﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        //const logger = Logger.getLogger('watchface_SashaCX75');
        const logger = DeviceRuntimeCore.HmLogger.getLogger('watchface_SashaCX75')
        //end of ignored block

        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_alarm_clock_icon_img = ''
        let normal_alarm_clock_current_text_font = ''
        let normal_sleep_icon_img = ''
        let normal_sleep_duration_total_font = ''
        let normal_system_lock_img = ''
        let normal_system_disconnect_img = ''
        let normal_battery_circle_scale = ''
        let normal_battery_current_text_font = ''
        let normal_day_month_font = ''
        let normal_timerTimeUpdate = undefined;
        let normal_dow_text_font = ''
        let normal_DOW_Array = ['LU', 'MA', 'MI', 'JU', 'VI', 'SA', 'DO'];
        let normal_weather_image_progress_img_level = ''
        let normal_temperature_current_text_font = ''
        let normal_calorie_circle_scale = ''
        let normal_calorie_current_text_font = ''
        let normal_heart_rate_text_font = ''
        let normal_heart_rate_pointer_progress_img_pointer = ''
        let normal_step_current_text_font = ''
        let normal_step_pointer_progress_img_pointer = ''
        let normal_digital_clock_img_time = ''
        let normal_analog_clock_time_pointer_second = ''
        let idle_system_disconnect_img = ''
        let idle_system_clock_img = ''
        let idle_battery_current_text_font = ''
        let idle_analog_clock_time_pointer_hour = ''
        let idle_analog_clock_time_pointer_minute = ''
        let idle_analog_clock_time_pointer_second = ''
        let normal_step_jumpable_img_click = ''
        let normal_heart_jumpable_img_click = ''
        let normal_battery_jumpable_img_click = ''
        let normal_temperature_jumpable_img_click = ''
        let normal_alarm_jumpable_img_click = ''
        let normal_sleep_jumpable_img_click = ''
        let normal_fatBurning_jumpable_img_click = ''
        let Button_1 = ''
        let Button_2 = ''
        let Button_3 = ''
        let Button_4 = ''
        let timeSensor = '';
        let sleepSensor = '';


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            // FontName: 1Shentox-Regular.ttf; FontSize: 24
            hmUI.createWidget(hmUI.widget.TEXT, {
              x: 464,
              y: 464,
              w: 316,
              h: 34,
              text_size: 24,
              char_space: 0,
              line_space: 0,
              font: 'fonts/1Shentox-Regular.ttf',
              color: 0xFFC0C0C0,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              text: "0123456789 _-.,:;`'%°\\/",
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // FontName: 1Shentox-Regular.ttf; FontSize: 29; Cache: full
            hmUI.createWidget(hmUI.widget.TEXT, {
              x: 464,
              y: 464,
              w: 34,
              h: 34,
              text_size: 29,
              char_space: 0,
              line_space: 0,
              font: 'fonts/1Shentox-Regular.ttf',
              color: 0xFFFFFFFF,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.NONE,
              text: "0123456789 ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz АБВГДЕЁЖЗИЙКЛМНОПРСТУФХЦЧШЩЪЫЬЭЮЯабвгдеёжзийклмнопрстуфхцчшщъыьэюя  ҐЄІЇґєії _-.,:;`'%°\\/",
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // FontName: 1Shentox-Regular.ttf; FontSize: 25
            hmUI.createWidget(hmUI.widget.TEXT, {
              x: 464,
              y: 464,
              w: 326,
              h: 36,
              text_size: 25,
              char_space: 0,
              line_space: 0,
              font: 'fonts/1Shentox-Regular.ttf',
              color: 0xFFFFFFFF,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              text: "0123456789 _-.,:;`'%°\\/",
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            console.log('Watch_Face.ScreenNormal');
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 466,
              h: 466,
              src: '0.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_alarm_clock_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 63,
              y: 164,
              src: 'alarm.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_alarm_clock_current_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 17,
              y: 17,
              w: 432,
              h: 432,
              text_size: 24,
              char_space: 0,
              color: 0xFFC0C0C0,
              // use_text_circle: true,
              start_angle: -89,
              end_angle: -61,
              mode: 0,
              // radius: 216,
              align_h: hmUI.align.CENTER_H,
              padding: true,
              type: hmUI.data_type.ALARM_CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sleep_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 381,
              y: 164,
              src: 'sue.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sleep_duration_total_font = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 17,
              y: 17,
              w: 432,
              h: 432,
              text_size: 24,
              char_space: 0,
              font: 'fonts/1Shentox-Regular.ttf',
              color: 0xFFC0C0C0,
              // use_text_circle: true,
              start_angle: 62,
              end_angle: 89,
              mode: 0,
              // radius: 216,
              align_h: hmUI.align.CENTER_H,
              // padding: true,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_lock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 366,
              y: 284,
              src: 'can.png',
              type: hmUI.system_status.LOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 71,
              y: 284,
              src: 'bt.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_battery_circle_scale = hmUI.createWidget(hmUI.widget.Circle_Scale, {
              // center_x: 233,
              // center_y: 233,
              // start_angle: 116,
              // end_angle: 94,
              // radius: 191,
              // line_width: 4,
              // line_cap: Rounded,
              // color: 0xFFE10000,
              // mirror: False,
              // inversion: False,
              // alpha: 255,
              // type: hmUI.data_type.BATTERY,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            let screenType = hmSetting.getScreenType();
            normal_battery_circle_scale = hmUI.createWidget(hmUI.widget.ARC_PROGRESS, {
              center_x: 233,
              center_y: 233,
              start_angle: 116,
              end_angle: 94,
              radius: 189,
              line_width: 4,
              corner_flag: 0,
              color: 0xFFE10000,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            
            const battery = hmSensor.createSensor(hmSensor.id.BATTERY);
            battery.addEventListener(hmSensor.event.CHANGE, function() {
              scale_call();
            });

            normal_battery_current_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 45,
              y: 45,
              w: 376,
              h: 376,
              text_size: 24,
              char_space: 0,
              font: 'fonts/1Shentox-Regular.ttf',
              color: 0xFFFFFFFF,
              // use_text_circle: true,
              start_angle: 124,
              end_angle: 152,
              mode: 1,
              // radius: 188,
              align_h: hmUI.align.CENTER_H,
              unit_type: 1,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            if (!timeSensor) timeSensor = hmSensor.createSensor(hmSensor.id.TIME);
            normal_day_month_font = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 45,
              y: 45,
              w: 376,
              h: 376,
              text_size: 24,
              char_space: 0,
              color: 0xFFFFFFFF,
              // use_text_circle: true,
              start_angle: 24,
              end_angle: 56,
              mode: 0,
              // radius: 188,
              align_h: hmUI.align.CENTER_H,
              // padding: true,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            timeSensor.addEventListener(timeSensor.event.DAYCHANGE, function() {
              time_update(true);
            });

            normal_dow_text_font = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 300,
              y: 127,
              w: 53,
              h: 29,
              text_size: 29,
              char_space: 0,
              font: 'fonts/1Shentox-Regular.ttf',
              color: 0xFFFFFFFF,
              line_space: 0,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.CENTER_H,
              // unit_string: LU, MA, MI, JU, VI, SA, DO,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 125,
              y: 120,
              image_array: ["w_0.png","w_1.png","w_2.png","w_3.png","w_4.png","w_5.png","w_6.png","w_7.png","w_8.png","w_9.png","w_10.png","w_11.png","w_12.png","w_13.png","w_14.png","w_15.png","w_16.png","w_17.png","w_18.png","w_19.png","w_20.png","w_21.png","w_22.png","w_23.png","w_24.png","w_25.png","w_26.png","w_27.png","w_28.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 45,
              y: 45,
              w: 376,
              h: 376,
              text_size: 24,
              char_space: 0,
              font: 'fonts/1Shentox-Regular.ttf',
              color: 0xFFFFFFFF,
              // use_text_circle: true,
              start_angle: -56,
              end_angle: -23,
              mode: 0,
              // radius: 188,
              align_h: hmUI.align.CENTER_H,
              unit_type: 1,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_cal_circle_scale = hmUI.createWidget(hmUI.widget.Circle_Scale, {
              // center_x: 233,
              // center_y: 233,
              // start_angle: -115,
              // end_angle: -95,
              // radius: 191,
              // line_width: 4,
              // line_cap: Rounded,
              // color: 0xFFD90000,
              // mirror: False,
              // inversion: False,
              // alpha: 255,
              // type: hmUI.data_type.CAL,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_calorie_circle_scale = hmUI.createWidget(hmUI.widget.ARC_PROGRESS, {
              center_x: 233,
              center_y: 233,
              start_angle: -115,
              end_angle: -95,
              radius: 189,
              line_width: 4,
              corner_flag: 0,
              color: 0xFFD90000,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            
            const calorie = hmSensor.createSensor(hmSensor.id.CALORIE);
            calorie.addEventListener(hmSensor.event.CHANGE, function() {
              scale_call();
            });

            normal_calorie_current_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 45,
              y: 45,
              w: 376,
              h: 376,
              text_size: 24,
              char_space: 0,
              font: 'fonts/1Shentox-Regular.ttf',
              color: 0xFFFFFFFF,
              // use_text_circle: true,
              start_angle: 204,
              end_angle: 237,
              mode: 1,
              // radius: 188,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 191,
              y: 130,
              w: 87,
              h: 29,
              text_size: 25,
              char_space: 0,
              font: 'fonts/1Shentox-Regular.ttf',
              color: 0xFFFFFFFF,
              line_space: 0,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_pointer_progress_img_pointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
              src: 'heartpoint.png',
              center_x: 233,
              center_y: 119,
              x: 15,
              y: 63,
              start_angle: 0,
              end_angle: 360,
              invalid_visible: false,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 191,
              y: 305,
              w: 87,
              h: 29,
              text_size: 25,
              char_space: 0,
              font: 'fonts/1Shentox-Regular.ttf',
              color: 0xFFFFFFFF,
              line_space: 0,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_pointer_progress_img_pointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
              src: 'heartpoint.png',
              center_x: 233,
              center_y: 344,
              x: 16,
              y: 63,
              start_angle: 0,
              end_angle: 360,
              invalid_visible: false,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 65,
              hour_startY: 195,
              hour_array: ["hour_0.png","hour_1.png","hour_2.png","hour_3.png","hour_4.png","hour_5.png","hour_6.png","hour_7.png","hour_8.png","hour_9.png"],
              hour_zero: 1,
              hour_space: 0,
              hour_angle: 0,
              hour_unit_sc: 'dots.png',
              hour_unit_tc: 'dots.png',
              hour_unit_en: 'dots.png',
              hour_align: hmUI.align.CENTER_H,

              minute_startX: 245,
              minute_startY: 195,
              minute_array: ["hour_0.png","hour_1.png","hour_2.png","hour_3.png","hour_4.png","hour_5.png","hour_6.png","hour_7.png","hour_8.png","hour_9.png"],
              minute_zero: 1,
              minute_space: 0,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.CENTER_H,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_second = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              second_path: 'second.png',
              second_centerX: 233,
              second_centerY: 233,
              second_posX: 30,
              second_posY: 235,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            console.log('Watch_Face.ScreenAOD');

            idle_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 1,
              y: 221,
              src: 'bt.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 220,
              y: 0,
              src: 'alarm.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_battery_current_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 163,
              y: 438,
              w: 146,
              h: 29,
              text_size: 24,
              char_space: 0,
              font: 'fonts/1Shentox-Regular.ttf',
              color: 0xFFC0C0C0,
              line_space: 0,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.CENTER_H,
              unit_type: 1,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_analog_clock_time_pointer_hour = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              hour_path: 'hour.png',
              hour_centerX: 233,
              hour_centerY: 233,
              hour_posX: 30,
              hour_posY: 180,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_analog_clock_time_pointer_minute = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              minute_path: 'minute.png',
              minute_centerX: 233,
              minute_centerY: 233,
              minute_posX: 30,
              minute_posY: 237,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_analog_clock_time_pointer_second = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              second_path: 'secao.png',
              second_centerX: 233,
              second_centerY: 233,
              second_posX: 30,
              second_posY: 231,
              show_level: hmUI.show_level.ONLY_AOD,
            });
            console.log('Watch_Face.Shortcuts');

            normal_step_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 181,
              y: 289,
              w: 105,
              h: 103,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 175,
              y: 58,
              w: 115,
              h: 114,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 290,
              y: 298,
              w: 87,
              h: 97,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 83,
              y: 83,
              w: 78,
              h: 76,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_alarm_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 0,
              y: 138,
              w: 77,
              h: 93,
              type: hmUI.data_type.ALARM_CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sleep_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 385,
              y: 146,
              w: 83,
              h: 86,
              type: hmUI.data_type.SLEEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_fatBurning_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 83,
              y: 298,
              w: 87,
              h: 97,
              type: hmUI.data_type.FAT_BURNING,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            console.log('Watch_Face.Buttons');
            Button_1 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 295,
              y: 79,
              w: 87,
              h: 87,
              text: '',
              color: 0xFFFF8C00,
              text_size: 24,
              press_src: 'transparent.png',
              normal_src: 'transparent.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'ScheduleCalScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_2 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 81,
              y: 198,
              w: 146,
              h: 87,
              text: '',
              color: 0xFFFF8C00,
              text_size: 24,
              press_src: 'transparent.png',
              normal_src: 'transparent.png',
              click_func: (button_widget) => {
                hmApp.startApp({ appid: 1049670, url: 'page/wclk_showLayer' });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_3 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 241,
              y: 198,
              w: 146,
              h: 87,
              text: '',
              color: 0xFFFF8C00,
              text_size: 24,
              press_src: 'transparent.png',
              normal_src: 'transparent.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'StopWatchScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_4 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 190,
              y: 405,
              w: 87,
              h: 68,
              text: '',
              color: 0xFFFF8C00,
              text_size: 24,
              press_src: 'transparent.png',
              normal_src: 'transparent.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'AppListScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            //#region time_update
            function time_update(updateHour = false, updateMinute = false) {
              console.log('time_update()');
              let hour = timeSensor.hour;
              let minute = timeSensor.minute;
              let second = timeSensor.second;
              let format_hour = timeSensor.format_hour;

              console.log('day/month font');
              if (updateHour) {
                let normal_DayStr = timeSensor.day.toString();
                let normal_MonthStr = timeSensor.month.toString();
                normal_DayStr = normal_DayStr.padStart(2, '0');
                normal_MonthStr = normal_MonthStr.padStart(2, '0');
                let normal_DayMonthStr = '--';
                const dateFormat = hmSetting.getDateFormat();
                if (dateFormat == 0 || dateFormat == 2) {
                  normal_DayMonthStr = normal_MonthStr + '/' + normal_DayStr;
                }
                if (dateFormat == 1) {
                  normal_DayMonthStr = normal_DayStr + '/' + normal_MonthStr;
                }
                normal_day_month_font.setProperty(hmUI.prop.TEXT, normal_DayMonthStr );
              };

              console.log('day of week font');
              if (updateHour) {
                let normal_DOW_Str = normal_DOW_Array[timeSensor.week-1];
                normal_dow_text_font.setProperty(hmUI.prop.TEXT, normal_DOW_Str );
                if (timeSensor.week >= 6) normal_dow_text_font.setProperty(hmUI.prop.COLOR, 0xFFFF0000);
                else normal_dow_text_font.setProperty(hmUI.prop.COLOR, 0xFFFFFFFF);
              };

            };

            //#endregion
            if (!sleepSensor) sleepSensor = hmSensor.createSensor(hmSensor.id.SLEEP);
            //#region sleep_update
            function sleep_update() {
              console.log('sleep_update()');

              console.log('sleep duration total time');
              let sleepDurationTotalTime = sleepSensor.getTotalTime();
              let sleepDurationTotalHour = Math.floor(sleepDurationTotalTime / 60);
              let sleepDurationTotalMin = sleepDurationTotalTime % 60;

              let normal_sleepDurationTotalHourStr = sleepDurationTotalHour.toString();
              normal_sleepDurationTotalHourStr = normal_sleepDurationTotalHourStr.padStart(2, '0');
              let normal_sleepDurationTotalMinStr = sleepDurationTotalMin.toString().padStart(2, '0');
              let normal_SleepDurationStr = normal_sleepDurationTotalHourStr + ':' + normal_sleepDurationTotalMinStr;
              if (normal_sleep_duration_total_font) normal_sleep_duration_total_font.setProperty(hmUI.prop.TEXT, normal_SleepDurationStr);

            };

            //#endregion
            function scale_call() {
              console.log('scale_call()');

                console.log('update scales BATTERY');
                
                let valueBattery = battery.current;
                let targetBattery = 100;
                let progressBattery = valueBattery/targetBattery;
                if (progressBattery > 1) progressBattery = 1;
                let progress_cs_normal_battery = progressBattery;

                if (screenType != hmSetting.screen_type.AOD) {

                  // normal_battery_circle_scale_circle_scale
                  let level = Math.round(progress_cs_normal_battery * 100);
                  if (normal_battery_circle_scale) {
                    normal_battery_circle_scale.setProperty(hmUI.prop.MORE, {                      
                      center_x: 233,
                      center_y: 233,
                      start_angle: 116,
                      end_angle: 94,
                      radius: 189,
                      line_width: 4,
                      corner_flag: 0,
                      color: 0xFFE10000,
                      show_level: hmUI.show_level.ONLY_NORMAL,
                      level: level,
                    });
                  };
                };

                console.log('update scales CALORIE');
                
                let valueCalories = calorie.current;
                let targetCalories = calorie.target;
                let progressCalories = valueCalories/targetCalories;
                if (progressCalories > 1) progressCalories = 1;
                let progress_cs_normal_calorie = progressCalories;

                if (screenType != hmSetting.screen_type.AOD) {

                  // normal_calorie_circle_scale_circle_scale
                  let level = Math.round(progress_cs_normal_calorie * 100);
                  if (normal_calorie_circle_scale) {
                    normal_calorie_circle_scale.setProperty(hmUI.prop.MORE, {                      
                      center_x: 233,
                      center_y: 233,
                      start_angle: -115,
                      end_angle: -95,
                      radius: 189,
                      line_width: 4,
                      corner_flag: 0,
                      color: 0xFFD90000,
                      show_level: hmUI.show_level.ONLY_NORMAL,
                      level: level,
                    });
                  };
                };

            };

            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                console.log('resume_call()');
                scale_call();
                time_update(true, true);
                sleep_update();
                if (screenType == hmSetting.screen_type.WATCHFACE) {
                  if (!normal_timerTimeUpdate) {
                    normal_timerTimeUpdate = timer.createTimer(0, 1000, (function (option) {
                      let updateHour = timeSensor.minute == 0;
                      let updateMinute = timeSensor.second < 2;
                      time_update(updateHour, updateMinute);
                    }));  // end timer 
                  };  // end timer check
                };  // end screenType


              }),
              pause_call: (function () {
                console.log('pause_call()');
                if (normal_timerTimeUpdate) {
                  timer.stopTimer(normal_timerTimeUpdate);
                  normal_timerTimeUpdate = undefined;
                }

              }),
            });

                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}