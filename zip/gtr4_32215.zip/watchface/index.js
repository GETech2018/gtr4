﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.0.1
    ** Copyright © CashaCX75. All Rights Reserved
    */

    try {
    (()=>{
        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_temperature_current_text_img = ''
        let normal_heart_rate_icon_img = ''
        let normal_heart_rate_text_text_img = ''
        let normal_step_icon_img = ''
        let normal_step_current_text_img = ''
        let normal_date_img_date_month_img = ''
        let normal_date_img_date_week_img = ''
        let normal_date_img_date_day = ''
        let normal_battery_icon_img = ''
        let normal_battery_text_text_img = ''
        let normal_battery_text_separator_img = ''
        let normal_battery_pointer_progress_img_pointer = ''
        let normal_digital_clock_img_time = ''
        let normal_analog_clock_time_pointer_hour = ''
        let normal_analog_clock_time_pointer_minute = ''
        let normal_analog_clock_time_pointer_second = ''
        let idle_background_bg_img = ''
        let idle_temperature_current_text_img = ''
        let idle_heart_rate_icon_img = ''
        let idle_heart_rate_text_text_img = ''
        let idle_step_icon_img = ''
        let idle_step_current_text_img = ''
        let idle_date_img_date_month_img = ''
        let idle_date_img_date_week_img = ''
        let idle_date_img_date_day = ''
        let idle_battery_icon_img = ''
        let idle_battery_text_text_img = ''
        let idle_battery_text_separator_img = ''
        let idle_battery_pointer_progress_img_pointer = ''
        let idle_digital_clock_img_time = ''
        let idle_analog_clock_time_pointer_hour = ''
        let idle_analog_clock_time_pointer_minute = ''
        let idle_analog_clock_time_pointer_second = ''
        let normal_alarm_jumpable_img_click = ''
        let normal_altimeter_jumpable_img_click = ''
        let normal_temperature_jumpable_img_click = ''
        let normal_heart_jumpable_img_click = ''
        let normal_step_jumpable_img_click = ''


        //dynamic modify end
        const e = __$$hmAppManager$$__.currentApp;
        const o = e.current
          , {px: i} = (new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(e,o)),
        e.__globals__)
          , n = Logger.getLogger("watchface6");
        o.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 466,
              h: 466,
              src: '001.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 70,
              y: 257,
              font_array: ["016.png","017.png","018.png","019.png","020.png","021.png","022.png","023.png","024.png","025.png"],
              padding: false,
              h_space: 0,
              unit_sc: '049.png',
              unit_tc: '049.png',
              unit_en: '049.png',
              negative_image: '050.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 306,
              y: 96,
              src: '045.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 299,
              y: 89,
              font_array: ["006.png","007.png","008.png","009.png","010.png","011.png","012.png","013.png","014.png","015.png"],
              padding: false,
              h_space: 2,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 293,
              y: 191,
              src: '046.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 279,
              y: 137,
              font_array: ["006.png","007.png","008.png","009.png","010.png","011.png","012.png","013.png","014.png","015.png"],
              padding: false,
              h_space: 1,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_month_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 192,
              month_startY: 319,
              month_sc_array: ["026.png","027.png","028.png","029.png","030.png","031.png","032.png","033.png","034.png","035.png","036.png","037.png"],
              month_tc_array: ["026.png","027.png","028.png","029.png","030.png","031.png","032.png","033.png","034.png","035.png","036.png","037.png"],
              month_en_array: ["026.png","027.png","028.png","029.png","030.png","031.png","032.png","033.png","034.png","035.png","036.png","037.png"],
              month_is_character: true ,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 244,
              y: 273,
              week_en: ["038.png","039.png","040.png","041.png","042.png","043.png","044.png"],
              week_tc: ["038.png","039.png","040.png","041.png","042.png","043.png","044.png"],
              week_sc: ["038.png","039.png","040.png","041.png","042.png","043.png","044.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 196,
              day_startY: 256,
              day_sc_array: ["006.png","007.png","008.png","009.png","010.png","011.png","012.png","013.png","014.png","015.png"],
              day_tc_array: ["006.png","007.png","008.png","009.png","010.png","011.png","012.png","013.png","014.png","015.png"],
              day_en_array: ["006.png","007.png","008.png","009.png","010.png","011.png","012.png","013.png","014.png","015.png"],
              day_zero: 0,
              day_space: 0,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 137,
              y: 149,
              src: '048.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 121,
              y: 179,
              font_array: ["016.png","017.png","018.png","019.png","020.png","021.png","022.png","023.png","024.png","025.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 167,
              y: 179,
              src: '052.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_pointer_progress_img_pointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
              src: '005.png',
              center_x: 150,
              center_y: 187,
              x: 9,
              y: 58,
              start_angle: -91,
              end_angle: 92,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 324,
              hour_startY: 257,
              hour_array: ["016.png","017.png","018.png","019.png","020.png","021.png","022.png","023.png","024.png","025.png"],
              hour_zero: 0,
              hour_space: 0,
              hour_unit_sc: '051.png',
              hour_unit_tc: '051.png',
              hour_unit_en: '051.png',
              hour_align: hmUI.align.CENTER_H,

              minute_startX: 0,
              minute_startY: 0,
              minute_array: ["016.png","017.png","018.png","019.png","020.png","021.png","022.png","023.png","024.png","025.png"],
              minute_zero: 1,
              minute_space: 0,
              minute_follow: 1,
              minute_align: hmUI.align.CENTER_H,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_hour = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              hour_path: '002.png',
              hour_centerX: 233,
              hour_centerY: 233,
              hour_posX: 19,
              hour_posY: 124,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_minute = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              minute_path: '003.png',
              minute_centerX: 233,
              minute_centerY: 233,
              minute_posX: 17,
              minute_posY: 192,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_second = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              second_path: '004.png',
              second_centerX: 233,
              second_centerY: 234,
              second_posX: 12,
              second_posY: 212,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            idle_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 466,
              h: 466,
              src: '001.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 70,
              y: 257,
              font_array: ["016.png","017.png","018.png","019.png","020.png","021.png","022.png","023.png","024.png","025.png"],
              padding: false,
              h_space: 0,
              unit_sc: '049.png',
              unit_tc: '049.png',
              unit_en: '049.png',
              negative_image: '050.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_heart_rate_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 306,
              y: 96,
              src: '045.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 299,
              y: 89,
              font_array: ["006.png","007.png","008.png","009.png","010.png","011.png","012.png","013.png","014.png","015.png"],
              padding: false,
              h_space: 2,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_step_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 293,
              y: 191,
              src: '046.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 279,
              y: 137,
              font_array: ["006.png","007.png","008.png","009.png","010.png","011.png","012.png","013.png","014.png","015.png"],
              padding: false,
              h_space: 1,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_month_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 192,
              month_startY: 319,
              month_sc_array: ["026.png","027.png","028.png","029.png","030.png","031.png","032.png","033.png","034.png","035.png","036.png","037.png"],
              month_tc_array: ["026.png","027.png","028.png","029.png","030.png","031.png","032.png","033.png","034.png","035.png","036.png","037.png"],
              month_en_array: ["026.png","027.png","028.png","029.png","030.png","031.png","032.png","033.png","034.png","035.png","036.png","037.png"],
              month_is_character: true ,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 244,
              y: 273,
              week_en: ["038.png","039.png","040.png","041.png","042.png","043.png","044.png"],
              week_tc: ["038.png","039.png","040.png","041.png","042.png","043.png","044.png"],
              week_sc: ["038.png","039.png","040.png","041.png","042.png","043.png","044.png"],
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 196,
              day_startY: 256,
              day_sc_array: ["006.png","007.png","008.png","009.png","010.png","011.png","012.png","013.png","014.png","015.png"],
              day_tc_array: ["006.png","007.png","008.png","009.png","010.png","011.png","012.png","013.png","014.png","015.png"],
              day_en_array: ["006.png","007.png","008.png","009.png","010.png","011.png","012.png","013.png","014.png","015.png"],
              day_zero: 0,
              day_space: 0,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_battery_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 137,
              y: 149,
              src: '048.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 121,
              y: 179,
              font_array: ["016.png","017.png","018.png","019.png","020.png","021.png","022.png","023.png","024.png","025.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_battery_text_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 167,
              y: 179,
              src: '052.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_battery_pointer_progress_img_pointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
              src: '005.png',
              center_x: 150,
              center_y: 187,
              x: 9,
              y: 58,
              start_angle: -91,
              end_angle: 92,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 324,
              hour_startY: 257,
              hour_array: ["016.png","017.png","018.png","019.png","020.png","021.png","022.png","023.png","024.png","025.png"],
              hour_zero: 0,
              hour_space: 0,
              hour_unit_sc: '051.png',
              hour_unit_tc: '051.png',
              hour_unit_en: '051.png',
              hour_align: hmUI.align.CENTER_H,

              minute_startX: 0,
              minute_startY: 0,
              minute_array: ["016.png","017.png","018.png","019.png","020.png","021.png","022.png","023.png","024.png","025.png"],
              minute_zero: 1,
              minute_space: 0,
              minute_follow: 1,
              minute_align: hmUI.align.CENTER_H,

              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_analog_clock_time_pointer_hour = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              hour_path: '002.png',
              hour_centerX: 233,
              hour_centerY: 233,
              hour_posX: 19,
              hour_posY: 124,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_analog_clock_time_pointer_minute = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              minute_path: '003.png',
              minute_centerX: 233,
              minute_centerY: 233,
              minute_posX: 17,
              minute_posY: 192,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_analog_clock_time_pointer_second = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              second_path: '004.png',
              second_centerX: 233,
              second_centerY: 234,
              second_posX: 12,
              second_posY: 212,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            normal_alarm_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 182,
              y: -8,
              w: 100,
              h: 100,
              src: '047.png',
              type: hmUI.data_type.ALARM_CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_altimeter_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 224,
              y: 276,
              w: 100,
              h: 100,
              src: '047.png',
              type: hmUI.data_type.ALTIMETER,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 54,
              y: 251,
              w: 100,
              h: 100,
              src: '047.png',
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 287,
              y: 82,
              w: 100,
              h: 70,
              src: '047.png',
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 273,
              y: 163,
              w: 100,
              h: 70,
              src: '047.png',
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


                //dynamic modify end
            },
            onInit() {
                n.log("index page.js on init invoke")
            },
            build() {
                this.init_view(),
                n.log("index page.js on ready invoke")
            },
            onDestroy() {
                n.log("index page.js on destroy invoke")
            }
        })
    }
    )()
} catch (e) {
    console.log("Mini Program Error", e),
    e && e.stack && e.stack.split(/\n/).forEach((e=>console.log("error stack", e)))
}
