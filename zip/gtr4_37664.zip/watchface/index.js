﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        const logger = Logger.getLogger('watchface_SashaCX75');
        //end of ignored block

        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_system_dnd_img = ''
        let normal_system_disconnect_img = ''
        let normal_system_clock_img = ''
        let normal_date_img_date_month_img = ''
        let normal_date_img_date_week_img = ''
        let normal_step_current_text_img = ''
        let normal_step_image_progress_img_level = ''
        let normal_date_img_date_day = ''
        let normal_battery_text_text_img = ''
        let normal_digital_clock_img_time = ''
        let normal_digital_clock_img_time_AmPm = ''
        let idle_background_bg = ''
        let idle_date_img_date_month_img = ''
        let idle_battery_text_text_img = ''
        let idle_battery_text_separator_img = ''
        let idle_date_img_date_week_img = ''
        let idle_date_img_date_day = ''
        let idle_digital_clock_img_time = ''
        let normal_alarm_jumpable_img_click = ''
        let normal_sunrise_jumpable_img_click = ''
        let normal_step_jumpable_img_click = ''
        let Button_1 = ''
        let Button_2 = ''
        let Button_3 = ''


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            console.log('Watch_Face.ScreenNormal');
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 466,
              h: 466,
              src: 'bg.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_dnd_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 406,
              y: 258,
              src: 'NO MOL.png',
              type: hmUI.system_status.DISTURB,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 111,
              y: 40,
              src: 'bt9.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 348,
              y: 69,
              src: 'ALARMA.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_month_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 85,
              month_startY: 289,
              month_sc_array: ["mes01.png","mes02.png","mes03.png","mes04.png","mes05.png","mes06.png","mes07.png","mes08.png","mes09.png","mes10.png","mes11.png","mes12.png"],
              month_tc_array: ["mes01.png","mes02.png","mes03.png","mes04.png","mes05.png","mes06.png","mes07.png","mes08.png","mes09.png","mes10.png","mes11.png","mes12.png"],
              month_en_array: ["mes01.png","mes02.png","mes03.png","mes04.png","mes05.png","mes06.png","mes07.png","mes08.png","mes09.png","mes10.png","mes11.png","mes12.png"],
              month_is_character: true ,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 12,
              y: 254,
              week_en: ["dia1.png","dia2.png","dia3.png","dia4.png","dia5.png","dia6.png","dia7.png"],
              week_tc: ["dia1.png","dia2.png","dia3.png","dia4.png","dia5.png","dia6.png","dia7.png"],
              week_sc: ["dia1.png","dia2.png","dia3.png","dia4.png","dia5.png","dia6.png","dia7.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 178,
              y: 401,
              font_array: ["data_0.png","data_1.png","data_2.png","data_3.png","data_4.png","data_5.png","data_6.png","data_7.png","data_8.png","data_9.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 94,
              y: 373,
              image_array: ["step_prog_1.png","step_prog_2.png","step_prog_3.png","step_prog_4.png","step_prog_5.png","step_prog_6.png","step_prog_7.png","step_prog_8.png","step_prog_9.png","step_prog_10.png","step_prog_11.png","step_prog_12.png","step_prog_13.png","step_prog_14.png","step_prog_15.png","step_prog_16.png","step_prog_17.png","step_prog_18.png"],
              image_length: 18,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 29,
              day_startY: 279,
              day_sc_array: ["data_0.png","data_1.png","data_2.png","data_3.png","data_4.png","data_5.png","data_6.png","data_7.png","data_8.png","data_9.png"],
              day_tc_array: ["data_0.png","data_1.png","data_2.png","data_3.png","data_4.png","data_5.png","data_6.png","data_7.png","data_8.png","data_9.png"],
              day_en_array: ["data_0.png","data_1.png","data_2.png","data_3.png","data_4.png","data_5.png","data_6.png","data_7.png","data_8.png","data_9.png"],
              day_zero: 1,
              day_space: 0,
              day_align: hmUI.align.LEFT,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 201,
              y: 17,
              font_array: ["data_0.png","data_1.png","data_2.png","data_3.png","data_4.png","data_5.png","data_6.png","data_7.png","data_8.png","data_9.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 71,
              hour_startY: 12,
              hour_array: ["hour_0.png","hour_1.png","hour_2.png","hour_3.png","hour_4.png","hour_5.png","hour_6.png","hour_7.png","hour_8.png","hour_9.png"],
              hour_zero: 1,
              hour_space: 0,
              hour_angle: 0,
              hour_align: hmUI.align.CENTER_H,

              minute_startX: 215,
              minute_startY: 185,
              minute_array: ["min_0.png","min_1.png","min_2.png","min_3.png","min_4.png","min_5.png","min_6.png","min_7.png","min_8.png","min_9.png"],
              minute_zero: 1,
              minute_space: 0,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.CENTER_H,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time_AmPm = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              am_x: 325,
              am_y: 184,
              am_sc_path: 'am.png',
              am_en_path: 'am.png',
              pm_x: 325,
              pm_y: 184,
              pm_sc_path: 'pm.png',
              pm_en_path: 'pm.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            console.log('Watch_Face.ScreenAOD');
            idle_background_bg = hmUI.createWidget(hmUI.widget.FILL_RECT, {
              x: 0,
              y: 0,
              w: 466,
              h: 466,
              color: '0xFF000000',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_month_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 85,
              month_startY: 289,
              month_sc_array: ["mes01.png","mes02.png","mes03.png","mes04.png","mes05.png","mes06.png","mes07.png","mes08.png","mes09.png","mes10.png","mes11.png","mes12.png"],
              month_tc_array: ["mes01.png","mes02.png","mes03.png","mes04.png","mes05.png","mes06.png","mes07.png","mes08.png","mes09.png","mes10.png","mes11.png","mes12.png"],
              month_en_array: ["mes01.png","mes02.png","mes03.png","mes04.png","mes05.png","mes06.png","mes07.png","mes08.png","mes09.png","mes10.png","mes11.png","mes12.png"],
              month_is_character: true ,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 193,
              y: 415,
              font_array: ["data_0.png","data_1.png","data_2.png","data_3.png","data_4.png","data_5.png","data_6.png","data_7.png","data_8.png","data_9.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_battery_text_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 165,
              y: 416,
              src: 'power.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 12,
              y: 254,
              week_en: ["dia1.png","dia2.png","dia3.png","dia4.png","dia5.png","dia6.png","dia7.png"],
              week_tc: ["dia1.png","dia2.png","dia3.png","dia4.png","dia5.png","dia6.png","dia7.png"],
              week_sc: ["dia1.png","dia2.png","dia3.png","dia4.png","dia5.png","dia6.png","dia7.png"],
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 29,
              day_startY: 279,
              day_sc_array: ["data_aod_0.png","data_aod_1.png","data_aod_2.png","data_aod_3.png","data_aod_4.png","data_aod_5.png","data_aod_6.png","data_aod_7.png","data_aod_8.png","data_aod_9.png"],
              day_tc_array: ["data_aod_0.png","data_aod_1.png","data_aod_2.png","data_aod_3.png","data_aod_4.png","data_aod_5.png","data_aod_6.png","data_aod_7.png","data_aod_8.png","data_aod_9.png"],
              day_en_array: ["data_aod_0.png","data_aod_1.png","data_aod_2.png","data_aod_3.png","data_aod_4.png","data_aod_5.png","data_aod_6.png","data_aod_7.png","data_aod_8.png","data_aod_9.png"],
              day_zero: 1,
              day_space: 0,
              day_align: hmUI.align.LEFT,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 71,
              hour_startY: 12,
              hour_array: ["hour_aod_1.png","hour_aod_2.png","hour_aod_3.png","hour_aod_4.png","hour_aod_5.png","hour_aod_6.png","hour_aod_7.png","hour_aod_8.png","hour_aod_9.png","hour_aod_10.png"],
              hour_zero: 1,
              hour_space: 0,
              hour_angle: 0,
              hour_align: hmUI.align.CENTER_H,

              minute_startX: 215,
              minute_startY: 185,
              minute_array: ["min_aod_1.png","min_aod_2.png","min_aod_3.png","min_aod_4.png","min_aod_5.png","min_aod_6.png","min_aod_7.png","min_aod_8.png","min_aod_9.png","min_aod_10.png"],
              minute_zero: 1,
              minute_space: 0,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.CENTER_H,

              show_level: hmUI.show_level.ONLY_AOD,
            });
            
            // disconnectAlert = hmUI.createWidget(hmUI.widget.DisconnectAlert, {
              // disconneсnt_vibrate_type: 0,
              // disconneсnt_toast_text: BT DESC.,
              // conneсnt_vibrate_type: 0,
              // conneсnt_toast_text: BT CON.,
            // });

            // vibration when connecting or disconnecting

            function checkConnection() {
              console.log('checkConnection()');
              hmBle.removeListener;
              hmBle.addListener(function (status) {
                if(!status) {
                  hmUI.showToast({text: "BT DESC."});
                  vibro(0);
                }
                if(status) {
                  hmUI.showToast({text: "BT CON."});
                  vibro(0);
                }
              });
            }

            // end vibration when connecting or disconnecting
            // vibrate function

            const vibrate = hmSensor.createSensor(hmSensor.id.VIBRATE);
            let timer_StopVibrate = null;


            function vibro(scene = 25) {
              let stopDelay = 50;
              stopVibro();
              vibrate.stop();
              vibrate.scene = scene;
              if(scene < 23 || scene > 25) stopDelay = 1300;
              vibrate.start();
              if (scene != 1) timer_StopVibrate = timer.createTimer(stopDelay, 3000, stopVibro, {});
            }

            function stopVibro(){
              vibrate.stop();
              if(timer_StopVibrate) timer.stopTimer(timer_StopVibrate);
            }

            // end vibrate function
            console.log('Watch_Face.Shortcuts');

            normal_alarm_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 335,
              y: 64,
              w: 70,
              h: 57,
              type: hmUI.data_type.ALARM_CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sunrise_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 340,
              y: 187,
              w: 50,
              h: 50,
              type: hmUI.data_type.SUN_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 93,
              y: 374,
              w: 300,
              h: 70,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            console.log('Watch_Face.Buttons');
            Button_1 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 184,
              y: 4,
              w: 101,
              h: 69,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'transparent.png',
              normal_src: 'transparent.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'PowerSaveHintScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_2 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 13,
              y: 255,
              w: 165,
              h: 69,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'transparent.png',
              normal_src: 'transparent.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'ScheduleCalScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_3 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 7,
              y: 172,
              w: 68,
              h: 69,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'transparent.png',
              normal_src: 'transparent.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'PhoneHomeScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                console.log('resume_call()');
                checkConnection();
                stopVibro();

              }),
              pause_call: (function () {
                console.log('pause_call()');
                stopVibro();

              }),
            });

                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}