﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        //const logger = Logger.getLogger('watchface_SashaCX75');
        const logger = DeviceRuntimeCore.HmLogger.getLogger('watchface_SashaCX75')
        //end of ignored block

        //dynamic modify start

        
        console.log('user_functions.js');
        // start user_functions.js

let time24 = hmSensor.createSensor(hmSensor.id.TIME);
let normal_24Hcheck =''

function check24h(){
if (time24.is24Hour){
normal_24Hcheck.setProperty(hmUI.prop.VISIBLE, true);
}

if (!time24.is24Hour){
normal_24Hcheck.setProperty(hmUI.prop.VISIBLE, false);
}

}
        // end user_functions.js

        let normal_background_bg = ''
        let normal_weather_image_progress_img_level = ''
        let normal_city_name_text = ''
        let normal_temperature_current_text_img = ''
        let normal_moon_image_progress_img_level = ''
        let normal_date_img_date_year = ''
        let normal_date_img_date_day = ''
        let normal_date_img_date_month_img = ''
        let normal_distance_text_text_img = ''
        let normal_calorie_current_text_img = ''
        let normal_altimeter_text_text_img = ''
        let normal_heart_rate_text_text_img = ''
        let normal_date_img_date_week_img = ''
        let normal_step_linear_scale = ''
        let normal_step_current_text_img = ''
        let normal_system_disconnect_img = ''
        let normal_system_clock_img = ''
        let normal_battery_circle_scale = ''
        let normal_battery_icon_img = ''
        let normal_battery_text_text_img = ''
        let normal_digital_clock_img_time_AmPm = ''
        let normal_digital_clock_img_time = ''
        let normal_digital_clock_hour_separator_img = ''
        let normal_digital_clock_minute_separator_img = ''
        let image_top_img = ''
        let normal_cal_jumpable_img_click = ''
        let normal_battery_jumpable_img_click = ''
        let normal_alarm_jumpable_img_click = ''
        let Button_1 = ''
        let Button_2 = ''
        let Button_3 = ''


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            console.log('Watch_Face.ScreenNormal');
            normal_background_bg = hmUI.createWidget(hmUI.widget.FILL_RECT, {
              x: 0,
              y: 0,
              w: 466,
              h: 466,
              color: '0xFF000000',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 0,
              y: 0,
              image_array: ["w_1.png","w_2.png","w_3.png","w_4.png","w_5.png","w_6.png","w_7.png","w_8.png","w_9.png","w_10.png","w_11.png","w_12.png","w_13.png","w_14.png","w_15.png","w_16.png","w_17.png","w_18.png","w_19.png","w_20.png","w_21.png","w_22.png","w_23.png","w_24.png","w_25.png","w_26.png","w_27.png","w_28.png","w_29.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
              const weatherSensor = hmSensor.createSensor(hmSensor.id.WEATHER);

            normal_city_name_text = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 155,
              y: 140,
              w: 155,
              h: 29,
              text_size: 17,
              char_space: 0,
              color: 0xFFFFFFFF,
              line_space: 0,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.NONE,
              align_h: hmUI.align.CENTER_H,
              // unit_type: 1,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 145,
              y: 101,
              font_array: ["temp_1.png","temp_2.png","temp_3.png","temp_4.png","temp_5.png","temp_6.png","temp_7.png","temp_8.png","temp_9.png","temp_10.png"],
              padding: false,
              h_space: -5,
              unit_sc: 'degC.png',
              unit_tc: 'degC.png',
              unit_en: 'degC.png',
              imperial_unit_sc: 'degF.png',
              imperial_unit_tc: 'degF.png',
              imperial_unit_en: 'degF.png',
              negative_image: 'minus.png',
              invalid_image: 'error.png',
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            const temperatureUnit = hmSetting.getTemperatureUnit();
            //#region temperatureUnit
            if (temperatureUnit == 1) {
              normal_temperature_current_text_img.setProperty(hmUI.prop.MORE, {
                x: 145,
                y: 101,
                font_array: ["temp_1.png","temp_2.png","temp_3.png","temp_4.png","temp_5.png","temp_6.png","temp_7.png","temp_8.png","temp_9.png","temp_10.png"],
                padding: false,
                h_space: -5,
                unit_sc: 'degF.png',
                unit_tc: 'degF.png',
                unit_en: 'degF.png',
                imperial_unit_sc: 'degC.png',
                imperial_unit_tc: 'degC.png',
                imperial_unit_en: 'degC.png',
                negative_image: 'minus.png',
                invalid_image: 'error.png',
                align_h: hmUI.align.RIGHT,
                type: hmUI.data_type.WEATHER_CURRENT,
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
            };
            //#endregion

            normal_moon_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 326,
              y: 105,
              image_array: ["moon_01.png","moon_1.png","moon_02.png","moon_2.png","moon_03.png","moon_3.png","moon_04.png","moon_4.png","moon_05.png","moon_5.png","moon_06.png","moon_6.png","moon_07.png","moon_7.png","moon_08.png","moon_8.png","moon_09.png","moon_9.png","moon_10.png","moon_11.png","moon_12.png","moon_13.png","moon_14.png","moon_15.png","moon_16.png","moon_17.png","moon_18.png","moon_19.png","moon_20.png","moon_21.png"],
              image_length: 30,
              type: hmUI.data_type.MOON,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_year = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              year_startX: 223,
              year_startY: 404,
              year_sc_array: ["power_1.png","power_2.png","power_3.png","power_4.png","power_5.png","power_6.png","power_7.png","power_8.png","power_9.png","power_10.png"],
              year_tc_array: ["power_1.png","power_2.png","power_3.png","power_4.png","power_5.png","power_6.png","power_7.png","power_8.png","power_9.png","power_10.png"],
              year_en_array: ["power_1.png","power_2.png","power_3.png","power_4.png","power_5.png","power_6.png","power_7.png","power_8.png","power_9.png","power_10.png"],
              year_zero: 1,
              year_space: 0,
              year_align: hmUI.align.CENTER_H,
              year_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 175,
              day_startY: 364,
              day_sc_array: ["step_1.png","step_2.png","step_3.png","step_4.png","step_5.png","step_6.png","step_7.png","step_8.png","step_9.png","step_10.png"],
              day_tc_array: ["step_1.png","step_2.png","step_3.png","step_4.png","step_5.png","step_6.png","step_7.png","step_8.png","step_9.png","step_10.png"],
              day_en_array: ["step_1.png","step_2.png","step_3.png","step_4.png","step_5.png","step_6.png","step_7.png","step_8.png","step_9.png","step_10.png"],
              day_zero: 0,
              day_space: 0,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_month_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 223,
              month_startY: 364,
              month_sc_array: ["month_01.png","month_02.png","month_03.png","month_04.png","month_05.png","month_06.png","month_07.png","month_08.png","month_09.png","month_10.png","month_11.png","month_12.png"],
              month_tc_array: ["month_01.png","month_02.png","month_03.png","month_04.png","month_05.png","month_06.png","month_07.png","month_08.png","month_09.png","month_10.png","month_11.png","month_12.png"],
              month_en_array: ["month_01.png","month_02.png","month_03.png","month_04.png","month_05.png","month_06.png","month_07.png","month_08.png","month_09.png","month_10.png","month_11.png","month_12.png"],
              month_is_character: true ,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_distance_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 325,
              y: 284,
              font_array: ["burn_1.png","burn_2.png","burn_3.png","burn_4.png","burn_5.png","burn_6.png","burn_7.png","burn_8.png","burn_9.png","burn_10.png"],
              padding: false,
              h_space: -3,
              dot_image: 'seperatorK.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.DISTANCE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_calorie_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 325,
              y: 252,
              font_array: ["burn_1.png","burn_2.png","burn_3.png","burn_4.png","burn_5.png","burn_6.png","burn_7.png","burn_8.png","burn_9.png","burn_10.png"],
              padding: false,
              h_space: -3,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_altimeter_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 266,
              y: 103,
              font_array: ["pressure_1.png","pressure_2.png","pressure_3.png","pressure_4.png","pressure_5.png","pressure_6.png","pressure_7.png","pressure_8.png","pressure_9.png","pressure_10.png"],
              padding: false,
              h_space: -4,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.ALTIMETER,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 75,
              y: 267,
              font_array: ["step_1.png","step_2.png","step_3.png","step_4.png","step_5.png","step_6.png","step_7.png","step_8.png","step_9.png","step_10.png"],
              padding: false,
              h_space: -3,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 108,
              y: 320,
              week_en: ["day_1.png","day_2.png","day_3.png","day_4.png","day_5.png","day_6.png","day_7.png"],
              week_tc: ["day_1.png","day_2.png","day_3.png","day_4.png","day_5.png","day_6.png","day_7.png"],
              week_sc: ["day_1.png","day_2.png","day_3.png","day_4.png","day_5.png","day_6.png","day_7.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            let screenType = hmSetting.getScreenType();
            if (screenType != hmSetting.screen_type.AOD) {
              normal_step_linear_scale = hmUI.createWidget(hmUI.widget.FILL_RECT);
            };

            // normal_step_linear_scale = hmUI.createWidget(hmUI.widget.Linear_Scale, {
              // start_x: 153,
              // start_y: 308,
              // color: 0xFFFF5400,
              // lenght: -58,
              // line_width: 12,
              // line_cap: Flat,
              // vertical: True,
              // mirror: False,
              // inversion: False,
              // alpha: 255,
              // type: hmUI.data_type.STEP,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });
            
            const step = hmSensor.createSensor(hmSensor.id.STEP);
            step.addEventListener(hmSensor.event.CHANGE, function() {
              scale_call();
            });

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 188,
              y: 267,
              font_array: ["step_1.png","step_2.png","step_3.png","step_4.png","step_5.png","step_6.png","step_7.png","step_8.png","step_9.png","step_10.png"],
              padding: false,
              h_space: -3,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            console.log('user_script.js');
            // start user_script.js
const deviceInfo1 = hmSetting.getDeviceInfo();
            normal_24Hcheck = hmUI.createWidget(hmUI.widget.IMG, {
              x: deviceInfo1.width / 480 * 407,
              y: deviceInfo1.height / 480 * 230,
              src: 'Clock24H.png',
            show_level: hmUI.show_level.ALL,

            });
check24h()
            // end user_script.js

            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 49,
              y: 277,
              src: 'bt.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 403,
              y: 277,
              src: 'alarm.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_battery_circle_scale = hmUI.createWidget(hmUI.widget.Circle_Scale, {
              // center_x: 68,
              // center_y: 210,
              // start_angle: 0,
              // end_angle: 360,
              // radius: 25,
              // line_width: 7,
              // line_cap: Flat,
              // color: 0xFFFF5400,
              // mirror: False,
              // inversion: False,
              // alpha: 255,
              // type: hmUI.data_type.BATTERY,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_battery_circle_scale = hmUI.createWidget(hmUI.widget.ARC_PROGRESS, {
              center_x: 68,
              center_y: 210,
              start_angle: 0,
              end_angle: 360,
              radius: 22,
              line_width: 7,
              corner_flag: 3,
              color: 0xFFFF5400,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            
            const battery = hmSensor.createSensor(hmSensor.id.BATTERY);
            battery.addEventListener(hmSensor.event.CHANGE, function() {
              scale_call();
            });

            normal_battery_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 39,
              y: 181,
              src: 'bar.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 50,
              y: 206,
              font_array: ["power_1.png","power_2.png","power_3.png","power_4.png","power_5.png","power_6.png","power_7.png","power_8.png","power_9.png","power_10.png"],
              padding: false,
              h_space: -3,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time_AmPm = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              am_x: 395,
              am_y: 223,
              am_sc_path: 'Clock_AM.png',
              am_en_path: 'Clock_AM.png',
              pm_x: 395,
              pm_y: 223,
              pm_sc_path: 'Clock_PM.png',
              pm_en_path: 'Clock_PM.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 104,
              hour_startY: 175,
              hour_array: ["time_1.png","time_2.png","time_3.png","time_4.png","time_5.png","time_6.png","time_7.png","time_8.png","time_9.png","time_10.png"],
              hour_zero: 1,
              hour_space: 0,
              hour_angle: 0,
              hour_align: hmUI.align.CENTER_H,

              minute_startX: 211,
              minute_startY: 175,
              minute_array: ["time_1.png","time_2.png","time_3.png","time_4.png","time_5.png","time_6.png","time_7.png","time_8.png","time_9.png","time_10.png"],
              minute_zero: 1,
              minute_space: 0,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.CENTER_H,

              second_startX: 315,
              second_startY: 175,
              second_array: ["time_1.png","time_2.png","time_3.png","time_4.png","time_5.png","time_6.png","time_7.png","time_8.png","time_9.png","time_10.png"],
              second_zero: 1,
              second_space: 0,
              second_angle: 0,
              second_follow: 0,
              second_align: hmUI.align.CENTER_H,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_hour_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 189,
              y: 167,
              src: 'timesep.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_minute_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 294,
              y: 167,
              src: 'timesep.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });



            image_top_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'outerring.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            console.log('Watch_Face.Shortcuts');

            normal_cal_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 204,
              y: 247,
              w: 58,
              h: 58,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 38,
              y: 181,
              w: 58,
              h: 58,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_alarm_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 369,
              y: 184,
              w: 49,
              h: 49,
              type: hmUI.data_type.ALARM_CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            console.log('Watch_Face.Buttons');
            Button_1 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 87,
              y: 102,
              w: 58,
              h: 49,
              text: '',
              color: 0xFFFF8C00,
              text_size: 24,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'WeatherScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_2 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 189,
              y: 352,
              w: 78,
              h: 39,
              text: '',
              color: 0xFFFF8C00,
              text_size: 24,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'ScheduleCalScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_3 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 78,
              y: 262,
              w: 49,
              h: 39,
              text: '',
              color: 0xFFFF8C00,
              text_size: 24,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'SportListScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            function scale_call() {
              console.log('scale_call()');

              console.log('Weather city name');
              let weatherData = weatherSensor.getForecastWeather();
              let normal_cityNameStr = weatherData.cityName;
              normal_cityNameStr = normal_cityNameStr.toUpperCase();
              normal_city_name_text.setProperty(hmUI.prop.TEXT, normal_cityNameStr);

                console.log('update scales STEP');
                
                let valueStep = step.current;
                let targetStep = step.target;
                let progressStep = valueStep/targetStep;
                if (progressStep > 1) progressStep = 1;
                let progress_ls_normal_step = progressStep;

                if (screenType != hmSetting.screen_type.AOD) {

                  // normal_step_linear_scale
                  // initial parameters
                  let start_x_normal_step = 153;
                  let start_y_normal_step = 308;
                  let lenght_ls_normal_step = -58;
                  let line_width_ls_normal_step = 12;
                  let color_ls_normal_step = 0xFFFF5400;
                  
                  // calculated parameters
                  let start_x_normal_step_draw = start_x_normal_step;
                  let start_y_normal_step_draw = start_y_normal_step;
                  lenght_ls_normal_step = lenght_ls_normal_step * progress_ls_normal_step;
                  let lenght_ls_normal_step_draw = line_width_ls_normal_step;
                  let line_width_ls_normal_step_draw = lenght_ls_normal_step;
                  if (lenght_ls_normal_step < 0){
                    line_width_ls_normal_step_draw = -lenght_ls_normal_step;
                    start_y_normal_step_draw = start_y_normal_step_draw - line_width_ls_normal_step_draw;
                  };
                  
                  normal_step_linear_scale.setProperty(hmUI.prop.MORE, {
                    x: start_x_normal_step_draw,
                    y: start_y_normal_step_draw,
                    w: lenght_ls_normal_step_draw,
                    h: line_width_ls_normal_step_draw,
                    color: color_ls_normal_step,
                  });
                };

                console.log('update scales BATTERY');
                
                let valueBattery = battery.current;
                let targetBattery = 100;
                let progressBattery = valueBattery/targetBattery;
                if (progressBattery > 1) progressBattery = 1;
                let progress_cs_normal_battery = progressBattery;

                if (screenType != hmSetting.screen_type.AOD) {

                  // normal_battery_circle_scale_circle_scale
                  let level = Math.round(progress_cs_normal_battery * 100);
                  if (normal_battery_circle_scale) {
                    normal_battery_circle_scale.setProperty(hmUI.prop.MORE, {                      
                      center_x: 68,
                      center_y: 210,
                      start_angle: 0,
                      end_angle: 360,
                      radius: 22,
                      line_width: 7,
                      corner_flag: 3,
                      color: 0xFFFF5400,
                      show_level: hmUI.show_level.ONLY_NORMAL,
                      level: level,
                    });
                  };
                };

            };

            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                console.log('resume_call()');
                scale_call();

                console.log('resume_call.js');
                // start resume_call.js

check24h()
                // end resume_call.js

              }),
            });

                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}