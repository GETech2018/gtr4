﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        const logger = Logger.getLogger('watchface_SashaCX75');
        //end of ignored block

        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_system_disconnect_img = ''
        let normal_system_clock_img = ''
        let normal_date_img_date_week_img = ''
        let normal_battery_circle_scale = ''
        let normal_battery_TextCircle = new Array(3);
        let normal_battery_TextCircle_ASCIIARRAY = new Array(10);
        let normal_battery_TextCircle_img_width = 16;
        let normal_battery_TextCircle_img_height = 28;
        let normal_heart_rate_circle_scale = ''
        let normal_heart_rate_TextCircle = new Array(3);
        let normal_heart_rate_TextCircle_ASCIIARRAY = new Array(10);
        let normal_heart_rate_TextCircle_img_width = 16;
        let normal_heart_rate_TextCircle_img_height = 28;
        let normal_calorie_circle_scale = ''
        let normal_calorie_TextCircle = new Array(4);
        let normal_calorie_TextCircle_ASCIIARRAY = new Array(10);
        let normal_calorie_TextCircle_img_width = 16;
        let normal_calorie_TextCircle_img_height = 28;
        let normal_step_circle_scale = ''
        let normal_step_TextCircle = new Array(5);
        let normal_step_TextCircle_ASCIIARRAY = new Array(10);
        let normal_step_TextCircle_img_width = 16;
        let normal_step_TextCircle_img_height = 28;
        let normal_hour_TextCircle = new Array(2);
        let normal_hour_TextCircle_ASCIIARRAY = new Array(10);
        let normal_hour_TextCircle_img_width = 15;
        let normal_hour_TextCircle_img_height = 26;
        let normal_timerTextUpdate = undefined;
        let normal_minute_TextCircle = new Array(2);
        let normal_minute_TextCircle_ASCIIARRAY = new Array(10);
        let normal_minute_TextCircle_img_width = 15;
        let normal_minute_TextCircle_img_height = 26;
        let normal_second_TextCircle = new Array(2);
        let normal_second_TextCircle_ASCIIARRAY = new Array(10);
        let normal_second_TextCircle_img_width = 15;
        let normal_second_TextCircle_img_height = 26;
        let normal_analog_clock_time_pointer_hour = ''
        let normal_analog_clock_time_pointer_minute = ''
        let normal_analog_clock_time_pointer_second = ''
        let idle_background_bg = ''
        let idle_system_disconnect_img = ''
        let idle_date_img_date_week_img = ''
        let idle_battery_text_text_img = ''
        let idle_analog_clock_time_pointer_hour = ''
        let idle_analog_clock_time_pointer_minute = ''


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 466,
              h: 466,
              src: 'bg_1.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 32,
              y: 221,
              src: 'bt.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 413,
              y: 221,
              src: 'alarm.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 163,
              y: 395,
              week_en: ["week_1.png","week_2.png","week_3.png","week_4.png","week_5.png","week_6.png","week_7.png"],
              week_tc: ["week_1.png","week_2.png","week_3.png","week_4.png","week_5.png","week_6.png","week_7.png"],
              week_sc: ["week_1.png","week_2.png","week_3.png","week_4.png","week_5.png","week_6.png","week_7.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_battery_circle_scale = hmUI.createWidget(hmUI.widget.Circle_Scale, {
              // center_x: 233,
              // center_y: 233,
              // start_angle: -227,
              // end_angle: 106,
              // radius: 85,
              // line_width: 23,
              // line_cap: Rounded,
              // color: 0xFF00A653,
              // mirror: False,
              // inversion: False,
              // type: hmUI.data_type.BATTERY,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            let screenType = hmSetting.getScreenType();
            normal_battery_circle_scale = hmUI.createWidget(hmUI.widget.ARC_PROGRESS, {
              center_x: 233,
              center_y: 233,
              start_angle: -227,
              end_angle: 106,
              radius: 74,
              line_width: 23,
              corner_flag: 0,
              color: 0xFF00A653,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            
            const battery = hmSensor.createSensor(hmSensor.id.BATTERY);
            battery.addEventListener(hmSensor.event.CHANGE, function() {
              text_update();
              scale_call();
            });

            // normal_battery_text_circle_img = hmUI.createWidget(hmUI.widget.Text_Circle, {
              // circle_center_X: 233,
              // circle_center_Y: 233,
              // font_array: ["green_0.png","green_1.png","green_2.png","green_3.png","green_4.png","green_5.png","green_6.png","green_7.png","green_8.png","green_9.png"],
              // radius: 200,
              // angle: 120,
              // char_space_angle: 0,
              // zero: false,
              // reverse_direction: true,
              // unit_in_alignment: true,
              // vertical_alignment: BOTTOM,
              // horizontal_alignment: CENTER_H,
              // type: hmUI.data_type.BATTERY,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_battery_TextCircle_ASCIIARRAY[0] = 'green_0.png';  // set of images with numbers
            normal_battery_TextCircle_ASCIIARRAY[1] = 'green_1.png';  // set of images with numbers
            normal_battery_TextCircle_ASCIIARRAY[2] = 'green_2.png';  // set of images with numbers
            normal_battery_TextCircle_ASCIIARRAY[3] = 'green_3.png';  // set of images with numbers
            normal_battery_TextCircle_ASCIIARRAY[4] = 'green_4.png';  // set of images with numbers
            normal_battery_TextCircle_ASCIIARRAY[5] = 'green_5.png';  // set of images with numbers
            normal_battery_TextCircle_ASCIIARRAY[6] = 'green_6.png';  // set of images with numbers
            normal_battery_TextCircle_ASCIIARRAY[7] = 'green_7.png';  // set of images with numbers
            normal_battery_TextCircle_ASCIIARRAY[8] = 'green_8.png';  // set of images with numbers
            normal_battery_TextCircle_ASCIIARRAY[9] = 'green_9.png';  // set of images with numbers

            //start of ignored block
            for (let i = 0; i < 3; i++) {
              normal_battery_TextCircle[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 466,
                h: 466,
                center_x: 233,
                center_y: 233,
                pos_x: 233 - normal_battery_TextCircle_img_width / 2,
                pos_y: 233 + 172,
                src: 'green_0.png',
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
              normal_battery_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
            };
            //end of ignored block
            
            function toDegree (radian) {
              return radian * (180 / Math.PI);
            };

            // normal_heart_circle_scale = hmUI.createWidget(hmUI.widget.Circle_Scale, {
              // center_x: 233,
              // center_y: 233,
              // start_angle: -107,
              // end_angle: 228,
              // radius: 111,
              // line_width: 20,
              // line_cap: Rounded,
              // color: 0xFFFF5353,
              // mirror: False,
              // inversion: False,
              // type: hmUI.data_type.HEART,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_heart_rate_circle_scale = hmUI.createWidget(hmUI.widget.ARC_PROGRESS, {
              center_x: 233,
              center_y: 233,
              start_angle: -107,
              end_angle: 228,
              radius: 101,
              line_width: 20,
              corner_flag: 0,
              color: 0xFFFF5353,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            
            const heart_rate = hmSensor.createSensor(hmSensor.id.HEART);
            heart_rate.addEventListener(hmSensor.event.CHANGE, function() {
              text_update();
              scale_call();
            });

            // normal_heart_rate_text_circle_img = hmUI.createWidget(hmUI.widget.Text_Circle, {
              // circle_center_X: 233,
              // circle_center_Y: 233,
              // font_array: ["red_0.png","red_1.png","red_2.png","red_3.png","red_4.png","red_5.png","red_6.png","red_7.png","red_8.png","red_9.png"],
              // radius: 200,
              // angle: -118,
              // char_space_angle: 0,
              // zero: false,
              // reverse_direction: true,
              // unit_in_alignment: true,
              // vertical_alignment: BOTTOM,
              // horizontal_alignment: CENTER_H,
              // type: hmUI.data_type.HEART,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_heart_rate_TextCircle_ASCIIARRAY[0] = 'red_0.png';  // set of images with numbers
            normal_heart_rate_TextCircle_ASCIIARRAY[1] = 'red_1.png';  // set of images with numbers
            normal_heart_rate_TextCircle_ASCIIARRAY[2] = 'red_2.png';  // set of images with numbers
            normal_heart_rate_TextCircle_ASCIIARRAY[3] = 'red_3.png';  // set of images with numbers
            normal_heart_rate_TextCircle_ASCIIARRAY[4] = 'red_4.png';  // set of images with numbers
            normal_heart_rate_TextCircle_ASCIIARRAY[5] = 'red_5.png';  // set of images with numbers
            normal_heart_rate_TextCircle_ASCIIARRAY[6] = 'red_6.png';  // set of images with numbers
            normal_heart_rate_TextCircle_ASCIIARRAY[7] = 'red_7.png';  // set of images with numbers
            normal_heart_rate_TextCircle_ASCIIARRAY[8] = 'red_8.png';  // set of images with numbers
            normal_heart_rate_TextCircle_ASCIIARRAY[9] = 'red_9.png';  // set of images with numbers

            //start of ignored block
            for (let i = 0; i < 3; i++) {
              normal_heart_rate_TextCircle[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 466,
                h: 466,
                center_x: 233,
                center_y: 233,
                pos_x: 233 - normal_heart_rate_TextCircle_img_width / 2,
                pos_y: 233 + 172,
                src: 'red_0.png',
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
              normal_heart_rate_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
            };
            //end of ignored block

            // normal_cal_circle_scale = hmUI.createWidget(hmUI.widget.Circle_Scale, {
              // center_x: 233,
              // center_y: 233,
              // start_angle: -52,
              // end_angle: 291,
              // radius: 135,
              // line_width: 18,
              // line_cap: Rounded,
              // color: 0xFF00DDDD,
              // mirror: False,
              // inversion: False,
              // type: hmUI.data_type.CAL,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_calorie_circle_scale = hmUI.createWidget(hmUI.widget.ARC_PROGRESS, {
              center_x: 233,
              center_y: 233,
              start_angle: -52,
              end_angle: 291,
              radius: 126,
              line_width: 18,
              corner_flag: 0,
              color: 0xFF00DDDD,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            
            const calorie = hmSensor.createSensor(hmSensor.id.CALORIE);
            calorie.addEventListener(hmSensor.event.CHANGE, function() {
              text_update();
              scale_call();
            });

            // normal_calorie_text_circle_img = hmUI.createWidget(hmUI.widget.Text_Circle, {
              // circle_center_X: 233,
              // circle_center_Y: 233,
              // font_array: ["cyan_0.png","cyan_1.png","cyan_2.png","cyan_3.png","cyan_4.png","cyan_5.png","cyan_6.png","cyan_7.png","cyan_8.png","cyan_9.png"],
              // radius: 174,
              // angle: -58,
              // char_space_angle: 0,
              // zero: false,
              // reverse_direction: false,
              // unit_in_alignment: true,
              // vertical_alignment: BOTTOM,
              // horizontal_alignment: CENTER_H,
              // type: hmUI.data_type.CAL,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_calorie_TextCircle_ASCIIARRAY[0] = 'cyan_0.png';  // set of images with numbers
            normal_calorie_TextCircle_ASCIIARRAY[1] = 'cyan_1.png';  // set of images with numbers
            normal_calorie_TextCircle_ASCIIARRAY[2] = 'cyan_2.png';  // set of images with numbers
            normal_calorie_TextCircle_ASCIIARRAY[3] = 'cyan_3.png';  // set of images with numbers
            normal_calorie_TextCircle_ASCIIARRAY[4] = 'cyan_4.png';  // set of images with numbers
            normal_calorie_TextCircle_ASCIIARRAY[5] = 'cyan_5.png';  // set of images with numbers
            normal_calorie_TextCircle_ASCIIARRAY[6] = 'cyan_6.png';  // set of images with numbers
            normal_calorie_TextCircle_ASCIIARRAY[7] = 'cyan_7.png';  // set of images with numbers
            normal_calorie_TextCircle_ASCIIARRAY[8] = 'cyan_8.png';  // set of images with numbers
            normal_calorie_TextCircle_ASCIIARRAY[9] = 'cyan_9.png';  // set of images with numbers

            //start of ignored block
            for (let i = 0; i < 4; i++) {
              normal_calorie_TextCircle[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 466,
                h: 466,
                center_x: 233,
                center_y: 233,
                pos_x: 233 - normal_calorie_TextCircle_img_width / 2,
                pos_y: 233 - 202,
                src: 'cyan_0.png',
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
              normal_calorie_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
            };
            //end of ignored block

            // normal_step_circle_scale = hmUI.createWidget(hmUI.widget.Circle_Scale, {
              // center_x: 233,
              // center_y: 233,
              // start_angle: 68,
              // end_angle: 412,
              // radius: 155,
              // line_width: 15,
              // line_cap: Rounded,
              // color: 0xFFFF8C00,
              // mirror: False,
              // inversion: False,
              // type: hmUI.data_type.STEP,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_step_circle_scale = hmUI.createWidget(hmUI.widget.ARC_PROGRESS, {
              center_x: 233,
              center_y: 233,
              start_angle: 68,
              end_angle: 412,
              radius: 148,
              line_width: 15,
              corner_flag: 0,
              color: 0xFFFF8C00,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            
            const step = hmSensor.createSensor(hmSensor.id.STEP);
            step.addEventListener(hmSensor.event.CHANGE, function() {
              text_update();
              scale_call();
            });

            // normal_step_text_circle_img = hmUI.createWidget(hmUI.widget.Text_Circle, {
              // circle_center_X: 233,
              // circle_center_Y: 233,
              // font_array: ["yellow_0.png","yellow_1.png","yellow_2.png","yellow_3.png","yellow_4.png","yellow_5.png","yellow_6.png","yellow_7.png","yellow_8.png","yellow_9.png"],
              // radius: 174,
              // angle: 60,
              // char_space_angle: 0,
              // zero: false,
              // reverse_direction: false,
              // unit_in_alignment: true,
              // vertical_alignment: BOTTOM,
              // horizontal_alignment: CENTER_H,
              // type: hmUI.data_type.STEP,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_step_TextCircle_ASCIIARRAY[0] = 'yellow_0.png';  // set of images with numbers
            normal_step_TextCircle_ASCIIARRAY[1] = 'yellow_1.png';  // set of images with numbers
            normal_step_TextCircle_ASCIIARRAY[2] = 'yellow_2.png';  // set of images with numbers
            normal_step_TextCircle_ASCIIARRAY[3] = 'yellow_3.png';  // set of images with numbers
            normal_step_TextCircle_ASCIIARRAY[4] = 'yellow_4.png';  // set of images with numbers
            normal_step_TextCircle_ASCIIARRAY[5] = 'yellow_5.png';  // set of images with numbers
            normal_step_TextCircle_ASCIIARRAY[6] = 'yellow_6.png';  // set of images with numbers
            normal_step_TextCircle_ASCIIARRAY[7] = 'yellow_7.png';  // set of images with numbers
            normal_step_TextCircle_ASCIIARRAY[8] = 'yellow_8.png';  // set of images with numbers
            normal_step_TextCircle_ASCIIARRAY[9] = 'yellow_9.png';  // set of images with numbers

            //start of ignored block
            for (let i = 0; i < 5; i++) {
              normal_step_TextCircle[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 466,
                h: 466,
                center_x: 233,
                center_y: 233,
                pos_x: 233 - normal_step_TextCircle_img_width / 2,
                pos_y: 233 - 202,
                src: 'yellow_0.png',
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
              normal_step_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
            };
            //end of ignored block

            // normal_hour_text_circle_img = hmUI.createWidget(hmUI.widget.Text_Circle, {
              // circle_center_X: 233,
              // circle_center_Y: 233,
              // font_array: ["font_0.png","font_1.png","font_2.png","font_3.png","font_4.png","font_5.png","font_6.png","font_7.png","font_8.png","font_9.png"],
              // radius: 175,
              // angle: -15,
              // char_space_angle: 0,
              // zero: true,
              // reverse_direction: false,
              // unit_in_alignment: true,
              // vertical_alignment: BOTTOM,
              // horizontal_alignment: CENTER_H,
              // type: hmUI.data_type.HOUR,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_hour_TextCircle_ASCIIARRAY[0] = 'font_0.png';  // set of images with numbers
            normal_hour_TextCircle_ASCIIARRAY[1] = 'font_1.png';  // set of images with numbers
            normal_hour_TextCircle_ASCIIARRAY[2] = 'font_2.png';  // set of images with numbers
            normal_hour_TextCircle_ASCIIARRAY[3] = 'font_3.png';  // set of images with numbers
            normal_hour_TextCircle_ASCIIARRAY[4] = 'font_4.png';  // set of images with numbers
            normal_hour_TextCircle_ASCIIARRAY[5] = 'font_5.png';  // set of images with numbers
            normal_hour_TextCircle_ASCIIARRAY[6] = 'font_6.png';  // set of images with numbers
            normal_hour_TextCircle_ASCIIARRAY[7] = 'font_7.png';  // set of images with numbers
            normal_hour_TextCircle_ASCIIARRAY[8] = 'font_8.png';  // set of images with numbers
            normal_hour_TextCircle_ASCIIARRAY[9] = 'font_9.png';  // set of images with numbers

            //start of ignored block
            for (let i = 0; i < 2; i++) {
              normal_hour_TextCircle[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 466,
                h: 466,
                center_x: 233,
                center_y: 233,
                pos_x: 233 - normal_hour_TextCircle_img_width / 2,
                pos_y: 233 - 201,
                src: 'font_0.png',
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
              normal_hour_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
            };
            //end of ignored block
            
            const timeNaw = hmSensor.createSensor(hmSensor.id.TIME);

            // normal_minute_text_circle_img = hmUI.createWidget(hmUI.widget.Text_Circle, {
              // circle_center_X: 233,
              // circle_center_Y: 233,
              // font_array: ["font_0.png","font_1.png","font_2.png","font_3.png","font_4.png","font_5.png","font_6.png","font_7.png","font_8.png","font_9.png"],
              // radius: 175,
              // angle: 0,
              // char_space_angle: 0,
              // zero: true,
              // reverse_direction: false,
              // unit_in_alignment: true,
              // vertical_alignment: BOTTOM,
              // horizontal_alignment: CENTER_H,
              // type: hmUI.data_type.MINUTE,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_minute_TextCircle_ASCIIARRAY[0] = 'font_0.png';  // set of images with numbers
            normal_minute_TextCircle_ASCIIARRAY[1] = 'font_1.png';  // set of images with numbers
            normal_minute_TextCircle_ASCIIARRAY[2] = 'font_2.png';  // set of images with numbers
            normal_minute_TextCircle_ASCIIARRAY[3] = 'font_3.png';  // set of images with numbers
            normal_minute_TextCircle_ASCIIARRAY[4] = 'font_4.png';  // set of images with numbers
            normal_minute_TextCircle_ASCIIARRAY[5] = 'font_5.png';  // set of images with numbers
            normal_minute_TextCircle_ASCIIARRAY[6] = 'font_6.png';  // set of images with numbers
            normal_minute_TextCircle_ASCIIARRAY[7] = 'font_7.png';  // set of images with numbers
            normal_minute_TextCircle_ASCIIARRAY[8] = 'font_8.png';  // set of images with numbers
            normal_minute_TextCircle_ASCIIARRAY[9] = 'font_9.png';  // set of images with numbers

            //start of ignored block
            for (let i = 0; i < 2; i++) {
              normal_minute_TextCircle[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 466,
                h: 466,
                center_x: 233,
                center_y: 233,
                pos_x: 233 - normal_minute_TextCircle_img_width / 2,
                pos_y: 233 - 201,
                src: 'font_0.png',
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
              normal_minute_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
            };
            //end of ignored block

            // normal_second_text_circle_img = hmUI.createWidget(hmUI.widget.Text_Circle, {
              // circle_center_X: 233,
              // circle_center_Y: 233,
              // font_array: ["font_0.png","font_1.png","font_2.png","font_3.png","font_4.png","font_5.png","font_6.png","font_7.png","font_8.png","font_9.png"],
              // radius: 175,
              // angle: 15,
              // char_space_angle: 0,
              // zero: true,
              // reverse_direction: false,
              // unit_in_alignment: true,
              // vertical_alignment: BOTTOM,
              // horizontal_alignment: CENTER_H,
              // type: hmUI.data_type.SECOND,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_second_TextCircle_ASCIIARRAY[0] = 'font_0.png';  // set of images with numbers
            normal_second_TextCircle_ASCIIARRAY[1] = 'font_1.png';  // set of images with numbers
            normal_second_TextCircle_ASCIIARRAY[2] = 'font_2.png';  // set of images with numbers
            normal_second_TextCircle_ASCIIARRAY[3] = 'font_3.png';  // set of images with numbers
            normal_second_TextCircle_ASCIIARRAY[4] = 'font_4.png';  // set of images with numbers
            normal_second_TextCircle_ASCIIARRAY[5] = 'font_5.png';  // set of images with numbers
            normal_second_TextCircle_ASCIIARRAY[6] = 'font_6.png';  // set of images with numbers
            normal_second_TextCircle_ASCIIARRAY[7] = 'font_7.png';  // set of images with numbers
            normal_second_TextCircle_ASCIIARRAY[8] = 'font_8.png';  // set of images with numbers
            normal_second_TextCircle_ASCIIARRAY[9] = 'font_9.png';  // set of images with numbers

            //start of ignored block
            for (let i = 0; i < 2; i++) {
              normal_second_TextCircle[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 466,
                h: 466,
                center_x: 233,
                center_y: 233,
                pos_x: 233 - normal_second_TextCircle_img_width / 2,
                pos_y: 233 - 201,
                src: 'font_0.png',
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
              normal_second_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
            };
            //end of ignored block

            normal_analog_clock_time_pointer_hour = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              hour_path: 'h.png',
              hour_centerX: 233,
              hour_centerY: 233,
              hour_posX: 21,
              hour_posY: 233,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_minute = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              minute_path: 'm.png',
              minute_centerX: 233,
              minute_centerY: 233,
              minute_posX: 21,
              minute_posY: 233,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_second = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              second_path: 's.png',
              second_centerX: 233,
              second_centerY: 233,
              second_posX: 20,
              second_posY: 233,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            idle_background_bg = hmUI.createWidget(hmUI.widget.FILL_RECT, {
              x: 0,
              y: 0,
              w: 466,
              h: 466,
              color: '0xFF000000',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 222,
              y: 222,
              src: 'bt.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 163,
              y: 395,
              week_en: ["week_1.png","week_2.png","week_3.png","week_4.png","week_5.png","week_6.png","week_7.png"],
              week_tc: ["week_1.png","week_2.png","week_3.png","week_4.png","week_5.png","week_6.png","week_7.png"],
              week_sc: ["week_1.png","week_2.png","week_3.png","week_4.png","week_5.png","week_6.png","week_7.png"],
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 211,
              y: 50,
              font_array: ["green_0.png","green_1.png","green_2.png","green_3.png","green_4.png","green_5.png","green_6.png","green_7.png","green_8.png","green_9.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_analog_clock_time_pointer_hour = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              hour_path: 'h.png',
              hour_centerX: 233,
              hour_centerY: 233,
              hour_posX: 21,
              hour_posY: 233,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_analog_clock_time_pointer_minute = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              minute_path: 'm.png',
              minute_centerX: 233,
              minute_centerY: 233,
              minute_posX: 21,
              minute_posY: 233,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            function text_update() {

              console.log('update text circle battery_BATTERY');
              let valueBattery = battery.current;
              let normal_battery_circle_string = parseInt(valueBattery).toString();

              if (screenType != hmSetting.screen_type.AOD) {
                for (var i = 1; i < 3; i++) {  // hide all symbols
                  normal_battery_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                let char_Angle = 300;
                if (valueBattery != null && valueBattery != undefined && isFinite(valueBattery) && normal_battery_circle_string.length > 0 && normal_battery_circle_string.length < 6) {  // display data if it was possible to get it
                  let normal_battery_TextCircle_img_angle = 0;
                  let normal_battery_TextCircle_dot_img_angle = 0;
                  normal_battery_TextCircle_img_angle = toDegree(Math.atan2(normal_battery_TextCircle_img_width/2, 200));
                  // alignment = CENTER_H
                  let normal_battery_TextCircle_angleOffset = normal_battery_TextCircle_img_angle * (normal_battery_circle_string.length - 1);
                  normal_battery_TextCircle_angleOffset = -normal_battery_TextCircle_angleOffset;
                  char_Angle -= normal_battery_TextCircle_angleOffset;
                  // alignment end
                  
                  let firstSymbol = true;
                  let index = 0;
                  for (let char of normal_battery_circle_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 3) break;
                    if (charCode >= 0 && charCode < 10) { 
                      if (!firstSymbol) char_Angle -= normal_battery_TextCircle_img_angle;
                      firstSymbol = false;
                      normal_battery_TextCircle[index].setProperty(hmUI.prop.ANGLE, char_Angle);
                      normal_battery_TextCircle[index].setProperty(hmUI.prop.POS_X, 233 - normal_battery_TextCircle_img_width / 2);
                      normal_battery_TextCircle[index].setProperty(hmUI.prop.SRC, normal_battery_TextCircle_ASCIIARRAY[charCode]);
                      normal_battery_TextCircle[index].setProperty(hmUI.prop.VISIBLE, true);
                      char_Angle -= normal_battery_TextCircle_img_angle;
                      index++;
                    };  // end if digit
                  };  // end char of string
                }  // end isFinite

              };

              console.log('update text circle heart_rate_HEART');
              let valueHeartRate = heart_rate.last;
              let normal_heart_rate_circle_string = parseInt(valueHeartRate).toString();

              if (screenType != hmSetting.screen_type.AOD) {
                for (var i = 1; i < 3; i++) {  // hide all symbols
                  normal_heart_rate_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                let char_Angle = 62;
                if (valueHeartRate != null && valueHeartRate != undefined && isFinite(valueHeartRate) && normal_heart_rate_circle_string.length > 0 && normal_heart_rate_circle_string.length < 6) {  // display data if it was possible to get it
                  let normal_heart_rate_TextCircle_img_angle = 0;
                  let normal_heart_rate_TextCircle_dot_img_angle = 0;
                  normal_heart_rate_TextCircle_img_angle = toDegree(Math.atan2(normal_heart_rate_TextCircle_img_width/2, 200));
                  // alignment = CENTER_H
                  let normal_heart_rate_TextCircle_angleOffset = normal_heart_rate_TextCircle_img_angle * (normal_heart_rate_circle_string.length - 1);
                  normal_heart_rate_TextCircle_angleOffset = -normal_heart_rate_TextCircle_angleOffset;
                  char_Angle -= normal_heart_rate_TextCircle_angleOffset;
                  // alignment end
                  
                  let firstSymbol = true;
                  let index = 0;
                  for (let char of normal_heart_rate_circle_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 3) break;
                    if (charCode >= 0 && charCode < 10) { 
                      if (!firstSymbol) char_Angle -= normal_heart_rate_TextCircle_img_angle;
                      firstSymbol = false;
                      normal_heart_rate_TextCircle[index].setProperty(hmUI.prop.ANGLE, char_Angle);
                      normal_heart_rate_TextCircle[index].setProperty(hmUI.prop.POS_X, 233 - normal_heart_rate_TextCircle_img_width / 2);
                      normal_heart_rate_TextCircle[index].setProperty(hmUI.prop.SRC, normal_heart_rate_TextCircle_ASCIIARRAY[charCode]);
                      normal_heart_rate_TextCircle[index].setProperty(hmUI.prop.VISIBLE, true);
                      char_Angle -= normal_heart_rate_TextCircle_img_angle;
                      index++;
                    };  // end if digit
                  };  // end char of string
                }  // end isFinite

              };

              console.log('update text circle calorie_CALORIE');
              let valueCalories = calorie.current;
              let normal_calorie_circle_string = parseInt(valueCalories).toString();

              if (screenType != hmSetting.screen_type.AOD) {
                for (var i = 1; i < 4; i++) {  // hide all symbols
                  normal_calorie_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                let char_Angle = -58;
                if (valueCalories != null && valueCalories != undefined && isFinite(valueCalories) && normal_calorie_circle_string.length > 0 && normal_calorie_circle_string.length < 6) {  // display data if it was possible to get it
                  let normal_calorie_TextCircle_img_angle = 0;
                  let normal_calorie_TextCircle_dot_img_angle = 0;
                  normal_calorie_TextCircle_img_angle = toDegree(Math.atan2(normal_calorie_TextCircle_img_width/2, 174));
                  // alignment = CENTER_H
                  let normal_calorie_TextCircle_angleOffset = normal_calorie_TextCircle_img_angle * (normal_calorie_circle_string.length - 1);
                  char_Angle -= normal_calorie_TextCircle_angleOffset;
                  // alignment end
                  
                  let firstSymbol = true;
                  let index = 0;
                  for (let char of normal_calorie_circle_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 4) break;
                    if (charCode >= 0 && charCode < 10) { 
                      if (!firstSymbol) char_Angle += normal_calorie_TextCircle_img_angle;
                      firstSymbol = false;
                      normal_calorie_TextCircle[index].setProperty(hmUI.prop.ANGLE, char_Angle);
                      normal_calorie_TextCircle[index].setProperty(hmUI.prop.POS_X, 233 - normal_calorie_TextCircle_img_width / 2);
                      normal_calorie_TextCircle[index].setProperty(hmUI.prop.SRC, normal_calorie_TextCircle_ASCIIARRAY[charCode]);
                      normal_calorie_TextCircle[index].setProperty(hmUI.prop.VISIBLE, true);
                      char_Angle += normal_calorie_TextCircle_img_angle;
                      index++;
                    };  // end if digit
                  };  // end char of string
                }  // end isFinite

              };

              console.log('update text circle step_STEP');
              let valueStep = step.current;
              let normal_step_circle_string = parseInt(valueStep).toString();

              if (screenType != hmSetting.screen_type.AOD) {
                for (var i = 1; i < 5; i++) {  // hide all symbols
                  normal_step_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                let char_Angle = 60;
                if (valueStep != null && valueStep != undefined && isFinite(valueStep) && normal_step_circle_string.length > 0 && normal_step_circle_string.length < 6) {  // display data if it was possible to get it
                  let normal_step_TextCircle_img_angle = 0;
                  let normal_step_TextCircle_dot_img_angle = 0;
                  normal_step_TextCircle_img_angle = toDegree(Math.atan2(normal_step_TextCircle_img_width/2, 174));
                  // alignment = CENTER_H
                  let normal_step_TextCircle_angleOffset = normal_step_TextCircle_img_angle * (normal_step_circle_string.length - 1);
                  char_Angle -= normal_step_TextCircle_angleOffset;
                  // alignment end
                  
                  let firstSymbol = true;
                  let index = 0;
                  for (let char of normal_step_circle_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 5) break;
                    if (charCode >= 0 && charCode < 10) { 
                      if (!firstSymbol) char_Angle += normal_step_TextCircle_img_angle;
                      firstSymbol = false;
                      normal_step_TextCircle[index].setProperty(hmUI.prop.ANGLE, char_Angle);
                      normal_step_TextCircle[index].setProperty(hmUI.prop.POS_X, 233 - normal_step_TextCircle_img_width / 2);
                      normal_step_TextCircle[index].setProperty(hmUI.prop.SRC, normal_step_TextCircle_ASCIIARRAY[charCode]);
                      normal_step_TextCircle[index].setProperty(hmUI.prop.VISIBLE, true);
                      char_Angle += normal_step_TextCircle_img_angle;
                      index++;
                    };  // end if digit
                  };  // end char of string
                }  // end isFinite

              };

              console.log('update text circle hour_TIME');
              let valueHour = timeNaw.hour;
              if (!timeNaw.is24Hour) {
                valueHour -= 12;
                if (valueHour < 1) valueHour += 12;
              };
              let normal_hour_circle_string = parseInt(valueHour).toString();
              normal_hour_circle_string = normal_hour_circle_string.padStart(2, '0');

              if (screenType != hmSetting.screen_type.AOD) {
                for (var i = 1; i < 2; i++) {  // hide all symbols
                  normal_hour_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                let char_Angle = -15;
                if (valueHour != null && valueHour != undefined && isFinite(valueHour) && normal_hour_circle_string.length > 0 && normal_hour_circle_string.length < 6) {  // display data if it was possible to get it
                  let normal_hour_TextCircle_img_angle = 0;
                  let normal_hour_TextCircle_dot_img_angle = 0;
                  normal_hour_TextCircle_img_angle = toDegree(Math.atan2(normal_hour_TextCircle_img_width/2, 175));
                  // alignment = CENTER_H
                  let normal_hour_TextCircle_angleOffset = normal_hour_TextCircle_img_angle * (normal_hour_circle_string.length - 1);
                  char_Angle -= normal_hour_TextCircle_angleOffset;
                  // alignment end
                  
                  let firstSymbol = true;
                  let index = 0;
                  for (let char of normal_hour_circle_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 2) break;
                    if (charCode >= 0 && charCode < 10) { 
                      if (!firstSymbol) char_Angle += normal_hour_TextCircle_img_angle;
                      firstSymbol = false;
                      normal_hour_TextCircle[index].setProperty(hmUI.prop.ANGLE, char_Angle);
                      normal_hour_TextCircle[index].setProperty(hmUI.prop.POS_X, 233 - normal_hour_TextCircle_img_width / 2);
                      normal_hour_TextCircle[index].setProperty(hmUI.prop.SRC, normal_hour_TextCircle_ASCIIARRAY[charCode]);
                      normal_hour_TextCircle[index].setProperty(hmUI.prop.VISIBLE, true);
                      char_Angle += normal_hour_TextCircle_img_angle;
                      index++;
                    };  // end if digit
                  };  // end char of string
                }  // end isFinite

              };

              console.log('update text circle minute_TIME');
              let valueMinute = timeNaw.minute;
              let normal_minute_circle_string = parseInt(valueMinute).toString();
              normal_minute_circle_string = normal_minute_circle_string.padStart(2, '0');

              if (screenType != hmSetting.screen_type.AOD) {
                for (var i = 1; i < 2; i++) {  // hide all symbols
                  normal_minute_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                let char_Angle = 0;
                if (valueMinute != null && valueMinute != undefined && isFinite(valueMinute) && normal_minute_circle_string.length > 0 && normal_minute_circle_string.length < 6) {  // display data if it was possible to get it
                  let normal_minute_TextCircle_img_angle = 0;
                  let normal_minute_TextCircle_dot_img_angle = 0;
                  normal_minute_TextCircle_img_angle = toDegree(Math.atan2(normal_minute_TextCircle_img_width/2, 175));
                  // alignment = CENTER_H
                  let normal_minute_TextCircle_angleOffset = normal_minute_TextCircle_img_angle * (normal_minute_circle_string.length - 1);
                  char_Angle -= normal_minute_TextCircle_angleOffset;
                  // alignment end
                  
                  let firstSymbol = true;
                  let index = 0;
                  for (let char of normal_minute_circle_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 2) break;
                    if (charCode >= 0 && charCode < 10) { 
                      if (!firstSymbol) char_Angle += normal_minute_TextCircle_img_angle;
                      firstSymbol = false;
                      normal_minute_TextCircle[index].setProperty(hmUI.prop.ANGLE, char_Angle);
                      normal_minute_TextCircle[index].setProperty(hmUI.prop.POS_X, 233 - normal_minute_TextCircle_img_width / 2);
                      normal_minute_TextCircle[index].setProperty(hmUI.prop.SRC, normal_minute_TextCircle_ASCIIARRAY[charCode]);
                      normal_minute_TextCircle[index].setProperty(hmUI.prop.VISIBLE, true);
                      char_Angle += normal_minute_TextCircle_img_angle;
                      index++;
                    };  // end if digit
                  };  // end char of string
                }  // end isFinite

              };

              console.log('update text circle second_TIME');
              let valueSecond = timeNaw.second;
              let normal_second_circle_string = parseInt(valueSecond).toString();
              normal_second_circle_string = normal_second_circle_string.padStart(2, '0');

              if (screenType != hmSetting.screen_type.AOD) {
                for (var i = 1; i < 2; i++) {  // hide all symbols
                  normal_second_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                let char_Angle = 15;
                if (valueSecond != null && valueSecond != undefined && isFinite(valueSecond) && normal_second_circle_string.length > 0 && normal_second_circle_string.length < 6) {  // display data if it was possible to get it
                  let normal_second_TextCircle_img_angle = 0;
                  let normal_second_TextCircle_dot_img_angle = 0;
                  normal_second_TextCircle_img_angle = toDegree(Math.atan2(normal_second_TextCircle_img_width/2, 175));
                  // alignment = CENTER_H
                  let normal_second_TextCircle_angleOffset = normal_second_TextCircle_img_angle * (normal_second_circle_string.length - 1);
                  char_Angle -= normal_second_TextCircle_angleOffset;
                  // alignment end
                  
                  let firstSymbol = true;
                  let index = 0;
                  for (let char of normal_second_circle_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 2) break;
                    if (charCode >= 0 && charCode < 10) { 
                      if (!firstSymbol) char_Angle += normal_second_TextCircle_img_angle;
                      firstSymbol = false;
                      normal_second_TextCircle[index].setProperty(hmUI.prop.ANGLE, char_Angle);
                      normal_second_TextCircle[index].setProperty(hmUI.prop.POS_X, 233 - normal_second_TextCircle_img_width / 2);
                      normal_second_TextCircle[index].setProperty(hmUI.prop.SRC, normal_second_TextCircle_ASCIIARRAY[charCode]);
                      normal_second_TextCircle[index].setProperty(hmUI.prop.VISIBLE, true);
                      char_Angle += normal_second_TextCircle_img_angle;
                      index++;
                    };  // end if digit
                  };  // end char of string
                }  // end isFinite

              };

            };

            function scale_call() {

                console.log('update scales BATTERY');
                
                let valueBattery = battery.current;
                let targetBattery = 100;
                let progressBattery = valueBattery/targetBattery;
                if (progressBattery > 1) progressBattery = 1;
                let progress_cs_normal_battery = progressBattery;

                if (screenType != hmSetting.screen_type.AOD) {

                  // normal_battery_circle_scale_circle_scale
                  let level = Math.round(progress_cs_normal_battery * 100);
                  if (normal_battery_circle_scale) {
                    normal_battery_circle_scale.setProperty(hmUI.prop.MORE, {                      
                      center_x: 233,
                      center_y: 233,
                      start_angle: -227,
                      end_angle: 106,
                      radius: 74,
                      line_width: 23,
                      corner_flag: 0,
                      color: 0xFF00A653,
                      show_level: hmUI.show_level.ONLY_NORMAL,
                      level: level,
                    });
                  };
                };

                console.log('update scales HEART');
                
                let valueHeartRate = heart_rate.last;
                let targetHeartRate = 179;
                let progressHeartRate = (valueHeartRate - 71)/(targetHeartRate - 71);
                if (progressHeartRate < 0) progressHeartRate = 0;
                if (progressHeartRate > 1) progressHeartRate = 1;
                let progress_cs_normal_heart_rate = progressHeartRate;

                if (screenType != hmSetting.screen_type.AOD) {

                  // normal_heart_rate_circle_scale_circle_scale
                  let level = Math.round(progress_cs_normal_heart_rate * 100);
                  if (normal_heart_rate_circle_scale) {
                    normal_heart_rate_circle_scale.setProperty(hmUI.prop.MORE, {                      
                      center_x: 233,
                      center_y: 233,
                      start_angle: -107,
                      end_angle: 228,
                      radius: 101,
                      line_width: 20,
                      corner_flag: 0,
                      color: 0xFFFF5353,
                      show_level: hmUI.show_level.ONLY_NORMAL,
                      level: level,
                    });
                  };
                };

                console.log('update scales CALORIE');
                
                let valueCalories = calorie.current;
                let targetCalories = calorie.target;
                let progressCalories = valueCalories/targetCalories;
                if (progressCalories > 1) progressCalories = 1;
                let progress_cs_normal_calorie = progressCalories;

                if (screenType != hmSetting.screen_type.AOD) {

                  // normal_calorie_circle_scale_circle_scale
                  let level = Math.round(progress_cs_normal_calorie * 100);
                  if (normal_calorie_circle_scale) {
                    normal_calorie_circle_scale.setProperty(hmUI.prop.MORE, {                      
                      center_x: 233,
                      center_y: 233,
                      start_angle: -52,
                      end_angle: 291,
                      radius: 126,
                      line_width: 18,
                      corner_flag: 0,
                      color: 0xFF00DDDD,
                      show_level: hmUI.show_level.ONLY_NORMAL,
                      level: level,
                    });
                  };
                };

                console.log('update scales STEP');
                
                let valueStep = step.current;
                let targetStep = step.target;
                let progressStep = valueStep/targetStep;
                if (progressStep > 1) progressStep = 1;
                let progress_cs_normal_step = progressStep;

                if (screenType != hmSetting.screen_type.AOD) {

                  // normal_step_circle_scale_circle_scale
                  let level = Math.round(progress_cs_normal_step * 100);
                  if (normal_step_circle_scale) {
                    normal_step_circle_scale.setProperty(hmUI.prop.MORE, {                      
                      center_x: 233,
                      center_y: 233,
                      start_angle: 68,
                      end_angle: 412,
                      radius: 148,
                      line_width: 15,
                      corner_flag: 0,
                      color: 0xFFFF8C00,
                      show_level: hmUI.show_level.ONLY_NORMAL,
                      level: level,
                    });
                  };
                };

            };

            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                scale_call();
                text_update();
                if (screenType == hmSetting.screen_type.WATCHFACE) {
                  if (!normal_timerTextUpdate) {
                    normal_timerTextUpdate = timer.createTimer(0, 1000, (function (option) {
                      text_update();
                    }));  // end timer 
                  };  // end timer check
                };  // end screenType


              }),
              pause_call: (function () {
                if (normal_timerTextUpdate) {
                  timer.stopTimer(normal_timerTextUpdate);
                  normal_timerTextUpdate = undefined;
                }

              }),
            });

                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}