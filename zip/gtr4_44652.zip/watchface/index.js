﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        //const logger = Logger.getLogger('watchface_SashaCX75');
        const logger = DeviceRuntimeCore.HmLogger.getLogger('watchface_SashaCX75')
        //end of ignored block

        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_date_img_date_day = ''
        let idle_background_bg_img = ''
        let idle_date_img_date_day = ''
        let editableTimePointers = ''
        let Button_1 = ''
        let Button_Switch_BG = ''

        let backgroundIndex = 0;
        let backgroundList = ['bg.png', 'bg_1.png', 'bg_2.png', 'bg_3.png', 'bg_4.png', 'bg_5.png', 'bg_6.png', 'bg_7.png', 'bg_8.png'];
        let backgroundToastList = ['Pozadí %s', 'Pozadí %s', 'Pozadí %s', 'Pozadí %s', 'Pozadí %s', 'Pozadí %s', 'Pozadí %s', 'Pozadí %s', 'Pozadí %s'];
        const watchfaceId = hmApp.packageInfo().watchfaceId;


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            //#region SwitchBackground
            console.log('SwitchBackground');
            function switchBackground() {
              backgroundIndex++;
              if (backgroundIndex >= backgroundList.length) backgroundIndex = 0;
              hmFS.SysProSetInt(`backgroundIndex_${watchfaceId}`, backgroundIndex);
              let toastText = backgroundToastList[backgroundIndex].replace('%s', `${backgroundIndex + 1}`);
              if (toastText.length > 0) hmUI.showToast({text: toastText});
              normal_background_bg_img.setProperty(hmUI.prop.SRC, backgroundList[backgroundIndex]);
            };
            //#endregion

            console.log('Watch_Face.ScreenNormal');
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 466,
              h: 466,
              src: 'bg.png',
              show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_EDIT,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 399,
              day_startY: 220,
              day_sc_array: ["white_0.png","white_1.png","white_2.png","white_3.png","white_4.png","white_5.png","white_6.png","white_7.png","white_8.png","white_9.png"],
              day_tc_array: ["white_0.png","white_1.png","white_2.png","white_3.png","white_4.png","white_5.png","white_6.png","white_7.png","white_8.png","white_9.png"],
              day_en_array: ["white_0.png","white_1.png","white_2.png","white_3.png","white_4.png","white_5.png","white_6.png","white_7.png","white_8.png","white_9.png"],
              day_zero: 0,
              day_space: 1,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            console.log('Watch_Face.ScreenAOD');
            idle_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 466,
              h: 466,
              src: 'bg.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 399,
              day_startY: 220,
              day_sc_array: ["white_0.png","white_1.png","white_2.png","white_3.png","white_4.png","white_5.png","white_6.png","white_7.png","white_8.png","white_9.png"],
              day_tc_array: ["white_0.png","white_1.png","white_2.png","white_3.png","white_4.png","white_5.png","white_6.png","white_7.png","white_8.png","white_9.png"],
              day_en_array: ["white_0.png","white_1.png","white_2.png","white_3.png","white_4.png","white_5.png","white_6.png","white_7.png","white_8.png","white_9.png"],
              day_zero: 0,
              day_space: 1,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_AOD,
            });
            console.log('Watch_Face.ElementEditablePointers');

            const pointerEdit = hmUI.createWidget(hmUI.widget.WATCHFACE_EDIT_POINTER, {
              edit_id: 1003,
              x: 0,
              y: 0,
              config: [
                {
                  id: 1,
                  second: {
                    centerX: 233,
                    centerY: 233,
                    posX: 14,
                    posY: 228,
                    path: 'second.png',
                  },
                  hour: {
                    centerX: 233,
                    centerY: 233,
                    posX: 20,
                    posY: 139,
                    path: 'hour.png',
                  },
                  minute: {
                    centerX: 233,
                    centerY: 233,
                    posX: 17,
                    posY: 211,
                    path: 'minute.png',
                  },
                  preview: 'pointer_edit_1_preview.png',
                },
                {
                  id: 2,
                  second: {
                    centerX: 233,
                    centerY: 233,
                    posX: 14,
                    posY: 228,
                    path: 'second_1.png',
                  },
                  hour: {
                    centerX: 233,
                    centerY: 233,
                    posX: 20,
                    posY: 139,
                    path: 'hour_1.png',
                  },
                  minute: {
                    centerX: 233,
                    centerY: 233,
                    posX: 17,
                    posY: 211,
                    path: 'minute_1.png',
                  },
                  preview: 'pointer_edit_2_preview.png',
                },
                {
                  id: 3,
                  hour: {
                    centerX: 233,
                    centerY: 233,
                    posX: 19,
                    posY: 143,
                    path: 'hour_2.png',
                  },
                  minute: {
                    centerX: 233,
                    centerY: 233,
                    posX: 16,
                    posY: 212,
                    path: 'minute_2.png',
                  },
                  preview: 'pointer_edit_3_preview.png',
                },
                {
                  id: 4,
                  hour: {
                    centerX: 233,
                    centerY: 233,
                    posX: 19,
                    posY: 143,
                    path: 'hour_3.png',
                  },
                  minute: {
                    centerX: 233,
                    centerY: 233,
                    posX: 16,
                    posY: 212,
                    path: 'minute_3.png',
                  },
                  preview: 'pointer_edit_4_preview.png',
                },
                {
                  id: 5,
                  hour: {
                    centerX: 233,
                    centerY: 233,
                    posX: 19,
                    posY: 143,
                    path: 'hour_4.png',
                  },
                  minute: {
                    centerX: 233,
                    centerY: 233,
                    posX: 16,
                    posY: 212,
                    path: 'minute_4.png',
                  },
                  preview: 'pointer_edit_5_preview.png',
                },
              ],
              count: 5,
              default_id: 1,
              fg: '.png',
              tips_x: 183,
              tips_y: 208,
              tips_bg: 'options.png',
            });
            const pointerProp = pointerEdit.getProperty(hmUI.prop.CURRENT_CONFIG, true);
            editableTimePointers = hmUI.createWidget(hmUI.widget.TIME_POINTER, pointerProp);

            console.log('Watch_Face.Buttons');
            Button_1 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 385,
              y: 207,
              w: 60,
              h: 50,
              text: '',
              color: 0xFFFF8C00,
              text_size: 24,
              press_src: 'dot.png',
              normal_src: 'dot.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'ScheduleCalScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            console.log('Watch_Face.SwitchBackground');
            // Button_Switch_BG = hmUI.createWidget(hmUI.widget.SwitchBackground, {
              // x: 186,
              // y: 5,
              // w: 97,
              // h: 81,
              // text: '',
              // color: 0xFFFF8C00,
              // text_size: 24,
              // press_src: 'dot.png',
              // normal_src: 'dot.png',
              // bg_list: bg|bg_1|bg_2|bg_3|bg_4|bg_5|bg_6|bg_7|bg_8,
              // toast_list: Pozadí %s|Pozadí %s|Pozadí %s|Pozadí %s|Pozadí %s|Pozadí %s|Pozadí %s|Pozadí %s|Pozadí %s,
              // use_crown: False,
              // use_in_AOD: False,
              // vibro: False,
            // });

            Button_Switch_BG = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 186,
              y: 5,
              w: 97,
              h: 81,
              text: '',
              color: 0xFFFF8C00,
              text_size: 24,
              press_src: 'dot.png',
              normal_src: 'dot.png',
              click_func: (button_widget) => {
                switchBackground();
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            let screenType = hmSetting.getScreenType();
            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                console.log('resume_call()');

                //SwitchBackground
                if (hmFS.SysProGetInt(`backgroundIndex_${watchfaceId}`) === undefined) {
                  backgroundIndex = 0;
                  hmFS.SysProSetInt(`backgroundIndex_${watchfaceId}`, backgroundIndex);
                } else {
                  backgroundIndex = hmFS.SysProGetInt(`backgroundIndex_${watchfaceId}`);
                };
                if (screenType == hmSetting.screen_type.WATCHFACE && normal_background_bg_img) normal_background_bg_img.setProperty(hmUI.prop.SRC, backgroundList[backgroundIndex]);
              }),
            });

                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}