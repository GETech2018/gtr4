﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        const logger = Logger.getLogger('watchface_SashaCX75');
        //end of ignored block

        //dynamic modify start

        
        let normal_background_bg = ''
        let normal_digital_clock_img_time_AmPm = ''
        let normal_hour_TextCircle = new Array(2);
        let normal_hour_TextCircle_ASCIIARRAY = new Array(10);
        let normal_hour_TextCircle_img_width = 466;
        let normal_hour_TextCircle_img_height = 466;
        let normal_timerTextUpdate = undefined;
        let normal_hour_TextRotate = new Array(2);
        let normal_hour_TextRotate_ASCIIARRAY = new Array(10);
        let normal_hour_TextRotate_img_width = 466;
        let normal_digital_clock_img_time_hour = ''
        let normal_battery_circle_scale = ''
        let normal_battery_icon_img = ''
        let normal_battery_text_text_img = ''
        let normal_analog_clock_pro_minute_pointer_img = ''
        let normal_timerUpdateSec = undefined;
        let normal_analog_clock_time_pointer_smooth_second = ''
        let idle_background_bg = ''
        let idle_digital_clock_img_time_AmPm = ''
        let idle_hour_TextCircle = new Array(2);
        let idle_hour_TextCircle_ASCIIARRAY = new Array(10);
        let idle_hour_TextCircle_img_width = 466;
        let idle_hour_TextCircle_img_height = 466;
        let idle_timerTextUpdate = undefined;
        let idle_hour_TextRotate = new Array(2);
        let idle_hour_TextRotate_ASCIIARRAY = new Array(10);
        let idle_hour_TextRotate_img_width = 466;
        let idle_digital_clock_img_time_hour = ''
        let idle_analog_clock_pro_minute_pointer_img = ''
        let normal_battery_jumpable_img_click = ''
        let timeSensor = ''


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            console.log('Watch_Face.ScreenNormal');
            normal_background_bg = hmUI.createWidget(hmUI.widget.FILL_RECT, {
              x: 0,
              y: 0,
              w: 466,
              h: 466,
              color: '0xFF000000',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time_AmPm = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              am_x: 0,
              am_y: 0,
              am_sc_path: '20.png',
              am_en_path: '20.png',
              pm_x: 0,
              pm_y: 0,
              pm_sc_path: '10.png',
              pm_en_path: '10.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_hour_text_circle_img = hmUI.createWidget(hmUI.widget.Text_Circle, {
              // circle_center_X: 233,
              // circle_center_Y: 0,
              // font_array: ["40.png","41.png","42.png","43.png","44.png","45.png","46.png","47.png","48.png","49.png"],
              // radius: 0,
              // angle: 0,
              // char_space_angle: 0,
              // zero: true,
              // reverse_direction: false,
              // unit_in_alignment: false,
              // vertical_alignment: TOP,
              // horizontal_alignment: RIGHT,
              // type: hmUI.data_type.HOUR,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_hour_TextCircle_ASCIIARRAY[0] = '40.png';  // set of images with numbers
            normal_hour_TextCircle_ASCIIARRAY[1] = '41.png';  // set of images with numbers
            normal_hour_TextCircle_ASCIIARRAY[2] = '42.png';  // set of images with numbers
            normal_hour_TextCircle_ASCIIARRAY[3] = '43.png';  // set of images with numbers
            normal_hour_TextCircle_ASCIIARRAY[4] = '44.png';  // set of images with numbers
            normal_hour_TextCircle_ASCIIARRAY[5] = '45.png';  // set of images with numbers
            normal_hour_TextCircle_ASCIIARRAY[6] = '46.png';  // set of images with numbers
            normal_hour_TextCircle_ASCIIARRAY[7] = '47.png';  // set of images with numbers
            normal_hour_TextCircle_ASCIIARRAY[8] = '48.png';  // set of images with numbers
            normal_hour_TextCircle_ASCIIARRAY[9] = '49.png';  // set of images with numbers

            //start of ignored block
            for (let i = 0; i < 2; i++) {
              normal_hour_TextCircle[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 466,
                h: 466,
                center_x: 233,
                center_y: 0,
                pos_x: 233 - normal_hour_TextCircle_img_width / 2,
                pos_y: 0 + 0,
                src: '40.png',
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
              normal_hour_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
            };
            //end of ignored block

            if (!timeSensor) timeSensor = hmSensor.createSensor(hmSensor.id.TIME);
            let screenType = hmSetting.getScreenType();            
            function toDegree (radian) {
              return radian * (180 / Math.PI);
            };

            // normal_hour_text_rotate_img = hmUI.createWidget(hmUI.widget.Text_Rotate, {
              // x: -466,
              // y: 0,
              // font_array: ["50.png","51.png","52.png","53.png","54.png","55.png","56.png","57.png","58.png","59.png"],
              // zero: false,
              // unit_in_alignment: false,
              // h_space: 0,
              // angle: 0,
              // align_h: hmUI.align.LEFT,
              // type: hmUI.data_type.HOUR,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_hour_TextRotate_ASCIIARRAY[0] = '50.png';  // set of images with numbers
            normal_hour_TextRotate_ASCIIARRAY[1] = '51.png';  // set of images with numbers
            normal_hour_TextRotate_ASCIIARRAY[2] = '52.png';  // set of images with numbers
            normal_hour_TextRotate_ASCIIARRAY[3] = '53.png';  // set of images with numbers
            normal_hour_TextRotate_ASCIIARRAY[4] = '54.png';  // set of images with numbers
            normal_hour_TextRotate_ASCIIARRAY[5] = '55.png';  // set of images with numbers
            normal_hour_TextRotate_ASCIIARRAY[6] = '56.png';  // set of images with numbers
            normal_hour_TextRotate_ASCIIARRAY[7] = '57.png';  // set of images with numbers
            normal_hour_TextRotate_ASCIIARRAY[8] = '58.png';  // set of images with numbers
            normal_hour_TextRotate_ASCIIARRAY[9] = '59.png';  // set of images with numbers

            //start of ignored block
            for (let i = 0; i < 2; i++) {
              normal_hour_TextRotate[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 466,
                h: 466,
                center_x: -466,
                center_y: 0,
                pos_x: -466,
                pos_y: 0,
                angle: 0,
                src: '50.png',
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
              normal_hour_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
            };
            //end of ignored block

            normal_digital_clock_img_time_hour = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: -466,
              hour_startY: 0,
              hour_array: ["60.png","61.png","62.png","63.png","64.png","65.png","66.png","67.png","68.png","69.png"],
              hour_zero: 0,
              hour_space: 0,
              hour_angle: 0,
              hour_align: hmUI.align.LEFT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_battery_circle_scale = hmUI.createWidget(hmUI.widget.Circle_Scale, {
              // center_x: 233,
              // center_y: 315,
              // start_angle: 24,
              // end_angle: 336,
              // radius: 55,
              // line_width: 13,
              // line_cap: Flat,
              // color: 0xFFF0BA8B,
              // mirror: False,
              // inversion: False,
              // type: hmUI.data_type.BATTERY,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_battery_circle_scale = hmUI.createWidget(hmUI.widget.ARC_PROGRESS, {
              center_x: 233,
              center_y: 315,
              start_angle: 24,
              end_angle: 336,
              radius: 49,
              line_width: 13,
              corner_flag: 3,
              color: 0xFFF0BA8B,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            
            const battery = hmSensor.createSensor(hmSensor.id.BATTERY);
            battery.addEventListener(hmSensor.event.CHANGE, function() {
              scale_call();
            });

            normal_battery_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'battery.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 194,
              y: 306,
              font_array: ["00.png","01.png","02.png","03.png","04.png","05.png","06.png","07.png","08.png","09.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'percent.png',
              unit_tc: 'percent.png',
              unit_en: 'percent.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            const deviceInfo = hmSetting.getDeviceInfo();
            // normal_analog_clock_pro_minute_pointer_img = hmUI.createWidget(hmUI.widget.TIME_POINTER_PRO, {
              // src: 'Min.png',
              // center_x: 233,
              // center_y: 233,
              // x: 233,
              // y: 233,
              // start_angle: 0,
              // end_angle: 360,
              // type: hmUI.data_type.minute,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });


            normal_analog_clock_pro_minute_pointer_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: deviceInfo.width,
              h: deviceInfo.height,
              pos_x: 233 - 233,
              pos_y: 233 - 233,
              center_x: 233,
              center_y: 233,
              src: 'Min.png',
              angle: 0,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_analog_clock_pro_second_pointer_img = hmUI.createWidget(hmUI.widget.TIME_POINTER_PRO, {
              // src: 'second.png',
              // center_x: 233,
              // center_y: 233,
              // x: 233,
              // y: 233,
              // start_angle: 0,
              // end_angle: 360,
              // type: hmUI.data_type.second,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });


            normal_analog_clock_time_pointer_smooth_second = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              second_path: 'second.png',
              second_centerX: 233,
              second_centerY: 233,
              second_posX: 233,
              second_posY: 233,
              fresh_frequency: 15,
              fresh_freqency: 15,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_analog_clock_pro_smooth_second = hmUI.createWidget(hmUI.widget.SMOOTH_SECOND, {
              // type: 3,
              // fps: 15,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });



            console.log('Watch_Face.ScreenAOD');
            idle_background_bg = hmUI.createWidget(hmUI.widget.FILL_RECT, {
              x: 0,
              y: 0,
              w: 466,
              h: 466,
              color: '0xFF000000',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time_AmPm = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              am_x: 0,
              am_y: 0,
              am_sc_path: '20.png',
              am_en_path: '20.png',
              pm_x: 0,
              pm_y: 0,
              pm_sc_path: '20.png',
              pm_en_path: '20.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            // idle_hour_text_circle_img = hmUI.createWidget(hmUI.widget.Text_Circle, {
              // circle_center_X: 233,
              // circle_center_Y: 0,
              // font_array: ["10.png","11.png","12.png","13.png","14.png","15.png","16.png","17.png","18.png","19.png"],
              // radius: 0,
              // angle: 0,
              // char_space_angle: 0,
              // zero: true,
              // reverse_direction: false,
              // unit_in_alignment: false,
              // vertical_alignment: TOP,
              // horizontal_alignment: RIGHT,
              // type: hmUI.data_type.HOUR,
              // show_level: hmUI.show_level.ONLY_AOD,
            // });

            idle_hour_TextCircle_ASCIIARRAY[0] = '10.png';  // set of images with numbers
            idle_hour_TextCircle_ASCIIARRAY[1] = '11.png';  // set of images with numbers
            idle_hour_TextCircle_ASCIIARRAY[2] = '12.png';  // set of images with numbers
            idle_hour_TextCircle_ASCIIARRAY[3] = '13.png';  // set of images with numbers
            idle_hour_TextCircle_ASCIIARRAY[4] = '14.png';  // set of images with numbers
            idle_hour_TextCircle_ASCIIARRAY[5] = '15.png';  // set of images with numbers
            idle_hour_TextCircle_ASCIIARRAY[6] = '16.png';  // set of images with numbers
            idle_hour_TextCircle_ASCIIARRAY[7] = '17.png';  // set of images with numbers
            idle_hour_TextCircle_ASCIIARRAY[8] = '18.png';  // set of images with numbers
            idle_hour_TextCircle_ASCIIARRAY[9] = '19.png';  // set of images with numbers

            //start of ignored block
            for (let i = 0; i < 2; i++) {
              idle_hour_TextCircle[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 466,
                h: 466,
                center_x: 233,
                center_y: 0,
                pos_x: 233 - idle_hour_TextCircle_img_width / 2,
                pos_y: 0 + 0,
                src: '10.png',
                show_level: hmUI.show_level.ONLY_AOD,
              });
              idle_hour_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
            };
            //end of ignored block

            // idle_hour_text_rotate_img = hmUI.createWidget(hmUI.widget.Text_Rotate, {
              // x: -466,
              // y: 0,
              // font_array: ["20.png","21.png","22.png","23.png","24.png","25.png","26.png","27.png","28.png","29.png"],
              // zero: false,
              // unit_in_alignment: false,
              // h_space: 0,
              // angle: 0,
              // align_h: hmUI.align.LEFT,
              // type: hmUI.data_type.HOUR,
              // show_level: hmUI.show_level.ONLY_AOD,
            // });

            idle_hour_TextRotate_ASCIIARRAY[0] = '20.png';  // set of images with numbers
            idle_hour_TextRotate_ASCIIARRAY[1] = '21.png';  // set of images with numbers
            idle_hour_TextRotate_ASCIIARRAY[2] = '22.png';  // set of images with numbers
            idle_hour_TextRotate_ASCIIARRAY[3] = '23.png';  // set of images with numbers
            idle_hour_TextRotate_ASCIIARRAY[4] = '24.png';  // set of images with numbers
            idle_hour_TextRotate_ASCIIARRAY[5] = '25.png';  // set of images with numbers
            idle_hour_TextRotate_ASCIIARRAY[6] = '26.png';  // set of images with numbers
            idle_hour_TextRotate_ASCIIARRAY[7] = '27.png';  // set of images with numbers
            idle_hour_TextRotate_ASCIIARRAY[8] = '28.png';  // set of images with numbers
            idle_hour_TextRotate_ASCIIARRAY[9] = '29.png';  // set of images with numbers

            //start of ignored block
            for (let i = 0; i < 2; i++) {
              idle_hour_TextRotate[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 466,
                h: 466,
                center_x: -466,
                center_y: 0,
                pos_x: -466,
                pos_y: 0,
                angle: 0,
                src: '20.png',
                show_level: hmUI.show_level.ONLY_AOD,
              });
              idle_hour_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
            };
            //end of ignored block

            idle_digital_clock_img_time_hour = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: -466,
              hour_startY: 0,
              hour_array: ["30.png","31.png","32.png","33.png","34.png","35.png","36.png","37.png","38.png","39.png"],
              hour_zero: 0,
              hour_space: 0,
              hour_angle: 0,
              hour_align: hmUI.align.LEFT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            timeSensor.addEventListener(timeSensor.event.MINUTEEND, function() {
              let updateHour = timeSensor.minute == 0;

              time_update(updateHour, true);
            });

            // idle_analog_clock_pro_minute_pointer_img = hmUI.createWidget(hmUI.widget.TIME_POINTER_PRO, {
              // src: 'Min.png',
              // center_x: 233,
              // center_y: 233,
              // x: 233,
              // y: 233,
              // start_angle: 0,
              // end_angle: 360,
              // type: hmUI.data_type.minute,
              // show_level: hmUI.show_level.ONLY_AOD,
            // });


            idle_analog_clock_pro_minute_pointer_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: deviceInfo.width,
              h: deviceInfo.height,
              pos_x: 233 - 233,
              pos_y: 233 - 233,
              center_x: 233,
              center_y: 233,
              src: 'Min.png',
              angle: 0,
              show_level: hmUI.show_level.ONLY_AOD,
            });
            console.log('Watch_Face.Shortcuts');

            normal_battery_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 178,
              y: 259,
              w: 110,
              h: 110,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            //start of ignored block
            function time_update(updateHour = false, updateMinute = false) {
              console.log('time_update()');
              let hour = timeSensor.hour;
              let minute = timeSensor.minute;
              let second = timeSensor.second;
              let format_hour = timeSensor.format_hour;

              if (updateMinute) {
                let normal_fullAngle_minute = 360;
                let normal_angle_minute = 0 + normal_fullAngle_minute*(minute + second/60)/60;
                if (normal_analog_clock_pro_minute_pointer_img) normal_analog_clock_pro_minute_pointer_img.setProperty(hmUI.prop.ANGLE, normal_angle_minute);
              };

              if (updateMinute) {
                let idle_fullAngle_minute = 360;
                let idle_angle_minute = 0 + idle_fullAngle_minute*minute/60;
                if (idle_analog_clock_pro_minute_pointer_img) idle_analog_clock_pro_minute_pointer_img.setProperty(hmUI.prop.ANGLE, idle_angle_minute);
              };

            };

            //end of ignored block
            //start of ignored block
            function text_update() {
              console.log('text_update()');

              console.log('update text circle hour_TIME');
              let valueHour = timeSensor.format_hour;
              let normal_hour_circle_string = parseInt(valueHour).toString();
              normal_hour_circle_string = normal_hour_circle_string.padStart(2, '0');

              if (screenType != hmSetting.screen_type.AOD) {
                for (var i = 1; i < 2; i++) {  // hide all symbols
                  normal_hour_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                let char_Angle = 0;
                if (valueHour != null && valueHour != undefined && isFinite(valueHour) && normal_hour_circle_string.length > 0 && normal_hour_circle_string.length <= 2) {  // display data if it was possible to get it
                  let normal_hour_TextCircle_img_angle = 0;
                  let normal_hour_TextCircle_dot_img_angle = 0;
                  normal_hour_TextCircle_img_angle = toDegree(Math.atan2(normal_hour_TextCircle_img_width/2, 0));
                  // alignment = RIGHT
                  let normal_hour_TextCircle_angleOffset = normal_hour_TextCircle_img_angle * (normal_hour_circle_string.length - 1);
                  char_Angle -= 2 * normal_hour_TextCircle_angleOffset;
                  // alignment end
                  
                  let firstSymbol = true;
                  let index = 0;
                  for (let char of normal_hour_circle_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 2) break;
                    if (charCode >= 0 && charCode < 10) { 
                      if (!firstSymbol) char_Angle += normal_hour_TextCircle_img_angle;
                      firstSymbol = false;
                      normal_hour_TextCircle[index].setProperty(hmUI.prop.ANGLE, char_Angle);
                      normal_hour_TextCircle[index].setProperty(hmUI.prop.POS_X, 233 - normal_hour_TextCircle_img_width / 2);
                      normal_hour_TextCircle[index].setProperty(hmUI.prop.SRC, normal_hour_TextCircle_ASCIIARRAY[charCode]);
                      normal_hour_TextCircle[index].setProperty(hmUI.prop.VISIBLE, true);
                      char_Angle += normal_hour_TextCircle_img_angle;
                      index++;
                    };  // end if digit
                  };  // end char of string
                }  // end isFinite

              };

              console.log('update text rotate hour_TIME');
              let normal_hour_rotate_string = parseInt(valueHour).toString();

              if (screenType != hmSetting.screen_type.AOD) {
                for (var i = 1; i < 2; i++) {  // hide all symbols
                  normal_hour_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                if (valueHour != null && valueHour != undefined && isFinite(valueHour) && normal_hour_rotate_string.length > 0 && normal_hour_rotate_string.length <= 2) {  // display data if it was possible to get it
                  let img_offset = 0;
                  
                  let index = 0;
                  for (let char of normal_hour_rotate_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 2) break;
                    if (charCode >= 0 && charCode < 10) { 
                      normal_hour_TextRotate[index].setProperty(hmUI.prop.POS_X, -466 + img_offset);
                      normal_hour_TextRotate[index].setProperty(hmUI.prop.SRC, normal_hour_TextRotate_ASCIIARRAY[charCode]);
                      normal_hour_TextRotate[index].setProperty(hmUI.prop.VISIBLE, true);
                      img_offset += normal_hour_TextRotate_img_width;
                      index++;
                    };  // end if digit
                  };  // end char of string
                }  // end isFinite

              };

              console.log('update text circle hour_TIME');
              let idle_hour_circle_string = parseInt(valueHour).toString();
              idle_hour_circle_string = idle_hour_circle_string.padStart(2, '0');

              if (screenType == hmSetting.screen_type.AOD) {
                for (var i = 1; i < 2; i++) {  // hide all symbols
                  idle_hour_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                let char_Angle = 0;
                if (valueHour != null && valueHour != undefined && isFinite(valueHour) && idle_hour_circle_string.length > 0 && idle_hour_circle_string.length <= 2) {  // display data if it was possible to get it
                  let idle_hour_TextCircle_img_angle = 0;
                  let idle_hour_TextCircle_dot_img_angle = 0;
                  idle_hour_TextCircle_img_angle = toDegree(Math.atan2(idle_hour_TextCircle_img_width/2, 0));
                  // alignment = RIGHT
                  let idle_hour_TextCircle_angleOffset = idle_hour_TextCircle_img_angle * (idle_hour_circle_string.length - 1);
                  char_Angle -= 2 * idle_hour_TextCircle_angleOffset;
                  // alignment end
                  
                  let firstSymbol = true;
                  let index = 0;
                  for (let char of idle_hour_circle_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 2) break;
                    if (charCode >= 0 && charCode < 10) { 
                      if (!firstSymbol) char_Angle += idle_hour_TextCircle_img_angle;
                      firstSymbol = false;
                      idle_hour_TextCircle[index].setProperty(hmUI.prop.ANGLE, char_Angle);
                      idle_hour_TextCircle[index].setProperty(hmUI.prop.POS_X, 233 - idle_hour_TextCircle_img_width / 2);
                      idle_hour_TextCircle[index].setProperty(hmUI.prop.SRC, idle_hour_TextCircle_ASCIIARRAY[charCode]);
                      idle_hour_TextCircle[index].setProperty(hmUI.prop.VISIBLE, true);
                      char_Angle += idle_hour_TextCircle_img_angle;
                      index++;
                    };  // end if digit
                  };  // end char of string
                }  // end isFinite

              };

              console.log('update text rotate hour_TIME');
              let idle_hour_rotate_string = parseInt(valueHour).toString();

              if (screenType == hmSetting.screen_type.AOD) {
                for (var i = 1; i < 2; i++) {  // hide all symbols
                  idle_hour_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                if (valueHour != null && valueHour != undefined && isFinite(valueHour) && idle_hour_rotate_string.length > 0 && idle_hour_rotate_string.length <= 2) {  // display data if it was possible to get it
                  let img_offset = 0;
                  
                  let index = 0;
                  for (let char of idle_hour_rotate_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 2) break;
                    if (charCode >= 0 && charCode < 10) { 
                      idle_hour_TextRotate[index].setProperty(hmUI.prop.POS_X, -466 + img_offset);
                      idle_hour_TextRotate[index].setProperty(hmUI.prop.SRC, idle_hour_TextRotate_ASCIIARRAY[charCode]);
                      idle_hour_TextRotate[index].setProperty(hmUI.prop.VISIBLE, true);
                      img_offset += idle_hour_TextRotate_img_width;
                      index++;
                    };  // end if digit
                  };  // end char of string
                }  // end isFinite

              };

            };

            //end of ignored block
            function scale_call() {
              console.log('scale_call()');

                console.log('update scales BATTERY');
                
                let valueBattery = battery.current;
                let targetBattery = 100;
                let progressBattery = valueBattery/targetBattery;
                if (progressBattery > 1) progressBattery = 1;
                let progress_cs_normal_battery = progressBattery;

                if (screenType != hmSetting.screen_type.AOD) {

                  // normal_battery_circle_scale_circle_scale
                  let level = Math.round(progress_cs_normal_battery * 100);
                  if (normal_battery_circle_scale) {
                    normal_battery_circle_scale.setProperty(hmUI.prop.MORE, {                      
                      center_x: 233,
                      center_y: 315,
                      start_angle: 24,
                      end_angle: 336,
                      radius: 49,
                      line_width: 13,
                      corner_flag: 3,
                      color: 0xFFF0BA8B,
                      show_level: hmUI.show_level.ONLY_NORMAL,
                      level: level,
                    });
                  };
                };

            };

            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                console.log('resume_call()');
                scale_call();
                time_update(true, true);
                text_update();
                if (screenType == hmSetting.screen_type.WATCHFACE) {
                  if (!normal_timerTextUpdate) {
                    normal_timerTextUpdate = timer.createTimer(0, 1000, (function (option) {
                      text_update();
                    }));  // end timer 
                  };  // end timer check
                };  // end screenType

                if (screenType == hmSetting.screen_type.WATCHFACE) {
                  if (!normal_timerUpdateSec) {
                    let animDelay = timeSensor.utc % 1000;
                    let animRepeat = 1000;
                    normal_timerUpdateSec = timer.createTimer(animDelay, animRepeat, (function (option) {
                      time_update(false, true);
                    }));  // end timer 
                  };  // end timer check
                };  // end screenType

                if (screenType == hmSetting.screen_type.AOD) {
                  if (!idle_timerTextUpdate) {
                    idle_timerTextUpdate = timer.createTimer(0, 1000, (function (option) {
                      text_update();
                    }));  // end timer 
                  };  // end timer check
                };  // end screenType


              }),
              pause_call: (function () {
                console.log('pause_call()');
                if (normal_timerTextUpdate) {
                  timer.stopTimer(normal_timerTextUpdate);
                  normal_timerTextUpdate = undefined;
                }
                if (normal_timerUpdateSec) {
                  timer.stopTimer(normal_timerUpdateSec);
                  normal_timerUpdateSec = undefined;
                }
                if (idle_timerTextUpdate) {
                  timer.stopTimer(idle_timerTextUpdate);
                  idle_timerTextUpdate = undefined;
                }

              }),
            });

                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}