﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        const logger = Logger.getLogger('watchface_SashaCX75');
        //end of ignored block

        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_date_img_date_week_img = ''
        let normal_day_pointer_progress_date_pointer = ''
        let normal_day_TextRotate = new Array(2);
        let normal_day_TextRotate_ASCIIARRAY = new Array(10);
        let normal_day_TextRotate_img_width = 38;
        let normal_timerTextUpdate = undefined;
        let normal_date_img_date_day = ''
        let normal_battery_icon_img = ''
        let normal_battery_linear_scale = ''
        let normal_battery_pointer_progress_img_pointer = ''
        let normal_image_img = ''
        let normal_weather_image_progress_img_level = ''
        let normal_temperature_current_text_img = ''
        let normal_uvi_pointer_progress_img_pointer = ''
        let normal_step_pointer_progress_img_pointer = ''
        let normal_step_current_text_img = ''
        let normal_analog_clock_time_pointer_hour = ''
        let normal_analog_clock_time_pointer_minute = ''
        let normal_analog_clock_time_pointer_second = ''
        let idle_background_bg_img = ''
        let idle_date_img_date_week_img = ''
        let idle_day_pointer_progress_date_pointer = ''
        let idle_day_TextRotate = new Array(2);
        let idle_day_TextRotate_ASCIIARRAY = new Array(10);
        let idle_day_TextRotate_img_width = 38;
        let idle_timerTextUpdate = undefined;
        let idle_date_img_date_day = ''
        let idle_battery_icon_img = ''
        let idle_battery_linear_scale = ''
        let idle_battery_pointer_progress_img_pointer = ''
        let idle_image_img = ''
        let idle_weather_image_progress_img_level = ''
        let idle_temperature_current_text_img = ''
        let idle_uvi_pointer_progress_img_pointer = ''
        let idle_step_pointer_progress_img_pointer = ''
        let idle_step_current_text_img = ''
        let idle_analog_clock_time_pointer_hour = ''
        let idle_analog_clock_time_pointer_minute = ''
        let timeSensor = ''


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            console.log('Watch_Face.ScreenNormal');
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 466,
              h: 466,
              src: 'BG.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 284,
              y: 222,
              week_en: ["20.png","21.png","22.png","23.png","24.png","25.png","26.png"],
              week_tc: ["20.png","21.png","22.png","23.png","24.png","25.png","26.png"],
              week_sc: ["20.png","21.png","22.png","23.png","24.png","25.png","26.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_day_pointer_progress_date_pointer = hmUI.createWidget(hmUI.widget.DATE_POINTER, {
              src: 'date_ring.png',
              center_x: 233,
              center_y: 233,
              posX: 233,
              posY: 233,
              start_angle: 11,
              end_angle: -349,
              type: hmUI.date.DAY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_day_text_rotate_img = hmUI.createWidget(hmUI.widget.Text_Rotate, {
              // x: 353,
              // y: 214,
              // font_array: ["60.png","61.png","62.png","63.png","64.png","65.png","66.png","67.png","68.png","69.png"],
              // zero: true,
              // unit_in_alignment: false,
              // h_space: 0,
              // angle: 0,
              // align_h: hmUI.align.LEFT,
              // type: hmUI.data_type.DAY,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_day_TextRotate_ASCIIARRAY[0] = '60.png';  // set of images with numbers
            normal_day_TextRotate_ASCIIARRAY[1] = '61.png';  // set of images with numbers
            normal_day_TextRotate_ASCIIARRAY[2] = '62.png';  // set of images with numbers
            normal_day_TextRotate_ASCIIARRAY[3] = '63.png';  // set of images with numbers
            normal_day_TextRotate_ASCIIARRAY[4] = '64.png';  // set of images with numbers
            normal_day_TextRotate_ASCIIARRAY[5] = '65.png';  // set of images with numbers
            normal_day_TextRotate_ASCIIARRAY[6] = '66.png';  // set of images with numbers
            normal_day_TextRotate_ASCIIARRAY[7] = '67.png';  // set of images with numbers
            normal_day_TextRotate_ASCIIARRAY[8] = '68.png';  // set of images with numbers
            normal_day_TextRotate_ASCIIARRAY[9] = '69.png';  // set of images with numbers

            //start of ignored block
            for (let i = 0; i < 2; i++) {
              normal_day_TextRotate[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 466,
                h: 466,
                center_x: 353,
                center_y: 214,
                pos_x: 353,
                pos_y: 214,
                angle: 0,
                src: '60.png',
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
              normal_day_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
            };
            //end of ignored block

            if (!timeSensor) timeSensor = hmSensor.createSensor(hmSensor.id.TIME);
            let screenType = hmSetting.getScreenType();
            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 369,
              day_startY: 222,
              day_sc_array: ["10.png","11.png","12.png","13.png","14.png","15.png","16.png","17.png","18.png","19.png"],
              day_tc_array: ["10.png","11.png","12.png","13.png","14.png","15.png","16.png","17.png","18.png","19.png"],
              day_en_array: ["10.png","11.png","12.png","13.png","14.png","15.png","16.png","17.png","18.png","19.png"],
              day_zero: 0,
              day_space: 0,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'Battery_BG.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            if (screenType != hmSetting.screen_type.AOD) {
              normal_battery_linear_scale = hmUI.createWidget(hmUI.widget.FILL_RECT);
            };

            // normal_battery_linear_scale = hmUI.createWidget(hmUI.widget.Linear_Scale, {
              // start_x: 132,
              // start_y: 243,
              // color: 0xFFFFFFFF,
              // lenght: -21,
              // line_width: 10,
              // line_cap: Flat,
              // vertical: True,
              // mirror: False,
              // inversion: False,
              // alpha: 255,
              // type: hmUI.data_type.BATTERY,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });
            
            const battery = hmSensor.createSensor(hmSensor.id.BATTERY);
            battery.addEventListener(hmSensor.event.CHANGE, function() {
              scale_call();
            });

            normal_battery_pointer_progress_img_pointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
              src: 'BAtttery_Shadowed.png',
              center_x: 114,
              center_y: 233,
              x: 11,
              y: 44,
              start_angle: 180,
              end_angle: 360,
              invalid_visible: false,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_image_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'Frame.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 205,
              y: 100,
              image_array: ["0030.png","0031.png","0032.png","0033.png","0034.png","0035.png","0036.png","0037.png","0038.png","0039.png","0040.png","0041.png","0042.png","0043.png","0044.png","0045.png","0046.png","0047.png","0048.png","0049.png","0050.png","0051.png","0052.png","0053.png","0054.png","0055.png","0056.png","0057.png","0058.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 213,
              y: 160,
              font_array: ["00.png","01.png","02.png","03.png","04.png","05.png","06.png","07.png","08.png","09.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'Degree.png',
              unit_tc: 'Degree.png',
              unit_en: 'Degree.png',
              imperial_unit_sc: 'Degree.png',
              imperial_unit_tc: 'Degree.png',
              imperial_unit_en: 'Degree.png',
              negative_image: 'Minus.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            const temperatureUnit = hmSetting.getTemperatureUnit();
            //start of ignored block
            if (temperatureUnit == 1) {
              normal_temperature_current_text_img.setProperty(hmUI.prop.MORE, {
                x: 213,
                y: 160,
                font_array: ["00.png","01.png","02.png","03.png","04.png","05.png","06.png","07.png","08.png","09.png"],
                padding: false,
                h_space: 0,
                unit_sc: 'Degree.png',
                unit_tc: 'Degree.png',
                unit_en: 'Degree.png',
                imperial_unit_sc: 'Degree.png',
                imperial_unit_tc: 'Degree.png',
                imperial_unit_en: 'Degree.png',
                negative_image: 'Minus.png',
                align_h: hmUI.align.CENTER_H,
                type: hmUI.data_type.WEATHER_CURRENT,
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
            };
            //end of ignored block

            normal_uvi_pointer_progress_img_pointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
              src: 'UV.png',
              center_x: 233,
              center_y: 144,
              x: 2,
              y: 57,
              start_angle: -120,
              end_angle: 120,
              invalid_visible: false,
              type: hmUI.data_type.UVI,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_pointer_progress_img_pointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
              src: 'Steps_Shadowed.png',
              center_x: 233,
              center_y: 324,
              x: 12,
              y: 57,
              start_angle: -107,
              end_angle: 107,
              invalid_visible: false,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 201,
              y: 339,
              font_array: ["00.png","01.png","02.png","03.png","04.png","05.png","06.png","07.png","08.png","09.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_hour = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              hour_path: 'Hour.png',
              hour_centerX: 233,
              hour_centerY: 233,
              hour_posX: 233,
              hour_posY: 233,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_minute = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              minute_path: 'Min.png',
              minute_centerX: 233,
              minute_centerY: 233,
              minute_posX: 233,
              minute_posY: 233,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_second = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              second_path: 'Sec.png',
              second_centerX: 233,
              second_centerY: 233,
              second_posX: 233,
              second_posY: 233,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            console.log('Watch_Face.ScreenAOD');
            idle_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 466,
              h: 466,
              src: 'BG.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 285,
              y: 222,
              week_en: ["20.png","21.png","22.png","23.png","24.png","25.png","26.png"],
              week_tc: ["20.png","21.png","22.png","23.png","24.png","25.png","26.png"],
              week_sc: ["20.png","21.png","22.png","23.png","24.png","25.png","26.png"],
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_day_pointer_progress_date_pointer = hmUI.createWidget(hmUI.widget.DATE_POINTER, {
              src: 'date_ring.png',
              center_x: 233,
              center_y: 233,
              posX: 233,
              posY: 233,
              start_angle: 11,
              end_angle: -349,
              type: hmUI.date.DAY,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            // idle_day_text_rotate_img = hmUI.createWidget(hmUI.widget.Text_Rotate, {
              // x: 353,
              // y: 214,
              // font_array: ["60.png","61.png","62.png","63.png","64.png","65.png","66.png","67.png","68.png","69.png"],
              // zero: true,
              // unit_in_alignment: false,
              // h_space: 0,
              // angle: 0,
              // align_h: hmUI.align.LEFT,
              // type: hmUI.data_type.DAY,
              // show_level: hmUI.show_level.ONLY_AOD,
            // });

            idle_day_TextRotate_ASCIIARRAY[0] = '60.png';  // set of images with numbers
            idle_day_TextRotate_ASCIIARRAY[1] = '61.png';  // set of images with numbers
            idle_day_TextRotate_ASCIIARRAY[2] = '62.png';  // set of images with numbers
            idle_day_TextRotate_ASCIIARRAY[3] = '63.png';  // set of images with numbers
            idle_day_TextRotate_ASCIIARRAY[4] = '64.png';  // set of images with numbers
            idle_day_TextRotate_ASCIIARRAY[5] = '65.png';  // set of images with numbers
            idle_day_TextRotate_ASCIIARRAY[6] = '66.png';  // set of images with numbers
            idle_day_TextRotate_ASCIIARRAY[7] = '67.png';  // set of images with numbers
            idle_day_TextRotate_ASCIIARRAY[8] = '68.png';  // set of images with numbers
            idle_day_TextRotate_ASCIIARRAY[9] = '69.png';  // set of images with numbers

            //start of ignored block
            for (let i = 0; i < 2; i++) {
              idle_day_TextRotate[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 466,
                h: 466,
                center_x: 353,
                center_y: 214,
                pos_x: 353,
                pos_y: 214,
                angle: 0,
                src: '60.png',
                show_level: hmUI.show_level.ONLY_AOD,
              });
              idle_day_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
            };
            //end of ignored block

            idle_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 370,
              day_startY: 222,
              day_sc_array: ["10.png","11.png","12.png","13.png","14.png","15.png","16.png","17.png","18.png","19.png"],
              day_tc_array: ["10.png","11.png","12.png","13.png","14.png","15.png","16.png","17.png","18.png","19.png"],
              day_en_array: ["10.png","11.png","12.png","13.png","14.png","15.png","16.png","17.png","18.png","19.png"],
              day_zero: 0,
              day_space: 0,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_battery_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'Battery_BG.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            if (screenType == hmSetting.screen_type.AOD) {
              idle_battery_linear_scale = hmUI.createWidget(hmUI.widget.FILL_RECT);
            };

            // idle_battery_linear_scale = hmUI.createWidget(hmUI.widget.Linear_Scale, {
              // start_x: 132,
              // start_y: 243,
              // color: 0xFFFFFFFF,
              // lenght: -21,
              // line_width: 10,
              // line_cap: Flat,
              // vertical: True,
              // mirror: False,
              // inversion: False,
              // alpha: 255,
              // type: hmUI.data_type.BATTERY,
              // show_level: hmUI.show_level.ONLY_AOD,
            // });

            idle_battery_pointer_progress_img_pointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
              src: 'BAtttery_Shadowed.png',
              center_x: 114,
              center_y: 233,
              x: 11,
              y: 44,
              start_angle: 180,
              end_angle: 360,
              invalid_visible: false,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_image_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'Frame.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 205,
              y: 100,
              image_array: ["0030.png","0031.png","0032.png","0033.png","0034.png","0035.png","0036.png","0037.png","0038.png","0039.png","0040.png","0041.png","0042.png","0043.png","0044.png","0045.png","0046.png","0047.png","0048.png","0049.png","0050.png","0051.png","0052.png","0053.png","0054.png","0055.png","0056.png","0057.png","0058.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 213,
              y: 160,
              font_array: ["00.png","01.png","02.png","03.png","04.png","05.png","06.png","07.png","08.png","09.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'Degree.png',
              unit_tc: 'Degree.png',
              unit_en: 'Degree.png',
              imperial_unit_sc: 'Degree.png',
              imperial_unit_tc: 'Degree.png',
              imperial_unit_en: 'Degree.png',
              negative_image: 'Minus.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            //start of ignored block
            if (temperatureUnit == 1) {
              idle_temperature_current_text_img.setProperty(hmUI.prop.MORE, {
                x: 213,
                y: 160,
                font_array: ["00.png","01.png","02.png","03.png","04.png","05.png","06.png","07.png","08.png","09.png"],
                padding: false,
                h_space: 0,
                unit_sc: 'Degree.png',
                unit_tc: 'Degree.png',
                unit_en: 'Degree.png',
                imperial_unit_sc: 'Degree.png',
                imperial_unit_tc: 'Degree.png',
                imperial_unit_en: 'Degree.png',
                negative_image: 'Minus.png',
                align_h: hmUI.align.CENTER_H,
                type: hmUI.data_type.WEATHER_CURRENT,
                show_level: hmUI.show_level.ONLY_AOD,
              });
            };
            //end of ignored block

            idle_uvi_pointer_progress_img_pointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
              src: 'UV.png',
              center_x: 233,
              center_y: 144,
              x: 2,
              y: 57,
              start_angle: -120,
              end_angle: 120,
              invalid_visible: false,
              type: hmUI.data_type.UVI,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_step_pointer_progress_img_pointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
              src: 'Steps_Shadowed.png',
              center_x: 233,
              center_y: 324,
              x: 12,
              y: 57,
              start_angle: -107,
              end_angle: 107,
              invalid_visible: false,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 201,
              y: 339,
              font_array: ["00.png","01.png","02.png","03.png","04.png","05.png","06.png","07.png","08.png","09.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_analog_clock_time_pointer_hour = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              hour_path: 'Hour.png',
              hour_centerX: 233,
              hour_centerY: 233,
              hour_posX: 233,
              hour_posY: 233,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_analog_clock_time_pointer_minute = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              minute_path: 'Min_AOD.png',
              minute_centerX: 233,
              minute_centerY: 233,
              minute_posX: 233,
              minute_posY: 233,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            //start of ignored block
            function text_update() {
              console.log('text_update()');

              console.log('update text rotate day_TIME');
              let valueDay = timeSensor.day;
              let normal_day_rotate_string = parseInt(valueDay).toString();
              normal_day_rotate_string = normal_day_rotate_string.padStart(2, '0');

              if (screenType != hmSetting.screen_type.AOD) {
                for (var i = 1; i < 2; i++) {  // hide all symbols
                  normal_day_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                if (valueDay != null && valueDay != undefined && isFinite(valueDay) && normal_day_rotate_string.length > 0 && normal_day_rotate_string.length <= 2) {  // display data if it was possible to get it
                  let img_offset = 0;
                  
                  let index = 0;
                  for (let char of normal_day_rotate_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 2) break;
                    if (charCode >= 0 && charCode < 10) { 
                      normal_day_TextRotate[index].setProperty(hmUI.prop.POS_X, 353 + img_offset);
                      normal_day_TextRotate[index].setProperty(hmUI.prop.SRC, normal_day_TextRotate_ASCIIARRAY[charCode]);
                      normal_day_TextRotate[index].setProperty(hmUI.prop.VISIBLE, true);
                      img_offset += normal_day_TextRotate_img_width;
                      index++;
                    };  // end if digit
                  };  // end char of string
                }  // end isFinite

              };

              console.log('update text rotate day_TIME');
              let idle_day_rotate_string = parseInt(valueDay).toString();
              idle_day_rotate_string = idle_day_rotate_string.padStart(2, '0');

              if (screenType == hmSetting.screen_type.AOD) {
                for (var i = 1; i < 2; i++) {  // hide all symbols
                  idle_day_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                if (valueDay != null && valueDay != undefined && isFinite(valueDay) && idle_day_rotate_string.length > 0 && idle_day_rotate_string.length <= 2) {  // display data if it was possible to get it
                  let img_offset = 0;
                  
                  let index = 0;
                  for (let char of idle_day_rotate_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 2) break;
                    if (charCode >= 0 && charCode < 10) { 
                      idle_day_TextRotate[index].setProperty(hmUI.prop.POS_X, 353 + img_offset);
                      idle_day_TextRotate[index].setProperty(hmUI.prop.SRC, idle_day_TextRotate_ASCIIARRAY[charCode]);
                      idle_day_TextRotate[index].setProperty(hmUI.prop.VISIBLE, true);
                      img_offset += idle_day_TextRotate_img_width;
                      index++;
                    };  // end if digit
                  };  // end char of string
                }  // end isFinite

              };

            };

            //end of ignored block
            function scale_call() {
              console.log('scale_call()');

                console.log('update scales BATTERY');
                
                let valueBattery = battery.current;
                let targetBattery = 100;
                let progressBattery = valueBattery/targetBattery;
                if (progressBattery > 1) progressBattery = 1;
                let progress_ls_normal_battery = progressBattery;

                if (screenType != hmSetting.screen_type.AOD) {

                  // normal_battery_linear_scale
                  // initial parameters
                  let start_x_normal_battery = 132;
                  let start_y_normal_battery = 243;
                  let lenght_ls_normal_battery = -21;
                  let line_width_ls_normal_battery = 10;
                  let color_ls_normal_battery = 0xFFFFFFFF;
                  
                  // calculated parameters
                  let start_x_normal_battery_draw = start_x_normal_battery;
                  let start_y_normal_battery_draw = start_y_normal_battery;
                  lenght_ls_normal_battery = lenght_ls_normal_battery * progress_ls_normal_battery;
                  let lenght_ls_normal_battery_draw = line_width_ls_normal_battery;
                  let line_width_ls_normal_battery_draw = lenght_ls_normal_battery;
                  if (lenght_ls_normal_battery < 0){
                    line_width_ls_normal_battery_draw = -lenght_ls_normal_battery;
                    start_y_normal_battery_draw = start_y_normal_battery_draw - line_width_ls_normal_battery_draw;
                  };
                  
                  normal_battery_linear_scale.setProperty(hmUI.prop.MORE, {
                    x: start_x_normal_battery_draw,
                    y: start_y_normal_battery_draw,
                    w: lenght_ls_normal_battery_draw,
                    h: line_width_ls_normal_battery_draw,
                    color: color_ls_normal_battery,
                  });
                };

                console.log('update scales BATTERY');
                let progress_ls_idle_battery = progressBattery;

                if (screenType == hmSetting.screen_type.AOD) {

                  // idle_battery_linear_scale
                  // initial parameters
                  let start_x_idle_battery = 132;
                  let start_y_idle_battery = 243;
                  let lenght_ls_idle_battery = -21;
                  let line_width_ls_idle_battery = 10;
                  let color_ls_idle_battery = 0xFFFFFFFF;
                  
                  // calculated parameters
                  let start_x_idle_battery_draw = start_x_idle_battery;
                  let start_y_idle_battery_draw = start_y_idle_battery;
                  lenght_ls_idle_battery = lenght_ls_idle_battery * progress_ls_idle_battery;
                  let lenght_ls_idle_battery_draw = line_width_ls_idle_battery;
                  let line_width_ls_idle_battery_draw = lenght_ls_idle_battery;
                  if (lenght_ls_idle_battery < 0){
                    line_width_ls_idle_battery_draw = -lenght_ls_idle_battery;
                    start_y_idle_battery_draw = start_y_idle_battery_draw - line_width_ls_idle_battery_draw;
                  };
                  
                  idle_battery_linear_scale.setProperty(hmUI.prop.MORE, {
                    x: start_x_idle_battery_draw,
                    y: start_y_idle_battery_draw,
                    w: lenght_ls_idle_battery_draw,
                    h: line_width_ls_idle_battery_draw,
                    color: color_ls_idle_battery,
                  });
                };

            };

            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                console.log('resume_call()');
                scale_call();
                text_update();
                if (screenType == hmSetting.screen_type.WATCHFACE) {
                  if (!normal_timerTextUpdate) {
                    normal_timerTextUpdate = timer.createTimer(0, 1000, (function (option) {
                      text_update();
                    }));  // end timer 
                  };  // end timer check
                };  // end screenType

                if (screenType == hmSetting.screen_type.AOD) {
                  if (!idle_timerTextUpdate) {
                    idle_timerTextUpdate = timer.createTimer(0, 1000, (function (option) {
                      text_update();
                    }));  // end timer 
                  };  // end timer check
                };  // end screenType


              }),
              pause_call: (function () {
                console.log('pause_call()');
                if (normal_timerTextUpdate) {
                  timer.stopTimer(normal_timerTextUpdate);
                  normal_timerTextUpdate = undefined;
                }
                if (idle_timerTextUpdate) {
                  timer.stopTimer(idle_timerTextUpdate);
                  idle_timerTextUpdate = undefined;
                }

              }),
            });

                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}