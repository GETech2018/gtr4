﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        const logger = Logger.getLogger('watchface_SashaCX75');
        //end of ignored block

        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_system_disconnect_img = ''
        let normal_system_clock_img = ''
        let normal_date_img_date_year = ''
        let normal_date_img_date_month_img = ''
        let normal_battery_TextCircle = new Array(3);
        let normal_battery_TextCircle_ASCIIARRAY = new Array(10);
        let normal_battery_TextCircle_img_width = 20;
        let normal_battery_TextCircle_img_height = 36;
        let normal_calorie_current_text_img = ''
        let normal_heart_rate_text_text_img = ''
        let normal_distance_TextCircle = new Array(5);
        let normal_distance_TextCircle_ASCIIARRAY = new Array(10);
        let normal_distance_TextCircle_img_width = 20;
        let normal_distance_TextCircle_img_height = 36;
        let normal_distance_TextCircle_dot_width = 8;
        let normal_step_TextCircle = new Array(5);
        let normal_step_TextCircle_ASCIIARRAY = new Array(10);
        let normal_step_TextCircle_img_width = 20;
        let normal_step_TextCircle_img_height = 36;
        let normal_weather_image_progress_img_level = ''
        let normal_temperature_current_text_img = ''
        let normal_date_img_date_day = ''
        let normal_date_img_date_week_img = ''
        let normal_digital_clock_img_time = ''
        let idle_battery_current_text_font = ''
        let idle_digital_clock_img_time = ''
        let normal_step_jumpable_img_click = ''
        let normal_heart_jumpable_img_click = ''
        let normal_battery_jumpable_img_click = ''
        let normal_sunrise_jumpable_img_click = ''
        let normal_temperature_jumpable_img_click = ''
        let normal_alarm_jumpable_img_click = ''
        let normal_fatBurning_jumpable_img_click = ''
        let Button_1 = ''
        let Button_2 = ''
        let Button_3 = ''
        let Button_4 = ''


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            console.log('Watch_Face.ScreenNormal');
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 466,
              h: 466,
              src: '0.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 220,
              y: 296,
              src: 'bt.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 0,
              y: 219,
              src: '31.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_year = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              year_startX: 342,
              year_startY: 159,
              year_sc_array: ["bs0.png","bs1.png","bs2.png","bs3.png","bs4.png","bs5.png","bs6.png","bs7.png","bs8.png","bs9.png"],
              year_tc_array: ["bs0.png","bs1.png","bs2.png","bs3.png","bs4.png","bs5.png","bs6.png","bs7.png","bs8.png","bs9.png"],
              year_en_array: ["bs0.png","bs1.png","bs2.png","bs3.png","bs4.png","bs5.png","bs6.png","bs7.png","bs8.png","bs9.png"],
              year_zero: 1,
              year_space: -5,
              year_align: hmUI.align.CENTER_H,
              year_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_month_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 277,
              month_startY: 162,
              month_sc_array: ["m01.png","m02.png","m03.png","m04.png","m05.png","m06.png","m07.png","m08.png","m09.png","m10.png","m11.png","m12.png"],
              month_tc_array: ["m01.png","m02.png","m03.png","m04.png","m05.png","m06.png","m07.png","m08.png","m09.png","m10.png","m11.png","m12.png"],
              month_en_array: ["m01.png","m02.png","m03.png","m04.png","m05.png","m06.png","m07.png","m08.png","m09.png","m10.png","m11.png","m12.png"],
              month_is_character: true ,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_battery_text_circle_img = hmUI.createWidget(hmUI.widget.Text_Circle, {
              // circle_center_X: 233,
              // circle_center_Y: 233,
              // font_array: ["s01.png","s02.png","s03.png","s04.png","s05.png","s06.png","s07.png","s08.png","s09.png","s10.png"],
              // radius: 221,
              // angle: 180,
              // char_space_angle: 0,
              // zero: false,
              // reverse_direction: true,
              // unit_in_alignment: true,
              // vertical_alignment: CENTER_V,
              // horizontal_alignment: CENTER_H,
              // type: hmUI.data_type.BATTERY,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_battery_TextCircle_ASCIIARRAY[0] = 's01.png';  // set of images with numbers
            normal_battery_TextCircle_ASCIIARRAY[1] = 's02.png';  // set of images with numbers
            normal_battery_TextCircle_ASCIIARRAY[2] = 's03.png';  // set of images with numbers
            normal_battery_TextCircle_ASCIIARRAY[3] = 's04.png';  // set of images with numbers
            normal_battery_TextCircle_ASCIIARRAY[4] = 's05.png';  // set of images with numbers
            normal_battery_TextCircle_ASCIIARRAY[5] = 's06.png';  // set of images with numbers
            normal_battery_TextCircle_ASCIIARRAY[6] = 's07.png';  // set of images with numbers
            normal_battery_TextCircle_ASCIIARRAY[7] = 's08.png';  // set of images with numbers
            normal_battery_TextCircle_ASCIIARRAY[8] = 's09.png';  // set of images with numbers
            normal_battery_TextCircle_ASCIIARRAY[9] = 's10.png';  // set of images with numbers

            //start of ignored block
            for (let i = 0; i < 3; i++) {
              normal_battery_TextCircle[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 466,
                h: 466,
                center_x: 233,
                center_y: 233,
                pos_x: 233 - normal_battery_TextCircle_img_width / 2,
                pos_y: 233 + 203,
                src: 's01.png',
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
              normal_battery_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
            };
            //end of ignored block
            
            const battery = hmSensor.createSensor(hmSensor.id.BATTERY);
            battery.addEventListener(hmSensor.event.CHANGE, function() {
              text_update();
            });
            
            function toDegree (radian) {
              return radian * (180 / Math.PI);
            };

            normal_calorie_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 244,
              y: 370,
              font_array: ["s01.png","s02.png","s03.png","s04.png","s05.png","s06.png","s07.png","s08.png","s09.png","s10.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 149,
              y: 370,
              font_array: ["s01.png","s02.png","s03.png","s04.png","s05.png","s06.png","s07.png","s08.png","s09.png","s10.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_distance_text_circle_img = hmUI.createWidget(hmUI.widget.Text_Circle, {
              // circle_center_X: 233,
              // circle_center_Y: 233,
              // font_array: ["s01.png","s02.png","s03.png","s04.png","s05.png","s06.png","s07.png","s08.png","s09.png","s10.png"],
              // radius: 221,
              // angle: 136,
              // char_space_angle: 0,
              // dot_image: '11.png',
              // zero: false,
              // reverse_direction: true,
              // unit_in_alignment: true,
              // vertical_alignment: CENTER_V,
              // horizontal_alignment: RIGHT,
              // type: hmUI.data_type.DISTANCE,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_distance_TextCircle_ASCIIARRAY[0] = 's01.png';  // set of images with numbers
            normal_distance_TextCircle_ASCIIARRAY[1] = 's02.png';  // set of images with numbers
            normal_distance_TextCircle_ASCIIARRAY[2] = 's03.png';  // set of images with numbers
            normal_distance_TextCircle_ASCIIARRAY[3] = 's04.png';  // set of images with numbers
            normal_distance_TextCircle_ASCIIARRAY[4] = 's05.png';  // set of images with numbers
            normal_distance_TextCircle_ASCIIARRAY[5] = 's06.png';  // set of images with numbers
            normal_distance_TextCircle_ASCIIARRAY[6] = 's07.png';  // set of images with numbers
            normal_distance_TextCircle_ASCIIARRAY[7] = 's08.png';  // set of images with numbers
            normal_distance_TextCircle_ASCIIARRAY[8] = 's09.png';  // set of images with numbers
            normal_distance_TextCircle_ASCIIARRAY[9] = 's10.png';  // set of images with numbers

            //start of ignored block
            for (let i = 0; i < 5; i++) {
              normal_distance_TextCircle[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 466,
                h: 466,
                center_x: 233,
                center_y: 233,
                pos_x: 233 - normal_distance_TextCircle_img_width / 2,
                pos_y: 233 + 203,
                src: 's01.png',
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
              normal_distance_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
            };
            //end of ignored block
            
            const distance = hmSensor.createSensor(hmSensor.id.DISTANCE);
            distance.addEventListener(hmSensor.event.CHANGE, function() {
              text_update();
            });

            // normal_step_text_circle_img = hmUI.createWidget(hmUI.widget.Text_Circle, {
              // circle_center_X: 233,
              // circle_center_Y: 233,
              // font_array: ["s01.png","s02.png","s03.png","s04.png","s05.png","s06.png","s07.png","s08.png","s09.png","s10.png"],
              // radius: 221,
              // angle: 227,
              // char_space_angle: 0,
              // zero: false,
              // reverse_direction: true,
              // unit_in_alignment: true,
              // vertical_alignment: CENTER_V,
              // horizontal_alignment: LEFT,
              // type: hmUI.data_type.STEP,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_step_TextCircle_ASCIIARRAY[0] = 's01.png';  // set of images with numbers
            normal_step_TextCircle_ASCIIARRAY[1] = 's02.png';  // set of images with numbers
            normal_step_TextCircle_ASCIIARRAY[2] = 's03.png';  // set of images with numbers
            normal_step_TextCircle_ASCIIARRAY[3] = 's04.png';  // set of images with numbers
            normal_step_TextCircle_ASCIIARRAY[4] = 's05.png';  // set of images with numbers
            normal_step_TextCircle_ASCIIARRAY[5] = 's06.png';  // set of images with numbers
            normal_step_TextCircle_ASCIIARRAY[6] = 's07.png';  // set of images with numbers
            normal_step_TextCircle_ASCIIARRAY[7] = 's08.png';  // set of images with numbers
            normal_step_TextCircle_ASCIIARRAY[8] = 's09.png';  // set of images with numbers
            normal_step_TextCircle_ASCIIARRAY[9] = 's10.png';  // set of images with numbers

            //start of ignored block
            for (let i = 0; i < 5; i++) {
              normal_step_TextCircle[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 466,
                h: 466,
                center_x: 233,
                center_y: 233,
                pos_x: 233 - normal_step_TextCircle_img_width / 2,
                pos_y: 233 + 203,
                src: 's01.png',
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
              normal_step_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
            };
            //end of ignored block
            
            const step = hmSensor.createSensor(hmSensor.id.STEP);
            step.addEventListener(hmSensor.event.CHANGE, function() {
              text_update();
            });

            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 370,
              y: 193,
              image_array: ["0095.png","0096.png","0097.png","0098.png","0099.png","0100.png","0101.png","0102.png","0103.png","0104.png","0105.png","0106.png","0107.png","0108.png","0109.png","0110.png","0111.png","0112.png","0113.png","0114.png","0115.png","0116.png","0117.png","0118.png","0119.png","0120.png","0121.png","0122.png","0123.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 374,
              y: 268,
              font_array: ["s01.png","s02.png","s03.png","s04.png","s05.png","s06.png","s07.png","s08.png","s09.png","s10.png"],
              padding: false,
              h_space: 0,
              unit_sc: '14.png',
              unit_tc: '14.png',
              unit_en: '14.png',
              imperial_unit_sc: '15.png',
              imperial_unit_tc: '15.png',
              imperial_unit_en: '15.png',
              negative_image: 'neg.png',
              invalid_image: 'inv.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            const temperatureUnit = hmSetting.getTemperatureUnit();
            //start of ignored block
            if (temperatureUnit == 1) {
              normal_temperature_current_text_img.setProperty(hmUI.prop.MORE, {
                x: 374,
                y: 268,
                font_array: ["s01.png","s02.png","s03.png","s04.png","s05.png","s06.png","s07.png","s08.png","s09.png","s10.png"],
                padding: false,
                h_space: 0,
                unit_sc: '15.png',
                unit_tc: '15.png',
                unit_en: '15.png',
                imperial_unit_sc: '14.png',
                imperial_unit_tc: '14.png',
                imperial_unit_en: '14.png',
                negative_image: 'neg.png',
                invalid_image: 'inv.png',
                align_h: hmUI.align.CENTER_H,
                type: hmUI.data_type.WEATHER_CURRENT,
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
            };
            //end of ignored block

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 201,
              day_startY: 20,
              day_sc_array: ["35.png","36.png","37.png","38.png","39.png","40.png","41.png","42.png","43.png","44.png"],
              day_tc_array: ["35.png","36.png","37.png","38.png","39.png","40.png","41.png","42.png","43.png","44.png"],
              day_en_array: ["35.png","36.png","37.png","38.png","39.png","40.png","41.png","42.png","43.png","44.png"],
              day_zero: 1,
              day_space: -4,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 65,
              y: 84,
              week_en: ["57.png","58.png","59.png","60.png","61.png","62.png","63.png"],
              week_tc: ["57.png","58.png","59.png","60.png","61.png","62.png","63.png"],
              week_sc: ["57.png","58.png","59.png","60.png","61.png","62.png","63.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 44,
              hour_startY: 168,
              hour_array: ["71.png","72.png","73.png","74.png","75.png","76.png","77.png","78.png","79.png","80.png"],
              hour_zero: 1,
              hour_space: 0,
              hour_angle: 0,
              hour_align: hmUI.align.CENTER_H,

              minute_startX: 246,
              minute_startY: 209,
              minute_array: ["81.png","82.png","83.png","84.png","85.png","86.png","87.png","88.png","89.png","90.png"],
              minute_zero: 1,
              minute_space: 0,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.CENTER_H,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            console.log('Watch_Face.ScreenAOD');

            idle_battery_current_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 196,
              y: 433,
              w: 74,
              h: 30,
              text_size: 30,
              char_space: 0,
              line_space: 0,
              color: 0xFFFFFFFF,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.CENTER_V,
              unit_type: 1,
              text_style: hmUI.text_style.ELLIPSIS,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 158,
              hour_startY: 122,
              hour_array: ["01.png","02.png","03.png","04.png","05.png","06.png","07.png","08.png","09.png","10.png"],
              hour_zero: 1,
              hour_space: 0,
              hour_angle: 0,
              hour_align: hmUI.align.CENTER_H,

              minute_startX: 158,
              minute_startY: 235,
              minute_array: ["01.png","02.png","03.png","04.png","05.png","06.png","07.png","08.png","09.png","10.png"],
              minute_zero: 1,
              minute_space: 0,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.CENTER_H,

              show_level: hmUI.show_level.ONLY_AOD,
            });
            console.log('Watch_Face.Shortcuts');

            normal_step_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 29,
              y: 316,
              w: 106,
              h: 100,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 142,
              y: 316,
              w: 74,
              h: 85,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 186,
              y: 409,
              w: 100,
              h: 57,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sunrise_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 370,
              y: 205,
              w: 90,
              h: 50,
              type: hmUI.data_type.SUN_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 371,
              y: 264,
              w: 86,
              h: 40,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_alarm_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 0,
              y: 216,
              w: 40,
              h: 40,
              type: hmUI.data_type.ALARM_CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_fatBurning_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 244,
              y: 316,
              w: 82,
              h: 84,
              type: hmUI.data_type.FAT_BURNING,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            console.log('Watch_Face.Buttons');
            Button_1 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 116,
              y: 33,
              w: 70,
              h: 40,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'transparent.png',
              normal_src: 'transparent.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'PhoneHomeScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_2 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 282,
              y: 33,
              w: 70,
              h: 40,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'transparent.png',
              normal_src: 'transparent.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'MusicCommonScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_3 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 61,
              y: 93,
              w: 314,
              h: 49,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'transparent.png',
              normal_src: 'transparent.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'ScheduleCalScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_4 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 45,
              y: 201,
              w: 314,
              h: 95,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'transparent.png',
              normal_src: 'transparent.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'WorldClockScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            let screenType = hmSetting.getScreenType();
            //start of ignored block
            function text_update() {
              console.log('text_update()');

              console.log('update text circle battery_BATTERY');
              let valueBattery = battery.current;
              let normal_battery_circle_string = parseInt(valueBattery).toString();

              if (screenType != hmSetting.screen_type.AOD) {
                for (var i = 1; i < 3; i++) {  // hide all symbols
                  normal_battery_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                let char_Angle = 360;
                if (valueBattery != null && valueBattery != undefined && isFinite(valueBattery) && normal_battery_circle_string.length > 0 && normal_battery_circle_string.length <= 3) {  // display data if it was possible to get it
                  let normal_battery_TextCircle_img_angle = 0;
                  let normal_battery_TextCircle_dot_img_angle = 0;
                  normal_battery_TextCircle_img_angle = toDegree(Math.atan2(normal_battery_TextCircle_img_width/2, 221));
                  // alignment = CENTER_H
                  let normal_battery_TextCircle_angleOffset = normal_battery_TextCircle_img_angle * (normal_battery_circle_string.length - 1);
                  normal_battery_TextCircle_angleOffset = -normal_battery_TextCircle_angleOffset;
                  char_Angle -= normal_battery_TextCircle_angleOffset;
                  // alignment end
                  
                  let firstSymbol = true;
                  let index = 0;
                  for (let char of normal_battery_circle_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 3) break;
                    if (charCode >= 0 && charCode < 10) { 
                      if (!firstSymbol) char_Angle -= normal_battery_TextCircle_img_angle;
                      firstSymbol = false;
                      normal_battery_TextCircle[index].setProperty(hmUI.prop.ANGLE, char_Angle);
                      normal_battery_TextCircle[index].setProperty(hmUI.prop.POS_X, 233 - normal_battery_TextCircle_img_width / 2);
                      normal_battery_TextCircle[index].setProperty(hmUI.prop.SRC, normal_battery_TextCircle_ASCIIARRAY[charCode]);
                      normal_battery_TextCircle[index].setProperty(hmUI.prop.VISIBLE, true);
                      char_Angle -= normal_battery_TextCircle_img_angle;
                      index++;
                    };  // end if digit
                  };  // end char of string
                }  // end isFinite

              };

              console.log('update text circle DISTANCE');
              let distanceCurrent = distance.current;
              let normal_distance_circle_string = (distanceCurrent / 1000).toFixed(2);

              if (screenType != hmSetting.screen_type.AOD) {
                for (var i = 1; i < 5; i++) {  // hide all symbols
                  normal_distance_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                let char_Angle = 316;
                if (distanceCurrent != null && distanceCurrent != undefined && isFinite(distanceCurrent) && normal_distance_circle_string.length > 0 && normal_distance_circle_string.length <= 5) {  // display data if it was possible to get it
                  let normal_distance_TextCircle_img_angle = 0;
                  let normal_distance_TextCircle_dot_img_angle = 0;
                  normal_distance_TextCircle_img_angle = toDegree(Math.atan2(normal_distance_TextCircle_img_width/2, 221));
                  normal_distance_TextCircle_dot_img_angle = toDegree(Math.atan2(normal_distance_TextCircle_dot_width/2, 221));
                  // alignment = RIGHT
                  let normal_distance_TextCircle_angleOffset = normal_distance_TextCircle_img_angle * (normal_distance_circle_string.length - 1);
                  normal_distance_TextCircle_angleOffset = normal_distance_TextCircle_angleOffset - normal_distance_TextCircle_img_angle + normal_distance_TextCircle_dot_img_angle;
                  normal_distance_TextCircle_angleOffset = -normal_distance_TextCircle_angleOffset;
                  char_Angle -= 2 * normal_distance_TextCircle_angleOffset;
                  // alignment end
                  
                  let firstSymbol = true;
                  let index = 0;
                  for (let char of normal_distance_circle_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 5) break;
                    if (charCode >= 0 && charCode < 10) { 
                      if (!firstSymbol) char_Angle -= normal_distance_TextCircle_img_angle;
                      firstSymbol = false;
                      normal_distance_TextCircle[index].setProperty(hmUI.prop.ANGLE, char_Angle);
                      normal_distance_TextCircle[index].setProperty(hmUI.prop.POS_X, 233 - normal_distance_TextCircle_img_width / 2);
                      normal_distance_TextCircle[index].setProperty(hmUI.prop.SRC, normal_distance_TextCircle_ASCIIARRAY[charCode]);
                      normal_distance_TextCircle[index].setProperty(hmUI.prop.VISIBLE, true);
                      char_Angle -= normal_distance_TextCircle_img_angle;
                      index++;
                    }  // end if digit
                    else { 
                      if (!firstSymbol) char_Angle -= normal_distance_TextCircle_dot_img_angle; 
                      firstSymbol = false;
                      normal_distance_TextCircle[index].setProperty(hmUI.prop.ANGLE, char_Angle);
                      normal_distance_TextCircle[index].setProperty(hmUI.prop.POS_X, 233 - normal_distance_TextCircle_dot_width / 2);
                      normal_distance_TextCircle[index].setProperty(hmUI.prop.SRC, '11.png');
                      normal_distance_TextCircle[index].setProperty(hmUI.prop.VISIBLE, true);
                      char_Angle -= normal_distance_TextCircle_dot_img_angle;
                      index++;
                    };  // end if dot point 
                  };  // end char of string
                }  // end isFinite

              };

              console.log('update text circle step_STEP');
              let valueStep = step.current;
              let normal_step_circle_string = parseInt(valueStep).toString();

              if (screenType != hmSetting.screen_type.AOD) {
                for (var i = 1; i < 5; i++) {  // hide all symbols
                  normal_step_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                let char_Angle = 407;
                if (valueStep != null && valueStep != undefined && isFinite(valueStep) && normal_step_circle_string.length > 0 && normal_step_circle_string.length <= 5) {  // display data if it was possible to get it
                  let normal_step_TextCircle_img_angle = 0;
                  let normal_step_TextCircle_dot_img_angle = 0;
                  normal_step_TextCircle_img_angle = toDegree(Math.atan2(normal_step_TextCircle_img_width/2, 221));
                  
                  let firstSymbol = true;
                  let index = 0;
                  for (let char of normal_step_circle_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 5) break;
                    if (charCode >= 0 && charCode < 10) { 
                      if (!firstSymbol) char_Angle -= normal_step_TextCircle_img_angle;
                      firstSymbol = false;
                      normal_step_TextCircle[index].setProperty(hmUI.prop.ANGLE, char_Angle);
                      normal_step_TextCircle[index].setProperty(hmUI.prop.POS_X, 233 - normal_step_TextCircle_img_width / 2);
                      normal_step_TextCircle[index].setProperty(hmUI.prop.SRC, normal_step_TextCircle_ASCIIARRAY[charCode]);
                      normal_step_TextCircle[index].setProperty(hmUI.prop.VISIBLE, true);
                      char_Angle -= normal_step_TextCircle_img_angle;
                      index++;
                    };  // end if digit
                  };  // end char of string
                }  // end isFinite

              };

            };

            //end of ignored block
            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                console.log('resume_call()');
                text_update();
              }),
            });

                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}