﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        //const logger = Logger.getLogger('watchface_SashaCX75');
        const logger = DeviceRuntimeCore.HmLogger.getLogger('watchface_SashaCX75')
        //end of ignored block

        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_system_disconnect_img = ''
        let normal_system_clock_img = ''
        let normal_group_ForecastWeather = ''
        let normal_forecast_date_week_font = new Array(3);
        let normal_forecast_date_week_font_Array = ['LU', 'MA', 'MI', 'JU', 'VI', 'SA', 'DO'];
        let normal_forecast_low_text_font = new Array(3);
        let normal_forecast_high_text_font = new Array(3);
        let normal_forecast_image_progress_img_level = new Array(3);
        let normal_forecast_image_array = ['P0056.png', 'P0057.png', 'P0058.png', 'P0059.png', 'P0060.png', 'P0061.png', 'P0062.png', 'P0063.png', 'P0064.png', 'P0065.png', 'P0066.png', 'P0067.png', 'P0068.png', 'P0069.png', 'P0070.png', 'P0071.png', 'P0072.png', 'P0073.png', 'P0074.png', 'P0075.png', 'P0076.png', 'P0077.png', 'P0078.png', 'P0079.png', 'P0080.png', 'P0081.png', 'P0082.png', 'P0083.png', 'P0084.png'];
        let normal_dow_text_font = ''
        let normal_DOW_Array = ['LUNES', 'MARTES', 'MIERCOLES', 'JUEVES', 'VIERNES', 'SABADO', 'DOMINGO'];
        let normal_weather_image_progress_img_level = ''
        let normal_temperature_current_text_img = ''
        let normal_date_img_date_day = ''
        let normal_date_img_date_month = ''
        let normal_date_img_date_year = ''
        let normal_battery_text_text_img = ''
        let normal_heart_rate_text_text_img = ''
        let normal_calorie_current_text_img = ''
        let normal_step_current_text_img = ''
        let normal_frame_animation_1 = ''
        let normal_digital_clock_img_time = ''
        let normal_analog_clock_time_pointer_second = ''
        let idle_system_disconnect_img = ''
        let idle_system_clock_img = ''
        let idle_dow_text_font = ''
        let idle_DOW_Array = ['LUNES', 'MARTES', 'MIERCOLES', 'JUEVES', 'VIERNES', 'SABADO', 'DOMINGO'];
        let idle_day_text_font = ''
        let idle_battery_current_text_font = ''
        let idle_digital_clock_img_time = ''
        let normal_step_jumpable_img_click = ''
        let normal_heart_jumpable_img_click = ''
        let normal_battery_jumpable_img_click = ''
        let normal_temperature_jumpable_img_click = ''
        let normal_alarm_jumpable_img_click = ''
        let normal_fatBurning_jumpable_img_click = ''
        let Button_1 = ''
        let Button_2 = ''
        let Button_3 = ''
        let Button_4 = ''
        let Button_5 = ''
        let timeSensor = '';


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            // FontName: Eurosti.ttf; FontSize: 20
            hmUI.createWidget(hmUI.widget.TEXT, {
              x: 464,
              y: 464,
              w: 288,
              h: 25,
              text_size: 20,
              char_space: 0,
              line_space: 0,
              font: 'fonts/Eurosti.ttf',
              color: 0xFFFFFFFF,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              text: "0123456789 _-.,:;`'%°\\/",
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // FontName: Eurosti.ttf; FontSize: 25; Cache: full
            hmUI.createWidget(hmUI.widget.TEXT, {
              x: 464,
              y: 464,
              w: 30,
              h: 30,
              text_size: 25,
              char_space: 0,
              line_space: 0,
              font: 'fonts/Eurosti.ttf',
              color: 0xFFFFFFFF,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.NONE,
              text: "0123456789 ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz АБВГДЕЁЖЗИЙКЛМНОПРСТУФХЦЧШЩЪЫЬЭЮЯабвгдеёжзийклмнопрстуфхцчшщъыьэюя  ҐЄІЇґєії _-.,:;`'%°\\/",
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // FontName: Eurosti.ttf; FontSize: 27
            hmUI.createWidget(hmUI.widget.TEXT, {
              x: 464,
              y: 464,
              w: 396,
              h: 34,
              text_size: 27,
              char_space: 0,
              line_space: 0,
              font: 'fonts/Eurosti.ttf',
              color: 0xFF808080,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              text: "0123456789 _-.,:;`'%°\\/",
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // FontName: Eurosti.ttf; FontSize: 34
            hmUI.createWidget(hmUI.widget.TEXT, {
              x: 464,
              y: 464,
              w: 494,
              h: 43,
              text_size: 34,
              char_space: 0,
              line_space: 0,
              font: 'fonts/Eurosti.ttf',
              color: 0xFF808080,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              text: "0123456789 _-.,:;`'%°\\/",
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            console.log('Watch_Face.ScreenNormal');
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 466,
              h: 466,
              src: '1.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 432,
              y: 209,
              src: '110.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 45,
              y: 173,
              src: '111.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            let screenType = hmSetting.getScreenType();            
            // normal_Weather_FewDays = hmUI.createWidget(hmUI.widget.FewDays, {
              // x: 8,
              // y: 0,
              // ColumnWidth: 72,
              // DaysCount: 3,
            // });
            
            normal_group_ForecastWeather = hmUI.createWidget(hmUI.widget.GROUP, {
              x: 8,
              y: 0,
              h: 0,
              w: 0,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_forecast_date_week_font = normal_group_ForecastWeather.createWidget(hmUI.widget.TEXT_Options, {
              // x: 119,
              // y: 161,
              // w: 46,
              // h: 30,
              // text_size: 20,
              // char_space: 0,
              // line_space: 0,
              // alpha: 255,
              // font: 'fonts/Eurosti.ttf',
              // color: 0xFFFFFFFF,
              // color_2: 0xFFFF0000,
              // use_color_2: False,
              // align_h: hmUI.align.CENTER_H,
              // align_v: hmUI.align.TOP,
              // text_style: hmUI.text_style.ELLIPSIS,
              // type: hmUI.data_type.forecast_date_week_img,
              // unit_string: LU, MA, MI, JU, VI, SA, DO,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            //#region screenType
            if (screenType == hmSetting.screen_type.WATCHFACE) {
              for (let i = 0; i < 3; i++) {
                normal_forecast_date_week_font[i] = normal_group_ForecastWeather.createWidget(hmUI.widget.TEXT, {
                  x: 119 + i*72,
                  y: 161,
                  w: 46,
                  h: 30,
                  text_size: 20,
                  char_space: 0,
                  line_space: 0,
                  font: 'fonts/Eurosti.ttf',
                  color: 0xFFFFFFFF,
                  // color_2: 0xFFFF0000,
                  align_h: hmUI.align.CENTER_H,
                  align_v: hmUI.align.TOP,
                  text_style: hmUI.text_style.ELLIPSIS,
                  // unit_string: LU, MA, MI, JU, VI, SA, DO,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });
              };
            };
            //#endregion

            if (!timeSensor) timeSensor = hmSensor.createSensor(hmSensor.id.TIME);
            // normal_forecast_low_text_font = normal_group_ForecastWeather.createWidget(hmUI.widget.TEXT_Options, {
              // x: 119,
              // y: 244,
              // w: 46,
              // h: 30,
              // text_size: 18,
              // char_space: 0,
              // line_space: 0,
              // alpha: 255,
              // color: 0xFFFFFFFF,
              // color_2: 0xFFFF0000,
              // use_color_2: False,
              // align_h: hmUI.align.CENTER_H,
              // align_v: hmUI.align.TOP,
              // text_style: hmUI.text_style.ELLIPSIS,
              // type: hmUI.data_type.forecast_low_text_font,
              // unit_type: 1,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            //#region screenType
            if (screenType == hmSetting.screen_type.WATCHFACE) {
              for (let i = 0; i < 3; i++) {
                normal_forecast_low_text_font[i] = normal_group_ForecastWeather.createWidget(hmUI.widget.TEXT, {
                  x: 119 + i*72,
                  y: 244,
                  w: 46,
                  h: 30,
                  text_size: 18,
                  char_space: 0,
                  line_space: 0,
                  color: 0xFFFFFFFF,
                  align_h: hmUI.align.CENTER_H,
                  align_v: hmUI.align.TOP,
                  text_style: hmUI.text_style.ELLIPSIS,
                  // unit_type: 1,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });
              };
            };
            //#endregion

            // normal_forecast_high_text_font = normal_group_ForecastWeather.createWidget(hmUI.widget.TEXT_Options, {
              // x: 119,
              // y: 222,
              // w: 46,
              // h: 30,
              // text_size: 18,
              // char_space: 0,
              // line_space: 0,
              // alpha: 255,
              // color: 0xFFFFFFFF,
              // color_2: 0xFFFF0000,
              // use_color_2: False,
              // align_h: hmUI.align.CENTER_H,
              // align_v: hmUI.align.TOP,
              // text_style: hmUI.text_style.ELLIPSIS,
              // type: hmUI.data_type.forecast_high_text_font,
              // unit_type: 1,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            //#region screenType
            if (screenType == hmSetting.screen_type.WATCHFACE) {
              for (let i = 0; i < 3; i++) {
                normal_forecast_high_text_font[i] = normal_group_ForecastWeather.createWidget(hmUI.widget.TEXT, {
                  x: 119 + i*72,
                  y: 222,
                  w: 46,
                  h: 30,
                  text_size: 18,
                  char_space: 0,
                  line_space: 0,
                  color: 0xFFFFFFFF,
                  align_h: hmUI.align.CENTER_H,
                  align_v: hmUI.align.TOP,
                  text_style: hmUI.text_style.ELLIPSIS,
                  // unit_type: 1,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });
              };
            };
            //#endregion

            // normal_forecast_image_progress_img_level = normal_group_ForecastWeather.createWidget(hmUI.widget.IMG_LEVEL_Options, {
              // x: 89,
              // y: 173,
              // image_array: ["P0056.png","P0057.png","P0058.png","P0059.png","P0060.png","P0061.png","P0062.png","P0063.png","P0064.png","P0065.png","P0066.png","P0067.png","P0068.png","P0069.png","P0070.png","P0071.png","P0072.png","P0073.png","P0074.png","P0075.png","P0076.png","P0077.png","P0078.png","P0079.png","P0080.png","P0081.png","P0082.png","P0083.png","P0084.png"],
              // image_length: 29,
              // type: hmUI.data_type.forecast_image,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            //#region screenType
            if (screenType == hmSetting.screen_type.WATCHFACE) {
              for (let i = 0; i < 3; i++) {
                normal_forecast_image_progress_img_level[i] = normal_group_ForecastWeather.createWidget(hmUI.widget.IMG, {
                  x: 89 + i*72,
                  y: 173,
                  src: normal_forecast_image_array[25],
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });
              };
            };
            //#endregion

            timeSensor.addEventListener(timeSensor.event.DAYCHANGE, function() {
              time_update(true);
            });

            normal_dow_text_font = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 159,
              y: 14,
              w: 150,
              h: 30,
              text_size: 25,
              char_space: 0,
              font: 'fonts/Eurosti.ttf',
              color: 0xFFFFFFFF,
              line_space: 0,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.CENTER_H,
              // unit_string: LUNES, MARTES, MIERCOLES, JUEVES, VIERNES, SABADO, DOMINGO,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 307,
              y: 132,
              image_array: ["w56.png","w57.png","w58.png","w59.png","w60.png","w61.png","w62.png","w63.png","w64.png","w65.png","w66.png","w67.png","w68.png","w69.png","w70.png","w71.png","w72.png","w73.png","w74.png","w75.png","w76.png","w77.png","w78.png","w79.png","w80.png","w81.png","w82.png","w83.png","w84.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 336,
              y: 235,
              font_array: ["9.png","10.png","11.png","12.png","13.png","14.png","15.png","16.png","17.png","18.png"],
              padding: false,
              h_space: 0,
              negative_image: '25.png',
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 118,
              day_startY: 47,
              day_sc_array: ["9.png","10.png","11.png","12.png","13.png","14.png","15.png","16.png","17.png","18.png"],
              day_tc_array: ["9.png","10.png","11.png","12.png","13.png","14.png","15.png","16.png","17.png","18.png"],
              day_en_array: ["9.png","10.png","11.png","12.png","13.png","14.png","15.png","16.png","17.png","18.png"],
              day_zero: 1,
              day_space: 0,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_month = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 186,
              month_startY: 47,
              month_sc_array: ["9.png","10.png","11.png","12.png","13.png","14.png","15.png","16.png","17.png","18.png"],
              month_tc_array: ["9.png","10.png","11.png","12.png","13.png","14.png","15.png","16.png","17.png","18.png"],
              month_en_array: ["9.png","10.png","11.png","12.png","13.png","14.png","15.png","16.png","17.png","18.png"],
              month_zero: 1,
              month_space: 0,
              month_align: hmUI.align.CENTER_H,
              month_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_year = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              year_startX: 255,
              year_startY: 47,
              year_sc_array: ["9.png","10.png","11.png","12.png","13.png","14.png","15.png","16.png","17.png","18.png"],
              year_tc_array: ["9.png","10.png","11.png","12.png","13.png","14.png","15.png","16.png","17.png","18.png"],
              year_en_array: ["9.png","10.png","11.png","12.png","13.png","14.png","15.png","16.png","17.png","18.png"],
              year_zero: 1,
              year_space: 0,
              year_align: hmUI.align.CENTER_H,
              year_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 336,
              y: 290,
              font_array: ["9.png","10.png","11.png","12.png","13.png","14.png","15.png","16.png","17.png","18.png"],
              padding: true,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 209,
              y: 350,
              font_array: ["9.png","10.png","11.png","12.png","13.png","14.png","15.png","16.png","17.png","18.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_calorie_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 342,
              y: 350,
              font_array: ["9.png","10.png","11.png","12.png","13.png","14.png","15.png","16.png","17.png","18.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 116,
              y: 290,
              font_array: ["9.png","10.png","11.png","12.png","13.png","14.png","15.png","16.png","17.png","18.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_frame_animation_1 = hmUI.createWidget(hmUI.widget.IMG_ANIM, {
              x: 19,
              y: 225,
              anim_path: "animation",
              anim_ext: "png",
              anim_prefix: "animation",
              anim_fps: 12,
              anim_size: 6,
              repeat_count: 0,
              anim_repeat: true,
              anim_status:hmUI.anim_status.START,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 76,
              hour_startY: 81,
              hour_array: ["52.png","53.png","54.png","55.png","56.png","57.png","58.png","59.png","60.png","61.png"],
              hour_zero: 1,
              hour_space: 0,
              hour_angle: 0,
              hour_unit_sc: '62.png',
              hour_unit_tc: '62.png',
              hour_unit_en: '62.png',
              hour_align: hmUI.align.CENTER_H,

              minute_startX: 0,
              minute_startY: 0,
              minute_array: ["52.png","53.png","54.png","55.png","56.png","57.png","58.png","59.png","60.png","61.png"],
              minute_zero: 1,
              minute_space: 0,
              minute_angle: 0,
              minute_follow: 1,
              minute_align: hmUI.align.CENTER_H,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_second = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              second_path: 'seg.png',
              second_centerX: 233,
              second_centerY: 233,
              second_posX: 233,
              second_posY: 233,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            console.log('Watch_Face.ScreenAOD');

            idle_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 216,
              y: 396,
              src: '110.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 217,
              y: 173,
              src: '111.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_dow_text_font = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 159,
              y: 14,
              w: 150,
              h: 30,
              text_size: 25,
              char_space: 0,
              font: 'fonts/Eurosti.ttf',
              color: 0xFF808080,
              line_space: 0,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.CENTER_H,
              // unit_string: LUNES, MARTES, MIERCOLES, JUEVES, VIERNES, SABADO, DOMINGO,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_day_text_font = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 159,
              y: 46,
              w: 150,
              h: 30,
              text_size: 27,
              char_space: 0,
              font: 'fonts/Eurosti.ttf',
              color: 0xFF808080,
              line_space: 0,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.CENTER_H,
              // padding: true,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_battery_current_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 163,
              y: 430,
              w: 150,
              h: 37,
              text_size: 34,
              char_space: 0,
              font: 'fonts/Eurosti.ttf',
              color: 0xFF808080,
              line_space: 0,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.CENTER_H,
              unit_type: 1,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 76,
              hour_startY: 81,
              hour_array: ["63.png","64.png","65.png","66.png","67.png","68.png","69.png","70.png","71.png","72.png"],
              hour_zero: 1,
              hour_space: 0,
              hour_angle: 0,
              hour_unit_sc: '73.png',
              hour_unit_tc: '73.png',
              hour_unit_en: '73.png',
              hour_align: hmUI.align.CENTER_H,

              minute_startX: 0,
              minute_startY: 0,
              minute_array: ["63.png","64.png","65.png","66.png","67.png","68.png","69.png","70.png","71.png","72.png"],
              minute_zero: 1,
              minute_space: 0,
              minute_angle: 0,
              minute_follow: 1,
              minute_align: hmUI.align.CENTER_H,

              show_level: hmUI.show_level.ONLY_AOD,
            });
            console.log('Watch_Face.Shortcuts');

            normal_step_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 17,
              y: 278,
              w: 230,
              h: 50,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 123,
              y: 343,
              w: 167,
              h: 50,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 283,
              y: 280,
              w: 143,
              h: 50,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 123,
              y: 167,
              w: 300,
              h: 100,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_alarm_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 32,
              y: 162,
              w: 60,
              h: 60,
              type: hmUI.data_type.ALARM_CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_fatBurning_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 304,
              y: 340,
              w: 115,
              h: 50,
              type: hmUI.data_type.FAT_BURNING,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            console.log('Watch_Face.Buttons');
            Button_1 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 113,
              y: 404,
              w: 60,
              h: 50,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'transparent.png',
              normal_src: 'transparent.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'PhoneHomeScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_2 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 201,
              y: 404,
              w: 60,
              h: 50,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'transparent.png',
              normal_src: 'transparent.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'AppListScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_3 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 286,
              y: 404,
              w: 60,
              h: 50,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'transparent.png',
              normal_src: 'transparent.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'PhoneMusicCtrlScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_4 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 117,
              y: 15,
              w: 250,
              h: 56,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'transparent.png',
              normal_src: 'transparent.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'ScheduleCalScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_5 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 69,
              y: 82,
              w: 323,
              h: 73,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'transparent.png',
              normal_src: 'transparent.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'WorldClockScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            const weatherSensor = hmSensor.createSensor(hmSensor.id.WEATHER);
            //#region weather_few_days
            function weather_few_days() {
              console.log('weather_few_days()');
              let weatherData = weatherSensor.getForecastWeather();
              let forecastData = weatherData.forecastData;

              for (let i = 0; i < 3; i++) {
                // DayOfWeek font
                if (screenType == hmSetting.screen_type.WATCHFACE) {
                  let dowIndex = timeSensor.week - 1;
                  dowIndex += i;
                  while (dowIndex >= 7) {dowIndex -= 7;}
                  normal_forecast_date_week_font[i].setProperty(hmUI.prop.TEXT, normal_forecast_date_week_font_Array[dowIndex]);
                };
              
                // Number_Font_Min
                let minTemperature = '-';
                if (i < forecastData.count) minTemperature = forecastData.data[i].low.toString();
                if (screenType == hmSetting.screen_type.WATCHFACE) {
                  normal_forecast_low_text_font[i].setProperty(hmUI.prop.TEXT, minTemperature + '°');
                };
                
                // Number_Font_Max
                let maxTemperature = '-';
                if (i < forecastData.count) maxTemperature = forecastData.data[i].high.toString();
                if (screenType == hmSetting.screen_type.WATCHFACE) {
                  normal_forecast_high_text_font[i].setProperty(hmUI.prop.TEXT, maxTemperature + '°');
                };
                
                // Images
                if (screenType == hmSetting.screen_type.WATCHFACE) {
                  let weatherIndex = 25
                  if (i < forecastData.count) weatherIndex = forecastData.data[i].index;
                  normal_forecast_image_progress_img_level[i].setProperty(hmUI.prop.SRC, normal_forecast_image_array[weatherIndex]);
                };
              
              };  // end for

            };
            //#endregion

            //#region time_update
            function time_update(updateHour = false, updateMinute = false) {
              console.log('time_update()');
              let hour = timeSensor.hour;
              let minute = timeSensor.minute;
              let second = timeSensor.second;
              let format_hour = timeSensor.format_hour;

              console.log('day of week font');
              if (updateHour) {
                let normal_DOW_Str = normal_DOW_Array[timeSensor.week-1];
                normal_dow_text_font.setProperty(hmUI.prop.TEXT, normal_DOW_Str );
              };

              console.log('day of week font');
              if (updateHour) {
                let idle_DOW_Str = idle_DOW_Array[timeSensor.week-1];
                idle_dow_text_font.setProperty(hmUI.prop.TEXT, idle_DOW_Str );
              };

              console.log('day font');
              if (updateHour) {
                let idle_dayStr = timeSensor.day.toString();
                idle_dayStr = idle_dayStr.padStart(2, '0');
                idle_day_text_font.setProperty(hmUI.prop.TEXT, idle_dayStr );
              };

            };

            //#endregion
            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                console.log('resume_call()');
                time_update(true, true);
                normal_frame_animation_1.setProperty(hmUI.prop.ANIM_STATUS,hmUI.anim_status.START);

                weather_few_days();
              }),
              pause_call: (function () {
                console.log('pause_call()');
                normal_frame_animation_1.setProperty(hmUI.prop.ANIM_STATUS,hmUI.anim_status.STOP);

              }),
            });

                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}