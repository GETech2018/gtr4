﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        //const logger = Logger.getLogger('watchface_SashaCX75');
        const logger = DeviceRuntimeCore.HmLogger.getLogger('watchface_SashaCX75')
        //end of ignored block

        //dynamic modify start

        
        console.log('user_functions.js');
        // start user_functions.js

const {
       width: D_W,
       height: D_H
      } = hmSetting.getDeviceInfo();	

 let screenTypeJS = hmSetting.getScreenType();
      
/********  класс Провайдер погоды  ********/
/******				v1.4			*******/
/******		2025 © leXxiR [4pda]	*******/

	class WeatherProvider {
	  constructor(props = {}) {
		this.props = {
			night_icons: [],											// индексы иконок для замены день-ночь
			index: hmFS.SysProGetInt('WeatherProviderIndex') ?? 0,		// текущий индекс провайдера (сохраняется и считывается из памяти)
			show_toast: true,											// показывать всплывающее сообщение при переключении провайдера
			temp_widget: null,											// виджет TEXT для отображения температуры
			temp_max_widget: null,										// виджет TEXT для отображения максимальной температуры
			temp_min_widget: null,										// виджет TEXT для отображения минимальной температуры
			temp_feels_widget: null,									// виджет TEXT для отображения ощущаемой температуры
chance_Of_Rain: null,									// виджет TEXT для отображения осадков            
			description_widget: null,									// виджет TEXT для отображения текстового описания текущей погоды
			cityName_widget: null,										// виджет TEXT для отображения названия города
			windDirection_widget: null,										// виджет TEXT для отображения направления ветра
			windSpeed_widget: null,										// виджет TEXT для отображения скорости ветра
			icon_widget: null,											// виджет IMG для отображения значка погоды
			icon_widget_Rain: null,										// виджет IMG для отображения значка осадков (зонтик)		
			time_sensor: null,											// сенсор времени, если не задан, то создается новый
			weather_sensor: null,										// сенсор погоды, если не задан, то создается новый
			file_name: 'weather.json',									// имя файла с погодными данными
			auto_update: true,											// автоматическое обновление погоды (нет необходимости добавлять weatherProvider.update() в event.MINUTEEND и WIDGET_DELEGATE)
			lang: hmSetting.getLanguage() == 4 ? 0 : 1,					// языка устройства	(Русский = 0 / Английский = 1)
			...props,
		};

		this.providers = [
						{name: ['Zepp', 'Zepp'], appId: null},							// 0
						{name: ['Погодный сервис', 'Weather service'], appId: 1065824},	// 1
						{name: ['RuWeather', 'RWeather'], appId: 1066654},				// 2
					]

		this.description = [
				['Облачно', 'Временами дождь', 'Временами снег', 'Ясно', 'Пасмурно', 'Слабый дождь', 'Слабый снег', 'Умеренный дождь', 'Умеренный снег', 'Сильный снегопад', 'Сильный дождь', 'Песчаная буря', 'Мокрый снег', 'Туман', 'Дымка', 'Дождь с грозой', 'Метель', 'Пыльно', 'Ливень', 'Дождь с градом', 'Сильный дождь с градом', 'Сильный дождь', 'Пыльная буря', 'Сильная песчаная буря', 'Сильный дождь', 'Обновите погоду', 'Облачно ночью', 'Дождливо ночью', 'Ясно ночью'],
				['Cloudy', 'Showers', 'Snow Showers', 'Sunny', 'Overcast', 'Light Rain', 'Light Snow', 'Moderate Rain', 'Moderate Snow', 'Heavy Snow', 'Heavy Rain', 'Sandstorm', 'Rain and Snow', 'Fog', 'Hazy', 'T-Storms', 'Snowstorm', 'Floating dust', 'Very Heavy Rainstorm', 'Rain and Hail', 'T-Storms and Hail', 'Heavy Rainstorm', 'Dust', 'Heavy sand storm', 'Rainstorm', 'Unknown', 'Cloudy Nighttime', 'Showers Nighttime', 'Sunny Nighttime'],
			]
			
this.windDirectionStr = [
       ['Северный', 'N'], // 0
       ['Сев-Вос', 'NE'], // 1
       ['Восточный', 'E'], // 2
       ['Юго-Вос', 'SE'], // 3
       ['Южный', 'S'], // 4
       ['Юго-Зап', 'SW'], // 5
       ['Западный', 'W'], // 6
       ['Сев-Зап', 'NW'], // 7
      ];                 			
			

		this.last = {
			weatherIcon: 25,
			weatherDescription:  'Нет данных',
			temperature: '--',
			temperatureFeels: '--',
			chanceOfRain: '--',
			temperatureMax: '--',
			temperatureMin: '--',
			cityName: '--',
            windDirection: 0,
        windSpeed: '--',
            modTime: null,
		}

		if (!this.props.time_sensor) this.props.time_sensor = hmSensor.createSensor(hmSensor.id.TIME);
		if (!this.props.weather_sensor) this.props.weather_sensor = hmSensor.createSensor(hmSensor.id.WEATHER);
		if (isFinite(props.index)) hmFS.SysProSetInt('WeatherProviderIndex', props.index);
		if (this.props.auto_update) this.createHandlers();
	  }

	// создание обработчиков автоматического обновления погоды
		createHandlers() {
			this.props.time_sensor.addEventListener(this.props.time_sensor.event.MINUTEEND, () => this.update());

			this.widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
			  resume_call: ( () => this.update() )
			})
		}

	// служебные функции
		arrayBufferToCyrillic(buffer) {
		  let result = '';
		  const bytes = new Uint8Array(buffer);

		  let i = 0;
		  while (i < bytes.length) {
			let byte1 = bytes[i++];
			
			if (byte1 < 0x80) {								// Обработка 1-байтовых символов (ASCII)
			  result += String.fromCharCode(byte1);
			} else if (byte1 >= 0xC0 && byte1 < 0xE0) {		// Обработка 2-байтовых символов (UTF-8 кодировка для кириллицы)
			  let byte2 = bytes[i++];
			  let charCode = ((byte1 & 0x1F) << 6) | (byte2 & 0x3F);
			  result += String.fromCharCode(charCode);
			} else if (byte1 >= 0xE0 && byte1 < 0xF0) {		// Обработка 3-байтовых символов (например, для UTF-8)
			  let byte2 = bytes[i++];
			  let byte3 = bytes[i++];
			  let charCode = ((byte1 & 0x0F) << 12) | ((byte2 & 0x3F) << 6) | (byte3 & 0x3F);
			  result += String.fromCharCode(charCode);
			}
		  }

		  return result
		}

	// чтение погодных данных из файла
		readFile(app_id) {
		  if (!app_id) return null				
		  let str_result = "";
		  try {
			const [fs_stat, err] = hmFS.stat(this.props.file_name, {
			  appid: app_id,
			});
			if (err == 0) {
			  const fh = hmFS.open(this.props.file_name, hmFS.O_RDONLY, {
				appid: app_id,
			  });

			  const len = fs_stat.size;
			  let array_buffer = new ArrayBuffer(len);
			  hmFS.read(fh, array_buffer, 0, len);
			  hmFS.close(fh);
			  str_result = this.arrayBufferToCyrillic(array_buffer);

			  return str_result;
			} else {
			  console.log("err:", err);
			}
		  } catch (error) {
			console.log("error:", error);
			console.log("FAIL: No access to hmFS.");
		  }
		  return null;
		}

	// получить время последнего изменеия файла
		getFileModTime(app_id) {
		  if (!app_id) return null
		  try {
			const [fs_stat, err] = hmFS.stat(this.props.file_name, {
			  appid: app_id,
			});
			
			if (err == 0) {
			  return fs_stat.mtime
			} else {
			  console.log("ModTime err:", err);
			}
		  } catch (error) {
			console.log("ModTime error:", error);
			console.log("FAIL: No access to hmFS.");
		  }
			return null
		}

	// проверка времени суток: возвращает true, если сейчас день
		isDayNow() {
			const sunData = this.props.weather_sensor.getForecastWeather().tideData;
			let sunriseMins = 8 * 60;			// время восхода
			let sunsetMins = 20 * 60;			// и заката по умолчанию

			if (sunData.count > 0){
				const today = sunData.data[0];
				sunriseMins = today.sunrise.hour * 60 + today.sunrise.minute;
				sunsetMins = today.sunset.hour * 60 + today.sunset.minute;
			}

			const curMins = curTime.hour * 60 + curTime.minute;
			const nowIsDay = (curMins >= sunriseMins) && (curMins < sunsetMins);

			return nowIsDay
		}


	// сопоставление индекса иконки погоды из приложений WeatherService и RuWeather с иконками погоды от Zepp 
		getZeppIconIndex(index, app_id = null) {
			
			if (!app_id)  return index;			//	если нет app_id, то не меняем индекс иконки

			let newIndex = 25;
			
			if (app_id == 1065824) {					// WeatherService
				switch(index) {
				   case 1:
						newIndex = 3;
					break;
				   case 2:
						newIndex = 0;
					break;
				   case 3:
				   case 4:
						newIndex = 4;
					break;
				   case 5:
						newIndex = 1;
					break;
				   case 6:
						newIndex = 5;
					break;
				   case 7:
						newIndex = 10;
					break;
				   case 8:
						newIndex = 15;
					break;
				   case 9:
						newIndex = 6;
					break;
				   case 10:
						newIndex = 8;
					break;
				   case 11:
						newIndex = 9;
					break;
				   case 12:
						newIndex = 12;
					break;
				   case 13:
						newIndex = 13;
					break;
				   case 14:
						newIndex = 17;
					break;
				   default:
						newIndex = 25;
					break;
				}
			} else if (app_id == 1066654) {					// RuWeather
				newIndex = index - 1;
			}

			return newIndex
		}

	// температура со знаком
		tempWithSign(val){
			val = parseFloat(val);
			if (!isFinite(val)) return '--'		// если на входе не число - возвращаем прочерки
			val = Math.round(val);
			if (val > 0) val = '+' + val;
			val += '°';
			
			return val
		}
        
		tempWithSign0(val){
			val = parseFloat(val);
			if (!isFinite(val)) return '--'		// если на входе не число - возвращаем прочерки
			val = Math.round(val);
			if (val > 0) val = '' + val;
			val += '';
			
			return val
		}
        
		rainWithSign(val){
			//val = parseFloat(val);
			if (!isFinite(val)) return '--'		// если на входе не число - возвращаем прочерки
			//val = Math.round(val);
			//if (val > 0) val = '' + val;
			val += '%';
			
			return val
		}
		
		
		
	windWithSign(val){
			val = parseFloat(val);
			if (!isFinite(val)) return '--'		// если на входе не число - возвращаем прочерки
			//val = Math.round(val);
			// val = 'Южный ' + val;
			val += ' м/с';
			
			return val
		}	
		
		
		


windDirectSign(val2) {
    // Приводим к числу, берём остаток от 360 и вычисляем индекс
    const normalizedAngle = parseFloat(val2) % 360; // Угол в диапазоне [0, 360)
    const index = Math.floor((normalizedAngle + 22.5) / 45) % 8;
    return index;
}

		

	//получение погодных данных из Zepp
		getZeppWeatherData() {
			const iconIndex = this.props.weather_sensor.curAirIconIndex ?? 25;
			const data = {
				weatherIcon: iconIndex,
				weatherDescription:  this.description[this.props.lang][iconIndex],
				temperature: this.props.weather_sensor.current ?? '--',
				temperatureFeels: '--',
				chanceOfRain: '--',
                windDirection: 0,
                windSpeed: '--',
				temperatureMax: this.props.weather_sensor.high ?? '--',
				temperatureMin: this.props.weather_sensor.low ?? '--',
				cityName: this.props.weather_sensor.getForecastWeather().cityName ?? '--',
			}

			return data
		}

	//получение погодных данных из файла приложения
		getAppWeatherData(app_id) {
			const data = {
				weatherIcon: 25,
				weatherDescription:  'Нет данных',
				temperature: '--',
				temperatureFeels: '--',
				chanceOfRain: '--',
                windDirection: 0,
                windSpeed: '--',
				temperatureMax: '--',
				temperatureMin: '--',
				cityName: '--',
			}

			// читаем данные из файла данных приложения
			let weather_str = this.readFile(app_id);
			let weatherJson = JSON.parse(weather_str);
	  
			if (weatherJson) {
				if (isFinite(weatherJson.weatherIcon)) {		// считываем индекс иконки погоды и сразу переводим в нумерацию Zepp
				  data.weatherIcon = this.getZeppIconIndex(parseInt(weatherJson.weatherIcon), app_id);
				}

				if (weatherJson?.weatherDescriptionExtended?.length) {
				  data.weatherDescription = weatherJson.weatherDescriptionExtended;
				  data.weatherDescription = data.weatherDescription.replace(data.weatherDescription[0], data.weatherDescription[0].toUpperCase());
				} else data.weatherDescription = this.description[data.weatherIcon];

				if (isFinite(weatherJson.temperature)) {
				  data.temperature = parseFloat(weatherJson.temperature);
				  data.temperature = Math.round(data.temperature);
				}
				
				if (isFinite(weatherJson.temperatureFeels)){
					data.temperatureFeels = parseFloat(weatherJson.temperatureFeels);
					data.temperatureFeels = Math.round(data.temperatureFeels);
				}
					
				if (isFinite(weatherJson.chanceOfRain)){
					data.chanceOfRain = parseFloat(weatherJson.chanceOfRain);
					data.chanceOfRain = Math.round(data.chanceOfRain);
				}
					
				  
				if (isFinite(weatherJson.temperatureMax)){
					data.temperatureMax = parseFloat(weatherJson.temperatureMax);
					data.temperatureMax = Math.round(data.temperatureMax);
				}
				  
				if (isFinite(weatherJson.temperatureMin)){
					data.temperatureMin = parseFloat(weatherJson.temperatureMin);
					data.temperatureMin = Math.round(data.temperatureMin);
				}
                
				if (isFinite(weatherJson.windDirection)){
					data.windDirection = parseFloat(weatherJson.windDirection);
					//data.windDirection = Math.round(data.windDirection);
				}
                
        if (isFinite(weatherJson.windSpeed)) {
         data.windSpeed = parseFloat(weatherJson.windSpeed);
         data.windSpeed > 10 ? data.windSpeed = Math.round(data.windSpeed) : data.windSpeed = data.windSpeed.toFixed(1);
        }
                
                
				
				if (weatherJson.city) {
				  data.cityName = weatherJson.city;
				}
			}
			
			return data
		}

	//получение погодных данных из файла приложения или Zepp
		getWeatherData(app_id = null) {
			if (!app_id) return this.getZeppWeatherData()		// если нет app_id, то получаем данные от Zepp
			else return this.getAppWeatherData(app_id);			// иначе читаем данные из файла данных приложения
		}

	// обновить виджеты, используя данные текущего провайдера
		update() {
			let curIcon = parseInt(this.last.weatherIcon);				// текущий индекс значка погоды без учета времени суток (т.е. число без "n")

			const modTime = this.getFileModTime(this.providers[this.props.index].appId);		// время изменеия файла с данными
			
			if (!modTime || this.last.modTime != modTime){										// если не получено время изменеия или оно отличается от последнего времени изменеия
				const newData = this.getWeatherData(this.providers[this.props.index].appId);	// тогда читаем новые данные из файла
				this.last.modTime = modTime;

				let val = this.tempWithSign0(newData.temperature);
				if (val != this.last.temperature){
					this.last.temperature = val;
					if (this.props.temp_widget) this.props.temp_widget.setProperty(hmUI.prop.TEXT, val);
				}

				val = this.tempWithSign0(newData.temperatureMax);
				if (val != this.last.temperatureMax){
					this.last.temperatureMax = val;
					if (this.props.temp_max_widget) this.props.temp_max_widget.setProperty(hmUI.prop.TEXT, val);
				}

				val = this.tempWithSign0(newData.temperatureMin);
				if (val != this.last.temperatureMin){
					this.last.temperatureMin = val;
					if (this.props.temp_min_widget) this.props.temp_min_widget.setProperty(hmUI.prop.TEXT, val);
				}

				val = this.tempWithSign(newData.temperatureFeels);
				if (val != this.last.temperatureFeels){
					this.last.temperatureFeels = val;
					if (this.props.temp_feels_widget) this.props.temp_feels_widget.setProperty(hmUI.prop.TEXT, val);
				}
					
				val = this.rainWithSign(newData.chanceOfRain);
				if (val != this.last.chanceOfRain) {
				 this.last.chanceOfRain = val;
				 if (this.props.chance_Of_Rain) this.props.chance_Of_Rain.setProperty(hmUI.prop.TEXT, val);
				 if (this.props.icon_widget_Rain) this.props.icon_widget_Rain.setProperty(hmUI.prop.SRC, val.replace('%', '') >= 50 ? 'images/Grafik/ic_activ/ic_rain_on.png' : 'images/Grafik/ic_activ/ic_rain_off.png');
				}

				val = newData.windDirection;
				if (val != this.last.windDirection) {
				 this.last.windDirection = val;
				 if (this.props.windDirection_widget) this.props.windDirection_widget.setProperty(hmUI.prop.TEXT, val);
				}

				val = this.windWithSign(newData.windSpeed);
				if (val != this.last.windSpeed) {
				 this.last.windSpeed = val;

				 if (this.props.windSpeed_widget) this.props.windSpeed_widget.setProperty(hmUI.prop.TEXT, this.windDirectionStr[this.windDirectSign(newData.windDirection)][0] + ' ' + val);
				}

				val = newData.cityName;
				if (val != this.last.cityName){
					this.last.cityName = val;
					if (this.props.cityName_widget) this.props.cityName_widget.setProperty(hmUI.prop.TEXT, val);
				}

				val = newData.weatherDescription;
				if (val != this.last.weatherDescription){
					this.last.weatherDescription = val;
					if (this.props.description_widget) this.props.description_widget.setProperty(hmUI.prop.TEXT, val);
				}

				
				curIcon = newData.weatherIcon;						// получаем текущий индекс значка погоды
			}

			if (this.props.night_icons.includes(curIcon) && !this.isDayNow()){		// если он в списке ночных иконок и сейчас "ночь", то добавляем суффикс 'n'
				curIcon += 'n';
			}

			if (curIcon != this.last.weatherIcon){
				this.last.weatherIcon = curIcon;
				if (this.props.icon_widget) this.props.icon_widget.setProperty(hmUI.prop.SRC, 'w_${curIcon}.png');
			}
			
		}

	// переключить на следующего провайдера
		next(show_toast = this.props.show_toast) {
			const v = (this.props.index + 1) % this.providers.length;
			this.provider = v;
			if (show_toast) hmUI.showToast({text: this.name});
		}

	// переключить на предыдующего провайдера
		prev(show_toast = this.props.show_toast) {
			const v = (this.props.index - 1 + this.providers.length) % this.providers.length;
			this.provider = v;
			if (show_toast) hmUI.showToast({text: this.name});
		}

	// переключить назад или вперед
		toggle(dir, show_toast = this.props.show_toast) {
			if (dir > 0) this.next(show_toast)
			else this.prev(show_toast);
		}
		
	// установить провайдера по индексу
		set provider(v) {
			this.props.index = v;
			hmFS.SysProSetInt('WeatherProviderIndex', v);
			this.update();
		}

	// получить индекс текущего провайдера
		get index() {
			return this.props.index
		}

	// получить название текущего провайдера
		get name() {
			return this.providers[this.props.index].name[this.props.lang]
		}
        
	// получить название города
		get cityName() {
			return this.last.cityName
		}

	// получить напрвление ветра
		get windDirection() {
			return this.last.windDirection
		}
        
	// получить скорость ветра
		get windSpeed() {
			return this.last.windSpeed
		}

	// получить текущую температуру
		get temperature() {
			return this.last.temperature
		}

	// получить максимальную температуру
		get temperatureMax() {
			return this.last.temperatureMax
		}

	// получить минимальную температуру
		get temperatureMin() {
			return this.last.temperatureMin
		}

	// получить ощущаемую температуру
		get temperatureFeels() {
			return this.last.temperatureFeels
		}
			
		get chanceOfRain() {
			return this.last.chanceOfRain
		}
			

	// получить описание погоды
		get weatherDescription() {
			return this.last.weatherDescription
		}

	// удалить
	  delete() {
		this.providers = null;
		this.props = null;
		this.last = null;
		this.description = null;
		if (this.widgetDelegate) {
			hmUI.deleteWidget(this.widgetDelegate);
			this.widgetDelegate = null;
		}
	  }

	}		
		
      
      let groupVremya = ''
      let groupPogoda = ''
      //let groupTap = ''
      let groupActiv = ''
      //let canvas0 = ''
      //let canvas = ''

      let groupSleep = ''
      let alpha_grey = 76
	  
	  
	  

      const weatherSensor = hmSensor.createSensor(hmSensor.id.WEATHER);

      const battery = hmSensor.createSensor(hmSensor.id.BATTERY)
      const step = hmSensor.createSensor(hmSensor.id.STEP);
      const heart_rate = hmSensor.createSensor(hmSensor.id.HEART); //heart_rate.last
      const distance = hmSensor.createSensor(hmSensor.id.DISTANCE);
      const calorie = hmSensor.createSensor(hmSensor.id.CALORIE);
      const stand = hmSensor.createSensor(hmSensor.id.STAND)
      const pai = hmSensor.createSensor(hmSensor.id.PAI);
      const fatburn = hmSensor.createSensor(hmSensor.id.FAT_BURRING);
      const spo2 = hmSensor.createSensor(hmSensor.id.SPO2);
      const stress = hmSensor.createSensor(hmSensor.id.STRESS);


     let normal_background_bg = ''


      let sleep_time_txt = ''
      let sleep_start_time_txt = ''
      let sleep_end_time_txt = ''
      let sleep_score_txt = ''
      let wake_time_txt

      const sleep = hmSensor.createSensor(hmSensor.id.SLEEP);
      let sleepInfo = sleep.getBasicInfo();

      let sleepTotalTime = sleep.getTotalTime();
      let sleepStartTime = sleepInfo.startTime;
      let sleepEndTime = sleepInfo.endTime + 1;
      let sleepScore = sleepInfo.score;

      //-----------  время пробуждений ------------------		
      let sleepStageArray = sleep.getSleepStageData();
      const modelData = sleep.getSleepStageModel();
      //-------------------------------------------------		

      //sleep_time_txt.setProperty(hmUI.prop.TEXT, 'Время сна: ' + Math.floor(sleepTotalTime / 60).toString().padStart(2, "0") + ':' + (sleepTotalTime % 60).toString().padStart(2, "0"));


      function click_sleep() {
       // groupVremya.setProperty(hmUI.prop.VISIBLE, false);
       groupSleep.setProperty(hmUI.prop.VISIBLE, true);
      }


      function click_exit_sleep() {
       // groupVremya.setProperty(hmUI.prop.VISIBLE, true);
       groupSleep.setProperty(hmUI.prop.VISIBLE, false);
      }


      function read_pressure() {
       console.log("read_pressure()");
       const file_name_alt = "../../../baro_altim/pressure.dat";
       const [fs_stat, err] = hmFS.stat(file_name_alt);
       if (err == 0) {
        let file_size = fs_stat.size;
        const len = file_size / 4;
        console.log(`size_alt: ${file_size}, lenght: ${len}`)
        const fh = hmFS.open(file_name_alt, hmFS.O_RDONLY)

        let array_buffer = new Float32Array(len);
        hmFS.read(fh, array_buffer.buffer, 0, file_size);
        hmFS.close(fh);
        console.log(`value ${array_buffer[array_buffer.length -1]}`);
        return array_buffer;
       } else {
        console.log('err:', err)
       }
       return null;
      }

      function getPressureValue(pressure_array) {
       console.log("getPressureValue()");
       if (pressure_array == null || pressure_array == undefined || pressure_array.length == 0) return 0;
       let start_index = pressure_array.length - 1;
       let end_index = start_index - 30 * 3; // 3 часа
       if (end_index < 0) end_index = 0;
       for (let index = start_index; index >= end_index; index--) {
        if (pressure_array[index] != 0) return parseInt(pressure_array[index] / 100);
       }
       return 0;
      }

      function changesPressure(pressure_array) {
       console.log("changesPressure()");
       if (pressure_array == null || pressure_array == undefined || pressure_array.length == 0) return 0;
       let start_index = pressure_array.length - 1;
       let end_index = start_index - 30 * 3; // 3 часа
       let value = pressure_array[start_index];
       let result = 0;
       if (end_index < 0) end_index = 0;
       for (let index = start_index; index >= end_index; index--) {
        let element = pressure_array[index];
        if (element != 0) {
         if (Math.abs(value - element) > 10) { // учитываем только если разниза больше 0,1 hPa
          value = value - element;
          console.log(`element = ${element}`);
          console.log(`pressere_changes = ${value}`);
          return value;
         }
        }
       }
       return result;
      }

      function hPa_To_mmHg(hPa_value = 0) {
       let mmHg = Math.round(hPa_value * 0.750064);
       return mmHg;
      }
      //#endregion

      let text_pressere; // отображаем давление
      let text_pressere_changes; // отображаем изменение давления 


      function makeAOD() {
//loadSettings()
		  
       const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
        resume_call: (function () {
			
         stopVibro();
        }),
		   
        pause_call: (function () {
			
     //    hmApp.unregisterSpinEvent();
         stopVibro();
        }),
       });


      }


      let Activ_color_alpha = ''
      let menu = 0
      let color_ic = 0
      let Activ_color = 0

      function click_Activ_color() {
       Activ_color = (Activ_color + 1) % 2
       ic_activ_color_off_img.setProperty(hmUI.prop.VISIBLE, Activ_color == 0);
       hmFS.SysProSetInt('GRMN_FRNR_GS_color', Activ_color);
      }

      let Btn_set_ = []
      let Shag_Y = 66

      let color_bg = [
[0xFF0000, 0xFF4500, 0xDC143C, 0xFF69B4, 0xFF1493, 0xFF8C00, 0xFFA500, 0xFFD700, 0xFFFF00, 0x228B22, 0x32CD32, 0x00FF00, 0x98FF98, 0x50C878, 0x00FFFF, 0x00CED1, 0x40E0D0, 0x7FFFD4, 0x0000FF, 0x1E90FF, 0x007FFF, 0x00008B, 0x4B0082, 0x800080, 0x9932CC, 0x8A2BE2, 0xDA70D6, 0xA52A2A, 0xD2691E, 0x8B4513, 0x926226, 0xFFFFFF, 0xD3D3D3, 0x808080, 0x505050, 0x000000],
       // [0xff0000, 0xFCB61C, 0x068FF9, 0xFFB900, 0xffffff, 0xf8e36c, 0xb84cf6, 0xa3fd1f, 0xfd912f, 0x8cffff, 0xff00a2, 0x8a8a8a],
       [0xff0000, 0xff0000, 0xFCB61C, 0x068FF9, 0xFFB900, 0xffffff, 0xf8e36c, 0xb84cf6, 0xa3fd1f, 0xfd912f, 0x8cffff, 0xff00a2, 0x8a8a8a],
      ];

      let colorNames = ["Красный", "Алый", "Малиновый", "Тёмно-красный", "Бордовый", "Розовый", "Оранжевый", "Горчичный", "Золотой", "Жёлтый", "Лимонный", "Мятный", "Изумрудный", "Лесной зелёный", "Оливковый", "Зелёный", "Бирюзовый", "Голубой", "Лазурный", "Синий", "Тёмно-синий", "Индиго", "Пурпурный", "Пурпурный (маджента)", "Белый", "Медовый", "Бежевый", "Светло-серый", "Серый", "Тёмно-серый", "Коричневый", "Чёрный"];

      let app_TF = []
      let app_ic = []
      let app_ACR_text = []

      let app_text_arr = [
       ['КАЛОРИИ', hmUI.data_type.CAL, false, 0, 'ic_app_0.png'],
       ['КМ', hmUI.data_type.DISTANCE, false, 0, 'ic_app_1.png'],
       ['ММ.РТ.СТ', hmUI.data_type.ALTIMETER, false, 0, 'ic_app_2.png'],
       ['ВЫСОТА', hmUI.data_type.ALTITUDE, false, 0, 'ic_app_3.png'],
       ['ВЛАЖНОСТЬ', hmUI.data_type.HUMIDITY, false, 1, 'ic_app_4.png'],
       ['НОЧЬ/ДЕНЬ', hmUI.data_type.WEATHER_HIGH_LOW, false, 0, 'ic_app_5.png'],
       ['ВОСХОД', hmUI.data_type.SUN_RISE, false, 0, 'ic_app_7.png'],
       ['СТРЕСС', hmUI.data_type.STRESS, false, 0, 'ic_app_8.png'],
       ['КИСЛОРОД', hmUI.data_type.SPO2, false, 0, 'ic_app_9.png'],
       ['PAI', hmUI.data_type.PAI_DAILY, false, 0, 'ic_app_10.png'],
       ['ЖИР', hmUI.data_type.FAT_BURNING, false, 0, 'ic_app_11.png'],
       ['УФ', hmUI.data_type.UVI, false, 0, 'ic_app_12.png'],
       ['РАЗМИНКА', hmUI.data_type.STAND, false, 0, 'ic_app_13.png'],
       /* ['БУДИЛЬНИК', hmUI.data_type.ALARM_CLOCK, true, 0, 'ic_app_14.png'],*/
       ['ТАЙМЕР', hmUI.data_type.COUNT_DOWN, true, 0, 'ic_app_15.png'],
       ['ЭТАЖ', hmUI.data_type.FLOOR, false, 0, 'ic_app_16.png'],
       ['ВЕТЕР', hmUI.data_type.WIND, false, 0, 'ic_app_17.png'],
       ['ПУЛЬС', hmUI.data_type.HEART, false, 0, 'ic_app_18.png'],
      ];

      let Line_arr = [
       ['C', '--', '--', 'КАЛОРИИ'], //0 калории
       ['D', '--', '--', 'ПУТЬ'], //1 путь
       ['H', '--', '--', 'ДАВЛЕНИЕ'], //2 давление
       ['G', '--', '--', 'ЖИР'], //3 жир
       ['I', '--', '--', 'PAI'], //4 pai
       ['O', '--', '--', 'КИСЛОРОД'], //5 o2
       ['R', '--', '--', 'РАЗМИНКА'], //6 разминка
       ['K', '--', '--', 'ВОС/ЗАК'], //7 восход
       // ['J', '--', '--'], //8 ЗАКТ
       ['', '', '', 'ПУСТО'], //9 пусто
      ];

      let CONF_MAIN = [{ // 0. Вертикальный градиент (3 цвета)
        name: 'ЦВЕТ', // кнопка
        id: 7, // при старте
        len: color_bg[0].length, // длина
        type: 0, // цвет или данные
       }, /*{ // 1. Горизонтальный градиент (2 цвета)
        name: 'ЦВЕТ МИН', // кнопка
        id: 24,
        len: color_bg[0].length, // длина
        type: 0,
       }, { // 2. Одноцветный прямоугольник
        name: 'ЦВЕТ  ДАТА НЕДЕЛЯ', // кнопка
        id: 1,
        len: color_bg[0].length, // длина
        type: 0,
       }, { // 3. Одноцветный прямоугольник
        name: 'ЦВЕТ АКТИВ', // кнопка
        id: 7,
        len: color_bg[0].length,
        type: 0,
       },*/
      /* { // 4. Одноцветный прямоугольник
              name: 'ЦВЕТ ПРАВО', // кнопка
              id: 24,
              len: color_bg[0].length,
              type: 0,
          }, { // 5. Одноцветный прямоугольник
              name: 'ЦВЕТ ВЕРХ', // кнопка
              id: 24,
              len: color_bg[0].length,
              type: 0,
          }, { // 3. Одноцветный прямоугольник
              name: 'ФОН прогресс', // кнопка
              id: 31,
              len: color_bg[0].length,
              type: 0,
          }, { // 3. Одноцветный прямоугольник
              name: 'КРЫШКА', // кнопка
              id: 10,
              len: 10,
              type: 1,
          }, { // 3. Одноцветный прямоугольник
              name: 'APP', // кнопка
              id: 2,
              len: app_text_arr.length,
              type: 1,
          },*/
       { // 3. Одноцветный прямоугольник
        name: 'КОРОНКА ОТКЛЮЧЕНА', // кнопка
        id: 10,
        len: 1,
        type: 1,
       }
      ]
      // .filter(item => item.enabled);     

      function loadSettings() {
       color_ic = hmFS.SysProGetInt('GRMN_FRNR_GS_color_ic') === undefined ? (hmFS.SysProSetInt('GRMN_FRNR_GS_color_ic', 0), 0) : hmFS.SysProGetInt('GRMN_FRNR_GS_color_ic');
       tip_grafik = hmFS.SysProGetInt('GRMN_FRNR_GS_tip_grafik') === undefined ? (hmFS.SysProSetInt('GRMN_FRNR_GS_tip_grafik', 0), 0) : hmFS.SysProGetInt('GRMN_FRNR_GS_tip_grafik');
		  
		  
		  
       crown = hmFS.SysProGetInt('GRMN_FRNR_GS_crown') === undefined ? (hmFS.SysProSetInt('GRMN_FRNR_GS_crown', 1), 1) : hmFS.SysProGetInt('GRMN_FRNR_GS_crown');
       fix_gsm = hmFS.SysProGetInt('GRMN_FRNR_GS_fix_gsm') === undefined ? (hmFS.SysProSetInt('GRMN_FRNR_GS_fix_gsm', 0), 0) : hmFS.SysProGetInt('GRMN_FRNR_GS_fix_gsm');
       grad_btn_direction = hmFS.SysProGetInt('GRMN_FRNR_GS_grad_btn_direction') === undefined ? (hmFS.SysProSetInt('GRMN_FRNR_GS_grad_btn_direction', 1), 1) : hmFS.SysProGetInt('GRMN_FRNR_GS_grad_btn_direction');
       grad_btn_reverse = hmFS.SysProGetInt('GRMN_FRNR_GS_grad_btn_reverse') === undefined ? (hmFS.SysProSetInt('GRMN_FRNR_GS_grad_btn_reverse', 0), 0) : hmFS.SysProGetInt('GRMN_FRNR_GS_grad_btn_reverse');
       for (let i = 0; i < CONF_MAIN.length - 1; i++) {
        CONF_MAIN[i].id = hmFS.SysProGetInt('GRMN_FRNR_GS_color_' + i) === undefined ? (hmFS.SysProSetInt('GRMN_FRNR_GS_color_' + i, CONF_MAIN[crown].id), CONF_MAIN[i].id) : hmFS.SysProGetInt('GRMN_FRNR_GS_color_' + i);
       }
      }

      //  let menu_ARC_color = Array(CONF_MAIN.length).fill().map(() => []);

      let ARC_set = [
       [383, 107, 18],
       [398, 129, 22],
       [412, 159, 26],
       [423, 192, 30],
       [427, 233, 34],
       [423, 274, 30],
       [412, 307, 26],
       [398, 337, 22],
       [383, 359, 18],
      ]

      let menu_ARC_color = [];

      let grad_btn_direction = 1

      function grad_direction() {
       grad_btn_direction = (grad_btn_direction + 1) % 2
       grad_btn_reverse = (grad_btn_reverse + 1) % 2
       //    clearCanvas()
       //    updateFirstGradient()
       hmFS.SysProSetInt('GRMN_FRNR_GS_grad_btn_direction', grad_btn_direction);
      }

      let grad_btn_reverse = 0
      function grad_reverse() {
       grad_btn_reverse = (grad_btn_reverse + 1) % 2
       //    clearCanvas()
       //    updateFirstGradient()
       hmFS.SysProSetInt('GRMN_FRNR_GS_grad_btn_reverse', grad_btn_reverse);
      }

      function app_update() {
		autoToggleWeatherIcons();  
		  
       let distanceCurrent = distance.current;
       let current = weatherSensor.current;
       let curAirIconIndex = weatherSensor.curAirIconIndex;
       let temperature_current_temp = -100;
       if (weatherSensor.current != undefined && weatherSensor.current != 'undefined') {
        temperature_current_temp = weatherSensor.current;
       }; // end currentWeather; 
       
       
               //  if (screenTypeJS == hmSetting.screen_type.WATCHFACE) {      
normal_heart_rate_text_font.setProperty(hmUI.prop.TEXT, heart_rate.last + " чсс")
normal_step_current_text_font.setProperty(hmUI.prop.TEXT, step.current + " шг")
normal_temperature_current_text_font.setProperty(hmUI.prop.TEXT, temperature_current_temp + "°C");	
normal_distance_current_text_font.setProperty(hmUI.prop.TEXT, (distanceCurrent / 1000).toFixed(2) + " км")
normal_city_name_text.setProperty(hmUI.prop.TEXT, shotWeaterhNames[curAirIconIndex].toUpperCase());	  
//}

           //     if (screenType == hmSetting.screen_type.AOD) {
idle_heart_rate_text_font.setProperty(hmUI.prop.TEXT, heart_rate.last + " чсс")
idle_step_current_text_font.setProperty(hmUI.prop.TEXT, step.current + " шг")
idle_temperature_current_text_font.setProperty(hmUI.prop.TEXT, temperature_current_temp + "°C");	
idle_distance_current_text_font.setProperty(hmUI.prop.TEXT, (distanceCurrent / 1000).toFixed(2) + " км")
idle_city_name_text.setProperty(hmUI.prop.TEXT, shotWeaterhNames[curAirIconIndex].toUpperCase());
//}	  

		  

      }


      let crownSensitivity = 70; // уровень чувствительности колесика
      let color = 0;
      let color_str = 0;
      let bridg = 127;
      let crown = 0


      // Функция для обновления свойств кнопок
      function updateButtons() {
       CONF_MAIN.forEach((_, i) => {
        Btn_set_[i].setProperty(hmUI.prop.MORE, {
         x: CONF_MAIN.length <= 5 ? 153 : i < Math.ceil(CONF_MAIN.length / 2) ? 70 : 233,
         y: CONF_MAIN.length <= 5 ? 70 + i * Shag_Y : i < Math.ceil(CONF_MAIN.length / 2) ? 70 + i * Shag_Y : 70 + i * Shag_Y - Shag_Y * Math.ceil(CONF_MAIN.length / 2),
         w: 160,
         h: 60,
         text: CONF_MAIN[i].name,
         char_space: 0,
         line_space: -35,
         color: 0xFFFFFFFF,
         text_size: 24,
         radius: 12,
         press_color: 0xFFFF0000,
         normal_color: i !== crown ? 0x000000 : 0x800000,
         text_style: hmUI.text_style.WRAP,
         show_level: hmUI.show_level.ONLY_NORMAL
        });
       });
      }


      function updateProgressArc(len = CONF_MAIN[crown].len, id = CONF_MAIN[crown].id) {
       menu_ARC_PROGRES.setProperty(hmUI.prop.MORE, {
        center_x: D_W / 2,
        center_y: D_W / 2,
        start_angle: 45 + 81 / len * id,
        end_angle: 45 + 9 + 81 / len * (id + 1),
        radius: 219 + 8,
        line_width: 8,
        corner_flag: 0,
        color: 0xFF0000,
        // level: CONF_MAIN[crown].type == 1 ? 100 / CONF_MAIN[crown].len : 100,
        level: 100,
        show_level: hmUI.show_level.ONLY_NORMAL
       });
       menu_ARC_PROGRES.setProperty(hmUI.prop.VISIBLE, true);
      }


      function updateColorElements() {
       for (let i = 0; i < ARC_set.length; i++) {
        g_ACR_color_PROGRES.setProperty(hmUI.prop.VISIBLE, CONF_MAIN[crown].type === 0);
        const colorIndex = CONF_MAIN[crown].id - 4 + i;
        menu_ARC_color[i].setProperty(hmUI.prop.MORE, {
         center_x: ARC_set[i][0],
         center_y: ARC_set[i][1],
         radius: ARC_set[i][2] / 2,
         color: color_bg[0][colorIndex] || 0,
         alpha: color_bg[0][colorIndex] == null ? 0 : 255,
         show_level: hmUI.show_level.ONLY_NORMAL,
        });
       }
      }


      // Основная функция для обработки клика по короне
      function click_crown(index) {
       crown = index;
       // Обновление кнопок
       updateButtons();
       // Обновление дуги прогресса
       updateProgressArc();
       // Обновление цветовых элементов
       updateColorElements();
      }

      // Функция для обработки включения настроек
      function click_Set_on() {
       set = 1;
       groupVremya.setProperty(hmUI.prop.VISIBLE, true);
       g_Set.setProperty(hmUI.prop.VISIBLE, true);
       g_ACR_panel.setProperty(hmUI.prop.VISIBLE, true);
       // Обновление цветовых элементов
       updateColorElements();
      }

      // Функция для обработки выключения настроек
      function click_Set_off() {
       set = 0;
       g_Set.setProperty(hmUI.prop.VISIBLE, false);
       groupVremya.setProperty(hmUI.prop.VISIBLE, true);
       g_ACR_panel.setProperty(hmUI.prop.VISIBLE, false);
       // Скрыть все цветовые элементы
       g_ACR_color_PROGRES.setProperty(hmUI.prop.VISIBLE, false);
       // Сохранить текущую корону
       hmFS.SysProSetInt('GRMN_FRNR_GS_crown', crown);
      }

      // Функция для обработки текста приложения
      function click_app_text_on_off() {

       bg_app_text.setProperty(hmUI.prop.X, crown == 1 ? 233 - 163 : 233);

       for (let i = 0; i < Line_arr.length; i++) {
        app_ACR_text[i].setProperty(hmUI.prop.X, crown == 1 ? 233 - 163 : 233 + 3);
       };


       bg_app_text.setProperty(hmUI.prop.VISIBLE, true);
       Line_arr.forEach((_, i) => app_ACR_text[i].setProperty(hmUI.prop.VISIBLE, true));

       // Скрыть все цветовые элементы
       g_ACR_color_PROGRES.setProperty(hmUI.prop.VISIBLE, false);

       g_ACR_panel.setProperty(hmUI.prop.VISIBLE, true);

       // Установить таймер для автоматического скрытия
       if (MenuCirkl_Timer) timer.stopTimer(MenuCirkl_Timer);
       MenuCirkl_Timer = timer.createTimer(1000, 1, () => {
        timer.stopTimer(MenuCirkl_Timer);
        bg_app_text.setProperty(hmUI.prop.VISIBLE, false);
        Line_arr.forEach((_, i) => app_ACR_text[i].setProperty(hmUI.prop.VISIBLE, false));
        g_ACR_panel.setProperty(hmUI.prop.VISIBLE, false);
       });
       // Установить цвета текста
       Line_arr.forEach((_, i) => {
        app_ACR_text[i].setProperty(hmUI.prop.COLOR, CONF_MAIN[crown].id == i ? 0xff0000 : 0xffffff);
       });
      }
		

      let set = 0;
      let degreeSum = 0;
      let MenuCirkl_Timer = null;

      function switch_crown_0() {
       /*       hmUI.showToast({
               text: colorNames[CONF_MAIN[0].id],
              });*/
		  
     normal_background.setProperty(hmUI.prop.COLOR, color_bg[0][CONF_MAIN[crown].id]);
normal_time_minute_text_font.setProperty(hmUI.prop.COLOR, color_bg[0][CONF_MAIN[crown].id]);
normal_day_text_font.setProperty(hmUI.prop.COLOR, color_bg[0][CONF_MAIN[crown].id]);
normal_heart_rate_text_font.setProperty(hmUI.prop.COLOR, color_bg[0][CONF_MAIN[crown].id]);		  
normal_step_current_text_font.setProperty(hmUI.prop.COLOR, color_bg[0][CONF_MAIN[crown].id]);
normal_temperature_current_text_font.setProperty(hmUI.prop.COLOR, color_bg[0][CONF_MAIN[crown].id]);
		  
       vibro();
      }

      function switch_crown_1() {
		  
/*         let minute = timeSensor.minute;
		  
        for (let i = 0; i < 10; i++) {
        normal_min_TextRotate_ASCIIARRAY[i] = 'H_'+CONF_MAIN[crown].id+'_'+i+'.png'; 
         };	
		  
         normal_M1.setProperty(hmUI.prop.SRC, 'H_' + CONF_MAIN[crown].id + '_' + parseInt(minute / 10) + '.png');
         normal_M2.setProperty(hmUI.prop.SRC, 'H_' + CONF_MAIN[crown].id + '_' + parseInt(minute % 10) + '.png');	*/		  
		  
		  
//       normal_background_min.setProperty(hmUI.prop.COLOR, color_bg[0][CONF_MAIN[crown].id]);
       vibro();
      }

      function switch_crown_2() {
     //  normal_background_week.setProperty(hmUI.prop.COLOR, color_bg[0][CONF_MAIN[crown].id]);
/*        for (let i = 0; i < 10; i++) {
        normal_day_TextRotate_ASCIIARRAY[i] = 'data_'+CONF_MAIN[crown].id+'_'+i+'.png'; 
         };	*/
		  
       vibro();
      }

      function switch_crown_3() {
		  
//normal_background_dig.setProperty(hmUI.prop.COLOR, color_bg[0][CONF_MAIN[crown].id]);

/*        for (let i = 0; i < 11; i++) {
       normal_dig_TextRotate_ASCIIARRAY[i] = 'dig_'+CONF_MAIN[crown].id+'_'+i+'.png'; 
        };
		  
normal_battery_TextRotate_unit.setProperty(hmUI.prop.SRC, 'dig_'+CONF_MAIN[crown].id+'_pr.png');*/

       vibro();
      }

      function switch_crown_4() {
/*        for (let i = 0; i < 10; i++) {
       normal_step_TextRotate_ASCIIARRAY[i] = 'H_'+CONF_MAIN[crown].id+'_'+i+'.png'; 
        };
          normal_step_TextRotate_unit.setProperty(hmUI.prop.SRC, 'H_'+CONF_MAIN[crown].id+'_'+ 11 +'.png');
		  
		  
		  
           vibro();
      }

      function switch_crown_5() {
        normal_temperature_current_text_font.setProperty(hmUI.prop.MORE, {
         x: 221,
         y: 13,
         w: 150,
         h: 70,
         text_size: 51,
         char_space: 0,
         line_space: 0,
         font: 'fonts/digitalfinalest.ttf',
         color: color_bg[0][CONF_MAIN[crown].id],
         align_h: hmUI.align.LEFT,
         align_v: hmUI.align.CENTER_V,
         unit_type: 1,
         text_style: hmUI.text_style.ELLIPSIS,
         type: hmUI.data_type.WEATHER_CURRENT,
         show_level: hmUI.show_level.ONLY_NORMAL,
        });
           vibro();*/

      }

      function switch_crown_6() {
       //    hmUI.showToast({
       //        text: colorNames[CONF_MAIN[6].id],
       //    });
       //    bg_progress_up.setProperty(hmUI.prop.COLOR, color_bg[0][CONF_MAIN[crown].id]);
       //    bg_progress_down.setProperty(hmUI.prop.COLOR, color_bg[0][CONF_MAIN[crown].id]);
       //    bg_progress_up.setProperty(hmUI.prop.ALPHA, CONF_MAIN[crown].id == 31 ? 0 : 255);
       //    bg_progress_down.setProperty(hmUI.prop.ALPHA, CONF_MAIN[crown].id == 31 ? 0 : 255);
       //    vibro();
      }

      function switch_crown_7() {
       //    normal_calorie_icon_img.setProperty(hmUI.prop.SRC, 'bg_' + CONF_MAIN[crown].id + '.png');
       //    vibro();
      }

      function switch_crown_8() {
       /*    click_app_text_on_off()
           for (var i = 0; i < app_text_arr.length; i++) {
               app_ic[i].setProperty(hmUI.prop.SRC, app_text_arr[i][4]);
               app_ic[i].setProperty(hmUI.prop.VISIBLE, i == CONF_MAIN[crown].id);
               if (i != 2 && i != 6) {
                   app_TF[i].setProperty(hmUI.prop.VISIBLE, i == CONF_MAIN[crown].id);
               }
           }
           normal_text_pressure.setProperty(hmUI.prop.VISIBLE, 2 == CONF_MAIN[crown].id);
           app_TF[6].setProperty(hmUI.prop.VISIBLE, 6 == CONF_MAIN[crown].id);
           normal_uvi_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, 11 == CONF_MAIN[crown].id);
           normal_humidity_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, 4 == CONF_MAIN[crown].id);
           normal_wind_direction_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, 15 == CONF_MAIN[crown].id);
           vibro();*/
      }

      // Создаём массив, где каждый элемент — соответствующая функция
      const crownFunctions = [
       switch_crown_0, // crown === 0
//       switch_crown_1, // crown === 1
//       switch_crown_2, // crown === 2
//       switch_crown_3, // crown === 3
//           switch_crown_4, // crown === 4
//           switch_crown_5, // crown === 5
       //    switch_crown_6, // crown === 6
       //    switch_crown_7, // crown === 7
       //    switch_crown_8, // crown === 8
      ];

      function switch_crown(crown) {
       if (crown >= 0 && crown < crownFunctions.length) {
        crownFunctions[crown](); // Вызываем нужную функцию
       }
      }


      function crown_color(crown, step = 0, isCrownEvent = false) {
       // Для событий коронки используем degreeSum
       if (isCrownEvent) {
        step = degreeSum < 0 ? -1 : 1;
        degreeSum = 0; // Сбрасываем после использования
       }

       // Обновляем значение с проверкой границ
       CONF_MAIN[crown].id = Math.max(0,
        Math.min(CONF_MAIN[crown].len - 1, CONF_MAIN[crown].id + step));

       //  hmUI.showToast({
       //      text: CONF_MAIN[crown].id +" ",
       //  });


       hmFS.SysProSetInt('GRMN_FRNR_GS_color_' + crown, CONF_MAIN[crown].id);

       // Логика отображения
       if (set == 0) {
        g_ACR_panel.setProperty(hmUI.prop.VISIBLE, true);
        g_ACR_color_PROGRES.setProperty(hmUI.prop.VISIBLE, CONF_MAIN[crown].type == 0 ? true : false);
        if (MenuCirkl_Timer) timer.stopTimer(MenuCirkl_Timer);
        MenuCirkl_Timer = timer.createTimer(1000, 1, () => {
         g_ACR_color_PROGRES.setProperty(hmUI.prop.VISIBLE, false);
         g_ACR_panel.setProperty(hmUI.prop.VISIBLE, false);
         timer.stopTimer(MenuCirkl_Timer);
        });
       } else {
        g_Set.setProperty(hmUI.prop.VISIBLE, false);
        if (MenuCirkl_Timer) timer.stopTimer(MenuCirkl_Timer);
        MenuCirkl_Timer = timer.createTimer(1000, 1, () => {
         g_Set.setProperty(hmUI.prop.VISIBLE, true);
         timer.stopTimer(MenuCirkl_Timer);
        });
       }
       // Обновить дугу прогресса
       updateProgressArc();
       // Обновление цветовых элементов
       updateColorElements();
      }

      const KEY_SENSITIVITY = 3; // Чувствительность кнопок (2-быстро, 5-медленно)

      // ПОЛНАЯ ЗАМЕНА функции onKeyEvent
      function onKeyEvent() {
       let pressCounter = 0; // Счетчик нажатий

       hmApp.registerKeyEvent(function (key, action) {
        if (action !== hmApp.action.CLICK) return;

        // Определяем направление
        const direction = (key === hmApp.key.UP) ? 1 : -1;
        pressCounter++;

        // Срабатываем только после KEY_SENSITIVITY нажатий
        if (pressCounter >= KEY_SENSITIVITY) {
         pressCounter = 0;

         if (Activ_color == 1 && menu == 1) {
          // Меняем цвет с проверкой границ
          const newIndex = color_ic + direction;
          color_ic = Math.max(0, Math.min(color_bg[1].length - 1, newIndex));
          hmFS.SysProSetInt('GRMN_FRNR_GS_color_ic', color_ic);

          // Обновляем отображение
          Activ_color_alpha.setProperty(hmUI.prop.MORE, {
           center_x: 233,
           center_y: 233,
           radius: 233,
           color: color_bg[1][color_ic],
           alpha: color_ic === 0 ? 0 : 255
          });

          for (let i = 0; i < ARC_set.length; i++) {
           g_ACR_color_PROGRES.setProperty(hmUI.prop.VISIBLE, CONF_MAIN[crown].type === 0);
           const colorIndex = color_ic - 4 + i;
           menu_ARC_color[i].setProperty(hmUI.prop.MORE, {
            center_x: ARC_set[i][0],
            center_y: ARC_set[i][1],
            radius: ARC_set[i][2] / 2,
            color: color_bg[1][colorIndex] || 0,
            alpha: color_bg[1][colorIndex] == null ? 0 : 255,
            show_level: hmUI.show_level.ONLY_NORMAL,
           });
          }

          updateProgressArc(len = color_bg[1].length, id = color_ic)


          g_ACR_panel.setProperty(hmUI.prop.VISIBLE, true);

          // Установить таймер для автоматического скрытия
          if (MenuCirkl_Timer) timer.stopTimer(MenuCirkl_Timer);
          MenuCirkl_Timer = timer.createTimer(1000, 1, () => {
           // Скрыть все цветовые элементы
           g_ACR_color_PROGRES.setProperty(hmUI.prop.VISIBLE, false);
           g_ACR_panel.setProperty(hmUI.prop.VISIBLE, false);
           timer.stopTimer(MenuCirkl_Timer);
          });

          vibro();
         }

         // Обработка коронок
         for (let i = 0; i < crownFunctions.length; i++) {
          if (Activ_color == 0 && menu == 0 && crown == i) {
           crown_color(crown, direction, false)
           switch_crown(crown)
          }
         }


        }
       });
      }

      function offKeyEvent() {
       try {
        hmApp.unregisterKeyEvent();
       } catch (e) {
        console.log("Unregister key event error:", e);
       }
      }

      function onDigitalCrown() {
       hmApp.registerSpinEvent(function (key, degree) {
        if (key === hmApp.key.HOME) {
         degreeSum += degree;
         if (Math.abs(degreeSum) > crownSensitivity) {

          if (Activ_color == 1 && menu == 1) {
           let step = degreeSum < 0 ? -1 : 1;
           color_ic = color_ic + step < 0 ? 0 : (color_ic + step > color_bg[1].length - 1 ? color_bg[1].length - 1 : color_ic + step);
           degreeSum = 0;
           hmFS.SysProSetInt('GRMN_FRNR_GS_color_ic', color_ic);

           Activ_color_alpha.setProperty(hmUI.prop.MORE, {
            center_x: 233,
            center_y: 233,
            radius: 233,
            color: color_bg[1][color_ic],
            alpha: color_ic == 0 ? 0 : 255,
            show_level: hmUI.show_level.ONLY_NORMAL,
           })

           for (let i = 0; i < ARC_set.length; i++) {
            g_ACR_color_PROGRES.setProperty(hmUI.prop.VISIBLE, true);
            const colorIndex = color_ic - 4 + i;
            menu_ARC_color[i].setProperty(hmUI.prop.MORE, {
             center_x: ARC_set[i][0],
             center_y: ARC_set[i][1],
             radius: ARC_set[i][2] / 2,
             color: color_bg[1][colorIndex] || 0,
             alpha: color_bg[1][colorIndex] == null ? 0 : 255,
             show_level: hmUI.show_level.ONLY_NORMAL,
            });
           }

           updateProgressArc(len = color_bg[1].length, id = color_ic)


           g_ACR_panel.setProperty(hmUI.prop.VISIBLE, true);

           // Установить таймер для автоматического скрытия
           if (MenuCirkl_Timer) timer.stopTimer(MenuCirkl_Timer);
           MenuCirkl_Timer = timer.createTimer(1000, 1, () => {
            // Скрыть все цветовые элементы
            g_ACR_color_PROGRES.setProperty(hmUI.prop.VISIBLE, false);
            g_ACR_panel.setProperty(hmUI.prop.VISIBLE, false);
            timer.stopTimer(MenuCirkl_Timer);
           });

           vibro();
          }


          for (let i = 0; i < crownFunctions.length; i++) {
           if (Activ_color == 0 && menu == 0 && crown == i) {
            crown_color(crown, 0, true)
            switch_crown(crown)
           }
          }
         }
        }
       }) // crown
      }


      // ===== КОНФИГУРАЦИЯ ГРАДИЕНТОВ (единая структура для всех типов) =====
      const GRADIENT_CONFIGS = [{ // 1. Вертикальный градиент (3 цвета)
       line_thickness: 10, // Добавьте эту строку
       x: 50,
       y: 50,
       w: 150,
       h: 150,
       color_start: 0xFF0000,
       color_middle: 0x00FF00,
       color_end: 0x0000FF,
       use_three_colors: true,
       alpha: 255,
       direction: 'vertical', //vertical  horizontal
       reverse: false,
       is_single_color: false,
       enabled: false
      }, { // 2. Горизонтальный градиент (2 цвета)
       line_thickness: 1, // Добавьте эту строку		  
       x: 0,
       y: 0,
       w: 466,
       h: 466,
       color_start: 0xFFFF00,
       color_middle: 0x000000, // Не используется
       color_end: 0x00FFFF,
       use_three_colors: false,
       alpha: 255,
       direction: 'horizontal', //vertical  horizontal
       reverse: false,
       is_single_color: true,
       enabled: true,
      }, { // 3. Одноцветный прямоугольник
       line_thickness: 10, // Добавьте эту строку		  
       x: 50,
       y: 400,
       w: 350,
       h: 50,
       color_start: 0xFFFFFF,
       color_middle: 0x000000, // Не используется
       color_end: 0x000000, // Не используется
       use_three_colors: false,
       alpha: 255,
       direction: 'vertical', // Не важно
       reverse: false, // Не важно
       is_single_color: true,
       enabled: false
      }].filter(config => config.enabled);

      // ===== ПЕРЕМЕННЫЕ =====
      let canvas = null;
      // let line_gradient = Array(GRADIENT_CONFIGS.length).fill().map(() => []);
      let solidRect = null;

      // ===== ФУНКЦИИ (адаптированные под единую конфигурацию) =====


      //normal_day_text_font.setProperty(hmUI.prop.COLOR, color_bg[0][CONF_MAIN[crown].id]);

      const vibrate = hmSensor.createSensor(hmSensor.id.VIBRATE)
      let stopVibro_Timer = null;

      /*      function vibro(scene = 25) {
             let stopDelay = 50;
             vibrate.stop();
             vibrate.scene = scene;
             if (scene < 23 || scene > 25) stopDelay = 1220;
             vibrate.start();
             stopVibro_Timer = timer.createTimer(stopDelay, 0, stopVibro, {});
            }*/

      function vibro(scene = 25) {
       //let stopDelay = 50;
       vibrate.stop();
       vibrate.scene = scene;
       vibrate.start();

       // stopVibro_Timer = timer.createTimer(stopDelay, 0, stopVibro, {});
      }
        

      function stopVibro() {
       vibrate.stop();
       timer.stopTimer(stopVibro_Timer);
      }

      function click_Pogoda_on() {
       normal_background_Pogoda.setProperty(hmUI.prop.VISIBLE, true);
         // updateGrafik()       
       menu = 2
       groupVremya.setProperty(hmUI.prop.VISIBLE, false);
       groupPogoda.setProperty(hmUI.prop.VISIBLE, true);
		  

       updateGrafik()

      }

      function click_Pogoda_off() {
       normal_background_Pogoda.setProperty(hmUI.prop.VISIBLE, false);
       menu = 0
       groupVremya.setProperty(hmUI.prop.VISIBLE, true);
       groupPogoda.setProperty(hmUI.prop.VISIBLE, false);

      }

      function click_Activ_on() {
       menu = 1
        autoToggleWeatherIcons()
       groupVremya.setProperty(hmUI.prop.VISIBLE, false);
       groupActiv.setProperty(hmUI.prop.VISIBLE, true);
      }

      function click_Activ_off() {
       menu = 0
       Activ_color = 0
       ic_activ_color_off_img.setProperty(hmUI.prop.VISIBLE, Activ_color == 0);
       groupVremya.setProperty(hmUI.prop.VISIBLE, true);
       groupActiv.setProperty(hmUI.prop.VISIBLE, false);
      }


      let apps = [
       ['Нет действия', '-', `tap/i_tap_pusto.png`, 0, 'page/index'],
       ['Таймер', 'CountdownAppScreen', `tap/i_tap_obrat_otchet.png`, 0, 'page/index'],
       ['Секундомер', 'StopWatchScreen', `tap/i_tap_secundomer.png`, 0, 'page/index'],
       ['Мировые часы', 'WorldClockScreen', `tap/i_tap_mirivie_chasi.png`, 0, 'page/index'],
       ['Восход/закат', 'TideScreen', `tap/i_tap_voshod_zakat.png`, 0, 'page/index'],
       ['Сон', 'Sleep_HomeScreen', `tap/i_tap_son.png`, 0, 'page/index'],
       ['Стресс', 'StressHomeScreen', `tap/i_tap_stress.png`, 0, 'page/index'],
       ['SP02 (Кислород)', 'spo_HomeScreen', `tap/i_tap_kislorod.png`, 0, 'page/index'],
       ['Дыхание', 'RespirationsettingScreen', `tap/i_tap_dihanie.png`, 0, 'page/index'],
       ['Измерение одним касанием', 'oneKeyAppScreen', `tap/i_tap_1_kosanie.png`, 0, 'page/index'],
       ['Женский календарь', 'menstrualAppScreen', `tap/i_tap_gensk_calendar.png`, 0, 'page/index'],
       ['Найти телефон', 'FindPhoneScreen', `tap/i_tap_naiti_telo.png`, 0, 'page/index'],
       ['Музыка', 'LocalMusicScreen', `tap/i_tap_musik.png`, 0, 'page/index'], //'PhoneMusicCtrlScreen'
       ['Компас', 'CompassScreen', `tap/i_tap_kompas.png`, 0, 'page/index'],
       ['Набрать номер', 'DialCallScreen', `tap/i_tap_nabor.png`, 0, 'page/index'],
       ['Телефон', 'PhoneHomeScreen', `tap/i_tap_telefon.png`, 0, 'page/index'],
       ['Диктофон', 'VoiceMemoScreen', `tap/i_tap_dictofon.png`, 0, 'page/index'],
       ['Расписание', 'ScheduleListScreen', `tap/i_tap_raspisanie.png`, 0, 'page/index'],
       ['Список дел', 'todoListScreen', `tap/i_tap_spisok_del.png`, 0, 'page/index'],
       ['Календарь', 'ScheduleCalScreen', `tap/i_tap_calendar.png`, 0, 'page/index'],
       ['Погода', 'WeatherScreen', `tap/i_tap_pogoda.png`, 0, 'page/index'],
       ['Настройка', 'Settings_homeScreen', `tap/i_tap_sitting.png`, 0, 'page/index'],
       ['Камера', 'HidcameraScreen', `tap/i_tap_camera.png`, 0, 'page/index'],
       ['Пульс', 'heart_app_Screen', `tap/i_tap_puls.png`, 0, 'page/index'],
       ['Будильник', 'AlarmInfoScreen', `tap/i_tap_budilnik.png`, 0, 'page/index'],
       ['PAI', 'PAI_app_Screen', `tap/i_tap_pai.png`, 0, 'page/index'],
       ['Тренировка', 'SportListScreen', `tap/i_tap_trenerovka.png`, 0, 'page/index'],
       ['AOD', 'Settings_standbyModelScreen', `tap/i_tap_aod.png`, 0, 'page/index'],
       ['Экономия заряда', 'LowBatteryScreen', `tap/i_tap_LowBattery.png`, 0, 'page/index'],
       ['Давление/Высота', 'BaroAltimeterScreen', `tap/i_tap_barometr.png`, 0, 'page/index'],
       ['Погода LeXxiR', '1051195', `tap/i_tap_LeXxiR.png`, 1, 'page/index'],
       ['Календарь Sasha', '1057409', `tap/i_tap_calen_Sasha.png`, 1, 'page/index'],
       ['Flow', '1038314', `tap/i_tap_flow.png`, 1, 'page/gtr/home/index.page'],
       ['Ночной режим', 'Settings_nsModeHomeScreen', `tap/i_tap_night_Mode_Screen.png`, 0, 'page/index'],
       ['Говорящие часы', '1066653', `tap/i_tap_talking_watch.png`, 1, 'page/index.page'],
       ['Перезагрузка', 'HmReStartScreen', `tap/i_tap_restart.png`, 0, 'page/index'],
      ];


      let btn_tap = ''
      let btn_click_tap_exit = ''


      function tap_zona_exit() {
       //    canvas.setProperty(hmUI.prop.MORE, {
       //        x: 0,
       //        y: 0,
       //        w: 466,
       //        h: 466,
       //        show_level: hmUI.show_level.ONLY_NORMAL
       //    });

       // setTimeout(() => {
       // drawGradients();
       //  }, 300);

       groupVremya.setProperty(hmUI.prop.VISIBLE, true);
       groupTap.setProperty(hmUI.prop.VISIBLE, false);

      }


      function tap_run() {
       //    canvas.setProperty(hmUI.prop.MORE, {
       //        x: 466,
       //        y: 466,
       //        w: 466,
       //        h: 466,
       //        show_level: hmUI.show_level.ONLY_NORMAL
       //    });

       groupVremya.setProperty(hmUI.prop.VISIBLE, false);
       groupTap.setProperty(hmUI.prop.VISIBLE, true);
      }


      //-------------------------------- 
      //переменные для ргафика
      let weather_ic_array = []
      let weather_ic = []
      let DigDay = []
      let DigNight = []
      let yArrH = [];
      let arr_xH = [];
      let arr_yH = [];
      let arr_x = [];
      let arr_y = [];
      let arr_xL = [];
      let arr_yL = [];
      let yArrAll = [];
      let yArrL = [];
      let y_pogodaH = [];
      let y_pogodaL = [];
      let week_array = ["ПН", "ВТ", "СР", "ЧТ", "ПТ", "СБ", "ВС"];
      let week_text = []
      let data_text = []
      const ROOTPATH = "images/"
      var shag = 46;
      var x0 = 119 - 23 - 23;
      let dney = 8;
      let isDayIcons = false

      let shotWeaterhNames = ["Облачно", "Местами дождь", "Местами снег", "Cолнечно", "Пасмурно", "Слабый дождь", "Слабый снег", "Умеренный дождь", "Умеренный снег", "Сильный снегопад", "Сильный дождь", "Песчаная буря", "Мокрый снег", "Туман", "Дымка", "Дождь с грозой", "Метель", "Пыльно", "Ливень", "Дождь с градом", "Сильный дождь с градом", "Сильный дождь ", "Песчаная буря", "Сильная песчаная буря ", "Сильный дождь", "Неизвестная погода", "Облачно ночью", "Дождливо ночью", "Ясно ночью"];


      let tip_grafik = 0

      function click_tip_grafik() {
       tip_grafik = (tip_grafik + 1) % 2
       hmFS.SysProSetInt('GRMN_FRNR_GS_tip_grafik', tip_grafik);
       ic_graf_img.setProperty(hmUI.prop.SRC, "images/Grafik/ic_graf_" + tip_grafik + ".png");
       click_Pogoda_off();
       normal_background_Pogoda.setProperty(hmUI.prop.VISIBLE, true);
       setTimeout(() => {
        click_Pogoda_on()
        tip()
       }, 150);
      }

      let fix_gsm = 1;

      function click_fix_gms() {
       fix_gsm = (fix_gsm + 1) % 2
       hmFS.SysProSetInt('GRMN_FRNR_GS_fix_gsm', fix_gsm);
       fix_gsm_text_font.setProperty(hmUI.prop.TEXT, fix_gsm == 0 ? '+0' : '+1');
       click_Pogoda_off();
       normal_background_Pogoda.setProperty(hmUI.prop.VISIBLE, true);
       setTimeout(() => {
        click_Pogoda_on()
        updateGrafik()
       // app_update();
       }, 150);
      }


      let normal_city_name_text_0 = ''

      //-------------------------------- 

      //массив иконок для графика       
      for (var i = 0; i <= 28; i++) {
       weather_ic_array.push(ROOTPATH + "Grafik/weather/" + i + ".png"); //0-28
      }
		
function getSunTimes(weatherData, fix_gsm) {
    let tideData = weatherData.tideData;
    
    // Получение времени заката
    let sunset_hour = -1;
    let sunset_minute = -1;
    if (tideData.count > 0) {
        sunset_hour = tideData.data[0].sunset.hour + fix_gsm;
        sunset_minute = tideData.data[0].sunset.minute;
    }

    let normal_sunset = undefined;
    if (sunset_hour >= 0 && sunset_minute >= 0) {
        normal_sunset = String(sunset_hour).padStart(2, '0') + ':' + String(sunset_minute).padStart(2, '0');
    }

    // Получение времени восхода
    let sunrise_hour = -1;
    let sunrise_minute = -1;
    if (tideData.count > 0) {
        sunrise_hour = tideData.data[0].sunrise.hour + fix_gsm;
        sunrise_minute = tideData.data[0].sunrise.minute;
    }

    let normal_sunrise = undefined;
    if (sunrise_hour >= 0 && sunrise_minute >= 0) {
        normal_sunrise = String(sunrise_hour).padStart(2, '0') + ':' + String(sunrise_minute).padStart(2, '0');
    }

    return {
        normal_sunset_circle_string: normal_sunset,
        normal_sunrise_circle_string: normal_sunrise
    };
}				
		
	function tempWithSign2(val){
			val = parseFloat(val);
			if (!isFinite(val)) return '--'		// если на входе не число - возвращаем прочерки
			val = Math.round(val);
			if (val > 0) val = '+' + val;
			val += '°';
			
			return val
		}		

      function updateLineUp(tempNow, Feels, tempMin, tempMax) {
		  
       let current = weatherSensor.current;
       let curAirIconIndex = weatherSensor.curAirIconIndex;
		  
normal_line_up_text.setProperty(hmUI.prop.TEXT, tempWithSign2(tempNow) + " " + shotWeaterhNames[curAirIconIndex].toUpperCase() + " " + Feels);
		  
       let weatherData = weatherSensor.getForecastWeather();
		  
const { normal_sunset_circle_string, normal_sunrise_circle_string } = getSunTimes(weatherData, fix_gsm);
		  
        normal_left_text.setProperty(hmUI.prop.TEXT, normal_sunrise_circle_string + " " + tempMin + "°");
        normal_right_text.setProperty(hmUI.prop.TEXT, tempMax + "° " + normal_sunset_circle_string);
	  
	  }
      
      function autoToggleWeatherIcons() {
      
     let weatherData = weatherSensor.getForecastWeather();
    let tideData = weatherData.tideData;
        
    
       sunData = weatherData.tideData;
       if (sunData.count > 0) {
        today = sunData.data[0];
        sunriseMins = (today.sunrise.hour + fix_gsm) * 60 + today.sunrise.minute;
        sunsetMins = (today.sunset.hour + fix_gsm) * 60 + today.sunset.minute;
       } else {
        sunriseMins = sunriseMins_def;
        sunsetMins = sunsetMins_def;
       }
       curMins = timeSensor.hour * 60 + timeSensor.minute;
       let isDayNow = (curMins >= sunriseMins) && (curMins < sunsetMins);

       if (isDayNow) {
        if (!isDayIcons) {
         isDayIcons = true;
        }
       } else {
        if (isDayIcons) {
         isDayIcons = false;
        }
       }  
       
 const { normal_sunset_circle_string, normal_sunrise_circle_string } = getSunTimes(weatherData, fix_gsm); 

        normal_vos_zak_text_font.setProperty(hmUI.prop.TEXT, isDayIcons == false ? normal_sunrise_circle_string : normal_sunset_circle_string);
        normal_vos_zak_icon_img.setProperty(hmUI.prop.SRC, isDayIcons == false ? 'images/Grafik/ic_activ/ic_vos.png' : 'images/Grafik/ic_activ/ic_zak.png');
      
      
       let T_N = curMins;
//       let T_V = sunrise_hour * 60 + sunrise_minute;
//       let T_Z = sunset_hour * 60 + sunset_minute;
       
// Получаем часы и минуты из строки формата "HH:MM"
const [sunriseHours, sunriseMinutes] = normal_sunrise_circle_string.split(':').map(Number);
const [sunsetHours, sunsetMinutes] = normal_sunset_circle_string.split(':').map(Number);

let T_V = sunriseHours * 60 + sunriseMinutes;
let T_Z = sunsetHours * 60 + sunsetMinutes; 


       let T_24 = T_Z - T_N;
       let level_SUN_CURRENT_day = (T_N - T_V) / (T_Z - T_V) * 100;
       let level_SUN_CURRENT_night = T_24 < 0 ? (T_N - T_Z) / ((24 * 60 - T_Z) + T_V) * 100 : (24 * 60 - T_Z + T_N) / ((24 * 60 - T_Z) + T_V) * 100;

       SUN_CURRENT_PROGRESS.setProperty(hmUI.prop.MORE, {
        center_x: 175 + 116 + 7,
        center_y: 166 + 116,
        start_angle: -135,
        end_angle: 135,
        radius: 39,
        line_width: 10,
        corner_flag: 3,
        color: isDayIcons ? 0xffef42 : 0x42ffeb,
        level: isDayIcons ? level_SUN_CURRENT_day : level_SUN_CURRENT_night,
        // type: hmUI.data_type.SUN_CURRENT,
        show_level: hmUI.show_level.ONLY_NORMAL,
       });	       
       
       
       shotWeaterhNames = isDayIcons == false ? ["Облачно ночью", "Местами дождь", "Местами снег", "Ясно ночью", "Пасмурно ночью", "Слабый дождь", "Слабый снег", "Умеренный дождь", "Умеренный снег", "Сильный снегопад", "Сильный дождь", "Песчаная буря", "Мокрый снег", "Туман", "Дымка", "Дождь с грозой", "Метель", "Пыльно", "Ливень", "Дождь с градом", "Сильный дождь с градом", "Сильный дождь ", "Песчаная буря", "Сильная песчаная буря", "Сильный дождь", "Неизвестная погода", "Облачно ночью", "Дождливо ночью", "Ясно ночью"] : ["Облачно", "Местами дождь", "Местами снег", "Cолнечно", "Пасмурно", "Слабый дождь", "Слабый снег", "Умеренный дождь", "Умеренный снег", "Сильный снегопад", "Сильный дождь", "Песчаная буря", "Мокрый снег", "Туман", "Дымка", "Дождь с грозой", "Метель", "Пыльно", "Ливень", "Дождь с градом", "Сильный дождь с градом", "Сильный дождь ", "Песчаная буря", "Сильная песчаная буря ", "Сильный дождь", "Неизвестная погода", "Облачно ночью", "Дождливо ночью", "Ясно ночью"];
       
       
	  }
      
      
      
      

      //обновление для   графика           
      function updateGrafik() {
      
autoToggleWeatherIcons() 

       if (!timeSensor) timeSensor = hmSensor.createSensor(hmSensor.id.TIME);
       let day_num = [0, 31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31];
       let year = timeSensor.year;
       if (year % 4 == 0 && (year % 100 != 0 || year % 400 == 0)) { // Високосный год
        day_num[2] = 29
       } else {
        day_num[2] = 28
       }

       let current = weatherSensor.current;
       let curAirIconIndex = weatherSensor.curAirIconIndex;

       let temperature_current_temp = -100;
       if (weatherSensor.current != undefined && weatherSensor.current != 'undefined') {
        temperature_current_temp = weatherSensor.current;
       }; // end currentWeather; 

       let weatherData = weatherSensor.getForecastWeather();
       let forecastData = weatherData.forecastData;

const { normal_sunset_circle_string, normal_sunrise_circle_string } = getSunTimes(weatherData, fix_gsm);


       normal_temp_text_font.setProperty(hmUI.prop.TEXT, temperature_current_temp + "°С");
       normal_weather_text_font.setProperty(hmUI.prop.TEXT, shotWeaterhNames[curAirIconIndex].toUpperCase());
       normal_city_name_text_0.setProperty(hmUI.prop.TEXT, normal_sunrise_circle_string + "   " + weatherData.cityName.toUpperCase() + "   " + normal_sunset_circle_string);
		  

//        normal_left_text.setProperty(hmUI.prop.TEXT, normal_sunrise_circle_string + " " + forecastData.data[0].low + "°");
//        normal_right_text.setProperty(hmUI.prop.TEXT, forecastData.data[0].high + "° " + normal_sunset_circle_string);
		  
		  
		  
       // normal_weater_name_text.setProperty(hmUI.prop.TEXT, shotWeaterhNames[curAirIconIndex]);
       //normal_temperature_max_min_text.setProperty(hmUI.prop.TEXT, forecastData.data[0].high + "/" + forecastData.data[0].low);
       // normal_temperature_current_text.setProperty(hmUI.prop.TEXT, temperature_current_temp + "°");

       if (forecastData.count == 0) {
        for (let i = 0; i < dney; i++) {
         var invalidPath = "--";
         weather_ic[i].setProperty(hmUI.prop.SRC, ROOTPATH + "Grafik/weather/25.png");
        }
       } else {
        let weekDay = timeSensor.week - 1;
        let data_gr = timeSensor.day;
        let month_gr = timeSensor.month;

        for (let i = 0; i < dney; i++) {

         // let arr_y  = [252, 238, 252, 266, 238, 224, 308, 322];    

         yArrH[i] = forecastData.data[i].high;

         let element = forecastData.data[i];
         let iconIndex = element.index;
         weather_ic[i].setProperty(hmUI.prop.SRC, weather_ic_array[iconIndex]);
         let week2 = week_array[weekDay];
         week_text[i].setProperty(hmUI.prop.MORE, {
          color: weekDay < 5 ? "0xFFFFFFFF" : "0xFFFF0000",
          text: week2,
         });
         data_text[i].setProperty(hmUI.prop.MORE, {
          color: weekDay < 5 ? "0xFFFFFFFF" : "0xFFFF0000",
          text: data_gr,
         });
         weekDay = (weekDay + 1) % 7;
         data_gr = (data_gr + 1)
         if (data_gr > day_num[month_gr]) data_gr = 1
         if (i < dney - 1) yArrL[i] = forecastData.data[i].low;

        }
       }


       //  array_ic_weater = isDayIcons == false ?  ["Ъ", "Ы", "Э", "Ь", "Д", "Е", "Ж", "З", "И", "Й", "К", "Л", "М", "Н", "О", "П", "Р", "С", "У", "Ф", "Х", "Ц", "Ч", "Ш", "?", "Ъ", "Ы", "Ь"] : ["А", "Б", "В", "Г", "Д", "Е", "Ж", "З", "И", "Й", "К", "Л", "М", "Н", "О", "П", "Р", "С", "У", "Ф", "Х", "Ц", "Ч", "Ш", "?", "Ъ", "Ы", "Ь"];  

       // if (menu == 2) tip();
       tip();

      }

      function tip() {

       canvas.clear({
        x: 0,
        y: 0,
        w: D_W,
        h: D_W,
       })

       canvas.setPaint({
        color: 0x00ff00,
        line_width: 4
       })

       for (let i = 0; i < dney - 1; i++) {
        canvas.drawRect({
         x1: 94 + shag * [i],
         y1: 93,
         x2: 94 + shag * [i] + 1,
         y2: 351,
         color: 0xc0c0c0
        })
       }


       let maxH = Math.max(...yArrH)
       let maxL = Math.min(...yArrL)
       let delta = 120 / (maxL - maxH)

       let RedArray = [];
       let BlueArray = [];

       if (tip_grafik == 0) {
        for (let i = 0; i < dney; i++) {
         arr_x[i] = x0 + shag * [i];
         arr_y[i] = yArrH[i] * delta + 162 - maxH * delta;
        }
        // let n = arr_x.length;
        splain(dney)

        for (let i = 0; i < dney - 1; i++) {
         arr_x[i] = x0 + 23 + shag * [i];
         arr_y[i] = yArrL[i] * delta + 162 - maxH * delta;
        }
        // n = dney - 1;
        splain(dney - 1)
       }
       if (tip_grafik == 1) {
        let k = 0
        for (let i = 0; i < dney; i++) {

         yArrAll[k] = yArrH[i]
         k = k + 1
         yArrAll[k] = yArrL[i]
         k = k + 1

        }


        for (let i = 0; i < yArrAll.length; i++) {
         arr_x[i] = x0 + shag / 2 * [i];
         arr_y[i] = yArrAll[i] * delta + 162 - maxH * delta;
        }
        //n = yArrAll.length - 1;
        splain(yArrAll.length - 1)
       }


       for (let i = 0; i < dney; i++) {
        if (tip_grafik == 0) {
         canvas.drawCircle({
          center_x: x0 + shag * [i],
          center_y: yArrH[i] * delta + 162 - maxH * delta,
          radius: 5,
          color: 0xFF0000
         })
        }
        y_pogodaH[i] = (yArrH[i] * delta + 145 - maxH * delta) - 5;
        DigDay[i].setProperty(hmUI.prop.more, {
         x: x0 - 23 - 5 + i * 45 * 1.02,
         y: y_pogodaH[i] - 18, //120-7//120-7/- 38
         w: 50,
         h: 40,
         color: "0xFFffffff",
         text_size: 27,
         text: yArrH[i],
         text_style: hmUI.text_style.NONE,
         align_h: hmUI.align.CENTER_H,
         align_v: hmUI.align.CENTER_V,
         show_level: hmUI.show_level.ONLY_NORMAL
        });

        if (i < dney - 1) {
         if (tip_grafik == 0) {
          canvas.drawCircle({
           center_x: x0 + 23 + shag * [i],
           center_y: yArrL[i] * delta + 162 - maxH * delta,
           radius: 5,
           color: 0x00eaff
          })
         }
         y_pogodaL[i] = (yArrL[i] * delta + 145 - maxH * delta) - 5;;
         DigNight[i].setProperty(hmUI.prop.more, {
          x: x0 - 23 - 5 + 23 + i * 45 * 1.02,
          y: y_pogodaL[i] + 19, //120-7 / - 1  
          w: 50,
          h: 40,
          color: "0xFFffffff",
          text_size: 27,
          text: yArrL[i],
          text_style: hmUI.text_style.NONE,
          align_h: hmUI.align.CENTER_H,
          align_v: hmUI.align.CENTER_V,
          show_level: hmUI.show_level.ONLY_NORMAL
         });
        } //dney - 1
       }; //dney   
      }


      function splain(n) {
       let arr_a = new Array(n).fill().map(() => new Array(1));
       let arr_b = new Array(n - 1).fill().map(() => new Array(1));
       let arr_c = new Array(n).fill().map(() => new Array(1));
       let arr_d = new Array(n - 1).fill().map(() => new Array(1));

       let arr_h = new Array(n - 1).fill().map(() => new Array(1));
       let arr_alpha = new Array(n).fill().map(() => new Array(1));
       let arr_l = new Array(n).fill().map(() => new Array(1));
       let arr_mu = new Array(n).fill().map(() => new Array(1));
       let arr_z = new Array(n).fill().map(() => new Array(1));

       for (var i = 0; i < n - 1; i++) {
        arr_h[i] = arr_x[i + 1] - arr_x[i];
       }

       for (var i = 1; i < n - 1; i++) {
        arr_alpha[i] = 3 * ((arr_y[i + 1] - arr_y[i]) / arr_h[i] - (arr_y[i] - arr_y[i - 1]) / arr_h[i - 1]);
       }

       arr_l[0] = 1;
       arr_mu[0] = 0;
       arr_z[0] = 0;

       for (var i = 1; i < n - 1; i++) {
        arr_l[i] = 2 * (arr_x[i + 1] - arr_x[i - 1]) - arr_h[i - 1] * arr_mu[i - 1];
        arr_mu[i] = arr_h[i] / arr_l[i];
        arr_z[i] = (arr_alpha[i] - arr_h[i - 1] * arr_z[i - 1]) / arr_l[i];
       }

       arr_l[n - 1] = 1;
       arr_z[n - 1] = 0;
       arr_c[n - 1] = 0;

       for (var j = n - 2; j >= 0; j--) {
        arr_c[j] = arr_z[j] - arr_mu[j] * arr_c[j + 1];
        arr_b[j] = (arr_y[j + 1] - arr_y[j]) / arr_h[j] - arr_h[j] * (arr_c[j + 1] + 2 * arr_c[j]) / 3;
        arr_d[j] = (arr_c[j + 1] - arr_c[j]) / (3 * arr_h[j]);
        arr_a[j] = arr_y[j];
       }

       for (var i = 0; i < n - 1; i++) {
        for (xi = arr_x[i]; xi < arr_x[i + 1] - 1; xi += 5) {
         yi = arr_a[i] + arr_b[i] * (xi - arr_x[i]) + arr_c[i] * Math.pow((xi - arr_x[i]), 2) + arr_d[i] * Math.pow((xi - arr_x[i]), 3);

         if (tip_grafik == 0) {
          canvas.drawImage({
           x: xi,
           y: yi,
           w: 5,
           h: 310 - yi,
           alpha: 127,
           image: n == dney ? 'images/Grafik/line_day.png' : 'images/Grafik/line_night.png'
          })
         }

         canvas.drawLine({
          x1: xi,
          y1: yi,
          x2: xi + 5,
          y2: arr_a[i] + arr_b[i] * (xi + 5 - arr_x[i]) + arr_c[i] * Math.pow((xi + 5 - arr_x[i]), 2) + arr_d[i] * Math.pow((xi + 5 - arr_x[i]), 3),
          // color: n == dney ? 0xff0000 : 0x00eaff//0x009cff  yArrAll.length - 1
          color: n == dney ? 0xff0000 : n == dney - 1 ? 0x00eaff : 0x12a2fd //0x009cff
         })


        }
       }

      }

      function updateSleep() {
       //-----------  сон------------------
       sleepTotalTime = sleep.getTotalTime();
       sleepInfo = sleep.getBasicInfo();
       sleepStartTime = sleepInfo.startTime;
       if (sleepStartTime >= 24 * 60) {
        sleepStartTime -= 24 * 60
       }

       sleepEndTime = sleepInfo.endTime + 1;
       if (sleepEndTime >= 24 * 60) {
        sleepEndTime -= 24 * 60
       }

       //-----------  время пробуждений ------------------
       let wakeTime = 0;
       sleepStageArray = sleep.getSleepStageData();

       for (let i = 0; i < sleepStageArray.length; i++) {
        let data = sleepStageArray[i];
        if (data.model == modelData.WAKE_STAGE) {
         wakeTime += data.stop + 1 - data.start;
        }

       }

       sleepTotalTime -= wakeTime;
       //-------------------------------------------------

       sleep_time_txt.setProperty(hmUI.prop.TEXT, 'СПАЛИ ' + Math.floor(sleepTotalTime / 60).toString().padStart(2, "0") + ':' + (sleepTotalTime % 60).toString().padStart(2, "0"));
       sleep_start_time_txt.setProperty(hmUI.prop.TEXT, Math.floor(sleepStartTime / 60).toString().padStart(2, "0") + ':' + (sleepStartTime % 60).toString().padStart(2, "0"));
       sleep_end_time_txt.setProperty(hmUI.prop.TEXT, Math.floor(sleepEndTime / 60).toString().padStart(2, "0") + ':' + (sleepEndTime % 60).toString().padStart(2, "0"));
       wake_time_txt.setProperty(hmUI.prop.TEXT, 'ПРОСЫПАЛИСЬ ' + String(wakeTime) + ' мин.');
       sleep_score_txt.setProperty(hmUI.prop.TEXT, 'КАЧЕСТВО ' + String(sleepScore) + ' %');
       //-------------------------------------------------

      }
		
		

      function updatePressere() {
       let pressure_array = read_pressure();
       let value = getPressureValue(pressure_array);
       value = hPa_To_mmHg(value); // если нужно перевести в мм.рт.ст.

       let pressere_changes_str = "=";
       //let color_pressere = 0x00ff00;
       let color_pressere_0 = value < 760 ? 0xffff00 : value > 760 ? 0xff0000 : 0x00ff00;

       let pressere_changes = changesPressure(pressure_array);
       if (pressere_changes < 0) {
        pressere_changes_str = "↓"; /*color_pressere = 0xffff00;*/
       }
       if (pressere_changes > 0) {
        pressere_changes_str = "↑"; /*color_pressere = 0xff0000;*/
       }
       //text_pressere_changes.setProperty(hmUI.prop.TEXT, pressere_changes_str);

       let value_str = value == 0 ? "--" : value + pressere_changes_str;
       text_pressere.setProperty(hmUI.prop.TEXT, value_str);
       text_pressere.setProperty(hmUI.prop.COLOR, color_pressere_0);
		  
//       let distanceCurrent = distance.current;
//       distanceCurrent = (distanceCurrent / 1000).toFixed(2);
//		  
//		  normal_line_2_text.setProperty(hmUI.prop.TEXT, Rain +"% " + getWindDescription(Direction) + " " + Speed +" " + value + "мм " + distanceCurrent + "км")
		  
//windDirectionStr
       // app_text_arr[2][1] = String(value);
       //  normal_text_pressure.setProperty(hmUI.prop.TEXT, String(value));
//       Line_arr[2][1] = value;
//       Line_arr[2][2] = value;
		  //return: value
      }


      // Параметры системы
      const SQUARE_SIZE = 112;
      const INNER_DIAMETER = 302; // Диаметр для центров квадратов
      const OUTER_DIAMETER = D_W; // Диаметр главной окружности
      const OFFSET = -6; // Намеренный сдвиг 

      // Генерация 5 конфигураций (без последнего элемента)
      const tapConfigs = Array.from({
       length: 6
      }, (_, i) => {
       // Угол: -90° + шаг 60° (первый квадрат сверху)
       const angle = -Math.PI / 2 + i * (2 * Math.PI / 6);

       // Центр квадрата (на окружности INNER_DIAMETER)
       const centerX = (OUTER_DIAMETER / 2) + (INNER_DIAMETER / 2) * Math.cos(angle);
       const centerY = (OUTER_DIAMETER / 2) + (INNER_DIAMETER / 2) * Math.sin(angle);

       // Левый верхний угол квадрата с поправкой (-6, -6)
       const x = Math.round(centerX - SQUARE_SIZE / 2) + OFFSET;
       const y = Math.round(centerY - SQUARE_SIZE / 2) + OFFSET;

       // Определение defaultType и смещения подсказок
       let defaultType, tipsY;
       switch (i) {
        case 0:
         defaultType = 19;
         tipsY = 130;
         break; // Верхний
        case 1:
         defaultType = 20;
         tipsY = 130;
         break; // Верхний правый
        case 2:
         defaultType = 24;
         tipsY = -62;
         break; // Нижний правый
        case 3:
         defaultType = 11;
         tipsY = -64;
         break; // Нижний (особый сдвиг -64)
        case 4:
         defaultType = 35;
         tipsY = -62;
         break; // Нижний левый
        case 5:
         defaultType = 0;
         tipsY = 130;
         break; // Нижний левый
         
       }

       return {
        id: 101 + i,
        x: x,
        y: y,
        defaultType: defaultType,
        tipsX: -35, // Общее смещение по X для всех
        tipsY: tipsY // Индивидуальное по Y
       };
      });
      // Результат (можно раскомментировать последний элемент, если нужно все 6)


      // Генерация 6 квадратов
      const tapPositions = Array.from({
       length: 6
      }, (_, i) => {
       // Угол: -90° + шаг 60° (первый квадрат сверху)
       const angle = -Math.PI / 2 + i * (2 * Math.PI / 6);

       // Центр квадрата (на окружности INNER_DIAMETER)
       const centerX = (OUTER_DIAMETER / 2) + (INNER_DIAMETER / 2) * Math.cos(angle);
       const centerY = (OUTER_DIAMETER / 2) + (INNER_DIAMETER / 2) * Math.sin(angle);

       // Левый верхний угол квадрата
       return {
        x: Math.round(centerX - SQUARE_SIZE / 2),
        y: Math.round(centerY - SQUARE_SIZE / 2),
        index: i
       };
      });


      // 1. Создаём массив для хранения результатов
      const tapSelections = [];

      // 2. Проходим по всем конфигам последовательно
      for (let i = 0; i < tapConfigs.length; i++) {
       const config = tapConfigs[i];

       // 3. Создаём виджет
       const edit = hmUI.createWidget(hmUI.widget.WATCHFACE_EDIT_GROUP, {
        edit_id: config.id,
        x: config.x,
        y: config.y,
        w: 124,
        h: 124,
        select_image: 'tap/edit_red_1.png',
        un_select_image: 'tap/edit_griin_1.png',
        default_type: config.defaultType,
        optional_types: apps.map((app, index) => ({
         type: index,
         preview: app[2],
         title_en: app[0]
        })),
        count: apps.length,
        tips_x: config.tipsX,
        tips_y: config.tipsY,
        tips_width: 195,
        tips_margin: 10,
        tips_BG: 'tap/tips_bg.png'
       });

       // 4. Даём время на инициализацию (если нужно)
       let counter = 0;
       while (counter < 1000) counter++; // Микро-задержка

       // 5. Получаем текущий тип и сохраняем
       tapSelections[i] = edit.getProperty(hmUI.prop.CURRENT_TYPE);

      }

      // Создаем группу для Tap интерфейса (только 5 элементов: 0,1,2,3,5)


      function createTapInterface() {
      
       groupTap = hmUI.createWidget(hmUI.widget.GROUP, {
        x: 0,
        y: 0,
        w: D_W,
        h: D_H,
        show_level: hmUI.show_level.ONLY_NORMAL
       });
       
       
    i_tap_bg_img = groupTap.createWidget(hmUI.widget.IMG, {
         x: 0,
         y: 0,
         w: D_W,
         h: D_H,
         src: 'tap/i_tap_bg.png',
         show_level: hmUI.show_level.ONLY_NORMAL,
        });      
       

       for (let i = 0; i < 6; i++) {
        // if (i === 4) continue; // Пропускаем 5-й элемент

        const pos = tapPositions[i];
        const appIndex = tapSelections[i];

        // Иконка приложения
        groupTap.createWidget(hmUI.widget.IMG, {
         x: pos.x,
         y: pos.y,
         src: apps[appIndex][2],
         show_level: hmUI.show_level.ONLY_NORMAL,
        });

        // Кнопка (невидимая, но кликабельная)
        groupTap.createWidget(hmUI.widget.BUTTON, {
         x: pos.x,
         y: pos.y,
         w: 113,
         h: 113,
         normal_src: '0_Empty.png',
         press_src: '0_Empty.png',
         click_func: () => {
          vibro();
          const app = apps[appIndex];
          hmApp.startApp({
           appid: app[3] === 0 ? '' : app[1],
           url: app[3] === 0 ? app[1] : app[4],
           native: app[3] === 0,
           params: app[3] === 0 ? null : {
            from_wf: true
           },
          });
         },
         show_level: hmUI.show_level.ONLY_NORMAL,
        });
       }

       return groupTap;
      }
      
      
      
        // end user_functions.js

        let normal_image_img = ''
        let normal_hour_TextRotate = new Array(2);
        let normal_hour_TextRotate_ASCIIARRAY = new Array(10);
        let normal_hour_TextRotate_img_width = 178;
        let normal_H2 = ''
        let normal_H1 = ''
        let idle_H2 = ''
        let idle_H1 = ''
        let normal_time_minute_text_font = ''
        let normal_timerTimeUpdate = undefined;
        let normal_time_second_text_font = ''
        let normal_battery_current_text_font = ''
        let normal_dow_text_font = ''
        let normal_DOW_Array = ['ПОНЕДЕЛЬНИК', 'ВТОРНИК', 'СРЕДА', 'ЧЕТВЕРГ', 'ПЯТНИЦА', 'СУББОТА', 'ВОСКРЕСЕНЬЕ'];
        let normal_month_name_font = ''
        let normal_Month_Array = ['ЯНВ', 'ФЕВ', 'МАР', 'АПР', 'МАЙ', 'ИЮН', 'ИЮЛ', 'АВГ', 'СЕН', 'ОКТ', 'НОЯ', 'ДЕК', ];
        let normal_day_text_font = ''
        let normal_heart_rate_text_font = ''
        let normal_step_current_text_font = ''
        let normal_distance_current_text_font = ''
        let normal_city_name_text = ''
        let normal_weather_image_progress_img_level = ''
        let normal_temperature_current_text_font = ''
        let normal_alarm_clock_text_text_img = ''
        let normal_system_disconnect_img = ''
        let normal_system_clock_img = ''
        let idle_background_bg = ''
        let idle_image_img = ''
        let idle_hour_TextRotate = new Array(2);
        let idle_hour_TextRotate_ASCIIARRAY = new Array(10);
        let idle_hour_TextRotate_img_width = 178;
        let idle_timerTextUpdate = undefined;
        let idle_digital_clock_img_time_hour = ''
        let idle_time_minute_text_font = ''
        let idle_timerTimeUpdate = undefined;
        let idle_time_second_text_font = ''
        let idle_battery_current_text_font = ''
        let idle_dow_text_font = ''
        let idle_DOW_Array = ['ПОНЕДЕЛЬНИК', 'ВТОРНИК', 'СРЕДА', 'ЧЕТВЕРГ', 'ПЯТНИЦА', 'СУББОТА', 'ВОСКРЕСЕНЬЕ'];
        let idle_month_name_font = ''
        let idle_Month_Array = ['ЯНВ', 'ФЕВ', 'МАР', 'АПР', 'МАЙ', 'ИЮН', 'ИЮЛ', 'АВГ', 'СЕН', 'ОКТ', 'НОЯ', 'ДЕК', ];
        let idle_day_text_font = ''
        let idle_heart_rate_text_font = ''
        let idle_step_current_text_font = ''
        let idle_distance_current_text_font = ''
        let idle_city_name_text = ''
        let idle_weather_image_progress_img_level = ''
        let idle_temperature_current_text_font = ''
        let idle_alarm_clock_text_text_img = ''
        let idle_system_disconnect_img = ''
        let idle_system_clock_img = ''
        let timeSensor = '';


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            // FontName: Barlow_Medium.ttf; FontSize: 117
            hmUI.createWidget(hmUI.widget.TEXT, {
              x: 464,
              y: 464,
              w: 1516,
              h: 190,
              text_size: 117,
              char_space: 0,
              line_space: 0,
              font: 'fonts/Barlow_Medium.ttf',
              color: 0xFF80FF00,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              text: "0123456789 _-.,:;`'%°\\/",
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // FontName: Barlow_Medium.ttf; FontSize: 44
            hmUI.createWidget(hmUI.widget.TEXT, {
              x: 464,
              y: 464,
              w: 571,
              h: 72,
              text_size: 44,
              char_space: 0,
              line_space: 0,
              font: 'fonts/Barlow_Medium.ttf',
              color: 0xFFFFFFFF,
              align_h: hmUI.align.LEFT,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              text: "0123456789 _-.,:;`'%°\\/C",
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // FontName: Barlow_Medium.ttf; FontSize: 33
            hmUI.createWidget(hmUI.widget.TEXT, {
              x: 464,
              y: 464,
              w: 429,
              h: 54,
              text_size: 33,
              char_space: 0,
              line_space: 0,
              font: 'fonts/Barlow_Medium.ttf',
              color: 0xFFFFFFFF,
              align_h: hmUI.align.LEFT,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              text: "0123456789 _-.,:;`'%°\\/",
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // FontName: DIN Alternate Bold.ttf; FontSize: 26; Cache: full
            hmUI.createWidget(hmUI.widget.TEXT, {
              x: 464,
              y: 464,
              w: 31,
              h: 31,
              text_size: 26,
              char_space: 0,
              line_space: 0,
              font: 'fonts/DIN Alternate Bold.ttf',
              color: 0xFFFFFFFF,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.NONE,
              text: "0123456789 ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz АБВГДЕЁЖЗИЙКЛМНОПРСТУФХЦЧШЩЪЫЬЭЮЯабвгдеёжзийклмнопрстуфхцчшщъыьэюя  ҐЄІЇґєії _-.,:;`'%°\\/",
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // FontName: DIN Alternate Bold.ttf; FontSize: 41; Cache: full
            hmUI.createWidget(hmUI.widget.TEXT, {
              x: 464,
              y: 464,
              w: 49,
              h: 49,
              text_size: 41,
              char_space: 0,
              line_space: 0,
              font: 'fonts/DIN Alternate Bold.ttf',
              color: 0xFFFFFFFF,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.NONE,
              text: "0123456789 ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz АБВГДЕЁЖЗИЙКЛМНОПРСТУФХЦЧШЩЪЫЬЭЮЯабвгдеёжзийклмнопрстуфхцчшщъыьэюя  ҐЄІЇґєії _-.,:;`'%°\\/",
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // FontName: DIN Alternate Bold.ttf; FontSize: 43
            hmUI.createWidget(hmUI.widget.TEXT, {
              x: 464,
              y: 464,
              w: 506,
              h: 60,
              text_size: 43,
              char_space: 0,
              line_space: 0,
              font: 'fonts/DIN Alternate Bold.ttf',
              color: 0xFF80FF00,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              text: "0123456789 _-.,:;`'%°\\/",
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // FontName: DIN Alternate Bold.ttf; FontSize: 30; Cache: full
            hmUI.createWidget(hmUI.widget.TEXT, {
              x: 464,
              y: 464,
              w: 36,
              h: 36,
              text_size: 30,
              char_space: 0,
              line_space: 0,
              font: 'fonts/DIN Alternate Bold.ttf',
              color: 0xFF80FF00,
              align_h: hmUI.align.LEFT,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.NONE,
              text: "0123456789 ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz АБВГДЕЁЖЗИЙКЛМНОПРСТУФХЦЧШЩЪЫЬЭЮЯабвгдеёжзийклмнопрстуфхцчшщъыьэюя  ҐЄІЇґєії _-.,:;`'%°\\/",
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // FontName: DIN Alternate Bold.ttf; FontSize: 40
            hmUI.createWidget(hmUI.widget.TEXT, {
              x: 464,
              y: 464,
              w: 470,
              h: 56,
              text_size: 40,
              char_space: 0,
              line_space: 0,
              font: 'fonts/DIN Alternate Bold.ttf',
              color: 0xFF80FF00,
              align_h: hmUI.align.LEFT,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              text: "0123456789 ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz АБВГДЕЁЖЗИЙКЛМНОПРСТУФХЦЧШЩЪЫЬЭЮЯабвгдеёжзийклмнопрстуфхцчшщъыьэюя  ҐЄІЇґєії _-.,:;`'%°\\/",
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // FontName: DIN Alternate Bold.ttf; FontSize: 44; Cache: full
            hmUI.createWidget(hmUI.widget.TEXT, {
              x: 464,
              y: 464,
              w: 52,
              h: 52,
              text_size: 44,
              char_space: 0,
              line_space: 0,
              font: 'fonts/DIN Alternate Bold.ttf',
              color: 0xFFFFFFFF,
              align_h: hmUI.align.LEFT,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.NONE,
              text: "0123456789 ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz АБВГДЕЁЖЗИЙКЛМНОПРСТУФХЦЧШЩЪЫЬЭЮЯабвгдеёжзийклмнопрстуфхцчшщъыьэюя  ҐЄІЇґєії _-.,:;`'%°\\/",
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // FontName: DIN Alternate Bold.ttf; FontSize: 22; Cache: full
            hmUI.createWidget(hmUI.widget.TEXT, {
              x: 464,
              y: 464,
              w: 26,
              h: 26,
              text_size: 22,
              char_space: 0,
              line_space: 0,
              font: 'fonts/DIN Alternate Bold.ttf',
              color: 0xFFFFFFFF,
              align_h: hmUI.align.LEFT,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.NONE,
              text: "0123456789 ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz АБВГДЕЁЖЗИЙКЛМНОПРСТУФХЦЧШЩЪЫЬЭЮЯабвгдеёжзийклмнопрстуфхцчшщъыьэюя  ҐЄІЇґєії _-.,:;`'%°\\/",
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            console.log('user_script_start.js');
            // start user_script_start.js

loadSettings()

        hmUI.createWidget(hmUI.widget.TEXT, {
         x: 464,
         y: 464,
         w: 42,
         h: 42,
         text_size: 27,
         char_space: 0,
         line_space: 0,
         font: 'fonts/Bebas22.ttf',
         color: 0xFFFFFF00,
         align_h: hmUI.align.LEFT,
         align_v: hmUI.align.CENTER_V,
         text_style: hmUI.text_style.NONE,
         text: "0123456789 ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz АБВГДЕЁЖЗИЙКЛМНОПРСТУФХЦЧШЩЪЫЬЭЮЯабвгдеёжзийклмнопрстуфхцчшщъыьэюя  ҐЄІЇґєії _-.,:;`'%°\\/",
         show_level: hmUI.show_level.ONLY_NORMAL,
        });

        hmUI.createWidget(hmUI.widget.TEXT, {
         x: 464,
         y: 464,
         w: 42,
         h: 42,
         text_size: 33,
         char_space: 0,
         line_space: 0,
         font: 'fonts/Bebas22.ttf',
         color: 0xFFFFFF00,
         align_h: hmUI.align.LEFT,
         align_v: hmUI.align.CENTER_V,
         text_style: hmUI.text_style.NONE,
         text: "0123456789 ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz АБВГДЕЁЖЗИЙКЛМНОПРСТУФХЦЧШЩЪЫЬЭЮЯабвгдеёжзийклмнопрстуфхцчшщъыьэюя  ҐЄІЇґєії _-.,:;`'%°\\/",
         show_level: hmUI.show_level.ONLY_NORMAL,
        });

        hmUI.createWidget(hmUI.widget.TEXT, {
         x: 464,
         y: 464,
         w: 328,
         h: 48,
         text_size: 35,
         char_space: 0,
         line_space: 0,
         font: 'fonts/Bebas22.ttf',
         color: 0xFFFFFFFF,
         align_h: hmUI.align.CENTER_H,
         align_v: hmUI.align.CENTER_V,
         text_style: hmUI.text_style.ELLIPSIS,
         text: "0123456789 ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz АБВГДЕЁЖЗИЙКЛМНОПРСТУФХЦЧШЩЪЫЬЭЮЯабвгдеёжзийклмнопрстуфхцчшщъыьэюя  ҐЄІЇґєії _-.,:;`'%°\\/",
         show_level: hmUI.show_level.ONLY_NORMAL,
        });

if (screenTypeJS == hmSetting.screen_type.WATCHFACE) {
    normal_background = hmUI.createWidget(hmUI.widget.FILL_RECT, {
        x: 0,
        y: 0,
        w: 466,
        h: 466,
        color: color_bg[0][CONF_MAIN[0].id],
        //color: 0xFFFF0000,
        show_level: hmUI.show_level.ONLY_NORMAL,
    });
}
            // end user_script_start.js

            console.log('Watch_Face.ScreenNormal');

            normal_image_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'bg.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });



            if (!timeSensor) timeSensor = hmSensor.createSensor(hmSensor.id.TIME);
            let screenType = hmSetting.getScreenType();

        normal_H2 = hmUI.createWidget(hmUI.widget.IMG, {
         x: 33-2,
         y: 125-2,
         src: 'H2_0.png',
         show_level: hmUI.show_level.ONLY_NORMAL,
        });
				
        normal_H1 = hmUI.createWidget(hmUI.widget.IMG, {
         x: -3,
         y: 164,
         src: 'H1_0.png',
         show_level: hmUI.show_level.ONLY_NORMAL,
        });

            normal_H1.setAlpha(128);
            
            
            normal_time_minute_text_font = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 219,
              y: 52,
              w: 150,
              h: 150,
              text_size: 117,
              char_space: 0,
              line_space: 0,
              font: 'fonts/Barlow_Medium.ttf',
          color: color_bg[0][CONF_MAIN[0].id],
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              // padding: true,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_time_second_text_font = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 367,
              y: 83,
              w: 150,
              h: 60,
              text_size: 44,
              char_space: 0,
              line_space: 0,
              font: 'fonts/Barlow_Medium.ttf',
              color: 0xFFFFFFFF,
              align_h: hmUI.align.LEFT,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              // padding: true,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_current_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 367,
              y: 132,
              w: 150,
              h: 60,
              text_size: 33,
              char_space: 0,
              line_space: 0,
              font: 'fonts/Barlow_Medium.ttf',
              color: 0xFFFFFFFF,
              align_h: hmUI.align.LEFT,
              align_v: hmUI.align.CENTER_V,
              unit_type: 1,
              text_style: hmUI.text_style.ELLIPSIS,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            timeSensor.addEventListener(timeSensor.event.DAYCHANGE, function() {
              time_update(true);
            });

            normal_dow_text_font = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 184,
              y: 178,
              w: 300,
              h: 50,
              text_size: 26,
              char_space: 0,
              line_space: 0,
              font: 'fonts/DIN Alternate Bold.ttf',
              color: 0xFFFFFFFF,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              // unit_string: ПОНЕДЕЛЬНИК, ВТОРНИК, СРЕДА, ЧЕТВЕРГ, ПЯТНИЦА, СУББОТА, ВОСКРЕСЕНЬЕ,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_month_name_font = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 36,
              y: 71,
              w: 150,
              h: 60,
              text_size: 41,
              char_space: 0,
              line_space: 0,
              font: 'fonts/DIN Alternate Bold.ttf',
              color: 0xFFFFFFFF,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              // unit_string: ЯНВ, ФЕВ, МАР, АПР, МАЙ, ИЮН, ИЮЛ, АВГ, СЕН, ОКТ, НОЯ, ДЕК,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_day_text_font = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 113,
              y: 69,
              w: 150,
              h: 60,
              text_size: 43,
              char_space: 0,
              line_space: 0,
              font: 'fonts/DIN Alternate Bold.ttf',
          color: color_bg[0][CONF_MAIN[0].id],
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              // padding: true,
              // unit_string: ЯНВ, ФЕВ, МАР, АПРП, МАЙ, ИЮН, ИЮЛ, АВГ, СЕН, ОКТ, НОЯ, ДЕК,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_font = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 233,
              y: 402,
              w: 300,
              h: 60,
              text_size: 30,
              char_space: 0,
              line_space: 0,
              font: 'fonts/DIN Alternate Bold.ttf',
          color: color_bg[0][CONF_MAIN[0].id],
              align_h: hmUI.align.LEFT,
              align_v: hmUI.align.CENTER_V,
              unit_type: 0,
              text_style: hmUI.text_style.ELLIPSIS,
             // type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_text_font = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 233,
              y: 358,
              w: 300,
              h: 60,
              text_size: 40,
              char_space: 0,
              line_space: 0,
              font: 'fonts/DIN Alternate Bold.ttf',
          color: color_bg[0][CONF_MAIN[0].id],
              align_h: hmUI.align.LEFT,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              //type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_distance_current_text_font = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 233,
              y: 317,
              w: 300,
              h: 60,
              text_size: 44,
              char_space: 0,
              line_space: 0,
              font: 'fonts/DIN Alternate Bold.ttf',
              color: 0xFFFFFFFF,
              align_h: hmUI.align.LEFT,
              align_v: hmUI.align.CENTER_V,
              unit_type: 0,
              text_style: hmUI.text_style.ELLIPSIS,
              //type: hmUI.data_type.DISTANCE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
              const weatherSensor = hmSensor.createSensor(hmSensor.id.WEATHER);

            normal_city_name_text = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 234,
              y: 295,
              w: 300,
              h: 50,
              text_size: 22,
              char_space: 0,
              line_space: 0,
              font: 'fonts/DIN Alternate Bold.ttf',
              color: 0xFFFFFFFF,
              align_h: hmUI.align.LEFT,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              // unit_type: 1,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 237,
              y: 229,
              image_array: ["w_0.png","w_1.png","w_2.png","w_3.png","w_4.png","w_5.png","w_6.png","w_7.png","w_8.png","w_9.png","w_10.png","w_11.png","w_12.png","w_13.png","w_14.png","w_15.png","w_16.png","w_17.png","w_18.png","w_19.png","w_20.png","w_21.png","w_22.png","w_23.png","w_24.png","w_25.png","w_26.png","w_27.png","w_28.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_text_font = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 309,
              y: 222,
              w: 150,
              h: 60,
              text_size: 44,
              char_space: 0,
              line_space: 0,
              font: 'fonts/Barlow_Medium.ttf',
          color: color_bg[0][CONF_MAIN[0].id],
              align_h: hmUI.align.LEFT,
              align_v: hmUI.align.CENTER_V,
              padding: true,
              unit_type: 0,
              text_style: hmUI.text_style.ELLIPSIS,
              //type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_alarm_clock_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 213,
              y: 49,
              font_array: ["AL_0.png","AL_1.png","AL_2.png","AL_3.png","AL_4.png","AL_5.png","AL_6.png","AL_7.png","AL_8.png","AL_9.png"],
              padding: true,
              h_space: 0,
              invalid_image: 'AL_11.png',
              dot_image: 'AL_10.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.ALARM_CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 214,
              y: 13,
              src: 'stat_B_off.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 170,
              y: 45,
              src: 'stat_H_on.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            console.log('Watch_Face.ScreenAOD');
            idle_background_bg = hmUI.createWidget(hmUI.widget.FILL_RECT, {
              x: 0,
              y: 0,
              w: 466,
              h: 466,
              color: '0xFFFFFFFF',
              show_level: hmUI.show_level.ONLY_AOD,
            });

hmUI.createWidget(hmUI.widget.FILL_RECT, {
         x: 238,
         y: 228,
         w: 54,
         h: 56,
          color: color_bg[0][CONF_MAIN[0].id],
          //color: 0xFFFF0000,
		 show_level: hmUI.show_level.ONLY_AOD,
        });


            idle_image_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'bg.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });


            
            
        idle_H2 = hmUI.createWidget(hmUI.widget.IMG, {
         x: 33-2,
         y: 125-2,
         src: 'H2_0.png',
         show_level: hmUI.show_level.ONLY_AOD,
        });
				
        idle_H1 = hmUI.createWidget(hmUI.widget.IMG, {
         x: -3,
         y: 164,
         src: 'H1_0.png',
         show_level: hmUI.show_level.ONLY_AOD,
        });

            idle_H1.setAlpha(128);
            
            

            idle_time_minute_text_font = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 219,
              y: 52,
              w: 150,
              h: 150,
              text_size: 117,
              char_space: 0,
              line_space: 0,
              font: 'fonts/Barlow_Medium.ttf',
              color: 0xFFFFFFFF,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              // padding: true,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_time_second_text_font = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 367,
              y: 83,
              w: 150,
              h: 60,
              text_size: 44,
              char_space: 0,
              line_space: 0,
              font: 'fonts/Barlow_Medium.ttf',
              color: 0xFFFFFFFF,
              align_h: hmUI.align.LEFT,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              // padding: true,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_battery_current_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 367,
              y: 132,
              w: 150,
              h: 60,
              text_size: 33,
              char_space: 0,
              line_space: 0,
              font: 'fonts/Barlow_Medium.ttf',
              color: 0xFFFFFFFF,
              align_h: hmUI.align.LEFT,
              align_v: hmUI.align.CENTER_V,
              unit_type: 1,
              text_style: hmUI.text_style.ELLIPSIS,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_dow_text_font = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 184,
              y: 178,
              w: 300,
              h: 50,
              text_size: 26,
              char_space: 0,
              line_space: 0,
              font: 'fonts/DIN Alternate Bold.ttf',
              color: 0xFFFFFFFF,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              // unit_string: ПОНЕДЕЛЬНИК, ВТОРНИК, СРЕДА, ЧЕТВЕРГ, ПЯТНИЦА, СУББОТА, ВОСКРЕСЕНЬЕ,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_month_name_font = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 36,
              y: 71,
              w: 150,
              h: 60,
              text_size: 41,
              char_space: 0,
              line_space: 0,
              font: 'fonts/DIN Alternate Bold.ttf',
              color: 0xFFFFFFFF,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              // unit_string: ЯНВ, ФЕВ, МАР, АПР, МАЙ, ИЮН, ИЮЛ, АВГ, СЕН, ОКТ, НОЯ, ДЕК,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_day_text_font = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 113,
              y: 69,
              w: 150,
              h: 60,
              text_size: 43,
              char_space: 0,
              line_space: 0,
              font: 'fonts/DIN Alternate Bold.ttf',
              color: 0xFFFFFFFF,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              // padding: true,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_heart_rate_text_font = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 233,
              y: 402,
              w: 300,
              h: 60,
              text_size: 30,
              char_space: 0,
              line_space: 0,
              font: 'fonts/DIN Alternate Bold.ttf',
              color: 0xFFFFFFFF,
              align_h: hmUI.align.LEFT,
              align_v: hmUI.align.CENTER_V,
             // unit_type: 1,
              text_style: hmUI.text_style.ELLIPSIS,
             // type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_step_current_text_font = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 233,
              y: 358,
              w: 300,
              h: 60,
              text_size: 40,
              char_space: 0,
              line_space: 0,
              font: 'fonts/DIN Alternate Bold.ttf',
              color: 0xFFFFFFFF,
              align_h: hmUI.align.LEFT,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              //type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_distance_current_text_font = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 233,
              y: 317,
              w: 300,
              h: 60,
              text_size: 44,
              char_space: 0,
              line_space: 0,
              font: 'fonts/DIN Alternate Bold.ttf',
              color: 0xFFFFFFFF,
              align_h: hmUI.align.LEFT,
              align_v: hmUI.align.CENTER_V,
              //unit_type: 1,
              text_style: hmUI.text_style.ELLIPSIS,
             // type: hmUI.data_type.DISTANCE,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_city_name_text = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 234,
              y: 295,
              w: 300,
              h: 50,
              text_size: 22,
              char_space: 0,
              line_space: 0,
              font: 'fonts/DIN Alternate Bold.ttf',
              color: 0xFFFFFFFF,
              align_h: hmUI.align.LEFT,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 237,
              y: 229,
              image_array: ["w_0.png","w_1.png","w_2.png","w_3.png","w_4.png","w_5.png","w_6.png","w_7.png","w_8.png","w_9.png","w_10.png","w_11.png","w_12.png","w_13.png","w_14.png","w_15.png","w_16.png","w_17.png","w_18.png","w_19.png","w_20.png","w_21.png","w_22.png","w_23.png","w_24.png","w_25.png","w_26.png","w_27.png","w_28.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_temperature_current_text_font = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 309,
              y: 222,
              w: 150,
              h: 60,
              text_size: 44,
              char_space: 0,
              line_space: 0,
              font: 'fonts/Barlow_Medium.ttf',
              color: 0xFFFFFFFF,
              align_h: hmUI.align.LEFT,
              align_v: hmUI.align.CENTER_V,
              padding: true,
             // unit_type: 1,
              text_style: hmUI.text_style.ELLIPSIS,
             // type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_alarm_clock_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 213,
              y: 49,
              font_array: ["AL_0.png","AL_1.png","AL_2.png","AL_3.png","AL_4.png","AL_5.png","AL_6.png","AL_7.png","AL_8.png","AL_9.png"],
              padding: true,
              h_space: 0,
              invalid_image: 'AL_11.png',
              dot_image: 'AL_10.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.ALARM_CLOCK,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 214,
              y: 13,
              src: 'stat_B_off.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 170,
              y: 45,
              src: 'stat_H_on.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            console.log('user_script_beforeShortcuts.js');
            // start user_script_beforeShortcuts.js

// Initialize tap interface

       
        bg_edit_img = hmUI.createWidget(hmUI.widget.IMG, {
         x: 0,
         y: 0,
         src: 'tap/bg_edit.png',
         show_level: hmUI.show_level.ONLY_EDIT,
        });   
       
        
        
                if (screenTypeJS == hmSetting.screen_type.WATCHFACE) {
       groupTap = createTapInterface();
        
        groupVremya = hmUI.createWidget(hmUI.widget.GROUP, {
         x: 0,
         y: 0,
         w: D_W,
         h: D_H,
        }); //

        btn_tap = groupVremya.createWidget(hmUI.widget.BUTTON, {
         x: 183,
         y: 0,
         text: '',
         w: 100,
         h: 100,
         normal_src: '0_Empty.png',
         press_src: '0_Empty.png',
         click_func: () => {
          vibro();
          tap_run();
         },
         show_level: hmUI.show_level.ONLY_NORMAL,
        });

        btn_str = groupVremya.createWidget(hmUI.widget.BUTTON, {
         x: 183, //x кнопки
         y: 183, //y кнопки
         text: '',
         w: 100, //ширина кнопки
         h: 100, //высота кнопки
         normal_src: '0_Empty.png',
         press_src: '0_Empty.png',
         click_func: () => {
          vibro();
          click_Pogoda_on();
         },
         //           longpress_func: () => {
         //            vibro();
         //			   blok_btn_on();
         //           },
         show_level: hmUI.show_level.ONLY_NORMAL,
        });

        btn_Activ = groupVremya.createWidget(hmUI.widget.BUTTON, {
         x: 183, //x кнопки
         y: 366, //y кнопки
         text: '',
         w: 100, //ширина кнопки
         h: 100, //высота кнопки
         normal_src: '0_Empty.png',
         press_src: '0_Empty.png',
         click_func: () => {
          vibro();
          click_Activ_on();
         },
         //           longpress_func: () => {
         //            vibro();
         //			   blok_btn_on();
         //           },
         show_level: hmUI.show_level.ONLY_NORMAL,
        });

        btn_sleep = groupVremya.createWidget(hmUI.widget.BUTTON, {
         x: 372, //x кнопки
         y: 186, //y кнопки
         text: '',
         w: 94, //ширина кнопки
         h: 94, //высота кнопки
         normal_src: '0_Empty.png',
         press_src: '0_Empty.png',
         click_func: () => {
          vibro();
          click_sleep();
         },
//                    longpress_func: () => {
//                     vibro();
//         			   click_sleep();
//                    },
         show_level: hmUI.show_level.ONLY_NORMAL,
        });


        btn_click_tap_exit = groupTap.createWidget(hmUI.widget.BUTTON, {
         x: 183,
         y: 183,
         text: '',
         w: 100,
         h: 100,
         normal_src: '0_Empty.png',
         press_src: '0_Empty.png',
         click_func: () => {
          vibro();
          tap_zona_exit();
         },
         show_level: hmUI.show_level.ONLY_NORMAL,
        });


        groupSleep = hmUI.createWidget(hmUI.widget.GROUP, {
         x: 0,
         y: 0,
         w: D_W,
         h: D_H,
        }); // ы


        normal_Sleep_bg = groupSleep.createWidget(hmUI.widget.FILL_RECT, {
         x: 72,
         y: 99,
         w: 322,
         h: 200,
         color: 0x000000,
         radius: 20,
         alpha: 178,
         show_level: hmUI.show_level.ONLY_NORMAL,
        });


        sleep_time_txt = groupSleep.createWidget(hmUI.widget.TEXT, {
         x: 0, // координата X
         y: 108, // координата Y
         w: 466, // ширина 	
         h: 40, // высота	
         text_size: 27, // размер текста
         text: '',
         font: 'fonts/Bebas22.ttf',
         color: 0xffffff, // цвет текста
         align_h: hmUI.align.CENTER_H,
         show_level: hmUI.show_level.ONLY_NORMAL,
        });

        groupSleep.createWidget(hmUI.widget.TEXT, {
         x: 103, // координата X
         y: 144, // координата Y
         w: 466, // ширина 	
         h: 40, // высота	
         text_size: 27, // размер текста
         text: 'ЗАСНУЛИ',
         font: 'fonts/Bebas22.ttf',
         color: 0x00ff00, // цвет текста
         align_h: hmUI.align.LEFT,
         show_level: hmUI.show_level.ONLY_NORMAL,
        });

        groupSleep.createWidget(hmUI.widget.TEXT, {
         x: -105, // координата X
         y: 144, // координата Y
         w: 466, // ширина 	
         h: 40, // высота	
         text_size: 27, // размер текста
         text: 'ПРОСНУЛИСЬ',
         font: 'fonts/Bebas22.ttf',
         color: 0xe779ff, // цвет текста
         align_h: hmUI.align.RIGHT,
         show_level: hmUI.show_level.ONLY_NORMAL,
        });


        sleep_start_time_txt = groupSleep.createWidget(hmUI.widget.TEXT, {
         x: 103,
         y: 181,
         w: 466, // ширина 	
         h: 40,
         text_size: 27,
         text: '',
         font: 'fonts/Bebas22.ttf',
         color: 0x00ff00,
         align_h: hmUI.align.LEFT,
         show_level: hmUI.show_level.ONLY_NORMAL,
        });


        sleep_end_time_txt = groupSleep.createWidget(hmUI.widget.TEXT, {
         x: -105, // координата X
         y: 181,
         w: 466, // ширина 	
         h: 40,
         text_size: 27,
         text: '',
         font: 'fonts/Bebas22.ttf',
         color: 0xe779ff,
         align_h: hmUI.align.RIGHT,
         show_level: hmUI.show_level.ONLY_NORMAL,
        });

        wake_time_txt = groupSleep.createWidget(hmUI.widget.TEXT, {
         x: 0,
         y: 217,
         w: 466,
         h: 40,
         text_size: 27,
         font: 'fonts/Bebas22.ttf',
         text: '',
         color: 0xff4949,
         align_h: hmUI.align.CENTER_H,
         show_level: hmUI.show_level.ONLY_NORMAL,
        });

        sleep_score_txt = groupSleep.createWidget(hmUI.widget.TEXT, {
         x: 0,
         y: 256,
         w: 466,
         h: 40,
         text_size: 27,
         font: 'fonts/Bebas22.ttf',
         text: '',
         color: 0xffffff,
         align_h: hmUI.align.CENTER_H,
         show_level: hmUI.show_level.ONLY_NORMAL,
        });


        btn_exit_sleep = groupSleep.createWidget(hmUI.widget.BUTTON, {
         x: 0, //x кнопки
         y: 0, //y кнопки
         text: '',
         w: 466, //ширина кнопки
         h: 466, //высота кнопки
         normal_src: '0_Empty.png',
         press_src: '0_Empty.png',
         click_func: () => {
          vibro();
          click_exit_sleep();
         },
         //           longpress_func: () => {
         //            vibro();
         //			   blok_btn_on();
         //           },
         show_level: hmUI.show_level.ONLY_NORMAL,
        });


        normal_background_Pogoda = hmUI.createWidget(hmUI.widget.FILL_RECT, {
         x: 0,
         y: 0,
         w: 466,
         h: 466,
         color: 0x000000,
         show_level: hmUI.show_level.ONLY_NORMAL,
        });
        normal_background_Pogoda.setProperty(hmUI.prop.VISIBLE, false);

        //---------------------------    погода
        groupPogoda = hmUI.createWidget(hmUI.widget.GROUP, {
         x: 0,
         y: 0,
         w: D_W,
         h: D_H,
         show_level: hmUI.show_level.ONLY_NORMAL,
        });

        canvas = groupPogoda.createWidget(hmUI.widget.CANVAS, {
         x: 0,
         y: 0,
         w: 466,
         h: 466,
         show_level: hmUI.show_level.ONLY_NORMAL,
        });

        canvas.setPaint({
         color: 0x00ff00,
         line_width: 4
        })


        normal_temp_text_font = groupPogoda.createWidget(hmUI.widget.TEXT, {
         x: 115,
         y: 47 + 5 + 6 + 2 - 29 - 29,
         w: 236,
         h: 32,
         text_size: 27,
         char_space: 0,
         line_space: 0,
         font: 'fonts/Bebas22.ttf',
         color: 0xFFFFFFFF,
         align_h: hmUI.align.CENTER_H,
         align_v: hmUI.align.CENTER_V,
         text_style: hmUI.text_style.NONE,
         show_level: hmUI.show_level.ONLY_NORMAL,
        })

        normal_weather_text_font = groupPogoda.createWidget(hmUI.widget.TEXT, {
         x: 115,
         y: 47 + 5 + 6 + 2 - 29,
         w: 236,
         h: 32,
         text_size: 27,
         char_space: 0,
         line_space: 0,
         font: 'fonts/Bebas22.ttf',
         color: 0xFFFFFFFF,
         align_h: hmUI.align.CENTER_H,
         align_v: hmUI.align.CENTER_V,
         text_style: hmUI.text_style.NONE,
         show_level: hmUI.show_level.ONLY_NORMAL,
        })

        normal_city_name_text_0 = groupPogoda.createWidget(hmUI.widget.TEXT, {
         x: 74,
         y: 47 + 5 + 6 + 2,
         w: 318,
         h: 32,
         text_size: 27,
         char_space: 0,
         line_space: 0,
         font: 'fonts/Bebas22.ttf',
         color: 0xFFFFFFFF,
         align_h: hmUI.align.CENTER_H,
         align_v: hmUI.align.CENTER_V,
         text_style: hmUI.text_style.NONE,
         show_level: hmUI.show_level.ONLY_NORMAL,
        });


        ic_graf_img = groupPogoda.createWidget(hmUI.widget.IMG, {
         x: 414,
         y: 212,
         src: 'images/Grafik/ic_graf_0.png',
         show_level: hmUI.show_level.ONLY_NORMAL,
        });


        groupPogoda.createWidget(hmUI.widget.CIRCLE, {
         center_x: 31,
         center_y: 233,
         radius: 21,
         color: 0xbdbabd,
         // alpha: color_ic == 0 ? 0 : 255,
         show_level: hmUI.show_level.ONLY_NORMAL,
        });

        fix_gsm_text_font = groupPogoda.createWidget(hmUI.widget.TEXT, {
         x: 10,
         y: 212 + 2,
         w: 42,
         h: 42,
         text: fix_gsm == 0 ? '+0' : '+1',
         text_size: 27,
         char_space: 0,
         line_space: 0,
         font: 'fonts/Bebas22.ttf',
         color: 0x000000,
         align_h: hmUI.align.CENTER_H,
         align_v: hmUI.align.CENTER_V,
         text_style: hmUI.text_style.NONE,
         show_level: hmUI.show_level.ONLY_NORMAL,
        })

    windSpeedText = groupPogoda.createWidget(hmUI.widget.TEXT, {
         x: 0,
         y: 399,
         w: 466,
         h: 40,
         text_size: 35,
         char_space: 0,
         line_space: 0,
         color: 0xFFFFFFFF,
         font: 'fonts/Bebas22.ttf',
         align_h: hmUI.align.CENTER_H,
         align_v: hmUI.align.CENTER_V,
         unit_type: 1,
         text_style: hmUI.text_style.ELLIPSIS,
        // type: hmUI.data_type.WIND,
         show_level: hmUI.show_level.ONLY_NORMAL,
        });
        
  chanceOfRainText = groupPogoda.createWidget(hmUI.widget.TEXT, {
         x: 210,
         y: 357,
         w: 150,
         h: 40,
        // text: '100%',
         text_size: 35,
         char_space: 0,
         line_space: 0,
         color: 0xFFFFFFFF,
         font: 'fonts/Bebas22.ttf',
         align_h: hmUI.align.LEFT,
         align_v: hmUI.align.CENTER_V,
         unit_type: 1,
         text_style: hmUI.text_style.ELLIPSIS,
        // type: hmUI.data_type.HUMIDITY,
         show_level: hmUI.show_level.ONLY_NORMAL,
        });
      
        
        RainImg = groupPogoda.createWidget(hmUI.widget.IMG, {
         x: 169,
         y: 359,
         src: 'images/Grafik/ic_activ/ic_rain_on.png',
         show_level: hmUI.show_level.ONLY_NORMAL,
        });        
        
        
        
				const weatherProvider = new WeatherProvider({
				 //				night_icons: [0, 1, 2, 3, 14],
				 index: 1, // текущий индекс провайдера (сохраняется и считывается из памяти)
				 //				show_toast: false,
				 //				temp_widget: tempText,
				 //				temp_max_widget: tempMaxText,
				 //				temp_min_widget: tempMinText,
				// temp_feels_widget: tempFeelsText,
				icon_widget_Rain: RainImg,
				chance_Of_Rain: chanceOfRainText,
				windSpeed_widget: windSpeedText,
					//				description_widget: descriptionText,
				 //				cityName_widget: cityNameText,
				 //				icon_widget: weatherImg,
				 //				time_sensor: curTime,
				 //				weather_sensor: weather,
				});	


        groupPogoda.createWidget(hmUI.widget.IMG, {
         x: 285,
         y: 360,
         src: ROOTPATH + 'Grafik/ic_activ/ic_davl_txt.png',
         show_level: hmUI.show_level.ONLY_NORMAL,
        });


        groupPogoda.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 12,
              y: 166,
              image_array: ["images/Grafik/ic_activ/uv_0.png","images/Grafik/ic_activ/uv_1.png","images/Grafik/ic_activ/uv_2.png","images/Grafik/ic_activ/uv_3.png","images/Grafik/ic_activ/uv_4.png"],
              image_length: 5,
              type: hmUI.data_type.UVI,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            groupPogoda.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 66,
              y: 358,
              image_array: ["images/Grafik/ic_activ/vl_0.png","images/Grafik/ic_activ/vl_1.png","images/Grafik/ic_activ/vl_2.png","images/Grafik/ic_activ/vl_3.png","images/Grafik/ic_activ/vl_4.png","images/Grafik/ic_activ/vl_5.png","images/Grafik/ic_activ/vl_6.png","images/Grafik/ic_activ/vl_7.png","images/Grafik/ic_activ/vl_8.png","images/Grafik/ic_activ/vl_9.png"],
              image_length: 10,
              type: hmUI.data_type.HUMIDITY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


        groupPogoda.createWidget(hmUI.widget.TEXT_FONT, {
         x: -43,
         y: 265 + 5,
         w: 150,
         h: 30,
         text_size: 27,
         font: 'fonts/Bebas22.ttf',
         char_space: 0,
         line_space: 0,
         color: 0xFFFFFFFF,
         align_h: hmUI.align.CENTER_H,
         align_v: hmUI.align.CENTER_V,
         text_style: hmUI.text_style.ELLIPSIS,
         type: hmUI.data_type.UVI,
         show_level: hmUI.show_level.ONLY_NORMAL,
        });

        groupPogoda.createWidget(hmUI.widget.IMG, {
         x: 420,
         y: 171,
         src: ROOTPATH + 'Grafik/ic_activ/ic_visota.png',
         show_level: hmUI.show_level.ONLY_NORMAL,
        });

        groupPogoda.createWidget(hmUI.widget.TEXT_FONT, {
         x: 359,
         y: 265 + 5,
         w: 150,
         h: 30,
         text_size: 27,
         font: 'fonts/Bebas22.ttf',
         char_space: 0,
         line_space: 0,
         color: 0xFFFFFFFF,
         align_h: hmUI.align.CENTER_H,
         align_v: hmUI.align.CENTER_V,
         text_style: hmUI.text_style.ELLIPSIS,
         type: hmUI.data_type.ALTITUDE,
         show_level: hmUI.show_level.ONLY_NORMAL,
        });

        text_pressere = groupPogoda.createWidget(hmUI.widget.TEXT, {
         x: 347,
         y: 357,
         w: 150,
         h: 40,
         color: 0xffffff,
         font: 'fonts/Bebas22.ttf',
         text_size: 35,
         align_h: hmUI.align.LEFT,
         align_v: hmUI.align.CENTER_V,
         text_style: hmUI.text_style.NONE,
         text: "--",
        });


        groupPogoda.createWidget(hmUI.widget.TEXT_FONT, {
         x: 97,
         y: 357,
         w: 150,
         h: 40,
         text_size: 35,
         char_space: 0,
         line_space: 0,
         color: 0xFFFFFFFF,
         font: 'fonts/Bebas22.ttf',
         align_h: hmUI.align.LEFT,
         align_v: hmUI.align.CENTER_V,
         unit_type: 1,
         text_style: hmUI.text_style.ELLIPSIS,
         type: hmUI.data_type.HUMIDITY,
         show_level: hmUI.show_level.ONLY_NORMAL,
        });


        for (var i = 0; i < dney; i++) {
         week_text[i] = groupPogoda.createWidget(hmUI.widget.TEXT, {
          x: x0 - 3 - 23 + i * 46 * 1.0, //,107 + i * 45 * 1.02,
          y: 295 - 1 + 2, //- 21
          w: 50,
          h: 50,
          char_space: 0, //-1
          line_space: 0,
          color: "0xFFffffff",
          text: week_array[i],
          text_size: 22,
          text_style: hmUI.text_style.NONE,
          align_h: hmUI.align.CENTER_H,
          align_v: hmUI.align.CENTER_V,
          show_level: hmUI.show_level.ONLY_NORMAL
         });
         // hmUI.deleteWidget(data_text[i]);
         data_text[i] = groupPogoda.createWidget(hmUI.widget.TEXT, {
          x: x0 - 3 - 23 + i * 46 * 1.0, //,107 + i * 45 * 1.02,
          y: 295 - 1 + 2 + 20, //- 21
          w: 50,
          h: 50,

          char_space: 0, //-1
          line_space: 0,
          color: "0xFFffffff",
          text: 31,
          text_size: 22,
          text_style: hmUI.text_style.NONE,
          align_h: hmUI.align.CENTER_H,
          align_v: hmUI.align.CENTER_V,
          show_level: hmUI.show_level.ONLY_NORMAL
         });

         weather_ic[i] = groupPogoda.createWidget(hmUI.widget.IMG, {
          x: x0 - 23 + i * shag,
          y: 78 + 10, //- 10
          w: 40,
          h: 40,
          // src: weatherArray[i],
          shortcut: true,
          show_level: hmUI.show_level.ONLY_NORMAL,
         });

         DigDay[i] = groupPogoda.createWidget(hmUI.widget.TEXT);
         if (i < dney - 1) DigNight[i] = groupPogoda.createWidget(hmUI.widget.TEXT);

        }


        btn_Pogoda_off = groupPogoda.createWidget(hmUI.widget.BUTTON, {
         x: 183, //x кнопки
         y: 183, //y кнопки
         text: '',
         w: 100, //ширина кнопки
         h: 100, //высота кнопки
         normal_src: '0_Empty.png',
         press_src: 'press_100.png',
         click_func: () => {
          vibro(); //имя вызываемой функции
          click_Pogoda_off();
         },
         //           longpress_func: () => {
         //            vibro();
         //			   blok_btn_off();
         //           },
         show_level: hmUI.show_level.ONLY_NORMAL,
        });

        btn_tip_grafik = groupPogoda.createWidget(hmUI.widget.BUTTON, {
         x: 366, //x кнопки
         y: 183, //y кнопки
         text: '',
         w: 100, //ширина кнопки
         h: 100, //высота кнопки
         normal_src: '0_Empty.png',
         press_src: 'press_100.png',
         click_func: () => {
          vibro(); //имя вызываемой функции
          click_tip_grafik();
         },
         //           longpress_func: () => {
         //            vibro();
         //			   blok_btn_off();
         //           },
         show_level: hmUI.show_level.ONLY_NORMAL,
        });

        groupPogoda.createWidget(hmUI.widget.BUTTON, {
         x: 0,
         y: 183,
         w: 100,
         h: 100,
         text: '',
         normal_src: 'blank.png',
         press_src: 'images/Grafik/press_100.png',
         click_func: () => {

          vibro(); //имя вызываемой функции
          click_fix_gms();

          //          hmApp.startApp({
          //           appid: 1051195,
          //           url: 'page/index',
          //           params: {
          //            from_wf: true,
          //           }
          //          });

         },
        });

        groupActiv = hmUI.createWidget(hmUI.widget.GROUP, {
         x: 0,
         y: 0,
         w: D_W,
         h: D_H,
        });

        groupActiv.createWidget(hmUI.widget.IMG, {
         x: 0,
         y: 0,
         w: 466,
         h: 466,
         src: 'images/Grafik/bg_activ.png',
         show_level: hmUI.show_level.ONLY_NORMAL,
        });

        Activ_color_alpha = groupActiv.createWidget(hmUI.widget.CIRCLE, {
         center_x: 233,
         center_y: 233,
         radius: 233,
         // color: color_bg_Activ[color_ic],
         color: color_bg[1][color_ic],
         alpha: color_ic == 0 ? 0 : 255,
         show_level: hmUI.show_level.ONLY_NORMAL,
        });

        groupActiv.createWidget(hmUI.widget.IMG, {
         x: 0,
         y: 0,
         w: 466,
         h: 466,
         src: 'images/Grafik/bg_activ_mask.png',
         show_level: hmUI.show_level.ONLY_NORMAL,
        });

        groupActiv.createWidget(hmUI.widget.TEXT_FONT, {
         x: 216,
         y: 192,
         w: 150,
         h: 40,
         text_size: 37,
         char_space: 0,
         line_space: 0,
         color: 0xFFFFFFFF,
         align_h: hmUI.align.CENTER_H,
         align_v: hmUI.align.CENTER_V,
         text_style: hmUI.text_style.ELLIPSIS,
         type: hmUI.data_type.WEATHER_HIGH_LOW,
         show_level: hmUI.show_level.ONLY_NORMAL,
        });

        groupActiv.createWidget(hmUI.widget.TEXT_FONT, {
         x: 157,
         y: 359,
         w: 150,
         h: 40,
         text_size: 37,
         char_space: 0,
         line_space: 0,
         color: 0xFFFFFFFF,
         align_h: hmUI.align.CENTER_H,
         align_v: hmUI.align.CENTER_V,
         text_style: hmUI.text_style.ELLIPSIS,
         type: hmUI.data_type.DISTANCE,
         show_level: hmUI.show_level.ONLY_NORMAL,
        });

        groupActiv.createWidget(hmUI.widget.TEXT_FONT, {
         x: 260,
         y: 70,
         w: 150,
         h: 40,
         text_size: 37,
         char_space: 0,
         line_space: 0,
         color: 0xFFFFFFFF,
         align_h: hmUI.align.CENTER_H,
         align_v: hmUI.align.CENTER_V,
         text_style: hmUI.text_style.ELLIPSIS,
         type: hmUI.data_type.PAI_WEEKLY,
         show_level: hmUI.show_level.ONLY_NORMAL,
        });

        normal_vos_zak_icon_img = groupActiv.createWidget(hmUI.widget.IMG, {
         x: 276,
         y: 254,
         src: 'images/Grafik/ic_activ/ic_vos.png',
         show_level: hmUI.show_level.ONLY_NORMAL,
        });


        normal_vos_zak_text_font = groupActiv.createWidget(hmUI.widget.TEXT, {
         x: 223,
         y: 308,
         w: 150,
         h: 40,
         text_size: 37,
         char_space: 0,
         line_space: 0,
         color: 0xFFFFFFFF,
         align_h: hmUI.align.CENTER_H,
         align_v: hmUI.align.CENTER_V,
         text_style: hmUI.text_style.ELLIPSIS,
         // type: hmUI.data_type.SUN_RISE,
         show_level: hmUI.show_level.ONLY_NORMAL,
        });


        groupActiv.createWidget(hmUI.widget.TEXT_FONT, {

         x: 157,
         y: 70,
         w: 150,
         h: 40,
         text_size: 37,
         char_space: 0,
         line_space: 0,
         color: 0xFFFFFFFF,
         padding: true,
         align_h: hmUI.align.CENTER_H,
         align_v: hmUI.align.CENTER_V,
         text_style: hmUI.text_style.ELLIPSIS,
         type: hmUI.data_type.ALARM_CLOCK,
         show_level: hmUI.show_level.ONLY_NORMAL,
        });

        groupActiv.createWidget(hmUI.widget.TEXT_FONT, {
         x: 51,
         y: 385,
         w: 150,
         h: 40,
         text_size: 37,
         char_space: 0,
         line_space: 0,
         color: 0xFFFFFFFF,
         align_h: hmUI.align.CENTER_H,
         align_v: hmUI.align.CENTER_V,
         text_style: hmUI.text_style.ELLIPSIS,
         type: hmUI.data_type.SPO2,
         show_level: hmUI.show_level.ONLY_NORMAL,
        });

        groupActiv.createWidget(hmUI.widget.TEXT_FONT, {
         x: 333,
         y: 308,
         w: 150,
         h: 40,
         text_size: 37,
         char_space: 0,
         line_space: 0,
         color: 0xFFFFFFFF,
         align_h: hmUI.align.CENTER_H,
         align_v: hmUI.align.CENTER_V,
         text_style: hmUI.text_style.ELLIPSIS,
         type: hmUI.data_type.STRESS,
         show_level: hmUI.show_level.ONLY_NORMAL,
        });

        groupActiv.createWidget(hmUI.widget.ARC_PROGRESS, {
         center_x: 407,
         center_y: 166,
         start_angle: -135,
         end_angle: 135,
         radius: 39,
         line_width: 10,
         corner_flag: 3,
         color: 0xFFFFFFFF,
         type: hmUI.data_type.STAND,

         show_level: hmUI.show_level.ONLY_NORMAL,
        });

        groupActiv.createWidget(hmUI.widget.TEXT_FONT, {
         x: 333,
         y: 192,
         w: 150,
         h: 40,
         text_size: 37,
         char_space: 0,
         line_space: 0,
         color: 0xFFFFFFFF,
         align_h: hmUI.align.CENTER_H,
         align_v: hmUI.align.CENTER_V,
         text_style: hmUI.text_style.ELLIPSIS,
         type: hmUI.data_type.STAND,
         show_level: hmUI.show_level.ONLY_NORMAL,
        });

        groupActiv.createWidget(hmUI.widget.ARC_PROGRESS, {
         center_x: 180,
         center_y: 280,
         start_angle: -135,
         end_angle: 135,
         radius: 39,
         line_width: 10,
         corner_flag: 3,
         color: 0xFFFFFFFF,
         type: hmUI.data_type.STEP,
         show_level: hmUI.show_level.ONLY_NORMAL,
        });

        groupActiv.createWidget(hmUI.widget.TEXT_FONT, {
         x: 260,
         y: 385,
         w: 150,
         h: 40,
         text_size: 37,
         char_space: 0,
         line_space: 0,
         //padding: true,
         color: 0xFFFFFFFF,
         align_h: hmUI.align.CENTER_H,
         align_v: hmUI.align.CENTER_V,
         text_style: hmUI.text_style.ELLIPSIS,
         type: hmUI.data_type.FLOOR,
         show_level: hmUI.show_level.ONLY_NORMAL,
        });

        groupActiv.createWidget(hmUI.widget.TEXT_FONT, {
         x: 99,
         y: 308,
         w: 150,
         h: 40,
         text_size: 37,
         char_space: 0,
         line_space: 0,
         color: 0xFFFFFFFF,
         align_h: hmUI.align.CENTER_H,
         align_v: hmUI.align.CENTER_V,
         text_style: hmUI.text_style.ELLIPSIS,
         type: hmUI.data_type.STEP,
         show_level: hmUI.show_level.ONLY_NORMAL,
        });

        groupActiv.createWidget(hmUI.widget.ARC_PROGRESS, {
         center_x: 175 + 116,
         center_y: 166,
         start_angle: -135,
         end_angle: 135,
         radius: 39,
         line_width: 10,
         corner_flag: 3,
         color: 0xFFFFFFFF,
         type: hmUI.data_type.WEATHER_CURRENT,
         show_level: hmUI.show_level.ONLY_NORMAL,
        });

        groupActiv.createWidget(hmUI.widget.ARC_PROGRESS, {
         center_x: 175 + 116 + 116,
         center_y: 166 + 116,
         start_angle: -135,
         end_angle: 135,
         radius: 39,
         line_width: 10,
         corner_flag: 3,
         color: 0xFFFFFFFF,
         type: hmUI.data_type.STRESS,
         show_level: hmUI.show_level.ONLY_NORMAL,
        });

        SUN_CURRENT_PROGRESS = groupActiv.createWidget(hmUI.widget.ARC_PROGRESS, {
         center_x: 175 + 116 + 7,
         center_y: 166 + 116,
         start_angle: -135,
         end_angle: 135,
         radius: 39,
         line_width: 10,
         corner_flag: 3,
         color: 0xFFFFFFFF,
         // type: hmUI.data_type.SUN_CURRENT,
         show_level: hmUI.show_level.ONLY_NORMAL,
        });

        groupActiv.createWidget(hmUI.widget.ARC_PROGRESS, {
         center_x: 175,
         center_y: 166,
         start_angle: -135,
         end_angle: 135,
         radius: 39,
         line_width: 10,
         corner_flag: 3,
         color: 0xFFFFFFFF,
         type: hmUI.data_type.HEART,
         show_level: hmUI.show_level.ONLY_NORMAL,
        });

        groupActiv.createWidget(hmUI.widget.TEXT_FONT, {
         x: 99,
         y: 192,
         w: 150,
         h: 40,
         text_size: 37,
         char_space: 0,
         line_space: 0,
         color: 0xFFFFFFFF,
         align_h: hmUI.align.CENTER_H,
         align_v: hmUI.align.CENTER_V,
         text_style: hmUI.text_style.ELLIPSIS,
         type: hmUI.data_type.HEART,
         show_level: hmUI.show_level.ONLY_NORMAL,
        });

        groupActiv.createWidget(hmUI.widget.ARC_PROGRESS, {
         center_x: 59,
         center_y: 282,
         start_angle: -135,
         end_angle: 135,
         radius: 39,
         line_width: 10,
         corner_flag: 3,
         color: 0xFFFFFFFF,
         type: hmUI.data_type.FAT_BURNING,
         show_level: hmUI.show_level.ONLY_NORMAL,
        });

        groupActiv.createWidget(hmUI.widget.TEXT_FONT, {
         x: -17,
         y: 308,
         w: 150,
         h: 40,
         text_size: 37,
         char_space: 0,
         line_space: 0,
         color: 0xFFFFFFFF,
         align_h: hmUI.align.CENTER_H,
         align_v: hmUI.align.CENTER_V,
         text_style: hmUI.text_style.ELLIPSIS,
         type: hmUI.data_type.FAT_BURNING,
         show_level: hmUI.show_level.ONLY_NORMAL,
        });

        groupActiv.createWidget(hmUI.widget.ARC_PROGRESS, {
         center_x: 59,
         center_y: 166,
         start_angle: -135,
         end_angle: 135,
         radius: 39,
         line_width: 10,
         corner_flag: 3,
         color: 0xFFFFFFFF,
         type: hmUI.data_type.CAL,
         show_level: hmUI.show_level.ONLY_NORMAL,
        });

        groupActiv.createWidget(hmUI.widget.TEXT_FONT, {
         x: 51,
         y: 70,
         w: 150,
         h: 40,
         text_size: 37,
         char_space: 0,
         line_space: 0,
         padding: true,
         color: 0xFFFFFFFF,
         align_h: hmUI.align.CENTER_H,
         align_v: hmUI.align.CENTER_V,
         text_style: hmUI.text_style.ELLIPSIS,
         type: hmUI.data_type.COUNT_DOWN,
         show_level: hmUI.show_level.ONLY_NORMAL,
        });

        groupActiv.createWidget(hmUI.widget.TEXT_FONT, {
         x: -17,
         y: 192,
         w: 150,
         h: 40,
         text_size: 37,
         char_space: 0,
         line_space: 0,
         color: 0xFFFFFFFF,
         align_h: hmUI.align.CENTER_H,
         align_v: hmUI.align.CENTER_V,
         text_style: hmUI.text_style.ELLIPSIS,
         type: hmUI.data_type.CAL,
         show_level: hmUI.show_level.ONLY_NORMAL,
        });

        ic_activ_color_off_img = groupActiv.createWidget(hmUI.widget.IMG, {
         x: 363,
         y: 346,
         src: 'images/Grafik/ic_activ_color_off.png',
         show_level: hmUI.show_level.ONLY_NORMAL,
        });
        ic_activ_color_off_img.setProperty(hmUI.prop.VISIBLE, Activ_color == 0);


        Button_1 = groupActiv.createWidget(hmUI.widget.BUTTON, {
         x: 183,
         y: 18,
         w: 100,
         h: 100,
         text: '',
         color: 0xFFFF8C00,
         text_size: 25,
         press_src: 'images/Grafik/press_100.png',
         normal_src: 'pusto.png',
         click_func: (button_widget) => {
          hmApp.startApp({
           url: 'AlarmInfoScreen',
           native: true

          });
          vibro();
         }, // end func
         show_level: hmUI.show_level.ONLY_NORMAL,
        }); // end button

        Button_2 = groupActiv.createWidget(hmUI.widget.BUTTON, {
         x: 79,
         y: 18,
         w: 100,
         h: 100,
         text: '',
         color: 0xFFFF8C00,
         text_size: 25,
         press_src: 'images/Grafik/press_100.png',
         normal_src: 'pusto.png',
         click_func: (button_widget) => {
          hmApp.startApp({
           url: 'CountdownAppScreen',
           native: true
          });
          vibro();
         }, // end func
         show_level: hmUI.show_level.ONLY_NORMAL,
        }); // end button

        Button_3 = groupActiv.createWidget(hmUI.widget.BUTTON, {
         x: 287,
         y: 18,
         w: 100,
         h: 100,
         text: '',
         color: 0xFFFF8C00,
         text_size: 25,
         press_src: 'images/Grafik/press_100.png',
         normal_src: 'pusto.png',
         click_func: (button_widget) => {
          hmApp.startApp({
           url: 'PAI_app_Screen',
           native: true
          });
          vibro();
         }, // end func
         show_level: hmUI.show_level.ONLY_NORMAL,
        }); // end button

        Button_4 = groupActiv.createWidget(hmUI.widget.BUTTON, {
         x: 8,
         y: 122,
         w: 100,
         h: 100,
         text: '',
         color: 0xFFFF8C00,
         text_size: 25,
         press_src: 'images/Grafik/press_100.png',
         normal_src: 'pusto.png',
         click_func: (button_widget) => {
          hmApp.startApp({
           url: 'activityWeekShowScreen',
           native: true
          });
          vibro();
         }, // end func
         show_level: hmUI.show_level.ONLY_NORMAL,
        }); // end button

        Button_5 = groupActiv.createWidget(hmUI.widget.BUTTON, {
         x: 124,
         y: 122,
         w: 100,
         h: 100,
         text: '',
         color: 0xFFFF8C00,
         text_size: 25,
         press_src: 'images/Grafik/press_100.png',
         normal_src: 'pusto.png',
         click_func: (button_widget) => {
          hmApp.startApp({
           url: 'heart_app_Screen',
           native: true
          });
          vibro();
         }, // end func
         show_level: hmUI.show_level.ONLY_NORMAL,
        }); // end button

        Button_6 = groupActiv.createWidget(hmUI.widget.BUTTON, {
         x: 241,
         y: 122,
         w: 100,
         h: 100,
         text: '',
         color: 0xFFFF8C00,
         text_size: 25,
         press_src: 'images/Grafik/press_100.png',
         normal_src: 'pusto.png',
         click_func: (button_widget) => {
          hmApp.startApp({
           url: 'WeatherScreen',
           native: true
          });
          vibro();
         }, // end func
         show_level: hmUI.show_level.ONLY_NORMAL,
        }); // end button

        Button_7 = groupActiv.createWidget(hmUI.widget.BUTTON, {
         x: 357,
         y: 122,
         w: 100,
         h: 100,
         text: '',
         color: 0xFFFF8C00,
         text_size: 25,
         press_src: 'images/Grafik/press_100.png',
         normal_src: 'pusto.png',
         click_func: (button_widget) => {
          hmApp.startApp({
           url: 'SportListScreen',
           native: true
          });
          vibro();
         }, // end func
         show_level: hmUI.show_level.ONLY_NORMAL,
        }); // end button

        Button_8 = groupActiv.createWidget(hmUI.widget.BUTTON, {
         x: 9,
         y: 237,
         w: 100,
         h: 100,
         text: '',
         color: 0xFFFF8C00,
         text_size: 25,
         press_src: 'images/Grafik/press_100.png',
         normal_src: 'pusto.png',
         click_func: (button_widget) => {
          hmApp.startApp({
           url: 'readinessAppScreen',
           native: true
          });
          vibro();
         }, // end func
         show_level: hmUI.show_level.ONLY_NORMAL,
        }); // end button

        Button_9 = groupActiv.createWidget(hmUI.widget.BUTTON, {
         x: 130,
         y: 237,
         w: 100,
         h: 100,
         text: '',
         color: 0xFFFF8C00,
         text_size: 25,
         press_src: 'images/Grafik/press_100.png',
         normal_src: 'pusto.png',
         click_func: (button_widget) => {
          hmApp.startApp({
           url: 'activityAppScreen',
           native: true
          });
          vibro();
         }, // end func
         show_level: hmUI.show_level.ONLY_NORMAL,
        }); // end button

        Button_10 = groupActiv.createWidget(hmUI.widget.BUTTON, {
         x: 250,
         y: 237,
         w: 100,
         h: 100,
         text: '',
         color: 0xFFFF8C00,
         text_size: 25,
         press_src: 'images/Grafik/press_100.png',
         normal_src: 'pusto.png',
         click_func: (button_widget) => {
          hmApp.startApp({
           url: 'TideScreen',
           native: true
          });
          vibro();
         }, // end func
         show_level: hmUI.show_level.ONLY_NORMAL,
        }); // end button

        Button_11 = groupActiv.createWidget(hmUI.widget.BUTTON, {
         x: 357,
         y: 237,
         w: 100,
         h: 100,
         text: '',
         color: 0xFFFF8C00,
         text_size: 25,
         press_src: 'images/Grafik/press_100.png',
         normal_src: 'pusto.png',
         click_func: (button_widget) => {
          hmApp.startApp({
           url: 'SportRecordListScreen',
           native: true
          });
          vibro();
         }, // end func
         show_level: hmUI.show_level.ONLY_NORMAL,
        }); // end button

        Button_12 = groupActiv.createWidget(hmUI.widget.BUTTON, {
         x: 76,
         y: 342,
         w: 100,
         h: 100,
         text: '',
         color: 0xFFFF8C00,
         text_size: 25,
         press_src: 'images/Grafik/press_100.png',
         normal_src: 'pusto.png',
         click_func: (button_widget) => {
          hmApp.startApp({
           url: 'RespirationwidgetScreen',
           native: true
          });
          vibro();
         }, // end func
         show_level: hmUI.show_level.ONLY_NORMAL,
        }); // end button		   


        btn_Activ_off = groupActiv.createWidget(hmUI.widget.BUTTON, {
         x: 183,
         y: 366,
         text: '',
         w: 100, //ширина кнопки
         h: 100, //высота кнопки
         text: "ОК",
         char_space: 0,
         line_space: -55,
         color: 0xFFFFFFFF,
         text_size: 24,
         normal_src: '0_Empty.png',
         press_src: 'images/Grafik/press_100.png',
         click_func: () => {
          vibro(); //имя вызываемой функции
          click_Activ_off();
         },
         show_level: hmUI.show_level.ONLY_NORMAL,
        });

        btn_Activ_color = groupActiv.createWidget(hmUI.widget.BUTTON, {
         x: 300,
         y: 345,
         text: '',
         w: 100, //ширина кнопки
         h: 100, //высота кнопки
         normal_src: '0_Empty.png',
         press_src: 'press_100.png',
         click_func: () => {
          vibro(); //имя вызываемой функции
             click_Activ_color();
         },
         show_level: hmUI.show_level.ONLY_NORMAL,
        });

        g_ACR_panel = hmUI.createWidget(hmUI.widget.GROUP, {
         x: 0,
         y: 0,
         w: 466,
         h: 466,
        })

        //цвет	
        menu_ARC_PROGRES_bg = g_ACR_panel.createWidget(hmUI.widget.ARC_PROGRESS, {
         center_x: 233,
         center_y: 233,
         start_angle: 60 - 15,
         end_angle: 120 + 15,
         radius: 219 + 8,
         line_width: 8,
         corner_flag: 0,
         color: 0xFF5b5b5b,
         level: 100,
         show_level: hmUI.show_level.ONLY_NORMAL,
        });

        menu_ARC_PROGRES = g_ACR_panel.createWidget(hmUI.widget.ARC_PROGRESS, {
         center_x: 233,
         center_y: 233,
         start_angle: 45 + 90 / CONF_MAIN[0].len * (-CONF_MAIN[0].id * 95), // start_angle: 45 + 90 / array * gde,
         end_angle: 135 + 90 / CONF_MAIN[0].len * (-CONF_MAIN[0].id * 95), //end_angle: 135 + 90 / array * gde,
         radius: 219,
         line_width: 16,
         corner_flag: 0,
         color: 0xFF0000, //0xFF007eff
         level: 100 / CONF_MAIN[0].len, //level: pointer,
         show_level: hmUI.show_level.ONLY_NORMAL,
        });
        g_ACR_panel.setProperty(hmUI.prop.VISIBLE, false);


        g_ACR_color_PROGRES = hmUI.createWidget(hmUI.widget.GROUP, {
         x: 0,
         y: 0,
         w: 466,
         h: 466,
        })

        for (let i = 0; i < ARC_set.length; i++) {
         menu_ARC_color[i] = g_ACR_color_PROGRES.createWidget(hmUI.widget.CIRCLE, {
          center_x: ARC_set[i][0],
          center_y: ARC_set[i][1],
          radius: ARC_set[i][2] / 2,
          color: color_bg[0][i],
          alpha: 255,
          show_level: hmUI.show_level.ONLY_NORMAL,
         });
        };

        CIRCLE_select = g_ACR_color_PROGRES.createWidget(hmUI.widget.ARC_PROGRESS, {
         center_x: ARC_set[4][0],
         center_y: ARC_set[4][1],
         radius: ARC_set[4][2] / 2 + 6,
         start_angle: 0,
         end_angle: 360,
         line_width: 6,
         corner_flag: 3,
         color: 0xff0000,
         //alpha: 255,
         level: 100,
         show_level: hmUI.show_level.ONLY_NORMAL,
        });

        g_ACR_color_PROGRES.setProperty(hmUI.prop.VISIBLE, false);


        g_Set = hmUI.createWidget(hmUI.widget.GROUP, {
         x: 0,
         y: 0,
         w: 466,
         h: 466,
        })

        normal_background_Set = g_Set.createWidget(hmUI.widget.FILL_RECT, {
         x: 0,
         y: 0,
         w: 466,
         h: 466,
         color: 0x000000,
         // radius: 12,
         alpha: 153,
         show_level: hmUI.show_level.ONLY_NORMAL,
        });

        for (let i = 0; i < CONF_MAIN.length; i++) {
         Btn_set_[i] = g_Set.createWidget(hmUI.widget.BUTTON, {
          x: CONF_MAIN.length <= 5 ? 153 : i < Math.ceil(CONF_MAIN.length / 2) ? 70 : 233,
          y: CONF_MAIN.length <= 5 ? 70 + i * Shag_Y : i < Math.ceil(CONF_MAIN.length / 2) ? 70 + i * Shag_Y : 70 + i * Shag_Y - Shag_Y * Math.ceil(CONF_MAIN.length / 2),
          w: 160,
          h: 60,
          text: CONF_MAIN[i].name,
          char_space: 0,
          line_space: -35,
          color: 0xFFFFFFFF,
          text_size: 24,
          radius: 12,
          press_color: 0xFFFF0000,
          normal_color: i != crown ? 0x000000 : 0x800000,
          click_func: () => {
           vibro();
           click_crown(i);
          },
          text_style: hmUI.text_style.WRAP,
          show_level: hmUI.show_level.ONLY_NORMAL,
         }); // end button
        };

        btn_Set_exit = g_Set.createWidget(hmUI.widget.BUTTON, {
         x: 203, //x кнопки
         y: 70 + Shag_Y * 5, //y кнопки
         w: 60,
         h: 60,
         text: "ОК",
         char_space: 0,
         line_space: -35,
         color: 0xFFFFFFFF,
         text_size: 24,
         radius: 12,
         press_color: 0xFFFF0000,
         normal_color: 0xFF000000,
         click_func: () => {
          vibro();
          click_Set_off();
         },
         text_style: hmUI.text_style.WRAP,
         show_level: hmUI.show_level.ONLY_NORMAL,
        });
        g_Set.setProperty(hmUI.prop.VISIBLE, false);

        bg_app_text = hmUI.createWidget(hmUI.widget.FILL_RECT, {
         x: crown == 1 ? 233 - 163 : 233 + 163,
         y: 49 + 25,
         w: 163,
         h: Line_arr.length * 21 + 21 / 2,
         color: 0x000000,
         alpha: 178,
         show_level: hmUI.show_level.ONLY_NORMAL,
        });
        bg_app_text.setProperty(hmUI.prop.VISIBLE, false);

        for (let i = 0; i < Line_arr.length; i++) {
         app_ACR_text[i] = hmUI.createWidget(hmUI.widget.TEXT, {
          x: crown == 1 ? 233 - 166 : 233 + 166,
          y: 70 + 25 + i * 21 - 22,
          w: 166,
          h: 30,
          text: Line_arr[i][3],
          text_size: 21,
          char_space: 0,
          line_space: 0,
          //font: 'fonts/Bebas22.ttf',
          color: CONF_MAIN[1].id == i ? 0xff0000 : 0xffffff,
          align_h: hmUI.align.CENTER_H,
          align_v: hmUI.align.CENTER_V,
          text_style: hmUI.text_style.NONE,
          show_level: hmUI.show_level.ONLY_NORMAL,
         });
         app_ACR_text[i].setProperty(hmUI.prop.VISIBLE, false);
        };


        btn_crown = groupVremya.createWidget(hmUI.widget.BUTTON, {
         x: 302, //x кнопки
         y: 59, //y кнопки
         text: '',
         w: 100, //ширина кнопки
         h: 100, //высота кнопки
         normal_src: '0_Empty.png',
         press_src: '0_Empty.png',
         click_func: () => {
          // vibro();
          click_Set_on();
         },
         //           longpress_func: () => {
         //            vibro();
         //			   blok_btn_on();
         //           },
         show_level: hmUI.show_level.ONLY_NORMAL,
        });

/*         btn_tap_left = groupVremya.createWidget(hmUI.widget.BUTTON, {
             x: 0, //x кнопки
             y: 183, //y кнопки
             text: '',
             w: 100, //ширина кнопки
             h: 100, //высота кнопки
             normal_src: '0_Empty.png',
             press_src: '0_Empty.png',
             click_func: () => {
                 vibro();
                 clik_tap_left();
             },
             longpress_func: () => {
                 vibro();
                 clik_longpress_tap_left();
             },
             show_level: hmUI.show_level.ONLY_NORMAL,
         });
*/
				




        groupVremya.setProperty(hmUI.prop.VISIBLE, true);
        groupTap.setProperty(hmUI.prop.VISIBLE, false);
        groupPogoda.setProperty(hmUI.prop.VISIBLE, false);
        groupActiv.setProperty(hmUI.prop.VISIBLE, false);
        groupSleep.setProperty(hmUI.prop.VISIBLE, false);
				
          
                };  // end screenType

            // end user_script_beforeShortcuts.js

            //start of ignored block
            function time_update(updateHour = false, updateMinute = false) {
              console.log('time_update()');
              let hour = timeSensor.hour;
              let minute = timeSensor.minute;
              let second = timeSensor.second;
              let format_hour = timeSensor.format_hour;
              
              
              

              console.log('minute font');
              if (updateMinute) {
                let normal_minuteStr = minute.toString();
                normal_minuteStr = normal_minuteStr.padStart(2, '0');
                normal_time_minute_text_font.setProperty(hmUI.prop.TEXT, normal_minuteStr );
              };

              console.log('second font');
                let normal_secondStr = second.toString();
                normal_secondStr = normal_secondStr.padStart(2, '0');
                normal_time_second_text_font.setProperty(hmUI.prop.TEXT, normal_secondStr );
              console.log('day of week font');
              if (updateHour) {
                let normal_DOW_Str = normal_DOW_Array[timeSensor.week-1];
                normal_dow_text_font.setProperty(hmUI.prop.TEXT, normal_DOW_Str );
              };

              console.log('month font');
              if (updateHour) {
              
         let hour_1 = parseInt(hour / 10);
         let hour_2 = parseInt(hour % 10);
normal_H1.setProperty(hmUI.prop.SRC, 'H1_' + hour_1 + '.png');
normal_H2.setProperty(hmUI.prop.SRC, 'H2_' + hour_2 + '.png');  
idle_H1.setProperty(hmUI.prop.SRC, 'H1_' + hour_1 + '.png');
idle_H2.setProperty(hmUI.prop.SRC, 'H2_' + hour_2 + '.png');  

              
                let normal_Month_Str = normal_Month_Array[timeSensor.month-1];
                normal_month_name_font.setProperty(hmUI.prop.TEXT, normal_Month_Str );
              };

              console.log('day font');
              if (updateHour) {
                let normal_dayStr = timeSensor.day.toString();
                normal_dayStr = normal_dayStr.padStart(2, '0');
                normal_day_text_font.setProperty(hmUI.prop.TEXT, normal_dayStr );
              };

              console.log('minute font');
              if (updateMinute) {
                let idle_minuteStr = minute.toString();
                idle_minuteStr = idle_minuteStr.padStart(2, '0');
                idle_time_minute_text_font.setProperty(hmUI.prop.TEXT, idle_minuteStr );
              };

              console.log('second font');
                let idle_secondStr = second.toString();
                idle_secondStr = idle_secondStr.padStart(2, '0');
                idle_time_second_text_font.setProperty(hmUI.prop.TEXT, idle_secondStr );
              console.log('day of week font');
              if (updateHour) {
                let idle_DOW_Str = idle_DOW_Array[timeSensor.week-1];
                idle_dow_text_font.setProperty(hmUI.prop.TEXT, idle_DOW_Str );
              };

              console.log('month font');
              if (updateHour) {
                let idle_Month_Str = idle_Month_Array[timeSensor.month-1];
                idle_month_name_font.setProperty(hmUI.prop.TEXT, idle_Month_Str );
              };

              console.log('day font');
              if (updateHour) {
                let idle_dayStr = timeSensor.day.toString();
                idle_dayStr = idle_dayStr.padStart(2, '0');
                idle_day_text_font.setProperty(hmUI.prop.TEXT, idle_dayStr );
              };

            };

            //end of ignored block
            //start of ignored block
            function text_update() {
              console.log('text_update()');

              console.log('update text rotate hour_TIME');
              let valueHour = timeSensor.format_hour;
              let normal_hour_rotate_string = parseInt(valueHour).toString();
              normal_hour_rotate_string = normal_hour_rotate_string.padStart(2, '0');



              console.log('update text rotate hour_TIME');
              let idle_hour_rotate_string = parseInt(valueHour).toString();
              idle_hour_rotate_string = idle_hour_rotate_string.padStart(2, '0');

              if (screenType == hmSetting.screen_type.AOD) {
                for (var i = 1; i < 2; i++) {  // hide all symbols
                  idle_hour_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                if (valueHour != null && valueHour != undefined && isFinite(valueHour) && idle_hour_rotate_string.length > 0 && idle_hour_rotate_string.length <= 2) {  // display data if it was possible to get it
                  let img_offset = 0;
                  
                  let index = 0;
                  for (let char of idle_hour_rotate_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 2) break;
                    if (charCode >= 0 && charCode < 10) { 
                      idle_hour_TextRotate[index].setProperty(hmUI.prop.POS_X, -647 + img_offset);
                      idle_hour_TextRotate[index].setProperty(hmUI.prop.SRC, idle_hour_TextRotate_ASCIIARRAY[charCode]);
                      idle_hour_TextRotate[index].setProperty(hmUI.prop.VISIBLE, true);
                      img_offset += idle_hour_TextRotate_img_width + 500;
                      index++;
                    };  // end if digit
                  };  // end char of string
                }  // end isFinite

              };

            };

            //end of ignored block
            function scale_call() {
              console.log('scale_call()');

              console.log('Weather city name');
              let weatherData = weatherSensor.getForecastWeather();
              let normal_cityNameStr = weatherData.cityName;
              normal_cityNameStr = normal_cityNameStr.toUpperCase();
              normal_city_name_text.setProperty(hmUI.prop.TEXT, normal_cityNameStr);

              console.log('Weather city name');
              let idle_cityNameStr = weatherData.cityName;
              idle_city_name_text.setProperty(hmUI.prop.TEXT, idle_cityNameStr);

            };
            
app_update();            
            

            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                console.log('resume_call()');
                scale_call();
                time_update(true, true);


                if (screenType == hmSetting.screen_type.WATCHFACE) {
                  if (!normal_timerTimeUpdate) {
                    normal_timerTimeUpdate = timer.createTimer(0, 1000, (function (option) {
                      let updateHour = timeSensor.minute == 0 && timeSensor.second < 2;
                      let updateMinute = timeSensor.second < 2;
                      time_update(updateHour, updateMinute);
                    }));  // end timer 
                  };  // end timer check
                };  // end screenType


                if (screenType == hmSetting.screen_type.AOD) {
                  if (!idle_timerTimeUpdate) {
                    idle_timerTimeUpdate = timer.createTimer(0, 1000, (function (option) {
                      let updateHour = timeSensor.minute == 0 && timeSensor.second < 2;
                      let updateMinute = timeSensor.second < 2;
                      time_update(updateHour, updateMinute);
                      app_update();
                    }));  // end timer 
                  };  // end timer check
                };  // end screenType


                console.log('resume_call.js');
                // start resume_call.js


loadSettings() 
          updateSleep()
          updatePressere()
          app_update();
          //updateGrafik();
				  
          click_Pogoda_off();
          setTimeout(() => {
           onDigitalCrown();
          }, 1000);
          setTimeout(() => {
           onKeyEvent();
          }, 1000);
           
                     stopVibro();

                // end resume_call.js

              }),
              pause_call: (function () {

                if (normal_timerTimeUpdate) {
                  timer.stopTimer(normal_timerTimeUpdate);
                  normal_timerTimeUpdate = undefined;
                }
                if (idle_timerTimeUpdate) {
                  timer.stopTimer(idle_timerTimeUpdate);
                  idle_timerTimeUpdate = undefined;
                }

                console.log('pause_call.js');
                // start pause_call.js

vibrate.stop();
          hmApp.unregisterSpinEvent();
          offKeyEvent()
          normal_background_Pogoda.setProperty(hmUI.prop.VISIBLE, false);
          groupTap.setProperty(hmUI.prop.VISIBLE, false);
          groupVremya.setProperty(hmUI.prop.VISIBLE, true);
          groupPogoda.setProperty(hmUI.prop.VISIBLE, false);
          groupActiv.setProperty(hmUI.prop.VISIBLE, false);
          groupSleep.setProperty(hmUI.prop.VISIBLE, false);


                // end pause_call.js

              }),
            });

                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}