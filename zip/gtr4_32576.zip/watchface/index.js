﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        const logger = Logger.getLogger('watchface_SashaCX75');
        //end of ignored block

        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_calorie_pointer_progress_img_pointer = ''
        let normal_calorie_current_text_img = ''
        let normal_battery_text_text_img = ''
        let normal_battery_pointer_progress_img_pointer = ''
        let normal_system_lock_img = ''
        let normal_system_disconnect_img = ''
        let normal_system_clock_img = ''
        let normal_system_dnd_img = ''
        let normal_temperature_current_text_img = ''
        let normal_weather_image_progress_img_level = ''
        let normal_distance_text_text_img = ''
        let normal_step_current_text_img = ''
        let normal_step_pointer_progress_img_pointer = ''
        let normal_heart_rate_text_text_img = ''
        let normal_heart_rate_image_progress_img_level = ''
        let normal_analog_clock_time_pointer_hour = ''
        let normal_analog_clock_time_pointer_minute = ''
        let normal_analog_clock_time_pointer_second = ''
        let idle_background_bg_img = ''
        let idle_analog_clock_time_pointer_second = ''
        let idle_digital_clock_img_time = ''
        let idle_digital_clock_hour_separator_img = ''


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 466,
              h: 466,
              src: 'Top1.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_calorie_pointer_progress_img_pointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
              src: 'pointer.png',
              center_x: 232,
              center_y: 386,
              x: 9,
              y: 76,
              start_angle: 0,
              end_angle: 360,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_calorie_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 203,
              y: 407,
              font_array: ["font_0.png","font_1.png","font_2.png","font_3.png","font_4.png","font_5.png","font_6.png","font_7.png","font_8.png","font_9.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 53,
              y: 250,
              font_array: ["font_0.png","font_1.png","font_2.png","font_3.png","font_4.png","font_5.png","font_6.png","font_7.png","font_8.png","font_9.png"],
              padding: false,
              h_space: 1,
              unit_sc: '%.png',
              unit_tc: '%.png',
              unit_en: '%.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_pointer_progress_img_pointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
              src: 'pointer.png',
              center_x: 78,
              center_y: 231,
              x: 9,
              y: 76,
              start_angle: 0,
              end_angle: 360,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_lock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 125,
              y: 315,
              src: 'block.png',
              type: hmUI.system_status.LOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 127,
              y: 126,
              src: 'bluetooth_(10).png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 318,
              y: 124,
              src: 'alarm_(2).png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_dnd_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 316,
              y: 315,
              src: 'free-icon-sleep-7921424.png',
              type: hmUI.system_status.DISTURB,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 226,
              y: 26,
              font_array: ["Weather_Font_01.png","Weather_Font_02.png","Weather_Font_03.png","Weather_Font_04.png","Weather_Font_05.png","Weather_Font_06.png","Weather_Font_07.png","Weather_Font_08.png","Weather_Font_09.png","Weather_Font_10.png"],
              padding: false,
              h_space: 2,
              unit_sc: 'Weather_symbo_01.png',
              unit_tc: 'Weather_symbo_01.png',
              unit_en: 'Weather_symbo_01.png',
              negative_image: 'Weather_symbo_02.png',
              invalid_image: 'Weather_symbo_02.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 187,
              y: 18,
              image_array: ["weather_0.png","weather_1.png","weather_2.png","weather_3.png","weather_4.png","weather_5.png","weather_6.png","weather_7.png","weather_8.png","weather_9.png","weather_10.png","weather_11.png","weather_12.png","weather_13.png","weather_14.png","weather_15.png","weather_16.png","weather_17.png","weather_18.png","weather_19.png","weather_20.png","weather_21.png","weather_22.png","weather_23.png","weather_24.png","weather_25.png","weather_26.png","weather_27.png","weather_28.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_distance_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 185,
              y: 272,
              font_array: ["Act_Font_01.png","Act_Font_02.png","Act_Font_03.png","Act_Font_04.png","Act_Font_05.png","Act_Font_06.png","Act_Font_07.png","Act_Font_08.png","Act_Font_09.png","Act_Font_10.png"],
              padding: false,
              h_space: 4,
              unit_sc: 'Act_KM.png',
              unit_tc: 'Act_KM.png',
              unit_en: 'Act_KM.png',
              dot_image: 'Act_Dot.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.DISTANCE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 350,
              y: 250,
              font_array: ["font_0.png","font_1.png","font_2.png","font_3.png","font_4.png","font_5.png","font_6.png","font_7.png","font_8.png","font_9.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_pointer_progress_img_pointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
              src: 'pointer.png',
              center_x: 387,
              center_y: 231,
              x: 10,
              y: 76,
              start_angle: 0,
              end_angle: 360,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 207,
              y: 81,
              font_array: ["Act_Font_01.png","Act_Font_02.png","Act_Font_03.png","Act_Font_04.png","Act_Font_05.png","Act_Font_06.png","Act_Font_07.png","Act_Font_08.png","Act_Font_09.png","Act_Font_10.png"],
              padding: false,
              h_space: 4,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 215,
              y: 120,
              image_array: ["Zone_01.png","Zone_02.png","Zone_03.png","Zone_04.png","Zone_05.png","Zone_06.png"],
              image_length: 6,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_hour = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              hour_path: 'aodh.png',
              hour_centerX: 233,
              hour_centerY: 233,
              hour_posX: 23,
              hour_posY: 183,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_minute = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              minute_path: 'aodm.png',
              minute_centerX: 233,
              minute_centerY: 233,
              minute_posX: 23,
              minute_posY: 216,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_second = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              second_path: 'aods.png',
              second_centerX: 233,
              second_centerY: 233,
              second_posX: 41,
              second_posY: 216,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            idle_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 466,
              h: 466,
              src: 'aodtop.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_analog_clock_time_pointer_second = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              second_path: 'Analog_second_circle.png',
              second_centerX: 233,
              second_centerY: 233,
              second_posX: 233,
              second_posY: 234,
              second_cover_path: 'aodtop.png',
              second_cover_x: 0,
              second_cover_y: 0,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 27,
              hour_startY: 192,
              hour_array: ["Time_H1_01.png","Time_H1_02.png","Time_H1_03.png","Time_H1_04.png","Time_H1_05.png","Time_H1_06.png","Time_H1_07.png","Time_H1_08.png","Time_H1_09.png","Time_H1_10.png"],
              hour_zero: 1,
              hour_space: 4,
              hour_align: hmUI.align.LEFT,

              minute_startX: 138,
              minute_startY: 192,
              minute_array: ["Time_H5_01.png","Time_H5_02.png","Time_H5_03.png","Time_H5_04.png","Time_H5_05.png","Time_H5_06.png","Time_H5_07.png","Time_H5_08.png","Time_H5_09.png","Time_H5_10.png"],
              minute_zero: 1,
              minute_space: 4,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              second_startX: 235,
              second_startY: 196,
              second_array: ["Act_Font_01.png","Act_Font_02.png","Act_Font_03.png","Act_Font_04.png","Act_Font_05.png","Act_Font_06.png","Act_Font_07.png","Act_Font_08.png","Act_Font_09.png","Act_Font_10.png"],
              second_zero: 1,
              second_space: 4,
              second_follow: 0,
              second_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_hour_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 120,
              y: 216,
              src: 'Digital_dot.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });


                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}