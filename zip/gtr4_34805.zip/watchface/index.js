﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        const logger = Logger.getLogger('watchface_SashaCX75');
        //end of ignored block

        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_temperature_current_text_img = ''
        let normal_weather_image_progress_img_level = ''
        let normal_battery_circle_scale = ''
        let normal_battery_text_text_img = ''
        let normal_date_img_date_week_img = ''
        let normal_date_img_date_day = ''
        let normal_date_img_date_month = ''
        let normal_step_circle_scale = ''
        let normal_step_current_text_img = ''
        let normal_heart_rate_text_text_img = ''
        let normal_digital_clock_img_time = ''
        let idle_digital_clock_img_time = ''
        let normal_stopwatch_jumpable_img_click = ''
        let normal_sunrise_jumpable_img_click = ''
        let normal_temperature_jumpable_img_click = ''
        let normal_heart_jumpable_img_click = ''
        let normal_step_jumpable_img_click = ''


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 466,
              h: 466,
              src: '0000.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 391,
              y: 191,
              font_array: ["0013.png","0014.png","0015.png","0016.png","0017.png","0018.png","0019.png","0020.png","0021.png","0022.png"],
              padding: false,
              h_space: -2,
              unit_sc: '0076.png',
              unit_tc: '0076.png',
              unit_en: '0076.png',
              negative_image: '0075.png',
              invalid_image: '0075.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 401,
              y: 145,
              image_array: ["0040.png","0041.png","0042.png","0043.png","0044.png","0045.png","0046.png","0047.png","0048.png","0049.png","0050.png","0051.png","0052.png","0053.png","0054.png","0055.png","0056.png","0057.png","0058.png","0059.png","0060.png","0061.png","0062.png","0063.png","0064.png","0065.png","0066.png","0067.png","0068.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_battery_circle_scale = hmUI.createWidget(hmUI.widget.Circle_Scale, {
              // center_x: 123,
              // center_y: 343,
              // start_angle: 211,
              // end_angle: 512,
              // radius: 50,
              // line_width: 8,
              // line_cap: Rounded,
              // color: 0xFFF3FF1A,
              // mirror: False,
              // inversion: False,
              // type: hmUI.data_type.BATTERY,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            let screenType = hmSetting.getScreenType();
            normal_battery_circle_scale = hmUI.createWidget(hmUI.widget.ARC_PROGRESS, {
              center_x: 123,
              center_y: 343,
              start_angle: 211,
              end_angle: 512,
              radius: 46,
              line_width: 8,
              corner_flag: 0,
              color: 0xFFF3FF1A,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            
            const battery = hmSensor.createSensor(hmSensor.id.BATTERY);
            battery.addEventListener(hmSensor.event.CHANGE, function() {
              scale_call();
            });

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 86,
              y: 334,
              font_array: ["0013.png","0014.png","0015.png","0016.png","0017.png","0018.png","0019.png","0020.png","0021.png","0022.png"],
              padding: false,
              h_space: 0,
              unit_sc: '0073.png',
              unit_tc: '0073.png',
              unit_en: '0073.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 171,
              y: 381,
              week_en: ["0033.png","0034.png","0035.png","0036.png","0037.png","0038.png","0039.png"],
              week_tc: ["0033.png","0034.png","0035.png","0036.png","0037.png","0038.png","0039.png"],
              week_sc: ["0033.png","0034.png","0035.png","0036.png","0037.png","0038.png","0039.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 323,
              day_startY: 390,
              day_sc_array: ["0023.png","0024.png","0025.png","0026.png","0027.png","0028.png","0029.png","0030.png","0031.png","0032.png"],
              day_tc_array: ["0023.png","0024.png","0025.png","0026.png","0027.png","0028.png","0029.png","0030.png","0031.png","0032.png"],
              day_en_array: ["0023.png","0024.png","0025.png","0026.png","0027.png","0028.png","0029.png","0030.png","0031.png","0032.png"],
              day_zero: 1,
              day_space: 0,
              day_align: hmUI.align.LEFT,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_month = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 256,
              month_startY: 390,
              month_sc_array: ["0023.png","0024.png","0025.png","0026.png","0027.png","0028.png","0029.png","0030.png","0031.png","0032.png"],
              month_tc_array: ["0023.png","0024.png","0025.png","0026.png","0027.png","0028.png","0029.png","0030.png","0031.png","0032.png"],
              month_en_array: ["0023.png","0024.png","0025.png","0026.png","0027.png","0028.png","0029.png","0030.png","0031.png","0032.png"],
              month_zero: 1,
              month_space: 0,
              month_unit_sc: '0072.png',
              month_unit_tc: '0072.png',
              month_unit_en: '0072.png',
              month_align: hmUI.align.LEFT,
              month_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_step_circle_scale = hmUI.createWidget(hmUI.widget.Circle_Scale, {
              // center_x: 123,
              // center_y: 121,
              // start_angle: 211,
              // end_angle: 511,
              // radius: 50,
              // line_width: 8,
              // line_cap: Rounded,
              // color: 0xFFF3FF1A,
              // mirror: False,
              // inversion: False,
              // type: hmUI.data_type.STEP,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_step_circle_scale = hmUI.createWidget(hmUI.widget.ARC_PROGRESS, {
              center_x: 123,
              center_y: 121,
              start_angle: 211,
              end_angle: 511,
              radius: 46,
              line_width: 8,
              corner_flag: 0,
              color: 0xFFF3FF1A,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            
            const step = hmSensor.createSensor(hmSensor.id.STEP);
            step.addEventListener(hmSensor.event.CHANGE, function() {
              scale_call();
            });

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 83,
              y: 111,
              font_array: ["0013.png","0014.png","0015.png","0016.png","0017.png","0018.png","0019.png","0020.png","0021.png","0022.png"],
              padding: false,
              h_space: -4,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 40,
              y: 226,
              font_array: ["0013.png","0014.png","0015.png","0016.png","0017.png","0018.png","0019.png","0020.png","0021.png","0022.png"],
              padding: false,
              h_space: -2,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 186,
              hour_startY: 79,
              hour_array: ["0001.png","0002.png","0003.png","0004.png","0005.png","0006.png","0007.png","0008.png","0009.png","0010.png"],
              hour_zero: 1,
              hour_space: 0,
              hour_angle: 0,
              hour_align: hmUI.align.LEFT,

              minute_startX: 186,
              minute_startY: 233,
              minute_array: ["0001.png","0002.png","0003.png","0004.png","0005.png","0006.png","0007.png","0008.png","0009.png","0010.png"],
              minute_zero: 1,
              minute_space: 0,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              second_startX: 400,
              second_startY: 240,
              second_array: ["0013.png","0014.png","0015.png","0016.png","0017.png","0018.png","0019.png","0020.png","0021.png","0022.png"],
              second_zero: 1,
              second_space: 2,
              second_angle: 0,
              second_follow: 0,
              second_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });



            idle_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 68,
              hour_startY: 79,
              hour_array: ["0001.png","0002.png","0003.png","0004.png","0005.png","0006.png","0007.png","0008.png","0009.png","0010.png"],
              hour_zero: 1,
              hour_space: 0,
              hour_angle: 0,
              hour_align: hmUI.align.LEFT,

              minute_startX: 184,
              minute_startY: 233,
              minute_array: ["0001.png","0002.png","0003.png","0004.png","0005.png","0006.png","0007.png","0008.png","0009.png","0010.png"],
              minute_zero: 1,
              minute_space: 0,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_AOD,
            });

            normal_stopwatch_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 397,
              y: 241,
              w: 51,
              h: 51,
              src: '0077.png',
              type: hmUI.data_type.STOP_WATCH,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sunrise_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 396,
              y: 130,
              w: 51,
              h: 51,
              src: '0077.png',
              type: hmUI.data_type.SUN_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 397,
              y: 185,
              w: 51,
              h: 51,
              src: '0077.png',
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 43,
              y: 215,
              w: 51,
              h: 51,
              src: '0077.png',
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 92,
              y: 100,
              w: 51,
              h: 51,
              src: '0077.png',
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            function scale_call() {

                console.log('update scales BATTERY');
                
                let valueBattery = battery.current;
                let targetBattery = 100;
                let progressBattery = valueBattery/targetBattery;
                if (progressBattery > 1) progressBattery = 1;
                let progress_cs_normal_battery = progressBattery;

                if (screenType != hmSetting.screen_type.AOD) {

                  // normal_battery_circle_scale_circle_scale
                  let level = Math.round(progress_cs_normal_battery * 100);
                  if (normal_battery_circle_scale) {
                    normal_battery_circle_scale.setProperty(hmUI.prop.MORE, {                      
                      center_x: 123,
                      center_y: 343,
                      start_angle: 211,
                      end_angle: 512,
                      radius: 46,
                      line_width: 8,
                      corner_flag: 0,
                      color: 0xFFF3FF1A,
                      show_level: hmUI.show_level.ONLY_NORMAL,
                      level: level,
                    });
                  };
                };

                console.log('update scales STEP');
                
                let valueStep = step.current;
                let targetStep = step.target;
                let progressStep = valueStep/targetStep;
                if (progressStep > 1) progressStep = 1;
                let progress_cs_normal_step = progressStep;

                if (screenType != hmSetting.screen_type.AOD) {

                  // normal_step_circle_scale_circle_scale
                  let level = Math.round(progress_cs_normal_step * 100);
                  if (normal_step_circle_scale) {
                    normal_step_circle_scale.setProperty(hmUI.prop.MORE, {                      
                      center_x: 123,
                      center_y: 121,
                      start_angle: 211,
                      end_angle: 511,
                      radius: 46,
                      line_width: 8,
                      corner_flag: 0,
                      color: 0xFFF3FF1A,
                      show_level: hmUI.show_level.ONLY_NORMAL,
                      level: level,
                    });
                  };
                };

            };

            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                scale_call();
              }),
            });

                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}