﻿    /*
     ** Watch_Face_Editor tool
     ** watchface js version v2.1.1
     ** Copyright © SashaCX75. All Rights Reserved
     */

    try {
     (() => {
      //start of ignored block
      const __$$app$$__ = __$$hmAppManager$$__.currentApp;

      function getApp() {
       return __$$app$$__.app;
      }

      function getCurrentPage() {
       return __$$app$$__.current && __$$app$$__.current.module;
      }
      const __$$module$$__ = __$$app$$__.current;
      const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
      const {
       px
      } = __$$app$$__.__globals__;
      const logger = Logger.getLogger('watchface_SashaCX75');
      //end of ignored block

      //dynamic modify start
      const weatherSensor = hmSensor.createSensor(hmSensor.id.WEATHER);
      let timeSensor = hmSensor.createSensor(hmSensor.id.TIME);
      console.log('user_functions.js');
      // start user_functions.js

      const {
       width: D_W,
       height: D_H
      } = hmSetting.getDeviceInfo();
      let groupVremya = ''
     // let groupPogoda = ''
      let groupTap = ''
      let normal_stat_bt_img = ''


      let normal_group_ForecastWeather = ''
      let normal_canvas1 = '';
      let normal_canvas2 = '';
      let normal_forecast_date_week_img = new Array(7);
      let normal_forecast_date_week_img_array = ['week_t_0.png', 'week_t_1.png', 'week_t_2.png', 'week_t_3.png', 'week_t_4.png', 'week_t_5.png', 'week_t_6.png'];
      let normal_forecast_low_text_img = new Array(7);
      let normal_forecast_high_text_img = new Array(7);
      let normal_forecast_image_progress_img_level = new Array(7);
      let normal_forecast_image_array = ['wt_0.png', 'wt_1.png', 'wt_2.png', 'wt_3.png', 'wt_4.png', 'wt_5.png', 'wt_6.png', 'wt_7.png', 'wt_8.png', 'wt_9.png', 'wt_10.png', 'wt_11.png', 'wt_12.png', 'wt_13.png', 'wt_14.png', 'wt_15.png', 'wt_16.png', 'wt_17.png', 'wt_18.png', 'wt_19.png', 'wt_20.png', 'wt_21.png', 'wt_22.png', 'wt_23.png', 'wt_24.png', 'wt_25.png', 'wt_26.png', 'wt_27.png', 'wt_28.png'];
        let normal_forecast_high_text_font = new Array(7);
      let normal_background_bg = ''

            function loadSettings() {

                if (hmFS.SysProGetInt('ANYTIME_color') === undefined) {
                    color = 0;
                    hmFS.SysProSetInt('ANYTIME_color', color);
                } else {
                    color = hmFS.SysProGetInt('ANYTIME_color');
                }

                if (hmFS.SysProGetInt('ANYTIME_zona') === undefined) {
                    zona = 0;
                    hmFS.SysProSetInt('ANYTIME_zona', zona);
                } else {
                    zona = hmFS.SysProGetInt('ANYTIME_zona');
                }

            }
	  
	  
      function makeAOD() {
       // color = hmFS.SysProGetInt('NUMNUM_color');
       const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
        resume_call: (function () {
         stopVibro();
        }),
        pause_call: (function () {
         hmApp.unregisterSpinEvent();
         stopVibro();
        }),
       });
      }


      let color_bg = [0xff0000, 0xFCB61C, 0x068FF9, 0xFFB900, 0xffffff, 0xf8e36c, 0xb84cf6, 0xa3fd1f, 0xfd912f, 0x8cffff, 0xff00a2];


      let crownSensitivity = 70; // уровень чувствительности колесика
      let color = 0;
      let degreeSum = 0;

      //         let MenuCirklDelay = 1000;
      //         let MenuCirkl_Timer = null;


      function onDigitalCrown() {
       hmApp.registerSpinEvent(function (key, degree) {
        if (key === hmApp.key.HOME) {
         degreeSum += degree;
         if (Math.abs(degreeSum) > crownSensitivity) {


          // if (blok_btn == 0) {
          let step = degreeSum < 0 ? -1 : 1;
          color += step;
          color = color < 0 ? color_bg.length + color : color % color_bg.length;
          degreeSum = 0;
			 
             hmFS.SysProSetInt('ANYTIME_color', color);

          normal_background_bg.setProperty(hmUI.prop.COLOR, color_bg[color]);
          normal_city_name_text.setProperty(hmUI.prop.COLOR, color_bg[color]);

          for (let i = 0; i < 7; i++) {
           normal_day_text_font_[i].setProperty(hmUI.prop.MORE, {
            x: 25 + i * 44, //159
            y: 293 - 59,
            w: 150,
            h: 40,
            text_size: 27,
            char_space: 0,
            line_space: 0,
            font: 'fonts/Oswald-Regular.ttf',
            color: i == timeSensor.week - 1 ? color_bg[color] : "0xFFFFFFFF",
            align_h: hmUI.align.CENTER_H,
            align_v: hmUI.align.TOP,
            text_style: hmUI.text_style.ELLIPSIS,
            show_level: hmUI.show_level.ONLY_NORMAL,
           });
          }

          normal_vos_text_font.setProperty(hmUI.prop.MORE, {
           x: -37,
           y: 242,
           w: 150,
           h: 30,
           text_size: 22,
           char_space: 0,
           line_space: 0,
           font: 'fonts/Oswald-Regular.ttf',
           color: color_bg[color],
           align_h: hmUI.align.CENTER_H,
           align_v: hmUI.align.CENTER_V,
           text_style: hmUI.text_style.ELLIPSIS,
           type: hmUI.data_type.SUN_RISE,
           show_level: hmUI.show_level.ONLY_NORMAL,
          });

          normal_zak_text_font.setProperty(hmUI.prop.MORE, {
           x: -37,
           y: 242,
           w: 150,
           h: 30,
           text_size: 22,
           char_space: 0,
           line_space: 0,
           font: 'fonts/Oswald-Regular.ttf',
           color: color_bg[color],
           align_h: hmUI.align.CENTER_H,
           align_v: hmUI.align.CENTER_V,
           text_style: hmUI.text_style.ELLIPSIS,
           type: hmUI.data_type.SUN_SET,
           show_level: hmUI.show_level.ONLY_NORMAL,
          });


          normal_temperature_current_text_font.setProperty(hmUI.prop.MORE, {
           x: 356,
           y: 240,
           w: 150,
           h: 30,
           text_size: 22,
           char_space: 0,
           line_space: 0,
           font: 'fonts/Oswald-Regular.ttf',
           color: color_bg[color],
           align_h: hmUI.align.CENTER_H,
           align_v: hmUI.align.CENTER_V,
           unit_type: 1,
           text_style: hmUI.text_style.ELLIPSIS,
           type: hmUI.data_type.WEATHER_CURRENT,
           show_level: hmUI.show_level.ONLY_NORMAL,
          });


          normal_battery_circle_scale.setProperty(hmUI.prop.MORE, {
           center_x: 102,
           center_y: 339,
           start_angle: 90,
           end_angle: 450,
           radius: 28,
           line_width: 13,
           corner_flag: 3,
           color: color_bg[color],
           type: hmUI.data_type.BATTERY,
           show_level: hmUI.show_level.ONLY_NORMAL,
          });

          normal_calorie_circle_scale.setProperty(hmUI.prop.MORE, {
           center_x: 364,
           center_y: 339,
           start_angle: -90,
           end_angle: -450,
           radius: 28,
           line_width: 13,
           corner_flag: 3,
           color: color_bg[color],
           type: hmUI.data_type.CAL,
           show_level: hmUI.show_level.ONLY_NORMAL,
          });

          normal_calorie_current_text_font.setProperty(hmUI.prop.MORE, {
           x: 289,
           y: 324,
           w: 150,
           h: 30,
           text_size: 25,
           char_space: 0,
           line_space: 0,
           font: 'fonts/Oswald-Regular.ttf',
           color: color_bg[color],
           align_h: hmUI.align.CENTER_H,
           align_v: hmUI.align.CENTER_V,
           text_style: hmUI.text_style.ELLIPSIS,
           type: hmUI.data_type.CAL,
           show_level: hmUI.show_level.ONLY_NORMAL,
          });

          normal_battery_current_text_font.setProperty(hmUI.prop.MORE, {
           x: 28,
           y: 324,
           w: 150,
           h: 30,
           text_size: 25,
           char_space: 0,
           line_space: 0,
           font: 'fonts/Oswald-Regular.ttf',
           color: color_bg[color],
           align_h: hmUI.align.CENTER_H,
           align_v: hmUI.align.CENTER_V,
           text_style: hmUI.text_style.ELLIPSIS,
           type: hmUI.data_type.BATTERY,
           show_level: hmUI.show_level.ONLY_NORMAL,
          });

          //                   normal_battery_circle_scale.setProperty(hmUI.prop.MORE, {                      
          //                      center_x: 134,
          //                      center_y: 233,
          //                      start_angle: -183,
          //                      end_angle: 3,
          //                      radius: 135,
          //                      line_width: 197,
          //                      corner_flag: 3,
          //                      color: color_bg[color],
          //                      show_level: hmUI.show_level.ONLY_NORMAL,
          //                      //level: level,
          //                    });


          //  hmFS.SysProSetInt('NUMNUM_color', color);                   


          //              idle_background_bg.setProperty(hmUI.prop.COLOR, color_bg[color]);
          vibro();

          //  }
         }
        }
       }) // crown
      }


      const vibrate = hmSensor.createSensor(hmSensor.id.VIBRATE)
      let stopVibro_Timer = null;

      function vibro(scene = 25) {
       let stopDelay = 50;
       vibrate.stop();
       vibrate.scene = scene;
       if (scene < 23 || scene > 25) stopDelay = 1220;
       vibrate.start();
       stopVibro_Timer = timer.createTimer(stopDelay, 0, stopVibro, {});
      }

      function stopVibro() {
       vibrate.stop();
       timer.stopTimer(stopVibro_Timer);
      }
		 
		 let zona = 0
      function click_Pogoda_on() {
		zona = (zona + 1)%2  
		  hmFS.SysProSetInt('ANYTIME_zona', zona);
       groupVremya.setProperty(hmUI.prop.VISIBLE, zona == 0);
		normal_distance_icon_img.setProperty(hmUI.prop.VISIBLE, zona == 1);
       normal_group_ForecastWeather.setProperty(hmUI.prop.VISIBLE, zona == 1);
      }

      function click_Pogoda_off() {
		zona = (zona + 1)%2 
		  hmFS.SysProSetInt('ANYTIME_zona', zona);
       groupVremya.setProperty(hmUI.prop.VISIBLE, zona == 0);
		normal_distance_icon_img.setProperty(hmUI.prop.VISIBLE, zona == 1); 
       normal_group_ForecastWeather.setProperty(hmUI.prop.VISIBLE, zona == 1);
      }

      let apps = [
       ['Нет действия', '-', `tap/i_tap_pusto.png`],
       ['Таймер', 'CountdownAppScreen', `tap/i_tap_obrat_otchet.png`],
       ['Секундомер', 'StopWatchScreen', `tap/i_tap_secundomer.png`],
       ['Мировые часы', 'WorldClockScreen', `tap/i_tap_mirivie_chasi.png`],
       ['Восход/закат', 'TideScreen', `tap/i_tap_voshod_zakat.png`],
       ['Сон', 'Sleep_HomeScreen', `tap/i_tap_son.png`],
       ['Стресс', 'StressHomeScreen', `tap/i_tap_stress.png`],
       ['SP02 (Кислород)', 'spo_HomeScreen', `tap/i_tap_kislorod.png`],
       ['Дыхание', 'RespirationsettingScreen', `tap/i_tap_dihanie.png`],
       ['Измерение одним касанием', 'oneKeyAppScreen', `tap/i_tap_1_kosanie.png`],
       ['Женский календарь', 'menstrualAppScreen', `tap/i_tap_gensk_calendar.png`],
       ['Найти телефон', 'FindPhoneScreen', `tap/i_tap_naiti_telo.png`],
       ['Музыка', 'PhoneMusicCtrlScreen', `tap/i_tap_musik.png`],
       ['Компас', 'CompassScreen', `tap/i_tap_kompas.png`],
       ['Набрать номер', 'DialCallScreen', `tap/i_tap_nabor.png`],
       ['Телефон', 'PhoneHomeScreen', `tap/i_tap_telefon.png`],
       ['Диктофон', 'VoiceMemoScreen', `tap/i_tap_dictofon.png`],
       ['Расписание', 'ScheduleListScreen', `tap/i_tap_raspisanie.png`],
       ['Список дел', 'todoListScreen', `tap/i_tap_spisok_del.png`],
       ['Календарь', 'ScheduleCalScreen', `tap/i_tap_calendar.png`],
       ['Погода', 'WeatherScreen', `tap/i_tap_pogoda.png`],
       ['Настройка', 'Settings_homeScreen', `tap/i_tap_sitting.png`],
       ['Камера', 'HidcameraScreen', `tap/i_tap_camera.png`],
       ['Пульс', 'heart_app_Screen', `tap/i_tap_puls.png`],
       ['Будильник', 'AlarmInfoScreen', `tap/i_tap_budilnik.png`],
       ['PAI', 'PAI_app_Screen', `tap/i_tap_pai.png`],
       ['Тренировка', 'SportListScreen', `tap/i_tap_trenerovka.png`],
       ['AOD', 'Settings_standbyModelScreen', `tap/i_tap_aod.png`],
       ['Экономия заряда', 'LowBatteryScreen', `tap/i_tap_LowBattery.png`],
       ['Давление/Высота', 'BaroAltimeterScreen', `tap/i_tap_barometr.png`]
      ];


      const tap_1_edit = hmUI.createWidget(hmUI.widget.WATCHFACE_EDIT_GROUP, {
       edit_id: 101,
       x: 171,
       y: 20,
       w: 124,
       h: 124,
       select_image: 'tap/edit_red_1.png',
       un_select_image: 'tap/edit_griin_1.png',
       default_type: 19,
       optional_types: [{
        type: 0,
        preview: apps[0][2],
        title_en: apps[0][0]
       }, {
        type: 1,
        preview: apps[1][2],
        title_en: apps[1][0]
       }, {
        type: 2,
        preview: apps[2][2],
        title_en: apps[2][0]
       }, {
        type: 3,
        preview: apps[3][2],
        title_en: apps[3][0]
       }, {
        type: 4,
        preview: apps[4][2],
        title_en: apps[4][0]
       }, {
        type: 5,
        preview: apps[5][2],
        title_en: apps[5][0]
       }, {
        type: 6,
        preview: apps[6][2],
        title_en: apps[6][0]
       }, {
        type: 7,
        preview: apps[7][2],
        title_en: apps[7][0]
       }, {
        type: 8,
        preview: apps[8][2],
        title_en: apps[8][0]
       }, {
        type: 9,
        preview: apps[9][2],
        title_en: apps[9][0]
       }, {
        type: 10,
        preview: apps[10][2],
        title_en: apps[10][0]
       }, {
        type: 11,
        preview: apps[11][2],
        title_en: apps[11][0]
       }, {
        type: 12,
        preview: apps[12][2],
        title_en: apps[12][0]
       }, {
        type: 13,
        preview: apps[13][2],
        title_en: apps[13][0]
       }, {
        type: 14,
        preview: apps[14][2],
        title_en: apps[14][0]
       }, {
        type: 15,
        preview: apps[15][2],
        title_en: apps[15][0]
       }, {
        type: 16,
        preview: apps[16][2],
        title_en: apps[16][0]
       }, {
        type: 17,
        preview: apps[17][2],
        title_en: apps[17][0]
       }, {
        type: 18,
        preview: apps[18][2],
        title_en: apps[18][0]
       }, {
        type: 19,
        preview: apps[19][2],
        title_en: apps[19][0]
       }, {
        type: 20,
        preview: apps[20][2],
        title_en: apps[20][0]
       }, {
        type: 21,
        preview: apps[21][2],
        title_en: apps[21][0]
       }, {
        type: 22,
        preview: apps[22][2],
        title_en: apps[22][0]
       }, {
        type: 23,
        preview: apps[23][2],
        title_en: apps[23][0]
       }, {
        type: 24,
        preview: apps[24][2],
        title_en: apps[24][0]
       }, {
        type: 25,
        preview: apps[25][2],
        title_en: apps[25][0]
       }, {
        type: 26,
        preview: apps[26][2],
        title_en: apps[26][0]
       }, {
        type: 27,
        preview: apps[27][2],
        title_en: apps[27][0]
       }, {
        type: 28,
        preview: apps[28][2],
        title_en: apps[28][0]
       }, {
        type: 29,
        preview: apps[29][2],
        title_en: apps[29][0]
       }, ],
       count: 30,
       tips_x: 135 - 171,
       tips_y: 150 - 20,
       tips_width: 195,
       tips_margin: 10,
       tips_BG: 'tap/tips_bg.png'
      })

      let tap_1_select = tap_1_edit.getProperty(hmUI.prop.CURRENT_TYPE)

      const tap_2_edit = hmUI.createWidget(hmUI.widget.WATCHFACE_EDIT_GROUP, {
       edit_id: 102,
       x: 301,
       y: 95,
       w: 124,
       h: 124,
       select_image: 'tap/edit_red_1.png',
       un_select_image: 'tap/edit_griin_1.png',
       default_type: 20,
       optional_types: [{
        type: 0,
        preview: apps[0][2],
        title_en: apps[0][0]
       }, {
        type: 1,
        preview: apps[1][2],
        title_en: apps[1][0]
       }, {
        type: 2,
        preview: apps[2][2],
        title_en: apps[2][0]
       }, {
        type: 3,
        preview: apps[3][2],
        title_en: apps[3][0]
       }, {
        type: 4,
        preview: apps[4][2],
        title_en: apps[4][0]
       }, {
        type: 5,
        preview: apps[5][2],
        title_en: apps[5][0]
       }, {
        type: 6,
        preview: apps[6][2],
        title_en: apps[6][0]
       }, {
        type: 7,
        preview: apps[7][2],
        title_en: apps[7][0]
       }, {
        type: 8,
        preview: apps[8][2],
        title_en: apps[8][0]
       }, {
        type: 9,
        preview: apps[9][2],
        title_en: apps[9][0]
       }, {
        type: 10,
        preview: apps[10][2],
        title_en: apps[10][0]
       }, {
        type: 11,
        preview: apps[11][2],
        title_en: apps[11][0]
       }, {
        type: 12,
        preview: apps[12][2],
        title_en: apps[12][0]
       }, {
        type: 13,
        preview: apps[13][2],
        title_en: apps[13][0]
       }, {
        type: 14,
        preview: apps[14][2],
        title_en: apps[14][0]
       }, {
        type: 15,
        preview: apps[15][2],
        title_en: apps[15][0]
       }, {
        type: 16,
        preview: apps[16][2],
        title_en: apps[16][0]
       }, {
        type: 17,
        preview: apps[17][2],
        title_en: apps[17][0]
       }, {
        type: 18,
        preview: apps[18][2],
        title_en: apps[18][0]
       }, {
        type: 19,
        preview: apps[19][2],
        title_en: apps[19][0]
       }, {
        type: 20,
        preview: apps[20][2],
        title_en: apps[20][0]
       }, {
        type: 21,
        preview: apps[21][2],
        title_en: apps[21][0]
       }, {
        type: 22,
        preview: apps[22][2],
        title_en: apps[22][0]
       }, {
        type: 23,
        preview: apps[23][2],
        title_en: apps[23][0]
       }, {
        type: 24,
        preview: apps[24][2],
        title_en: apps[24][0]
       }, {
        type: 25,
        preview: apps[25][2],
        title_en: apps[25][0]
       }, {
        type: 26,
        preview: apps[26][2],
        title_en: apps[26][0]
       }, {
        type: 27,
        preview: apps[27][2],
        title_en: apps[27][0]
       }, {
        type: 28,
        preview: apps[28][2],
        title_en: apps[28][0]
       }, {
        type: 29,
        preview: apps[29][2],
        title_en: apps[29][0]
       }, ],
       count: 30,
       tips_x: 266 - 301,
       tips_y: 225 - 95,
       tips_width: 195,
       tips_margin: 10,
       tips_BG: 'tap/tips_bg.png'
      })


      let tap_2_select = tap_2_edit.getProperty(hmUI.prop.CURRENT_TYPE)


      const tap_3_edit = hmUI.createWidget(hmUI.widget.WATCHFACE_EDIT_GROUP, {
       edit_id: 103,
       x: 301,
       y: 246,
       w: 124,
       h: 124,
       select_image: 'tap/edit_red_1.png',
       un_select_image: 'tap/edit_griin_1.png',
       default_type: 24,
       optional_types: [{
        type: 0,
        preview: apps[0][2],
        title_en: apps[0][0]
       }, {
        type: 1,
        preview: apps[1][2],
        title_en: apps[1][0]
       }, {
        type: 2,
        preview: apps[2][2],
        title_en: apps[2][0]
       }, {
        type: 3,
        preview: apps[3][2],
        title_en: apps[3][0]
       }, {
        type: 4,
        preview: apps[4][2],
        title_en: apps[4][0]
       }, {
        type: 5,
        preview: apps[5][2],
        title_en: apps[5][0]
       }, {
        type: 6,
        preview: apps[6][2],
        title_en: apps[6][0]
       }, {
        type: 7,
        preview: apps[7][2],
        title_en: apps[7][0]
       }, {
        type: 8,
        preview: apps[8][2],
        title_en: apps[8][0]
       }, {
        type: 9,
        preview: apps[9][2],
        title_en: apps[9][0]
       }, {
        type: 10,
        preview: apps[10][2],
        title_en: apps[10][0]
       }, {
        type: 11,
        preview: apps[11][2],
        title_en: apps[11][0]
       }, {
        type: 12,
        preview: apps[12][2],
        title_en: apps[12][0]
       }, {
        type: 13,
        preview: apps[13][2],
        title_en: apps[13][0]
       }, {
        type: 14,
        preview: apps[14][2],
        title_en: apps[14][0]
       }, {
        type: 15,
        preview: apps[15][2],
        title_en: apps[15][0]
       }, {
        type: 16,
        preview: apps[16][2],
        title_en: apps[16][0]
       }, {
        type: 17,
        preview: apps[17][2],
        title_en: apps[17][0]
       }, {
        type: 18,
        preview: apps[18][2],
        title_en: apps[18][0]
       }, {
        type: 19,
        preview: apps[19][2],
        title_en: apps[19][0]
       }, {
        type: 20,
        preview: apps[20][2],
        title_en: apps[20][0]
       }, {
        type: 21,
        preview: apps[21][2],
        title_en: apps[21][0]
       }, {
        type: 22,
        preview: apps[22][2],
        title_en: apps[22][0]
       }, {
        type: 23,
        preview: apps[23][2],
        title_en: apps[23][0]
       }, {
        type: 24,
        preview: apps[24][2],
        title_en: apps[24][0]
       }, {
        type: 25,
        preview: apps[25][2],
        title_en: apps[25][0]
       }, {
        type: 26,
        preview: apps[26][2],
        title_en: apps[26][0]
       }, {
        type: 27,
        preview: apps[27][2],
        title_en: apps[27][0]
       }, {
        type: 28,
        preview: apps[28][2],
        title_en: apps[28][0]
       }, {
        type: 29,
        preview: apps[29][2],
        title_en: apps[29][0]
       }, ],
       count: 30,
       tips_x: 266 - 301,
       tips_y: 184 - 246,
       tips_width: 195,
       tips_margin: 10,
       tips_BG: 'tap/tips_bg.png'
      })

      let tap_3_select = tap_3_edit.getProperty(hmUI.prop.CURRENT_TYPE)

      const tap_4_edit = hmUI.createWidget(hmUI.widget.WATCHFACE_EDIT_GROUP, {
       edit_id: 104,
       x: 171,
       y: 321,
       w: 124,
       h: 124,
       select_image: 'tap/edit_red_1.png',
       un_select_image: 'tap/edit_griin_1.png',
       default_type: 11,
       optional_types: [{
        type: 0,
        preview: apps[0][2],
        title_en: apps[0][0]
       }, {
        type: 1,
        preview: apps[1][2],
        title_en: apps[1][0]
       }, {
        type: 2,
        preview: apps[2][2],
        title_en: apps[2][0]
       }, {
        type: 3,
        preview: apps[3][2],
        title_en: apps[3][0]
       }, {
        type: 4,
        preview: apps[4][2],
        title_en: apps[4][0]
       }, {
        type: 5,
        preview: apps[5][2],
        title_en: apps[5][0]
       }, {
        type: 6,
        preview: apps[6][2],
        title_en: apps[6][0]
       }, {
        type: 7,
        preview: apps[7][2],
        title_en: apps[7][0]
       }, {
        type: 8,
        preview: apps[8][2],
        title_en: apps[8][0]
       }, {
        type: 9,
        preview: apps[9][2],
        title_en: apps[9][0]
       }, {
        type: 10,
        preview: apps[10][2],
        title_en: apps[10][0]
       }, {
        type: 11,
        preview: apps[11][2],
        title_en: apps[11][0]
       }, {
        type: 12,
        preview: apps[12][2],
        title_en: apps[12][0]
       }, {
        type: 13,
        preview: apps[13][2],
        title_en: apps[13][0]
       }, {
        type: 14,
        preview: apps[14][2],
        title_en: apps[14][0]
       }, {
        type: 15,
        preview: apps[15][2],
        title_en: apps[15][0]
       }, {
        type: 16,
        preview: apps[16][2],
        title_en: apps[16][0]
       }, {
        type: 17,
        preview: apps[17][2],
        title_en: apps[17][0]
       }, {
        type: 18,
        preview: apps[18][2],
        title_en: apps[18][0]
       }, {
        type: 19,
        preview: apps[19][2],
        title_en: apps[19][0]
       }, {
        type: 20,
        preview: apps[20][2],
        title_en: apps[20][0]
       }, {
        type: 21,
        preview: apps[21][2],
        title_en: apps[21][0]
       }, {
        type: 22,
        preview: apps[22][2],
        title_en: apps[22][0]
       }, {
        type: 23,
        preview: apps[23][2],
        title_en: apps[23][0]
       }, {
        type: 24,
        preview: apps[24][2],
        title_en: apps[24][0]
       }, {
        type: 25,
        preview: apps[25][2],
        title_en: apps[25][0]
       }, {
        type: 26,
        preview: apps[26][2],
        title_en: apps[26][0]
       }, {
        type: 27,
        preview: apps[27][2],
        title_en: apps[27][0]
       }, {
        type: 28,
        preview: apps[28][2],
        title_en: apps[28][0]
       }, {
        type: 29,
        preview: apps[29][2],
        title_en: apps[29][0]
       }, ],
       count: 30,
       tips_x: 135 - 171,
       tips_y: 257 - 321,
       tips_width: 195,
       tips_margin: 10,
       tips_BG: 'tap/tips_bg.png'
      })

      let tap_4_select = tap_4_edit.getProperty(hmUI.prop.CURRENT_TYPE)

      const tap_5_edit = hmUI.createWidget(hmUI.widget.WATCHFACE_EDIT_GROUP, {
       edit_id: 105,
       x: 40,
       y: 246,
       w: 124,
       h: 124,
       select_image: 'tap/edit_red_1.png',
       un_select_image: 'tap/edit_griin_1.png',
       default_type: 0,
       optional_types: [{
        type: 0,
        preview: apps[0][2],
        title_en: apps[0][0]
       }, {
        type: 1,
        preview: apps[1][2],
        title_en: apps[1][0]
       }, {
        type: 2,
        preview: apps[2][2],
        title_en: apps[2][0]
       }, {
        type: 3,
        preview: apps[3][2],
        title_en: apps[3][0]
       }, {
        type: 4,
        preview: apps[4][2],
        title_en: apps[4][0]
       }, {
        type: 5,
        preview: apps[5][2],
        title_en: apps[5][0]
       }, {
        type: 6,
        preview: apps[6][2],
        title_en: apps[6][0]
       }, {
        type: 7,
        preview: apps[7][2],
        title_en: apps[7][0]
       }, {
        type: 8,
        preview: apps[8][2],
        title_en: apps[8][0]
       }, {
        type: 9,
        preview: apps[9][2],
        title_en: apps[9][0]
       }, {
        type: 10,
        preview: apps[10][2],
        title_en: apps[10][0]
       }, {
        type: 11,
        preview: apps[11][2],
        title_en: apps[11][0]
       }, {
        type: 12,
        preview: apps[12][2],
        title_en: apps[12][0]
       }, {
        type: 13,
        preview: apps[13][2],
        title_en: apps[13][0]
       }, {
        type: 14,
        preview: apps[14][2],
        title_en: apps[14][0]
       }, {
        type: 15,
        preview: apps[15][2],
        title_en: apps[15][0]
       }, {
        type: 16,
        preview: apps[16][2],
        title_en: apps[16][0]
       }, {
        type: 17,
        preview: apps[17][2],
        title_en: apps[17][0]
       }, {
        type: 18,
        preview: apps[18][2],
        title_en: apps[18][0]
       }, {
        type: 19,
        preview: apps[19][2],
        title_en: apps[19][0]
       }, {
        type: 20,
        preview: apps[20][2],
        title_en: apps[20][0]
       }, {
        type: 21,
        preview: apps[21][2],
        title_en: apps[21][0]
       }, {
        type: 22,
        preview: apps[22][2],
        title_en: apps[22][0]
       }, {
        type: 23,
        preview: apps[23][2],
        title_en: apps[23][0]
       }, {
        type: 24,
        preview: apps[24][2],
        title_en: apps[24][0]
       }, {
        type: 25,
        preview: apps[25][2],
        title_en: apps[25][0]
       }, {
        type: 26,
        preview: apps[26][2],
        title_en: apps[26][0]
       }, {
        type: 27,
        preview: apps[27][2],
        title_en: apps[27][0]
       }, {
        type: 28,
        preview: apps[28][2],
        title_en: apps[28][0]
       }, {
        type: 29,
        preview: apps[29][2],
        title_en: apps[29][0]
       }, ],
       count: 30,
       tips_x: 5 - 40,
       tips_y: 184 - 246,
       tips_width: 195,
       tips_margin: 10,
       tips_BG: 'tap/tips_bg.png'
      })

      let tap_5_select = tap_5_edit.getProperty(hmUI.prop.CURRENT_TYPE)

      const tap_6_edit = hmUI.createWidget(hmUI.widget.WATCHFACE_EDIT_GROUP, {
       edit_id: 106,
       x: 40,
       y: 95,
       w: 124,
       h: 124,
       select_image: 'tap/edit_red_1.png',
       un_select_image: 'tap/edit_griin_1.png',
       default_type: 0,
       optional_types: [{
        type: 0,
        preview: apps[0][2],
        title_en: apps[0][0]
       }, {
        type: 1,
        preview: apps[1][2],
        title_en: apps[1][0]
       }, {
        type: 2,
        preview: apps[2][2],
        title_en: apps[2][0]
       }, {
        type: 3,
        preview: apps[3][2],
        title_en: apps[3][0]
       }, {
        type: 4,
        preview: apps[4][2],
        title_en: apps[4][0]
       }, {
        type: 5,
        preview: apps[5][2],
        title_en: apps[5][0]
       }, {
        type: 6,
        preview: apps[6][2],
        title_en: apps[6][0]
       }, {
        type: 7,
        preview: apps[7][2],
        title_en: apps[7][0]
       }, {
        type: 8,
        preview: apps[8][2],
        title_en: apps[8][0]
       }, {
        type: 9,
        preview: apps[9][2],
        title_en: apps[9][0]
       }, {
        type: 10,
        preview: apps[10][2],
        title_en: apps[10][0]
       }, {
        type: 11,
        preview: apps[11][2],
        title_en: apps[11][0]
       }, {
        type: 12,
        preview: apps[12][2],
        title_en: apps[12][0]
       }, {
        type: 13,
        preview: apps[13][2],
        title_en: apps[13][0]
       }, {
        type: 14,
        preview: apps[14][2],
        title_en: apps[14][0]
       }, {
        type: 15,
        preview: apps[15][2],
        title_en: apps[15][0]
       }, {
        type: 16,
        preview: apps[16][2],
        title_en: apps[16][0]
       }, {
        type: 17,
        preview: apps[17][2],
        title_en: apps[17][0]
       }, {
        type: 18,
        preview: apps[18][2],
        title_en: apps[18][0]
       }, {
        type: 19,
        preview: apps[19][2],
        title_en: apps[19][0]
       }, {
        type: 20,
        preview: apps[20][2],
        title_en: apps[20][0]
       }, {
        type: 21,
        preview: apps[21][2],
        title_en: apps[21][0]
       }, {
        type: 22,
        preview: apps[22][2],
        title_en: apps[22][0]
       }, {
        type: 23,
        preview: apps[23][2],
        title_en: apps[23][0]
       }, {
        type: 24,
        preview: apps[24][2],
        title_en: apps[24][0]
       }, {
        type: 25,
        preview: apps[25][2],
        title_en: apps[25][0]
       }, {
        type: 26,
        preview: apps[26][2],
        title_en: apps[26][0]
       }, {
        type: 27,
        preview: apps[27][2],
        title_en: apps[27][0]
       }, {
        type: 28,
        preview: apps[28][2],
        title_en: apps[28][0]
       }, {
        type: 29,
        preview: apps[29][2],
        title_en: apps[29][0]
       }, ],
       count: 30,
       tips_x: 5 - 40,
       tips_y: 225 - 95,

       tips_width: 195,
       tips_margin: 10,
       tips_BG: 'tap/tips_bg.png'
      })

      let tap_6_select = tap_6_edit.getProperty(hmUI.prop.CURRENT_TYPE)

      let btn_tap = ''
      let btn_click_tap_exit = ''

      let btn_Tap_zona_0 = ''
      let btn_Tap_zona_1 = ''
      let btn_Tap_zona_2 = ''
      let btn_Tap_zona_3 = ''
      let btn_Tap_zona_4 = ''
      let btn_Tap_zona_5 = ''

      function tap_zona_exit() {
       groupVremya.setProperty(hmUI.prop.VISIBLE, zona == 0); 
		normal_distance_icon_img.setProperty(hmUI.prop.VISIBLE, zona == 1); 
       normal_group_ForecastWeather.setProperty(hmUI.prop.VISIBLE, zona == 1);
       groupTap.setProperty(hmUI.prop.VISIBLE, false);
		btn_tap.setProperty(hmUI.prop.VISIBLE, true);  
  
      }

      let tap_x_y = [
       [178, 26, 1],
       [308, 102, 1],
       [308, 253, 1],
       [178, 328, 0],
       [47, 253, 0],
       [47, 102, 0]
      ];

      function tap_run() {
       groupVremya.setProperty(hmUI.prop.VISIBLE, false); 
		normal_distance_icon_img.setProperty(hmUI.prop.VISIBLE, false); 
       normal_group_ForecastWeather.setProperty(hmUI.prop.VISIBLE, false);
       groupTap.setProperty(hmUI.prop.VISIBLE, true);
		btn_tap.setProperty(hmUI.prop.VISIBLE, false);  
      }

      //переменные для ргафика
      let weatherArrayGrafik = [] //есть
      let weatherIconImgArrayGrafik = [] //есть
      let weatherTxtImgArray = []
      let weatherTxtImgArrayN = []
      let pointred = new Array(6);
      let pointblue = new Array(5);
      let linered = new Array(6);
      let lineblue = new Array(5);
     // let yArrH = new Array(6);
      let yArrL = new Array(5);
      let y_pogodaH = new Array(6);
      let y_pogodaL = new Array(5);
      let week_weater = ["ПН", "ВТ", "СР", "ЧТ", "ПТ", "СБ", "ВС"];
      let week_weater_img = []
      let day_weater_img = []
      const ROOTPATH = "images/"

      let isDayIcons = false;

      let shotWeaterhNames = ["ОБЛАЧНО", "МЕСТАМИ ДОЖДЬ", "МЕСТАМИ СНЕГ", "ЯСНО", "ПАСМУРНО", "СЛАБЫЙ ДОЖДЬ", "СЛАБЫЙ СНЕГ", "УМЕРЕННЫЙ ДОЖДЬ", "УМЕРЕННЫЙ СНЕГ", "СИЛЬНЫЙ СНЕГОПАД", "СИЛЬНЫЙ ДОЖДЬ", "ПЕСЧАНАЯ БУРЯ", "МОКРЫЙ СНЕГ", "ТУМАН", "ДЫМКА", "ДОЖДЬ С ГРОЗОЙ", "МЕТЕЛЬ", "ПЫЛЬНО", "ЛИВЕНЬ", "ДОЖДЬ С ГРАДОМ", "СИЛЬНЫЙ ДОЖДЬ С ГРАДОМ", "СИЛЬНЫЙ ДОЖДЬ", "ПЕСЧАНАЯ БУРЯ", "СИЛЬНАЯ ПЕСЧАНАЯ БУРЯ", "СИЛЬНЫЙ ДОЖДЬ", "НЕИЗВЕСТНАЯ ПОГОДА", "ОБЛАЧНО НОЧЬЮ", "ДОЖДЛИВО НОЧЬЮ", "ЯСНО НОЧЬЮ"];
      //let normal_city_name_text = ''
      //let timeSensor = hmSensor.createSensor(hmSensor.id.TIME);


      let day_num = [0, 31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31];
      let year = timeSensor.year;
      if (year % 4 == 0 && (year % 100 != 0 || year % 400 == 0)) { // Високосный год
       day_num[2] = 29
      } else {
       day_num[2] = 28
      }

      let normal_day_text_font_ = []


      //-------------------------------- 


      //обновление для   графика           
      function updateGrafik() {
       let weatherData = weatherSensor.getForecastWeather();
       let forecastData = weatherData.forecastData;

       let current = weatherSensor.current;
       let curAirIconIndex = weatherSensor.curAirIconIndex;

       normal_weather_text_font.setProperty(hmUI.prop.TEXT, shotWeaterhNames[curAirIconIndex]);


       normal_city_name_text.setProperty(hmUI.prop.TEXT, weatherData.cityName);

       // let week0 = timeSensor.week;
       let weekDay = timeSensor.week - 1;
       let data_gr = timeSensor.day;
       let month_gr = timeSensor.month;
       let data = timeSensor.day;

       let data_plus = 33;
       let m_data = timeSensor.day;
       let week = timeSensor.week;
       let m_month = timeSensor.month;
       let month44 = 0;


       sunData = weatherData.tideData;
       if (sunData.count > 0) {
        today = sunData.data[0];
        sunriseMins = today.sunrise.hour * 60 + today.sunrise.minute;
        sunsetMins = today.sunset.hour * 60 + today.sunset.minute;
       } else {
        sunriseMins = sunriseMins_def;
        sunsetMins = sunsetMins_def;
       }
       curMins = timeSensor.hour * 60 + timeSensor.minute;
       let isDayNow = (curMins >= sunriseMins) && (curMins < sunsetMins);

       if (isDayNow) {
        if (!isDayIcons) {
         isDayIcons = true;
        }
       } else {
        if (isDayIcons) {
         isDayIcons = false;
        }
       }

       normal_vos_text_font.setProperty(hmUI.prop.VISIBLE, isDayIcons == false);
       normal_vos_icon_img.setProperty(hmUI.prop.VISIBLE, isDayIcons == false);
       normal_zak_text_font.setProperty(hmUI.prop.VISIBLE, isDayIcons == true);
       normal_zak_icon_img.setProperty(hmUI.prop.VISIBLE, isDayIcons == true);


       for (let i = 0; i < 7; i++) {

        data_plus = m_data - week + 1 + i

        if (data_plus > day_num[m_month]) {
         data_plus2 = data_plus2 + 1
         data = data_plus2
         month44 = m_month + 1
         if (month44 == 13) month44 = 1
        } else {
         data = data_plus
         month44 = m_month
        }
        if (data_plus < 1) {
         m_month = m_month - 1 == 0 ? m_month = 13 : m_month
         data = data_plus + day_num[m_month - 1]
         month44 = m_month - 1
        }
        if (i == week - 1) {
         data = m_data
        }

        normal_day_text_font_[i].setProperty(hmUI.prop.MORE, {
         x: 25 + i * 44, //159
         y: 293 - 59,
         w: 150,
         h: 40,
         text_size: 27,
         // text: 88, //timeSensor.day-1 среда = 2 // day_num[month]
         text: data, //timeSensor.day-1 среда = 2 // day_num[month]
         char_space: 0,
         line_space: 0,
         font: 'fonts/Oswald-Regular.ttf',
         color: i == timeSensor.week - 1 ? color_bg[color] : "0xFFFFFFFF",
         // color: 0xffffff,
         // color: week == i ? 0xFFFFffFF:0xFFFFffFF,
         align_h: hmUI.align.CENTER_H,
         align_v: hmUI.align.TOP,
         text_style: hmUI.text_style.ELLIPSIS,
         show_level: hmUI.show_level.ONLY_NORMAL,
        });

       }


      }
      // end user_functions.js

      let normal_image_img = ''
      let normal_month_name_font = ''
      let normal_Month_Array = ['ЯНВАРЬ', 'ФЕВРАЛЬ', 'МАРТ', 'АПРЕЛЬ', 'МАЙ', 'ИЮНЬ', 'ИЮЛЬ', 'АВГУСТ', 'СЕНТЯБРЬ', 'ОКТЯБРЬ', 'НОЯБРЬ', 'ДЕКАБРЬ', ];
      let normal_time_hour_min_text_font = ''
      let normal_timerTimeUpdate = undefined;
      let normal_time_second_text_font = ''
      let normal_heart_rate_text_font = ''
      let normal_step_current_text_font = ''
      let normal_calorie_circle_scale = ''
      let normal_calorie_icon_img = ''
      let normal_calorie_current_text_font = ''
      let normal_sun_icon_img = ''
      let normal_sun_high_text_font = ''
      let normal_ALARM_CLOCK_text_font = ''
      let normal_distance_current_text_font = ''
      let normal_battery_circle_scale = ''
      let normal_battery_icon_img = ''
      let normal_battery_current_text_font = ''
      let normal_date_img_date_week_img = ''
      let normal_temperature_icon_img = ''
      let normal_city_name_text = ''
      let normal_weather_image_progress_img_level = ''
      let normal_temperature_high_text_font = ''
      let normal_temperature_low_text_font = ''
      let normal_temperature_current_text_font = ''
      let normal_system_disconnect_img = ''
      // let timeSensor = ''


      //dynamic modify end

      __$$module$$__.module = DeviceRuntimeCore.WatchFace({
       init_view() {
        //dynamic modify start
                    loadSettings();

        // FontName: Oswald-Regular.ttf; FontSize: 26; Cache: full
        hmUI.createWidget(hmUI.widget.TEXT, {
         x: 464,
         y: 464,
         w: 31,
         h: 31,
         text_size: 26,
         char_space: 0,
         line_space: 0,
         font: 'fonts/Oswald-Regular.ttf',
         color: 0xFFFFFFFF,
         align_h: hmUI.align.CENTER_H,
         align_v: hmUI.align.CENTER_V,
         text_style: hmUI.text_style.NONE,
         text: "0123456789 ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz АБВГДЕЁЖЗИЙКЛМНОПРСТУФХЦЧШЩЪЫЬЭЮЯабвгдеёжзийклмнопрстуфхцчшщъыьэюя  ҐЄІЇґєії _-.,:;`'%°\\/",
         show_level: hmUI.show_level.ONLY_NORMAL,
        });

        // FontName: Oswald-Regular.ttf; FontSize: 82
        hmUI.createWidget(hmUI.widget.TEXT, {
         x: 464,
         y: 464,
         w: 1023,
         h: 169,
         text_size: 82,
         char_space: 0,
         line_space: 0,
         font: 'fonts/Oswald-Regular.ttf',
         color: 0xFFFFFFFF,
         align_h: hmUI.align.CENTER_H,
         align_v: hmUI.align.CENTER_V,
         text_style: hmUI.text_style.ELLIPSIS,
         text: "0123456789 _-.,:;`'%°\\/",
         show_level: hmUI.show_level.ONLY_NORMAL,
        });

        // FontName: Oswald-Regular.ttf; FontSize: 27
        hmUI.createWidget(hmUI.widget.TEXT, {
         x: 464,
         y: 464,
         w: 342,
         h: 57,
         text_size: 27,
         char_space: 0,
         line_space: 0,
         font: 'fonts/Oswald-Regular.ttf',
         color: 0xFFFFFFFF,
         align_h: hmUI.align.CENTER_H,
         align_v: hmUI.align.CENTER_V,
         text_style: hmUI.text_style.ELLIPSIS,
         text: "0123456789 _-.,:;`'%°\\/",
         show_level: hmUI.show_level.ONLY_NORMAL,
        });

        // FontName: Oswald-Regular.ttf; FontSize: 42
        hmUI.createWidget(hmUI.widget.TEXT, {
         x: 464,
         y: 464,
         w: 528,
         h: 87,
         text_size: 42,
         char_space: 0,
         line_space: 0,
         font: 'fonts/Oswald-Regular.ttf',
         color: 0xFF000000,
         align_h: hmUI.align.RIGHT,
         align_v: hmUI.align.CENTER_V,
         text_style: hmUI.text_style.ELLIPSIS,
         text: "0123456789 _-.,:;`'%°\\/",
         show_level: hmUI.show_level.ONLY_NORMAL,
        });

        // FontName: Oswald-Regular.ttf; FontSize: 25
        hmUI.createWidget(hmUI.widget.TEXT, {
         x: 464,
         y: 464,
         w: 306,
         h: 50,
         text_size: 25,
         char_space: 0,
         line_space: 0,
         font: 'fonts/Oswald-Regular.ttf',
         color: color_bg[color],
         align_h: hmUI.align.CENTER_H,
         align_v: hmUI.align.CENTER_V,
         text_style: hmUI.text_style.ELLIPSIS,
         text: "0123456789 _-.,:;`'%°\\/",
         show_level: hmUI.show_level.ONLY_NORMAL,
        });

        // FontName: Oswald-Regular.ttf; FontSize: 22
        hmUI.createWidget(hmUI.widget.TEXT, {
         x: 464,
         y: 464,
         w: 271,
         h: 44,
         text_size: 22,
         char_space: 0,
         line_space: 0,
         font: 'fonts/Oswald-Regular.ttf',
         color: color_bg[color],
         align_h: hmUI.align.CENTER_H,
         align_v: hmUI.align.CENTER_V,
         text_style: hmUI.text_style.ELLIPSIS,
         text: "0123456789 ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz АБВГДЕЁЖЗИЙКЛМНОПРСТУФХЦЧШЩЪЫЬЭЮЯабвгдеёжзийклмнопрстуфхцчшщъыьэюя  ҐЄІЇґєії _-.,:;`'%°\\/",
         show_level: hmUI.show_level.ONLY_NORMAL,
        });

        // FontName: Oswald-Regular.ttf; FontSize: 21
        hmUI.createWidget(hmUI.widget.TEXT, {
         x: 464,
         y: 464,
         w: 271,
         h: 44,
         text_size: 21,
         char_space: 0,
         line_space: 0,
         font: 'fonts/Oswald-Regular.ttf',
         color: 0xFF000000,
         align_h: hmUI.align.CENTER_H,
         align_v: hmUI.align.CENTER_V,
         text_style: hmUI.text_style.ELLIPSIS,
         text: "0123456789 _-.,:;`'%°\\/",
         show_level: hmUI.show_level.ONLY_NORMAL,
        });

        // FontName: Oswald-Regular.ttf; FontSize: 20; Cache: full
        hmUI.createWidget(hmUI.widget.TEXT, {
         x: 464,
         y: 464,
         w: 24,
         h: 24,
         text_size: 20,
         char_space: 0,
         line_space: 0,
         font: 'fonts/Oswald-Regular.ttf',
         color: 0xFF000000,
         align_h: hmUI.align.CENTER_H,
         align_v: hmUI.align.CENTER_V,
         text_style: hmUI.text_style.NONE,
         text: "0123456789 ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz АБВГДЕЁЖЗИЙКЛМНОПРСТУФХЦЧШЩЪЫЬЭЮЯабвгдеёжзийклмнопрстуфхцчшщъыьэюя  ҐЄІЇґєії _-.,:;`'%°\\/",
         show_level: hmUI.show_level.ONLY_NORMAL,
        });

        // FontName: Bebas11.ttf; FontSize: 20; Cache: full
        hmUI.createWidget(hmUI.widget.TEXT, {
         x: 464,
         y: 464,
         w: 24,
         h: 24,
         text_size: 20,
         char_space: 0,
         line_space: 0,
         font: 'fonts/Bebas11.ttf',
         color: color_bg[color],
         align_h: hmUI.align.CENTER_H,
         align_v: hmUI.align.CENTER_V,
         text_style: hmUI.text_style.NONE,
         text: "0123456789 ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz АБВГДЕЁЖЗИЙКЛМНОПРСТУФХЦЧШЩЪЫЬЭЮЯабвгдеёжзийклмнопрстуфхцчшщъыьэюя  ҐЄІЇґєії _-.,:;`'%°\\/",
         show_level: hmUI.show_level.ONLY_NORMAL,
        });

        console.log('user_script_start.js');
        // start user_script_start.js

        normal_background_bg = hmUI.createWidget(hmUI.widget.FILL_RECT, {
         x: 0,
         y: 0,
         w: 466,
         h: 466,
         color: color_bg[color],
         show_level: hmUI.show_level.ONLY_NORMAL,
        });

        /*            normal_color_step_bg = hmUI.createWidget(hmUI.widget.FILL_RECT, {
                      x: 333,
                      y: 0,
                      w: 133,
                      h: 466,
                      color: '0xFFbfbfbf',
                      show_level: hmUI.show_level.ONLY_NORMAL,
                    });*/
        // end user_script_start.js

        console.log('Watch_Face.ScreenNormal');

        normal_image_img = hmUI.createWidget(hmUI.widget.IMG, {
         x: 0,
         y: 0,
         src: 'bg.png',
         show_level: hmUI.show_level.ONLY_NORMAL,
        });


        timeSensor.addEventListener(timeSensor.event.DAYCHANGE, function () {
         time_update(true);
        });

        normal_month_name_font = hmUI.createWidget(hmUI.widget.TEXT, {
         x: 0,
         y: 158,
         w: 466,
         h: 30,
         text_size: 26,
         char_space: 0,
         line_space: 0,
         font: 'fonts/Oswald-Regular.ttf',
         color: 0xFFFFFFFF,
         align_h: hmUI.align.CENTER_H,
         align_v: hmUI.align.CENTER_V,
         text_style: hmUI.text_style.ELLIPSIS,
         // unit_string: ЯНВАРЬ, ФЕВРАЛЬ, МАРТ, АПРЕЛЬ, МАЙ, ИЮНЬ, ИЮЛЬ, АВГУСТ, СЕНТЯБРЬ, ОКТЯБРЬ, НОЯБРЬ, ДЕКАБРЬ,
         show_level: hmUI.show_level.ONLY_NORMAL,
        });

        let screenType = hmSetting.getScreenType();
        normal_time_hour_min_text_font = hmUI.createWidget(hmUI.widget.TEXT, {
         x: 0,
         y: 27,
         w: 466,
         h: 150,
         text_size: 82,
         char_space: 0,
         line_space: 0,
         font: 'fonts/Oswald-Regular.ttf',
         color: 0xFFFFFFFF,
         align_h: hmUI.align.CENTER_H,
         align_v: hmUI.align.CENTER_V,
         text_style: hmUI.text_style.ELLIPSIS,
         show_level: hmUI.show_level.ONLY_NORMAL,
        });

        normal_time_second_text_font = hmUI.createWidget(hmUI.widget.TEXT, {
         x: 315,
         y: 71,
         w: 100,
         h: 50,
         text_size: 27,
         char_space: 0,
         line_space: 0,
         font: 'fonts/Oswald-Regular.ttf',
         color: 0xFFFFFFFF,
         align_h: hmUI.align.CENTER_H,
         align_v: hmUI.align.CENTER_V,
         text_style: hmUI.text_style.ELLIPSIS,
         show_level: hmUI.show_level.ONLY_NORMAL,
        });

        normal_heart_rate_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
         x: 194,
         y: 375,
         w: 150,
         h: 50,
         text_size: 42,
         char_space: 0,
         line_space: 0,
         font: 'fonts/Oswald-Regular.ttf',
         color: 0xFF000000,
         align_h: hmUI.align.RIGHT,
         align_v: hmUI.align.CENTER_V,
         text_style: hmUI.text_style.ELLIPSIS,
         type: hmUI.data_type.HEART,
         show_level: hmUI.show_level.ONLY_NORMAL,
        });

        normal_step_current_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
         x: 70,
         y: 375,
         w: 200,
         h: 50,
         text_size: 42,
         char_space: 0,
         line_space: 0,
         font: 'fonts/Oswald-Regular.ttf',
         color: 0xFF000000,
         align_h: hmUI.align.RIGHT,
         align_v: hmUI.align.CENTER_V,
         text_style: hmUI.text_style.ELLIPSIS,
         type: hmUI.data_type.STEP,
         show_level: hmUI.show_level.ONLY_NORMAL,
        });

        // normal_cal_circle_scale = hmUI.createWidget(hmUI.widget.Circle_Scale, {
        // center_x: 364,
        // center_y: 339,
        // start_angle: -90,
        // end_angle: -450,
        // radius: 34,
        // line_width: 13,
        // line_cap: Flat,
        // color: color_bg[color],
        // mirror: False,
        // inversion: False,
        // type: hmUI.data_type.CAL,
        // show_level: hmUI.show_level.ONLY_NORMAL,
        // });

        normal_calorie_circle_scale = hmUI.createWidget(hmUI.widget.ARC_PROGRESS, {
         center_x: 364,
         center_y: 339,
         start_angle: -90,
         end_angle: -450,
         radius: 28,
         line_width: 13,
         corner_flag: 3,
         color: color_bg[color],
         type: hmUI.data_type.CAL,
         show_level: hmUI.show_level.ONLY_NORMAL,
        });

        const calorie = hmSensor.createSensor(hmSensor.id.CALORIE);
        calorie.addEventListener(hmSensor.event.CHANGE, function () {
         scale_call();
        });

        normal_calorie_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
         x: 330,
         y: 305,
         src: 'bg_progress.png',
         show_level: hmUI.show_level.ONLY_NORMAL,
        });

        normal_calorie_current_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
         x: 289,
         y: 324,
         w: 150,
         h: 30,
         text_size: 25,
         char_space: 0,
         line_space: 0,
         font: 'fonts/Oswald-Regular.ttf',
         color: color_bg[color],
         align_h: hmUI.align.CENTER_H,
         align_v: hmUI.align.CENTER_V,
         text_style: hmUI.text_style.ELLIPSIS,
         type: hmUI.data_type.CAL,
         show_level: hmUI.show_level.ONLY_NORMAL,
        });

        normal_vos_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
         x: 27,
         y: 203,
         src: 'ic_vos.png',
         show_level: hmUI.show_level.ONLY_NORMAL,
        });

        normal_zak_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
         x: 27,
         y: 203,
         src: 'ic_zak.png',
         show_level: hmUI.show_level.ONLY_NORMAL,
        });


        normal_vos_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
         x: -37,
         y: 242,
         w: 150,
         h: 30,
         text_size: 22,
         char_space: 0,
         line_space: 0,
         font: 'fonts/Oswald-Regular.ttf',
         color: color_bg[color],
         align_h: hmUI.align.CENTER_H,
         align_v: hmUI.align.CENTER_V,
         text_style: hmUI.text_style.ELLIPSIS,
         type: hmUI.data_type.SUN_RISE,
         show_level: hmUI.show_level.ONLY_NORMAL,
        });

        normal_zak_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
         x: -37,
         y: 242,
         w: 150,
         h: 30,
         text_size: 22,
         char_space: 0,
         line_space: 0,
         font: 'fonts/Oswald-Regular.ttf',
         color: color_bg[color],
         align_h: hmUI.align.CENTER_H,
         align_v: hmUI.align.CENTER_V,
         text_style: hmUI.text_style.ELLIPSIS,
         type: hmUI.data_type.SUN_SET,
         show_level: hmUI.show_level.ONLY_NORMAL,
        });


        normal_ALARM_CLOCK_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
         x: 26,
         y: 113,
         w: 150,
         h: 30,
         text_size: 21,
         char_space: 0,
         line_space: 0,
         padding: true,
         font: 'fonts/Oswald-Regular.ttf',
         color: 0xFF000000,
         align_h: hmUI.align.CENTER_H,
         align_v: hmUI.align.CENTER_V,
         text_style: hmUI.text_style.ELLIPSIS,
         type: hmUI.data_type.ALARM_CLOCK,
         show_level: hmUI.show_level.ONLY_NORMAL,
        });


        normal_distance_current_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
         x: 0,
         y: 425,
         w: 466,
         h: 30,
         text_size: 20,
         char_space: 0,
         line_space: 0,
         font: 'fonts/Oswald-Regular.ttf',
         color: 0xFF000000,
         align_h: hmUI.align.CENTER_H,
         align_v: hmUI.align.CENTER_V,
         unit_type: 1,
         text_style: hmUI.text_style.ELLIPSIS,
         type: hmUI.data_type.DISTANCE,
         show_level: hmUI.show_level.ONLY_NORMAL,
        });

        // normal_battery_circle_scale = hmUI.createWidget(hmUI.widget.Circle_Scale, {
        // center_x: 102,
        // center_y: 339,
        // start_angle: 90,
        // end_angle: 450,
        // radius: 34,
        // line_width: 13,
        // line_cap: Flat,
        // color: color_bg[color],
        // mirror: False,
        // inversion: False,
        // type: hmUI.data_type.BATTERY,
        // show_level: hmUI.show_level.ONLY_NORMAL,
        // });

        normal_battery_circle_scale = hmUI.createWidget(hmUI.widget.ARC_PROGRESS, {
         center_x: 102,
         center_y: 339,
         start_angle: 90,
         end_angle: 450,
         radius: 28,
         line_width: 13,
         corner_flag: 3,
         color: color_bg[color],
         type: hmUI.data_type.BATTERY,
         show_level: hmUI.show_level.ONLY_NORMAL,
        });

        const battery = hmSensor.createSensor(hmSensor.id.BATTERY);
        battery.addEventListener(hmSensor.event.CHANGE, function () {
         scale_call();
        });

        normal_battery_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
         x: 68,
         y: 305,
         src: 'bg_progress.png',
         show_level: hmUI.show_level.ONLY_NORMAL,
        });

        normal_battery_current_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
         x: 28,
         y: 324,
         w: 150,
         h: 30,
         text_size: 25,
         char_space: 0,
         line_space: 0,
         font: 'fonts/Oswald-Regular.ttf',
         color: color_bg[color],
         align_h: hmUI.align.CENTER_H,
         align_v: hmUI.align.CENTER_V,
         text_style: hmUI.text_style.ELLIPSIS,
         type: hmUI.data_type.BATTERY,
         show_level: hmUI.show_level.ONLY_NORMAL,
        });

        normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
         x: 76,
         y: 207,
         week_en: ["week_0.png", "week_1.png", "week_2.png", "week_3.png", "week_4.png", "week_5.png", "week_6.png"],
         week_tc: ["week_0.png", "week_1.png", "week_2.png", "week_3.png", "week_4.png", "week_5.png", "week_6.png"],
         week_sc: ["week_0.png", "week_1.png", "week_2.png", "week_3.png", "week_4.png", "week_5.png", "week_6.png"],
         show_level: hmUI.show_level.ONLY_NORMAL,
        });

		   
        normal_temperature_icon_img = hmUI.createWidget(hmUI.widget.FILL_RECT, {
         x: 89,
         y: 232,
         w: 288,
         h: 3,
         color: 0x555555,
         show_level: hmUI.show_level.ONLY_NORMAL,
        });	
		   
        for (let i = 0; i < 7; i++) {
         normal_day_text_font_[i] = hmUI.createWidget(hmUI.widget.TEXT, {
          x: 25 + i * 44, //159
          y: 293 - 59,
          w: 150,
          h: 40,
          text_size: 27,
          char_space: 0,
          line_space: 0,
          text: 26,
          font: 'fonts/Oswald-Regular.ttf',
          // color: i == week - 1 ? color_bg[color] : 0xffffff,
          color: 0xFFFFffFF,
          align_h: hmUI.align.CENTER_H,
          align_v: hmUI.align.BOTTOM,
          text_style: hmUI.text_style.ELLIPSIS,
          show_level: hmUI.show_level.ONLY_NORMAL,
         });
        }
		   
        normal_city_name_text = hmUI.createWidget(hmUI.widget.TEXT, {
         x: 130,
         y: 310,
         w: 206,
         h: 30,
         text_size: 20,
         char_space: 0,
         line_space: 0,
         font: 'fonts/Bebas11.ttf',
         color: color_bg[color],
         align_h: hmUI.align.CENTER_H,
         align_v: hmUI.align.CENTER_V,
         text_style: hmUI.text_style.NONE,
         show_level: hmUI.show_level.ONLY_NORMAL,
        });

        normal_weather_text_font = hmUI.createWidget(hmUI.widget.TEXT, {
         x: 130,
         y: 310 + 30,
         w: 206,
         h: 30,
         text_size: 22,
         char_space: 0,
         line_space: 0,
         font: 'fonts/Oswald-Regular.ttf',
         color: 0Xffffff,
         align_h: hmUI.align.CENTER_H,
         align_v: hmUI.align.CENTER_V,
         text_style: hmUI.text_style.NONE,
         show_level: hmUI.show_level.ONLY_NORMAL,
        });


        normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
         x: 413-2,
         y: 194-2,
         image_array: ['wt_0.png', 'wt_1.png', 'wt_2.png', 'wt_3.png', 'wt_4.png', 'wt_5.png', 'wt_6.png', 'wt_7.png', 'wt_8.png', 'wt_9.png', 'wt_10.png', 'wt_11.png', 'wt_12.png', 'wt_13.png', 'wt_14.png', 'wt_15.png', 'wt_16.png', 'wt_17.png', 'wt_18.png', 'wt_19.png', 'wt_20.png', 'wt_21.png', 'wt_22.png', 'wt_23.png', 'wt_24.png', 'wt_25.png', 'wt_26.png', 'wt_27.png', 'wt_28.png'],
         image_length: 29,
         type: hmUI.data_type.WEATHER_CURRENT,
         show_level: hmUI.show_level.ONLY_NORMAL,
        });

        normal_temperature_high_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
         x: 289,
         y: 146,
         w: 150,
         h: 30,
         text_size: 20,
         char_space: 0,
         line_space: 0,
         font: 'fonts/Oswald-Regular.ttf',
         color: 0xFFFFFFFF,
         align_h: hmUI.align.CENTER_H,
         align_v: hmUI.align.CENTER_V,
         unit_type: 1,
         text_style: hmUI.text_style.ELLIPSIS,
         type: hmUI.data_type.WEATHER_HIGH,
         show_level: hmUI.show_level.ONLY_NORMAL,
        });

        normal_temperature_low_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
         x: 27,
         y: 146,
         w: 150,
         h: 30,
         text_size: 20,
         char_space: 0,
         line_space: 0,
         font: 'fonts/Oswald-Regular.ttf',
         color: 0xFFFFFFFF,
         align_h: hmUI.align.CENTER_H,
         align_v: hmUI.align.CENTER_V,
         unit_type: 1,
         text_style: hmUI.text_style.ELLIPSIS,
         type: hmUI.data_type.WEATHER_LOW,
         show_level: hmUI.show_level.ONLY_NORMAL,
        });

        normal_temperature_current_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
         x: 356,
         y: 240,
         w: 150,
         h: 30,
         text_size: 22,
         char_space: 0,
         line_space: 0,
         font: 'fonts/Oswald-Regular.ttf',
         color: color_bg[color],
         align_h: hmUI.align.CENTER_H,
         align_v: hmUI.align.CENTER_V,
         unit_type: 1,
         text_style: hmUI.text_style.ELLIPSIS,
         type: hmUI.data_type.WEATHER_CURRENT,
         show_level: hmUI.show_level.ONLY_NORMAL,
        });




        console.log('user_script_beforeShortcuts.js');
        // start user_script_beforeShortcuts.js


        bg_edit_img = hmUI.createWidget(hmUI.widget.IMG, {
         x: 0,
         y: 0,
         src: 'tap/bg_edit.png',
         show_level: hmUI.show_level.ONLY_EDIT,
        });

        groupVremya = hmUI.createWidget(hmUI.widget.GROUP, {
         x: 0,
         y: 0,
         w: D_W,
         h: D_H,
        }); // 


        groupTap = hmUI.createWidget(hmUI.widget.GROUP, {
         x: 0,
         y: 0,
         w: D_W,
         h: D_H,
        });

        i_tap_bg_img = groupTap.createWidget(hmUI.widget.IMG, {
         x: 0,
         y: 0,
         w: D_W,
         h: D_H,
         src: 'tap/i_tap_bg.png',
         show_level: hmUI.show_level.ONLY_NORMAL,
        });


        Tap_zona_0 = groupTap.createWidget(hmUI.widget.IMG, {
         x: tap_x_y[0][0],
         y: tap_x_y[0][1],
         src: apps[tap_1_select][2], //'tap/i_tap_calendar.png',
         show_level: hmUI.show_level.ONLY_NORMAL,
        });

        Tap_zona_1 = groupTap.createWidget(hmUI.widget.IMG, {
         x: tap_x_y[1][0],
         y: tap_x_y[1][1],
         src: apps[tap_2_select][2],
         show_level: hmUI.show_level.ONLY_NORMAL,
        });

        Tap_zona_2 = groupTap.createWidget(hmUI.widget.IMG, {
         x: tap_x_y[2][0],
         y: tap_x_y[2][1],
         src: apps[tap_3_select][2],
         show_level: hmUI.show_level.ONLY_NORMAL,
        });

        Tap_zona_3 = groupTap.createWidget(hmUI.widget.IMG, {
         x: tap_x_y[3][0],
         y: tap_x_y[3][1],
         src: apps[tap_4_select][2],
         show_level: hmUI.show_level.ONLY_NORMAL,
        });

        Tap_zona_4 = groupTap.createWidget(hmUI.widget.IMG, {
         x: tap_x_y[4][0],
         y: tap_x_y[4][1],
         src: apps[tap_5_select][2],
         show_level: hmUI.show_level.ONLY_NORMAL,
        });

        Tap_zona_5 = groupTap.createWidget(hmUI.widget.IMG, {
         x: tap_x_y[5][0],
         y: tap_x_y[5][1],
         src: apps[tap_6_select][2],
         show_level: hmUI.show_level.ONLY_NORMAL,
        });


        btn_Tap_zona_0 = groupTap.createWidget(hmUI.widget.BUTTON, {
         x: tap_x_y[0][0],
         y: tap_x_y[0][1],
         text: '',
         w: 113,
         h: 113,
         normal_src: '0_Empty.png',
         press_src: '0_Empty.png',
         click_func: () => {
          vibro();
          hmApp.startApp({
           url: apps[tap_1_select][1],
           native: true
          });
         },
         show_level: hmUI.show_level.ONLY_NORMAL,
        });


        btn_Tap_zona_1 = groupTap.createWidget(hmUI.widget.BUTTON, {
         x: tap_x_y[1][0],
         y: tap_x_y[1][1],
         text: '',
         w: 113,
         h: 113,
         normal_src: '0_Empty.png',
         press_src: '0_Empty.png',
         click_func: () => {
          vibro();
          hmApp.startApp({
           url: apps[tap_2_select][1],
           native: true
          });
         },
         show_level: hmUI.show_level.ONLY_NORMAL,
        });

        btn_Tap_zona_2 = groupTap.createWidget(hmUI.widget.BUTTON, {
         x: tap_x_y[2][0],
         y: tap_x_y[2][1],
         text: '',
         w: 113,
         h: 113,
         normal_src: '0_Empty.png',
         press_src: '0_Empty.png',
         click_func: () => {
          vibro();
          hmApp.startApp({
           url: apps[tap_3_select][1],
           native: true
          });
         },
         show_level: hmUI.show_level.ONLY_NORMAL,
        });

        btn_Tap_zona_3 = groupTap.createWidget(hmUI.widget.BUTTON, {
         x: tap_x_y[3][0],
         y: tap_x_y[3][1],
         text: '',
         w: 113,
         h: 113,
         normal_src: '0_Empty.png',
         press_src: '0_Empty.png',
         click_func: () => {
          vibro();
          hmApp.startApp({
           url: apps[tap_4_select][1],
           native: true
          });
         },
         show_level: hmUI.show_level.ONLY_NORMAL,
        });

        btn_Tap_zona_4 = groupTap.createWidget(hmUI.widget.BUTTON, {
         x: tap_x_y[4][0],
         y: tap_x_y[4][1],
         text: '',
         w: 113,
         h: 113,
         normal_src: '0_Empty.png',
         press_src: '0_Empty.png',
         click_func: () => {
          vibro();
          hmApp.startApp({
           url: apps[tap_5_select][1],
           native: true
          });
         },
         show_level: hmUI.show_level.ONLY_NORMAL,
        });

        btn_Tap_zona_5 = groupTap.createWidget(hmUI.widget.BUTTON, {
         x: tap_x_y[5][0],
         y: tap_x_y[5][1],
         text: '',
         w: 113,
         h: 113,
         normal_src: '0_Empty.png',
         press_src: '0_Empty.png',
         click_func: () => {
          vibro();
          hmApp.startApp({
           url: apps[tap_6_select][1],
           native: true
          });
         },
         show_level: hmUI.show_level.ONLY_NORMAL,
        });


        btn_tap = hmUI.createWidget(hmUI.widget.BUTTON, {
         x: 183,
         y: 0,
         text: '',
         w: 100,
         h: 100,
         normal_src: '0_Empty.png',
         press_src: '0_Empty.png',
         click_func: () => {
          vibro();
          tap_run();
         },
         show_level: hmUI.show_level.ONLY_NORMAL,
        });

        btn_click_tap_exit = groupTap.createWidget(hmUI.widget.BUTTON, {
         x: 183,
         y: 183,
         text: '',
         w: 100,
         h: 100,
         normal_src: '0_Empty.png',
         press_src: '0_Empty.png',
         click_func: () => {
          vibro();
          tap_zona_exit();
         },
         show_level: hmUI.show_level.ONLY_NORMAL,
        });


        //---------------------------    погода
//        groupPogoda = hmUI.createWidget(hmUI.widget.GROUP, {
//         x: 0,
//         y: 20,
//         w: D_W,
//         h: D_H,
//        });



        //Button_1.setProperty(hmUI.prop.VISIBLE, false); //screen_mode

        // end user_script_beforeShortcuts.js

        //start of ignored block
        function time_update(updateHour = false, updateMinute = false) {
         console.log('time_update()');
         let hour = timeSensor.hour;
         let minute = timeSensor.minute;
         let second = timeSensor.second;
         let format_hour = timeSensor.format_hour;

         console.log('month font');
         if (updateHour) {
          let normal_Month_Str = normal_Month_Array[timeSensor.month - 1];
          normal_month_name_font.setProperty(hmUI.prop.TEXT, normal_Month_Str);
          let normal_yearStr = timeSensor.year.toString();
          normal_year_text_font.setProperty(hmUI.prop.TEXT, normal_yearStr);
         };

         console.log('hour:min font');
         if (updateMinute) {
          let normal_HourMinStr = format_hour.toString();
          normal_HourMinStr = normal_HourMinStr + ':' + minute.toString().padStart(2, '0')
          if (!timeSensor.is24Hour) {
           if (hour > 11) normal_HourMinStr = 'pm ' + normal_HourMinStr
           else normal_HourMinStr = 'am ' + normal_HourMinStr
          };
          normal_time_hour_min_text_font.setProperty(hmUI.prop.TEXT, normal_HourMinStr);
         };

         console.log('second font');
         let normal_secondStr = second.toString();
         normal_secondStr = normal_secondStr.padStart(2, '0');
         normal_time_second_text_font.setProperty(hmUI.prop.TEXT, normal_secondStr);
        };


        normal_year_text_font = hmUI.createWidget(hmUI.widget.TEXT, {
         x: 290,
         y: 113,
         w: 150,
         h: 30,
         text_size: 21,
         char_space: 0,
         line_space: 0,
         font: 'fonts/Oswald-Regular.ttf',
         color: 0xFF000000,
         align_h: hmUI.align.CENTER_H,
         align_v: hmUI.align.CENTER_V,
         text_style: hmUI.text_style.ELLIPSIS,
         // padding: true,
         show_level: hmUI.show_level.ONLY_NORMAL,
        });

        normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
         x: 212,
         y: 33,
         src: 'stat_B_off.png',
         type: hmUI.system_status.DISCONNECT,
         show_level: hmUI.show_level.ONLY_NORMAL,
        });
		   
		   
        normal_distance_icon_img = hmUI.createWidget(hmUI.widget.FILL_RECT, {
         x: 76,
         y: 207,
         w: 316,
         h: 73,
         color: 0x000000,
         show_level: hmUI.show_level.ONLY_NORMAL,
        });

        normal_group_ForecastWeather = hmUI.createWidget(hmUI.widget.GROUP, {
         x: 87,
         y: 267,
         h: 0,
         w: 0,
         show_level: hmUI.show_level.ONLY_NORMAL,
        });
           
/*            let yArrH = [];
            let arr_xH = [];
            let arr_yH = [];
            let arr_x = [];
            let arr_y = [];
            let arr_xL = [];
            let arr_yL = [];
            let yArrAll = [];
            let yArrL = [];
           
                let maxH = Math.max(...yArrH)
                let maxL = Math.min(...yArrL)
                let delta = 120 / (maxL - maxH)
           
           
                    for (let i = 0; i < dney; i++) {
                        arr_x[i] = x0 + shag * [i];
                        arr_y[i] = yArrH[i] * delta + 162 - maxH * delta;
                    }
           
		   
            function splain(n=7) {
                
                
                
                let arr_a = new Array(n).fill().map(() => new Array(1));
                let arr_b = new Array(n - 1).fill().map(() => new Array(1));
                let arr_c = new Array(n).fill().map(() => new Array(1));
                let arr_d = new Array(n - 1).fill().map(() => new Array(1));

                let arr_h = new Array(n - 1).fill().map(() => new Array(1));
                let arr_alpha = new Array(n).fill().map(() => new Array(1));
                let arr_l = new Array(n).fill().map(() => new Array(1));
                let arr_mu = new Array(n).fill().map(() => new Array(1));
                let arr_z = new Array(n).fill().map(() => new Array(1));

                for (var i = 0; i < n - 1; i++) {
                    arr_h[i] = arr_x[i + 1] - arr_x[i];
                }

                for (var i = 1; i < n - 1; i++) {
                    arr_alpha[i] = 3 * ((arr_y[i + 1] - arr_y[i]) / arr_h[i] - (arr_y[i] - arr_y[i - 1]) / arr_h[i - 1]);
                }

                arr_l[0] = 1;
                arr_mu[0] = 0;
                arr_z[0] = 0;

                for (var i = 1; i < n - 1; i++) {
                    arr_l[i] = 2 * (arr_x[i + 1] - arr_x[i - 1]) - arr_h[i - 1] * arr_mu[i - 1];
                    arr_mu[i] = arr_h[i] / arr_l[i];
                    arr_z[i] = (arr_alpha[i] - arr_h[i - 1] * arr_z[i - 1]) / arr_l[i];
                }

                arr_l[n - 1] = 1;
                arr_z[n - 1] = 0;
                arr_c[n - 1] = 0;

                for (var j = n - 2; j >= 0; j--) {
                    arr_c[j] = arr_z[j] - arr_mu[j] * arr_c[j + 1];
                    arr_b[j] = (arr_y[j + 1] - arr_y[j]) / arr_h[j] - arr_h[j] * (arr_c[j + 1] + 2 * arr_c[j]) / 3;
                    arr_d[j] = (arr_c[j + 1] - arr_c[j]) / (3 * arr_h[j]);
                    arr_a[j] = arr_y[j];
                }

                for (var i = 0; i < n - 1; i++) {
                    for (xi = arr_x[i]; xi < arr_x[i + 1] - 1; xi += 5) {
                        yi = arr_a[i] + arr_b[i] * (xi - arr_x[i]) + arr_c[i] * Math.pow((xi - arr_x[i]), 2) + arr_d[i] * Math.pow((xi - arr_x[i]), 3);

                        if (tip_grafik == 0) {
                            canvas.drawImage({
                                x: xi,
                                y: yi,
                                w: 5,
                                h: 310 - yi,
                                alpha: 127,
                                image: n == dney ? 'images/Grafik/line_day.png' : 'images/Grafik/line_night.png'
                            })
                        }

                        canvas.drawLine({
                            x1: xi,
                            y1: yi,
                            x2: xi + 5,
                            y2: arr_a[i] + arr_b[i] * (xi + 5 - arr_x[i]) + arr_c[i] * Math.pow((xi + 5 - arr_x[i]), 2) + arr_d[i] * Math.pow((xi + 5 - arr_x[i]), 3),
                            // color: n == dney ? 0xff0000 : 0x00eaff//0x009cff  yArrAll.length - 1
                            color: n == dney ? 0xff0000 : n == dney - 1 ? 0x00eaff : 0x12a2fd //0x009cff
                        })


                    }
                }

            }
	*/	   

        //start of ignored block
//        function drawLine(canvas1, canvas2, x1, y1, x2, y2, color, line_width) {
//         if (x1 > x2) {
//          let temp_x = x1;
//          let temp_y = y1;
//          x1 = x2;
//          y1 = y2;
//          x2 = temp_x;
//          y2 = temp_y;
//         };
//              canvas2.setPaint({ color: color, line_width: line_width });
//              canvas2.drawLine({ x1: x1, y1: y1, x2: x2, y2: y2 });
//        };
           
        function drawLine(canvas1, canvas2, x1, y1, x2, y2, color, line_width) {
         if (x1 > x2) {
          let temp_x = x1;
          let temp_y = y1;
          x1 = x2;
          y1 = y2;
          x2 = temp_x;
          y2 = temp_y;
         };
              canvas2.setPaint({ color: color, line_width: line_width });
              canvas2.drawLine({ x1: x1, y1: y1, x2: x2, y2: y2 });
        };           
           
           
           

        function drawRect(canvas1, canvas2, x1, y1, x2, y2, color) {
         if (x1 > x2) {
          let temp_x = x1;
          let temp_y = y1;
          x1 = x2;
          y1 = y2;
          x2 = temp_x;
          y2 = temp_y;
         };

              canvas2.drawRect({ x1: x1, y1: y1, x2: x2, y2: y2, color: color });
        };
           
           
           
           
           

            function drawCircle(canvas1, canvas2, center_x, center_y, color, radius) {
              canvas2.drawCircle({ center_x: center_x, center_y: center_y, radius: radius, color: color });
            };

            function drawGraphPoint(canvas1, canvas2, x, y, color, pointSize, pointType) {
              switch (pointType) {
                case 1:
                  x -= pointSize/2;
                  y -= pointSize/2;
                  drawRect(canvas1, canvas2, x, y, x+pointSize, y+pointSize, color);
                  break;
                case 2:
                  let posX = x - pointSize/2;
                  let posY = y - pointSize/2;
                  drawRect(canvas1, canvas2, posX, posY, posX+pointSize, posY+pointSize, color );
                  posX = x - pointSize/4;
                  posY = y - pointSize/4;
                  drawRect(canvas1, canvas2, posX, posY, posX+pointSize/2, posY+pointSize/2, 0xffffff );
                  break;
                case 3:
                  drawCircle(canvas1, canvas2, x, y, color, pointSize/2 );
                  break;
                case 4:
                  drawCircle(canvas1, canvas2, x, y, color, pointSize/2 );
                  drawCircle(canvas1, canvas2, x, y, 0xffffff, pointSize/4 );
                  break;
              }
            };

        //end of ignored block


        //start of ignored block
            function graphScale(heightGraph, maxPointSize, minPointSize, forecastData, daysCount) {
              console.log(`function graphScale`);
              heightGraph -= (maxPointSize + minPointSize) / 2;
              let high = -300;
              let low = 300;

              for (let index = 0; index < daysCount; index++) {
                if (index < forecastData.length) {
                  let item = forecastData[index];
                  if (item.high > high) high = item.high;
                 // if (item.low < low) low = item.low; ;
                  if (item.high < low) low = item.high; ;
                       // yArrH[index] = item.high;
                    
                } // end if
              } // end for
                
              let delta = high - low;
              let scale = heightGraph / delta;
              console.log(`heightGraph: ${heightGraph}; high: ${high}; low : ${low}`);
              return {graphScale: scale, maximal_temp: high};
            };

        //end of ignored block

        //start of ignored block
            if (screenType == hmSetting.screen_type.WATCHFACE) {
              normal_canvas1 = normal_group_ForecastWeather.createWidget(hmUI.widget.CANVAS, {
                x: 0,
                y: 0,
                w: 0,
                h: 0,
              });

              normal_canvas2 = normal_group_ForecastWeather.createWidget(hmUI.widget.CANVAS, {
                x: -5,
                y: -24,
                w: 466,
                h: 466,
              });
            };
        //end of ignored block

           
            if (screenType == hmSetting.screen_type.WATCHFACE) {
              for (let i = 0; i < 7; i++) {
                normal_forecast_image_progress_img_level[i] = normal_group_ForecastWeather.createWidget(hmUI.widget.IMG, {
                  x: -2 + i*44,
                  y: -81,
                  src: normal_forecast_image_array[25],
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });
              };
            };           
           
        //start of ignored block
            if (screenType == hmSetting.screen_type.WATCHFACE) {
              for (let i = 0; i < 7; i++) {
                normal_forecast_high_text_font[i] = normal_group_ForecastWeather.createWidget(hmUI.widget.TEXT, {
                  x: -58 + i*44,
                  y: -36,
                  w: 150,
                  h: 30,
                  text_size: 22,
                  char_space: 0,
                  line_space: 0,
                  font: 'fonts/Oswald-Regular.ttf',
                  color: 0xFFFFFFFF,
                  align_h: hmUI.align.CENTER_H,
                  align_v: hmUI.align.TOP,
                  text_style: hmUI.text_style.ELLIPSIS,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });
              };
            };
        //end of ignored block



        normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
         x: 212,
         y: 33,
         src: 'stat_B_off.png',
         type: hmUI.system_status.DISCONNECT,
         show_level: hmUI.show_level.ONLY_NORMAL,
        });


            //start of ignored block
            function weather_few_days() {
              console.log('weather_few_days()');
              let weatherData = weatherSensor.getForecastWeather();
              let forecastData = weatherData.forecastData;
              let result = {graphScale: 1, maximal_temp: 0};
              let maxOldX = 0;

              if (screenType == hmSetting.screen_type.WATCHFACE) result = graphScale(51, 10, 0, forecastData.data, 7);
              let forecastGraphScale = result.graphScale;
              let maximal_temp = result.maximal_temp;
              console.log(`forecastGraphScale = ${forecastGraphScale}, maximal_temp = ${maximal_temp}`);

              if (screenType == hmSetting.screen_type.WATCHFACE) {
                normal_canvas1.clear({x: 0, y:0, w: 0, h: 0});
                normal_canvas2.clear({x: 0, y:0, w: 466, h: 466});
              };
              let normal_max_offsetX = 21;
              if (screenType == hmSetting.screen_type.WATCHFACE)  maxOldX = normal_max_offsetX;
              let maxOldY = (maximal_temp - forecastData.data[0].high) * forecastGraphScale + 5;
              let endPointMax = false;
                
                let dney = 7
                let n = dney
            let arr_x = [];
            let arr_y = [];

                
                    for (let i = 0; i < dney; i++) {
                   // yArrH[i] = forecastData.data[i].high;
                 arr_x[i] = normal_max_offsetX + i * 44;
                 arr_y[i] =  (maximal_temp - forecastData.data[i].high) * forecastGraphScale + 5;

                    }

let arr_y_0 = (maximal_temp - 0) * forecastGraphScale + 5;
                
                      
                let arr_a = new Array(n).fill().map(() => new Array(1));
                let arr_b = new Array(n - 1).fill().map(() => new Array(1));
                let arr_c = new Array(n).fill().map(() => new Array(1));
                let arr_d = new Array(n - 1).fill().map(() => new Array(1));

                let arr_h = new Array(n - 1).fill().map(() => new Array(1));
                let arr_alpha = new Array(n).fill().map(() => new Array(1));
                let arr_l = new Array(n).fill().map(() => new Array(1));
                let arr_mu = new Array(n).fill().map(() => new Array(1));
                let arr_z = new Array(n).fill().map(() => new Array(1));

                for (var i = 0; i < n - 1; i++) {
                    arr_h[i] = arr_x[i + 1] - arr_x[i];
                }

                for (var i = 1; i < n - 1; i++) {
 
                    arr_alpha[i] = 3 * ((arr_y[i + 1] - arr_y[i]) / arr_h[i] - (arr_y[i] - arr_y[i - 1]) / arr_h[i - 1]);
                }

                arr_l[0] = 1;
                arr_mu[0] = 0;
                arr_z[0] = 0;

                for (var i = 1; i < n - 1; i++) {
                    arr_l[i] = 2 * (arr_x[i + 1] - arr_x[i - 1]) - arr_h[i - 1] * arr_mu[i - 1];
                    arr_mu[i] = arr_h[i] / arr_l[i];
                    arr_z[i] = (arr_alpha[i] - arr_h[i - 1] * arr_z[i - 1]) / arr_l[i];
                }

                arr_l[n - 1] = 1;
                arr_z[n - 1] = 0;
                arr_c[n - 1] = 0;

                for (var j = n - 2; j >= 0; j--) {
                    arr_c[j] = arr_z[j] - arr_mu[j] * arr_c[j + 1];
                    arr_b[j] = (arr_y[j + 1] - arr_y[j]) / arr_h[j] - arr_h[j] * (arr_c[j + 1] + 2 * arr_c[j]) / 3;
                    arr_d[j] = (arr_c[j + 1] - arr_c[j]) / (3 * arr_h[j]);
                    arr_a[j] = arr_y[j];
                }                        
                                   
                      let color_max_min_point = forecastData.data[0].high >= 0 ? 0xFFFF0000 : 0x00eaff;
                
                
              for (let i = 0; i < 7; i++) {
                // Graph
                if (screenType == hmSetting.screen_type.WATCHFACE) {
                  if (i < forecastData.count) {
                      
                    let maxStartX_point = maxOldX;
                    let maxStartY_point  = maxOldY;
                    maxOldX = normal_max_offsetX + i * 44;
                    maxOldY = (maximal_temp - forecastData.data[i].high) * forecastGraphScale + 5;
                    let maxEndX = maxOldX;
                    let maxEndY = maxOldY;
                    if (maxStartX_point != maxEndX) {
                       color_max_min_point = forecastData.data[i-1].high >= 0 ? 0xFFFF0000 : 0x00eaff;
                      //let color_max_min_line = arr_y_0 > maxEndY ? 0xFFFF0000: 0x00eaff;   
                      drawGraphPoint(normal_canvas1, normal_canvas2, maxStartX_point, maxStartY_point , color_max_min_point, 10, 3)
                      endPointMax = true;
                    };               
                      
                    for (xi = arr_x[i]; xi < arr_x[i + 1] - 1; xi += 5) {
                       // yi = arr_a[i] + arr_b[i] * (xi - arr_x[i]) + arr_c[i] * Math.pow((xi - arr_x[i]), 2) + arr_d[i] * Math.pow((xi - arr_x[i]), 3);    
                    let maxStartX = xi;
                    let maxStartY =arr_a[i] + arr_b[i] * (xi - arr_x[i]) + arr_c[i] * Math.pow((xi - arr_x[i]), 2) + arr_d[i] * Math.pow((xi - arr_x[i]), 3);  
//                    let maxStartX = maxOldX;
//                    let maxStartY = maxOldY;
                        
                      
                      
                      
                    let maxEndX = xi+5;
                   // let maxEndY = maxOldY;
                    let maxEndY = arr_a[i] + arr_b[i] * (xi + 5 - arr_x[i]) + arr_c[i] * Math.pow((xi + 5 - arr_x[i]), 2) + arr_d[i] * Math.pow((xi + 5 - arr_x[i]), 3);
                    if (maxStartX != maxEndX) {
       // function drawLine(canvas1, canvas2, x1, y1, x2, y2, color, line_width) {
                      let color_max_min_line = arr_y_0 > maxEndY ? 0xFFFF0000: 0x00eaff;   
                      drawLine(normal_canvas1, normal_canvas2, maxStartX, maxStartY, maxEndX, maxEndY, color_max_min_line, 4)

                    };
                  };
                  };
                };  // end screen_type
                
                // Images
                if (screenType == hmSetting.screen_type.WATCHFACE) {
                  let weatherIndex = 25
                  if (i < forecastData.count) weatherIndex = forecastData.data[i].index;
                  normal_forecast_image_progress_img_level[i].setProperty(hmUI.prop.SRC, normal_forecast_image_array[weatherIndex]);
                };
              
                // Number_Font_Max
                let maxTemperature = '-';
                if (i < forecastData.count) maxTemperature = forecastData.data[i].high.toString();
                if (screenType == hmSetting.screen_type.WATCHFACE) {
                  let normal_forecast_high_text_font_posY = (maximal_temp - forecastData.data[i].high) * forecastGraphScale + -55;
                  normal_forecast_high_text_font[i].setProperty(hmUI.prop.Y, normal_forecast_high_text_font_posY);
                  normal_forecast_high_text_font[i].setProperty(hmUI.prop.TEXT, maxTemperature);
                };
                
              };  // end for

              if (screenType == hmSetting.screen_type.WATCHFACE && endPointMax) {
                drawGraphPoint(normal_canvas1, normal_canvas2, maxOldX, maxOldY, color_max_min_point, 10, 3)
              };
            };
            //end of ignored block
                



        const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
         resume_call: (function () {


          console.log('resume_call()');
          time_update(true, true);
          if (screenType == hmSetting.screen_type.WATCHFACE) {
           if (!normal_timerTimeUpdate) {
            normal_timerTimeUpdate = timer.createTimer(0, 1000, (function (option) {
             let updateHour = timeSensor.minute == 0;
             let updateMinute = timeSensor.second < 2;
             time_update(updateHour, updateMinute);
            })); // end timer 
           }; // end timer check
          }; // end screenType

          weather_few_days();
          console.log('resume_call.js');
          // start resume_call.js

          stopVibro();
          updateGrafik();
          onDigitalCrown();
          //let str_valueStep = 'ШАГИ ' + step.current
          //normal_step_current_text_font.setProperty(hmUI.prop.TEXT, str_valueStep );
          //idle_step_current_text_font.setProperty(hmUI.prop.TEXT, str_valueStep );
          // end resume_call.js

         }),
         pause_call: (function () {
          console.log('pause_call()');
          if (normal_timerTimeUpdate) {
           timer.stopTimer(normal_timerTimeUpdate);
           normal_timerTimeUpdate = undefined;
          }
          console.log('pause_call.js');
          // start pause_call.js
          stopVibro();
          groupVremya.setProperty(hmUI.prop.VISIBLE, true);
         // groupPogoda.setProperty(hmUI.prop.VISIBLE, false);
          groupTap.setProperty(hmUI.prop.VISIBLE, false);
          // end pause_call.js

         }),
        });


        btn_str = groupVremya.createWidget(hmUI.widget.BUTTON, {
         x: 183, //x кнопки
         y: 183, //y кнопки
         text: '',
         w: 100, //ширина кнопки
         h: 100, //высота кнопки
         normal_src: '0_Empty.png',
         press_src: '0_Empty.png',
         click_func: () => {
          vibro();
          click_Pogoda_on();
         },
         //           longpress_func: () => {
         //            vibro();
         //			   blok_btn_on();
         //           },
         show_level: hmUI.show_level.ONLY_NORMAL,
        });


        btn_Pogoda_off = normal_group_ForecastWeather.createWidget(hmUI.widget.BUTTON, {
         x: 183-87, //x кнопки
         y: 183-267, //y кнопки
         text: '',
         w: 100, //ширина кнопки
         h: 100, //высота кнопки
         normal_src: '0_Empty.png',
         press_src: 'press_100.png',
         click_func: () => {
          vibro(); //имя вызываемой функции
          click_Pogoda_off();
         },
         //           longpress_func: () => {
         //            vibro();
         //			   blok_btn_off();
         //           },
         show_level: hmUI.show_level.ONLY_NORMAL,
        });

		   
       groupVremya.setProperty(hmUI.prop.VISIBLE, zona == 0);
		normal_distance_icon_img.setProperty(hmUI.prop.VISIBLE, zona == 1); 
       normal_group_ForecastWeather.setProperty(hmUI.prop.VISIBLE, zona == 1);

        groupTap.setProperty(hmUI.prop.VISIBLE, false);
       // groupPogoda.setProperty(hmUI.prop.VISIBLE, false);

        //dynamic modify end
       },
       onInit() {
		                    loadSettings();
        logger.log('index page.js on init invoke');
       },
       build() {
        this.init_view();
        logger.log('index page.js on ready invoke');
       },
       onDestroy() {
        logger.log('index page.js on destroy invoke');
       }
      });;
     })();
    } catch (e) {
     console.log('Mini Program Error', e);
     e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));;
    }
