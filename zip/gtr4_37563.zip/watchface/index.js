﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        const logger = Logger.getLogger('watchface_SashaCX75');
        //end of ignored block

        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_system_lock_img = ''
        let normal_system_dnd_img = ''
        let normal_system_disconnect_img = ''
        let normal_system_clock_img = ''
        let normal_battery_TextCircle = new Array(3);
        let normal_battery_TextCircle_ASCIIARRAY = new Array(10);
        let normal_battery_TextCircle_img_width = 17;
        let normal_battery_TextCircle_img_height = 44;
        let normal_battery_image_progress_img_level = ''
        let normal_heart_rate_TextCircle = new Array(3);
        let normal_heart_rate_TextCircle_ASCIIARRAY = new Array(10);
        let normal_heart_rate_TextCircle_img_width = 17;
        let normal_heart_rate_TextCircle_img_height = 44;
        let normal_heart_rate_image_progress_img_level = ''
        let normal_moon_image_progress_img_level = ''
        let normal_step_circle_scale = ''
        let normal_step_current_text_img = ''
        let normal_city_name_text = ''
        let normal_temperature_current_text_img = ''
        let normal_weather_image_progress_img_level = ''
        let normal_date_img_date_year = ''
        let normal_date_img_date_month = ''
        let normal_date_img_date_day = ''
        let normal_date_img_date_week_img = ''
        let normal_digital_clock_img_time_AmPm = ''
        let normal_digital_clock_img_time = ''
        let idle_system_lock_img = ''
        let idle_system_dnd_img = ''
        let idle_system_disconnect_img = ''
        let idle_system_clock_img = ''
        let idle_battery_text_text_img = ''
        let idle_date_img_date_year = ''
        let idle_date_img_date_month = ''
        let idle_date_img_date_day = ''
        let idle_date_img_date_week_img = ''
        let idle_digital_clock_img_time_AmPm = ''
        let idle_digital_clock_img_time = ''
        let idle_digital_clock_minute_separator_img = ''
        let normal_altimeter_jumpable_img_click = ''
        let normal_temperature_jumpable_img_click = ''
        let normal_heart_jumpable_img_click = ''
        let normal_step_jumpable_img_click = ''
        let Button_1 = ''
        let Button_2 = ''
        let Button_3 = ''
        let Button_4 = ''
        let Button_5 = ''


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            console.log('Watch_Face.ScreenNormal');
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 466,
              h: 466,
              src: '00.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_lock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 330,
              y: 299,
              src: 'can1.png',
              type: hmUI.system_status.LOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_dnd_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 108,
              y: 301,
              src: 'can6.png',
              type: hmUI.system_status.DISTURB,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 330,
              y: 106,
              src: 'BT3.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 112,
              y: 107,
              src: 'alar20.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_battery_text_circle_img = hmUI.createWidget(hmUI.widget.Text_Circle, {
              // circle_center_X: 233,
              // circle_center_Y: 233,
              // font_array: ["digital3_0.png","digital3_1.png","digital3_2.png","digital3_3.png","digital3_4.png","digital3_5.png","digital3_6.png","digital3_7.png","digital3_8.png","digital3_9.png"],
              // radius: 200,
              // angle: 152,
              // char_space_angle: 0,
              // zero: false,
              // reverse_direction: true,
              // unit_in_alignment: true,
              // vertical_alignment: CENTER_V,
              // horizontal_alignment: CENTER_H,
              // type: hmUI.data_type.BATTERY,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_battery_TextCircle_ASCIIARRAY[0] = 'digital3_0.png';  // set of images with numbers
            normal_battery_TextCircle_ASCIIARRAY[1] = 'digital3_1.png';  // set of images with numbers
            normal_battery_TextCircle_ASCIIARRAY[2] = 'digital3_2.png';  // set of images with numbers
            normal_battery_TextCircle_ASCIIARRAY[3] = 'digital3_3.png';  // set of images with numbers
            normal_battery_TextCircle_ASCIIARRAY[4] = 'digital3_4.png';  // set of images with numbers
            normal_battery_TextCircle_ASCIIARRAY[5] = 'digital3_5.png';  // set of images with numbers
            normal_battery_TextCircle_ASCIIARRAY[6] = 'digital3_6.png';  // set of images with numbers
            normal_battery_TextCircle_ASCIIARRAY[7] = 'digital3_7.png';  // set of images with numbers
            normal_battery_TextCircle_ASCIIARRAY[8] = 'digital3_8.png';  // set of images with numbers
            normal_battery_TextCircle_ASCIIARRAY[9] = 'digital3_9.png';  // set of images with numbers

            //start of ignored block
            for (let i = 0; i < 3; i++) {
              normal_battery_TextCircle[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 466,
                h: 466,
                center_x: 233,
                center_y: 233,
                pos_x: 233 - normal_battery_TextCircle_img_width / 2,
                pos_y: 233 + 178,
                src: 'digital3_0.png',
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
              normal_battery_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
            };
            //end of ignored block
            
            const battery = hmSensor.createSensor(hmSensor.id.BATTERY);
            battery.addEventListener(hmSensor.event.CHANGE, function() {
              text_update();
            });
            
            function toDegree (radian) {
              return radian * (180 / Math.PI);
            };

            normal_battery_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 0,
              y: 0,
              image_array: ["digital1_1.png","digital1_2.png","digital1_3.png","digital1_4.png","digital1_5.png","digital1_6.png","digital1_7.png","digital1_8.png","digital1_9.png"],
              image_length: 9,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_heart_rate_text_circle_img = hmUI.createWidget(hmUI.widget.Text_Circle, {
              // circle_center_X: 233,
              // circle_center_Y: 233,
              // font_array: ["digital3_0.png","digital3_1.png","digital3_2.png","digital3_3.png","digital3_4.png","digital3_5.png","digital3_6.png","digital3_7.png","digital3_8.png","digital3_9.png"],
              // radius: 200,
              // angle: 208,
              // char_space_angle: 0,
              // zero: false,
              // reverse_direction: true,
              // unit_in_alignment: true,
              // vertical_alignment: CENTER_V,
              // horizontal_alignment: CENTER_H,
              // type: hmUI.data_type.HEART,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_heart_rate_TextCircle_ASCIIARRAY[0] = 'digital3_0.png';  // set of images with numbers
            normal_heart_rate_TextCircle_ASCIIARRAY[1] = 'digital3_1.png';  // set of images with numbers
            normal_heart_rate_TextCircle_ASCIIARRAY[2] = 'digital3_2.png';  // set of images with numbers
            normal_heart_rate_TextCircle_ASCIIARRAY[3] = 'digital3_3.png';  // set of images with numbers
            normal_heart_rate_TextCircle_ASCIIARRAY[4] = 'digital3_4.png';  // set of images with numbers
            normal_heart_rate_TextCircle_ASCIIARRAY[5] = 'digital3_5.png';  // set of images with numbers
            normal_heart_rate_TextCircle_ASCIIARRAY[6] = 'digital3_6.png';  // set of images with numbers
            normal_heart_rate_TextCircle_ASCIIARRAY[7] = 'digital3_7.png';  // set of images with numbers
            normal_heart_rate_TextCircle_ASCIIARRAY[8] = 'digital3_8.png';  // set of images with numbers
            normal_heart_rate_TextCircle_ASCIIARRAY[9] = 'digital3_9.png';  // set of images with numbers

            //start of ignored block
            for (let i = 0; i < 3; i++) {
              normal_heart_rate_TextCircle[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 466,
                h: 466,
                center_x: 233,
                center_y: 233,
                pos_x: 233 - normal_heart_rate_TextCircle_img_width / 2,
                pos_y: 233 + 178,
                src: 'digital3_0.png',
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
              normal_heart_rate_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
            };
            //end of ignored block
            
            const heart_rate = hmSensor.createSensor(hmSensor.id.HEART);
            heart_rate.addEventListener(hmSensor.event.CHANGE, function() {
              text_update();
            });

            normal_heart_rate_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 0,
              y: 0,
              image_array: ["bpm1.png","bpm2.png","bpm3.png","bpm4.png","bpm5.png","bpm6.png"],
              image_length: 6,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_moon_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 95,
              y: 212,
              image_array: ["fase1.png","fase2.png","fase3.png","fase4.png","fase5.png","fase6.png","fase7.png","fase8.png"],
              image_length: 8,
              type: hmUI.data_type.MOON,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_step_circle_scale = hmUI.createWidget(hmUI.widget.Circle_Scale, {
              // center_x: 233,
              // center_y: 233,
              // start_angle: -32,
              // end_angle: 34,
              // radius: 124,
              // line_width: 7,
              // line_cap: Rounded,
              // color: 0xFF10A5F5,
              // mirror: False,
              // inversion: False,
              // type: hmUI.data_type.STEP,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            let screenType = hmSetting.getScreenType();
            normal_step_circle_scale = hmUI.createWidget(hmUI.widget.ARC_PROGRESS, {
              center_x: 233,
              center_y: 233,
              start_angle: -32,
              end_angle: 34,
              radius: 121,
              line_width: 7,
              corner_flag: 0,
              color: 0xFF10A5F5,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            
            const step = hmSensor.createSensor(hmSensor.id.STEP);
            step.addEventListener(hmSensor.event.CHANGE, function() {
              scale_call();
            });

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 190,
              y: 123,
              font_array: ["digital3_0.png","digital3_1.png","digital3_2.png","digital3_3.png","digital3_4.png","digital3_5.png","digital3_6.png","digital3_7.png","digital3_8.png","digital3_9.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
              const weatherSensor = hmSensor.createSensor(hmSensor.id.WEATHER);

            normal_city_name_text = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 147,
              y: 281,
              w: 169,
              h: 30,
              text_size: 20,
              char_space: 0,
              line_space: 0,
              color: 0xFFFFFFFF,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.NONE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 212,
              y: 78,
              font_array: ["digital9_0.png","digital9_1.png","digital9_2.png","digital9_3.png","digital9_4.png","digital9_5.png","digital9_6.png","digital9_7.png","digital9_8.png","digital9_9.png"],
              padding: false,
              h_space: 0,
              unit_sc: '0044.png',
              unit_tc: '0044.png',
              unit_en: '0044.png',
              negative_image: 'digital8_10.png',
              invalid_image: 'invalid.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 182,
              y: 0,
              image_array: ["w_0.png","w_1.png","w_2.png","w_3.png","w_4.png","w_5.png","w_6.png","w_7.png","w_8.png","w_9.png","w_10.png","w_11.png","w_12.png","w_13.png","w_14.png","w_15.png","w_16.png","w_17.png","w_18.png","w_19.png","w_20.png","w_21.png","w_22.png","w_23.png","w_24.png","w_25.png","w_26.png","w_27.png","w_28.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_year = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              year_startX: 247,
              year_startY: 361,
              year_sc_array: ["digital9_0.png","digital9_1.png","digital9_2.png","digital9_3.png","digital9_4.png","digital9_5.png","digital9_6.png","digital9_7.png","digital9_8.png","digital9_9.png"],
              year_tc_array: ["digital9_0.png","digital9_1.png","digital9_2.png","digital9_3.png","digital9_4.png","digital9_5.png","digital9_6.png","digital9_7.png","digital9_8.png","digital9_9.png"],
              year_en_array: ["digital9_0.png","digital9_1.png","digital9_2.png","digital9_3.png","digital9_4.png","digital9_5.png","digital9_6.png","digital9_7.png","digital9_8.png","digital9_9.png"],
              year_zero: 1,
              year_space: 0,
              year_align: hmUI.align.CENTER_H,
              year_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_month = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 213,
              month_startY: 361,
              month_sc_array: ["digital9_0.png","digital9_1.png","digital9_2.png","digital9_3.png","digital9_4.png","digital9_5.png","digital9_6.png","digital9_7.png","digital9_8.png","digital9_9.png"],
              month_tc_array: ["digital9_0.png","digital9_1.png","digital9_2.png","digital9_3.png","digital9_4.png","digital9_5.png","digital9_6.png","digital9_7.png","digital9_8.png","digital9_9.png"],
              month_en_array: ["digital9_0.png","digital9_1.png","digital9_2.png","digital9_3.png","digital9_4.png","digital9_5.png","digital9_6.png","digital9_7.png","digital9_8.png","digital9_9.png"],
              month_zero: 1,
              month_space: 0,
              month_unit_sc: 'digital9_10.png',
              month_unit_tc: 'digital9_10.png',
              month_unit_en: 'digital9_10.png',
              month_align: hmUI.align.CENTER_H,
              month_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 179,
              day_startY: 361,
              day_sc_array: ["digital9_0.png","digital9_1.png","digital9_2.png","digital9_3.png","digital9_4.png","digital9_5.png","digital9_6.png","digital9_7.png","digital9_8.png","digital9_9.png"],
              day_tc_array: ["digital9_0.png","digital9_1.png","digital9_2.png","digital9_3.png","digital9_4.png","digital9_5.png","digital9_6.png","digital9_7.png","digital9_8.png","digital9_9.png"],
              day_en_array: ["digital9_0.png","digital9_1.png","digital9_2.png","digital9_3.png","digital9_4.png","digital9_5.png","digital9_6.png","digital9_7.png","digital9_8.png","digital9_9.png"],
              day_zero: 1,
              day_space: 0,
              day_unit_sc: 'digital9_10.png',
              day_unit_tc: 'digital9_10.png',
              day_unit_en: 'digital9_10.png',
              day_align: hmUI.align.LEFT,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 148,
              y: 314,
              week_en: ["Day-001.png","Day-002.png","Day-003.png","Day-004.png","Day-005.png","Day-006.png","Day-007.png"],
              week_tc: ["Day-001.png","Day-002.png","Day-003.png","Day-004.png","Day-005.png","Day-006.png","Day-007.png"],
              week_sc: ["Day-001.png","Day-002.png","Day-003.png","Day-004.png","Day-005.png","Day-006.png","Day-007.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time_AmPm = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              am_x: 309,
              am_y: 201,
              am_sc_path: '33.png',
              am_en_path: '33.png',
              pm_x: 309,
              pm_y: 201,
              pm_sc_path: '34.png',
              pm_en_path: '34.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 146,
              hour_startY: 184,
              hour_array: ["digital2_0.png","digital2_1.png","digital2_2.png","digital2_3.png","digital2_4.png","digital2_5.png","digital2_6.png","digital2_7.png","digital2_8.png","digital2_9.png"],
              hour_zero: 1,
              hour_space: 0,
              hour_angle: 0,
              hour_unit_sc: 'digital2_10.png',
              hour_unit_tc: 'digital2_10.png',
              hour_unit_en: 'digital2_10.png',
              hour_align: hmUI.align.CENTER_H,

              minute_startX: 240,
              minute_startY: 184,
              minute_array: ["digital2_0.png","digital2_1.png","digital2_2.png","digital2_3.png","digital2_4.png","digital2_5.png","digital2_6.png","digital2_7.png","digital2_8.png","digital2_9.png"],
              minute_zero: 1,
              minute_space: 0,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.CENTER_H,

              second_startX: 324,
              second_startY: 228,
              second_array: ["digital3_0.png","digital3_1.png","digital3_2.png","digital3_3.png","digital3_4.png","digital3_5.png","digital3_6.png","digital3_7.png","digital3_8.png","digital3_9.png"],
              second_zero: 1,
              second_space: 0,
              second_angle: 0,
              second_follow: 0,
              second_align: hmUI.align.CENTER_H,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            console.log('Watch_Face.ScreenAOD');

            idle_system_lock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 330,
              y: 299,
              src: 'can1.png',
              type: hmUI.system_status.LOCK,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_system_dnd_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 108,
              y: 301,
              src: 'can6.png',
              type: hmUI.system_status.DISTURB,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 330,
              y: 106,
              src: 'BT3.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 112,
              y: 107,
              src: 'alar20.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 327,
              y: 230,
              font_array: ["digital3_0.png","digital3_1.png","digital3_2.png","digital3_3.png","digital3_4.png","digital3_5.png","digital3_6.png","digital3_7.png","digital3_8.png","digital3_9.png"],
              padding: false,
              h_space: 0,
              unit_sc: '0053.png',
              unit_tc: '0053.png',
              unit_en: '0053.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_year = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              year_startX: 247,
              year_startY: 361,
              year_sc_array: ["digital9_0.png","digital9_1.png","digital9_2.png","digital9_3.png","digital9_4.png","digital9_5.png","digital9_6.png","digital9_7.png","digital9_8.png","digital9_9.png"],
              year_tc_array: ["digital9_0.png","digital9_1.png","digital9_2.png","digital9_3.png","digital9_4.png","digital9_5.png","digital9_6.png","digital9_7.png","digital9_8.png","digital9_9.png"],
              year_en_array: ["digital9_0.png","digital9_1.png","digital9_2.png","digital9_3.png","digital9_4.png","digital9_5.png","digital9_6.png","digital9_7.png","digital9_8.png","digital9_9.png"],
              year_zero: 1,
              year_space: 0,
              year_align: hmUI.align.CENTER_H,
              year_is_character: false,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_month = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 213,
              month_startY: 361,
              month_sc_array: ["digital9_0.png","digital9_1.png","digital9_2.png","digital9_3.png","digital9_4.png","digital9_5.png","digital9_6.png","digital9_7.png","digital9_8.png","digital9_9.png"],
              month_tc_array: ["digital9_0.png","digital9_1.png","digital9_2.png","digital9_3.png","digital9_4.png","digital9_5.png","digital9_6.png","digital9_7.png","digital9_8.png","digital9_9.png"],
              month_en_array: ["digital9_0.png","digital9_1.png","digital9_2.png","digital9_3.png","digital9_4.png","digital9_5.png","digital9_6.png","digital9_7.png","digital9_8.png","digital9_9.png"],
              month_zero: 1,
              month_space: 0,
              month_unit_sc: 'digital9_10.png',
              month_unit_tc: 'digital9_10.png',
              month_unit_en: 'digital9_10.png',
              month_align: hmUI.align.CENTER_H,
              month_is_character: false,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 179,
              day_startY: 361,
              day_sc_array: ["digital9_0.png","digital9_1.png","digital9_2.png","digital9_3.png","digital9_4.png","digital9_5.png","digital9_6.png","digital9_7.png","digital9_8.png","digital9_9.png"],
              day_tc_array: ["digital9_0.png","digital9_1.png","digital9_2.png","digital9_3.png","digital9_4.png","digital9_5.png","digital9_6.png","digital9_7.png","digital9_8.png","digital9_9.png"],
              day_en_array: ["digital9_0.png","digital9_1.png","digital9_2.png","digital9_3.png","digital9_4.png","digital9_5.png","digital9_6.png","digital9_7.png","digital9_8.png","digital9_9.png"],
              day_zero: 1,
              day_space: 0,
              day_unit_sc: 'digital9_10.png',
              day_unit_tc: 'digital9_10.png',
              day_unit_en: 'digital9_10.png',
              day_align: hmUI.align.LEFT,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 148,
              y: 314,
              week_en: ["Day-001.png","Day-002.png","Day-003.png","Day-004.png","Day-005.png","Day-006.png","Day-007.png"],
              week_tc: ["Day-001.png","Day-002.png","Day-003.png","Day-004.png","Day-005.png","Day-006.png","Day-007.png"],
              week_sc: ["Day-001.png","Day-002.png","Day-003.png","Day-004.png","Day-005.png","Day-006.png","Day-007.png"],
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time_AmPm = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              am_x: 309,
              am_y: 201,
              am_sc_path: '33.png',
              am_en_path: '33.png',
              pm_x: 309,
              pm_y: 201,
              pm_sc_path: '34.png',
              pm_en_path: '34.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 146,
              hour_startY: 184,
              hour_array: ["digital2_0.png","digital2_1.png","digital2_2.png","digital2_3.png","digital2_4.png","digital2_5.png","digital2_6.png","digital2_7.png","digital2_8.png","digital2_9.png"],
              hour_zero: 1,
              hour_space: 0,
              hour_angle: 0,
              hour_unit_sc: 'digital2_10.png',
              hour_unit_tc: 'digital2_10.png',
              hour_unit_en: 'digital2_10.png',
              hour_align: hmUI.align.CENTER_H,

              minute_startX: 240,
              minute_startY: 184,
              minute_array: ["digital2_0.png","digital2_1.png","digital2_2.png","digital2_3.png","digital2_4.png","digital2_5.png","digital2_6.png","digital2_7.png","digital2_8.png","digital2_9.png"],
              minute_zero: 1,
              minute_space: 0,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.CENTER_H,

              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_minute_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'sharp.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });
            
            // disconnectAlert = hmUI.createWidget(hmUI.widget.DisconnectAlert, {
              // disconneсnt_vibrate_type: 0,
              // disconneсnt_toast_text: BT DESC.,
              // conneсnt_vibrate_type: 0,
              // conneсnt_toast_text: BT CON.,
            // });

            // vibration when connecting or disconnecting

            function checkConnection() {
              console.log('checkConnection()');
              hmBle.removeListener;
              hmBle.addListener(function (status) {
                if(!status) {
                  hmUI.showToast({text: "BT DESC."});
                  vibro(0);
                }
                if(status) {
                  hmUI.showToast({text: "BT CON."});
                  vibro(0);
                }
              });
            }

            // end vibration when connecting or disconnecting
            // vibrate function

            const vibrate = hmSensor.createSensor(hmSensor.id.VIBRATE);
            let timer_StopVibrate = null;


            function vibro(scene = 25) {
              let stopDelay = 50;
              stopVibro();
              vibrate.stop();
              vibrate.scene = scene;
              if(scene < 23 || scene > 25) stopDelay = 1300;
              vibrate.start();
              if (scene != 1) timer_StopVibrate = timer.createTimer(stopDelay, 3000, stopVibro, {});
            }

            function stopVibro(){
              vibrate.stop();
              if(timer_StopVibrate) timer.stopTimer(timer_StopVibrate);
            }

            // end vibrate function
            console.log('Watch_Face.Shortcuts');

            normal_altimeter_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 84,
              y: 206,
              w: 60,
              h: 60,
              type: hmUI.data_type.ALTIMETER,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 180,
              y: 2,
              w: 100,
              h: 103,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 83,
              y: 356,
              w: 83,
              h: 69,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 145,
              y: 110,
              w: 180,
              h: 55,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            console.log('Watch_Face.Buttons');
            Button_1 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 354,
              y: 352,
              w: 46,
              h: 50,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'invalid.png',
              normal_src: 'transparent.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'LowBatteryScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_2 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 303,
              y: 384,
              w: 50,
              h: 50,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'invalid.png',
              normal_src: 'transparent.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'PowerSaveHintScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_3 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 176,
              y: 318,
              w: 119,
              h: 80,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'transparent.png',
              normal_src: 'transparent.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'ScheduleCalScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_4 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 80,
              y: 58,
              w: 50,
              h: 50,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'transparent.png',
              normal_src: 'transparent.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'FindPhoneScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_5 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 345,
              y: 61,
              w: 50,
              h: 50,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'transparent.png',
              normal_src: 'transparent.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'PhoneHomeScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            function text_update() {
              console.log('text_update()');

              console.log('update text circle battery_BATTERY');
              let valueBattery = battery.current;
              let normal_battery_circle_string = parseInt(valueBattery).toString();

              if (screenType != hmSetting.screen_type.AOD) {
                for (var i = 1; i < 3; i++) {  // hide all symbols
                  normal_battery_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                let char_Angle = 332;
                if (valueBattery != null && valueBattery != undefined && isFinite(valueBattery) && normal_battery_circle_string.length > 0 && normal_battery_circle_string.length < 6) {  // display data if it was possible to get it
                  let normal_battery_TextCircle_img_angle = 0;
                  let normal_battery_TextCircle_dot_img_angle = 0;
                  normal_battery_TextCircle_img_angle = toDegree(Math.atan2(normal_battery_TextCircle_img_width/2, 200));
                  // alignment = CENTER_H
                  let normal_battery_TextCircle_angleOffset = normal_battery_TextCircle_img_angle * (normal_battery_circle_string.length - 1);
                  normal_battery_TextCircle_angleOffset = -normal_battery_TextCircle_angleOffset;
                  char_Angle -= normal_battery_TextCircle_angleOffset;
                  // alignment end
                  
                  let firstSymbol = true;
                  let index = 0;
                  for (let char of normal_battery_circle_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 3) break;
                    if (charCode >= 0 && charCode < 10) { 
                      if (!firstSymbol) char_Angle -= normal_battery_TextCircle_img_angle;
                      firstSymbol = false;
                      normal_battery_TextCircle[index].setProperty(hmUI.prop.ANGLE, char_Angle);
                      normal_battery_TextCircle[index].setProperty(hmUI.prop.POS_X, 233 - normal_battery_TextCircle_img_width / 2);
                      normal_battery_TextCircle[index].setProperty(hmUI.prop.SRC, normal_battery_TextCircle_ASCIIARRAY[charCode]);
                      normal_battery_TextCircle[index].setProperty(hmUI.prop.VISIBLE, true);
                      char_Angle -= normal_battery_TextCircle_img_angle;
                      index++;
                    };  // end if digit
                  };  // end char of string
                }  // end isFinite

              };

              console.log('update text circle heart_rate_HEART');
              let valueHeartRate = heart_rate.last;
              let normal_heart_rate_circle_string = parseInt(valueHeartRate).toString();

              if (screenType != hmSetting.screen_type.AOD) {
                for (var i = 1; i < 3; i++) {  // hide all symbols
                  normal_heart_rate_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                let char_Angle = 388;
                if (valueHeartRate != null && valueHeartRate != undefined && isFinite(valueHeartRate) && normal_heart_rate_circle_string.length > 0 && normal_heart_rate_circle_string.length < 6) {  // display data if it was possible to get it
                  let normal_heart_rate_TextCircle_img_angle = 0;
                  let normal_heart_rate_TextCircle_dot_img_angle = 0;
                  normal_heart_rate_TextCircle_img_angle = toDegree(Math.atan2(normal_heart_rate_TextCircle_img_width/2, 200));
                  // alignment = CENTER_H
                  let normal_heart_rate_TextCircle_angleOffset = normal_heart_rate_TextCircle_img_angle * (normal_heart_rate_circle_string.length - 1);
                  normal_heart_rate_TextCircle_angleOffset = -normal_heart_rate_TextCircle_angleOffset;
                  char_Angle -= normal_heart_rate_TextCircle_angleOffset;
                  // alignment end
                  
                  let firstSymbol = true;
                  let index = 0;
                  for (let char of normal_heart_rate_circle_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 3) break;
                    if (charCode >= 0 && charCode < 10) { 
                      if (!firstSymbol) char_Angle -= normal_heart_rate_TextCircle_img_angle;
                      firstSymbol = false;
                      normal_heart_rate_TextCircle[index].setProperty(hmUI.prop.ANGLE, char_Angle);
                      normal_heart_rate_TextCircle[index].setProperty(hmUI.prop.POS_X, 233 - normal_heart_rate_TextCircle_img_width / 2);
                      normal_heart_rate_TextCircle[index].setProperty(hmUI.prop.SRC, normal_heart_rate_TextCircle_ASCIIARRAY[charCode]);
                      normal_heart_rate_TextCircle[index].setProperty(hmUI.prop.VISIBLE, true);
                      char_Angle -= normal_heart_rate_TextCircle_img_angle;
                      index++;
                    };  // end if digit
                  };  // end char of string
                }  // end isFinite

              };

            };

            function scale_call() {
              console.log('scale_call()');

                console.log('update scales STEP');
                
                let valueStep = step.current;
                let targetStep = step.target;
                let progressStep = valueStep/targetStep;
                if (progressStep > 1) progressStep = 1;
                let progress_cs_normal_step = progressStep;

                if (screenType != hmSetting.screen_type.AOD) {

                  // normal_step_circle_scale_circle_scale
                  let level = Math.round(progress_cs_normal_step * 100);
                  if (normal_step_circle_scale) {
                    normal_step_circle_scale.setProperty(hmUI.prop.MORE, {                      
                      center_x: 233,
                      center_y: 233,
                      start_angle: -32,
                      end_angle: 34,
                      radius: 121,
                      line_width: 7,
                      corner_flag: 0,
                      color: 0xFF10A5F5,
                      show_level: hmUI.show_level.ONLY_NORMAL,
                      level: level,
                    });
                  };
                };

              console.log('Weather city name');
              let weatherData = weatherSensor.getForecastWeather();
              normal_city_name_text.setProperty(hmUI.prop.TEXT, weatherData.cityName);

            };

            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                console.log('resume_call()');
                scale_call();
                text_update();
                checkConnection();
                stopVibro();

              }),
              pause_call: (function () {
                console.log('pause_call()');
                stopVibro();

              }),
            });

                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}