﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        const logger = Logger.getLogger('watchface_SashaCX75');
        //end of ignored block

        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_system_lock_img = ''
        let normal_system_dnd_img = ''
        let normal_system_disconnect_img = ''
        let normal_system_clock_img = ''
        let normal_battery_pointer_progress_img_pointer = ''
        let normal_date_img_date_day = ''
        let normal_weather_image_progress_img_level = ''
        let normal_analog_clock_time_pointer_hour = ''
        let normal_analog_clock_time_pointer_minute = ''
        let normal_analog_clock_time_pointer_second = ''
        let normal_pai_icon_img = ''
        let normal_analog_clock_pro_hour_pointer_img = ''
        let normal_analog_clock_pro_minute_pointer_img = ''
        let normal_analog_clock_pro_second_pointer_img = ''
        let normal_timerUpdateSec = undefined;
        let idle_background_bg_img = ''
        let idle_analog_clock_time_pointer_hour = ''
        let idle_analog_clock_time_pointer_minute = ''
        let idle_system_disconnect_img = ''
        let normal_stopwatch_jumpable_img_click = ''
        let normal_alarm_jumpable_img_click = ''
        let normal_stress_jumpable_img_click = ''
        let normal_heart_jumpable_img_click = ''
        let timeSensor = ''
		let normal_calendar_img_click = ''
		let normal_music_img_click = ''
		let normal_voice_img_click = ''
		let normal_phone_img_click = ''
		let normal_contact_img_click = ''
		let normal_settings_img_click = ''
		let normal_load_img_click = ''
		
		let btn_zona1 = ''
        let zona1_num = 0
        let zona1_all = 2
		
		function click_zona1() {
		  zona1_num = (zona1_num + 1) % (zona1_all + 1);
          if (zona1_num == 0) {
			normal_analog_clock_time_pointer_hour.setProperty(hmUI.prop.VISIBLE, true);
            normal_analog_clock_time_pointer_minute.setProperty(hmUI.prop.VISIBLE, true); 
            normal_analog_clock_time_pointer_second.setProperty(hmUI.prop.VISIBLE, true);
			normal_pai_icon_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_analog_clock_pro_hour_pointer_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_analog_clock_pro_minute_pointer_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_analog_clock_pro_second_pointer_img.setProperty(hmUI.prop.VISIBLE, false);
		    hmUI.showToast({
            });
          };
            if (zona1_num == 1) {		  
		  	normal_analog_clock_time_pointer_hour.setProperty(hmUI.prop.VISIBLE, false);
            normal_analog_clock_time_pointer_minute.setProperty(hmUI.prop.VISIBLE, false); 
            normal_analog_clock_time_pointer_second.setProperty(hmUI.prop.VISIBLE, false);
			normal_pai_icon_img.setProperty(hmUI.prop.VISIBLE, true);
			normal_analog_clock_pro_hour_pointer_img.setProperty(hmUI.prop.VISIBLE, true);
			normal_analog_clock_pro_minute_pointer_img.setProperty(hmUI.prop.VISIBLE, true);
			normal_analog_clock_pro_second_pointer_img.setProperty(hmUI.prop.VISIBLE, true);
		    hmUI.showToast({
            });
          };
		}
		
		let batteryInfo_click = ''
		
		const battery = hmSensor.createSensor(hmSensor.id.BATTERY);
		
		let valueBattery = ''
		
		let btn_bezel = ''
        let bezel_num = 1
        let bezel_all = 3
     
        function click_Bezel() {
            if(bezel_num>=bezel_all) {bezel_num=1;}
            else { bezel_num=bezel_num+1;}
            hmUI.showToast({text: "<BackGround> " + parseInt(bezel_num) });
            normal_background_bg_img.setProperty(hmUI.prop.SRC, "bg_" + parseInt(bezel_num) + ".png");
        }


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 466,
              h: 466,
              src: 'bg_1.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_lock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 123,
              y: 30,
              src: 'lock.png',
              type: hmUI.system_status.LOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_dnd_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 301,
              y: 394,
              src: 'dnd.png',
              type: hmUI.system_status.DISTURB,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 301,
              y: 33,
              src: 'bt.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 127,
              y: 393,
              src: 'alarm.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_pointer_progress_img_pointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
              src: '25.png',
              center_x: 79,
              center_y: 138,
              x: 6,
              y: 36,
              start_angle: 0,
              end_angle: 360,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 158,
              day_startY: 119,
              day_sc_array: ["date_0.png","date_1.png","date_2.png","date_3.png","date_4.png","date_5.png","date_6.png","date_7.png","date_8.png","date_9.png"],
              day_tc_array: ["date_0.png","date_1.png","date_2.png","date_3.png","date_4.png","date_5.png","date_6.png","date_7.png","date_8.png","date_9.png"],
              day_en_array: ["date_0.png","date_1.png","date_2.png","date_3.png","date_4.png","date_5.png","date_6.png","date_7.png","date_8.png","date_9.png"],
              day_zero: 1,
              day_space: 0,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 211,
              y: 28,
              image_array: ["w_0.png","w_1.png","w_2.png","w_3.png","w_4.png","w_5.png","w_6.png","w_7.png","w_8.png","w_9.png","w_10.png","w_11.png","w_12.png","w_13.png","w_14.png","w_15.png","w_16.png","w_17.png","w_18.png","w_19.png","w_20.png","w_21.png","w_22.png","w_23.png","w_24.png","w_25.png","w_26.png","w_27.png","w_28.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_hour = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              hour_path: 'hour.png',
              hour_centerX: 233,
              hour_centerY: 233,
              hour_posX: 3,
              hour_posY: 38,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_minute = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              minute_path: 'minute.png',
              minute_centerX: 233,
              minute_centerY: 233,
              minute_posX: 4,
              minute_posY: 48,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_second = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              second_path: 'second.png',
              second_centerX: 233,
              second_centerY: 233,
              second_posX: 4,
              second_posY: 56,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_pai_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 133,
              y: 133,
              src: 'time.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            const deviceInfo = hmSetting.getDeviceInfo();
            if (!timeSensor) timeSensor = hmSensor.createSensor(hmSensor.id.TIME);
            timeSensor.addEventListener(timeSensor.event.MINUTEEND, function() {
              time_update(true, true);
            });

            // normal_analog_clock_pro_hour_pointer_img = hmUI.createWidget(hmUI.widget.TIME_POINTER_PRO, {
              // src: 'hour (2).png',
              // center_x: 233,
              // center_y: 233,
              // x: 7,
              // y: 72,
              // start_angle: 0,
              // end_angle: 360,
              // type: hmUI.data_type.hour,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });


            normal_analog_clock_pro_hour_pointer_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: deviceInfo.width,
              h: deviceInfo.height,
              pos_x: 233 - 7,
              pos_y: 233 - 72,
              center_x: 233,
              center_y: 233,
              src: 'hour (2).png',
              angle: 0,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_analog_clock_pro_minute_pointer_img = hmUI.createWidget(hmUI.widget.TIME_POINTER_PRO, {
              // src: 'minute (2).png',
              // center_x: 233,
              // center_y: 233,
              // x: 9,
              // y: 101,
              // start_angle: 0,
              // end_angle: 360,
              // type: hmUI.data_type.minute,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });


            normal_analog_clock_pro_minute_pointer_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: deviceInfo.width,
              h: deviceInfo.height,
              pos_x: 233 - 9,
              pos_y: 233 - 101,
              center_x: 233,
              center_y: 233,
              src: 'minute (2).png',
              angle: 0,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_analog_clock_pro_second_pointer_img = hmUI.createWidget(hmUI.widget.TIME_POINTER_PRO, {
              // src: 'second (2).png',
              // center_x: 233,
              // center_y: 233,
              // x: 7,
              // y: 97,
              // start_angle: 0,
              // end_angle: 360,
              // type: hmUI.data_type.second,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });


            normal_analog_clock_pro_second_pointer_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: deviceInfo.width,
              h: deviceInfo.height,
              pos_x: 233 - 7,
              pos_y: 233 - 97,
              center_x: 233,
              center_y: 233,
              src: 'second (2).png',
              angle: 0,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            let screenType = hmSetting.getScreenType();

            idle_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 466,
              h: 466,
              src: 'aods.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_analog_clock_time_pointer_hour = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              hour_path: 'h10.png',
              hour_centerX: 233,
              hour_centerY: 233,
              hour_posX: 22,
              hour_posY: 162,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_analog_clock_time_pointer_minute = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              minute_path: 'm10.png',
              minute_centerX: 233,
              minute_centerY: 233,
              minute_posX: 17,
              minute_posY: 202,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 216,
              y: 216,
              src: 'bt.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_AOD,
            });
			
			function get_values (){
			  valueBattery = battery.current;
			}

			get_values ();
			
			battery.addEventListener(hmSensor.event.CHANGE, function () {
              get_values();
            });
			
			batteryInfo_click = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 48,
              y: 105,
              w: 60,
              h: 60,
              text: '',
              normal_src: 'Empty.png',
              press_src: 'Empty.png',
              click_func: () => {
                hmUI.showToast({ text: 'Battery is ' + valueBattery + ' %' });
              },
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_stopwatch_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 404,
              y: 212,
              w: 45,
              h: 45,
              src: 'Empty.png',
              type: hmUI.data_type.STOP_WATCH,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_alarm_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 18,
              y: 212,
              w: 45,
              h: 45,
              src: 'Empty.png',
              type: hmUI.data_type.ALARM_CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_stress_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 259,
              y: 305,
              w: 65,
              h: 65,
              src: 'Empty.png',
              type: hmUI.data_type.STRESS,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            btn_zona1 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 188,
              y: 188,
              text: '',
              w: 90,
              h: 90,
              normal_src: 'Empty.png',
              press_src: 'Empty.png',
              click_func: () => {
                click_zona1();
                click_Vibrate();
              },
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            btn_zona1.setProperty(hmUI.prop.VISIBLE, true);
			normal_pai_icon_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_analog_clock_pro_hour_pointer_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_analog_clock_pro_minute_pointer_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_analog_clock_pro_second_pointer_img.setProperty(hmUI.prop.VISIBLE, false);

            normal_heart_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 50,
              y: 298,
              w: 60,
              h: 60,
              src: 'Empty.png',
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
			
			normal_calendar_img_click = hmUI.createWidget(hmUI.widget.IMG, {
              x: 142,
              y: 105,
              w: 60,
              h: 60,
              src: 'Empty.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            normal_calendar_img_click.addEventListener(hmUI.event.CLICK_DOWN, function (info) {
              hmApp.startApp({
                appid: 1,
                url: 'ScheduleCalScreen',
                native: true
              })
            });
			
			normal_settings_img_click = hmUI.createWidget(hmUI.widget.IMG, {
              x: 355,
              y: 105,
              w: 60,
              h: 60,
              src: 'Empty.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            normal_settings_img_click.addEventListener(hmUI.event.CLICK_DOWN, function (info) {
              hmApp.startApp({
                appid: 1,
                url: 'Settings_homeScreen',
                native: true
              })
            });
			
			normal_music_img_click = hmUI.createWidget(hmUI.widget.IMG, {
              x: 313,
              y: 200,
              w: 65,
              h: 65,
              src: 'Empty.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            normal_music_img_click.addEventListener(hmUI.event.CLICK_DOWN, function (info) {
              hmApp.startApp({
                appid: 1,
                url: 'LocalMusicScreen',
                native: true
              })
            });
			
			normal_contact_img_click = hmUI.createWidget(hmUI.widget.IMG, {
              x: 142,
              y: 304,
              w: 65,
              h: 65,
              src: 'Empty.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            normal_contact_img_click.addEventListener(hmUI.event.CLICK_DOWN, function (info) {
              hmApp.startApp({
                appid: 1,
                url: 'PhoneContactsScreen',
                native: true
              })
            });
			
			normal_phone_img_click = hmUI.createWidget(hmUI.widget.IMG, {
              x: 202,
              y: 385,
              w: 65,
              h: 65,
              src: 'Empty.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            normal_phone_img_click.addEventListener(hmUI.event.CLICK_DOWN, function (info) {
              hmApp.startApp({
                appid: 1,
                url: 'PhoneRecentCallScreen',
                native: true
              })
            });
			
			normal_voice_img_click = hmUI.createWidget(hmUI.widget.IMG, {
              x: 92,
              y: 205,
              w: 65,
              h: 65,
              src: 'Empty.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            normal_voice_img_click.addEventListener(hmUI.event.CLICK_DOWN, function (info) {
              hmApp.startApp({
                appid: 1,
                url: 'VoiceMemoScreen',
                native: true
              })
            });
			
			normal_load_img_click = hmUI.createWidget(hmUI.widget.IMG, {
              x: 355,
              y: 295,
              w: 65,
              h: 65,
              src: 'Empty.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            normal_load_img_click.addEventListener(hmUI.event.CLICK_DOWN, function (info) {
              hmApp.startApp({
                appid: 1,
                url: 'SportStatusScreen',
                native: true
              })
            });
			
			hmUI.createWidget(hmUI.widget.BUTTON, {
				 x: 260,        
				 y: 100,      
				 w: 65,      
				 h: 65,     
				 text: '',      
				 normal_src: 'Empty.png',      
				 press_src: 'Empty.png', 
				 click_func: () => {
				hmApp.startApp({ url: 'activityAppScreen', native: true }); 
				 },
				 show_level: hmUI.show_level.ONLY_NORMAL,
			});
			
			btn_bezel = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 113,
              y: 26,
              text: '',
              w: 65,
              h: 55,
              normal_src: 'Empty.png',
              press_src: 'Empty.png',
              click_func: () => {
                  click_Bezel();
              },
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            btn_bezel.setProperty(hmUI.prop.VISIBLE, true);

            function time_update(updateHour = false, updateMinute = false) {
              let hour = timeSensor.hour;
              let minute = timeSensor.minute;
              let second = timeSensor.second;

              if (updateHour) {
                let normal_hour = hour;
                let normal_fullAngle_hour = 360;
                if (normal_hour > 11) normal_hour -= 12;
                let normal_angle_hour = 0 + normal_fullAngle_hour*normal_hour/12 + (normal_fullAngle_hour/12)*minute/60;
                if (normal_analog_clock_pro_hour_pointer_img) normal_analog_clock_pro_hour_pointer_img.setProperty(hmUI.prop.ANGLE, normal_angle_hour);
              };

              if (updateMinute) {
                let normal_fullAngle_minute = 360;
                let normal_angle_minute = 0 + normal_fullAngle_minute*minute/60;
                if (normal_analog_clock_pro_minute_pointer_img) normal_analog_clock_pro_minute_pointer_img.setProperty(hmUI.prop.ANGLE, normal_angle_minute);
              };

              let normal_fullAngle_second = 360;
              let normal_angle_second = 0 + normal_fullAngle_second*second/60;
              if (normal_analog_clock_pro_second_pointer_img) normal_analog_clock_pro_second_pointer_img.setProperty(hmUI.prop.ANGLE, normal_angle_second);

            };

            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                time_update(true, true);
                if (screenType == hmSetting.screen_type.WATCHFACE) {
                  if (!normal_timerUpdateSec) {
                    let animDelay = timeSensor.utc % 1000;
                    let animRepeat = 1000;
                    normal_timerUpdateSec = timer.createTimer(animDelay, animRepeat, (function (option) {
                      time_update(false, false);
                    }));  // end timer 
                  };  // end timer check
                };  // end screenType


              }),
              pause_call: (function () {
                if (normal_timerUpdateSec) {
                  timer.stopTimer(normal_timerUpdateSec);
                  normal_timerUpdateSec = undefined;
                }

              }),
            });

                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}