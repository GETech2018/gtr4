﻿
    /*
    ** Watch_Face_Editor tool
    ** watchface js version v1.0.1
    ** Copyright © CashaCX75. All Rights Reserved
    */

    try {

      (() => {

        var __$$app$$__ = __$$hmAppManager$$__.currentApp;
        var __$$module$$__ = __$$app$$__.current;
        //drink is a name,can modify
        var h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__), 'drink');

        'use strict';

        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_analog_clock_time_pointer_minute = ''
        let normal_analog_clock_time_pointer_second = ''
		let normal_battery_icon_img = ''
        let normal_digital_clock_img_time = ''
        let idle_background_bg_img = ''
        let idle_digital_clock_img_time = ''

		let sec_pointer = null;
		let clock_timer = null
		var sec_offset = 0;
		var sec_old = 0;								   	 

        //dynamic modify end 
		
        //not required
        const logger = DeviceRuntimeCore.HmLogger.getLogger("yeguang");

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({

          init_view() {

            //dynamic modify start
                    
            
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 466,
              h: 466,
              src: '0000.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_minute = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              minute_path: '0042.png',
              minute_centerX: 233,
              minute_centerY: 233,
              minute_posX: 233,
              minute_posY: 233,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_analog_clock_time_pointer_second = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              // second_path: '0041.png',
              // second_centerX: 233,
              // second_centerY: 233,
              // second_posX: 233,
              // second_posY: 233,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });
			
			// Smooth Seconds
			// normal_analog_clock_time_pointer_second = normal_analog_clock_time_pointer_second || hmUI.createWidget(hmUI.widget.IMG, {
			  // x: 0,
			  // y: 0,
			  // w: 466,
			  // h: 466,
			  // pos_x: 466 / 2,
			  // pos_y: 466 / 2,
			  // center_x: 233,
			  // center_y: 233,
			  // src: "0041.png",
			  // angle: 45,
			  // show_level: hmUI.show_level.ONLY_NORMAL,
			// });
			// setSec();
			
			sec_pointer = hmUI.createWidget(hmUI.widget.IMG, {
				x: 0,
				y: 0,
				w: 466,//display screen width
				h: 466,//display screen height
				pos_x: 0,
				pos_y: 0,
				center_x: 233,
				center_y: 233,
				angle: 0,
				src: "0041.png",
				show_level: hmUI.show_level.ONLY_NORMAL,
			});

            normal_battery_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 304,
              y: 190,
              src: '0044.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
			
            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 166,
              hour_startY: 193,
              hour_array: ["0001.png","0002.png","0003.png","0004.png","0005.png","0006.png","0007.png","0008.png","0009.png","0010.png"],
              hour_zero: 1,
              hour_space: 0,
              hour_align: hmUI.align.CENTER_H,

              minute_startX: 322,
              minute_startY: 209,
              minute_array: ["0011.png","0012.png","0013.png","0014.png","0015.png","0016.png","0017.png","0018.png","0019.png","0020.png"],
              minute_zero: 1,
              minute_space: 0,
              minute_follow: 0,
              minute_align: hmUI.align.CENTER_H,
			  
			  second_startX: 407,
              second_startY: 209,
              second_array: ["0021.png","0022.png","0023.png","0024.png","0025.png","0026.png","0027.png","0028.png","0029.png","0030.png"],
              second_zero: 1,
              second_space: -1,
              second_follow: 0,
              second_align: hmUI.align.CENTER_H,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });

			const time_naw = hmSensor.createSensor(hmSensor.id.TIME);
				
			clock_timer = timer.createTimer(0, 167, (function (option) {
				var sec = time_naw.second;
				if(sec != sec_old)
				{
					sec_offset = 0;                  
				}
				sec_old = sec;
				//sec = sec + sec_offset;
				sec_offset = sec_offset + 1;
				var angle = sec * 6 + sec_offset;
				sec_pointer.setProperty(hmUI.prop.ANGLE, angle);
			}));

            idle_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 466,
              h: 466,
              src: '0043.png',
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 166,
              hour_startY: 193,
              hour_array: ["0001.png","0002.png","0003.png","0004.png","0005.png","0006.png","0007.png","0008.png","0009.png","0010.png"],
              hour_zero: 1,
              hour_space: 0,
              hour_align: hmUI.align.CENTER_H,

              minute_startX: 322,
              minute_startY: 209,
              minute_array: ["0011.png","0012.png","0013.png","0014.png","0015.png","0016.png","0017.png","0018.png","0019.png","0020.png"],
              minute_zero: 1,
              minute_space: 0,
              minute_follow: 0,
              minute_align: hmUI.align.CENTER_H,

              show_level: hmUI.show_level.ONAL_AOD,
            });
			
			const vDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
				resume_call: (function () {
					var sec = time_naw.second;
					if(sec != sec_old)
					{
						sec_offset = 0;                  
					}
					sec_old = sec;
					//sec = sec + sec_offset;
					sec_offset = sec_offset + 1;
					var angle = sec * 6 + sec_offset;
					sec_pointer.setProperty(hmUI.prop.ANGLE, angle);
						
				}),
				pause_call: (function () {
					console.log('ui pause');
				}),

			});

        //dynamic modify end
      },

      onInit() {
        console.log('index page.js on init invoke')
        this.init_view()
      },

      onReady() {
        console.log('index page.js on ready invoke')
      },

      onShow() {
        console.log('index page.js on show invoke')
      },

      onHide() {
        console.log('index page.js on hide invoke')
      },
    });

  })()
} catch (e) {
  console.log(e)
}