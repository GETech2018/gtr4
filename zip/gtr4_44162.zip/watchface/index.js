﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (()=>{
        //dynamic modify start

        const lang = DeviceRuntimeCore.HmUtils.getLanguage()
        let normal_background_bg_img = ''
        let normal_readiness_text_text_img = ''
        let normal_date_img_date_year = ''
        let normal_date_img_date_month = ''
        let normal_date_img_date_day = ''
        let normal_sleep_score_font = ''
        let normal_wakeup_count_font = ''
        let normal_wakeup_time_font = ''
        let normal_sleep_time_font = ''
        let normal_system_lock_img = ''
        let normal_system_disconnect_img = ''
        let normal_system_clock_img = ''
        let normal_alarm_clock_current_text_font = ''
        let normal_date_img_date_week_img = ''
        let normal_calorie_current_text_img = ''
        let normal_weather_image_progress_img_level = ''
        let normal_temperature_max_min_text_img = ''
        let normal_temperature_current_text_img = ''
        let normal_distance_text_text_img = ''
        let normal_step_current_text_img = ''
        let normal_battery_text_text_img = ''
        let normal_heart_rate_text_text_img = ''
        let normal_heart_rate_image_progress_img_level = ''
        let normal_digital_clock_img_time = ''
        let idle_background_bg_img = ''
        let idle_readiness_text_text_img = ''
        let idle_date_img_date_day = ''
        let idle_date_img_date_year = ''
        let idle_date_img_date_month = ''
        let idle_battery_text_text_img = ''
        let idle_heart_rate_text_text_img = ''
        let idle_heart_rate_image_progress_img_level = ''
        let idle_step_current_text_img = ''
        let idle_alarm_clock_text_text_img = ''
        let idle_digital_clock_img_time = ''
        let normal_step_jumpable_img_click = ''
        let normal_cal_jumpable_img_click = ''
        let normal_heart_jumpable_img_click = ''
        let normal_battery_jumpable_img_click = ''
        let normal_temperature_jumpable_img_click = ''
        let normal_countdown_jumpable_img_click = ''
        let normal_stopwatch_jumpable_img_click = ''
        let normal_alarm_jumpable_img_click = ''
        let normal_sleep_jumpable_img_click = ''
        let normal_readiness_jumpable_img_click = ''
        let Button_1 = ''
        let Button_2 = ''
        let sleepSensor = '';


        //dynamic modify end
        const e = __$$hmAppManager$$__.currentApp;
        const o = e.current
          , {px: i} = (new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(e,o)),
        e.__globals__)
          , n = Logger.getLogger("watchface6");
        o.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            console.log('Watch_Face.ScreenNormal');
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 466,
              h: 466,
              src: 'bg1.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_readiness_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 231,
              y: 275,
              font_array: ["A100_114.png","A100_115.png","A100_116.png","A100_117.png","A100_118.png","A100_119.png","A100_120.png","A100_121.png","A100_122.png","A100_123.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.READINESS,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_year = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              year_startX: 246,
              year_startY: 39,
              year_sc_array: ["A100_114.png","A100_115.png","A100_116.png","A100_117.png","A100_118.png","A100_119.png","A100_120.png","A100_121.png","A100_122.png","A100_123.png"],
              year_tc_array: ["A100_114.png","A100_115.png","A100_116.png","A100_117.png","A100_118.png","A100_119.png","A100_120.png","A100_121.png","A100_122.png","A100_123.png"],
              year_en_array: ["A100_114.png","A100_115.png","A100_116.png","A100_117.png","A100_118.png","A100_119.png","A100_120.png","A100_121.png","A100_122.png","A100_123.png"],
              year_zero: 0,
              year_space: 0,
              year_align: hmUI.align.CENTER_H,
              year_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_month = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 178,
              month_startY: 39,
              month_sc_array: ["A100_114.png","A100_115.png","A100_116.png","A100_117.png","A100_118.png","A100_119.png","A100_120.png","A100_121.png","A100_122.png","A100_123.png"],
              month_tc_array: ["A100_114.png","A100_115.png","A100_116.png","A100_117.png","A100_118.png","A100_119.png","A100_120.png","A100_121.png","A100_122.png","A100_123.png"],
              month_en_array: ["A100_114.png","A100_115.png","A100_116.png","A100_117.png","A100_118.png","A100_119.png","A100_120.png","A100_121.png","A100_122.png","A100_123.png"],
              month_zero: 1,
              month_space: 5,
              month_unit_sc: 'minus.png',
              month_unit_tc: 'minus.png',
              month_unit_en: 'minus.png',
              month_align: hmUI.align.CENTER_H,
              month_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 109,
              day_startY: 39,
              day_sc_array: ["A100_114.png","A100_115.png","A100_116.png","A100_117.png","A100_118.png","A100_119.png","A100_120.png","A100_121.png","A100_122.png","A100_123.png"],
              day_tc_array: ["A100_114.png","A100_115.png","A100_116.png","A100_117.png","A100_118.png","A100_119.png","A100_120.png","A100_121.png","A100_122.png","A100_123.png"],
              day_en_array: ["A100_114.png","A100_115.png","A100_116.png","A100_117.png","A100_118.png","A100_119.png","A100_120.png","A100_121.png","A100_122.png","A100_123.png"],
              day_zero: 1,
              day_space: 5,
              day_unit_sc: 'minus.png',
              day_unit_tc: 'minus.png',
              day_unit_en: 'minus.png',
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sleep_score_font = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 310,
              y: 331,
              w: 146,
              h: 29,
              text_size: 24,
              char_space: 0,
              color: 0xFFFFFFFF,
              line_space: 0,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.CENTER_H,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_wakeup_count_font = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 303,
              y: 370,
              w: 146,
              h: 29,
              text_size: 24,
              char_space: 0,
              color: 0xFFFFFFFF,
              line_space: 0,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.CENTER_H,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_wakeup_time_font = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 310,
              y: 291,
              w: 146,
              h: 29,
              text_size: 24,
              char_space: 0,
              color: 0xFFFFFFFF,
              line_space: 0,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.CENTER_H,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sleep_time_font = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 327,
              y: 204,
              w: 146,
              h: 29,
              text_size: 24,
              char_space: 0,
              color: 0xFFFFFFFF,
              line_space: 0,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.CENTER_H,
              // padding: true,
              // unit_string: :,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_lock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 43,
              y: 171,
              src: 'lock.png',
              type: hmUI.system_status.LOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 40,
              y: 134,
              src: 'bt.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 321,
              y: 247,
              src: 'alarm.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_alarm_clock_current_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 327,
              y: 242,
              w: 146,
              h: 29,
              text_size: 24,
              char_space: 0,
              color: 0xFFFFFFFF,
              line_space: 0,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.CENTER_H,
              padding: true,
              type: hmUI.data_type.ALARM_CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
			
			let dned=["day_1.png","day_2.png","day_3.png","day_4.png","day_5.png","day_6.png","day_7.png"]
			if(lang=='ru-RU'){
				dned=["dayru_1.png","dayru_2.png","dayru_3.png","dayru_4.png","dayru_5.png","dayru_6.png","dayru_7.png"]
			}
            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 82,
              y: 93,
              week_en: dned,
              week_tc: ["day_1.png","day_2.png","day_3.png","day_4.png","day_5.png","day_6.png","day_7.png"],
              week_sc: ["day_1.png","day_2.png","day_3.png","day_4.png","day_5.png","day_6.png","day_7.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_calorie_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 93,
              y: 379,
              font_array: ["num_0.png","num_1.png","num_2.png","num_3.png","num_4.png","num_5.png","num_6.png","num_7.png","num_8.png","num_9.png"],
              padding: false,
              h_space: -1,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 335,
              y: 71,
              image_array: ["w_1.png","w_2.png","w_3.png","w_4.png","w_5.png","w_6.png","w_7.png","w_8.png","w_9.png","w_10.png","w_11.png","w_12.png","w_13.png","w_14.png","w_15.png","w_16.png","w_17.png","w_18.png","w_19.png","w_20.png","w_21.png","w_22.png","w_23.png","w_24.png","w_25.png","w_26.png","w_27.png","w_28.png","w_29.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_max_min_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 339,
              y: 162,
              font_array: ["num_0.png","num_1.png","num_2.png","num_3.png","num_4.png","num_5.png","num_6.png","num_7.png","num_8.png","num_9.png"],
              padding: false,
              h_space: 0,
              negative_image: 'min.png',
              dot_image: 'sl.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_HIGH_LOW,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 332,
              y: 126,
              font_array: ["A100_114.png","A100_115.png","A100_116.png","A100_117.png","A100_118.png","A100_119.png","A100_120.png","A100_121.png","A100_122.png","A100_123.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'gradus.png',
              unit_tc: 'gradus.png',
              unit_en: 'gradus.png',
              negative_image: 'minus.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_distance_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 209,
              y: 395,
              font_array: ["num_0.png","num_1.png","num_2.png","num_3.png","num_4.png","num_5.png","num_6.png","num_7.png","num_8.png","num_9.png"],
              padding: false,
              h_space: 0,
              dot_image: 'dot.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.DISTANCE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 208,
              y: 354,
              font_array: ["num_0.png","num_1.png","num_2.png","num_3.png","num_4.png","num_5.png","num_6.png","num_7.png","num_8.png","num_9.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 44,
              y: 275,
              font_array: ["A100_114.png","A100_115.png","A100_116.png","A100_117.png","A100_118.png","A100_119.png","A100_120.png","A100_121.png","A100_122.png","A100_123.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 137,
              y: 275,
              font_array: ["A100_114.png","A100_115.png","A100_116.png","A100_117.png","A100_118.png","A100_119.png","A100_120.png","A100_121.png","A100_122.png","A100_123.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 150,
              y: 249,
              image_array: ["h_0.png","h_1.png","h_2.png","h_3.png","h_4.png","h_5.png"],
              image_length: 6,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 78,
              hour_startY: 141,
              hour_array: ["A100_049.png","A100_050.png","A100_051.png","A100_052.png","A100_053.png","A100_054.png","A100_055.png","A100_056.png","A100_057.png","A100_058.png"],
              hour_zero: 1,
              hour_space: 5,
              hour_angle: 0,
              hour_unit_sc: 'A100_059.png',
              hour_unit_tc: 'A100_059.png',
              hour_unit_en: 'A100_059.png',
              hour_align: hmUI.align.LEFT,

              minute_startX: 191,
              minute_startY: 141,
              minute_array: ["A100_049.png","A100_050.png","A100_051.png","A100_052.png","A100_053.png","A100_054.png","A100_055.png","A100_056.png","A100_057.png","A100_058.png"],
              minute_zero: 1,
              minute_space: 5,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              second_startX: 249,
              second_startY: 201,
              second_array: ["num_0.png","num_1.png","num_2.png","num_3.png","num_4.png","num_5.png","num_6.png","num_7.png","num_8.png","num_9.png"],
              second_zero: 1,
              second_space: 0,
              second_angle: 0,
              second_follow: 0,
              second_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            console.log('Watch_Face.ScreenAOD');
            idle_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 466,
              h: 466,
              src: 'aod1.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_readiness_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 321,
              y: 328,
              font_array: ["A100_114.png","A100_115.png","A100_116.png","A100_117.png","A100_118.png","A100_119.png","A100_120.png","A100_121.png","A100_122.png","A100_123.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.READINESS,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 153,
              day_startY: 126,
              day_sc_array: ["A100_114.png","A100_115.png","A100_116.png","A100_117.png","A100_118.png","A100_119.png","A100_120.png","A100_121.png","A100_122.png","A100_123.png"],
              day_tc_array: ["A100_114.png","A100_115.png","A100_116.png","A100_117.png","A100_118.png","A100_119.png","A100_120.png","A100_121.png","A100_122.png","A100_123.png"],
              day_en_array: ["A100_114.png","A100_115.png","A100_116.png","A100_117.png","A100_118.png","A100_119.png","A100_120.png","A100_121.png","A100_122.png","A100_123.png"],
              day_zero: 1,
              day_space: 0,
              day_unit_sc: 'null.png',
              day_unit_tc: 'null.png',
              day_unit_en: 'null.png',
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_year = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              year_startX: 270,
              year_startY: 126,
              year_sc_array: ["A100_114.png","A100_115.png","A100_116.png","A100_117.png","A100_118.png","A100_119.png","A100_120.png","A100_121.png","A100_122.png","A100_123.png"],
              year_tc_array: ["A100_114.png","A100_115.png","A100_116.png","A100_117.png","A100_118.png","A100_119.png","A100_120.png","A100_121.png","A100_122.png","A100_123.png"],
              year_en_array: ["A100_114.png","A100_115.png","A100_116.png","A100_117.png","A100_118.png","A100_119.png","A100_120.png","A100_121.png","A100_122.png","A100_123.png"],
              year_zero: 0,
              year_space: 0,
              year_align: hmUI.align.CENTER_H,
              year_is_character: false,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_month = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 213,
              month_startY: 126,
              month_sc_array: ["A100_114.png","A100_115.png","A100_116.png","A100_117.png","A100_118.png","A100_119.png","A100_120.png","A100_121.png","A100_122.png","A100_123.png"],
              month_tc_array: ["A100_114.png","A100_115.png","A100_116.png","A100_117.png","A100_118.png","A100_119.png","A100_120.png","A100_121.png","A100_122.png","A100_123.png"],
              month_en_array: ["A100_114.png","A100_115.png","A100_116.png","A100_117.png","A100_118.png","A100_119.png","A100_120.png","A100_121.png","A100_122.png","A100_123.png"],
              month_zero: 1,
              month_space: 0,
              month_unit_sc: 'null.png',
              month_unit_tc: 'null.png',
              month_unit_en: 'null.png',
              month_align: hmUI.align.CENTER_H,
              month_is_character: false,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 83,
              y: 328,
              font_array: ["A100_114.png","A100_115.png","A100_116.png","A100_117.png","A100_118.png","A100_119.png","A100_120.png","A100_121.png","A100_122.png","A100_123.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 205,
              y: 328,
              font_array: ["A100_114.png","A100_115.png","A100_116.png","A100_117.png","A100_118.png","A100_119.png","A100_120.png","A100_121.png","A100_122.png","A100_123.png"],
              padding: false,
              h_space: 0,
              invalid_image: 'null.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_heart_rate_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 217,
              y: 302,
              image_array: ["h_0.png","h_1.png","h_2.png","h_3.png","h_4.png","h_5.png"],
              image_length: 6,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 193,
              y: 417,
              font_array: ["num_0.png","num_1.png","num_2.png","num_3.png","num_4.png","num_5.png","num_6.png","num_7.png","num_8.png","num_9.png"],
              padding: false,
              h_space: 3,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_alarm_clock_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 176,
              y: 63,
              font_array: ["A100_114.png","A100_115.png","A100_116.png","A100_117.png","A100_118.png","A100_119.png","A100_120.png","A100_121.png","A100_122.png","A100_123.png"],
              padding: true,
              h_space: 0,
              invalid_image: 'nullalarm.png',
              dot_image: 'dots.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.ALARM_CLOCK,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 83,
              hour_startY: 197,
              hour_array: ["A100_006.png","A100_007.png","A100_008.png","A100_009.png","A100_010.png","A100_011.png","A100_012.png","A100_013.png","A100_014.png","A100_015.png"],
              hour_zero: 1,
              hour_space: 10,
              hour_angle: 0,
              hour_unit_sc: 'A100_016.png',
              hour_unit_tc: 'A100_016.png',
              hour_unit_en: 'A100_016.png',
              hour_align: hmUI.align.LEFT,

              minute_startX: 247,
              minute_startY: 197,
              minute_array: ["A100_006.png","A100_007.png","A100_008.png","A100_009.png","A100_010.png","A100_011.png","A100_012.png","A100_013.png","A100_014.png","A100_015.png"],
              minute_zero: 1,
              minute_space: 10,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_AOD,
            });
            console.log('Watch_Face.Shortcuts');

            normal_step_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 204,
              y: 345,
              w: 97,
              h: 97,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_cal_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 58,
              y: 345,
              w: 97,
              h: 97,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 124,
              y: 243,
              w: 85,
              h: 78,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 31,
              y: 243,
              w: 85,
              h: 78,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 330,
              y: 87,
              w: 97,
              h: 97,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_countdown_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 190,
              y: 138,
              w: 97,
              h: 53,
              type: hmUI.data_type.COUNT_DOWN,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_stopwatch_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 216,
              y: 194,
              w: 97,
              h: 46,
              type: hmUI.data_type.STOP_WATCH,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_alarm_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 330,
              y: 244,
              w: 97,
              h: 49,
              type: hmUI.data_type.ALARM_CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sleep_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 330,
              y: 191,
              w: 97,
              h: 49,
              type: hmUI.data_type.SLEEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_readiness_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 216,
              y: 243,
              w: 85,
              h: 78,
              type: hmUI.data_type.READINESS,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            console.log('Watch_Face.Buttons');
            Button_1 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 330,
              y: 296,
              w: 85,
              h: 107,
              text: '',
              color: 0xFFFF8C00,
              text_size: 24,
              press_src: 'Empty.png',
              normal_src: 'Empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'oneKeyNightMonitorScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_2 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 107,
              y: 53,
              w: 85,
              h: 78,
              text: '',
              color: 0xFFFF8C00,
              text_size: 24,
              press_src: 'Empty.png',
              normal_src: 'Empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'ScheduleCalScreen', native: true });
              }, // end func
              longpress_func: (button_widget) => {
                hmApp.startApp({url: 'todoListScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            if (!sleepSensor) sleepSensor = hmSensor.createSensor(hmSensor.id.SLEEP);
            //#region sleep_update
            function sleep_update() {
              console.log('sleep_update()');
              let sleepInfo = sleepSensor.getBasicInfo();

              console.log('sleep score');
              let sleepScore = sleepInfo.score;
              if (normal_sleep_score_font) normal_sleep_score_font.setProperty(hmUI.prop.TEXT, String(sleepScore));

              console.log('sleep wakeup count');
              let sleepTime = sleepSensor.getTotalTime();
              const modelData = sleepSensor.getSleepStageModel();
              let sleepStageArray = sleepSensor.getSleepStageData();
              let wakeupTime = 0;
              let wakeupCount = 0;

              for (let i = 0; i < sleepStageArray.length; i++) {
                let data = sleepStageArray[i];
                if (data.model == modelData.WAKE_STAGE) {
                  wakeupTime += data.stop + 1 - data.start;
                  wakeupCount++;
                };
              };
              sleepTime -= wakeupTime;
              if (normal_wakeup_count_font) normal_wakeup_count_font.setProperty(hmUI.prop.TEXT, String(wakeupCount));

              console.log('sleep wakeup time');
              let wakeupTimeHour = Math.floor(wakeupTime / 60);
              let wakeupTimeMin = wakeupTime % 60;

              if (normal_wakeup_time_font) normal_wakeup_time_font.setProperty(hmUI.prop.TEXT, wakeupTime.toString());

              console.log('sleep duration time');
              let sleepTimeHour = Math.floor(sleepTime / 60);
              let sleepTimeMin = sleepTime % 60;

              let normal_sleepTimeHourStr = sleepTimeHour.toString();
              normal_sleepTimeHourStr = normal_sleepTimeHourStr.padStart(2, '0');
              let normal_sleepTimeMinStr = sleepTimeMin.toString().padStart(2, '0');
              let normal_sleepTimeStr = normal_sleepTimeHourStr + ':' + normal_sleepTimeMinStr;
              if (normal_sleep_time_font) normal_sleep_time_font.setProperty(hmUI.prop.TEXT, normal_sleepTimeStr);

            };

            //#endregion
            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                console.log('resume_call()');
                sleep_update();
              }),
            });

                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}