﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        const logger = Logger.getLogger('watchface_SashaCX75');
        //end of ignored block

        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_system_lock_img = ''
        let normal_system_disconnect_img = ''
        let normal_system_clock_img = ''
        let normal_calorie_current_text_img = ''
        let normal_calorie_current_separator_img = ''
        let normal_distance_text_text_img = ''
        let normal_distance_text_separator_img = ''
        let normal_step_current_text_img = ''
        let normal_step_current_separator_img = ''
        let normal_heart_rate_text_text_img = ''
        let normal_date_img_date_day = ''
        let normal_battery_pointer_progress_img_pointer = ''
        let normal_battery_text_text_img = ''
        let normal_date_img_date_week_img = ''
        let normal_digital_clock_img_time = ''
        let normal_analog_clock_time_pointer_hour = ''
        let normal_analog_clock_time_pointer_minute = ''
        let image_top_img = ''
        let normal_stopwatch_jumpable_img_click = ''
        let Button_1 = ''
        let Button_2 = ''
        let Button_3 = ''
        let Button_4 = ''
        let Button_5 = ''
        let Button_6 = ''


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            console.log('Watch_Face.ScreenNormal');
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 466,
              h: 466,
              src: 'bg_1.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_lock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 208,
              y: 295,
              src: 'lock.png',
              type: hmUI.system_status.LOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 273,
              y: 135,
              src: 'bt.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 169,
              y: 135,
              src: 'alarms.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_calorie_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 191,
              y: 383,
              font_array: ["date_0.png","date_1.png","date_2.png","date_3.png","date_4.png","date_5.png","date_6.png","date_7.png","date_8.png","date_9.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_calorie_current_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 190,
              y: 363,
              src: 'kcal.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_distance_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 185,
              y: 383,
              font_array: ["date_0.png","date_1.png","date_2.png","date_3.png","date_4.png","date_5.png","date_6.png","date_7.png","date_8.png","date_9.png"],
              padding: false,
              h_space: 0,
              dot_image: 'dot.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.DISTANCE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_distance_text_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 189,
              y: 364,
              src: 'dist.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 182,
              y: 381,
              font_array: ["date_0.png","date_1.png","date_2.png","date_3.png","date_4.png","date_5.png","date_6.png","date_7.png","date_8.png","date_9.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 202,
              y: 358,
              src: 'stp.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 133,
              y: 309,
              font_array: ["date_0.png","date_1.png","date_2.png","date_3.png","date_4.png","date_5.png","date_6.png","date_7.png","date_8.png","date_9.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 305,
              day_startY: 218,
              day_sc_array: ["date_0.png","date_1.png","date_2.png","date_3.png","date_4.png","date_5.png","date_6.png","date_7.png","date_8.png","date_9.png"],
              day_tc_array: ["date_0.png","date_1.png","date_2.png","date_3.png","date_4.png","date_5.png","date_6.png","date_7.png","date_8.png","date_9.png"],
              day_en_array: ["date_0.png","date_1.png","date_2.png","date_3.png","date_4.png","date_5.png","date_6.png","date_7.png","date_8.png","date_9.png"],
              day_zero: 1,
              day_space: 0,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_pointer_progress_img_pointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
              src: 'week.png',
              center_x: 89,
              center_y: 232,
              x: 73,
              y: 73,
              start_angle: -180,
              end_angle: 180,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 275,
              y: 309,
              font_array: ["date_0.png","date_1.png","date_2.png","date_3.png","date_4.png","date_5.png","date_6.png","date_7.png","date_8.png","date_9.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 302,
              y: 160,
              week_en: ["week_1.png","week_2.png","week_3.png","week_4.png","week_5.png","week_6.png","week_7.png"],
              week_tc: ["week_1.png","week_2.png","week_3.png","week_4.png","week_5.png","week_6.png","week_7.png"],
              week_sc: ["week_1.png","week_2.png","week_3.png","week_4.png","week_5.png","week_6.png","week_7.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 109,
              hour_startY: 83,
              hour_array: ["wfs_bitmap_clock_0_234c9bb1_6574_49a4_aac6_e97d36c7bc3b.png","wfs_bitmap_clock_1_f79b0cef_82fb_40bf_8c23_df13757e2d18.png","wfs_bitmap_clock_2_9dcd1f20_3776_4021_a51b_a3062ddab862.png","wfs_bitmap_clock_3_b73f786e_3ccf_4e93_88b0_e214e6a598e1.png","wfs_bitmap_clock_4_70c33bcf_bb4e_483b_83f5_4005772b9529.png","wfs_bitmap_clock_5_8b5ae16b_e302_4a19_886e_1ddb58b805f6.png","wfs_bitmap_clock_6_cbbf3360_040e_46fc_94ba_2470b8f62977.png","wfs_bitmap_clock_7_0ed20b03_ab63_49f3_99cf_7cd93d3e0a9c.png","wfs_bitmap_clock_8_890b0b78_44d1_4cd3_bc48_8da3f906df1d.png","wfs_bitmap_clock_9_8acb9b82_287e_4446_87cb_898e6f0f7b76.png"],
              hour_zero: 1,
              hour_space: 0,
              hour_angle: 0,
              hour_unit_sc: 'wfs_bitmap_colon_8971c0f6_1824_499c_8cae_90d1394293ba.png',
              hour_unit_tc: 'wfs_bitmap_colon_8971c0f6_1824_499c_8cae_90d1394293ba.png',
              hour_unit_en: 'wfs_bitmap_colon_8971c0f6_1824_499c_8cae_90d1394293ba.png',
              hour_align: hmUI.align.LEFT,

              minute_startX: 196,
              minute_startY: 83,
              minute_array: ["wfs_bitmap_clock_0_234c9bb1_6574_49a4_aac6_e97d36c7bc3b.png","wfs_bitmap_clock_1_f79b0cef_82fb_40bf_8c23_df13757e2d18.png","wfs_bitmap_clock_2_9dcd1f20_3776_4021_a51b_a3062ddab862.png","wfs_bitmap_clock_3_b73f786e_3ccf_4e93_88b0_e214e6a598e1.png","wfs_bitmap_clock_4_70c33bcf_bb4e_483b_83f5_4005772b9529.png","wfs_bitmap_clock_5_8b5ae16b_e302_4a19_886e_1ddb58b805f6.png","wfs_bitmap_clock_6_cbbf3360_040e_46fc_94ba_2470b8f62977.png","wfs_bitmap_clock_7_0ed20b03_ab63_49f3_99cf_7cd93d3e0a9c.png","wfs_bitmap_clock_8_890b0b78_44d1_4cd3_bc48_8da3f906df1d.png","wfs_bitmap_clock_9_8acb9b82_287e_4446_87cb_898e6f0f7b76.png"],
              minute_zero: 1,
              minute_space: 0,
              minute_angle: 0,
              minute_follow: 0,
              minute_unit_sc: 'wfs_bitmap_colon_8971c0f6_1824_499c_8cae_90d1394293ba.png',
              minute_unit_tc: 'wfs_bitmap_colon_8971c0f6_1824_499c_8cae_90d1394293ba.png',
              minute_unit_en: 'wfs_bitmap_colon_8971c0f6_1824_499c_8cae_90d1394293ba.png',
              minute_align: hmUI.align.LEFT,

              second_startX: 283,
              second_startY: 83,
              second_array: ["wfs_bitmap_clock_0_234c9bb1_6574_49a4_aac6_e97d36c7bc3b.png","wfs_bitmap_clock_1_f79b0cef_82fb_40bf_8c23_df13757e2d18.png","wfs_bitmap_clock_2_9dcd1f20_3776_4021_a51b_a3062ddab862.png","wfs_bitmap_clock_3_b73f786e_3ccf_4e93_88b0_e214e6a598e1.png","wfs_bitmap_clock_4_70c33bcf_bb4e_483b_83f5_4005772b9529.png","wfs_bitmap_clock_5_8b5ae16b_e302_4a19_886e_1ddb58b805f6.png","wfs_bitmap_clock_6_cbbf3360_040e_46fc_94ba_2470b8f62977.png","wfs_bitmap_clock_7_0ed20b03_ab63_49f3_99cf_7cd93d3e0a9c.png","wfs_bitmap_clock_8_890b0b78_44d1_4cd3_bc48_8da3f906df1d.png","wfs_bitmap_clock_9_8acb9b82_287e_4446_87cb_898e6f0f7b76.png"],
              second_zero: 1,
              second_space: 0,
              second_angle: 0,
              second_follow: 0,
              second_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_hour = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              hour_path: 'h_1.png',
              hour_centerX: 233,
              hour_centerY: 233,
              hour_posX: 233,
              hour_posY: 233,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_minute = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              minute_path: 'm_1.png',
              minute_centerX: 233,
              minute_centerY: 233,
              minute_posX: 233,
              minute_posY: 233,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            console.log('Watch_Face.ScreenAOD');

            image_top_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 15,
              y: 15,
              src: 'wfs_center_516d0e3c_c37e_407a_bf52_f87d3f6bbdcf.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            console.log('Watch_Face.Shortcuts');

            normal_stopwatch_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 301,
              y: 83,
              w: 53,
              h: 53,
              type: hmUI.data_type.STOP_WATCH,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            console.log('Watch_Face.Buttons');
            Button_1 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 197,
              y: 197,
              w: 73,
              h: 73,
              text: '',
              color: 0xFFFFFFFF,
              text_size: 24,
              press_src: 'Empty.png',
              normal_src: 'Empty.png',
              click_func: (button_widget) => {
                click_Bezel();
                              },
                              show_level: hmUI.show_level.ONLY_NORMAL,
                            });
                            btn_bezel.setProperty(hmUI.prop.VISIBLE, true);
                            normal_heart_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
                              x: 125,
                              y: 310,
                              w: 80,
                              h: 55,
                              type: hmUI.data_type.HEART,
                              show_level: hmUI.show_level.ONLY_NORMAL,
                            });
                            btn_zona1 = hmUI.createWidget(hmUI.widget.BUTTON, {
                              x: 190,
                              y: 380,
                              text: '',
                              w: 100,
                              h: 65,
                              normal_src: 'Empty.png',
                              press_src: 'Empty.png',
                              click_func: () => {
                				click_zona1();
                click_Vibrate();
                             },
                			  longpress_func: () => {
                             hmApp.startApp({ url: "activityAppScreen", native: true });
                             },
                              show_level: hmUI.show_level.ONLY_NORMAL,
                            });
                            btn_zona1.setProperty(hmUI.prop.VISIBLE, true);
                			normal_distance_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
                			normal_distance_text_separator_img.setProperty(hmUI.prop.VISIBLE, false);
                			normal_calorie_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
                			normal_calorie_current_separator_img.setProperty(hmUI.prop.VISIBLE, false);
                            console.log('Watch_Face.Buttons');
                            Button_1 = hmUI.createWidget(hmUI.widget.BUTTON, {
                              x: 45,
                              y: 310,
                              w: 55,
                              h: 55,
                              text: '',
                              color: 0xFFFF8C00,
                              text_size: 25,
                              press_src: 'Empty.png',
                              normal_src: 'Empty.png',
                              click_func: (button_widget) => {
                hmApp.startApp({url: 'Settings_homeScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_2 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 369,
              y: 301,
              w: 53,
              h: 53,
              text: '',
              color: 0xFFFF8C00,
              text_size: 24,
              press_src: 'Empty.png',
              normal_src: 'Empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'VoiceMemoScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_3 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 369,
              y: 107,
              w: 53,
              h: 53,
              text: '',
              color: 0xFFFF8C00,
              text_size: 24,
              press_src: 'Empty.png',
              normal_src: 'Empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'LocalMusicScreen', native: true });
              }, // end func
              longpress_func: (button_widget) => {
                hmApp.startApp({url: 'PhoneMusicCtrlScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_4 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 44,
              y: 107,
              w: 53,
              h: 53,
              text: '',
              color: 0xFFFF8C00,
              text_size: 24,
              press_src: 'Empty.png',
              normal_src: 'Empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'PhoneRecentCallScreen', native: true });
              }, // end func
              longpress_func: (button_widget) => {
                hmApp.startApp({url: 'PhoneContactsScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_5 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 267,
              y: 301,
              w: 78,
              h: 53,
              text: '',
              color: 0xFFFF8C00,
              text_size: 24,
              press_src: 'Empty.png',
              normal_src: 'Empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'Settings_batteryManagerScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_6 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 343,
              y: 199,
              w: 78,
              h: 78,
              text: '',
              color: 0xFFFF8C00,
              text_size: 24,
              press_src: 'Empty.png',
              normal_src: 'Empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'ScheduleCalScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button


                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}