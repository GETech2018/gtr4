    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        const logger = Logger.getLogger('watchface_SashaCX75');
        //end of ignored block

        //dynamic modify start

        console.log('user_functions.js');
        // start user_functions.js
/////////////////////////////////////////////////////////////////////
// Start background change
        let codecolor ="0xFFF3462E"
        let elementnumber_5 = 1
        let total_elemente5 = 5
  let hours_array = ["Step0.png","Step1.png","Step2.png","Step3.png","Step4.png","Step5.png","Step6.png","Step7.png","Step8.png","Step9.png"];
  let second_array =["Second_Font_0.png","Second_Font_1.png","Second_Font_2.png","Second_Font_3.png","Second_Font_4.png","Second_Font_5.png","Second_Font_6.png","Second_Font_7.png","Second_Font_8.png","Second_Font_9.png"];
let fonts_array = ["Cal_GR0.png","Cal_GR1.png","Cal_GR2.png","Cal_GR3.png","Cal_GR4.png","Cal_GR5.png","Cal_GR6.png","Cal_GR7.png","Cal_GR8.png","Cal_GR9.png"];				
        function click_elemente5() {
            if(elementnumber_5 >=total_elemente5) {
           elementnumber_5=1;
            }
else { 
elementnumber_5 =elementnumber_5 +1;
}
            if(elementnumber_5 ==1) {
       hmUI.showToast({text: 'Orange Style'});
  hours_array = ["Step0.png","Step1.png","Step2.png","Step3.png","Step4.png","Step5.png","Step6.png","Step7.png","Step8.png","Step9.png"];
 second_array =["Second_Font_0.png","Second_Font_1.png","Second_Font_2.png","Second_Font_3.png","Second_Font_4.png","Second_Font_5.png","Second_Font_6.png","Second_Font_7.png","Second_Font_8.png","Second_Font_9.png"];
fonts_array = ["Cal_GR0.png","Cal_GR1.png","Cal_GR2.png","Cal_GR3.png","Cal_GR4.png","Cal_GR5.png","Cal_GR6.png","Cal_GR7.png","Cal_GR8.png","Cal_GR9.png"];				
codecolor ="0xFFF3462E"
}

            if(elementnumber_5 ==2) {
      hmUI.showToast({text: 'Cyan Style'});
  hours_array = ["StepY0.png","StepY1.png","StepY2.png","StepY3.png","StepY4.png","StepY5.png","StepY6.png","StepY7.png","StepY8.png","StepY9.png"];
 second_array =["Second_Font_Y0.png","Second_Font_Y1.png","Second_Font_Y2.png","Second_Font_Y3.png","Second_Font_Y4.png","Second_Font_Y5.png","Second_Font_Y6.png","Second_Font_Y7.png","Second_Font_Y8.png","Second_Font_Y9.png"];
fonts_array = ["Cal_GR0.png","Cal_GR1.png","Cal_GR2.png","Cal_GR3.png","Cal_GR4.png","Cal_GR5.png","Cal_GR6.png","Cal_GR7.png","Cal_GR8.png","Cal_GR9.png"];				
codecolor ="0xFFFFEB02"
}

            if(elementnumber_5 ==3) {
 hmUI.showToast({text: 'Green Style'});
  hours_array = ["StepG0.png","StepG1.png","StepG2.png","StepG3.png","StepG4.png","StepG5.png","StepG6.png","StepG7.png","StepG8.png","StepG9.png"];
 second_array =["Second_Font_G0.png","Second_Font_G1.png","Second_Font_G2.png","Second_Font_G3.png","Second_Font_G4.png","Second_Font_G5.png","Second_Font_G6.png","Second_Font_G7.png","Second_Font_G8.png","Second_Font_G9.png"];
fonts_array = ["Cal_GR0.png","Cal_GR1.png","Cal_GR2.png","Cal_GR3.png","Cal_GR4.png","Cal_GR5.png","Cal_GR6.png","Cal_GR7.png","Cal_GR8.png","Cal_GR9.png"];				
codecolor ="0xFFC4FB00"
}
            if(elementnumber_5 ==4) {
hmUI.showToast({text: 'Blue Style'});
  hours_array = ["StepB0.png","StepB1.png","StepB2.png","StepB3.png","StepB4.png","StepB5.png","StepB6.png","StepB7.png","StepB8.png","StepB9.png"];
 second_array =["Second_Font_B0.png","Second_Font_B1.png","Second_Font_B2.png","Second_Font_B3.png","Second_Font_B4.png","Second_Font_B5.png","Second_Font_B6.png","Second_Font_B7.png","Second_Font_B8.png","Second_Font_B9.png"];
fonts_array = ["Cal_GR0.png","Cal_GR1.png","Cal_GR2.png","Cal_GR3.png","Cal_GR4.png","Cal_GR5.png","Cal_GR6.png","Cal_GR7.png","Cal_GR8.png","Cal_GR9.png"];
codecolor ="0xFF0093E4"

}
            if(elementnumber_5 ==5) { 
hmUI.showToast({text: 'White Style'});
 hours_array = ["StepGR0.png","StepGR1.png","StepGR2.png","StepGR3.png","StepGR4.png","StepGR5.png","StepGR6.png","StepGR7.png","StepGR8.png","StepGR9.png"];
 second_array =["Second_Font_GR0.png","Second_Font_GR1.png","Second_Font_GR2.png","Second_Font_GR3.png","Second_Font_GR4.png","Second_Font_GR5.png","Second_Font_GR6.png","Second_Font_GR7.png","Second_Font_GR8.png","Second_Font_GR9.png"];
fonts_array = ["Cal_GR0.png","Cal_GR1.png","Cal_GR2.png","Cal_GR3.png","Cal_GR4.png","Cal_GR5.png","Cal_GR6.png","Cal_GR7.png","Cal_GR8.png","Cal_GR9.png"];
codecolor ="0xFCCCCCCF"
 
}

////////  This script bast on  GTR3 ///////////
            const deviceInfo = hmSetting.getDeviceInfo();
// hour
let xx = deviceInfo.width / 454 * 230
let yy = deviceInfo.height / 454 * 268

let xxm = deviceInfo.width / 454 * 230
let yym = deviceInfo.height / 454 * 329

let xxs = deviceInfo.width / 454 * 303
let yys = deviceInfo.height / 454 * 295

let xxd = deviceInfo.width / 454 * 251
let yyd = deviceInfo.height / 454 * 265

let xxT = deviceInfo.width / 466 * 233
let yyT = deviceInfo.height / 466 * 233
let xxTw = deviceInfo.width / 466 * 233
let yyTw = deviceInfo.height / 466 * 238

//////////////////////////////////////////////////

if (elementnumber_5 <= total_elemente5 ){
            normal_digital_clock_img_time_hour.setProperty(hmUI.prop.MORE, {
              hour_startX: xx,
              hour_startY: yy,
              hour_array: hours_array,
              hour_zero: 1,
              hour_space: 4,
              hour_angle: 0,
              hour_align: hmUI.align.LEFT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time_minute.setProperty(hmUI.prop.MORE, {
              minute_startX: xxm,
              minute_startY: yym,
              minute_array: hours_array,
              minute_zero: 1,
              minute_space: 4,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            normal_digital_clock_img_time_second.setProperty(hmUI.prop.MORE, {
              second_startX: xxs,
              second_startY: yys,
              second_array: second_array,
              second_zero: 1,
              second_space: 3,
              second_angle: 0,
              second_follow: 0,
              second_align: hmUI.align.LEFT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });



            normal_date_img_date_day.setProperty(hmUI.prop.MORE, {
              day_startX: xxd,
              day_startY: yyd,
              day_sc_array: hours_array,
              day_tc_array: hours_array,
              day_en_array: hours_array,
              day_zero: 1,
              day_space: 5,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });



normal_background_bg_img.setProperty(hmUI.prop.SRC, "main" + parseInt(elementnumber_5) + ".png");

        let HH = "Hand_H" + parseInt(elementnumber_5) + ".png"
        let MM = "Hand_M" + parseInt(elementnumber_5) + ".png"
        let SS =  "Hand_S" + parseInt(elementnumber_5) + ".png"


            normal_analog_clock_time_pointer_hour.setProperty(hmUI.prop.MORE, {
              hour_path: HH,
              hour_centerX: xxT,
              hour_centerY: yyT,
              hour_posX: xxTw,
              hour_posY: yyTw,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_minute.setProperty(hmUI.prop.MORE, {
              minute_path: MM,
              minute_centerX: xxT,
              minute_centerY: yyT,
              minute_posX: xxTw,
              minute_posY: yyTw,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_second .setProperty(hmUI.prop.MORE, {
              second_path: SS,
              second_centerX: xxT,
              second_centerY: yyT,
              second_posX: xxTw,
              second_posY: yyTw,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            normal_distance_text_text_img.setProperty(hmUI.prop.MORE, {
              x: deviceInfo.width / 454  * 244,
              y: deviceInfo.height / 454 * 339,
              font_array: fonts_array,
              padding: false,
              h_space: 3,
              unit_sc: 'Dis_KM.png',
              unit_tc: 'Dis_KM.png',
              unit_en: 'Dis_KM.png',
              imperial_unit_sc: 'Dis_Mi.png',
              imperial_unit_tc: 'Dis_Mi.png',
              imperial_unit_en: 'Dis_Mi.png',
              dot_image: 'Dis_dot.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.DISTANCE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_calorie_current_text_img.setProperty(hmUI.prop.MORE, {
              x: deviceInfo.width / 454 * 248,
              y: deviceInfo.height / 454 * 368,
              font_array: fonts_array,
              padding: false,
              h_space: 2,
              unit_sc: 'cal_k.png',
              unit_tc: 'cal_k.png',
              unit_en: 'cal_k.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            normal_step_circle_scale.setProperty(hmUI.prop.MORE, {
              center_x: deviceInfo.width / 454 * 227,
              center_y: deviceInfo.height / 454 * 227,
              start_angle: 243,
              end_angle: 417,
              radius: deviceInfo.width / 454 * 96,
              line_width: deviceInfo.width / 454 * 8,
              corner_flag: 0,
              color: codecolor,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            


            normal_step_current_text_img.setProperty(hmUI.prop.MORE, {
              x: deviceInfo.width / 454 * 212,
              y: deviceInfo.height / 454 * 283,
              font_array: hours_array,
              padding: false,
              h_space: 1,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_text_img.setProperty(hmUI.prop.MORE, {
              x: deviceInfo.width / 454 * 274,
              y: deviceInfo.height / 454 * 292,
              font_array: fonts_array,
              padding: false,
              h_space: 2,
              unit_sc: 'Weather_Symbo1.png',
              unit_tc: 'Weather_Symbo1.png',
              unit_en: 'Weather_Symbo1.png',
              negative_image: 'Weather_Symbo2.png',
              invalid_image: 'Weather_Symbo2.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });



            normal_heart_rate_text_text_img.setProperty(hmUI.prop.MORE, {
              x: deviceInfo.width / 454 * 319,
              y: deviceInfo.height / 454 * 218,
              font_array: second_array,
              padding: false,
              h_space: 2,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            normal_spo2_text_text_img.setProperty(hmUI.prop.MORE, {
              x: deviceInfo.width / 454 * 319,
              y: deviceInfo.height / 454 * 220,
              font_array: second_array,
              padding: false,
              h_space: 0,
              unit_sc: 'Batt_unit.png',
              unit_tc: 'Batt_unit.png',
              unit_en: 'Batt_unit.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.SPO2,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            normal_battery_text_text_img.setProperty(hmUI.prop.MORE, {
              x: deviceInfo.width / 454 * 261,
              y: deviceInfo.height / 454 * 372,
              font_array: fonts_array,
              padding: false,
              h_space: 2,
              unit_sc: 'Batt_unit.png',
              unit_tc: 'Batt_unit.png',
              unit_en: 'Batt_unit.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


 
const result = hmSetting.setScreenOff()

 }
 }

////////////////////////////////////////////




//////////////////////////////////////////////////////////////////////////////////////////////////
        // Activity select

        let backgroundnumber2 = 1
        let totalpictures2 = 2
        let cc = 0

        function click_info2() {
            if(backgroundnumber2>=totalpictures2) {
            backgroundnumber2=1;
                Update2BackgroundOne();
                }
            else {
                backgroundnumber2=backgroundnumber2+1;
                if(backgroundnumber2==2) {
                  Update2BackgroundTwo();
                }
  

            }
          if(backgroundnumber2==1) hmUI.showToast({text: 'Heart Rate'});
          if(backgroundnumber2==2) hmUI.showToast({text: 'Oxygen Blood'});


        }

//////////////////////////////////////////////////////////////////////////////////////////////////

        //Heart Rate
        function Update2BackgroundOne(){
        normal_heart_rate_text_text_img.setProperty(hmUI.prop.VISIBLE, true);
        normal_heart_rate_text_separator_img.setProperty(hmUI.prop.VISIBLE, true);
        normal_spo2_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
        normal_spo2_text_separator_img.setProperty(hmUI.prop.VISIBLE, false);


        normal_spo2_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, false);
        normal_heart_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, true);

        }

//////////////////////////////////////////////////////////////////////////////////////////////////

        //Oxygen Blood
        function Update2BackgroundTwo(){

        normal_heart_rate_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
        normal_heart_rate_text_separator_img.setProperty(hmUI.prop.VISIBLE, false);
        normal_spo2_text_text_img.setProperty(hmUI.prop.VISIBLE, true);
        normal_spo2_text_separator_img.setProperty(hmUI.prop.VISIBLE, true);


        normal_spo2_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, true);
        normal_heart_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, false);

        }

//////////////////////////////////////////////////////////////////////////////////////////////////




        // Activity select

        let backgroundnumber = 1
        let totalpictures = 5

        function click_info1() {
            if(backgroundnumber>=totalpictures) {
            backgroundnumber=1;
                UpdateBackgroundOne();
                }
            else {
                backgroundnumber=backgroundnumber+1;
                if(backgroundnumber==2) {
                  UpdateBackgroundTwo();
                }
                if(backgroundnumber==3) {
                  UpdateBackgroundThree();
                }
                if(backgroundnumber==4) {
                  UpdateBackgroundFour();
                }
                if(backgroundnumber==5) {
                  UpdateBackgroundFive();
                }
   

            }
          if(backgroundnumber==1) hmUI.showToast({text: 'Calendar'});
          if(backgroundnumber==2) hmUI.showToast({text: 'Activity'});
          if(backgroundnumber==3) hmUI.showToast({text: 'Time'});
          if(backgroundnumber==4) hmUI.showToast({text: 'Weather'});
          if(backgroundnumber==5) hmUI.showToast({text: 'Battery'});

        }

//////////////////////////////////////////////////////////////////////////////////////////////////

        //Calendar
        function UpdateBackgroundOne(){


       normal_frame_animation_1.setProperty(hmUI.prop.VISIBLE, false);
       normal_distance_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
       normal_calorie_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
       normal_step_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
       normal_step_current_separator_img.setProperty(hmUI.prop.VISIBLE, false);

       normal_battery_icon_img.setProperty(hmUI.prop.VISIBLE, false);
       normal_battery_pointer_progress_img_pointer.setProperty(hmUI.prop.VISIBLE, false);
       normal_battery_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
       normal_battery_text_separator_img.setProperty(hmUI.prop.VISIBLE, false);

       normal_moon_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, false);
       normal_temperature_icon_img.setProperty(hmUI.prop.VISIBLE, false);
       normal_city_name_text.setProperty(hmUI.prop.VISIBLE, false);
       normal_temperature_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
       normal_temperature_current_separator_img.setProperty(hmUI.prop.VISIBLE, false);
       normal_weather_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, false);

       normal_digital_clock_img_time_second.setProperty(hmUI.prop.VISIBLE, false);
       normal_digital_clock_second_separator_img.setProperty(hmUI.prop.VISIBLE, false);
       normal_digital_clock_img_time_minute.setProperty(hmUI.prop.VISIBLE, false);
       normal_digital_clock_minute_separator_img.setProperty(hmUI.prop.VISIBLE, false);
       normal_digital_clock_img_time_hour.setProperty(hmUI.prop.VISIBLE, false);
       normal_digital_clock_hour_separator_img.setProperty(hmUI.prop.VISIBLE, false);
       normal_digital_clock_img_time_AmPm.setProperty(hmUI.prop.VISIBLE, false);

       normal_date_img_date_month_img.setProperty(hmUI.prop.VISIBLE, true);
       normal_date_img_date_week_img.setProperty(hmUI.prop.VISIBLE, true);
       normal_date_img_date_day.setProperty(hmUI.prop.VISIBLE, true);
       normal_date_day_separator_img.setProperty(hmUI.prop.VISIBLE, true);


        normal_stopwatch_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, false);
        normal_countdown_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, false);
 
        normal_sunrise_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, false);
        normal_temperature_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, false);


        normal_step_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, false);



        }

//////////////////////////////////////////////////////////////////////////////////////////////////

        //Activity
        function UpdateBackgroundTwo(){

       normal_frame_animation_1.setProperty(hmUI.prop.VISIBLE, true);
       normal_distance_text_text_img.setProperty(hmUI.prop.VISIBLE, true);
       normal_calorie_current_text_img.setProperty(hmUI.prop.VISIBLE, true);
       normal_step_current_text_img.setProperty(hmUI.prop.VISIBLE, true);
       normal_step_current_separator_img.setProperty(hmUI.prop.VISIBLE, true);

       normal_battery_icon_img.setProperty(hmUI.prop.VISIBLE, false);
       normal_battery_pointer_progress_img_pointer.setProperty(hmUI.prop.VISIBLE, false);
       normal_battery_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
       normal_battery_text_separator_img.setProperty(hmUI.prop.VISIBLE, false);

       normal_moon_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, false);
       normal_temperature_icon_img.setProperty(hmUI.prop.VISIBLE, false);
       normal_city_name_text.setProperty(hmUI.prop.VISIBLE, false);
       normal_temperature_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
       normal_temperature_current_separator_img.setProperty(hmUI.prop.VISIBLE, false);
       normal_weather_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, false);

       normal_digital_clock_img_time_second.setProperty(hmUI.prop.VISIBLE, false);
       normal_digital_clock_second_separator_img.setProperty(hmUI.prop.VISIBLE, false);
       normal_digital_clock_img_time_minute.setProperty(hmUI.prop.VISIBLE, false);
       normal_digital_clock_minute_separator_img.setProperty(hmUI.prop.VISIBLE, false);
       normal_digital_clock_img_time_hour.setProperty(hmUI.prop.VISIBLE, false);
       normal_digital_clock_hour_separator_img.setProperty(hmUI.prop.VISIBLE, false);
       normal_digital_clock_img_time_AmPm.setProperty(hmUI.prop.VISIBLE, false);

       normal_date_img_date_month_img.setProperty(hmUI.prop.VISIBLE, false);
       normal_date_img_date_week_img.setProperty(hmUI.prop.VISIBLE, false);
       normal_date_img_date_day.setProperty(hmUI.prop.VISIBLE, false);
       normal_date_day_separator_img.setProperty(hmUI.prop.VISIBLE, false);


        normal_stopwatch_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, false);
        normal_countdown_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, false);
 
        normal_sunrise_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, false);
        normal_temperature_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, false);


        normal_step_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, true);


        }

//////////////////////////////////////////////////////////////////////////////////////////////////

        //Time
        function UpdateBackgroundThree(){

     normal_frame_animation_1.setProperty(hmUI.prop.VISIBLE, false);
       normal_distance_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
       normal_calorie_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
       normal_step_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
       normal_step_current_separator_img.setProperty(hmUI.prop.VISIBLE, false);

       normal_battery_icon_img.setProperty(hmUI.prop.VISIBLE, false);
       normal_battery_pointer_progress_img_pointer.setProperty(hmUI.prop.VISIBLE, false);
       normal_battery_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
       normal_battery_text_separator_img.setProperty(hmUI.prop.VISIBLE, false);

       normal_moon_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, false);
       normal_temperature_icon_img.setProperty(hmUI.prop.VISIBLE, false);
       normal_city_name_text.setProperty(hmUI.prop.VISIBLE, false);
       normal_temperature_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
       normal_temperature_current_separator_img.setProperty(hmUI.prop.VISIBLE, false);
       normal_weather_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, false);

       normal_digital_clock_img_time_second.setProperty(hmUI.prop.VISIBLE, true);
       normal_digital_clock_second_separator_img.setProperty(hmUI.prop.VISIBLE, true);
       normal_digital_clock_img_time_minute.setProperty(hmUI.prop.VISIBLE, true);
       normal_digital_clock_minute_separator_img.setProperty(hmUI.prop.VISIBLE, true);
       normal_digital_clock_img_time_hour.setProperty(hmUI.prop.VISIBLE, true);
       normal_digital_clock_hour_separator_img.setProperty(hmUI.prop.VISIBLE, true);
       normal_digital_clock_img_time_AmPm.setProperty(hmUI.prop.VISIBLE, true);

       normal_date_img_date_month_img.setProperty(hmUI.prop.VISIBLE, false);
       normal_date_img_date_week_img.setProperty(hmUI.prop.VISIBLE, false);
       normal_date_img_date_day.setProperty(hmUI.prop.VISIBLE, false);
       normal_date_day_separator_img.setProperty(hmUI.prop.VISIBLE, false);


        normal_stopwatch_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, true);
        normal_countdown_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, true);
 
        normal_sunrise_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, false);
        normal_temperature_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, false);


        normal_step_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, false);


        }

//////////////////////////////////////////////////////////////////////////////////////////////////

        //Weather
        function UpdateBackgroundFour(){

     normal_frame_animation_1.setProperty(hmUI.prop.VISIBLE, false);
       normal_distance_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
       normal_calorie_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
       normal_step_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
       normal_step_current_separator_img.setProperty(hmUI.prop.VISIBLE, false);

       normal_battery_icon_img.setProperty(hmUI.prop.VISIBLE, false);
       normal_battery_pointer_progress_img_pointer.setProperty(hmUI.prop.VISIBLE, false);
       normal_battery_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
       normal_battery_text_separator_img.setProperty(hmUI.prop.VISIBLE, false);

       normal_moon_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, true);
       normal_temperature_icon_img.setProperty(hmUI.prop.VISIBLE, true);
       normal_city_name_text.setProperty(hmUI.prop.VISIBLE, true);
       normal_temperature_current_text_img.setProperty(hmUI.prop.VISIBLE, true);
       normal_temperature_current_separator_img.setProperty(hmUI.prop.VISIBLE, true);
       normal_weather_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, true);

       normal_digital_clock_img_time_second.setProperty(hmUI.prop.VISIBLE, false);
       normal_digital_clock_second_separator_img.setProperty(hmUI.prop.VISIBLE, false);
       normal_digital_clock_img_time_minute.setProperty(hmUI.prop.VISIBLE, false);
       normal_digital_clock_minute_separator_img.setProperty(hmUI.prop.VISIBLE, false);
       normal_digital_clock_img_time_hour.setProperty(hmUI.prop.VISIBLE, false);
       normal_digital_clock_hour_separator_img.setProperty(hmUI.prop.VISIBLE, false);
       normal_digital_clock_img_time_AmPm.setProperty(hmUI.prop.VISIBLE, false);

       normal_date_img_date_month_img.setProperty(hmUI.prop.VISIBLE, false);
       normal_date_img_date_week_img.setProperty(hmUI.prop.VISIBLE, false);
       normal_date_img_date_day.setProperty(hmUI.prop.VISIBLE, false);
       normal_date_day_separator_img.setProperty(hmUI.prop.VISIBLE, false);



        normal_stopwatch_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, false);
        normal_countdown_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, false);
 
        normal_sunrise_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, true);
        normal_temperature_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, true);


        normal_step_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, false);

        }
//////////////////////////////////////////////////////////////////////////////////////////////////

        //Battery
        function UpdateBackgroundFive(){

     normal_frame_animation_1.setProperty(hmUI.prop.VISIBLE, false);
       normal_distance_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
       normal_calorie_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
       normal_step_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
       normal_step_current_separator_img.setProperty(hmUI.prop.VISIBLE, false);

       normal_battery_icon_img.setProperty(hmUI.prop.VISIBLE, true);
       normal_battery_pointer_progress_img_pointer.setProperty(hmUI.prop.VISIBLE, true);
       normal_battery_text_text_img.setProperty(hmUI.prop.VISIBLE, true);
       normal_battery_text_separator_img.setProperty(hmUI.prop.VISIBLE, true);

       normal_moon_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, false);
       normal_temperature_icon_img.setProperty(hmUI.prop.VISIBLE, false);
       normal_city_name_text.setProperty(hmUI.prop.VISIBLE, false);
       normal_temperature_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
       normal_temperature_current_separator_img.setProperty(hmUI.prop.VISIBLE, false);
       normal_weather_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, false);

       normal_digital_clock_img_time_second.setProperty(hmUI.prop.VISIBLE, false);
       normal_digital_clock_second_separator_img.setProperty(hmUI.prop.VISIBLE, false);
       normal_digital_clock_img_time_minute.setProperty(hmUI.prop.VISIBLE, false);
       normal_digital_clock_minute_separator_img.setProperty(hmUI.prop.VISIBLE, false);
       normal_digital_clock_img_time_hour.setProperty(hmUI.prop.VISIBLE, false);
       normal_digital_clock_hour_separator_img.setProperty(hmUI.prop.VISIBLE, false);
       normal_digital_clock_img_time_AmPm.setProperty(hmUI.prop.VISIBLE, false);

       normal_date_img_date_month_img.setProperty(hmUI.prop.VISIBLE, false);
       normal_date_img_date_week_img.setProperty(hmUI.prop.VISIBLE, false);
       normal_date_img_date_day.setProperty(hmUI.prop.VISIBLE, false);
       normal_date_day_separator_img.setProperty(hmUI.prop.VISIBLE, false);


        normal_stopwatch_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, false);
        normal_countdown_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, false);
 
        normal_sunrise_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, false);
        normal_temperature_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, false);


        normal_step_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, false);


        }
//////////////////////////////////////////////////////////////////////////////////////////
        // end user_functions.js

        
        
        let normal_background_bg_img = ''
        let normal_system_disconnect_img = ''
        let normal_system_clock_img = ''
        let normal_analog_clock_pro_second_pointer_img = ''
        let normal_timerUpdateSecSmooth = undefined;
        let normal_analog_clock_pro_second_cover_pointer_img = ''
        let normal_stress_icon_img = ''
        let normal_frame_animation_1 = ''
        let normal_distance_text_text_img = ''
        let normal_calorie_current_text_img = ''
        let normal_step_circle_scale = ''
        let normal_step_pointer_progress_img_pointer = ''
        let normal_step_current_text_img = ''
        let normal_step_current_separator_img = ''
        let normal_battery_icon_img = ''
        let normal_battery_pointer_progress_img_pointer = ''
        let normal_battery_text_text_img = ''
        let normal_battery_text_separator_img = ''
        let normal_moon_image_progress_img_level = ''
        let normal_temperature_icon_img = ''
        let normal_city_name_text = ''
        let normal_temperature_current_text_img = ''
        let normal_temperature_current_separator_img = ''
        let normal_weather_image_progress_img_level = ''
        let normal_digital_clock_img_time_second = ''
        let normal_digital_clock_second_separator_img = ''
        let normal_digital_clock_img_time_minute = ''
        let normal_digital_clock_minute_separator_img = ''
        let normal_digital_clock_img_time_hour = ''
        let normal_digital_clock_hour_separator_img = ''
        let normal_digital_clock_img_time_AmPm = ''
        let normal_date_img_date_month_img = ''
        let normal_date_img_date_week_img = ''
        let normal_date_img_date_day = ''
        let normal_date_day_separator_img = ''
        let normal_fat_burning_icon_img = ''
        let normal_heart_rate_text_text_img = ''
        let normal_heart_rate_text_separator_img = ''
        let normal_spo2_text_text_img = ''
        let normal_spo2_text_separator_img = ''
        let normal_analog_clock_time_pointer_hour = ''
        let normal_analog_clock_time_pointer_minute = ''
        let normal_analog_clock_time_pointer_second = ''
        let idle_background_bg_img = ''
        let idle_battery_text_text_img = ''
        let idle_system_disconnect_img = ''
        let idle_system_clock_img = ''
        let idle_digital_clock_img_time = ''
        let normal_stopwatch_jumpable_img_click = ''
        let normal_countdown_jumpable_img_click = ''
        let normal_alarm_jumpable_img_click = ''
        let normal_sunrise_jumpable_img_click = ''
        let normal_temperature_jumpable_img_click = ''
        let normal_spo2_jumpable_img_click = ''
        let normal_heart_jumpable_img_click = ''
        let normal_pai_jumpable_img_click = ''
        let normal_step_jumpable_img_click = ''
        let Button_1 = ''
        let Button_2 = ''
        let Button_3 = ''
        let Button_4 = ''
        let Button_5 = ''
        let timeSensor = ''


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            console.log('Watch_Face.ScreenNormal');
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 466,
              h: 466,
              src: 'main1.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 170,
              y: 216,
              src: 'System_BT_OFF.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 389,
              y: 288,
              src: 'System_Alarm.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            const deviceInfo = hmSetting.getDeviceInfo();
            if (!timeSensor) timeSensor = hmSensor.createSensor(hmSensor.id.TIME);
            // normal_analog_clock_pro_second_pointer_img = hmUI.createWidget(hmUI.widget.TIME_POINTER_PRO, {
              // src: 'circlesecond.png',
              // center_x: 233,
              // center_y: 233,
              // x: 127,
              // y: 127,
              // start_angle: 360,
              // end_angle: 0,
              // cover_path: 'Top_second.png',
              // cover_x: 0,
              // cover_y: 78,
              // type: hmUI.data_type.second,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });


            normal_analog_clock_pro_second_pointer_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: deviceInfo.width,
              h: deviceInfo.height,
              pos_x: 233 - 127,
              pos_y: 233 - 127,
              center_x: 233,
              center_y: 233,
              src: 'circlesecond.png',
              angle: 0,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            let screenType = hmSetting.getScreenType();
            normal_analog_clock_pro_second_cover_pointer_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 78,
              src: 'Top_second.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_analog_clock_pro_smooth_second = hmUI.createWidget(hmUI.widget.SMOOTH_SECOND, {
              // type: 2,
              // fps: 15,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });


            normal_stress_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 183,
              y: 228,
              src: 'CircleMid.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_frame_animation_1 = hmUI.createWidget(hmUI.widget.IMG_ANIM, {
              x: 247,
              y: 257,
              anim_path: "animation",
              anim_ext: "png",
              anim_prefix: "run",
              anim_fps: 15,
              anim_size: 12,
              repeat_count: 0,
              anim_repeat: true,
              anim_status:hmUI.anim_status.START,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_distance_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 250,
              y: 348,
              font_array: ["Cal_GR0.png","Cal_GR1.png","Cal_GR2.png","Cal_GR3.png","Cal_GR4.png","Cal_GR5.png","Cal_GR6.png","Cal_GR7.png","Cal_GR8.png","Cal_GR9.png"],
              padding: false,
              h_space: 3,
              unit_sc: 'Dis_KM.png',
              unit_tc: 'Dis_KM.png',
              unit_en: 'Dis_KM.png',
              imperial_unit_sc: 'Dis_Mi.png',
              imperial_unit_tc: 'Dis_Mi.png',
              imperial_unit_en: 'Dis_Mi.png',
              dot_image: 'Dis_dot.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.DISTANCE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_calorie_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 255,
              y: 378,
              font_array: ["Cal_GR0.png","Cal_GR1.png","Cal_GR2.png","Cal_GR3.png","Cal_GR4.png","Cal_GR5.png","Cal_GR6.png","Cal_GR7.png","Cal_GR8.png","Cal_GR9.png"],
              padding: false,
              h_space: 2,
              unit_sc: 'cal_k.png',
              unit_tc: 'cal_k.png',
              unit_en: 'cal_k.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_step_circle_scale = hmUI.createWidget(hmUI.widget.Circle_Scale, {
              // center_x: 233,
              // center_y: 233,
              // start_angle: 243,
              // end_angle: 417,
              // radius: 103,
              // line_width: 8,
              // line_cap: Rounded,
              // color: 0xFFF3462E,
              // mirror: False,
              // inversion: False,
              // type: hmUI.data_type.STEP,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_step_circle_scale = hmUI.createWidget(hmUI.widget.ARC_PROGRESS, {
              center_x: 233,
              center_y: 233,
              start_angle: 243,
              end_angle: 417,
              radius: 99,
              line_width: 8,
              corner_flag: 0,
              color: 0xFFF3462E,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            
            const step = hmSensor.createSensor(hmSensor.id.STEP);
            step.addEventListener(hmSensor.event.CHANGE, function() {
              scale_call();
            });

            normal_step_pointer_progress_img_pointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
              src: 'step_pointer.png',
              center_x: 233,
              center_y: 233,
              x: 6,
              y: 105,
              start_angle: 243,
              end_angle: 414,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 218,
              y: 290,
              font_array: ["Step0.png","Step1.png","Step2.png","Step3.png","Step4.png","Step5.png","Step6.png","Step7.png","Step8.png","Step9.png"],
              padding: false,
              h_space: 1,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 169,
              y: 267,
              src: 'icon_steps.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 212,
              y: 251,
              src: 'Batt_area.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_pointer_progress_img_pointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
              src: 'pointerbatt.png',
              center_x: 292,
              center_y: 326,
              x: 24,
              y: 66,
              start_angle: 225,
              end_angle: 498,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 268,
              y: 382,
              font_array: ["Cal_GR0.png","Cal_GR1.png","Cal_GR2.png","Cal_GR3.png","Cal_GR4.png","Cal_GR5.png","Cal_GR6.png","Cal_GR7.png","Cal_GR8.png","Cal_GR9.png"],
              padding: false,
              h_space: 2,
              unit_sc: 'Batt_unit.png',
              unit_tc: 'Batt_unit.png',
              unit_en: 'Batt_unit.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 169,
              y: 267,
              src: 'icon_battery.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_moon_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 248,
              y: 270,
              image_array: ["Moon_01.png","Moon_02.png","Moon_03.png","Moon_04.png","Moon_05.png","Moon_06.png","Moon_07.png","Moon_08.png","Moon_09.png","Moon_10.png","Moon_11.png","Moon_12.png","Moon_13.png","Moon_14.png","Moon_15.png","Moon_16.png","Moon_17.png","Moon_18.png","Moon_19.png","Moon_20.png","Moon_21.png","Moon_22.png","Moon_23.png","Moon_24.png","Moon_25.png","Moon_26.png","Moon_27.png","Moon_28.png","Moon_29.png","Moon_30.png"],
              image_length: 30,
              type: hmUI.data_type.MOON,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 213,
              y: 284,
              src: 'WeatherView.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
              const weatherSensor = hmSensor.createSensor(hmSensor.id.WEATHER);

            normal_city_name_text = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 235,
              y: 362,
              w: 108,
              h: 31,
              text_size: 23,
              char_space: 0,
              line_space: 0,
              color: 0xFFFFFFFF,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.NONE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 271,
              y: 296,
              font_array: ["Cal_GR0.png","Cal_GR1.png","Cal_GR2.png","Cal_GR3.png","Cal_GR4.png","Cal_GR5.png","Cal_GR6.png","Cal_GR7.png","Cal_GR8.png","Cal_GR9.png"],
              padding: false,
              h_space: 2,
              unit_sc: 'Weather_Symbo1.png',
              unit_tc: 'Weather_Symbo1.png',
              unit_en: 'Weather_Symbo1.png',
              negative_image: 'Weather_Symbo2.png',
              invalid_image: 'Weather_Symbo2.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 169,
              y: 267,
              src: 'icon_weather.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 311,
              y: 302,
              image_array: ["Weather_image_01.png","Weather_image_02.png","Weather_image_03.png","Weather_image_04.png","Weather_image_05.png","Weather_image_06.png","Weather_image_07.png","Weather_image_08.png","Weather_image_09.png","Weather_image_10.png","Weather_image_11.png","Weather_image_12.png","Weather_image_13.png","Weather_image_14.png","Weather_image_15.png","Weather_image_16.png","Weather_image_17.png","Weather_image_18.png","Weather_image_19.png","Weather_image_20.png","Weather_image_21.png","Weather_image_22.png","Weather_image_23.png","Weather_image_24.png","Weather_image_25.png","Weather_image_26.png","Weather_image_27.png","Weather_image_28.png","Weather_image_29.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time_second = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              second_startX: 311,
              second_startY: 303,
              second_array: ["Second_Font_0.png","Second_Font_1.png","Second_Font_2.png","Second_Font_3.png","Second_Font_4.png","Second_Font_5.png","Second_Font_6.png","Second_Font_7.png","Second_Font_8.png","Second_Font_9.png"],
              second_zero: 1,
              second_space: 3,
              second_angle: 0,
              second_follow: 0,
              second_align: hmUI.align.LEFT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_second_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 315,
              y: 351,
              src: 'Clock_24H.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time_minute = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              minute_startX: 236,
              minute_startY: 338,
              minute_array: ["Step0.png","Step1.png","Step2.png","Step3.png","Step4.png","Step5.png","Step6.png","Step7.png","Step8.png","Step9.png"],
              minute_zero: 1,
              minute_space: 4,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_minute_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 225,
              y: 329,
              src: 'DigitalBar.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time_hour = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 236,
              hour_startY: 275,
              hour_array: ["Step0.png","Step1.png","Step2.png","Step3.png","Step4.png","Step5.png","Step6.png","Step7.png","Step8.png","Step9.png"],
              hour_zero: 1,
              hour_space: 4,
              hour_angle: 0,
              hour_align: hmUI.align.LEFT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_hour_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 169,
              y: 267,
              src: 'icon_digitaltime.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time_AmPm = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              am_x: 314,
              am_y: 350,
              am_sc_path: 'Clock_AM.png',
              am_en_path: 'Clock_AM.png',
              pm_x: 314,
              pm_y: 350,
              pm_sc_path: 'Clock_PM.png',
              pm_en_path: 'Clock_PM.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_month_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 235,
              month_startY: 370,
              month_sc_array: ["Month_01.png","Month_02.png","Month_03.png","Month_04.png","Month_05.png","Month_06.png","Month_07.png","Month_08.png","Month_09.png","Month_10.png","Month_11.png","Month_12.png"],
              month_tc_array: ["Month_01.png","Month_02.png","Month_03.png","Month_04.png","Month_05.png","Month_06.png","Month_07.png","Month_08.png","Month_09.png","Month_10.png","Month_11.png","Month_12.png"],
              month_en_array: ["Month_01.png","Month_02.png","Month_03.png","Month_04.png","Month_05.png","Month_06.png","Month_07.png","Month_08.png","Month_09.png","Month_10.png","Month_11.png","Month_12.png"],
              month_is_character: true ,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 221,
              y: 334,
              week_en: ["Week_1.png","Week_2.png","Week_3.png","Week_4.png","Week_5.png","Week_6.png","Week_7.png"],
              week_tc: ["Week_1.png","Week_2.png","Week_3.png","Week_4.png","Week_5.png","Week_6.png","Week_7.png"],
              week_sc: ["Week_1.png","Week_2.png","Week_3.png","Week_4.png","Week_5.png","Week_6.png","Week_7.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 258,
              day_startY: 272,
              day_sc_array: ["Step0.png","Step1.png","Step2.png","Step3.png","Step4.png","Step5.png","Step6.png","Step7.png","Step8.png","Step9.png"],
              day_tc_array: ["Step0.png","Step1.png","Step2.png","Step3.png","Step4.png","Step5.png","Step6.png","Step7.png","Step8.png","Step9.png"],
              day_en_array: ["Step0.png","Step1.png","Step2.png","Step3.png","Step4.png","Step5.png","Step6.png","Step7.png","Step8.png","Step9.png"],
              day_zero: 1,
              day_space: 5,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_day_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 169,
              y: 267,
              src: 'icon_date.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_fat_burning_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 284,
              y: 161,
              src: 'circletop.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 327,
              y: 224,
              font_array: ["Second_Font_0.png","Second_Font_1.png","Second_Font_2.png","Second_Font_3.png","Second_Font_4.png","Second_Font_5.png","Second_Font_6.png","Second_Font_7.png","Second_Font_8.png","Second_Font_9.png"],
              padding: false,
              h_space: 2,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 349,
              y: 189,
              src: 'icon_heart.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_spo2_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 327,
              y: 226,
              font_array: ["Second_Font_0.png","Second_Font_1.png","Second_Font_2.png","Second_Font_3.png","Second_Font_4.png","Second_Font_5.png","Second_Font_6.png","Second_Font_7.png","Second_Font_8.png","Second_Font_9.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'Batt_unit.png',
              unit_tc: 'Batt_unit.png',
              unit_en: 'Batt_unit.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.SPO2,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_spo2_text_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 340,
              y: 197,
              src: 'icon_SpO2.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_hour = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              hour_path: 'Hand_H1.png',
              hour_centerX: 233,
              hour_centerY: 233,
              hour_posX: 233,
              hour_posY: 238,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_minute = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              minute_path: 'Hand_M1.png',
              minute_centerX: 233,
              minute_centerY: 233,
              minute_posX: 233,
              minute_posY: 238,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_second = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              second_path: 'Hand_S1.png',
              second_centerX: 233,
              second_centerY: 233,
              second_posX: 233,
              second_posY: 238,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            console.log('Watch_Face.ScreenAOD');
            idle_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 466,
              h: 466,
              src: 'aod_bg.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 391,
              y: 219,
              font_array: ["dark_00.png","dark_01.png","dark_02.png","dark_03.png","dark_04.png","dark_05.png","dark_06.png","dark_07.png","dark_08.png","dark_09.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'num_13.png',
              unit_tc: 'num_13.png',
              unit_en: 'num_13.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 170,
              y: 216,
              src: 'System_BT_OFF.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 212,
              y: 225,
              src: 'System_Alarm.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 227,
              hour_startY: 208,
              hour_array: ["0010.png","0011.png","0012.png","0013.png","0014.png","0015.png","0016.png","0017.png","0018.png","0019.png"],
              hour_zero: 1,
              hour_space: 3,
              hour_angle: 0,
              hour_unit_sc: 'min_sep.png',
              hour_unit_tc: 'min_sep.png',
              hour_unit_en: 'min_sep.png',
              hour_align: hmUI.align.CENTER_H,

              minute_startX: 0,
              minute_startY: 0,
              minute_array: ["0010.png","0011.png","0012.png","0013.png","0014.png","0015.png","0016.png","0017.png","0018.png","0019.png"],
              minute_zero: 1,
              minute_space: 3,
              minute_angle: 0,
              minute_follow: 1,
              minute_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_AOD,
            });
            console.log('Watch_Face.Shortcuts');

            normal_stopwatch_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 311,
              y: 300,
              w: 56,
              h: 51,
              type: hmUI.data_type.STOP_WATCH,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_countdown_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 236,
              y: 344,
              w: 60,
              h: 60,
              type: hmUI.data_type.COUNT_DOWN,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_alarm_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 378,
              y: 282,
              w: 59,
              h: 43,
              type: hmUI.data_type.ALARM_CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sunrise_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 235,
              y: 251,
              w: 60,
              h: 60,
              type: hmUI.data_type.SUN_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 313,
              y: 302,
              w: 55,
              h: 55,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_spo2_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 328,
              y: 192,
              w: 71,
              h: 75,
              type: hmUI.data_type.SPO2,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 331,
              y: 191,
              w: 67,
              h: 76,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_pai_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 234,
              y: 347,
              w: 113,
              h: 54,
              type: hmUI.data_type.PAI_WEEKLY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 229,
              y: 287,
              w: 121,
              h: 54,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            console.log('Watch_Face.Buttons');
            Button_1 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 196,
              y: 4,
              w: 75,
              h: 60,
              text: '',
              color: 0xFFFF8C00,
              text_size: 26,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'ScheduleCalScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_2 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 192,
              y: 153,
              w: 74,
              h: 37,
              text: '',
              color: 0xFFFF8C00,
              text_size: 26,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'Sleep_HomeScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_3 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 202,
              y: 405,
              w: 60,
              h: 60,
              text: '',
              color: 0xFFFF8C00,
              text_size: 26,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                // Date , activity , Time , Weather , Battery select
                click_info1()
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_4 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 410,
              y: 205,
              w: 60,
              h: 60,
              text: '',
              color: 0xFFFF8C00,
              text_size: 26,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                // Heart , O2
                click_info2()
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_5 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 89,
              y: 318,
              w: 60,
              h: 60,
              text: '',
              color: 0xFFFF8C00,
              text_size: 26,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                // color
                click_elemente5()
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            console.log('user_script_end.js');
            // start user_script_end.js
//////////////////////////
if (cc==0) {


       normal_frame_animation_1.setProperty(hmUI.prop.VISIBLE, false);
       normal_distance_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
       normal_calorie_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
       normal_step_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
       normal_step_current_separator_img.setProperty(hmUI.prop.VISIBLE, false);

       normal_battery_icon_img.setProperty(hmUI.prop.VISIBLE, false);
       normal_battery_pointer_progress_img_pointer.setProperty(hmUI.prop.VISIBLE, false);
       normal_battery_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
       normal_battery_text_separator_img.setProperty(hmUI.prop.VISIBLE, false);

       normal_moon_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, false);
       normal_temperature_icon_img.setProperty(hmUI.prop.VISIBLE, false);
       normal_city_name_text.setProperty(hmUI.prop.VISIBLE, false);
       normal_temperature_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
       normal_temperature_current_separator_img.setProperty(hmUI.prop.VISIBLE, false);
       normal_weather_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, false);

       normal_digital_clock_img_time_second.setProperty(hmUI.prop.VISIBLE, false);
       normal_digital_clock_second_separator_img.setProperty(hmUI.prop.VISIBLE, false);
       normal_digital_clock_img_time_minute.setProperty(hmUI.prop.VISIBLE, false);
       normal_digital_clock_minute_separator_img.setProperty(hmUI.prop.VISIBLE, false);
       normal_digital_clock_img_time_hour.setProperty(hmUI.prop.VISIBLE, false);
       normal_digital_clock_hour_separator_img.setProperty(hmUI.prop.VISIBLE, false);
       normal_digital_clock_img_time_AmPm.setProperty(hmUI.prop.VISIBLE, false);

       normal_date_img_date_month_img.setProperty(hmUI.prop.VISIBLE, true);
       normal_date_img_date_week_img.setProperty(hmUI.prop.VISIBLE, true);
       normal_date_img_date_day.setProperty(hmUI.prop.VISIBLE, true);
       normal_date_day_separator_img.setProperty(hmUI.prop.VISIBLE, true);


        normal_stopwatch_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, false);
        normal_countdown_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, false);
 
        normal_sunrise_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, false);
        normal_temperature_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, false);


        normal_pai_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, false);
        normal_step_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, false);

        normal_heart_rate_text_text_img.setProperty(hmUI.prop.VISIBLE, true);
        normal_heart_rate_text_separator_img.setProperty(hmUI.prop.VISIBLE, true);
        normal_spo2_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
        normal_spo2_text_separator_img.setProperty(hmUI.prop.VISIBLE, false);


        normal_spo2_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, false);
        normal_heart_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, true);

cc =1
}
            // end user_script_end.js

            function time_update(updateHour = false, updateMinute = false) {
              console.log('time_update()');
              let hour = timeSensor.hour;
              let minute = timeSensor.minute;
              let second = timeSensor.second;

              let normal_fullAngle_second = -360;
              let normal_angle_second = 360 + normal_fullAngle_second*(second + (timeSensor.utc % 1000)/1000)/60;
              if (normal_analog_clock_pro_second_pointer_img) normal_analog_clock_pro_second_pointer_img.setProperty(hmUI.prop.ANGLE, normal_angle_second);

            };

            function scale_call() {
              console.log('scale_call()');

                console.log('update scales STEP');
                
                let valueStep = step.current;
                let targetStep = step.target;
                let progressStep = valueStep/targetStep;
                if (progressStep > 1) progressStep = 1;
                let progress_cs_normal_step = progressStep;

                if (screenType != hmSetting.screen_type.AOD) {

                  // normal_step_circle_scale_circle_scale
                  let level = Math.round(progress_cs_normal_step * 100);
                  if (normal_step_circle_scale) {
                    normal_step_circle_scale.setProperty(hmUI.prop.MORE, {                      
                      center_x: 233,
                      center_y: 233,
                      start_angle: 243,
                      end_angle: 417,
                      radius: 99,
                      line_width: 8,
                      corner_flag: 0,
                      color: 0xFFF3462E,
                      show_level: hmUI.show_level.ONLY_NORMAL,
                      level: level,
                    });
                  };
                };

              console.log('Weather city name');
              let weatherData = weatherSensor.getForecastWeather();
              normal_city_name_text.setProperty(hmUI.prop.TEXT, weatherData.cityName);

            };

            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                console.log('resume_call()');
                scale_call();
                time_update(true, true);
                if (screenType == hmSetting.screen_type.WATCHFACE) {
                  if (!normal_timerUpdateSecSmooth) {
                    let animDelay = 0;
                    let animRepeat = 1000/15;
                    normal_timerUpdateSecSmooth = timer.createTimer(animDelay, animRepeat, (function (option) {
                      time_update(false, false);
                    }));  // end timer 
                  };  // end timer check
                };  // end screenType

                normal_frame_animation_1.setProperty(hmUI.prop.ANIM_STATUS,hmUI.anim_status.START);

              }),
              pause_call: (function () {
                console.log('pause_call()');
                if (normal_timerUpdateSecSmooth) {
                  timer.stopTimer(normal_timerUpdateSecSmooth);
                  normal_timerUpdateSecSmooth = undefined;
                }
                normal_frame_animation_1.setProperty(hmUI.prop.ANIM_STATUS,hmUI.anim_status.STOP);

              }),
            });

                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}