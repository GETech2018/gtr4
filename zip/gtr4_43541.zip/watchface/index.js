﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        //const logger = Logger.getLogger('watchface_SashaCX75');
        const logger = DeviceRuntimeCore.HmLogger.getLogger('watchface_SashaCX75')
        //end of ignored block

        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_system_dnd_img = ''
        let normal_system_disconnect_img = ''
        let normal_system_clock_img = ''
        let normal_humidity_current_text_font = ''
        let normal_sun_high_text_font = ''
        let normal_sun_low_text_font = ''
        let normal_wind_pointer_progress_img_pointer = ''
        let normal_wind_current_text_font = ''
        let normal_heart_rate_icon_img = ''
        let normal_heart_rate_text_font = ''
        let normal_step_icon_img = ''
        let normal_step_pointer_progress_img_pointer = ''
        let normal_step_current_text_font = ''
        let normal_city_name_text = ''
        let normal_weather_image_progress_img_level = ''
        let normal_temperature_high_text_font = ''
        let normal_temperature_low_text_font = ''
        let normal_temperature_current_text_font = ''
        let normal_day_month_year_font = ''
        let normal_timerTimeUpdate = undefined;
        let normal_date_img_date_week_img = ''
        let normal_digital_clock_img_time = ''
        let idle_day_month_year_font = ''
        let idle_timerTimeUpdate = undefined;
        let idle_date_img_date_week_img = ''
        let idle_digital_clock_img_time = ''
        let Button_1 = ''
        let Button_2 = ''
        let Button_3 = ''
        let Button_4 = ''
        let Button_5 = ''
        let Button_6 = ''
        let Button_7 = ''
        let Button_8 = ''
        let Button_9 = ''
        let Button_10 = ''
        let Button_11 = ''
        let Button_12 = ''
        let timeSensor = '';


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            // FontName: wfs_archangelsk_368d3316_09c0_4faf_b0b5_1e0cce13d111.ttf; FontSize: 31
            hmUI.createWidget(hmUI.widget.TEXT, {
              x: 464,
              y: 464,
              w: 477,
              h: 39,
              text_size: 31,
              char_space: 0,
              line_space: 0,
              font: 'fonts/wfs_archangelsk_368d3316_09c0_4faf_b0b5_1e0cce13d111.ttf',
              color: 0xFFFFFFFF,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              text: "0123456789 _-.,:;`'%°\\/",
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // FontName: wfs_archangelsk_368d3316_09c0_4faf_b0b5_1e0cce13d111.ttf; FontSize: 43
            hmUI.createWidget(hmUI.widget.TEXT, {
              x: 464,
              y: 464,
              w: 655,
              h: 54,
              text_size: 43,
              char_space: 0,
              line_space: 0,
              font: 'fonts/wfs_archangelsk_368d3316_09c0_4faf_b0b5_1e0cce13d111.ttf',
              color: 0xFFFFFEFD,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              text: "0123456789 _-.,:;`'%°\\/",
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // FontName: wfs_archangelsk_368d3316_09c0_4faf_b0b5_1e0cce13d111.ttf; FontSize: 19; Cache: full
            hmUI.createWidget(hmUI.widget.TEXT, {
              x: 464,
              y: 464,
              w: 22,
              h: 22,
              text_size: 19,
              char_space: 0,
              line_space: 0,
              font: 'fonts/wfs_archangelsk_368d3316_09c0_4faf_b0b5_1e0cce13d111.ttf',
              color: 0xFFFFFAF2,
              align_h: hmUI.align.LEFT,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.NONE,
              text: "0123456789 ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz АБВГДЕЁЖЗИЙКЛМНОПРСТУФХЦЧШЩЪЫЬЭЮЯабвгдеёжзийклмнопрстуфхцчшщъыьэюя  ҐЄІЇґєії _-.,:;`'%°\\/",
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // FontName: wfs_archangelsk_368d3316_09c0_4faf_b0b5_1e0cce13d111.ttf; FontSize: 35
            hmUI.createWidget(hmUI.widget.TEXT, {
              x: 464,
              y: 464,
              w: 518,
              h: 43,
              text_size: 35,
              char_space: 0,
              line_space: 0,
              font: 'fonts/wfs_archangelsk_368d3316_09c0_4faf_b0b5_1e0cce13d111.ttf',
              color: 0xFFFF0000,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              text: "0123456789 _-.,:;`'%°\\/",
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // FontName: wfs_archangelsk_368d3316_09c0_4faf_b0b5_1e0cce13d111.ttf; FontSize: 33
            hmUI.createWidget(hmUI.widget.TEXT, {
              x: 464,
              y: 464,
              w: 499,
              h: 42,
              text_size: 33,
              char_space: 0,
              line_space: 0,
              font: 'fonts/wfs_archangelsk_368d3316_09c0_4faf_b0b5_1e0cce13d111.ttf',
              color: 0xFF0080FF,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              text: "0123456789 _-.,:;`'%°\\/",
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            console.log('Watch_Face.ScreenNormal');
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 466,
              h: 466,
              src: 'bg_1.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_dnd_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 279,
              y: 427,
              src: '0075.png',
              type: hmUI.system_status.DISTURB,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 250,
              y: 427,
              src: '0074.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 225,
              y: 427,
              src: '0076.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_humidity_current_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 184,
              y: 289,
              w: 146,
              h: 29,
              text_size: 31,
              char_space: 0,
              line_space: 0,
              font: 'fonts/wfs_archangelsk_368d3316_09c0_4faf_b0b5_1e0cce13d111.ttf',
              color: 0xFFFFFFFF,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              type: hmUI.data_type.HUMIDITY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sun_high_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 303,
              y: 144,
              w: 146,
              h: 29,
              text_size: 31,
              char_space: 0,
              line_space: 0,
              font: 'fonts/wfs_archangelsk_368d3316_09c0_4faf_b0b5_1e0cce13d111.ttf',
              color: 0xFFFFFFFF,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              type: hmUI.data_type.SUN_RISE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sun_low_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 334,
              y: 289,
              w: 146,
              h: 29,
              text_size: 31,
              char_space: 0,
              line_space: 0,
              font: 'fonts/wfs_archangelsk_368d3316_09c0_4faf_b0b5_1e0cce13d111.ttf',
              color: 0xFFFFFFFF,
              align_h: hmUI.align.LEFT,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              type: hmUI.data_type.SUN_SET,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_wind_pointer_progress_img_pointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
              src: 'sv_ic.png',
              center_x: 394,
              center_y: 109,
              x: 23,
              y: 23,
              start_angle: 0,
              end_angle: 360,
              invalid_visible: false,
              cover_path: 'sv_ic_p.png',
              cover_x: 370,
              cover_y: 85,
              type: hmUI.data_type.WIND,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_wind_current_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 45,
              y: 289,
              w: 146,
              h: 29,
              text_size: 31,
              char_space: 0,
              line_space: 0,
              font: 'fonts/wfs_archangelsk_368d3316_09c0_4faf_b0b5_1e0cce13d111.ttf',
              color: 0xFFFFFFFF,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              type: hmUI.data_type.WIND,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 207,
              y: 22,
              src: 'puls_icon.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 227,
              y: 30,
              w: 149,
              h: 37,
              text_size: 43,
              char_space: 0,
              line_space: 0,
              font: 'fonts/wfs_archangelsk_368d3316_09c0_4faf_b0b5_1e0cce13d111.ttf',
              color: 0xFFFFFEFD,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 201,
              y: 77,
              src: 'step_icon.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_pointer_progress_img_pointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
              src: 'point.png',
              center_x: 233,
              center_y: 233,
              x: 13,
              y: 223,
              start_angle: 15,
              end_angle: 56,
              invalid_visible: false,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 237,
              y: 89,
              w: 146,
              h: 35,
              text_size: 43,
              char_space: 0,
              line_space: 0,
              font: 'fonts/wfs_archangelsk_368d3316_09c0_4faf_b0b5_1e0cce13d111.ttf',
              color: 0xFFFFFFFF,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
              const weatherSensor = hmSensor.createSensor(hmSensor.id.WEATHER);

            normal_city_name_text = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 76,
              y: 151,
              w: 146,
              h: 29,
              text_size: 19,
              char_space: 0,
              line_space: 0,
              font: 'fonts/wfs_archangelsk_368d3316_09c0_4faf_b0b5_1e0cce13d111.ttf',
              color: 0xFFFFFAF2,
              align_h: hmUI.align.LEFT,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.NONE,
              // unit_type: 1,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 28,
              y: 203,
              image_array: ["w_0.png","w_1.png","w_2.png","w_3.png","w_4.png","w_5.png","w_6.png","w_7.png","w_8.png","w_9.png","w_10.png","w_11.png","w_12.png","w_13.png","w_14.png","w_15.png","w_16.png","w_17.png","w_18.png","w_19.png","w_20.png","w_21.png","w_22.png","w_23.png","w_24.png","w_25.png","w_26.png","w_27.png","w_28.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_high_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 130,
              y: 187,
              w: 146,
              h: 29,
              text_size: 35,
              char_space: 0,
              line_space: 0,
              font: 'fonts/wfs_archangelsk_368d3316_09c0_4faf_b0b5_1e0cce13d111.ttf',
              color: 0xFFFF0000,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.TOP,
              unit_type: 1,
              text_style: hmUI.text_style.ELLIPSIS,
              type: hmUI.data_type.WEATHER_HIGH,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_low_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 127,
              y: 239,
              w: 146,
              h: 29,
              text_size: 33,
              char_space: 0,
              line_space: 0,
              font: 'fonts/wfs_archangelsk_368d3316_09c0_4faf_b0b5_1e0cce13d111.ttf',
              color: 0xFF0080FF,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.TOP,
              unit_type: 1,
              text_style: hmUI.text_style.ELLIPSIS,
              type: hmUI.data_type.WEATHER_LOW,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 60,
              y: 214,
              w: 146,
              h: 29,
              text_size: 35,
              char_space: 0,
              line_space: 0,
              font: 'fonts/wfs_archangelsk_368d3316_09c0_4faf_b0b5_1e0cce13d111.ttf',
              color: 0xFFFFFDFB,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.TOP,
              unit_type: 1,
              text_style: hmUI.text_style.ELLIPSIS,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            if (!timeSensor) timeSensor = hmSensor.createSensor(hmSensor.id.TIME);
            let screenType = hmSetting.getScreenType();
            normal_day_month_year_font = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 185,
              y: 339,
              w: 229,
              h: 37,
              text_size: 43,
              char_space: 0,
              line_space: 0,
              font: 'fonts/wfs_archangelsk_368d3316_09c0_4faf_b0b5_1e0cce13d111.ttf',
              color: 0xFFFFFBF4,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              // padding: true,
              // unit_string: .,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 256,
              y: 380,
              week_en: ["dn_1.png","dn_2.png","dn_3.png","dn_4.png","dn_5.png","dn_6.png","dn_7.png"],
              week_tc: ["dn_1.png","dn_2.png","dn_3.png","dn_4.png","dn_5.png","dn_6.png","dn_7.png"],
              week_sc: ["dn_1.png","dn_2.png","dn_3.png","dn_4.png","dn_5.png","dn_6.png","dn_7.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 238,
              hour_startY: 183,
              hour_array: ["bnum_1.png","bnum_2.png","bnum_3.png","bnum_4.png","bnum_5.png","bnum_6.png","bnum_7.png","bnum_8.png","bnum_9.png","bnum_10.png"],
              hour_zero: 1,
              hour_space: 2,
              hour_angle: 0,
              hour_unit_sc: 'bnum_11.png',
              hour_unit_tc: 'bnum_11.png',
              hour_unit_en: 'bnum_11.png',
              hour_align: hmUI.align.CENTER_H,

              minute_startX: 352,
              minute_startY: 184,
              minute_array: ["bnum_1.png","bnum_2.png","bnum_3.png","bnum_4.png","bnum_5.png","bnum_6.png","bnum_7.png","bnum_8.png","bnum_9.png","bnum_10.png"],
              minute_zero: 1,
              minute_space: 2,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.CENTER_H,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            console.log('Watch_Face.ScreenAOD');

            idle_day_month_year_font = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 185,
              y: 339,
              w: 229,
              h: 37,
              text_size: 43,
              char_space: 0,
              line_space: 0,
              font: 'fonts/wfs_archangelsk_368d3316_09c0_4faf_b0b5_1e0cce13d111.ttf',
              color: 0xFFFFFBF4,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              // padding: true,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 256,
              y: 380,
              week_en: ["dn_1.png","dn_2.png","dn_3.png","dn_4.png","dn_5.png","dn_6.png","dn_7.png"],
              week_tc: ["dn_1.png","dn_2.png","dn_3.png","dn_4.png","dn_5.png","dn_6.png","dn_7.png"],
              week_sc: ["dn_1.png","dn_2.png","dn_3.png","dn_4.png","dn_5.png","dn_6.png","dn_7.png"],
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 238,
              hour_startY: 183,
              hour_array: ["bnum_1.png","bnum_2.png","bnum_3.png","bnum_4.png","bnum_5.png","bnum_6.png","bnum_7.png","bnum_8.png","bnum_9.png","bnum_10.png"],
              hour_zero: 1,
              hour_space: 2,
              hour_angle: 0,
              hour_unit_sc: 'bnum_11.png',
              hour_unit_tc: 'bnum_11.png',
              hour_unit_en: 'bnum_11.png',
              hour_align: hmUI.align.CENTER_H,

              minute_startX: 355,
              minute_startY: 184,
              minute_array: ["bnum_1.png","bnum_2.png","bnum_3.png","bnum_4.png","bnum_5.png","bnum_6.png","bnum_7.png","bnum_8.png","bnum_9.png","bnum_10.png"],
              minute_zero: 1,
              minute_space: 2,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.CENTER_H,

              show_level: hmUI.show_level.ONLY_AOD,
            });

            console.log('Watch_Face.Buttons');
            Button_1 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 28,
              y: 188,
              w: 59,
              h: 75,
              text: '',
              color: 0xFFFF8C00,
              text_size: 24,
              press_src: 'null.png',
              normal_src: 'null.png',
              click_func: (button_widget) => {
                hmApp.startApp({ appid: 1051195, url: 'page/index', params: { from_wf: true} });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_2 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 105,
              y: 187,
              w: 124,
              h: 75,
              text: '',
              color: 0xFFFF8C00,
              text_size: 24,
              press_src: 'null.png',
              normal_src: 'null.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'WeatherScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_3 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 201,
              y: 82,
              w: 155,
              h: 57,
              text: '',
              color: 0xFFFF8C00,
              text_size: 24,
              press_src: 'null.png',
              normal_src: 'null.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'activityAppScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_4 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 198,
              y: 21,
              w: 155,
              h: 57,
              text: '',
              color: 0xFFFF8C00,
              text_size: 24,
              press_src: 'null.png',
              normal_src: 'null.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'heart_app_Screen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_5 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 292,
              y: 142,
              w: 155,
              h: 34,
              text: '',
              color: 0xFFFF8C00,
              text_size: 24,
              press_src: 'null.png',
              normal_src: 'null.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'TideScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_6 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 289,
              y: 286,
              w: 155,
              h: 34,
              text: '',
              color: 0xFFFF8C00,
              text_size: 24,
              press_src: 'null.png',
              normal_src: 'null.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'TideScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_7 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 211,
              y: 339,
              w: 155,
              h: 78,
              text: '',
              color: 0xFFFF8C00,
              text_size: 24,
              press_src: 'null.png',
              normal_src: 'null.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'ScheduleCalScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_8 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 84,
              y: 55,
              w: 101,
              h: 78,
              text: '',
              color: 0xFFFF8C00,
              text_size: 24,
              press_src: 'null.png',
              normal_src: 'null.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'PowerSaveHintScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_9 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 89,
              y: 332,
              w: 101,
              h: 78,
              text: '',
              color: 0xFFFF8C00,
              text_size: 24,
              press_src: 'null.png',
              normal_src: 'null.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'activityWeekShowScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_10 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 51,
              y: 291,
              w: 198,
              h: 34,
              text: '',
              color: 0xFFFF8C00,
              text_size: 24,
              press_src: 'null.png',
              normal_src: 'null.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'spo_HomeScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_11 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 253,
              y: 185,
              w: 88,
              h: 91,
              text: '',
              color: 0xFFFF8C00,
              text_size: 24,
              press_src: 'null.png',
              normal_src: 'null.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'StopWatchScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_12 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 357,
              y: 184,
              w: 88,
              h: 91,
              text: '',
              color: 0xFFFF8C00,
              text_size: 24,
              press_src: 'null.png',
              normal_src: 'null.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'CountdownAppScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            //#region time_update
            function time_update(updateHour = false, updateMinute = false) {
              console.log('time_update()');
              let hour = timeSensor.hour;
              let minute = timeSensor.minute;
              let second = timeSensor.second;
              let format_hour = timeSensor.format_hour;

              console.log('day/month/year font');
              if (updateHour) {
                let normal_DayStr = timeSensor.day.toString();
                let normal_MonthStr = timeSensor.month.toString();
                let normal_YearStr = (timeSensor.year % 100).toString();
                normal_DayStr = normal_DayStr.padStart(2, '0');
                normal_MonthStr = normal_MonthStr.padStart(2, '0');
                let normal_DayMonthYearStr = '--';
                const dateFormat = hmSetting.getDateFormat();
                if (dateFormat == 0) {
                  normal_DayMonthYearStr = normal_YearStr + '.' + normal_MonthStr + '.' + normal_DayStr;
                }
                if (dateFormat == 1) {
                  normal_DayMonthYearStr = normal_DayStr + '.' + normal_MonthStr + '.' + normal_YearStr;
                }
                if (dateFormat == 2) {
                  normal_DayMonthYearStr = normal_MonthStr + '.' + normal_DayStr + '.' + normal_YearStr;
                }
                normal_day_month_year_font.setProperty(hmUI.prop.TEXT, normal_DayMonthYearStr );
              };

              console.log('day/month/year font');
              if (updateHour) {
                let idle_DayStr = timeSensor.day.toString();
                let idle_MonthStr = timeSensor.month.toString();
                let idle_YearStr = (timeSensor.year % 100).toString();
                idle_DayStr = idle_DayStr.padStart(2, '0');
                idle_MonthStr = idle_MonthStr.padStart(2, '0');
                let idle_DayMonthYearStr = '--';
                const dateFormat = hmSetting.getDateFormat();
                if (dateFormat == 0) {
                  idle_DayMonthYearStr = idle_YearStr + '/' + idle_MonthStr + '/' + idle_DayStr;
                }
                if (dateFormat == 1) {
                  idle_DayMonthYearStr = idle_DayStr + '/' + idle_MonthStr + '/' + idle_YearStr;
                }
                if (dateFormat == 2) {
                  idle_DayMonthYearStr = idle_MonthStr + '/' + idle_DayStr + '/' + idle_YearStr;
                }
                idle_day_month_year_font.setProperty(hmUI.prop.TEXT, idle_DayMonthYearStr );
              };

            };

            //#endregion
            function scale_call() {
              console.log('scale_call()');

              console.log('Weather city name');
              let weatherData = weatherSensor.getForecastWeather();
              let normal_cityNameStr = weatherData.cityName;
              normal_cityNameStr = normal_cityNameStr.toUpperCase();
              normal_city_name_text.setProperty(hmUI.prop.TEXT, normal_cityNameStr);

            };

            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                console.log('resume_call()');
                scale_call();
                time_update(true, true);
                if (screenType == hmSetting.screen_type.WATCHFACE) {
                  if (!normal_timerTimeUpdate) {
                    normal_timerTimeUpdate = timer.createTimer(0, 1000, (function (option) {
                      let updateHour = timeSensor.minute == 0;
                      let updateMinute = timeSensor.second < 2;
                      time_update(updateHour, updateMinute);
                    }));  // end timer 
                  };  // end timer check
                };  // end screenType

                if (screenType == hmSetting.screen_type.AOD) {
                  if (!idle_timerTimeUpdate) {
                    idle_timerTimeUpdate = timer.createTimer(0, 1000, (function (option) {
                      let updateHour = timeSensor.minute == 0;
                      let updateMinute = timeSensor.second < 2;
                      time_update(updateHour, updateMinute);
                    }));  // end timer 
                  };  // end timer check
                };  // end screenType


              }),
              pause_call: (function () {
                console.log('pause_call()');
                if (normal_timerTimeUpdate) {
                  timer.stopTimer(normal_timerTimeUpdate);
                  normal_timerTimeUpdate = undefined;
                }
                if (idle_timerTimeUpdate) {
                  timer.stopTimer(idle_timerTimeUpdate);
                  idle_timerTimeUpdate = undefined;
                }

              }),
            });

                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}