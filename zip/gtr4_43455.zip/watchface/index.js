﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        //const logger = Logger.getLogger('watchface_SashaCX75');
        const logger = DeviceRuntimeCore.HmLogger.getLogger('watchface_SashaCX75')
        //end of ignored block

        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_temperature_current_text_img = ''
        let normal_floor_text_text_img = ''
        let normal_spo2_text_text_img = ''
        let normal_stand_current_text_img = ''
        let normal_humidity_text_text_img = ''
        let normal_uvi_text_text_img = ''
        let normal_sun_icon_img = ''
        let normal_sun_high_text_img = ''
        let normal_sun_low_text_img = ''
        let normal_distance_text_text_img = ''
        let normal_heart_rate_text_text_img = ''
        let normal_step_current_text_img = ''
        let normal_group_ForecastWeather = ''
        let normal_forecast_date_week_font = new Array(3);
        let normal_forecast_date_week_font_Array = ['LUN', 'MAR', 'MIE', 'JUE', 'VIE', 'SAB', 'DOM'];
        let normal_forecast_high_low_text_font = new Array(3);
        let normal_forecast_image_progress_img_level = new Array(3);
        let normal_forecast_image_array = ['Meteo-01.png', 'Meteo-02.png', 'Meteo-03.png', 'Meteo-04.png', 'Meteo-05.png', 'Meteo-06.png', 'Meteo-07.png', 'Meteo-08.png', 'Meteo-09.png', 'Meteo-10.png', 'Meteo-11.png', 'Meteo-12.png', 'Meteo-13.png', 'Meteo-14.png', 'Meteo-15.png', 'Meteo-16.png', 'Meteo-17.png', 'Meteo-18.png', 'Meteo-19.png', 'Meteo-20.png', 'Meteo-21.png', 'Meteo-22.png', 'Meteo-23.png', 'Meteo-24.png', 'Meteo-25.png', 'Meteo-26.png', 'Meteo-27.png', 'Meteo-28.png', 'Meteo-29.png'];
        let normal_moon_image_progress_img_level = ''
        let normal_year_text_font = ''
        let normal_month_name_font = ''
        let normal_Month_Array = ['Ene', 'Feb', 'Mar', 'Abr', 'May', 'Jun', 'Jul', 'Ago', 'Sep', 'Oct', 'Nov', 'Dic', ];
        let normal_day_text_font = ''
        let normal_battery_linear_scale = ''
        let normal_battery_text_text_img = ''
        let normal_time_hour_min_text_font = ''
        let normal_timerTimeUpdate = undefined;
        let normal_time_second_text_font = ''
        let timeSensor = '';


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            console.log('Watch_Face.ScreenNormal');
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: '0.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 84,
              y: 348,
              font_array: ["MININ00.png","MININ01.png","MININ02.png","MININ03.png","MININ04.png","MININ05.png","MININ06.png","MININ07.png","MININ08.png","MININ09.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'MININ13.png',
              unit_tc: 'MININ13.png',
              unit_en: 'MININ13.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_floor_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 320,
              y: 378,
              font_array: ["MININ00.png","MININ01.png","MININ02.png","MININ03.png","MININ04.png","MININ05.png","MININ06.png","MININ07.png","MININ08.png","MININ09.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.FLOOR,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_spo2_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 305,
              y: 408,
              font_array: ["MININ00.png","MININ01.png","MININ02.png","MININ03.png","MININ04.png","MININ05.png","MININ06.png","MININ07.png","MININ08.png","MININ09.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'MININ112.png',
              unit_tc: 'MININ112.png',
              unit_en: 'MININ112.png',
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.SPO2,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_stand_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 290,
              y: 348,
              font_array: ["MININ00.png","MININ01.png","MININ02.png","MININ03.png","MININ04.png","MININ05.png","MININ06.png","MININ07.png","MININ08.png","MININ09.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.STAND,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_humidity_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 105,
              y: 378,
              font_array: ["MININ00.png","MININ01.png","MININ02.png","MININ03.png","MININ04.png","MININ05.png","MININ06.png","MININ07.png","MININ08.png","MININ09.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'MININ112.png',
              unit_tc: 'MININ112.png',
              unit_en: 'MININ112.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.HUMIDITY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_uvi_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 134,
              y: 408,
              font_array: ["MININ00.png","MININ01.png","MININ02.png","MININ03.png","MININ04.png","MININ05.png","MININ06.png","MININ07.png","MININ08.png","MININ09.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.UVI,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sun_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 334,
              y: 103,
              src: 'sol.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sun_high_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 333,
              y: 75,
              font_array: ["MINI00.png","MINI01.png","MINI02.png","MINI03.png","MINI04.png","MINI05.png","MINI06.png","MINI07.png","MINI08.png","MINI09.png"],
              padding: false,
              h_space: 0,
              dot_image: 'MINI10.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.SUN_RISE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sun_low_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 333,
              y: 151,
              font_array: ["MINI00.png","MINI01.png","MINI02.png","MINI03.png","MINI04.png","MINI05.png","MINI06.png","MINI07.png","MINI08.png","MINI09.png"],
              padding: false,
              h_space: 0,
              dot_image: 'MINI10.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.SUN_SET,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_distance_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 374,
              y: 298,
              font_array: ["MINI00.png","MINI01.png","MINI02.png","MINI03.png","MINI04.png","MINI05.png","MINI06.png","MINI07.png","MINI08.png","MINI09.png"],
              padding: false,
              h_space: 0,
              dot_image: 'MINI10.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.DISTANCE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 294,
              y: 298,
              font_array: ["MINI00.png","MINI01.png","MINI02.png","MINI03.png","MINI04.png","MINI05.png","MINI06.png","MINI07.png","MINI08.png","MINI09.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 169,
              y: 298,
              font_array: ["MINI00.png","MINI01.png","MINI02.png","MINI03.png","MINI04.png","MINI05.png","MINI06.png","MINI07.png","MINI08.png","MINI09.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            let screenType = hmSetting.getScreenType();            
            // normal_Weather_FewDays = hmUI.createWidget(hmUI.widget.FewDays, {
              // x: 0,
              // y: 0,
              // ColumnWidth: 94,
              // DaysCount: 3,
            // });
            
            normal_group_ForecastWeather = hmUI.createWidget(hmUI.widget.GROUP, {
              x: 0,
              y: 0,
              h: 0,
              w: 0,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_forecast_date_week_font = normal_group_ForecastWeather.createWidget(hmUI.widget.TEXT_Options, {
              // x: 54,
              // y: 135,
              // w: 84,
              // h: 35,
              // text_size: 30,
              // char_space: 0,
              // line_space: 0,
              // alpha: 255,
              // color: 0xFFFF8C00,
              // color_2: 0xFFFF0000,
              // use_color_2: True,
              // align_h: hmUI.align.CENTER_H,
              // align_v: hmUI.align.BOTTOM,
              // text_style: hmUI.text_style.ELLIPSIS,
              // type: hmUI.data_type.forecast_date_week_img,
              // unit_string: LUN, MAR, MIE, JUE, VIE, SAB, DOM,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            //#region screenType
            if (screenType == hmSetting.screen_type.WATCHFACE) {
              for (let i = 0; i < 3; i++) {
                normal_forecast_date_week_font[i] = normal_group_ForecastWeather.createWidget(hmUI.widget.TEXT, {
                  x: 54 + i*94,
                  y: 135,
                  w: 84,
                  h: 35,
                  text_size: 30,
                  char_space: 0,
                  line_space: 0,
                  color: 0xFFFF8C00,
                  // color_2: 0xFFFF0000,
                  align_h: hmUI.align.CENTER_H,
                  align_v: hmUI.align.BOTTOM,
                  text_style: hmUI.text_style.ELLIPSIS,
                  // unit_string: LUN, MAR, MIE, JUE, VIE, SAB, DOM,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });
              };
            };
            //#endregion

            if (!timeSensor) timeSensor = hmSensor.createSensor(hmSensor.id.TIME);
            // normal_forecast_high_low_text_font = normal_group_ForecastWeather.createWidget(hmUI.widget.TEXT_Options, {
              // x: 51,
              // y: 115,
              // w: 87,
              // h: 22,
              // text_size: 20,
              // char_space: 0,
              // line_space: 0,
              // alpha: 255,
              // color: 0xFFFF8C00,
              // color_2: 0xFFFF0000,
              // use_color_2: False,
              // align_h: hmUI.align.CENTER_H,
              // align_v: hmUI.align.BOTTOM,
              // text_style: hmUI.text_style.ELLIPSIS,
              // type: hmUI.data_type.forecast_high_low_text_font,
              // unit_type: 1,
              // unit_string:  | ,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            //#region screenType
            if (screenType == hmSetting.screen_type.WATCHFACE) {
              for (let i = 0; i < 3; i++) {
                normal_forecast_high_low_text_font[i] = normal_group_ForecastWeather.createWidget(hmUI.widget.TEXT, {
                  x: 51 + i*94,
                  y: 115,
                  w: 87,
                  h: 22,
                  text_size: 20,
                  char_space: 0,
                  line_space: 0,
                  color: 0xFFFF8C00,
                  align_h: hmUI.align.CENTER_H,
                  align_v: hmUI.align.BOTTOM,
                  text_style: hmUI.text_style.ELLIPSIS,
                  // unit_type: 1,
                  // unit_string:  | ,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });
              };
            };
            //#endregion

            // normal_forecast_image_progress_img_level = normal_group_ForecastWeather.createWidget(hmUI.widget.IMG_LEVEL_Options, {
              // x: 50,
              // y: 47,
              // image_array: ["Meteo-01.png","Meteo-02.png","Meteo-03.png","Meteo-04.png","Meteo-05.png","Meteo-06.png","Meteo-07.png","Meteo-08.png","Meteo-09.png","Meteo-10.png","Meteo-11.png","Meteo-12.png","Meteo-13.png","Meteo-14.png","Meteo-15.png","Meteo-16.png","Meteo-17.png","Meteo-18.png","Meteo-19.png","Meteo-20.png","Meteo-21.png","Meteo-22.png","Meteo-23.png","Meteo-24.png","Meteo-25.png","Meteo-26.png","Meteo-27.png","Meteo-28.png","Meteo-29.png"],
              // image_length: 29,
              // type: hmUI.data_type.forecast_image,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            //#region screenType
            if (screenType == hmSetting.screen_type.WATCHFACE) {
              for (let i = 0; i < 3; i++) {
                normal_forecast_image_progress_img_level[i] = normal_group_ForecastWeather.createWidget(hmUI.widget.IMG, {
                  x: 50 + i*94,
                  y: 47,
                  src: normal_forecast_image_array[25],
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });
              };
            };
            //#endregion

            normal_moon_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 384,
              y: 103,
              image_array: ["fase1.png","fase2.png","fase3.png","fase4.png","fase5.png","fase6.png","fase7.png","fase8.png","Meteo-01.png"],
              image_length: 9,
              type: hmUI.data_type.MOON,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            timeSensor.addEventListener(timeSensor.event.DAYCHANGE, function() {
              time_update(true);
            });

            normal_year_text_font = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 11,
              y: 278,
              w: 102,
              h: 50,
              text_size: 40,
              char_space: 0,
              line_space: 0,
              color: 0xFFFFFFFF,
              align_h: hmUI.align.RIGHT,
              align_v: hmUI.align.BOTTOM,
              text_style: hmUI.text_style.ELLIPSIS,
              // padding: true,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_month_name_font = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 38,
              y: 241,
              w: 69,
              h: 47,
              text_size: 44,
              char_space: 0,
              line_space: 0,
              color: 0xFFFF8000,
              align_h: hmUI.align.RIGHT,
              align_v: hmUI.align.BOTTOM,
              text_style: hmUI.text_style.ELLIPSIS,
              // unit_string: Ene, Feb, Mar, Abr, May, Jun, Jul, Ago, Sep, Oct, Nov, Dic,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_day_text_font = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 28,
              y: 176,
              w: 90,
              h: 80,
              text_size: 80,
              char_space: 0,
              line_space: 2,
              color: 0xFFFFFFFF,
              align_h: hmUI.align.RIGHT,
              align_v: hmUI.align.BOTTOM,
              text_style: hmUI.text_style.ELLIPSIS,
              // padding: true,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            if (screenType != hmSetting.screen_type.AOD) {
              normal_battery_linear_scale = hmUI.createWidget(hmUI.widget.FILL_RECT);
            };

            // normal_battery_linear_scale = hmUI.createWidget(hmUI.widget.Linear_Scale, {
              // start_x: 136,
              // start_y: 28,
              // color: 0xFFFF0000,
              // lenght: 207,
              // line_width: 8,
              // line_cap: Rounded,
              // vertical: False,
              // mirror: False,
              // inversion: False,
              // alpha: 255,
              // type: hmUI.data_type.BATTERY,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });
            
            const battery = hmSensor.createSensor(hmSensor.id.BATTERY);
            battery.addEventListener(hmSensor.event.CHANGE, function() {
              scale_call();
            });

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 207,
              y: 2,
              font_array: ["MINI00.png","MINI01.png","MINI02.png","MINI03.png","MINI04.png","MINI05.png","MINI06.png","MINI07.png","MINI08.png","MINI09.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'MINI13.png',
              unit_tc: 'MINI13.png',
              unit_en: 'MINI13.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_time_hour_min_text_font = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 136,
              y: 185,
              w: 260,
              h: 111,
              text_size: 100,
              char_space: 0,
              line_space: 0,
              color: 0xFFFFFFFF,
              align_h: hmUI.align.LEFT,
              align_v: hmUI.align.BOTTOM,
              text_style: hmUI.text_style.ELLIPSIS,
              // padding: true,
              // unit_type: 2,
              // unit_end: true,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_time_second_text_font = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 390,
              y: 196,
              w: 59,
              h: 50,
              text_size: 50,
              char_space: 0,
              line_space: 0,
              color: 0xFFFF8C00,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.BOTTOM,
              text_style: hmUI.text_style.ELLIPSIS,
              // padding: true,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            console.log('Watch_Face.ScreenAOD');

            const weatherSensor = hmSensor.createSensor(hmSensor.id.WEATHER);
            //#region weather_few_days
            function weather_few_days() {
              console.log('weather_few_days()');
              let weatherData = weatherSensor.getForecastWeather();
              let forecastData = weatherData.forecastData;

              for (let i = 0; i < 3; i++) {
                // DayOfWeek font
                if (screenType == hmSetting.screen_type.WATCHFACE) {
                  let dowIndex = timeSensor.week - 1;
                  dowIndex += i;
                  while (dowIndex >= 7) {dowIndex -= 7;}
                  normal_forecast_date_week_font[i].setProperty(hmUI.prop.TEXT, normal_forecast_date_week_font_Array[dowIndex]);
                  if (dowIndex >= 5) normal_forecast_date_week_font[i].setProperty(hmUI.prop.COLOR, 0xFFFF0000);
                  else normal_forecast_date_week_font[i].setProperty(hmUI.prop.COLOR, 0xFFFF8C00);
                };
              
                // Number_Font_Maxmin
                let normal_max_min_Temperature_font = '-';
                if (i < forecastData.count) {
                  normal_max_min_Temperature_font = forecastData.data[i].high.toString();
                  normal_max_min_Temperature_font += ' | ';
                  normal_max_min_Temperature_font += forecastData.data[i].low.toString();
                };
                if (screenType == hmSetting.screen_type.WATCHFACE) {
                  normal_forecast_high_low_text_font[i].setProperty(hmUI.prop.TEXT, normal_max_min_Temperature_font + '°');
                };
                
                // Images
                if (screenType == hmSetting.screen_type.WATCHFACE) {
                  let weatherIndex = 25
                  if (i < forecastData.count) weatherIndex = forecastData.data[i].index;
                  normal_forecast_image_progress_img_level[i].setProperty(hmUI.prop.SRC, normal_forecast_image_array[weatherIndex]);
                };
              
              };  // end for

            };
            //#endregion

            //#region time_update
            function time_update(updateHour = false, updateMinute = false) {
              console.log('time_update()');
              let hour = timeSensor.hour;
              let minute = timeSensor.minute;
              let second = timeSensor.second;
              let format_hour = timeSensor.format_hour;

              console.log('year font');
              if (updateHour) {
                let normal_yearStr = timeSensor.year.toString();
                normal_year_text_font.setProperty(hmUI.prop.TEXT, normal_yearStr );
              };

              console.log('month font');
              if (updateHour) {
                let normal_Month_Str = normal_Month_Array[timeSensor.month-1];
                normal_month_name_font.setProperty(hmUI.prop.TEXT, normal_Month_Str );
              };

              console.log('day font');
              if (updateHour) {
                let normal_dayStr = timeSensor.day.toString();
                normal_dayStr = normal_dayStr.padStart(2, '0');
                normal_day_text_font.setProperty(hmUI.prop.TEXT, normal_dayStr );
              };

              console.log('hour:min font');
              if (updateMinute) {
                let normal_HourMinStr = format_hour.toString();
                normal_HourMinStr = normal_HourMinStr.padStart(2, '0');
                normal_HourMinStr = normal_HourMinStr + ':' + minute.toString().padStart(2, '0')
                if (!timeSensor.is24Hour) {
                  if (hour > 11) normal_HourMinStr = normal_HourMinStr + ' PM';
                  else normal_HourMinStr = normal_HourMinStr + ' AM';
                };
                normal_time_hour_min_text_font.setProperty(hmUI.prop.TEXT, normal_HourMinStr );
              };

              console.log('second font');
                let normal_secondStr = second.toString();
                normal_secondStr = normal_secondStr.padStart(2, '0');
                normal_time_second_text_font.setProperty(hmUI.prop.TEXT, normal_secondStr );
            };

            //#endregion
            function scale_call() {
              console.log('scale_call()');

                console.log('update scales BATTERY');
                
                let valueBattery = battery.current;
                let targetBattery = 100;
                let progressBattery = valueBattery/targetBattery;
                if (progressBattery > 1) progressBattery = 1;
                let progress_ls_normal_battery = progressBattery;

                if (screenType != hmSetting.screen_type.AOD) {

                  // normal_battery_linear_scale
                  // initial parameters
                  let start_x_normal_battery = 136;
                  let start_y_normal_battery = 28;
                  let lenght_ls_normal_battery = 207;
                  let line_width_ls_normal_battery = 8;
                  let color_ls_normal_battery = 0xFFFF0000;
                  
                  // calculated parameters
                  let start_x_normal_battery_draw = start_x_normal_battery;
                  let start_y_normal_battery_draw = start_y_normal_battery;
                  lenght_ls_normal_battery = lenght_ls_normal_battery * progress_ls_normal_battery;
                  let lenght_ls_normal_battery_draw = lenght_ls_normal_battery;
                  let line_width_ls_normal_battery_draw = line_width_ls_normal_battery;
                  if (lenght_ls_normal_battery < 0){
                    lenght_ls_normal_battery_draw = -lenght_ls_normal_battery;
                    start_x_normal_battery_draw = start_x_normal_battery - lenght_ls_normal_battery_draw;
                  };
                  
                  normal_battery_linear_scale.setProperty(hmUI.prop.MORE, {
                    x: start_x_normal_battery_draw,
                    y: start_y_normal_battery_draw,
                    w: lenght_ls_normal_battery_draw,
                    h: line_width_ls_normal_battery_draw,
                    radius: 4,
                    color: color_ls_normal_battery,
                  });
                };

            };

            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                console.log('resume_call()');
                scale_call();
                time_update(true, true);
                if (screenType == hmSetting.screen_type.WATCHFACE) {
                  if (!normal_timerTimeUpdate) {
                    normal_timerTimeUpdate = timer.createTimer(0, 1000, (function (option) {
                      let updateHour = timeSensor.minute == 0 && timeSensor.second < 2;
                      let updateMinute = timeSensor.second < 2;
                      time_update(updateHour, updateMinute);
                    }));  // end timer 
                  };  // end timer check
                };  // end screenType


                weather_few_days();
              }),
              pause_call: (function () {
                console.log('pause_call()');
                if (normal_timerTimeUpdate) {
                  timer.stopTimer(normal_timerTimeUpdate);
                  normal_timerTimeUpdate = undefined;
                }

              }),
            });

                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}