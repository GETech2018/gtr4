﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        const logger = Logger.getLogger('watchface_SashaCX75');
        //end of ignored block

        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_date_img_date_month_img = ''
        let normal_date_img_date_day = ''
        let normal_date_img_date_week_img = ''
        let normal_temperature_current_text_img = ''
        let normal_weather_image_progress_img_level = ''
        let normal_battery_text_text_img = ''
        let normal_heart_rate_text_text_img = ''
        let normal_calorie_current_text_img = ''
        let normal_step_current_text_img = ''
        let normal_digital_clock_img_time = ''
        let idle_background_bg_img = ''
        let idle_date_img_date_month_img = ''
        let idle_date_img_date_day = ''
        let idle_date_img_date_week_img = ''
        let idle_temperature_current_text_img = ''
        let idle_weather_image_progress_img_level = ''
        let idle_battery_text_text_img = ''
        let idle_heart_rate_text_text_img = ''
        let idle_calorie_current_text_img = ''
        let idle_step_current_text_img = ''
        let idle_digital_clock_img_time = ''
        let Button_1 = ''
        let Button_2 = ''
        let Button_3 = ''
        let Button_4 = ''
        let Button_5 = ''
        let Button_6 = ''


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            console.log('Watch_Face.ScreenNormal');
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 466,
              h: 466,
              src: 'bg.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_month_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 165,
              month_startY: 217,
              month_sc_array: ["BJ30-MO-1.png","BJ30-MO-2.png","BJ30-MO-3.png","BJ30-MO-4.png","BJ30-MO-5.png","BJ30-MO-6.png","BJ30-MO-7.png","BJ30-MO-8.png","BJ30-MO-9.png","BJ30-MO-10.png","BJ30-MO-11.png","BJ30-MO-12.png"],
              month_tc_array: ["BJ30-MO-1.png","BJ30-MO-2.png","BJ30-MO-3.png","BJ30-MO-4.png","BJ30-MO-5.png","BJ30-MO-6.png","BJ30-MO-7.png","BJ30-MO-8.png","BJ30-MO-9.png","BJ30-MO-10.png","BJ30-MO-11.png","BJ30-MO-12.png"],
              month_en_array: ["BJ30-MO-1.png","BJ30-MO-2.png","BJ30-MO-3.png","BJ30-MO-4.png","BJ30-MO-5.png","BJ30-MO-6.png","BJ30-MO-7.png","BJ30-MO-8.png","BJ30-MO-9.png","BJ30-MO-10.png","BJ30-MO-11.png","BJ30-MO-12.png"],
              month_is_character: true ,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 100,
              day_startY: 217,
              day_sc_array: ["BAI30__0.png","BAI30__1.png","BAI30__2.png","BAI30__3.png","BAI30__4.png","BAI30__5.png","BAI30__6.png","BAI30__7.png","BAI30__8.png","BAI30__9.png"],
              day_tc_array: ["BAI30__0.png","BAI30__1.png","BAI30__2.png","BAI30__3.png","BAI30__4.png","BAI30__5.png","BAI30__6.png","BAI30__7.png","BAI30__8.png","BAI30__9.png"],
              day_en_array: ["BAI30__0.png","BAI30__1.png","BAI30__2.png","BAI30__3.png","BAI30__4.png","BAI30__5.png","BAI30__6.png","BAI30__7.png","BAI30__8.png","BAI30__9.png"],
              day_zero: 1,
              day_space: -48,
              day_align: hmUI.align.LEFT,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 50,
              y: 217,
              week_en: ["BJ30-WD-1.png","BJ30-WD-2.png","BJ30-WD-3.png","BJ30-WD-4.png","BJ30-WD-5.png","BJ30-WD-6.png","BJ30-WD-7.png"],
              week_tc: ["BJ30-WD-1.png","BJ30-WD-2.png","BJ30-WD-3.png","BJ30-WD-4.png","BJ30-WD-5.png","BJ30-WD-6.png","BJ30-WD-7.png"],
              week_sc: ["BJ30-WD-1.png","BJ30-WD-2.png","BJ30-WD-3.png","BJ30-WD-4.png","BJ30-WD-5.png","BJ30-WD-6.png","BJ30-WD-7.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 258,
              y: 322,
              font_array: ["BAI30__0.png","BAI30__1.png","BAI30__2.png","BAI30__3.png","BAI30__4.png","BAI30__5.png","BAI30__6.png","BAI30__7.png","BAI30__8.png","BAI30__9.png"],
              padding: false,
              h_space: -46,
              unit_sc: 'grad.png',
              unit_tc: 'grad.png',
              unit_en: 'grad.png',
              negative_image: 'minus.png',
              invalid_image: 'error.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 244,
              y: 319,
              image_array: ["Weather-0.png","Weather-1.png","Weather-2.png","Weather-3.png","Weather-4.png","Weather-5.png","Weather-6.png","Weather-7.png","Weather-8.png","Weather-9.png","Weather-10.png","Weather-11.png","Weather-12.png","Weather-13.png","Weather-14.png","Weather-15.png","Weather-16.png","Weather-17.png","Weather-18.png","Weather-19.png","Weather-20.png","Weather-21.png","Weather-22.png","Weather-23.png","Weather-24.png","Weather-25.png","Weather-26.png","Weather-27.png","Weather-28.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 257,
              y: 164,
              font_array: ["BAI30__0.png","BAI30__1.png","BAI30__2.png","BAI30__3.png","BAI30__4.png","BAI30__5.png","BAI30__6.png","BAI30__7.png","BAI30__8.png","BAI30__9.png"],
              padding: false,
              h_space: -46,
              unit_sc: 'percent_15_stroke.png',
              unit_tc: 'percent_15_stroke.png',
              unit_en: 'percent_15_stroke.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 256,
              y: 270,
              font_array: ["BAI30__0.png","BAI30__1.png","BAI30__2.png","BAI30__3.png","BAI30__4.png","BAI30__5.png","BAI30__6.png","BAI30__7.png","BAI30__8.png","BAI30__9.png"],
              padding: false,
              h_space: -46,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_calorie_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 256,
              y: 111,
              font_array: ["BAI30__0.png","BAI30__1.png","BAI30__2.png","BAI30__3.png","BAI30__4.png","BAI30__5.png","BAI30__6.png","BAI30__7.png","BAI30__8.png","BAI30__9.png"],
              padding: false,
              h_space: -46,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 256,
              y: 216,
              font_array: ["BAI30__0.png","BAI30__1.png","BAI30__2.png","BAI30__3.png","BAI30__4.png","BAI30__5.png","BAI30__6.png","BAI30__7.png","BAI30__8.png","BAI30__9.png"],
              padding: false,
              h_space: -46,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 72,
              hour_startY: 85,
              hour_array: ["ANTRED-0.png","ANTRED-1.png","ANTRED-2.png","ANTRED-3.png","ANTRED-4.png","ANTRED-5.png","ANTRED-6.png","ANTRED-7.png","ANTRED-8.png","ANTRED-9.png"],
              hour_zero: 1,
              hour_space: 1,
              hour_angle: 0,
              hour_align: hmUI.align.CENTER_H,

              minute_startX: 72,
              minute_startY: 255,
              minute_array: ["ANT140-0.png","ANT140-1.png","ANT140-2.png","ANT140-3.png","ANT140-4.png","ANT140-5.png","ANT140-6.png","ANT140-7.png","ANT140-8.png","ANT140-9.png"],
              minute_zero: 1,
              minute_space: 1,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.CENTER_H,

              second_startX: 383,
              second_startY: 216,
              second_array: ["BAI30__0.png","BAI30__1.png","BAI30__2.png","BAI30__3.png","BAI30__4.png","BAI30__5.png","BAI30__6.png","BAI30__7.png","BAI30__8.png","BAI30__9.png"],
              second_zero: 1,
              second_space: -46,
              second_angle: 0,
              second_follow: 0,
              second_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            console.log('Watch_Face.ScreenAOD');
            idle_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 466,
              h: 466,
              src: 'bg.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_month_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 165,
              month_startY: 217,
              month_sc_array: ["BJ30-MO-1.png","BJ30-MO-2.png","BJ30-MO-3.png","BJ30-MO-4.png","BJ30-MO-5.png","BJ30-MO-6.png","BJ30-MO-7.png","BJ30-MO-8.png","BJ30-MO-9.png","BJ30-MO-10.png","BJ30-MO-11.png","BJ30-MO-12.png"],
              month_tc_array: ["BJ30-MO-1.png","BJ30-MO-2.png","BJ30-MO-3.png","BJ30-MO-4.png","BJ30-MO-5.png","BJ30-MO-6.png","BJ30-MO-7.png","BJ30-MO-8.png","BJ30-MO-9.png","BJ30-MO-10.png","BJ30-MO-11.png","BJ30-MO-12.png"],
              month_en_array: ["BJ30-MO-1.png","BJ30-MO-2.png","BJ30-MO-3.png","BJ30-MO-4.png","BJ30-MO-5.png","BJ30-MO-6.png","BJ30-MO-7.png","BJ30-MO-8.png","BJ30-MO-9.png","BJ30-MO-10.png","BJ30-MO-11.png","BJ30-MO-12.png"],
              month_is_character: true ,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 100,
              day_startY: 217,
              day_sc_array: ["BAI30__0.png","BAI30__1.png","BAI30__2.png","BAI30__3.png","BAI30__4.png","BAI30__5.png","BAI30__6.png","BAI30__7.png","BAI30__8.png","BAI30__9.png"],
              day_tc_array: ["BAI30__0.png","BAI30__1.png","BAI30__2.png","BAI30__3.png","BAI30__4.png","BAI30__5.png","BAI30__6.png","BAI30__7.png","BAI30__8.png","BAI30__9.png"],
              day_en_array: ["BAI30__0.png","BAI30__1.png","BAI30__2.png","BAI30__3.png","BAI30__4.png","BAI30__5.png","BAI30__6.png","BAI30__7.png","BAI30__8.png","BAI30__9.png"],
              day_zero: 1,
              day_space: -48,
              day_align: hmUI.align.LEFT,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 50,
              y: 217,
              week_en: ["BJ30-WD-1.png","BJ30-WD-2.png","BJ30-WD-3.png","BJ30-WD-4.png","BJ30-WD-5.png","BJ30-WD-6.png","BJ30-WD-7.png"],
              week_tc: ["BJ30-WD-1.png","BJ30-WD-2.png","BJ30-WD-3.png","BJ30-WD-4.png","BJ30-WD-5.png","BJ30-WD-6.png","BJ30-WD-7.png"],
              week_sc: ["BJ30-WD-1.png","BJ30-WD-2.png","BJ30-WD-3.png","BJ30-WD-4.png","BJ30-WD-5.png","BJ30-WD-6.png","BJ30-WD-7.png"],
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 256,
              y: 320,
              font_array: ["BAI30__0.png","BAI30__1.png","BAI30__2.png","BAI30__3.png","BAI30__4.png","BAI30__5.png","BAI30__6.png","BAI30__7.png","BAI30__8.png","BAI30__9.png"],
              padding: false,
              h_space: -46,
              unit_sc: 'grad.png',
              unit_tc: 'grad.png',
              unit_en: 'grad.png',
              negative_image: 'minus.png',
              invalid_image: 'error.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 244,
              y: 318,
              image_array: ["Weather-0.png","Weather-1.png","Weather-2.png","Weather-3.png","Weather-4.png","Weather-5.png","Weather-6.png","Weather-7.png","Weather-8.png","Weather-9.png","Weather-10.png","Weather-11.png","Weather-12.png","Weather-13.png","Weather-14.png","Weather-15.png","Weather-16.png","Weather-17.png","Weather-18.png","Weather-19.png","Weather-20.png","Weather-21.png","Weather-22.png","Weather-23.png","Weather-24.png","Weather-25.png","Weather-26.png","Weather-27.png","Weather-28.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 255,
              y: 161,
              font_array: ["BAI30__0.png","BAI30__1.png","BAI30__2.png","BAI30__3.png","BAI30__4.png","BAI30__5.png","BAI30__6.png","BAI30__7.png","BAI30__8.png","BAI30__9.png"],
              padding: false,
              h_space: -46,
              unit_sc: 'percent_15_stroke.png',
              unit_tc: 'percent_15_stroke.png',
              unit_en: 'percent_15_stroke.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 254,
              y: 267,
              font_array: ["BAI30__0.png","BAI30__1.png","BAI30__2.png","BAI30__3.png","BAI30__4.png","BAI30__5.png","BAI30__6.png","BAI30__7.png","BAI30__8.png","BAI30__9.png"],
              padding: false,
              h_space: -46,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_calorie_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 254,
              y: 108,
              font_array: ["BAI30__0.png","BAI30__1.png","BAI30__2.png","BAI30__3.png","BAI30__4.png","BAI30__5.png","BAI30__6.png","BAI30__7.png","BAI30__8.png","BAI30__9.png"],
              padding: false,
              h_space: -46,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 254,
              y: 213,
              font_array: ["BAI30__0.png","BAI30__1.png","BAI30__2.png","BAI30__3.png","BAI30__4.png","BAI30__5.png","BAI30__6.png","BAI30__7.png","BAI30__8.png","BAI30__9.png"],
              padding: false,
              h_space: -46,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 72,
              hour_startY: 85,
              hour_array: ["ANTRED-0.png","ANTRED-1.png","ANTRED-2.png","ANTRED-3.png","ANTRED-4.png","ANTRED-5.png","ANTRED-6.png","ANTRED-7.png","ANTRED-8.png","ANTRED-9.png"],
              hour_zero: 1,
              hour_space: 1,
              hour_angle: 0,
              hour_align: hmUI.align.CENTER_H,

              minute_startX: 72,
              minute_startY: 255,
              minute_array: ["ANT140-0.png","ANT140-1.png","ANT140-2.png","ANT140-3.png","ANT140-4.png","ANT140-5.png","ANT140-6.png","ANT140-7.png","ANT140-8.png","ANT140-9.png"],
              minute_zero: 1,
              minute_space: 1,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.CENTER_H,

              second_startX: 383,
              second_startY: 216,
              second_array: ["BAI30__0.png","BAI30__1.png","BAI30__2.png","BAI30__3.png","BAI30__4.png","BAI30__5.png","BAI30__6.png","BAI30__7.png","BAI30__8.png","BAI30__9.png"],
              second_zero: 1,
              second_space: -46,
              second_angle: 0,
              second_follow: 0,
              second_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_AOD,
            });

            console.log('Watch_Face.Buttons');
            Button_1 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 236,
              y: 108,
              w: 116,
              h: 40,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'transparent.png',
              normal_src: 'transparent.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'PAI_app_Screen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_2 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 236,
              y: 161,
              w: 129,
              h: 40,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'transparent.png',
              normal_src: 'transparent.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'spo_HomeScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_3 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 236,
              y: 213,
              w: 148,
              h: 40,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'transparent.png',
              normal_src: 'transparent.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'activityAppScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_4 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 50,
              y: 213,
              w: 166,
              h: 40,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'transparent.png',
              normal_src: 'transparent.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'ScheduleCalScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_5 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 238,
              y: 265,
              w: 129,
              h: 40,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'transparent.png',
              normal_src: 'transparent.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'heart_app_Screen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_6 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 238,
              y: 317,
              w: 116,
              h: 40,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'transparent.png',
              normal_src: 'transparent.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'WeatherScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button


                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}