﻿
    /*
    ** Watch_Face_Editor tool
    ** watchface js version v1.0.1
    ** Copyright © CashaCX75. All Rights Reserved
    */

    try {

      (() => {

        var __$$app$$__ = __$$hmAppManager$$__.currentApp;
        var __$$module$$__ = __$$app$$__.current;
        //drink is a name,can modify
        var h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__), 'drink');

        'use strict';

        //dynamic modify start

        
        let normal_background_bg_img = ''
        let editBg = ''
        let normal_system_clock_img = ''
        let normal_battery_circle_scale = ''
        let normal_battery_text_text_img = ''
        let normal_date_img_date_week_img = ''
        let normal_date_img_date_day = ''
        let normal_digital_clock_img_time = ''
        let idle_background_bg = ''
        let idle_date_img_date_week_img = ''
        let idle_date_img_date_month_img = ''
        let idle_date_img_date_day = ''
        let idle_digital_clock_img_time = ''


        //dynamic modify end

        //not required
        const logger = DeviceRuntimeCore.HmLogger.getLogger("yeguang");

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({

          init_view() {

            //dynamic modify start
                    
            
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 466,
              h: 466,
              src: 'fondo_sunto_con_logo_v2.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            editBg = hmUI.createWidget(hmUI.widget.WATCHFACE_EDIT_BG, {
            });

            normal_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 374,
              y: 134,
              src: '0040_Alarm_Enabled.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_battery_circle_scale = hmUI.createWidget(hmUI.widget.Circle_Scale, {
              // center_x: 232,
              // center_y: 412,
              // start_angle: 0,
              // end_angle: 360,
              // radius: 33,
              // line_width: 3,
              // color: 0xFFFFFFFF,
              // mirror: False,
              // inversion: False,
              // type: hmUI.data_type.BATTERY,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            let screenType = hmSetting.getScreenType();
            if (screenType != hmSetting.screen_type.AOD) {
              normal_battery_circle_scale = hmUI.createWidget(hmUI.widget.ARC);
            };
            
            const battery = hmSensor.createSensor(hmSensor.id.BATTERY);
            battery.addEventListener(hmSensor.event.CHANGE, function() {
              scale_call();
            });

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 202,
              y: 398,
              font_array: ["0012_Day_Weather_Distance_Digit_0.png","0013_Day_Weather_Distance_Digit_1.png","0014_Day_Weather_Distance_Digit_2.png","0015_Day_Weather_Distance_Digit_3.png","0016_Day_Weather_Distance_Digit_4.png","0017_Day_Weather_Distance_Digit_5.png","0018_Day_Weather_Distance_Digit_6.png","0019_Day_Weather_Distance_Digit_7.png","0020_Day_Weather_Distance_Digit_8.png","0021_Day_Weather_Distance_Digit_9.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 164,
              y: 100,
              week_en: ["162.png","163.png","164.png","165.png","166.png","167.png","168.png"],
              week_tc: ["162.png","163.png","164.png","165.png","166.png","167.png","168.png"],
              week_sc: ["162.png","163.png","164.png","165.png","166.png","167.png","168.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 203,
              day_startY: 51,
              day_sc_array: ["152.png","153.png","154.png","155.png","156.png","157.png","158.png","159.png","160.png","161.png"],
              day_tc_array: ["152.png","153.png","154.png","155.png","156.png","157.png","158.png","159.png","160.png","161.png"],
              day_en_array: ["152.png","153.png","154.png","155.png","156.png","157.png","158.png","159.png","160.png","161.png"],
              day_zero: 1,
              day_space: 0,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 41,
              hour_startY: 175,
              hour_array: ["0001_Clock_Digit_0.png","0002_Clock_Digit_1.png","0003_Clock_Digit_2.png","0004_Clock_Digit_3.png","0005_Clock_Digit_4.png","0006_Clock_Digit_5.png","0007_Clock_Digit_6.png","0008_Clock_Digit_7.png","0009_Clock_Digit_8.png","0010_Clock_Digit_9.png"],
              hour_zero: 1,
              hour_space: 9,
              hour_unit_sc: '0011_Clock_Separator.png',
              hour_unit_tc: '0011_Clock_Separator.png',
              hour_unit_en: '0011_Clock_Separator.png',
              hour_align: hmUI.align.CENTER_H,

              minute_startX: 252,
              minute_startY: 175,
              minute_array: ["0001_Clock_Digit_0.png","0002_Clock_Digit_1.png","0003_Clock_Digit_2.png","0004_Clock_Digit_3.png","0005_Clock_Digit_4.png","0006_Clock_Digit_5.png","0007_Clock_Digit_6.png","0008_Clock_Digit_7.png","0009_Clock_Digit_8.png","0010_Clock_Digit_9.png"],
              minute_zero: 1,
              minute_space: 9,
              minute_follow: 0,
              minute_align: hmUI.align.CENTER_H,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            idle_background_bg = hmUI.createWidget(hmUI.widget.FILL_RECT, {
              x: 0,
              y: 0,
              w: 466,
              h: 466,
              color: '0xFF000000',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 128,
              y: 134,
              week_en: ["0045_Weekdays_Monday.png","0046_Weekdays_Tuesday.png","0047_Weekdays_Wednesday.png","0048_Weekdays_Thursday.png","0049_Weekdays_Friday.png","0050_Weekdays_Saturday.png","0051_Weekdays_Sunday.png"],
              week_tc: ["0045_Weekdays_Monday.png","0046_Weekdays_Tuesday.png","0047_Weekdays_Wednesday.png","0048_Weekdays_Thursday.png","0049_Weekdays_Friday.png","0050_Weekdays_Saturday.png","0051_Weekdays_Sunday.png"],
              week_sc: ["0045_Weekdays_Monday.png","0046_Weekdays_Tuesday.png","0047_Weekdays_Wednesday.png","0048_Weekdays_Thursday.png","0049_Weekdays_Friday.png","0050_Weekdays_Saturday.png","0051_Weekdays_Sunday.png"],
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_month_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 273,
              month_startY: 134,
              month_sc_array: ["0052_Months_January.png","0053_Months_February.png","0054_Months_March.png","0055_Months_April.png","0056_Months_May.png","0057_Months_June.png","0058_Months_July.png","0059_Months_August.png","0060_Months_September.png","0061_Months_October.png","0062_Months_November.png","0063_Months_December.png"],
              month_tc_array: ["0052_Months_January.png","0053_Months_February.png","0054_Months_March.png","0055_Months_April.png","0056_Months_May.png","0057_Months_June.png","0058_Months_July.png","0059_Months_August.png","0060_Months_September.png","0061_Months_October.png","0062_Months_November.png","0063_Months_December.png"],
              month_en_array: ["0052_Months_January.png","0053_Months_February.png","0054_Months_March.png","0055_Months_April.png","0056_Months_May.png","0057_Months_June.png","0058_Months_July.png","0059_Months_August.png","0060_Months_September.png","0061_Months_October.png","0062_Months_November.png","0063_Months_December.png"],
              month_is_character: true ,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 214,
              day_startY: 132,
              day_sc_array: ["0012_Day_Weather_Distance_Digit_0.png","0013_Day_Weather_Distance_Digit_1.png","0014_Day_Weather_Distance_Digit_2.png","0015_Day_Weather_Distance_Digit_3.png","0016_Day_Weather_Distance_Digit_4.png","0017_Day_Weather_Distance_Digit_5.png","0018_Day_Weather_Distance_Digit_6.png","0019_Day_Weather_Distance_Digit_7.png","0020_Day_Weather_Distance_Digit_8.png","0021_Day_Weather_Distance_Digit_9.png"],
              day_tc_array: ["0012_Day_Weather_Distance_Digit_0.png","0013_Day_Weather_Distance_Digit_1.png","0014_Day_Weather_Distance_Digit_2.png","0015_Day_Weather_Distance_Digit_3.png","0016_Day_Weather_Distance_Digit_4.png","0017_Day_Weather_Distance_Digit_5.png","0018_Day_Weather_Distance_Digit_6.png","0019_Day_Weather_Distance_Digit_7.png","0020_Day_Weather_Distance_Digit_8.png","0021_Day_Weather_Distance_Digit_9.png"],
              day_en_array: ["0012_Day_Weather_Distance_Digit_0.png","0013_Day_Weather_Distance_Digit_1.png","0014_Day_Weather_Distance_Digit_2.png","0015_Day_Weather_Distance_Digit_3.png","0016_Day_Weather_Distance_Digit_4.png","0017_Day_Weather_Distance_Digit_5.png","0018_Day_Weather_Distance_Digit_6.png","0019_Day_Weather_Distance_Digit_7.png","0020_Day_Weather_Distance_Digit_8.png","0021_Day_Weather_Distance_Digit_9.png"],
              day_zero: 1,
              day_space: 0,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 43,
              hour_startY: 177,
              hour_array: ["0001_Clock_Digit_0.png","0002_Clock_Digit_1.png","0003_Clock_Digit_2.png","0004_Clock_Digit_3.png","0005_Clock_Digit_4.png","0006_Clock_Digit_5.png","0007_Clock_Digit_6.png","0008_Clock_Digit_7.png","0009_Clock_Digit_8.png","0010_Clock_Digit_9.png"],
              hour_zero: 1,
              hour_space: 9,
              hour_unit_sc: '0011_Clock_Separator.png',
              hour_unit_tc: '0011_Clock_Separator.png',
              hour_unit_en: '0011_Clock_Separator.png',
              hour_align: hmUI.align.CENTER_H,

              minute_startX: 253,
              minute_startY: 177,
              minute_array: ["0001_Clock_Digit_0.png","0002_Clock_Digit_1.png","0003_Clock_Digit_2.png","0004_Clock_Digit_3.png","0005_Clock_Digit_4.png","0006_Clock_Digit_5.png","0007_Clock_Digit_6.png","0008_Clock_Digit_7.png","0009_Clock_Digit_8.png","0010_Clock_Digit_9.png"],
              minute_zero: 1,
              minute_space: 9,
              minute_follow: 0,
              minute_align: hmUI.align.CENTER_H,

              show_level: hmUI.show_level.ONLY_AOD,
            });

            function scale_call() {

                console.log('update scales BATTERY');
                
                let valueBattery = battery.current;
                let targetBattery = 100;
                let progressBattery = valueBattery/targetBattery;
                if (progressBattery > 1) progressBattery = 1;
                let progress_cs_normal_battery = progressBattery;

                if (screenType != hmSetting.screen_type.AOD) {

                  // normal_battery_circle_scale
                  // initial parameters
                  let start_angle_normal_battery = -90;
                  let end_angle_normal_battery = 270;
                  let center_x_normal_battery = 232;
                  let center_y_normal_battery = 412;
                  let radius_normal_battery = 33;
                  let line_width_cs_normal_battery = 3;
                  let color_cs_normal_battery = 0xFFFFFFFF;
                  
                  // calculated parameters
                  let arcX_normal_battery = center_x_normal_battery - radius_normal_battery;
                  let arcY_normal_battery = center_y_normal_battery - radius_normal_battery;
                  let CircleWidth_normal_battery = 2 * radius_normal_battery;
                  let angle_offset_normal_battery = end_angle_normal_battery - start_angle_normal_battery;
                  angle_offset_normal_battery = angle_offset_normal_battery * progress_cs_normal_battery;
                  let end_angle_normal_battery_draw = start_angle_normal_battery + angle_offset_normal_battery;
                  
                  normal_battery_circle_scale.setProperty(hmUI.prop.MORE, {
                    x: arcX_normal_battery,
                    y: arcY_normal_battery,
                    w: CircleWidth_normal_battery,
                    h: CircleWidth_normal_battery,
                    start_angle: start_angle_normal_battery,
                    end_angle: end_angle_normal_battery_draw,
                    color: color_cs_normal_battery,
                    line_width: line_width_cs_normal_battery,
                  });
                };

            };

            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                scale_call();
              }),
            });

            //dynamic modify end
          },

          onInit() {
            console.log('index page.js on init invoke')

            this.init_view()

          },

          onReady() {
            console.log('index page.js on ready invoke')
          },

          onShow() {
            console.log('index page.js on show invoke')
          },

          onHide() {
            console.log('index page.js on hide invoke')
          },

          onDestory() {
            console.log('index page.js on destory invoke')
          },
        });

      })()
    } catch (e) {
      console.log(e)
    }
  