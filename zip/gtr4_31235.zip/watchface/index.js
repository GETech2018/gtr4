﻿
    /*
    ** Watch_Face_Editor tool
    ** watchface js version v1.0.1
    ** Copyright © CashaCX75. All Rights Reserved
    */

    try {

      (() => {

        var __$$app$$__ = __$$hmAppManager$$__.currentApp;
        var __$$module$$__ = __$$app$$__.current;
        //drink is a name,can modify
        var h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__), 'drink');

        'use strict';

        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_stress_icon_img = ''
        let normal_system_dnd_img = ''
        let normal_system_disconnect_img = ''
        let normal_battery_text_text_img = ''
        let normal_date_img_date_day = ''
        let normal_date_img_date_month_img = ''
        let normal_digital_clock_img_time = ''
        let normal_digital_clock_hour_separator_img = ''
        let normal_analog_clock_time_pointer_hour = ''
        let normal_analog_clock_time_pointer_minute = ''
        let normal_analog_clock_time_pointer_second = ''
        let idle_background_bg = ''
        let idle_system_disconnect_img = ''
        let idle_battery_text_text_img = ''
        let idle_digital_clock_img_time = ''
        let idle_digital_clock_hour_separator_img = ''


        //dynamic modify end

        //not required
        const logger = DeviceRuntimeCore.HmLogger.getLogger("yeguang");

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({

          init_view() {

            //dynamic modify start
                    
            
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 466,
              h: 466,
              src: '24.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_stress_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: -7,
              y: -5,
              src: '24.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_dnd_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 94,
              y: 312,
              src: 'icon_DND_lightgrey.png',
              type: hmUI.system_status.DISTURB,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 65,
              y: 215,
              src: 'icon_bluetooth_lightgrey.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 197,
              y: 92,
              font_array: ["digi_gina_grey5small_0001.png","digi_gina_grey5small_0002.png","digi_gina_grey5small_0003.png","digi_gina_grey5small_0004.png","digi_gina_grey5small_0005.png","digi_gina_grey5small_0006.png","digi_gina_grey5small_0007.png","digi_gina_grey5small_0008.png","digi_gina_grey5small_0009.png","digi_gina_grey5small_0010.png"],
              padding: false,
              h_space: -30,
              unit_sc: 'digi_gina_grey5small_0011.png',
              unit_tc: 'digi_gina_grey5small_0011.png',
              unit_en: 'digi_gina_grey5small_0011.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 167,
              day_startY: 291,
              day_sc_array: ["digi_gina_grey12medium_0001.png","digi_gina_grey12medium_0002.png","digi_gina_grey12medium_0003.png","digi_gina_grey12medium_0004.png","digi_gina_grey12medium_0005.png","digi_gina_grey12medium_0006.png","digi_gina_grey12medium_0007.png","digi_gina_grey12medium_0008.png","digi_gina_grey12medium_0009.png","digi_gina_grey12medium_0010.png"],
              day_tc_array: ["digi_gina_grey12medium_0001.png","digi_gina_grey12medium_0002.png","digi_gina_grey12medium_0003.png","digi_gina_grey12medium_0004.png","digi_gina_grey12medium_0005.png","digi_gina_grey12medium_0006.png","digi_gina_grey12medium_0007.png","digi_gina_grey12medium_0008.png","digi_gina_grey12medium_0009.png","digi_gina_grey12medium_0010.png"],
              day_en_array: ["digi_gina_grey12medium_0001.png","digi_gina_grey12medium_0002.png","digi_gina_grey12medium_0003.png","digi_gina_grey12medium_0004.png","digi_gina_grey12medium_0005.png","digi_gina_grey12medium_0006.png","digi_gina_grey12medium_0007.png","digi_gina_grey12medium_0008.png","digi_gina_grey12medium_0009.png","digi_gina_grey12medium_0010.png"],
              day_zero: 1,
              day_space: -71,
              day_align: hmUI.align.LEFT,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_month_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 182,
              month_startY: 346,
              month_sc_array: ["digi_gina_month_5_0013.png","digi_gina_month_5_0014.png","digi_gina_month_5_0015.png","digi_gina_month_5_0016.png","digi_gina_month_5_0017.png","digi_gina_month_5_0018.png","digi_gina_month_5_0019.png","digi_gina_month_5_0020.png","digi_gina_month_5_0021.png","digi_gina_month_5_0022.png","digi_gina_month_5_0023.png","digi_gina_month_5_0024.png"],
              month_tc_array: ["digi_gina_month_5_0013.png","digi_gina_month_5_0014.png","digi_gina_month_5_0015.png","digi_gina_month_5_0016.png","digi_gina_month_5_0017.png","digi_gina_month_5_0018.png","digi_gina_month_5_0019.png","digi_gina_month_5_0020.png","digi_gina_month_5_0021.png","digi_gina_month_5_0022.png","digi_gina_month_5_0023.png","digi_gina_month_5_0024.png"],
              month_en_array: ["digi_gina_month_5_0013.png","digi_gina_month_5_0014.png","digi_gina_month_5_0015.png","digi_gina_month_5_0016.png","digi_gina_month_5_0017.png","digi_gina_month_5_0018.png","digi_gina_month_5_0019.png","digi_gina_month_5_0020.png","digi_gina_month_5_0021.png","digi_gina_month_5_0022.png","digi_gina_month_5_0023.png","digi_gina_month_5_0024.png"],
              month_is_character: true ,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 131,
              hour_startY: 90,
              hour_array: ["digi_gina_grey12medium_0001.png","digi_gina_grey12medium_0002.png","digi_gina_grey12medium_0003.png","digi_gina_grey12medium_0004.png","digi_gina_grey12medium_0005.png","digi_gina_grey12medium_0006.png","digi_gina_grey12medium_0007.png","digi_gina_grey12medium_0008.png","digi_gina_grey12medium_0009.png","digi_gina_grey12medium_0010.png"],
              hour_zero: 1,
              hour_space: -75,
              hour_align: hmUI.align.LEFT,

              minute_startX: 211,
              minute_startY: 91,
              minute_array: ["digi_gina_grey12medium_0001.png","digi_gina_grey12medium_0002.png","digi_gina_grey12medium_0003.png","digi_gina_grey12medium_0004.png","digi_gina_grey12medium_0005.png","digi_gina_grey12medium_0006.png","digi_gina_grey12medium_0007.png","digi_gina_grey12medium_0008.png","digi_gina_grey12medium_0009.png","digi_gina_grey12medium_0010.png"],
              minute_zero: 1,
              minute_space: -75,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_hour_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 190,
              y: 84,
              src: 'digi_gina_grey12medium_0011.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_hour = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              hour_path: '0001.png',
              hour_centerX: 233,
              hour_centerY: 233,
              hour_posX: 27,
              hour_posY: 146,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_minute = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              minute_path: '0002.png',
              minute_centerX: 233,
              minute_centerY: 233,
              minute_posX: 27,
              minute_posY: 209,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_second = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              second_path: 'Picture26.png',
              second_centerX: 233,
              second_centerY: 233,
              second_posX: 13,
              second_posY: 203,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            idle_background_bg = hmUI.createWidget(hmUI.widget.FILL_RECT, {
              x: 0,
              y: 0,
              w: 466,
              h: 466,
              color: '0xFF000000',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 65,
              y: 215,
              src: 'icon_bluetooth_lightgrey.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 197,
              y: 92,
              font_array: ["digi_gina_grey5small_0001.png","digi_gina_grey5small_0002.png","digi_gina_grey5small_0003.png","digi_gina_grey5small_0004.png","digi_gina_grey5small_0005.png","digi_gina_grey5small_0006.png","digi_gina_grey5small_0007.png","digi_gina_grey5small_0008.png","digi_gina_grey5small_0009.png","digi_gina_grey5small_0010.png"],
              padding: false,
              h_space: -30,
              unit_sc: 'digi_gina_grey5small_0011.png',
              unit_tc: 'digi_gina_grey5small_0011.png',
              unit_en: 'digi_gina_grey5small_0011.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 131,
              hour_startY: 90,
              hour_array: ["digi_gina_grey12medium_0001.png","digi_gina_grey12medium_0002.png","digi_gina_grey12medium_0003.png","digi_gina_grey12medium_0004.png","digi_gina_grey12medium_0005.png","digi_gina_grey12medium_0006.png","digi_gina_grey12medium_0007.png","digi_gina_grey12medium_0008.png","digi_gina_grey12medium_0009.png","digi_gina_grey12medium_0010.png"],
              hour_zero: 1,
              hour_space: -75,
              hour_align: hmUI.align.LEFT,

              minute_startX: 211,
              minute_startY: 91,
              minute_array: ["digi_gina_grey12medium_0001.png","digi_gina_grey12medium_0002.png","digi_gina_grey12medium_0003.png","digi_gina_grey12medium_0004.png","digi_gina_grey12medium_0005.png","digi_gina_grey12medium_0006.png","digi_gina_grey12medium_0007.png","digi_gina_grey12medium_0008.png","digi_gina_grey12medium_0009.png","digi_gina_grey12medium_0010.png"],
              minute_zero: 1,
              minute_space: -75,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_hour_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 190,
              y: 84,
              src: 'digi_gina_grey12medium_0011.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });


            //dynamic modify end
          },

          onInit() {
            console.log('index page.js on init invoke')

            this.init_view()

          },

          onReady() {
            console.log('index page.js on ready invoke')
          },

          onShow() {
            console.log('index page.js on show invoke')
          },

          onHide() {
            console.log('index page.js on hide invoke')
          },

          onDestory() {
            console.log('index page.js on destory invoke')
          },
        });

      })()
    } catch (e) {
      console.log(e)
    }
  