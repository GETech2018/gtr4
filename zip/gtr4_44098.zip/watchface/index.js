﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        //const logger = Logger.getLogger('watchface_SashaCX75');
        const logger = DeviceRuntimeCore.HmLogger.getLogger('watchface_SashaCX75')
        //end of ignored block

        //dynamic modify start
		
		function read_pressure() {
      console.log("read_pressure()");
      const file_name_alt = "../../../baro_altim/pressure.dat";
      const [fs_stat, err] = hmFS.stat(file_name_alt);
      if (err == 0) {
        let file_size = fs_stat.size;
        const len = file_size / 4;
        console.log(`size_alt: ${file_size}, lenght: ${len}`)
        const fh = hmFS.open(file_name_alt, hmFS.O_RDONLY)
      
        let array_buffer = new Float32Array(len);
        hmFS.read(fh, array_buffer.buffer, 0, file_size);
        hmFS.close(fh);
        console.log(`value ${array_buffer[array_buffer.length -1]}`);
        return array_buffer;
      } else {
        console.log('err:', err)
      }
      return null;
      }
      
      function getPressureValue(pressure_array) {
      console.log("getPressureValue()");
      if(pressure_array == null || pressure_array == undefined || pressure_array.length == 0) return 0;
      let start_index = pressure_array.length - 1;
      let end_index = start_index - 30*3; // 3 часа
      if(end_index < 0) end_index = 0;
      for (let index = start_index; index >= end_index; index--) {
        if(pressure_array[index] != 0) return parseInt(pressure_array[index] / 100);
      }
      return 0;
      }
      
      function hPa_To_mmHg(hPa_value = 0) {
      let mmHg = Math.round(hPa_value * 0.750064);
      return mmHg;
      }
      
      function getPressureMMHG() {
      const pressure_array = read_pressure();
      const val = hPa_To_mmHg(getPressureValue(pressure_array));		// получаем давление и переводим в мм рт. ст.
          
      return val
      }
      
      function updatePressure() {
      normal_altimeter_text_text_img.setProperty({
              x: 91,
              y: 125,
              font_array: ["A100_005.png","A100_006.png","A100_007.png","A100_008.png","A100_009.png","A100_010.png","A100_011.png","A100_012.png","A100_013.png","A100_014.png"],
              padding: false,
              h_space: 0,
              text: getPressureMMHG(),
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
      }

        
        let normal_background_bg_img = ''
        let normal_bio_charge_icon_img = ''
        let normal_date_img_date_week_img = ''
        let normal_date_img_date_day = ''
        let normal_battery_text_text_img = ''
        let normal_altimeter_icon_img = ''
        let normal_altitude_target_text_img = ''
        let normal_altimeter_text_text_img = ''
        let normal_digital_clock_img_time = ''
        let idle_background_bg = ''
        let idle_bio_charge_icon_img = ''
        let idle_digital_clock_img_time = ''
        let Button_1 = ''
        let Button_2 = ''
        let Button_3 = ''
        let Button_4 = ''
        let Button_5 = ''
        let Button_6 = ''
        let Button_7 = ''
        let Button_8 = ''
        let Button_9 = ''
        let Button_10 = ''
        let Button_11 = ''
        let Button_12 = ''


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            console.log('Watch_Face.ScreenNormal');
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 466,
              h: 466,
              src: 'A100_002.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_bio_charge_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 288,
              y: 381,
              src: 'tel.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 155,
              y: 29,
              week_en: ["A100_019.png","A100_020.png","A100_021.png","A100_022.png","A100_023.png","A100_024.png","A100_025.png"],
              week_tc: ["A100_019.png","A100_020.png","A100_021.png","A100_022.png","A100_023.png","A100_024.png","A100_025.png"],
              week_sc: ["A100_019.png","A100_020.png","A100_021.png","A100_022.png","A100_023.png","A100_024.png","A100_025.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 239,
              day_startY: 28,
              day_sc_array: ["A100_026.png","A100_027.png","A100_028.png","A100_029.png","A100_030.png","A100_031.png","A100_032.png","A100_033.png","A100_034.png","A100_035.png"],
              day_tc_array: ["A100_026.png","A100_027.png","A100_028.png","A100_029.png","A100_030.png","A100_031.png","A100_032.png","A100_033.png","A100_034.png","A100_035.png"],
              day_en_array: ["A100_026.png","A100_027.png","A100_028.png","A100_029.png","A100_030.png","A100_031.png","A100_032.png","A100_033.png","A100_034.png","A100_035.png"],
              day_zero: 1,
              day_space: -1,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 362,
              y: 125,
              font_array: ["A100_005.png","A100_006.png","A100_007.png","A100_008.png","A100_009.png","A100_010.png","A100_011.png","A100_012.png","A100_013.png","A100_014.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_altimeter_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 47,
              y: 86,
              src: 'pol.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_altitude_target_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 230,
              y: 125,
              font_array: ["A100_005.png","A100_006.png","A100_007.png","A100_008.png","A100_009.png","A100_010.png","A100_011.png","A100_012.png","A100_013.png","A100_014.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.ALTITUDE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_altimeter_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 91,
              y: 125,
              font_array: ["A100_005.png","A100_006.png","A100_007.png","A100_008.png","A100_009.png","A100_010.png","A100_011.png","A100_012.png","A100_013.png","A100_014.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.LEFT,
              text: getPressureMMHG(),
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 4,
              hour_startY: 189,
              hour_array: ["A100_038.png","A100_039.png","A100_040.png","A100_041.png","A100_042.png","A100_043.png","A100_044.png","A100_045.png","A100_046.png","A100_047.png"],
              hour_zero: 1,
              hour_space: -4,
              hour_angle: 0,
              hour_align: hmUI.align.CENTER_H,

              minute_startX: 163,
              minute_startY: 189,
              minute_array: ["A100_038.png","A100_039.png","A100_040.png","A100_041.png","A100_042.png","A100_043.png","A100_044.png","A100_045.png","A100_046.png","A100_047.png"],
              minute_zero: 1,
              minute_space: -4,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.CENTER_H,

              second_startX: 322,
              second_startY: 189,
              second_array: ["A100_038.png","A100_039.png","A100_040.png","A100_041.png","A100_042.png","A100_043.png","A100_044.png","A100_045.png","A100_046.png","A100_047.png"],
              second_zero: 1,
              second_space: -4,
              second_angle: 0,
              second_follow: 0,
              second_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            console.log('Watch_Face.ScreenAOD');
            idle_background_bg = hmUI.createWidget(hmUI.widget.FILL_RECT, {
              x: 0,
              y: 0,
              w: 466,
              h: 466,
              color: '0xFF000000',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_bio_charge_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 80,
              y: 185,
              src: 'tab.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 85,
              hour_startY: 189,
              hour_array: ["A100_038.png","A100_039.png","A100_040.png","A100_041.png","A100_042.png","A100_043.png","A100_044.png","A100_045.png","A100_046.png","A100_047.png"],
              hour_zero: 1,
              hour_space: -4,
              hour_angle: 0,
              hour_align: hmUI.align.CENTER_H,

              minute_startX: 244,
              minute_startY: 189,
              minute_array: ["A100_038.png","A100_039.png","A100_040.png","A100_041.png","A100_042.png","A100_043.png","A100_044.png","A100_045.png","A100_046.png","A100_047.png"],
              minute_zero: 1,
              minute_space: -4,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.CENTER_H,

              show_level: hmUI.show_level.ONLY_AOD,
            });

            console.log('Watch_Face.Buttons');
            Button_1 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 156,
              y: 30,
              w: 153,
              h: 48,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'ScheduleCalScreen', native: true });
              }, // end func
              longpress_func: (button_widget) => {
                hmApp.startApp({ appid: 1057409, url: 'page/index' });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_2 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 42,
              y: 113,
              w: 122,
              h: 48,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'BaroAltimeterScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_3 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 182,
              y: 113,
              w: 122,
              h: 48,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'TideScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_4 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 324,
              y: 113,
              w: 122,
              h: 48,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'Settings_batteryManagerScreen', native: true });
              }, // end func
              longpress_func: (button_widget) => {
                hmApp.startApp({url: 'FindPhoneScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_5 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 109,
              y: 386,
              w: 122,
              h: 48,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'PhoneContactsScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_6 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 238,
              y: 386,
              w: 122,
              h: 48,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'PhoneHomeScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_7 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 62,
              y: 318,
              w: 52,
              h: 48,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'activityAppScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_8 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 122,
              y: 318,
              w: 52,
              h: 48,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'oneKeyAppScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_9 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 181,
              y: 318,
              w: 52,
              h: 48,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'SportListScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_10 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 242,
              y: 318,
              w: 52,
              h: 48,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'AlarmInfoScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_11 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 302,
              y: 318,
              w: 52,
              h: 48,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'CountdownAppScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_12 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 365,
              y: 318,
              w: 52,
              h: 48,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'StopWatchScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button


                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}