﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        const logger = Logger.getLogger('watchface_SashaCX75');
        //end of ignored block

        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_group_ForecastWeather = ''
        
        let normal_forecast_date_font = new Array(4);
        let normal_forecast_date_week_font = new Array(4);
        let normal_forecast_date_week_font_Array = ['ПНД', 'ВТР', 'СРД', 'ЧТВ', 'ПТН', 'СБТ', 'ВСК'];
        let normal_forecast_low_text_font = new Array(4);
        let normal_forecast_high_text_font = new Array(4);
        let normal_forecast_image_progress_img_level = new Array(4);
        let normal_forecast_image_array = ['wm_0.png', 'wm_1.png', 'wm_2.png', 'wm_3.png', 'wm_4.png', 'wm_5.png', 'wm_6.png', 'wm_7.png', 'wm_8.png', 'wm_9.png', 'wm_10.png', 'wm_11.png', 'wm_12.png', 'wm_13.png', 'wm_14.png', 'wm_15.png', 'wm_16.png', 'wm_17.png', 'wm_18.png', 'wm_19.png', 'wm_20.png', 'wm_21.png', 'wm_22.png', 'wm_23.png', 'wm_24.png', 'wm_25.png', 'wm_26.png', 'wm_27.png', 'wm_28.png'];
        let normal_step_icon_img = ''
        let normal_step_linear_scale = ''
        let normal_step_current_text_font = ''
        let normal_time_hour_min_text_font = ''
        let normal_timerTimeUpdate = undefined;
        let normal_dow_text_font = ''
        let normal_DOW_Array = ['ПНД', 'ВТР', 'СРД', 'ЧТВ', 'ПТН', 'СБТ', 'ВСК'];
        let normal_day_text_font = ''
        let normal_month_name_font = ''
        let normal_Month_Array = ['ЯНВАРЬ', 'ФЕВРАЛЬ', 'МАРТ', 'АПРЕЛЬ', 'МАЙ', 'ИЮНЬ', 'ИЮЛЬ', 'АВГУСТ', 'СЕНТЯБРЬ', 'ОКТЯБРЬ', 'НОЯБРЬ', 'ДЕКАБРЬ', ];
        let normal_city_name_text = ''
        let normal_weather_image_progress_img_level = ''
        let normal_temperature_low_text_font = ''
        let normal_temperature_high_text_font = ''
        let normal_temperature_current_text_font = ''
        let normal_wind_direction_image_progress_img_level = ''
        let normal_wind_current_text_font = ''
        let normal_battery_linear_scale = ''
        let normal_battery_current_text_font = ''
        let timeSensor = ''
        
      let shotWeaterhNames = ["ОБЛАЧНО", "МЕСТАМИ ДОЖДЬ", "МЕСТАМИ СНЕГ", "CОЛНЕЧНО", "ПАСМУРНО", "СЛАБЫЙ ДОЖДЬ", "СЛАБЫЙ СНЕГ", "УМЕРЕННЫЙ ДОЖДЬ", "УМЕРЕННЫЙ СНЕГ", "СИЛЬНЫЙ СНЕГОПАД", "СИЛЬНЫЙ ДОЖДЬ", "ПЕСЧАНАЯ БУРЯ", "МОКРЫЙ СНЕГ", "ТУМАН", "ДЫМКА", "ДОЖДЬ С ГРОЗОЙ", "МЕТЕЛЬ", "ВЕТЕР", "ЛИВЕНЬ", "ДОЖДЬ С ГРАДОМ", "СИЛЬНЫЙ ДОЖДЬ С ГРАДОМ", "СИЛЬНЫЙ ДОЖДЬ ", "СИЛЬНЫЙ ВЕТЕР", "СИЛЬНАЯ ПЕСЧАНАЯ БУРЯ ", "СИЛЬНЫЙ ДОЖДЬ", "НЕИЗВЕСТНАЯ ПОГОДА", "ОБЛАЧНО НОЧЬЮ", "ДОЖДЛИВО НОЧЬЮ", "ЯСНО НОЧЬЮ"];        

		      let isDayIcons = false

        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            // FontName: Montserrat_Medium.ttf; FontSize: 17
            hmUI.createWidget(hmUI.widget.TEXT, {
              x: 464,
              y: 464,
              w: 238,
              h: 28,
              text_size: 17,
              char_space: 0,
              line_space: 0,
              font: 'fonts/Montserrat_Medium.ttf',
              color: 0xFFC8C8C8,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              text: "0123456789 _-.,:;`'%°\\/",
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
				
            hmUI.createWidget(hmUI.widget.TEXT, {
              x: 464,
              y: 464,
              w: 238,
              h: 28,
              text_size: 25,
              char_space: 0,
              line_space: 0,
              font: 'fonts/Montserrat_Medium.ttf',
              color: 0xFFC8C8C8,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              text: "0123456789 _-.,:;`'%°\\/",
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
				
				

            // FontName: Montserrat_Medium.ttf; FontSize: 21
            hmUI.createWidget(hmUI.widget.TEXT, {
              x: 464,
              y: 464,
              w: 297,
              h: 34,
              text_size: 21,
              char_space: 0,
              line_space: 0,
              font: 'fonts/Montserrat_Medium.ttf',
              color: 0xFFC8C8C8,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              text: "0123456789 _-.,:;`'%°\\/",
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // FontName: Montserrat_Medium.ttf; FontSize: 23
            hmUI.createWidget(hmUI.widget.TEXT, {
              x: 464,
              y: 464,
              w: 321,
              h: 38,
              text_size: 23,
              char_space: 0,
              line_space: 0,
              font: 'fonts/Montserrat_Medium.ttf',
              color: 0xFFFFFFFF,
              align_h: hmUI.align.LEFT,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              text: "0123456789 _-.,:;`'%°\\/",
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // FontName: Montserrat_Medium.ttf; FontSize: 86
            hmUI.createWidget(hmUI.widget.TEXT, {
              x: 464,
              y: 464,
              w: 1200,
              h: 141,
              text_size: 86,
              char_space: 0,
              line_space: 0,
              font: 'fonts/Montserrat_Medium.ttf',
              color: 0xFFFFFFFF,
              align_h: hmUI.align.LEFT,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              text: "0123456789 _-.,:;`'%°\\/",
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // FontName: Montserrat_Medium.ttf; FontSize: 36; Cache: full
            hmUI.createWidget(hmUI.widget.TEXT, {
              x: 464,
              y: 464,
              w: 43,
              h: 43,
              text_size: 36,
              char_space: 0,
              line_space: 0,
              font: 'fonts/Montserrat_Medium.ttf',
              color: 0xFFC8C8C8,
              align_h: hmUI.align.RIGHT,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.NONE,
              text: "0123456789 ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz АБВГДЕЁЖЗИЙКЛМНОПРСТУФХЦЧШЩЪЫЬЭЮЯабвгдеёжзийклмнопрстуфхцчшщъыьэюя  ҐЄІЇґєії _-.,:;`'%°\\/",
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // FontName: Montserrat_Medium.ttf; FontSize: 46
            hmUI.createWidget(hmUI.widget.TEXT, {
              x: 464,
              y: 464,
              w: 640,
              h: 75,
              text_size: 46,
              char_space: 0,
              line_space: 0,
              font: 'fonts/Montserrat_Medium.ttf',
              color: 0xFFFFFFFF,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              text: "0123456789 _-.,:;`'%°\\/",
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // FontName: Montserrat_Medium.ttf; FontSize: 22; Cache: full
            hmUI.createWidget(hmUI.widget.TEXT, {
              x: 464,
              y: 464,
              w: 26,
              h: 26,
              text_size: 22,
              char_space: 0,
              line_space: 0,
              font: 'fonts/Montserrat_Medium.ttf',
              color: 0xFF969696,
              align_h: hmUI.align.RIGHT,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.NONE,
              text: "0123456789 ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz АБВГДЕЁЖЗИЙКЛМНОПРСТУФХЦЧШЩЪЫЬЭЮЯабвгдеёжзийклмнопрстуфхцчшщъыьэюя  ҐЄІЇґєії _-.,:;`'%°\\/",
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // FontName: Montserrat_Medium.ttf; FontSize: 32; Cache: full
            hmUI.createWidget(hmUI.widget.TEXT, {
              x: 464,
              y: 464,
              w: 38,
              h: 38,
              text_size: 25,
              char_space: 0,
              line_space: 0,
              font: 'fonts/gothland.ttf',
              color: 0xFFCCCCCC,
              align_h: hmUI.align.LEFT,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.NONE,
              text: "0123456789 ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz АБВГДЕЁЖЗИЙКЛМНОПРСТУФХЦЧШЩЪЫЬЭЮЯабвгдеёжзийклмнопрстуфхцчшщъыьэюя  ҐЄІЇґєії _-.,:;`'%°\\/",
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // FontName: Montserrat_Regular.ttf; FontSize: 24
            hmUI.createWidget(hmUI.widget.TEXT, {
              x: 464,
              y: 464,
              w: 331,
              h: 39,
              text_size: 24,
              char_space: 0,
              line_space: 0,
              font: 'fonts/Montserrat_Regular.ttf',
              color: 0xFFFFFFFF,
              align_h: hmUI.align.LEFT,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              text: "0123456789 _-.,:;`'%°\\/",
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // FontName: Montserrat_Regular.ttf; FontSize: 46
            hmUI.createWidget(hmUI.widget.TEXT, {
              x: 464,
              y: 464,
              w: 630,
              h: 75,
              text_size: 46,
              char_space: 0,
              line_space: 0,
              font: 'fonts/Montserrat_Regular.ttf',
              color: 0xFFFFFFFF,
              align_h: hmUI.align.RIGHT,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              text: "0123456789 _-.,:;`'%°\\/",
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            console.log('Watch_Face.ScreenNormal');
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 466,
              h: 466,
              src: 'bg.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            let screenType = hmSetting.getScreenType();            
            // normal_Weather_FewDays = hmUI.createWidget(hmUI.widget.FewDays, {
              // x: 141,
              // y: 309,
              // ColumnWidth: 74,
              // DaysCount: 4,
            // });
            
            normal_group_ForecastWeather = hmUI.createWidget(hmUI.widget.GROUP, {
              x: 141,
              y: 309,
              h: 0,
              w: 0,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_forecast_date_week_font = normal_group_ForecastWeather.createWidget(hmUI.widget.TEXT_Options, {
              // x: -44,
              // y: -77,
              // w: 150,
              // h: 30,
              // text_size: 17,
              // char_space: 0,
              // line_space: 0,
              // alpha: 255,
              // font: 'fonts/Montserrat_Medium.ttf',
              // color: 0xFFC8C8C8,
              // color_2: 0xFFFF0000,
              // use_color_2: False,
              // align_h: hmUI.align.CENTER_H,
              // align_v: hmUI.align.CENTER_V,
              // text_style: hmUI.text_style.ELLIPSIS,
              // type: hmUI.data_type.forecast_date_week_img,
              // unit_type: 1,
              // unit_string: ПНД, ВТР, СРД, ЧТВ, ПТН, СБТ, ВСК,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            //start of ignored block
            if (screenType == hmSetting.screen_type.WATCHFACE) {
              for (let i = 0; i < 4; i++) {
                normal_forecast_date_font[i] = normal_group_ForecastWeather.createWidget(hmUI.widget.TEXT, {
                  x: -44 + i*74,
                  y: -77-30+7,
                  w: 150,
                  h: 30,
                  text: 20,
                  text_size: 25,
                  char_space: 0,
                  line_space: 0,
                  font: 'fonts/Montserrat_Medium.ttf',
                  color: 0xFFFFFFFF,
                  // color_2: 0xFFFF0000,
                  align_h: hmUI.align.CENTER_H,
                  align_v: hmUI.align.CENTER_V,
                  text_style: hmUI.text_style.ELLIPSIS,
                  // unit_type: 1,
                  // unit_string: ПНД, ВТР, СРД, ЧТВ, ПТН, СБТ, ВСК,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });                  
                  
                normal_forecast_date_week_font[i] = normal_group_ForecastWeather.createWidget(hmUI.widget.TEXT, {
                  x: -44 + i*74,
                  y: -77,
                  w: 150,
                  h: 30,
                  text_size: 17,
                  char_space: 0,
                  line_space: 0,
                  font: 'fonts/Montserrat_Medium.ttf',
                  color: 0xFFC8C8C8,
                  // color_2: 0xFFFF0000,
                  align_h: hmUI.align.CENTER_H,
                  align_v: hmUI.align.CENTER_V,
                  text_style: hmUI.text_style.ELLIPSIS,
                  // unit_type: 1,
                  // unit_string: ПНД, ВТР, СРД, ЧТВ, ПТН, СБТ, ВСК,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });
              };
            };
            //end of ignored block

            if (!timeSensor) timeSensor = hmSensor.createSensor(hmSensor.id.TIME);
            // normal_forecast_low_text_font = normal_group_ForecastWeather.createWidget(hmUI.widget.TEXT_Options, {
              // x: -44,
              // y: 17,
              // w: 150,
              // h: 30,
              // text_size: 21,
              // char_space: 0,
              // line_space: 0,
              // alpha: 255,
              // font: 'fonts/Montserrat_Medium.ttf',
              // color: 0xFFC8C8C8,
              // color_2: 0xFFFF0000,
              // use_color_2: False,
              // align_h: hmUI.align.CENTER_H,
              // align_v: hmUI.align.CENTER_V,
              // text_style: hmUI.text_style.ELLIPSIS,
              // type: hmUI.data_type.forecast_low_text_font,
              // unit_type: 1,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            //start of ignored block
            if (screenType == hmSetting.screen_type.WATCHFACE) {
              for (let i = 0; i < 4; i++) {
                normal_forecast_low_text_font[i] = normal_group_ForecastWeather.createWidget(hmUI.widget.TEXT, {
                  x: -44 + i*74,
                  y: 17,
                  w: 150,
                  h: 30,
                  text_size: 21,
                  char_space: 0,
                  line_space: 0,
                  font: 'fonts/Montserrat_Medium.ttf',
                  color: 0xFFC8C8C8,
                  align_h: hmUI.align.CENTER_H,
                  align_v: hmUI.align.CENTER_V,
                  text_style: hmUI.text_style.ELLIPSIS,
                  // unit_type: 1,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });
              };
            };
            //end of ignored block

            // normal_forecast_high_text_font = normal_group_ForecastWeather.createWidget(hmUI.widget.TEXT_Options, {
              // x: -44,
              // y: -7,
              // w: 150,
              // h: 30,
              // text_size: 21,
              // char_space: 0,
              // line_space: 0,
              // alpha: 255,
              // font: 'fonts/Montserrat_Medium.ttf',
              // color: 0xFFC8C8C8,
              // color_2: 0xFFFF0000,
              // use_color_2: False,
              // align_h: hmUI.align.CENTER_H,
              // align_v: hmUI.align.CENTER_V,
              // text_style: hmUI.text_style.ELLIPSIS,
              // type: hmUI.data_type.forecast_high_text_font,
              // unit_type: 1,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            //start of ignored block
            if (screenType == hmSetting.screen_type.WATCHFACE) {
              for (let i = 0; i < 4; i++) {
                normal_forecast_high_text_font[i] = normal_group_ForecastWeather.createWidget(hmUI.widget.TEXT, {
                  x: -44 + i*74,
                  y: -7,
                  w: 150,
                  h: 30,
                  text_size: 21,
                  char_space: 0,
                  line_space: 0,
                  font: 'fonts/Montserrat_Medium.ttf',
                  color: 0xFFC8C8C8,
                  align_h: hmUI.align.CENTER_H,
                  align_v: hmUI.align.CENTER_V,
                  text_style: hmUI.text_style.ELLIPSIS,
                  // unit_type: 1,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });
              };
            };
            //end of ignored block

            // normal_forecast_image_progress_img_level = normal_group_ForecastWeather.createWidget(hmUI.widget.IMG_LEVEL_Options, {
              // x: 9,
              // y: -45,
              // image_array: ["wm_0.png","wm_1.png","wm_2.png","wm_3.png","wm_4.png","wm_5.png","wm_6.png","wm_7.png","wm_8.png","wm_9.png","wm_10.png","wm_11.png","wm_12.png","wm_13.png","wm_14.png","wm_15.png","wm_16.png","wm_17.png","wm_18.png","wm_19.png","wm_20.png","wm_21.png","wm_22.png","wm_23.png","wm_24.png","wm_25.png","wm_26.png","wm_27.png","wm_28.png"],
              // image_length: 29,
              // type: hmUI.data_type.forecast_image,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            //start of ignored block
            if (screenType == hmSetting.screen_type.WATCHFACE) {
              for (let i = 0; i < 4; i++) {
                normal_forecast_image_progress_img_level[i] = normal_group_ForecastWeather.createWidget(hmUI.widget.IMG, {
                  x: 9 + i*74,
                  y: -45,
                  src: normal_forecast_image_array[25],
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });
              };
            };
            //end of ignored block

            normal_step_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 67,
              y: 197,
              src: 'cap_forecast.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            if (screenType != hmSetting.screen_type.AOD) {
              normal_step_linear_scale = hmUI.createWidget(hmUI.widget.FILL_RECT);
            };

            // normal_step_linear_scale = hmUI.createWidget(hmUI.widget.Linear_Scale, {
              // start_x: 247,
              // start_y: 445,
              // color: 0xFFFFFFFF,
              // lenght: -52,
              // line_width: 20,
              // line_cap: Flat,
              // vertical: True,
              // mirror: False,
              // inversion: False,
              // type: hmUI.data_type.STEP,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });
            
            const step = hmSensor.createSensor(hmSensor.id.STEP);
            step.addEventListener(hmSensor.event.CHANGE, function() {
              scale_call();
            });

            normal_step_current_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 277,
              y: 376,
              w: 150,
              h: 50,
              text_size: 23,
              char_space: 0,
              line_space: 0,
              font: 'fonts/Montserrat_Medium.ttf',
              color: 0xFFFFFFFF,
              align_h: hmUI.align.LEFT,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_time_hour_min_text_font = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 0,
              y: 29,
              w: 466,
              h: 100,
              text_size: 86,
              char_space: 0,
              line_space: 0,
              font: 'fonts/Montserrat_Medium.ttf',
              color: 0xFFFFFFFF,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            timeSensor.addEventListener(timeSensor.event.DAYCHANGE, function() {
              time_update(true);
            });

            normal_dow_text_font = hmUI.createWidget(hmUI.widget.TEXT, {
              x: -30,
              y: 142,
              w: 150,
              h: 50,
              text_size: 36,
              char_space: 0,
              line_space: 0,
              font: 'fonts/Montserrat_Medium.ttf',
              color: 0xFFC8C8C8,
              align_h: hmUI.align.RIGHT,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              // unit_string: ПНД, ВТР, СРД, ЧТВ, ПТН, СБТ, ВСК,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_day_text_font = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 80,
              y: 142,
              w: 150,
              h: 50,
              text_size: 46,
              char_space: 0,
              line_space: 0,
              font: 'fonts/Montserrat_Medium.ttf',
              color: 0xFFFFFFFF,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_month_name_font = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 48,
              y: 194,
              w: 150,
              h: 30,
              text_size: 22,
              char_space: 0,
              line_space: 0,
              font: 'fonts/Montserrat_Medium.ttf',
              color: 0xFF969696,
              align_h: hmUI.align.RIGHT,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              // unit_string: ЯНВАРЬ, ФЕВРАЛЬ, МАРТ, АПРЕЛЬ, МАЙ, ИЮНЬ, ИЮЛЬ, АВГУСТ, СЕНТЯБРЬ, ОКТЯБРЬ, НОЯБРЬ, ДЕКАБРЬ,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
              const weatherSensor = hmSensor.createSensor(hmSensor.id.WEATHER);

            normal_city_name_text = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 219,
              y: 134,
              w: 226,
              h: 50,
              text_size: 25,
              char_space: 2,
              line_space: 0,
              font: 'fonts/gothland.ttf',
              color: 0xFFCCCCCC,
              align_h: hmUI.align.LEFT,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.NONE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 45,
              y: 295,
              image_array: ["w_0.png","w_1.png","w_2.png","w_3.png","w_4.png","w_5.png","w_6.png","w_7.png","w_8.png","w_9.png","w_10.png","w_11.png","w_12.png","w_13.png","w_14.png","w_15.png","w_16.png","w_17.png","w_18.png","w_19.png","w_20.png","w_21.png","w_22.png","w_23.png","w_24.png","w_25.png","w_26.png","w_27.png","w_28.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_low_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 157,
              y: 246,
              w: 150,
              h: 50,
              text_size: 24,
              char_space: 0,
              line_space: 0,
              font: 'fonts/Montserrat_Regular.ttf',
              color: 0xFFFFFFFF,
              align_h: hmUI.align.LEFT,
              align_v: hmUI.align.CENTER_V,
              unit_type: 1,
              text_style: hmUI.text_style.ELLIPSIS,
              type: hmUI.data_type.WEATHER_LOW,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_high_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 157,
              y: 217,
              w: 150,
              h: 50,
              text_size: 24,
              char_space: 0,
              line_space: 0,
              font: 'fonts/Montserrat_Regular.ttf',
              color: 0xFFFFFFFF,
              align_h: hmUI.align.LEFT,
              align_v: hmUI.align.CENTER_V,
              unit_type: 1,
              text_style: hmUI.text_style.ELLIPSIS,
              type: hmUI.data_type.WEATHER_HIGH,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: -34,
              y: 229,
              w: 150,
              h: 50,
              text_size: 46,
              char_space: 0,
              line_space: 0,
              font: 'fonts/Montserrat_Regular.ttf',
              color: 0xFFFFFFFF,
              align_h: hmUI.align.RIGHT,
              align_v: hmUI.align.CENTER_V,
              unit_type: 1,
              text_style: hmUI.text_style.ELLIPSIS,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_wind_direction_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 128,
              y: 327,
              image_array: ["wind_0.png","wind_1.png","wind_2.png","wind_3.png","wind_4.png","wind_5.png","wind_6.png","wind_7.png"],
              image_length: 8,
              type: hmUI.data_type.WIND_DIRECTION,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_wind_current_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 157,
              y: 286,
              w: 150,
              h: 50,
              text_size: 24,
              char_space: 0,
              line_space: 0,
              font: 'fonts/Montserrat_Regular.ttf',
              color: 0xFFFFFFFF,
              align_h: hmUI.align.LEFT,
              align_v: hmUI.align.CENTER_V,
              unit_type: 1,
              text_style: hmUI.text_style.ELLIPSIS,
              type: hmUI.data_type.WIND,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
				
            normal_ALARM_CLOCK_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 318,
              y: 96,
              w: 150,
              h: 30,
              text_size: 22,
         padding: true,
				char_space: 0,
              line_space: 0,
              font: 'fonts/Montserrat_Medium.ttf',
              color: 0xFFFFFFFF,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              type: hmUI.data_type.ALARM_CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
				
            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 46,
              y: 100,
              src: 'stat_B_off.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });				
				
                
        normal_weather_text_font = hmUI.createWidget(hmUI.widget.TEXT, {
         x: 220,
         y: 170,
         w: 235,
         h: 33,
         text_size: 23,
         char_space: 0,
         line_space: 0,
          font: 'fonts/Montserrat_Medium.ttf',
         color: 0x969696,
         align_h: hmUI.align.LEFT,
         align_v: hmUI.align.CENTER_V,
         text_style: hmUI.text_style.NONE,
         show_level: hmUI.show_level.ONLY_NORMAL,
        })                
                
                

            if (screenType != hmSetting.screen_type.AOD) {
              normal_battery_linear_scale = hmUI.createWidget(hmUI.widget.FILL_RECT);
            };

            // normal_battery_linear_scale = hmUI.createWidget(hmUI.widget.Linear_Scale, {
              // start_x: 203,
              // start_y: 445,
              // color: 0xFFFFFFFF,
              // lenght: -52,
              // line_width: 20,
              // line_cap: Flat,
              // vertical: True,
              // mirror: False,
              // inversion: False,
              // type: hmUI.data_type.BATTERY,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });
            
            const battery = hmSensor.createSensor(hmSensor.id.BATTERY);
            battery.addEventListener(hmSensor.event.CHANGE, function() {
              scale_call();
            });

            normal_battery_current_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 42,
              y: 376,
              w: 150,
              h: 50,
              text_size: 23,
              char_space: 0,
              line_space: 0,
              font: 'fonts/Montserrat_Medium.ttf',
              color: 0xFFFFFFFF,
              align_h: hmUI.align.RIGHT,
              align_v: hmUI.align.CENTER_V,
              unit_type: 1,
              text_style: hmUI.text_style.ELLIPSIS,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });



            //start of ignored block
            function weather_few_days() {
              console.log('weather_few_days()');
       if (!timeSensor) timeSensor = hmSensor.createSensor(hmSensor.id.TIME);
       let day_num = [0, 31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31];
       let year = timeSensor.year;
       if (year % 4 == 0 && (year % 100 != 0 || year % 400 == 0)) { // Високосный год
        day_num[2] = 29
       } else {
        day_num[2] = 28
       }
        let data_gr = timeSensor.day;
        let month_gr = timeSensor.month;
                
                
              let weatherData = weatherSensor.getForecastWeather();
              let forecastData = weatherData.forecastData;
                

				
       sunData = weatherData.tideData;
       if (sunData.count > 0) {
        today = sunData.data[0];
        sunriseMins = today.sunrise.hour * 60 + today.sunrise.minute;
        sunsetMins = today.sunset.hour * 60 + today.sunset.minute;
       } else {
        sunriseMins = sunriseMins_def;
        sunsetMins = sunsetMins_def;
       }
       curMins = timeSensor.hour * 60 + timeSensor.minute;
       let isDayNow = (curMins >= sunriseMins) && (curMins < sunsetMins);

       if (isDayNow) {
        if (!isDayIcons) {
         isDayIcons = true;
        }
       } else {
        if (isDayIcons) {
         isDayIcons = false;
        }
       }   
				
       shotWeaterhNames = isDayIcons == false ? ["ОБЛАЧНО НОЧЬЮ", "МЕСТАМИ ДОЖДЬ", "МЕСТАМИ СНЕГ", "ЯСНО НОЧЬЮ", "ПАСМУРНО НОЧЬЮ", "СЛАБЫЙ ДОЖДЬ", "СЛАБЫЙ СНЕГ", "УМЕРЕННЫЙ ДОЖДЬ", "УМЕРЕННЫЙ СНЕГ", "СИЛЬНЫЙ СНЕГОПАД", "СИЛЬНЫЙ ДОЖДЬ", "ПЕСЧАНАЯ БУРЯ", "МОКРЫЙ СНЕГ", "ТУМАН", "ДЫМКА НОЧЬЮ", "ДОЖДЬ С ГРОЗОЙ", "МЕТЕЛЬ", "ВЕТЕР", "ЛИВЕНЬ", "ДОЖДЬ С ГРАДОМ", "СИЛЬНЫЙ ДОЖДЬ С ГРАДОМ", "СИЛЬНЫЙ ДОЖДЬ ", "ПЕСЧАНАЯ БУРЯ", "СИЛЬНЫЙ ВЕТЕР", "СИЛЬНЫЙ ДОЖДЬ", "НЕИЗВЕСТНАЯ ПОГОДА", "ОБЛАЧНО НОЧЬЮ", "ДОЖДЛИВО НОЧЬЮ", "ЯСНО НОЧЬЮ"] : ["ОБЛАЧНО", "МЕСТАМИ ДОЖДЬ", "МЕСТАМИ СНЕГ", "CОЛНЕЧНО", "ПАСМУРНО", "СЛАБЫЙ ДОЖДЬ", "СЛАБЫЙ СНЕГ", "УМЕРЕННЫЙ ДОЖДЬ", "УМЕРЕННЫЙ СНЕГ", "СИЛЬНЫЙ СНЕГОПАД", "СИЛЬНЫЙ ДОЖДЬ", "ПЕСЧАНАЯ БУРЯ", "МОКРЫЙ СНЕГ", "ТУМАН", "ДЫМКА", "ДОЖДЬ С ГРОЗОЙ", "МЕТЕЛЬ", "ВЕТЕР", "ЛИВЕНЬ", "ДОЖДЬ С ГРАДОМ", "СИЛЬНЫЙ ДОЖДЬ С ГРАДОМ", "СИЛЬНЫЙ ДОЖДЬ ", "ПЕСЧАНАЯ БУРЯ", "СИЛЬНЫЙ ВЕТЕР", "СИЛЬНЫЙ ДОЖДЬ", "НЕИЗВЕСТНАЯ ПОГОДА", "ОБЛАЧНО НОЧЬЮ", "ДОЖДЛИВО НОЧЬЮ", "ЯСНО НОЧЬЮ"];
				
				
       let curAirIconIndex = weatherSensor.curAirIconIndex;
       normal_weather_text_font.setProperty(hmUI.prop.TEXT, shotWeaterhNames[curAirIconIndex]); 				
                

              for (let i = 0; i < 4; i++) {
                // DayOfWeek font
                if (screenType == hmSetting.screen_type.WATCHFACE) {
                  let dowIndex = timeSensor.week - 1;
                  dowIndex += i;
                  while (dowIndex >= 7) {dowIndex -= 7;}
                  normal_forecast_date_week_font[i].setProperty(hmUI.prop.TEXT, normal_forecast_date_week_font_Array[dowIndex]);
                    
            normal_forecast_date_font[i].setProperty(hmUI.prop.TEXT, String(data_gr));            data_gr = (data_gr + 1)
         if (data_gr > day_num[month_gr]) data_gr = 1
                    
                };
              
                // Number_Font_Min
                let minTemperature = '-';
                if (i < forecastData.count) minTemperature = forecastData.data[i].low.toString();
                if (screenType == hmSetting.screen_type.WATCHFACE) {
                  normal_forecast_low_text_font[i].setProperty(hmUI.prop.TEXT, minTemperature + '°');
                };
                
                // Number_Font_Max
                let maxTemperature = '-';
                if (i < forecastData.count) maxTemperature = forecastData.data[i].high.toString();
                if (screenType == hmSetting.screen_type.WATCHFACE) {
                  normal_forecast_high_text_font[i].setProperty(hmUI.prop.TEXT, maxTemperature + '°');
                };
                
                // Images
                if (screenType == hmSetting.screen_type.WATCHFACE) {
                  let weatherIndex = 25
                  if (i < forecastData.count) weatherIndex = forecastData.data[i].index;
                  normal_forecast_image_progress_img_level[i].setProperty(hmUI.prop.SRC, normal_forecast_image_array[weatherIndex]);
                };
              
              };  // end for

            };
            //end of ignored block

            //start of ignored block
            function time_update(updateHour = false, updateMinute = false) {
              console.log('time_update()');
              let hour = timeSensor.hour;
              let minute = timeSensor.minute;
              let second = timeSensor.second;
              let format_hour = timeSensor.format_hour;

              console.log('hour:min font');
              if (updateMinute) {
                let normal_HourMinStr = format_hour.toString();
                normal_HourMinStr = normal_HourMinStr + ':' + minute.toString().padStart(2, '0')
                if (!timeSensor.is24Hour) {
                  if (hour > 11) normal_HourMinStr = 'pm ' + normal_HourMinStr
                  else normal_HourMinStr = 'am ' + normal_HourMinStr
                };
                normal_time_hour_min_text_font.setProperty(hmUI.prop.TEXT, normal_HourMinStr );
              };

              console.log('day of week font');
              if (updateHour) {
                let normal_DOW_Str = normal_DOW_Array[timeSensor.week-1];
                normal_dow_text_font.setProperty(hmUI.prop.TEXT, normal_DOW_Str );
              };

              console.log('day font');
              if (updateHour) {
                let normal_dayStr = timeSensor.day.toString();
                normal_day_text_font.setProperty(hmUI.prop.TEXT, normal_dayStr );
              };

              console.log('month font');
              if (updateHour) {
                let normal_Month_Str = normal_Month_Array[timeSensor.month-1];
                normal_month_name_font.setProperty(hmUI.prop.TEXT, normal_Month_Str );
              };

            };

            //end of ignored block
            function scale_call() {
              console.log('scale_call()');

                console.log('update scales STEP');
                
                let valueStep = step.current;
                let targetStep = step.target;
                let progressStep = valueStep/targetStep;
                if (progressStep > 1) progressStep = 1;
                let progress_ls_normal_step = progressStep;

                if (screenType != hmSetting.screen_type.AOD) {

                  // normal_step_linear_scale
                  // initial parameters
                  let start_x_normal_step = 247;
                  let start_y_normal_step = 445;
                  let lenght_ls_normal_step = -52;
                  let line_width_ls_normal_step = 20;
                  let color_ls_normal_step = 0xFFFFFFFF;
                  
                  // calculated parameters
                  let start_x_normal_step_draw = start_x_normal_step;
                  let start_y_normal_step_draw = start_y_normal_step;
                  lenght_ls_normal_step = lenght_ls_normal_step * progress_ls_normal_step;
                  let lenght_ls_normal_step_draw = line_width_ls_normal_step;
                  let line_width_ls_normal_step_draw = lenght_ls_normal_step;
                  if (lenght_ls_normal_step < 0){
                    line_width_ls_normal_step_draw = -lenght_ls_normal_step;
                    start_y_normal_step_draw = start_y_normal_step_draw - line_width_ls_normal_step_draw;
                  };
                  
                  normal_step_linear_scale.setProperty(hmUI.prop.MORE, {
                    x: start_x_normal_step_draw,
                    y: start_y_normal_step_draw,
                    w: lenght_ls_normal_step_draw,
                    h: line_width_ls_normal_step_draw,
                    color: color_ls_normal_step,
                  });
                };

              console.log('Weather city name');
              let weatherData = weatherSensor.getForecastWeather();
              normal_city_name_text.setProperty(hmUI.prop.TEXT, weatherData.cityName);

                console.log('update scales BATTERY');
                
                let valueBattery = battery.current;
                let targetBattery = 100;
                let progressBattery = valueBattery/targetBattery;
                if (progressBattery > 1) progressBattery = 1;
                let progress_ls_normal_battery = progressBattery;

                if (screenType != hmSetting.screen_type.AOD) {

                  // normal_battery_linear_scale
                  // initial parameters
                  let start_x_normal_battery = 203;
                  let start_y_normal_battery = 445;
                  let lenght_ls_normal_battery = -52;
                  let line_width_ls_normal_battery = 20;
                  let color_ls_normal_battery = 0xFFFFFFFF;
                  
                  // calculated parameters
                  let start_x_normal_battery_draw = start_x_normal_battery;
                  let start_y_normal_battery_draw = start_y_normal_battery;
                  lenght_ls_normal_battery = lenght_ls_normal_battery * progress_ls_normal_battery;
                  let lenght_ls_normal_battery_draw = line_width_ls_normal_battery;
                  let line_width_ls_normal_battery_draw = lenght_ls_normal_battery;
                  if (lenght_ls_normal_battery < 0){
                    line_width_ls_normal_battery_draw = -lenght_ls_normal_battery;
                    start_y_normal_battery_draw = start_y_normal_battery_draw - line_width_ls_normal_battery_draw;
                  };
                  
                  normal_battery_linear_scale.setProperty(hmUI.prop.MORE, {
                    x: start_x_normal_battery_draw,
                    y: start_y_normal_battery_draw,
                    w: lenght_ls_normal_battery_draw,
                    h: line_width_ls_normal_battery_draw,
                    color: color_ls_normal_battery,
                  });
                };

            };

            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                console.log('resume_call()');
                scale_call();
                time_update(true, true);
                if (screenType == hmSetting.screen_type.WATCHFACE) {
                  if (!normal_timerTimeUpdate) {
                    normal_timerTimeUpdate = timer.createTimer(0, 1000, (function (option) {
                      let updateHour = timeSensor.minute == 0 && timeSensor.second < 2;
                      let updateMinute = timeSensor.second < 2;
                      time_update(updateHour, updateMinute);
                    }));  // end timer 
                  };  // end timer check
                };  // end screenType


                weather_few_days();
              }),
              pause_call: (function () {
                console.log('pause_call()');
                if (normal_timerTimeUpdate) {
                  timer.stopTimer(normal_timerTimeUpdate);
                  normal_timerTimeUpdate = undefined;
                }

              }),
            });

                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}