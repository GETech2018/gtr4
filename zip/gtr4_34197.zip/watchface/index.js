/*
** Facemaker bundle tool v0.0.3
* *huamiOS watchface js version v2.0.1
* *Copyright © Huami. All Rights Reserved
*/


try {
	(() => {
		var __$$app$$__ = __$$hmAppManager$$__.currentApp;
		var __$$module$$__ = __$$app$$__.current;

		//drink is a name,can modify
		var h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__), 'drink');

		'use strict';

		//dynamic modify start
		let normal_img0 = '';
		let normal_img1 = '';
		let normal_img2 = '';
		let normal_battery_imageset4 = '';
		let normal_week_imageset6 = '';
		let normal_date_imagecombo7 = '';
		let normal_month_imageset8 = '';
		let timeInterval;
		let normal_hour_high_imageset10 = '';
		let normal_hour_high_imageset10_array = ['0045.png','0046.png','0047.png'];
		let normal_hour_low_imageset11 = '';
		let normal_hour_low_imageset11_array = ['0048.png','0049.png','0050.png','0051.png','0052.png','0053.png','0054.png','0055.png','0056.png','0057.png'];
		let normal_minute_high_imageset12 = '';
		let normal_minute_high_imageset12_array = ['0048.png','0049.png','0050.png','0051.png','0052.png','0053.png'];
		let normal_minute_low_imageset13 = '';
		let normal_minute_low_imageset13_array = ['0048.png','0049.png','0050.png','0051.png','0052.png','0053.png','0054.png','0055.png','0056.png','0057.png'];
		let normal_second_high_imageset14 = '';
		let normal_second_high_imageset14_array = ['0048.png','0049.png','0050.png','0051.png','0052.png','0053.png'];
		let normal_second_low_imageset15 = '';
		let normal_second_low_imageset15_array = ['0048.png','0049.png','0050.png','0051.png','0052.png','0053.png','0054.png','0055.png','0056.png','0057.png'];
		let normal_second_low_imageset16 = '';
		let normal_second_low_imageset16_array = ['0058.png','0059.png','0058.png','0059.png','0058.png','0059.png','0058.png','0059.png','0058.png','0059.png'];
		let normal_steps_shortcut19 = '';
		let normal_heart_shortcut20 = '';
		let idle_img22 = '';
		let idle_img23 = '';
		let idle_img24 = '';
		let idle_hour_high_imageset26 = '';
		let idle_hour_high_imageset26_array = ['0063.png','0064.png','0065.png'];
		let idle_hour_low_imageset27 = '';
		let idle_hour_low_imageset27_array = ['0063.png','0064.png','0065.png','0066.png','0067.png','0068.png','0069.png','0070.png','0071.png','0072.png'];
		let idle_minute_high_imageset28 = '';
		let idle_minute_high_imageset28_array = ['0063.png','0064.png','0065.png','0066.png','0067.png','0068.png'];
		let idle_minute_low_imageset29 = '';
		let idle_minute_low_imageset29_array = ['0063.png','0064.png','0065.png','0066.png','0067.png','0068.png','0069.png','0070.png','0071.png','0072.png'];
		let idle_second_high_imageset30 = '';
		let idle_second_high_imageset30_array = ['0063.png','0064.png','0065.png','0066.png','0067.png','0068.png'];
		let idle_second_low_imageset31 = '';
		let idle_second_low_imageset31_array = ['0063.png','0064.png','0065.png','0066.png','0067.png','0068.png','0069.png','0070.png','0071.png','0072.png'];
		let idle_second_low_imageset32 = '';
		let idle_second_low_imageset32_array = ['0073.png','0074.png','0073.png','0074.png','0073.png','0074.png','0073.png','0074.png','0073.png','0074.png'];
		//dynamic modify end

		//not required
		const logger = DeviceRuntimeCore.HmLogger.getLogger("yeguang");

		__$$module$$__.module = DeviceRuntimeCore.WatchFace({
			init_view() {

				const timeSensor = hmSensor.createSensor(hmSensor.id.TIME);
				let screenType = hmSetting.getScreenType();

				normal_img0 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 0,
					y: 0,
					w: 466,
					h: 466,
					src: '0002.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img1 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 66,
					y: 172,
					w: 341,
					h: 96,
					src: '0003.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img2 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 284,
					y: 173,
					w: 20,
					h: 94,
					src: '0004.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_battery_imageset4 = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
					x: 189,
					y: 327,
					image_array: ["0005.png","0006.png","0007.png","0008.png","0009.png","0010.png","0011.png","0012.png","0013.png","0014.png","0015.png"],
					image_length: 11,
					type: hmUI.data_type.BATTERY,
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_week_imageset6 = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
					x: 42,
					y: 270,
					week_en: ["0016.png","0017.png","0018.png","0019.png","0020.png","0021.png","0022.png"],
					week_tc: ["0016.png","0017.png","0018.png","0019.png","0020.png","0021.png","0022.png"],
					week_sc: ["0016.png","0017.png","0018.png","0019.png","0020.png","0021.png","0022.png"],
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_date_imagecombo7 = hmUI.createWidget(hmUI.widget.IMG_DATE, {
					day_startX: 186,
					day_startY: 76,
					day_sc_array: ["0023.png","0024.png","0025.png","0026.png","0027.png","0028.png","0029.png","0030.png","0031.png","0032.png"],
					day_tc_array: ["0023.png","0024.png","0025.png","0026.png","0027.png","0028.png","0029.png","0030.png","0031.png","0032.png"],
					day_en_array: ["0023.png","0024.png","0025.png","0026.png","0027.png","0028.png","0029.png","0030.png","0031.png","0032.png"],
					day_zero: false,
					day_space: 0,
					day_align: hmUI.align.CENTER_H,
					day_is_character: false,
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_month_imageset8 = hmUI.createWidget(hmUI.widget.IMG_DATE, {
					month_startX: 118,
					month_startY: 116,
					month_sc_array: ["0033.png","0034.png","0035.png","0036.png","0037.png","0038.png","0039.png","0040.png","0041.png","0042.png","0043.png","0044.png"],
					month_tc_array: ["0033.png","0034.png","0035.png","0036.png","0037.png","0038.png","0039.png","0040.png","0041.png","0042.png","0043.png","0044.png"],
					month_en_array: ["0033.png","0034.png","0035.png","0036.png","0037.png","0038.png","0039.png","0040.png","0041.png","0042.png","0043.png","0044.png"],
					month_is_character: true,
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_hour_high_imageset10 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 67,
					y: 176,
					w: 67,
					h: 176,
					src: '0047.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				})

				normal_hour_low_imageset11 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 113,
					y: 172,
					w: 113,
					h: 172,
					src: '0057.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				})

				normal_minute_high_imageset12 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 187,
					y: 172,
					w: 187,
					h: 172,
					src: '0053.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				})

				normal_minute_low_imageset13 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 235,
					y: 172,
					w: 235,
					h: 172,
					src: '0057.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				})

				normal_second_high_imageset14 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 305,
					y: 172,
					w: 305,
					h: 172,
					src: '0053.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				})

				normal_second_low_imageset15 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 354,
					y: 172,
					w: 354,
					h: 172,
					src: '0057.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				})

				normal_second_low_imageset16 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 164,
					y: 172,
					w: 164,
					h: 172,
					src: '0059.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				})

				normal_steps_shortcut19 = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
					x: 92,
					y: 322,
					w: 70,
					h: 70,
					src: '',
					type: hmUI.data_type.STEP,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_heart_shortcut20 = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
					x: 304,
					y: 322,
					w: 70,
					h: 70,
					src: '',
					type: hmUI.data_type.HEART,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				idle_img22 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 66,
					y: 175,
					w: 340,
					h: 90,
					src: '0060.png',
					enable: false,
					show_level: hmUI.show_level.ONAL_AOD,
				});

				idle_img23 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 89,
					y: 142,
					w: 286,
					h: 30,
					src: '0061.png',
					enable: false,
					show_level: hmUI.show_level.ONAL_AOD,
				});

				idle_img24 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 286,
					y: 175,
					w: 16,
					h: 90,
					src: '0062.png',
					enable: false,
					show_level: hmUI.show_level.ONAL_AOD,
				});

				idle_hour_high_imageset26 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 68,
					y: 174,
					w: 68,
					h: 174,
					src: '0065.png',
					enable: false,
					show_level: hmUI.show_level.ONAL_AOD,
				})

				idle_hour_low_imageset27 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 116,
					y: 174,
					w: 116,
					h: 174,
					src: '0072.png',
					enable: false,
					show_level: hmUI.show_level.ONAL_AOD,
				})

				idle_minute_high_imageset28 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 189,
					y: 174,
					w: 189,
					h: 174,
					src: '0068.png',
					enable: false,
					show_level: hmUI.show_level.ONAL_AOD,
				})

				idle_minute_low_imageset29 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 239,
					y: 175,
					w: 239,
					h: 175,
					src: '0072.png',
					enable: false,
					show_level: hmUI.show_level.ONAL_AOD,
				})

				idle_second_high_imageset30 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 309,
					y: 176,
					w: 309,
					h: 176,
					src: '0068.png',
					enable: false,
					show_level: hmUI.show_level.ONAL_AOD,
				})

				idle_second_low_imageset31 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 358,
					y: 175,
					w: 358,
					h: 175,
					src: '0072.png',
					enable: false,
					show_level: hmUI.show_level.ONAL_AOD,
				})

				idle_second_low_imageset32 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 164,
					y: 174,
					w: 164,
					h: 174,
					src: '0074.png',
					enable: false,
					show_level: hmUI.show_level.ONAL_AOD,
				})

				function updateTime() {
					normal_hour_high_imageset10.setProperty(hmUI.prop.MORE, {
						src: normal_hour_high_imageset10_array[(timeSensor.format_hour.toString().length == 2 ? timeSensor.format_hour.toString().charAt(0) : 0)]
					})
					normal_hour_low_imageset11.setProperty(hmUI.prop.MORE, {
						src: normal_hour_low_imageset11_array[(timeSensor.format_hour.toString().length == 2 ? timeSensor.format_hour.toString().charAt(1) : timeSensor.format_hour.toString().charAt(0))]
					})
					normal_minute_high_imageset12.setProperty(hmUI.prop.MORE, {
						src: normal_minute_high_imageset12_array[(timeSensor.minute.toString().length == 2 ? timeSensor.minute.toString().charAt(0) : 0)]
					})
					normal_minute_low_imageset13.setProperty(hmUI.prop.MORE, {
						src: normal_minute_low_imageset13_array[(timeSensor.minute.toString().length == 2 ? timeSensor.minute.toString().charAt(1) : timeSensor.minute.toString().charAt(0))]
					})
					normal_second_high_imageset14.setProperty(hmUI.prop.MORE, {
						src: normal_second_high_imageset14_array[(timeSensor.second.toString().length == 2 ? timeSensor.second.toString().charAt(0) : 0)]
					})
					normal_second_low_imageset15.setProperty(hmUI.prop.MORE, {
						src: normal_second_low_imageset15_array[(timeSensor.second.toString().length == 2 ? timeSensor.second.toString().charAt(1) : timeSensor.second.toString().charAt(0))]
					})
					normal_second_low_imageset16.setProperty(hmUI.prop.MORE, {
						src: normal_second_low_imageset16_array[(timeSensor.second.toString().length == 2 ? timeSensor.second.toString().charAt(1) : timeSensor.second.toString().charAt(0))]
					})
					idle_hour_high_imageset26.setProperty(hmUI.prop.MORE, {
						src: idle_hour_high_imageset26_array[(timeSensor.format_hour.toString().length == 2 ? timeSensor.format_hour.toString().charAt(0) : 0)]
					})
					idle_hour_low_imageset27.setProperty(hmUI.prop.MORE, {
						src: idle_hour_low_imageset27_array[(timeSensor.format_hour.toString().length == 2 ? timeSensor.format_hour.toString().charAt(1) : timeSensor.format_hour.toString().charAt(0))]
					})
					idle_minute_high_imageset28.setProperty(hmUI.prop.MORE, {
						src: idle_minute_high_imageset28_array[(timeSensor.minute.toString().length == 2 ? timeSensor.minute.toString().charAt(0) : 0)]
					})
					idle_minute_low_imageset29.setProperty(hmUI.prop.MORE, {
						src: idle_minute_low_imageset29_array[(timeSensor.minute.toString().length == 2 ? timeSensor.minute.toString().charAt(1) : timeSensor.minute.toString().charAt(0))]
					})
					idle_second_high_imageset30.setProperty(hmUI.prop.MORE, {
						src: idle_second_high_imageset30_array[(timeSensor.second.toString().length == 2 ? timeSensor.second.toString().charAt(0) : 0)]
					})
					idle_second_low_imageset31.setProperty(hmUI.prop.MORE, {
						src: idle_second_low_imageset31_array[(timeSensor.second.toString().length == 2 ? timeSensor.second.toString().charAt(1) : timeSensor.second.toString().charAt(0))]
					})
					idle_second_low_imageset32.setProperty(hmUI.prop.MORE, {
						src: idle_second_low_imageset32_array[(timeSensor.second.toString().length == 2 ? timeSensor.second.toString().charAt(1) : timeSensor.second.toString().charAt(0))]
					})
				}

				timeSensor.addEventListener(hmSensor.event.CHANGE, function() {
					updateTime();
				});

				const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
					resume_call: (function () {
						updateTime();
						timeInterval = setInterval(updateTime, 1000);
					}),
					pause_call: (function () {
						clearInterval(timeInterval);
					}),
				})
			},

		onInit() {
			console.log('index page.js on init invoke')
			this.init_view()
		},
		onReady() {
			console.log('index page.js on ready invoke')
		},
		onShow() {
			console.log('index page.js on show invoke')
		},
		onHide() {
			console.log('index page.js on hide invoke')
		},
		onDestroy() {
			console.log('index page.js on destroy invoke')
		},
	});	})()
} catch (e) {
	console.log(e)
}