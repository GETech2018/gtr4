﻿
    /*
    ** Watch_Face_Editor tool
    ** watchface js version v1.0.1
    ** Copyright © CashaCX75. All Rights Reserved
    */

    try {

      (() => {

        var __$$app$$__ = __$$hmAppManager$$__.currentApp;
        var __$$module$$__ = __$$app$$__.current;
        //drink is a name,can modify
        var h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__), 'drink');

        'use strict';

        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_digital_clock_img_time_AmPm = ''
        let normal_digital_clock_img_time = ''
        let normal_step_icon_img = ''
        let normal_step_current_text_img = ''
        let normal_step_current_separator_img = ''
        let normal_date_img_date_week_img = ''
        let normal_heart_rate_icon_img = ''
        let normal_heart_rate_text_text_img = ''
        let normal_heart_rate_text_separator_img = ''
        let normal_date_img_date_month_img = ''
        let normal_date_img_date_day = ''
        let normal_battery_text_text_img = ''
        let normal_battery_text_separator_img = ''
        let normal_system_disconnect_img = ''
        let idle_background_bg = ''
        let idle_digital_clock_img_time_AmPm = ''
        let idle_digital_clock_img_time = ''
        let idle_step_icon_img = ''
        let idle_battery_text_text_img = ''
        let idle_battery_text_separator_img = ''
        let idle_system_disconnect_img = ''
        let idle_calorie_icon_img = ''


        //dynamic modify end

        //not required
        const logger = DeviceRuntimeCore.HmLogger.getLogger("yeguang");

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({

          init_view() {

            //dynamic modify start
                    
            
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 466,
              h: 466,
              src: 'back_blue_001.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time_AmPm = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              am_x: 0,
              am_y: 0,
              am_sc_path: 'zzblank_icon_AM.png',
              am_en_path: 'zzblank_icon_AM.png',
              pm_x: 0,
              pm_y: 0,
              pm_sc_path: 'zzblank_icon_PM.png',
              pm_en_path: 'zzblank_icon_PM.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: -77,
              hour_startY: -110,
              hour_array: ["digi_alexana_size60_001.png","digi_alexana_size60_002.png","digi_alexana_size60_003.png","digi_alexana_size60_004.png","digi_alexana_size60_005.png","digi_alexana_size60_006.png","digi_alexana_size60_007.png","digi_alexana_size60_008.png","digi_alexana_size60_009.png","digi_alexana_size60_010.png"],
              hour_zero: 1,
              hour_space: -374,
              hour_align: hmUI.align.LEFT,

              minute_startX: -135,
              minute_startY: 47,
              minute_array: ["digi_alexana_sizered30_001.png","digi_alexana_sizered30_002.png","digi_alexana_sizered30_003.png","digi_alexana_sizered30_004.png","digi_alexana_sizered30_005.png","digi_alexana_sizered30_006.png","digi_alexana_sizered30_007.png","digi_alexana_sizered30_008.png","digi_alexana_sizered30_009.png","digi_alexana_sizered30_010.png"],
              minute_zero: 1,
              minute_space: -369,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: -4,
              y: -86,
              src: 'foreg_slant_black.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 358,
              y: 217,
              font_array: ["digi_size7-5_slantyellowmonths_001.png","digi_size7-5_slantyellowmonths_002.png","digi_size7-5_slantyellowmonths_003.png","digi_size7-5_slantyellowmonths_004.png","digi_size7-5_slantyellowmonths_005.png","digi_size7-5_slantyellowmonths_006.png","digi_size7-5_slantyellowmonths_007.png","digi_size7-5_slantyellowmonths_008.png","digi_size7-5_slantyellowmonths_009.png","digi_size7-5_slantyellowmonths_010.png"],
              padding: false,
              h_space: -8,
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 300,
              y: 238,
              src: 'icon_step_yellred.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 197,
              y: 240,
              week_en: ["digi_slantyellow_size9_001.png","digi_slantyellow_size9_002.png","digi_slantyellow_size9_003.png","digi_slantyellow_size9_004.png","digi_slantyellow_size9_005.png","digi_slantyellow_size9_006.png","digi_slantyellow_size9_007.png"],
              week_tc: ["digi_slantyellow_size9_001.png","digi_slantyellow_size9_002.png","digi_slantyellow_size9_003.png","digi_slantyellow_size9_004.png","digi_slantyellow_size9_005.png","digi_slantyellow_size9_006.png","digi_slantyellow_size9_007.png"],
              week_sc: ["digi_slantyellow_size9_001.png","digi_slantyellow_size9_002.png","digi_slantyellow_size9_003.png","digi_slantyellow_size9_004.png","digi_slantyellow_size9_005.png","digi_slantyellow_size9_006.png","digi_slantyellow_size9_007.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 269,
              y: -15,
              src: 'logo_4.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 391,
              y: 122,
              font_array: ["digi_size7-5_slantyellowmonths_001.png","digi_size7-5_slantyellowmonths_002.png","digi_size7-5_slantyellowmonths_003.png","digi_size7-5_slantyellowmonths_004.png","digi_size7-5_slantyellowmonths_005.png","digi_size7-5_slantyellowmonths_006.png","digi_size7-5_slantyellowmonths_007.png","digi_size7-5_slantyellowmonths_008.png","digi_size7-5_slantyellowmonths_009.png","digi_size7-5_slantyellowmonths_010.png"],
              padding: false,
              h_space: -6,
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 359,
              y: 160,
              src: 'icon_heartyel.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_month_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 274,
              month_startY: 93,
              month_sc_array: ["digi_slantyellowmonths_size9_001.png","digi_slantyellowmonths_size9_002.png","digi_slantyellowmonths_size9_003.png","digi_slantyellowmonths_size9_004.png","digi_slantyellowmonths_size9_005.png","digi_slantyellowmonths_size9_006.png","digi_slantyellowmonths_size9_007.png","digi_slantyellowmonths_size9_008.png","digi_slantyellowmonths_size9_009.png","digi_slantyellowmonths_size9_010.png","digi_slantyellowmonths_size9_011.png","digi_slantyellowmonths_size9_012.png"],
              month_tc_array: ["digi_slantyellowmonths_size9_001.png","digi_slantyellowmonths_size9_002.png","digi_slantyellowmonths_size9_003.png","digi_slantyellowmonths_size9_004.png","digi_slantyellowmonths_size9_005.png","digi_slantyellowmonths_size9_006.png","digi_slantyellowmonths_size9_007.png","digi_slantyellowmonths_size9_008.png","digi_slantyellowmonths_size9_009.png","digi_slantyellowmonths_size9_010.png","digi_slantyellowmonths_size9_011.png","digi_slantyellowmonths_size9_012.png"],
              month_en_array: ["digi_slantyellowmonths_size9_001.png","digi_slantyellowmonths_size9_002.png","digi_slantyellowmonths_size9_003.png","digi_slantyellowmonths_size9_004.png","digi_slantyellowmonths_size9_005.png","digi_slantyellowmonths_size9_006.png","digi_slantyellowmonths_size9_007.png","digi_slantyellowmonths_size9_008.png","digi_slantyellowmonths_size9_009.png","digi_slantyellowmonths_size9_010.png","digi_slantyellowmonths_size9_011.png","digi_slantyellowmonths_size9_012.png"],
              month_is_character: true ,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 234,
              day_startY: 199,
              day_sc_array: ["digi_slantyellownumbers_size9_001.png","digi_slantyellownumbers_size9_002.png","digi_slantyellownumbers_size9_003.png","digi_slantyellownumbers_size9_004.png","digi_slantyellownumbers_size9_005.png","digi_slantyellownumbers_size9_006.png","digi_slantyellownumbers_size9_007.png","digi_slantyellownumbers_size9_008.png","digi_slantyellownumbers_size9_009.png","digi_slantyellownumbers_size9_010.png"],
              day_tc_array: ["digi_slantyellownumbers_size9_001.png","digi_slantyellownumbers_size9_002.png","digi_slantyellownumbers_size9_003.png","digi_slantyellownumbers_size9_004.png","digi_slantyellownumbers_size9_005.png","digi_slantyellownumbers_size9_006.png","digi_slantyellownumbers_size9_007.png","digi_slantyellownumbers_size9_008.png","digi_slantyellownumbers_size9_009.png","digi_slantyellownumbers_size9_010.png"],
              day_en_array: ["digi_slantyellownumbers_size9_001.png","digi_slantyellownumbers_size9_002.png","digi_slantyellownumbers_size9_003.png","digi_slantyellownumbers_size9_004.png","digi_slantyellownumbers_size9_005.png","digi_slantyellownumbers_size9_006.png","digi_slantyellownumbers_size9_007.png","digi_slantyellownumbers_size9_008.png","digi_slantyellownumbers_size9_009.png","digi_slantyellownumbers_size9_010.png"],
              day_zero: 1,
              day_space: -87,
              day_align: hmUI.align.LEFT,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 308,
              y: 311,
              font_array: ["zdigi_size7-5_slantyellowmonths_001.png","zdigi_size7-5_slantyellowmonths_002.png","zdigi_size7-5_slantyellowmonths_003.png","zdigi_size7-5_slantyellowmonths_004.png","zdigi_size7-5_slantyellowmonths_005.png","zdigi_size7-5_slantyellowmonths_006.png","zdigi_size7-5_slantyellowmonths_007.png","zdigi_size7-5_slantyellowmonths_008.png","zdigi_size7-5_slantyellowmonths_009.png","zdigi_size7-5_slantyellowmonths_010.png"],
              padding: false,
              h_space: -4,
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 297,
              y: 354,
              src: 'Battery.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 6,
              y: 233,
              src: 'bluetoothoff (2).png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            idle_background_bg = hmUI.createWidget(hmUI.widget.FILL_RECT, {
              x: 0,
              y: 0,
              w: 466,
              h: 466,
              color: '0xFF000000',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time_AmPm = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              am_x: 0,
              am_y: 0,
              am_sc_path: 'zzblank_icon_AM.png',
              am_en_path: 'zzblank_icon_AM.png',
              pm_x: 0,
              pm_y: 0,
              pm_sc_path: 'zzblank_icon_PM.png',
              pm_en_path: 'zzblank_icon_PM.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: -77,
              hour_startY: -110,
              hour_array: ["digi_alexana_size60_001.png","digi_alexana_size60_002.png","digi_alexana_size60_003.png","digi_alexana_size60_004.png","digi_alexana_size60_005.png","digi_alexana_size60_006.png","digi_alexana_size60_007.png","digi_alexana_size60_008.png","digi_alexana_size60_009.png","digi_alexana_size60_010.png"],
              hour_zero: 1,
              hour_space: -374,
              hour_align: hmUI.align.LEFT,

              minute_startX: -135,
              minute_startY: 47,
              minute_array: ["digi_alexana_sizered30_001.png","digi_alexana_sizered30_002.png","digi_alexana_sizered30_003.png","digi_alexana_sizered30_004.png","digi_alexana_sizered30_005.png","digi_alexana_sizered30_006.png","digi_alexana_sizered30_007.png","digi_alexana_sizered30_008.png","digi_alexana_sizered30_009.png","digi_alexana_sizered30_010.png"],
              minute_zero: 1,
              minute_space: -361,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              second_startX: 135,
              second_startY: 350,
              second_array: ["sec_alexana_size60_001.png","sec_alexana_size60_002.png","sec_alexana_size60_003.png","sec_alexana_size60_004.png","sec_alexana_size60_005.png","sec_alexana_size60_006.png","sec_alexana_size60_007.png","sec_alexana_size60_008.png","sec_alexana_size60_009.png","sec_alexana_size60_010.png"],
              second_zero: 1,
              second_space: -80,
              second_follow: 0,
              second_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_step_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: -4,
              y: -86,
              src: 'foreg_slant_black.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 259,
              y: 362,
              font_array: ["digi_size7-5_slantyellowmonths_001.png","digi_size7-5_slantyellowmonths_002.png","digi_size7-5_slantyellowmonths_003.png","digi_size7-5_slantyellowmonths_004.png","digi_size7-5_slantyellowmonths_005.png","digi_size7-5_slantyellowmonths_006.png","digi_size7-5_slantyellowmonths_007.png","digi_size7-5_slantyellowmonths_008.png","digi_size7-5_slantyellowmonths_009.png","digi_size7-5_slantyellowmonths_010.png"],
              padding: false,
              h_space: -5,
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_battery_text_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 238,
              y: 405,
              src: 'Battery.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 6,
              y: 233,
              src: 'bluetoothoff (2).png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_calorie_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: -45,
              y: -9,
              src: 'AOB Overlay.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });


            //dynamic modify end
          },

          onInit() {
            console.log('index page.js on init invoke')

            this.init_view()

          },

          onReady() {
            console.log('index page.js on ready invoke')
          },

          onShow() {
            console.log('index page.js on show invoke')
          },

          onHide() {
            console.log('index page.js on hide invoke')
          },

          onDestory() {
            console.log('index page.js on destory invoke')
          },
        });

      })()
    } catch (e) {
      console.log(e)
    }
  