﻿/*
** Watch_Face_Editor tool
** watchface js version v2.1.1
** Copyright © SashaCX75. All Rights Reserved
*/

try {
  (() => {
    //start of ignored block
    const __$$app$$__ = __$$hmAppManager$$__.currentApp;
    function getApp() {
      return __$$app$$__.app;
    }
    function getCurrentPage() {
      return __$$app$$__.current && __$$app$$__.current.module;
    }
    const __$$module$$__ = __$$app$$__.current;
    const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
    const { px } = __$$app$$__.__globals__;
    const logger = Logger.getLogger('watchface_SashaCX75');
    //end of ignored block

    //dynamic modify start


    let normal_background_bg = ''
    let normal_calorie_icon_img = ''
    let normal_calorie_circle_scale = ''
    let normal_calorie_TextCircle = new Array(4);
    let normal_calorie_TextCircle_ASCIIARRAY = new Array(10);
    let normal_calorie_TextCircle_img_width = 18;
    let normal_calorie_TextCircle_img_height = 24;
    let normal_step_icon_img = ''
    let normal_step_circle_scale = ''
    let normal_step_TextCircle = new Array(5);
    let normal_step_TextCircle_ASCIIARRAY = new Array(10);
    let normal_step_TextCircle_img_width = 18;
    let normal_step_TextCircle_img_height = 24;
    let normal_heart_rate_circle_scale = ''
    let normal_heart_rate_TextCircle = new Array(3);
    let normal_heart_rate_TextCircle_ASCIIARRAY = new Array(10);
    let normal_heart_rate_TextCircle_img_width = 18;
    let normal_heart_rate_TextCircle_img_height = 24;
    let normal_heart_rate_icon_img = ''
    let normal_image_img = ''
    let normal_battery_TextCircle = new Array(3);
    let normal_battery_TextCircle_ASCIIARRAY = new Array(10);
    let normal_battery_TextCircle_img_width = 18;
    let normal_battery_TextCircle_img_height = 24;
    let normal_battery_image_progress_img_level = ''
    let normal_battery_icon_img = ''
    let normal_analog_clock_time_pointer_hour = ''
    let normal_analog_clock_time_pointer_minute = ''
    let idle_analog_clock_time_pointer_hour = ''
    let idle_analog_clock_time_pointer_minute = ''
    let Button_1 = ''
    let Button_2 = ''
    let bg_color = ['0xFFF8641D', '0xFFEC76C3', '0xFFE9C001', '0xFFA1BD00', '0xFF40ABFD', '0xFF4C7EFB', '0xFF7B62B7', '0xFFFFC197', '0xFFFFBDC8', '0xFFFFDE96', '0xFFCDE191', '0xFF76CED6', '0xFF7790B5', '0xFFC2B5F5'];


    let color_num = 0
    let color_all = 13
    function click_color() {
      if (color_num >= color_all) { color_num = 0; }
      else { color_num = color_num + 1; }
      hmUI.showToast({ text: "Color " + parseInt(color_num + 1) });
      normal_background_bg.setProperty(hmUI.prop.MORE,{ 
        x: 0,
        y: 0,
        w: 466,
        h: 466,
        color: bg_color[color_num],
        show_level: hmUI.show_level.ONLY_NORMAL,
      });
    }


    let progress_num = 1

    //dynamic modify end

    __$$module$$__.module = DeviceRuntimeCore.WatchFace({
      init_view() {
        //dynamic modify start

        const time = hmSensor.createSensor(hmSensor.id.TIME);

        console.log('Watch_Face.ScreenNormal');

        normal_background_bg = hmUI.createWidget(hmUI.widget.FILL_RECT, {
          x: 0,
          y: 0,
          w: 466,
          h: 466,
          color: '0xFFF8641D',
          show_level: hmUI.show_level.ONLY_NORMAL,
        });

        let screenType = hmSetting.getScreenType();

        normal_calorie_circle_scale = hmUI.createWidget(hmUI.widget.ARC_PROGRESS, {
          center_x: 233,
          center_y: 233,
          start_angle: -111,
          end_angle: -69,
          radius: 215,
          line_width: 25,
          corner_flag: 0,
          color: 0xFFD9D9D9,
          show_level: hmUI.show_level.ONLY_NORMAL,
        });
        normal_calorie_circle_scale.setProperty(hmUI.prop.VISIBLE, false);

        normal_heart_rate_circle_scale = hmUI.createWidget(hmUI.widget.ARC_PROGRESS, {
          center_x: 233,
          center_y: 233,
          start_angle: -111,
          end_angle: -69,
          radius: 215,
          line_width: 25,
          corner_flag: 0,
          color: 0xFFD9D9D9,
          show_level: hmUI.show_level.ONLY_NORMAL,
        });

        normal_step_circle_scale = hmUI.createWidget(hmUI.widget.ARC_PROGRESS, {
          center_x: 233,
          center_y: 233,
          start_angle: -111,
          end_angle: -69,
          radius: 215,
          line_width: 25,
          corner_flag: 0,
          color: 0xFFD9D9D9,
          show_level: hmUI.show_level.ONLY_NORMAL,
        });
        normal_step_circle_scale.setProperty(hmUI.prop.VISIBLE, false);


        function toDegree(radian) {
          return radian * (180 / Math.PI);
        };

        normal_image_img = hmUI.createWidget(hmUI.widget.IMG, {
          x: 0,
          y: 0,
          src: 'h_1.png',
          show_level: hmUI.show_level.ONLY_NORMAL,
        });

        normal_battery_TextCircle_ASCIIARRAY[0] = '0.png';  // set of images with numbers
        normal_battery_TextCircle_ASCIIARRAY[1] = '1.png';  // set of images with numbers
        normal_battery_TextCircle_ASCIIARRAY[2] = '2.png';  // set of images with numbers
        normal_battery_TextCircle_ASCIIARRAY[3] = '3.png';  // set of images with numbers
        normal_battery_TextCircle_ASCIIARRAY[4] = '4.png';  // set of images with numbers
        normal_battery_TextCircle_ASCIIARRAY[5] = '5.png';  // set of images with numbers
        normal_battery_TextCircle_ASCIIARRAY[6] = '6.png';  // set of images with numbers
        normal_battery_TextCircle_ASCIIARRAY[7] = '7.png';  // set of images with numbers
        normal_battery_TextCircle_ASCIIARRAY[8] = '8.png';  // set of images with numbers
        normal_battery_TextCircle_ASCIIARRAY[9] = '9.png';  // set of images with numbers

        //start of ignored block
        for (let i = 0; i < 3; i++) {
          normal_battery_TextCircle[i] = hmUI.createWidget(hmUI.widget.IMG, {
            x: 0,
            y: 0,
            w: 466,
            h: 466,
            center_x: 233,
            center_y: 233,
            pos_x: 233 - normal_battery_TextCircle_img_width / 2,
            pos_y: 233 + 201,
            src: '0.png',
            show_level: hmUI.show_level.ONLY_NORMAL,
          });
          normal_battery_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
        };
        //end of ignored block

        const battery = hmSensor.createSensor(hmSensor.id.BATTERY);
        battery.addEventListener(hmSensor.event.CHANGE, function () {
          text_update();
        });

        normal_battery_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
          x: 0,
          y: 0,
          image_array: ["bat_1.png", "bat_2.png", "bat_3.png", "bat_4.png", "bat_5.png", "bat_6.png", "bat_7.png", "bat_8.png", "bat_9.png", "bat_10.png"],
          image_length: 10,
          type: hmUI.data_type.BATTERY,
          show_level: hmUI.show_level.ONLY_NORMAL,
        });

        normal_battery_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
          x: 413,
          y: 117,
          src: 'ico_bat.png',
          show_level: hmUI.show_level.ONLY_NORMAL,
        });

        normal_analog_clock_time_pointer_hour = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
          hour_path: 'spatial_number_hands_hr_aod.png',
          hour_centerX: 233,
          hour_centerY: 233,
          hour_posX: 25,
          hour_posY: 218,
          show_level: hmUI.show_level.ONLY_NORMAL,
        });

        normal_analog_clock_time_pointer_minute = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
          minute_path: 'spatial_number_hands_min_aod.png',
          minute_centerX: 233,
          minute_centerY: 233,
          minute_posX: 25,
          minute_posY: 218,
          show_level: hmUI.show_level.ONLY_NORMAL,
        });

        normal_heart_rate_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
          x: 31,
          y: 122,
          src: 'ico_heart.png',
          show_level: hmUI.show_level.ONLY_NORMAL,
        });

        const heart_rate = hmSensor.createSensor(hmSensor.id.HEART);
        heart_rate.addEventListener(hmSensor.event.CHANGE, function () {
          text_update();
          scale_call();
        });

        normal_heart_rate_TextCircle_ASCIIARRAY[0] = '0.png';  // set of images with numbers
        normal_heart_rate_TextCircle_ASCIIARRAY[1] = '1.png';  // set of images with numbers
        normal_heart_rate_TextCircle_ASCIIARRAY[2] = '2.png';  // set of images with numbers
        normal_heart_rate_TextCircle_ASCIIARRAY[3] = '3.png';  // set of images with numbers
        normal_heart_rate_TextCircle_ASCIIARRAY[4] = '4.png';  // set of images with numbers
        normal_heart_rate_TextCircle_ASCIIARRAY[5] = '5.png';  // set of images with numbers
        normal_heart_rate_TextCircle_ASCIIARRAY[6] = '6.png';  // set of images with numbers
        normal_heart_rate_TextCircle_ASCIIARRAY[7] = '7.png';  // set of images with numbers
        normal_heart_rate_TextCircle_ASCIIARRAY[8] = '8.png';  // set of images with numbers
        normal_heart_rate_TextCircle_ASCIIARRAY[9] = '9.png';  // set of images with numbers

        //start of ignored block
        for (let i = 0; i < 3; i++) {
          normal_heart_rate_TextCircle[i] = hmUI.createWidget(hmUI.widget.IMG, {
            x: 0,
            y: 0,
            w: 466,
            h: 466,
            center_x: 233,
            center_y: 233,
            pos_x: 233 - normal_heart_rate_TextCircle_img_width / 2,
            pos_y: 233 + 201,
            src: '0.png',
            show_level: hmUI.show_level.ONLY_NORMAL,
          });
          normal_heart_rate_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
        };
        //end of ignored block

        normal_calorie_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
          x: 31,
          y: 119,
          src: 'ico_cal.png',
          show_level: hmUI.show_level.ONLY_NORMAL,
        });

        normal_calorie_icon_img.setProperty(hmUI.prop.VISIBLE, false);

        const calorie = hmSensor.createSensor(hmSensor.id.CALORIE);
        calorie.addEventListener(hmSensor.event.CHANGE, function () {
          text_update();
          scale_call();
        });


        normal_calorie_TextCircle_ASCIIARRAY[0] = '0.png';  // set of images with numbers
        normal_calorie_TextCircle_ASCIIARRAY[1] = '1.png';  // set of images with numbers
        normal_calorie_TextCircle_ASCIIARRAY[2] = '2.png';  // set of images with numbers
        normal_calorie_TextCircle_ASCIIARRAY[3] = '3.png';  // set of images with numbers
        normal_calorie_TextCircle_ASCIIARRAY[4] = '4.png';  // set of images with numbers
        normal_calorie_TextCircle_ASCIIARRAY[5] = '5.png';  // set of images with numbers
        normal_calorie_TextCircle_ASCIIARRAY[6] = '6.png';  // set of images with numbers
        normal_calorie_TextCircle_ASCIIARRAY[7] = '7.png';  // set of images with numbers
        normal_calorie_TextCircle_ASCIIARRAY[8] = '8.png';  // set of images with numbers
        normal_calorie_TextCircle_ASCIIARRAY[9] = '9.png';  // set of images with numbers

        //start of ignored block
        for (let i = 0; i < 4; i++) {
          normal_calorie_TextCircle[i] = hmUI.createWidget(hmUI.widget.IMG, {
            x: 0,
            y: 0,
            w: 466,
            h: 466,
            center_x: 233,
            center_y: 233,
            pos_x: 233 - normal_calorie_TextCircle_img_width / 2,
            pos_y: 233 + 201,
            src: '0.png',
            show_level: hmUI.show_level.ONLY_NORMAL,
          });
          normal_calorie_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
        };
        //end of ignored block

        normal_step_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
          x: 31,
          y: 117,
          src: 'ico_step.png',
          show_level: hmUI.show_level.ONLY_NORMAL,
        });

        normal_step_icon_img.setProperty(hmUI.prop.VISIBLE, false);

        const step = hmSensor.createSensor(hmSensor.id.STEP);
        step.addEventListener(hmSensor.event.CHANGE, function () {
          text_update();
          scale_call();
        });

        normal_step_TextCircle_ASCIIARRAY[0] = '0.png';  // set of images with numbers
        normal_step_TextCircle_ASCIIARRAY[1] = '1.png';  // set of images with numbers
        normal_step_TextCircle_ASCIIARRAY[2] = '2.png';  // set of images with numbers
        normal_step_TextCircle_ASCIIARRAY[3] = '3.png';  // set of images with numbers
        normal_step_TextCircle_ASCIIARRAY[4] = '4.png';  // set of images with numbers
        normal_step_TextCircle_ASCIIARRAY[5] = '5.png';  // set of images with numbers
        normal_step_TextCircle_ASCIIARRAY[6] = '6.png';  // set of images with numbers
        normal_step_TextCircle_ASCIIARRAY[7] = '7.png';  // set of images with numbers
        normal_step_TextCircle_ASCIIARRAY[8] = '8.png';  // set of images with numbers
        normal_step_TextCircle_ASCIIARRAY[9] = '9.png';  // set of images with numbers

        //start of ignored block
        for (let i = 0; i < 5; i++) {
          normal_step_TextCircle[i] = hmUI.createWidget(hmUI.widget.IMG, {
            x: 0,
            y: 0,
            w: 466,
            h: 466,
            center_x: 233,
            center_y: 233,
            pos_x: 233 - normal_step_TextCircle_img_width / 2,
            pos_y: 233 + 201,
            src: '0.png',
            show_level: hmUI.show_level.ONLY_NORMAL,
          });
          normal_step_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
        };
        //end of ignored block

        console.log('Watch_Face.ScreenAOD');

        idle_analog_clock_time_pointer_hour = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
          hour_path: 'spatial_number_hands_hr_aod.png',
          hour_centerX: 233,
          hour_centerY: 233,
          hour_posX: 25,
          hour_posY: 218,
          show_level: hmUI.show_level.ONLY_AOD,
        });

        idle_analog_clock_time_pointer_minute = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
          minute_path: 'spatial_number_hands_min_aod.png',
          minute_centerX: 233,
          minute_centerY: 233,
          minute_posX: 25,
          minute_posY: 218,
          show_level: hmUI.show_level.ONLY_AOD,
        });
        console.log('Watch_Face.Shortcuts');

        console.log('Watch_Face.Buttons');
        Button_1 = hmUI.createWidget(hmUI.widget.BUTTON, {
          x: 195,
          y: 195,
          w: 76,
          h: 76,
          text: "",
          normal_src: "wfs_clear.png",
          press_src: "wfs_clear.png",
          click_func: (button_widget) => {
            click_color();
          }, // end func
          show_level: hmUI.show_level.ONLY_NORMAL,
        }); // end button

        Button_2 = hmUI.createWidget(hmUI.widget.BUTTON, {
          x: 1,
          y: 195,
          w: 76,
          h: 76,
          text: "",
          normal_src: "wfs_clear.png",
          press_src: "wfs_clear.png",
          click_func: (button_widget) => {
            click_progress();
          }, // end func
        }); // end button

        //--------------------------------------------------------------------------------------------------------------------------------------------------------------------

        //start of ignored block
        function text_update() {
          console.log('text_update()');

          console.log('update text circle heart_rate_HEART');
          let valueHeartRate = heart_rate.last;
          let normal_heart_rate_circle_string = parseInt(valueHeartRate).toString();

          if (progress_num == 1) {
            //start of ignored block
            for (let i = 0; i < 4; i++) {
              normal_calorie_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
            };
            for (var i = 0; i < 5; i++) {  // hide all symbols
              normal_step_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
            };
            if (screenType != hmSetting.screen_type.AOD) {
              for (var i = 1; i < 3; i++) {  // hide all symbols
                normal_heart_rate_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
              };
              let char_Angle = 63;
              if (valueHeartRate != null && valueHeartRate != undefined && isFinite(valueHeartRate) && normal_heart_rate_circle_string.length > 0 && normal_heart_rate_circle_string.length < 6) {  // display data if it was possible to get it
                let normal_heart_rate_TextCircle_img_angle = 0;
                let normal_heart_rate_TextCircle_dot_img_angle = 0;
                normal_heart_rate_TextCircle_img_angle = toDegree(Math.atan2(normal_heart_rate_TextCircle_img_width / 2, 225));

                let firstSymbol = true;
                let index = 0;
                for (let char of normal_heart_rate_circle_string) {
                  let charCode = char.charCodeAt() - 48;
                  if (index >= 3) break;
                  if (charCode >= 0 && charCode < 10) {
                    if (!firstSymbol) char_Angle -= normal_heart_rate_TextCircle_img_angle;
                    firstSymbol = false;
                    normal_heart_rate_TextCircle[index].setProperty(hmUI.prop.ANGLE, char_Angle);
                    normal_heart_rate_TextCircle[index].setProperty(hmUI.prop.POS_X, 233 - normal_heart_rate_TextCircle_img_width / 2);
                    normal_heart_rate_TextCircle[index].setProperty(hmUI.prop.SRC, normal_heart_rate_TextCircle_ASCIIARRAY[charCode]);
                    normal_heart_rate_TextCircle[index].setProperty(hmUI.prop.VISIBLE, true);
                    char_Angle -= normal_heart_rate_TextCircle_img_angle;
                    index++;
                  };  // end if digit
                };  // end char of string
              }  // end isFinite

            };
          };

          console.log('update text circle step_STEP');
          let valueStep = step.current;
          let normal_step_circle_string = parseInt(valueStep).toString();

          if (progress_num == 2) {
            for (let i = 0; i < 3; i++) {
              normal_heart_rate_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
            };
            for (var i = 0; i < 4; i++) {  // hide all symbols
              normal_calorie_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
            };
            if (screenType != hmSetting.screen_type.AOD) {
              for (var i = 1; i < 5; i++) {  // hide all symbols
                normal_step_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
              };
              let char_Angle = 63;
              if (valueStep != null && valueStep != undefined && isFinite(valueStep) && normal_step_circle_string.length > 0 && normal_step_circle_string.length < 6) {  // display data if it was possible to get it
                let normal_step_TextCircle_img_angle = 0;
                let normal_step_TextCircle_dot_img_angle = 0;
                normal_step_TextCircle_img_angle = toDegree(Math.atan2(normal_step_TextCircle_img_width / 2, 225));

                let firstSymbol = true;
                let index = 0;
                for (let char of normal_step_circle_string) {
                  let charCode = char.charCodeAt() - 48;
                  if (index >= 5) break;
                  if (charCode >= 0 && charCode < 10) {
                    if (!firstSymbol) char_Angle -= normal_step_TextCircle_img_angle;
                    firstSymbol = false;
                    normal_step_TextCircle[index].setProperty(hmUI.prop.ANGLE, char_Angle);
                    normal_step_TextCircle[index].setProperty(hmUI.prop.POS_X, 233 - normal_step_TextCircle_img_width / 2);
                    normal_step_TextCircle[index].setProperty(hmUI.prop.SRC, normal_step_TextCircle_ASCIIARRAY[charCode]);
                    normal_step_TextCircle[index].setProperty(hmUI.prop.VISIBLE, true);
                    char_Angle -= normal_step_TextCircle_img_angle;
                    index++;
                  };  // end if digit
                };  // end char of string
              }  // end isFinite

            };
          };

          if (progress_num == 3) {
            console.log('update text circle calorie_CALORIE');
            let valueCalories = calorie.current;
            let normal_calorie_circle_string = parseInt(valueCalories).toString();
            for (let i = 0; i < 3; i++) {
              normal_heart_rate_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
            };
            for (var i = 0; i < 5; i++) {  // hide all symbols
              normal_step_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
            };
            if (screenType != hmSetting.screen_type.AOD) {
              for (var i = 1; i < 4; i++) {  // hide all symbols
                normal_calorie_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
              };
              let char_Angle = 63;
              if (valueCalories != null && valueCalories != undefined && isFinite(valueCalories) && normal_calorie_circle_string.length > 0 && normal_calorie_circle_string.length < 6) {  // display data if it was possible to get it
                let normal_calorie_TextCircle_img_angle = 0;
                let normal_calorie_TextCircle_dot_img_angle = 0;
                normal_calorie_TextCircle_img_angle = toDegree(Math.atan2(normal_calorie_TextCircle_img_width / 2, 225));

                let firstSymbol = true;
                let index = 0;
                for (let char of normal_calorie_circle_string) {
                  let charCode = char.charCodeAt() - 48;
                  if (index >= 4) break;
                  if (charCode >= 0 && charCode < 10) {
                    if (!firstSymbol) char_Angle -= normal_calorie_TextCircle_img_angle;
                    firstSymbol = false;
                    normal_calorie_TextCircle[index].setProperty(hmUI.prop.ANGLE, char_Angle);
                    normal_calorie_TextCircle[index].setProperty(hmUI.prop.POS_X, 233 - normal_calorie_TextCircle_img_width / 2);
                    normal_calorie_TextCircle[index].setProperty(hmUI.prop.SRC, normal_calorie_TextCircle_ASCIIARRAY[charCode]);
                    normal_calorie_TextCircle[index].setProperty(hmUI.prop.VISIBLE, true);
                    char_Angle -= normal_calorie_TextCircle_img_angle;
                    index++;
                  };  // end if digit
                };  // end char of string
              }  // end isFinite
            };
          };

          console.log('update text circle battery_BATTERY');
          let valueBattery = battery.current;
          let normal_battery_circle_string = parseInt(valueBattery).toString();

          if (screenType != hmSetting.screen_type.AOD) {
            for (var i = 1; i < 3; i++) {  // hide all symbols
              normal_battery_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
            };
            let char_Angle = 296;
            if (valueBattery != null && valueBattery != undefined && isFinite(valueBattery) && normal_battery_circle_string.length > 0 && normal_battery_circle_string.length < 6) {  // display data if it was possible to get it
              let normal_battery_TextCircle_img_angle = 0;
              let normal_battery_TextCircle_dot_img_angle = 0;
              normal_battery_TextCircle_img_angle = toDegree(Math.atan2(normal_battery_TextCircle_img_width / 2, 225));
              // alignment = RIGHT
              let normal_battery_TextCircle_angleOffset = normal_battery_TextCircle_img_angle * (normal_battery_circle_string.length - 1);
              normal_battery_TextCircle_angleOffset = -normal_battery_TextCircle_angleOffset;
              char_Angle -= 2 * normal_battery_TextCircle_angleOffset;
              // alignment end

              let firstSymbol = true;
              let index = 0;
              for (let char of normal_battery_circle_string) {
                let charCode = char.charCodeAt() - 48;
                if (index >= 3) break;
                if (charCode >= 0 && charCode < 10) {
                  if (!firstSymbol) char_Angle -= normal_battery_TextCircle_img_angle;
                  firstSymbol = false;
                  normal_battery_TextCircle[index].setProperty(hmUI.prop.ANGLE, char_Angle);
                  normal_battery_TextCircle[index].setProperty(hmUI.prop.POS_X, 233 - normal_battery_TextCircle_img_width / 2);
                  normal_battery_TextCircle[index].setProperty(hmUI.prop.SRC, normal_battery_TextCircle_ASCIIARRAY[charCode]);
                  normal_battery_TextCircle[index].setProperty(hmUI.prop.VISIBLE, true);
                  char_Angle -= normal_battery_TextCircle_img_angle;
                  index++;
                };  // end if digit
              };  // end char of string
            }  // end isFinite

          };
        };

        //end of ignored block
        function scale_call() {
          console.log('scale_call()');

          console.log('update scales HEART');
          if (progress_num == 1) {
            let valueHeartRate = heart_rate.last;
            let targetHeartRate = 179;
            let progressHeartRate = (valueHeartRate - 71) / (targetHeartRate - 71);
            if (progressHeartRate < 0) progressHeartRate = 0;
            if (progressHeartRate > 1) progressHeartRate = 1;
            let progress_cs_normal_heart_rate = progressHeartRate;

            if (screenType != hmSetting.screen_type.AOD) {

              // normal_heart_rate_circle_scale_circle_scale
              let level = Math.round(progress_cs_normal_heart_rate * 100);
              if (normal_heart_rate_circle_scale) {
                normal_heart_rate_circle_scale.setProperty(hmUI.prop.MORE, {
                  center_x: 233,
                  center_y: 233,
                  start_angle: -111,
                  end_angle: -69,
                  radius: 215,
                  line_width: 25,
                  corner_flag: 0,
                  color: 0xFFD9D9D9,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                  level: level,
                });
              };
            };
            normal_heart_rate_circle_scale.setProperty(hmUI.prop.VISIBLE, true);
            normal_step_circle_scale.setProperty(hmUI.prop.VISIBLE, false);
            normal_calorie_circle_scale.setProperty(hmUI.prop.VISIBLE, false);
          };

          console.log('update scales STEP');
          if (progress_num == 2) {
            let valueStep = step.current;
            let targetStep = step.target;
            let progressStep = valueStep / targetStep;
            if (progressStep > 1) progressStep = 1;
            let progress_cs_normal_step = progressStep;

            if (screenType != hmSetting.screen_type.AOD) {

              // normal_step_circle_scale_circle_scale
              let level = Math.round(progress_cs_normal_step * 100);
              if (normal_step_circle_scale) {
                normal_step_circle_scale.setProperty(hmUI.prop.MORE, {
                  center_x: 233,
                  center_y: 233,
                  start_angle: -111,
                  end_angle: -69,
                  radius: 215,
                  line_width: 25,
                  corner_flag: 0,
                  color: 0xFFD9D9D9,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                  level: level,
                });
              };
            };
            normal_heart_rate_circle_scale.setProperty(hmUI.prop.VISIBLE, false);
            normal_step_circle_scale.setProperty(hmUI.prop.VISIBLE, true);
            normal_calorie_circle_scale.setProperty(hmUI.prop.VISIBLE, false);
          };

          console.log('update scales CALORIE');
          if (progress_num == 3) {
            let valueCalories = calorie.current;
            let targetCalories = calorie.target;
            let progressCalories = valueCalories / targetCalories;
            if (progressCalories > 1) progressCalories = 1;
            let progress_cs_normal_calorie = progressCalories;

            if (screenType != hmSetting.screen_type.AOD) {

              // normal_calorie_circle_scale_circle_scale
              let level = Math.round(progress_cs_normal_calorie * 100);
              if (normal_calorie_circle_scale) {
                normal_calorie_circle_scale.setProperty(hmUI.prop.MORE, {
                  center_x: 233,
                  center_y: 233,
                  start_angle: -111,
                  end_angle: -69,
                  radius: 215,
                  line_width: 25,
                  corner_flag: 0,
                  color: 0xFFD9D9D9,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                  level: level,
                });
              };
            };
            normal_heart_rate_circle_scale.setProperty(hmUI.prop.VISIBLE, false);
            normal_step_circle_scale.setProperty(hmUI.prop.VISIBLE, false);
            normal_calorie_circle_scale.setProperty(hmUI.prop.VISIBLE, true);
          };
        };

        function click_progress() {
          if (progress_num >= 3) { progress_num = 1; }
          else { progress_num = progress_num + 1; }
          if (progress_num == 1) {
            normal_calorie_icon_img.setProperty(hmUI.prop.VISIBLE, false);
            normal_step_icon_img.setProperty(hmUI.prop.VISIBLE, false);
            normal_heart_rate_icon_img.setProperty(hmUI.prop.VISIBLE, true);
          }
          if (progress_num == 2) {
            normal_heart_rate_icon_img.setProperty(hmUI.prop.VISIBLE, false);
            normal_calorie_icon_img.setProperty(hmUI.prop.VISIBLE, false);
            normal_step_icon_img.setProperty(hmUI.prop.VISIBLE, true);
          }
          if (progress_num == 3) {
            normal_heart_rate_icon_img.setProperty(hmUI.prop.VISIBLE, false);
            normal_step_icon_img.setProperty(hmUI.prop.VISIBLE, false);
            normal_calorie_icon_img.setProperty(hmUI.prop.VISIBLE, true);
          }

          scale_call();
          text_update();
        }

        function TimeUpdate() {
          let hr = time.hour;
          if (hr >= 12) {
            hr = hr - 12;
          }
          
          console.log();
          normal_image_img.setProperty(hmUI.prop.SRC, 'h_' + hr.toString() + '.png');
        }

        time.addEventListener(time.event.MINUTEEND, function () {
          TimeUpdate();
        });

        const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
          resume_call: (function () {
            console.log('resume_call()');
            scale_call();
            text_update();
            TimeUpdate();
          }),
          pause_call: (function () {
            console.log("ui pause");
          }),
        });

        //dynamic modify end
      },
      onInit() {
        logger.log('index page.js on init invoke');
      },
      build() {
        this.init_view();
        logger.log('index page.js on ready invoke');
      },
      onDestroy() {
        logger.log('index page.js on destroy invoke');
      }
    });
    ;
  })();
} catch (e) {
  console.log('Mini Program Error', e);
  e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
  ;
}