﻿
    /*
    ** Watch_Face_Editor tool
    ** watchface js version v1.0.1
    ** Copyright © CashaCX75. All Rights Reserved
    */

    try {

      (() => {

        var __$$app$$__ = __$$hmAppManager$$__.currentApp;
        var __$$module$$__ = __$$app$$__.current;
        //drink is a name,can modify
        var h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__), 'drink');

        'use strict';

        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_frame_animation_1 = ''
        let normal_frame_animation_2 = ''
        let normal_sun_current_text_img = ''
        let normal_heart_rate_text_text_img = ''
        let normal_temperature_high_text_img = ''
        let normal_temperature_low_text_img = ''
        let normal_temperature_current_text_img = ''
        let normal_step_current_text_img = ''
        let normal_date_img_date_month = ''
        let normal_date_img_date_day = ''
        let normal_date_day_separator_img = ''
        let normal_battery_image_progress_img_level = ''
        let normal_digital_clock_img_time = ''
        let idle_background_bg_img = ''
        let idle_date_img_date_month = ''
        let idle_date_img_date_day = ''
        let idle_date_day_separator_img = ''
        let idle_digital_clock_img_time = ''


        //dynamic modify end

        //not required
        const logger = DeviceRuntimeCore.HmLogger.getLogger("yeguang");

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({

          init_view() {

            //dynamic modify start
                    
            
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 466,
              h: 466,
              src: 'GTR4_Retro_Digital_Yellow_Bckg.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_frame_animation_1 = hmUI.createWidget(hmUI.widget.IMG_ANIM, {
              x: 235,
              y: 302,
              anim_path: "animation",
              anim_ext: "png",
              anim_prefix: "Black_TDots",
              anim_fps: 15,
              anim_size: 10,
              repeat_count: 0,
              anim_repeat: true,
              anim_status:hmUI.anim_status.START,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_frame_animation_2 = hmUI.createWidget(hmUI.widget.IMG_ANIM, {
              x: 235,
              y: 302,
              anim_path: "animation",
              anim_ext: "png",
              anim_prefix: "Black_TDots",
              anim_fps: 15,
              anim_size: 10,
              repeat_count: 0,
              anim_repeat: true,
              anim_status:hmUI.anim_status.START,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sun_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 259,
              y: 96,
              font_array: ["Cas_Tiny_Black__0.png","Cas_Tiny_Black__1.png","Cas_Tiny_Black__2.png","Cas_Tiny_Black__3.png","Cas_Tiny_Black__4.png","Cas_Tiny_Black__5.png","Cas_Tiny_Black__6.png","Cas_Tiny_Black__7.png","Cas_Tiny_Black__8.png","Cas_Tiny_Black__9.png"],
              padding: false,
              h_space: 7,
              invalid_image: 'Small_Black_Minus.png',
              dot_image: 'Small_Black_Minus.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.SUN_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 347,
              y: 218,
              font_array: ["Cas_Tiny_Black__0.png","Cas_Tiny_Black__1.png","Cas_Tiny_Black__2.png","Cas_Tiny_Black__3.png","Cas_Tiny_Black__4.png","Cas_Tiny_Black__5.png","Cas_Tiny_Black__6.png","Cas_Tiny_Black__7.png","Cas_Tiny_Black__8.png","Cas_Tiny_Black__9.png"],
              padding: false,
              h_space: 5,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_high_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 263,
              y: 219,
              font_array: ["Cas_Tiny_Black__0.png","Cas_Tiny_Black__1.png","Cas_Tiny_Black__2.png","Cas_Tiny_Black__3.png","Cas_Tiny_Black__4.png","Cas_Tiny_Black__5.png","Cas_Tiny_Black__6.png","Cas_Tiny_Black__7.png","Cas_Tiny_Black__8.png","Cas_Tiny_Black__9.png"],
              padding: false,
              h_space: 4,
              negative_image: 'Small_Black_Minus.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.WEATHER_HIGH,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_low_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 196,
              y: 219,
              font_array: ["Cas_Tiny_Black__0.png","Cas_Tiny_Black__1.png","Cas_Tiny_Black__2.png","Cas_Tiny_Black__3.png","Cas_Tiny_Black__4.png","Cas_Tiny_Black__5.png","Cas_Tiny_Black__6.png","Cas_Tiny_Black__7.png","Cas_Tiny_Black__8.png","Cas_Tiny_Black__9.png"],
              padding: false,
              h_space: 4,
              negative_image: 'Small_Black_Minus.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.WEATHER_LOW,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 128,
              y: 219,
              font_array: ["Cas_Tiny_Black__0.png","Cas_Tiny_Black__1.png","Cas_Tiny_Black__2.png","Cas_Tiny_Black__3.png","Cas_Tiny_Black__4.png","Cas_Tiny_Black__5.png","Cas_Tiny_Black__6.png","Cas_Tiny_Black__7.png","Cas_Tiny_Black__8.png","Cas_Tiny_Black__9.png"],
              padding: false,
              h_space: 4,
              negative_image: 'Small_Black_Minus.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 265,
              y: 138,
              font_array: ["Cas_Tiny_Black__0.png","Cas_Tiny_Black__1.png","Cas_Tiny_Black__2.png","Cas_Tiny_Black__3.png","Cas_Tiny_Black__4.png","Cas_Tiny_Black__5.png","Cas_Tiny_Black__6.png","Cas_Tiny_Black__7.png","Cas_Tiny_Black__8.png","Cas_Tiny_Black__9.png"],
              padding: false,
              h_space: 5,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_month = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 168,
              month_startY: 97,
              month_sc_array: ["Cas_Tiny_Black__0.png","Cas_Tiny_Black__1.png","Cas_Tiny_Black__2.png","Cas_Tiny_Black__3.png","Cas_Tiny_Black__4.png","Cas_Tiny_Black__5.png","Cas_Tiny_Black__6.png","Cas_Tiny_Black__7.png","Cas_Tiny_Black__8.png","Cas_Tiny_Black__9.png"],
              month_tc_array: ["Cas_Tiny_Black__0.png","Cas_Tiny_Black__1.png","Cas_Tiny_Black__2.png","Cas_Tiny_Black__3.png","Cas_Tiny_Black__4.png","Cas_Tiny_Black__5.png","Cas_Tiny_Black__6.png","Cas_Tiny_Black__7.png","Cas_Tiny_Black__8.png","Cas_Tiny_Black__9.png"],
              month_en_array: ["Cas_Tiny_Black__0.png","Cas_Tiny_Black__1.png","Cas_Tiny_Black__2.png","Cas_Tiny_Black__3.png","Cas_Tiny_Black__4.png","Cas_Tiny_Black__5.png","Cas_Tiny_Black__6.png","Cas_Tiny_Black__7.png","Cas_Tiny_Black__8.png","Cas_Tiny_Black__9.png"],
              month_zero: 1,
              month_space: 5,
              month_align: hmUI.align.LEFT,
              month_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 118,
              day_startY: 97,
              day_sc_array: ["Cas_Tiny_Black__0.png","Cas_Tiny_Black__1.png","Cas_Tiny_Black__2.png","Cas_Tiny_Black__3.png","Cas_Tiny_Black__4.png","Cas_Tiny_Black__5.png","Cas_Tiny_Black__6.png","Cas_Tiny_Black__7.png","Cas_Tiny_Black__8.png","Cas_Tiny_Black__9.png"],
              day_tc_array: ["Cas_Tiny_Black__0.png","Cas_Tiny_Black__1.png","Cas_Tiny_Black__2.png","Cas_Tiny_Black__3.png","Cas_Tiny_Black__4.png","Cas_Tiny_Black__5.png","Cas_Tiny_Black__6.png","Cas_Tiny_Black__7.png","Cas_Tiny_Black__8.png","Cas_Tiny_Black__9.png"],
              day_en_array: ["Cas_Tiny_Black__0.png","Cas_Tiny_Black__1.png","Cas_Tiny_Black__2.png","Cas_Tiny_Black__3.png","Cas_Tiny_Black__4.png","Cas_Tiny_Black__5.png","Cas_Tiny_Black__6.png","Cas_Tiny_Black__7.png","Cas_Tiny_Black__8.png","Cas_Tiny_Black__9.png"],
              day_zero: 1,
              day_space: 5,
              day_align: hmUI.align.LEFT,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_day_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 150,
              y: 97,
              src: 'Small_Black_Minus.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 64,
              y: 221,
              image_array: ["GTR4_Casio_Batt__1.png","GTR4_Casio_Batt__2.png","GTR4_Casio_Batt__3.png","GTR4_Casio_Batt__4.png","GTR4_Casio_Batt__5.png","GTR4_Casio_Batt__6.png","GTR4_Casio_Batt__7.png","GTR4_Casio_Batt__8.png","GTR4_Casio_Batt__9.png","GTR4_Casio_Batt__10.png","GTR4_Casio_Batt__11.png","GTR4_Casio_Batt__12.png","GTR4_Casio_Batt__13.png"],
              image_length: 13,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 112,
              hour_startY: 256,
              hour_array: ["Cas_Big_Bold_Black_0.png","Cas_Big_Bold_Black_1.png","Cas_Big_Bold_Black_2.png","Cas_Big_Bold_Black_3.png","Cas_Big_Bold_Black_4.png","Cas_Big_Bold_Black_5.png","Cas_Big_Bold_Black_6.png","Cas_Big_Bold_Black_7.png","Cas_Big_Bold_Black_8.png","Cas_Big_Bold_Black_9.png"],
              hour_zero: 1,
              hour_space: 6,
              hour_align: hmUI.align.LEFT,

              minute_startX: 251,
              minute_startY: 256,
              minute_array: ["Cas_Big_Bold_Black_0.png","Cas_Big_Bold_Black_1.png","Cas_Big_Bold_Black_2.png","Cas_Big_Bold_Black_3.png","Cas_Big_Bold_Black_4.png","Cas_Big_Bold_Black_5.png","Cas_Big_Bold_Black_6.png","Cas_Big_Bold_Black_7.png","Cas_Big_Bold_Black_8.png","Cas_Big_Bold_Black_9.png"],
              minute_zero: 1,
              minute_space: 7,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              second_startX: 372,
              second_startY: 288,
              second_array: ["Cas_Tiny_Black__0.png","Cas_Tiny_Black__1.png","Cas_Tiny_Black__2.png","Cas_Tiny_Black__3.png","Cas_Tiny_Black__4.png","Cas_Tiny_Black__5.png","Cas_Tiny_Black__6.png","Cas_Tiny_Black__7.png","Cas_Tiny_Black__8.png","Cas_Tiny_Black__9.png"],
              second_zero: 1,
              second_space: 8,
              second_follow: 0,
              second_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            idle_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 466,
              h: 466,
              src: 'GTR4_Retro_Digital_Yellow_Bckg_AOD.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_month = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 168,
              month_startY: 97,
              month_sc_array: ["Cas_Tiny_White__0.png","Cas_Tiny_White__1.png","Cas_Tiny_White__2.png","Cas_Tiny_White__3.png","Cas_Tiny_White__4.png","Cas_Tiny_White__5.png","Cas_Tiny_White__6.png","Cas_Tiny_White__7.png","Cas_Tiny_White__8.png","Cas_Tiny_White__9.png"],
              month_tc_array: ["Cas_Tiny_White__0.png","Cas_Tiny_White__1.png","Cas_Tiny_White__2.png","Cas_Tiny_White__3.png","Cas_Tiny_White__4.png","Cas_Tiny_White__5.png","Cas_Tiny_White__6.png","Cas_Tiny_White__7.png","Cas_Tiny_White__8.png","Cas_Tiny_White__9.png"],
              month_en_array: ["Cas_Tiny_White__0.png","Cas_Tiny_White__1.png","Cas_Tiny_White__2.png","Cas_Tiny_White__3.png","Cas_Tiny_White__4.png","Cas_Tiny_White__5.png","Cas_Tiny_White__6.png","Cas_Tiny_White__7.png","Cas_Tiny_White__8.png","Cas_Tiny_White__9.png"],
              month_zero: 1,
              month_space: 5,
              month_align: hmUI.align.LEFT,
              month_is_character: false,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 118,
              day_startY: 97,
              day_sc_array: ["Cas_Tiny_White__0.png","Cas_Tiny_White__1.png","Cas_Tiny_White__2.png","Cas_Tiny_White__3.png","Cas_Tiny_White__4.png","Cas_Tiny_White__5.png","Cas_Tiny_White__6.png","Cas_Tiny_White__7.png","Cas_Tiny_White__8.png","Cas_Tiny_White__9.png"],
              day_tc_array: ["Cas_Tiny_White__0.png","Cas_Tiny_White__1.png","Cas_Tiny_White__2.png","Cas_Tiny_White__3.png","Cas_Tiny_White__4.png","Cas_Tiny_White__5.png","Cas_Tiny_White__6.png","Cas_Tiny_White__7.png","Cas_Tiny_White__8.png","Cas_Tiny_White__9.png"],
              day_en_array: ["Cas_Tiny_White__0.png","Cas_Tiny_White__1.png","Cas_Tiny_White__2.png","Cas_Tiny_White__3.png","Cas_Tiny_White__4.png","Cas_Tiny_White__5.png","Cas_Tiny_White__6.png","Cas_Tiny_White__7.png","Cas_Tiny_White__8.png","Cas_Tiny_White__9.png"],
              day_zero: 1,
              day_space: 5,
              day_align: hmUI.align.LEFT,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_day_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 150,
              y: 97,
              src: 'Cas_Tiny_White__-.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 112,
              hour_startY: 256,
              hour_array: ["Cas_Big_Bold_White_0.png","Cas_Big_Bold_White_1.png","Cas_Big_Bold_White_2.png","Cas_Big_Bold_White_3.png","Cas_Big_Bold_White_4.png","Cas_Big_Bold_White_5.png","Cas_Big_Bold_White_6.png","Cas_Big_Bold_White_7.png","Cas_Big_Bold_White_8.png","Cas_Big_Bold_White_9.png"],
              hour_zero: 1,
              hour_space: 6,
              hour_align: hmUI.align.LEFT,

              minute_startX: 251,
              minute_startY: 256,
              minute_array: ["Cas_Big_Bold_White_0.png","Cas_Big_Bold_White_1.png","Cas_Big_Bold_White_2.png","Cas_Big_Bold_White_3.png","Cas_Big_Bold_White_4.png","Cas_Big_Bold_White_5.png","Cas_Big_Bold_White_6.png","Cas_Big_Bold_White_7.png","Cas_Big_Bold_White_8.png","Cas_Big_Bold_White_9.png"],
              minute_zero: 1,
              minute_space: 7,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_AOD,
            });

            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                normal_frame_animation_1.setProperty(hmUI.prop.ANIM_STATUS,hmUI.anim_status.START);
                normal_frame_animation_2.setProperty(hmUI.prop.ANIM_STATUS,hmUI.anim_status.START);

              }),
              pause_call: (function () {
                normal_frame_animation_1.setProperty(hmUI.prop.ANIM_STATUS,hmUI.anim_status.STOP);
                normal_frame_animation_2.setProperty(hmUI.prop.ANIM_STATUS,hmUI.anim_status.STOP);

              }),
            });

            //dynamic modify end
          },

          onInit() {
            console.log('index page.js on init invoke')

            this.init_view()

          },

          onReady() {
            console.log('index page.js on ready invoke')
          },

          onShow() {
            console.log('index page.js on show invoke')
          },

          onHide() {
            console.log('index page.js on hide invoke')
          },

          onDestory() {
            console.log('index page.js on destory invoke')
          },
        });

      })()
    } catch (e) {
      console.log(e)
    }
  