﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        const logger = Logger.getLogger('watchface_SashaCX75');
        //end of ignored block

        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_system_disconnect_img = ''
        let normal_date_img_date_day = ''
        let normal_compass_direction_pointer_img = ''
        let normal_compass_text_img = ''
        let normal_analog_clock_time_pointer_hour = ''
        let normal_analog_clock_time_pointer_minute = ''
        let normal_analog_clock_time_pointer_second = ''
        let idle_background_bg_img = ''
        let idle_system_disconnect_img = ''
        let idle_date_img_date_day = ''
        let idle_analog_clock_time_pointer_hour = ''
        let idle_analog_clock_time_pointer_minute = ''
        let Button_1 = ''
        let Button_2 = ''
        let Button_3 = ''


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            console.log('Watch_Face.ScreenNormal');
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 466,
              h: 466,
              src: 'bg.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 176,
              y: 132,
              src: 'bt.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 364,
              day_startY: 217,
              day_sc_array: ["fs_0.png","fs_1.png","fs_2.png","fs_3.png","fs_4.png","fs_5.png","fs_6.png","fs_7.png","fs_8.png","fs_9.png"],
              day_tc_array: ["fs_0.png","fs_1.png","fs_2.png","fs_3.png","fs_4.png","fs_5.png","fs_6.png","fs_7.png","fs_8.png","fs_9.png"],
              day_en_array: ["fs_0.png","fs_1.png","fs_2.png","fs_3.png","fs_4.png","fs_5.png","fs_6.png","fs_7.png","fs_8.png","fs_9.png"],
              day_zero: 1,
              day_space: 0,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            const deviceInfo = hmSetting.getDeviceInfo();
            
            // normal_compass_custom_pointer_img = hmUI.createWidget(hmUI.widget.CUSTOM_POINTER, {
              // src: 'compass.png',
              // center_x: 233,
              // center_y: 233,
              // x: 233,
              // y: 233,
              // start_angle: 0,
              // end_angle: 360,
              // type: hmUI.data_type.COMPASS,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });


            //start of ignored block
            normal_compass_direction_pointer_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: deviceInfo.width,
              h: deviceInfo.height,
              pos_x: 233 - 233,
              pos_y: 233 - 233,
              center_x: 233,
              center_y: 233,
              src: 'compass.png',
              angle: 0,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            //end of ignored block

            normal_compass_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 199,
              y: 99,
              font_array: ["0.png","1.png","2.png","3.png","4.png","5.png","6.png","7.png","8.png","9.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'du.png',
              unit_tc: 'du.png',
              unit_en: 'du.png',
              align_h: hmUI.align.CENTER_H,
              // type: hmUI.data_type.COMPASS,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_hour = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              hour_path: '20.png',
              hour_centerX: 233,
              hour_centerY: 233,
              hour_posX: 22,
              hour_posY: 133,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_minute = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              minute_path: '21.png',
              minute_centerX: 233,
              minute_centerY: 233,
              minute_posX: 17,
              minute_posY: 186,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_second = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              second_path: '22.png',
              second_centerX: 233,
              second_centerY: 233,
              second_posX: 17,
              second_posY: 196,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            console.log('Watch_Face.ScreenAOD');
            idle_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 466,
              h: 466,
              src: 'aod.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 176,
              y: 132,
              src: 'bt.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 364,
              day_startY: 217,
              day_sc_array: ["fs_0.png","fs_1.png","fs_2.png","fs_3.png","fs_4.png","fs_5.png","fs_6.png","fs_7.png","fs_8.png","fs_9.png"],
              day_tc_array: ["fs_0.png","fs_1.png","fs_2.png","fs_3.png","fs_4.png","fs_5.png","fs_6.png","fs_7.png","fs_8.png","fs_9.png"],
              day_en_array: ["fs_0.png","fs_1.png","fs_2.png","fs_3.png","fs_4.png","fs_5.png","fs_6.png","fs_7.png","fs_8.png","fs_9.png"],
              day_zero: 1,
              day_space: 0,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_analog_clock_time_pointer_hour = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              hour_path: 'h_aod.png',
              hour_centerX: 233,
              hour_centerY: 233,
              hour_posX: 22,
              hour_posY: 133,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_analog_clock_time_pointer_minute = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              minute_path: 'm_aod.png',
              minute_centerX: 233,
              minute_centerY: 233,
              minute_posX: 17,
              minute_posY: 186,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            console.log('Watch_Face.Buttons');
            Button_1 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 197,
              y: 197,
              w: 78,
              h: 78,
              text: '',
              color: 0xFFFF8C00,
              text_size: 24,
              press_src: 'Empty.png',
              normal_src: 'Empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'CountdownAppScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_2 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 340,
              y: 205,
              w: 78,
              h: 58,
              text: '',
              color: 0xFFFF8C00,
              text_size: 24,
              press_src: 'Empty.png',
              normal_src: 'Empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'ScheduleCalScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_3 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 184,
              y: 97,
              w: 97,
              h: 39,
              text: '',
              color: 0xFFFF8C00,
              text_size: 24,
              press_src: 'Empty.png',
              normal_src: 'Empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'CompassScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            let screenType = hmSetting.getScreenType();
            //start of ignored block
            console.log('compass_update()');
            if (screenType == hmSetting.screen_type.WATCHFACE){
              compass = hmSensor.createSensor(hmSensor.id.COMPASS);
              compass.start();

              if (compass.direction_angle && compass.direction  && compass.direction_angle != 'INVALID') { // initial data
                // Compass Pointer
                let compass_direction_angle = parseInt(compass.direction_angle);
                normal_compass_direction_pointer_img.setProperty(hmUI.prop.ANGLE, -compass_direction_angle);
                // Compass Number
                let normal_compass_direction_angle_text = compass_direction_angle.toString();
                normal_compass_text_img.setProperty(hmUI.prop.TEXT, normal_compass_direction_angle_text);

              } else { // error data
                normal_compass_direction_pointer_img.setProperty(hmUI.prop.ANGLE, 0);
                normal_compass_text_img.setProperty(hmUI.prop.TEXT, '-');

              }

              compass.addEventListener(hmSensor.event.CHANGE, function (compass_res) { // change values when changing direction

                if (compass_res.calibration_status) {
                  // Compass Pointer
                  let compass_direction_angle = parseInt(compass_res.direction_angle);
                  normal_compass_direction_pointer_img.setProperty(hmUI.prop.ANGLE, -compass_direction_angle);
                  // Compass Number
                  let normal_compass_direction_angle_text = compass_direction_angle.toString();
                  normal_compass_text_img.setProperty(hmUI.prop.TEXT, normal_compass_direction_angle_text);

                } else { // error data
                  normal_compass_direction_pointer_img.setProperty(hmUI.prop.ANGLE, 0);
                  normal_compass_text_img.setProperty(hmUI.prop.TEXT, '-');

                }

              }); // Listener end

            };
            //end of ignored block

            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                console.log('resume_call()');
                if (compass && screenType == hmSetting.screen_type.WATCHFACE) compass.start();

              }),
              pause_call: (function () {
                console.log('pause_call()');
                if (compass) compass.stop();

              }),
            });

                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}