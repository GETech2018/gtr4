﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        const logger = Logger.getLogger('watchface_SashaCX75');
        //end of ignored block

        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_date_img_date_month = ''
        let normal_date_img_date_day = ''
        let normal_battery_text_text_img = ''
        let normal_battery_image_progress_img_level = ''
        let normal_stand_target_text_img = ''
        let normal_stand_current_text_img = ''
        let normal_fat_burning_current_text_img = ''
        let normal_step_current_text_img = ''
        let normal_weather_image_progress_img_level = ''
        let normal_temperature_current_text_img = ''
        let normal_group_ForecastWeather = ''
        let normal_forecast_date_week_img = new Array(4);
        let normal_forecast_date_week_img_array = ['week_0.png', 'week_1.png', 'week_2.png', 'week_3.png', 'week_4.png', 'week_5.png', 'week_6.png'];
        let normal_forecast_high_low_text_img = new Array(4);
        let normal_forecast_image_progress_img_level = new Array(4);
        let normal_forecast_image_array = ['w_0.png', 'w_1.png', 'w_2.png', 'w_3.png', 'w_4.png', 'w_5.png', 'w_6.png', 'w_7.png', 'w_8.png', 'w_9.png', 'w_10.png', 'w_11.png', 'w_12.png', 'w_13.png', 'w_14.png', 'w_15.png', 'w_16.png', 'w_17.png', 'w_18.png', 'w_19.png', 'w_20.png', 'w_21.png', 'w_22.png', 'w_23.png', 'w_24.png', 'w_25.png', 'w_26.png', 'w_27.png', 'w_28.png'];
        let normal_system_disconnect_img = ''
        let normal_system_clock_img = ''
        let normal_digital_clock_img_time = ''
        let normal_analog_clock_time_pointer_second = ''
        let idle_background_bg = ''
        let idle_date_img_date_month = ''
        let idle_date_img_date_day = ''
        let idle_battery_text_text_img = ''
        let idle_battery_image_progress_img_level = ''
        let idle_digital_clock_img_time = ''
        let normal_countdown_jumpable_img_click = ''
        let normal_alarm_jumpable_img_click = ''
        let normal_sunrise_jumpable_img_click = ''
        let normal_altimeter_jumpable_img_click = ''
        let normal_temperature_jumpable_img_click = ''
        let normal_step_jumpable_img_click = ''
        let Button_1 = ''
        let Button_2 = ''
        let Button_3 = ''
        let timeSensor = ''


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            console.log('Watch_Face.ScreenNormal');
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 466,
              h: 466,
              src: 'bg.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_month = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 241,
              month_startY: 39,
              month_sc_array: ["font_0.png","font_1.png","font_2.png","font_3.png","font_4.png","font_5.png","font_6.png","font_7.png","font_8.png","font_9.png"],
              month_tc_array: ["font_0.png","font_1.png","font_2.png","font_3.png","font_4.png","font_5.png","font_6.png","font_7.png","font_8.png","font_9.png"],
              month_en_array: ["font_0.png","font_1.png","font_2.png","font_3.png","font_4.png","font_5.png","font_6.png","font_7.png","font_8.png","font_9.png"],
              month_zero: 1,
              month_space: 0,
              month_align: hmUI.align.CENTER_H,
              month_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 197,
              day_startY: 39,
              day_sc_array: ["font_0.png","font_1.png","font_2.png","font_3.png","font_4.png","font_5.png","font_6.png","font_7.png","font_8.png","font_9.png"],
              day_tc_array: ["font_0.png","font_1.png","font_2.png","font_3.png","font_4.png","font_5.png","font_6.png","font_7.png","font_8.png","font_9.png"],
              day_en_array: ["font_0.png","font_1.png","font_2.png","font_3.png","font_4.png","font_5.png","font_6.png","font_7.png","font_8.png","font_9.png"],
              day_zero: 1,
              day_space: 0,
              day_unit_sc: 'dot11.png',
              day_unit_tc: 'dot11.png',
              day_unit_en: 'dot11.png',
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 210,
              y: 409,
              font_array: ["font_0.png","font_1.png","font_2.png","font_3.png","font_4.png","font_5.png","font_6.png","font_7.png","font_8.png","font_9.png"],
              padding: false,
              h_space: 0,
              unit_sc: '%.png',
              unit_tc: '%.png',
              unit_en: '%.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 220,
              y: 437,
              image_array: ["bt_1.png","bt_2.png","bt_3.png","bt_4.png","bt_5.png","bt_6.png","bt_7.png","bt_8.png","bt_9.png","bt_10.png","bt_11.png"],
              image_length: 11,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_stand_target_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 325,
              y: 361,
              font_array: ["font_0.png","font_1.png","font_2.png","font_3.png","font_4.png","font_5.png","font_6.png","font_7.png","font_8.png","font_9.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STAND_TARGET,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_stand_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 283,
              y: 361,
              font_array: ["font_0.png","font_1.png","font_2.png","font_3.png","font_4.png","font_5.png","font_6.png","font_7.png","font_8.png","font_9.png"],
              padding: true,
              h_space: 0,
              unit_sc: 'dot_1.png',
              unit_tc: 'dot_1.png',
              unit_en: 'dot_1.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.STAND,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_fat_burning_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 213,
              y: 361,
              font_array: ["font_0.png","font_1.png","font_2.png","font_3.png","font_4.png","font_5.png","font_6.png","font_7.png","font_8.png","font_9.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.FAT_BURNING,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 112,
              y: 361,
              font_array: ["font_0.png","font_1.png","font_2.png","font_3.png","font_4.png","font_5.png","font_6.png","font_7.png","font_8.png","font_9.png"],
              padding: false,
              h_space: -1,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 77,
              y: 198,
              image_array: ["w_1.png","w_2.png","w_3.png","w_4.png","w_5.png","w_6.png","w_7.png","w_8.png","w_9.png","w_10.png","w_11.png","w_12.png","w_13.png","w_14.png","w_15.png","w_16.png","w_17.png","w_18.png","w_19.png","w_20.png","w_21.png","w_22.png","w_23.png","w_24.png","w_25.png","w_26.png","w_27.png","w_28.png","weatherpinter.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 73,
              y: 169,
              font_array: ["font_0.png","font_1.png","font_2.png","font_3.png","font_4.png","font_5.png","font_6.png","font_7.png","font_8.png","font_9.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'gradus.png',
              unit_tc: 'gradus.png',
              unit_en: 'gradus.png',
              negative_image: 'dot11.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            let screenType = hmSetting.getScreenType();            
            // normal_Weather_FewDays = hmUI.createWidget(hmUI.widget.FewDays, {
              // x: 141,
              // y: 198,
              // ColumnWidth: 73,
              // DaysCount: 4,
            // });
            
            normal_group_ForecastWeather = hmUI.createWidget(hmUI.widget.GROUP, {
              x: 141,
              y: 198,
              h: 0,
              w: 0,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_forecast_date_week_img = normal_group_ForecastWeather.createWidget(hmUI.widget.IMG_LEVEL_Options, {
              // x: 5,
              // y: 48,
              // image_array: ["week_0.png","week_1.png","week_2.png","week_3.png","week_4.png","week_5.png","week_6.png"],
              // image_length: 7,
              // type: hmUI.data_type.forecast_date_week_img,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            //start of ignored block
            if (screenType == hmSetting.screen_type.WATCHFACE) {
              for (let i = 0; i < 4; i++) {
                normal_forecast_date_week_img[i] = normal_group_ForecastWeather.createWidget(hmUI.widget.IMG, {
                  x: 5 + i*73,
                  y: 48,
                  src: normal_forecast_date_week_img_array[0],
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });
              };
            };
            //end of ignored block

            if (!timeSensor) timeSensor = hmSensor.createSensor(hmSensor.id.TIME);
            // normal_forecast_high_low_text_img = normal_group_ForecastWeather.createWidget(hmUI.widget.TEXT_IMG_Options, {
              // x: 0,
              // y: -20,
              // font_array: ["fonts_0.png","fonts_1.png","fonts_2.png","fonts_3.png","fonts_4.png","fonts_5.png","fonts_6.png","fonts_7.png","fonts_8.png","fonts_9.png"],
              // padding: false,
              // h_space: 0,
              // negative_image: 'dot1.png',
              // dot_image: 'dot1.png',
              // separator_image: 'dots_1.png',
              // align_h: hmUI.align.CENTER_H,
              // type: hmUI.data_type.forecast_high_low_text_img,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            //start of ignored block
            if (screenType == hmSetting.screen_type.WATCHFACE) {
              for (let i = 0; i < 4; i++) {
                normal_forecast_high_low_text_img[i] = normal_group_ForecastWeather.createWidget(hmUI.widget.TEXT_IMG, {
                  x: 0 + i*73,
                  y: -20,
                  font_array: ["fonts_0.png","fonts_1.png","fonts_2.png","fonts_3.png","fonts_4.png","fonts_5.png","fonts_6.png","fonts_7.png","fonts_8.png","fonts_9.png"],
                  padding: false,
                  h_space: 0,
                  negative_image: 'dot1.png',
                  dot_image: 'dots_1.png',
                  align_h: hmUI.align.CENTER_H,
                  // type: hmUI.data_type.FORECAST_NUMBER_MAX,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });
              };
            };
            //end of ignored block

            // normal_forecast_image_progress_img_level = normal_group_ForecastWeather.createWidget(hmUI.widget.IMG_LEVEL_Options, {
              // x: 8,
              // y: 5,
              // image_array: ["w_0.png","w_1.png","w_2.png","w_3.png","w_4.png","w_5.png","w_6.png","w_7.png","w_8.png","w_9.png","w_10.png","w_11.png","w_12.png","w_13.png","w_14.png","w_15.png","w_16.png","w_17.png","w_18.png","w_19.png","w_20.png","w_21.png","w_22.png","w_23.png","w_24.png","w_25.png","w_26.png","w_27.png","w_28.png"],
              // image_length: 29,
              // type: hmUI.data_type.forecast_image,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            //start of ignored block
            if (screenType == hmSetting.screen_type.WATCHFACE) {
              for (let i = 0; i < 4; i++) {
                normal_forecast_image_progress_img_level[i] = normal_group_ForecastWeather.createWidget(hmUI.widget.IMG, {
                  x: 8 + i*73,
                  y: 5,
                  src: normal_forecast_image_array[25],
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });
              };
            };
            //end of ignored block

            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 392,
              y: 284,
              src: 'bt.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 51,
              y: 283,
              src: 'al.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 118,
              hour_startY: 73,
              hour_array: ["107.png","108.png","109.png","110.png","111.png","112.png","113.png","114.png","115.png","116.png"],
              hour_zero: 1,
              hour_space: 5,
              hour_angle: 0,
              hour_unit_sc: '133.png',
              hour_unit_tc: '133.png',
              hour_unit_en: '133.png',
              hour_align: hmUI.align.LEFT,

              minute_startX: 248,
              minute_startY: 73,
              minute_array: ["123.png","124.png","125.png","126.png","127.png","128.png","129.png","130.png","131.png","132.png"],
              minute_zero: 1,
              minute_space: 5,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_second = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              second_path: 'weatherpinter.png',
              second_centerX: 233,
              second_centerY: 233,
              second_posX: 11,
              second_posY: 235,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            console.log('Watch_Face.ScreenAOD');
            idle_background_bg = hmUI.createWidget(hmUI.widget.FILL_RECT, {
              x: 0,
              y: 0,
              w: 466,
              h: 466,
              color: '0xFF000000',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_month = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 241,
              month_startY: 39,
              month_sc_array: ["font_0.png","font_1.png","font_2.png","font_3.png","font_4.png","font_5.png","font_6.png","font_7.png","font_8.png","font_9.png"],
              month_tc_array: ["font_0.png","font_1.png","font_2.png","font_3.png","font_4.png","font_5.png","font_6.png","font_7.png","font_8.png","font_9.png"],
              month_en_array: ["font_0.png","font_1.png","font_2.png","font_3.png","font_4.png","font_5.png","font_6.png","font_7.png","font_8.png","font_9.png"],
              month_zero: 1,
              month_space: 0,
              month_align: hmUI.align.CENTER_H,
              month_is_character: false,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 197,
              day_startY: 39,
              day_sc_array: ["font_0.png","font_1.png","font_2.png","font_3.png","font_4.png","font_5.png","font_6.png","font_7.png","font_8.png","font_9.png"],
              day_tc_array: ["font_0.png","font_1.png","font_2.png","font_3.png","font_4.png","font_5.png","font_6.png","font_7.png","font_8.png","font_9.png"],
              day_en_array: ["font_0.png","font_1.png","font_2.png","font_3.png","font_4.png","font_5.png","font_6.png","font_7.png","font_8.png","font_9.png"],
              day_zero: 1,
              day_space: 0,
              day_unit_sc: 'dot11.png',
              day_unit_tc: 'dot11.png',
              day_unit_en: 'dot11.png',
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 210,
              y: 409,
              font_array: ["font_0.png","font_1.png","font_2.png","font_3.png","font_4.png","font_5.png","font_6.png","font_7.png","font_8.png","font_9.png"],
              padding: false,
              h_space: 0,
              unit_sc: '%.png',
              unit_tc: '%.png',
              unit_en: '%.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_battery_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 220,
              y: 437,
              image_array: ["bt_1.png","bt_2.png","bt_3.png","bt_4.png","bt_5.png","bt_6.png","bt_7.png","bt_8.png","bt_9.png","bt_10.png","bt_11.png"],
              image_length: 11,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 118,
              hour_startY: 212,
              hour_array: ["107.png","108.png","109.png","110.png","111.png","112.png","113.png","114.png","115.png","116.png"],
              hour_zero: 1,
              hour_space: 5,
              hour_angle: 0,
              hour_unit_sc: '133.png',
              hour_unit_tc: '133.png',
              hour_unit_en: '133.png',
              hour_align: hmUI.align.LEFT,

              minute_startX: 248,
              minute_startY: 212,
              minute_array: ["123.png","124.png","125.png","126.png","127.png","128.png","129.png","130.png","131.png","132.png"],
              minute_zero: 1,
              minute_space: 5,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_AOD,
            });
            console.log('Watch_Face.Shortcuts');

            normal_countdown_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 277,
              y: 65,
              w: 63,
              h: 63,
              type: hmUI.data_type.COUNT_DOWN,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_alarm_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 39,
              y: 274,
              w: 49,
              h: 49,
              type: hmUI.data_type.ALARM_CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sunrise_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 345,
              y: 165,
              w: 58,
              h: 97,
              type: hmUI.data_type.SUN_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_altimeter_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 204,
              y: 165,
              w: 58,
              h: 97,
              type: hmUI.data_type.ALTIMETER,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 78,
              y: 165,
              w: 58,
              h: 97,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 112,
              y: 291,
              w: 73,
              h: 97,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            console.log('Watch_Face.Buttons');
            Button_1 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 204,
              y: 408,
              w: 73,
              h: 53,
              text: '',
              color: 0xFFFF8C00,
              text_size: 24,
              press_src: 'Empty.png',
              normal_src: 'Empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'Settings_batteryManagerScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_2 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 284,
              y: 291,
              w: 73,
              h: 97,
              text: '',
              color: 0xFFFF8C00,
              text_size: 24,
              press_src: 'Empty.png',
              normal_src: 'Empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'activityWeekShowScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_3 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 199,
              y: 291,
              w: 73,
              h: 97,
              text: '',
              color: 0xFFFF8C00,
              text_size: 24,
              press_src: 'Empty.png',
              normal_src: 'Empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'SportStatusScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            const weatherSensor = hmSensor.createSensor(hmSensor.id.WEATHER);
            //start of ignored block
            function weather_few_days() {
              console.log('weather_few_days()');
              let weatherData = weatherSensor.getForecastWeather();
              let forecastData = weatherData.forecastData;

              for (let i = 0; i < 4; i++) {
                // DOW images
                if (screenType == hmSetting.screen_type.WATCHFACE) {
                  let dowIndex = timeSensor.week - 1;
                  dowIndex += i;
                  while (dowIndex >= 7) {dowIndex -= 7;}
                  normal_forecast_date_week_img[i].setProperty(hmUI.prop.SRC, normal_forecast_date_week_img_array[dowIndex]);
                };
              
                // Number_MaxMin
                let max_min_Temperature_img = '-';
                if (i < forecastData.count) {
                  max_min_Temperature_img = forecastData.data[i].high.toString();
                  max_min_Temperature_img += '.';
                  max_min_Temperature_img += forecastData.data[i].low.toString();
                };
                if (screenType == hmSetting.screen_type.WATCHFACE) {
                  normal_forecast_high_low_text_img[i].setProperty(hmUI.prop.TEXT, max_min_Temperature_img);
                };
                
                // Images
                if (screenType == hmSetting.screen_type.WATCHFACE) {
                  let weatherIndex = 25
                  if (i < forecastData.count) weatherIndex = forecastData.data[i].index;
                  normal_forecast_image_progress_img_level[i].setProperty(hmUI.prop.SRC, normal_forecast_image_array[weatherIndex]);
                };
              
              };  // end for

            };
            //end of ignored block

            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                console.log('resume_call()');

                weather_few_days();
              }),
            });

                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}