﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        const logger = Logger.getLogger('watchface_SashaCX75');
        //end of ignored block

        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_battery_image_progress_img_level = ''
        let normal_digital_clock_img_time = ''
        let normal_analog_clock_time_pointer_smooth_second = ''
        let idle_background_bg = ''
        let idle_digital_clock_img_time = ''
        let idle_digital_clock_hour_separator_img = ''
        let idle_step_icon_img = ''


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 466,
              h: 466,
              src: 'backG_8.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 200,
              y: 421,
              image_array: ["batt_level_grey_3d_0001.png","batt_level_grey_3d_0002.png","batt_level_grey_3d_0003.png","batt_level_grey_3d_0004.png","batt_level_grey_3d_0005.png","batt_level_grey_3d_0006.png"],
              image_length: 6,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: -91,
              hour_startY: -94,
              hour_array: ["cream_dark_0001.png","cream_dark_0002.png","cream_dark_0003.png","cream_dark_0004.png","cream_dark_0005.png","cream_dark_0006.png","cream_dark_0007.png","cream_dark_0008.png","cream_dark_0009.png","cream_dark_0010.png"],
              hour_zero: 1,
              hour_space: -343,
              hour_align: hmUI.align.LEFT,

              minute_startX: -74,
              minute_startY: 99,
              minute_array: ["cream_light_0001.png","cream_light_0002.png","cream_light_0003.png","cream_light_0004.png","cream_light_0005.png","cream_light_0006.png","cream_light_0007.png","cream_light_0008.png","cream_light_0009.png","cream_light_0010.png"],
              minute_zero: 1,
              minute_space: -324,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_analog_clock_pro_second_pointer_img = hmUI.createWidget(hmUI.widget.TIME_POINTER_PRO, {
              // src: 'cream_sec.png',
              // center_x: 233,
              // center_y: 233,
              // x: 17,
              // y: 264,
              // start_angle: 0,
              // end_angle: 360,
              // type: hmUI.data_type.second,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });


            normal_analog_clock_time_pointer_smooth_second = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              second_path: 'cream_sec.png',
              second_centerX: 233,
              second_centerY: 233,
              second_posX: 17,
              second_posY: 264,
              fresh_frequency: 40,
              fresh_freqency: 40,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_analog_clock_pro_smooth_second = hmUI.createWidget(hmUI.widget.SMOOTH_SECOND, {
              // type: 3,
              // fps: 40,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });



            idle_background_bg = hmUI.createWidget(hmUI.widget.FILL_RECT, {
              x: 0,
              y: 0,
              w: 466,
              h: 466,
              color: '0xFF000000',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: -91,
              hour_startY: -94,
              hour_array: ["cream_dark_0001.png","cream_dark_0002.png","cream_dark_0003.png","cream_dark_0004.png","cream_dark_0005.png","cream_dark_0006.png","cream_dark_0007.png","cream_dark_0008.png","cream_dark_0009.png","cream_dark_0010.png"],
              hour_zero: 1,
              hour_space: -343,
              hour_align: hmUI.align.LEFT,

              minute_startX: -74,
              minute_startY: 112,
              minute_array: ["cream_light_0001.png","cream_light_0002.png","cream_light_0003.png","cream_light_0004.png","cream_light_0005.png","cream_light_0006.png","cream_light_0007.png","cream_light_0008.png","cream_light_0009.png","cream_light_0010.png"],
              minute_zero: 1,
              minute_space: -324,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_hour_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 167,
              y: 0,
              src: 'Logo_4.51z.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_step_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: -46,
              y: -6,
              src: 'AOB Overlay.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });


                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}