﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        const logger = Logger.getLogger('watchface_SashaCX75');
        //end of ignored block

        //dynamic modify start

        
        console.log('user_functions.js');
        // start user_functions.js


			// Additional const and vars -- RFA
		
			const language = hmSetting.getLanguage()


			let element_index = 1;  // Selected element index
			let element_count = 7;  // Number of elements: steps/dist/cal/HR/PAI/batt/[blank]


			let face_index = 1;  // Initial background face (color)
			let face_count = 7;	// Number of background colors, not incl. AOD
		

			let weather_index = 1;	// Initial state of weather
			let weather_count = 3;	// Number of elements: Weather/Moon/[blank]
			
			
        // end user_functions.js

        let normal_background_bg_img = ''
        let normal_moon_image_progress_img_level = ''
        let normal_city_name_text = ''
        let normal_temperature_current_text_font = ''
        let normal_weather_image_progress_img_level = ''
        let normal_pai_icon_img = ''
        let normal_pai_weekly_text_font = ''
        let normal_distance_icon_img = ''
        let normal_distance_current_text_font = ''
        let normal_battery_icon_img = ''
        let normal_battery_current_text_font = ''
        let normal_calorie_icon_img = ''
        let normal_calorie_current_text_font = ''
        let normal_heart_rate_icon_img = ''
        let normal_heart_rate_text_font = ''
        let normal_step_icon_img = ''
        let normal_step_current_text_font = ''
        let normal_system_disconnect_img = ''
        let normal_system_clock_img = ''
        let normal_day_text_font = ''
        let normal_month_name_font = ''
        let normal_Month_Array = ['JAN', 'FEB', 'MAR', 'APR', 'MAY', 'JUN', 'JUL', 'AUG', 'SEP', 'OCT', 'NOV', 'DEC', ];
        let normal_dow_text_font = ''
        let normal_DOW_Array = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday'];
        let normal_analog_clock_pro_hour_pointer_img = ''
        let normal_analog_clock_pro_minute_pointer_img = ''
        let normal_analog_clock_pro_second_pointer_img = ''
        let normal_timerUpdateSec = undefined;
        let idle_background_bg_img = ''
        let idle_analog_clock_time_pointer_hour = ''
        let idle_analog_clock_time_pointer_minute = ''
        let normal_alarm_jumpable_img_click = ''
        let Button_1 = ''
        let Button_2 = ''
        let Button_3 = ''
        let timeSensor = '';


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            // FontName: FuturaCyrillicMedium.ttf; FontSize: 20; Cache: full
            hmUI.createWidget(hmUI.widget.TEXT, {
              x: 464,
              y: 464,
              w: 24,
              h: 24,
              text_size: 20,
              char_space: -2,
              line_space: 0,
              font: 'fonts/FuturaCyrillicMedium.ttf',
              color: 0xFFFFFFFF,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.NONE,
              text: "0123456789 ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz АБВГДЕЁЖЗИЙКЛМНОПРСТУФХЦЧШЩЪЫЬЭЮЯабвгдеёжзийклмнопрстуфхцчшщъыьэюя  ҐЄІЇґєії _-.,:;`'%°\\/",
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // FontName: FuturaCyrillicMedium.ttf; FontSize: 32
            hmUI.createWidget(hmUI.widget.TEXT, {
              x: 464,
              y: 464,
              w: 397,
              h: 49,
              text_size: 32,
              char_space: -2,
              line_space: 0,
              font: 'fonts/FuturaCyrillicMedium.ttf',
              color: 0xFFFFFFFF,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              text: "0123456789 _-.,:;`'%°\\/",
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // FontName: FuturaCyrillicMedium.ttf; FontSize: 32; Cache: full
            hmUI.createWidget(hmUI.widget.TEXT, {
              x: 464,
              y: 464,
              w: 38,
              h: 38,
              text_size: 32,
              char_space: -2,
              line_space: 0,
              font: 'fonts/FuturaCyrillicMedium.ttf',
              color: 0xFFFFFFFF,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.NONE,
              text: "0123456789 ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz АБВГДЕЁЖЗИЙКЛМНОПРСТУФХЦЧШЩЪЫЬЭЮЯабвгдеёжзийклмнопрстуфхцчшщъыьэюя  ҐЄІЇґєії _-.,:;`'%°\\/",
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            console.log('Watch_Face.ScreenNormal');
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 466,
              h: 466,
              src: 'bkgnd-1.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_moon_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 188,
              y: 75,
              image_array: ["M-01.png","M-02.png","M-03.png","M-04.png","M-05.png","M-06.png","M-07.png","M-08.png","M-09.png","M-10.png","M-11.png","M-12.png","M-13.png","M-14.png","M-15.png","M-16.png","M-17.png","M-18.png","M-19.png","M-20.png","M-21.png","M-22.png","M-23.png","M-24.png","M-25.png","M-26.png","M-27.png","M-28.png","M-29.png","M-30.png"],
              image_length: 30,
              shortcut: true,
              type: hmUI.data_type.MOON,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
              const weatherSensor = hmSensor.createSensor(hmSensor.id.WEATHER);

            normal_city_name_text = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 83,
              y: 167,
              w: 300,
              h: 30,
              text_size: 20,
              char_space: -2,
              line_space: 0,
              font: 'fonts/FuturaCyrillicMedium.ttf',
              color: 0xFFFFFFFF,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 193,
              y: 135,
              w: 80,
              h: 33,
              text_size: 32,
              char_space: -2,
              line_space: 0,
              font: 'fonts/FuturaCyrillicMedium.ttf',
              color: 0xFFFFFFFF,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.CENTER_V,
              unit_type: 2,
              text_style: hmUI.text_style.ELLIPSIS,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 203,
              y: 75,
              image_array: ["w01.png","w02.png","w03.png","w04.png","w05.png","w06.png","w07.png","w08.png","w09.png","w10.png","w11.png","w12.png","w13.png","w14.png","w15.png","w16.png","w17.png","w18.png","w19.png","w20.png","w21.png","w22.png","w23.png","w24.png","w25.png","w26.png","w27.png","w28.png","w29.png"],
              image_length: 29,
              shortcut: true,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_pai_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 203,
              y: 288,
              src: 'PAI_60sq_white_label.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_pai_weekly_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 193,
              y: 348,
              w: 80,
              h: 33,
              text_size: 32,
              char_space: -2,
              line_space: 0,
              font: 'fonts/FuturaCyrillicMedium.ttf',
              color: 0xFFFFFFFF,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              type: hmUI.data_type.PAI_WEEKLY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_distance_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 203,
              y: 288,
              src: 'MapPin_white_60sq.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_distance_current_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 163,
              y: 348,
              w: 140,
              h: 33,
              text_size: 32,
              char_space: -2,
              line_space: 0,
              font: 'fonts/FuturaCyrillicMedium.ttf',
              color: 0xFFFFFFFF,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.CENTER_V,
              unit_type: 1,
              text_style: hmUI.text_style.ELLIPSIS,
              type: hmUI.data_type.DISTANCE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 203,
              y: 288,
              src: 'Charge_white_60sq.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_current_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 188,
              y: 348,
              w: 90,
              h: 33,
              text_size: 32,
              char_space: -2,
              line_space: 0,
              font: 'fonts/FuturaCyrillicMedium.ttf',
              color: 0xFFFFFFFF,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.CENTER_V,
              unit_type: 1,
              text_style: hmUI.text_style.ELLIPSIS,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_calorie_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 203,
              y: 288,
              src: 'Flame_white_60sq.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_calorie_current_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 169,
              y: 348,
              w: 128,
              h: 33,
              text_size: 32,
              char_space: -2,
              line_space: 0,
              font: 'fonts/FuturaCyrillicMedium.ttf',
              color: 0xFFFFFFFF,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.CENTER_V,
              unit_type: 1,
              text_style: hmUI.text_style.ELLIPSIS,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 203,
              y: 288,
              src: 'HR_60sq_white_pulse.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 193,
              y: 348,
              w: 80,
              h: 33,
              text_size: 32,
              char_space: -2,
              line_space: 0,
              font: 'fonts/FuturaCyrillicMedium.ttf',
              color: 0xFFFFFFFF,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 203,
              y: 288,
              src: 'CTAS-1.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 183,
              y: 348,
              w: 100,
              h: 33,
              text_size: 32,
              char_space: -2,
              line_space: 0,
              font: 'fonts/FuturaCyrillicMedium.ttf',
              color: 0xFFFFFFFF,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 120,
              y: 305,
              src: 'no_bt_sm.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 120,
              y: 120,
              src: 'alarm_sm.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            if (!timeSensor) timeSensor = hmSensor.createSensor(hmSensor.id.TIME);
            timeSensor.addEventListener(timeSensor.event.DAYCHANGE, function() {
              time_update(true);
            });

            normal_day_text_font = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 300,
              y: 214,
              w: 34,
              h: 38,
              text_size: 32,
              char_space: -2,
              line_space: 0,
              font: 'fonts/FuturaCyrillicMedium.ttf',
              color: 0xFFFFFFFF,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_month_name_font = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 342,
              y: 214,
              w: 72,
              h: 38,
              text_size: 32,
              char_space: -2,
              line_space: 0,
              font: 'fonts/FuturaCyrillicMedium.ttf',
              color: 0xFFFFFFFF,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              // unit_string: JAN,FEB,MAR,APR,MAY,JUN,JUL,AUG,SEP,OCT, NOV,DEC,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_dow_text_font = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 56,
              y: 214,
              w: 160,
              h: 38,
              text_size: 32,
              char_space: -1,
              line_space: 0,
              font: 'fonts/FuturaCyrillicMedium.ttf',
              color: 0xFFFFFFFF,
              align_h: hmUI.align.LEFT,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              // unit_string: Monday,Tuesday,Wednesday,Thursday,Friday,Saturday,Sunday,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            const deviceInfo = hmSetting.getDeviceInfo();
            timeSensor.addEventListener(timeSensor.event.MINUTEEND, function() {
              let updateHour = timeSensor.minute == 0;

              time_update(updateHour, true);
            });

            // normal_analog_clock_pro_hour_pointer_img = hmUI.createWidget(hmUI.widget.TIME_POINTER_PRO, {
              // src: 'hand_hour_fat-50.png',
              // center_x: 233,
              // center_y: 233,
              // x: 22,
              // y: 141,
              // start_angle: 0,
              // end_angle: 360,
              // type: hmUI.data_type.hour,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });


            normal_analog_clock_pro_hour_pointer_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: deviceInfo.width,
              h: deviceInfo.height,
              pos_x: 233 - 22,
              pos_y: 233 - 141,
              center_x: 233,
              center_y: 233,
              src: 'hand_hour_fat-50.png',
              angle: 0,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_analog_clock_pro_minute_pointer_img = hmUI.createWidget(hmUI.widget.TIME_POINTER_PRO, {
              // src: 'hand_min_fat-50.png',
              // center_x: 233,
              // center_y: 233,
              // x: 24,
              // y: 200,
              // start_angle: 0,
              // end_angle: 360,
              // type: hmUI.data_type.minute,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });


            normal_analog_clock_pro_minute_pointer_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: deviceInfo.width,
              h: deviceInfo.height,
              pos_x: 233 - 24,
              pos_y: 233 - 200,
              center_x: 233,
              center_y: 233,
              src: 'hand_min_fat-50.png',
              angle: 0,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_analog_clock_pro_second_pointer_img = hmUI.createWidget(hmUI.widget.TIME_POINTER_PRO, {
              // src: 'hand_sec_fat-50.png',
              // center_x: 233,
              // center_y: 233,
              // x: 10,
              // y: 209,
              // start_angle: 0,
              // end_angle: 360,
              // type: hmUI.data_type.second,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });


            normal_analog_clock_pro_second_pointer_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: deviceInfo.width,
              h: deviceInfo.height,
              pos_x: 233 - 10,
              pos_y: 233 - 209,
              center_x: 233,
              center_y: 233,
              src: 'hand_sec_fat-50.png',
              angle: 0,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            let screenType = hmSetting.getScreenType();

            console.log('Watch_Face.ScreenAOD');
            idle_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 466,
              h: 466,
              src: 'bkgnd-AOD.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_analog_clock_time_pointer_hour = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              hour_path: 'Hand_hour_AOD2.png',
              hour_centerX: 233,
              hour_centerY: 233,
              hour_posX: 7,
              hour_posY: 125,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_analog_clock_time_pointer_minute = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              minute_path: 'hand_minute_AOD2.png',
              minute_centerX: 233,
              minute_centerY: 233,
              minute_posX: 7,
              minute_posY: 185,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            console.log('user_script_beforeShortcuts.js');
            // start user_script_beforeShortcuts.js




			//set initial states of non-visible widgets -- RFA
 
				//normal_battery_icon_img.setProperty(hmUI.prop.VISIBLE, false);
				//normal_battery_current_text_font.setProperty(hmUI.prop.VISIBLE, false);
				normal_step_icon_img.setProperty(hmUI.prop.VISIBLE, false);
				normal_step_current_text_font.setProperty(hmUI.prop.VISIBLE, false);
				normal_distance_icon_img.setProperty(hmUI.prop.VISIBLE, false);
				normal_distance_current_text_font.setProperty(hmUI.prop.VISIBLE, false);
				normal_heart_rate_icon_img.setProperty(hmUI.prop.VISIBLE, false);
				normal_heart_rate_text_font.setProperty(hmUI.prop.VISIBLE, false);
				normal_calorie_icon_img.setProperty(hmUI.prop.VISIBLE, false);
				normal_calorie_current_text_font.setProperty(hmUI.prop.VISIBLE, false);
				normal_pai_icon_img.setProperty(hmUI.prop.VISIBLE, false);
				normal_pai_weekly_text_font.setProperty(hmUI.prop.VISIBLE, false);
				
				//normal_weather_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, false);
				//normal_temperature_current_text_font.setProperty(hmUI.prop.VISIBLE, false);
				//normal_city_name_text.setProperty(hmUI.prop.VISIBLE, false);
				
				normal_moon_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, false);		


				function click_btn_high() {  // Function to enable and disable the visibility of elements -- RFA
					weather_index++;
					if(weather_index > weather_count) weather_index = 1;

					normal_weather_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, weather_index == 1);
					normal_temperature_current_text_font.setProperty(hmUI.prop.VISIBLE, weather_index == 1);
					normal_city_name_text.setProperty(hmUI.prop.VISIBLE, weather_index == 1);

					normal_moon_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, weather_index == 2);		
			  
					//if element_index is 3, nothing is shown

				};


				function click_btn_low() {  // Function to enable and disable the visibility of elements -- RFA
					element_index++;
					if(element_index > element_count) element_index = 1;

					normal_battery_icon_img.setProperty(hmUI.prop.VISIBLE, element_index == 1);
					normal_battery_current_text_font.setProperty(hmUI.prop.VISIBLE, element_index == 1);
			  
					normal_step_icon_img.setProperty(hmUI.prop.VISIBLE, element_index == 2);
					normal_step_current_text_font.setProperty(hmUI.prop.VISIBLE, element_index == 2);

					normal_distance_icon_img.setProperty(hmUI.prop.VISIBLE, element_index == 3);
					normal_distance_current_text_font.setProperty(hmUI.prop.VISIBLE, element_index == 3);

					normal_heart_rate_icon_img.setProperty(hmUI.prop.VISIBLE, element_index == 4);
					normal_heart_rate_text_font.setProperty(hmUI.prop.VISIBLE, element_index == 4);

					normal_calorie_icon_img.setProperty(hmUI.prop.VISIBLE, element_index == 5);
					normal_calorie_current_text_font.setProperty(hmUI.prop.VISIBLE, element_index == 5);

					normal_pai_icon_img.setProperty(hmUI.prop.VISIBLE, element_index == 6);
					normal_pai_weekly_text_font.setProperty(hmUI.prop.VISIBLE, element_index == 6);
			  
					//if element_index is 7, nothing is shown

				};
				
				function click_btn_face() {
					face_index++;
					if(face_index > face_count) face_index = 1;
					normal_background_bg_img.setProperty(hmUI.prop.SRC, 'bkgnd-' + parseInt(face_index) + '.png');
					normal_step_icon_img.setProperty(hmUI.prop.SRC, 'CTAS-' + parseInt(face_index) + '.png');
				};

				function set_dow() { //set verbose day of week based on language -- RFA
					if (language == 3) normal_DOW_Array = ['Lunes', 'Martes', 'Miércoles', 'Jueves', 'Viernes', 'Sábado', 'Domingo', ];
					else if (language == 6) normal_DOW_Array =  ['Lundi', 'Mardi', 'Mercredi', 'Jeudi', 'Vendredi', 'Samedi', 'Dimanche', ];
					else if (language == 7) normal_DOW_Array =  ['Montag', 'Dienstag', 'Mittwoch', 'Donnerstag', 'Freitag', 'Samstag', 'Sonntag', ];
					else if (language == 16) normal_DOW_Array =  ['Maandag', 'Dinsdag', 'Woensdag', 'Donderdag', 'Vrijdag', 'Zaterdag', 'Zondag', ];
					else if (language == 18) normal_DOW_Array =  ['Понеділок', 'Вівторок', 'Середа', 'Четвер', 'П’ятниця', 'Субота', 'Неділя', ];
					else normal_DOW_Array =  ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday', ]; //English default
				};
				
				set_dow();
				
				function set_MOab() { //set abbrev month based on language -- RFA
					if (language == 3) normal_Month_Array = ['ENE', 'FEB', 'MAR', 'ABR', 'MAY', 'JUN', 'JUL', 'AGO', 'SEPT', 'OCT', 'NOV', 'DIC',];
					else if (language == 6) normal_Month_Array =  ['JANV', 'FÉVR', 'MARS', 'AVR', 'MAI', 'JUIN', 'JUIL', 'AOUT', 'SEPT', 'OCT', 'NOV', 'DÉC',];
					else if (language == 7) normal_Month_Array =  ['JAN', 'FEB', 'MÄR', 'APR', 'MAI', 'JUN', 'JUL', 'AUG', 'SEP', 'OKT', 'NOV', 'DEZ',];
					else if (language == 16) normal_Month_Array =  ['JAN', 'FEB', 'MRT', 'APR', 'MEI', 'JUNI', 'JULI', 'AUG', 'SEP', 'OKT', 'NOV', 'DEC',];
					else if (language == 18) normal_Month_Array =  ['СІЧ', 'ЛЮТИ', 'БЕРЕЗ', 'КВІТ', 'ТРАВ', 'ЧЕРВ', 'ЛИП', 'СЕРП', 'ВЕРЕС', 'ЖОВТ', 'ЛИСТ', 'ГРУД',];
					else normal_Month_Array =  ['JAN', 'FEB', 'MAR', 'APR', 'MAY', 'JUN', 'JUL', 'AUG', 'SEP', 'OCT', 'NOV', 'DEC',]; //English default
				};
				
				set_MOab();


            // end user_script_beforeShortcuts.js
            console.log('Watch_Face.Shortcuts');

            normal_alarm_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 118,
              y: 120,
              w: 40,
              h: 40,
              type: hmUI.data_type.ALARM_CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            console.log('Watch_Face.Buttons');
            Button_1 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 2,
              y: 193,
              w: 80,
              h: 80,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'button_press.png',
              normal_src: 'Transp_60sq.png',
              click_func: (button_widget) => {
                click_btn_face();
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_2 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 193,
              y: 2,
              w: 80,
              h: 80,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'button_press.png',
              normal_src: 'Transp_60sq.png',
              click_func: (button_widget) => {
                click_btn_high();
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_3 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 193,
              y: 386,
              w: 80,
              h: 80,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'button_press.png',
              normal_src: 'Transp_60sq.png',
              click_func: (button_widget) => {
                click_btn_low();
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            //start of ignored block
            function time_update(updateHour = false, updateMinute = false) {
              console.log('time_update()');
              let hour = timeSensor.hour;
              let minute = timeSensor.minute;
              let second = timeSensor.second;
              let format_hour = timeSensor.format_hour;

              console.log('day font');
              if (updateHour) {
                let normal_dayStr = timeSensor.day.toString();
                normal_day_text_font.setProperty(hmUI.prop.TEXT, normal_dayStr );
              };

              console.log('month font');
              if (updateHour) {
                let normal_Month_Str = normal_Month_Array[timeSensor.month-1];
                normal_month_name_font.setProperty(hmUI.prop.TEXT, normal_Month_Str );
              };

              console.log('day of week font');
              if (updateHour) {
                let normal_DOW_Str = normal_DOW_Array[timeSensor.week-1];
                normal_dow_text_font.setProperty(hmUI.prop.TEXT, normal_DOW_Str );
              };

              if (updateMinute) {
                let normal_hour = hour;
                let normal_fullAngle_hour = 360;
                if (normal_hour > 11) normal_hour -= 12;
                let normal_angle_hour = 0 + normal_fullAngle_hour*normal_hour/12 + (normal_fullAngle_hour/12)*minute/60;
                if (normal_analog_clock_pro_hour_pointer_img) normal_analog_clock_pro_hour_pointer_img.setProperty(hmUI.prop.ANGLE, normal_angle_hour);
              };

              if (updateMinute) {
                let normal_fullAngle_minute = 360;
                let normal_angle_minute = 0 + normal_fullAngle_minute*minute/60;
                if (normal_analog_clock_pro_minute_pointer_img) normal_analog_clock_pro_minute_pointer_img.setProperty(hmUI.prop.ANGLE, normal_angle_minute);
              };

              let normal_fullAngle_second = 360;
              let normal_angle_second = 0 + normal_fullAngle_second*second/60;
              if (normal_analog_clock_pro_second_pointer_img) normal_analog_clock_pro_second_pointer_img.setProperty(hmUI.prop.ANGLE, normal_angle_second);

            };

            //end of ignored block
            function scale_call() {
              console.log('scale_call()');

              console.log('Weather city name');
              let weatherData = weatherSensor.getForecastWeather();
              normal_city_name_text.setProperty(hmUI.prop.TEXT, weatherData.cityName);

            };

            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                console.log('resume_call()');
                scale_call();
                time_update(true, true);
                if (screenType == hmSetting.screen_type.WATCHFACE) {
                  if (!normal_timerUpdateSec) {
                    let animDelay = timeSensor.utc % 1000;
                    let animRepeat = 1000;
                    normal_timerUpdateSec = timer.createTimer(animDelay, animRepeat, (function (option) {
                      time_update(false, false);
                    }));  // end timer 
                  };  // end timer check
                };  // end screenType


              }),
              pause_call: (function () {
                console.log('pause_call()');
                if (normal_timerUpdateSec) {
                  timer.stopTimer(normal_timerUpdateSec);
                  normal_timerUpdateSec = undefined;
                }

              }),
            });

                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}