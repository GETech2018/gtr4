﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        const logger = Logger.getLogger('watchface_SashaCX75');
        //end of ignored block

        //dynamic modify start

        
        console.log('user_functions.js');
        // start user_functions.js

//////////////////////////////////////////////////////////////////////////////////////////////////
let cc=0

        // Start color change
        let colornumber_main2 = 1
        let totalcolors_main2 = 6
        let namecolor_main2 = ''

        function click_Color2() {
            if(colornumber_main2>=totalcolors_main2) {
            colornumber_main2=1;
                }
            else {
                colornumber_main2=colornumber_main2+1;
            }

if ( colornumber_main2 == 1) { namecolor_main2 = "style one"}
if ( colornumber_main2 == 2) { namecolor_main2 = "style two"}
if ( colornumber_main2 == 3) { namecolor_main2 = "style three"}
if ( colornumber_main2 == 6) { namecolor_main2 = "style four"}
hmUI.showToast({text: namecolor_main2 });

             normal_analog_clock_pro_hour_pointer_img.setProperty(hmUI.prop.SRC, "Hand_H"+ parseInt(colornumber_main2) + ".png");
             normal_analog_clock_pro_minute_pointer_img.setProperty(hmUI.prop.SRC, "Hand_M"+ parseInt(colornumber_main2) + ".png");
                           
        }

/////////////////////////////////////////////////////////////////////////////////////////////////

//////////////////////////////////////////////////////////////////////////////////////////////////

        // Start color change
        let colornumber_main = 1
        let totalcolors_main = 6
        let namecolor_main = ''

        function click_Color() {
            if(colornumber_main>=totalcolors_main) {
            colornumber_main=1;
                }
            else {
                colornumber_main=colornumber_main+1;
            }

if ( colornumber_main == 1) { namecolor_main = "GRAY"}
if ( colornumber_main == 2) { namecolor_main = "BLUE"}
if ( colornumber_main == 3) { namecolor_main = "GREEN"}
if ( colornumber_main == 4) { namecolor_main = "YELLOW"}
if ( colornumber_main == 5) { namecolor_main = "ORANGE"}
if ( colornumber_main == 6) { namecolor_main = "Turquoise"}
hmUI.showToast({text: namecolor_main });

             normal_background_bg_img.setProperty(hmUI.prop.SRC, "main" + parseInt(colornumber_main) + ".png");
             normal_analog_clock_pro_hour_pointer_img.setProperty(hmUI.prop.SRC, "Hand_H"+ parseInt(colornumber_main) + ".png");
             normal_analog_clock_pro_minute_pointer_img.setProperty(hmUI.prop.SRC, "Hand_M"+ parseInt(colornumber_main) + ".png");
                           
        }

/////////////////////////////////////////////////////////////////////////////////////////////////



       // Start background change
        let elementnumber_1 = 1
        let total_elemente = 2

        function click_elemente() {
            if(elementnumber_1==total_elemente) {
            elementnumber_1=1;
                UpdateElementeOne();
                }
            else {
                elementnumber_1=elementnumber_1+1;
                if(elementnumber_1==2) {
                  UpdateElementeTwo();
                }

            }
            if(elementnumber_1==1) hmUI.showToast({text: 'Analog Seconds Smooth'});
            if(elementnumber_1==2) hmUI.showToast({text: 'Analog Seconds Normal'});
        }

        //Hand smooth
        function UpdateElementeOne(){

                normal_analog_clock_time_pointer_second.setProperty(hmUI.prop.VISIBLE, false);
               normal_analog_clock_pro_second_pointer_img.setProperty(hmUI.prop.SRC, "Hand_S1.png");

        }

        //Hand Normal
        function UpdateElementeTwo(){

                normal_analog_clock_time_pointer_second.setProperty(hmUI.prop.VISIBLE, true);
               normal_analog_clock_pro_second_pointer_img.setProperty(hmUI.prop.SRC, "Empty_0.png");

        }




        // Start background change
        let elementnumber_2 = 1
        let total_elemente2 = 2

        function click_elemente2() {
            if(elementnumber_2==total_elemente2) {
            elementnumber_2=1;
                UpdateElemente2One();
                }
            else {
                elementnumber_2=elementnumber_2+1;
                if(elementnumber_2==2) {
                  UpdateElemente2Two();
                }

            }
            if(elementnumber_2==1) hmUI.showToast({text: 'STEPS'});
            if(elementnumber_2==2) hmUI.showToast({text: 'DISTANCE'});
        }

        //STEPS
        function UpdateElemente2One(){
        normal_step_current_text_img.setProperty(hmUI.prop.VISIBLE, true);
        normal_distance_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
        normal_distance_text_separator_img.setProperty(hmUI.prop.VISIBLE, false);


        }

        //DISTANCE
        function UpdateElemente2Two(){
        normal_step_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
        normal_distance_text_text_img.setProperty(hmUI.prop.VISIBLE, true);
        normal_distance_text_separator_img.setProperty(hmUI.prop.VISIBLE, true);

        }
        // end user_functions.js

        let normal_background_bg_img = ''
        let normal_sun_low_text_img = ''
        let normal_weather_image_progress_img_level = ''
        let normal_temperature_current_text_img = ''
        let normal_step_current_text_img = ''
        let normal_step_current_separator_img = ''
        let normal_distance_text_text_img = ''
        let normal_distance_text_separator_img = ''
        let normal_date_img_date_day = ''
        let normal_date_img_date_week_img = ''
        let normal_heart_rate_text_text_img = ''
        let normal_battery_text_text_img = ''
        let normal_digital_clock_img_time_AmPm = ''
        let normal_digital_clock_img_time = ''
        let normal_analog_clock_time_pointer_hour = ''
        let normal_analog_clock_time_pointer_minute = ''
        let normal_analog_clock_time_pointer_second = ''
        let idle_background_bg_img = ''
        let idle_date_img_date_day = ''
        let idle_date_img_date_week_img = ''
        let idle_digital_clock_img_time_AmPm = ''
        let idle_digital_clock_img_time = ''
        let normal_step_jumpable_img_click = ''
        let normal_heart_jumpable_img_click = ''
        let normal_pai_jumpable_img_click = ''
        let normal_sunrise_jumpable_img_click = ''
        let normal_temperature_jumpable_img_click = ''
        let normal_spo2_jumpable_img_click = ''
        let normal_countdown_jumpable_img_click = ''
        let normal_stopwatch_jumpable_img_click = ''
        let normal_alarm_jumpable_img_click = ''
        let Button_1 = ''
        let Button_2 = ''
        let Button_3 = ''
        let Button_4 = ''
        let Button_5 = ''
        let Button_6 = ''
        let Button_7 = ''


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            console.log('Watch_Face.ScreenNormal');
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 466,
              h: 466,
              src: 'main1.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sun_low_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 265,
              y: 85,
              font_array: ["Cal_num_0.png","Cal_num_1.png","Cal_num_2.png","Cal_num_3.png","Cal_num_4.png","Cal_num_5.png","Cal_num_6.png","Cal_num_7.png","Cal_num_8.png","Cal_num_9.png"],
              padding: false,
              h_space: 1,
              invalid_image: 'Weather_icon_symbo1.png',
              dot_image: 'Pointer2.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.SUN_SET,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 139,
              y: 250,
              image_array: ["Weather_icon_01.png","Weather_icon_02.png","Weather_icon_03.png","Weather_icon_04.png","Weather_icon_05.png","Weather_icon_06.png","Weather_icon_07.png","Weather_icon_08.png","Weather_icon_09.png","Weather_icon_10.png","Weather_icon_11.png","Weather_icon_12.png","Weather_icon_13.png","Weather_icon_14.png","Weather_icon_15.png","Weather_icon_16.png","Weather_icon_17.png","Weather_icon_18.png","Weather_icon_19.png","Weather_icon_20.png","Weather_icon_21.png","Weather_icon_22.png","Weather_icon_23.png","Weather_icon_24.png","Weather_icon_25.png","Weather_icon_26.png","Weather_icon_27.png","Weather_icon_28.png","Weather_icon_29.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 66,
              y: 254,
              font_array: ["Batteru_font_01.png","Batteru_font_02.png","Batteru_font_03.png","Batteru_font_04.png","Batteru_font_05.png","Batteru_font_06.png","Batteru_font_07.png","Batteru_font_08.png","Batteru_font_09.png","Batteru_font_10.png"],
              padding: false,
              h_space: 1,
              unit_sc: 'Weather_icon_symbo2.png',
              unit_tc: 'Weather_icon_symbo2.png',
              unit_en: 'Weather_icon_symbo2.png',
              imperial_unit_sc: 'Weather_icon_symbo2.png',
              imperial_unit_tc: 'Weather_icon_symbo2.png',
              imperial_unit_en: 'Weather_icon_symbo2.png',
              negative_image: 'Weather_icon_symbo1.png',
              invalid_image: 'Weather_icon_symbo1.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            const temperatureUnit = hmSetting.getTemperatureUnit();
            //start of ignored block
            if (temperatureUnit == 1) {
              normal_temperature_current_text_img.setProperty(hmUI.prop.MORE, {
                x: 66,
                y: 254,
                font_array: ["Batteru_font_01.png","Batteru_font_02.png","Batteru_font_03.png","Batteru_font_04.png","Batteru_font_05.png","Batteru_font_06.png","Batteru_font_07.png","Batteru_font_08.png","Batteru_font_09.png","Batteru_font_10.png"],
                padding: false,
                h_space: 1,
                unit_sc: 'Weather_icon_symbo2.png',
                unit_tc: 'Weather_icon_symbo2.png',
                unit_en: 'Weather_icon_symbo2.png',
                imperial_unit_sc: 'Weather_icon_symbo2.png',
                imperial_unit_tc: 'Weather_icon_symbo2.png',
                imperial_unit_en: 'Weather_icon_symbo2.png',
                negative_image: 'Weather_icon_symbo1.png',
                invalid_image: 'Weather_icon_symbo1.png',
                align_h: hmUI.align.CENTER_H,
                type: hmUI.data_type.WEATHER_CURRENT,
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
            };
            //end of ignored block

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 206,
              y: 133,
              font_array: ["Batteru_font_01.png","Batteru_font_02.png","Batteru_font_03.png","Batteru_font_04.png","Batteru_font_05.png","Batteru_font_06.png","Batteru_font_07.png","Batteru_font_08.png","Batteru_font_09.png","Batteru_font_10.png"],
              padding: false,
              h_space: 1,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 156,
              y: 132,
              src: 'System_Alarm.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_distance_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 204,
              y: 134,
              font_array: ["Batteru_font_01.png","Batteru_font_02.png","Batteru_font_03.png","Batteru_font_04.png","Batteru_font_05.png","Batteru_font_06.png","Batteru_font_07.png","Batteru_font_08.png","Batteru_font_09.png","Batteru_font_10.png"],
              padding: false,
              h_space: 1,
              unit_sc: 'Dis_KM.png',
              unit_tc: 'Dis_KM.png',
              unit_en: 'Dis_KM.png',
              imperial_unit_sc: 'Dis_Mi.png',
              imperial_unit_tc: 'Dis_Mi.png',
              imperial_unit_en: 'Dis_Mi.png',
              dot_image: 'Dis_Dot.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.DISTANCE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_distance_text_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 156,
              y: 132,
              src: 'System_Alarm.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 355,
              day_startY: 200,
              day_sc_array: ["number_small_01.png","number_small_02.png","number_small_03.png","number_small_04.png","number_small_05.png","number_small_06.png","number_small_07.png","number_small_08.png","number_small_09.png","number_small_10.png"],
              day_tc_array: ["number_small_01.png","number_small_02.png","number_small_03.png","number_small_04.png","number_small_05.png","number_small_06.png","number_small_07.png","number_small_08.png","number_small_09.png","number_small_10.png"],
              day_en_array: ["number_small_01.png","number_small_02.png","number_small_03.png","number_small_04.png","number_small_05.png","number_small_06.png","number_small_07.png","number_small_08.png","number_small_09.png","number_small_10.png"],
              day_zero: 1,
              day_space: 0,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 345,
              y: 252,
              week_en: ["Month_01.png","Month_02.png","Month_03.png","Month_04.png","Month_05.png","Month_06.png","Month_07.png"],
              week_tc: ["Month_01.png","Month_02.png","Month_03.png","Month_04.png","Month_05.png","Month_06.png","Month_07.png"],
              week_sc: ["Month_01.png","Month_02.png","Month_03.png","Month_04.png","Month_05.png","Month_06.png","Month_07.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 67,
              y: 190,
              font_array: ["Batteru_font_01.png","Batteru_font_02.png","Batteru_font_03.png","Batteru_font_04.png","Batteru_font_05.png","Batteru_font_06.png","Batteru_font_07.png","Batteru_font_08.png","Batteru_font_09.png","Batteru_font_10.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 138,
              y: 85,
              font_array: ["Cal_num_0.png","Cal_num_1.png","Cal_num_2.png","Cal_num_3.png","Cal_num_4.png","Cal_num_5.png","Cal_num_6.png","Cal_num_7.png","Cal_num_8.png","Cal_num_9.png"],
              padding: false,
              h_space: 1,
              unit_sc: 'Pointer1.png',
              unit_tc: 'Pointer1.png',
              unit_en: 'Pointer1.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time_AmPm = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              am_x: 190,
              am_y: 301,
              am_sc_path: 'Clock_AM.png',
              am_en_path: 'Clock_AM.png',
              pm_x: 190,
              pm_y: 300,
              pm_sc_path: 'Clock_PM.png',
              pm_en_path: 'Clock_PM.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 159,
              hour_startY: 345,
              hour_array: ["number_white_01.png","number_white_02.png","number_white_03.png","number_white_04.png","number_white_05.png","number_white_06.png","number_white_07.png","number_white_08.png","number_white_09.png","number_white_10.png"],
              hour_zero: 1,
              hour_space: 2,
              hour_angle: 0,
              hour_align: hmUI.align.CENTER_H,

              minute_startX: 248,
              minute_startY: 345,
              minute_array: ["number_white_01.png","number_white_02.png","number_white_03.png","number_white_04.png","number_white_05.png","number_white_06.png","number_white_07.png","number_white_08.png","number_white_09.png","number_white_10.png"],
              minute_zero: 1,
              minute_space: 2,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_hour = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              hour_path: 'Hand_H1.png',
              hour_centerX: 233,
              hour_centerY: 233,
              hour_posX: 35,
              hour_posY: 225,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_minute = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              minute_path: 'Hand_M1.png',
              minute_centerX: 233,
              minute_centerY: 233,
              minute_posX: 36,
              minute_posY: 224,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_second = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              second_path: 'Hand_S1.png',
              second_centerX: 233,
              second_centerY: 233,
              second_posX: 35,
              second_posY: 225,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            console.log('Watch_Face.ScreenAOD');
            idle_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 466,
              h: 466,
              src: 'System_BT_OFF.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 356,
              day_startY: 200,
              day_sc_array: ["number_small_01.png","number_small_02.png","number_small_03.png","number_small_04.png","number_small_05.png","number_small_06.png","number_small_07.png","number_small_08.png","number_small_09.png","number_small_10.png"],
              day_tc_array: ["number_small_01.png","number_small_02.png","number_small_03.png","number_small_04.png","number_small_05.png","number_small_06.png","number_small_07.png","number_small_08.png","number_small_09.png","number_small_10.png"],
              day_en_array: ["number_small_01.png","number_small_02.png","number_small_03.png","number_small_04.png","number_small_05.png","number_small_06.png","number_small_07.png","number_small_08.png","number_small_09.png","number_small_10.png"],
              day_zero: 1,
              day_space: 1,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 347,
              y: 254,
              week_en: ["Month_01.png","Month_02.png","Month_03.png","Month_04.png","Month_05.png","Month_06.png","Month_07.png"],
              week_tc: ["Month_01.png","Month_02.png","Month_03.png","Month_04.png","Month_05.png","Month_06.png","Month_07.png"],
              week_sc: ["Month_01.png","Month_02.png","Month_03.png","Month_04.png","Month_05.png","Month_06.png","Month_07.png"],
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time_AmPm = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              am_x: 191,
              am_y: 301,
              am_sc_path: 'Clock_AM.png',
              am_en_path: 'Clock_AM.png',
              pm_x: 191,
              pm_y: 303,
              pm_sc_path: 'Clock_PM.png',
              pm_en_path: 'Clock_PM.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 159,
              hour_startY: 344,
              hour_array: ["number_white_01.png","number_white_02.png","number_white_03.png","number_white_04.png","number_white_05.png","number_white_06.png","number_white_07.png","number_white_08.png","number_white_09.png","number_white_10.png"],
              hour_zero: 1,
              hour_space: 3,
              hour_angle: 0,
              hour_align: hmUI.align.LEFT,

              minute_startX: 247,
              minute_startY: 345,
              minute_array: ["number_white_01.png","number_white_02.png","number_white_03.png","number_white_04.png","number_white_05.png","number_white_06.png","number_white_07.png","number_white_08.png","number_white_09.png","number_white_10.png"],
              minute_zero: 1,
              minute_space: 3,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_AOD,
            });
            console.log('Watch_Face.Shortcuts');

            normal_step_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 50,
              y: 212,
              w: 119,
              h: 31,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 81,
              y: 329,
              w: 64,
              h: 40,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_pai_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 321,
              y: 328,
              w: 62,
              h: 38,
              type: hmUI.data_type.PAI_WEEKLY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sunrise_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 316,
              y: 96,
              w: 49,
              h: 53,
              type: hmUI.data_type.SUN_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 96,
              y: 78,
              w: 56,
              h: 66,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_spo2_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 155,
              y: 301,
              w: 50,
              h: 99,
              type: hmUI.data_type.SPO2,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_countdown_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 349,
              y: 218,
              w: 25,
              h: 30,
              type: hmUI.data_type.COUNT_DOWN,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_stopwatch_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 325,
              y: 256,
              w: 91,
              h: 24,
              type: hmUI.data_type.STOP_WATCH,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_alarm_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 366,
              y: 50,
              w: 57,
              h: 63,
              type: hmUI.data_type.ALARM_CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            console.log('Watch_Face.Buttons');
            Button_1 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 98,
              y: 60,
              w: 104,
              h: 60,
              text: '',
              color: 0xFFFF8C00,
              text_size: 24,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'PowerSaveHintScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_2 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 322,
              y: 185,
              w: 97,
              h: 97,
              text: '',
              color: 0xFFFF8C00,
              text_size: 24,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'ScheduleCalScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_3 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 205,
              y: 11,
              w: 54,
              h: 42,
              text: '',
              color: 0xFFFF8C00,
              text_size: 24,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'SportListScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_4 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 203,
              y: 409,
              w: 59,
              h: 58,
              text: '',
              color: 0xFFFF8C00,
              text_size: 24,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                // change main screen
                click_Color()
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_5 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 207,
              y: 205,
              w: 58,
              h: 60,
              text: '',
              color: 0xFFFF8C00,
              text_size: 24,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                // swith smooth - normal
                click_elemente()
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_6 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 422,
              y: 149,
              w: 47,
              h: 168,
              text: '',
              color: 0xFFFF8C00,
              text_size: 24,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                //change color second hand
                click_Color2()
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_7 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 142,
              y: 124,
              w: 178,
              h: 49,
              text: '',
              color: 0xFFFF8C00,
              text_size: 24,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                // Activity
                click_elemente2()
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            console.log('user_script_end.js');
            // start user_script_end.js

if(cc==0){
UpdateElementeOne()
UpdateElemente2One()
cc=1
}
            // end user_script_end.js


                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}