try {
(function () {
  var __$$app$$__ = __$$hmAppManager$$__.currentApp;
  var __$$module$$__ = __$$app$$__.current;
  var logger = Logger.getLogger('watchface_firered_torch');

  // Native screens opened by the two new taps (change here if one does not open)
  var WORKOUT_URL = 'SportListScreen';
  var CALENDAR_URL = 'ScheduleCalScreen';
  var TORCH_URL = 'FlashLightScreen';

  var built = false;
  var W = {};
  var ts = null;

  function arr(dir) { var a = []; for (var i = 0; i < 10; i++) { a.push(dir + i + '.png'); } return a; }
  function setSrc(w, s) { try { w.setProperty(hmUI.prop.SRC, s); } catch (e) {} }
  function openNative(url) {
    try { hmApp.startApp({ appid: 1, url: url, native: true }); } catch (e) { logger.log('open failed ' + url); }
  }

  function update() {
    try {
      if (!built || !ts) { return; }
      try {
        if (hmSetting.getScreenType() === hmSetting.screen_type.AOD) { return; }
      } catch (e0) {}
      var h = ts.hour, m = ts.minute;
      setSrc(W.h1, 'images/time/normal/white/' + Math.floor(h / 10) + '.png');
      setSrc(W.h2, 'images/time/normal/green/' + (h % 10) + '.png');
      setSrc(W.m1, 'images/time/normal/green/' + Math.floor(m / 10) + '.png');
      setSrc(W.m2, 'images/time/normal/white/' + (m % 10) + '.png');
      var mo = ts.month - 1; if (mo < 0 || mo > 11) { mo = 0; }
      var d = ts.day;
      setSrc(W.mo, 'images/month/' + mo + '.png');
      setSrc(W.d1, 'images/date/' + Math.floor(d / 10) + '.png');
      setSrc(W.d2, 'images/date/' + (d % 10) + '.png');
      var wd = (new Date().getDay() + 6) % 7;
      setSrc(W.wk, 'images/week/' + wd + '.png');
    } catch (e) {}
  }

  function build() {
    if (built) { return; }
    var N = hmUI.show_level.ONLY_NORMAL, A = hmUI.show_level.ONLY_AOD;
    var img = function (o) { return hmUI.createWidget(hmUI.widget.IMG, o); };
    var months = [0,1,2,3,4,5,6,7,8,9,10,11].map(function (n) { return 'images/aod/month/' + n + '.png'; });
    var weeks = [0,1,2,3,4,5,6].map(function (n) { return 'images/aod/week/' + n + '.png'; });

    img({ x: 0, y: 0, w: 466, h: 466, src: 'images/bg.png', show_level: N });
    img({ x: 0, y: 0, w: 466, h: 466, src: 'images/aodbg.png', show_level: A });

    W.wk = img({ x: 0, y: 0, w: 466, h: 88, src: 'images/week/0.png', show_level: N });
    W.h1 = img({ x: 153, y: 120, w: 80, h: 112, src: 'images/time/normal/white/0.png', show_level: N });
    W.h2 = img({ x: 233, y: 120, w: 80, h: 112, src: 'images/time/normal/green/0.png', show_level: N });
    W.m1 = img({ x: 153, y: 234, w: 80, h: 112, src: 'images/time/normal/green/0.png', show_level: N });
    W.m2 = img({ x: 233, y: 234, w: 80, h: 112, src: 'images/time/normal/white/0.png', show_level: N });
    W.d1 = img({ x: 190, y: 82, w: 14, h: 24, src: 'images/date/0.png', show_level: N });
    W.d2 = img({ x: 204, y: 82, w: 14, h: 24, src: 'images/date/0.png', show_level: N });
    W.mo = img({ x: 227, y: 82, w: 64, h: 24, src: 'images/month/0.png', show_level: N });

    var spots = [
      { cx: 92,  y: 144, type: hmUI.data_type.BATTERY, unit: true },
      { cx: 374, y: 144, type: hmUI.data_type.CAL },
      { cx: 92,  y: 252, type: hmUI.data_type.STEP },
      { cx: 374, y: 252, type: hmUI.data_type.HEART, none: true }
    ];
    for (var i = 0; i < spots.length; i++) {
      var s = spots[i];
      var a = { x: s.cx - 50, y: s.y, w: 100, h: 28, h_space: 0, align_h: hmUI.align.CENTER_H, type: s.type,
                font_array: arr('images/data/'), padding: false, show_level: N };
      var b = { x: s.cx - 50, y: s.y, w: 100, h: 28, h_space: 0, align_h: hmUI.align.CENTER_H, type: s.type,
                font_array: arr('images/aod/data/'), padding: false, show_level: A };
      if (s.unit) {
        a.unit_sc = a.unit_tc = a.unit_en = 'images/data/unit.png';
        b.unit_sc = b.unit_tc = b.unit_en = 'images/aod/data/unit.png';
      }
      if (s.none) {
        a.invalid_image = 'images/data/none.png';
        b.invalid_image = 'images/aod/data/none.png';
      }
      hmUI.createWidget(hmUI.widget.TEXT_IMG, a);
      hmUI.createWidget(hmUI.widget.TEXT_IMG, b);
    }

    // always-on display (system driven)
    hmUI.createWidget(hmUI.widget.IMG_WEEK, { x: 0, y: 0, week_en: weeks, week_tc: weeks, week_sc: weeks, show_level: A });
    hmUI.createWidget(hmUI.widget.IMG_DATE, {
      month_startX: 227, month_startY: 82, month_align: hmUI.align.LEFT, month_space: 0, month_zero: 0, month_is_character: true,
      month_en_array: months, month_sc_array: months, month_tc_array: months,
      day_startX: 190, day_startY: 82, day_align: hmUI.align.LEFT, day_space: 0, day_zero: 1,
      day_en_array: arr('images/aod/date/'), day_sc_array: arr('images/aod/date/'), day_tc_array: arr('images/aod/date/'),
      show_level: A });
    hmUI.createWidget(hmUI.widget.IMG_TIME, {
      hour_zero: 1, hour_startX: 153, hour_startY: 120, hour_array: arr('images/time/aod/'), hour_space: 0, hour_align: hmUI.align.LEFT,
      minute_zero: 1, minute_startX: 153, minute_startY: 234, minute_array: arr('images/time/aod/'), minute_space: 0, minute_align: hmUI.align.LEFT,
      show_level: A });

    // taps: stats open their app, date opens calendar, WORKOUT chip opens workouts
    var zones = [
      { x: 30,  y: 136, t: hmUI.data_type.BATTERY },
      { x: 312, y: 136, t: hmUI.data_type.CAL },
      { x: 30,  y: 244, t: hmUI.data_type.STEP },
      { x: 312, y: 244, t: hmUI.data_type.HEART }
    ];
    for (var j = 0; j < zones.length; j++) {
      hmUI.createWidget(hmUI.widget.IMG_CLICK, { x: zones[j].x, y: zones[j].y, w: 124, h: 84, type: zones[j].t, show_level: N });
    }
    hmUI.createWidget(hmUI.widget.BUTTON, {
      x: 176, y: 74, w: 118, h: 38, text: '', color: 0xFFFFFFFF, text_size: 25,
      press_src: 'images/click_date.png', normal_src: 'images/click_date.png',
      click_func: function () { openNative(CALENDAR_URL); }, show_level: N });
    hmUI.createWidget(hmUI.widget.BUTTON, {
      x: 163, y: 366, w: 140, h: 36, text: '', color: 0xFFFFFFFF, text_size: 25,
      press_src: 'images/click_workout.png', normal_src: 'images/click_workout.png',
      click_func: function () { openNative(WORKOUT_URL); }, show_level: N });

    hmUI.createWidget(hmUI.widget.BUTTON, {
      x: 116, y: 76, w: 40, h: 40, text: '', color: 0xFFFFFFFF, text_size: 25,
      press_src: 'images/click_torch.png', normal_src: 'images/click_torch.png',
      click_func: function () { openNative(TORCH_URL); }, show_level: N });

    ts = hmSensor.createSensor(hmSensor.id.TIME);
    built = true;
    try { ts.addEventListener(ts.event.MINUTEEND, update); } catch (e1) {}
    try { ts.addEventListener(ts.event.CHANGE, update); } catch (e2) {}
    try { hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, { resume_call: update, pause_call: function () {} }); } catch (e3) {}
    update();
  }

  __$$module$$__.module = DeviceRuntimeCore.WatchFace({
    init_view: function () { build(); },
    onInit: function () { logger.log('fire red torch on init'); },
    build: function () { this.init_view(); logger.log('fire red torch on ready'); },
    onDestroy: function () { logger.log('fire red torch on destroy'); }
  });
})();
} catch (e) {
  console.log('Mini Program Error', e);
}
