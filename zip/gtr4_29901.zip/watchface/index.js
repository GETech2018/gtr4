﻿
    /*
    ** Watch_Face_Editor tool
    ** watchface js version v1.0.1
    ** Copyright © CashaCX75. All Rights Reserved
    */

    try {

      (() => {

        var __$$app$$__ = __$$hmAppManager$$__.currentApp;
        var __$$module$$__ = __$$app$$__.current;
        //drink is a name,can modify
        var h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__), 'drink');

        'use strict';

        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_date_img_date_week_img = ''
        let normal_date_img_date_month = ''
        let normal_date_img_date_day = ''
        let normal_date_day_separator_img = ''
        let normal_distance_text_text_img = ''
        let normal_heart_rate_text_text_img = ''
        let normal_calorie_current_text_img = ''
        let normal_step_current_text_img = ''
        let normal_digital_clock_img_time = ''
        let idle_background_bg_img = ''
        let idle_date_img_date_week_img = ''
        let idle_date_img_date_month = ''
        let idle_date_img_date_day = ''
        let idle_date_day_separator_img = ''
        let idle_distance_text_text_img = ''
        let idle_heart_rate_text_text_img = ''
        let idle_calorie_current_text_img = ''
        let idle_step_current_text_img = ''
        let idle_digital_clock_img_time = ''


        //dynamic modify end

        //not required
        const logger = DeviceRuntimeCore.HmLogger.getLogger("yeguang");

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({

          init_view() {

            //dynamic modify start
                    
            
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 466,
              h: 466,
              src: 'Fundo-2.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 264,
              y: 354,
              week_en: ["008.png","009.png","010.png","011.png","012.png","013.png","014.png"],
              week_tc: ["008.png","009.png","010.png","011.png","012.png","013.png","014.png"],
              week_sc: ["008.png","009.png","010.png","011.png","012.png","013.png","014.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_month = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 161,
              month_startY: 354,
              month_sc_array: ["043.png","044.png","045.png","046.png","047.png","048.png","049.png","050.png","051.png","052.png"],
              month_tc_array: ["043.png","044.png","045.png","046.png","047.png","048.png","049.png","050.png","051.png","052.png"],
              month_en_array: ["043.png","044.png","045.png","046.png","047.png","048.png","049.png","050.png","051.png","052.png"],
              month_zero: 1,
              month_space: 0,
              month_align: hmUI.align.LEFT,
              month_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 200,
              day_startY: 354,
              day_sc_array: ["043.png","044.png","045.png","046.png","047.png","048.png","049.png","050.png","051.png","052.png"],
              day_tc_array: ["043.png","044.png","045.png","046.png","047.png","048.png","049.png","050.png","051.png","052.png"],
              day_en_array: ["043.png","044.png","045.png","046.png","047.png","048.png","049.png","050.png","051.png","052.png"],
              day_zero: 1,
              day_space: 0,
              day_align: hmUI.align.LEFT,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_day_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 187,
              y: 351,
              src: 'barra.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_distance_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 361,
              y: 173,
              font_array: ["043.png","044.png","045.png","046.png","047.png","048.png","049.png","050.png","051.png","052.png"],
              padding: false,
              h_space: 0,
              dot_image: 'ponto.png',
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.DISTANCE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 58,
              y: 273,
              font_array: ["043.png","044.png","045.png","046.png","047.png","048.png","049.png","050.png","051.png","052.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_calorie_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 368,
              y: 273,
              font_array: ["043.png","044.png","045.png","046.png","047.png","048.png","049.png","050.png","051.png","052.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 53,
              y: 173,
              font_array: ["043.png","044.png","045.png","046.png","047.png","048.png","049.png","050.png","051.png","052.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 157,
              hour_startY: 87,
              hour_array: ["015.png","016.png","017.png","018.png","019.png","020.png","021.png","022.png","023.png","024.png"],
              hour_zero: 1,
              hour_space: 9,
              hour_align: hmUI.align.LEFT,

              minute_startX: 157,
              minute_startY: 216,
              minute_array: ["025.png","026.png","027.png","028.png","029.png","030.png","031.png","032.png","033.png","034.png"],
              minute_zero: 1,
              minute_space: 9,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            idle_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 466,
              h: 466,
              src: 'Fundo-2.png',
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 264,
              y: 354,
              week_en: ["001.png","002.png","003.png","004.png","005.png","006.png","007.png"],
              week_tc: ["001.png","002.png","003.png","004.png","005.png","006.png","007.png"],
              week_sc: ["001.png","002.png","003.png","004.png","005.png","006.png","007.png"],
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_date_img_date_month = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 200,
              month_startY: 354,
              month_sc_array: ["043.png","044.png","045.png","046.png","047.png","048.png","049.png","050.png","051.png","052.png"],
              month_tc_array: ["043.png","044.png","045.png","046.png","047.png","048.png","049.png","050.png","051.png","052.png"],
              month_en_array: ["043.png","044.png","045.png","046.png","047.png","048.png","049.png","050.png","051.png","052.png"],
              month_zero: 1,
              month_space: 0,
              month_align: hmUI.align.LEFT,
              month_is_character: false,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 161,
              day_startY: 354,
              day_sc_array: ["043.png","044.png","045.png","046.png","047.png","048.png","049.png","050.png","051.png","052.png"],
              day_tc_array: ["043.png","044.png","045.png","046.png","047.png","048.png","049.png","050.png","051.png","052.png"],
              day_en_array: ["043.png","044.png","045.png","046.png","047.png","048.png","049.png","050.png","051.png","052.png"],
              day_zero: 1,
              day_space: 0,
              day_align: hmUI.align.LEFT,
              day_is_character: false,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_date_day_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 187,
              y: 351,
              src: 'barra.png',
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_distance_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 361,
              y: 173,
              font_array: ["043.png","044.png","045.png","046.png","047.png","048.png","049.png","050.png","051.png","052.png"],
              padding: false,
              h_space: 0,
              dot_image: 'ponto.png',
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.DISTANCE,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 58,
              y: 273,
              font_array: ["043.png","044.png","045.png","046.png","047.png","048.png","049.png","050.png","051.png","052.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_calorie_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 368,
              y: 273,
              font_array: ["043.png","044.png","045.png","046.png","047.png","048.png","049.png","050.png","051.png","052.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 53,
              y: 173,
              font_array: ["043.png","044.png","045.png","046.png","047.png","048.png","049.png","050.png","051.png","052.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 157,
              hour_startY: 87,
              hour_array: ["015.png","016.png","017.png","018.png","019.png","020.png","021.png","022.png","023.png","024.png"],
              hour_zero: 1,
              hour_space: 9,
              hour_align: hmUI.align.LEFT,

              minute_startX: 157,
              minute_startY: 216,
              minute_array: ["025.png","026.png","027.png","028.png","029.png","030.png","031.png","032.png","033.png","034.png"],
              minute_zero: 1,
              minute_space: 9,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONAL_AOD,
            });


            //dynamic modify end
          },

          onInit() {
            console.log('index page.js on init invoke')

            this.init_view()

          },

          onReady() {
            console.log('index page.js on ready invoke')
          },

          onShow() {
            console.log('index page.js on show invoke')
          },

          onHide() {
            console.log('index page.js on hide invoke')
          },

          onDestory() {
            console.log('index page.js on destory invoke')
          },
        });

      })()
    } catch (e) {
      console.log(e)
    }
  