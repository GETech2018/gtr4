﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        //const logger = Logger.getLogger('watchface_SashaCX75');
        const logger = DeviceRuntimeCore.HmLogger.getLogger('watchface_SashaCX75')
        //end of ignored block

        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_system_disconnect_img = ''
        let normal_system_clock_img = ''
        let normal_year_TextCircle = new Array(4);
        let normal_year_TextCircle_ASCIIARRAY = new Array(10);
        let normal_year_TextCircle_img_width = 20;
        let normal_year_TextCircle_img_height = 22;
        let normal_timerTextUpdate = undefined;
        let normal_month_TextCircle = new Array(2);
        let normal_month_TextCircle_ASCIIARRAY = new Array(10);
        let normal_month_TextCircle_img_width = 20;
        let normal_month_TextCircle_img_height = 22;
        let normal_month_TextCircle_unit = null;
        let normal_month_TextCircle_unit_width = 20;
        let normal_day_TextCircle = new Array(2);
        let normal_day_TextCircle_ASCIIARRAY = new Array(10);
        let normal_day_TextCircle_img_width = 20;
        let normal_day_TextCircle_img_height = 22;
        let normal_day_TextCircle_unit = null;
        let normal_day_TextCircle_unit_width = 20;
        let normal_battery_circle_scale = ''
        let normal_battery_TextCircle = new Array(3);
        let normal_battery_TextCircle_ASCIIARRAY = new Array(10);
        let normal_battery_TextCircle_img_width = 20;
        let normal_battery_TextCircle_img_height = 22;
        let normal_battery_TextCircle_unit = null;
        let normal_battery_TextCircle_unit_width = 21;
        let normal_step_circle_scale = ''
        let normal_step_TextCircle = new Array(5);
        let normal_step_TextCircle_ASCIIARRAY = new Array(10);
        let normal_step_TextCircle_img_width = 20;
        let normal_step_TextCircle_img_height = 22;
        let normal_city_name_text = ''
        let normal_image_img = ''
        let normal_analog_clock_pro_hour_pointer_img = ''
        let normal_analog_clock_pro_minute_pointer_img = ''
        let normal_timerUpdateSec = undefined;
        let normal_analog_clock_time_pointer_smooth_second = ''
        let idle_background_bg_img = ''
        let idle_system_disconnect_img = ''
        let idle_system_clock_img = ''
        let idle_year_TextCircle = new Array(4);
        let idle_year_TextCircle_ASCIIARRAY = new Array(10);
        let idle_year_TextCircle_img_width = 20;
        let idle_year_TextCircle_img_height = 22;
        let idle_timerTextUpdate = undefined;
        let idle_month_TextCircle = new Array(2);
        let idle_month_TextCircle_ASCIIARRAY = new Array(10);
        let idle_month_TextCircle_img_width = 20;
        let idle_month_TextCircle_img_height = 22;
        let idle_month_TextCircle_unit = null;
        let idle_month_TextCircle_unit_width = 20;
        let idle_day_TextCircle = new Array(2);
        let idle_day_TextCircle_ASCIIARRAY = new Array(10);
        let idle_day_TextCircle_img_width = 20;
        let idle_day_TextCircle_img_height = 22;
        let idle_day_TextCircle_unit = null;
        let idle_day_TextCircle_unit_width = 20;
        let idle_battery_current_text_font = ''
        let idle_image_img = ''
        let idle_analog_clock_pro_hour_pointer_img = ''
        let idle_analog_clock_pro_minute_pointer_img = ''
        let idle_timerUpdateSec = undefined;
        let normal_step_jumpable_img_click = ''
        let normal_battery_jumpable_img_click = ''
        let normal_temperature_jumpable_img_click = ''
        let normal_alarm_jumpable_img_click = ''
        let Button_1 = ''
        let Button_2 = ''
        let timeSensor = '';


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            console.log('Watch_Face.ScreenNormal');
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 466,
              h: 466,
              src: '1.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 217,
              y: 327,
              src: 'bt.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 216,
              y: 48,
              src: 'alar.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_year_text_circle_img = hmUI.createWidget(hmUI.widget.Text_Circle, {
              // circle_center_X: 233,
              // circle_center_Y: 233,
              // font_array: ["R-02.png","R-03.png","R-04.png","R-05.png","R-06.png","R-07.png","R-08.png","R-09.png","R-10.png","R-11.png"],
              // radius: 184,
              // angle: 162,
              // char_space_angle: 0,
              // zero: false,
              // reverse_direction: true,
              // unit_in_alignment: true,
              // vertical_alignment: BOTTOM,
              // horizontal_alignment: CENTER_H,
              // type: hmUI.data_type.YEAR,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_year_TextCircle_ASCIIARRAY[0] = 'R-02.png';  // set of images with numbers
            normal_year_TextCircle_ASCIIARRAY[1] = 'R-03.png';  // set of images with numbers
            normal_year_TextCircle_ASCIIARRAY[2] = 'R-04.png';  // set of images with numbers
            normal_year_TextCircle_ASCIIARRAY[3] = 'R-05.png';  // set of images with numbers
            normal_year_TextCircle_ASCIIARRAY[4] = 'R-06.png';  // set of images with numbers
            normal_year_TextCircle_ASCIIARRAY[5] = 'R-07.png';  // set of images with numbers
            normal_year_TextCircle_ASCIIARRAY[6] = 'R-08.png';  // set of images with numbers
            normal_year_TextCircle_ASCIIARRAY[7] = 'R-09.png';  // set of images with numbers
            normal_year_TextCircle_ASCIIARRAY[8] = 'R-10.png';  // set of images with numbers
            normal_year_TextCircle_ASCIIARRAY[9] = 'R-11.png';  // set of images with numbers

            //#region TextCircle
            for (let i = 0; i < 4; i++) {
              normal_year_TextCircle[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 466,
                h: 466,
                center_x: 233,
                center_y: 233,
                pos_x: 233 - normal_year_TextCircle_img_width / 2,
                pos_y: 233 + 162,
                src: 'R-02.png',
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
              normal_year_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
            };
            //#endregion

            if (!timeSensor) timeSensor = hmSensor.createSensor(hmSensor.id.TIME);
            let screenType = hmSetting.getScreenType();            
            function toDegree (radian) {
              return radian * (180 / Math.PI);
            };

            // normal_month_text_circle_img = hmUI.createWidget(hmUI.widget.Text_Circle, {
              // circle_center_X: 233,
              // circle_center_Y: 233,
              // font_array: ["R-02.png","R-03.png","R-04.png","R-05.png","R-06.png","R-07.png","R-08.png","R-09.png","R-10.png","R-11.png"],
              // radius: 184,
              // angle: 177,
              // char_space_angle: 0,
              // unit: 'ESP.png',
              // zero: true,
              // reverse_direction: true,
              // unit_in_alignment: true,
              // vertical_alignment: BOTTOM,
              // horizontal_alignment: CENTER_H,
              // type: hmUI.data_type.MONTH,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_month_TextCircle_ASCIIARRAY[0] = 'R-02.png';  // set of images with numbers
            normal_month_TextCircle_ASCIIARRAY[1] = 'R-03.png';  // set of images with numbers
            normal_month_TextCircle_ASCIIARRAY[2] = 'R-04.png';  // set of images with numbers
            normal_month_TextCircle_ASCIIARRAY[3] = 'R-05.png';  // set of images with numbers
            normal_month_TextCircle_ASCIIARRAY[4] = 'R-06.png';  // set of images with numbers
            normal_month_TextCircle_ASCIIARRAY[5] = 'R-07.png';  // set of images with numbers
            normal_month_TextCircle_ASCIIARRAY[6] = 'R-08.png';  // set of images with numbers
            normal_month_TextCircle_ASCIIARRAY[7] = 'R-09.png';  // set of images with numbers
            normal_month_TextCircle_ASCIIARRAY[8] = 'R-10.png';  // set of images with numbers
            normal_month_TextCircle_ASCIIARRAY[9] = 'R-11.png';  // set of images with numbers

            //#region TextCircle
            for (let i = 0; i < 2; i++) {
              normal_month_TextCircle[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 466,
                h: 466,
                center_x: 233,
                center_y: 233,
                pos_x: 233 - normal_month_TextCircle_img_width / 2,
                pos_y: 233 + 162,
                src: 'R-02.png',
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
              normal_month_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
            };

            normal_month_TextCircle_unit = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 466,
              h: 466,
              center_x: 233,
              center_y: 233,
              pos_x: 233 - normal_month_TextCircle_unit_width / 2,
              pos_y: 233 + 162,
              src: 'ESP.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            normal_month_TextCircle_unit.setProperty(hmUI.prop.VISIBLE, false);
            //#endregion

            // normal_day_text_circle_img = hmUI.createWidget(hmUI.widget.Text_Circle, {
              // circle_center_X: 233,
              // circle_center_Y: 233,
              // font_array: ["R-02.png","R-03.png","R-04.png","R-05.png","R-06.png","R-07.png","R-08.png","R-09.png","R-10.png","R-11.png"],
              // radius: 184,
              // angle: 196,
              // char_space_angle: 0,
              // unit: 'ESP.png',
              // zero: true,
              // reverse_direction: true,
              // unit_in_alignment: true,
              // vertical_alignment: BOTTOM,
              // horizontal_alignment: CENTER_H,
              // type: hmUI.data_type.DAY,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_day_TextCircle_ASCIIARRAY[0] = 'R-02.png';  // set of images with numbers
            normal_day_TextCircle_ASCIIARRAY[1] = 'R-03.png';  // set of images with numbers
            normal_day_TextCircle_ASCIIARRAY[2] = 'R-04.png';  // set of images with numbers
            normal_day_TextCircle_ASCIIARRAY[3] = 'R-05.png';  // set of images with numbers
            normal_day_TextCircle_ASCIIARRAY[4] = 'R-06.png';  // set of images with numbers
            normal_day_TextCircle_ASCIIARRAY[5] = 'R-07.png';  // set of images with numbers
            normal_day_TextCircle_ASCIIARRAY[6] = 'R-08.png';  // set of images with numbers
            normal_day_TextCircle_ASCIIARRAY[7] = 'R-09.png';  // set of images with numbers
            normal_day_TextCircle_ASCIIARRAY[8] = 'R-10.png';  // set of images with numbers
            normal_day_TextCircle_ASCIIARRAY[9] = 'R-11.png';  // set of images with numbers

            //#region TextCircle
            for (let i = 0; i < 2; i++) {
              normal_day_TextCircle[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 466,
                h: 466,
                center_x: 233,
                center_y: 233,
                pos_x: 233 - normal_day_TextCircle_img_width / 2,
                pos_y: 233 + 162,
                src: 'R-02.png',
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
              normal_day_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
            };

            normal_day_TextCircle_unit = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 466,
              h: 466,
              center_x: 233,
              center_y: 233,
              pos_x: 233 - normal_day_TextCircle_unit_width / 2,
              pos_y: 233 + 162,
              src: 'ESP.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            normal_day_TextCircle_unit.setProperty(hmUI.prop.VISIBLE, false);
            //#endregion

            // normal_battery_circle_scale = hmUI.createWidget(hmUI.widget.Circle_Scale, {
              // center_x: 233,
              // center_y: 233,
              // start_angle: 136,
              // end_angle: 45,
              // radius: 169,
              // line_width: 6,
              // line_cap: Rounded,
              // color: 0xFFFFFF00,
              // mirror: False,
              // inversion: False,
              // alpha: 255,
              // type: hmUI.data_type.BATTERY,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_battery_circle_scale = hmUI.createWidget(hmUI.widget.ARC_PROGRESS, {
              center_x: 233,
              center_y: 233,
              start_angle: 136,
              end_angle: 45,
              radius: 166,
              line_width: 6,
              corner_flag: 0,
              color: 0xFFFFFF00,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            
            const battery = hmSensor.createSensor(hmSensor.id.BATTERY);
            battery.addEventListener(hmSensor.event.CHANGE, function() {
              text_update();
              scale_call();
            });

            // normal_battery_text_circle_img = hmUI.createWidget(hmUI.widget.Text_Circle, {
              // circle_center_X: 233,
              // circle_center_Y: 233,
              // font_array: ["R-02.png","R-03.png","R-04.png","R-05.png","R-06.png","R-07.png","R-08.png","R-09.png","R-10.png","R-11.png"],
              // radius: 160,
              // angle: 90,
              // char_space_angle: 0,
              // unit: 'bat.png',
              // zero: false,
              // reverse_direction: true,
              // unit_in_alignment: true,
              // vertical_alignment: BOTTOM,
              // horizontal_alignment: CENTER_H,
              // type: hmUI.data_type.BATTERY,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_battery_TextCircle_ASCIIARRAY[0] = 'R-02.png';  // set of images with numbers
            normal_battery_TextCircle_ASCIIARRAY[1] = 'R-03.png';  // set of images with numbers
            normal_battery_TextCircle_ASCIIARRAY[2] = 'R-04.png';  // set of images with numbers
            normal_battery_TextCircle_ASCIIARRAY[3] = 'R-05.png';  // set of images with numbers
            normal_battery_TextCircle_ASCIIARRAY[4] = 'R-06.png';  // set of images with numbers
            normal_battery_TextCircle_ASCIIARRAY[5] = 'R-07.png';  // set of images with numbers
            normal_battery_TextCircle_ASCIIARRAY[6] = 'R-08.png';  // set of images with numbers
            normal_battery_TextCircle_ASCIIARRAY[7] = 'R-09.png';  // set of images with numbers
            normal_battery_TextCircle_ASCIIARRAY[8] = 'R-10.png';  // set of images with numbers
            normal_battery_TextCircle_ASCIIARRAY[9] = 'R-11.png';  // set of images with numbers

            //#region TextCircle
            for (let i = 0; i < 3; i++) {
              normal_battery_TextCircle[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 466,
                h: 466,
                center_x: 233,
                center_y: 233,
                pos_x: 233 - normal_battery_TextCircle_img_width / 2,
                pos_y: 233 + 138,
                src: 'R-02.png',
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
              normal_battery_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
            };

            normal_battery_TextCircle_unit = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 466,
              h: 466,
              center_x: 233,
              center_y: 233,
              pos_x: 233 - normal_battery_TextCircle_unit_width / 2,
              pos_y: 233 + 138,
              src: 'bat.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            normal_battery_TextCircle_unit.setProperty(hmUI.prop.VISIBLE, false);
            //#endregion

            // normal_step_circle_scale = hmUI.createWidget(hmUI.widget.Circle_Scale, {
              // center_x: 233,
              // center_y: 233,
              // start_angle: -136,
              // end_angle: -44,
              // radius: 169,
              // line_width: 6,
              // line_cap: Rounded,
              // color: 0xFFFFFF00,
              // mirror: False,
              // inversion: False,
              // alpha: 255,
              // type: hmUI.data_type.STEP,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_step_circle_scale = hmUI.createWidget(hmUI.widget.ARC_PROGRESS, {
              center_x: 233,
              center_y: 233,
              start_angle: -136,
              end_angle: -44,
              radius: 166,
              line_width: 6,
              corner_flag: 0,
              color: 0xFFFFFF00,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            
            const step = hmSensor.createSensor(hmSensor.id.STEP);
            step.addEventListener(hmSensor.event.CHANGE, function() {
              text_update();
              scale_call();
            });

            // normal_step_text_circle_img = hmUI.createWidget(hmUI.widget.Text_Circle, {
              // circle_center_X: 233,
              // circle_center_Y: 233,
              // font_array: ["R-02.png","R-03.png","R-04.png","R-05.png","R-06.png","R-07.png","R-08.png","R-09.png","R-10.png","R-11.png"],
              // radius: 160,
              // angle: -91,
              // char_space_angle: 0,
              // zero: false,
              // reverse_direction: true,
              // unit_in_alignment: true,
              // vertical_alignment: BOTTOM,
              // horizontal_alignment: CENTER_H,
              // type: hmUI.data_type.STEP,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_step_TextCircle_ASCIIARRAY[0] = 'R-02.png';  // set of images with numbers
            normal_step_TextCircle_ASCIIARRAY[1] = 'R-03.png';  // set of images with numbers
            normal_step_TextCircle_ASCIIARRAY[2] = 'R-04.png';  // set of images with numbers
            normal_step_TextCircle_ASCIIARRAY[3] = 'R-05.png';  // set of images with numbers
            normal_step_TextCircle_ASCIIARRAY[4] = 'R-06.png';  // set of images with numbers
            normal_step_TextCircle_ASCIIARRAY[5] = 'R-07.png';  // set of images with numbers
            normal_step_TextCircle_ASCIIARRAY[6] = 'R-08.png';  // set of images with numbers
            normal_step_TextCircle_ASCIIARRAY[7] = 'R-09.png';  // set of images with numbers
            normal_step_TextCircle_ASCIIARRAY[8] = 'R-10.png';  // set of images with numbers
            normal_step_TextCircle_ASCIIARRAY[9] = 'R-11.png';  // set of images with numbers

            //#region TextCircle
            for (let i = 0; i < 5; i++) {
              normal_step_TextCircle[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 466,
                h: 466,
                center_x: 233,
                center_y: 233,
                pos_x: 233 - normal_step_TextCircle_img_width / 2,
                pos_y: 233 + 138,
                src: 'R-02.png',
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
              normal_step_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
            };
            //#endregion
              const weatherSensor = hmSensor.createSensor(hmSensor.id.WEATHER);

            normal_city_name_text = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 71,
              y: 71,
              w: 324,
              h: 324,
              text_size: 20,
              char_space: 0,
              color: 0xFFFFFF00,
              // use_text_circle: true,
              start_angle: 135,
              end_angle: 225,
              mode: 1,
              // radius: 162,
              align_h: hmUI.align.CENTER_H,
              // unit_type: 1,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_image_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: '2.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            const deviceInfo = hmSetting.getDeviceInfo();
            timeSensor.addEventListener(timeSensor.event.MINUTEEND, function() {
              let updateHour = timeSensor.minute == 0;

              time_update(updateHour, true);
            });

            // normal_analog_clock_pro_hour_pointer_img = hmUI.createWidget(hmUI.widget.TIME_POINTER_PRO, {
              // src: 'h.png',
              // center_x: 233,
              // center_y: 233,
              // x: 20,
              // y: 142,
              // start_angle: 0,
              // end_angle: 360,
              // type: hmUI.data_type.hour,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });


            normal_analog_clock_pro_hour_pointer_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: deviceInfo.width,
              h: deviceInfo.height,
              pos_x: 233 - 20,
              pos_y: 233 - 142,
              center_x: 233,
              center_y: 233,
              src: 'h.png',
              angle: 0,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_analog_clock_pro_minute_pointer_img = hmUI.createWidget(hmUI.widget.TIME_POINTER_PRO, {
              // src: 'm.png',
              // center_x: 233,
              // center_y: 233,
              // x: 17,
              // y: 215,
              // start_angle: 0,
              // end_angle: 360,
              // type: hmUI.data_type.minute,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });


            normal_analog_clock_pro_minute_pointer_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: deviceInfo.width,
              h: deviceInfo.height,
              pos_x: 233 - 17,
              pos_y: 233 - 215,
              center_x: 233,
              center_y: 233,
              src: 'm.png',
              angle: 0,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_analog_clock_pro_second_pointer_img = hmUI.createWidget(hmUI.widget.TIME_POINTER_PRO, {
              // src: 's.png',
              // center_x: 233,
              // center_y: 233,
              // x: 141,
              // y: 326,
              // start_angle: 0,
              // end_angle: 360,
              // type: hmUI.data_type.second,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });


            normal_analog_clock_time_pointer_smooth_second = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              second_path: 's.png',
              second_centerX: 233,
              second_centerY: 233,
              second_posX: 141,
              second_posY: 326,
              fresh_frequency: 20,
              fresh_freqency: 20,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_analog_clock_pro_smooth_second = hmUI.createWidget(hmUI.widget.SMOOTH_SECOND, {
              // type: 3,
              // fps: 20,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });



            console.log('Watch_Face.ScreenAOD');
            idle_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 466,
              h: 466,
              src: '0003.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 217,
              y: 356,
              src: 'bt.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 217,
              y: 89,
              src: 'alar.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            // idle_year_text_circle_img = hmUI.createWidget(hmUI.widget.Text_Circle, {
              // circle_center_X: 233,
              // circle_center_Y: 233,
              // font_array: ["R-02.png","R-03.png","R-04.png","R-05.png","R-06.png","R-07.png","R-08.png","R-09.png","R-10.png","R-11.png"],
              // radius: 184,
              // angle: 162,
              // char_space_angle: 0,
              // zero: false,
              // reverse_direction: true,
              // unit_in_alignment: true,
              // vertical_alignment: BOTTOM,
              // horizontal_alignment: CENTER_H,
              // type: hmUI.data_type.YEAR,
              // show_level: hmUI.show_level.ONLY_AOD,
            // });

            idle_year_TextCircle_ASCIIARRAY[0] = 'R-02.png';  // set of images with numbers
            idle_year_TextCircle_ASCIIARRAY[1] = 'R-03.png';  // set of images with numbers
            idle_year_TextCircle_ASCIIARRAY[2] = 'R-04.png';  // set of images with numbers
            idle_year_TextCircle_ASCIIARRAY[3] = 'R-05.png';  // set of images with numbers
            idle_year_TextCircle_ASCIIARRAY[4] = 'R-06.png';  // set of images with numbers
            idle_year_TextCircle_ASCIIARRAY[5] = 'R-07.png';  // set of images with numbers
            idle_year_TextCircle_ASCIIARRAY[6] = 'R-08.png';  // set of images with numbers
            idle_year_TextCircle_ASCIIARRAY[7] = 'R-09.png';  // set of images with numbers
            idle_year_TextCircle_ASCIIARRAY[8] = 'R-10.png';  // set of images with numbers
            idle_year_TextCircle_ASCIIARRAY[9] = 'R-11.png';  // set of images with numbers

            //#region TextCircle
            for (let i = 0; i < 4; i++) {
              idle_year_TextCircle[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 466,
                h: 466,
                center_x: 233,
                center_y: 233,
                pos_x: 233 - idle_year_TextCircle_img_width / 2,
                pos_y: 233 + 162,
                src: 'R-02.png',
                show_level: hmUI.show_level.ONLY_AOD,
              });
              idle_year_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
            };
            //#endregion

            // idle_month_text_circle_img = hmUI.createWidget(hmUI.widget.Text_Circle, {
              // circle_center_X: 233,
              // circle_center_Y: 233,
              // font_array: ["R-02.png","R-03.png","R-04.png","R-05.png","R-06.png","R-07.png","R-08.png","R-09.png","R-10.png","R-11.png"],
              // radius: 184,
              // angle: 177,
              // char_space_angle: 0,
              // unit: 'ESP.png',
              // zero: true,
              // reverse_direction: true,
              // unit_in_alignment: true,
              // vertical_alignment: BOTTOM,
              // horizontal_alignment: CENTER_H,
              // type: hmUI.data_type.MONTH,
              // show_level: hmUI.show_level.ONLY_AOD,
            // });

            idle_month_TextCircle_ASCIIARRAY[0] = 'R-02.png';  // set of images with numbers
            idle_month_TextCircle_ASCIIARRAY[1] = 'R-03.png';  // set of images with numbers
            idle_month_TextCircle_ASCIIARRAY[2] = 'R-04.png';  // set of images with numbers
            idle_month_TextCircle_ASCIIARRAY[3] = 'R-05.png';  // set of images with numbers
            idle_month_TextCircle_ASCIIARRAY[4] = 'R-06.png';  // set of images with numbers
            idle_month_TextCircle_ASCIIARRAY[5] = 'R-07.png';  // set of images with numbers
            idle_month_TextCircle_ASCIIARRAY[6] = 'R-08.png';  // set of images with numbers
            idle_month_TextCircle_ASCIIARRAY[7] = 'R-09.png';  // set of images with numbers
            idle_month_TextCircle_ASCIIARRAY[8] = 'R-10.png';  // set of images with numbers
            idle_month_TextCircle_ASCIIARRAY[9] = 'R-11.png';  // set of images with numbers

            //#region TextCircle
            for (let i = 0; i < 2; i++) {
              idle_month_TextCircle[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 466,
                h: 466,
                center_x: 233,
                center_y: 233,
                pos_x: 233 - idle_month_TextCircle_img_width / 2,
                pos_y: 233 + 162,
                src: 'R-02.png',
                show_level: hmUI.show_level.ONLY_AOD,
              });
              idle_month_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
            };

            idle_month_TextCircle_unit = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 466,
              h: 466,
              center_x: 233,
              center_y: 233,
              pos_x: 233 - idle_month_TextCircle_unit_width / 2,
              pos_y: 233 + 162,
              src: 'ESP.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });
            idle_month_TextCircle_unit.setProperty(hmUI.prop.VISIBLE, false);
            //#endregion

            // idle_day_text_circle_img = hmUI.createWidget(hmUI.widget.Text_Circle, {
              // circle_center_X: 233,
              // circle_center_Y: 233,
              // font_array: ["R-02.png","R-03.png","R-04.png","R-05.png","R-06.png","R-07.png","R-08.png","R-09.png","R-10.png","R-11.png"],
              // radius: 184,
              // angle: 196,
              // char_space_angle: 0,
              // unit: 'ESP.png',
              // zero: true,
              // reverse_direction: true,
              // unit_in_alignment: true,
              // vertical_alignment: BOTTOM,
              // horizontal_alignment: CENTER_H,
              // type: hmUI.data_type.DAY,
              // show_level: hmUI.show_level.ONLY_AOD,
            // });

            idle_day_TextCircle_ASCIIARRAY[0] = 'R-02.png';  // set of images with numbers
            idle_day_TextCircle_ASCIIARRAY[1] = 'R-03.png';  // set of images with numbers
            idle_day_TextCircle_ASCIIARRAY[2] = 'R-04.png';  // set of images with numbers
            idle_day_TextCircle_ASCIIARRAY[3] = 'R-05.png';  // set of images with numbers
            idle_day_TextCircle_ASCIIARRAY[4] = 'R-06.png';  // set of images with numbers
            idle_day_TextCircle_ASCIIARRAY[5] = 'R-07.png';  // set of images with numbers
            idle_day_TextCircle_ASCIIARRAY[6] = 'R-08.png';  // set of images with numbers
            idle_day_TextCircle_ASCIIARRAY[7] = 'R-09.png';  // set of images with numbers
            idle_day_TextCircle_ASCIIARRAY[8] = 'R-10.png';  // set of images with numbers
            idle_day_TextCircle_ASCIIARRAY[9] = 'R-11.png';  // set of images with numbers

            //#region TextCircle
            for (let i = 0; i < 2; i++) {
              idle_day_TextCircle[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 466,
                h: 466,
                center_x: 233,
                center_y: 233,
                pos_x: 233 - idle_day_TextCircle_img_width / 2,
                pos_y: 233 + 162,
                src: 'R-02.png',
                show_level: hmUI.show_level.ONLY_AOD,
              });
              idle_day_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
            };

            idle_day_TextCircle_unit = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 466,
              h: 466,
              center_x: 233,
              center_y: 233,
              pos_x: 233 - idle_day_TextCircle_unit_width / 2,
              pos_y: 233 + 162,
              src: 'ESP.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });
            idle_day_TextCircle_unit.setProperty(hmUI.prop.VISIBLE, false);
            //#endregion

            idle_battery_current_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 201,
              y: 50,
              w: 70,
              h: 35,
              text_size: 25,
              char_space: 0,
              color: 0xFFC0C0C0,
              line_space: 0,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.CENTER_H,
              unit_type: 1,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_image_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: '2.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            // idle_analog_clock_pro_hour_pointer_img = hmUI.createWidget(hmUI.widget.TIME_POINTER_PRO, {
              // src: 'h.png',
              // center_x: 233,
              // center_y: 233,
              // x: 20,
              // y: 142,
              // start_angle: 0,
              // end_angle: 360,
              // type: hmUI.data_type.hour,
              // show_level: hmUI.show_level.ONLY_AOD,
            // });


            idle_analog_clock_pro_hour_pointer_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: deviceInfo.width,
              h: deviceInfo.height,
              pos_x: 233 - 20,
              pos_y: 233 - 142,
              center_x: 233,
              center_y: 233,
              src: 'h.png',
              angle: 0,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            // idle_analog_clock_pro_minute_pointer_img = hmUI.createWidget(hmUI.widget.TIME_POINTER_PRO, {
              // src: 'm.png',
              // center_x: 233,
              // center_y: 233,
              // x: 17,
              // y: 215,
              // start_angle: 0,
              // end_angle: 360,
              // type: hmUI.data_type.minute,
              // show_level: hmUI.show_level.ONLY_AOD,
            // });


            idle_analog_clock_pro_minute_pointer_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: deviceInfo.width,
              h: deviceInfo.height,
              pos_x: 233 - 17,
              pos_y: 233 - 215,
              center_x: 233,
              center_y: 233,
              src: 'm.png',
              angle: 0,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            // idle_analog_clock_pro_smooth_second = hmUI.createWidget(hmUI.widget.SMOOTH_SECOND, {
              // type: 2,
              // fps: 20,
              // show_level: hmUI.show_level.ONLY_AOD,
            // });

            console.log('Watch_Face.Shortcuts');

            normal_step_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 60,
              y: 118,
              w: 70,
              h: 235,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 330,
              y: 113,
              w: 70,
              h: 237,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 201,
              y: 0,
              w: 70,
              h: 47,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_alarm_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 210,
              y: 48,
              w: 50,
              h: 50,
              type: hmUI.data_type.ALARM_CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            console.log('Watch_Face.Buttons');
            Button_1 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 159,
              y: 353,
              w: 151,
              h: 68,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'transparent.png',
              normal_src: 'transparent.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'ScheduleCalScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_2 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 193,
              y: 193,
              w: 80,
              h: 80,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'transparent.png',
              normal_src: 'transparent.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'AppListScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            //#region time_update
            function time_update(updateHour = false, updateMinute = false) {
              console.log('time_update()');
              let hour = timeSensor.hour;
              let minute = timeSensor.minute;
              let second = timeSensor.second;
              let format_hour = timeSensor.format_hour;

              if (updateMinute) { // Hour Pointer
                let normal_hour = hour;
                let normal_fullAngle_hour = 360;
                if (normal_hour > 11) normal_hour -= 12;
                let normal_angle_hour = 0 + normal_fullAngle_hour*normal_hour/12 + (normal_fullAngle_hour/12)*minute/60;
                if (normal_analog_clock_pro_hour_pointer_img) normal_analog_clock_pro_hour_pointer_img.setProperty(hmUI.prop.ANGLE, normal_angle_hour);
              };

                let normal_fullAngle_minute = 360;
                let normal_angle_minute = 0 + normal_fullAngle_minute*(minute + second/60)/60;
                if (normal_analog_clock_pro_minute_pointer_img) normal_analog_clock_pro_minute_pointer_img.setProperty(hmUI.prop.ANGLE, normal_angle_minute);
              if (updateMinute) { // Hour Pointer
                let idle_hour = hour;
                let idle_fullAngle_hour = 360;
                if (idle_hour > 11) idle_hour -= 12;
                let idle_angle_hour = 0 + idle_fullAngle_hour*idle_hour/12 + (idle_fullAngle_hour/12)*minute/60;
                if (idle_analog_clock_pro_hour_pointer_img) idle_analog_clock_pro_hour_pointer_img.setProperty(hmUI.prop.ANGLE, idle_angle_hour);
              };

                let idle_fullAngle_minute = 360;
                let idle_angle_minute = 0 + idle_fullAngle_minute*(minute + second/60)/60;
                if (idle_analog_clock_pro_minute_pointer_img) idle_analog_clock_pro_minute_pointer_img.setProperty(hmUI.prop.ANGLE, idle_angle_minute);
            };

            //#endregion
            //#region text_update
            function text_update() {
              console.log('text_update()');

              console.log('update text circle year_TIME');
              let valueYear = timeSensor.year;
              let normal_year_circle_string = parseInt(valueYear % 100).toString();

              if (screenType != hmSetting.screen_type.AOD) {
                for (var i = 1; i < 4; i++) {  // hide all symbols
                  normal_year_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                let char_Angle = 342;
                if (valueYear != null && valueYear != undefined && isFinite(valueYear) && normal_year_circle_string.length > 0 && normal_year_circle_string.length <= 4) {  // display data if it was possible to get it
                  let normal_year_TextCircle_img_angle = 0;
                  let normal_year_TextCircle_dot_img_angle = 0;
                  normal_year_TextCircle_img_angle = toDegree(Math.atan2(normal_year_TextCircle_img_width/2, 184));
                  // alignment = CENTER_H
                  let normal_year_TextCircle_angleOffset = normal_year_TextCircle_img_angle * (normal_year_circle_string.length - 1);
                  normal_year_TextCircle_angleOffset = -normal_year_TextCircle_angleOffset;
                  char_Angle -= normal_year_TextCircle_angleOffset;
                  // alignment end
                  
                  let firstSymbol = true;
                  let index = 0;
                  for (let char of normal_year_circle_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 4) break;
                    if (charCode >= 0 && charCode < 10) { 
                      if (!firstSymbol) char_Angle -= normal_year_TextCircle_img_angle;
                      firstSymbol = false;
                      normal_year_TextCircle[index].setProperty(hmUI.prop.ANGLE, char_Angle);
                      normal_year_TextCircle[index].setProperty(hmUI.prop.POS_X, 233 - normal_year_TextCircle_img_width / 2);
                      normal_year_TextCircle[index].setProperty(hmUI.prop.SRC, normal_year_TextCircle_ASCIIARRAY[charCode]);
                      normal_year_TextCircle[index].setProperty(hmUI.prop.VISIBLE, true);
                      char_Angle -= normal_year_TextCircle_img_angle;
                      index++;
                    };  // end if digit
                  };  // end char of string
                }  // end isFinite

              };

              console.log('update text circle month_TIME');
              let valueMonth = timeSensor.month;
              let normal_month_circle_string = parseInt(valueMonth).toString();
              normal_month_circle_string = normal_month_circle_string.padStart(2, '0');

              if (screenType != hmSetting.screen_type.AOD) {
                for (var i = 1; i < 2; i++) {  // hide all symbols
                  normal_month_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                normal_month_TextCircle_unit.setProperty(hmUI.prop.VISIBLE, false);
                let char_Angle = 357;
                if (valueMonth != null && valueMonth != undefined && isFinite(valueMonth) && normal_month_circle_string.length > 0 && normal_month_circle_string.length <= 2) {  // display data if it was possible to get it
                  let normal_month_TextCircle_img_angle = 0;
                  let normal_month_TextCircle_dot_img_angle = 0;
                  let normal_month_TextCircle_unit_angle = 0;
                  normal_month_TextCircle_img_angle = toDegree(Math.atan2(normal_month_TextCircle_img_width/2, 184));
                  normal_month_TextCircle_unit_angle = toDegree(Math.atan2(normal_month_TextCircle_unit_width/2, 184));
                  // alignment = CENTER_H
                  let normal_month_TextCircle_angleOffset = normal_month_TextCircle_img_angle * (normal_month_circle_string.length - 1);
                  normal_month_TextCircle_angleOffset = normal_month_TextCircle_angleOffset + (normal_month_TextCircle_img_angle + normal_month_TextCircle_unit_angle + 0) / 2;
                  normal_month_TextCircle_angleOffset = -normal_month_TextCircle_angleOffset;
                  char_Angle -= normal_month_TextCircle_angleOffset;
                  // alignment end
                  
                  let firstSymbol = true;
                  let index = 0;
                  for (let char of normal_month_circle_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 2) break;
                    if (charCode >= 0 && charCode < 10) { 
                      if (!firstSymbol) char_Angle -= normal_month_TextCircle_img_angle;
                      firstSymbol = false;
                      normal_month_TextCircle[index].setProperty(hmUI.prop.ANGLE, char_Angle);
                      normal_month_TextCircle[index].setProperty(hmUI.prop.POS_X, 233 - normal_month_TextCircle_img_width / 2);
                      normal_month_TextCircle[index].setProperty(hmUI.prop.SRC, normal_month_TextCircle_ASCIIARRAY[charCode]);
                      normal_month_TextCircle[index].setProperty(hmUI.prop.VISIBLE, true);
                      char_Angle -= normal_month_TextCircle_img_angle;
                      index++;
                    };  // end if digit
                  };  // end char of string
                  char_Angle -= normal_month_TextCircle_unit_angle;
                  normal_month_TextCircle_unit.setProperty(hmUI.prop.ANGLE, char_Angle);
                  normal_month_TextCircle_unit.setProperty(hmUI.prop.VISIBLE, true);
                }  // end isFinite

              };

              console.log('update text circle day_TIME');
              let valueDay = timeSensor.day;
              let normal_day_circle_string = parseInt(valueDay).toString();
              normal_day_circle_string = normal_day_circle_string.padStart(2, '0');

              if (screenType != hmSetting.screen_type.AOD) {
                for (var i = 1; i < 2; i++) {  // hide all symbols
                  normal_day_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                normal_day_TextCircle_unit.setProperty(hmUI.prop.VISIBLE, false);
                let char_Angle = 376;
                if (valueDay != null && valueDay != undefined && isFinite(valueDay) && normal_day_circle_string.length > 0 && normal_day_circle_string.length <= 2) {  // display data if it was possible to get it
                  let normal_day_TextCircle_img_angle = 0;
                  let normal_day_TextCircle_dot_img_angle = 0;
                  let normal_day_TextCircle_unit_angle = 0;
                  normal_day_TextCircle_img_angle = toDegree(Math.atan2(normal_day_TextCircle_img_width/2, 184));
                  normal_day_TextCircle_unit_angle = toDegree(Math.atan2(normal_day_TextCircle_unit_width/2, 184));
                  // alignment = CENTER_H
                  let normal_day_TextCircle_angleOffset = normal_day_TextCircle_img_angle * (normal_day_circle_string.length - 1);
                  normal_day_TextCircle_angleOffset = normal_day_TextCircle_angleOffset + (normal_day_TextCircle_img_angle + normal_day_TextCircle_unit_angle + 0) / 2;
                  normal_day_TextCircle_angleOffset = -normal_day_TextCircle_angleOffset;
                  char_Angle -= normal_day_TextCircle_angleOffset;
                  // alignment end
                  
                  let firstSymbol = true;
                  let index = 0;
                  for (let char of normal_day_circle_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 2) break;
                    if (charCode >= 0 && charCode < 10) { 
                      if (!firstSymbol) char_Angle -= normal_day_TextCircle_img_angle;
                      firstSymbol = false;
                      normal_day_TextCircle[index].setProperty(hmUI.prop.ANGLE, char_Angle);
                      normal_day_TextCircle[index].setProperty(hmUI.prop.POS_X, 233 - normal_day_TextCircle_img_width / 2);
                      normal_day_TextCircle[index].setProperty(hmUI.prop.SRC, normal_day_TextCircle_ASCIIARRAY[charCode]);
                      normal_day_TextCircle[index].setProperty(hmUI.prop.VISIBLE, true);
                      char_Angle -= normal_day_TextCircle_img_angle;
                      index++;
                    };  // end if digit
                  };  // end char of string
                  char_Angle -= normal_day_TextCircle_unit_angle;
                  normal_day_TextCircle_unit.setProperty(hmUI.prop.ANGLE, char_Angle);
                  normal_day_TextCircle_unit.setProperty(hmUI.prop.VISIBLE, true);
                }  // end isFinite

              };

              console.log('update text circle battery_BATTERY');
              let valueBattery = battery.current;
              let normal_battery_circle_string = parseInt(valueBattery).toString();

              if (screenType != hmSetting.screen_type.AOD) {
                for (var i = 1; i < 3; i++) {  // hide all symbols
                  normal_battery_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                normal_battery_TextCircle_unit.setProperty(hmUI.prop.VISIBLE, false);
                let char_Angle = 270;
                if (valueBattery != null && valueBattery != undefined && isFinite(valueBattery) && normal_battery_circle_string.length > 0 && normal_battery_circle_string.length <= 3) {  // display data if it was possible to get it
                  let normal_battery_TextCircle_img_angle = 0;
                  let normal_battery_TextCircle_dot_img_angle = 0;
                  let normal_battery_TextCircle_unit_angle = 0;
                  normal_battery_TextCircle_img_angle = toDegree(Math.atan2(normal_battery_TextCircle_img_width/2, 160));
                  normal_battery_TextCircle_unit_angle = toDegree(Math.atan2(normal_battery_TextCircle_unit_width/2, 160));
                  // alignment = CENTER_H
                  let normal_battery_TextCircle_angleOffset = normal_battery_TextCircle_img_angle * (normal_battery_circle_string.length - 1);
                  normal_battery_TextCircle_angleOffset = normal_battery_TextCircle_angleOffset + (normal_battery_TextCircle_img_angle + normal_battery_TextCircle_unit_angle + 0) / 2;
                  normal_battery_TextCircle_angleOffset = -normal_battery_TextCircle_angleOffset;
                  char_Angle -= normal_battery_TextCircle_angleOffset;
                  // alignment end
                  
                  let firstSymbol = true;
                  let index = 0;
                  for (let char of normal_battery_circle_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 3) break;
                    if (charCode >= 0 && charCode < 10) { 
                      if (!firstSymbol) char_Angle -= normal_battery_TextCircle_img_angle;
                      firstSymbol = false;
                      normal_battery_TextCircle[index].setProperty(hmUI.prop.ANGLE, char_Angle);
                      normal_battery_TextCircle[index].setProperty(hmUI.prop.POS_X, 233 - normal_battery_TextCircle_img_width / 2);
                      normal_battery_TextCircle[index].setProperty(hmUI.prop.SRC, normal_battery_TextCircle_ASCIIARRAY[charCode]);
                      normal_battery_TextCircle[index].setProperty(hmUI.prop.VISIBLE, true);
                      char_Angle -= normal_battery_TextCircle_img_angle;
                      index++;
                    };  // end if digit
                  };  // end char of string
                  char_Angle -= normal_battery_TextCircle_unit_angle;
                  normal_battery_TextCircle_unit.setProperty(hmUI.prop.ANGLE, char_Angle);
                  normal_battery_TextCircle_unit.setProperty(hmUI.prop.VISIBLE, true);
                }  // end isFinite

              };

              console.log('update text circle step_STEP');
              let valueStep = step.current;
              let normal_step_circle_string = parseInt(valueStep).toString();

              if (screenType != hmSetting.screen_type.AOD) {
                for (var i = 1; i < 5; i++) {  // hide all symbols
                  normal_step_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                let char_Angle = 89;
                if (valueStep != null && valueStep != undefined && isFinite(valueStep) && normal_step_circle_string.length > 0 && normal_step_circle_string.length <= 5) {  // display data if it was possible to get it
                  let normal_step_TextCircle_img_angle = 0;
                  let normal_step_TextCircle_dot_img_angle = 0;
                  normal_step_TextCircle_img_angle = toDegree(Math.atan2(normal_step_TextCircle_img_width/2, 160));
                  // alignment = CENTER_H
                  let normal_step_TextCircle_angleOffset = normal_step_TextCircle_img_angle * (normal_step_circle_string.length - 1);
                  normal_step_TextCircle_angleOffset = -normal_step_TextCircle_angleOffset;
                  char_Angle -= normal_step_TextCircle_angleOffset;
                  // alignment end
                  
                  let firstSymbol = true;
                  let index = 0;
                  for (let char of normal_step_circle_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 5) break;
                    if (charCode >= 0 && charCode < 10) { 
                      if (!firstSymbol) char_Angle -= normal_step_TextCircle_img_angle;
                      firstSymbol = false;
                      normal_step_TextCircle[index].setProperty(hmUI.prop.ANGLE, char_Angle);
                      normal_step_TextCircle[index].setProperty(hmUI.prop.POS_X, 233 - normal_step_TextCircle_img_width / 2);
                      normal_step_TextCircle[index].setProperty(hmUI.prop.SRC, normal_step_TextCircle_ASCIIARRAY[charCode]);
                      normal_step_TextCircle[index].setProperty(hmUI.prop.VISIBLE, true);
                      char_Angle -= normal_step_TextCircle_img_angle;
                      index++;
                    };  // end if digit
                  };  // end char of string
                }  // end isFinite

              };

              console.log('update text circle year_TIME');
              let idle_year_circle_string = parseInt(valueYear % 100).toString();

              if (screenType == hmSetting.screen_type.AOD) {
                for (var i = 1; i < 4; i++) {  // hide all symbols
                  idle_year_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                let char_Angle = 342;
                if (valueYear != null && valueYear != undefined && isFinite(valueYear) && idle_year_circle_string.length > 0 && idle_year_circle_string.length <= 4) {  // display data if it was possible to get it
                  let idle_year_TextCircle_img_angle = 0;
                  let idle_year_TextCircle_dot_img_angle = 0;
                  idle_year_TextCircle_img_angle = toDegree(Math.atan2(idle_year_TextCircle_img_width/2, 184));
                  // alignment = CENTER_H
                  let idle_year_TextCircle_angleOffset = idle_year_TextCircle_img_angle * (idle_year_circle_string.length - 1);
                  idle_year_TextCircle_angleOffset = -idle_year_TextCircle_angleOffset;
                  char_Angle -= idle_year_TextCircle_angleOffset;
                  // alignment end
                  
                  let firstSymbol = true;
                  let index = 0;
                  for (let char of idle_year_circle_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 4) break;
                    if (charCode >= 0 && charCode < 10) { 
                      if (!firstSymbol) char_Angle -= idle_year_TextCircle_img_angle;
                      firstSymbol = false;
                      idle_year_TextCircle[index].setProperty(hmUI.prop.ANGLE, char_Angle);
                      idle_year_TextCircle[index].setProperty(hmUI.prop.POS_X, 233 - idle_year_TextCircle_img_width / 2);
                      idle_year_TextCircle[index].setProperty(hmUI.prop.SRC, idle_year_TextCircle_ASCIIARRAY[charCode]);
                      idle_year_TextCircle[index].setProperty(hmUI.prop.VISIBLE, true);
                      char_Angle -= idle_year_TextCircle_img_angle;
                      index++;
                    };  // end if digit
                  };  // end char of string
                }  // end isFinite

              };

              console.log('update text circle month_TIME');
              let idle_month_circle_string = parseInt(valueMonth).toString();
              idle_month_circle_string = idle_month_circle_string.padStart(2, '0');

              if (screenType == hmSetting.screen_type.AOD) {
                for (var i = 1; i < 2; i++) {  // hide all symbols
                  idle_month_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                idle_month_TextCircle_unit.setProperty(hmUI.prop.VISIBLE, false);
                let char_Angle = 357;
                if (valueMonth != null && valueMonth != undefined && isFinite(valueMonth) && idle_month_circle_string.length > 0 && idle_month_circle_string.length <= 2) {  // display data if it was possible to get it
                  let idle_month_TextCircle_img_angle = 0;
                  let idle_month_TextCircle_dot_img_angle = 0;
                  let idle_month_TextCircle_unit_angle = 0;
                  idle_month_TextCircle_img_angle = toDegree(Math.atan2(idle_month_TextCircle_img_width/2, 184));
                  idle_month_TextCircle_unit_angle = toDegree(Math.atan2(idle_month_TextCircle_unit_width/2, 184));
                  // alignment = CENTER_H
                  let idle_month_TextCircle_angleOffset = idle_month_TextCircle_img_angle * (idle_month_circle_string.length - 1);
                  idle_month_TextCircle_angleOffset = idle_month_TextCircle_angleOffset + (idle_month_TextCircle_img_angle + idle_month_TextCircle_unit_angle + 0) / 2;
                  idle_month_TextCircle_angleOffset = -idle_month_TextCircle_angleOffset;
                  char_Angle -= idle_month_TextCircle_angleOffset;
                  // alignment end
                  
                  let firstSymbol = true;
                  let index = 0;
                  for (let char of idle_month_circle_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 2) break;
                    if (charCode >= 0 && charCode < 10) { 
                      if (!firstSymbol) char_Angle -= idle_month_TextCircle_img_angle;
                      firstSymbol = false;
                      idle_month_TextCircle[index].setProperty(hmUI.prop.ANGLE, char_Angle);
                      idle_month_TextCircle[index].setProperty(hmUI.prop.POS_X, 233 - idle_month_TextCircle_img_width / 2);
                      idle_month_TextCircle[index].setProperty(hmUI.prop.SRC, idle_month_TextCircle_ASCIIARRAY[charCode]);
                      idle_month_TextCircle[index].setProperty(hmUI.prop.VISIBLE, true);
                      char_Angle -= idle_month_TextCircle_img_angle;
                      index++;
                    };  // end if digit
                  };  // end char of string
                  char_Angle -= idle_month_TextCircle_unit_angle;
                  idle_month_TextCircle_unit.setProperty(hmUI.prop.ANGLE, char_Angle);
                  idle_month_TextCircle_unit.setProperty(hmUI.prop.VISIBLE, true);
                }  // end isFinite

              };

              console.log('update text circle day_TIME');
              let idle_day_circle_string = parseInt(valueDay).toString();
              idle_day_circle_string = idle_day_circle_string.padStart(2, '0');

              if (screenType == hmSetting.screen_type.AOD) {
                for (var i = 1; i < 2; i++) {  // hide all symbols
                  idle_day_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                idle_day_TextCircle_unit.setProperty(hmUI.prop.VISIBLE, false);
                let char_Angle = 376;
                if (valueDay != null && valueDay != undefined && isFinite(valueDay) && idle_day_circle_string.length > 0 && idle_day_circle_string.length <= 2) {  // display data if it was possible to get it
                  let idle_day_TextCircle_img_angle = 0;
                  let idle_day_TextCircle_dot_img_angle = 0;
                  let idle_day_TextCircle_unit_angle = 0;
                  idle_day_TextCircle_img_angle = toDegree(Math.atan2(idle_day_TextCircle_img_width/2, 184));
                  idle_day_TextCircle_unit_angle = toDegree(Math.atan2(idle_day_TextCircle_unit_width/2, 184));
                  // alignment = CENTER_H
                  let idle_day_TextCircle_angleOffset = idle_day_TextCircle_img_angle * (idle_day_circle_string.length - 1);
                  idle_day_TextCircle_angleOffset = idle_day_TextCircle_angleOffset + (idle_day_TextCircle_img_angle + idle_day_TextCircle_unit_angle + 0) / 2;
                  idle_day_TextCircle_angleOffset = -idle_day_TextCircle_angleOffset;
                  char_Angle -= idle_day_TextCircle_angleOffset;
                  // alignment end
                  
                  let firstSymbol = true;
                  let index = 0;
                  for (let char of idle_day_circle_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 2) break;
                    if (charCode >= 0 && charCode < 10) { 
                      if (!firstSymbol) char_Angle -= idle_day_TextCircle_img_angle;
                      firstSymbol = false;
                      idle_day_TextCircle[index].setProperty(hmUI.prop.ANGLE, char_Angle);
                      idle_day_TextCircle[index].setProperty(hmUI.prop.POS_X, 233 - idle_day_TextCircle_img_width / 2);
                      idle_day_TextCircle[index].setProperty(hmUI.prop.SRC, idle_day_TextCircle_ASCIIARRAY[charCode]);
                      idle_day_TextCircle[index].setProperty(hmUI.prop.VISIBLE, true);
                      char_Angle -= idle_day_TextCircle_img_angle;
                      index++;
                    };  // end if digit
                  };  // end char of string
                  char_Angle -= idle_day_TextCircle_unit_angle;
                  idle_day_TextCircle_unit.setProperty(hmUI.prop.ANGLE, char_Angle);
                  idle_day_TextCircle_unit.setProperty(hmUI.prop.VISIBLE, true);
                }  // end isFinite

              };

            };

            //#endregion
            function scale_call() {
              console.log('scale_call()');

                console.log('update scales BATTERY');
                
                let valueBattery = battery.current;
                let targetBattery = 100;
                let progressBattery = valueBattery/targetBattery;
                if (progressBattery > 1) progressBattery = 1;
                let progress_cs_normal_battery = progressBattery;

                if (screenType != hmSetting.screen_type.AOD) {

                  // normal_battery_circle_scale_circle_scale
                  let level = Math.round(progress_cs_normal_battery * 100);
                  if (normal_battery_circle_scale) {
                    normal_battery_circle_scale.setProperty(hmUI.prop.MORE, {                      
                      center_x: 233,
                      center_y: 233,
                      start_angle: 136,
                      end_angle: 45,
                      radius: 166,
                      line_width: 6,
                      corner_flag: 0,
                      color: 0xFFFFFF00,
                      show_level: hmUI.show_level.ONLY_NORMAL,
                      level: level,
                    });
                  };
                };

                console.log('update scales STEP');
                
                let valueStep = step.current;
                let targetStep = step.target;
                let progressStep = valueStep/targetStep;
                if (progressStep > 1) progressStep = 1;
                let progress_cs_normal_step = progressStep;

                if (screenType != hmSetting.screen_type.AOD) {

                  // normal_step_circle_scale_circle_scale
                  let level = Math.round(progress_cs_normal_step * 100);
                  if (normal_step_circle_scale) {
                    normal_step_circle_scale.setProperty(hmUI.prop.MORE, {                      
                      center_x: 233,
                      center_y: 233,
                      start_angle: -136,
                      end_angle: -44,
                      radius: 166,
                      line_width: 6,
                      corner_flag: 0,
                      color: 0xFFFFFF00,
                      show_level: hmUI.show_level.ONLY_NORMAL,
                      level: level,
                    });
                  };
                };

              console.log('Weather city name');
              let weatherData = weatherSensor.getForecastWeather();
              let normal_cityNameStr = weatherData.cityName;
              normal_cityNameStr = normal_cityNameStr.toUpperCase();
              normal_city_name_text.setProperty(hmUI.prop.TEXT, normal_cityNameStr);

            };

            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                console.log('resume_call()');
                scale_call();
                time_update(true, true);
                text_update();
                if (screenType == hmSetting.screen_type.WATCHFACE) {
                  if (!normal_timerTextUpdate) {
                    normal_timerTextUpdate = timer.createTimer(0, 1000, (function (option) {
                      text_update();
                    }));  // end timer 
                  };  // end timer check
                };  // end screenType

                if (screenType == hmSetting.screen_type.WATCHFACE) {
                  if (!normal_timerUpdateSec) {
                    let animDelay = timeSensor.utc % 1000;
                    let animRepeat = 1000;
                    normal_timerUpdateSec = timer.createTimer(animDelay, animRepeat, (function (option) {
                      time_update(false, true);
                    }));  // end timer 
                  };  // end timer check
                };  // end screenType

                if (screenType == hmSetting.screen_type.AOD) {
                  if (!idle_timerTextUpdate) {
                    idle_timerTextUpdate = timer.createTimer(0, 1000, (function (option) {
                      text_update();
                    }));  // end timer 
                  };  // end timer check
                };  // end screenType

                if (screenType == hmSetting.screen_type.AOD) {
                  if (!idle_timerUpdateSec) {
                    let animDelay = timeSensor.utc % 1000;
                    let animRepeat = 1000;
                    idle_timerUpdateSec = timer.createTimer(animDelay, animRepeat, (function (option) {
                      time_update(false, true);
                    }));  // end timer 
                  };  // end timer check
                };  // end screenType


              }),
              pause_call: (function () {
                console.log('pause_call()');
                if (normal_timerTextUpdate) {
                  timer.stopTimer(normal_timerTextUpdate);
                  normal_timerTextUpdate = undefined;
                }
                if (normal_timerUpdateSec) {
                  timer.stopTimer(normal_timerUpdateSec);
                  normal_timerUpdateSec = undefined;
                }
                if (idle_timerTextUpdate) {
                  timer.stopTimer(idle_timerTextUpdate);
                  idle_timerTextUpdate = undefined;
                }
                if (idle_timerUpdateSec) {
                  timer.stopTimer(idle_timerUpdateSec);
                  idle_timerUpdateSec = undefined;
                }

              }),
            });

                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}