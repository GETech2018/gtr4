﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        const logger = Logger.getLogger('watchface_SashaCX75');
        //end of ignored block

        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_system_dnd_img = ''
        let normal_system_disconnect_img = ''
        let normal_system_clock_img = ''
        let normal_heart_rate_text_text_img = ''
        let normal_heart_rate_image_progress_img_level = ''
        let normal_battery_text_text_img = ''
        let normal_battery_image_progress_img_level = ''
        let normal_date_img_date_week_img = ''
        let normal_date_img_date_day = ''
        let normal_date_img_date_month_img = ''
        let normal_date_img_date_year = ''
        let normal_distance_text_text_img = ''
        let normal_step_circle_scale = ''
        let normal_step_current_text_img = ''
        let normal_step_image_progress_img_level = ''
        let normal_frame_animation_1 = ''
        let normal_frame_animation_2 = ''
        let normal_digital_clock_img_time_AmPm = ''
        let normal_digital_clock_img_time = ''
        let normal_analog_clock_time_pointer_second = ''
        let idle_background_bg_img = ''
        let idle_digital_clock_img_time_AmPm = ''
        let idle_digital_clock_img_time = ''
        let idle_analog_clock_time_pointer_second = ''
        let normal_step_jumpable_img_click = ''
        let normal_heart_jumpable_img_click = ''
        let normal_temperature_jumpable_img_click = ''
        let normal_stopwatch_jumpable_img_click = ''
        let normal_alarm_jumpable_img_click = ''


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            console.log('Watch_Face.ScreenNormal');
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 466,
              h: 466,
              src: '0000.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_dnd_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 219,
              y: 82,
              src: 'i_2.png',
              type: hmUI.system_status.DISTURB,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 265,
              y: 412,
              src: 'i_1.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 175,
              y: 412,
              src: 'i_0.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 316,
              y: 353,
              font_array: ["n_0.png","n_1.png","n_2.png","n_3.png","n_4.png","n_5.png","n_6.png","n_7.png","n_8.png","n_9.png"],
              padding: false,
              h_space: -2,
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 310,
              y: 304,
              image_array: ["hr_01.png","hr_02.png","hr_03.png","hr_04.png","hr_05.png","hr_06.png"],
              image_length: 6,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 89,
              y: 354,
              font_array: ["n_0.png","n_1.png","n_2.png","n_3.png","n_4.png","n_5.png","n_6.png","n_7.png","n_8.png","n_9.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'k_1.png',
              unit_tc: 'k_1.png',
              unit_en: 'k_1.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 77,
              y: 304,
              image_array: ["bt_00.png","bt_01.png","bt_02.png","bt_03.png","bt_04.png","bt_05.png","bt_06.png","bt_07.png","bt_08.png","bt_09.png","bt_10.png","bt_11.png","bt_12.png","bt_13.png","bt_14.png","bt_15.png","bt_16.png","bt_17.png","bt_18.png","bt_19.png","bt_20.png","bt_21.png","bt_22.png","bt_23.png","bt_24.png","bt_25.png","bt_26.png","bt_27.png","bt_28.png","bt_29.png","bt_30.png","bt_31.png","bt_32.png","bt_33.png","bt_34.png","bt_35.png","bt_36.png","bt_37.png","bt_38.png","bt_39.png","bt_40.png","bt_41.png","bt_42.png","bt_43.png","bt_44.png","bt_45.png","bt_46.png","bt_47.png","bt_48.png","bt_49.png","bt_50.png","bt_51.png","bt_52.png","bt_53.png","bt_54.png","bt_55.png","bt_56.png","bt_57.png","bt_58.png","bt_59.png","bt_60.png","bt_61.png","bt_62.png","bt_63.png","bt_64.png","bt_65.png","bt_66.png","bt_67.png","bt_68.png","bt_69.png","bt_70.png","bt_71.png","bt_72.png","bt_73.png","bt_74.png","bt_75.png","bt_76.png","bt_77.png","bt_78.png","bt_79.png","bt_80.png","bt_81.png","bt_82.png","bt_83.png","bt_84.png","bt_85.png","bt_86.png","bt_87.png","bt_88.png","bt_89.png","bt_90.png","bt_91.png","bt_92.png","bt_93.png","bt_94.png","bt_95.png","bt_96.png","bt_97.png","bt_98.png","bt_99.png"],
              image_length: 100,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 297,
              y: 133,
              week_en: ["wk_01.png","wk_02.png","wk_03.png","wk_04.png","wk_05.png","wk_06.png","wk_07.png"],
              week_tc: ["wk_01.png","wk_02.png","wk_03.png","wk_04.png","wk_05.png","wk_06.png","wk_07.png"],
              week_sc: ["wk_01.png","wk_02.png","wk_03.png","wk_04.png","wk_05.png","wk_06.png","wk_07.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 252,
              day_startY: 133,
              day_sc_array: ["n_0.png","n_1.png","n_2.png","n_3.png","n_4.png","n_5.png","n_6.png","n_7.png","n_8.png","n_9.png"],
              day_tc_array: ["n_0.png","n_1.png","n_2.png","n_3.png","n_4.png","n_5.png","n_6.png","n_7.png","n_8.png","n_9.png"],
              day_en_array: ["n_0.png","n_1.png","n_2.png","n_3.png","n_4.png","n_5.png","n_6.png","n_7.png","n_8.png","n_9.png"],
              day_zero: 0,
              day_space: 0,
              day_align: hmUI.align.LEFT,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_month_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 190,
              month_startY: 133,
              month_sc_array: ["mo_01.png","mo_02.png","mo_03.png","mo_04.png","mo_05.png","mo_06.png","mo_07.png","mo_08.png","mo_09.png","mo_10.png","mo_11.png","mo_12.png"],
              month_tc_array: ["mo_01.png","mo_02.png","mo_03.png","mo_04.png","mo_05.png","mo_06.png","mo_07.png","mo_08.png","mo_09.png","mo_10.png","mo_11.png","mo_12.png"],
              month_en_array: ["mo_01.png","mo_02.png","mo_03.png","mo_04.png","mo_05.png","mo_06.png","mo_07.png","mo_08.png","mo_09.png","mo_10.png","mo_11.png","mo_12.png"],
              month_is_character: true ,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_year = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              year_startX: 117,
              year_startY: 133,
              year_sc_array: ["n_0.png","n_1.png","n_2.png","n_3.png","n_4.png","n_5.png","n_6.png","n_7.png","n_8.png","n_9.png"],
              year_tc_array: ["n_0.png","n_1.png","n_2.png","n_3.png","n_4.png","n_5.png","n_6.png","n_7.png","n_8.png","n_9.png"],
              year_en_array: ["n_0.png","n_1.png","n_2.png","n_3.png","n_4.png","n_5.png","n_6.png","n_7.png","n_8.png","n_9.png"],
              year_zero: 1,
              year_space: 0,
              year_align: hmUI.align.LEFT,
              year_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_distance_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 194,
              y: 374,
              font_array: ["n_0.png","n_1.png","n_2.png","n_3.png","n_4.png","n_5.png","n_6.png","n_7.png","n_8.png","n_9.png"],
              padding: false,
              h_space: -2,
              unit_sc: 'l_0.png',
              unit_tc: 'l_0.png',
              unit_en: 'l_0.png',
              imperial_unit_sc: 'l_1.png',
              imperial_unit_tc: 'l_1.png',
              imperial_unit_en: 'l_1.png',
              dot_image: 'k_0.png',
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.DISTANCE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_step_circle_scale = hmUI.createWidget(hmUI.widget.Circle_Scale, {
              // center_x: 233,
              // center_y: 357,
              // start_angle: -75,
              // end_angle: 76,
              // radius: 55,
              // line_width: 3,
              // line_cap: Rounded,
              // color: 0xFFFF8C00,
              // mirror: False,
              // inversion: False,
              // alpha: 255,
              // type: hmUI.data_type.STEP,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            let screenType = hmSetting.getScreenType();
            normal_step_circle_scale = hmUI.createWidget(hmUI.widget.ARC_PROGRESS, {
              center_x: 233,
              center_y: 357,
              start_angle: -75,
              end_angle: 76,
              radius: 54,
              line_width: 3,
              corner_flag: 0,
              color: 0xFFFF8C00,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            
            const step = hmSensor.createSensor(hmSensor.id.STEP);
            step.addEventListener(hmSensor.event.CHANGE, function() {
              scale_call();
            });

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 181,
              y: 351,
              font_array: ["n_0.png","n_1.png","n_2.png","n_3.png","n_4.png","n_5.png","n_6.png","n_7.png","n_8.png","n_9.png"],
              padding: false,
              h_space: -1,
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 221,
              y: 328,
              image_array: ["st_00.png","st_01.png","st_02.png","st_03.png","st_04.png","st_05.png","st_06.png","st_07.png","st_08.png","st_09.png","st_10.png","st_11.png","st_12.png","st_13.png","st_14.png","st_15.png","st_16.png","st_17.png","st_18.png","st_19.png","st_20.png","st_21.png","st_22.png","st_23.png","st_24.png","st_25.png","st_26.png","st_27.png","st_28.png","st_29.png","st_30.png","st_31.png","st_32.png","st_33.png","st_34.png","st_35.png","st_36.png","st_37.png","st_38.png","st_39.png","st_40.png","st_41.png","st_42.png","st_43.png","st_44.png","st_45.png","st_46.png","st_47.png","st_48.png","st_49.png","st_50.png","st_51.png","st_52.png","st_53.png","st_54.png","st_55.png","st_56.png","st_57.png","st_58.png","st_59.png","st_60.png","st_61.png","st_62.png","st_63.png","st_64.png","st_65.png","st_66.png","st_67.png","st_68.png","st_69.png","st_70.png","st_71.png","st_72.png","st_73.png","st_74.png","st_75.png","st_76.png","st_77.png","st_78.png","st_79.png","st_80.png","st_81.png","st_82.png","st_83.png","st_84.png","st_85.png","st_86.png","st_87.png","st_88.png","st_89.png","st_90.png","st_91.png","st_92.png","st_93.png","st_94.png","st_95.png","st_96.png","st_97.png","st_98.png","st_99.png"],
              image_length: 100,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_frame_animation_1 = hmUI.createWidget(hmUI.widget.IMG_ANIM, {
              x: 225,
              y: 188,
              anim_path: "animation",
              anim_ext: "png",
              anim_prefix: "ani",
              anim_fps: 2,
              anim_size: 2,
              repeat_count: 0,
              anim_repeat: true,
              anim_status:hmUI.anim_status.START,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_frame_animation_2 = hmUI.createWidget(hmUI.widget.IMG_ANIM, {
              x: 341,
              y: 321,
              anim_path: "animation",
              anim_ext: "png",
              anim_prefix: "han",
              anim_fps: 4,
              anim_size: 2,
              repeat_count: 0,
              anim_repeat: true,
              anim_status:hmUI.anim_status.START,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time_AmPm = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              am_x: 373,
              am_y: 263,
              am_sc_path: 'ap_0.png',
              am_en_path: 'ap_0.png',
              pm_x: 373,
              pm_y: 263,
              pm_sc_path: 'ap_1.png',
              pm_en_path: 'ap_1.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 91,
              hour_startY: 188,
              hour_array: ["d_0.png","d_1.png","d_2.png","d_3.png","d_4.png","d_5.png","d_6.png","d_7.png","d_8.png","d_9.png"],
              hour_zero: 0,
              hour_space: 8,
              hour_angle: 0,
              hour_align: hmUI.align.RIGHT,

              minute_startX: 249,
              minute_startY: 188,
              minute_array: ["d_0.png","d_1.png","d_2.png","d_3.png","d_4.png","d_5.png","d_6.png","d_7.png","d_8.png","d_9.png"],
              minute_zero: 1,
              minute_space: 8,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.RIGHT,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_second = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              second_path: 'sh.png',
              second_centerX: 233,
              second_centerY: 233,
              second_posX: 13,
              second_posY: 230,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            console.log('Watch_Face.ScreenAOD');
            idle_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 466,
              h: 466,
              src: 'aod.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time_AmPm = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              am_x: 373,
              am_y: 263,
              am_sc_path: 'ap_0.png',
              am_en_path: 'ap_0.png',
              pm_x: 373,
              pm_y: 263,
              pm_sc_path: 'ap_1.png',
              pm_en_path: 'ap_1.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 91,
              hour_startY: 188,
              hour_array: ["d_0.png","d_1.png","d_2.png","d_3.png","d_4.png","d_5.png","d_6.png","d_7.png","d_8.png","d_9.png"],
              hour_zero: 0,
              hour_space: 8,
              hour_angle: 0,
              hour_align: hmUI.align.RIGHT,

              minute_startX: 249,
              minute_startY: 188,
              minute_array: ["d_0.png","d_1.png","d_2.png","d_3.png","d_4.png","d_5.png","d_6.png","d_7.png","d_8.png","d_9.png"],
              minute_zero: 1,
              minute_space: 8,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.RIGHT,

              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_analog_clock_time_pointer_second = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              second_path: 'sh.png',
              second_centerX: 233,
              second_centerY: 233,
              second_posX: 13,
              second_posY: 230,
              show_level: hmUI.show_level.ONLY_AOD,
            });
            console.log('Watch_Face.Shortcuts');

            normal_step_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 186,
              y: 300,
              w: 100,
              h: 80,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 303,
              y: 300,
              w: 90,
              h: 90,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 186,
              y: 124,
              w: 100,
              h: 40,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_stopwatch_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 186,
              y: 182,
              w: 100,
              h: 100,
              type: hmUI.data_type.STOP_WATCH,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_alarm_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 157,
              y: 393,
              w: 60,
              h: 60,
              type: hmUI.data_type.ALARM_CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            function scale_call() {
              console.log('scale_call()');

                console.log('update scales STEP');
                
                let valueStep = step.current;
                let targetStep = step.target;
                let progressStep = valueStep/targetStep;
                if (progressStep > 1) progressStep = 1;
                let progress_cs_normal_step = progressStep;

                if (screenType != hmSetting.screen_type.AOD) {

                  // normal_step_circle_scale_circle_scale
                  let level = Math.round(progress_cs_normal_step * 100);
                  if (normal_step_circle_scale) {
                    normal_step_circle_scale.setProperty(hmUI.prop.MORE, {                      
                      center_x: 233,
                      center_y: 357,
                      start_angle: -75,
                      end_angle: 76,
                      radius: 54,
                      line_width: 3,
                      corner_flag: 0,
                      color: 0xFFFF8C00,
                      show_level: hmUI.show_level.ONLY_NORMAL,
                      level: level,
                    });
                  };
                };

            };

            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                console.log('resume_call()');
                scale_call();
                normal_frame_animation_1.setProperty(hmUI.prop.ANIM_STATUS,hmUI.anim_status.START);
                normal_frame_animation_2.setProperty(hmUI.prop.ANIM_STATUS,hmUI.anim_status.START);

              }),
              pause_call: (function () {
                console.log('pause_call()');
                normal_frame_animation_1.setProperty(hmUI.prop.ANIM_STATUS,hmUI.anim_status.STOP);
                normal_frame_animation_2.setProperty(hmUI.prop.ANIM_STATUS,hmUI.anim_status.STOP);

              }),
            });

                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}