    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
	** This watch face is created by Wong Kam Fei, please do not copy and modify it.
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        const logger = Logger.getLogger('watchface_SashaCX75');
        //end of ignored block

        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_sun_image_progress_img_level = '' //Sky Change
        let normal_weather_image_progress_img_level = ''  //Night Weather Icon
        let normal_weather2_image_progress_img_level = ''  //Night Weather Icon
        let normal_weather_text_sc_img_level = ''  //Night Weather Icon
        let normal_weather_text_tc_img_level = ''  //Night Weather Icon
        let normal_weather_text_en_img_level = ''  //Night Weather Icon
        let normal_Contact_img = ''  //Changetable icon
        let normal_Recent_Call_img = ''  //Changetable icon
        let normal_Local_Music_img = ''  //Changetable icon
        let normal_Phone_Music_img = ''  //Changetable icon
        let normal_Find_Phone_img = ''  //Changetable icon
        let normal_Recorder_img = ''  //Changetable icon
        let normal_Todo_img = ''  //Changetable icon
        let normal_Compass_img = ''  //Changetable icon
        let normal_One_Tap_img = ''  //Changetable icon
        let normal_masking_img = ''  //Changetable icon
        let normal_Icon_YingYang_img = ''  //Changetable icon
        let normal_city_name_text = ''
        let normal_weather_languege_change_img = ''
        let normal_battery_icon_img = ''
        let normal_battery_text_text_img = ''
        let normal_battery_text_separator_img = ''
        let normal_battery_image_progress_img_level = ''
        let normal_digital_clock_img_time = ''
        let normal_digital_clock_second_separator_img = ''
        let normal_digital_clock_img_time_AmPm = ''
        let normal_date_img_date_day = ''
        let normal_date_img_date_month_img = ''
        let normal_date_img_date_week_img = ''
        let normal_pai_bg_img = ''
        let normal_pai_image_progress_img_level = ''
        let normal_paiw_image_progress_img_level = ''
        let normal_pai_weekly_text_img = ''
        let normal_distance_text_text_img = ''
        let normal_distance_text_separator_img = ''
        let normal_step_current_text_img = ''
        let normal_step_current_separator_img = ''
        let normal_calorie_current_text_img = ''
        let normal_calorie_current_separator_img = ''
        let normal_spo2_text_text_img = ''
        let normal_spo2_text_separator_img = ''
        let normal_heart_rate_text_text_img = ''
        let normal_heart_rate_text_separator_img = ''
        let normal_stress_text_text_img = ''
        let normal_stress_icon_img = ''
        let normal_SLEEP_text_text_img = ''
        let normal_SLEEP_icon_img = ''
        let normal_system_dnd_img = ''
        let normal_system_clock_img = ''
        let normal_system_disconnect_img = ''
        let normal_system_lock_img = ''
        let normal_training_jumpable_img_click = ''
        let normal_step_jumpable_img_click = ''
        let normal_spo2_jumpable_img_click = ''
        let normal_heart_jumpable_img_click = ''
        let normal_stress_jumpable_img_click = ''
        let normal_pai_jumpable_img_click = ''
        let normal_alarm_jumpable_img_click = ''
        let normal_countdown_jumpable_img_click = ''
        let normal_sunrise_jumpable_img_click = ''
        let normal_stopwatch_jumpable_img_click = ''
        let normal_sleep_jumpable_img_click = ''
        let idle_battery_icon_img = ''
        let idle_battery_image_progress_img_level = ''
        let idle_battery_text_text_img = ''
        let idle_battery_text_separator_img = ''
        let idle_digital_clock_img_time_AmPm = ''
        let idle_digital_clock_img_time = ''
        let idle_date_img_date_day = ''
        let idle_date_img_date_month_img = ''
        let idle_date_img_date_week_img = ''
        let idle_masking_icon_img = ''
        let idle_masking2_icon_img = ''
        let idle_step_current_text_img = ''
        let idle_heart_rate_text_text_img = ''
        let idle_system_disconnect_img = ''
		let con_rest = 'Connection Restored'  // text change
		let con_lost = 'Connection Lost'  // text change
		let lunar_dply = 'Lunar Display'  // text change
		let lunar_hide = 'Lunar Hide'  // text change
		let top_cont = 'Top Contacts'  // text change
		let rcts_call = 'Recents Call'  // text change
		let v_memo = 'Voice Memos'  // text change
		let lcl_msc = 'Local Music'  // text change
		let phn_msc = 'Phone Music Control'  // text change
		let find_phn = 'Find My Phone'  // text change
		let todo = 'To Do'  // text change
		let comps = 'Compass'  // text change
		let otm = 'One-tap Measuring'  // text change
		let wb_text = ''  // text change
		let uv_cls = ['UVI-en-1.png','UVI-en-2.png','UVI-en-3.png','UVI-en-4.png','UVI-en-5.png'];  // text change
		let hPa = 'Number-hPa.png'  // text change
		let n_m = 'Number-m.png'  // text change
		let n_ft = 'Number-ft.png'  // text change
		let wind_dir = ['wind-en_00.png','wind-en_01.png','wind-en_02.png','wind-en_03.png','wind-en_04.png','wind-en_05.png','wind-en_06.png','wind-en_07.png'];  // text change
		let wind_cls = ''  // text change

//dynamic modify end


//vibrate (add destroy at end)
        const vibrate = hmSensor.createSensor(hmSensor.id.VIBRATE)
        function click_Vibrate() {
           vibrate.stop()
           vibrate.scene = 27
           vibrate.start()
        }


// Weather Board Start
		let debug_mode=false;
		let is_window_opened = false
		let normal_weather_board = ''
//		let normal_weather_text = ''
		let init=true;

// Weather Board End

        	

// Autocorrect night weather icons
        const curTime = hmSensor.createSensor(hmSensor.id.TIME);
        let weather_icons = ["Weather-0.png","Weather-1.png","Weather-2.png","Weather-3.png","Weather-4.png","Weather-5.png","Weather-6.png","Weather-.png","Weather-8.png","Weather-9.png","Weather-10.png","Weather-11.png","Weather-.png","Weather-13.png","Weather-14.png","Weather-15.png","Weather-16.png","Weather-17.png","Weather-18.png","Weather-19.png","Weather-20.png","Weather-21.png","Weather-22.png","Weather-23.png","Weather-24.png","Weather-25.png","Weather-0n.png","Weather-1n.png","Weather-3n.png"]
        let weather2_icons = ["Weather2-0.png","Weather2-1.png","Weather2-2.png","Weather2-3.png","Weather2-4.png","Weather2-5.png","Weather2-6.png","Weather2-.png","Weather2-8.png","Weather2-9.png","Weather2-10.png","Weather2-11.png","Weather2-.png","Weather2-13.png","Weather2-14.png","Weather2-15.png","Weather2-16.png","Weather2-17.png","Weather2-18.png","Weather2-19.png","Weather2-20.png","Weather2-21.png","Weather2-22.png","Weather2-23.png","Weather2-24.png","Weather2-25.png","Weather2-0n.png","Weather2-1n.png","Weather2-3n.png"]
        let weather_text_sc	= ["Weather-sc-0.png","Weather-sc-1.png","Weather-sc-2.png","Weather-sc-3.png","Weather-sc-4.png","Weather-sc-5.png","Weather-sc-6.png","Weather-sc-.png","Weather-sc-8.png","Weather-sc-9.png","Weather-sc-10.png","Weather-sc-11.png","Weather-sc-.png","Weather-sc-13.png","Weather-sc-14.png","Weather-sc-15.png","Weather-sc-16.png","Weather-sc-17.png","Weather-sc-18.png","Weather-sc-19.png","Weather-sc-20.png","Weather-sc-21.png","Weather-sc-22.png","Weather-sc-23.png","Weather-sc-24.png","Weather-sc-25.png","Weather-sc-0n.png","Weather-sc-1n.png","Weather-sc-3n.png"]
        let weather_text_tc	= ["Weather-tc-0.png","Weather-tc-1.png","Weather-tc-2.png","Weather-tc-3.png","Weather-tc-4.png","Weather-tc-5.png","Weather-tc-6.png","Weather-tc-.png","Weather-tc-8.png","Weather-tc-9.png","Weather-tc-10.png","Weather-tc-11.png","Weather-tc-.png","Weather-tc-13.png","Weather-tc-14.png","Weather-tc-15.png","Weather-tc-16.png","Weather-tc-17.png","Weather-tc-18.png","Weather-tc-19.png","Weather-tc-20.png","Weather-tc-21.png","Weather-tc-22.png","Weather-tc-23.png","Weather-tc-24.png","Weather-tc-25.png","Weather-tc-0n.png","Weather-tc-1n.png","Weather-tc-3n.png"]
        let weather_text_en = ["Weather-en-0.png","Weather-en-1.png","Weather-en-2.png","Weather-en-3.png","Weather-en-4.png","Weather-en-5.png","Weather-en-6.png","Weather-en-.png","Weather-en-8.png","Weather-en-9.png","Weather-en-10.png","Weather-en-11.png","Weather-en-.png","Weather-en-13.png","Weather-en-14.png","Weather-en-15.png","Weather-en-16.png","Weather-en-17.png","Weather-en-18.png","Weather-en-19.png","Weather-en-20.png","Weather-en-21.png","Weather-en-22.png","Weather-en-23.png","Weather-en-24.png","Weather-en-25.png","Weather-en-0n.png","Weather-en-1n.png","Weather-en-3n.png"]
       
        let weather = hmSensor.createSensor(hmSensor.id.WEATHER);
        let weatherData = weather.getForecastWeather();
        let forecastData = weatherData.forecastData;
        let sunData = weatherData.tideData;
        let today = '';
        let sunriseMins = '';
        let sunsetMins = '';
        let sunriseMins_def = 8 * 60;			// sunrise time
        let sunsetMins_def = 20 * 60;			//and default sunset
        
        let curMins = '';
        
        let isDayIcons = true;
        let wiReplacement = [0, 1, 3, 14];		// icon indexes for day-night replacement
        
        function autoToggleWeatherIcons() {
        
        weatherData = weather.getForecastWeather();
        sunData = weatherData.tideData;
        if (sunData.count > 0){
        today = sunData.data[0];
        sunriseMins = today.sunrise.hour * 60 + today.sunrise.minute;
        sunsetMins = today.sunset.hour * 60 + today.sunset.minute;
        } else {
        sunriseMins = sunriseMins_def;
        sunsetMins = sunsetMins_def;
        }
        
        curMins = curTime.hour * 60 + curTime.minute;
        let isDayNow = (curMins >= sunriseMins) && (curMins < sunsetMins);
        
        if(isDayNow){
        if(!isDayIcons) //Day Picture
		{for (let i = 0; i < wiReplacement.length; i++) {
            weather_icons[wiReplacement[i]] = "Weather-" + wiReplacement[i].toString() + ".png";
          }
          isDayIcons = true;}
		{for (let i = 0; i < wiReplacement.length; i++) {
            weather2_icons[wiReplacement[i]] = "Weather2-" + wiReplacement[i].toString() + ".png";
          }
          isDayIcons = true;}
		{for (let i = 0; i < wiReplacement.length; i++) {
            weather_text_sc[wiReplacement[i]] = "Weather-sc-" + wiReplacement[i].toString() + ".png";
          }
          isDayIcons = true;}
		{for (let i = 0; i < wiReplacement.length; i++) {
            weather_text_tc[wiReplacement[i]] = "Weather-tc-" + wiReplacement[i].toString() + ".png";
          }
          isDayIcons = true;}
		{for (let i = 0; i < wiReplacement.length; i++) {
            weather_text_en[wiReplacement[i]] = "Weather-en-" + wiReplacement[i].toString() + ".png";
          }
          isDayIcons = true;}
		{{
            normal_background_bg_img.setProperty(hmUI.prop.SRC, "BG.png");
          }
          isDayIcons = true;}
		}
		else {
        if(isDayIcons) //Night Picture
		{for (let i = 0; i < wiReplacement.length; i++) {
            weather_icons[wiReplacement[i]] = "Weather-" + wiReplacement[i].toString() + "n.png";
          }
          isDayIcons = false;}
		{for (let i = 0; i < wiReplacement.length; i++) {
            weather2_icons[wiReplacement[i]] = "Weather2-" + wiReplacement[i].toString() + "n.png";
          }
          isDayIcons = false;}
		{for (let i = 0; i < wiReplacement.length; i++) {
            weather_text_sc[wiReplacement[i]] = "Weather-sc-" + wiReplacement[i].toString() + "n.png";
          }
          isDayIcons = false;}
		{for (let i = 0; i < wiReplacement.length; i++) {
            weather_text_tc[wiReplacement[i]] = "Weather-tc-" + wiReplacement[i].toString() + "n.png";
          }
          isDayIcons = false;}
		{for (let i = 0; i < wiReplacement.length; i++) {
            weather_text_en[wiReplacement[i]] = "Weather-en-" + wiReplacement[i].toString() + "n.png";
          }
          isDayIcons = false;}
		{{
            normal_background_bg_img.setProperty(hmUI.prop.SRC, "BG-n.png");
          }
          isDayIcons = false;}
		}
        }
// Autocorrect night weather icons


// Lunar Data Start
	let dateText = null;
    let nongli = null;

    let zodiacs = ['鼠', '牛', '虎', '兔', '龙', '蛇', '马', '羊', '猴', '鸡', '狗', '猪']
    let Gan = ['甲', '乙', '丙', '丁', '戊', '己', '庚', '辛', '壬', '癸']
    let Zhi = ['子', '丑', '寅', '卯', '辰', '巳', '午', '未', '申', '酉', '戌', '亥']
    let weekday = ['星期一', '星期二', '星期三', '星期四', '星期五', '星期六', '星期日']

    let now = null
    let countDownTimer = null
    //用于计算农历年月日的数据
    let GY = 0
    let GM = 0
    let GD = 0

    let year = 0
    let month = 0
    let date = 0
    let hours = 0
    let minutes = 0
    let seconds = 0

    const calendar = {
      gregorianYear: null,          //公历年
      gregorianMonth: null,         //公历月
      gregorianDay: null,           //公历日
      weekday: null,                //星期
      hours: null,
      minutes: null,
      seconds: null,

      lunarYear: null,              //农历年
      lunarMonth: null,             //农历月
      lunarDay: null,               //农历日

      lunarYearCn: '',              //农历天干地支纪年
      lunarMonthCn: '',             //农历中文月
      lunarDayCn: '',               //农历中文日
      zodiacYear: '',               //农历生肖年

      solarTerm: '',                //节气
      gregorianFestival: '',        //公历节日
      lunarFestival: ''             //农历节日
    }

    let lunarInfo = [
      0x04bd8, 0x04ae0, 0x0a570, 0x054d5, 0x0d260, 0x0d950, 0x16554, 0x056a0, 0x09ad0, 0x055d2,
      0x04ae0, 0x0a5b6, 0x0a4d0, 0x0d250, 0x1d255, 0x0b540, 0x0d6a0, 0x0ada2, 0x095b0, 0x14977,
      0x04970, 0x0a4b0, 0x0b4b5, 0x06a50, 0x06d40, 0x1ab54, 0x02b60, 0x09570, 0x052f2, 0x04970,
      0x06566, 0x0d4a0, 0x0ea50, 0x06e95, 0x05ad0, 0x02b60, 0x186e3, 0x092e0, 0x1c8d7, 0x0c950,
      0x0d4a0, 0x1d8a6, 0x0b550, 0x056a0, 0x1a5b4, 0x025d0, 0x092d0, 0x0d2b2, 0x0a950, 0x0b557,
      0x06ca0, 0x0b550, 0x15355, 0x04da0, 0x0a5d0, 0x14573, 0x052d0, 0x0a9a8, 0x0e950, 0x06aa0,
      0x0aea6, 0x0ab50, 0x04b60, 0x0aae4, 0x0a570, 0x05260, 0x0f263, 0x0d950, 0x05b57, 0x056a0,
      0x096d0, 0x04dd5, 0x04ad0, 0x0a4d0, 0x0d4d4, 0x0d250, 0x0d558, 0x0b540, 0x0b5a0, 0x195a6,
      0x095b0, 0x049b0, 0x0a974, 0x0a4b0, 0x0b27a, 0x06a50, 0x06d40, 0x0af46, 0x0ab60, 0x09570,
      0x04af5, 0x04970, 0x064b0, 0x074a3, 0x0ea50, 0x06b58, 0x055c0, 0x0ab60, 0x096d5, 0x092e0,
      0x0c960, 0x0d954, 0x0d4a0, 0x0da50, 0x07552, 0x056a0, 0x0abb7, 0x025d0, 0x092d0, 0x0cab5,
      0x0a950, 0x0b4a0, 0x0baa4, 0x0ad50, 0x055d9, 0x04ba0, 0x0a5b0, 0x15176, 0x052b0, 0x0a930,
      0x07954, 0x06aa0, 0x0ad50, 0x05b52, 0x04b60, 0x0a6e6, 0x0a4e0, 0x0d260, 0x0ea65, 0x0d530,
      0x05aa0, 0x076a3, 0x096d0, 0x04bd7, 0x04ad0, 0x0a4d0, 0x1d0b6, 0x0d250, 0x0d520, 0x0dd45,
      0x0b5a0, 0x056d0, 0x055b2, 0x049b0, 0x0a577, 0x0a4b0, 0x0aa50, 0x1b255, 0x06d20, 0x0ada0]

    /**
    * 阳历节日
    */
    let festival = {
      '1-1': { title: '元旦' },
      '2-2': { title: '世界湿地日' },
      '2-14': { title: '情人节' },
      '3-5': { title: '学雷锋纪念日' },
      '3-8': { title: '三八妇女节' },
      '3-12': { title: '植树节' },
      '3-14': { title: '白色情人节' },
      '3-15': { title: '消费者权益日' },
      '4-1': { title: '愚人节' },
      '4-22': { title: '地球日' },
      '5-1': { title: '国际劳动节' },
      '5-4': { title: '中国青年节' },
//    '5-12': { title: '护士节' },
      '6-1': { title: '国际儿童节' },
      '7-1': { title: '建党节' },
      '8-1': { title: '建军节' },
      '8-19': { title: '中国医师节' },
      '9-3': { title: '抗日纪念日' },
      '9-10': { title: '教师节' },
      '9-30': { title: '烈士纪念日' },
      '10-1': { title: '中国国庆节' },
      '10-31': { title: '万圣前夜' },
      '11-1': { title: '万圣节' },
      '11-8': { title: '中国记者日' },
      '11-9': { title: '消防宣传日' },
      '11-11': { title: '光棍日' },
      '12-13': { title: '国家公祭日' },
      '12-20': { title: '澳门回归' },
      '12-24': { title: '平安夜' },
      '12-25': { title: '圣诞节' }
    }

    /**
    * 农历节日
    */
    let lfestival = {
      //'12-30': { title: '除夕' },
      '1-1': { title: '春节' },
      '1-15': { title: '元宵节' },
      '2-2': { title: '龙抬头' },
      '5-5': { title: '端午节' },
      '7-7': { title: '七夕情人节' },
      '7-15': { title: '中元节' },
      '8-15': { title: '中秋节' },
      '9-9': { title: '重阳节' },
      '12-8': { title: '腊八节' },
      '12-23': { title: '北方小年' },
      '12-24': { title: '南方小年' }
    }

    //母亲节和父亲节、感恩节
    function getMotherOrFatherDay(year, month, day) {
      if (month != 5 && month != 6 && month != 11) return null;
      if ((month == 5 && (day < 8 || day > 14)) || (month == 6 && (day < 15 || day > 21)) || (month == 11 && (day < 22 || day > 28))) return null;
      var d = new Date(year, month - 1, 1, 1, 1, 1, 0)
      var weekDate = (d.getDay() == 0 ? 7 : d.getDay()) - 1;

      switch (month) {
        case 5:
          weekDate = 7 - weekDate;
          if (day == 7 + weekDate) {
            return "母亲节";
          }
          break;
        case 6:
          weekDate = 7 - weekDate;
          if (day == 14 + weekDate) {
            return "父亲节";
          }
          break;
        case 11:
          weekDate = weekDate >= 4 ? (11 - weekDate) : (4 - weekDate)
          if (day == 21 + weekDate) {
            return "感恩节"
          }
          break;
      }
      return null;
    }

    //==== 传入 offset 传回干支, 0=甲子
    function cyclical(num) {
      return (Gan[num % 10] + Zhi[num % 12])
    }

    //==== 传回农历 year年的总天数
    function lYearDays(year) {
      let i, sum = 348
      for (i = 0x8000; i > 0x8; i >>= 1) {
        sum += (lunarInfo[year - 1900] & i) ? 1 : 0
      }
      return (sum + leapDays(year))
    }

    //==== 传回农历 year年闰月的天数
    function leapDays(year) {
      if (leapMonth(year)) {
        return ((lunarInfo[year - 1900] & 0x10000) ? 30 : 29)
      }
      else {
        return 0
      }
    }

    //==== 传回农历 year年闰哪个月 1-12 , 没闰传回 0
    function leapMonth(year) {
      return (lunarInfo[year - 1900] & 0xf)
    }

    //==== 传回农历 year年month月的总天数
    function monthDays(year, month) {
      return ((lunarInfo[year - 1900] & (0x10000 >> month)) ? 30 : 29)
    }

    //==== 算出农历, 传入日期对象, 传回农历日期对象
    //     该对象属性有 农历年year 农历月month 农历日day 是否闰年isLeap yearCyl dayCyl monCyl
    function Lunar(objDate) {
      let i, temp = 0
      let baseDate = new Date(1900, 0, 31)
      let offset = Math.floor((objDate - baseDate) / 86400000)

      let dayCyl = offset + 40
      let monCyl = 14

      for (i = 1900; i < 2050 && offset > 0; i++) {
        temp = lYearDays(i)
        offset -= temp
        monCyl += 12
      }
      if (offset < 0) {
        offset += temp;
        i--;
        monCyl -= 12
      }
      //农历年
      let year = i
      let yearCyl = i - 1864

      let leap = leapMonth(i) //闰哪个月
      let isLeap = false  //是否闰年

      for (i = 1; i < 13 && offset > 0; i++) {
        //闰月
        if (leap > 0 && i === (leap + 1) && isLeap === false) {
          --i; isLeap = true; temp = leapDays(year);
        }
        else {
          temp = monthDays(year, i);
        }

        //解除闰月
        if (isLeap === true && i === (leap + 1)) {
          isLeap = false
        }

        offset -= temp
        if (isLeap === false) {
          monCyl++
        }
      }

      if (offset === 0 && leap > 0 && i === leap + 1)
        if (isLeap) {
          isLeap = false
        }
        else {
          isLeap = true
          --i
          --monCyl
        }

      if (offset < 0) {
        offset += temp
        --i
        --monCyl
      }
      //农历月
      let month = i
      //农历日
      let day = offset + 1
      let dateStr = '' + month + "-" + day
      let holidayTemp = lfestival[dateStr]
      let holiday = holidayTemp ? holidayTemp.title : null
      if (holiday == null && month == 12 && ((temp == 29 && day == 29) || (temp == 30 && day == 30))) {
        holiday = '除夕';
      }

      return {
        year: year,
        month: month,
        day: day,
        isLeap: isLeap,
        leap: leap,
        yearCyl: yearCyl,
        dayCyl: dayCyl,
        monCyl: monCyl,
        holiday: holiday
      }
    }

    //==== 中文日期 m为传入月份，d为传入日期
    function cDay(m, d) {
      let nStrMonth = ['正', '二', '三', '四', '五', '六', '七', '八', '九', '十', '冬', '腊']
      let nStr1 = ['日', '一', '二', '三', '四', '五', '六', '七', '八', '九', '十']
      let nStr2 = ['初', '十', '廿', '卅', '']
      //农历中文月
      let lunarMonthCn
      //农历中文日
      let lunarDayCn

      lunarMonthCn = nStrMonth[m - 1]

      lunarMonthCn += '月'

      switch (d) {
        case 10: lunarDayCn = '初十'; break;
        case 20: lunarDayCn = '二十'; break;
        case 30: lunarDayCn = '三十'; break;
        default: lunarDayCn = nStr2[Math.floor(d / 10)] + nStr1[d % 10]
      }
      return {
        lunarMonthCn: lunarMonthCn,
        lunarDayCn: lunarDayCn
      }
    }

    //节气
    function getSolarTerm() {
      let sTermInfo = [
        0, 21208, 42467, 63836, 85337, 107014,
        128867, 150921, 173149, 195551, 218072, 240693,
        263343, 285989, 308563, 331033, 353350, 375494,
        397447, 419210, 440795, 462224, 483532, 504758
      ]
      let solarTerm = [
        '小寒', '大寒', '立春', '雨水', '惊蛰', '春分',
        '清明', '谷雨', '立夏', '小满', '芒种', '夏至',
        '小暑', '大暑', '立秋', '处暑', '白露', '秋分',
        '寒露', '霜降', '立冬', '小雪', '大雪', '冬至'
      ]

      let solarTerms = ''
      let tmp1 = new Date(
        (31556925974.7 * (GY - 1900) + sTermInfo[GM * 2 + 1] * 60000) + Date.UTC(1900, 0, 6, 2, 5)
      )
      let tmp2 = tmp1.getUTCDate()
      if (tmp2 === GD) solarTerms = solarTerm[GM * 2 + 1]
      tmp1 = new Date(
        (31556925974.7 * (GY - 1900) + sTermInfo[GM * 2] * 60000) + Date.UTC(1900, 0, 6, 2, 5)
      )
      tmp2 = tmp1.getUTCDate()
      if (tmp2 === GD) solarTerms = solarTerm[GM * 2]

      return solarTerms
    }

          now = hmSensor.createSensor(hmSensor.id.TIME);

        function add0(v) {
          if (v < 10) return "0" + v;
          else return v;
        }

        function updateCalendar() {
          if (now == null) {
            now = hmSensor.createSensor(hmSensor.id.TIME)
          }
          //用于计算农历年月日的数据
          GY = now.year
          GM = now.month - 1
          GD = now.day

          year = now.year
          month = now.month - 1 + 1
          date = now.day
          hours = now.hour
          minutes = now.minute
          seconds = now.second
		  
		  if (year != calendar.gregorianYear || month != calendar.gregorianMonth || date != calendar.gregorianDay) {
          let dateStr = '' + month + "-" + date
          let holidayTemp = festival[dateStr]
          let holiday = holidayTemp ? holidayTemp.title : null
          calendar.gregorianFestival = holiday
          if (calendar.gregorianFestival == '' || calendar.gregorianFestival == null) {
            calendar.gregorianFestival = getMotherOrFatherDay(year, month, date)
          }
          // month = month.toString().padStart(2, '0')
          // date = date.toString().padStart(2, '0')
          // hours = hours.toString().padStart(2, '0')
          // minutes = minutes.toString().padStart(2, '0')
          // seconds = seconds.toString().padStart(2, '0')
          //公历年月日、星期、时分秒
          calendar.gregorianYear = year
          calendar.gregorianMonth = month
          calendar.gregorianDay = date
          calendar.weekday = weekday[now.week - 1]
          calendar.hours = hours
          calendar.minutes = minutes
          calendar.seconds = seconds

          //去掉时分秒的日期
          let sDObj = new Date(GY, GM, GD);
          let lDObj = new Lunar(sDObj);

          //农历年月日、生肖年,数字
          calendar.lunarYear = lDObj.year
          calendar.lunarMonth = lDObj.month
          calendar.lunarDay = lDObj.day
          calendar.zodiacYear = zodiacs[(GY - 4) % 12]

          //农历中文年月日
          calendar.lunarYearCn = cyclical(GY - 1900 + 36)
          calendar.lunarMonthCn = cDay(lDObj.month, lDObj.day).lunarMonthCn
          calendar.lunarDayCn = cDay(lDObj.month, lDObj.day).lunarDayCn
          calendar.lunarFestival = lDObj.holiday

          //节气
          calendar.solarTerm = getSolarTerm()
		  if (dateText != null) {
                dateText.setProperty(hmUI.prop.TEXT, " " + add0(now.month) + "月" + add0(now.day) + "日 " + calendar.weekday);
            }
			
          if (nongli != null) {
            var str = "" + calendar.lunarMonthCn + "" + calendar.lunarDayCn + "\n";
            if (calendar.solarTerm != '') {//节气
              str += "" + calendar.solarTerm;
            }
            if (calendar.lunarFestival != null) {//农历节日
              str += " " + calendar.lunarFestival;
            }
            if (calendar.gregorianFestival != null) {//公历节日纪念日
              str += " " + calendar.gregorianFestival;
            }

            nongli.setProperty(hmUI.prop.TEXT, str);
          }
		   
        }
		}
// Lunar Data End


// Click Zona Start
		let btn_zona1 = ''
        let zona1_num = 0
        let zona1_all = 3

		function click_zona1() {
		  zona1_num = (zona1_num + 1) % (zona1_all + 1);
              if (zona1_num == 0) {		  
			normal_weather_text_en_img_level.setProperty(hmUI.prop.VISIBLE, false);
            normal_weather_text_sc_img_level.setProperty(hmUI.prop.VISIBLE, false);
            normal_weather_text_tc_img_level.setProperty(hmUI.prop.VISIBLE, false);
			con_rest = 'Connection Restored';
			con_lost = 'Connection Lost';
			lunar_dply = 'Lunar Display';
			lunar_hide = 'Lunar Hide';
			top_cont = 'Top Contacts';
			rcts_call = 'Recents Call';
			v_memo = 'Voice Memos';
			lcl_msc = 'Local Music';
			phn_msc = 'Phone Music Control';
			find_phn = 'Find My Phone';
			todo = 'To Do';
			comps = 'Compass';
			otm = 'One-tap Measuring';
			wb_text = 'shortcut.png';
			uv_cls = ['UVI-en-1.png','UVI-en-2.png','UVI-en-3.png','UVI-en-4.png','UVI-en-5.png'];
			hPa = 'Number-hPa.png';
			n_m = 'Number-m.png';
			n_ft = 'Number-ft.png';
			wind_dir = ['wind-en_00.png','wind-en_01.png','wind-en_02.png','wind-en_03.png','wind-en_04.png','wind-en_05.png','wind-en_06.png','wind-en_07.png'];
			wind_cls = 'shortcut.png';
		    hmUI.showToast({		  		  
				text: 'None'
            });
          };
           if (zona1_num == 1) {		  
            normal_weather_text_sc_img_level.setProperty(hmUI.prop.VISIBLE, true);
            normal_weather_text_tc_img_level.setProperty(hmUI.prop.VISIBLE, false);
			normal_weather_text_en_img_level.setProperty(hmUI.prop.VISIBLE, false);
			con_rest = '连接恢复';
			con_lost = '连接断开';
			lunar_dply = '显示农历';
			lunar_hide = '隐藏农历';
			top_cont = '常用联系人';
			rcts_call = '最近通话';
			v_memo = '语音备忘录';
			lcl_msc = '手表音乐';
			phn_msc = '手机音乐控制';
			find_phn = '查找手机';
			todo = '待办事项';
			comps = '指南针';
			otm = '一键测量';
			wb_text = 'Today_weather-sc.png';
			uv_cls = ['UVI-sc-1.png','UVI-sc-2.png','UVI-sc-3.png','UVI-sc-4.png','UVI-sc-5.png'];
			hPa = 'Number-sc-hPa.png';
			n_m = 'Number-sc-m.png';
			n_ft = 'Number-sc-ft.png';
			wind_dir = ['wind-sc_00.png','wind-sc_01.png','wind-sc_02.png','wind-sc_03.png','wind-sc_04.png','wind-sc_05.png','wind-sc_06.png','wind-sc_07.png'];
			wind_cls = 'wind-sc_class.png';
		    hmUI.showToast({		  		  
				text: '简体中文'
            });
          };
           if (zona1_num == 2) {		  
            normal_weather_text_sc_img_level.setProperty(hmUI.prop.VISIBLE, false);
            normal_weather_text_tc_img_level.setProperty(hmUI.prop.VISIBLE, true);
			normal_weather_text_en_img_level.setProperty(hmUI.prop.VISIBLE, false);
			con_rest = '連接恢復';
			con_lost = '連接斷開';
			lunar_dply = '顯示農曆';
			lunar_hide = '隱藏農曆';
			top_cont = '常用聯絡人';
			rcts_call = '最近通話';
			v_memo = '語音備忘錄';
			lcl_msc = '手錶音樂';
			phn_msc = '手機音樂控制';
			find_phn = '尋找手機';
			todo = '待辦事項';
			comps = '指南針';
			otm = '一鍵測量';
			wb_text = 'Today_weather-tc.png';
			uv_cls = ['UVI-sc-1.png','UVI-sc-2.png','UVI-sc-3.png','UVI-sc-4.png','UVI-sc-5.png'];
			hPa = 'Number-sc-hPa.png';
			n_m = 'Number-sc-m.png';
			n_ft = 'Number-sc-ft.png';
			wind_dir = ['wind-tc_00.png','wind-tc_01.png','wind-tc_02.png','wind-tc_03.png','wind-tc_04.png','wind-tc_05.png','wind-tc_06.png','wind-tc_07.png'];
			wind_cls = 'wind-sc_class.png';
		    hmUI.showToast({		  		  
				text: '繁體中文'
            });
          };
          if (zona1_num == 3) {
            normal_weather_text_sc_img_level.setProperty(hmUI.prop.VISIBLE, false);
            normal_weather_text_tc_img_level.setProperty(hmUI.prop.VISIBLE, false);
			normal_weather_text_en_img_level.setProperty(hmUI.prop.VISIBLE, true);
			con_rest = 'Connection Restored';
			con_lost = 'Connection Lost';
			lunar_dply = 'Lunar Display';
			lunar_hide = 'Lunar Hide';
			top_cont = 'Top Contacts';
			rcts_call = 'Recents Call';
			v_memo = 'Voice Memos';
			lcl_msc = 'Local Music';
			phn_msc = 'Phone Music Control';
			find_phn = 'Find My Phone';
			todo = 'To Do';
			comps = 'Compass';
			otm = 'One-tap Measuring';
			wb_text = 'shortcut.png';
			uv_cls = ['UVI-en-1.png','UVI-en-2.png','UVI-en-3.png','UVI-en-4.png','UVI-en-5.png'];
			hPa = 'Number-hPa.png';
			n_m = 'Number-m.png';
			n_ft = 'Number-ft.png';
			wind_dir = ['wind-en_00.png','wind-en_01.png','wind-en_02.png','wind-en_03.png','wind-en_04.png','wind-en_05.png','wind-en_06.png','wind-en_07.png'];
			wind_cls = 'shortcut.png';
		    hmUI.showToast({		  		  
				text: 'English'
            });
          };
        }


		let btn_zona2 = ''
        let zona2_num = 0
        let zona2_all = 1
		
		function click_zona2() {
		  zona2_num = (zona2_num + 1) % (zona2_all + 1);
          if (zona2_num == 0) {		
		    normal_masking_img.setProperty(hmUI.prop.VISIBLE, true);
		    nongli.setProperty(hmUI.prop.VISIBLE, true);
		    normal_Icon_YingYang_img.setProperty(hmUI.prop.VISIBLE, false);
		    normal_stress_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
		    hmUI.showToast({
				text: lunar_dply
            });
          };
		  
		 if (zona2_num == 1) {
		    normal_masking_img.setProperty(hmUI.prop.VISIBLE, false);
			nongli.setProperty(hmUI.prop.VISIBLE, false);
		    normal_Icon_YingYang_img.setProperty(hmUI.prop.VISIBLE, true);
		    normal_stress_text_text_img.setProperty(hmUI.prop.VISIBLE, true);
		    hmUI.showToast({
				text: lunar_hide
            });
          };
        }


		
		let btn_zona3 = ''
        let zona3_num = 0
        let zona3_all = 8
		
		function click_zona3() {
	   zona3_num = (zona3_num + 1) % (zona3_all + 1);
       if (zona3_num == 0) {
            normal_Contact_img.setProperty(hmUI.prop.VISIBLE, true);
            normal_Recent_Call_img.setProperty(hmUI.prop.VISIBLE, false);
            normal_Recorder_img.setProperty(hmUI.prop.VISIBLE, false);
            normal_Local_Music_img.setProperty(hmUI.prop.VISIBLE, false);
            normal_Phone_Music_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_Find_Phone_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_Todo_img.setProperty(hmUI.prop.VISIBLE, false);
		   	normal_Compass_img.setProperty(hmUI.prop.VISIBLE, false);
		   	normal_One_Tap_img.setProperty(hmUI.prop.VISIBLE, false);
		    hmUI.showToast({		  		  
				text: top_cont
            });
		  };
		  
	   if (zona3_num == 1) {
		   	normal_Contact_img.setProperty(hmUI.prop.VISIBLE, false);
            normal_Recent_Call_img.setProperty(hmUI.prop.VISIBLE, true);
            normal_Recorder_img.setProperty(hmUI.prop.VISIBLE, false);
            normal_Local_Music_img.setProperty(hmUI.prop.VISIBLE, false);
            normal_Phone_Music_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_Find_Phone_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_Todo_img.setProperty(hmUI.prop.VISIBLE, false);
		   	normal_Compass_img.setProperty(hmUI.prop.VISIBLE, false);
		   	normal_One_Tap_img.setProperty(hmUI.prop.VISIBLE, false);
		    hmUI.showToast({		  		  
				text: rcts_call
            });
		  };

	   if (zona3_num == 2) {
		   	normal_Contact_img.setProperty(hmUI.prop.VISIBLE, false);
            normal_Recent_Call_img.setProperty(hmUI.prop.VISIBLE, false);
            normal_Recorder_img.setProperty(hmUI.prop.VISIBLE, true);
            normal_Local_Music_img.setProperty(hmUI.prop.VISIBLE, false);
            normal_Phone_Music_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_Find_Phone_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_Todo_img.setProperty(hmUI.prop.VISIBLE, false);
		   	normal_Compass_img.setProperty(hmUI.prop.VISIBLE, false);
		   	normal_One_Tap_img.setProperty(hmUI.prop.VISIBLE, false);
		    hmUI.showToast({		  		  
				text: v_memo
            });
		  };

	   if (zona3_num == 3) {
		   	normal_Contact_img.setProperty(hmUI.prop.VISIBLE, false);
            normal_Recent_Call_img.setProperty(hmUI.prop.VISIBLE, false);
            normal_Recorder_img.setProperty(hmUI.prop.VISIBLE, false);
            normal_Local_Music_img.setProperty(hmUI.prop.VISIBLE, true);
            normal_Phone_Music_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_Find_Phone_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_Todo_img.setProperty(hmUI.prop.VISIBLE, false);
		   	normal_Compass_img.setProperty(hmUI.prop.VISIBLE, false);
		   	normal_One_Tap_img.setProperty(hmUI.prop.VISIBLE, false);
		    hmUI.showToast({		  		  
				text: lcl_msc
            });
		  };

	   if (zona3_num == 4) {
		   	normal_Contact_img.setProperty(hmUI.prop.VISIBLE, false);
            normal_Recent_Call_img.setProperty(hmUI.prop.VISIBLE, false);
            normal_Recorder_img.setProperty(hmUI.prop.VISIBLE, false);
            normal_Local_Music_img.setProperty(hmUI.prop.VISIBLE, false);
            normal_Phone_Music_img.setProperty(hmUI.prop.VISIBLE, true);
			normal_Find_Phone_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_Todo_img.setProperty(hmUI.prop.VISIBLE, false);
		   	normal_Compass_img.setProperty(hmUI.prop.VISIBLE, false);
		   	normal_One_Tap_img.setProperty(hmUI.prop.VISIBLE, false);
		    hmUI.showToast({		  		  
				text: phn_msc
            });
		  };

	   if (zona3_num == 5) {
		   	normal_Contact_img.setProperty(hmUI.prop.VISIBLE, false);
            normal_Recent_Call_img.setProperty(hmUI.prop.VISIBLE, false);
            normal_Recorder_img.setProperty(hmUI.prop.VISIBLE, false);
            normal_Local_Music_img.setProperty(hmUI.prop.VISIBLE, false);
            normal_Phone_Music_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_Find_Phone_img.setProperty(hmUI.prop.VISIBLE, true);
			normal_Todo_img.setProperty(hmUI.prop.VISIBLE, false);
		   	normal_Compass_img.setProperty(hmUI.prop.VISIBLE, false);
		   	normal_One_Tap_img.setProperty(hmUI.prop.VISIBLE, false);
		    hmUI.showToast({		  		  
				text: find_phn
            });
		  };

	   if (zona3_num == 6) {
		   	normal_Contact_img.setProperty(hmUI.prop.VISIBLE, false);
            normal_Recent_Call_img.setProperty(hmUI.prop.VISIBLE, false);
            normal_Recorder_img.setProperty(hmUI.prop.VISIBLE, false);
            normal_Local_Music_img.setProperty(hmUI.prop.VISIBLE, false);
            normal_Phone_Music_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_Find_Phone_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_Todo_img.setProperty(hmUI.prop.VISIBLE, true);
		   	normal_Compass_img.setProperty(hmUI.prop.VISIBLE, false);
		   	normal_One_Tap_img.setProperty(hmUI.prop.VISIBLE, false);
		    hmUI.showToast({		  		  
				text: todo
            });
		  };

	   if (zona3_num == 7) {
		   	normal_Contact_img.setProperty(hmUI.prop.VISIBLE, false);
            normal_Recent_Call_img.setProperty(hmUI.prop.VISIBLE, false);
            normal_Recorder_img.setProperty(hmUI.prop.VISIBLE, false);
            normal_Local_Music_img.setProperty(hmUI.prop.VISIBLE, false);
            normal_Phone_Music_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_Find_Phone_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_Todo_img.setProperty(hmUI.prop.VISIBLE, false);
		   	normal_Compass_img.setProperty(hmUI.prop.VISIBLE, true);
		   	normal_One_Tap_img.setProperty(hmUI.prop.VISIBLE, false);
		    hmUI.showToast({		  		  
				text: comps
            });
		  };

	   if (zona3_num == 8) {
		   	normal_Contact_img.setProperty(hmUI.prop.VISIBLE, false);
            normal_Recent_Call_img.setProperty(hmUI.prop.VISIBLE, false);
            normal_Recorder_img.setProperty(hmUI.prop.VISIBLE, false);
            normal_Local_Music_img.setProperty(hmUI.prop.VISIBLE, false);
            normal_Phone_Music_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_Find_Phone_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_Todo_img.setProperty(hmUI.prop.VISIBLE, false);
		   	normal_Compass_img.setProperty(hmUI.prop.VISIBLE, false);
		   	normal_One_Tap_img.setProperty(hmUI.prop.VISIBLE, true);
		    hmUI.showToast({		  		  
				text: otm
            });
		  };
        }
// Click Zona End


//dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
//dynamic modify start
                    
                
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 466,
              h: 466,
              src: 'BG.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sun_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 0,
              y: 0,
              image_array: ["Day-2.png","Day-3.png","Day-4.png","Day-5.png","Day-6.png","Day-7.png","Day-8.png","Day-9.png","Day-10.png","Day-11.png","Day-12.png"],
              image_length: 11,
              type: hmUI.data_type.SUN_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

              autoToggleWeatherIcons();
            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 0,
              y: 0,
              image_array:  weather_icons,
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_weather2_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 10,
              y: 233,
              image_array:  weather2_icons,
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

             normal_weather_text_sc_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 90,
              y: 125,
              image_array:  weather_text_sc,
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_weather_text_tc_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 90,
              y: 125,
              image_array:  weather_text_tc,
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_weather_text_en_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 90,
              y: 125,
              image_array:  weather_text_en,
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_Contact_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 214,
              y: 414,
              src: 'Icon-Contact.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_Recent_Call_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 214,
              y: 414,
              src: 'Icon-Recents_Call.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_Recorder_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 214,
              y: 414,
              src: 'Icon-Recorder.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_Local_Music_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 214,
              y: 414,
              src: 'Icon-Local_Music.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_Phone_Music_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 214,
              y: 414,
              src: 'Icon-Phone_Music.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_Find_Phone_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 214,
              y: 414,
              src: 'Icon-Find_My_Phone.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_Todo_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 214,
              y: 414,
              src: 'Icon-Todo.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_Compass_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 214,
              y: 414,
              src: 'Icon-Compass.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_One_Tap_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 214,
              y: 414,
              src: 'Icon-One_Tap.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_masking_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 210,
              y: 410,
              src: 'Icon-Masking.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

              //农历和节日        
			nongli = hmUI.createWidget(hmUI.widget.TEXT, {
			  x: 148,
			  y: 375,
			  w: 170,//文本容器宽度,文本会居中显示
			  h: 80,//文本容器高度
			  color: 0xFFFFFFFF,
			  text_size: 27,
			  line_space: 0,
			  text: " ",
			  align_h: h.ALIGN.CENTER_H,
			  text_style: hmUI.text_style.WRAP,
			  show_level: hmUI.show_level.ALL,
			});

            normal_Icon_YingYang_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 225,
              y: 380,
              src: 'Icon-YingYang.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_city_name_text = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 10,
              y: 206,
              w: 240,
              h: 40,
              text_size: 27,
              char_space: 0,
              line_space: 0,
              color: 0xFFFFFFFF,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.NONE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_weather_languege_change_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 22,
              y: 110,
              src: 'Icon-Language.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 20, 
              y: 170, 
              font_array: ["Number-0.png","Number-1.png","Number-2.png","Number-3.png","Number-4.png","Number-5.png","Number-6.png","Number-7.png","Number-8.png","Number-9.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'Number-%.png',
              unit_tc: 'Number-%.png',
              unit_en: 'Number-%.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
 
            normal_battery_text_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 1, 
              y: 170, 
              src: 'Logo-BA.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 256,
              y: 231,
              src: 'Bat-lvl-0.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

           normal_battery_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 256,
              y: 231,
              image_array: ["Bat-lvl-1.png","Bat-lvl-2.png","Bat-lvl-3.png","Bat-lvl-4.png","Bat-lvl-5.png","Bat-lvl-6.png","Bat-lvl-7.png","Bat-lvl-8.png","Bat-lvl-9.png","Bat-lvl-10.png"],
              image_length: 10,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 255,
              hour_startY: 85,
              hour_array: ["Time-H1-0.png","Time-H1-1.png","Time-H1-2.png","Time-H1-3.png","Time-H1-4.png","Time-H1-5.png","Time-H1-6.png","Time-H1-7.png","Time-H1-8.png","Time-H1-9.png"],
              hour_zero: 1,
              hour_space: 0,
              hour_align: hmUI.align.RIGHT,

              minute_startX: 255,
              minute_startY: 230,
              minute_array: ["Time-M1-0.png","Time-M1-1.png","Time-M1-2.png","Time-M1-3.png","Time-M1-4.png","Time-M1-5.png","Time-M1-6.png","Time-M1-7.png","Time-M1-8.png","Time-M1-9.png"],
              minute_zero: 1,
              minute_space: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              second_startX: 409,
              second_startY: 235,
              second_array: ["Time-S1-0.png","Time-S1-1.png","Time-S1-2.png","Time-S1-3.png","Time-S1-4.png","Time-S1-5.png","Time-S1-6.png","Time-S1-7.png","Time-S1-8.png","Time-S1-9.png"],
              second_zero: 1,
              second_space: 0,
              second_follow: 0,
              second_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_second_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 250,
              y: 233,
              src: 'Time-Mask.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time_AmPm = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              am_x: 405,
              am_y: 180,
              am_sc_path: 'Time-sc-AM.png',
              am_en_path: 'Time-AM.png',
              pm_x: 405,
              pm_y: 180,
              pm_sc_path: 'Time-sc-PM.png',
              pm_en_path: 'Time-PM.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 260,
              day_startY: 39,
              day_sc_array: ["Time-S1-0.png","Time-S1-1.png","Time-S1-2.png","Time-S1-3.png","Time-S1-4.png","Time-S1-5.png","Time-S1-6.png","Time-S1-7.png","Time-S1-8.png","Time-S1-9.png"],
              day_tc_array: ["Time-S1-0.png","Time-S1-1.png","Time-S1-2.png","Time-S1-3.png","Time-S1-4.png","Time-S1-5.png","Time-S1-6.png","Time-S1-7.png","Time-S1-8.png","Time-S1-9.png"],
              day_en_array: ["Time-S1-0.png","Time-S1-1.png","Time-S1-2.png","Time-S1-3.png","Time-S1-4.png","Time-S1-5.png","Time-S1-6.png","Time-S1-7.png","Time-S1-8.png","Time-S1-9.png"],
              day_zero: 1,
              day_space: 0,
              day_align: hmUI.align.LEFT,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_month_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 312,
              month_startY: 49,
              month_sc_array: ["Month-sc-1.png","Month-sc-2.png","Month-sc-3.png","Month-sc-4.png","Month-sc-5.png","Month-sc-6.png","Month-sc-7.png","Month-sc-8.png","Month-sc-9.png","Month-sc-10.png","Month-sc-11.png","Month-sc-12.png"],
              month_tc_array: ["Month-sc-1.png","Month-sc-2.png","Month-sc-3.png","Month-sc-4.png","Month-sc-5.png","Month-sc-6.png","Month-sc-7.png","Month-sc-8.png","Month-sc-9.png","Month-sc-10.png","Month-sc-11.png","Month-sc-12.png"],
              month_en_array: ["Month-1.png","Month-2.png","Month-3.png","Month-4.png","Month-5.png","Month-6.png","Month-7.png","Month-8.png","Month-9.png","Month-10.png","Month-11.png","Month-12.png"],
              month_is_character: true ,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 225,
              y: 40,
              week_en: ["Week-1.png","Week-2.png","Week-3.png","Week-4.png","Week-5.png","Week-6.png","Week-7.png"],
              week_tc: ["Week-sc-1.png","Week-sc-2.png","Week-sc-3.png","Week-sc-4.png","Week-sc-5.png","Week-sc-6.png","Week-sc-7.png"],
              week_sc: ["Week-sc-1.png","Week-sc-2.png","Week-sc-3.png","Week-sc-4.png","Week-sc-5.png","Week-sc-6.png","Week-sc-7.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_pai_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 180,
              y: 310,
              src: 'pai00.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_pai_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 180,
              y: 310,
              image_array: ["pai01.png","pai02.png","pai03.png","pai04.png","pai05.png","pai06.png","pai07.png","pai08.png","pai09.png","pai10.png"],
              image_length: 10,
              type: hmUI.data_type.PAI_DAILY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_paiw_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 180,
              y: 310,
              image_array: ["PaiW01.png","PaiW02.png","PaiW03.png","PaiW04.png","PaiW05.png","PaiW06.png","PaiW07.png","PaiW08.png","PaiW09.png","PaiW10.png"],
              image_length: 10,
              type: hmUI.data_type.PAI_WEEKLY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_pai_weekly_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 188,
              y: 325,
              font_array: ["Number-0.png","Number-1.png","Number-2.png","Number-3.png","Number-4.png","Number-5.png","Number-6.png","Number-7.png","Number-8.png","Number-9.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.PAI_WEEKLY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 40,
              y: 255,
              font_array: ["Number-0.png","Number-1.png","Number-2.png","Number-3.png","Number-4.png","Number-5.png","Number-6.png","Number-7.png","Number-8.png","Number-9.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 3,
              y: 255,
              src: 'Logo-Step.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_calorie_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 195,
              y: 255,
              font_array: ["Number-0.png","Number-1.png","Number-2.png","Number-3.png","Number-4.png","Number-5.png","Number-6.png","Number-7.png","Number-8.png","Number-9.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_calorie_current_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 160,
              y: 255,
              src: 'Logo-Cal.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_distance_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 55,
              y: 296,
              font_array: ["Number-0.png","Number-1.png","Number-2.png","Number-3.png","Number-4.png","Number-5.png","Number-6.png","Number-7.png","Number-8.png","Number-9.png"],
              padding: false,
              h_space: 0,
              unit_en: 'Number-km.png',
              unit_sc: 'Number-sc-km.png',
              unit_tc: 'Number-sc-km.png',
              imperial_unit_en: 'Number-mi.png',
              imperial_unit_sc: 'Number-sc-mi.png',
              imperial_unit_tc: 'Number-sc-mi.png',
              dot_image: 'Number-..png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.DISTANCE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_distance_text_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 17,
              y: 296,
              src: 'Logo-Distance.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_spo2_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 68,
              y: 337,
              font_array: ["Number-0.png","Number-1.png","Number-2.png","Number-3.png","Number-4.png","Number-5.png","Number-6.png","Number-7.png","Number-8.png","Number-9.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'Number-%.png',
              unit_tc: 'Number-%.png',
              unit_en: 'Number-%.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.SPO2,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_spo2_text_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 35,
              y: 337,
              src: 'Logo-O2.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 100,
              y: 378,
              font_array: ["Number-0.png","Number-1.png","Number-2.png","Number-3.png","Number-4.png","Number-5.png","Number-6.png","Number-7.png","Number-8.png","Number-9.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 67,
              y: 378,
              src: 'Logo-Heart.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_stress_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 155,
              y: 420,
              font_array: ["Number-0.png","Number-1.png","Number-2.png","Number-3.png","Number-4.png","Number-5.png","Number-6.png","Number-7.png","Number-8.png","Number-9.png"],
              padding: false,
              h_space: 0,
              angle: 0,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.STRESS,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_stress_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 120,
              y: 411,
              src: 'Logo-Stress.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

			normal_SLEEP_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 305,
              y: 378,
              w: 60,
              h: 40,
              type: hmUI.data_type.SLEEP,
              font_array: ["Number-0.png","Number-1.png","Number-2.png","Number-3.png","Number-4.png","Number-5.png","Number-6.png","Number-7.png","Number-8.png","Number-9.png"],
              align_h: hmUI.align.RIGHT,
              h_space: 0,
              show_level: hmUI.show_level.ONLY_NORMAL,
              dot_image: "Number-..png", //小数点图片
              padding: true,
              isCharacter: false
           });

            normal_SLEEP_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
				x:365,
				y:378,
				src:"Logo-Sleep.png",
				show_level:hmUI.show_level.ONLY_NORMAL
				}),

            normal_system_lock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 410,
              y: 107,
              src: 'Statuses-Lock.png',
              type: hmUI.system_status.LOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 415,
              y: 145,
              src: 'Statuses-Alarm.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_dnd_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 415,
              y: 286,
              src: 'Statuses-DND.png',
              type: hmUI.system_status.DISTURB,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 410,
              y: 324,
              src: 'Statuses-BlueTooth.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


// Weather Board Start

            function showWeather(){
				if(is_window_opened) return;
				is_window_opened=true;
				normal_weather_board = hmUI.createWidget(hmUI.widget.GROUP, {
				  x: 0,
				  y: 0,
				  w: 466,
				  h: 466,
				});
				
	// clicking "outside the window" closes the window
				normal_weather_board.createWidget(hmUI.widget.BUTTON, {
				  x: 0,
				  y: 0,
				  w: 466,
				  h: 466,
				  text: '',
				  normal_src: 'shortcut.png',
				  press_src: 'shortcut.png',
				  click_func: (button_widget) => {
					normal_weather_board.setProperty(hmUI.prop.VISIBLE, false); 
					hmUI.deleteWidget(normal_weather_board);
					is_window_opened=false;
				  },
				  show_level: hmUI.show_level.ONLY_NORMAL,
				});	

				normal_weather_board.createWidget(hmUI.widget.IMG, {  //New window back groud
				  x: 0,
				  y: 80,
				  src: 'Today_Weather.png',
				  show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_weather_board.createWidget(hmUI.widget.IMG, {  //New window back groud
				  x: 116,
				  y: 91,
				  src: wb_text,
				  show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_weather_board.createWidget(hmUI.widget.BUTTON, {  //Exit new window
				  x: 350,
				  y: 100,
				  w: 50,
				  h: 50,
					text: '',
					normal_src: 'shortcut.png',   
					press_src: 'shortcut.png', 
				  click_func: (button_widget) => {
					normal_weather_board.setProperty(hmUI.prop.VISIBLE, false); 
					hmUI.deleteWidget(normal_weather_board);
					is_window_opened=false;
				  },
				  show_level: hmUI.show_level.ONLY_NORMAL,
				});					

if(!debug_mode){
				normal_weather_board.createWidget(hmUI.widget.IMG_LEVEL, {  //Moon Phase
				  x: 180,
				  y: 245,
				  image_array: ["Moon_01.png","Moon_02.png","Moon_03.png","Moon_04.png","Moon_05.png","Moon_06.png","Moon_07.png","Moon_08.png","Moon_09.png","Moon_10.png","Moon_11.png","Moon_12.png","Moon_13.png","Moon_14.png","Moon_15.png","Moon_16.png","Moon_17.png","Moon_18.png","Moon_19.png","Moon_20.png","Moon_21.png","Moon_22.png","Moon_23.png","Moon_24.png","Moon_25.png","Moon_26.png","Moon_27.png","Moon_28.png","Moon_29.png","Moon_30.png"],
				  image_length: 30,
				  type: hmUI.data_type.MOON,
				  show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_weather_board.createWidget(hmUI.widget.IMG, {  //Clouds for Moon Phase
				  x: 150,
				  y: 265,
				  src: 'Moon_Clouds.png',
				  show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_weather_board.createWidget(hmUI.widget.IMG, {  //UVI icon
				  x: 35,
				  y: 175,
				  src: 'Icon-UVI.png',
				  show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_weather_board.createWidget(hmUI.widget.IMG_LEVEL, {  //UV Index Level
				  x: 90,
				  y: 175,
				  image_array: uv_cls,
				  image_length: 5,
				  type: hmUI.data_type.UVI,
				  show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_weather_board.createWidget(hmUI.widget.IMG, {  //Huminity icon
				  x: 35,
				  y: 213,
				  src: 'Icon-Humidity.png',
				  show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_weather_board.createWidget(hmUI.widget.TEXT_IMG, {  //Humidity
				  x: 90,
				  y: 213,
				  font_array: ["Number-0.png","Number-1.png","Number-2.png","Number-3.png","Number-4.png","Number-5.png","Number-6.png","Number-7.png","Number-8.png","Number-9.png"],
				  padding: false,
				  h_space: 0,
				  unit_en: 'Number-%.png',
				  unit_sc: 'Number-%.png',
				  unit_tc: 'Number-%.png',
 				  align_h: hmUI.align.LEFT,
				  type: hmUI.data_type.HUMIDITY,
				  show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_weather_board.createWidget(hmUI.widget.IMG, {  //AQI icon
				  x: 35,
				  y: 251,
				  src: 'Icon-AQI.png',
				  show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_weather_board.createWidget(hmUI.widget.TEXT_IMG, {  //AQI Index
				  x: 90,
				  y: 251,
				  font_array: ["Number-0.png","Number-1.png","Number-2.png","Number-3.png","Number-4.png","Number-5.png","Number-6.png","Number-7.png","Number-8.png","Number-9.png"],
				  padding: false,
				  h_space: 0,
				  invalid_image: 'Number---.png',
				  align_h: hmUI.align.LEFT,
				  type: hmUI.data_type.AQI,
				  show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_weather_board.createWidget(hmUI.widget.IMG, {  //Air Sea Level
				  x: 35,
				  y: 289,
				  src: 'Icon-Altitude.png',
				  show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_weather_board.createWidget(hmUI.widget.TEXT_IMG, {  //Altitude
				  x: 90,
				  y: 289,
				  font_array: ["Number-0.png","Number-1.png","Number-2.png","Number-3.png","Number-4.png","Number-5.png","Number-6.png","Number-7.png","Number-8.png","Number-9.png"],
				  padding: false,
				  h_space: 0,
				  unit_en: n_m,
				  unit_sc: n_m,
				  unit_tc: n_m,
				  imperial_unit_en: n_ft,
				  imperial_unit_sc: n_ft,
				  imperial_unit_tc: n_ft,
 				  align_h: hmUI.align.LEFT,
				  type: hmUI.data_type.ALTITUDE,
				  show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_weather_board.createWidget(hmUI.widget.IMG, {  //Air Preasure icon
				  x: 35,
				  y: 327,
				  src: 'Icon-Barometer.png',
				  show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_weather_board.createWidget(hmUI.widget.TEXT_IMG, {  //Altimeter
				  x: 90,
				  y: 327,
				  font_array: ["Number-0.png","Number-1.png","Number-2.png","Number-3.png","Number-4.png","Number-5.png","Number-6.png","Number-7.png","Number-8.png","Number-9.png"],
				  padding: false,
				  h_space: 0,
				  unit_en: hPa,
				  unit_sc: hPa,
				  unit_tc: hPa,
 				  align_h: hmUI.align.LEFT,
				  type: hmUI.data_type.ALTIMETER,
				  show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_weather_board.createWidget(hmUI.widget.IMG, {  //Wind icon
				  x: 90,
				  y: 365,
				  src: 'Icon-Wind.png',
				  show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_weather_board.createWidget(hmUI.widget.TEXT_IMG, {  //Wind
				  x: 145,
				  y: 365,
				  font_array: ["Number-0.png","Number-1.png","Number-2.png","Number-3.png","Number-4.png","Number-5.png","Number-6.png","Number-7.png","Number-8.png","Number-9.png"],
				  padding: false,
				  h_space: 0,
				  unit_sc: wind_cls,
				  unit_tc: wind_cls,
				  unit_en: wind_cls,
				  align_h: hmUI.align.CENTER_H,
				  type: hmUI.data_type.WIND,
				  show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_weather_board.createWidget(hmUI.widget.IMG_LEVEL, {  //Wind-Direction
				  x: 195,
				  y: 365,
				  image_array: wind_dir,
				  image_length: 8,
				  type: hmUI.data_type.WIND_DIRECTION,
				  show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_weather_board.createWidget(hmUI.widget.IMG, {  //Thermometer icon
				  x: 405,
				  y: 170,
				  src: 'Thermometer.png',
				  show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_weather_board.createWidget(hmUI.widget.TEXT_IMG, {  //Weather Current
				  x: 185,
				  y: 185,
				  font_array: ["Temp-0.png","Temp-1.png","Temp-2.png","Temp-3.png","Temp-4.png","Temp-5.png","Temp-6.png","Temp-7.png","Temp-8.png","Temp-9.png"],
				  padding: false,
				  h_space: 0,
				  unit_en: 'Temp-C.png',
				  unit_sc: 'Temp-C.png',
				  unit_tc: 'Temp-C.png',
				  imperial_unit_en: 'Temp-F.png',
				  imperial_unit_sc: 'Temp-F.png',
				  imperial_unit_tc: 'Temp-F.png',
				  negative_image: 'Temp--.png',
				  invalid_image: 'Temp---.png',
 				  align_h: hmUI.align.RIGHT,
				  type: hmUI.data_type.WEATHER_CURRENT,
				  show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_weather_board.createWidget(hmUI.widget.TEXT_IMG, {  //Weather Max
				  x: 342,
				  y: 180,
				  font_array: ["Number-0.png","Number-1.png","Number-2.png","Number-3.png","Number-4.png","Number-5.png","Number-6.png","Number-7.png","Number-8.png","Number-9.png"],
				  padding: false,
				  h_space: 0,
				  unit_en: 'Temp.png',
				  unit_sc: 'Temp.png',
				  unit_tc: 'Temp.png',
				  negative_image: 'Number--.png',
				  invalid_image: 'Number---.png',
 				  align_h: hmUI.align.RIGHT,
				  type: hmUI.data_type.WEATHER_HIGH,
				  show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_weather_board.createWidget(hmUI.widget.TEXT_IMG, {  //Weather Min
				  x: 342,
				  y: 225,
				  font_array: ["Number-0.png","Number-1.png","Number-2.png","Number-3.png","Number-4.png","Number-5.png","Number-6.png","Number-7.png","Number-8.png","Number-9.png"],
				  padding: false,
				  h_space: 0,
				  unit_en: 'Temp.png',
				  unit_sc: 'Temp.png',
				  unit_tc: 'Temp.png',
				  negative_image: 'Number--.png',
				  invalid_image: 'Number---.png',
 				  align_h: hmUI.align.RIGHT,
				  type: hmUI.data_type.WEATHER_LOW,
				  show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_weather_board.createWidget(hmUI.widget.IMG, {  //Sunrise icon
				  x: 262,
				  y: 265,
				  src: 'Icon-Sunrise.png',
				  show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_weather_board.createWidget(hmUI.widget.TEXT_IMG, {  //Sunrise
				  x: 245,
				  y: 322,
				  font_array: ["Number-0.png","Number-1.png","Number-2.png","Number-3.png","Number-4.png","Number-5.png","Number-6.png","Number-7.png","Number-8.png","Number-9.png"],
				  padding: false,
				  h_space: 0,
				  invalid_image: 'Number---.png',
				  dot_image: 'Number-...png',
 				  align_h: hmUI.align.CENTER_H,
				  type: hmUI.data_type.SUN_RISE,
				  show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_weather_board.createWidget(hmUI.widget.IMG, {  //Sunset icon
				  x: 352,
				  y: 265,
				  src: 'Icon-Sunset.png',
				  show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_weather_board.createWidget(hmUI.widget.TEXT_IMG, {  //Sunset Current
				  x: 335,
				  y: 322,
				  font_array: ["Number-0.png","Number-1.png","Number-2.png","Number-3.png","Number-4.png","Number-5.png","Number-6.png","Number-7.png","Number-8.png","Number-9.png"],
				  padding: false,
				  h_space: 0,
				  invalid_image: 'Number---.png',
				  dot_image: 'Number-...png',
 				  align_h: hmUI.align.CENTER_H,
				  type: hmUI.data_type.SUN_SET,
				  show_level: hmUI.show_level.ONLY_NORMAL,
				});
				}
 

 // Shortcut in weather Board to Altimeter & Air Temperature
				normal_weather_board.createWidget(hmUI.widget.IMG_CLICK, {
				  x: 35,
				  y: 175,
				  w: 385,
				  h: 110,
				  src: 'shortcut.png',
				  type: hmUI.data_type.WEATHER_CURRENT,
				  show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_weather_board.createWidget(hmUI.widget.IMG_CLICK, {
				  x: 35,
				  y: 285,
				  w: 190,
				  h: 80,
				  src: 'shortcut.png',
				  type: hmUI.data_type.ALTIMETER,
				  show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_weather_board.createWidget(hmUI.widget.IMG_CLICK, {
				  x: 230,
				  y: 265,
				  w: 190,
				  h: 100,
				  src: 'shortcut.png',
				  type: hmUI.data_type.SUN_CURRENT,
				  show_level: hmUI.show_level.ONLY_NORMAL,
				});

				
				const weatherSensor = hmSensor.createSensor(hmSensor.id.WEATHER);
                const weatherData = weatherSensor.getForecastWeather();
//				normal_city2_name_text.setProperty(hmUI.prop.TEXT, weatherData.cityName);
				const { forecastData, tideData } = weatherData;
				if(forecastData.count>0){
					const { index, high, low } = forecastData.data[0];
//				normal_weather_text.setProperty(hmUI.prop.TEXT, weather_text[index]);
				}

			}
// Weather Board end

		
// Long Press Start
		let longPress_Timer = null;
	    let longPressDelay = 700;
		
		function getLongPress1() {
		    if(longPress_Timer) timer.stopTimer(longPress_Timer);
			
			let url;

			switch(zona3_num) {
			   case 0:
					url = 'PhoneContactsScreen';
				break;
			   case 1:
					url = 'PhoneRecentCallScreen';
				break;
			   case 2:
					url = 'VoiceMemoScreen';
				break;
			   case 3:
					url = 'LocalMusicScreen';
				break;
			   case 4:
					url = 'PhoneMusicCtrlScreen';
				break;
			   case 5:
					url = 'FindPhoneScreen';
				break;
			   case 6:
					url = 'todoListScreen';
				break;
			   case 7:
					url = 'CompassScreen';
				break;
			   case 8:
					url = 'oneKeyAppScreen';
				break;
			   default:
				break;
			}
			hmApp.startApp({ url: url, native: true });
	    }

// Long Press End


// Zona ShortCut Start
            btn_zona1 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 22, 
              y: 110, 
              text: '',
              w: 52, 
              h: 52, 
              normal_src: 'shortcut.png',
              press_src: 'shortcut.png',
              click_func: () => {
                click_zona1();
                click_Vibrate();
              },
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            btn_zona1.setProperty(hmUI.prop.VISIBLE, true);
			normal_weather_text_en_img_level.setProperty(hmUI.prop.VISIBLE, true);
			normal_weather_text_sc_img_level.setProperty(hmUI.prop.VISIBLE, false);
			normal_weather_text_tc_img_level.setProperty(hmUI.prop.VISIBLE, false);


            btn_zona2 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 175, 
              y: 373, 
              text: '',
              w: 120, 
              h: 40, 
              normal_src: 'shortcut.png',
              press_src: 'shortcut.png',
               click_func: () => {
                click_zona2();
                click_Vibrate();
              },
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            btn_zona2.setProperty(hmUI.prop.VISIBLE, true);
		    normal_masking_img.setProperty(hmUI.prop.VISIBLE, false);
			nongli.setProperty(hmUI.prop.VISIBLE, false);
            normal_Icon_YingYang_img.setProperty(hmUI.prop.VISIBLE, true);
            normal_stress_text_text_img.setProperty(hmUI.prop.VISIBLE, true);


            btn_zona3 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 175, 
              y: 413, 
              text: '',
              w: 120, 
              h: 53, 
              normal_src: 'shortcut.png',
              press_src: 'shortcut.png',
              click_func: () => {
                click_zona3();
                click_Vibrate();
              },
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            btn_zona3.setProperty(hmUI.prop.VISIBLE, true);
			normal_Contact_img.setProperty(hmUI.prop.VISIBLE, true);
			normal_Recent_Call_img.setProperty(hmUI.prop.VISIBLE, false);
            normal_Recorder_img.setProperty(hmUI.prop.VISIBLE, false);
            normal_Local_Music_img.setProperty(hmUI.prop.VISIBLE, false);
            normal_Phone_Music_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_Find_Phone_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_Todo_img.setProperty(hmUI.prop.VISIBLE, false);
		   	normal_Compass_img.setProperty(hmUI.prop.VISIBLE, false);
		   	normal_One_Tap_img.setProperty(hmUI.prop.VISIBLE, false);
			
			btn_zona3.addEventListener(hmUI.event.CLICK_DOWN, function () {
					if(longPress_Timer) timer.stopTimer(longPress_Timer);
					longPress_Timer = timer.createTimer(longPressDelay, 0, getLongPress1, {});
			});
			btn_zona3.addEventListener(hmUI.event.CLICK_UP, function () {
					if(longPress_Timer) timer.stopTimer(longPress_Timer);
			});
// Zona ShortCut End


// disconnectAlert = hmUI.createWidget(hmUI.widget.DisconnectAlert, {
// disconneсnt_vibrate_type: 27,(0=Medium,9=Long,25=Short,27=Long Continuous),
// disconneсnt_toast_text: Bluetooth OFF,
// conneсnt_vibrate_type: 9,
// conneсnt_toast_text: Bluetooth ON,
// });

// vibration when connecting or disconnecting

            function checkConnection() {
              hmBle.removeListener;
              hmBle.addListener(function (status) {
                if(!status) {
                  hmUI.showToast({text: con_lost});
                  vibro(9);
                }
                if(status) {
                  hmUI.showToast({text: con_rest});
                  vibro(9);
                }
              });
            }

// end vibration when connecting or disconnecting

// vibrate function
            const vibrate = hmSensor.createSensor(hmSensor.id.VIBRATE);
            let timer_StopVibrate = null;


            function vibro(scene = 25) {
              let stopDelay = 50;
              stopVibro();
              vibrate.stop();
              vibrate.scene = scene;
              if(scene < 23 || scene > 25) stopDelay = 1300;
              vibrate.start();
              timer_StopVibrate = timer.createTimer(stopDelay, 3000, stopVibro, {});
            }

            function stopVibro(){
              vibrate.stop();
              if(timer_StopVibrate) timer.stopTimer(timer_StopVibrate);
            }

// end vibrate function
 

//Shortcut Jumpable start
 
//Battery Shortcut            
            hmUI.createWidget(hmUI.widget.BUTTON, {
             x: 0,
             y: 165,
             w: 90,
             h: 45,
			 text: '',    
			 normal_src: 'shortcut.png',   
			 press_src: 'shortcut.png', 
			 click_func: () => {
				hmApp.startApp({ url: 'LowBatteryScreen', native: true });
				},
				show_level: hmUI.show_level.ONLY_NORMAL,
			});


//Sport List Shortcut            
            hmUI.createWidget(hmUI.widget.BUTTON, {
			 x: 88,
			 y: 20,  
			 w: 135,     
			 h: 80,     
			 text: '',    
			 normal_src: 'shortcut.png',   
			 press_src: 'shortcut.png', 
			 click_func: () => {
				vibro();
				hmApp.startApp({ url: 'SportListScreen', native: true });
				},
				longpress_func: () => {
				},
				show_level: hmUI.show_level.ONLY_NORMAL,
			});

//Current weather board Shortcut
            hmUI.createWidget(hmUI.widget.BUTTON, {
             x: 88,
             y: 120,
             w: 140,
             h: 90,
			 text: '',
			 normal_src: 'shortcut.png',
			 press_src: 'shortcut.png',
			 click_func: () => {
				showWeather();
				},
				show_level: hmUI.show_level.ONLY_NORMAL,
            });			

//World Clock Shortcut            
            hmUI.createWidget(hmUI.widget.BUTTON, {
			 x: 0,
			 y: 210,  
			 w: 250,     
			 h: 42,     
			 text: '',    
			 normal_src: 'shortcut.png',   
			 press_src: 'shortcut.png', 
			 click_func: () => {
				hmApp.startApp({ url: 'WorldClockScreen', native: true });
				},
				show_level: hmUI.show_level.ONLY_NORMAL,
			});

            normal_step_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
             x: 0,
             y: 252,
             w: 250,
             h: 41,
             src: 'shortcut.png',
             type: hmUI.data_type.STEP,
             show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_training_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
             x: 0,
             y: 293,
             w: 170,
             h: 41,
             src: 'shortcut.png',
             type: hmUI.data_type.TRAINING_LOAD,
             show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_spo2_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
             x: 0,
             y: 334,
             w: 170,
             h: 41,
             src: 'shortcut.png',
             type: hmUI.data_type.SPO2,
             show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
             x: 0,
             y: 375,
             w: 170,
             h: 41,
             src: 'shortcut.png',
             type: hmUI.data_type.HEART,
             show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_pai_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
             x: 178,
             y: 306,
             w: 70,
             h: 70,
             src: 'shortcut.png',
             type: hmUI.data_type.PAI_WEEKLY,
             show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_stress_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
             x: 0,
             y: 416,
             w: 180,
             h: 50,
             src: 'shortcut.png',
             type: hmUI.data_type.STRESS,
             show_level: hmUI.show_level.ONLY_NORMAL,
            });

//Workout History Shortcut
            hmUI.createWidget(hmUI.widget.BUTTON, {
			 x: 222,
			 y: 35,  
			 w: 40,     
			 h: 175,     
			 text: '',    
			 normal_src: 'shortcut.png',   
			 press_src: 'shortcut.png', 
			 click_func: () => {
				hmApp.startApp({ url: 'SportRecordListScreen', native: true });
				},
				show_level: hmUI.show_level.ONLY_NORMAL,
			});

//Calendar Shortcut
            hmUI.createWidget(hmUI.widget.BUTTON, {
             x: 260,
             y: 35,
             w: 145,
             h: 50,
			 text: '',    
			 normal_src: 'shortcut.png',   
			 press_src: 'shortcut.png', 
			 click_func: () => {
				hmApp.startApp({ url: 'ScheduleCalScreen', native: true });
				},
				show_level: hmUI.show_level.ONLY_NORMAL,
			});

            normal_alarm_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
             x: 265,
             y: 90,
             w: 135,
             h: 140,
             src: 'shortcut.png',
             type: hmUI.data_type.ALARM_CLOCK,
             show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_countdown_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
             x: 265,
             y: 230,
             w: 135,
             h: 140,
             src: 'shortcut.png',
             type: hmUI.data_type.COUNT_DOWN,
             show_level: hmUI.show_level.ONLY_NORMAL,
            });

//Calendar Shortcut
            hmUI.createWidget(hmUI.widget.BUTTON, {
             x: 405,
             y: 140,
             w: 100,
             h: 90,
			 text: '',    
			 normal_src: 'shortcut.png',   
			 press_src: 'shortcut.png', 
			 click_func: () => {
				hmApp.startApp({ url: 'TomatoMainScreen', native: true });
				},
				show_level: hmUI.show_level.ONLY_NORMAL,
			});

            normal_stopwatch_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
             x: 405,
             y: 230,
             w: 100,
             h: 90,
             src: 'shortcut.png',
             type: hmUI.data_type.STOP_WATCH,
             show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sleep_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
             x: 300,
             y: 372,
             w: 110,
             h: 80,
             src: 'shortcut.png',
             type: hmUI.data_type.SLEEP,
             show_level: hmUI.show_level.ONLY_NORMAL,
            });

//Shortcut Jumpable end

//AOD Screen Start
            idle_battery_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 82,
              y: 50,
              src: 'Bat-lvl-AOD-0.png',
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_battery_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 82,
              y: 50,
              image_array: ["Bat-lvl-AOD-1.png","Bat-lvl-AOD-2.png","Bat-lvl-AOD-3.png","Bat-lvl-AOD-4.png","Bat-lvl-AOD-5.png","Bat-lvl-AOD-6.png","Bat-lvl-AOD-7.png","Bat-lvl-AOD-8.png","Bat-lvl-AOD-9.png","Bat-lvl-AOD-10.png"],
              image_length: 10,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 203,
              y: 50,
              font_array: ["BA0.png","BA1.png","BA2.png","BA3.png","BA4.png","BA5.png","BA6.png","BA7.png","BA8.png","BA9.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'AOD-BA%.png',
              unit_tc: 'AOD-BA%.png',
              unit_en: 'AOD-BA%.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_battery_text_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 143,
              y: 50,
              src: 'AOD-BA.png',
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_digital_clock_img_time_AmPm = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              am_x: 328,
              am_y: 175,
              am_sc_path: 'AOD-sc-AM.png',
              am_en_path: 'AOD-AM.png',
              pm_x: 328,
              pm_y: 175,
              pm_sc_path: 'AOD-sc-PM.png',
              pm_en_path: 'AOD-PM.png',
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 82,
              hour_startY: 91,
              hour_array: ["AOD-H0.png","AOD-H1.png","AOD-H2.png","AOD-H3.png","AOD-H4.png","AOD-H5.png","AOD-H6.png","AOD-H7.png","AOD-H8.png","AOD-H9.png"],
              hour_zero: 1,
              hour_space: 0,
              hour_align: hmUI.align.LEFT,

              minute_startX: 235,
              minute_startY: 240,
              minute_array: ["AOD-M0.png","AOD-M1.png","AOD-M2.png","AOD-M3.png","AOD-M4.png","AOD-M5.png","AOD-M6.png","AOD-M7.png","AOD-M8.png","AOD-M9.png"],
              minute_zero: 1,
              minute_space: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 77,
              day_startY: 280,
              day_sc_array: ["AOD-Number-0.png","AOD-Number-1.png","AOD-Number-2.png","AOD-Number-3.png","AOD-Number-4.png","AOD-Number-5.png","AOD-Number-6.png","AOD-Number-7.png","AOD-Number-8.png","AOD-Number-9.png"],
              day_tc_array: ["AOD-Number-0.png","AOD-Number-1.png","AOD-Number-2.png","AOD-Number-3.png","AOD-Number-4.png","AOD-Number-5.png","AOD-Number-6.png","AOD-Number-7.png","AOD-Number-8.png","AOD-Number-9.png"],
              day_en_array: ["AOD-Number-0.png","AOD-Number-1.png","AOD-Number-2.png","AOD-Number-3.png","AOD-Number-4.png","AOD-Number-5.png","AOD-Number-6.png","AOD-Number-7.png","AOD-Number-8.png","AOD-Number-9.png"],
              day_zero: 1,
              day_space: 0,
              day_align: hmUI.align.LEFT,
              day_is_character: false,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_date_img_date_month_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 130,
              month_startY: 280,
              month_sc_array: ["AOD-Month-sc-1.png","AOD-Month-sc-2.png","AOD-Month-sc-3.png","AOD-Month-sc-4.png","AOD-Month-sc-5.png","AOD-Month-sc-6.png","AOD-Month-sc-7.png","AOD-Month-sc-8.png","AOD-Month-sc-9.png","AOD-Month-sc-10.png","AOD-Month-sc-11.png","AOD-Month-sc-12.png"],
              month_tc_array: ["AOD-Month-sc-1.png","AOD-Month-sc-2.png","AOD-Month-sc-3.png","AOD-Month-sc-4.png","AOD-Month-sc-5.png","AOD-Month-sc-6.png","AOD-Month-sc-7.png","AOD-Month-sc-8.png","AOD-Month-sc-9.png","AOD-Month-sc-10.png","AOD-Month-sc-11.png","AOD-Month-sc-12.png"],
              month_en_array: ["AOD-Month-1.png","AOD-Month-2.png","AOD-Month-3.png","AOD-Month-4.png","AOD-Month-5.png","AOD-Month-6.png","AOD-Month-7.png","AOD-Month-8.png","AOD-Month-9.png","AOD-Month-10.png","AOD-Month-11.png","AOD-Month-12.png"],
              month_is_character: true ,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 48,
              y: 320,
              week_en: ["AOD-Week-1.png","AOD-Week-2.png","AOD-Week-3.png","AOD-Week-4.png","AOD-Week-5.png","AOD-Week-6.png","AOD-Week-7.png"],
              week_tc: ["AOD-Week-sc-1.png","AOD-Week-sc-2.png","AOD-Week-sc-3.png","AOD-Week-sc-4.png","AOD-Week-sc-5.png","AOD-Week-sc-6.png","AOD-Week-sc-7.png"],
              week_sc: ["AOD-Week-sc-1.png","AOD-Week-sc-2.png","AOD-Week-sc-3.png","AOD-Week-sc-4.png","AOD-Week-sc-5.png","AOD-Week-sc-6.png","AOD-Week-sc-7.png"],
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_masking_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 158,
              y: 374,
              src: 'Lunar_Masking.png',
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 250,
              y: 370,
              font_array: ["AOD-Number-0.png","AOD-Number-1.png","AOD-Number-2.png","AOD-Number-3.png","AOD-Number-4.png","AOD-Number-5.png","AOD-Number-6.png","AOD-Number-7.png","AOD-Number-8.png","AOD-Number-9.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'AOD-Step.png',
              unit_tc: 'AOD-Step.png',
              unit_en: 'AOD-Step.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 100,
              y: 370,
              font_array: ["AOD-Number-0.png","AOD-Number-1.png","AOD-Number-2.png","AOD-Number-3.png","AOD-Number-4.png","AOD-Number-5.png","AOD-Number-6.png","AOD-Number-7.png","AOD-Number-8.png","AOD-Number-9.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'AOD-Heart.png',
              unit_tc: 'AOD-Heart.png',
              unit_en: 'AOD-Heart.png',
              invalid_image: 'Number---.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 345,
              y: 90,
              src: 'AOD-Statuses-BlueTooth.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

//AOD Screen End


            function scale_call() {

              console.log('Wearther city name');
              const weatherSensor = hmSensor.createSensor(hmSensor.id.WEATHER);
              const weatherData = weatherSensor.getForecastWeather();
              normal_city_name_text.setProperty(hmUI.prop.TEXT, weatherData.cityName);

            };
		

            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                scale_call();
				autoToggleWeatherIcons(); //NightWeatherIcon
				updateCalendar() //Lunar Calendar
                checkConnection(); // DisconnectAlert
                stopVibro(); // DisconnectAlert
				if(typeof normal_weather_board !== 'string') // Windows Weather Board
					hmUI.deleteWidget(normal_weather_board); // Windows Weather Board
				is_window_opened=false; // Windows Weather Board
              }),
               pause_call: (function () { // DisconnectAlert
                stopVibro(); // DisconnectAlert

              }),
            });

                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}		
