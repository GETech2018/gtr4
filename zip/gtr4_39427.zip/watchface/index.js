﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        const logger = Logger.getLogger('watchface_SashaCX75');
        //end of ignored block

        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_temperature_current_text_img = ''
        let normal_weather_image_progress_img_level = ''
        let normal_battery_text_text_img = ''
        let normal_battery_image_progress_img_level = ''
        let normal_heart_rate_text_text_img = ''
        let normal_step_current_text_img = ''
        let normal_date_img_date_week_img = ''
        let normal_date_img_date_month_img = ''
        let normal_date_img_date_day = ''
        let normal_digital_clock_img_time = ''
        let idle_digital_clock_img_time = ''
        let Button_1 = ''
        let Button_2 = ''
        let Button_3 = ''
        let Button_4 = ''
        let Button_5 = ''
        let Button_6 = ''
        let Button_7 = ''
        let Button_8 = ''


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            console.log('Watch_Face.ScreenNormal');
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 466,
              h: 466,
              src: '0001.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 40,
              y: 212,
              font_array: ["data_0001.png","data_0002.png","data_0003.png","data_0004.png","data_0005.png","data_0006.png","data_0007.png","data_0008.png","data_0009.png","data_0010.png"],
              padding: false,
              h_space: -7,
              unit_sc: 'data_0013.png',
              unit_tc: 'data_0013.png',
              unit_en: 'data_0013.png',
              negative_image: 'data_0011.png',
              invalid_image: 'data_0014.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 144,
              y: 205,
              image_array: ["weather_0001.png","weather_0002.png","weather_0003.png","weather_0004.png","weather_0005.png","weather_0006.png","weather_0007.png","weather_0008.png","weather_0009.png","weather_0010.png","weather_0011.png","weather_0012.png","weather_0013.png","weather_0014.png","weather_0015.png","weather_0016.png","weather_0017.png","weather_0018.png","weather_0019.png","weather_0020.png","weather_0021.png","weather_0022.png","weather_0023.png","weather_0024.png","weather_0025.png","weather_0026.png","weather_0027.png","weather_0028.png","weather_0029.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 49,
              y: 292,
              font_array: ["data_0001.png","data_0002.png","data_0003.png","data_0004.png","data_0005.png","data_0006.png","data_0007.png","data_0008.png","data_0009.png","data_0010.png"],
              padding: false,
              h_space: -7,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 83,
              y: 370,
              image_array: ["bat_0001.png","bat_0002.png","bat_0003.png","bat_0004.png","bat_0005.png"],
              image_length: 5,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 49,
              y: 130,
              font_array: ["data_0001.png","data_0002.png","data_0003.png","data_0004.png","data_0005.png","data_0006.png","data_0007.png","data_0008.png","data_0009.png","data_0010.png"],
              padding: false,
              h_space: -7,
              invalid_image: 'data_0014.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 80,
              y: 63,
              font_array: ["sec_0001.png","sec_0002.png","sec_0003.png","sec_0004.png","sec_0005.png","sec_0006.png","sec_0007.png","sec_0008.png","sec_0009.png","sec_0010.png"],
              padding: false,
              h_space: -5,
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 386,
              y: 122,
              week_en: ["week_0001.png","week_0002.png","week_0003.png","week_0004.png","week_0005.png","week_0006.png","week_0007.png"],
              week_tc: ["week_0001.png","week_0002.png","week_0003.png","week_0004.png","week_0005.png","week_0006.png","week_0007.png"],
              week_sc: ["week_0001.png","week_0002.png","week_0003.png","week_0004.png","week_0005.png","week_0006.png","week_0007.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_month_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 384,
              month_startY: 210,
              month_sc_array: ["mont_0001.png","mont_0002.png","mont_0003.png","mont_0004.png","mont_0005.png","mont_0006.png","mont_0007.png","mont_0008.png","mont_0009.png","mont_0010.png","mont_0011.png","mont_0012.png"],
              month_tc_array: ["mont_0001.png","mont_0002.png","mont_0003.png","mont_0004.png","mont_0005.png","mont_0006.png","mont_0007.png","mont_0008.png","mont_0009.png","mont_0010.png","mont_0011.png","mont_0012.png"],
              month_en_array: ["mont_0001.png","mont_0002.png","mont_0003.png","mont_0004.png","mont_0005.png","mont_0006.png","mont_0007.png","mont_0008.png","mont_0009.png","mont_0010.png","mont_0011.png","mont_0012.png"],
              month_is_character: true ,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 390,
              day_startY: 160,
              day_sc_array: ["date_0001.png","date_0002.png","date_0003.png","date_0004.png","date_0005.png","date_0006.png","date_0007.png","date_0008.png","date_0009.png","date_0010.png"],
              day_tc_array: ["date_0001.png","date_0002.png","date_0003.png","date_0004.png","date_0005.png","date_0006.png","date_0007.png","date_0008.png","date_0009.png","date_0010.png"],
              day_en_array: ["date_0001.png","date_0002.png","date_0003.png","date_0004.png","date_0005.png","date_0006.png","date_0007.png","date_0008.png","date_0009.png","date_0010.png"],
              day_zero: 1,
              day_space: -5,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 242,
              hour_startY: 111,
              hour_array: ["clock_0001.png","clock_0002.png","clock_0003.png","clock_0004.png","clock_0005.png","clock_0006.png","clock_0007.png","clock_0008.png","clock_0009.png","clock_0010.png"],
              hour_zero: 1,
              hour_space: -18,
              hour_angle: 0,
              hour_align: hmUI.align.LEFT,

              minute_startX: 242,
              minute_startY: 238,
              minute_array: ["clock_0001.png","clock_0002.png","clock_0003.png","clock_0004.png","clock_0005.png","clock_0006.png","clock_0007.png","clock_0008.png","clock_0009.png","clock_0010.png"],
              minute_zero: 1,
              minute_space: -18,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              second_startX: 259,
              second_startY: 367,
              second_array: ["sec_0001.png","sec_0002.png","sec_0003.png","sec_0004.png","sec_0005.png","sec_0006.png","sec_0007.png","sec_0008.png","sec_0009.png","sec_0010.png"],
              second_zero: 1,
              second_space: -5,
              second_angle: 0,
              second_follow: 0,
              second_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            console.log('Watch_Face.ScreenAOD');

            idle_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 242,
              hour_startY: 122,
              hour_array: ["aod_0001.png","aod_0002.png","aod_0003.png","aod_0004.png","aod_0005.png","aod_0006.png","aod_0007.png","aod_0008.png","aod_0009.png","aod_0010.png"],
              hour_zero: 1,
              hour_space: -15,
              hour_angle: 0,
              hour_align: hmUI.align.LEFT,

              minute_startX: 242,
              minute_startY: 231,
              minute_array: ["aod_0001.png","aod_0002.png","aod_0003.png","aod_0004.png","aod_0005.png","aod_0006.png","aod_0007.png","aod_0008.png","aod_0009.png","aod_0010.png"],
              minute_zero: 1,
              minute_space: -15,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_AOD,
            });
            
            // disconnectAlert = hmUI.createWidget(hmUI.widget.DisconnectAlert, {
              // disconneсnt_vibrate_type: 9,
              // disconneсnt_toast_text: Связь потеряна,
            // });

            // vibration when connecting or disconnecting

            function checkConnection() {
              console.log('checkConnection()');
              hmBle.removeListener;
              hmBle.addListener(function (status) {
                if(!status) {
                  hmUI.showToast({text: "Связь потеряна"});
                  vibro(9);
                }
              });
            }

            // end vibration when connecting or disconnecting
            // vibrate function

            const vibrate = hmSensor.createSensor(hmSensor.id.VIBRATE);
            let timer_StopVibrate = null;


            function vibro(scene = 25) {
              let stopDelay = 50;
              stopVibro();
              vibrate.stop();
              vibrate.scene = scene;
              if(scene < 23 || scene > 25) stopDelay = 1300;
              vibrate.start();
              if (scene != 1) timer_StopVibrate = timer.createTimer(stopDelay, 3000, stopVibro, {});
            }

            function stopVibro(){
              vibrate.stop();
              if(timer_StopVibrate) timer.stopTimer(timer_StopVibrate);
            }

            // end vibrate function

            console.log('Watch_Face.Buttons');
            Button_1 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 43,
              y: 282,
              w: 165,
              h: 70,
              text: '',
              color: 0xFFFF8C00,
              text_size: 24,
              press_src: 'null.png',
              normal_src: 'null.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'PowerSaveHintScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_2 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 43,
              y: 199,
              w: 165,
              h: 70,
              text: '',
              color: 0xFFFF8C00,
              text_size: 24,
              press_src: 'null.png',
              normal_src: 'null.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'WeatherScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_3 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 243,
              y: 367,
              w: 73,
              h: 49,
              text: '',
              color: 0xFFFF8C00,
              text_size: 24,
              press_src: 'null.png',
              normal_src: 'null.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'StopWatchScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_4 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 43,
              y: 54,
              w: 165,
              h: 49,
              text: '',
              color: 0xFFFF8C00,
              text_size: 24,
              press_src: 'null.png',
              normal_src: 'null.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'activityAppScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_5 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 243,
              y: 244,
              w: 121,
              h: 108,
              text: '',
              color: 0xFFFF8C00,
              text_size: 24,
              press_src: 'null.png',
              normal_src: 'null.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'CountdownAppScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_6 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 381,
              y: 122,
              w: 81,
              h: 122,
              text: '',
              color: 0xFFFF8C00,
              text_size: 24,
              press_src: 'null.png',
              normal_src: 'null.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'ScheduleCalScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_7 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 243,
              y: 117,
              w: 121,
              h: 108,
              text: '',
              color: 0xFFFF8C00,
              text_size: 24,
              press_src: 'null.png',
              normal_src: 'null.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'AlarmInfoScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_8 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 43,
              y: 117,
              w: 165,
              h: 70,
              text: '',
              color: 0xFFFF8C00,
              text_size: 24,
              press_src: 'null.png',
              normal_src: 'null.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'heart_app_Screen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                console.log('resume_call()');
                checkConnection();
                stopVibro();

              }),
              pause_call: (function () {
                console.log('pause_call()');
                stopVibro();

              }),
            });

                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}