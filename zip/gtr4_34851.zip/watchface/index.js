﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        const logger = Logger.getLogger('watchface_SashaCX75');
        //end of ignored block

        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_system_lock_img = ''
        let normal_system_dnd_img = ''
        let normal_system_disconnect_img = ''
        let normal_system_clock_img = ''
        let normal_battery_text_text_img = ''
        let normal_moon_image_progress_img_level = ''
        let normal_sun_current_text_img = ''
        let normal_temperature_current_text_img = ''
        let normal_weather_image_progress_img_level = ''
        let normal_pai_weekly_text_img = ''
        let normal_heart_rate_text_text_img = ''
        let normal_calorie_current_text_img = ''
        let normal_step_current_text_img = ''
        let normal_step_image_progress_img_level = ''
        let normal_date_img_date_week_img = ''
        let normal_date_img_date_day = ''
        let normal_digital_clock_img_time_AmPm = ''
        let normal_digital_clock_img_time = ''
        let idle_background_bg_img = ''
        let idle_system_lock_img = ''
        let idle_system_dnd_img = ''
        let idle_system_disconnect_img = ''
        let idle_system_clock_img = ''
        let idle_battery_text_text_img = ''
        let idle_moon_image_progress_img_level = ''
        let idle_sun_current_text_img = ''
        let idle_temperature_current_text_img = ''
        let idle_weather_image_progress_img_level = ''
        let idle_pai_weekly_text_img = ''
        let idle_heart_rate_text_text_img = ''
        let idle_calorie_current_text_img = ''
        let idle_step_current_text_img = ''
        let idle_date_img_date_week_img = ''
        let idle_date_img_date_day = ''
        let idle_digital_clock_img_time_AmPm = ''
        let idle_digital_clock_img_time = ''
        let normal_sleep_jumpable_img_click = ''
        let normal_alarm_jumpable_img_click = ''
        let normal_sunrise_jumpable_img_click = ''
        let normal_altimeter_jumpable_img_click = ''
        let normal_temperature_jumpable_img_click = ''
        let normal_pai_jumpable_img_click = ''
        let normal_spo2_jumpable_img_click = ''
        let normal_heart_jumpable_img_click = ''
        let normal_step_jumpable_img_click = ''


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 466,
              h: 466,
              src: 'bg.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_lock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 115,
              y: 158,
              src: 'lock.png',
              type: hmUI.system_status.LOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_dnd_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 115,
              y: 126,
              src: 'dnd.png',
              type: hmUI.system_status.DISTURB,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 115,
              y: 60,
              src: 'bt.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 115,
              y: 94,
              src: 'alarm.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 330,
              y: 331,
              font_array: ["font_activ_0.png","font_activ_1.png","font_activ_2.png","font_activ_3.png","font_activ_4.png","font_activ_5.png","font_activ_6.png","font_activ_7.png","font_activ_8.png","font_activ_9.png"],
              padding: false,
              h_space: 2,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_moon_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 102,
              y: 352,
              image_array: ["Moon_1.png","Moon_2.png","Moon_3.png","Moon_4.png","Moon_5.png","Moon_6.png","Moon_7.png","Moon_8.png","Moon_9.png","Moon_10.png","Moon_11.png","Moon_12.png","Moon_13.png","Moon_14.png","Moon_15.png","Moon_16.png","Moon_17.png","Moon_18.png","Moon_19.png","Moon_20.png","Moon_21.png","Moon_22.png","Moon_23.png","Moon_24.png","Moon_25.png","Moon_26.png","Moon_27.png","Moon_28.png","Moon_29.png","Moon_30.png"],
              image_length: 30,
              type: hmUI.data_type.MOON,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sun_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 63,
              y: 301,
              font_array: ["font_activ_0.png","font_activ_1.png","font_activ_2.png","font_activ_3.png","font_activ_4.png","font_activ_5.png","font_activ_6.png","font_activ_7.png","font_activ_8.png","font_activ_9.png"],
              padding: false,
              h_space: 2,
              invalid_image: 'dot_1.png',
              dot_image: 'pointer_0.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.SUN_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 61,
              y: 241,
              font_array: ["font_activ_0.png","font_activ_1.png","font_activ_2.png","font_activ_3.png","font_activ_4.png","font_activ_5.png","font_activ_6.png","font_activ_7.png","font_activ_8.png","font_activ_9.png"],
              padding: false,
              h_space: 1,
              unit_sc: 'pointer_2.png',
              unit_tc: 'pointer_2.png',
              unit_en: 'pointer_2.png',
              negative_image: 'pointer_1.png',
              invalid_image: 'dot_1.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 69,
              y: 198,
              image_array: ["weather_1.png","weather_2.png","weather_3.png","weather_4.png","weather_5.png","weather_6.png","weather_7.png","weather_8.png","weather_9.png","weather_10.png","weather_11.png","weather_12.png","weather_13.png","weather_14.png","weather_15.png","weather_16.png","weather_17.png","weather_18.png","weather_19.png","weather_20.png","weather_21.png","weather_22.png","weather_23.png","weather_24.png","weather_25.png","weather_26.png","weather_27.png","weather_28.png","weather_29.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_pai_weekly_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 329,
              y: 110,
              font_array: ["font_activ_0.png","font_activ_1.png","font_activ_2.png","font_activ_3.png","font_activ_4.png","font_activ_5.png","font_activ_6.png","font_activ_7.png","font_activ_8.png","font_activ_9.png"],
              padding: false,
              h_space: 2,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.PAI_WEEKLY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 362,
              y: 273,
              font_array: ["font_activ_0.png","font_activ_1.png","font_activ_2.png","font_activ_3.png","font_activ_4.png","font_activ_5.png","font_activ_6.png","font_activ_7.png","font_activ_8.png","font_activ_9.png"],
              padding: false,
              h_space: 2,
              invalid_image: 'dot_1.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_calorie_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 348,
              y: 165,
              font_array: ["font_activ_0.png","font_activ_1.png","font_activ_2.png","font_activ_3.png","font_activ_4.png","font_activ_5.png","font_activ_6.png","font_activ_7.png","font_activ_8.png","font_activ_9.png"],
              padding: false,
              h_space: 2,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 366,
              y: 220,
              font_array: ["font_activ_0.png","font_activ_1.png","font_activ_2.png","font_activ_3.png","font_activ_4.png","font_activ_5.png","font_activ_6.png","font_activ_7.png","font_activ_8.png","font_activ_9.png"],
              padding: false,
              h_space: 4,
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 8,
              y: 8,
              image_array: ["img_step_1.png","img_step_2.png","img_step_3.png","img_step_4.png","img_step_5.png","img_step_6.png","img_step_7.png","img_step_8.png","img_step_9.png","img_step_10.png","img_step_11.png","img_step_12.png","img_step_13.png","img_step_14.png","img_step_15.png","img_step_16.png","img_step_17.png"],
              image_length: 17,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 186,
              y: 48,
              week_en: ["day_1.png","day_2.png","day_3.png","day_4.png","day_5.png","day_6.png","day_7.png"],
              week_tc: ["day_1.png","day_2.png","day_3.png","day_4.png","day_5.png","day_6.png","day_7.png"],
              week_sc: ["day_1.png","day_2.png","day_3.png","day_4.png","day_5.png","day_6.png","day_7.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 212,
              day_startY: 79,
              day_sc_array: ["font_day_0.png","font_day_1.png","font_day_2.png","font_day_3.png","font_day_4.png","font_day_5.png","font_day_6.png","font_day_7.png","font_day_8.png","font_day_9.png"],
              day_tc_array: ["font_day_0.png","font_day_1.png","font_day_2.png","font_day_3.png","font_day_4.png","font_day_5.png","font_day_6.png","font_day_7.png","font_day_8.png","font_day_9.png"],
              day_en_array: ["font_day_0.png","font_day_1.png","font_day_2.png","font_day_3.png","font_day_4.png","font_day_5.png","font_day_6.png","font_day_7.png","font_day_8.png","font_day_9.png"],
              day_zero: 0,
              day_space: 0,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time_AmPm = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              am_x: 178,
              am_y: 377,
              am_sc_path: 'am.png',
              am_en_path: 'am.png',
              pm_x: 262,
              pm_y: 377,
              pm_sc_path: 'pm.png',
              pm_en_path: 'pm.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 176,
              hour_startY: 155,
              hour_array: ["font_time_0.png","font_time_1.png","font_time_2.png","font_time_3.png","font_time_4.png","font_time_5.png","font_time_6.png","font_time_7.png","font_time_8.png","font_time_9.png"],
              hour_zero: 0,
              hour_space: 2,
              hour_angle: 0,
              hour_align: hmUI.align.CENTER_H,

              minute_startX: 176,
              minute_startY: 265,
              minute_array: ["font_time_min_0.png","font_time_min_1.png","font_time_min_2.png","font_time_min_3.png","font_time_min_4.png","font_time_min_5.png","font_time_min_6.png","font_time_min_7.png","font_time_min_8.png","font_time_min_9.png"],
              minute_zero: 1,
              minute_space: 4,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              second_startX: 211,
              second_startY: 384,
              second_array: ["font_day_0.png","font_day_1.png","font_day_2.png","font_day_3.png","font_day_4.png","font_day_5.png","font_day_6.png","font_day_7.png","font_day_8.png","font_day_9.png"],
              second_zero: 1,
              second_space: 2,
              second_angle: 0,
              second_follow: 0,
              second_align: hmUI.align.CENTER_H,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            idle_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 466,
              h: 466,
              src: 'aod.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_system_lock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 115,
              y: 158,
              src: 'lock.png',
              type: hmUI.system_status.LOCK,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_system_dnd_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 115,
              y: 126,
              src: 'dnd.png',
              type: hmUI.system_status.DISTURB,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 115,
              y: 60,
              src: 'bt.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 115,
              y: 94,
              src: 'alarm.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 330,
              y: 331,
              font_array: ["font_activ_0.png","font_activ_1.png","font_activ_2.png","font_activ_3.png","font_activ_4.png","font_activ_5.png","font_activ_6.png","font_activ_7.png","font_activ_8.png","font_activ_9.png"],
              padding: false,
              h_space: 2,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_moon_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 102,
              y: 352,
              image_array: ["Moon_1.png","Moon_2.png","Moon_3.png","Moon_4.png","Moon_5.png","Moon_6.png","Moon_7.png","Moon_8.png","Moon_9.png","Moon_10.png","Moon_11.png","Moon_12.png","Moon_13.png","Moon_14.png","Moon_15.png","Moon_16.png","Moon_17.png","Moon_18.png","Moon_19.png","Moon_20.png","Moon_21.png","Moon_22.png","Moon_23.png","Moon_24.png","Moon_25.png","Moon_26.png","Moon_27.png","Moon_28.png","Moon_29.png","Moon_30.png"],
              image_length: 30,
              type: hmUI.data_type.MOON,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_sun_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 63,
              y: 301,
              font_array: ["font_activ_0.png","font_activ_1.png","font_activ_2.png","font_activ_3.png","font_activ_4.png","font_activ_5.png","font_activ_6.png","font_activ_7.png","font_activ_8.png","font_activ_9.png"],
              padding: false,
              h_space: 2,
              invalid_image: 'dot_1.png',
              dot_image: 'pointer_0.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.SUN_CURRENT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 61,
              y: 241,
              font_array: ["font_activ_0.png","font_activ_1.png","font_activ_2.png","font_activ_3.png","font_activ_4.png","font_activ_5.png","font_activ_6.png","font_activ_7.png","font_activ_8.png","font_activ_9.png"],
              padding: false,
              h_space: 1,
              unit_sc: 'pointer_2.png',
              unit_tc: 'pointer_2.png',
              unit_en: 'pointer_2.png',
              negative_image: 'pointer_1.png',
              invalid_image: 'dot_1.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 69,
              y: 198,
              image_array: ["weather_1.png","weather_2.png","weather_3.png","weather_4.png","weather_5.png","weather_6.png","weather_7.png","weather_8.png","weather_9.png","weather_10.png","weather_11.png","weather_12.png","weather_13.png","weather_14.png","weather_15.png","weather_16.png","weather_17.png","weather_18.png","weather_19.png","weather_20.png","weather_21.png","weather_22.png","weather_23.png","weather_24.png","weather_25.png","weather_26.png","weather_27.png","weather_28.png","weather_29.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_pai_weekly_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 329,
              y: 110,
              font_array: ["font_activ_0.png","font_activ_1.png","font_activ_2.png","font_activ_3.png","font_activ_4.png","font_activ_5.png","font_activ_6.png","font_activ_7.png","font_activ_8.png","font_activ_9.png"],
              padding: false,
              h_space: 2,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.PAI_WEEKLY,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 362,
              y: 273,
              font_array: ["font_activ_0.png","font_activ_1.png","font_activ_2.png","font_activ_3.png","font_activ_4.png","font_activ_5.png","font_activ_6.png","font_activ_7.png","font_activ_8.png","font_activ_9.png"],
              padding: false,
              h_space: 2,
              invalid_image: 'dot_1.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_calorie_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 348,
              y: 165,
              font_array: ["font_activ_0.png","font_activ_1.png","font_activ_2.png","font_activ_3.png","font_activ_4.png","font_activ_5.png","font_activ_6.png","font_activ_7.png","font_activ_8.png","font_activ_9.png"],
              padding: false,
              h_space: 2,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 366,
              y: 220,
              font_array: ["font_activ_0.png","font_activ_1.png","font_activ_2.png","font_activ_3.png","font_activ_4.png","font_activ_5.png","font_activ_6.png","font_activ_7.png","font_activ_8.png","font_activ_9.png"],
              padding: false,
              h_space: 4,
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 186,
              y: 48,
              week_en: ["day_1.png","day_2.png","day_3.png","day_4.png","day_5.png","day_6.png","day_7.png"],
              week_tc: ["day_1.png","day_2.png","day_3.png","day_4.png","day_5.png","day_6.png","day_7.png"],
              week_sc: ["day_1.png","day_2.png","day_3.png","day_4.png","day_5.png","day_6.png","day_7.png"],
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 212,
              day_startY: 79,
              day_sc_array: ["font_day_0.png","font_day_1.png","font_day_2.png","font_day_3.png","font_day_4.png","font_day_5.png","font_day_6.png","font_day_7.png","font_day_8.png","font_day_9.png"],
              day_tc_array: ["font_day_0.png","font_day_1.png","font_day_2.png","font_day_3.png","font_day_4.png","font_day_5.png","font_day_6.png","font_day_7.png","font_day_8.png","font_day_9.png"],
              day_en_array: ["font_day_0.png","font_day_1.png","font_day_2.png","font_day_3.png","font_day_4.png","font_day_5.png","font_day_6.png","font_day_7.png","font_day_8.png","font_day_9.png"],
              day_zero: 0,
              day_space: 0,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time_AmPm = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              am_x: 178,
              am_y: 377,
              am_sc_path: 'am.png',
              am_en_path: 'am.png',
              pm_x: 262,
              pm_y: 377,
              pm_sc_path: 'pm.png',
              pm_en_path: 'pm.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 176,
              hour_startY: 155,
              hour_array: ["font_time_0.png","font_time_1.png","font_time_2.png","font_time_3.png","font_time_4.png","font_time_5.png","font_time_6.png","font_time_7.png","font_time_8.png","font_time_9.png"],
              hour_zero: 0,
              hour_space: 2,
              hour_angle: 0,
              hour_align: hmUI.align.CENTER_H,

              minute_startX: 176,
              minute_startY: 265,
              minute_array: ["font_time_min_0.png","font_time_min_1.png","font_time_min_2.png","font_time_min_3.png","font_time_min_4.png","font_time_min_5.png","font_time_min_6.png","font_time_min_7.png","font_time_min_8.png","font_time_min_9.png"],
              minute_zero: 1,
              minute_space: 4,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              second_startX: 211,
              second_startY: 384,
              second_array: ["font_day_0.png","font_day_1.png","font_day_2.png","font_day_3.png","font_day_4.png","font_day_5.png","font_day_6.png","font_day_7.png","font_day_8.png","font_day_9.png"],
              second_zero: 1,
              second_space: 2,
              second_angle: 0,
              second_follow: 0,
              second_align: hmUI.align.CENTER_H,

              show_level: hmUI.show_level.ONLY_AOD,
            });

            normal_sleep_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 261,
              y: 370,
              w: 29,
              h: 29,
              src: 'dot.png',
              type: hmUI.data_type.SLEEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_alarm_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 177,
              y: 370,
              w: 29,
              h: 29,
              src: 'dot.png',
              type: hmUI.data_type.ALARM_CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sunrise_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 50,
              y: 295,
              w: 104,
              h: 32,
              src: 'dot.png',
              type: hmUI.data_type.SUN_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_altimeter_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 99,
              y: 350,
              w: 39,
              h: 39,
              src: 'dot.png',
              type: hmUI.data_type.ALTIMETER,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 45,
              y: 191,
              w: 86,
              h: 86,
              src: 'dot.png',
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_pai_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 320,
              y: 70,
              w: 69,
              h: 69,
              src: 'dot.png',
              type: hmUI.data_type.PAI_WEEKLY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_spo2_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 322,
              y: 160,
              w: 97,
              h: 29,
              src: 'dot.png',
              type: hmUI.data_type.SPO2,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 322,
              y: 270,
              w: 97,
              h: 29,
              src: 'dot.png',
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 324,
              y: 215,
              w: 137,
              h: 33,
              src: 'dot.png',
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}