﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        const logger = Logger.getLogger('watchface_SashaCX75');
        //end of ignored block

        //dynamic modify start

        
        console.log('user_functions.js');
        // start user_functions.js
let colorNumber = 1
let totalColors = 6
let colorName = ''


function click_color() {

    if(colorNumber >= totalColors) {
        colorNumber = 1;
    }
    else {
        colorNumber = colorNumber + 1;
    }


    //*** Toast with text / Toast con texto ***
    if ( colorNumber == 1) { colorName = "Original"}
    if ( colorNumber > 1)  { colorName = "Varinta_" + parseInt(colorNumber - 1)}
    hmUI.showToast({text: colorName });


    //*** Toast with text and index / Toast con texto e indice ***
    //hmUI.showToast({text: "Color " + parseInt(colorNumber) });


    //*** Toast with index / Toast con indice ***
	//hmUI.showToast({text: "" + parseInt(colorNumber) });


    normal_background_bg_img.setProperty(hmUI.prop.SRC, "bg" + parseInt(colorNumber) + ".png");
         
    }
        // end user_functions.js

        let normal_background_bg_img = ''
        let normal_system_lock_img = ''
        let normal_system_disconnect_img = ''
        let normal_system_clock_img = ''
        let normal_sun_high_text_img = ''
        let normal_sun_low_text_img = ''
        let normal_distance_text_text_img = ''
        let normal_spo2_text_text_img = ''
        let normal_date_img_date_year = ''
        let normal_date_img_date_month = ''
        let normal_date_img_date_day = ''
        let normal_date_img_date_week_img = ''
        let normal_heart_rate_text_text_img = ''
        let normal_temperature_current_text_img = ''
        let normal_weather_image_progress_img_level = ''
        let normal_battery_circle_scale = ''
        let normal_battery_text_text_img = ''
        let normal_calorie_circle_scale = ''
        let normal_calorie_current_text_img = ''
        let normal_step_current_text_img = ''
        let normal_moon_image_progress_img_level = ''
        let normal_digital_clock_img_time_AmPm = ''
        let normal_digital_clock_img_time = ''
        let idle_background_bg = ''
        let idle_system_lock_img = ''
        let idle_system_disconnect_img = ''
        let idle_system_clock_img = ''
        let idle_date_img_date_year = ''
        let idle_date_img_date_month = ''
        let idle_date_img_date_day = ''
        let idle_date_img_date_week_img = ''
        let idle_temperature_current_text_img = ''
        let idle_weather_image_progress_img_level = ''
        let idle_digital_clock_img_time_AmPm = ''
        let idle_digital_clock_img_time = ''
        let normal_alarm_jumpable_img_click = ''
        let normal_sunrise_jumpable_img_click = ''
        let normal_altimeter_jumpable_img_click = ''
        let normal_temperature_jumpable_img_click = ''
        let normal_pai_jumpable_img_click = ''
        let normal_spo2_jumpable_img_click = ''
        let normal_heart_jumpable_img_click = ''
        let normal_step_jumpable_img_click = ''
        let Button_1 = ''
        let Button_2 = ''
        let Button_3 = ''
        let Button_4 = ''


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            console.log('Watch_Face.ScreenNormal');
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 466,
              h: 466,
              src: 'bg1.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_lock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 219,
              y: 440,
              src: 'bloque8.png',
              type: hmUI.system_status.LOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 175,
              y: 215,
              src: 'BT8.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 140,
              y: 213,
              src: '0228.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sun_high_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 172,
              y: 42,
              font_array: ["p_0.png","p_1.png","p_2.png","p_3.png","p_4.png","p_5.png","p_6.png","p_7.png","p_8.png","p_9.png"],
              padding: false,
              h_space: 0,
              dot_image: 'c_point.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.SUN_RISE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sun_low_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 189,
              y: 8,
              font_array: ["p_0.png","p_1.png","p_2.png","p_3.png","p_4.png","p_5.png","p_6.png","p_7.png","p_8.png","p_9.png"],
              padding: false,
              h_space: 0,
              dot_image: 'c_point.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.SUN_SET,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_distance_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 242,
              y: 357,
              font_array: ["m_0.png","m_1.png","m_2.png","m_3.png","m_4.png","m_5.png","m_6.png","m_7.png","m_8.png","m_9.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'Km.png',
              unit_tc: 'Km.png',
              unit_en: 'Km.png',
              dot_image: 'c_point1.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.DISTANCE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_spo2_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 263,
              y: 299,
              font_array: ["m_0.png","m_1.png","m_2.png","m_3.png","m_4.png","m_5.png","m_6.png","m_7.png","m_8.png","m_9.png"],
              padding: false,
              h_space: -2,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.SPO2,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_year = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              year_startX: 360,
              year_startY: 173,
              year_sc_array: ["p_0.png","p_1.png","p_2.png","p_3.png","p_4.png","p_5.png","p_6.png","p_7.png","p_8.png","p_9.png"],
              year_tc_array: ["p_0.png","p_1.png","p_2.png","p_3.png","p_4.png","p_5.png","p_6.png","p_7.png","p_8.png","p_9.png"],
              year_en_array: ["p_0.png","p_1.png","p_2.png","p_3.png","p_4.png","p_5.png","p_6.png","p_7.png","p_8.png","p_9.png"],
              year_zero: 1,
              year_space: 0,
              year_align: hmUI.align.LEFT,
              year_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_month = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 315,
              month_startY: 173,
              month_sc_array: ["p_0.png","p_1.png","p_2.png","p_3.png","p_4.png","p_5.png","p_6.png","p_7.png","p_8.png","p_9.png"],
              month_tc_array: ["p_0.png","p_1.png","p_2.png","p_3.png","p_4.png","p_5.png","p_6.png","p_7.png","p_8.png","p_9.png"],
              month_en_array: ["p_0.png","p_1.png","p_2.png","p_3.png","p_4.png","p_5.png","p_6.png","p_7.png","p_8.png","p_9.png"],
              month_zero: 1,
              month_space: 0,
              month_unit_sc: 'c_point.png',
              month_unit_tc: 'c_point.png',
              month_unit_en: 'c_point.png',
              month_align: hmUI.align.LEFT,
              month_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 266,
              day_startY: 173,
              day_sc_array: ["p_0.png","p_1.png","p_2.png","p_3.png","p_4.png","p_5.png","p_6.png","p_7.png","p_8.png","p_9.png"],
              day_tc_array: ["p_0.png","p_1.png","p_2.png","p_3.png","p_4.png","p_5.png","p_6.png","p_7.png","p_8.png","p_9.png"],
              day_en_array: ["p_0.png","p_1.png","p_2.png","p_3.png","p_4.png","p_5.png","p_6.png","p_7.png","p_8.png","p_9.png"],
              day_zero: 1,
              day_space: 0,
              day_unit_sc: 'c_point.png',
              day_unit_tc: 'c_point.png',
              day_unit_en: 'c_point.png',
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 199,
              y: 80,
              week_en: ["day_1.png","day_2.png","day_3.png","day_4.png","day_5.png","day_6.png","day_7.png"],
              week_tc: ["day_1.png","day_2.png","day_3.png","day_4.png","day_5.png","day_6.png","day_7.png"],
              week_sc: ["day_1.png","day_2.png","day_3.png","day_4.png","day_5.png","day_6.png","day_7.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 331,
              y: 299,
              font_array: ["m_0.png","m_1.png","m_2.png","m_3.png","m_4.png","m_5.png","m_6.png","m_7.png","m_8.png","m_9.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 224,
              y: 126,
              font_array: ["m_0.png","m_1.png","m_2.png","m_3.png","m_4.png","m_5.png","m_6.png","m_7.png","m_8.png","m_9.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'Grados.png',
              unit_tc: 'Grados.png',
              unit_en: 'Grados.png',
              negative_image: '0033.png',
              invalid_image: '0025.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 307,
              y: 84,
              image_array: ["w0069.png","w0070.png","w0071.png","w0072.png","w0073.png","w0074.png","w0075.png","w0076.png","w0077.png","w0078.png","w0079.png","w0080.png","w0081.png","w0082.png","w0083.png","w0084.png","w0085.png","w0086.png","w0087.png","w0088.png","w0089.png","w0090.png","w0091.png","w0092.png","w0093.png","w0094.png","w0095.png","w0096.png","w0097.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_battery_circle_scale = hmUI.createWidget(hmUI.widget.Circle_Scale, {
              // center_x: 141,
              // center_y: 124,
              // start_angle: 0,
              // end_angle: 360,
              // radius: 54,
              // line_width: 14,
              // line_cap: Flat,
              // color: 0xFFFF0000,
              // mirror: False,
              // inversion: False,
              // type: hmUI.data_type.BATTERY,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            let screenType = hmSetting.getScreenType();
            normal_battery_circle_scale = hmUI.createWidget(hmUI.widget.ARC_PROGRESS, {
              center_x: 141,
              center_y: 124,
              start_angle: 0,
              end_angle: 360,
              radius: 47,
              line_width: 14,
              corner_flag: 3,
              color: 0xFFFF0000,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            
            const battery = hmSensor.createSensor(hmSensor.id.BATTERY);
            battery.addEventListener(hmSensor.event.CHANGE, function() {
              scale_call();
            });

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 119,
              y: 124,
              font_array: ["p_0.png","p_1.png","p_2.png","p_3.png","p_4.png","p_5.png","p_6.png","p_7.png","p_8.png","p_9.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_cal_circle_scale = hmUI.createWidget(hmUI.widget.Circle_Scale, {
              // center_x: 142,
              // center_y: 336,
              // start_angle: 0,
              // end_angle: 360,
              // radius: 54,
              // line_width: 13,
              // line_cap: Flat,
              // color: 0xFFFF0000,
              // mirror: False,
              // inversion: False,
              // type: hmUI.data_type.CAL,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_calorie_circle_scale = hmUI.createWidget(hmUI.widget.ARC_PROGRESS, {
              center_x: 142,
              center_y: 336,
              start_angle: 0,
              end_angle: 360,
              radius: 48,
              line_width: 13,
              corner_flag: 3,
              color: 0xFFFF0000,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            
            const calorie = hmSensor.createSensor(hmSensor.id.CALORIE);
            calorie.addEventListener(hmSensor.event.CHANGE, function() {
              scale_call();
            });

            normal_calorie_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 111,
              y: 332,
              font_array: ["p_0.png","p_1.png","p_2.png","p_3.png","p_4.png","p_5.png","p_6.png","p_7.png","p_8.png","p_9.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 34,
              y: 212,
              font_array: ["m_0.png","m_1.png","m_2.png","m_3.png","m_4.png","m_5.png","m_6.png","m_7.png","m_8.png","m_9.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_moon_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 402,
              y: 131,
              image_array: ["fase1.png","fase2.png","fase3.png","fase4.png","fase5.png","fase6.png","fase7.png","fase8.png"],
              image_length: 8,
              type: hmUI.data_type.MOON,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time_AmPm = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              am_x: 398,
              am_y: 254,
              am_sc_path: '33.png',
              am_en_path: '33.png',
              pm_x: 398,
              pm_y: 254,
              pm_sc_path: '34.png',
              pm_en_path: '34.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 238,
              hour_startY: 212,
              hour_array: ["h_0.png","h_1.png","h_2.png","h_3.png","h_4.png","h_5.png","h_6.png","h_7.png","h_8.png","h_9.png"],
              hour_zero: 1,
              hour_space: 0,
              hour_angle: 0,
              hour_align: hmUI.align.CENTER_H,

              minute_startX: 329,
              minute_startY: 212,
              minute_array: ["h_0.png","h_1.png","h_2.png","h_3.png","h_4.png","h_5.png","h_6.png","h_7.png","h_8.png","h_9.png"],
              minute_zero: 1,
              minute_space: 0,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.CENTER_H,

              second_startX: 405,
              second_startY: 213,
              second_array: ["p_0.png","p_1.png","p_2.png","p_3.png","p_4.png","p_5.png","p_6.png","p_7.png","p_8.png","p_9.png"],
              second_zero: 1,
              second_space: 0,
              second_angle: 0,
              second_follow: 0,
              second_align: hmUI.align.CENTER_H,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            console.log('Watch_Face.ScreenAOD');
            idle_background_bg = hmUI.createWidget(hmUI.widget.FILL_RECT, {
              x: 0,
              y: 0,
              w: 466,
              h: 466,
              color: '0xFF000000',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_system_lock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 219,
              y: 440,
              src: 'bloque8.png',
              type: hmUI.system_status.LOCK,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 175,
              y: 215,
              src: 'BT8.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 140,
              y: 213,
              src: '0228.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_year = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              year_startX: 360,
              year_startY: 173,
              year_sc_array: ["p_0.png","p_1.png","p_2.png","p_3.png","p_4.png","p_5.png","p_6.png","p_7.png","p_8.png","p_9.png"],
              year_tc_array: ["p_0.png","p_1.png","p_2.png","p_3.png","p_4.png","p_5.png","p_6.png","p_7.png","p_8.png","p_9.png"],
              year_en_array: ["p_0.png","p_1.png","p_2.png","p_3.png","p_4.png","p_5.png","p_6.png","p_7.png","p_8.png","p_9.png"],
              year_zero: 1,
              year_space: 0,
              year_align: hmUI.align.LEFT,
              year_is_character: false,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_month = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 315,
              month_startY: 173,
              month_sc_array: ["p_0.png","p_1.png","p_2.png","p_3.png","p_4.png","p_5.png","p_6.png","p_7.png","p_8.png","p_9.png"],
              month_tc_array: ["p_0.png","p_1.png","p_2.png","p_3.png","p_4.png","p_5.png","p_6.png","p_7.png","p_8.png","p_9.png"],
              month_en_array: ["p_0.png","p_1.png","p_2.png","p_3.png","p_4.png","p_5.png","p_6.png","p_7.png","p_8.png","p_9.png"],
              month_zero: 1,
              month_space: 0,
              month_unit_sc: 'c_point.png',
              month_unit_tc: 'c_point.png',
              month_unit_en: 'c_point.png',
              month_align: hmUI.align.LEFT,
              month_is_character: false,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 266,
              day_startY: 173,
              day_sc_array: ["p_0.png","p_1.png","p_2.png","p_3.png","p_4.png","p_5.png","p_6.png","p_7.png","p_8.png","p_9.png"],
              day_tc_array: ["p_0.png","p_1.png","p_2.png","p_3.png","p_4.png","p_5.png","p_6.png","p_7.png","p_8.png","p_9.png"],
              day_en_array: ["p_0.png","p_1.png","p_2.png","p_3.png","p_4.png","p_5.png","p_6.png","p_7.png","p_8.png","p_9.png"],
              day_zero: 1,
              day_space: 0,
              day_unit_sc: 'c_point.png',
              day_unit_tc: 'c_point.png',
              day_unit_en: 'c_point.png',
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 199,
              y: 80,
              week_en: ["day_1.png","day_2.png","day_3.png","day_4.png","day_5.png","day_6.png","day_7.png"],
              week_tc: ["day_1.png","day_2.png","day_3.png","day_4.png","day_5.png","day_6.png","day_7.png"],
              week_sc: ["day_1.png","day_2.png","day_3.png","day_4.png","day_5.png","day_6.png","day_7.png"],
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 224,
              y: 126,
              font_array: ["m_0.png","m_1.png","m_2.png","m_3.png","m_4.png","m_5.png","m_6.png","m_7.png","m_8.png","m_9.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'Grados.png',
              unit_tc: 'Grados.png',
              unit_en: 'Grados.png',
              negative_image: '0033.png',
              invalid_image: '0025.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 307,
              y: 84,
              image_array: ["w0069.png","w0070.png","w0071.png","w0072.png","w0073.png","w0074.png","w0075.png","w0076.png","w0077.png","w0078.png","w0079.png","w0080.png","w0081.png","w0082.png","w0083.png","w0084.png","w0085.png","w0086.png","w0087.png","w0088.png","w0089.png","w0090.png","w0091.png","w0092.png","w0093.png","w0094.png","w0095.png","w0096.png","w0097.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time_AmPm = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              am_x: 398,
              am_y: 254,
              am_sc_path: '33.png',
              am_en_path: '33.png',
              pm_x: 398,
              pm_y: 254,
              pm_sc_path: '34.png',
              pm_en_path: '34.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 216,
              hour_startY: 212,
              hour_array: ["h_0.png","h_1.png","h_2.png","h_3.png","h_4.png","h_5.png","h_6.png","h_7.png","h_8.png","h_9.png"],
              hour_zero: 1,
              hour_space: 0,
              hour_angle: 0,
              hour_unit_sc: 'colon.png',
              hour_unit_tc: 'colon.png',
              hour_unit_en: 'colon.png',
              hour_align: hmUI.align.CENTER_H,

              minute_startX: 329,
              minute_startY: 212,
              minute_array: ["h_0.png","h_1.png","h_2.png","h_3.png","h_4.png","h_5.png","h_6.png","h_7.png","h_8.png","h_9.png"],
              minute_zero: 1,
              minute_space: 0,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.CENTER_H,

              second_startX: 405,
              second_startY: 213,
              second_array: ["p_0.png","p_1.png","p_2.png","p_3.png","p_4.png","p_5.png","p_6.png","p_7.png","p_8.png","p_9.png"],
              second_zero: 1,
              second_space: 0,
              second_angle: 0,
              second_follow: 0,
              second_align: hmUI.align.CENTER_H,

              show_level: hmUI.show_level.ONLY_AOD,
            });
            console.log('Watch_Face.Shortcuts');

            normal_alarm_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 136,
              y: 211,
              w: 50,
              h: 50,
              type: hmUI.data_type.ALARM_CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sunrise_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 129,
              y: 8,
              w: 180,
              h: 70,
              type: hmUI.data_type.SUN_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_altimeter_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 401,
              y: 125,
              w: 50,
              h: 50,
              type: hmUI.data_type.ALTIMETER,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 215,
              y: 89,
              w: 180,
              h: 80,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_pai_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 93,
              y: 284,
              w: 100,
              h: 100,
              type: hmUI.data_type.PAI_WEEKLY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_spo2_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 240,
              y: 295,
              w: 80,
              h: 50,
              type: hmUI.data_type.SPO2,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 329,
              y: 296,
              w: 100,
              h: 50,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 15,
              y: 206,
              w: 120,
              h: 70,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            console.log('Watch_Face.Buttons');
            Button_1 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 20,
              y: 133,
              w: 59,
              h: 55,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'transparent.png',
              normal_src: 'transparent.png',
              click_func: (button_widget) => {
                click_color();
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_2 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 265,
              y: 404,
              w: 50,
              h: 50,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'transparent.png',
              normal_src: 'transparent.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'Settings_homeScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_3 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 207,
              y: 405,
              w: 50,
              h: 50,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'transparent.png',
              normal_src: 'transparent.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'ScheduleCalScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_4 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 151,
              y: 405,
              w: 50,
              h: 50,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'transparent.png',
              normal_src: 'transparent.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'PhoneHomeScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            function scale_call() {
              console.log('scale_call()');

                console.log('update scales BATTERY');
                
                let valueBattery = battery.current;
                let targetBattery = 100;
                let progressBattery = valueBattery/targetBattery;
                if (progressBattery > 1) progressBattery = 1;
                let progress_cs_normal_battery = progressBattery;

                if (screenType != hmSetting.screen_type.AOD) {

                  // normal_battery_circle_scale_circle_scale
                  let level = Math.round(progress_cs_normal_battery * 100);
                  if (normal_battery_circle_scale) {
                    normal_battery_circle_scale.setProperty(hmUI.prop.MORE, {                      
                      center_x: 141,
                      center_y: 124,
                      start_angle: 0,
                      end_angle: 360,
                      radius: 47,
                      line_width: 14,
                      corner_flag: 3,
                      color: 0xFFFF0000,
                      show_level: hmUI.show_level.ONLY_NORMAL,
                      level: level,
                    });
                  };
                };

                console.log('update scales CALORIE');
                
                let valueCalories = calorie.current;
                let targetCalories = calorie.target;
                let progressCalories = valueCalories/targetCalories;
                if (progressCalories > 1) progressCalories = 1;
                let progress_cs_normal_calorie = progressCalories;

                if (screenType != hmSetting.screen_type.AOD) {

                  // normal_calorie_circle_scale_circle_scale
                  let level = Math.round(progress_cs_normal_calorie * 100);
                  if (normal_calorie_circle_scale) {
                    normal_calorie_circle_scale.setProperty(hmUI.prop.MORE, {                      
                      center_x: 142,
                      center_y: 336,
                      start_angle: 0,
                      end_angle: 360,
                      radius: 48,
                      line_width: 13,
                      corner_flag: 3,
                      color: 0xFFFF0000,
                      show_level: hmUI.show_level.ONLY_NORMAL,
                      level: level,
                    });
                  };
                };

            };

            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                console.log('resume_call()');
                scale_call();
              }),
            });

                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}