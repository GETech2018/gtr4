﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        const logger = Logger.getLogger('watchface_SashaCX75');
        //end of ignored block

        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_system_disconnect_img = ''
        let normal_system_clock_img = ''
        let normal_calorie_icon_img = ''
        let normal_calorie_TextRotate = new Array(4);
        let normal_calorie_TextRotate_ASCIIARRAY = new Array(10);
        let normal_calorie_TextRotate_img_width = 30;
        let normal_battery_TextRotate = new Array(3);
        let normal_battery_TextRotate_ASCIIARRAY = new Array(10);
        let normal_battery_TextRotate_img_width = 30;
        let normal_battery_image_progress_img_level = ''
        let normal_city_name_text = ''
        let normal_temperature_current_text_img = ''
        let normal_weather_image_progress_img_level = ''
        let normal_step_icon_img = ''
        let normal_step_TextRotate = new Array(5);
        let normal_step_TextRotate_ASCIIARRAY = new Array(10);
        let normal_step_TextRotate_img_width = 21;
        let normal_heart_rate_TextRotate = new Array(3);
        let normal_heart_rate_TextRotate_ASCIIARRAY = new Array(10);
        let normal_heart_rate_TextRotate_img_width = 30;
        let normal_heart_rate_image_progress_img_level = ''
        let normal_month_TextRotate = new Array(2);
        let normal_month_TextRotate_ASCIIARRAY = new Array(10);
        let normal_month_TextRotate_img_width = 21;
        let normal_timerTextUpdate = undefined;
        let normal_year_TextRotate = new Array(4);
        let normal_year_TextRotate_ASCIIARRAY = new Array(10);
        let normal_year_TextRotate_img_width = 21;
        let normal_day_TextRotate = new Array(2);
        let normal_day_TextRotate_ASCIIARRAY = new Array(10);
        let normal_day_TextRotate_img_width = 21;
        let normal_day_TextRotate_unit = null;
        let normal_day_TextRotate_unit_width = 10;
        let normal_hour_TextRotate = new Array(2);
        let normal_hour_TextRotate_ASCIIARRAY = new Array(10);
        let normal_hour_TextRotate_img_width = 30;
        let normal_hour_TextRotate_unit = null;
        let normal_hour_TextRotate_unit_width = 15;
        let normal_minute_TextRotate = new Array(2);
        let normal_minute_TextRotate_ASCIIARRAY = new Array(10);
        let normal_minute_TextRotate_img_width = 30;
        let normal_analog_clock_pro_hour_pointer_img = ''
        let normal_analog_clock_pro_minute_pointer_img = ''
        let normal_timerUpdateSec = undefined;
        let normal_analog_clock_pro_second_pointer_img = ''
        let normal_timerUpdateSecSmooth = undefined;
        let idle_background_bg_img = ''
        let idle_system_disconnect_img = ''
        let idle_system_clock_img = ''
        let idle_month_TextRotate = new Array(2);
        let idle_month_TextRotate_ASCIIARRAY = new Array(10);
        let idle_month_TextRotate_img_width = 21;
        let idle_timerTextUpdate = undefined;
        let idle_year_TextRotate = new Array(4);
        let idle_year_TextRotate_ASCIIARRAY = new Array(10);
        let idle_year_TextRotate_img_width = 21;
        let idle_day_TextRotate = new Array(2);
        let idle_day_TextRotate_ASCIIARRAY = new Array(10);
        let idle_day_TextRotate_img_width = 21;
        let idle_day_TextRotate_unit = null;
        let idle_day_TextRotate_unit_width = 10;
        let idle_hour_TextRotate = new Array(2);
        let idle_hour_TextRotate_ASCIIARRAY = new Array(10);
        let idle_hour_TextRotate_img_width = 30;
        let idle_hour_TextRotate_unit = null;
        let idle_hour_TextRotate_unit_width = 15;
        let idle_minute_TextRotate = new Array(2);
        let idle_minute_TextRotate_ASCIIARRAY = new Array(10);
        let idle_minute_TextRotate_img_width = 30;
        let idle_analog_clock_pro_hour_pointer_img = ''
        let idle_analog_clock_pro_minute_pointer_img = ''
        let idle_timerUpdateSec = undefined;
        let idle_analog_clock_pro_second_pointer_img = ''
        let idle_timerUpdateSecSmooth = undefined;
        let Button_1 = ''
        let Button_2 = ''
        let Button_3 = ''
        let Button_4 = ''
        let Button_5 = ''
        let Button_6 = ''
        let Button_7 = ''
        let Button_8 = ''
        let Button_9 = ''
        let Button_10 = ''
        let Button_11 = ''
        let Button_12 = ''
        let timeSensor = ''


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 466,
              h: 466,
              src: 'Diskas.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 190,
              y: 175,
              src: '036.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 265,
              y: 195,
              src: 'alrms.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_calorie_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 42,
              y: 157,
              src: 'anim_cal_0.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_calorie_text_rotate_img = hmUI.createWidget(hmUI.widget.Text_Rotate, {
              // x: 109,
              // y: 100,
              // font_array: ["cfr01.png","cfr02.png","cfr03.png","cfr04.png","cfr05.png","cfr06.png","cfr07.png","cfr08.png","cfr09.png","cfr10.png"],
              // zero: false,
              // unit_in_alignment: true,
              // h_space: 0,
              // angle: 39,
              // align_h: hmUI.align.LEFT,
              // type: hmUI.data_type.CAL,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_calorie_TextRotate_ASCIIARRAY[0] = 'cfr01.png';  // set of images with numbers
            normal_calorie_TextRotate_ASCIIARRAY[1] = 'cfr02.png';  // set of images with numbers
            normal_calorie_TextRotate_ASCIIARRAY[2] = 'cfr03.png';  // set of images with numbers
            normal_calorie_TextRotate_ASCIIARRAY[3] = 'cfr04.png';  // set of images with numbers
            normal_calorie_TextRotate_ASCIIARRAY[4] = 'cfr05.png';  // set of images with numbers
            normal_calorie_TextRotate_ASCIIARRAY[5] = 'cfr06.png';  // set of images with numbers
            normal_calorie_TextRotate_ASCIIARRAY[6] = 'cfr07.png';  // set of images with numbers
            normal_calorie_TextRotate_ASCIIARRAY[7] = 'cfr08.png';  // set of images with numbers
            normal_calorie_TextRotate_ASCIIARRAY[8] = 'cfr09.png';  // set of images with numbers
            normal_calorie_TextRotate_ASCIIARRAY[9] = 'cfr10.png';  // set of images with numbers

            //start of ignored block
            for (let i = 0; i < 4; i++) {
              normal_calorie_TextRotate[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 466,
                h: 466,
                center_x: 109,
                center_y: 100,
                pos_x: 109,
                pos_y: 100,
                angle: 39,
                src: 'cfr01.png',
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
              normal_calorie_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
            };
            //end of ignored block
            
            const calorie = hmSensor.createSensor(hmSensor.id.CALORIE);
            calorie.addEventListener(hmSensor.event.CHANGE, function() {
              text_update();
            });

            // normal_battery_text_rotate_img = hmUI.createWidget(hmUI.widget.Text_Rotate, {
              // x: 334,
              // y: 136,
              // font_array: ["cfr01.png","cfr02.png","cfr03.png","cfr04.png","cfr05.png","cfr06.png","cfr07.png","cfr08.png","cfr09.png","cfr10.png"],
              // zero: false,
              // unit_in_alignment: false,
              // h_space: 0,
              // angle: -39,
              // align_h: hmUI.align.LEFT,
              // type: hmUI.data_type.BATTERY,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_battery_TextRotate_ASCIIARRAY[0] = 'cfr01.png';  // set of images with numbers
            normal_battery_TextRotate_ASCIIARRAY[1] = 'cfr02.png';  // set of images with numbers
            normal_battery_TextRotate_ASCIIARRAY[2] = 'cfr03.png';  // set of images with numbers
            normal_battery_TextRotate_ASCIIARRAY[3] = 'cfr04.png';  // set of images with numbers
            normal_battery_TextRotate_ASCIIARRAY[4] = 'cfr05.png';  // set of images with numbers
            normal_battery_TextRotate_ASCIIARRAY[5] = 'cfr06.png';  // set of images with numbers
            normal_battery_TextRotate_ASCIIARRAY[6] = 'cfr07.png';  // set of images with numbers
            normal_battery_TextRotate_ASCIIARRAY[7] = 'cfr08.png';  // set of images with numbers
            normal_battery_TextRotate_ASCIIARRAY[8] = 'cfr09.png';  // set of images with numbers
            normal_battery_TextRotate_ASCIIARRAY[9] = 'cfr10.png';  // set of images with numbers

            //start of ignored block
            for (let i = 0; i < 3; i++) {
              normal_battery_TextRotate[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 466,
                h: 466,
                center_x: 334,
                center_y: 136,
                pos_x: 334,
                pos_y: 136,
                angle: -39,
                src: 'cfr01.png',
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
              normal_battery_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
            };
            //end of ignored block
            
            const battery = hmSensor.createSensor(hmSensor.id.BATTERY);
            battery.addEventListener(hmSensor.event.CHANGE, function() {
              text_update();
            });

            normal_battery_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 289,
              y: 149,
              image_array: ["battery_0.png","battery_1.png","battery_2.png","battery_3.png","battery_4.png","battery_5.png","battery_6.png","battery_7.png","battery_8.png","battery_9.png"],
              image_length: 10,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
              const weatherSensor = hmSensor.createSensor(hmSensor.id.WEATHER);

            normal_city_name_text = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 197,
              y: 107,
              w: 84,
              h: 45,
              text_size: 25,
              char_space: 0,
              line_space: 0,
              color: 0xFFE9E9E9,
              align_h: hmUI.align.LEFT,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 212,
              y: 20,
              font_array: ["44.png","45.png","46.png","47.png","48.png","49.png","50.png","51.png","52.png","53.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'c.png',
              unit_tc: 'c.png',
              unit_en: 'c.png',
              negative_image: '0024.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 210,
              y: 49,
              image_array: ["weather_1.png","weather_2.png","weather_3.png","weather_4.png","weather_5.png","weather_6.png","weather_7.png","weather_8.png","weather_9.png","weather_10.png","weather_11.png","weather_12.png","weather_13.png","weather_14.png","weather_15.png","weather_16.png","weather_17.png","weather_18.png","weather_19.png","weather_20.png","weather_21.png","weather_22.png","weather_23.png","weather_24.png","weather_25.png","weather_26.png","weather_27.png","weather_28.png","weather_29.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 198,
              y: 389,
              src: 'step.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_step_text_rotate_img = hmUI.createWidget(hmUI.widget.Text_Rotate, {
              // x: 140,
              // y: 392,
              // font_array: ["44.png","45.png","46.png","47.png","48.png","49.png","50.png","51.png","52.png","53.png"],
              // zero: false,
              // unit_in_alignment: false,
              // h_space: 1,
              // angle: -64,
              // align_h: hmUI.align.LEFT,
              // type: hmUI.data_type.STEP,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_step_TextRotate_ASCIIARRAY[0] = '44.png';  // set of images with numbers
            normal_step_TextRotate_ASCIIARRAY[1] = '45.png';  // set of images with numbers
            normal_step_TextRotate_ASCIIARRAY[2] = '46.png';  // set of images with numbers
            normal_step_TextRotate_ASCIIARRAY[3] = '47.png';  // set of images with numbers
            normal_step_TextRotate_ASCIIARRAY[4] = '48.png';  // set of images with numbers
            normal_step_TextRotate_ASCIIARRAY[5] = '49.png';  // set of images with numbers
            normal_step_TextRotate_ASCIIARRAY[6] = '50.png';  // set of images with numbers
            normal_step_TextRotate_ASCIIARRAY[7] = '51.png';  // set of images with numbers
            normal_step_TextRotate_ASCIIARRAY[8] = '52.png';  // set of images with numbers
            normal_step_TextRotate_ASCIIARRAY[9] = '53.png';  // set of images with numbers

            //start of ignored block
            for (let i = 0; i < 5; i++) {
              normal_step_TextRotate[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 466,
                h: 466,
                center_x: 140,
                center_y: 392,
                pos_x: 140,
                pos_y: 392,
                angle: -64,
                src: '44.png',
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
              normal_step_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
            };
            //end of ignored block
            
            const step = hmSensor.createSensor(hmSensor.id.STEP);
            step.addEventListener(hmSensor.event.CHANGE, function() {
              text_update();
            });

            // normal_heart_rate_text_rotate_img = hmUI.createWidget(hmUI.widget.Text_Rotate, {
              // x: 278,
              // y: 307,
              // font_array: ["cfr01.png","cfr02.png","cfr03.png","cfr04.png","cfr05.png","cfr06.png","cfr07.png","cfr08.png","cfr09.png","cfr10.png"],
              // zero: true,
              // unit_in_alignment: true,
              // h_space: 2,
              // angle: 65,
              // align_h: hmUI.align.LEFT,
              // type: hmUI.data_type.HEART,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_heart_rate_TextRotate_ASCIIARRAY[0] = 'cfr01.png';  // set of images with numbers
            normal_heart_rate_TextRotate_ASCIIARRAY[1] = 'cfr02.png';  // set of images with numbers
            normal_heart_rate_TextRotate_ASCIIARRAY[2] = 'cfr03.png';  // set of images with numbers
            normal_heart_rate_TextRotate_ASCIIARRAY[3] = 'cfr04.png';  // set of images with numbers
            normal_heart_rate_TextRotate_ASCIIARRAY[4] = 'cfr05.png';  // set of images with numbers
            normal_heart_rate_TextRotate_ASCIIARRAY[5] = 'cfr06.png';  // set of images with numbers
            normal_heart_rate_TextRotate_ASCIIARRAY[6] = 'cfr07.png';  // set of images with numbers
            normal_heart_rate_TextRotate_ASCIIARRAY[7] = 'cfr08.png';  // set of images with numbers
            normal_heart_rate_TextRotate_ASCIIARRAY[8] = 'cfr09.png';  // set of images with numbers
            normal_heart_rate_TextRotate_ASCIIARRAY[9] = 'cfr10.png';  // set of images with numbers

            //start of ignored block
            for (let i = 0; i < 3; i++) {
              normal_heart_rate_TextRotate[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 466,
                h: 466,
                center_x: 278,
                center_y: 307,
                pos_x: 278,
                pos_y: 307,
                angle: 65,
                src: 'cfr01.png',
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
              normal_heart_rate_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
            };
            //end of ignored block
            
            const heart_rate = hmSensor.createSensor(hmSensor.id.HEART);
            heart_rate.addEventListener(hmSensor.event.CHANGE, function() {
              text_update();
            });

            normal_heart_rate_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 353,
              y: 337,
              image_array: ["h_0.png","h_1.png","h_2.png","h_3.png","h_4.png","h_5.png"],
              image_length: 6,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_month_text_rotate_img = hmUI.createWidget(hmUI.widget.Text_Rotate, {
              // x: 99,
              // y: 228,
              // font_array: ["44.png","45.png","46.png","47.png","48.png","49.png","50.png","51.png","52.png","53.png"],
              // zero: true,
              // unit_in_alignment: false,
              // h_space: 0,
              // angle: -12,
              // align_h: hmUI.align.LEFT,
              // type: hmUI.data_type.MONTH,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_month_TextRotate_ASCIIARRAY[0] = '44.png';  // set of images with numbers
            normal_month_TextRotate_ASCIIARRAY[1] = '45.png';  // set of images with numbers
            normal_month_TextRotate_ASCIIARRAY[2] = '46.png';  // set of images with numbers
            normal_month_TextRotate_ASCIIARRAY[3] = '47.png';  // set of images with numbers
            normal_month_TextRotate_ASCIIARRAY[4] = '48.png';  // set of images with numbers
            normal_month_TextRotate_ASCIIARRAY[5] = '49.png';  // set of images with numbers
            normal_month_TextRotate_ASCIIARRAY[6] = '50.png';  // set of images with numbers
            normal_month_TextRotate_ASCIIARRAY[7] = '51.png';  // set of images with numbers
            normal_month_TextRotate_ASCIIARRAY[8] = '52.png';  // set of images with numbers
            normal_month_TextRotate_ASCIIARRAY[9] = '53.png';  // set of images with numbers

            //start of ignored block
            for (let i = 0; i < 2; i++) {
              normal_month_TextRotate[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 466,
                h: 466,
                center_x: 99,
                center_y: 228,
                pos_x: 99,
                pos_y: 228,
                angle: -12,
                src: '44.png',
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
              normal_month_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
            };
            //end of ignored block
            
            const timeNaw = hmSensor.createSensor(hmSensor.id.TIME);

            let screenType = hmSetting.getScreenType();
            // normal_year_text_rotate_img = hmUI.createWidget(hmUI.widget.Text_Rotate, {
              // x: 77,
              // y: 267,
              // font_array: ["44.png","45.png","46.png","47.png","48.png","49.png","50.png","51.png","52.png","53.png"],
              // zero: true,
              // unit_in_alignment: false,
              // h_space: 0,
              // angle: -13,
              // align_h: hmUI.align.LEFT,
              // type: hmUI.data_type.YEAR,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_year_TextRotate_ASCIIARRAY[0] = '44.png';  // set of images with numbers
            normal_year_TextRotate_ASCIIARRAY[1] = '45.png';  // set of images with numbers
            normal_year_TextRotate_ASCIIARRAY[2] = '46.png';  // set of images with numbers
            normal_year_TextRotate_ASCIIARRAY[3] = '47.png';  // set of images with numbers
            normal_year_TextRotate_ASCIIARRAY[4] = '48.png';  // set of images with numbers
            normal_year_TextRotate_ASCIIARRAY[5] = '49.png';  // set of images with numbers
            normal_year_TextRotate_ASCIIARRAY[6] = '50.png';  // set of images with numbers
            normal_year_TextRotate_ASCIIARRAY[7] = '51.png';  // set of images with numbers
            normal_year_TextRotate_ASCIIARRAY[8] = '52.png';  // set of images with numbers
            normal_year_TextRotate_ASCIIARRAY[9] = '53.png';  // set of images with numbers

            //start of ignored block
            for (let i = 0; i < 4; i++) {
              normal_year_TextRotate[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 466,
                h: 466,
                center_x: 77,
                center_y: 267,
                pos_x: 77,
                pos_y: 267,
                angle: -13,
                src: '44.png',
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
              normal_year_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
            };
            //end of ignored block

            // normal_day_text_rotate_img = hmUI.createWidget(hmUI.widget.Text_Rotate, {
              // x: 43,
              // y: 242,
              // font_array: ["44.png","45.png","46.png","47.png","48.png","49.png","50.png","51.png","52.png","53.png"],
              // zero: true,
              // unit_in_alignment: false,
              // h_space: 2,
              // angle: -13,
              // unit_en: '0024.png',
              // align_h: hmUI.align.LEFT,
              // type: hmUI.data_type.DAY,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_day_TextRotate_ASCIIARRAY[0] = '44.png';  // set of images with numbers
            normal_day_TextRotate_ASCIIARRAY[1] = '45.png';  // set of images with numbers
            normal_day_TextRotate_ASCIIARRAY[2] = '46.png';  // set of images with numbers
            normal_day_TextRotate_ASCIIARRAY[3] = '47.png';  // set of images with numbers
            normal_day_TextRotate_ASCIIARRAY[4] = '48.png';  // set of images with numbers
            normal_day_TextRotate_ASCIIARRAY[5] = '49.png';  // set of images with numbers
            normal_day_TextRotate_ASCIIARRAY[6] = '50.png';  // set of images with numbers
            normal_day_TextRotate_ASCIIARRAY[7] = '51.png';  // set of images with numbers
            normal_day_TextRotate_ASCIIARRAY[8] = '52.png';  // set of images with numbers
            normal_day_TextRotate_ASCIIARRAY[9] = '53.png';  // set of images with numbers

            //start of ignored block
            for (let i = 0; i < 2; i++) {
              normal_day_TextRotate[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 466,
                h: 466,
                center_x: 43,
                center_y: 242,
                pos_x: 43,
                pos_y: 242,
                angle: -13,
                src: '44.png',
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
              normal_day_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
            };

            normal_day_TextRotate_unit = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 466,
              h: 466,
              center_x: 43,
              center_y: 242,
              pos_x: 43,
              pos_y: 242,
              angle: -13,
              src: '0024.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            normal_day_TextRotate_unit.setProperty(hmUI.prop.VISIBLE, false);
            //end of ignored block

            // normal_hour_text_rotate_img = hmUI.createWidget(hmUI.widget.Text_Rotate, {
              // x: 308,
              // y: 236,
              // font_array: ["cfr01.png","cfr02.png","cfr03.png","cfr04.png","cfr05.png","cfr06.png","cfr07.png","cfr08.png","cfr09.png","cfr10.png"],
              // zero: true,
              // unit_in_alignment: false,
              // h_space: 0,
              // angle: 13,
              // unit_en: '12.png',
              // align_h: hmUI.align.LEFT,
              // type: hmUI.data_type.HOUR,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_hour_TextRotate_ASCIIARRAY[0] = 'cfr01.png';  // set of images with numbers
            normal_hour_TextRotate_ASCIIARRAY[1] = 'cfr02.png';  // set of images with numbers
            normal_hour_TextRotate_ASCIIARRAY[2] = 'cfr03.png';  // set of images with numbers
            normal_hour_TextRotate_ASCIIARRAY[3] = 'cfr04.png';  // set of images with numbers
            normal_hour_TextRotate_ASCIIARRAY[4] = 'cfr05.png';  // set of images with numbers
            normal_hour_TextRotate_ASCIIARRAY[5] = 'cfr06.png';  // set of images with numbers
            normal_hour_TextRotate_ASCIIARRAY[6] = 'cfr07.png';  // set of images with numbers
            normal_hour_TextRotate_ASCIIARRAY[7] = 'cfr08.png';  // set of images with numbers
            normal_hour_TextRotate_ASCIIARRAY[8] = 'cfr09.png';  // set of images with numbers
            normal_hour_TextRotate_ASCIIARRAY[9] = 'cfr10.png';  // set of images with numbers

            //start of ignored block
            for (let i = 0; i < 2; i++) {
              normal_hour_TextRotate[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 466,
                h: 466,
                center_x: 308,
                center_y: 236,
                pos_x: 308,
                pos_y: 236,
                angle: 13,
                src: 'cfr01.png',
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
              normal_hour_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
            };

            normal_hour_TextRotate_unit = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 466,
              h: 466,
              center_x: 308,
              center_y: 236,
              pos_x: 308,
              pos_y: 236,
              angle: 13,
              src: '12.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            normal_hour_TextRotate_unit.setProperty(hmUI.prop.VISIBLE, false);
            //end of ignored block

            // normal_minute_text_rotate_img = hmUI.createWidget(hmUI.widget.Text_Rotate, {
              // x: 382,
              // y: 252,
              // font_array: ["cfr01.png","cfr02.png","cfr03.png","cfr04.png","cfr05.png","cfr06.png","cfr07.png","cfr08.png","cfr09.png","cfr10.png"],
              // zero: true,
              // unit_in_alignment: false,
              // h_space: 0,
              // angle: 13,
              // align_h: hmUI.align.LEFT,
              // type: hmUI.data_type.MINUTE,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_minute_TextRotate_ASCIIARRAY[0] = 'cfr01.png';  // set of images with numbers
            normal_minute_TextRotate_ASCIIARRAY[1] = 'cfr02.png';  // set of images with numbers
            normal_minute_TextRotate_ASCIIARRAY[2] = 'cfr03.png';  // set of images with numbers
            normal_minute_TextRotate_ASCIIARRAY[3] = 'cfr04.png';  // set of images with numbers
            normal_minute_TextRotate_ASCIIARRAY[4] = 'cfr05.png';  // set of images with numbers
            normal_minute_TextRotate_ASCIIARRAY[5] = 'cfr06.png';  // set of images with numbers
            normal_minute_TextRotate_ASCIIARRAY[6] = 'cfr07.png';  // set of images with numbers
            normal_minute_TextRotate_ASCIIARRAY[7] = 'cfr08.png';  // set of images with numbers
            normal_minute_TextRotate_ASCIIARRAY[8] = 'cfr09.png';  // set of images with numbers
            normal_minute_TextRotate_ASCIIARRAY[9] = 'cfr10.png';  // set of images with numbers

            //start of ignored block
            for (let i = 0; i < 2; i++) {
              normal_minute_TextRotate[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 466,
                h: 466,
                center_x: 382,
                center_y: 252,
                pos_x: 382,
                pos_y: 252,
                angle: 13,
                src: 'cfr01.png',
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
              normal_minute_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
            };
            //end of ignored block

            const deviceInfo = hmSetting.getDeviceInfo();
            if (!timeSensor) timeSensor = hmSensor.createSensor(hmSensor.id.TIME);
            timeSensor.addEventListener(timeSensor.event.MINUTEEND, function() {
              time_update(true, true);
            });

            // normal_analog_clock_pro_hour_pointer_img = hmUI.createWidget(hmUI.widget.TIME_POINTER_PRO, {
              // src: '00033.png',
              // center_x: 233,
              // center_y: 233,
              // x: 15,
              // y: 137,
              // start_angle: 0,
              // end_angle: 360,
              // type: hmUI.data_type.hour,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });


            normal_analog_clock_pro_hour_pointer_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: deviceInfo.width,
              h: deviceInfo.height,
              pos_x: 233 - 15,
              pos_y: 233 - 137,
              center_x: 233,
              center_y: 233,
              src: '00033.png',
              angle: 0,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_analog_clock_pro_minute_pointer_img = hmUI.createWidget(hmUI.widget.TIME_POINTER_PRO, {
              // src: '00044.png',
              // center_x: 233,
              // center_y: 233,
              // x: 13,
              // y: 196,
              // start_angle: 0,
              // end_angle: 360,
              // type: hmUI.data_type.minute,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });


            normal_analog_clock_pro_minute_pointer_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: deviceInfo.width,
              h: deviceInfo.height,
              pos_x: 233 - 13,
              pos_y: 233 - 196,
              center_x: 233,
              center_y: 233,
              src: '00044.png',
              angle: 0,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_analog_clock_pro_second_pointer_img = hmUI.createWidget(hmUI.widget.TIME_POINTER_PRO, {
              // src: 'sek.png',
              // center_x: 233,
              // center_y: 233,
              // x: 66,
              // y: 233,
              // start_angle: 0,
              // end_angle: 360,
              // type: hmUI.data_type.second,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });


            normal_analog_clock_pro_second_pointer_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: deviceInfo.width,
              h: deviceInfo.height,
              pos_x: 233 - 66,
              pos_y: 233 - 233,
              center_x: 233,
              center_y: 233,
              src: 'sek.png',
              angle: 0,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_analog_clock_pro_smooth_second = hmUI.createWidget(hmUI.widget.SMOOTH_SECOND, {
              // type: 2,
              // fps: 15,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });



            idle_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 466,
              h: 466,
              src: 'Diskas.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 190,
              y: 175,
              src: '036.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 265,
              y: 195,
              src: 'alrms.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            // idle_month_text_rotate_img = hmUI.createWidget(hmUI.widget.Text_Rotate, {
              // x: 99,
              // y: 228,
              // font_array: ["44.png","45.png","46.png","47.png","48.png","49.png","50.png","51.png","52.png","53.png"],
              // zero: true,
              // unit_in_alignment: false,
              // h_space: 0,
              // angle: -12,
              // align_h: hmUI.align.LEFT,
              // type: hmUI.data_type.MONTH,
              // show_level: hmUI.show_level.ONLY_AOD,
            // });

            idle_month_TextRotate_ASCIIARRAY[0] = '44.png';  // set of images with numbers
            idle_month_TextRotate_ASCIIARRAY[1] = '45.png';  // set of images with numbers
            idle_month_TextRotate_ASCIIARRAY[2] = '46.png';  // set of images with numbers
            idle_month_TextRotate_ASCIIARRAY[3] = '47.png';  // set of images with numbers
            idle_month_TextRotate_ASCIIARRAY[4] = '48.png';  // set of images with numbers
            idle_month_TextRotate_ASCIIARRAY[5] = '49.png';  // set of images with numbers
            idle_month_TextRotate_ASCIIARRAY[6] = '50.png';  // set of images with numbers
            idle_month_TextRotate_ASCIIARRAY[7] = '51.png';  // set of images with numbers
            idle_month_TextRotate_ASCIIARRAY[8] = '52.png';  // set of images with numbers
            idle_month_TextRotate_ASCIIARRAY[9] = '53.png';  // set of images with numbers

            //start of ignored block
            for (let i = 0; i < 2; i++) {
              idle_month_TextRotate[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 466,
                h: 466,
                center_x: 99,
                center_y: 228,
                pos_x: 99,
                pos_y: 228,
                angle: -12,
                src: '44.png',
                show_level: hmUI.show_level.ONLY_AOD,
              });
              idle_month_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
            };
            //end of ignored block

            // idle_year_text_rotate_img = hmUI.createWidget(hmUI.widget.Text_Rotate, {
              // x: 77,
              // y: 267,
              // font_array: ["44.png","45.png","46.png","47.png","48.png","49.png","50.png","51.png","52.png","53.png"],
              // zero: true,
              // unit_in_alignment: false,
              // h_space: 0,
              // angle: -13,
              // align_h: hmUI.align.LEFT,
              // type: hmUI.data_type.YEAR,
              // show_level: hmUI.show_level.ONLY_AOD,
            // });

            idle_year_TextRotate_ASCIIARRAY[0] = '44.png';  // set of images with numbers
            idle_year_TextRotate_ASCIIARRAY[1] = '45.png';  // set of images with numbers
            idle_year_TextRotate_ASCIIARRAY[2] = '46.png';  // set of images with numbers
            idle_year_TextRotate_ASCIIARRAY[3] = '47.png';  // set of images with numbers
            idle_year_TextRotate_ASCIIARRAY[4] = '48.png';  // set of images with numbers
            idle_year_TextRotate_ASCIIARRAY[5] = '49.png';  // set of images with numbers
            idle_year_TextRotate_ASCIIARRAY[6] = '50.png';  // set of images with numbers
            idle_year_TextRotate_ASCIIARRAY[7] = '51.png';  // set of images with numbers
            idle_year_TextRotate_ASCIIARRAY[8] = '52.png';  // set of images with numbers
            idle_year_TextRotate_ASCIIARRAY[9] = '53.png';  // set of images with numbers

            //start of ignored block
            for (let i = 0; i < 4; i++) {
              idle_year_TextRotate[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 466,
                h: 466,
                center_x: 77,
                center_y: 267,
                pos_x: 77,
                pos_y: 267,
                angle: -13,
                src: '44.png',
                show_level: hmUI.show_level.ONLY_AOD,
              });
              idle_year_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
            };
            //end of ignored block

            // idle_day_text_rotate_img = hmUI.createWidget(hmUI.widget.Text_Rotate, {
              // x: 43,
              // y: 242,
              // font_array: ["44.png","45.png","46.png","47.png","48.png","49.png","50.png","51.png","52.png","53.png"],
              // zero: true,
              // unit_in_alignment: false,
              // h_space: 2,
              // angle: -13,
              // unit_en: '0024.png',
              // align_h: hmUI.align.LEFT,
              // type: hmUI.data_type.DAY,
              // show_level: hmUI.show_level.ONLY_AOD,
            // });

            idle_day_TextRotate_ASCIIARRAY[0] = '44.png';  // set of images with numbers
            idle_day_TextRotate_ASCIIARRAY[1] = '45.png';  // set of images with numbers
            idle_day_TextRotate_ASCIIARRAY[2] = '46.png';  // set of images with numbers
            idle_day_TextRotate_ASCIIARRAY[3] = '47.png';  // set of images with numbers
            idle_day_TextRotate_ASCIIARRAY[4] = '48.png';  // set of images with numbers
            idle_day_TextRotate_ASCIIARRAY[5] = '49.png';  // set of images with numbers
            idle_day_TextRotate_ASCIIARRAY[6] = '50.png';  // set of images with numbers
            idle_day_TextRotate_ASCIIARRAY[7] = '51.png';  // set of images with numbers
            idle_day_TextRotate_ASCIIARRAY[8] = '52.png';  // set of images with numbers
            idle_day_TextRotate_ASCIIARRAY[9] = '53.png';  // set of images with numbers

            //start of ignored block
            for (let i = 0; i < 2; i++) {
              idle_day_TextRotate[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 466,
                h: 466,
                center_x: 43,
                center_y: 242,
                pos_x: 43,
                pos_y: 242,
                angle: -13,
                src: '44.png',
                show_level: hmUI.show_level.ONLY_AOD,
              });
              idle_day_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
            };

            idle_day_TextRotate_unit = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 466,
              h: 466,
              center_x: 43,
              center_y: 242,
              pos_x: 43,
              pos_y: 242,
              angle: -13,
              src: '0024.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });
            idle_day_TextRotate_unit.setProperty(hmUI.prop.VISIBLE, false);
            //end of ignored block

            // idle_hour_text_rotate_img = hmUI.createWidget(hmUI.widget.Text_Rotate, {
              // x: 308,
              // y: 236,
              // font_array: ["cfr01.png","cfr02.png","cfr03.png","cfr04.png","cfr05.png","cfr06.png","cfr07.png","cfr08.png","cfr09.png","cfr10.png"],
              // zero: true,
              // unit_in_alignment: false,
              // h_space: 0,
              // angle: 13,
              // unit_en: '12.png',
              // align_h: hmUI.align.LEFT,
              // type: hmUI.data_type.HOUR,
              // show_level: hmUI.show_level.ONLY_AOD,
            // });

            idle_hour_TextRotate_ASCIIARRAY[0] = 'cfr01.png';  // set of images with numbers
            idle_hour_TextRotate_ASCIIARRAY[1] = 'cfr02.png';  // set of images with numbers
            idle_hour_TextRotate_ASCIIARRAY[2] = 'cfr03.png';  // set of images with numbers
            idle_hour_TextRotate_ASCIIARRAY[3] = 'cfr04.png';  // set of images with numbers
            idle_hour_TextRotate_ASCIIARRAY[4] = 'cfr05.png';  // set of images with numbers
            idle_hour_TextRotate_ASCIIARRAY[5] = 'cfr06.png';  // set of images with numbers
            idle_hour_TextRotate_ASCIIARRAY[6] = 'cfr07.png';  // set of images with numbers
            idle_hour_TextRotate_ASCIIARRAY[7] = 'cfr08.png';  // set of images with numbers
            idle_hour_TextRotate_ASCIIARRAY[8] = 'cfr09.png';  // set of images with numbers
            idle_hour_TextRotate_ASCIIARRAY[9] = 'cfr10.png';  // set of images with numbers

            //start of ignored block
            for (let i = 0; i < 2; i++) {
              idle_hour_TextRotate[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 466,
                h: 466,
                center_x: 308,
                center_y: 236,
                pos_x: 308,
                pos_y: 236,
                angle: 13,
                src: 'cfr01.png',
                show_level: hmUI.show_level.ONLY_AOD,
              });
              idle_hour_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
            };

            idle_hour_TextRotate_unit = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 466,
              h: 466,
              center_x: 308,
              center_y: 236,
              pos_x: 308,
              pos_y: 236,
              angle: 13,
              src: '12.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });
            idle_hour_TextRotate_unit.setProperty(hmUI.prop.VISIBLE, false);
            //end of ignored block

            // idle_minute_text_rotate_img = hmUI.createWidget(hmUI.widget.Text_Rotate, {
              // x: 382,
              // y: 252,
              // font_array: ["cfr01.png","cfr02.png","cfr03.png","cfr04.png","cfr05.png","cfr06.png","cfr07.png","cfr08.png","cfr09.png","cfr10.png"],
              // zero: true,
              // unit_in_alignment: false,
              // h_space: 0,
              // angle: 13,
              // align_h: hmUI.align.LEFT,
              // type: hmUI.data_type.MINUTE,
              // show_level: hmUI.show_level.ONLY_AOD,
            // });

            idle_minute_TextRotate_ASCIIARRAY[0] = 'cfr01.png';  // set of images with numbers
            idle_minute_TextRotate_ASCIIARRAY[1] = 'cfr02.png';  // set of images with numbers
            idle_minute_TextRotate_ASCIIARRAY[2] = 'cfr03.png';  // set of images with numbers
            idle_minute_TextRotate_ASCIIARRAY[3] = 'cfr04.png';  // set of images with numbers
            idle_minute_TextRotate_ASCIIARRAY[4] = 'cfr05.png';  // set of images with numbers
            idle_minute_TextRotate_ASCIIARRAY[5] = 'cfr06.png';  // set of images with numbers
            idle_minute_TextRotate_ASCIIARRAY[6] = 'cfr07.png';  // set of images with numbers
            idle_minute_TextRotate_ASCIIARRAY[7] = 'cfr08.png';  // set of images with numbers
            idle_minute_TextRotate_ASCIIARRAY[8] = 'cfr09.png';  // set of images with numbers
            idle_minute_TextRotate_ASCIIARRAY[9] = 'cfr10.png';  // set of images with numbers

            //start of ignored block
            for (let i = 0; i < 2; i++) {
              idle_minute_TextRotate[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 466,
                h: 466,
                center_x: 382,
                center_y: 252,
                pos_x: 382,
                pos_y: 252,
                angle: 13,
                src: 'cfr01.png',
                show_level: hmUI.show_level.ONLY_AOD,
              });
              idle_minute_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
            };
            //end of ignored block

            // idle_analog_clock_pro_hour_pointer_img = hmUI.createWidget(hmUI.widget.TIME_POINTER_PRO, {
              // src: '00033.png',
              // center_x: 233,
              // center_y: 233,
              // x: 14,
              // y: 138,
              // start_angle: 0,
              // end_angle: 360,
              // type: hmUI.data_type.hour,
              // show_level: hmUI.show_level.ONLY_AOD,
            // });


            idle_analog_clock_pro_hour_pointer_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: deviceInfo.width,
              h: deviceInfo.height,
              pos_x: 233 - 14,
              pos_y: 233 - 138,
              center_x: 233,
              center_y: 233,
              src: '00033.png',
              angle: 0,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            // idle_analog_clock_pro_minute_pointer_img = hmUI.createWidget(hmUI.widget.TIME_POINTER_PRO, {
              // src: '00044.png',
              // center_x: 233,
              // center_y: 233,
              // x: 12,
              // y: 197,
              // start_angle: 0,
              // end_angle: 360,
              // type: hmUI.data_type.minute,
              // show_level: hmUI.show_level.ONLY_AOD,
            // });


            idle_analog_clock_pro_minute_pointer_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: deviceInfo.width,
              h: deviceInfo.height,
              pos_x: 233 - 12,
              pos_y: 233 - 197,
              center_x: 233,
              center_y: 233,
              src: '00044.png',
              angle: 0,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            // idle_analog_clock_pro_second_pointer_img = hmUI.createWidget(hmUI.widget.TIME_POINTER_PRO, {
              // src: 'sek.png',
              // center_x: 233,
              // center_y: 233,
              // x: 66,
              // y: 233,
              // start_angle: 0,
              // end_angle: 360,
              // type: hmUI.data_type.second,
              // show_level: hmUI.show_level.ONLY_AOD,
            // });


            idle_analog_clock_pro_second_pointer_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: deviceInfo.width,
              h: deviceInfo.height,
              pos_x: 233 - 66,
              pos_y: 233 - 233,
              center_x: 233,
              center_y: 233,
              src: 'sek.png',
              angle: 0,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            // idle_analog_clock_pro_smooth_second = hmUI.createWidget(hmUI.widget.SMOOTH_SECOND, {
              // type: 2,
              // fps: 15,
              // show_level: hmUI.show_level.ONLY_AOD,
            // });

            
            // disconnectAlert = hmUI.createWidget(hmUI.widget.DisconnectAlert, {
              // disconneсnt_vibrate_type: 9,
              // disconneсnt_toast_text: ===  BT  OFF  ===,
              // conneсnt_vibrate_type: 0,
              // conneсnt_toast_text: ===  BT  ON  ===,
            // });

            // vibration when connecting or disconnecting

            function checkConnection() {
              hmBle.removeListener;
              hmBle.addListener(function (status) {
                if(!status) {
                  hmUI.showToast({text: "===  BT  OFF  ==="});
                  vibro(9);
                }
                if(status) {
                  hmUI.showToast({text: "===  BT  ON  ==="});
                  vibro(0);
                }
              });
            }

            // end vibration when connecting or disconnecting
            // vibrate function

            const vibrate = hmSensor.createSensor(hmSensor.id.VIBRATE);
            let timer_StopVibrate = null;


            function vibro(scene = 25) {
              let stopDelay = 50;
              stopVibro();
              vibrate.stop();
              vibrate.scene = scene;
              if(scene < 23 || scene > 25) stopDelay = 1300;
              vibrate.start();
              timer_StopVibrate = timer.createTimer(stopDelay, 3000, stopVibro, {});
            }

            function stopVibro(){
              vibrate.stop();
              if(timer_StopVibrate) timer.stopTimer(timer_StopVibrate);
            }

            // end vibrate function

            Button_1 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 187,
              y: 169,
              w: 45,
              h: 45,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '0.png',
              normal_src: '0.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'FindPhoneScreen', native: true });
              }, // end func
              longpress_func: (button_widget) => {
                hmApp.startApp({url: 'WatchFaceScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_2 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 253,
              y: 190,
              w: 40,
              h: 40,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '0.png',
              normal_src: '0.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'AlarmInfoScreen', native: true });
              }, // end func
              longpress_func: (button_widget) => {
                hmApp.startApp({url: 'WorldClockScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_3 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 35,
              y: 217,
              w: 133,
              h: 65,
              text: '',
              color: 0xFFFF8C00,
              text_size: 21,
              press_src: '0.png',
              normal_src: '0.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'ScheduleCalScreen', native: true });
              }, // end func
              longpress_func: (button_widget) => {
                hmApp.startApp({url: 'todoListScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_4 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 280,
              y: 140,
              w: 66,
              h: 65,
              text: '',
              color: 0xFFFF8C00,
              text_size: 21,
              press_src: '0.png',
              normal_src: '0.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'Settings_batteryManagerScreen', native: true });
              }, // end func
              longpress_func: (button_widget) => {
                hmApp.startApp({url: 'PowerSaveHintScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_5 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 345,
              y: 90,
              w: 66,
              h: 65,
              text: '',
              color: 0xFFFF8C00,
              text_size: 21,
              press_src: '0.png',
              normal_src: '0.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'Settings_batteryManagerScreen', native: true });
              }, // end func
              longpress_func: (button_widget) => {
                hmApp.startApp({url: 'PowerSaveHintScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_6 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 285,
              y: 36,
              w: 58,
              h: 68,
              text: '',
              color: 0xFFFF8C00,
              text_size: 21,
              press_src: '006.png',
              normal_src: '006.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'DragListScreen', native: true });
              }, // end func
              longpress_func: (button_widget) => {
                hmApp.startApp({url: 'HidcameraScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_7 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 380,
              y: 165,
              w: 66,
              h: 70,
              text: '',
              color: 0xFFFF8C00,
              text_size: 21,
              press_src: 'LOGO_AMAZFIT_gray1.png',
              normal_src: 'LOGO_AMAZFIT_gray1.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'Settings_systemScreen', native: true });
              }, // end func
              longpress_func: (button_widget) => {
                hmApp.startApp({url: 'HmReStartScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_8 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 340,
              y: 320,
              w: 66,
              h: 65,
              text: '',
              color: 0xFFFF8C00,
              text_size: 21,
              press_src: '0.png',
              normal_src: '0.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'heart_app_Screen', native: true });
              }, // end func
              longpress_func: (button_widget) => {
                hmApp.startApp({url: 'StressHomeScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_9 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 52,
              y: 306,
              w: 61,
              h: 70,
              text: '',
              color: 0xFFFF8C00,
              text_size: 21,
              press_src: 'Phone_30029.png',
              normal_src: 'Phone_30029.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'PhoneRecentCallScreen', native: true });
              }, // end func
              longpress_func: (button_widget) => {
                hmApp.startApp({url: 'PhoneContactsScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_10 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 195,
              y: 380,
              w: 60,
              h: 60,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '0.png',
              normal_src: '0.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'activityAppScreen', native: true });
              }, // end func
              longpress_func: (button_widget) => {
                hmApp.startApp({url: 'spo_HomeScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_11 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 25,
              y: 155,
              w: 60,
              h: 60,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '0.png',
              normal_src: '0.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'PAI_app_Screen', native: true });
              }, // end func
              longpress_func: (button_widget) => {
                hmApp.startApp({url: 'oneKeyAppScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_12 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 128,
              y: 32,
              w: 60,
              h: 60,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'c1.png',
              normal_src: 'c1.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'WeatherScreen', native: true });
              }, // end func
              longpress_func: (button_widget) => {
                hmApp.startApp({url: 'BaroAltimeterScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            function time_update(updateHour = false, updateMinute = false) {
              let hour = timeSensor.hour;
              let minute = timeSensor.minute;
              let second = timeSensor.second;

              if (updateHour) {
                let normal_hour = hour;
                let normal_fullAngle_hour = 360;
                if (normal_hour > 11) normal_hour -= 12;
                let normal_angle_hour = 0 + normal_fullAngle_hour*normal_hour/12 + (normal_fullAngle_hour/12)*minute/60;
                if (normal_analog_clock_pro_hour_pointer_img) normal_analog_clock_pro_hour_pointer_img.setProperty(hmUI.prop.ANGLE, normal_angle_hour);
              };

              if (updateMinute) {
                let normal_fullAngle_minute = 360;
                let normal_angle_minute = 0 + normal_fullAngle_minute*(minute + second/60)/60;
                if (normal_analog_clock_pro_minute_pointer_img) normal_analog_clock_pro_minute_pointer_img.setProperty(hmUI.prop.ANGLE, normal_angle_minute);
              };

              let normal_fullAngle_second = 360;
              let normal_angle_second = 0 + normal_fullAngle_second*(second + (timeSensor.utc % 1000)/1000)/60;
              if (normal_analog_clock_pro_second_pointer_img) normal_analog_clock_pro_second_pointer_img.setProperty(hmUI.prop.ANGLE, normal_angle_second);

              if (updateHour) {
                let idle_hour = hour;
                let idle_fullAngle_hour = 360;
                if (idle_hour > 11) idle_hour -= 12;
                let idle_angle_hour = 0 + idle_fullAngle_hour*idle_hour/12 + (idle_fullAngle_hour/12)*minute/60;
                if (idle_analog_clock_pro_hour_pointer_img) idle_analog_clock_pro_hour_pointer_img.setProperty(hmUI.prop.ANGLE, idle_angle_hour);
              };

              if (updateMinute) {
                let idle_fullAngle_minute = 360;
                let idle_angle_minute = 0 + idle_fullAngle_minute*(minute + second/60)/60;
                if (idle_analog_clock_pro_minute_pointer_img) idle_analog_clock_pro_minute_pointer_img.setProperty(hmUI.prop.ANGLE, idle_angle_minute);
              };

              let idle_fullAngle_second = 360;
              let idle_angle_second = 0 + idle_fullAngle_second*(second + (timeSensor.utc % 1000)/1000)/60;
              if (idle_analog_clock_pro_second_pointer_img) idle_analog_clock_pro_second_pointer_img.setProperty(hmUI.prop.ANGLE, idle_angle_second);

            };

            function text_update() {

              console.log('update text rotate calorie_CALORIE');
              let valueCalories = calorie.current;
              let normal_calorie_rotate_string = parseInt(valueCalories).toString();

              if (screenType != hmSetting.screen_type.AOD) {
                for (var i = 1; i < 4; i++) {  // hide all symbols
                  normal_calorie_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                if (valueCalories != null && valueCalories != undefined && isFinite(valueCalories) && normal_calorie_rotate_string.length > 0 && normal_calorie_rotate_string.length < 6) {  // display data if it was possible to get it
                  let img_offset = 0;
                  
                  let index = 0;
                  for (let char of normal_calorie_rotate_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 4) break;
                    if (charCode >= 0 && charCode < 10) { 
                      normal_calorie_TextRotate[index].setProperty(hmUI.prop.POS_X, 109 + img_offset);
                      normal_calorie_TextRotate[index].setProperty(hmUI.prop.SRC, normal_calorie_TextRotate_ASCIIARRAY[charCode]);
                      normal_calorie_TextRotate[index].setProperty(hmUI.prop.VISIBLE, true);
                      img_offset += normal_calorie_TextRotate_img_width;
                      index++;
                    };  // end if digit
                  };  // end char of string
                }  // end isFinite

              };

              console.log('update text rotate battery_BATTERY');
              let valueBattery = battery.current;
              let normal_battery_rotate_string = parseInt(valueBattery).toString();

              if (screenType != hmSetting.screen_type.AOD) {
                for (var i = 1; i < 3; i++) {  // hide all symbols
                  normal_battery_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                if (valueBattery != null && valueBattery != undefined && isFinite(valueBattery) && normal_battery_rotate_string.length > 0 && normal_battery_rotate_string.length < 6) {  // display data if it was possible to get it
                  let img_offset = 0;
                  
                  let index = 0;
                  for (let char of normal_battery_rotate_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 3) break;
                    if (charCode >= 0 && charCode < 10) { 
                      normal_battery_TextRotate[index].setProperty(hmUI.prop.POS_X, 334 + img_offset);
                      normal_battery_TextRotate[index].setProperty(hmUI.prop.SRC, normal_battery_TextRotate_ASCIIARRAY[charCode]);
                      normal_battery_TextRotate[index].setProperty(hmUI.prop.VISIBLE, true);
                      img_offset += normal_battery_TextRotate_img_width;
                      index++;
                    };  // end if digit
                  };  // end char of string
                }  // end isFinite

              };

              console.log('update text rotate step_STEP');
              let valueStep = step.current;
              let normal_step_rotate_string = parseInt(valueStep).toString();

              if (screenType != hmSetting.screen_type.AOD) {
                for (var i = 1; i < 5; i++) {  // hide all symbols
                  normal_step_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                if (valueStep != null && valueStep != undefined && isFinite(valueStep) && normal_step_rotate_string.length > 0 && normal_step_rotate_string.length < 6) {  // display data if it was possible to get it
                  let img_offset = 0;
                  
                  let index = 0;
                  for (let char of normal_step_rotate_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 5) break;
                    if (charCode >= 0 && charCode < 10) { 
                      normal_step_TextRotate[index].setProperty(hmUI.prop.POS_X, 140 + img_offset);
                      normal_step_TextRotate[index].setProperty(hmUI.prop.SRC, normal_step_TextRotate_ASCIIARRAY[charCode]);
                      normal_step_TextRotate[index].setProperty(hmUI.prop.VISIBLE, true);
                      img_offset += normal_step_TextRotate_img_width + 1;
                      index++;
                    };  // end if digit
                  };  // end char of string
                }  // end isFinite

              };

              console.log('update text rotate heart_rate_HEART');
              let valueHeartRate = heart_rate.last;
              let normal_heart_rate_rotate_string = parseInt(valueHeartRate).toString();
              normal_heart_rate_rotate_string = normal_heart_rate_rotate_string.padStart(3, '0');

              if (screenType != hmSetting.screen_type.AOD) {
                for (var i = 1; i < 3; i++) {  // hide all symbols
                  normal_heart_rate_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                if (valueHeartRate != null && valueHeartRate != undefined && isFinite(valueHeartRate) && normal_heart_rate_rotate_string.length > 0 && normal_heart_rate_rotate_string.length < 6) {  // display data if it was possible to get it
                  let img_offset = 0;
                  
                  let index = 0;
                  for (let char of normal_heart_rate_rotate_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 3) break;
                    if (charCode >= 0 && charCode < 10) { 
                      normal_heart_rate_TextRotate[index].setProperty(hmUI.prop.POS_X, 278 + img_offset);
                      normal_heart_rate_TextRotate[index].setProperty(hmUI.prop.SRC, normal_heart_rate_TextRotate_ASCIIARRAY[charCode]);
                      normal_heart_rate_TextRotate[index].setProperty(hmUI.prop.VISIBLE, true);
                      img_offset += normal_heart_rate_TextRotate_img_width + 2;
                      index++;
                    };  // end if digit
                  };  // end char of string
                }  // end isFinite

              };

              console.log('update text rotate month_TIME');
              let valueMonth = timeNaw.month;
              let normal_month_rotate_string = parseInt(valueMonth).toString();
              normal_month_rotate_string = normal_month_rotate_string.padStart(2, '0');

              if (screenType != hmSetting.screen_type.AOD) {
                for (var i = 1; i < 2; i++) {  // hide all symbols
                  normal_month_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                if (valueMonth != null && valueMonth != undefined && isFinite(valueMonth) && normal_month_rotate_string.length > 0 && normal_month_rotate_string.length < 6) {  // display data if it was possible to get it
                  let img_offset = 0;
                  
                  let index = 0;
                  for (let char of normal_month_rotate_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 2) break;
                    if (charCode >= 0 && charCode < 10) { 
                      normal_month_TextRotate[index].setProperty(hmUI.prop.POS_X, 99 + img_offset);
                      normal_month_TextRotate[index].setProperty(hmUI.prop.SRC, normal_month_TextRotate_ASCIIARRAY[charCode]);
                      normal_month_TextRotate[index].setProperty(hmUI.prop.VISIBLE, true);
                      img_offset += normal_month_TextRotate_img_width;
                      index++;
                    };  // end if digit
                  };  // end char of string
                }  // end isFinite

              };

              console.log('update text rotate year_TIME');
              let valueYear = timeNaw.year;
              let normal_year_rotate_string = parseInt(valueYear).toString();

              if (screenType != hmSetting.screen_type.AOD) {
                for (var i = 1; i < 4; i++) {  // hide all symbols
                  normal_year_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                if (valueYear != null && valueYear != undefined && isFinite(valueYear) && normal_year_rotate_string.length > 0 && normal_year_rotate_string.length < 6) {  // display data if it was possible to get it
                  let img_offset = 0;
                  
                  let index = 0;
                  for (let char of normal_year_rotate_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 4) break;
                    if (charCode >= 0 && charCode < 10) { 
                      normal_year_TextRotate[index].setProperty(hmUI.prop.POS_X, 77 + img_offset);
                      normal_year_TextRotate[index].setProperty(hmUI.prop.SRC, normal_year_TextRotate_ASCIIARRAY[charCode]);
                      normal_year_TextRotate[index].setProperty(hmUI.prop.VISIBLE, true);
                      img_offset += normal_year_TextRotate_img_width;
                      index++;
                    };  // end if digit
                  };  // end char of string
                }  // end isFinite

              };

              console.log('update text rotate day_TIME');
              let valueDay = timeNaw.day;
              let normal_day_rotate_string = parseInt(valueDay).toString();
              normal_day_rotate_string = normal_day_rotate_string.padStart(2, '0');

              if (screenType != hmSetting.screen_type.AOD) {
                for (var i = 1; i < 2; i++) {  // hide all symbols
                  normal_day_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                normal_day_TextRotate_unit.setProperty(hmUI.prop.VISIBLE, false);
                if (valueDay != null && valueDay != undefined && isFinite(valueDay) && normal_day_rotate_string.length > 0 && normal_day_rotate_string.length < 6) {  // display data if it was possible to get it
                  let img_offset = 0;
                  
                  let index = 0;
                  for (let char of normal_day_rotate_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 2) break;
                    if (charCode >= 0 && charCode < 10) { 
                      normal_day_TextRotate[index].setProperty(hmUI.prop.POS_X, 43 + img_offset);
                      normal_day_TextRotate[index].setProperty(hmUI.prop.SRC, normal_day_TextRotate_ASCIIARRAY[charCode]);
                      normal_day_TextRotate[index].setProperty(hmUI.prop.VISIBLE, true);
                      img_offset += normal_day_TextRotate_img_width + 2;
                      index++;
                    };  // end if digit
                  };  // end char of string
                  normal_day_TextRotate_unit.setProperty(hmUI.prop.POS_X, 43 + img_offset);
                  normal_day_TextRotate_unit.setProperty(hmUI.prop.VISIBLE, true);
                }  // end isFinite

              };

              console.log('update text rotate hour_TIME');
              let valueHour = timeNaw.hour;
              if (!timeNaw.is24Hour) {
                valueHour -= 12;
                if (valueHour < 1) valueHour += 12;
              };
              let normal_hour_rotate_string = parseInt(valueHour).toString();
              normal_hour_rotate_string = normal_hour_rotate_string.padStart(2, '0');

              if (screenType != hmSetting.screen_type.AOD) {
                for (var i = 1; i < 2; i++) {  // hide all symbols
                  normal_hour_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                normal_hour_TextRotate_unit.setProperty(hmUI.prop.VISIBLE, false);
                if (valueHour != null && valueHour != undefined && isFinite(valueHour) && normal_hour_rotate_string.length > 0 && normal_hour_rotate_string.length < 6) {  // display data if it was possible to get it
                  let img_offset = 0;
                  
                  let index = 0;
                  for (let char of normal_hour_rotate_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 2) break;
                    if (charCode >= 0 && charCode < 10) { 
                      normal_hour_TextRotate[index].setProperty(hmUI.prop.POS_X, 308 + img_offset);
                      normal_hour_TextRotate[index].setProperty(hmUI.prop.SRC, normal_hour_TextRotate_ASCIIARRAY[charCode]);
                      normal_hour_TextRotate[index].setProperty(hmUI.prop.VISIBLE, true);
                      img_offset += normal_hour_TextRotate_img_width;
                      index++;
                    };  // end if digit
                  };  // end char of string
                  normal_hour_TextRotate_unit.setProperty(hmUI.prop.POS_X, 308 + img_offset);
                  normal_hour_TextRotate_unit.setProperty(hmUI.prop.VISIBLE, true);
                }  // end isFinite

              };

              console.log('update text rotate minute_TIME');
              let valueMinute = timeNaw.minute;
              let normal_minute_rotate_string = parseInt(valueMinute).toString();
              normal_minute_rotate_string = normal_minute_rotate_string.padStart(2, '0');

              if (screenType != hmSetting.screen_type.AOD) {
                for (var i = 1; i < 2; i++) {  // hide all symbols
                  normal_minute_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                if (valueMinute != null && valueMinute != undefined && isFinite(valueMinute) && normal_minute_rotate_string.length > 0 && normal_minute_rotate_string.length < 6) {  // display data if it was possible to get it
                  let img_offset = 0;
                  
                  let index = 0;
                  for (let char of normal_minute_rotate_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 2) break;
                    if (charCode >= 0 && charCode < 10) { 
                      normal_minute_TextRotate[index].setProperty(hmUI.prop.POS_X, 382 + img_offset);
                      normal_minute_TextRotate[index].setProperty(hmUI.prop.SRC, normal_minute_TextRotate_ASCIIARRAY[charCode]);
                      normal_minute_TextRotate[index].setProperty(hmUI.prop.VISIBLE, true);
                      img_offset += normal_minute_TextRotate_img_width;
                      index++;
                    };  // end if digit
                  };  // end char of string
                }  // end isFinite

              };

              console.log('update text rotate month_TIME');
              let idle_month_rotate_string = parseInt(valueMonth).toString();
              idle_month_rotate_string = idle_month_rotate_string.padStart(2, '0');

              if (screenType == hmSetting.screen_type.AOD) {
                for (var i = 1; i < 2; i++) {  // hide all symbols
                  idle_month_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                if (valueMonth != null && valueMonth != undefined && isFinite(valueMonth) && idle_month_rotate_string.length > 0 && idle_month_rotate_string.length < 6) {  // display data if it was possible to get it
                  let img_offset = 0;
                  
                  let index = 0;
                  for (let char of idle_month_rotate_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 2) break;
                    if (charCode >= 0 && charCode < 10) { 
                      idle_month_TextRotate[index].setProperty(hmUI.prop.POS_X, 99 + img_offset);
                      idle_month_TextRotate[index].setProperty(hmUI.prop.SRC, idle_month_TextRotate_ASCIIARRAY[charCode]);
                      idle_month_TextRotate[index].setProperty(hmUI.prop.VISIBLE, true);
                      img_offset += idle_month_TextRotate_img_width;
                      index++;
                    };  // end if digit
                  };  // end char of string
                }  // end isFinite

              };

              console.log('update text rotate year_TIME');
              let idle_year_rotate_string = parseInt(valueYear).toString();

              if (screenType == hmSetting.screen_type.AOD) {
                for (var i = 1; i < 4; i++) {  // hide all symbols
                  idle_year_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                if (valueYear != null && valueYear != undefined && isFinite(valueYear) && idle_year_rotate_string.length > 0 && idle_year_rotate_string.length < 6) {  // display data if it was possible to get it
                  let img_offset = 0;
                  
                  let index = 0;
                  for (let char of idle_year_rotate_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 4) break;
                    if (charCode >= 0 && charCode < 10) { 
                      idle_year_TextRotate[index].setProperty(hmUI.prop.POS_X, 77 + img_offset);
                      idle_year_TextRotate[index].setProperty(hmUI.prop.SRC, idle_year_TextRotate_ASCIIARRAY[charCode]);
                      idle_year_TextRotate[index].setProperty(hmUI.prop.VISIBLE, true);
                      img_offset += idle_year_TextRotate_img_width;
                      index++;
                    };  // end if digit
                  };  // end char of string
                }  // end isFinite

              };

              console.log('update text rotate day_TIME');
              let idle_day_rotate_string = parseInt(valueDay).toString();
              idle_day_rotate_string = idle_day_rotate_string.padStart(2, '0');

              if (screenType == hmSetting.screen_type.AOD) {
                for (var i = 1; i < 2; i++) {  // hide all symbols
                  idle_day_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                idle_day_TextRotate_unit.setProperty(hmUI.prop.VISIBLE, false);
                if (valueDay != null && valueDay != undefined && isFinite(valueDay) && idle_day_rotate_string.length > 0 && idle_day_rotate_string.length < 6) {  // display data if it was possible to get it
                  let img_offset = 0;
                  
                  let index = 0;
                  for (let char of idle_day_rotate_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 2) break;
                    if (charCode >= 0 && charCode < 10) { 
                      idle_day_TextRotate[index].setProperty(hmUI.prop.POS_X, 43 + img_offset);
                      idle_day_TextRotate[index].setProperty(hmUI.prop.SRC, idle_day_TextRotate_ASCIIARRAY[charCode]);
                      idle_day_TextRotate[index].setProperty(hmUI.prop.VISIBLE, true);
                      img_offset += idle_day_TextRotate_img_width + 2;
                      index++;
                    };  // end if digit
                  };  // end char of string
                  idle_day_TextRotate_unit.setProperty(hmUI.prop.POS_X, 43 + img_offset);
                  idle_day_TextRotate_unit.setProperty(hmUI.prop.VISIBLE, true);
                }  // end isFinite

              };

              console.log('update text rotate hour_TIME');
              let idle_hour_rotate_string = parseInt(valueHour).toString();
              idle_hour_rotate_string = idle_hour_rotate_string.padStart(2, '0');

              if (screenType == hmSetting.screen_type.AOD) {
                for (var i = 1; i < 2; i++) {  // hide all symbols
                  idle_hour_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                idle_hour_TextRotate_unit.setProperty(hmUI.prop.VISIBLE, false);
                if (valueHour != null && valueHour != undefined && isFinite(valueHour) && idle_hour_rotate_string.length > 0 && idle_hour_rotate_string.length < 6) {  // display data if it was possible to get it
                  let img_offset = 0;
                  
                  let index = 0;
                  for (let char of idle_hour_rotate_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 2) break;
                    if (charCode >= 0 && charCode < 10) { 
                      idle_hour_TextRotate[index].setProperty(hmUI.prop.POS_X, 308 + img_offset);
                      idle_hour_TextRotate[index].setProperty(hmUI.prop.SRC, idle_hour_TextRotate_ASCIIARRAY[charCode]);
                      idle_hour_TextRotate[index].setProperty(hmUI.prop.VISIBLE, true);
                      img_offset += idle_hour_TextRotate_img_width;
                      index++;
                    };  // end if digit
                  };  // end char of string
                  idle_hour_TextRotate_unit.setProperty(hmUI.prop.POS_X, 308 + img_offset);
                  idle_hour_TextRotate_unit.setProperty(hmUI.prop.VISIBLE, true);
                }  // end isFinite

              };

              console.log('update text rotate minute_TIME');
              let idle_minute_rotate_string = parseInt(valueMinute).toString();
              idle_minute_rotate_string = idle_minute_rotate_string.padStart(2, '0');

              if (screenType == hmSetting.screen_type.AOD) {
                for (var i = 1; i < 2; i++) {  // hide all symbols
                  idle_minute_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                if (valueMinute != null && valueMinute != undefined && isFinite(valueMinute) && idle_minute_rotate_string.length > 0 && idle_minute_rotate_string.length < 6) {  // display data if it was possible to get it
                  let img_offset = 0;
                  
                  let index = 0;
                  for (let char of idle_minute_rotate_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 2) break;
                    if (charCode >= 0 && charCode < 10) { 
                      idle_minute_TextRotate[index].setProperty(hmUI.prop.POS_X, 382 + img_offset);
                      idle_minute_TextRotate[index].setProperty(hmUI.prop.SRC, idle_minute_TextRotate_ASCIIARRAY[charCode]);
                      idle_minute_TextRotate[index].setProperty(hmUI.prop.VISIBLE, true);
                      img_offset += idle_minute_TextRotate_img_width;
                      index++;
                    };  // end if digit
                  };  // end char of string
                }  // end isFinite

              };

            };

            function scale_call() {

              console.log('Weather city name');
              let weatherData = weatherSensor.getForecastWeather();
              normal_city_name_text.setProperty(hmUI.prop.TEXT, weatherData.cityName);

            };

            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                scale_call();
                time_update(true, true);
                text_update();
                if (screenType == hmSetting.screen_type.WATCHFACE) {
                  if (!normal_timerTextUpdate) {
                    normal_timerTextUpdate = timer.createTimer(0, 1000, (function (option) {
                      text_update();
                    }));  // end timer 
                  };  // end timer check
                };  // end screenType

                if (screenType == hmSetting.screen_type.WATCHFACE) {
                  if (!normal_timerUpdateSec) {
                    let animDelay = timeSensor.utc % 1000;
                    let animRepeat = 1000;
                    normal_timerUpdateSec = timer.createTimer(animDelay, animRepeat, (function (option) {
                      time_update(false, true);
                    }));  // end timer 
                  };  // end timer check
                };  // end screenType

                if (screenType == hmSetting.screen_type.WATCHFACE) {
                  if (!normal_timerUpdateSecSmooth) {
                    let animDelay = 0;
                    let animRepeat = 1000/15;
                    normal_timerUpdateSecSmooth = timer.createTimer(animDelay, animRepeat, (function (option) {
                      time_update(false, false);
                    }));  // end timer 
                  };  // end timer check
                };  // end screenType

                if (screenType == hmSetting.screen_type.AOD) {
                  if (!idle_timerTextUpdate) {
                    idle_timerTextUpdate = timer.createTimer(0, 1000, (function (option) {
                      text_update();
                    }));  // end timer 
                  };  // end timer check
                };  // end screenType

                if (screenType == hmSetting.screen_type.AOD) {
                  if (!idle_timerUpdateSec) {
                    let animDelay = timeSensor.utc % 1000;
                    let animRepeat = 1000;
                    idle_timerUpdateSec = timer.createTimer(animDelay, animRepeat, (function (option) {
                      time_update(false, true);
                    }));  // end timer 
                  };  // end timer check
                };  // end screenType

                if (screenType == hmSetting.screen_type.AOD) {
                  if (!idle_timerUpdateSecSmooth) {
                    let animDelay = 0;
                    let animRepeat = 1000/15;
                    idle_timerUpdateSecSmooth = timer.createTimer(animDelay, animRepeat, (function (option) {
                      time_update(false, false);
                    }));  // end timer 
                  };  // end timer check
                };  // end screenType

                checkConnection();
                stopVibro();

              }),
              pause_call: (function () {
                if (normal_timerTextUpdate) {
                  timer.stopTimer(normal_timerTextUpdate);
                  normal_timerTextUpdate = undefined;
                }
                if (normal_timerUpdateSec) {
                  timer.stopTimer(normal_timerUpdateSec);
                  normal_timerUpdateSec = undefined;
                }
                if (normal_timerUpdateSecSmooth) {
                  timer.stopTimer(normal_timerUpdateSecSmooth);
                  normal_timerUpdateSecSmooth = undefined;
                }
                if (idle_timerTextUpdate) {
                  timer.stopTimer(idle_timerTextUpdate);
                  idle_timerTextUpdate = undefined;
                }
                if (idle_timerUpdateSec) {
                  timer.stopTimer(idle_timerUpdateSec);
                  idle_timerUpdateSec = undefined;
                }
                if (idle_timerUpdateSecSmooth) {
                  timer.stopTimer(idle_timerUpdateSecSmooth);
                  idle_timerUpdateSecSmooth = undefined;
                }
                stopVibro();

              }),
            });

                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}