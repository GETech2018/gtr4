﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        const logger = Logger.getLogger('watchface_SashaCX75');
        //end of ignored block

        //dynamic modify start

        
        let normal_background_bg = ''
        let normal_analog_clock_time_pointer_smooth_second = ''
        let normal_system_disconnect_img = ''
        let normal_pai_icon_img = ''
        let normal_date_img_date_year = ''
        let normal_date_img_date_month = ''
        let normal_date_img_date_week_img = ''
        let normal_date_img_date_day = ''
        let normal_moon_high_text_img = ''
        let normal_moon_high_separator_img = ''
        let normal_moon_low_text_img = ''
        let normal_moon_low_separator_img = ''
        let normal_moon_image_progress_img_level = ''
        let normal_analog_clock_time_pointer_hour = ''
        let normal_analog_clock_time_pointer_minute = ''
        let normal_analog_clock_time_pointer_second = ''


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            console.log('Watch_Face.ScreenNormal');
            normal_background_bg = hmUI.createWidget(hmUI.widget.FILL_RECT, {
              x: 0,
              y: 0,
              w: 466,
              h: 466,
              color: '0xFF000000',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_analog_clock_pro_second_pointer_img = hmUI.createWidget(hmUI.widget.TIME_POINTER_PRO, {
              // src: 'A100_109.png',
              // center_x: 233,
              // center_y: 233,
              // x: 233,
              // y: 233,
              // start_angle: 0,
              // end_angle: 360,
              // type: hmUI.data_type.second,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });


            normal_analog_clock_time_pointer_smooth_second = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              second_path: 'A100_109.png',
              second_centerX: 233,
              second_centerY: 233,
              second_posX: 233,
              second_posY: 233,
              fresh_frequency: 15,
              fresh_freqency: 15,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_analog_clock_pro_smooth_second = hmUI.createWidget(hmUI.widget.SMOOTH_SECOND, {
              // type: 3,
              // fps: 15,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });


            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 121,
              y: 228,
              src: 'bt.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_pai_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'A100_093.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_year = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              year_startX: 260,
              year_startY: 131,
              year_sc_array: ["font_0.png","font_1.png","font_2.png","font_3.png","font_4.png","font_5.png","font_6.png","font_7.png","font_8.png","font_9.png"],
              year_tc_array: ["font_0.png","font_1.png","font_2.png","font_3.png","font_4.png","font_5.png","font_6.png","font_7.png","font_8.png","font_9.png"],
              year_en_array: ["font_0.png","font_1.png","font_2.png","font_3.png","font_4.png","font_5.png","font_6.png","font_7.png","font_8.png","font_9.png"],
              year_zero: 0,
              year_space: 0,
              year_align: hmUI.align.CENTER_H,
              year_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_month = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 216,
              month_startY: 131,
              month_sc_array: ["font_0.png","font_1.png","font_2.png","font_3.png","font_4.png","font_5.png","font_6.png","font_7.png","font_8.png","font_9.png"],
              month_tc_array: ["font_0.png","font_1.png","font_2.png","font_3.png","font_4.png","font_5.png","font_6.png","font_7.png","font_8.png","font_9.png"],
              month_en_array: ["font_0.png","font_1.png","font_2.png","font_3.png","font_4.png","font_5.png","font_6.png","font_7.png","font_8.png","font_9.png"],
              month_zero: 1,
              month_space: 0,
              month_unit_sc: 'dian.png',
              month_unit_tc: 'dian.png',
              month_unit_en: 'dian.png',
              month_align: hmUI.align.CENTER_H,
              month_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 177,
              y: 163,
              week_en: ["week_0.png","week_1.png","week_2.png","week_3.png","week_4.png","week_5.png","week_6.png"],
              week_tc: ["week_0.png","week_1.png","week_2.png","week_3.png","week_4.png","week_5.png","week_6.png"],
              week_sc: ["week_0.png","week_1.png","week_2.png","week_3.png","week_4.png","week_5.png","week_6.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 174,
              day_startY: 131,
              day_sc_array: ["font_0.png","font_1.png","font_2.png","font_3.png","font_4.png","font_5.png","font_6.png","font_7.png","font_8.png","font_9.png"],
              day_tc_array: ["font_0.png","font_1.png","font_2.png","font_3.png","font_4.png","font_5.png","font_6.png","font_7.png","font_8.png","font_9.png"],
              day_en_array: ["font_0.png","font_1.png","font_2.png","font_3.png","font_4.png","font_5.png","font_6.png","font_7.png","font_8.png","font_9.png"],
              day_zero: 1,
              day_space: 0,
              day_unit_sc: 'dian.png',
              day_unit_tc: 'dian.png',
              day_unit_en: 'dian.png',
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_moon_high_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 44,
              y: 201,
              font_array: ["font_0.png","font_1.png","font_2.png","font_3.png","font_4.png","font_5.png","font_6.png","font_7.png","font_8.png","font_9.png"],
              padding: false,
              h_space: 0,
              dot_image: 'dots.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.MOON_RISE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_moon_high_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 60,
              y: 165,
              src: 'Moon Rise.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_moon_low_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 356,
              y: 201,
              font_array: ["font_0.png","font_1.png","font_2.png","font_3.png","font_4.png","font_5.png","font_6.png","font_7.png","font_8.png","font_9.png"],
              padding: false,
              h_space: 0,
              dot_image: 'dots.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.MOON_SET,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_moon_low_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 374,
              y: 165,
              src: 'Moon Set.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_moon_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 199,
              y: 53,
              image_array: ["moon_0.png","moon_01.png","moon_02.png","moon_03.png","moon_04.png","moon_05.png","moon_06.png","moon_07.png","moon_08.png","moon_09.png","moon_11.png","moon_12.png","moon_13.png","moon_14.png","moon_15.png","moon_16.png","moon_17.png","moon_18.png","moon_19.png","moon_20.png","moon_21.png","moon_22.png","moon_23.png","moon_24.png","moon_25.png","moon_26.png","moon_27.png","moon_28.png","moon_29.png","moon_30.png"],
              image_length: 30,
              type: hmUI.data_type.MOON,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_hour = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              hour_path: 'A100_003.png',
              hour_centerX: 233,
              hour_centerY: 233,
              hour_posX: 15,
              hour_posY: 225,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_minute = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              minute_path: 'A100_102.png',
              minute_centerX: 233,
              minute_centerY: 233,
              minute_posX: 15,
              minute_posY: 225,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_second = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              second_path: 'A100_002.png',
              second_centerX: 233,
              second_centerY: 233,
              second_posX: 15,
              second_posY: 222,
              second_cover_path: 'A100_065.png',
              second_cover_x: 216,
              second_cover_y: 216,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });




                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}