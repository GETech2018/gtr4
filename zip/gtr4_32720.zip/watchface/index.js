﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.0.1
    ** Copyright © CashaCX75. All Rights Reserved
    */

    try {
    (()=>{
        //dynamic modify start

        
        let editBg = ''
        let normal_date_img_date_year = ''
        let normal_uvi_text_text_img = ''
        let normal_date_img_date_month = ''
        let normal_date_month_separator_img = ''
        let normal_date_img_date_day = ''
        let normal_date_day_separator_img = ''
        let normal_sun_high_text_img = ''
        let normal_sun_low_text_img = ''
        let normal_moon_image_progress_img_level = ''
        let normal_battery_text_text_img = ''
        let normal_altimeter_text_text_img = ''
        let normal_humidity_text_text_img = ''
        let normal_temperature_high_text_img = ''
        let normal_temperature_high_separator_img = ''
        let normal_temperature_low_text_img = ''
        let normal_temperature_current_text_img = ''
        let normal_temperature_current_separator_img = ''
        let normal_weather_image_progress_img_level = ''
        let normal_heart_rate_text_text_img = ''
        let normal_distance_text_text_img = ''
        let normal_calorie_current_text_img = ''
        let normal_step_current_text_img = ''
        let normal_digital_clock_img_time = ''
        let normal_digital_clock_hour_separator_img = ''
        let normal_digital_clock_minute_separator_img = ''
        let idle_battery_text_text_img = ''
        let idle_battery_image_progress_img_level = ''
        let idle_digital_clock_img_time = ''
        let idle_digital_clock_hour_separator_img = ''
        let normal_stopwatch_jumpable_img_click = ''
        let normal_countdown_jumpable_img_click = ''
        let normal_sleep_jumpable_img_click = ''
        let normal_alarm_jumpable_img_click = ''
        let normal_sunrise_jumpable_img_click = ''
        let normal_altimeter_jumpable_img_click = ''
        let normal_temperature_jumpable_img_click = ''
        let normal_pai_jumpable_img_click = ''
        let normal_heart_jumpable_img_click = ''
        let normal_step_jumpable_img_click = ''


        //dynamic modify end
        const e = __$$hmAppManager$$__.currentApp;
        const o = e.current
          , {px: i} = (new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(e,o)),
        e.__globals__)
          , n = Logger.getLogger("watchface6");
        o.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            editBg = hmUI.createWidget(hmUI.widget.WATCHFACE_EDIT_BG, {
              edit_id: 1002,
              x: 0,
              y: 0,
              // w: 466,
              // h: 466,
              // AOD_show: False,
              bg_config: [
                { id: 1, preview: 'bg_edit_1_preview.png', path: 'Background.png' },
                { id: 2, preview: 'bg_edit_2_preview.png', path: 'Background2.png' },
                { id: 3, preview: 'bg_edit_3_preview.png', path: 'Background3.png' },
                { id: 4, preview: 'bg_edit_4_preview.png', path: 'Background4.png' },
                { id: 5, preview: 'bg_edit_5_preview.png', path: 'Background5.png' },
                { id: 6, preview: 'bg_edit_6_preview.png', path: 'Background6.png' },
                { id: 7, preview: 'bg_edit_7_preview.png', path: 'Background7.png' },
                { id: 8, preview: 'bg_edit_8_preview.png', path: 'Background8.png' },
                { id: 9, preview: 'bg_edit_9_preview.png', path: 'Background9.png' },
              ],
              count: 9,
              default_id: 1,
              fg: 'MANU.png',
              tips_bg: '.png',
              tips_x: 186,
              tips_y: 167,
              show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_EDIT,
            });

            normal_date_img_date_year = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              year_startX: 155,
              year_startY: 133,
              year_sc_array: ["digsmall_00.png","digsmall_01.png","digsmall_02.png","digsmall_03.png","digsmall_04.png","digsmall_05.png","digsmall_06.png","digsmall_07.png","digsmall_08.png","digsmall_09.png"],
              year_tc_array: ["digsmall_00.png","digsmall_01.png","digsmall_02.png","digsmall_03.png","digsmall_04.png","digsmall_05.png","digsmall_06.png","digsmall_07.png","digsmall_08.png","digsmall_09.png"],
              year_en_array: ["digsmall_00.png","digsmall_01.png","digsmall_02.png","digsmall_03.png","digsmall_04.png","digsmall_05.png","digsmall_06.png","digsmall_07.png","digsmall_08.png","digsmall_09.png"],
              year_zero: 1,
              year_space: 0,
              year_align: hmUI.align.CENTER_H,
              year_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_uvi_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 300,
              y: 380,
              font_array: ["digsmall_00.png","digsmall_01.png","digsmall_02.png","digsmall_03.png","digsmall_04.png","digsmall_05.png","digsmall_06.png","digsmall_07.png","digsmall_08.png","digsmall_09.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.UVI,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_month = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 104,
              month_startY: 133,
              month_sc_array: ["digsmall_00.png","digsmall_01.png","digsmall_02.png","digsmall_03.png","digsmall_04.png","digsmall_05.png","digsmall_06.png","digsmall_07.png","digsmall_08.png","digsmall_09.png"],
              month_tc_array: ["digsmall_00.png","digsmall_01.png","digsmall_02.png","digsmall_03.png","digsmall_04.png","digsmall_05.png","digsmall_06.png","digsmall_07.png","digsmall_08.png","digsmall_09.png"],
              month_en_array: ["digsmall_00.png","digsmall_01.png","digsmall_02.png","digsmall_03.png","digsmall_04.png","digsmall_05.png","digsmall_06.png","digsmall_07.png","digsmall_08.png","digsmall_09.png"],
              month_zero: 0,
              month_space: 0,
              month_align: hmUI.align.CENTER_H,
              month_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_month_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 138,
              y: 133,
              src: 'digsmall_min.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 58,
              day_startY: 133,
              day_sc_array: ["digsmall_00.png","digsmall_01.png","digsmall_02.png","digsmall_03.png","digsmall_04.png","digsmall_05.png","digsmall_06.png","digsmall_07.png","digsmall_08.png","digsmall_09.png"],
              day_tc_array: ["digsmall_00.png","digsmall_01.png","digsmall_02.png","digsmall_03.png","digsmall_04.png","digsmall_05.png","digsmall_06.png","digsmall_07.png","digsmall_08.png","digsmall_09.png"],
              day_en_array: ["digsmall_00.png","digsmall_01.png","digsmall_02.png","digsmall_03.png","digsmall_04.png","digsmall_05.png","digsmall_06.png","digsmall_07.png","digsmall_08.png","digsmall_09.png"],
              day_zero: 0,
              day_space: 0,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_day_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 94,
              y: 133,
              src: 'digsmall_min.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sun_high_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 242,
              y: 132,
              font_array: ["digsmall_00.png","digsmall_01.png","digsmall_02.png","digsmall_03.png","digsmall_04.png","digsmall_05.png","digsmall_06.png","digsmall_07.png","digsmall_08.png","digsmall_09.png"],
              padding: false,
              h_space: 0,
              dot_image: 'digsmall_10.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.SUN_RISE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sun_low_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 336,
              y: 132,
              font_array: ["digsmall_00.png","digsmall_01.png","digsmall_02.png","digsmall_03.png","digsmall_04.png","digsmall_05.png","digsmall_06.png","digsmall_07.png","digsmall_08.png","digsmall_09.png"],
              padding: false,
              h_space: 0,
              dot_image: 'digsmall_10.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.SUN_SET,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_moon_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 257,
              y: 28,
              image_array: ["Moon_01.png","Moon_02.png","Moon_03.png","Moon_04.png","Moon_05.png","Moon_06.png","Moon_07.png","Moon_08.png","Moon_09.png","Moon_10.png","Moon_11.png","Moon_12.png","Moon_13.png","Moon_14.png","Moon_15.png","Moon_16.png","Moon_17.png","Moon_18.png","Moon_19.png","Moon_20.png","Moon_21.png","Moon_22.png","Moon_23.png","Moon_24.png","Moon_25.png","Moon_26.png","Moon_27.png","Moon_28.png","Moon_29.png","Moon_30.png"],
              image_length: 30,
              type: hmUI.data_type.MOON,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 205,
              y: 437,
              font_array: ["digsmall_00.png","digsmall_01.png","digsmall_02.png","digsmall_03.png","digsmall_04.png","digsmall_05.png","digsmall_06.png","digsmall_07.png","digsmall_08.png","digsmall_09.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_altimeter_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 198,
              y: 379,
              font_array: ["digsmall_00.png","digsmall_01.png","digsmall_02.png","digsmall_03.png","digsmall_04.png","digsmall_05.png","digsmall_06.png","digsmall_07.png","digsmall_08.png","digsmall_09.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.ALTIMETER,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_humidity_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 111,
              y: 379,
              font_array: ["digsmall_00.png","digsmall_01.png","digsmall_02.png","digsmall_03.png","digsmall_04.png","digsmall_05.png","digsmall_06.png","digsmall_07.png","digsmall_08.png","digsmall_09.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.HUMIDITY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_high_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 95,
              y: 88,
              font_array: ["digsmall_00.png","digsmall_01.png","digsmall_02.png","digsmall_03.png","digsmall_04.png","digsmall_05.png","digsmall_06.png","digsmall_07.png","digsmall_08.png","digsmall_09.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'digsmall_11.png',
              unit_tc: 'digsmall_11.png',
              unit_en: 'digsmall_11.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_HIGH,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_high_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'digsmall_11.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_low_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 163,
              y: 87,
              font_array: ["digsmall_00.png","digsmall_01.png","digsmall_02.png","digsmall_03.png","digsmall_04.png","digsmall_05.png","digsmall_06.png","digsmall_07.png","digsmall_08.png","digsmall_09.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'digsmall_11.png',
              unit_tc: 'digsmall_11.png',
              unit_en: 'digsmall_11.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_LOW,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 114,
              y: 43,
              font_array: ["digsmall_00.png","digsmall_01.png","digsmall_02.png","digsmall_03.png","digsmall_04.png","digsmall_05.png","digsmall_06.png","digsmall_07.png","digsmall_08.png","digsmall_09.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'digsmall_11.png',
              unit_tc: 'digsmall_11.png',
              unit_en: 'digsmall_11.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'digsmall_11.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 164,
              y: 29,
              image_array: ["weat_01.png","weat_02.png","weat_03.png","weat_04.png","weat_05.png","weat_06.png","weat_07.png","weat_08.png","weat_09.png","weat_10.png","weat_11.png","weat_12.png","weat_13.png","weat_14.png","weat_15.png","weat_16.png","weat_17.png","weat_18.png","weat_19.png","weat_20.png","weat_21.png","weat_22.png","weat_23.png","weat_24.png","weat_25.png","weat_26.png","weat_27.png","weat_28.png","weat_29.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 330,
              y: 318,
              font_array: ["digsmall_00.png","digsmall_01.png","digsmall_02.png","digsmall_03.png","digsmall_04.png","digsmall_05.png","digsmall_06.png","digsmall_07.png","digsmall_08.png","digsmall_09.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_distance_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 156,
              y: 319,
              font_array: ["digsmall_00.png","digsmall_01.png","digsmall_02.png","digsmall_03.png","digsmall_04.png","digsmall_05.png","digsmall_06.png","digsmall_07.png","digsmall_08.png","digsmall_09.png"],
              padding: false,
              h_space: 0,
              dot_image: 'digsmall_10.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.DISTANCE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_calorie_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 245,
              y: 319,
              font_array: ["digsmall_00.png","digsmall_01.png","digsmall_02.png","digsmall_03.png","digsmall_04.png","digsmall_05.png","digsmall_06.png","digsmall_07.png","digsmall_08.png","digsmall_09.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 60,
              y: 319,
              font_array: ["digsmall_00.png","digsmall_01.png","digsmall_02.png","digsmall_03.png","digsmall_04.png","digsmall_05.png","digsmall_06.png","digsmall_07.png","digsmall_08.png","digsmall_09.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 13,
              hour_startY: 175,
              hour_array: ["H012.png","H013.png","H014.png","H015.png","H016.png","H017.png","H018.png","H019.png","H020.png","H021.png"],
              hour_zero: 1,
              hour_space: 0,
              hour_align: hmUI.align.CENTER_H,

              minute_startX: 166,
              minute_startY: 175,
              minute_array: ["H012.png","H013.png","H014.png","H015.png","H016.png","H017.png","H018.png","H019.png","H020.png","H021.png"],
              minute_zero: 1,
              minute_space: 0,
              minute_follow: 0,
              minute_align: hmUI.align.CENTER_H,

              second_startX: 318,
              second_startY: 175,
              second_array: ["H012.png","H013.png","H014.png","H015.png","H016.png","H017.png","H018.png","H019.png","H020.png","H021.png"],
              second_zero: 1,
              second_space: 0,
              second_follow: 0,
              second_align: hmUI.align.CENTER_H,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_hour_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 149,
              y: 199,
              src: '022.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_minute_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 300,
              y: 199,
              src: '022.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });



            idle_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 209,
              y: 415,
              font_array: ["digsmall_00.png","digsmall_01.png","digsmall_02.png","digsmall_03.png","digsmall_04.png","digsmall_05.png","digsmall_06.png","digsmall_07.png","digsmall_08.png","digsmall_09.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_battery_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 224,
              y: 377,
              image_array: ["120.png","121.png","122.png","123.png","124.png","125.png","126.png","127.png"],
              image_length: 8,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 78,
              hour_startY: 184,
              hour_array: ["H012.png","H013.png","H014.png","H015.png","H016.png","H017.png","H018.png","H019.png","H020.png","H021.png"],
              hour_zero: 1,
              hour_space: 0,
              hour_align: hmUI.align.CENTER_H,

              minute_startX: 248,
              minute_startY: 184,
              minute_array: ["H012.png","H013.png","H014.png","H015.png","H016.png","H017.png","H018.png","H019.png","H020.png","H021.png"],
              minute_zero: 1,
              minute_space: 0,
              minute_follow: 0,
              minute_align: hmUI.align.CENTER_H,

              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_hour_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 222,
              y: 207,
              src: '022.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            normal_stopwatch_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: -1,
              y: 174,
              w: 154,
              h: 104,
              src: 'transparent.png',
              type: hmUI.data_type.STOP_WATCH,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_countdown_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 321,
              y: 168,
              w: 200,
              h: 120,
              src: 'transparent.png',
              type: hmUI.data_type.COUNT_DOWN,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sleep_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 182,
              y: 406,
              w: 100,
              h: 100,
              src: 'transparent.png',
              type: hmUI.data_type.SLEEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_alarm_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 163,
              y: 174,
              w: 156,
              h: 106,
              src: 'transparent.png',
              type: hmUI.data_type.ALARM_CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sunrise_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 238,
              y: 29,
              w: 186,
              h: 133,
              src: 'transparent.png',
              type: hmUI.data_type.SUN_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_altimeter_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 183,
              y: 356,
              w: 100,
              h: 50,
              src: 'transparent.png',
              type: hmUI.data_type.ALTIMETER,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 30,
              y: -39,
              w: 200,
              h: 200,
              src: 'transparent.png',
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_pai_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 236,
              y: 293,
              w: 85,
              h: 55,
              src: 'transparent.png',
              type: hmUI.data_type.PAI_WEEKLY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 321,
              y: 290,
              w: 92,
              h: 58,
              src: 'transparent.png',
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 55,
              y: 290,
              w: 174,
              h: 58,
              src: 'transparent.png',
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


                //dynamic modify end
            },
            onInit() {
                n.log("index page.js on init invoke")
            },
            build() {
                this.init_view(),
                n.log("index page.js on ready invoke")
            },
            onDestroy() {
                n.log("index page.js on destroy invoke")
            }
        })
    }
    )()
} catch (e) {
    console.log("Mini Program Error", e),
    e && e.stack && e.stack.split(/\n/).forEach((e=>console.log("error stack", e)))
}
