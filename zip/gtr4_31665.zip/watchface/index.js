﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.0.1
    ** Copyright © CashaCX75. All Rights Reserved
    */

    try {
    (()=>{
        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_system_disconnect_img = ''
        let normal_battery_text_text_img = ''
        let normal_heart_rate_text_text_img = ''
        let normal_date_img_date_day = ''
        let normal_date_img_date_week_img = ''
        let normal_digital_clock_img_time = ''
        let idle_background_bg_img = ''
        let idle_system_disconnect_img = ''
        let idle_battery_text_text_img = ''
        let idle_heart_rate_text_text_img = ''
        let idle_date_img_date_day = ''
        let idle_date_img_date_week_img = ''
        let idle_digital_clock_img_time = ''
        let normal_heart_jumpable_img_click = ''
        let normal_step_jumpable_img_click = ''


        //dynamic modify end
        const e = __$$hmAppManager$$__.currentApp;
        const o = e.current
          , {px: i} = (new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(e,o)),
        e.__globals__)
          , n = Logger.getLogger("watchface6");
        o.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 466,
              h: 466,
              src: 'bg.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 388,
              y: 311,
              src: '0213.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 188,
              y: 430,
              font_array: ["D000.png","D001.png","D002.png","D003.png","D004.png","D005.png","D006.png","D007.png","D008.png","D009.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 191,
              y: 3,
              font_array: ["D000.png","D001.png","D002.png","D003.png","D004.png","D005.png","D006.png","D007.png","D008.png","D009.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 424,
              day_startY: 214,
              day_sc_array: ["D000.png","D001.png","D002.png","D003.png","D004.png","D005.png","D006.png","D007.png","D008.png","D009.png"],
              day_tc_array: ["D000.png","D001.png","D002.png","D003.png","D004.png","D005.png","D006.png","D007.png","D008.png","D009.png"],
              day_en_array: ["D000.png","D001.png","D002.png","D003.png","D004.png","D005.png","D006.png","D007.png","D008.png","D009.png"],
              day_zero: 0,
              day_space: 0,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 395,
              y: 165,
              week_en: ["ED001.png","ED002.png","ED003.png","ED004.png","ED005.png","ED006.png","ED007.png"],
              week_tc: ["ED001.png","ED002.png","ED003.png","ED004.png","ED005.png","ED006.png","ED007.png"],
              week_sc: ["ED001.png","ED002.png","ED003.png","ED004.png","ED005.png","ED006.png","ED007.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 79,
              hour_startY: 44,
              hour_array: ["o000.png","o001.png","o002.png","o003.png","o004.png","o005.png","o006.png","o007.png","o008.png","o009.png"],
              hour_zero: 1,
              hour_space: -2,
              hour_align: hmUI.align.LEFT,

              minute_startX: 83,
              minute_startY: 229,
              minute_array: ["l000.png","l001.png","l002.png","l003.png","l004.png","l005.png","l006.png","l007.png","l008.png","l009.png"],
              minute_zero: 1,
              minute_space: -5,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            idle_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 466,
              h: 466,
              src: 'aodbg.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 388,
              y: 311,
              src: '0213.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 188,
              y: 430,
              font_array: ["D000.png","D001.png","D002.png","D003.png","D004.png","D005.png","D006.png","D007.png","D008.png","D009.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 191,
              y: 3,
              font_array: ["D000.png","D001.png","D002.png","D003.png","D004.png","D005.png","D006.png","D007.png","D008.png","D009.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 424,
              day_startY: 214,
              day_sc_array: ["D000.png","D001.png","D002.png","D003.png","D004.png","D005.png","D006.png","D007.png","D008.png","D009.png"],
              day_tc_array: ["D000.png","D001.png","D002.png","D003.png","D004.png","D005.png","D006.png","D007.png","D008.png","D009.png"],
              day_en_array: ["D000.png","D001.png","D002.png","D003.png","D004.png","D005.png","D006.png","D007.png","D008.png","D009.png"],
              day_zero: 0,
              day_space: 0,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 395,
              y: 165,
              week_en: ["ED001.png","ED002.png","ED003.png","ED004.png","ED005.png","ED006.png","ED007.png"],
              week_tc: ["ED001.png","ED002.png","ED003.png","ED004.png","ED005.png","ED006.png","ED007.png"],
              week_sc: ["ED001.png","ED002.png","ED003.png","ED004.png","ED005.png","ED006.png","ED007.png"],
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 79,
              hour_startY: 44,
              hour_array: ["oaod000.png","oaod001.png","oaod002.png","oaod003.png","oaod004.png","oaod005.png","oaod006.png","oaod007.png","oaod008.png","oaod009.png"],
              hour_zero: 1,
              hour_space: -5,
              hour_align: hmUI.align.LEFT,

              minute_startX: 83,
              minute_startY: 229,
              minute_array: ["laod000.png","laod001.png","laod002.png","laod003.png","laod004.png","laod005.png","laod006.png","laod007.png","laod008.png","laod009.png"],
              minute_zero: 1,
              minute_space: -5,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_AOD,
            });

            normal_heart_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 174,
              y: 1,
              w: 118,
              h: 34,
              src: 'transparent_img.png',
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 4,
              y: 158,
              w: 56,
              h: 151,
              src: 'transparent_img.png',
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


                //dynamic modify end
            },
            onInit() {
                n.log("index page.js on init invoke")
            },
            build() {
                this.init_view(),
                n.log("index page.js on ready invoke")
            },
            onDestroy() {
                n.log("index page.js on destroy invoke")
            }
        })
    }
    )()
} catch (e) {
    console.log("Mini Program Error", e),
    e && e.stack && e.stack.split(/\n/).forEach((e=>console.log("error stack", e)))
}
