﻿    /*
    ** Watch_Face_Editor tool v 18.2
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        //const logger = Logger.getLogger('watchface_SashaCX75');
        const logger = DeviceRuntimeCore.HmLogger.getLogger('watchface_SashaCX75')
        //end of ignored block

        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_date_img_date_week_img = ''
        let normal_date_img_date_day = ''
        let normal_date_img_date_month_img = ''
        let normal_battery_text_text_img = ''
        let normal_heart_rate_text_text_img = ''
        let normal_step_current_text_img = ''
        let normal_digital_clock_img_time_second = ''
        let normal_digital_clock_img_time_minute = ''
        let normal_digital_clock_img_time_hour = ''
        let idle_background_bg_img = ''
        let idle_date_img_date_week_img = ''
        let idle_date_img_date_day = ''
        let idle_date_img_date_month_img = ''
        let idle_battery_text_text_img = ''
        let idle_heart_rate_text_text_img = ''
        let idle_step_current_text_img = ''
        let idle_digital_clock_img_time_minute = ''
        let idle_digital_clock_img_time_hour = ''
        let Button_Switch_BG = ''

        let backgroundIndex = 0;
        let backgroundList = ['Bg1.png', 'Bg2.png'];
        let backgroundToastList = ['Background %s', 'Background %s'];
        const watchfaceId = hmApp.packageInfo().watchfaceId;


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            //#region SwitchBackground
            console.log('SwitchBackground');
            function switchBackground() {
              backgroundIndex++;
              if (backgroundIndex >= backgroundList.length) backgroundIndex = 0;
              hmFS.SysProSetInt(`backgroundIndex_${watchfaceId}`, backgroundIndex);
              let toastText = backgroundToastList[backgroundIndex].replace('%s', `${backgroundIndex + 1}`);
              if (toastText.length > 0) hmUI.showToast({text: toastText});
              normal_background_bg_img.setProperty(hmUI.prop.SRC, backgroundList[backgroundIndex]);
if ( backgroundIndex==0){
           normal_date_img_date_week_img.setProperty(hmUI.prop.MORE, {
              x: 360,
              y: 277,
              week_en: ["Week_1.png","Week_2.png","Week_3.png","Week_4.png","Week_5.png","Week_6.png","Week_7.png"],
              week_tc: ["Week_1.png","Week_2.png","Week_3.png","Week_4.png","Week_5.png","Week_6.png","Week_7.png"],
              week_sc: ["Week_1.png","Week_2.png","Week_3.png","Week_4.png","Week_5.png","Week_6.png","Week_7.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day.setProperty(hmUI.prop.MORE, {
              day_startX: 316,
              day_startY: 277,
              day_sc_array: ["Act21_0.png","Act21_1.png","Act21_2.png","Act21_3.png","Act21_4.png","Act21_5.png","Act21_6.png","Act21_7.png","Act21_8.png","Act21_9.png"],
              day_tc_array: ["Act21_0.png","Act21_1.png","Act21_2.png","Act21_3.png","Act21_4.png","Act21_5.png","Act21_6.png","Act21_7.png","Act21_8.png","Act21_9.png"],
              day_en_array: ["Act21_0.png","Act21_1.png","Act21_2.png","Act21_3.png","Act21_4.png","Act21_5.png","Act21_6.png","Act21_7.png","Act21_8.png","Act21_9.png"],
              day_zero: 1,
              day_space: 0,
              day_align: hmUI.align.LEFT,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_month_img.setProperty(hmUI.prop.MORE, {
              month_startX: 257,
              month_startY: 277,
              month_sc_array: ["Month_01.png","Month_02.png","Month_03.png","Month_04.png","Month_05.png","Month_06.png","Month_07.png","Month_08.png","Month_09.png","Month_10.png","Month_11.png","Month_12.png"],
              month_tc_array: ["Month_01.png","Month_02.png","Month_03.png","Month_04.png","Month_05.png","Month_06.png","Month_07.png","Month_08.png","Month_09.png","Month_10.png","Month_11.png","Month_12.png"],
              month_en_array: ["Month_01.png","Month_02.png","Month_03.png","Month_04.png","Month_05.png","Month_06.png","Month_07.png","Month_08.png","Month_09.png","Month_10.png","Month_11.png","Month_12.png"],
              month_is_character: true ,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_text_img.setProperty(hmUI.prop.MORE, {
              x: 180,
              y: 275,
              font_array: ["Act21_0.png","Act21_1.png","Act21_2.png","Act21_3.png","Act21_4.png","Act21_5.png","Act21_6.png","Act21_7.png","Act21_8.png","Act21_9.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'Batt_Unit.png',
              unit_tc: 'Batt_Unit.png',
              unit_en: 'Batt_Unit.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_text_img.setProperty(hmUI.prop.MORE, {
              x: 372,
              y: 170,
              font_array: ["Act21_0.png","Act21_1.png","Act21_2.png","Act21_3.png","Act21_4.png","Act21_5.png","Act21_6.png","Act21_7.png","Act21_8.png","Act21_9.png"],
              padding: false,
              h_space: 2,
              invalid_image: 'Act21_0.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_text_img.setProperty(hmUI.prop.MORE, {
              x: 155,
              y: 170,
              font_array: ["Act21_0.png","Act21_1.png","Act21_2.png","Act21_3.png","Act21_4.png","Act21_5.png","Act21_6.png","Act21_7.png","Act21_8.png","Act21_9.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time_second.setProperty(hmUI.prop.MORE, {
              second_startX: 310,
              second_startY: 199,
              second_array: ["Time_0.png","Time_1.png","Time_2.png","Time_3.png","Time_4.png","Time_5.png","Time_6.png","Time_7.png","Time_8.png","Time_9.png"],
              second_zero: 1,
              second_space: 0,
              second_angle: 0,
              second_follow: 0,
              second_align: hmUI.align.LEFT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time_minute.setProperty(hmUI.prop.MORE, {
              minute_startX: 181,
              minute_startY: 199,
              minute_array: ["Time_0.png","Time_1.png","Time_2.png","Time_3.png","Time_4.png","Time_5.png","Time_6.png","Time_7.png","Time_8.png","Time_9.png"],
              minute_zero: 1,
              minute_space: 0,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time_hour.setProperty(hmUI.prop.MORE, {
              hour_startX: 52,
              hour_startY: 199,
              hour_array: ["Time_0.png","Time_1.png","Time_2.png","Time_3.png","Time_4.png","Time_5.png","Time_6.png","Time_7.png","Time_8.png","Time_9.png"],
              hour_zero: 1,
              hour_space: 0,
              hour_angle: 0,
              hour_align: hmUI.align.LEFT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
const result = hmSetting.setScreenOff()

}


if ( backgroundIndex==1){
           normal_date_img_date_week_img.setProperty(hmUI.prop.MORE, {
              x: 360,
              y: 277,
              week_en: ["Bg_Black/Week_1.png","Bg_Black/Week_2.png","Bg_Black/Week_3.png","Bg_Black/Week_4.png","Bg_Black/Week_5.png","Bg_Black/Week_6.png","Bg_Black/Week_7.png"],
              week_tc: ["Bg_Black/Week_1.png","Bg_Black/Week_2.png","Bg_Black/Week_3.png","Bg_Black/Week_4.png","Bg_Black/Week_5.png","Bg_Black/Week_6.png","Bg_Black/Week_7.png"],
              week_sc: ["Bg_Black/Week_1.png","Bg_Black/Week_2.png","Bg_Black/Week_3.png","Bg_Black/Week_4.png","Bg_Black/Week_5.png","Bg_Black/Week_6.png","Bg_Black/Week_7.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day.setProperty(hmUI.prop.MORE, {
              day_startX: 316,
              day_startY: 277,
              day_sc_array: ["Bg_Black/Act21_0.png","Bg_Black/Act21_1.png","Bg_Black/Act21_2.png","Bg_Black/Act21_3.png","Bg_Black/Act21_4.png","Bg_Black/Act21_5.png","Bg_Black/Act21_6.png","Bg_Black/Act21_7.png","Bg_Black/Act21_8.png","Bg_Black/Act21_9.png"],
              day_tc_array: ["Bg_Black/Act21_0.png","Bg_Black/Act21_1.png","Bg_Black/Act21_2.png","Bg_Black/Act21_3.png","Bg_Black/Act21_4.png","Bg_Black/Act21_5.png","Bg_Black/Act21_6.png","Bg_Black/Act21_7.png","Bg_Black/Act21_8.png","Bg_Black/Act21_9.png"],
              day_en_array: ["Bg_Black/Act21_0.png","Bg_Black/Act21_1.png","Bg_Black/Act21_2.png","Bg_Black/Act21_3.png","Bg_Black/Act21_4.png","Bg_Black/Act21_5.png","Bg_Black/Act21_6.png","Bg_Black/Act21_7.png","Bg_Black/Act21_8.png","Bg_Black/Act21_9.png"],
              day_zero: 1,
              day_space: 0,
              day_align: hmUI.align.LEFT,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_month_img.setProperty(hmUI.prop.MORE, {
              month_startX: 257,
              month_startY: 277,
              month_sc_array: ["Bg_Black/Month_01.png","Bg_Black/Month_02.png","Bg_Black/Month_03.png","Bg_Black/Month_04.png","Bg_Black/Month_05.png","Bg_Black/Month_06.png","Bg_Black/Month_07.png","Bg_Black/Month_08.png","Bg_Black/Month_09.png","Bg_Black/Month_10.png","Bg_Black/Month_11.png","Bg_Black/Month_12.png"],
              month_tc_array: ["Bg_Black/Month_01.png","Bg_Black/Month_02.png","Bg_Black/Month_03.png","Bg_Black/Month_04.png","Bg_Black/Month_05.png","Bg_Black/Month_06.png","Bg_Black/Month_07.png","Bg_Black/Month_08.png","Bg_Black/Month_09.png","Bg_Black/Month_10.png","Bg_Black/Month_11.png","Bg_Black/Month_12.png"],
              month_en_array: ["Bg_Black/Month_01.png","Bg_Black/Month_02.png","Bg_Black/Month_03.png","Bg_Black/Month_04.png","Bg_Black/Month_05.png","Bg_Black/Month_06.png","Bg_Black/Month_07.png","Bg_Black/Month_08.png","Bg_Black/Month_09.png","Bg_Black/Month_10.png","Bg_Black/Month_11.png","Bg_Black/Month_12.png"],
              month_is_character: true ,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_text_img.setProperty(hmUI.prop.MORE, {
              x: 180,
              y: 275,
              font_array: ["Bg_Black/Act21_0.png","Bg_Black/Act21_1.png","Bg_Black/Act21_2.png","Bg_Black/Act21_3.png","Bg_Black/Act21_4.png","Bg_Black/Act21_5.png","Bg_Black/Act21_6.png","Bg_Black/Act21_7.png","Bg_Black/Act21_8.png","Bg_Black/Act21_9.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'Batt_Unit.png',
              unit_tc: 'Batt_Unit.png',
              unit_en: 'Batt_Unit.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_text_img.setProperty(hmUI.prop.MORE, {
              x: 372,
              y: 170,
              font_array: ["Bg_Black/Act21_0.png","Bg_Black/Act21_1.png","Bg_Black/Act21_2.png","Bg_Black/Act21_3.png","Bg_Black/Act21_4.png","Bg_Black/Act21_5.png","Bg_Black/Act21_6.png","Bg_Black/Act21_7.png","Bg_Black/Act21_8.png","Bg_Black/Act21_9.png"],
              padding: false,
              h_space: 2,
              invalid_image: '"Bg_Black/Act21_0.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_text_img.setProperty(hmUI.prop.MORE, {
              x: 155,
              y: 170,
              font_array: ["Bg_Black/Act21_0.png","Bg_Black/Act21_1.png","Bg_Black/Act21_2.png","Bg_Black/Act21_3.png","Bg_Black/Act21_4.png","Bg_Black/Act21_5.png","Bg_Black/Act21_6.png","Bg_Black/Act21_7.png","Bg_Black/Act21_8.png","Bg_Black/Act21_9.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time_second.setProperty(hmUI.prop.MORE, {
              second_startX: 310,
              second_startY: 199,
              second_array: ["Bg_Black/Time_0.png","Bg_Black/Time_1.png","Bg_Black/Time_2.png","Bg_Black/Time_3.png","Bg_Black/Time_4.png","Bg_Black/Time_5.png","Bg_Black/Time_6.png","Bg_Black/Time_7.png","Bg_Black/Time_8.png","Bg_Black/Time_9.png"],
              second_zero: 1,
              second_space: 0,
              second_angle: 0,
              second_follow: 0,
              second_align: hmUI.align.LEFT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time_minute.setProperty(hmUI.prop.MORE, {
              minute_startX: 181,
              minute_startY: 199,
              minute_array: ["Bg_Black/Time_0.png","Bg_Black/Time_1.png","Bg_Black/Time_2.png","Bg_Black/Time_3.png","Bg_Black/Time_4.png","Bg_Black/Time_5.png","Bg_Black/Time_6.png","Bg_Black/Time_7.png","Bg_Black/Time_8.png","Bg_Black/Time_9.png"],
              minute_zero: 1,
              minute_space: 0,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time_hour.setProperty(hmUI.prop.MORE, {
              hour_startX: 52,
              hour_startY: 199,
              hour_array: ["Bg_Black/Time_0.png","Bg_Black/Time_1.png","Bg_Black/Time_2.png","Bg_Black/Time_3.png","Bg_Black/Time_4.png","Bg_Black/Time_5.png","Bg_Black/Time_6.png","Bg_Black/Time_7.png","Bg_Black/Time_8.png","Bg_Black/Time_9.png"],
              hour_zero: 1,
              hour_space: 0,
              hour_angle: 0,
              hour_align: hmUI.align.LEFT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
const result = hmSetting.setScreenOff()

}

            };
            //#endregion

            console.log('Watch_Face.ScreenNormal');
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 466,
              h: 466,
              src: 'Bg1.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 360,
              y: 277,
              week_en: ["Week_1.png","Week_2.png","Week_3.png","Week_4.png","Week_5.png","Week_6.png","Week_7.png"],
              week_tc: ["Week_1.png","Week_2.png","Week_3.png","Week_4.png","Week_5.png","Week_6.png","Week_7.png"],
              week_sc: ["Week_1.png","Week_2.png","Week_3.png","Week_4.png","Week_5.png","Week_6.png","Week_7.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 316,
              day_startY: 277,
              day_sc_array: ["Act21_0.png","Act21_1.png","Act21_2.png","Act21_3.png","Act21_4.png","Act21_5.png","Act21_6.png","Act21_7.png","Act21_8.png","Act21_9.png"],
              day_tc_array: ["Act21_0.png","Act21_1.png","Act21_2.png","Act21_3.png","Act21_4.png","Act21_5.png","Act21_6.png","Act21_7.png","Act21_8.png","Act21_9.png"],
              day_en_array: ["Act21_0.png","Act21_1.png","Act21_2.png","Act21_3.png","Act21_4.png","Act21_5.png","Act21_6.png","Act21_7.png","Act21_8.png","Act21_9.png"],
              day_zero: 1,
              day_space: 0,
              day_align: hmUI.align.LEFT,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_month_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 257,
              month_startY: 277,
              month_sc_array: ["Month_01.png","Month_02.png","Month_03.png","Month_04.png","Month_05.png","Month_06.png","Month_07.png","Month_08.png","Month_09.png","Month_10.png","Month_11.png","Month_12.png"],
              month_tc_array: ["Month_01.png","Month_02.png","Month_03.png","Month_04.png","Month_05.png","Month_06.png","Month_07.png","Month_08.png","Month_09.png","Month_10.png","Month_11.png","Month_12.png"],
              month_en_array: ["Month_01.png","Month_02.png","Month_03.png","Month_04.png","Month_05.png","Month_06.png","Month_07.png","Month_08.png","Month_09.png","Month_10.png","Month_11.png","Month_12.png"],
              month_is_character: true ,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 180,
              y: 275,
              font_array: ["Act21_0.png","Act21_1.png","Act21_2.png","Act21_3.png","Act21_4.png","Act21_5.png","Act21_6.png","Act21_7.png","Act21_8.png","Act21_9.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'Batt_Unit.png',
              unit_tc: 'Batt_Unit.png',
              unit_en: 'Batt_Unit.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 372,
              y: 170,
              font_array: ["Act21_0.png","Act21_1.png","Act21_2.png","Act21_3.png","Act21_4.png","Act21_5.png","Act21_6.png","Act21_7.png","Act21_8.png","Act21_9.png"],
              padding: false,
              h_space: 2,
              invalid_image: 'Act21_0.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 155,
              y: 170,
              font_array: ["Act21_0.png","Act21_1.png","Act21_2.png","Act21_3.png","Act21_4.png","Act21_5.png","Act21_6.png","Act21_7.png","Act21_8.png","Act21_9.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time_second = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              second_startX: 310,
              second_startY: 199,
              second_array: ["Time_0.png","Time_1.png","Time_2.png","Time_3.png","Time_4.png","Time_5.png","Time_6.png","Time_7.png","Time_8.png","Time_9.png"],
              second_zero: 1,
              second_space: 0,
              second_angle: 0,
              second_follow: 0,
              second_align: hmUI.align.LEFT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time_minute = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              minute_startX: 181,
              minute_startY: 199,
              minute_array: ["Time_0.png","Time_1.png","Time_2.png","Time_3.png","Time_4.png","Time_5.png","Time_6.png","Time_7.png","Time_8.png","Time_9.png"],
              minute_zero: 1,
              minute_space: 0,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time_hour = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 52,
              hour_startY: 199,
              hour_array: ["Time_0.png","Time_1.png","Time_2.png","Time_3.png","Time_4.png","Time_5.png","Time_6.png","Time_7.png","Time_8.png","Time_9.png"],
              hour_zero: 1,
              hour_space: 0,
              hour_angle: 0,
              hour_align: hmUI.align.LEFT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            console.log('Watch_Face.ScreenAOD');
            idle_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 466,
              h: 466,
              src: 'Bg2.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 360,
              y: 277,
              week_en: ["AOD_Week_1.png","AOD_Week_2.png","AOD_Week_3.png","AOD_Week_4.png","AOD_Week_5.png","AOD_Week_6.png","AOD_Week_7.png"],
              week_tc: ["AOD_Week_1.png","AOD_Week_2.png","AOD_Week_3.png","AOD_Week_4.png","AOD_Week_5.png","AOD_Week_6.png","AOD_Week_7.png"],
              week_sc: ["AOD_Week_1.png","AOD_Week_2.png","AOD_Week_3.png","AOD_Week_4.png","AOD_Week_5.png","AOD_Week_6.png","AOD_Week_7.png"],
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 316,
              day_startY: 277,
              day_sc_array: ["AOD_Act21_0.png","AOD_Act21_1.png","AOD_Act21_2.png","AOD_Act21_3.png","AOD_Act21_4.png","AOD_Act21_5.png","AOD_Act21_6.png","AOD_Act21_7.png","AOD_Act21_8.png","AOD_Act21_9.png"],
              day_tc_array: ["AOD_Act21_0.png","AOD_Act21_1.png","AOD_Act21_2.png","AOD_Act21_3.png","AOD_Act21_4.png","AOD_Act21_5.png","AOD_Act21_6.png","AOD_Act21_7.png","AOD_Act21_8.png","AOD_Act21_9.png"],
              day_en_array: ["AOD_Act21_0.png","AOD_Act21_1.png","AOD_Act21_2.png","AOD_Act21_3.png","AOD_Act21_4.png","AOD_Act21_5.png","AOD_Act21_6.png","AOD_Act21_7.png","AOD_Act21_8.png","AOD_Act21_9.png"],
              day_zero: 1,
              day_space: 0,
              day_align: hmUI.align.LEFT,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_month_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 257,
              month_startY: 277,
              month_sc_array: ["AOD_Month_01.png","AOD_Month_02.png","AOD_Month_03.png","AOD_Month_04.png","AOD_Month_05.png","AOD_Month_06.png","AOD_Month_07.png","AOD_Month_08.png","AOD_Month_09.png","AOD_Month_10.png","AOD_Month_11.png","AOD_Month_12.png"],
              month_tc_array: ["AOD_Month_01.png","AOD_Month_02.png","AOD_Month_03.png","AOD_Month_04.png","AOD_Month_05.png","AOD_Month_06.png","AOD_Month_07.png","AOD_Month_08.png","AOD_Month_09.png","AOD_Month_10.png","AOD_Month_11.png","AOD_Month_12.png"],
              month_en_array: ["AOD_Month_01.png","AOD_Month_02.png","AOD_Month_03.png","AOD_Month_04.png","AOD_Month_05.png","AOD_Month_06.png","AOD_Month_07.png","AOD_Month_08.png","AOD_Month_09.png","AOD_Month_10.png","AOD_Month_11.png","AOD_Month_12.png"],
              month_is_character: true ,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 180,
              y: 275,
              font_array: ["AOD_Act21_0.png","AOD_Act21_1.png","AOD_Act21_2.png","AOD_Act21_3.png","AOD_Act21_4.png","AOD_Act21_5.png","AOD_Act21_6.png","AOD_Act21_7.png","AOD_Act21_8.png","AOD_Act21_9.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'Batt_Unit.png',
              unit_tc: 'Batt_Unit.png',
              unit_en: 'Batt_Unit.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 372,
              y: 170,
              font_array: ["AOD_Act21_0.png","AOD_Act21_1.png","AOD_Act21_2.png","AOD_Act21_3.png","AOD_Act21_4.png","AOD_Act21_5.png","AOD_Act21_6.png","AOD_Act21_7.png","AOD_Act21_8.png","AOD_Act21_9.png"],
              padding: false,
              h_space: 2,
              invalid_image: 'Act21_0.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 155,
              y: 170,
              font_array: ["AOD_Act21_0.png","AOD_Act21_1.png","AOD_Act21_2.png","AOD_Act21_3.png","AOD_Act21_4.png","AOD_Act21_5.png","AOD_Act21_6.png","AOD_Act21_7.png","AOD_Act21_8.png","AOD_Act21_9.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time_minute = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              minute_startX: 181,
              minute_startY: 199,
              minute_array: ["AOD_Time_0.png","AOD_Time_1.png","AOD_Time_2.png","AOD_Time_3.png","AOD_Time_4.png","AOD_Time_5.png","AOD_Time_6.png","AOD_Time_7.png","AOD_Time_8.png","AOD_Time_9.png"],
              minute_zero: 1,
              minute_space: 0,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time_hour = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 52,
              hour_startY: 199,
              hour_array: ["AOD_Time_0.png","AOD_Time_1.png","AOD_Time_2.png","AOD_Time_3.png","AOD_Time_4.png","AOD_Time_5.png","AOD_Time_6.png","AOD_Time_7.png","AOD_Time_8.png","AOD_Time_9.png"],
              hour_zero: 1,
              hour_space: 0,
              hour_angle: 0,
              hour_align: hmUI.align.LEFT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            console.log('Watch_Face.SwitchBackground');
            // Button_Switch_BG = hmUI.createWidget(hmUI.widget.SwitchBackground, {
              // x: 184,
              // y: 383,
              // w: 100,
              // h: 100,
              // text: '',
              // color: 0xFFFF8C00,
              // text_size: 25,
              // press_src: '0.png',
              // normal_src: '0.png',
              // bg_list: Bg1|Bg2,
              // toast_list: Background %s|Background %s,
              // use_crown: False,
              // use_in_AOD: False,
              // vibro: False,
            // });

            Button_Switch_BG = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 184,
              y: 383,
              w: 100,
              h: 100,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '0.png',
              normal_src: '0.png',
              click_func: (button_widget) => {
                switchBackground();
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            let screenType = hmSetting.getScreenType();
            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                console.log('resume_call()');

                //SwitchBackground
                if (hmFS.SysProGetInt(`backgroundIndex_${watchfaceId}`) === undefined) {
                  backgroundIndex = 0;
                  hmFS.SysProSetInt(`backgroundIndex_${watchfaceId}`, backgroundIndex);
                } else {
                  backgroundIndex = hmFS.SysProGetInt(`backgroundIndex_${watchfaceId}`);
                };
                if (screenType == hmSetting.screen_type.WATCHFACE && normal_background_bg_img){ normal_background_bg_img.setProperty(hmUI.prop.SRC, backgroundList[backgroundIndex]);
if ( backgroundIndex==0){
           normal_date_img_date_week_img.setProperty(hmUI.prop.MORE, {
              x: 360,
              y: 277,
              week_en: ["Week_1.png","Week_2.png","Week_3.png","Week_4.png","Week_5.png","Week_6.png","Week_7.png"],
              week_tc: ["Week_1.png","Week_2.png","Week_3.png","Week_4.png","Week_5.png","Week_6.png","Week_7.png"],
              week_sc: ["Week_1.png","Week_2.png","Week_3.png","Week_4.png","Week_5.png","Week_6.png","Week_7.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day.setProperty(hmUI.prop.MORE, {
              day_startX: 316,
              day_startY: 277,
              day_sc_array: ["Act21_0.png","Act21_1.png","Act21_2.png","Act21_3.png","Act21_4.png","Act21_5.png","Act21_6.png","Act21_7.png","Act21_8.png","Act21_9.png"],
              day_tc_array: ["Act21_0.png","Act21_1.png","Act21_2.png","Act21_3.png","Act21_4.png","Act21_5.png","Act21_6.png","Act21_7.png","Act21_8.png","Act21_9.png"],
              day_en_array: ["Act21_0.png","Act21_1.png","Act21_2.png","Act21_3.png","Act21_4.png","Act21_5.png","Act21_6.png","Act21_7.png","Act21_8.png","Act21_9.png"],
              day_zero: 1,
              day_space: 0,
              day_align: hmUI.align.LEFT,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_month_img.setProperty(hmUI.prop.MORE, {
              month_startX: 257,
              month_startY: 277,
              month_sc_array: ["Month_01.png","Month_02.png","Month_03.png","Month_04.png","Month_05.png","Month_06.png","Month_07.png","Month_08.png","Month_09.png","Month_10.png","Month_11.png","Month_12.png"],
              month_tc_array: ["Month_01.png","Month_02.png","Month_03.png","Month_04.png","Month_05.png","Month_06.png","Month_07.png","Month_08.png","Month_09.png","Month_10.png","Month_11.png","Month_12.png"],
              month_en_array: ["Month_01.png","Month_02.png","Month_03.png","Month_04.png","Month_05.png","Month_06.png","Month_07.png","Month_08.png","Month_09.png","Month_10.png","Month_11.png","Month_12.png"],
              month_is_character: true ,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_text_img.setProperty(hmUI.prop.MORE, {
              x: 180,
              y: 275,
              font_array: ["Act21_0.png","Act21_1.png","Act21_2.png","Act21_3.png","Act21_4.png","Act21_5.png","Act21_6.png","Act21_7.png","Act21_8.png","Act21_9.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'Batt_Unit.png',
              unit_tc: 'Batt_Unit.png',
              unit_en: 'Batt_Unit.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_text_img.setProperty(hmUI.prop.MORE, {
              x: 372,
              y: 170,
              font_array: ["Act21_0.png","Act21_1.png","Act21_2.png","Act21_3.png","Act21_4.png","Act21_5.png","Act21_6.png","Act21_7.png","Act21_8.png","Act21_9.png"],
              padding: false,
              h_space: 2,
              invalid_image: 'Act21_0.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_text_img.setProperty(hmUI.prop.MORE, {
              x: 155,
              y: 170,
              font_array: ["Act21_0.png","Act21_1.png","Act21_2.png","Act21_3.png","Act21_4.png","Act21_5.png","Act21_6.png","Act21_7.png","Act21_8.png","Act21_9.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time_second.setProperty(hmUI.prop.MORE, {
              second_startX: 310,
              second_startY: 199,
              second_array: ["Time_0.png","Time_1.png","Time_2.png","Time_3.png","Time_4.png","Time_5.png","Time_6.png","Time_7.png","Time_8.png","Time_9.png"],
              second_zero: 1,
              second_space: 0,
              second_angle: 0,
              second_follow: 0,
              second_align: hmUI.align.LEFT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time_minute.setProperty(hmUI.prop.MORE, {
              minute_startX: 181,
              minute_startY: 199,
              minute_array: ["Time_0.png","Time_1.png","Time_2.png","Time_3.png","Time_4.png","Time_5.png","Time_6.png","Time_7.png","Time_8.png","Time_9.png"],
              minute_zero: 1,
              minute_space: 0,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time_hour.setProperty(hmUI.prop.MORE, {
              hour_startX: 52,
              hour_startY: 199,
              hour_array: ["Time_0.png","Time_1.png","Time_2.png","Time_3.png","Time_4.png","Time_5.png","Time_6.png","Time_7.png","Time_8.png","Time_9.png"],
              hour_zero: 1,
              hour_space: 0,
              hour_angle: 0,
              hour_align: hmUI.align.LEFT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

}


if ( backgroundIndex==1){
           normal_date_img_date_week_img.setProperty(hmUI.prop.MORE, {
              x: 360,
              y: 277,
              week_en: ["Bg_Black/Week_1.png","Bg_Black/Week_2.png","Bg_Black/Week_3.png","Bg_Black/Week_4.png","Bg_Black/Week_5.png","Bg_Black/Week_6.png","Bg_Black/Week_7.png"],
              week_tc: ["Bg_Black/Week_1.png","Bg_Black/Week_2.png","Bg_Black/Week_3.png","Bg_Black/Week_4.png","Bg_Black/Week_5.png","Bg_Black/Week_6.png","Bg_Black/Week_7.png"],
              week_sc: ["Bg_Black/Week_1.png","Bg_Black/Week_2.png","Bg_Black/Week_3.png","Bg_Black/Week_4.png","Bg_Black/Week_5.png","Bg_Black/Week_6.png","Bg_Black/Week_7.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day.setProperty(hmUI.prop.MORE, {
              day_startX: 316,
              day_startY: 277,
              day_sc_array: ["Bg_Black/Act21_0.png","Bg_Black/Act21_1.png","Bg_Black/Act21_2.png","Bg_Black/Act21_3.png","Bg_Black/Act21_4.png","Bg_Black/Act21_5.png","Bg_Black/Act21_6.png","Bg_Black/Act21_7.png","Bg_Black/Act21_8.png","Bg_Black/Act21_9.png"],
              day_tc_array: ["Bg_Black/Act21_0.png","Bg_Black/Act21_1.png","Bg_Black/Act21_2.png","Bg_Black/Act21_3.png","Bg_Black/Act21_4.png","Bg_Black/Act21_5.png","Bg_Black/Act21_6.png","Bg_Black/Act21_7.png","Bg_Black/Act21_8.png","Bg_Black/Act21_9.png"],
              day_en_array: ["Bg_Black/Act21_0.png","Bg_Black/Act21_1.png","Bg_Black/Act21_2.png","Bg_Black/Act21_3.png","Bg_Black/Act21_4.png","Bg_Black/Act21_5.png","Bg_Black/Act21_6.png","Bg_Black/Act21_7.png","Bg_Black/Act21_8.png","Bg_Black/Act21_9.png"],
              day_zero: 1,
              day_space: 0,
              day_align: hmUI.align.LEFT,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_month_img.setProperty(hmUI.prop.MORE, {
              month_startX: 257,
              month_startY: 277,
              month_sc_array: ["Bg_Black/Month_01.png","Bg_Black/Month_02.png","Bg_Black/Month_03.png","Bg_Black/Month_04.png","Bg_Black/Month_05.png","Bg_Black/Month_06.png","Bg_Black/Month_07.png","Bg_Black/Month_08.png","Bg_Black/Month_09.png","Bg_Black/Month_10.png","Bg_Black/Month_11.png","Bg_Black/Month_12.png"],
              month_tc_array: ["Bg_Black/Month_01.png","Bg_Black/Month_02.png","Bg_Black/Month_03.png","Bg_Black/Month_04.png","Bg_Black/Month_05.png","Bg_Black/Month_06.png","Bg_Black/Month_07.png","Bg_Black/Month_08.png","Bg_Black/Month_09.png","Bg_Black/Month_10.png","Bg_Black/Month_11.png","Bg_Black/Month_12.png"],
              month_en_array: ["Bg_Black/Month_01.png","Bg_Black/Month_02.png","Bg_Black/Month_03.png","Bg_Black/Month_04.png","Bg_Black/Month_05.png","Bg_Black/Month_06.png","Bg_Black/Month_07.png","Bg_Black/Month_08.png","Bg_Black/Month_09.png","Bg_Black/Month_10.png","Bg_Black/Month_11.png","Bg_Black/Month_12.png"],
              month_is_character: true ,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_text_img.setProperty(hmUI.prop.MORE, {
              x: 180,
              y: 275,
              font_array: ["Bg_Black/Act21_0.png","Bg_Black/Act21_1.png","Bg_Black/Act21_2.png","Bg_Black/Act21_3.png","Bg_Black/Act21_4.png","Bg_Black/Act21_5.png","Bg_Black/Act21_6.png","Bg_Black/Act21_7.png","Bg_Black/Act21_8.png","Bg_Black/Act21_9.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'Batt_Unit.png',
              unit_tc: 'Batt_Unit.png',
              unit_en: 'Batt_Unit.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_text_img.setProperty(hmUI.prop.MORE, {
              x: 372,
              y: 170,
              font_array: ["Bg_Black/Act21_0.png","Bg_Black/Act21_1.png","Bg_Black/Act21_2.png","Bg_Black/Act21_3.png","Bg_Black/Act21_4.png","Bg_Black/Act21_5.png","Bg_Black/Act21_6.png","Bg_Black/Act21_7.png","Bg_Black/Act21_8.png","Bg_Black/Act21_9.png"],
              padding: false,
              h_space: 2,
              invalid_image: '"Bg_Black/Act21_0.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_text_img.setProperty(hmUI.prop.MORE, {
              x: 155,
              y: 170,
              font_array: ["Bg_Black/Act21_0.png","Bg_Black/Act21_1.png","Bg_Black/Act21_2.png","Bg_Black/Act21_3.png","Bg_Black/Act21_4.png","Bg_Black/Act21_5.png","Bg_Black/Act21_6.png","Bg_Black/Act21_7.png","Bg_Black/Act21_8.png","Bg_Black/Act21_9.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time_second.setProperty(hmUI.prop.MORE, {
              second_startX: 310,
              second_startY: 199,
              second_array: ["Bg_Black/Time_0.png","Bg_Black/Time_1.png","Bg_Black/Time_2.png","Bg_Black/Time_3.png","Bg_Black/Time_4.png","Bg_Black/Time_5.png","Bg_Black/Time_6.png","Bg_Black/Time_7.png","Bg_Black/Time_8.png","Bg_Black/Time_9.png"],
              second_zero: 1,
              second_space: 0,
              second_angle: 0,
              second_follow: 0,
              second_align: hmUI.align.LEFT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time_minute.setProperty(hmUI.prop.MORE, {
              minute_startX: 181,
              minute_startY: 199,
              minute_array: ["Bg_Black/Time_0.png","Bg_Black/Time_1.png","Bg_Black/Time_2.png","Bg_Black/Time_3.png","Bg_Black/Time_4.png","Bg_Black/Time_5.png","Bg_Black/Time_6.png","Bg_Black/Time_7.png","Bg_Black/Time_8.png","Bg_Black/Time_9.png"],
              minute_zero: 1,
              minute_space: 0,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time_hour.setProperty(hmUI.prop.MORE, {
              hour_startX: 52,
              hour_startY: 199,
              hour_array: ["Bg_Black/Time_0.png","Bg_Black/Time_1.png","Bg_Black/Time_2.png","Bg_Black/Time_3.png","Bg_Black/Time_4.png","Bg_Black/Time_5.png","Bg_Black/Time_6.png","Bg_Black/Time_7.png","Bg_Black/Time_8.png","Bg_Black/Time_9.png"],
              hour_zero: 1,
              hour_space: 0,
              hour_angle: 0,
              hour_align: hmUI.align.LEFT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

}
}
              }),
            });

                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}