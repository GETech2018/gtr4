﻿
    /*
    ** Watch_Face_Editor tool
    ** watchface js version v1.0.1
    ** Copyright © CashaCX75. All Rights Reserved
    */

    try {

      (() => {

        var __$$app$$__ = __$$hmAppManager$$__.currentApp;
        var __$$module$$__ = __$$app$$__.current;
        //drink is a name,can modify
        var h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__), 'drink');

        'use strict';

        //dynamic modify start

        
        let normal_step_icon_img = ''
        let normal_calorie_icon_img = ''
        let normal_system_disconnect_img = ''
        let normal_date_img_date_day = ''
        let normal_date_img_date_week_img = ''
        let normal_analog_clock_time_pointer_hour = ''
        let normal_analog_clock_time_pointer_minute = ''
        let normal_analog_clock_time_pointer_second = ''


        //dynamic modify end

        //not required
        const logger = DeviceRuntimeCore.HmLogger.getLogger("yeguang");

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({

          init_view() {

            //dynamic modify start
                    
            

            normal_step_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: -4,
              y: -21,
              src: 'Dails_0008asaorange.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_calorie_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 169,
              y: 351,
              src: 'mini_back.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 65,
              y: 215,
              src: 'icon_bluetooth_lightgrey.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 224,
              day_startY: 341,
              day_sc_array: ["digi_googlesan_redsmallsize3_0001.png","digi_googlesan_redsmallsize3_0002.png","digi_googlesan_redsmallsize3_0003.png","digi_googlesan_redsmallsize3_0004.png","digi_googlesan_redsmallsize3_0005.png","digi_googlesan_redsmallsize3_0006.png","digi_googlesan_redsmallsize3_0007.png","digi_googlesan_redsmallsize3_0008.png","digi_googlesan_redsmallsize3_0009.png","digi_googlesan_redsmallsize3_0010.png"],
              day_tc_array: ["digi_googlesan_redsmallsize3_0001.png","digi_googlesan_redsmallsize3_0002.png","digi_googlesan_redsmallsize3_0003.png","digi_googlesan_redsmallsize3_0004.png","digi_googlesan_redsmallsize3_0005.png","digi_googlesan_redsmallsize3_0006.png","digi_googlesan_redsmallsize3_0007.png","digi_googlesan_redsmallsize3_0008.png","digi_googlesan_redsmallsize3_0009.png","digi_googlesan_redsmallsize3_0010.png"],
              day_en_array: ["digi_googlesan_redsmallsize3_0001.png","digi_googlesan_redsmallsize3_0002.png","digi_googlesan_redsmallsize3_0003.png","digi_googlesan_redsmallsize3_0004.png","digi_googlesan_redsmallsize3_0005.png","digi_googlesan_redsmallsize3_0006.png","digi_googlesan_redsmallsize3_0007.png","digi_googlesan_redsmallsize3_0008.png","digi_googlesan_redsmallsize3_0009.png","digi_googlesan_redsmallsize3_0010.png"],
              day_zero: 0,
              day_space: -49,
              day_align: hmUI.align.RIGHT,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 151,
              y: 346,
              week_en: ["digi_googlesan_darksmallsize3_0001.png","digi_googlesan_darksmallsize3_0002.png","digi_googlesan_darksmallsize3_0003.png","digi_googlesan_darksmallsize3_0004.png","digi_googlesan_darksmallsize3_0005.png","digi_googlesan_darksmallsize3_0006.png","digi_googlesan_darksmallsize3_0007.png"],
              week_tc: ["digi_googlesan_darksmallsize3_0001.png","digi_googlesan_darksmallsize3_0002.png","digi_googlesan_darksmallsize3_0003.png","digi_googlesan_darksmallsize3_0004.png","digi_googlesan_darksmallsize3_0005.png","digi_googlesan_darksmallsize3_0006.png","digi_googlesan_darksmallsize3_0007.png"],
              week_sc: ["digi_googlesan_darksmallsize3_0001.png","digi_googlesan_darksmallsize3_0002.png","digi_googlesan_darksmallsize3_0003.png","digi_googlesan_darksmallsize3_0004.png","digi_googlesan_darksmallsize3_0005.png","digi_googlesan_darksmallsize3_0006.png","digi_googlesan_darksmallsize3_0007.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_hour = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              hour_path: '0048H.png',
              hour_centerX: 233,
              hour_centerY: 233,
              hour_posX: 25,
              hour_posY: 200,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_minute = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              minute_path: '0048Ma.png',
              minute_centerX: 233,
              minute_centerY: 233,
              minute_posX: 25,
              minute_posY: 198,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_second = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              second_path: 'Picture13S3.png',
              second_centerX: 233,
              second_centerY: 233,
              second_posX: 49,
              second_posY: 239,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });




            //dynamic modify end
          },

          onInit() {
            console.log('index page.js on init invoke')

            this.init_view()

          },

          onReady() {
            console.log('index page.js on ready invoke')
          },

          onShow() {
            console.log('index page.js on show invoke')
          },

          onHide() {
            console.log('index page.js on hide invoke')
          },

          onDestory() {
            console.log('index page.js on destory invoke')
          },
        });

      })()
    } catch (e) {
      console.log(e)
    }
  