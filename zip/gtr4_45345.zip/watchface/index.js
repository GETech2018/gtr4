﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        const logger = Logger.getLogger('watchface_SashaCX75');
        //end of ignored block

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
            hmUI.createWidget(hmUI.widget.FILL_RECT, {
             x: 0, y: 0, w: 466, h: 466, color: '0xFF000000', show_level: hmUI.show_level.ONLY_NORMAL,
            });
            hmUI.createWidget(hmUI.widget.IMG, { x: 0, y: 0, src: 'bg.png', show_level: hmUI.show_level.ONLY_NORMAL, });
            hmUI.createWidget(hmUI.widget.IMG, { x: 206, y: 80, src: 'lbl_time.png', show_level: hmUI.show_level.ONLY_NORMAL, });
            hmUI.createWidget(hmUI.widget.IMG_TIME, {
             hour_startX: 62, hour_startY: 84, hour_array: ["bd_0.png", "bd_1.png", "bd_2.png", "bd_3.png", "bd_4.png", "bd_5.png", "bd_6.png", "bd_7.png", "bd_8.png", "bd_9.png"], hour_zero: 1, hour_space: 6, hour_angle: 0, hour_align: hmUI.align.LEFT,
             minute_startX: 62, minute_startY: 176, minute_array: ["bd_0.png", "bd_1.png", "bd_2.png", "bd_3.png", "bd_4.png", "bd_5.png", "bd_6.png", "bd_7.png", "bd_8.png", "bd_9.png"], minute_zero: 1, minute_space: 6, minute_angle: 0, minute_follow: 0, minute_align: hmUI.align.LEFT,
             second_startX: 206, second_startY: 140, second_array: ["cu36_0.png", "cu36_1.png", "cu36_2.png", "cu36_3.png", "cu36_4.png", "cu36_5.png", "cu36_6.png", "cu36_7.png", "cu36_8.png", "cu36_9.png"], second_zero: 1, second_space: 2, second_angle: 0, second_follow: 0, second_align: hmUI.align.LEFT,
             show_level: hmUI.show_level.ONLY_NORMAL,
            });
            hmUI.createWidget(hmUI.widget.IMG_TIME, {
             am_x: 282, am_y: 142, am_sc_path: 'am.png', am_en_path: 'am.png',
             pm_x: 282, pm_y: 142, pm_sc_path: 'pm.png', pm_en_path: 'pm.png',
             show_level: hmUI.show_level.ONLY_NORMAL,
            });
            hmUI.createWidget(hmUI.widget.IMG_DATE, {
             month_startX: 206, month_startY: 98,
             month_sc_array: ["m_0.png", "m_1.png", "m_2.png", "m_3.png", "m_4.png", "m_5.png", "m_6.png", "m_7.png", "m_8.png", "m_9.png", "m_10.png", "m_11.png"], month_tc_array: ["m_0.png", "m_1.png", "m_2.png", "m_3.png", "m_4.png", "m_5.png", "m_6.png", "m_7.png", "m_8.png", "m_9.png", "m_10.png", "m_11.png"], month_en_array: ["m_0.png", "m_1.png", "m_2.png", "m_3.png", "m_4.png", "m_5.png", "m_6.png", "m_7.png", "m_8.png", "m_9.png", "m_10.png", "m_11.png"],
             month_is_character: true,
             show_level: hmUI.show_level.ONLY_NORMAL,
            });
            hmUI.createWidget(hmUI.widget.IMG_DATE, {
             day_startX: 293, day_startY: 98,
             day_sc_array: ["wh26_0.png", "wh26_1.png", "wh26_2.png", "wh26_3.png", "wh26_4.png", "wh26_5.png", "wh26_6.png", "wh26_7.png", "wh26_8.png", "wh26_9.png"], day_tc_array: ["wh26_0.png", "wh26_1.png", "wh26_2.png", "wh26_3.png", "wh26_4.png", "wh26_5.png", "wh26_6.png", "wh26_7.png", "wh26_8.png", "wh26_9.png"], day_en_array: ["wh26_0.png", "wh26_1.png", "wh26_2.png", "wh26_3.png", "wh26_4.png", "wh26_5.png", "wh26_6.png", "wh26_7.png", "wh26_8.png", "wh26_9.png"],
             day_zero: 0, day_space: 2, day_align: hmUI.align.LEFT, day_is_character: false,
             show_level: hmUI.show_level.ONLY_NORMAL,
            });
            hmUI.createWidget(hmUI.widget.IMG_WEEK, {
             x: 206, y: 216,
             week_en: ["w_1.png", "w_2.png", "w_3.png", "w_4.png", "w_5.png", "w_6.png", "w_0.png"], week_tc: ["w_1.png", "w_2.png", "w_3.png", "w_4.png", "w_5.png", "w_6.png", "w_0.png"], week_sc: ["w_1.png", "w_2.png", "w_3.png", "w_4.png", "w_5.png", "w_6.png", "w_0.png"],
             show_level: hmUI.show_level.ONLY_NORMAL,
            });
            hmUI.createWidget(hmUI.widget.TEXT_IMG, {
             x: 192,
             y: 192,
             w: 56,
             h: 16,
             font_array: ["wh14_0.png", "wh14_1.png", "wh14_2.png", "wh14_3.png", "wh14_4.png", "wh14_5.png", "wh14_6.png", "wh14_7.png", "wh14_8.png", "wh14_9.png"],
             padding: false,
             h_space: 1,
             angle: 0,
             negative_image: 'td_minus.png',
             invalid_image: 'td_dash.png',
             align_h: hmUI.align.RIGHT,
             type: hmUI.data_type.WEATHER_CURRENT,
             show_level: hmUI.show_level.ONLY_NORMAL,
            });
            hmUI.createWidget(hmUI.widget.IMG, { x: 249, y: 192, src: 'td_deg.png', show_level: hmUI.show_level.ONLY_NORMAL, });
            hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
             x: 264, y: 193, image_array: ["wn_0.png", "wn_1.png", "wn_2.png", "wn_3.png", "wn_4.png", "wn_5.png", "wn_6.png", "wn_7.png", "wn_8.png", "wn_9.png", "wn_10.png", "wn_11.png", "wn_12.png", "wn_13.png", "wn_14.png", "wn_15.png", "wn_16.png", "wn_17.png", "wn_18.png", "wn_19.png", "wn_20.png", "wn_21.png", "wn_22.png", "wn_23.png", "wn_24.png", "wn_25.png", "wn_26.png", "wn_27.png", "wn_28.png"], image_length: 29, type: hmUI.data_type.WEATHER_CURRENT, show_level: hmUI.show_level.ONLY_NORMAL,
            });
            hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
             x: 352, y: 120, image_array: ["wi_0.png", "wi_1.png", "wi_2.png", "wi_3.png", "wi_4.png", "wi_5.png", "wi_6.png", "wi_7.png", "wi_8.png", "wi_9.png", "wi_10.png", "wi_11.png", "wi_12.png", "wi_13.png", "wi_14.png", "wi_15.png", "wi_16.png", "wi_17.png", "wi_18.png", "wi_19.png", "wi_20.png", "wi_21.png", "wi_22.png", "wi_23.png", "wi_24.png", "wi_25.png", "wi_26.png", "wi_27.png", "wi_28.png"], image_length: 29, type: hmUI.data_type.WEATHER_CURRENT, show_level: hmUI.show_level.ONLY_NORMAL,
            });
            hmUI.createWidget(hmUI.widget.IMG, { x: 136, y: 278, src: 'lbl_energy.png', show_level: hmUI.show_level.ONLY_NORMAL, });
            hmUI.createWidget(hmUI.widget.TEXT_IMG, {
             x: 111,
             y: 292,
             w: 75,
             h: 32,
             font_array: ["wh26_0.png", "wh26_1.png", "wh26_2.png", "wh26_3.png", "wh26_4.png", "wh26_5.png", "wh26_6.png", "wh26_7.png", "wh26_8.png", "wh26_9.png"],
             padding: false,
             h_space: 2,
             angle: 0,
              align_h: hmUI.align.RIGHT,
             type: hmUI.data_type.BATTERY,
             show_level: hmUI.show_level.ONLY_NORMAL,
            });
            hmUI.createWidget(hmUI.widget.IMG, { x: 188, y: 306, src: 'pct.png', show_level: hmUI.show_level.ONLY_NORMAL, });
            hmUI.createWidget(hmUI.widget.IMG, { x: 136, y: 330, src: 'lbl_steps.png', show_level: hmUI.show_level.ONLY_NORMAL, });
            hmUI.createWidget(hmUI.widget.TEXT_IMG, {
             x: 136,
             y: 342,
             w: 200,
             h: 44,
             font_array: ["cu36_0.png", "cu36_1.png", "cu36_2.png", "cu36_3.png", "cu36_4.png", "cu36_5.png", "cu36_6.png", "cu36_7.png", "cu36_8.png", "cu36_9.png"],
             padding: false,
             h_space: 2,
             angle: 0,
              align_h: hmUI.align.LEFT,
             type: hmUI.data_type.STEP,
             show_level: hmUI.show_level.ONLY_NORMAL,
            });
            hmUI.createWidget(hmUI.widget.IMG, { x: 136, y: 398, src: 'heart.png', show_level: hmUI.show_level.ONLY_NORMAL, });
            hmUI.createWidget(hmUI.widget.TEXT_IMG, {
             x: 164,
             y: 392,
             w: 90,
             h: 32,
             font_array: ["cu26_0.png", "cu26_1.png", "cu26_2.png", "cu26_3.png", "cu26_4.png", "cu26_5.png", "cu26_6.png", "cu26_7.png", "cu26_8.png", "cu26_9.png"],
             padding: false,
             h_space: 2,
             angle: 0,
              align_h: hmUI.align.LEFT,
             type: hmUI.data_type.HEART,
             show_level: hmUI.show_level.ONLY_NORMAL,
            });
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}