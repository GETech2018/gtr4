﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        //const logger = Logger.getLogger('watchface_SashaCX75');
        const logger = DeviceRuntimeCore.HmLogger.getLogger('watchface_SashaCX75')
        //end of ignored block
        let curTime = null;
        try {
            curTime = hmSensor.createSensor(hmSensor.id.TIME);
        } catch (e) {
            curTime = null;
            console.log('TIME sensor not available or failed to create:', e);
        }
        let battery = null;
        try {
            battery = hmSensor.createSensor(hmSensor.id.BATTERY);
        } catch (e) {
            battery = null;
            console.log('BATTERY sensor not available or failed to create:', e);
        }
        const BK = {
            DATE: 'bl_date',
            BATT: 'bl_batt',
            DAYS: 'bl_days',
            DELTA: 'bl_delta', 
            FLAG: 'bl_flag',
            D1: 'bl_d1',
            D2: 'bl_d2' 
        };
        const DEFAULT_DELTA = 8;
        const MIN_DAILY_DRAIN = 2;
        const MAX_DAILY_DRAIN = 15;

        function readIntSafe(key, fallback = 0) {
            const v = hmFS.SysProGetInt(key);
            const n = Number(v);
            if (typeof n === 'number' && !isNaN(n)) return n; 
            return fallback;
        } 
        //dynamic modify start
        let normal_year_icon_img = null;
        let lastHolidayDate = -1;
        const HOLIDAYS = {
              1231: 'calendar_1.png', 
              101: 'calendar_1.png',
              214: 'calendar_2.png', 
              308: 'calendar_3.png', 
              401: 'calendar_4.png', 
              901: 'calendar_5.png',   
        };    
        // Pressure file unified path
        let barometer = null;            
        // Handler references 
        let curTimeMinuteHandler = null;
        let batteryChangeHandler = null;
        // Widgets & globals
        let weatherImg, tempText, cityNameText, tempMinText, tempMaxText, tempFeelsText, descriptionText;
        let weatherProvider = null;                    
        // Sleep / zodiac / day caches
        let lastDayChecked = -1;
        let lastZodiacDay = null;
        let currentZodiacIndex = null;
        //time update
        let lastHourChecked = -1;
        let lastDay = -1;
        // Other UI 
        let btn_bezel = ''
        let bezel_num = 1
        let bezel_all = 8
        let btn_bezel1 = ''
        let bezel_num1 = 1
        let bezel_all1 = 2
        let btn_bezel2 = ''
        let bezel_num2 = 1
        let bezel_all2 = 8    
        //dynamic modify start        
        let normal_background_bg_img = ''
        let normal_hour_circle_scale = ''
        let normal_image2_img = ''
        let zodiacImage = '' 
        let normal_alarm_clock_text_text_img = ''
        let normal_readiness_icon_img = ''
        let normal_readiness_current_text_font = ''
        let normal_digital_clock_img_time = ''
        let normal_moon_high_text_font = ''
        let normal_moon_image_progress_img_level = ''
        let normal_day_now = ''
        let normal_date_img_date_month_img = ''
        let normal_date_img_date_year = ''
        let normal_date_img_date_week_img = ''
        let normal_date_img_date_day = ''
        let normal_stand_current_text_font = ''
        let normal_stress_current_text_font = ''
        let normal_heart_rate_text_font = ''
        let normal_calorie_current_text_font = ''
        let normal_sleep_time_font = ''
        let normal_image_img = ''
        let normal_distance_current_text_font = ''
        let normal_humidity_current_text_font = ''
        let normal_altitude_target_text_font = ''
        let normal_sun_high_text_font = ''
        let normal_sun_low_text_font = ''
        let normal_wind_icon_img = ''
        let normal_wind_direction_image_progress_img_level = ''
        let normal_wind_current_text_font = ''
        let normal_battery_icon_img = ''
        let normal_battery_current_text_font = ''
        let normal_battery_image_progress_img_level = ''
        let normal_battery_life = null;
        let normal_step_current_text_font = ''
        let normal_step_image_progress_img_level = ''
        let normal_system_clock_img = ''
        let normal_system_disconnect_img = ''
        let idle_background_bg = ''
        let idle_date_img_date_month_img = ''
        let idle_date_img_date_week_img = ''
        let idle_date_img_date_day = ''
        let idle_heart_rate_icon_img = ''
        let idle_heart_rate_text_font = ''
        let idle_digital_clock_img_time = ''
        let idle_temperature_icon_img = ''
        let idle_weather_image_progress_img_level = ''
        let idle_temperature_current_text_font = ''
        let idle_readiness_icon_img = ''
        let idle_readiness_current_text_font = ''
        let idle_battery_icon_img = ''
        let idle_battery_current_text_font = ''
        let idle_step_icon_img = ''
        let idle_step_current_text_font = ''
        let idle_system_clock_img = ''
        let idle_system_disconnect_img = ''
        let normal_step_jumpable_img_click = ''
        let normal_heart_jumpable_img_click = ''
        let normal_battery_jumpable_img_click = ''
        let normal_temperature_jumpable_img_click = ''
        let normal_stress_jumpable_img_click = ''
        let normal_countdown_jumpable_img_click = ''
        let normal_stopwatch_jumpable_img_click = ''
        let normal_alarm_jumpable_img_click = ''
        let normal_sleep_jumpable_img_click = ''
        let normal_altitude_jumpable_img_click = ''
        let normal_readiness_jumpable_img_click = ''
        let normal_fatBurning_jumpable_img_click = ''
        let Button_1 = ''
        let Button_2 = ''
        let Button_3 = ''
        let Button_4 = ''
        let Button_5 = ''        
        let sleepSensor = '';

            // --------------------
            // WeatherProvider v5.1 —  T-Rex Ultra 2
            // --------------------
            class WeatherProvider {
                constructor(props = {}) {
                    this.iconMapService = {
                        1: 3, 2: 0, 3: 4, 4: 4, 5: 1, 6: 5, 7: 10, 8: 15,
                        9: 6, 10: 8, 11: 9, 12: 12, 13: 13, 14: 17
                    };

                    this.description = [
                        ['Облачно','Временами дождь','Временами снег','Ясно','Пасмурно','Слабый дождь','Слабый снег','Умеренный дождь','Умеренный снег','Сильный снегопад','Сильный дождь','Песчаная буря','Мокрый снег','Туман','Дымка','Дождь с грозой','Метель','Пыльно','Ливень','Дождь с градом','Сильный дождь с градом','Сильный дождь','Пыльная буря','Сильная песчаная буря','Сильный дождь','Обновите погоду','Облачно ночью','Дождливо ночью','Ясно ночью'],
                        ['Cloudy','Showers','Snow Showers','Sunny','Overcast','Light Rain','Light Snow','Moderate Rain','Moderate Snow','Heavy Snow','Heavy Rain','Sandstorm','Rain and Snow','Fog','Hazy','T-Storms','Snowstorm','Floating dust','Very Heavy Rainstorm','Rain and Hail','T-Storms and Hail','Heavy Rainstorm','Dust','Heavy sand storm','Rainstorm','Unknown','Cloudy Nighttime','Showers Nighttime','Sunny Nighttime']
                    ];

                    this.props = {
                        night_icons: [0, 1, 2, 3, 14],
                        index: hmFS.SysProGetInt('WeatherProviderIndex') ?? 0,
                        show_toast: true,
                        temp_widget: null,
                        temp_max_widget: null,
                        temp_min_widget: null,
                        temp_feels_widget: null,
                        description_widget: null,
                        cityName_widget: null,
                        icon_widget: null,
                        time_sensor: null,
                        weather_sensor: null,
                        lang: (hmSetting.getLanguage() === 4 ? 0 : 1),
                        ...props
                    };

                    this.providers = [
                        { name: ['Zepp','Zepp'], appId: null },
                        { name: ['Погодный сервис','Weather service'], appId: 1065824 }
                    ];

                    this.last = {
                        weatherIcon: 25,
                        displayedIcon: '25',
                        weatherDescription: 'Нет данных',
                        temperature: '--',
                        temperatureFeels: '--',
                        temperatureMax: '--',
                        temperatureMin: '--',
                        cityName: '--',
                        modTime: null,
                        sunriseMins: 360,
                        sunsetMins: 1200
                    };

                    this._THROTTLE_MS = 6 * 60 * 1000;
                    this._lastUpdateMs = hmFS.SysProGetInt64("weatherLastUpdateMs") || 0;
                    this._isUpdating = false;

                    if (!this.props.time_sensor) this.props.time_sensor = curTime;

                    if (!this.props.weather_sensor) {
                        try {
                            this.props.weather_sensor = hmSensor.createSensor(hmSensor.id.WEATHER);
                        } catch (e) {
                            console.log('WEATHER sensor creation failed:', e);
                            this.props.weather_sensor = null;
                        }
                    }

                    if (isFinite(this.props.index)) {
                        hmFS.SysProSetInt('WeatherProviderIndex', this.props.index);
                    }
                }

                update(force = false) {
                    if (this._isUpdating) return;

                    const nowMs = Date.now();
                    const isTimeout = (nowMs - this._lastUpdateMs >= this._THROTTLE_MS);

                    if (!force && !isTimeout) return;

                    this._isUpdating = true;

                    const prov = this.providers[this.props.index];
                    const isZepp = prov.appId === null;

                    let shouldApply = force;

                    if (isZepp) {
                        shouldApply = isTimeout || force;
                    } else {                        
                        const modTime = this.getFileModTime(prov.appId);
                        if (force || !modTime || modTime !== this.last.modTime) {
                            this.last.modTime = modTime;
                            shouldApply = true;
                        } else if (isTimeout) {
                            shouldApply = true;
                        }
                    }

                    if (shouldApply) {
                        const newData = this.getWeatherData(prov.appId);
                        this._applyWeatherData(newData);
                    }

                    this._lastUpdateMs = nowMs;
                    hmFS.SysProSetInt64("weatherLastUpdateMs", nowMs);

                    this._isUpdating = false;
                }

                _applyWeatherData(newData) {
                    
                    const tVal = this.tempWithSign(newData.temperature);
                    if (tVal !== this.last.temperature) {
                        this.last.temperature = tVal;
                        this.props.temp_widget?.setProperty(hmUI.prop.TEXT, tVal);
                    }

                    const tMax = this.tempWithSign(newData.temperatureMax);
                    if (tMax !== this.last.temperatureMax) {
                        this.last.temperatureMax = tMax;
                        this.props.temp_max_widget?.setProperty(hmUI.prop.TEXT, tMax);
                    }

                    const tMin = this.tempWithSign(newData.temperatureMin);
                    if (tMin !== this.last.temperatureMin) {
                        this.last.temperatureMin = tMin;
                        this.props.temp_min_widget?.setProperty(hmUI.prop.TEXT, tMin);
                    }

                    const tFeels = this.tempWithSign(newData.temperatureFeels);
                    if (tFeels !== this.last.temperatureFeels) {
                        this.last.temperatureFeels = tFeels;
                        this.props.temp_feels_widget?.setProperty(hmUI.prop.TEXT, tFeels);
                    }

                    if (newData.cityName !== this.last.cityName) {
                        this.last.cityName = newData.cityName;
                        this.props.cityName_widget?.setProperty(hmUI.prop.TEXT, newData.cityName);
                    }

                    if (newData.weatherDescription !== this.last.weatherDescription) {
                        this.last.weatherDescription = newData.weatherDescription;
                        this.props.description_widget?.setProperty(hmUI.prop.TEXT, newData.weatherDescription);
                    }
                    
                    let curIcon = parseInt(newData.weatherIcon);
                    let iconSuffix = (this.props.night_icons.includes(curIcon) && !this.isDayNow()) ? 'n' : '';
                    const finalIconStr = `${curIcon}${iconSuffix}`;

                    if (finalIconStr !== this.last.displayedIcon) {
                        this.last.displayedIcon = finalIconStr;
                        this.last.weatherIcon = curIcon;
                        this.props.icon_widget?.setProperty(hmUI.prop.SRC, `w_${finalIconStr}.png`);
                    }
                }

                tempWithSign(val) {
                    let fVal = parseFloat(val);
                    if (isNaN(fVal) || !isFinite(fVal)) return '--';
                    return (fVal > 0 ? '+' : '') + Math.round(fVal) + '°';
                }

                isDayNow() {
                    const ts = this.props.time_sensor;
                    let curMins;

                    if (ts && typeof ts.hour === 'number' && typeof ts.minute === 'number') {
                        curMins = ts.hour * 60 + ts.minute;
                    } else {
                        const now = new Date();
                        curMins = now.getHours() * 60 + now.getMinutes();
                    }

                    if (isNaN(this.last.sunriseMins) || isNaN(this.last.sunsetMins)) {
                        return true;
                    }

                    return curMins >= this.last.sunriseMins && curMins < this.last.sunsetMins;
                }

                getWeatherData(app_id = null) {
                    return !app_id ? this.getZeppWeatherData() : this.getAppWeatherData(app_id);
                }

                getZeppWeatherData() {
                    try {
                        const ws = this.props.weather_sensor;
                        if (!ws) throw new Error("No Sensor");

                        const fw = ws.getForecastWeather ? ws.getForecastWeather() : null;
                        const cityName = fw ? fw.cityName : '--';
                        const iconIndex = ws.curAirIconIndex ?? 25;

                        if (fw && fw.forecastData && fw.forecastData.count > 0) {
                            const today = fw.forecastData.data[0];
                            if (today.sunrise && today.sunset) {
                                const riseHour = parseInt(today.sunrise.hour);
                                const riseMin = parseInt(today.sunrise.minute);
                                const setHour = parseInt(today.sunset.hour);
                                const setMin = parseInt(today.sunset.minute);

                                if (!isNaN(riseHour) && !isNaN(riseMin) && !isNaN(setHour) && !isNaN(setMin)) {
                                    this.last.sunriseMins = riseHour * 60 + riseMin;
                                    this.last.sunsetMins = setHour * 60 + setMin;
                                    this.last.sunData = this.props.time_sensor ? this.props.time_sensor.day : new Date().getDate();
                                }
                            }
                        }

                        return {
                            weatherIcon: iconIndex,
                            weatherDescription: this.description[this.props.lang][iconIndex] || 'Нет данных',
                            temperature: ws.current ?? '--',
                            temperatureFeels: ws.feelsLike ?? '--',
                            temperatureMax: ws.high ?? '--',
                            temperatureMin: ws.low ?? '--',
                            cityName: cityName
                        };
                    } catch (e) {
                        console.log('getZeppWeatherData error:', e);
                        return { weatherIcon:25, weatherDescription:'Нет данных', temperature:'--', temperatureFeels:'--', temperatureMax:'--', temperatureMin:'--', cityName:'--' };
                    }
                }

                getAppWeatherData(app_id) {
                    const data = { weatherIcon: 25, weatherDescription: 'Нет данных', temperature: '--', temperatureFeels: '--', temperatureMax: '--', temperatureMin: '--', cityName: '--' };
                    const weather_str = this.readFile(app_id);
                    if (!weather_str) return data;

                    try {
                        const weatherJson = JSON.parse(weather_str);
                        if (weatherJson) {
                            data.weatherIcon = this.getZeppIconIndex(parseInt(weatherJson.weatherIcon || 25), app_id);

                            if (weatherJson.weatherDescriptionExtended) {
                                const desc = weatherJson.weatherDescriptionExtended;
                                data.weatherDescription = desc.charAt(0).toUpperCase() + desc.slice(1);
                            } else {
                                data.weatherDescription = this.description[this.props.lang][data.weatherIcon] || 'Нет данных';
                            }

                            data.temperature = weatherJson.temperature ?? '--';
                            data.temperatureFeels = weatherJson.temperatureFeels ?? '--';
                            data.temperatureMax = weatherJson.temperatureMax ?? '--';
                            data.temperatureMin = weatherJson.temperatureMin ?? '--';
                            data.cityName = weatherJson.city || '--';
                        }
                    } catch (e) {
                        console.log('JSON Parse error in getAppWeatherData:', e);
                    }
                    return data;
                }

                getZeppIconIndex(index, app_id = null) {
                    if (!app_id) return index;
                    if (app_id === 1065824) return this.iconMapService[index] ?? 25;
                    if (app_id === 1066654) return index - 1;
                    return index;
                }

                readFile(app_id) {
                    if (!app_id) return null;
                    try {
                        const [fs_stat, err] = hmFS.stat('weather.json', { appid: app_id });
                        if (err === 0 && fs_stat.size > 0) {
                            const fh = hmFS.open('weather.json', hmFS.O_RDONLY, { appid: app_id });
                            const array_buffer = new ArrayBuffer(fs_stat.size);
                            hmFS.read(fh, array_buffer, 0, fs_stat.size);
                            hmFS.close(fh);
                            return this.arrayBufferToCyrillic(array_buffer);
                        }
                    } catch (e) {
                        console.log('readFile error:', e);
                    }
                    return null;
                }

                getFileModTime(app_id) {
                    if (!app_id) return null;
                    try {
                        const [fs_stat, err] = hmFS.stat('weather.json', { appid: app_id });
                        if (err === 0) return fs_stat.mtime;
                    } catch (e) {}
                    return null;
                }

                arrayBufferToCyrillic(buffer) {
                    let result = '';
                    const bytes = new Uint8Array(buffer);
                    for (let i = 0; i < bytes.length;) {
                        let byte1 = bytes[i++];
                        if (byte1 < 0x80) {
                            result += String.fromCharCode(byte1);
                        } else if (byte1 >= 0xC0 && byte1 < 0xE0) {
                            let byte2 = bytes[i++];
                            result += String.fromCharCode(((byte1 & 0x1F) << 6) | (byte2 & 0x3F));
                        } else if (byte1 >= 0xE0 && byte1 < 0xF0) {
                            let byte2 = bytes[i++];
                            let byte3 = bytes[i++];
                            result += String.fromCharCode(((byte1 & 0x0F) << 12) | ((byte2 & 0x3F) << 6) | (byte3 & 0x3F));
                        }
                    }
                    return result;
                }

                next(show_toast = this.props.show_toast) {
                    this.props.index = (this.props.index + 1) % this.providers.length;
                    hmFS.SysProSetInt('WeatherProviderIndex', this.props.index);
                    this.last.modTime = 0;                    
                    if (show_toast) hmUI.showToast({ text: this.providers[this.props.index].name[this.props.lang] });
                    this.update(true);
                }

                prev(show_toast = this.props.show_toast) {
                    this.props.index = (this.props.index - 1 + this.providers.length) % this.providers.length;
                    hmFS.SysProSetInt('WeatherProviderIndex', this.props.index);
                    this.last.modTime = 0;                    
                    if (show_toast) hmUI.showToast({ text: this.providers[this.props.index].name[this.props.lang] });
                    this.update(true);
                }

                get cityName() { return this.last.cityName ?? '--'; }
                get temperature() { return this.last.temperature ?? '--'; }
                get temperatureFeels() { return this.last.temperatureFeels ?? '--'; }
                get temperatureMax() { return this.last.temperatureMax ?? '--'; }
                get temperatureMin() { return this.last.temperatureMin ?? '--'; }
                get weatherDescription() { return this.last.weatherDescription ?? 'Нет данных'; }
                get weatherIcon() { return this.last.weatherIcon ?? 25; }

                delete() {
                    this._isUpdating = false;
                    this.props = null;
                    this.last = null;
                    this.description = null;
                    this.iconMapService = null;
                    this.providers = null;
                }
            }

            // --------------------
            // day/year/zodiac
            // --------------------
            function isLeapYear(year) {
                return (year % 4 === 0 && year % 100 !== 0) || (year % 400 === 0);
            }
            function getDayOfYear(year, month, day) {
                const monthDays = [0, 31, 59, 90, 120, 151, 181, 212, 243, 273, 304, 334];
                let days = monthDays[month - 1] + day;
                if (month > 2 && isLeapYear(year)) days += 1;
                return days;
            }
            function updateDayOfYear() {
                if (curTime.day !== lastDayChecked) {
                    lastDayChecked = curTime.day;
                    const dayOfYear = getDayOfYear(curTime.year, curTime.month, curTime.day);
                    normal_day_now.setProperty(hmUI.prop.TEXT, String(dayOfYear).padStart(3, '0'));
                }
            }
            function updateZodiacIfNeeded() {
                if (!lastZodiacDay || lastZodiacDay !== curTime.day) {
                    updateZodiacSign();
                }
            }
            function getZodiacSign(month, day) {
                if ((month === 1 && day >= 20) || (month === 2 && day <= 18)) return 0;
                if ((month === 2 && day >= 19) || (month === 3 && day <= 20)) return 1;
                if ((month === 3 && day >= 21) || (month === 4 && day <= 19)) return 2;
                if ((month === 4 && day >= 20) || (month === 5 && day <= 20)) return 3;
                if ((month === 5 && day >= 21) || (month === 6 && day <= 20)) return 4;
                if ((month === 6 && day >= 21) || (month === 7 && day <= 22)) return 5;
                if ((month === 7 && day >= 23) || (month === 8 && day <= 22)) return 6;
                if ((month === 8 && day >= 23) || (month === 9 && day <= 22)) return 7;
                if ((month === 9 && day >= 23) || (month === 10 && day <= 22)) return 8;
                if ((month === 10 && day >= 23) || (month === 11 && day <= 21)) return 9;
                if ((month === 11 && day >= 22) || (month === 12 && day <= 21)) return 10;
                return 11;
            }
            function updateZodiacSign() {
                const today = curTime.day;
                if (lastZodiacDay === today && currentZodiacIndex !== null) return;
                const month = curTime.month;
                const day = curTime.day;
                const newIndex = getZodiacSign(month, day);
                if (newIndex !== currentZodiacIndex) {
                    currentZodiacIndex = newIndex;
                    try { zodiacImage.setProperty(hmUI.prop.SRC, 'zodiac_' + newIndex + '.png'); } catch(e){}
                }
                lastZodiacDay = today;
            }
            
            // ================================================
            // AdvancedBarometer v3.3 — Стабильная + энергоэффективная версия
            // ================================================
            class AdvancedBarometer {
                constructor(props = {}) {
                    this.props = {
                        unit_index: hmFS.SysProGetInt('BaroUnitIndex') ?? 0,
                        widget: null,
                        trend_widget: null,
                        lang: hmSetting.getLanguage() === 4 ? 0 : 1,
                        d_time: 30,                    
                        change_threshold: 0.15,        
                        ...props
                    };

                    this.unitStr = [
                        ['мм рт.ст.', 'mmHg'],
                        ['гПа', 'hPa']
                    ];

                    this.last = { value: null, trend: '' };

                    this.prev = {
                        value: hmFS.SysProGetDouble('BaroPrevValue') || null,
                        time: hmFS.SysProGetInt64('BaroPrevTime') || 0
                    };

                    this._changeHandler = null;
                    this.baroSensor = null;

                    try {
                        this.baroSensor = hmSensor.createSensor(hmSensor.id.BARO);

                        this._changeHandler = () => this._onPressureChange();
                        this.baroSensor.addEventListener(hmSensor.event.CHANGE, this._changeHandler);

                        setTimeout(() => this._onPressureChange(), 400);

                    } catch (e) {
                        console.log('BARO sensor creation failed:', e);
                        this.baroSensor = null;
                    }

                    hmFS.SysProSetInt('BaroUnitIndex', this.props.unit_index);
                }

                _onPressureChange() {
                    if (!this.baroSensor || !this.props) return;

                    const rawValue = this.baroSensor.pressure;
                    if (!rawValue || rawValue <= 300 || rawValue > 1200) return;

                    // === 1. Фильтр дребезга (по сырому значению) ===
                    if (this.last.value !== null) {
                        const diff = Math.abs(rawValue - this.last.value);
                        if (diff < this.props.change_threshold) {
                            return;
                        }
                    }

                    let trend = '';
                    if (this.prev.value !== null) {
                        const diff = rawValue - this.prev.value;
                        if (diff > 0.5)      trend = '\u2191';
                        else if (diff < -0.5) trend = '\u2193';
                    }

                    // === 3. Проверка реального изменения отображаемого значения ===
                    const newDisplay = this.props.unit_index === 0 
                        ? Math.round(rawValue * 0.750064).toString()
                        : Math.round(rawValue).toString();

                    const currentDisplay = this.pressure;

                    const displayChanged = (newDisplay !== currentDisplay);
                    const trendChanged = (trend !== this.last.trend);

                    if (displayChanged || trendChanged) {
                        this.last.value = rawValue;   
                        this.last.trend = trend;
                        this._updateWidgets();
                    }

                    const now = Date.now();
                    if (now - this.prev.time > this.props.d_time * 60 * 1000) {
                        this.prev.value = rawValue;
                        this.prev.time = now;

                        hmFS.SysProSetDouble('BaroPrevValue', rawValue);
                        hmFS.SysProSetInt64('BaroPrevTime', now);
                    }
                }

                _updateWidgets() {
                    if (!this.props) return;

                    if (this.props.widget) {
                        this.props.widget.setProperty(hmUI.prop.TEXT, this.pressure);
                    }

                    if (this.props.trend_widget) {
                        this.props.trend_widget.setProperty(hmUI.prop.TEXT, this.last.trend || ' ');
                    }
                }

                get mmHg() {
                    const v = this.last.value;
                    return (v == null || !isFinite(v)) ? '--' : Math.round(v * 0.750064).toString();
                }

                get hPa() {
                    const v = this.last.value;
                    return (v == null || !isFinite(v)) ? '--' : Math.round(v).toString();
                }

                get pressure() {
                    return this.props.unit_index === 0 ? this.mmHg : this.hPa;
                }

                get unit() {
                    return this.unitStr[this.props.unit_index][this.props.lang];
                }

                toggleUnits(show_toast = true) {
                    if (!this.props) return;
                    this.props.unit_index = (this.props.unit_index + 1) % 2;
                    hmFS.SysProSetInt('BaroUnitIndex', this.props.unit_index);
                    this._updateWidgets();
                    if (show_toast) hmUI.showToast({ text: this.unit });
                }

                delete() {
                    if (this.baroSensor && this._changeHandler) {
                        try {
                            this.baroSensor.removeEventListener(hmSensor.event.CHANGE, this._changeHandler);
                        } catch (e) {}
                    }

                    this.baroSensor = null;
                    this._changeHandler = null;
                    this.last = null;
                    this.prev = null;
                    this.props = null;
                }
            }
            
            // -------------------
            // updateBatteryLife v3.0
            // -------------------
            function drawBatteryWidget(currentBatt, delta, daysWorked) {
                try {
                    if (!normal_battery_life) return;
                    delta = Math.round(Number(delta)) || DEFAULT_DELTA;
                    if (delta < 1) delta = DEFAULT_DELTA;
                    let daysLeft = Math.max(0, Math.ceil(currentBatt / delta));
                    normal_battery_life.setProperty(hmUI.prop.TEXT, `${Math.round(delta)}% ${daysWorked}-${daysLeft}`);
                } catch (e) {
                    normal_battery_life && normal_battery_life.setProperty(hmUI.prop.TEXT, `${Math.round(delta || DEFAULT_DELTA)}% ${daysWorked}-??`);
                    console.log('drawBatteryWidget error:', e);
                }
            }

            function resetChargingStats(todayKey, currentBatt, oldDelta) {
                const prevDate = readIntSafe(BK.DATE, 0);
                const prevBatt = readIntSafe(BK.BATT, -1);
                
                if (prevDate !== todayKey) hmFS.SysProSetInt(BK.DATE, todayKey);
                if (prevBatt !== currentBatt) hmFS.SysProSetInt(BK.BATT, currentBatt);

                hmFS.SysProSetInt(BK.DAYS, 0);
                hmFS.SysProSetInt(BK.FLAG, 0);
                hmFS.SysProSetInt(BK.D1, 0);
                hmFS.SysProSetInt(BK.D2, 0);

                drawBatteryWidget(currentBatt, oldDelta, 0); 
            }

            function checkDayAndLearn() {
                try {
                    if (!battery || !curTime) return;
                    const cur = battery.current;
                    if (typeof cur !== 'number' || cur < 0 || cur > 100) return;

                    const todayKey = curTime.year * 10000 + curTime.month * 100 + curTime.day;

                    let cacheDate = readIntSafe(BK.DATE, 0);
                    let cacheBatt = readIntSafe(BK.BATT, -1);
                    let days = readIntSafe(BK.DAYS, 0);
                    const oldDays = days; 

                    let delta = readIntSafe(BK.DELTA, DEFAULT_DELTA);
                    if (delta < MIN_DAILY_DRAIN || delta > MAX_DAILY_DRAIN) delta = DEFAULT_DELTA;

                    if (cacheDate === 0) return;

                    if (cur > cacheBatt) {
                        resetChargingStats(todayKey, cur, delta);
                        return;
                    }

                    if (todayKey > cacheDate) {
                        
                        const drain = Math.max(0, cacheBatt - cur); 
                        days = days + 1;

                        let flag = readIntSafe(BK.FLAG, 0);
                        let currentDelta = delta; 

                        if (days > 1) {
                            if (flag === 0) {
                                hmFS.SysProSetInt(BK.D1, drain);
                                hmFS.SysProSetInt(BK.FLAG, 1);
                            } else if (flag === 1) {
                                hmFS.SysProSetInt(BK.D2, drain);
                                hmFS.SysProSetInt(BK.FLAG, 2);
                            } else if (flag === 2) {
                                const d1 = readIntSafe(BK.D1, 0);
                                const d2 = readIntSafe(BK.D2, 0);
                                const avg = Math.round((d1 + d2 + drain) / 3);
                                let newDelta = avg;
                                if (avg < MIN_DAILY_DRAIN || avg > MAX_DAILY_DRAIN) {
                                    newDelta = (delta >= MIN_DAILY_DRAIN && delta <= MAX_DAILY_DRAIN) ? delta : DEFAULT_DELTA;
                                }
                                if (newDelta !== delta) {
                                    hmFS.SysProSetInt(BK.DELTA, newDelta);
                                    currentDelta = newDelta; 
                                }

                                hmFS.SysProSetInt(BK.FLAG, 0);
                                hmFS.SysProSetInt(BK.D1, 0);
                                hmFS.SysProSetInt(BK.D2, 0);
                            }
                        }

                        if (cacheDate !== todayKey) hmFS.SysProSetInt(BK.DATE, todayKey);
                        if (cacheBatt !== cur) hmFS.SysProSetInt(BK.BATT, cur);
                        if (days !== oldDays) hmFS.SysProSetInt(BK.DAYS, days);
                        
                        updateBatteryLife(true, days, currentDelta); 

                    } else if (todayKey < cacheDate) {
                        resetChargingStats(todayKey, cur, delta);
                    }
                } catch (e) {
                    console.log('checkDayAndLearn error:', e);
                }
            }

            function updateBatteryLife(forceDraw = false, daysOverride, deltaOverride) {
                try {
                    if (!battery || !curTime) return;
                    if (!normal_battery_life) return;

                    const cur = battery.current;
                    if (typeof cur !== 'number' || cur < 0 || cur > 100) return;

                    const todayKey = curTime.year * 10000 + curTime.month * 100 + curTime.day;

                    let cacheDate = readIntSafe(BK.DATE, 0);
                    let cacheBatt = readIntSafe(BK.BATT, -1);
                    let days = readIntSafe(BK.DAYS, 0);
                    let delta = readIntSafe(BK.DELTA, DEFAULT_DELTA);
                    if (delta < MIN_DAILY_DRAIN || delta > MAX_DAILY_DRAIN) delta = DEFAULT_DELTA;
                    
                    const daysToDraw = daysOverride !== undefined ? daysOverride : days;
                    const deltaToDraw = deltaOverride !== undefined ? deltaOverride : delta;

                    if (!cacheDate || cur > cacheBatt) {
                        resetChargingStats(todayKey, cur, deltaToDraw); 
                        return;
                    }

                    if (!forceDraw && cacheDate === todayKey) return;

                    drawBatteryWidget(cur, deltaToDraw, daysToDraw);
                } catch (e) {
                    console.log('updateBatteryLife error:', e);
                }
            }
            
            // -----------
            // UI creation
            // -----------
            function click_Bezel() {
              if(bezel_num>=bezel_all) {bezel_num=1;}
              else { bezel_num=bezel_num+1;}
              hmUI.showToast({text: "Основной " + parseInt(bezel_num) });
                normal_background_bg_img.setProperty(hmUI.prop.SRC, "osn_" + parseInt(bezel_num) + ".png");
            }
            function click_Bezel1() {
              if(bezel_num1>=bezel_all1) {bezel_num1=1;}
              else { bezel_num1=bezel_num1+1;}
              hmUI.showToast({text: "Безель " + parseInt(bezel_num1) });
                normal_image_img.setProperty(hmUI.prop.SRC, "zapl_" + parseInt(bezel_num1) + ".png");
            }
            function click_Bezel2() {
              if(bezel_num2>=bezel_all2) {bezel_num2=1;}
              else { bezel_num2=bezel_num2+1;}
              hmUI.showToast({text: "Цвет " + parseInt(bezel_num2) });
                normal_image2_img.setProperty(hmUI.prop.SRC, "zapl_T_" + parseInt(bezel_num2) + ".png");
            } 
        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            // FontName: HONOR.ttf; FontSize: 29
            hmUI.createWidget(hmUI.widget.TEXT, {
              x: 464,
              y: 464,
              w: 350,
              h: 46,
              text_size: 29,
              char_space: 0,
              line_space: 0,
              font: 'fonts/HONOR.ttf',
              color: 0xFFFFFFFF,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              text: "0123456789 _-.,:;`'%°\\/",
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // FontName: HONOR.ttf; FontSize: 18
            hmUI.createWidget(hmUI.widget.TEXT, {
              x: 464,
              y: 464,
              w: 206,
              h: 28,
              text_size: 18,
              char_space: 0,
              line_space: 0,
              font: 'fonts/HONOR.ttf',
              color: 0xFFFFFFFF,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              text: "0123456789 _-.,:;`'%°\\/",
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // FontName: Netflix.ttf; FontSize: 23; Cache: full
            hmUI.createWidget(hmUI.widget.TEXT, {
              x: 464,
              y: 464,
              w: 27,
              h: 27,
              text_size: 23,
              char_space: 0,
              line_space: 0,
              font: 'fonts/Netflix.ttf',
              color: 0xFFFFFFFF,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.NONE,
              text: "0123456789 ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz АБВГДЕЁЖЗИЙКЛМНОПРСТУФХЦЧШЩЪЫЬЭЮЯабвгдеёжзийклмнопрстуфхцчшщъыьэюя  ҐЄІЇґєії _-.,:;`'%°\\/",
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // FontName: HONOR.ttf; FontSize: 28
            hmUI.createWidget(hmUI.widget.TEXT, {
              x: 464,
              y: 464,
              w: 358,
              h: 44,
              text_size: 28,
              char_space: 1,
              line_space: 0,
              font: 'fonts/HONOR.ttf',
              color: 0xFFFFFFFF,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              text: "0123456789 _-.,:;`'%°\\/",
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // FontName: HONOR.ttf; FontSize: 21
            hmUI.createWidget(hmUI.widget.TEXT, {
              x: 464,
              y: 464,
              w: 279,
              h: 33,
              text_size: 21,
              char_space: 1,
              line_space: 0,
              font: 'fonts/HONOR.ttf',
              color: 0xFFFFFFFF,
              align_h: hmUI.align.LEFT,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              text: "0123456789 _-.,:;`'%°\\/",
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 466,
              h: 466,
              src: 'osn_1.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            curTimeMinuteHandler = () => {
                time_update(curTime.minute === 0, true);
                checkDayAndLearn();                             
            };

            // normal_hour_circle_scale = hmUI.createWidget(hmUI.widget.Circle_Scale, {
              // center_x: 233,
              // center_y: 233,
              // start_angle: -114,
              // end_angle: -62,
              // radius: 164,
              // line_width: 8,
              // line_cap: Rounded,
              // color: 0xFFFFFFFF,
              // mirror: False,
              // inversion: False,
              // alpha: 255,
              // type: hmUI.data_type.HOUR,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });


            normal_hour_circle_scale = hmUI.createWidget(hmUI.widget.ARC_PROGRESS, {
              center_x: 233,
              center_y: 233,
              start_angle: -114,
              end_angle: -62,
              radius: 160,
              line_width: 8,
              corner_flag: 0,
              color: 0xFFFFFFFF,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_time_circle_options = hmUI.createWidget(hmUI.widget.TIME_CIRCLE_OPTIONS, {
              // smooth: false,
              // format24h: true,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_image2_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'zapl_T_1.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            zodiacImage = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'zodiac_0.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            updateZodiacIfNeeded();             


            normal_alarm_clock_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 208,
              y: 376,
              font_array: ["bd_0.png","bd_1.png","bd_2.png","bd_3.png","bd_4.png","bd_5.png","bd_6.png","bd_7.png","bd_8.png","bd_9.png"],
              padding: true,
              h_space: 0,
              invalid_image: 'clean.png',
              dot_image: 'bd_dv.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.ALARM_CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            normal_readiness_current_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 130,
              y: 338,
              w: 146,
              h: 39,
              text_size: 29,
              char_space: 0,
              font: 'fonts/HONOR.ttf',
              color: 0xFFFFFFFF,
              line_space: 0,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.READINESS,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 92,
              hour_startY: 153,
              hour_array: ["H_0.png","H_1.png","H_2.png","H_3.png","H_4.png","H_5.png","H_6.png","H_7.png","H_8.png","H_9.png"],
              hour_zero: 1,
              hour_space: -4,
              hour_angle: 0,
              hour_align: hmUI.align.CENTER_H,

              minute_startX: 248,
              minute_startY: 155,
              minute_array: ["M_0.png","M_1.png","M_2.png","M_3.png","M_4.png","M_5.png","M_6.png","M_7.png","M_8.png","M_9.png"],
              minute_zero: 1,
              minute_space: -5,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.CENTER_H,

              second_startX: 354,
              second_startY: 212,
              second_array: ["S_0.png","S_1.png","S_2.png","S_3.png","S_4.png","S_5.png","S_6.png","S_7.png","S_8.png","S_9.png"],
              second_zero: 1,
              second_space: 0,
              second_angle: 0,
              second_follow: 0,
              second_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_moon_high_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 303,
              y: 185,
              w: 146,
              h: 29,
              text_size: 18,
              char_space: 0,
              font: 'fonts/HONOR.ttf',
              color: 0xFFFFFFFF,
              line_space: 0,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.MOON_RISE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_moon_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 359,
              y: 159,
              image_array: ["Moon_01.png","Moon_02.png","Moon_03.png","Moon_04.png","Moon_05.png","Moon_06.png","Moon_07.png","Moon_08.png","Moon_09.png","Moon_10.png","Moon_11.png","Moon_12.png","Moon_13.png","Moon_14.png","Moon_15.png","Moon_16.png","Moon_17.png","Moon_18.png","Moon_19.png","Moon_20.png","Moon_21.png","Moon_22.png","Moon_23.png","Moon_24.png","Moon_25.png","Moon_26.png","Moon_27.png","Moon_28.png","Moon_29.png","Moon_30.png"],
              image_length: 30,
              type: hmUI.data_type.MOON,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_day_now = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 312,
              y: 312,
              w: 80,
              h: 30,
              text_size: 21,
              char_space: 0,
              font: 'fonts/HONOR.ttf',
              color: 0xFFFFFFFF,
              line_space: 0,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.CENTER_H,
              text: '---',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            updateDayOfYear();              

            normal_date_img_date_month_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 233,
              month_startY: 97,
              month_sc_array: ["month_0.png","month_1.png","month_2.png","month_3.png","month_4.png","month_5.png","month_6.png","month_7.png","month_8.png","month_9.png","month_10.png","month_11.png"],
              month_tc_array: ["month_0.png","month_1.png","month_2.png","month_3.png","month_4.png","month_5.png","month_6.png","month_7.png","month_8.png","month_9.png","month_10.png","month_11.png"],
              month_en_array: ["month_0.png","month_1.png","month_2.png","month_3.png","month_4.png","month_5.png","month_6.png","month_7.png","month_8.png","month_9.png","month_10.png","month_11.png"],
              month_is_character: true ,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_year = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              year_startX: 350,
              year_startY: 289,
              year_sc_array: ["yearText_0.png","yearText_1.png","yearText_2.png","yearText_3.png","yearText_4.png","yearText_5.png","yearText_6.png","yearText_7.png","yearText_8.png","yearText_9.png"],
              year_tc_array: ["yearText_0.png","yearText_1.png","yearText_2.png","yearText_3.png","yearText_4.png","yearText_5.png","yearText_6.png","yearText_7.png","yearText_8.png","yearText_9.png"],
              year_en_array: ["yearText_0.png","yearText_1.png","yearText_2.png","yearText_3.png","yearText_4.png","yearText_5.png","yearText_6.png","yearText_7.png","yearText_8.png","yearText_9.png"],
              year_zero: 1,
              year_space: 0,
              year_align: hmUI.align.CENTER_H,
              year_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 234,
              y: 66,
              week_en: ["day_0.png","day_1.png","day_2.png","day_3.png","day_4.png","day_5.png","day_6.png"],
              week_tc: ["day_0.png","day_1.png","day_2.png","day_3.png","day_4.png","day_5.png","day_6.png"],
              week_sc: ["day_0.png","day_1.png","day_2.png","day_3.png","day_4.png","day_5.png","day_6.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 176,
              day_startY: 70,
              day_sc_array: ["chisl_0.png","chisl_1.png","chisl_2.png","chisl_3.png","chisl_4.png","chisl_5.png","chisl_6.png","chisl_7.png","chisl_8.png","chisl_9.png"],
              day_tc_array: ["chisl_0.png","chisl_1.png","chisl_2.png","chisl_3.png","chisl_4.png","chisl_5.png","chisl_6.png","chisl_7.png","chisl_8.png","chisl_9.png"],
              day_en_array: ["chisl_0.png","chisl_1.png","chisl_2.png","chisl_3.png","chisl_4.png","chisl_5.png","chisl_6.png","chisl_7.png","chisl_8.png","chisl_9.png"],
              day_zero: 0,
              day_space: 0,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_stand_current_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 204,
              y: 308,
              w: 146,
              h: 39,
              text_size: 29,
              char_space: 0,
              font: 'fonts/HONOR.ttf',
              color: 0xFFFFFFFF,
              line_space: 0,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.STAND,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_stress_current_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 136,
              y: 308,
              w: 146,
              h: 39,
              text_size: 29,
              char_space: 0,
              font: 'fonts/HONOR.ttf',
              color: 0xFFFFFFFF,
              line_space: 0,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.STRESS,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 274,
              y: 338,
              w: 146,
              h: 39,
              text_size: 29,
              char_space: 0,
              font: 'fonts/HONOR.ttf',
              color: 0xFFFFFFFF,
              line_space: 0,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_calorie_current_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 274,
              y: 308,
              w: 146,
              h: 39,
              text_size: 29,
              char_space: 0,
              font: 'fonts/HONOR.ttf',
              color: 0xFFFFFFFF,
              line_space: 0,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sleep_time_font = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 274,
              y: 278,
              w: 146,
              h: 39,
              text_size: 29,
              char_space: 0,
              font: 'fonts/HONOR.ttf',
              color: 0xFFFFFFFF,
              line_space: 0,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.LEFT,
              // padding: true,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            const weatherInfo = hmUI.createWidget(hmUI.widget.GROUP, {
              x: 0,
              y: 0,
              w: 466,
              h: 466,
            });

            weatherImg = weatherInfo.createWidget(hmUI.widget.IMG, {
                x: 312,
                y: 98,
                w: 80,
                h: 80,
                src: 'w_25.png',
                show_level: hmUI.show_level.ONLY_NORMAL,
            });

            tempText = weatherInfo.createWidget(hmUI.widget.TEXT, {
                x: 71,
                y: 95,
                w: 146,
                h: 39,
                text_size: 29,
                char_space: 0,
                line_space: 0,
                font: 'fonts/HONOR.ttf',
                text: '--',
                color: 0xFFFFFFFF,
                align_h: hmUI.align.CENTER_H,
                align_v: hmUI.align.TOP,
                unit_type: 1,
                text_style: hmUI.text_style.ELLIPSIS,
                show_level: hmUI.show_level.ONLY_NORMAL,
            });

            descriptionText = hmUI.createWidget(hmUI.widget.TEXT, {
                x: 123,
                y: 127,
                w: 230,
                h: 30,
                text_size: 21,
                char_space: 0,
                line_space: 0,
                font: 'fonts/HONOR.ttf',
                text: '--',
                color: 0xFFFFFFFF,
                align_h: hmUI.align.CENTER_H,
                align_v: hmUI.align.TOP,
                text_style: hmUI.text_style.ELLIPSIS,
                show_level: hmUI.show_level.ONLY_NORMAL,
            });


            cityNameText = hmUI.createWidget(hmUI.widget.TEXT, {
                x: -2,
                y: -2,
                w: 470,
                h: 470,
                text_size: 23,
                char_space: 0,
                font: 'fonts/Netflix.ttf',
                color: 0xFFFFFFFF,
                // use_text_circle: true,
                start_angle: -36,
                end_angle: 37,
                mode: 0,
                // radius: 242,
                align_h: hmUI.align.CENTER_H,
                text: "--",
                show_level: hmUI.show_level.ONLY_NORMAL,
            });

            weatherProvider = new WeatherProvider({
                time_sensor: curTime,
                temp_widget: tempText,
                cityName_widget: cityNameText,
                icon_widget: weatherImg,
                description_widget: descriptionText,
                night_icons: [0, 1, 2, 3, 14],
                show_toast: true
            });
            weatherProvider.update(true);                

            normal_image_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'zapl_1.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            text_pressure = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 26,
              y: 26,
              w: 414,
              h: 414,
              text_size: 28,
              char_space: 1,
              font: 'fonts/HONOR.ttf',
              color: 0xFFFFFFFF,
              // use_text_circle: true,
              start_angle: -25,
              end_angle: 114,
              mode: 0,
              // radius: 207,
              align_h: hmUI.align.CENTER_H,
              text: "--",
              show_level: hmUI.show_level.ONLY_NORMAL,
            });            

            text_trend_icon = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 26,
              y: 26,
              w: 414,
              h: 414,
              text_size: 23,
              char_space: 1,             
              color: 0xFFFFFFFF,
              // use_text_circle: true,
              start_angle: -1,
              end_angle: 114,
              mode: 0,
              // radius: 207,
              align_h: hmUI.align.CENTER_H,
              text: "--",
              show_level: hmUI.show_level.ONLY_NORMAL,
            });     
            
            barometer = new AdvancedBarometer({
                widget: text_pressure,
                trend_widget: text_trend_icon,
                time_sensor: curTime,   
            });               

            normal_distance_current_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 24,
              y: 24,
              w: 418,
              h: 418,
              text_size: 28,
              char_space: 1,
              font: 'fonts/HONOR.ttf',
              color: 0xFFFFFFFF,
              // use_text_circle: true,
              start_angle: 80,
              end_angle: 190,
              mode: 1,
              // radius: 209,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.DISTANCE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_humidity_current_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 24,
              y: 24,
              w: 418,
              h: 418,
              text_size: 28,
              char_space: 1,
              font: 'fonts/HONOR.ttf',
              color: 0xFFFFFFFF,
              // use_text_circle: true,
              start_angle: 28,
              end_angle: 180,
              mode: 1,
              // radius: 209,
              align_h: hmUI.align.CENTER_H,
              unit_type: 1,
              type: hmUI.data_type.HUMIDITY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_altitude_target_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 26,
              y: 26,
              w: 414,
              h: 414,
              text_size: 28,
              char_space: 1,
              font: 'fonts/HONOR.ttf',
              color: 0xFFFFFFFF,
              // use_text_circle: true,
              start_angle: 0,
              end_angle: 152,
              mode: 0,
              // radius: 207,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.ALTITUDE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sun_high_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 26,
              y: 26,
              w: 414,
              h: 414,
              text_size: 28,
              char_space: 1,
              font: 'fonts/HONOR.ttf',
              color: 0xFFFFFFFF,
              // use_text_circle: true,
              start_angle: -104,
              end_angle: 75,
              mode: 0,
              // radius: 207,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.SUN_RISE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sun_low_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 26,
              y: 26,
              w: 414,
              h: 414,
              text_size: 28,
              char_space: 1,
              font: 'fonts/HONOR.ttf',
              color: 0xFFFFFFFF,
              // use_text_circle: true,
              start_angle: -76,
              end_angle: 108,
              mode: 0,
              // radius: 207,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.SUN_SET,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_wind_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 94,
              y: 71,
              src: 'data_ms.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_wind_direction_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 28,
              y: 145,
              image_array: ["wind_0.png","wind_1.png","wind_2.png","wind_3.png","wind_4.png","wind_5.png","wind_6.png","wind_7.png"],
              image_length: 8,
              type: hmUI.data_type.WIND_DIRECTION,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_wind_current_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 26,
              y: 26,
              w: 414,
              h: 414,
              text_size: 28,
              char_space: 1,
              font: 'fonts/HONOR.ttf',
              color: 0xFFFFFFFF,
              // use_text_circle: true,
              start_angle: -120,
              end_angle: 19,
              mode: 0,
              // radius: 207,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WIND,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'zapl_ten1.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            batteryChangeHandler = () => {                                
                updateBatteryLife();               
            };
            try {
                battery.addEventListener(hmSensor.event.CHANGE, batteryChangeHandler);
            } catch (e) {
                console.log('Error adding BATTERY listener:', e);
            }               

            normal_battery_current_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: -1,
              y: -1,
              w: 468,
              h: 468,
              text_size: 21,
              char_space: 1,
              font: 'fonts/HONOR.ttf',
              color: 0xFFFFFFFF,
              // use_text_circle: true,
              start_angle: 150,
              end_angle: 214,
              mode: 1,
              // radius: 234,
              align_h: hmUI.align.LEFT,
              unit_type: 1,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 8,
              y: 280,
              image_array: ["batt_0.png","batt_1.png","batt_2.png","batt_3.png","batt_4.png","batt_5.png","batt_6.png","batt_7.png","batt_8.png","batt_9.png","batt_10.png","batt_11.png","batt_12.png","batt_13.png","batt_14.png","batt_15.png"],
              image_length: 16,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_life = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 0,
              y: 0,
              w: 466,
              h: 466,
              text_size: 21,
              char_space: 0,
              font: 'fonts/HONOR.ttf',
              color: 0xFFFFFFFF,
              // use_text_circle: true,
              start_angle: -181,
              end_angle: 0,
              mode: 0,
              // radius: 233,
              align_h: hmUI.align.CENTER_H,
              text: "8% 1-12",
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            updateBatteryLife(true);             

            normal_step_current_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 24,
              y: 24,
              w: 418,
              h: 418,
              text_size: 28,
              char_space: 3,
              font: 'fonts/HONOR.ttf',
              color: 0xFFFFFFFF,
              // use_text_circle: true,
              start_angle: 0,
              end_angle: 360,
              mode: 1,
              // radius: 209,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 0,
              y: 0,
              image_array: ["shag_0.png","shag_1.png","shag_2.png","shag_3.png","shag_4.png","shag_5.png","shag_6.png","shag_7.png","shag_8.png","shag_9.png","shag_10.png","shag_11.png","shag_12.png"],
              image_length: 13,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 228,
              y: 163,
              src: 'alarm.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 108,
              y: 364,
              src: 'bt_off1.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_year_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'calendar_0.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });  

            idle_background_bg = hmUI.createWidget(hmUI.widget.FILL_RECT, {
              x: 0,
              y: 0,
              w: 466,
              h: 466,
              color: '0xFF000000',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_month_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 233,
              month_startY: 97,
              month_sc_array: ["month_0.png","month_1.png","month_2.png","month_3.png","month_4.png","month_5.png","month_6.png","month_7.png","month_8.png","month_9.png","month_10.png","month_11.png"],
              month_tc_array: ["month_0.png","month_1.png","month_2.png","month_3.png","month_4.png","month_5.png","month_6.png","month_7.png","month_8.png","month_9.png","month_10.png","month_11.png"],
              month_en_array: ["month_0.png","month_1.png","month_2.png","month_3.png","month_4.png","month_5.png","month_6.png","month_7.png","month_8.png","month_9.png","month_10.png","month_11.png"],
              month_is_character: true ,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 234,
              y: 66,
              week_en: ["day_0.png","day_1.png","day_2.png","day_3.png","day_4.png","day_5.png","day_6.png"],
              week_tc: ["day_0.png","day_1.png","day_2.png","day_3.png","day_4.png","day_5.png","day_6.png"],
              week_sc: ["day_0.png","day_1.png","day_2.png","day_3.png","day_4.png","day_5.png","day_6.png"],
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 176,
              day_startY: 70,
              day_sc_array: ["chisl_0.png","chisl_1.png","chisl_2.png","chisl_3.png","chisl_4.png","chisl_5.png","chisl_6.png","chisl_7.png","chisl_8.png","chisl_9.png"],
              day_tc_array: ["chisl_0.png","chisl_1.png","chisl_2.png","chisl_3.png","chisl_4.png","chisl_5.png","chisl_6.png","chisl_7.png","chisl_8.png","chisl_9.png"],
              day_en_array: ["chisl_0.png","chisl_1.png","chisl_2.png","chisl_3.png","chisl_4.png","chisl_5.png","chisl_6.png","chisl_7.png","chisl_8.png","chisl_9.png"],
              day_zero: 0,
              day_space: 0,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_heart_rate_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 230,
              y: 290,
              src: 'pulse.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_heart_rate_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 262,
              y: 284,
              w: 146,
              h: 39,
              text_size: 29,
              char_space: 0,
              font: 'fonts/HONOR.ttf',
              color: 0xFFFFFFFF,
              line_space: 0,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 92,
              hour_startY: 153,
              hour_array: ["H_0.png","H_1.png","H_2.png","H_3.png","H_4.png","H_5.png","H_6.png","H_7.png","H_8.png","H_9.png"],
              hour_zero: 1,
              hour_space: -4,
              hour_angle: 0,
              hour_align: hmUI.align.CENTER_H,

              minute_startX: 246,
              minute_startY: 152,
              minute_array: ["Maod_0.png","Maod_1.png","Maod_2.png","Maod_3.png","Maod_4.png","Maod_5.png","Maod_6.png","Maod_7.png","Maod_8.png","Maod_9.png"],
              minute_zero: 1,
              minute_space: -8,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.CENTER_H,

              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_temperature_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 229,
              y: 153,
              src: 'M_dv.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 312,
              y: 98,
              image_array: ["w_0.png","w_1.png","w_2.png","w_3.png","w_4.png","w_5.png","w_6.png","w_7.png","w_8.png","w_9.png","w_10.png","w_11.png","w_12.png","w_13.png","w_14.png","w_15.png","w_16.png","w_17.png","w_18.png","w_19.png","w_20.png","w_21.png","w_22.png","w_23.png","w_24.png","w_25.png","w_26.png","w_27.png","w_28.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_temperature_current_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 73,
              y: 95,
              w: 146,
              h: 39,
              text_size: 29,
              char_space: 0,
              font: 'fonts/HONOR.ttf',
              color: 0xFFFFFFFF,
              line_space: 0,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.CENTER_H,
              unit_type: 1,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_readiness_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 221,
              y: 298,
              src: 'bio_aod.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_readiness_current_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 262,
              y: 313,
              w: 97,
              h: 49,
              text_size: 29,
              char_space: 0,
              font: 'fonts/HONOR.ttf',
              color: 0xFFFFFFFF,
              line_space: 0,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.READINESS,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_battery_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'zapl_ten1.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_battery_current_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 121,
              y: 313,
              w: 97,
              h: 39,
              text_size: 29,
              char_space: 0,
              font: 'fonts/HONOR.ttf',
              color: 0xFFFFFFFF,
              line_space: 0,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.RIGHT,
              unit_type: 1,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_step_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 233,
              y: 264,
              src: 'footstep.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_step_current_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 262,
              y: 256,
              w: 146,
              h: 39,
              text_size: 29,
              char_space: 0,
              font: 'fonts/HONOR.ttf',
              color: 0xFFFFFFFF,
              line_space: 0,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 228,
              y: 162,
              src: 'alarm1.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 131,
              y: 360,
              src: 'bt_off.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_AOD,
            });
            

            normal_step_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 195,
              y: 404,
              w: 77,
              h: 56,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 254,
              y: 343,
              w: 66,
              h: 32,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 98,
              y: 396,
              w: 56,
              h: 45,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 404,
              y: 253,
              w: 49,
              h: 52,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_stress_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 111,
              y: 307,
              w: 61,
              h: 32,
              type: hmUI.data_type.STRESS,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_countdown_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 273,
              y: 177,
              w: 49,
              h: 55,
              type: hmUI.data_type.COUNT_DOWN,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_stopwatch_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 357,
              y: 212,
              w: 38,
              h: 37,
              type: hmUI.data_type.STOP_WATCH,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_alarm_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 221,
              y: 159,
              w: 36,
              h: 43,
              type: hmUI.data_type.ALARM_CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sleep_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 255,
              y: 276,
              w: 66,
              h: 30,
              type: hmUI.data_type.SLEEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_altitude_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 405,
              y: 149,
              w: 45,
              h: 54,
              type: hmUI.data_type.ALTITUDE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_readiness_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 158,
              y: 343,
              w: 62,
              h: 32,
              type: hmUI.data_type.READINESS,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_fatBurning_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 256,
              y: 309,
              w: 65,
              h: 31,
              type: hmUI.data_type.FAT_BURNING,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            
            Button_1 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 355,
              y: 167,
              w: 41,
              h: 39,
              text: '',
              color: 0xFFFF8C00,
              text_size: 24,
              press_src: 'clean.png',
              normal_src: 'clean.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'FlashLightScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_2 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 133,
              y: 177,
              w: 64,
              h: 58,
              text: '',
              color: 0xFFFF8C00,
              text_size: 24,
              press_src: 'clean.png',
              normal_src: 'clean.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'CompassScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_3 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 204,
              y: 91,
              w: 64,
              h: 34,
              text: '',
              color: 0xFFFF8C00,
              text_size: 24,
              press_src: 'clean.png',
              normal_src: 'clean.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'ScheduleCalScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_4 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 130,
              y: 94,
              w: 45,
              h: 45,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'clean.png',
              normal_src: 'clean.png',
              click_func: (button_widget) => {
                hmApp.startApp({ appid: 1065824, url: 'page/index', params: { from_wf: true} });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_5 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 304,
              y: 94,
              w: 45,
              h: 45,
              text: '',
              text_size: 25,
              color: 0xFFFF8C00,
              press_src: 'clean.png',
              normal_src: 'clean.png',
              click_func: () => {
                weatherProvider.prev(true);
              },
              show_level: hmUI.show_level.ONLY_NORMAL,
            });      
            
            btn_bezel = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 30,
              y: 150,
              text: '',
              w: 35,
              h: 35,
              normal_src: 'clean.png',
              press_src: 'clean.png',
              click_func: () => {
               click_Bezel();

              },
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            btn_bezel.setProperty(hmUI.prop.VISIBLE, true);

            btn_bezel1 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 76,
              y: 89,
              text: '',
              w: 35,
              h: 35,
              normal_src: 'clean.png',
              press_src: 'clean.png',
              click_func: () => {
               click_Bezel1();

              },
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            btn_bezel1.setProperty(hmUI.prop.VISIBLE, true);

            btn_bezel2 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 8,
              y: 208,
              text: '',
              w: 35,
              h: 35,
              normal_src: 'clean.png',
              press_src: 'clean.png',
              click_func: () => {
               click_Bezel2();

              },
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            btn_bezel2.setProperty(hmUI.prop.VISIBLE, true);             

            let screenType = hmSetting.getScreenType();
            //#region time_update
            function time_update(updateHour = false, updateMinute = false) {
                if (!curTime) return;
                const currentHour = curTime.hour;
                const currentDay  = curTime.day;
                const currentMonth = curTime.month;
                const isHourChanged = (currentHour !== lastHourChecked);
                const isDayChanged  = (currentDay  !== lastDay);                
                const needsStaticUpdate = isHourChanged || isDayChanged || updateHour;

                if (updateMinute && normal_hour_circle_scale) {
                    const hourProgress = ((currentHour / 24) + (curTime.minute / 60 / 24)) * 100;
                    normal_hour_circle_scale.setProperty(hmUI.prop.LEVEL, hourProgress);
                }

                if (needsStaticUpdate) {                    
                    updateDayOfYear();
                    updateZodiacIfNeeded();
                    if (normal_year_icon_img) {
                        const dateKey = currentMonth * 100 + currentDay;
                        if (dateKey !== lastHolidayDate) {
                            const calendarSrc = HOLIDAYS[dateKey] || 'calendar_0.png';
                            try {
                                normal_year_icon_img.setProperty(hmUI.prop.SRC, calendarSrc);
                            } catch (e) {}
                            lastHolidayDate = dateKey;
                        }
                    }
                }
                lastHourChecked = currentHour;
                lastDay = currentDay;
            }

            //#endregion
            if (!sleepSensor) sleepSensor = hmSensor.createSensor(hmSensor.id.SLEEP);
            //#region sleep_update
            function sleep_update() {

              let sleepTime = sleepSensor.getTotalTime();
              const modelData = sleepSensor.getSleepStageModel();
              let sleepStageArray = sleepSensor.getSleepStageData();
              let wakeupTime = 0;
              let wakeupCount = 0;

              for (let i = 0; i < sleepStageArray.length; i++) {
                let data = sleepStageArray[i];
                if (data.model == modelData.WAKE_STAGE) {
                  wakeupTime += data.stop + 1 - data.start;
                  wakeupCount++;
                };
              };
              sleepTime -= wakeupTime;
              let sleepTimeHour = Math.floor(sleepTime / 60);
              let sleepTimeMin = sleepTime % 60;

              let normal_sleepTimeHourStr = sleepTimeHour.toString();
              normal_sleepTimeHourStr = normal_sleepTimeHourStr.padStart(2, '0');
              let normal_sleepTimeMinStr = sleepTimeMin.toString().padStart(2, '0');
              let normal_sleepTimeStr = normal_sleepTimeHourStr + ':' + normal_sleepTimeMinStr;
              if (normal_sleep_time_font) normal_sleep_time_font.setProperty(hmUI.prop.TEXT, normal_sleepTimeStr);

            };

            //#endregion
            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                time_update(true, true);
                sleep_update();
                checkDayAndLearn();    
                updateBatteryLife(true);
                lastHolidayDate = -1;                                
                if (barometer && barometer._onPressureChange) {
                    barometer._onPressureChange();
                }   
                if (weatherProvider) {
                    weatherProvider.update(false);
                }                  
              }),
            });

                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                
                if (barometer) {
                    barometer.delete();
                    barometer = null;
                }
                
                if (weatherProvider) {
                    weatherProvider.delete();
                    weatherProvider = null;
                }
                
                if (curTime) {
                    if (curTimeMinuteHandler) {
                        try {
                            curTime.removeEventListener(hmSensor.event.MINUTEEND, curTimeMinuteHandler);
                        } catch (e) {
                            console.log('Error removing TIME listener:', e);
                        }
                        curTimeMinuteHandler = null;
                    }
                    curTime = null;
                }
                
                if (battery) {
                    if (batteryChangeHandler) {
                        try {
                            battery.removeEventListener(hmSensor.event.CHANGE, batteryChangeHandler);
                        } catch (e) {
                            console.log('Error removing BATTERY listener:', e);
                        }
                        batteryChangeHandler = null;
                    }
                    battery = null;
                }

                lastHourChecked = -1;
                lastDay = -1;
                lastDayChecked = -1;
                lastHolidayDate = -1;
                lastZodiacDay = null;
                currentZodiacIndex = null;
                
                logger.log('watchface destroyed — all cleaned OK');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}