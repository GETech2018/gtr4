try {
(function () {
  var __$$app$$__ = __$$hmAppManager$$__.currentApp;
  var __$$module$$__ = __$$app$$__.current;
  var logger = Logger.getLogger('watchface_reborn');
var THEMES = 7;
var KEY = 'wraith_reborn_theme';
var theme = 0;
var built = false;
var W = {};
var ts = null;

function p(t, f) { return 'images/th' + t + '/' + f; }
function arr(dir) { var a = []; for (var i = 0; i < 10; i++) { a.push(dir + i + '.png'); } return a; }

function loadTheme() {
  try {
    var v = hmFS.SysProGetInt(KEY);
    if (typeof v === 'number' && v >= 0 && v < THEMES) { return v; }
  } catch (e) {}
  return 0;
}
function saveTheme(v) {
  try { hmFS.SysProSetInt(KEY, v); } catch (e) {}
}
function setSrc(w, s) {
  try { w.setProperty(hmUI.prop.SRC, s); } catch (e) {}
}

function update() {
  try {
    if (!built || !ts) { return; }
    try {
      if (hmSetting.getScreenType() === hmSetting.screen_type.AOD) { return; }
    } catch (e0) {}
    var h = ts.hour, m = ts.minute;
    var fh = h;
    setSrc(W.h1, 'images/w/' + Math.floor(fh / 10) + '.png');
    setSrc(W.h2, p(theme, 'tm/' + (fh % 10) + '.png'));
    setSrc(W.m1, p(theme, 'tm/' + Math.floor(m / 10) + '.png'));
    setSrc(W.m2, 'images/w/' + (m % 10) + '.png');
    var mo = ts.month - 1; if (mo < 0 || mo > 11) { mo = 0; }
    var d = ts.day;
    setSrc(W.mo, p(theme, 'mo/' + mo + '.png'));
    setSrc(W.d1, p(theme, 'dt/' + Math.floor(d / 10) + '.png'));
    setSrc(W.d2, p(theme, 'dt/' + (d % 10) + '.png'));
    var wd = (new Date().getDay() + 6) % 7;
    setSrc(W.wk, p(theme, 'wk/' + wd + '.png'));
  } catch (e) {}
}

function applyTheme(t) {
  theme = t;
  setSrc(W.bg, p(theme, 'bg.png'));
  update();
}

function nextTheme() {
  var t = (theme + 1) % THEMES;
  saveTheme(t);
  applyTheme(t);
}

function build() {
  if (built) { return; }
  theme = loadTheme();
  var N = hmUI.show_level.ONLY_NORMAL, A = hmUI.show_level.ONLY_AOD;
  var img = function (o) { return hmUI.createWidget(hmUI.widget.IMG, o); };

  W.bg = img({ x: 0, y: 0, w: 466, h: 466, src: p(theme, 'bg.png'), show_level: N });
  img({ x: 0, y: 0, w: 466, h: 466, src: 'images/aodbg.png', show_level: A });

  W.wk = img({ x: 0, y: 0, w: 466, h: 88, src: p(theme, 'wk/0.png'), show_level: N });
  W.h1 = img({ x: 153, y: 120, w: 80, h: 112, src: 'images/w/0.png', show_level: N });
  W.h2 = img({ x: 233, y: 120, w: 80, h: 112, src: p(theme, 'tm/0.png'), show_level: N });
  W.m1 = img({ x: 153, y: 234, w: 80, h: 112, src: p(theme, 'tm/0.png'), show_level: N });
  W.m2 = img({ x: 233, y: 234, w: 80, h: 112, src: 'images/w/0.png', show_level: N });
  W.mo = img({ x: 177, y: 372, w: 64, h: 24, src: p(theme, 'mo/0.png'), show_level: N });
  W.d1 = img({ x: 255, y: 372, w: 14, h: 24, src: p(theme, 'dt/0.png'), show_level: N });
  W.d2 = img({ x: 269, y: 372, w: 14, h: 24, src: p(theme, 'dt/0.png'), show_level: N });

  var spots = [
    { cx: 92,  y: 144, type: hmUI.data_type.BATTERY, unit: true },
    { cx: 374, y: 144, type: hmUI.data_type.CAL },
    { cx: 92,  y: 252, type: hmUI.data_type.STEP },
    { cx: 374, y: 252, type: hmUI.data_type.HEART, none: true }
  ];
  for (var i = 0; i < spots.length; i++) {
    var s = spots[i];
    var shared = { x: s.cx - 50, y: s.y, w: 100, h: 28, h_space: 0,
                   align_h: hmUI.align.CENTER_H, type: s.type };
    var a = {}, b = {}, k;
    for (k in shared) { a[k] = shared[k]; b[k] = shared[k]; }
    a.font_array = arr('images/data/'); a.show_level = N;
    b.font_array = arr('images/aod/data/'); b.show_level = A;
    if (s.unit) {
      a.unit_sc = a.unit_tc = a.unit_en = 'images/data/unit.png';
      b.unit_sc = b.unit_tc = b.unit_en = 'images/aod/data/unit.png';
    }
    if (s.none) {
      a.invalid_image = 'images/data/none.png';
      b.invalid_image = 'images/aod/data/none.png';
    }
    hmUI.createWidget(hmUI.widget.TEXT_IMG, a);
    hmUI.createWidget(hmUI.widget.TEXT_IMG, b);
  }

  // AOD (system-driven widgets, neutral grey)
  hmUI.createWidget(hmUI.widget.IMG_WEEK, {
    x: 0, y: 0,
    week_en: arr('images/aod/week/').slice(0, 7), week_tc: arr('images/aod/week/').slice(0, 7), week_sc: arr('images/aod/week/').slice(0, 7),
    show_level: A });
  hmUI.createWidget(hmUI.widget.IMG_DATE, {
    month_startX: 177, month_startY: 372, month_align: hmUI.align.LEFT, month_space: 0, month_zero: 0,
    month_is_character: true,
    month_en_array: [0,1,2,3,4,5,6,7,8,9,10,11].map(function (n) { return 'images/aod/month/' + n + '.png'; }),
    month_sc_array: [0,1,2,3,4,5,6,7,8,9,10,11].map(function (n) { return 'images/aod/month/' + n + '.png'; }),
    month_tc_array: [0,1,2,3,4,5,6,7,8,9,10,11].map(function (n) { return 'images/aod/month/' + n + '.png'; }),
    day_startX: 255, day_startY: 372, day_align: hmUI.align.LEFT, day_space: 0, day_zero: 1,
    day_en_array: arr('images/aod/date/'), day_sc_array: arr('images/aod/date/'), day_tc_array: arr('images/aod/date/'),
    show_level: A });
  hmUI.createWidget(hmUI.widget.IMG_TIME, {
    hour_zero: 1, hour_startX: 153, hour_startY: 120, hour_array: arr('images/time/aod/'), hour_space: 0, hour_align: hmUI.align.LEFT,
    minute_zero: 1, minute_startX: 153, minute_startY: 234, minute_array: arr('images/time/aod/'), minute_space: 0, minute_align: hmUI.align.LEFT,
    show_level: A });

  // tap areas: stats open their app, time cycles the color theme
  var zones = [
    { x: 30,  y: 136, t: hmUI.data_type.BATTERY },
    { x: 312, y: 136, t: hmUI.data_type.CAL },
    { x: 30,  y: 244, t: hmUI.data_type.STEP },
    { x: 312, y: 244, t: hmUI.data_type.HEART }
  ];
  for (var j = 0; j < zones.length; j++) {
    hmUI.createWidget(hmUI.widget.IMG_CLICK, {
      x: zones[j].x, y: zones[j].y, w: 124, h: 84,
      type: zones[j].t, show_level: N });
  }
  hmUI.createWidget(hmUI.widget.BUTTON, {
    x: 150, y: 120, w: 166, h: 226, text: '', color: 0xFFFFFFFF, text_size: 25,
    press_src: 'images/click_time.png', normal_src: 'images/click_time.png',
    click_func: function () { nextTheme(); },
    show_level: N });

  ts = hmSensor.createSensor(hmSensor.id.TIME);
  built = true;
  try { ts.addEventListener(ts.event.MINUTEEND, update); } catch (e1) {}
  try { ts.addEventListener(ts.event.CHANGE, update); } catch (e2) {}
  try { hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, { resume_call: update, pause_call: function () {} }); } catch (e3) {}
  update();
}

__$$module$$__.module = DeviceRuntimeCore.WatchFace({
  init_view: function () { build(); },
  onInit: function () { logger.log('reborn on init'); },
  build: function () { this.init_view(); logger.log('reborn on ready'); },
  onDestroy: function () { logger.log('reborn on destroy'); }
});
})();
} catch (e) {
  console.log('Mini Program Error', e);
  e && e.stack && e.stack.split(/\\n/).forEach(function (i) { console.log('error stack', i); });
}
