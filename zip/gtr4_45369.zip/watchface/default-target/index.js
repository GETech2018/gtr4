try{(()=>{const __$$app$$__=__$$hmAppManager$$__.currentApp;function getApp(){return __$$app$$__.app}function getCurrentPage(){return __$$app$$__.current&&__$$app$$__.current.module}const __$$module$$__=__$$app$$__.current;const h=new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__,__$$module$$__));const{px}=__$$app$$__.__globals__;const logger=Logger.getLogger('monostats');
let timeSensor,Day,Month;
const NA=hmUI.show_level.ONLY_NORMAL|hmUI.show_level.ONLY_AOD;
const NO=hmUI.show_level.ONLY_NORMAL;
const arr=(p,n)=>{const r=[];for(let i=0;i<n;i++)r.push(p+i+'.png');return r};
const tm=arr('tm_',10),sm=arr('sm_',10),dd=arr('dd_',10),bt=arr('bt_',10),wk=arr('wk_',7),bat=arr('bat_',5);
function setDial(a){
  Day.setProperty(hmUI.prop.TEXT,String(a.day));
  Month.setProperty(hmUI.prop.SRC,'mo_'+(a.month-1)+'.png');
}
function row(y,icon,label,type,inv){
  hmUI.createWidget(hmUI.widget.IMG,{x:90,y:y-18,src:icon,show_level:NA});
  hmUI.createWidget(hmUI.widget.IMG,{x:134,y:y-15,src:label,show_level:NA});
  const o={x:200,y:y-16,w:170,h:32,type:type,font_array:sm,align_h:hmUI.align.RIGHT,h_space:1,padding:false,isCharacter:false,show_level:NA};
  if(inv)o.invalid_image='sm_0.png';
  hmUI.createWidget(hmUI.widget.TEXT_IMG,o);
  hmUI.createWidget(hmUI.widget.IMG_CLICK,{x:83,y:y-23,w:300,h:46,type:type,show_level:NO});
}
__$$module$$__.module=DeviceRuntimeCore.WatchFace({
init_view(){
  if(!timeSensor){timeSensor=hmSensor.createSensor(hmSensor.id.TIME)}
  hmUI.createWidget(hmUI.widget.FILL_RECT,{x:0,y:0,w:466,h:466,radius:0,color:0x000000,show_level:NA});
  hmUI.createWidget(hmUI.widget.IMG_LEVEL,{x:182,y:14,image_array:bat,image_length:5,type:hmUI.data_type.BATTERY,show_level:NA});
  hmUI.createWidget(hmUI.widget.TEXT_IMG,{x:234,y:14,w:80,h:23,type:hmUI.data_type.BATTERY,font_array:bt,align_h:hmUI.align.LEFT,h_space:1,unit_en:'bt_pct.png',padding:false,isCharacter:false,show_level:NA});
  hmUI.createWidget(hmUI.widget.IMG_CLICK,{x:173,y:8,w:140,h:34,type:hmUI.data_type.BATTERY,show_level:NO});
  hmUI.createWidget(hmUI.widget.IMG_TIME,{hour_zero:1,hour_startX:83,hour_startY:66,hour_array:tm,hour_space:0,hour_align:hmUI.align.LEFT,minute_zero:1,minute_startX:247,minute_startY:66,minute_array:tm,minute_space:0,minute_align:hmUI.align.LEFT,minute_follow:0,enable:false,show_level:NA});
  hmUI.createWidget(hmUI.widget.IMG,{x:219,y:66,src:'tm_colon.png',show_level:NA});
  hmUI.createWidget(hmUI.widget.IMG_WEEK,{x:72,y:172,week_en:wk,show_level:NA});
  hmUI.createWidget(hmUI.widget.FILL_RECT,{x:182,y:172,w:2,h:30,radius:0,color:0x666666,show_level:NA});
  Day=hmUI.createWidget(hmUI.widget.TEXT_IMG,{x:190,y:172,w:88,h:30,font_array:dd,align_h:hmUI.align.CENTER_H,h_space:1,text:'1',padding:false,isCharacter:false,show_level:NA});
  hmUI.createWidget(hmUI.widget.FILL_RECT,{x:285,y:172,w:2,h:30,radius:0,color:0x666666,show_level:NA});
  Month=hmUI.createWidget(hmUI.widget.IMG,{x:306,y:172,src:'mo_0.png',show_level:NA});
  row(255,'ic_steps.png','lbl_steps.png',hmUI.data_type.STEP,false);
  row(318,'ic_cal.png','lbl_cal.png',hmUI.data_type.CAL,false);
  row(380,'ic_heart.png','lbl_heart.png',hmUI.data_type.HEART,true);
  hmUI.createWidget(hmUI.widget.FILL_RECT,{x:90,y:285,w:280,h:1,radius:0,color:0x4a4a4a,show_level:NA});
  hmUI.createWidget(hmUI.widget.FILL_RECT,{x:90,y:348,w:280,h:1,radius:0,color:0x4a4a4a,show_level:NA});
  setDial(timeSensor);
  timeSensor.addEventListener(timeSensor.event.MINUTEEND,function(){setDial(timeSensor)});
  timer.createTimer(0,60000,function(a){setDial(a)},timeSensor);
  hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE,{resume_call:function(){setDial(timeSensor)}});
},
onInit(){logger.log('index page.js on init invoke')},
build(){this.init_view();logger.log('index page.js on ready invoke')},
onDestroy(){logger.log('index page.js on destroy invoke')}
})})()}catch(e){console.log('Mini Program Error',e);e&&e.stack&&e.stack.split(/\n/).forEach(i=>console.log('error stack',i))}
