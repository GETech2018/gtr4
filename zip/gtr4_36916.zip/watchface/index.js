﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        const logger = Logger.getLogger('watchface_SashaCX75');
        //end of ignored block

        //dynamic modify start

        
        let editBg = ''
        let normal_system_lock_img = ''
        let normal_system_disconnect_img = ''
        let normal_system_clock_img = ''
        let normal_sun_current_text_img = ''
        let normal_sun_current_separator_img = ''
        let normal_battery_linear_scale = ''
        let normal_battery_linear_scale_mirror = ''
        let normal_battery_text_text_img = ''
        let normal_temperature_current_text_img = ''
        let normal_weather_image_progress_img_level = ''
        let normal_moon_image_progress_img_level = ''
        let normal_stress_text_text_img = ''
        let normal_date_img_date_year = ''
        let normal_distance_text_text_img = ''
        let normal_calorie_current_text_img = ''
        let normal_heart_rate_text_text_img = ''
        let normal_step_current_text_img = ''
        let normal_date_img_date_month_img = ''
        let normal_date_img_date_day = ''
        let normal_date_img_date_week_img = ''
        let normal_digital_clock_img_time_AmPm = ''
        let normal_digital_clock_img_time = ''
        let normal_digital_clock_hour_separator_img = ''
        let normal_digital_clock_minute_separator_img = ''
        let idle_background_bg = ''
        let idle_system_lock_img = ''
        let idle_system_disconnect_img = ''
        let idle_system_clock_img = ''
        let idle_sun_current_text_img = ''
        let idle_battery_text_text_img = ''
        let idle_temperature_current_text_img = ''
        let idle_date_img_date_year = ''
        let idle_date_img_date_month_img = ''
        let idle_date_img_date_day = ''
        let idle_date_img_date_week_img = ''
        let idle_digital_clock_img_time_AmPm = ''
        let idle_digital_clock_img_time = ''
        let idle_digital_clock_hour_separator_img = ''
        let idle_digital_clock_minute_separator_img = ''
        let normal_alarm_jumpable_img_click = ''
        let normal_sunrise_jumpable_img_click = ''
        let normal_altimeter_jumpable_img_click = ''
        let normal_temperature_jumpable_img_click = ''
        let normal_stress_jumpable_img_click = ''
        let normal_pai_jumpable_img_click = ''
        let normal_heart_jumpable_img_click = ''
        let normal_step_jumpable_img_click = ''
        let Button_1 = ''
        let Button_2 = ''
        let Button_3 = ''
        let Button_4 = ''


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            console.log('Watch_Face.ScreenNormal');
            editBg = hmUI.createWidget(hmUI.widget.WATCHFACE_EDIT_BG, {
              edit_id: 1002,
              x: 0,
              y: 0,
              // w: 466,
              // h: 466,
              // AOD_show: False,
              bg_config: [
                { id: 1, preview: 'bg_edit_1_preview.png', path: '00.png' },
                { id: 2, preview: 'bg_edit_2_preview.png', path: '01.png' },
                { id: 3, preview: 'bg_edit_3_preview.png', path: '02.png' },
              ],
              count: 3,
              default_id: 1,
              fg: '.png',
              tips_bg: '.png',
              tips_x: 0,
              tips_y: 0,
              show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_EDIT,
            });

            normal_system_lock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 221,
              y: 262,
              src: 'can5.png',
              type: hmUI.system_status.LOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 388,
              y: 90,
              src: 'bt9.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 47,
              y: 88,
              src: 'alar7.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sun_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 3,
              y: 200,
              font_array: ["big_00.png","big_01.png","big_02.png","big_03.png","big_04.png","big_05.png","big_06.png","big_07.png","big_08.png","big_09.png"],
              padding: false,
              h_space: -3,
              dot_image: 'Puntos.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.SUN_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sun_current_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 22,
              y: 157,
              src: 'sol.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            let screenType = hmSetting.getScreenType();
            if (screenType != hmSetting.screen_type.AOD) {
              normal_battery_linear_scale = hmUI.createWidget(hmUI.widget.FILL_RECT);
              normal_battery_linear_scale_mirror = hmUI.createWidget(hmUI.widget.FILL_RECT);
            };

            // normal_battery_linear_scale = hmUI.createWidget(hmUI.widget.Linear_Scale, {
              // start_x: 235,
              // start_y: 457,
              // color: 0xFF008200,
              // lenght: 33,
              // line_width: 4,
              // line_cap: Flat,
              // vertical: False,
              // mirror: True,
              // inversion: False,
              // type: hmUI.data_type.BATTERY,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });
            
            const battery = hmSensor.createSensor(hmSensor.id.BATTERY);
            battery.addEventListener(hmSensor.event.CHANGE, function() {
              scale_call();
            });

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 206,
              y: 424,
              font_array: ["big_00.png","big_01.png","big_02.png","big_03.png","big_04.png","big_05.png","big_06.png","big_07.png","big_08.png","big_09.png"],
              padding: false,
              h_space: 0,
              unit_sc: '0053.png',
              unit_tc: '0053.png',
              unit_en: '0053.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 205,
              y: 78,
              font_array: ["big_00.png","big_01.png","big_02.png","big_03.png","big_04.png","big_05.png","big_06.png","big_07.png","big_08.png","big_09.png"],
              padding: false,
              h_space: 0,
              unit_sc: '0044.png',
              unit_tc: '0044.png',
              unit_en: '0044.png',
              negative_image: '0024.png',
              invalid_image: 'invalid.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 198,
              y: 0,
              image_array: ["C01.png","C02.png","C03.png","C04.png","C05.png","C06.png","C07.png","C08.png","C09.png","C10.png","C11.png","C12.png","C13.png","C14.png","C15.png","C16.png","C17.png","C18.png","C19.png","C20.png","C21.png","C22.png","C23.png","C24.png","C25.png","C26.png","C27.png","C28.png","C29.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_moon_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 401,
              y: 145,
              image_array: ["fase1.png","fase2.png","fase3.png","fase4.png","fase5.png","fase6.png","fase7.png","fase8.png"],
              image_length: 8,
              type: hmUI.data_type.MOON,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_stress_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 108,
              y: 334,
              font_array: ["big_00.png","big_01.png","big_02.png","big_03.png","big_04.png","big_05.png","big_06.png","big_07.png","big_08.png","big_09.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.STRESS,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_year = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              year_startX: 299,
              year_startY: 61,
              year_sc_array: ["big_00.png","big_01.png","big_02.png","big_03.png","big_04.png","big_05.png","big_06.png","big_07.png","big_08.png","big_09.png"],
              year_tc_array: ["big_00.png","big_01.png","big_02.png","big_03.png","big_04.png","big_05.png","big_06.png","big_07.png","big_08.png","big_09.png"],
              year_en_array: ["big_00.png","big_01.png","big_02.png","big_03.png","big_04.png","big_05.png","big_06.png","big_07.png","big_08.png","big_09.png"],
              year_zero: 0,
              year_space: 0,
              year_align: hmUI.align.CENTER_H,
              year_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_distance_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 313,
              y: 292,
              font_array: ["big_00.png","big_01.png","big_02.png","big_03.png","big_04.png","big_05.png","big_06.png","big_07.png","big_08.png","big_09.png"],
              padding: false,
              h_space: 0,
              dot_image: 'Puntos.png',
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.DISTANCE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_calorie_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 310,
              y: 334,
              font_array: ["big_00.png","big_01.png","big_02.png","big_03.png","big_04.png","big_05.png","big_06.png","big_07.png","big_08.png","big_09.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 206,
              y: 317,
              font_array: ["big_00.png","big_01.png","big_02.png","big_03.png","big_04.png","big_05.png","big_06.png","big_07.png","big_08.png","big_09.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 92,
              y: 292,
              font_array: ["big_00.png","big_01.png","big_02.png","big_03.png","big_04.png","big_05.png","big_06.png","big_07.png","big_08.png","big_09.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_month_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 292,
              month_startY: 33,
              month_sc_array: ["M01.png","M02.png","M03.png","M04.png","M05.png","M06.png","M07.png","M08.png","M09.png","M10.png","M11.png","M12.png"],
              month_tc_array: ["M01.png","M02.png","M03.png","M04.png","M05.png","M06.png","M07.png","M08.png","M09.png","M10.png","M11.png","M12.png"],
              month_en_array: ["M01.png","M02.png","M03.png","M04.png","M05.png","M06.png","M07.png","M08.png","M09.png","M10.png","M11.png","M12.png"],
              month_is_character: true ,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 127,
              day_startY: 61,
              day_sc_array: ["big_00.png","big_01.png","big_02.png","big_03.png","big_04.png","big_05.png","big_06.png","big_07.png","big_08.png","big_09.png"],
              day_tc_array: ["big_00.png","big_01.png","big_02.png","big_03.png","big_04.png","big_05.png","big_06.png","big_07.png","big_08.png","big_09.png"],
              day_en_array: ["big_00.png","big_01.png","big_02.png","big_03.png","big_04.png","big_05.png","big_06.png","big_07.png","big_08.png","big_09.png"],
              day_zero: 1,
              day_space: 0,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 106,
              y: 33,
              week_en: ["D1.png","D2.png","D3.png","D4.png","D5.png","D6.png","D7.png"],
              week_tc: ["D1.png","D2.png","D3.png","D4.png","D5.png","D6.png","D7.png"],
              week_sc: ["D1.png","D2.png","D3.png","D4.png","D5.png","D6.png","D7.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time_AmPm = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              am_x: 407,
              am_y: 200,
              am_sc_path: 'H1.png',
              am_en_path: 'H1.png',
              pm_x: 407,
              pm_y: 200,
              pm_sc_path: 'H2.png',
              pm_en_path: 'H2.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 77,
              hour_startY: 122,
              hour_array: ["0.png","1.png","2.png","3.png","4.png","5.png","6.png","7.png","8.png","9.png"],
              hour_zero: 1,
              hour_space: 0,
              hour_angle: 0,
              hour_align: hmUI.align.CENTER_H,

              minute_startX: 188,
              minute_startY: 122,
              minute_array: ["0.png","1.png","2.png","3.png","4.png","5.png","6.png","7.png","8.png","9.png"],
              minute_zero: 1,
              minute_space: 0,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.CENTER_H,

              second_startX: 293,
              second_startY: 122,
              second_array: ["0.png","1.png","2.png","3.png","4.png","5.png","6.png","7.png","8.png","9.png"],
              second_zero: 1,
              second_space: 0,
              second_angle: 0,
              second_follow: 0,
              second_align: hmUI.align.CENTER_H,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_hour_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 164,
              y: 135,
              src: 's_dot.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_minute_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 272,
              y: 135,
              src: 's_dot.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            console.log('Watch_Face.ScreenAOD');
            idle_background_bg = hmUI.createWidget(hmUI.widget.FILL_RECT, {
              x: 0,
              y: 0,
              w: 466,
              h: 466,
              color: '0xFF000000',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_system_lock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 221,
              y: 262,
              src: 'can5.png',
              type: hmUI.system_status.LOCK,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 388,
              y: 108,
              src: 'bt9.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 39,
              y: 104,
              src: 'alar7.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_sun_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 282,
              y: 210,
              font_array: ["big_00.png","big_01.png","big_02.png","big_03.png","big_04.png","big_05.png","big_06.png","big_07.png","big_08.png","big_09.png"],
              padding: false,
              h_space: -3,
              dot_image: 'Puntos.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.SUN_CURRENT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 207,
              y: 428,
              font_array: ["big_00.png","big_01.png","big_02.png","big_03.png","big_04.png","big_05.png","big_06.png","big_07.png","big_08.png","big_09.png"],
              padding: false,
              h_space: 0,
              unit_sc: '0053.png',
              unit_tc: '0053.png',
              unit_en: '0053.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 205,
              y: 14,
              font_array: ["big_00.png","big_01.png","big_02.png","big_03.png","big_04.png","big_05.png","big_06.png","big_07.png","big_08.png","big_09.png"],
              padding: false,
              h_space: 0,
              unit_sc: '0044.png',
              unit_tc: '0044.png',
              unit_en: '0044.png',
              negative_image: '0024.png',
              invalid_image: 'invalid.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_year = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              year_startX: 292,
              year_startY: 67,
              year_sc_array: ["big_00.png","big_01.png","big_02.png","big_03.png","big_04.png","big_05.png","big_06.png","big_07.png","big_08.png","big_09.png"],
              year_tc_array: ["big_00.png","big_01.png","big_02.png","big_03.png","big_04.png","big_05.png","big_06.png","big_07.png","big_08.png","big_09.png"],
              year_en_array: ["big_00.png","big_01.png","big_02.png","big_03.png","big_04.png","big_05.png","big_06.png","big_07.png","big_08.png","big_09.png"],
              year_zero: 0,
              year_space: 0,
              year_align: hmUI.align.CENTER_H,
              year_is_character: false,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_month_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 287,
              month_startY: 37,
              month_sc_array: ["M01.png","M02.png","M03.png","M04.png","M05.png","M06.png","M07.png","M08.png","M09.png","M10.png","M11.png","M12.png"],
              month_tc_array: ["M01.png","M02.png","M03.png","M04.png","M05.png","M06.png","M07.png","M08.png","M09.png","M10.png","M11.png","M12.png"],
              month_en_array: ["M01.png","M02.png","M03.png","M04.png","M05.png","M06.png","M07.png","M08.png","M09.png","M10.png","M11.png","M12.png"],
              month_is_character: true ,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 130,
              day_startY: 67,
              day_sc_array: ["big_00.png","big_01.png","big_02.png","big_03.png","big_04.png","big_05.png","big_06.png","big_07.png","big_08.png","big_09.png"],
              day_tc_array: ["big_00.png","big_01.png","big_02.png","big_03.png","big_04.png","big_05.png","big_06.png","big_07.png","big_08.png","big_09.png"],
              day_en_array: ["big_00.png","big_01.png","big_02.png","big_03.png","big_04.png","big_05.png","big_06.png","big_07.png","big_08.png","big_09.png"],
              day_zero: 1,
              day_space: 0,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 106,
              y: 37,
              week_en: ["D1.png","D2.png","D3.png","D4.png","D5.png","D6.png","D7.png"],
              week_tc: ["D1.png","D2.png","D3.png","D4.png","D5.png","D6.png","D7.png"],
              week_sc: ["D1.png","D2.png","D3.png","D4.png","D5.png","D6.png","D7.png"],
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time_AmPm = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              am_x: 297,
              am_y: 176,
              am_sc_path: 'H1.png',
              am_en_path: 'H1.png',
              pm_x: 297,
              pm_y: 176,
              pm_sc_path: 'H2.png',
              pm_en_path: 'H2.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 77,
              hour_startY: 122,
              hour_array: ["0.png","1.png","2.png","3.png","4.png","5.png","6.png","7.png","8.png","9.png"],
              hour_zero: 1,
              hour_space: 0,
              hour_angle: 0,
              hour_align: hmUI.align.CENTER_H,

              minute_startX: 188,
              minute_startY: 122,
              minute_array: ["0.png","1.png","2.png","3.png","4.png","5.png","6.png","7.png","8.png","9.png"],
              minute_zero: 1,
              minute_space: 0,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.CENTER_H,

              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_hour_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 164,
              y: 135,
              src: 's_dot.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_minute_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'sharp.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });
            
            // disconnectAlert = hmUI.createWidget(hmUI.widget.DisconnectAlert, {
              // disconneсnt_vibrate_type: 0,
              // disconneсnt_toast_text: BT DESC.,
              // conneсnt_vibrate_type: 0,
              // conneсnt_toast_text: BT CON.,
            // });

            // vibration when connecting or disconnecting

            function checkConnection() {
              console.log('checkConnection()');
              hmBle.removeListener;
              hmBle.addListener(function (status) {
                if(!status) {
                  hmUI.showToast({text: "BT DESC."});
                  vibro(0);
                }
                if(status) {
                  hmUI.showToast({text: "BT CON."});
                  vibro(0);
                }
              });
            }

            // end vibration when connecting or disconnecting
            // vibrate function

            const vibrate = hmSensor.createSensor(hmSensor.id.VIBRATE);
            let timer_StopVibrate = null;


            function vibro(scene = 25) {
              let stopDelay = 50;
              stopVibro();
              vibrate.stop();
              vibrate.scene = scene;
              if(scene < 23 || scene > 25) stopDelay = 1300;
              vibrate.start();
              if (scene != 1) timer_StopVibrate = timer.createTimer(stopDelay, 3000, stopVibro, {});
            }

            function stopVibro(){
              vibrate.stop();
              if(timer_StopVibrate) timer.stopTimer(timer_StopVibrate);
            }

            // end vibrate function
            console.log('Watch_Face.Shortcuts');

            normal_alarm_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 34,
              y: 86,
              w: 50,
              h: 50,
              type: hmUI.data_type.ALARM_CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sunrise_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 8,
              y: 160,
              w: 70,
              h: 80,
              type: hmUI.data_type.SUN_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_altimeter_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 399,
              y: 142,
              w: 50,
              h: 50,
              type: hmUI.data_type.ALTIMETER,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 185,
              y: 13,
              w: 100,
              h: 100,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_stress_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 67,
              y: 325,
              w: 100,
              h: 40,
              type: hmUI.data_type.STRESS,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_pai_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 319,
              y: 327,
              w: 100,
              h: 40,
              type: hmUI.data_type.PAI_WEEKLY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 187,
              y: 285,
              w: 100,
              h: 100,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 52,
              y: 281,
              w: 130,
              h: 40,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            console.log('Watch_Face.Buttons');
            Button_1 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 289,
              y: 393,
              w: 70,
              h: 60,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'transparent.png',
              normal_src: 'transparent.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'FindPhoneScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_2 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 287,
              y: 35,
              w: 70,
              h: 60,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'transparent.png',
              normal_src: 'transparent.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'ScheduleCalScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_3 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 113,
              y: 34,
              w: 70,
              h: 60,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'transparent.png',
              normal_src: 'transparent.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'ScheduleCalScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_4 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 114,
              y: 392,
              w: 70,
              h: 60,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'transparent.png',
              normal_src: 'transparent.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'PhoneHomeScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            function scale_call() {
              console.log('scale_call()');

                console.log('update scales BATTERY');
                
                let valueBattery = battery.current;
                let targetBattery = 100;
                let progressBattery = valueBattery/targetBattery;
                if (progressBattery > 1) progressBattery = 1;
                let progress_ls_normal_battery = progressBattery;

                if (screenType != hmSetting.screen_type.AOD) {

                  // normal_battery_linear_scale
                  // initial parameters
                  let start_x_normal_battery = 235;
                  let start_y_normal_battery = 457;
                  let lenght_ls_normal_battery = 33;
                  let line_width_ls_normal_battery = 4;
                  let color_ls_normal_battery = 0xFF008200;
                  
                  // calculated parameters
                  let start_x_normal_battery_draw = start_x_normal_battery;
                  let start_y_normal_battery_draw = start_y_normal_battery;
                  lenght_ls_normal_battery = lenght_ls_normal_battery * progress_ls_normal_battery;
                  let lenght_ls_normal_battery_draw = lenght_ls_normal_battery;
                  let line_width_ls_normal_battery_draw = line_width_ls_normal_battery;
                  if (lenght_ls_normal_battery < 0){
                    lenght_ls_normal_battery_draw = -lenght_ls_normal_battery;
                    start_x_normal_battery_draw = start_x_normal_battery - lenght_ls_normal_battery_draw;
                  };
                  
                  normal_battery_linear_scale.setProperty(hmUI.prop.MORE, {
                    x: start_x_normal_battery_draw,
                    y: start_y_normal_battery_draw,
                    w: lenght_ls_normal_battery_draw,
                    h: line_width_ls_normal_battery_draw,
                    color: color_ls_normal_battery,
                  });
                  
                  // normal_battery_linear_scale_mirror
                  // initial parameters
                  let start_x_normal_battery_mirror = 235;
                  let start_y_normal_battery_mirror = 457;
                  let lenght_ls_normal_battery_mirror = -33;
                  let line_width_ls_normal_battery_mirror =4;
                  let color_ls_normal_battery_mirror = 0xFF008200;
                  
                  // calculated parameters
                  let start_x_normal_battery_draw_mirror = start_x_normal_battery_mirror;
                  let start_y_normal_battery_draw_mirror = start_y_normal_battery_mirror;
                  lenght_ls_normal_battery_mirror = lenght_ls_normal_battery_mirror * progress_ls_normal_battery;
                  let lenght_ls_normal_battery_draw_mirror = lenght_ls_normal_battery_mirror;
                  let line_width_ls_normal_battery_draw_mirror = line_width_ls_normal_battery_mirror;
                  if (lenght_ls_normal_battery_mirror < 0){
                    lenght_ls_normal_battery_draw_mirror = -lenght_ls_normal_battery_mirror;
                    start_x_normal_battery_draw_mirror = start_x_normal_battery - lenght_ls_normal_battery_draw_mirror;
                  };
                  
                  normal_battery_linear_scale_mirror.setProperty(hmUI.prop.MORE, {
                    x: start_x_normal_battery_draw_mirror,
                    y: start_y_normal_battery_draw_mirror,
                    w: lenght_ls_normal_battery_draw_mirror,
                    h: line_width_ls_normal_battery_draw_mirror,
                    color: color_ls_normal_battery,
                  });
                };

            };

            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                console.log('resume_call()');
                scale_call();
                checkConnection();
                stopVibro();

              }),
              pause_call: (function () {
                console.log('pause_call()');
                stopVibro();

              }),
            });

                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}