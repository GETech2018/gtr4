﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        const logger = Logger.getLogger('watchface_SashaCX75');
        //end of ignored block

        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_date_img_date_month = ''
        let normal_distance_text_text_img = ''
        let normal_date_img_date_year = ''
        let normal_date_img_date_day = ''
        let normal_step_current_text_img = ''
        let normal_step_image_progress_img_level = ''
        let normal_weather_image_progress_img_level = ''
        let normal_temperature_current_text_img = ''
        let normal_date_img_date_week_img = ''
        let normal_heart_rate_pointer_progress_img_pointer = ''
        let normal_heart_rate_text_text_img = ''
        let normal_heart_rate_image_progress_img_level = ''
        let normal_battery_pointer_progress_img_pointer = ''
        let normal_battery_text_text_img = ''
        let normal_digital_clock_img_time = ''
        let normal_analog_clock_time_pointer_hour = ''
        let normal_analog_clock_time_pointer_minute = ''
        let normal_analog_clock_time_pointer_second = ''
        let idle_background_bg_img = ''
        let idle_date_img_date_month = ''
        let idle_distance_text_text_img = ''
        let idle_date_img_date_year = ''
        let idle_date_img_date_day = ''
        let idle_step_current_text_img = ''
        let idle_step_image_progress_img_level = ''
        let idle_weather_image_progress_img_level = ''
        let idle_temperature_current_text_img = ''
        let idle_date_img_date_week_img = ''
        let idle_heart_rate_pointer_progress_img_pointer = ''
        let idle_heart_rate_text_text_img = ''
        let idle_heart_rate_image_progress_img_level = ''
        let idle_battery_pointer_progress_img_pointer = ''
        let idle_battery_text_text_img = ''
        let idle_digital_clock_img_time = ''
        let idle_analog_clock_time_pointer_hour = ''
        let idle_analog_clock_time_pointer_minute = ''
        let idle_analog_clock_time_pointer_second = ''


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            console.log('Watch_Face.ScreenNormal');
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 466,
              h: 466,
              src: '0002.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_month = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 107,
              month_startY: 313,
              month_sc_array: ["SN00.png","SN01.png","SN02.png","SN03.png","SN04.png","SN05.png","SN06.png","SN07.png","SN08.png","SN09.png"],
              month_tc_array: ["SN00.png","SN01.png","SN02.png","SN03.png","SN04.png","SN05.png","SN06.png","SN07.png","SN08.png","SN09.png"],
              month_en_array: ["SN00.png","SN01.png","SN02.png","SN03.png","SN04.png","SN05.png","SN06.png","SN07.png","SN08.png","SN09.png"],
              month_zero: 1,
              month_space: 0,
              month_align: hmUI.align.CENTER_H,
              month_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_distance_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 335,
              y: 306,
              font_array: ["SN00.png","SN01.png","SN02.png","SN03.png","SN04.png","SN05.png","SN06.png","SN07.png","SN08.png","SN09.png"],
              padding: false,
              h_space: -2,
              dot_image: 'DC.png',
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.DISTANCE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_year = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              year_startX: 97,
              year_startY: 124,
              year_sc_array: ["SN00.png","SN01.png","SN02.png","SN03.png","SN04.png","SN05.png","SN06.png","SN07.png","SN08.png","SN09.png"],
              year_tc_array: ["SN00.png","SN01.png","SN02.png","SN03.png","SN04.png","SN05.png","SN06.png","SN07.png","SN08.png","SN09.png"],
              year_en_array: ["SN00.png","SN01.png","SN02.png","SN03.png","SN04.png","SN05.png","SN06.png","SN07.png","SN08.png","SN09.png"],
              year_zero: 1,
              year_space: -1,
              year_align: hmUI.align.LEFT,
              year_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 94,
              day_startY: 216,
              day_sc_array: ["BN00.png","BN01.png","BN02.png","BN03.png","BN04.png","BN05.png","BN06.png","BN07.png","BN08.png","BN09.png"],
              day_tc_array: ["BN00.png","BN01.png","BN02.png","BN03.png","BN04.png","BN05.png","BN06.png","BN07.png","BN08.png","BN09.png"],
              day_en_array: ["BN00.png","BN01.png","BN02.png","BN03.png","BN04.png","BN05.png","BN06.png","BN07.png","BN08.png","BN09.png"],
              day_zero: 0,
              day_space: 0,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 342,
              y: 135,
              font_array: ["SN00.png","SN01.png","SN02.png","SN03.png","SN04.png","SN05.png","SN06.png","SN07.png","SN08.png","SN09.png"],
              padding: false,
              h_space: -2,
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 0,
              y: 0,
              image_array: ["St01.png","St02.png","St03.png","St04.png","St05.png","St06.png","St07.png","St08.png","St09.png","St10.png"],
              image_length: 10,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 314,
              y: 197,
              image_array: ["Wh01.png","Wh02.png","Wh03.png","Wh04.png","Wh05.png","Wh06.png","Wh07.png","Wh08.png","Wh09.png","Wh10.png","Wh11.png","Wh12.png","Wh13.png","Wh14.png","Wh15.png","Wh16.png","Wh17.png","Wh18.png","Wh19.png","Wh20.png","Wh21.png","Wh22.png","Wh23.png","Wh24.png","Wh25.png","Wh26.png","Wh27.png","Wh28.png","Wh29.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 363,
              y: 198,
              font_array: ["SN00.png","SN01.png","SN02.png","SN03.png","SN04.png","SN05.png","SN06.png","SN07.png","SN08.png","SN09.png"],
              padding: false,
              h_space: -2,
              unit_sc: 'Gr.png',
              unit_tc: 'Gr.png',
              unit_en: 'Gr.png',
              imperial_unit_sc: 'Gr.png',
              imperial_unit_tc: 'Gr.png',
              imperial_unit_en: 'Gr.png',
              negative_image: 'Min.png',
              invalid_image: 'Min.png',
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            const temperatureUnit = hmSetting.getTemperatureUnit();
            //start of ignored block
            if (temperatureUnit == 1) {
              normal_temperature_current_text_img.setProperty(hmUI.prop.MORE, {
                x: 363,
                y: 198,
                font_array: ["SN00.png","SN01.png","SN02.png","SN03.png","SN04.png","SN05.png","SN06.png","SN07.png","SN08.png","SN09.png"],
                padding: false,
                h_space: -2,
                unit_sc: 'Gr.png',
                unit_tc: 'Gr.png',
                unit_en: 'Gr.png',
                imperial_unit_sc: 'Gr.png',
                imperial_unit_tc: 'Gr.png',
                imperial_unit_en: 'Gr.png',
                negative_image: 'Min.png',
                invalid_image: 'Min.png',
                align_h: hmUI.align.RIGHT,
                type: hmUI.data_type.WEATHER_CURRENT,
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
            };
            //end of ignored block

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 0,
              y: 0,
              week_en: ["W01.png","W02.png","W03.png","W04.png","W05.png","W06.png","W07.png"],
              week_tc: ["W01.png","W02.png","W03.png","W04.png","W05.png","W06.png","W07.png"],
              week_sc: ["W01.png","W02.png","W03.png","W04.png","W05.png","W06.png","W07.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_pointer_progress_img_pointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
              src: '0006.png',
              center_x: 233,
              center_y: 109,
              x: 68,
              y: 69,
              start_angle: -150,
              end_angle: 150,
              invalid_visible: false,
              cover_path: '0009.png',
              cover_x: 0,
              cover_y: 0,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 210,
              y: 85,
              font_array: ["BN00.png","BN01.png","BN02.png","BN03.png","BN04.png","BN05.png","BN06.png","BN07.png","BN08.png","BN09.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 0,
              y: 0,
              image_array: ["P01.png","P02.png","P03.png","P04.png","P05.png","P06.png"],
              image_length: 6,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_pointer_progress_img_pointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
              src: '0006.png',
              center_x: 233,
              center_y: 355,
              x: 68,
              y: 69,
              start_angle: -150,
              end_angle: 150,
              invalid_visible: false,
              cover_path: '0010.png',
              cover_x: 0,
              cover_y: 0,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 209,
              y: 339,
              font_array: ["BN00.png","BN01.png","BN02.png","BN03.png","BN04.png","BN05.png","BN06.png","BN07.png","BN08.png","BN09.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 315,
              hour_startY: 240,
              hour_array: ["SN00.png","SN01.png","SN02.png","SN03.png","SN04.png","SN05.png","SN06.png","SN07.png","SN08.png","SN09.png"],
              hour_zero: 1,
              hour_space: -2,
              hour_angle: 0,
              hour_unit_sc: 'Db.png',
              hour_unit_tc: 'Db.png',
              hour_unit_en: 'Db.png',
              hour_align: hmUI.align.LEFT,

              minute_startX: 0,
              minute_startY: 0,
              minute_array: ["SN00.png","SN01.png","SN02.png","SN03.png","SN04.png","SN05.png","SN06.png","SN07.png","SN08.png","SN09.png"],
              minute_zero: 1,
              minute_space: 0,
              minute_angle: 0,
              minute_follow: 1,
              minute_unit_sc: 'Db.png',
              minute_unit_tc: 'Db.png',
              minute_unit_en: 'Db.png',
              minute_align: hmUI.align.LEFT,

              second_startX: 0,
              second_startY: 0,
              second_array: ["SN00.png","SN01.png","SN02.png","SN03.png","SN04.png","SN05.png","SN06.png","SN07.png","SN08.png","SN09.png"],
              second_zero: 1,
              second_space: 0,
              second_angle: 0,
              second_follow: 1,
              second_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_hour = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              hour_path: '0003.png',
              hour_centerX: 233,
              hour_centerY: 233,
              hour_posX: 233,
              hour_posY: 233,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_minute = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              minute_path: '0004.png',
              minute_centerX: 233,
              minute_centerY: 233,
              minute_posX: 233,
              minute_posY: 233,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_second = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              second_path: '0005.png',
              second_centerX: 233,
              second_centerY: 233,
              second_posX: 233,
              second_posY: 233,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            console.log('Watch_Face.ScreenAOD');
            idle_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 466,
              h: 466,
              src: '0002.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_month = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 107,
              month_startY: 313,
              month_sc_array: ["SN00.png","SN01.png","SN02.png","SN03.png","SN04.png","SN05.png","SN06.png","SN07.png","SN08.png","SN09.png"],
              month_tc_array: ["SN00.png","SN01.png","SN02.png","SN03.png","SN04.png","SN05.png","SN06.png","SN07.png","SN08.png","SN09.png"],
              month_en_array: ["SN00.png","SN01.png","SN02.png","SN03.png","SN04.png","SN05.png","SN06.png","SN07.png","SN08.png","SN09.png"],
              month_zero: 1,
              month_space: 0,
              month_align: hmUI.align.CENTER_H,
              month_is_character: false,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_distance_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 335,
              y: 306,
              font_array: ["SN00.png","SN01.png","SN02.png","SN03.png","SN04.png","SN05.png","SN06.png","SN07.png","SN08.png","SN09.png"],
              padding: false,
              h_space: -2,
              dot_image: 'DC.png',
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.DISTANCE,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_year = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              year_startX: 97,
              year_startY: 124,
              year_sc_array: ["SN00.png","SN01.png","SN02.png","SN03.png","SN04.png","SN05.png","SN06.png","SN07.png","SN08.png","SN09.png"],
              year_tc_array: ["SN00.png","SN01.png","SN02.png","SN03.png","SN04.png","SN05.png","SN06.png","SN07.png","SN08.png","SN09.png"],
              year_en_array: ["SN00.png","SN01.png","SN02.png","SN03.png","SN04.png","SN05.png","SN06.png","SN07.png","SN08.png","SN09.png"],
              year_zero: 1,
              year_space: -1,
              year_align: hmUI.align.LEFT,
              year_is_character: false,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 94,
              day_startY: 216,
              day_sc_array: ["BN00.png","BN01.png","BN02.png","BN03.png","BN04.png","BN05.png","BN06.png","BN07.png","BN08.png","BN09.png"],
              day_tc_array: ["BN00.png","BN01.png","BN02.png","BN03.png","BN04.png","BN05.png","BN06.png","BN07.png","BN08.png","BN09.png"],
              day_en_array: ["BN00.png","BN01.png","BN02.png","BN03.png","BN04.png","BN05.png","BN06.png","BN07.png","BN08.png","BN09.png"],
              day_zero: 0,
              day_space: 0,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 342,
              y: 135,
              font_array: ["SN00.png","SN01.png","SN02.png","SN03.png","SN04.png","SN05.png","SN06.png","SN07.png","SN08.png","SN09.png"],
              padding: false,
              h_space: -2,
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_step_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 0,
              y: 0,
              image_array: ["St01.png","St02.png","St03.png","St04.png","St05.png","St06.png","St07.png","St08.png","St09.png","St10.png"],
              image_length: 10,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 314,
              y: 197,
              image_array: ["Wh01.png","Wh02.png","Wh03.png","Wh04.png","Wh05.png","Wh06.png","Wh07.png","Wh08.png","Wh09.png","Wh10.png","Wh11.png","Wh12.png","Wh13.png","Wh14.png","Wh15.png","Wh16.png","Wh17.png","Wh18.png","Wh19.png","Wh20.png","Wh21.png","Wh22.png","Wh23.png","Wh24.png","Wh25.png","Wh26.png","Wh27.png","Wh28.png","Wh29.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 363,
              y: 198,
              font_array: ["SN00.png","SN01.png","SN02.png","SN03.png","SN04.png","SN05.png","SN06.png","SN07.png","SN08.png","SN09.png"],
              padding: false,
              h_space: -2,
              unit_sc: 'Gr.png',
              unit_tc: 'Gr.png',
              unit_en: 'Gr.png',
              imperial_unit_sc: 'Gr.png',
              imperial_unit_tc: 'Gr.png',
              imperial_unit_en: 'Gr.png',
              negative_image: 'Min.png',
              invalid_image: 'Min.png',
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            //start of ignored block
            if (temperatureUnit == 1) {
              idle_temperature_current_text_img.setProperty(hmUI.prop.MORE, {
                x: 363,
                y: 198,
                font_array: ["SN00.png","SN01.png","SN02.png","SN03.png","SN04.png","SN05.png","SN06.png","SN07.png","SN08.png","SN09.png"],
                padding: false,
                h_space: -2,
                unit_sc: 'Gr.png',
                unit_tc: 'Gr.png',
                unit_en: 'Gr.png',
                imperial_unit_sc: 'Gr.png',
                imperial_unit_tc: 'Gr.png',
                imperial_unit_en: 'Gr.png',
                negative_image: 'Min.png',
                invalid_image: 'Min.png',
                align_h: hmUI.align.RIGHT,
                type: hmUI.data_type.WEATHER_CURRENT,
                show_level: hmUI.show_level.ONLY_AOD,
              });
            };
            //end of ignored block

            idle_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 0,
              y: 0,
              week_en: ["W01.png","W02.png","W03.png","W04.png","W05.png","W06.png","W07.png"],
              week_tc: ["W01.png","W02.png","W03.png","W04.png","W05.png","W06.png","W07.png"],
              week_sc: ["W01.png","W02.png","W03.png","W04.png","W05.png","W06.png","W07.png"],
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_heart_rate_pointer_progress_img_pointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
              src: '0006.png',
              center_x: 233,
              center_y: 109,
              x: 68,
              y: 69,
              start_angle: -150,
              end_angle: 150,
              invalid_visible: false,
              cover_path: '0009.png',
              cover_x: 0,
              cover_y: 0,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 210,
              y: 85,
              font_array: ["BN00.png","BN01.png","BN02.png","BN03.png","BN04.png","BN05.png","BN06.png","BN07.png","BN08.png","BN09.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_heart_rate_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 0,
              y: 0,
              image_array: ["P01.png","P02.png","P03.png","P04.png","P05.png","P06.png"],
              image_length: 6,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_battery_pointer_progress_img_pointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
              src: '0006.png',
              center_x: 233,
              center_y: 355,
              x: 68,
              y: 69,
              start_angle: -150,
              end_angle: 150,
              invalid_visible: false,
              cover_path: '0010.png',
              cover_x: 0,
              cover_y: 0,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 209,
              y: 339,
              font_array: ["BN00.png","BN01.png","BN02.png","BN03.png","BN04.png","BN05.png","BN06.png","BN07.png","BN08.png","BN09.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 315,
              hour_startY: 240,
              hour_array: ["SN00.png","SN01.png","SN02.png","SN03.png","SN04.png","SN05.png","SN06.png","SN07.png","SN08.png","SN09.png"],
              hour_zero: 1,
              hour_space: -2,
              hour_angle: 0,
              hour_unit_sc: 'Db.png',
              hour_unit_tc: 'Db.png',
              hour_unit_en: 'Db.png',
              hour_align: hmUI.align.LEFT,

              minute_startX: 0,
              minute_startY: 0,
              minute_array: ["SN00.png","SN01.png","SN02.png","SN03.png","SN04.png","SN05.png","SN06.png","SN07.png","SN08.png","SN09.png"],
              minute_zero: 1,
              minute_space: 0,
              minute_angle: 0,
              minute_follow: 1,
              minute_unit_sc: 'Db.png',
              minute_unit_tc: 'Db.png',
              minute_unit_en: 'Db.png',
              minute_align: hmUI.align.LEFT,

              second_startX: 0,
              second_startY: 0,
              second_array: ["SN00.png","SN01.png","SN02.png","SN03.png","SN04.png","SN05.png","SN06.png","SN07.png","SN08.png","SN09.png"],
              second_zero: 1,
              second_space: 0,
              second_angle: 0,
              second_follow: 1,
              second_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_analog_clock_time_pointer_hour = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              hour_path: '0003.png',
              hour_centerX: 233,
              hour_centerY: 233,
              hour_posX: 233,
              hour_posY: 233,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_analog_clock_time_pointer_minute = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              minute_path: '0004.png',
              minute_centerX: 233,
              minute_centerY: 233,
              minute_posX: 233,
              minute_posY: 233,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_analog_clock_time_pointer_second = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              second_path: '0005.png',
              second_centerX: 233,
              second_centerY: 233,
              second_posX: 233,
              second_posY: 233,
              show_level: hmUI.show_level.ONLY_AOD,
            });


                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}