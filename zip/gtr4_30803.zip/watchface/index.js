﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.0.1
    ** Copyright © CashaCX75. All Rights Reserved
    */

    try {
    (()=>{
        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_system_lock_img = ''
        let normal_system_dnd_img = ''
        let normal_system_disconnect_img = ''
        let normal_system_clock_img = ''
        let normal_temperature_current_text_img = ''
        let normal_weather_image_progress_img_level = ''
        let normal_city_name_text = ''
        let normal_humidity_text_text_img = ''
        let normal_heart_rate_text_text_img = ''
        let normal_distance_text_text_img = ''
        let normal_pai_day_text_img = ''
        let normal_calorie_current_text_img = ''
        let normal_step_current_text_img = ''
        let normal_date_img_date_week_img = ''
        let normal_date_img_date_month = ''
        let normal_date_img_date_day = ''
        let normal_battery_text_text_img = ''
        let normal_battery_image_progress_img_level = ''
        let normal_digital_clock_img_time = ''
        let idle_system_disconnect_img = ''
        let idle_date_img_date_week_img = ''
        let idle_date_img_date_month = ''
        let idle_date_img_date_day = ''
        let idle_battery_text_text_img = ''
        let idle_digital_clock_img_time = ''
        let normal_countdown_jumpable_img_click = ''
        let normal_alarm_jumpable_img_click = ''
        let normal_temperature_jumpable_img_click = ''
        let normal_pai_jumpable_img_click = ''
        let normal_heart_jumpable_img_click = ''
        let normal_step_jumpable_img_click = ''


        //dynamic modify end
        const e = __$$hmAppManager$$__.currentApp;
        const o = e.current
          , {px: i} = (new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(e,o)),
        e.__globals__)
          , n = Logger.getLogger("watchface6");
        o.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 466,
              h: 466,
              src: 'BACE.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_lock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 419,
              y: 264,
              src: 'Canda.png',
              type: hmUI.system_status.LOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_dnd_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 337,
              y: 319,
              src: 'NM.png',
              type: hmUI.system_status.DISTURB,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 108,
              y: 316,
              src: 'BT3.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 17,
              y: 271,
              src: '0013.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 207,
              y: 230,
              font_array: ["st001.png","st002.png","st003.png","st004.png","st005.png","st006.png","st007.png","st008.png","st009.png","st010.png"],
              padding: false,
              h_space: -5,
              unit_sc: 'kel.png',
              unit_tc: 'kel.png',
              unit_en: 'kel.png',
              negative_image: 'negative.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 215,
              y: 160,
              image_array: ["56.png","57.png","58.png","59.png","60.png","61.png","62.png","63.png","64.png","65.png","66.png","67.png","68.png","69.png","70.png","71.png","72.png","73.png","74.png","75.png","76.png","77.png","78.png","79.png","80.png","81.png","82.png","83.png","84.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_city_name_text = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 157,
              y: 420,
              w: 150,
              h: 30,
              text_size: 22,
              char_space: 0,
              line_space: 0,
              color: 0xFF04FFFF,
              align_h: hmUI.align.LEFT,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.NONE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_humidity_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 392,
              y: 325,
              font_array: ["st001.png","st002.png","st003.png","st004.png","st005.png","st006.png","st007.png","st008.png","st009.png","st010.png"],
              padding: false,
              h_space: -9,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HUMIDITY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 302,
              y: 393,
              font_array: ["di001.png","di002.png","di003.png","di004.png","di005.png","di006.png","di007.png","di008.png","di009.png","di010.png"],
              padding: false,
              h_space: -8,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_distance_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 104,
              y: 393,
              font_array: ["di001.png","di002.png","di003.png","di004.png","di005.png","di006.png","di007.png","di008.png","di009.png","di010.png"],
              padding: false,
              h_space: -10,
              unit_sc: 'dikm.png',
              unit_tc: 'dikm.png',
              unit_en: 'dikm.png',
              dot_image: 'ditelia.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.DISTANCE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_pai_day_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 37,
              y: 325,
              font_array: ["st001.png","st002.png","st003.png","st004.png","st005.png","st006.png","st007.png","st008.png","st009.png","st010.png"],
              padding: false,
              h_space: -10,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.PAI_DAILY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_calorie_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 332,
              y: 286,
              font_array: ["st001.png","st002.png","st003.png","st004.png","st005.png","st006.png","st007.png","st008.png","st009.png","st010.png"],
              padding: false,
              h_space: -10,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 79,
              y: 286,
              font_array: ["st001.png","st002.png","st003.png","st004.png","st005.png","st006.png","st007.png","st008.png","st009.png","st010.png"],
              padding: false,
              h_space: -10,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 100,
              y: 177,
              week_en: ["WEEK01.png","WEEK02.png","WEEK03.png","WEEK04.png","WEEK05.png","WEEK06.png","WEEK07.png"],
              week_tc: ["WEEK01.png","WEEK02.png","WEEK03.png","WEEK04.png","WEEK05.png","WEEK06.png","WEEK07.png"],
              week_sc: ["WEEK01.png","WEEK02.png","WEEK03.png","WEEK04.png","WEEK05.png","WEEK06.png","WEEK07.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_month = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 337,
              month_startY: 177,
              month_sc_array: ["DAY001.png","DAY002.png","DAY003.png","DAY004.png","DAY005.png","DAY006.png","DAY007.png","DAY008.png","DAY009.png","DAY010.png"],
              month_tc_array: ["DAY001.png","DAY002.png","DAY003.png","DAY004.png","DAY005.png","DAY006.png","DAY007.png","DAY008.png","DAY009.png","DAY010.png"],
              month_en_array: ["DAY001.png","DAY002.png","DAY003.png","DAY004.png","DAY005.png","DAY006.png","DAY007.png","DAY008.png","DAY009.png","DAY010.png"],
              month_zero: 1,
              month_space: -1,
              month_align: hmUI.align.LEFT,
              month_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 304,
              day_startY: 177,
              day_sc_array: ["DAY001.png","DAY002.png","DAY003.png","DAY004.png","DAY005.png","DAY006.png","DAY007.png","DAY008.png","DAY009.png","DAY010.png"],
              day_tc_array: ["DAY001.png","DAY002.png","DAY003.png","DAY004.png","DAY005.png","DAY006.png","DAY007.png","DAY008.png","DAY009.png","DAY010.png"],
              day_en_array: ["DAY001.png","DAY002.png","DAY003.png","DAY004.png","DAY005.png","DAY006.png","DAY007.png","DAY008.png","DAY009.png","DAY010.png"],
              day_zero: 1,
              day_space: -2,
              day_unit_sc: 'dayspace.png',
              day_unit_tc: 'dayspace.png',
              day_unit_en: 'dayspace.png',
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 211,
              y: 58,
              font_array: ["BAT001.png","BAT002.png","BAT003.png","BAT004.png","BAT005.png","BAT006.png","BAT007.png","BAT008.png","BAT009.png","BAT010.png"],
              padding: false,
              h_space: -8,
              unit_sc: 'BATEKATO.png',
              unit_tc: 'BATEKATO.png',
              unit_en: 'BATEKATO.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 179,
              y: 10,
              image_array: ["B001.png","B002.png","B003.png","B004.png","B005.png","B006.png","B007.png","B008.png","B009.png","B010.png","B011.png","B012.png","B013.png","B014.png","B015.png","B016.png","B017.png","B018.png","B019.png","B020.png"],
              image_length: 20,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 86,
              hour_startY: 126,
              hour_array: ["TIME001.png","TIME002.png","TIME003.png","TIME004.png","TIME005.png","TIME006.png","TIME007.png","TIME008.png","TIME009.png","TIME010.png"],
              hour_zero: 1,
              hour_space: 0,
              hour_align: hmUI.align.CENTER_H,

              minute_startX: 325,
              minute_startY: 126,
              minute_array: ["TIME001.png","TIME002.png","TIME003.png","TIME004.png","TIME005.png","TIME006.png","TIME007.png","TIME008.png","TIME009.png","TIME010.png"],
              minute_zero: 1,
              minute_space: 0,
              minute_follow: 0,
              minute_align: hmUI.align.CENTER_H,

              second_startX: 202,
              second_startY: 295,
              second_array: ["TIME001.png","TIME002.png","TIME003.png","TIME004.png","TIME005.png","TIME006.png","TIME007.png","TIME008.png","TIME009.png","TIME010.png"],
              second_zero: 1,
              second_space: 3,
              second_follow: 0,
              second_align: hmUI.align.CENTER_H,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });



            idle_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 223,
              y: 176,
              src: 'BT3.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 100,
              y: 177,
              week_en: ["WEEK01.png","WEEK02.png","WEEK03.png","WEEK04.png","WEEK05.png","WEEK06.png","WEEK07.png"],
              week_tc: ["WEEK01.png","WEEK02.png","WEEK03.png","WEEK04.png","WEEK05.png","WEEK06.png","WEEK07.png"],
              week_sc: ["WEEK01.png","WEEK02.png","WEEK03.png","WEEK04.png","WEEK05.png","WEEK06.png","WEEK07.png"],
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_month = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 337,
              month_startY: 177,
              month_sc_array: ["DAY001.png","DAY002.png","DAY003.png","DAY004.png","DAY005.png","DAY006.png","DAY007.png","DAY008.png","DAY009.png","DAY010.png"],
              month_tc_array: ["DAY001.png","DAY002.png","DAY003.png","DAY004.png","DAY005.png","DAY006.png","DAY007.png","DAY008.png","DAY009.png","DAY010.png"],
              month_en_array: ["DAY001.png","DAY002.png","DAY003.png","DAY004.png","DAY005.png","DAY006.png","DAY007.png","DAY008.png","DAY009.png","DAY010.png"],
              month_zero: 1,
              month_space: -1,
              month_align: hmUI.align.LEFT,
              month_is_character: false,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 304,
              day_startY: 177,
              day_sc_array: ["DAY001.png","DAY002.png","DAY003.png","DAY004.png","DAY005.png","DAY006.png","DAY007.png","DAY008.png","DAY009.png","DAY010.png"],
              day_tc_array: ["DAY001.png","DAY002.png","DAY003.png","DAY004.png","DAY005.png","DAY006.png","DAY007.png","DAY008.png","DAY009.png","DAY010.png"],
              day_en_array: ["DAY001.png","DAY002.png","DAY003.png","DAY004.png","DAY005.png","DAY006.png","DAY007.png","DAY008.png","DAY009.png","DAY010.png"],
              day_zero: 1,
              day_space: -2,
              day_unit_sc: 'dayspace.png',
              day_unit_tc: 'dayspace.png',
              day_unit_en: 'dayspace.png',
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 213,
              y: 99,
              font_array: ["BAT001.png","BAT002.png","BAT003.png","BAT004.png","BAT005.png","BAT006.png","BAT007.png","BAT008.png","BAT009.png","BAT010.png"],
              padding: false,
              h_space: -8,
              unit_sc: 'BATEKATO.png',
              unit_tc: 'BATEKATO.png',
              unit_en: 'BATEKATO.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 170,
              hour_startY: 126,
              hour_array: ["TIME001.png","TIME002.png","TIME003.png","TIME004.png","TIME005.png","TIME006.png","TIME007.png","TIME008.png","TIME009.png","TIME010.png"],
              hour_zero: 1,
              hour_space: 0,
              hour_align: hmUI.align.CENTER_H,

              minute_startX: 240,
              minute_startY: 125,
              minute_array: ["TIME001.png","TIME002.png","TIME003.png","TIME004.png","TIME005.png","TIME006.png","TIME007.png","TIME008.png","TIME009.png","TIME010.png"],
              minute_zero: 1,
              minute_space: 0,
              minute_follow: 0,
              minute_align: hmUI.align.CENTER_H,

              show_level: hmUI.show_level.ONLY_AOD,
            });

            normal_countdown_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 182,
              y: 282,
              w: 100,
              h: 100,
              src: 'transparent.png',
              type: hmUI.data_type.COUNT_DOWN,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_alarm_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 8,
              y: 253,
              w: 50,
              h: 40,
              src: 'transparent.png',
              type: hmUI.data_type.ALARM_CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 181,
              y: 164,
              w: 100,
              h: 100,
              src: 'transparent.png',
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_pai_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 24,
              y: 299,
              w: 50,
              h: 50,
              src: 'transparent.png',
              type: hmUI.data_type.PAI_WEEKLY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 302,
              y: 379,
              w: 50,
              h: 50,
              src: 'transparent.png',
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 75,
              y: 258,
              w: 75,
              h: 55,
              src: 'transparent.png',
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            function scale_call() {

              console.log('Wearther city name');
              const weatherSensor = hmSensor.createSensor(hmSensor.id.WEATHER);
              const weatherData = weatherSensor.getForecastWeather();
              normal_city_name_text.setProperty(hmUI.prop.TEXT, weatherData.cityName);

            };

            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                scale_call();
              }),
            });

                //dynamic modify end
            },
            onInit() {
                n.log("index page.js on init invoke")
            },
            build() {
                this.init_view(),
                n.log("index page.js on ready invoke")
            },
            onDestroy() {
                n.log("index page.js on destroy invoke")
            }
        })
    }
    )()
} catch (e) {
    console.log("Mini Program Error", e),
    e && e.stack && e.stack.split(/\n/).forEach((e=>console.log("error stack", e)))
}
