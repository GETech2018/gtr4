﻿
    /*
    ** Watch_Face_Editor tool
    ** watchface js version v1.0.1
    ** Copyright © CashaCX75. All Rights Reserved
    */

    try {

      (() => {

        var __$$app$$__ = __$$hmAppManager$$__.currentApp;
        var __$$module$$__ = __$$app$$__.current;
        //drink is a name,can modify
        var h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__), 'drink');

        'use strict';

        //dynamic modify start

        
        let normal_background_bg = ''
        let normal_stress_icon_img = ''
        let normal_heart_rate_text_text_img = ''
        let normal_heart_rate_text_separator_img = ''
        let normal_battery_text_text_img = ''
        let normal_battery_text_separator_img = ''
        let normal_date_img_date_week_img = ''
        let normal_date_img_date_month_img = ''
        let normal_date_img_date_day = ''
        let normal_digital_clock_img_time = ''
        let idle_background_bg = ''
        let idle_battery_text_text_img = ''
        let idle_digital_clock_img_time = ''
        let idle_stress_icon_img = ''


        //dynamic modify end

        //not required
        const logger = DeviceRuntimeCore.HmLogger.getLogger("yeguang");

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({

          init_view() {

            //dynamic modify start
                    
            
            normal_background_bg = hmUI.createWidget(hmUI.widget.FILL_RECT, {
              x: 0,
              y: 0,
              w: 466,
              h: 466,
              color: '0xFF000000',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_stress_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: -6,
              y: -3,
              src: 'ringingcture80.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 44,
              y: 206,
              font_array: ["aomonthsmall_4-5gans_0001.png","aomonthsmall_4-5gans_0002.png","aomonthsmall_4-5gans_0003.png","aomonthsmall_4-5gans_0004.png","aomonthsmall_4-5gans_0005.png","aomonthsmall_4-5gans_0006.png","aomonthsmall_4-5gans_0007.png","aomonthsmall_4-5gans_0008.png","aomonthsmall_4-5gans_0009.png","aomonthsmall_4-5gans_0010.png"],
              padding: false,
              h_space: -36,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 34,
              y: 216,
              src: 'Picture60.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 367,
              y: 206,
              font_array: ["aomonthsmall_4-5gans_0001.png","aomonthsmall_4-5gans_0002.png","aomonthsmall_4-5gans_0003.png","aomonthsmall_4-5gans_0004.png","aomonthsmall_4-5gans_0005.png","aomonthsmall_4-5gans_0006.png","aomonthsmall_4-5gans_0007.png","aomonthsmall_4-5gans_0008.png","aomonthsmall_4-5gans_0009.png","aomonthsmall_4-5gans_0010.png"],
              padding: false,
              h_space: -39,
              unit_sc: 'unitpocture.png',
              unit_tc: 'unitpocture.png',
              unit_en: 'unitpocture.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 359,
              y: 220,
              src: 'Picture61.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 255,
              y: 207,
              week_en: ["daysmall_4-5gans_0001.png","daysmall_4-5gans_0002.png","daysmall_4-5gans_0003.png","daysmall_4-5gans_0004.png","daysmall_4-5gans_0005.png","daysmall_4-5gans_0006.png","daysmall_4-5gans_0007.png"],
              week_tc: ["daysmall_4-5gans_0001.png","daysmall_4-5gans_0002.png","daysmall_4-5gans_0003.png","daysmall_4-5gans_0004.png","daysmall_4-5gans_0005.png","daysmall_4-5gans_0006.png","daysmall_4-5gans_0007.png"],
              week_sc: ["daysmall_4-5gans_0001.png","daysmall_4-5gans_0002.png","daysmall_4-5gans_0003.png","daysmall_4-5gans_0004.png","daysmall_4-5gans_0005.png","daysmall_4-5gans_0006.png","daysmall_4-5gans_0007.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_month_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 184,
              month_startY: 206,
              month_sc_array: ["monthsmall_4-5gans_0001.png","monthsmall_4-5gans_0002.png","monthsmall_4-5gans_0003.png","monthsmall_4-5gans_0004.png","monthsmall_4-5gans_0005.png","monthsmall_4-5gans_0006.png","monthsmall_4-5gans_0007.png","monthsmall_4-5gans_0008.png","monthsmall_4-5gans_0009.png","monthsmall_4-5gans_0010.png","monthsmall_4-5gans_0011.png","monthsmall_4-5gans_0012.png"],
              month_tc_array: ["monthsmall_4-5gans_0001.png","monthsmall_4-5gans_0002.png","monthsmall_4-5gans_0003.png","monthsmall_4-5gans_0004.png","monthsmall_4-5gans_0005.png","monthsmall_4-5gans_0006.png","monthsmall_4-5gans_0007.png","monthsmall_4-5gans_0008.png","monthsmall_4-5gans_0009.png","monthsmall_4-5gans_0010.png","monthsmall_4-5gans_0011.png","monthsmall_4-5gans_0012.png"],
              month_en_array: ["monthsmall_4-5gans_0001.png","monthsmall_4-5gans_0002.png","monthsmall_4-5gans_0003.png","monthsmall_4-5gans_0004.png","monthsmall_4-5gans_0005.png","monthsmall_4-5gans_0006.png","monthsmall_4-5gans_0007.png","monthsmall_4-5gans_0008.png","monthsmall_4-5gans_0009.png","monthsmall_4-5gans_0010.png","monthsmall_4-5gans_0011.png","monthsmall_4-5gans_0012.png"],
              month_is_character: true ,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 134,
              day_startY: 206,
              day_sc_array: ["small_4-5gans_0001.png","small_4-5gans_0002.png","small_4-5gans_0003.png","small_4-5gans_0004.png","small_4-5gans_0005.png","small_4-5gans_0006.png","small_4-5gans_0007.png","small_4-5gans_0008.png","small_4-5gans_0009.png","small_4-5gans_0010.png"],
              day_tc_array: ["small_4-5gans_0001.png","small_4-5gans_0002.png","small_4-5gans_0003.png","small_4-5gans_0004.png","small_4-5gans_0005.png","small_4-5gans_0006.png","small_4-5gans_0007.png","small_4-5gans_0008.png","small_4-5gans_0009.png","small_4-5gans_0010.png"],
              day_en_array: ["small_4-5gans_0001.png","small_4-5gans_0002.png","small_4-5gans_0003.png","small_4-5gans_0004.png","small_4-5gans_0005.png","small_4-5gans_0006.png","small_4-5gans_0007.png","small_4-5gans_0008.png","small_4-5gans_0009.png","small_4-5gans_0010.png"],
              day_zero: 1,
              day_space: -36,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 72,
              hour_startY: -89,
              hour_array: ["muticolo_digi_0001.png","muticolo_digi_0002.png","muticolo_digi_0003.png","muticolo_digi_0004.png","muticolo_digi_0005.png","muticolo_digi_0006.png","muticolo_digi_0007.png","muticolo_digi_0008.png","muticolo_digi_0009.png","muticolo_digi_0010.png"],
              hour_zero: 1,
              hour_space: -63,
              hour_align: hmUI.align.CENTER_H,

              minute_startX: 72,
              minute_startY: 131,
              minute_array: ["muticolo_digi_0001.png","muticolo_digi_0002.png","muticolo_digi_0003.png","muticolo_digi_0004.png","muticolo_digi_0005.png","muticolo_digi_0006.png","muticolo_digi_0007.png","muticolo_digi_0008.png","muticolo_digi_0009.png","muticolo_digi_0010.png"],
              minute_zero: 1,
              minute_space: -65,
              minute_follow: 0,
              minute_align: hmUI.align.CENTER_H,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            idle_background_bg = hmUI.createWidget(hmUI.widget.FILL_RECT, {
              x: 0,
              y: 0,
              w: 466,
              h: 466,
              color: '0xFF000000',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 203,
              y: 206,
              font_array: ["aomonthsmall_4-5gans_0001.png","aomonthsmall_4-5gans_0002.png","aomonthsmall_4-5gans_0003.png","aomonthsmall_4-5gans_0004.png","aomonthsmall_4-5gans_0005.png","aomonthsmall_4-5gans_0006.png","aomonthsmall_4-5gans_0007.png","aomonthsmall_4-5gans_0008.png","aomonthsmall_4-5gans_0009.png","aomonthsmall_4-5gans_0010.png"],
              padding: false,
              h_space: -39,
              unit_sc: 'unitpocture.png',
              unit_tc: 'unitpocture.png',
              unit_en: 'unitpocture.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 72,
              hour_startY: -89,
              hour_array: ["muticolo_digi_0001.png","muticolo_digi_0002.png","muticolo_digi_0003.png","muticolo_digi_0004.png","muticolo_digi_0005.png","muticolo_digi_0006.png","muticolo_digi_0007.png","muticolo_digi_0008.png","muticolo_digi_0009.png","muticolo_digi_0010.png"],
              hour_zero: 1,
              hour_space: -63,
              hour_align: hmUI.align.CENTER_H,

              minute_startX: 72,
              minute_startY: 131,
              minute_array: ["muticolo_digi_0001.png","muticolo_digi_0002.png","muticolo_digi_0003.png","muticolo_digi_0004.png","muticolo_digi_0005.png","muticolo_digi_0006.png","muticolo_digi_0007.png","muticolo_digi_0008.png","muticolo_digi_0009.png","muticolo_digi_0010.png"],
              minute_zero: 1,
              minute_space: -65,
              minute_follow: 0,
              minute_align: hmUI.align.CENTER_H,

              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_stress_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: -6,
              y: 30,
              src: 'AOB Overlay - 2.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });


            //dynamic modify end
          },

          onInit() {
            console.log('index page.js on init invoke')

            this.init_view()

          },

          onReady() {
            console.log('index page.js on ready invoke')
          },

          onShow() {
            console.log('index page.js on show invoke')
          },

          onHide() {
            console.log('index page.js on hide invoke')
          },

          onDestory() {
            console.log('index page.js on destory invoke')
          },
        });

      })()
    } catch (e) {
      console.log(e)
    }
  