﻿
/*
    ** Watch_Face_Editor tool with Integrated Calendar
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
*/

try {
    (() => {
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() { return __$$app$$__.app; }
        function getCurrentPage() { return __$$app$$__.current && __$$app$$__.current.module; }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        const logger = Logger.getLogger('watchface_SashaCX75');

        // Переменные для циферблата
        let normal_background_bg = '', normal_sun_current_text_img = '', normal_altimeter_text_text_img = '',
            normal_altimeter_text_separator_img = '', normal_wind_direction_image_progress_img_level = '',
            normal_wind_text_text_img = '', normal_wind_text_separator_img = '', normal_system_disconnect_img = '',
            normal_system_clock_img = '', normal_battery_image_progress_img_level = '', normal_battery_text_text_img = '',
            normal_weather_image_progress_img_level = '', normal_temperature_high_text_img = '',
            normal_temperature_low_text_img = '', normal_temperature_current_text_img = '', normal_image_img = '',
            normal_digital_clock_img_time = '', idle_background_bg = '', idle_digital_clock_img_time = '',
            normal_altimeter_mm_img = '';

        // Переменные для календаря
        const customFont = 'fonts/mi-Bold_0.ttf';
        let calendarWidgets = [];
        let timeSensor = null;

        // Размеры и отступы для календаря
        const cellSizeWidth = 30, cellSizeHeight = 25, cellSpacing = 2;

        // Функции для работы с давлением (из циферблата)
        function read_pressure() {
            console.log("read_pressure()");
            const file_name_alt = "../../../baro_altim/pressure.dat";
            const [fs_stat, err] = hmFS.stat(file_name_alt);
            if (err == 0) {
                let file_size = fs_stat.size;
                const len = file_size / 4;
                console.log(`size_alt: ${file_size}, lenght: ${len}`);
                const fh = hmFS.open(file_name_alt, hmFS.O_RDONLY);
                let array_buffer = new Float32Array(len);
                hmFS.read(fh, array_buffer.buffer, 0, file_size);
                hmFS.close(fh);
                console.log(`value ${array_buffer[array_buffer.length - 1]}`);
                return array_buffer;
            } else {
                console.log('err:', err);
            }
            return null;
        }

        function getPressureValue(pressure_array) {
            console.log("getPressureValue()");
            if (!pressure_array || pressure_array.length == 0) return 0;
            let start_index = pressure_array.length - 1;
            let end_index = start_index - 30 * 3;
            if (end_index < 0) end_index = 0;
            for (let index = start_index; index >= end_index; index--) {
                if (pressure_array[index] != 0) return parseInt(pressure_array[index] / 100);
            }
            return 0;
        }

        function hPa_To_mmHg(hPa_value = 0) {
            return Math.round(hPa_value * 0.750064);
        }

        function getPressureMMHG() {
            const pressure_array = read_pressure();
            return hPa_To_mmHg(getPressureValue(pressure_array));
        }

        function updatePressure() {
            const pressureValue = getPressureMMHG();
            normal_altimeter_text_text_img.setProperty(hmUI.prop.MORE, {
                x: 119, y: 372, font_array: ["46.png","47.png","48.png","49.png","50.png","51.png","52.png","53.png","54.png","55.png"],
                padding: false, h_space: 0, invalid_image: '78.png', text: pressureValue, show_level: hmUI.show_level.ONLY_NORMAL
            });
            normal_altimeter_mm_img.setProperty(hmUI.prop.MORE, {
                x: 119 + 48, y: 372, show_level: hmUI.show_level.ONLY_NORMAL
            });
        }

        // Функция обновления календаря
        function updateCalendar(day, month, year) {
            calendarWidgets.forEach(widget => hmUI.deleteWidget(widget));
            calendarWidgets = [];

            const today = new Date(year, month, day);
            const currentDay = today.getDate();
            const currentMonth = today.getMonth();
            const currentYear = today.getFullYear();

            const firstDay = (new Date(currentYear, currentMonth, 1).getDay() + 6) % 7;
            const daysInMonth = new Date(currentYear, currentMonth + 1, 0).getDate();

            const monthNames = ["Январь", "Февраль", "Март", "Апрель", "Май", "Июнь",
                "Июль", "Август", "Сентябрь", "Октябрь", "Ноябрь", "Декабрь"];
            const daysOfWeek = ["ПН", "ВТ", "СР", "ЧТ", "ПТ", "СБ", "ВС"];

            const startX = 210, startY = 195;
            const colorWeekday = 0xFFFFFF, colorSaturday = 0xecb2b2, colorSunday = 0xecb2b2,
                  colorToday = 0xFF0000, backgroundColor = 0x333333, backgroundRadius = 8,
                  todayBackgroundColor = 0x555555;

            calendarWidgets.push(hmUI.createWidget(hmUI.widget.TEXT, {
                x: startX + 50, y: startY, w: 200, h: 40, color: 0xFFFFFF, text_size: 20,
                align_h: hmUI.align.CENTER_H, text: `${monthNames[currentMonth]} ${currentYear}`, font: customFont,
                show_level: hmUI.show_level.ONLY_NORMAL
            }));

            calendarWidgets.push(hmUI.createWidget(hmUI.widget.FILL_RECT, {
                x: startX - 5, y: startY + 30 - 5, w: cellSizeWidth * 7 + 10, h: 30,
                radius: backgroundRadius, color: backgroundColor, show_level: hmUI.show_level.ONLY_NORMAL
            }));

            for (let i = 0; i < 7; i++) {
                calendarWidgets.push(hmUI.createWidget(hmUI.widget.TEXT, {
                    x: startX + i * cellSizeWidth, y: startY + 30, w: cellSizeWidth, h: 30,
                    color: 0xC8C8C8, text_size: 18, align_h: hmUI.align.CENTER_H, text: daysOfWeek[i],
                    font: customFont, show_level: hmUI.show_level.ONLY_NORMAL
                }));
            }

            for (let i = 1; i <= daysInMonth; i++) {
                let x = startX + ((i + firstDay - 1) % 7) * cellSizeWidth;
                let y = startY + 60 + Math.floor((i + firstDay - 1) / 7) * cellSizeHeight;

                if (i === currentDay) {
                    calendarWidgets.push(hmUI.createWidget(hmUI.widget.FILL_RECT, {
                        x: x - cellSpacing, y: y - cellSpacing, w: cellSizeWidth + cellSpacing * 2,
                        h: cellSizeHeight + cellSpacing * 2, radius: 6, color: todayBackgroundColor,
                        show_level: hmUI.show_level.ONLY_NORMAL
                    }));
                }

                let textColor = ((i + firstDay - 1) % 7 === 5) ? colorSaturday :
                               ((i + firstDay - 1) % 7 === 6) ? colorSunday : colorWeekday;
                if (i === currentDay) textColor = colorToday;

                calendarWidgets.push(hmUI.createWidget(hmUI.widget.TEXT, {
                    x: x, y: y, w: cellSizeWidth, h: cellSizeHeight, color: textColor,
                    text_size: 18, align_h: hmUI.align.CENTER_H, text: `${i}`, font: customFont,
                    show_level: hmUI.show_level.ONLY_NORMAL
                }));
            }
        }

        // Основной модуль циферблата
        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                // Инициализация сенсора времени
                if (!timeSensor) timeSensor = hmSensor.createSensor(hmSensor.id.TIME);

                // Инициализация виджетов циферблата
                normal_background_bg = hmUI.createWidget(hmUI.widget.FILL_RECT, {
                    x: 0, y: 0, w: 466, h: 466, color: '0xFF000000', show_level: hmUI.show_level.ONLY_NORMAL
                });
                normal_sun_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                    x: 128, y: 407, font_array: ["46.png","47.png","48.png","49.png","50.png","51.png","52.png","53.png","54.png","55.png"],
                    padding: false, h_space: 0, dot_image: '91.png', align_h: hmUI.align.CENTER_H, type: hmUI.data_type.SUN_CURRENT,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                normal_altimeter_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                    x: 119, y: 372, font_array: ["46.png","47.png","48.png","49.png","50.png","51.png","52.png","53.png","54.png","55.png"],
                    padding: false, h_space: 0, invalid_image: '78.png', align_h: hmUI.align.CENTER_H, text: getPressureMMHG(),
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                normal_altimeter_mm_img = hmUI.createWidget(hmUI.widget.IMG, {
                    x: 119 + 48, y: 372, src: "90.png", show_level: hmUI.show_level.ONLY_NORMAL
                });
                normal_altimeter_text_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
                    x: 90, y: 369, src: '89.png', show_level: hmUI.show_level.ONLY_NORMAL
                });
                normal_wind_direction_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
                    x: 174, y: 333, image_array: ["80.png","81.png","82.png","83.png","84.png","85.png","86.png","87.png"],
                    image_length: 8, type: hmUI.data_type.WIND_DIRECTION, show_level: hmUI.show_level.ONLY_NORMAL
                });
                normal_wind_direction_image_progress_img_level.setAlpha(240);
                normal_wind_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                    x: 104, y: 336, font_array: ["46.png","47.png","48.png","49.png","50.png","51.png","52.png","53.png","54.png","55.png"],
                    padding: false, h_space: 0, unit_sc: '79.png', unit_tc: '79.png', unit_en: '79.png', align_h: hmUI.align.CENTER_H,
                    type: hmUI.data_type.WIND, show_level: hmUI.show_level.ONLY_NORMAL
                });
                normal_wind_text_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
                    x: 67, y: 333, src: '88.png', show_level: hmUI.show_level.ONLY_NORMAL
                });
                normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
                    x: 375, y: 90, src: '33.png', type: hmUI.system_status.DISCONNECT, show_level: hmUI.show_level.ONLY_NORMAL
                });
                normal_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
                    x: 344, y: 91, src: '34.png', type: hmUI.system_status.CLOCK, show_level: hmUI.show_level.ONLY_NORMAL
                });
                normal_battery_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
                    x: 220, 
                    y: 81, 
                    image_array: ["56.png","57.png","58.png","59.png","60.png","61.png","62.png","63.png"],
                    image_length: 8, 
                    type: hmUI.data_type.BATTERY, 
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                    x: 251, y: 95, font_array: ["64.png","65.png","66.png","67.png","68.png","69.png","70.png","71.png","72.png","73.png"],
                    padding: false, h_space: 0, unit_sc: '74.png', unit_tc: '74.png', unit_en: '74.png', align_h: hmUI.align.CENTER_H,
                    type: hmUI.data_type.BATTERY, show_level: hmUI.show_level.ONLY_NORMAL
                });
                normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
                    x: 35, y: 102, image_array: ["3.png","4.png","5.png","6.png","7.png","8.png","9.png","10.png","11.png","12.png","13.png","14.png","15.png","16.png","17.png","18.png","19.png","20.png","21.png","22.png","23.png","24.png","25.png","26.png","27.png","28.png","29.png","30.png","31.png"],
                    image_length: 29, type: hmUI.data_type.WEATHER_CURRENT, show_level: hmUI.show_level.ONLY_NORMAL
                });
                normal_temperature_high_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                    x: 132, y: 68, font_array: ["46.png","47.png","48.png","49.png","50.png","51.png","52.png","53.png","54.png","55.png"],
                    padding: false, h_space: 0, unit_sc: '77.png', unit_tc: '77.png', unit_en: '77.png', negative_image: '78.png',
                    invalid_image: '78.png', align_h: hmUI.align.RIGHT, type: hmUI.data_type.WEATHER_HIGH, show_level: hmUI.show_level.ONLY_NORMAL
                });
                normal_temperature_low_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                    x: 132, y: 101, font_array: ["46.png","47.png","48.png","49.png","50.png","51.png","52.png","53.png","54.png","55.png"],
                    padding: false, h_space: 0, unit_sc: '77.png', unit_tc: '77.png', unit_en: '77.png', negative_image: '78.png',
                    invalid_image: '78.png', align_h: hmUI.align.RIGHT, type: hmUI.data_type.WEATHER_LOW, show_level: hmUI.show_level.ONLY_NORMAL
                });
                normal_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                    x: 18, y: 251, font_array: ["64.png","65.png","66.png","67.png","68.png","69.png","70.png","71.png","72.png","73.png"],
                    padding: false, h_space: 0, unit_sc: '75.png', unit_tc: '75.png', unit_en: '75.png', negative_image: '76.png',
                    invalid_image: '76.png', align_h: hmUI.align.CENTER_H, type: hmUI.data_type.WEATHER_CURRENT, show_level: hmUI.show_level.ONLY_NORMAL
                });
                normal_image_img = hmUI.createWidget(hmUI.widget.IMG, {
                    x: 0, y: 0, src: '1.png', show_level: hmUI.show_level.ONLY_NORMAL
                });
                normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
                    hour_startX: 233, hour_startY: 135, hour_array: ["35.png","36.png","37.png","38.png","39.png","40.png","41.png","42.png","43.png","44.png"],
                    hour_zero: 1, hour_space: 0, hour_angle: 0, hour_unit_sc: '45.png', hour_unit_tc: '45.png', hour_unit_en: '45.png',
                    hour_align: hmUI.align.CENTER_H, minute_startX: 0, minute_startY: 0, minute_array: ["35.png","36.png","37.png","38.png","39.png","40.png","41.png","42.png","43.png","44.png"],
                    minute_zero: 1, minute_space: 0, minute_angle: 0, minute_follow: 1, minute_align: hmUI.align.CENTER_H,
                    second_startX: 400, second_startY: 165, second_array: ["46.png","47.png","48.png","49.png","50.png","51.png","52.png","53.png","54.png","55.png"],
                    second_zero: 1, second_space: 0, second_angle: 0, second_follow: 0, second_align: hmUI.align.CENTER_H,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                idle_background_bg = hmUI.createWidget(hmUI.widget.FILL_RECT, {
                    x: 0, y: 0, w: 466, h: 466, color: '0xFF000000', show_level: hmUI.show_level.ONLY_AOD
                });
                idle_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
                    hour_startX: 233, hour_startY: 183, hour_array: ["35.png","36.png","37.png","38.png","39.png","40.png","41.png","42.png","43.png","44.png"],
                    hour_zero: 1, hour_space: 0, hour_angle: 0, hour_unit_sc: '45.png', hour_unit_tc: '45.png', hour_unit_en: '45.png',
                    hour_align: hmUI.align.CENTER_H, minute_startX: 0, minute_startY: 0, minute_array: ["35.png","36.png","37.png","38.png","39.png","40.png","41.png","42.png","43.png","44.png"],
                    minute_zero: 1, minute_space: 0, minute_angle: 0, minute_follow: 1, minute_align: hmUI.align.CENTER_H,
                    second_startX: 400, second_startY: 187, second_array: ["46.png","47.png","48.png","49.png","50.png","51.png","52.png","53.png","54.png","55.png"],
                    second_zero: 1, second_space: 0, second_angle: 0, second_follow: 0, second_align: hmUI.align.CENTER_H,
                    show_level: hmUI.show_level.ONLY_AOD
                });

                // Инициализация календаря
                time_update(true);

                // Подписка на смену дня
                timeSensor.addEventListener(timeSensor.event.DAYCHANGE, function() {
                    time_update(true);
                });
            },

            onInit() {
                logger.log('index page.js on init invoke');
            },

            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },

            onDestroy() {
                logger.log('index page.js on destroy invoke');
                if (timeSensor) timeSensor.removeEventListener(timeSensor.event.DAYCHANGE);
                calendarWidgets.forEach(widget => hmUI.deleteWidget(widget));
                calendarWidgets = [];
            }
        });

        const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
            resume_call: () => {
                console.log('resume_call()');
                updatePressure();
                time_update(true);
            }
        });

        function time_update(updateDay = false) {
            if (!timeSensor) return;
            let g_day = timeSensor.day;
            let g_month = timeSensor.month - 1;
            let g_year = timeSensor.year;
            if (updateDay) updateCalendar(g_day, g_month, g_year);
        }
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
}
