﻿
    /*
    ** Watch_Face_Editor tool
    ** watchface js version v1.0.1
    ** Copyright © CashaCX75. All Rights Reserved
    */

    try {

      (() => {

        var __$$app$$__ = __$$hmAppManager$$__.currentApp;
        var __$$module$$__ = __$$app$$__.current;
        //drink is a name,can modify
        var h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__), 'drink');

        'use strict';

        //dynamic modify start

        
        let normal_background_bg = ''
        let editBg = ''
        let normal_humidity_icon_img = ''
        let normal_day_pointer_progress_date_pointer = ''
        let idle_background_bg = ''
        let idle_humidity_icon_img = ''
        let idle_day_pointer_progress_date_pointer = ''
        let editableZone_1_battery_circle_scale = null;
        let editableZone_1_heart_rate_circle_scale = null;
        let editableZone_1_step_circle_scale = null;
        let editGroup_1  = ''
        let editableZone_2_heart_rate_circle_scale = null;
        let editableZone_2_step_circle_scale = null;
        let editableZone_2_battery_circle_scale = null;
        let editableZone_2_calorie_circle_scale = null;
        let editGroup_2  = ''
        let editableZone_3_battery_circle_scale = null;
        let editableZone_3_heart_rate_circle_scale = null;
        let editableZone_3_step_circle_scale = null;
        let editableZone_3_calorie_circle_scale = null;
        let editGroup_3  = ''
        let mask = ''
        let fg_mask = ''
        let editableTimePointers = ''


        //dynamic modify end

        //not required
        const logger = DeviceRuntimeCore.HmLogger.getLogger("yeguang");

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({

          init_view() {

            //dynamic modify start
                    
            
            normal_background_bg = hmUI.createWidget(hmUI.widget.FILL_RECT, {
              x: 0,
              y: 0,
              w: 466,
              h: 466,
              color: '0xFF000000',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            editBg = hmUI.createWidget(hmUI.widget.WATCHFACE_EDIT_BG, {
            });

            normal_humidity_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 309,
              y: 314,
              src: '0002.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_day_pointer_progress_date_pointer = hmUI.createWidget(hmUI.widget.DATE_POINTER, {
              src: '0007.png',
              center_x: 233,
              center_y: 233,
              posX: 178,
              posY: 178,
              start_angle: 131,
              end_angle: 490,
              cover_path: '0001.png',
              cover_x: 0,
              cover_y: 0,
              type: hmUI.date.DAY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            idle_background_bg = hmUI.createWidget(hmUI.widget.FILL_RECT, {
              x: 0,
              y: 0,
              w: 466,
              h: 466,
              color: '0xFF000000',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_humidity_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 309,
              y: 314,
              src: '0002.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_day_pointer_progress_date_pointer = hmUI.createWidget(hmUI.widget.DATE_POINTER, {
              src: '0007.png',
              center_x: 233,
              center_y: 233,
              posX: 178,
              posY: 178,
              start_angle: 131,
              end_angle: 490,
              cover_path: '0001.png',
              cover_x: 0,
              cover_y: 0,
              type: hmUI.date.DAY,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            let screenType = hmSetting.getScreenType();            
            const battery = hmSensor.createSensor(hmSensor.id.BATTERY);

                        
            const heart_rate = hmSensor.createSensor(hmSensor.id.HEART);

                        
            const step = hmSensor.createSensor(hmSensor.id.STEP);

            editGroup_1 = hmUI.createWidget(hmUI.widget.WATCHFACE_EDIT_GROUP, {
              edit_id: 10021,
              x: 179,
              y: 282,
              w: 108,
              h: 108,
              select_image: '0024.png',
              un_select_image: '0025.png',
              default_type: hmUI.edit_type.BATTERY,
              optional_types: [
                { type: hmUI.edit_type.BATTERY, preview: '0023.png' },
                { type: hmUI.edit_type.WEEK, preview: '0042.png' },
                { type: hmUI.edit_type.HEART, preview: '0026.png' },
                { type: hmUI.edit_type.STEP, preview: '0044.png' },
              ],
              count: 4,
              tips_BG: '0006.png',
              tips_x: -77,
              tips_y: -191,
              tips_width: 261,
              tips_margin: 0,
            });

            const editType_1 = editGroup_1.getProperty(hmUI.prop.CURRENT_TYPE);

            switch (editType_1) {
              case hmUI.edit_type.WEEK:
                hmUI.createWidget(hmUI.widget.IMG_WEEK, {
                  x: 185,
                  y: 299,
                  week_en: ["0035.png","0036.png","0037.png","0038.png","0039.png","0040.png","0041.png"],
                  week_tc: ["0035.png","0036.png","0037.png","0038.png","0039.png","0040.png","0041.png"],
                  week_sc: ["0035.png","0036.png","0037.png","0038.png","0039.png","0040.png","0041.png"],
                  show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_AOD,
                });
                break;

              case hmUI.edit_type.BATTERY:
                hmUI.createWidget(hmUI.widget.IMG, {
                  x: 179,
                  y: 282,
                  src: '0022.png',
                  show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_AOD,
                });

                // editableZone_1_battery_circle_scale = hmUI.createWidget(hmUI.widget.Circle_Scale, {
                  // center_x: 233,
                  // center_y: 336,
                  // start_angle: -150,
                  // end_angle: 150,
                  // radius: 50,
                  // line_width: 7,
                  // color: 0xFF4EB176,
                  // mirror: False,
                  // inversion: False,
                  // type: hmUI.data_type.BATTERY,
                  // show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_AOD,
                // });

                if (screenType == hmSetting.screen_type.WATCHFACE || screenType == hmSetting.screen_type.AOD) {
                  editableZone_1_battery_circle_scale = hmUI.createWidget(hmUI.widget.ARC);
                };
                battery.addEventListener(hmSensor.event.CHANGE, function() {
                  scale_call();
                });

                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                  x: 200,
                  y: 313,
                  font_array: ["0010.png","0011.png","0012.png","0013.png","0014.png","0015.png","0016.png","0017.png","0018.png","0019.png"],
                  padding: false,
                  h_space: -2,
                  align_h: hmUI.align.CENTER_H,
                  type: hmUI.data_type.BATTERY,
                  show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_AOD,
                });
                break;

              case hmUI.edit_type.STEP:
                hmUI.createWidget(hmUI.widget.IMG, {
                  x: 179,
                  y: 282,
                  src: '0043.png',
                  show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_AOD,
                });

                // editableZone_1_step_circle_scale = hmUI.createWidget(hmUI.widget.Circle_Scale, {
                  // center_x: 233,
                  // center_y: 336,
                  // start_angle: -150,
                  // end_angle: 150,
                  // radius: 50,
                  // line_width: 7,
                  // color: 0xFF00FFFF,
                  // mirror: False,
                  // inversion: False,
                  // type: hmUI.data_type.STEP,
                  // show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_AOD,
                // });

                if (screenType == hmSetting.screen_type.WATCHFACE || screenType == hmSetting.screen_type.AOD) {
                  editableZone_1_step_circle_scale = hmUI.createWidget(hmUI.widget.ARC);
                };
                step.addEventListener(hmSensor.event.CHANGE, function() {
                  scale_call();
                });
                break;

              case hmUI.edit_type.HEART:
                hmUI.createWidget(hmUI.widget.IMG, {
                  x: 179,
                  y: 282,
                  src: '0034.png',
                  show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_AOD,
                });

                // editableZone_1_heart_circle_scale = hmUI.createWidget(hmUI.widget.Circle_Scale, {
                  // center_x: 233,
                  // center_y: 336,
                  // start_angle: -150,
                  // end_angle: 150,
                  // radius: 50,
                  // line_width: 7,
                  // color: 0xFFFF0D13,
                  // mirror: False,
                  // inversion: False,
                  // type: hmUI.data_type.HEART,
                  // show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_AOD,
                // });

                if (screenType == hmSetting.screen_type.WATCHFACE || screenType == hmSetting.screen_type.AOD) {
                  editableZone_1_heart_rate_circle_scale = hmUI.createWidget(hmUI.widget.ARC);
                };
                heart_rate.addEventListener(hmSensor.event.LAST, function() {
                  scale_call();
                });

                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                  x: 201,
                  y: 313,
                  font_array: ["0010.png","0011.png","0012.png","0013.png","0014.png","0015.png","0016.png","0017.png","0018.png","0019.png"],
                  padding: false,
                  h_space: -2,
                  align_h: hmUI.align.CENTER_H,
                  type: hmUI.data_type.HEART,
                  show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_AOD,
                });
                break;
            }; // end switch

            
            
            
                        
            const calorie = hmSensor.createSensor(hmSensor.id.CALORIE);

            editGroup_2 = hmUI.createWidget(hmUI.widget.WATCHFACE_EDIT_GROUP, {
              edit_id: 10022,
              x: 68,
              y: 174,
              w: 122,
              h: 122,
              select_image: '0045.png',
              un_select_image: '0046.png',
              default_type: hmUI.edit_type.HEART,
              optional_types: [
                { type: hmUI.edit_type.HEART, preview: '0049.png' },
                { type: hmUI.edit_type.STEP, preview: '0053.png' },
                { type: hmUI.edit_type.BATTERY, preview: '0048.png' },
                { type: hmUI.edit_type.CAL, preview: '0055.png' },
                { type: hmUI.edit_type.WEEK, preview: '0051.png' },
              ],
              count: 5,
              tips_BG: '0006.png',
              tips_x: 34,
              tips_y: -83,
              tips_width: 261,
              tips_margin: 0,
            });

            const editType_2 = editGroup_2.getProperty(hmUI.prop.CURRENT_TYPE);

            switch (editType_2) {
              case hmUI.edit_type.WEEK:
                hmUI.createWidget(hmUI.widget.IMG_WEEK, {
                  x: 79,
                  y: 198,
                  week_en: ["0035.png","0036.png","0037.png","0038.png","0039.png","0040.png","0041.png"],
                  week_tc: ["0035.png","0036.png","0037.png","0038.png","0039.png","0040.png","0041.png"],
                  week_sc: ["0035.png","0036.png","0037.png","0038.png","0039.png","0040.png","0041.png"],
                  show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_AOD,
                });
                break;

              case hmUI.edit_type.BATTERY:
                hmUI.createWidget(hmUI.widget.IMG, {
                  x: 68,
                  y: 174,
                  src: '0047.png',
                  show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_AOD,
                });

                // editableZone_2_battery_circle_scale = hmUI.createWidget(hmUI.widget.Circle_Scale, {
                  // center_x: 129,
                  // center_y: 234,
                  // start_angle: -150,
                  // end_angle: 150,
                  // radius: 57,
                  // line_width: 8,
                  // color: 0xFF4EB176,
                  // mirror: False,
                  // inversion: False,
                  // type: hmUI.data_type.BATTERY,
                  // show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_AOD,
                // });

                if (screenType == hmSetting.screen_type.WATCHFACE || screenType == hmSetting.screen_type.AOD) {
                  editableZone_2_battery_circle_scale = hmUI.createWidget(hmUI.widget.ARC);
                };

                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                  x: 96,
                  y: 211,
                  font_array: ["0010.png","0011.png","0012.png","0013.png","0014.png","0015.png","0016.png","0017.png","0018.png","0019.png"],
                  padding: false,
                  h_space: -1,
                  align_h: hmUI.align.CENTER_H,
                  type: hmUI.data_type.BATTERY,
                  show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_AOD,
                });
                break;

              case hmUI.edit_type.STEP:
                hmUI.createWidget(hmUI.widget.IMG, {
                  x: 68,
                  y: 174,
                  src: '0052.png',
                  show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_AOD,
                });

                // editableZone_2_step_circle_scale = hmUI.createWidget(hmUI.widget.Circle_Scale, {
                  // center_x: 129,
                  // center_y: 234,
                  // start_angle: -150,
                  // end_angle: 150,
                  // radius: 57,
                  // line_width: 8,
                  // color: 0xFF00FFFF,
                  // mirror: False,
                  // inversion: False,
                  // type: hmUI.data_type.STEP,
                  // show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_AOD,
                // });

                if (screenType == hmSetting.screen_type.WATCHFACE || screenType == hmSetting.screen_type.AOD) {
                  editableZone_2_step_circle_scale = hmUI.createWidget(hmUI.widget.ARC);
                };
                break;

              case hmUI.edit_type.CAL:
                hmUI.createWidget(hmUI.widget.IMG, {
                  x: 68,
                  y: 174,
                  src: '0054.png',
                  show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_AOD,
                });

                // editableZone_2_cal_circle_scale = hmUI.createWidget(hmUI.widget.Circle_Scale, {
                  // center_x: 129,
                  // center_y: 234,
                  // start_angle: -150,
                  // end_angle: 150,
                  // radius: 57,
                  // line_width: 8,
                  // color: 0xFFFF8C00,
                  // mirror: False,
                  // inversion: False,
                  // type: hmUI.data_type.CAL,
                  // show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_AOD,
                // });

                if (screenType == hmSetting.screen_type.WATCHFACE || screenType == hmSetting.screen_type.AOD) {
                  editableZone_2_calorie_circle_scale = hmUI.createWidget(hmUI.widget.ARC);
                };
                calorie.addEventListener(hmSensor.event.CHANGE, function() {
                  scale_call();
                });

                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                  x: 83,
                  y: 211,
                  font_array: ["0010.png","0011.png","0012.png","0013.png","0014.png","0015.png","0016.png","0017.png","0018.png","0019.png"],
                  padding: false,
                  h_space: -1,
                  align_h: hmUI.align.CENTER_H,
                  type: hmUI.data_type.CAL,
                  show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_AOD,
                });
                break;

              case hmUI.edit_type.HEART:
                hmUI.createWidget(hmUI.widget.IMG, {
                  x: 68,
                  y: 174,
                  src: '0050.png',
                  show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_AOD,
                });

                // editableZone_2_heart_circle_scale = hmUI.createWidget(hmUI.widget.Circle_Scale, {
                  // center_x: 129,
                  // center_y: 234,
                  // start_angle: -150,
                  // end_angle: 150,
                  // radius: 57,
                  // line_width: 8,
                  // color: 0xFFFF0D13,
                  // mirror: False,
                  // inversion: False,
                  // type: hmUI.data_type.HEART,
                  // show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_AOD,
                // });

                if (screenType == hmSetting.screen_type.WATCHFACE || screenType == hmSetting.screen_type.AOD) {
                  editableZone_2_heart_rate_circle_scale = hmUI.createWidget(hmUI.widget.ARC);
                };

                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                  x: 96,
                  y: 211,
                  font_array: ["0010.png","0011.png","0012.png","0013.png","0014.png","0015.png","0016.png","0017.png","0018.png","0019.png"],
                  padding: false,
                  h_space: -1,
                  align_h: hmUI.align.CENTER_H,
                  type: hmUI.data_type.HEART,
                  show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_AOD,
                });
                break;
            }; // end switch

            
            
            
            
            editGroup_3 = hmUI.createWidget(hmUI.widget.WATCHFACE_EDIT_GROUP, {
              edit_id: 10023,
              x: 276,
              y: 174,
              w: 122,
              h: 122,
              select_image: '0045.png',
              un_select_image: '0046.png',
              default_type: hmUI.edit_type.WEEK,
              optional_types: [
                { type: hmUI.edit_type.WEEK, preview: '0051.png' },
                { type: hmUI.edit_type.BATTERY, preview: '0048.png' },
                { type: hmUI.edit_type.HEART, preview: '0049.png' },
                { type: hmUI.edit_type.STEP, preview: '0053.png' },
                { type: hmUI.edit_type.CAL, preview: '0055.png' },
              ],
              count: 5,
              tips_BG: '0006.png',
              tips_x: -174,
              tips_y: -83,
              tips_width: 261,
              tips_margin: 0,
            });

            const editType_3 = editGroup_3.getProperty(hmUI.prop.CURRENT_TYPE);

            switch (editType_3) {
              case hmUI.edit_type.WEEK:
                hmUI.createWidget(hmUI.widget.IMG_WEEK, {
                  x: 289,
                  y: 198,
                  week_en: ["0035.png","0036.png","0037.png","0038.png","0039.png","0040.png","0041.png"],
                  week_tc: ["0035.png","0036.png","0037.png","0038.png","0039.png","0040.png","0041.png"],
                  week_sc: ["0035.png","0036.png","0037.png","0038.png","0039.png","0040.png","0041.png"],
                  show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_AOD,
                });
                break;

              case hmUI.edit_type.BATTERY:
                hmUI.createWidget(hmUI.widget.IMG, {
                  x: 275,
                  y: 174,
                  src: '0047.png',
                  show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_AOD,
                });

                // editableZone_3_battery_circle_scale = hmUI.createWidget(hmUI.widget.Circle_Scale, {
                  // center_x: 336,
                  // center_y: 234,
                  // start_angle: -150,
                  // end_angle: 150,
                  // radius: 57,
                  // line_width: 8,
                  // color: 0xFF4EB176,
                  // mirror: False,
                  // inversion: False,
                  // type: hmUI.data_type.BATTERY,
                  // show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_AOD,
                // });

                if (screenType == hmSetting.screen_type.WATCHFACE || screenType == hmSetting.screen_type.AOD) {
                  editableZone_3_battery_circle_scale = hmUI.createWidget(hmUI.widget.ARC);
                };

                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                  x: 315,
                  y: 211,
                  font_array: ["0010.png","0011.png","0012.png","0013.png","0014.png","0015.png","0016.png","0017.png","0018.png","0019.png"],
                  padding: false,
                  h_space: -1,
                  align_h: hmUI.align.LEFT,
                  type: hmUI.data_type.BATTERY,
                  show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_AOD,
                });
                break;

              case hmUI.edit_type.STEP:
                hmUI.createWidget(hmUI.widget.IMG, {
                  x: 275,
                  y: 174,
                  src: '0052.png',
                  show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_AOD,
                });

                // editableZone_3_step_circle_scale = hmUI.createWidget(hmUI.widget.Circle_Scale, {
                  // center_x: 336,
                  // center_y: 234,
                  // start_angle: -150,
                  // end_angle: 150,
                  // radius: 57,
                  // line_width: 8,
                  // color: 0xFF00FFFF,
                  // mirror: False,
                  // inversion: False,
                  // type: hmUI.data_type.STEP,
                  // show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_AOD,
                // });

                if (screenType == hmSetting.screen_type.WATCHFACE || screenType == hmSetting.screen_type.AOD) {
                  editableZone_3_step_circle_scale = hmUI.createWidget(hmUI.widget.ARC);
                };
                break;

              case hmUI.edit_type.CAL:
                hmUI.createWidget(hmUI.widget.IMG, {
                  x: 275,
                  y: 174,
                  src: '0054.png',
                  show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_AOD,
                });

                // editableZone_3_cal_circle_scale = hmUI.createWidget(hmUI.widget.Circle_Scale, {
                  // center_x: 336,
                  // center_y: 234,
                  // start_angle: -150,
                  // end_angle: 150,
                  // radius: 57,
                  // line_width: 8,
                  // color: 0xFFFF8C00,
                  // mirror: False,
                  // inversion: False,
                  // type: hmUI.data_type.CAL,
                  // show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_AOD,
                // });

                if (screenType == hmSetting.screen_type.WATCHFACE || screenType == hmSetting.screen_type.AOD) {
                  editableZone_3_calorie_circle_scale = hmUI.createWidget(hmUI.widget.ARC);
                };

                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                  x: 291,
                  y: 211,
                  font_array: ["0010.png","0011.png","0012.png","0013.png","0014.png","0015.png","0016.png","0017.png","0018.png","0019.png"],
                  padding: false,
                  h_space: -1,
                  align_h: hmUI.align.CENTER_H,
                  type: hmUI.data_type.CAL,
                  show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_AOD,
                });
                break;

              case hmUI.edit_type.HEART:
                hmUI.createWidget(hmUI.widget.IMG, {
                  x: 275,
                  y: 174,
                  src: '0050.png',
                  show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_AOD,
                });

                // editableZone_3_heart_circle_scale = hmUI.createWidget(hmUI.widget.Circle_Scale, {
                  // center_x: 336,
                  // center_y: 234,
                  // start_angle: -150,
                  // end_angle: 150,
                  // radius: 57,
                  // line_width: 8,
                  // color: 0xFFFF0D13,
                  // mirror: False,
                  // inversion: False,
                  // type: hmUI.data_type.HEART,
                  // show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_AOD,
                // });

                if (screenType == hmSetting.screen_type.WATCHFACE || screenType == hmSetting.screen_type.AOD) {
                  editableZone_3_heart_rate_circle_scale = hmUI.createWidget(hmUI.widget.ARC);
                };

                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                  x: 304,
                  y: 211,
                  font_array: ["0010.png","0011.png","0012.png","0013.png","0014.png","0015.png","0016.png","0017.png","0018.png","0019.png"],
                  padding: false,
                  h_space: -1,
                  align_h: hmUI.align.CENTER_H,
                  type: hmUI.data_type.HEART,
                  show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_AOD,
                });
                break;
            }; // end switch

            mask = hmUI.createWidget(hmUI.widget.WATCHFACE_EDIT_MASK, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: '0020.png',
              show_level: hmUI.show_level.ONLY_EDIT,
            });

            fg_mask = hmUI.createWidget(hmUI.widget.WATCHFACE_EDIT_FG_MASK, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: '0021.png',
              show_level: hmUI.show_level.ONLY_EDIT,
            });

            const pointerEdit = hmUI.createWidget(hmUI.widget.WATCHFACE_EDIT_POINTER, {
              edit_id: 1003,
              x: 0,
              y: 0,
              config: [
                {
                  id: 1,
                  second: {
                    centerX: 233,
                    centerY: 233,
                    posX: 31,
                    posY: 214,
                    path: '0005.png',
                  },
                  hour: {
                    centerX: 233,
                    centerY: 233,
                    posX: 33,
                    posY: 135,
                    path: '0003.png',
                  },
                  minute: {
                    centerX: 233,
                    centerY: 233,
                    posX: 39,
                    posY: 224,
                    path: '0004.png',
                  },
                  preview: '0032.png',
                },
                {
                  id: 2,
                  second: {
                    centerX: 233,
                    centerY: 233,
                    posX: 31,
                    posY: 214,
                    path: '0031.png',
                  },
                  hour: {
                    centerX: 233,
                    centerY: 233,
                    posX: 33,
                    posY: 135,
                    path: '0029.png',
                  },
                  minute: {
                    centerX: 233,
                    centerY: 233,
                    posX: 39,
                    posY: 224,
                    path: '0030.png',
                  },
                  preview: '0033.png',
                },
              ],
              count: 2,
              default_id: 1,
              fg: '.png',
              tips_x: 0,
              tips_y: 0,
              tips_bg: '.png',
            });
            const pointerProp = pointerEdit.getProperty(hmUI.prop.CURRENT_CONFIG, true);
            editableTimePointers = hmUI.createWidget(hmUI.widget.TIME_POINTER, pointerProp);

            function scale_call() {

                console.log('update editable circle_scale BATTERY');
                
                let valueBattery = battery.current;
                let targetBattery = 100;
                let progressBattery = valueBattery/targetBattery;
                if (progressBattery > 1) progressBattery = 1;
                let progress_cs_editableZone_1_battery = progressBattery;

                if (editableZone_1_battery_circle_scale) {

                  // editableZone_1_battery_circle_scale
                  // initial parameters
                  let start_angle_editableZone_1_battery = -240;
                  let end_angle_editableZone_1_battery = 60;
                  let center_x_editableZone_1_battery = 233;
                  let center_y_editableZone_1_battery = 336;
                  let radius_editableZone_1_battery = 50;
                  let line_width_cs_editableZone_1_battery = 7;
                  let color_cs_editableZone_1_battery = 0xFF4EB176;
                  
                  // calculated parameters
                  let arcX_editableZone_1_battery = center_x_editableZone_1_battery - radius_editableZone_1_battery;
                  let arcY_editableZone_1_battery = center_y_editableZone_1_battery - radius_editableZone_1_battery;
                  let CircleWidth_editableZone_1_battery = 2 * radius_editableZone_1_battery;
                  let angle_offset_editableZone_1_battery = end_angle_editableZone_1_battery - start_angle_editableZone_1_battery;
                  angle_offset_editableZone_1_battery = angle_offset_editableZone_1_battery * progress_cs_editableZone_1_battery;
                  let end_angle_editableZone_1_battery_draw = start_angle_editableZone_1_battery + angle_offset_editableZone_1_battery;
                  
                  editableZone_1_battery_circle_scale.setProperty(hmUI.prop.MORE, {
                    x: arcX_editableZone_1_battery,
                    y: arcY_editableZone_1_battery,
                    w: CircleWidth_editableZone_1_battery,
                    h: CircleWidth_editableZone_1_battery,
                    start_angle: start_angle_editableZone_1_battery,
                    end_angle: end_angle_editableZone_1_battery_draw,
                    color: color_cs_editableZone_1_battery,
                    line_width: line_width_cs_editableZone_1_battery,
                  });
                };

                console.log('update editable circle_scale HEART');
                
                let valueHeartRate = heart_rate.last;
                let targetHeartRate = 179;
                let progressHeartRate = (valueHeartRate - 71)/(targetHeartRate - 71);
                if (progressHeartRate < 0) progressHeartRate = 0;
                if (progressHeartRate > 1) progressHeartRate = 1;
                let progress_cs_editableZone_1_heart_rate = progressHeartRate;

                if (editableZone_1_heart_rate_circle_scale) {

                  // editableZone_1_heart_rate_circle_scale
                  // initial parameters
                  let start_angle_editableZone_1_heart_rate = -240;
                  let end_angle_editableZone_1_heart_rate = 60;
                  let center_x_editableZone_1_heart_rate = 233;
                  let center_y_editableZone_1_heart_rate = 336;
                  let radius_editableZone_1_heart_rate = 50;
                  let line_width_cs_editableZone_1_heart_rate = 7;
                  let color_cs_editableZone_1_heart_rate = 0xFFFF0D13;
                  
                  // calculated parameters
                  let arcX_editableZone_1_heart_rate = center_x_editableZone_1_heart_rate - radius_editableZone_1_heart_rate;
                  let arcY_editableZone_1_heart_rate = center_y_editableZone_1_heart_rate - radius_editableZone_1_heart_rate;
                  let CircleWidth_editableZone_1_heart_rate = 2 * radius_editableZone_1_heart_rate;
                  let angle_offset_editableZone_1_heart_rate = end_angle_editableZone_1_heart_rate - start_angle_editableZone_1_heart_rate;
                  angle_offset_editableZone_1_heart_rate = angle_offset_editableZone_1_heart_rate * progress_cs_editableZone_1_heart_rate;
                  let end_angle_editableZone_1_heart_rate_draw = start_angle_editableZone_1_heart_rate + angle_offset_editableZone_1_heart_rate;
                  
                  editableZone_1_heart_rate_circle_scale.setProperty(hmUI.prop.MORE, {
                    x: arcX_editableZone_1_heart_rate,
                    y: arcY_editableZone_1_heart_rate,
                    w: CircleWidth_editableZone_1_heart_rate,
                    h: CircleWidth_editableZone_1_heart_rate,
                    start_angle: start_angle_editableZone_1_heart_rate,
                    end_angle: end_angle_editableZone_1_heart_rate_draw,
                    color: color_cs_editableZone_1_heart_rate,
                    line_width: line_width_cs_editableZone_1_heart_rate,
                  });
                };

                console.log('update editable circle_scale STEP');
                
                let valueStep = step.current;
                let targetStep = step.target;
                let progressStep = valueStep/targetStep;
                if (progressStep > 1) progressStep = 1;
                let progress_cs_editableZone_1_step = progressStep;

                if (editableZone_1_step_circle_scale) {

                  // editableZone_1_step_circle_scale
                  // initial parameters
                  let start_angle_editableZone_1_step = -240;
                  let end_angle_editableZone_1_step = 60;
                  let center_x_editableZone_1_step = 233;
                  let center_y_editableZone_1_step = 336;
                  let radius_editableZone_1_step = 50;
                  let line_width_cs_editableZone_1_step = 7;
                  let color_cs_editableZone_1_step = 0xFF00FFFF;
                  
                  // calculated parameters
                  let arcX_editableZone_1_step = center_x_editableZone_1_step - radius_editableZone_1_step;
                  let arcY_editableZone_1_step = center_y_editableZone_1_step - radius_editableZone_1_step;
                  let CircleWidth_editableZone_1_step = 2 * radius_editableZone_1_step;
                  let angle_offset_editableZone_1_step = end_angle_editableZone_1_step - start_angle_editableZone_1_step;
                  angle_offset_editableZone_1_step = angle_offset_editableZone_1_step * progress_cs_editableZone_1_step;
                  let end_angle_editableZone_1_step_draw = start_angle_editableZone_1_step + angle_offset_editableZone_1_step;
                  
                  editableZone_1_step_circle_scale.setProperty(hmUI.prop.MORE, {
                    x: arcX_editableZone_1_step,
                    y: arcY_editableZone_1_step,
                    w: CircleWidth_editableZone_1_step,
                    h: CircleWidth_editableZone_1_step,
                    start_angle: start_angle_editableZone_1_step,
                    end_angle: end_angle_editableZone_1_step_draw,
                    color: color_cs_editableZone_1_step,
                    line_width: line_width_cs_editableZone_1_step,
                  });
                };

                console.log('update editable circle_scale HEART');
                let progress_cs_editableZone_2_heart_rate = progressHeartRate;

                if (editableZone_2_heart_rate_circle_scale) {

                  // editableZone_2_heart_rate_circle_scale
                  // initial parameters
                  let start_angle_editableZone_2_heart_rate = -240;
                  let end_angle_editableZone_2_heart_rate = 60;
                  let center_x_editableZone_2_heart_rate = 129;
                  let center_y_editableZone_2_heart_rate = 234;
                  let radius_editableZone_2_heart_rate = 57;
                  let line_width_cs_editableZone_2_heart_rate = 8;
                  let color_cs_editableZone_2_heart_rate = 0xFFFF0D13;
                  
                  // calculated parameters
                  let arcX_editableZone_2_heart_rate = center_x_editableZone_2_heart_rate - radius_editableZone_2_heart_rate;
                  let arcY_editableZone_2_heart_rate = center_y_editableZone_2_heart_rate - radius_editableZone_2_heart_rate;
                  let CircleWidth_editableZone_2_heart_rate = 2 * radius_editableZone_2_heart_rate;
                  let angle_offset_editableZone_2_heart_rate = end_angle_editableZone_2_heart_rate - start_angle_editableZone_2_heart_rate;
                  angle_offset_editableZone_2_heart_rate = angle_offset_editableZone_2_heart_rate * progress_cs_editableZone_2_heart_rate;
                  let end_angle_editableZone_2_heart_rate_draw = start_angle_editableZone_2_heart_rate + angle_offset_editableZone_2_heart_rate;
                  
                  editableZone_2_heart_rate_circle_scale.setProperty(hmUI.prop.MORE, {
                    x: arcX_editableZone_2_heart_rate,
                    y: arcY_editableZone_2_heart_rate,
                    w: CircleWidth_editableZone_2_heart_rate,
                    h: CircleWidth_editableZone_2_heart_rate,
                    start_angle: start_angle_editableZone_2_heart_rate,
                    end_angle: end_angle_editableZone_2_heart_rate_draw,
                    color: color_cs_editableZone_2_heart_rate,
                    line_width: line_width_cs_editableZone_2_heart_rate,
                  });
                };

                console.log('update editable circle_scale STEP');
                let progress_cs_editableZone_2_step = progressStep;

                if (editableZone_2_step_circle_scale) {

                  // editableZone_2_step_circle_scale
                  // initial parameters
                  let start_angle_editableZone_2_step = -240;
                  let end_angle_editableZone_2_step = 60;
                  let center_x_editableZone_2_step = 129;
                  let center_y_editableZone_2_step = 234;
                  let radius_editableZone_2_step = 57;
                  let line_width_cs_editableZone_2_step = 8;
                  let color_cs_editableZone_2_step = 0xFF00FFFF;
                  
                  // calculated parameters
                  let arcX_editableZone_2_step = center_x_editableZone_2_step - radius_editableZone_2_step;
                  let arcY_editableZone_2_step = center_y_editableZone_2_step - radius_editableZone_2_step;
                  let CircleWidth_editableZone_2_step = 2 * radius_editableZone_2_step;
                  let angle_offset_editableZone_2_step = end_angle_editableZone_2_step - start_angle_editableZone_2_step;
                  angle_offset_editableZone_2_step = angle_offset_editableZone_2_step * progress_cs_editableZone_2_step;
                  let end_angle_editableZone_2_step_draw = start_angle_editableZone_2_step + angle_offset_editableZone_2_step;
                  
                  editableZone_2_step_circle_scale.setProperty(hmUI.prop.MORE, {
                    x: arcX_editableZone_2_step,
                    y: arcY_editableZone_2_step,
                    w: CircleWidth_editableZone_2_step,
                    h: CircleWidth_editableZone_2_step,
                    start_angle: start_angle_editableZone_2_step,
                    end_angle: end_angle_editableZone_2_step_draw,
                    color: color_cs_editableZone_2_step,
                    line_width: line_width_cs_editableZone_2_step,
                  });
                };

                console.log('update editable circle_scale BATTERY');
                let progress_cs_editableZone_2_battery = progressBattery;

                if (editableZone_2_battery_circle_scale) {

                  // editableZone_2_battery_circle_scale
                  // initial parameters
                  let start_angle_editableZone_2_battery = -240;
                  let end_angle_editableZone_2_battery = 60;
                  let center_x_editableZone_2_battery = 129;
                  let center_y_editableZone_2_battery = 234;
                  let radius_editableZone_2_battery = 57;
                  let line_width_cs_editableZone_2_battery = 8;
                  let color_cs_editableZone_2_battery = 0xFF4EB176;
                  
                  // calculated parameters
                  let arcX_editableZone_2_battery = center_x_editableZone_2_battery - radius_editableZone_2_battery;
                  let arcY_editableZone_2_battery = center_y_editableZone_2_battery - radius_editableZone_2_battery;
                  let CircleWidth_editableZone_2_battery = 2 * radius_editableZone_2_battery;
                  let angle_offset_editableZone_2_battery = end_angle_editableZone_2_battery - start_angle_editableZone_2_battery;
                  angle_offset_editableZone_2_battery = angle_offset_editableZone_2_battery * progress_cs_editableZone_2_battery;
                  let end_angle_editableZone_2_battery_draw = start_angle_editableZone_2_battery + angle_offset_editableZone_2_battery;
                  
                  editableZone_2_battery_circle_scale.setProperty(hmUI.prop.MORE, {
                    x: arcX_editableZone_2_battery,
                    y: arcY_editableZone_2_battery,
                    w: CircleWidth_editableZone_2_battery,
                    h: CircleWidth_editableZone_2_battery,
                    start_angle: start_angle_editableZone_2_battery,
                    end_angle: end_angle_editableZone_2_battery_draw,
                    color: color_cs_editableZone_2_battery,
                    line_width: line_width_cs_editableZone_2_battery,
                  });
                };

                console.log('update editable circle_scale CALORIE');
                
                let valueCalories = calorie.current;
                let targetCalories = calorie.target;
                let progressCalories = valueCalories/targetCalories;
                if (progressCalories > 1) progressCalories = 1;
                let progress_cs_editableZone_2_calorie = progressCalories;

                if (editableZone_2_calorie_circle_scale) {

                  // editableZone_2_calorie_circle_scale
                  // initial parameters
                  let start_angle_editableZone_2_calorie = -240;
                  let end_angle_editableZone_2_calorie = 60;
                  let center_x_editableZone_2_calorie = 129;
                  let center_y_editableZone_2_calorie = 234;
                  let radius_editableZone_2_calorie = 57;
                  let line_width_cs_editableZone_2_calorie = 8;
                  let color_cs_editableZone_2_calorie = 0xFFFF8C00;
                  
                  // calculated parameters
                  let arcX_editableZone_2_calorie = center_x_editableZone_2_calorie - radius_editableZone_2_calorie;
                  let arcY_editableZone_2_calorie = center_y_editableZone_2_calorie - radius_editableZone_2_calorie;
                  let CircleWidth_editableZone_2_calorie = 2 * radius_editableZone_2_calorie;
                  let angle_offset_editableZone_2_calorie = end_angle_editableZone_2_calorie - start_angle_editableZone_2_calorie;
                  angle_offset_editableZone_2_calorie = angle_offset_editableZone_2_calorie * progress_cs_editableZone_2_calorie;
                  let end_angle_editableZone_2_calorie_draw = start_angle_editableZone_2_calorie + angle_offset_editableZone_2_calorie;
                  
                  editableZone_2_calorie_circle_scale.setProperty(hmUI.prop.MORE, {
                    x: arcX_editableZone_2_calorie,
                    y: arcY_editableZone_2_calorie,
                    w: CircleWidth_editableZone_2_calorie,
                    h: CircleWidth_editableZone_2_calorie,
                    start_angle: start_angle_editableZone_2_calorie,
                    end_angle: end_angle_editableZone_2_calorie_draw,
                    color: color_cs_editableZone_2_calorie,
                    line_width: line_width_cs_editableZone_2_calorie,
                  });
                };

                console.log('update editable circle_scale BATTERY');
                let progress_cs_editableZone_3_battery = progressBattery;

                if (editableZone_3_battery_circle_scale) {

                  // editableZone_3_battery_circle_scale
                  // initial parameters
                  let start_angle_editableZone_3_battery = -240;
                  let end_angle_editableZone_3_battery = 60;
                  let center_x_editableZone_3_battery = 336;
                  let center_y_editableZone_3_battery = 234;
                  let radius_editableZone_3_battery = 57;
                  let line_width_cs_editableZone_3_battery = 8;
                  let color_cs_editableZone_3_battery = 0xFF4EB176;
                  
                  // calculated parameters
                  let arcX_editableZone_3_battery = center_x_editableZone_3_battery - radius_editableZone_3_battery;
                  let arcY_editableZone_3_battery = center_y_editableZone_3_battery - radius_editableZone_3_battery;
                  let CircleWidth_editableZone_3_battery = 2 * radius_editableZone_3_battery;
                  let angle_offset_editableZone_3_battery = end_angle_editableZone_3_battery - start_angle_editableZone_3_battery;
                  angle_offset_editableZone_3_battery = angle_offset_editableZone_3_battery * progress_cs_editableZone_3_battery;
                  let end_angle_editableZone_3_battery_draw = start_angle_editableZone_3_battery + angle_offset_editableZone_3_battery;
                  
                  editableZone_3_battery_circle_scale.setProperty(hmUI.prop.MORE, {
                    x: arcX_editableZone_3_battery,
                    y: arcY_editableZone_3_battery,
                    w: CircleWidth_editableZone_3_battery,
                    h: CircleWidth_editableZone_3_battery,
                    start_angle: start_angle_editableZone_3_battery,
                    end_angle: end_angle_editableZone_3_battery_draw,
                    color: color_cs_editableZone_3_battery,
                    line_width: line_width_cs_editableZone_3_battery,
                  });
                };

                console.log('update editable circle_scale HEART');
                let progress_cs_editableZone_3_heart_rate = progressHeartRate;

                if (editableZone_3_heart_rate_circle_scale) {

                  // editableZone_3_heart_rate_circle_scale
                  // initial parameters
                  let start_angle_editableZone_3_heart_rate = -240;
                  let end_angle_editableZone_3_heart_rate = 60;
                  let center_x_editableZone_3_heart_rate = 336;
                  let center_y_editableZone_3_heart_rate = 234;
                  let radius_editableZone_3_heart_rate = 57;
                  let line_width_cs_editableZone_3_heart_rate = 8;
                  let color_cs_editableZone_3_heart_rate = 0xFFFF0D13;
                  
                  // calculated parameters
                  let arcX_editableZone_3_heart_rate = center_x_editableZone_3_heart_rate - radius_editableZone_3_heart_rate;
                  let arcY_editableZone_3_heart_rate = center_y_editableZone_3_heart_rate - radius_editableZone_3_heart_rate;
                  let CircleWidth_editableZone_3_heart_rate = 2 * radius_editableZone_3_heart_rate;
                  let angle_offset_editableZone_3_heart_rate = end_angle_editableZone_3_heart_rate - start_angle_editableZone_3_heart_rate;
                  angle_offset_editableZone_3_heart_rate = angle_offset_editableZone_3_heart_rate * progress_cs_editableZone_3_heart_rate;
                  let end_angle_editableZone_3_heart_rate_draw = start_angle_editableZone_3_heart_rate + angle_offset_editableZone_3_heart_rate;
                  
                  editableZone_3_heart_rate_circle_scale.setProperty(hmUI.prop.MORE, {
                    x: arcX_editableZone_3_heart_rate,
                    y: arcY_editableZone_3_heart_rate,
                    w: CircleWidth_editableZone_3_heart_rate,
                    h: CircleWidth_editableZone_3_heart_rate,
                    start_angle: start_angle_editableZone_3_heart_rate,
                    end_angle: end_angle_editableZone_3_heart_rate_draw,
                    color: color_cs_editableZone_3_heart_rate,
                    line_width: line_width_cs_editableZone_3_heart_rate,
                  });
                };

                console.log('update editable circle_scale STEP');
                let progress_cs_editableZone_3_step = progressStep;

                if (editableZone_3_step_circle_scale) {

                  // editableZone_3_step_circle_scale
                  // initial parameters
                  let start_angle_editableZone_3_step = -240;
                  let end_angle_editableZone_3_step = 60;
                  let center_x_editableZone_3_step = 336;
                  let center_y_editableZone_3_step = 234;
                  let radius_editableZone_3_step = 57;
                  let line_width_cs_editableZone_3_step = 8;
                  let color_cs_editableZone_3_step = 0xFF00FFFF;
                  
                  // calculated parameters
                  let arcX_editableZone_3_step = center_x_editableZone_3_step - radius_editableZone_3_step;
                  let arcY_editableZone_3_step = center_y_editableZone_3_step - radius_editableZone_3_step;
                  let CircleWidth_editableZone_3_step = 2 * radius_editableZone_3_step;
                  let angle_offset_editableZone_3_step = end_angle_editableZone_3_step - start_angle_editableZone_3_step;
                  angle_offset_editableZone_3_step = angle_offset_editableZone_3_step * progress_cs_editableZone_3_step;
                  let end_angle_editableZone_3_step_draw = start_angle_editableZone_3_step + angle_offset_editableZone_3_step;
                  
                  editableZone_3_step_circle_scale.setProperty(hmUI.prop.MORE, {
                    x: arcX_editableZone_3_step,
                    y: arcY_editableZone_3_step,
                    w: CircleWidth_editableZone_3_step,
                    h: CircleWidth_editableZone_3_step,
                    start_angle: start_angle_editableZone_3_step,
                    end_angle: end_angle_editableZone_3_step_draw,
                    color: color_cs_editableZone_3_step,
                    line_width: line_width_cs_editableZone_3_step,
                  });
                };

                console.log('update editable circle_scale CALORIE');
                let progress_cs_editableZone_3_calorie = progressCalories;

                if (editableZone_3_calorie_circle_scale) {

                  // editableZone_3_calorie_circle_scale
                  // initial parameters
                  let start_angle_editableZone_3_calorie = -240;
                  let end_angle_editableZone_3_calorie = 60;
                  let center_x_editableZone_3_calorie = 336;
                  let center_y_editableZone_3_calorie = 234;
                  let radius_editableZone_3_calorie = 57;
                  let line_width_cs_editableZone_3_calorie = 8;
                  let color_cs_editableZone_3_calorie = 0xFFFF8C00;
                  
                  // calculated parameters
                  let arcX_editableZone_3_calorie = center_x_editableZone_3_calorie - radius_editableZone_3_calorie;
                  let arcY_editableZone_3_calorie = center_y_editableZone_3_calorie - radius_editableZone_3_calorie;
                  let CircleWidth_editableZone_3_calorie = 2 * radius_editableZone_3_calorie;
                  let angle_offset_editableZone_3_calorie = end_angle_editableZone_3_calorie - start_angle_editableZone_3_calorie;
                  angle_offset_editableZone_3_calorie = angle_offset_editableZone_3_calorie * progress_cs_editableZone_3_calorie;
                  let end_angle_editableZone_3_calorie_draw = start_angle_editableZone_3_calorie + angle_offset_editableZone_3_calorie;
                  
                  editableZone_3_calorie_circle_scale.setProperty(hmUI.prop.MORE, {
                    x: arcX_editableZone_3_calorie,
                    y: arcY_editableZone_3_calorie,
                    w: CircleWidth_editableZone_3_calorie,
                    h: CircleWidth_editableZone_3_calorie,
                    start_angle: start_angle_editableZone_3_calorie,
                    end_angle: end_angle_editableZone_3_calorie_draw,
                    color: color_cs_editableZone_3_calorie,
                    line_width: line_width_cs_editableZone_3_calorie,
                  });
                };

            };

            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                scale_call();
              }),
              pause_call: (function () {
                if (heart_rate) heart_rate.removeEventListener(heart_rate.event.LAST, function () {});
                if (heart_rate) heart_rate.removeEventListener(heart_rate.event.LAST, function () {});
                if (heart_rate) heart_rate.removeEventListener(heart_rate.event.LAST, function () {});

              }),
            });

            //dynamic modify end
          },

          onInit() {
            console.log('index page.js on init invoke')

            this.init_view()

          },

          onReady() {
            console.log('index page.js on ready invoke')
          },

          onShow() {
            console.log('index page.js on show invoke')
          },

          onHide() {
            console.log('index page.js on hide invoke')
          },

          onDestory() {
            heart_rate.removeEventListener(heart.event.CURRENT, hrCurrListener);
            console.log('index page.js on destory invoke')
          },
        });

      })()
    } catch (e) {
      console.log(e)
    }
  