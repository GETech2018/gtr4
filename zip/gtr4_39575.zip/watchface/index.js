﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        const logger = Logger.getLogger('watchface_SashaCX75');
        //end of ignored block

        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_system_clock_img = ''
        let normal_system_disconnect_img = ''
        let normal_system_lock_img = ''
        let normal_system_dnd_img = ''
        let normal_step_current_text_img = ''
        let normal_step_icon_img = ''
        let normal_sun_current_text_img = ''
        let normal_sun_current_separator_img = ''
        let normal_battery_image_progress_img_level = ''
        let normal_moon_image_progress_img_level = ''
        let normal_date_img_date_month_img = ''
        let normal_date_img_date_day = ''
        let normal_date_img_date_week_img = ''
        let normal_weather_image_progress_img_level = ''
        let normal_temperature_current_text_img = ''
        let normal_digital_clock_img_time_AmPm = ''
        let normal_digital_clock_img_time = ''
        let normal_analog_clock_time_pointer_hour = ''
        let normal_analog_clock_time_pointer_minute = ''
        let normal_analog_clock_time_pointer_second = ''
        let idle_moon_image_progress_img_level = ''
        let idle_date_img_date_month_img = ''
        let idle_date_img_date_day = ''
        let idle_date_img_date_week_img = ''
        let idle_digital_clock_img_time_AmPm = ''
        let idle_digital_clock_img_time = ''
        let idle_analog_clock_time_pointer_hour = ''
        let idle_analog_clock_time_pointer_minute = ''
        let normal_alarm_jumpable_img_click = ''
        let normal_sunrise_jumpable_img_click = ''
        let normal_heart_jumpable_img_click = ''
        let normal_step_jumpable_img_click = ''


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            console.log('Watch_Face.ScreenNormal');
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 466,
              h: 466,
              src: 'dail.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 128,
              y: 308,
              src: 'alarm.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 328,
              y: 308,
              src: 'bluetooth.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_lock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 328,
              y: 349,
              src: 'Lock.png',
              type: hmUI.system_status.LOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_dnd_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 128,
              y: 349,
              src: 'DND 1.png',
              type: hmUI.system_status.DISTURB,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 55,
              y: 234,
              font_array: ["MarineRed0052.png","MarineRed0053.png","MarineRed0054.png","MarineRed0055.png","MarineRed0056.png","MarineRed0057.png","MarineRed0058.png","MarineRed0059.png","MarineRed0060.png","MarineRed0061.png"],
              padding: true,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 66,
              y: 260,
              src: 'Steps.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sun_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 55,
              y: 205,
              font_array: ["MarineRed0052.png","MarineRed0053.png","MarineRed0054.png","MarineRed0055.png","MarineRed0056.png","MarineRed0057.png","MarineRed0058.png","MarineRed0059.png","MarineRed0060.png","MarineRed0061.png"],
              padding: false,
              h_space: 0,
              invalid_image: '30PT20014.png',
              dot_image: 'sssr_column.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.SUN_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sun_current_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 66,
              y: 170,
              src: '0011.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 350,
              y: 255,
              image_array: ["batterylevel0001.png","batterylevel0002.png","batterylevel0003.png","batterylevel0004.png","batterylevel0005.png","batterylevel0006.png","batterylevel0007.png","batterylevel0008.png","batterylevel0009.png","batterylevel0010.png"],
              image_length: 10,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_moon_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 163,
              y: 290,
              image_array: ["moon0001.png","moon0002.png","moon0003.png","moon0004.png","moon0005.png","moon0006.png","moon0007.png","moon0008.png","moon0009.png","moon0010.png","moon0011.png","moon0012.png","moon0013.png","moon0014.png","moon0015.png","moon0016.png","moon0017.png","moon0018.png","moon0019.png","moon0020.png","moon0021.png","moon0022.png","moon0023.png","moon0024.png","moon0025.png","moon0026.png","moon0027.png","moon0028.png","moon0029.png","moon0030.png"],
              image_length: 30,
              type: hmUI.data_type.MOON,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_month_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 320,
              month_startY: 225,
              month_sc_array: ["month_01.png","month_02.png","month_03.png","month_04.png","month_05.png","month_06.png","month_07.png","month_08.png","month_09.png","month_10.png","month_11.png","month_12.png"],
              month_tc_array: ["month_01.png","month_02.png","month_03.png","month_04.png","month_05.png","month_06.png","month_07.png","month_08.png","month_09.png","month_10.png","month_11.png","month_12.png"],
              month_en_array: ["month_01.png","month_02.png","month_03.png","month_04.png","month_05.png","month_06.png","month_07.png","month_08.png","month_09.png","month_10.png","month_11.png","month_12.png"],
              month_is_character: true ,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 380,
              day_startY: 225,
              day_sc_array: ["0037.png","0038.png","0039.png","0040.png","0041.png","0042.png","0043.png","0044.png","0045.png","0046.png"],
              day_tc_array: ["0037.png","0038.png","0039.png","0040.png","0041.png","0042.png","0043.png","0044.png","0045.png","0046.png"],
              day_en_array: ["0037.png","0038.png","0039.png","0040.png","0041.png","0042.png","0043.png","0044.png","0045.png","0046.png"],
              day_zero: 1,
              day_space: 0,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 329,
              y: 200,
              week_en: ["week_1.png","week_2.png","week_3.png","week_4.png","week_5.png","week_6.png","week_7.png"],
              week_tc: ["week_1.png","week_2.png","week_3.png","week_4.png","week_5.png","week_6.png","week_7.png"],
              week_sc: ["week_1.png","week_2.png","week_3.png","week_4.png","week_5.png","week_6.png","week_7.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 215,
              y: 119,
              image_array: ["Weather01.png","Weather02.png","Weather03.png","Weather04.png","Weather05.png","Weather06.png","Weather07.png","Weather08.png","Weather09.png","Weather10.png","Weather11.png","Weather12.png","Weather13.png","Weather14.png","Weather15.png","Weather16.png","Weather17.png","Weather18.png","Weather19.png","Weather20.png","Weather21.png","Weather22.png","Weather23.png","Weather24.png","Weather25.png","Weather26.png","Weather27.png","Weather28.png","Weather29.png"],
              image_length: 29,
              shortcut: true,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 207,
              y: 161,
              font_array: ["MarineRed0035.png","MarineRed0036.png","MarineRed0037.png","MarineRed0038.png","MarineRed0039.png","MarineRed0040.png","MarineRed0041.png","MarineRed0042.png","MarineRed0043.png","MarineRed0044.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'small_10.png',
              unit_tc: 'small_10.png',
              unit_en: 'small_10.png',
              negative_image: 'Minus.png',
              invalid_image: 'small_10.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time_AmPm = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              am_x: 218,
              am_y: 69,
              am_sc_path: 'MarineRed0014.png',
              am_en_path: 'MarineRed0014.png',
              pm_x: 218,
              pm_y: 69,
              pm_sc_path: 'MarineRed0015.png',
              pm_en_path: 'MarineRed0015.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 186,
              hour_startY: 88,
              hour_array: ["0014.png","0015.png","0016.png","0017.png","0018.png","0019.png","0020.png","0021.png","0022.png","0023.png"],
              hour_zero: 1,
              hour_space: 0,
              hour_angle: 0,
              hour_unit_sc: '0061.png',
              hour_unit_tc: '0061.png',
              hour_unit_en: '0061.png',
              hour_align: hmUI.align.CENTER_H,

              minute_startX: 241,
              minute_startY: 87,
              minute_array: ["0014.png","0015.png","0016.png","0017.png","0018.png","0019.png","0020.png","0021.png","0022.png","0023.png"],
              minute_zero: 1,
              minute_space: 0,
              minute_angle: 0,
              minute_follow: 1,
              minute_align: hmUI.align.CENTER_H,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_hour = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              hour_path: 'Hand_H1.png',
              hour_centerX: 233,
              hour_centerY: 233,
              hour_posX: 24,
              hour_posY: 230,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_minute = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              minute_path: 'Hand_M1.png',
              minute_centerX: 233,
              minute_centerY: 233,
              minute_posX: 25,
              minute_posY: 230,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_second = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              second_path: 'Hand_S9.png',
              second_centerX: 233,
              second_centerY: 233,
              second_posX: 25,
              second_posY: 230,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            console.log('Watch_Face.ScreenAOD');

            idle_moon_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 163,
              y: 290,
              image_array: ["moon0001.png","moon0002.png","moon0003.png","moon0004.png","moon0005.png","moon0006.png","moon0007.png","moon0008.png","moon0009.png","moon0010.png","moon0011.png","moon0012.png","moon0013.png","moon0014.png","moon0015.png","moon0016.png","moon0017.png","moon0018.png","moon0019.png","moon0020.png","moon0021.png","moon0022.png","moon0023.png","moon0024.png","moon0025.png","moon0026.png","moon0027.png","moon0028.png","moon0029.png","moon0030.png"],
              image_length: 30,
              type: hmUI.data_type.MOON,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_month_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 320,
              month_startY: 225,
              month_sc_array: ["month_01.png","month_02.png","month_03.png","month_04.png","month_05.png","month_06.png","month_07.png","month_08.png","month_09.png","month_10.png","month_11.png","month_12.png"],
              month_tc_array: ["month_01.png","month_02.png","month_03.png","month_04.png","month_05.png","month_06.png","month_07.png","month_08.png","month_09.png","month_10.png","month_11.png","month_12.png"],
              month_en_array: ["month_01.png","month_02.png","month_03.png","month_04.png","month_05.png","month_06.png","month_07.png","month_08.png","month_09.png","month_10.png","month_11.png","month_12.png"],
              month_is_character: true ,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 380,
              day_startY: 225,
              day_sc_array: ["0037.png","0038.png","0039.png","0040.png","0041.png","0042.png","0043.png","0044.png","0045.png","0046.png"],
              day_tc_array: ["0037.png","0038.png","0039.png","0040.png","0041.png","0042.png","0043.png","0044.png","0045.png","0046.png"],
              day_en_array: ["0037.png","0038.png","0039.png","0040.png","0041.png","0042.png","0043.png","0044.png","0045.png","0046.png"],
              day_zero: 1,
              day_space: 0,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 329,
              y: 200,
              week_en: ["week_1.png","week_2.png","week_3.png","week_4.png","week_5.png","week_6.png","week_7.png"],
              week_tc: ["week_1.png","week_2.png","week_3.png","week_4.png","week_5.png","week_6.png","week_7.png"],
              week_sc: ["week_1.png","week_2.png","week_3.png","week_4.png","week_5.png","week_6.png","week_7.png"],
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time_AmPm = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              am_x: 218,
              am_y: 69,
              am_sc_path: 'MarineRed0014.png',
              am_en_path: 'MarineRed0014.png',
              pm_x: 218,
              pm_y: 69,
              pm_sc_path: 'MarineRed0015.png',
              pm_en_path: 'MarineRed0015.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 186,
              hour_startY: 88,
              hour_array: ["0014.png","0015.png","0016.png","0017.png","0018.png","0019.png","0020.png","0021.png","0022.png","0023.png"],
              hour_zero: 1,
              hour_space: 0,
              hour_angle: 0,
              hour_unit_sc: '0061.png',
              hour_unit_tc: '0061.png',
              hour_unit_en: '0061.png',
              hour_align: hmUI.align.CENTER_H,

              minute_startX: 241,
              minute_startY: 87,
              minute_array: ["0014.png","0015.png","0016.png","0017.png","0018.png","0019.png","0020.png","0021.png","0022.png","0023.png"],
              minute_zero: 1,
              minute_space: 0,
              minute_angle: 0,
              minute_follow: 1,
              minute_align: hmUI.align.CENTER_H,

              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_analog_clock_time_pointer_hour = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              hour_path: 'Hand_H1.png',
              hour_centerX: 233,
              hour_centerY: 233,
              hour_posX: 24,
              hour_posY: 230,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_analog_clock_time_pointer_minute = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              minute_path: 'Hand_M1.png',
              minute_centerX: 233,
              minute_centerY: 233,
              minute_posX: 25,
              minute_posY: 230,
              show_level: hmUI.show_level.ONLY_AOD,
            });
            console.log('Watch_Face.Shortcuts');

            normal_alarm_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 143,
              y: 99,
              w: 31,
              h: 29,
              src: 'Shortcut.png',
              type: hmUI.data_type.ALARM_CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sunrise_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 94,
              y: 101,
              w: 38,
              h: 59,
              src: 'Shortcut.png',
              type: hmUI.data_type.SUN_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 114,
              y: 315,
              w: 40,
              h: 41,
              src: 'Shortcut.png',
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 93,
              y: 198,
              w: 40,
              h: 33,
              src: 'Shortcut.png',
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}