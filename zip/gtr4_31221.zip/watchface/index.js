﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.0.1
    ** Copyright © CashaCX75. All Rights Reserved
    */

    try {
    (()=>{
        //dynamic modify start

        
        let normal_background_bg = ''
        let normal_frame_animation_1 = ''
        let normal_system_dnd_img = ''
        let normal_system_disconnect_img = ''
        let normal_system_clock_img = ''
        let normal_battery_text_text_img = ''
        let normal_battery_text_separator_img = ''
        let normal_step_current_text_img = ''
        let normal_step_current_separator_img = ''
        let normal_date_img_date_day = ''
        let normal_date_img_date_week_img = ''
        let normal_analog_clock_time_pointer_hour = ''
        let normal_analog_clock_time_pointer_minute = ''
        let normal_analog_clock_time_pointer_second = ''
        let idle_battery_text_text_img = ''
        let idle_battery_text_separator_img = ''
        let idle_analog_clock_time_pointer_hour = ''
        let idle_analog_clock_time_pointer_minute = ''
        let normal_alarm_jumpable_img_click = ''
        let normal_step_jumpable_img_click = ''


        //dynamic modify end
        const e = __$$hmAppManager$$__.currentApp;
        const o = e.current
          , {px: i} = (new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(e,o)),
        e.__globals__)
          , n = Logger.getLogger("watchface6");
        o.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            normal_background_bg = hmUI.createWidget(hmUI.widget.FILL_RECT, {
              x: 0,
              y: 0,
              w: 466,
              h: 466,
              color: '0xFF000000',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_frame_animation_1 = hmUI.createWidget(hmUI.widget.IMG_ANIM, {
              x: -8,
              y: -6,
              anim_path: "animation",
              anim_ext: "png",
              anim_prefix: "cog",
              anim_fps: 15,
              anim_size: 24,
              repeat_count: 0,
              anim_repeat: true,
              anim_status:hmUI.anim_status.START,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_dnd_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 53,
              y: 348,
              src: '0069.png',
              type: hmUI.system_status.DISTURB,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 392,
              y: 94,
              src: '0065.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 324,
              y: 33,
              src: '0067.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 14,
              y: 292,
              font_array: ["digital1_0.png","digital1_1.png","digital1_2.png","digital1_3.png","digital1_4.png","digital1_5.png","digital1_6.png","digital1_7.png","digital1_8.png","digital1_9.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'procent.png',
              unit_tc: 'procent.png',
              unit_en: 'procent.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 39,
              y: 266,
              src: 'Bateria1.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 34,
              y: 216,
              font_array: ["digital1_0.png","digital1_1.png","digital1_2.png","digital1_3.png","digital1_4.png","digital1_5.png","digital1_6.png","digital1_7.png","digital1_8.png","digital1_9.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: -1,
              y: 207,
              src: 'step02.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 425,
              day_startY: 216,
              day_sc_array: ["digital1_0.png","digital1_1.png","digital1_2.png","digital1_3.png","digital1_4.png","digital1_5.png","digital1_6.png","digital1_7.png","digital1_8.png","digital1_9.png"],
              day_tc_array: ["digital1_0.png","digital1_1.png","digital1_2.png","digital1_3.png","digital1_4.png","digital1_5.png","digital1_6.png","digital1_7.png","digital1_8.png","digital1_9.png"],
              day_en_array: ["digital1_0.png","digital1_1.png","digital1_2.png","digital1_3.png","digital1_4.png","digital1_5.png","digital1_6.png","digital1_7.png","digital1_8.png","digital1_9.png"],
              day_zero: 1,
              day_space: 0,
              day_align: hmUI.align.LEFT,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 346,
              y: 215,
              week_en: ["BD1.png","BD2.png","BD3.png","BD4.png","BD5.png","BD6.png","BD7.png"],
              week_tc: ["BD1.png","BD2.png","BD3.png","BD4.png","BD5.png","BD6.png","BD7.png"],
              week_sc: ["BD1.png","BD2.png","BD3.png","BD4.png","BD5.png","BD6.png","BD7.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_hour = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              hour_path: 'hour_0.png',
              hour_centerX: 227,
              hour_centerY: 226,
              hour_posX: 24,
              hour_posY: 178,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_minute = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              minute_path: 'minute_0.png',
              minute_centerX: 226,
              minute_centerY: 226,
              minute_posX: 22,
              minute_posY: 207,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_second = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              second_path: 'time_seconds_0.png',
              second_centerX: 226,
              second_centerY: 226,
              second_posX: 13,
              second_posY: 214,
              second_cover_path: 'secondring.png',
              second_cover_x: 198,
              second_cover_y: 199,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });



            idle_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 14,
              y: 292,
              font_array: ["digital1_aod_0.png","digital1_aod_1.png","digital1_aod_2.png","digital1_aod_3.png","digital1_aod_4.png","digital1_aod_5.png","digital1_aod_6.png","digital1_aod_7.png","digital1_aod_8.png","digital1_aod_9.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'procent_aod.png',
              unit_tc: 'procent_aod.png',
              unit_en: 'procent_aod.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_battery_text_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 39,
              y: 266,
              src: 'BateriaAOD.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_analog_clock_time_pointer_hour = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              hour_path: 'hour_1.png',
              hour_centerX: 227,
              hour_centerY: 226,
              hour_posX: 24,
              hour_posY: 178,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_analog_clock_time_pointer_minute = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              minute_path: 'minute_1.png',
              minute_centerX: 226,
              minute_centerY: 226,
              minute_posX: 22,
              minute_posY: 207,
              minute_cover_path: 'secondring_aod.png',
              minute_cover_x: 198,
              minute_cover_y: 198,
              show_level: hmUI.show_level.ONLY_AOD,
            });
            
            // disconnectAlert = hmUI.createWidget(hmUI.widget.DisconnectAlert, {
              // disconneсnt_vibrate_type: 0,
              // disconneсnt_toast_text: Bluetooth\r\nDesconectado,
              // conneсnt_vibrate_type: 0,
              // conneсnt_toast_text: Bluetooth\r\nConectado,
            // });

            // vibration when connecting or disconnecting

            function checkConnection() {
              hmBle.removeListener;
              hmBle.addListener(function (status) {
                if(!status) {
                  hmUI.showToast({text: "Bluetooth\r\nDesconectado"});
                  vibro(0);
                }
                if(status) {
                  hmUI.showToast({text: "Bluetooth\r\nConectado"});
                  vibro(0);
                }
              });
            }

            // end vibration when connecting or disconnecting
            // vibrate function

            const vibrate = hmSensor.createSensor(hmSensor.id.VIBRATE);
            let timer_StopVibrate = null;


            function vibro(scene = 25) {
              let stopDelay = 50;
              stopVibro();
              vibrate.scene = scene;
              if(scene < 23 || scene > 25) stopDelay = 1300;
              vibrate.start();
              timer_StopVibrate = timer.createTimer(stopDelay, 3000, stopVibro, {});
            }

            function stopVibro(){
              vibrate.stop();
              if(timer_StopVibrate) timer.stopTimer(timer_StopVibrate);
            }

            // end vibrate function

            normal_alarm_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 316,
              y: 25,
              w: 50,
              h: 50,
              src: 'transparent.png',
              type: hmUI.data_type.ALARM_CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 6,
              y: 200,
              w: 100,
              h: 50,
              src: 'transparent.png',
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                normal_frame_animation_1.setProperty(hmUI.prop.ANIM_STATUS,hmUI.anim_status.START);
                checkConnection();
                stopVibro();

              }),
              pause_call: (function () {
                normal_frame_animation_1.setProperty(hmUI.prop.ANIM_STATUS,hmUI.anim_status.STOP);
                stopVibro();

              }),
            });

                //dynamic modify end
            },
            onInit() {
                n.log("index page.js on init invoke")
            },
            build() {
                this.init_view(),
                n.log("index page.js on ready invoke")
            },
            onDestroy() {
                n.log("index page.js on destroy invoke")
            }
        })
    }
    )()
} catch (e) {
    console.log("Mini Program Error", e),
    e && e.stack && e.stack.split(/\n/).forEach((e=>console.log("error stack", e)))
}
