﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        const logger = Logger.getLogger('watchface_SashaCX75');
        //end of ignored block

        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_date_img_date_month = ''
        let normal_date_img_date_day = ''
        let normal_system_disconnect_img = ''
        let normal_distance_text_text_img = ''
        let normal_step_current_text_img = ''
        let normal_calorie_current_text_img = ''
        let normal_battery_text_text_img = ''
        let normal_battery_image_progress_img_level = ''
        let normal_heart_rate_text_text_img = ''
        let normal_heart_rate_image_progress_img_level = ''
        let normal_digital_clock_img_time = ''
        let idle_background_bg = ''
        let idle_date_img_date_month = ''
        let idle_date_img_date_day = ''
        let idle_digital_clock_img_time = ''
        let normal_stopwatch_jumpable_img_click = ''
        let normal_countdown_jumpable_img_click = ''
        let normal_heart_jumpable_img_click = ''
        let normal_step_jumpable_img_click = ''


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            console.log('Watch_Face.ScreenNormal');
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 466,
              h: 466,
              src: 'pulse.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_month = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 244,
              month_startY: 39,
              month_sc_array: ["long_type_time_num_0.png","long_type_time_num_1.png","long_type_time_num_2.png","long_type_time_num_3.png","long_type_time_num_4.png","long_type_time_num_5.png","long_type_time_num_6.png","long_type_time_num_7.png","long_type_time_num_8.png","long_type_time_num_9.png"],
              month_tc_array: ["long_type_time_num_0.png","long_type_time_num_1.png","long_type_time_num_2.png","long_type_time_num_3.png","long_type_time_num_4.png","long_type_time_num_5.png","long_type_time_num_6.png","long_type_time_num_7.png","long_type_time_num_8.png","long_type_time_num_9.png"],
              month_en_array: ["long_type_time_num_0.png","long_type_time_num_1.png","long_type_time_num_2.png","long_type_time_num_3.png","long_type_time_num_4.png","long_type_time_num_5.png","long_type_time_num_6.png","long_type_time_num_7.png","long_type_time_num_8.png","long_type_time_num_9.png"],
              month_zero: 1,
              month_space: 0,
              month_align: hmUI.align.CENTER_H,
              month_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 187,
              day_startY: 39,
              day_sc_array: ["long_type_time_num_0.png","long_type_time_num_1.png","long_type_time_num_2.png","long_type_time_num_3.png","long_type_time_num_4.png","long_type_time_num_5.png","long_type_time_num_6.png","long_type_time_num_7.png","long_type_time_num_8.png","long_type_time_num_9.png"],
              day_tc_array: ["long_type_time_num_0.png","long_type_time_num_1.png","long_type_time_num_2.png","long_type_time_num_3.png","long_type_time_num_4.png","long_type_time_num_5.png","long_type_time_num_6.png","long_type_time_num_7.png","long_type_time_num_8.png","long_type_time_num_9.png"],
              day_en_array: ["long_type_time_num_0.png","long_type_time_num_1.png","long_type_time_num_2.png","long_type_time_num_3.png","long_type_time_num_4.png","long_type_time_num_5.png","long_type_time_num_6.png","long_type_time_num_7.png","long_type_time_num_8.png","long_type_time_num_9.png"],
              day_zero: 1,
              day_space: 0,
              day_unit_sc: 'dt.png',
              day_unit_tc: 'dt.png',
              day_unit_en: 'dt.png',
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 219,
              y: 246,
              src: 'bt.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_distance_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 81,
              y: 282,
              font_array: ["clock_time_num_0.png","clock_time_num_1.png","clock_time_num_2.png","clock_time_num_3.png","clock_time_num_4.png","clock_time_num_5.png","clock_time_num_6.png","clock_time_num_7.png","clock_time_num_8.png","clock_time_num_9.png"],
              padding: false,
              h_space: 0,
              dot_image: 'dot.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.DISTANCE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 259,
              y: 282,
              font_array: ["clock_time_num_0.png","clock_time_num_1.png","clock_time_num_2.png","clock_time_num_3.png","clock_time_num_4.png","clock_time_num_5.png","clock_time_num_6.png","clock_time_num_7.png","clock_time_num_8.png","clock_time_num_9.png"],
              padding: false,
              h_space: -1,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_calorie_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 78,
              y: 155,
              font_array: ["clock_time_num_0.png","clock_time_num_1.png","clock_time_num_2.png","clock_time_num_3.png","clock_time_num_4.png","clock_time_num_5.png","clock_time_num_6.png","clock_time_num_7.png","clock_time_num_8.png","clock_time_num_9.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 189,
              y: 383,
              font_array: ["clock_time_num_0.png","clock_time_num_1.png","clock_time_num_2.png","clock_time_num_3.png","clock_time_num_4.png","clock_time_num_5.png","clock_time_num_6.png","clock_time_num_7.png","clock_time_num_8.png","clock_time_num_9.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 163,
              y: 432,
              image_array: ["bat_0.png","bat_1.png","bat_2.png","bat_3.png","bat_4.png","bat_5.png","bat_6.png","bat_7.png","bat_8.png","bat_9.png"],
              image_length: 10,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 278,
              y: 155,
              font_array: ["clock_time_num_0.png","clock_time_num_1.png","clock_time_num_2.png","clock_time_num_3.png","clock_time_num_4.png","clock_time_num_5.png","clock_time_num_6.png","clock_time_num_7.png","clock_time_num_8.png","clock_time_num_9.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 0,
              y: 0,
              image_array: ["pulse_0.png","pulse_1.png","pulse_2.png","pulse_3.png","pulse_4.png","pulse_5.png"],
              image_length: 6,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 91,
              hour_startY: 83,
              hour_array: ["hour_0.png","hour_1.png","hour_2.png","hour_3.png","hour_4.png","hour_5.png","hour_6.png","hour_7.png","hour_8.png","hour_9.png"],
              hour_zero: 1,
              hour_space: 0,
              hour_angle: 0,
              hour_unit_sc: 'colon.png',
              hour_unit_tc: 'colon.png',
              hour_unit_en: 'colon.png',
              hour_align: hmUI.align.LEFT,

              minute_startX: 193,
              minute_startY: 83,
              minute_array: ["hour_0.png","hour_1.png","hour_2.png","hour_3.png","hour_4.png","hour_5.png","hour_6.png","hour_7.png","hour_8.png","hour_9.png"],
              minute_zero: 1,
              minute_space: 0,
              minute_angle: 0,
              minute_follow: 0,
              minute_unit_sc: 'colon.png',
              minute_unit_tc: 'colon.png',
              minute_unit_en: 'colon.png',
              minute_align: hmUI.align.LEFT,

              second_startX: 293,
              second_startY: 83,
              second_array: ["hour_0.png","hour_1.png","hour_2.png","hour_3.png","hour_4.png","hour_5.png","hour_6.png","hour_7.png","hour_8.png","hour_9.png"],
              second_zero: 1,
              second_space: 0,
              second_angle: 0,
              second_follow: 0,
              second_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            console.log('Watch_Face.ScreenAOD');
            idle_background_bg = hmUI.createWidget(hmUI.widget.FILL_RECT, {
              x: 0,
              y: 0,
              w: 466,
              h: 466,
              color: '0xFF000000',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_month = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 244,
              month_startY: 39,
              month_sc_array: ["long_type_time_num_0.png","long_type_time_num_1.png","long_type_time_num_2.png","long_type_time_num_3.png","long_type_time_num_4.png","long_type_time_num_5.png","long_type_time_num_6.png","long_type_time_num_7.png","long_type_time_num_8.png","long_type_time_num_9.png"],
              month_tc_array: ["long_type_time_num_0.png","long_type_time_num_1.png","long_type_time_num_2.png","long_type_time_num_3.png","long_type_time_num_4.png","long_type_time_num_5.png","long_type_time_num_6.png","long_type_time_num_7.png","long_type_time_num_8.png","long_type_time_num_9.png"],
              month_en_array: ["long_type_time_num_0.png","long_type_time_num_1.png","long_type_time_num_2.png","long_type_time_num_3.png","long_type_time_num_4.png","long_type_time_num_5.png","long_type_time_num_6.png","long_type_time_num_7.png","long_type_time_num_8.png","long_type_time_num_9.png"],
              month_zero: 1,
              month_space: 0,
              month_align: hmUI.align.CENTER_H,
              month_is_character: false,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 187,
              day_startY: 39,
              day_sc_array: ["long_type_time_num_0.png","long_type_time_num_1.png","long_type_time_num_2.png","long_type_time_num_3.png","long_type_time_num_4.png","long_type_time_num_5.png","long_type_time_num_6.png","long_type_time_num_7.png","long_type_time_num_8.png","long_type_time_num_9.png"],
              day_tc_array: ["long_type_time_num_0.png","long_type_time_num_1.png","long_type_time_num_2.png","long_type_time_num_3.png","long_type_time_num_4.png","long_type_time_num_5.png","long_type_time_num_6.png","long_type_time_num_7.png","long_type_time_num_8.png","long_type_time_num_9.png"],
              day_en_array: ["long_type_time_num_0.png","long_type_time_num_1.png","long_type_time_num_2.png","long_type_time_num_3.png","long_type_time_num_4.png","long_type_time_num_5.png","long_type_time_num_6.png","long_type_time_num_7.png","long_type_time_num_8.png","long_type_time_num_9.png"],
              day_zero: 1,
              day_space: 0,
              day_unit_sc: 'dt.png',
              day_unit_tc: 'dt.png',
              day_unit_en: 'dt.png',
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 120,
              hour_startY: 199,
              hour_array: ["hour_0.png","hour_1.png","hour_2.png","hour_3.png","hour_4.png","hour_5.png","hour_6.png","hour_7.png","hour_8.png","hour_9.png"],
              hour_zero: 1,
              hour_space: 10,
              hour_angle: 0,
              hour_unit_sc: 'colon.png',
              hour_unit_tc: 'colon.png',
              hour_unit_en: 'colon.png',
              hour_align: hmUI.align.LEFT,

              minute_startX: 250,
              minute_startY: 199,
              minute_array: ["hour_0.png","hour_1.png","hour_2.png","hour_3.png","hour_4.png","hour_5.png","hour_6.png","hour_7.png","hour_8.png","hour_9.png"],
              minute_zero: 1,
              minute_space: 10,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_AOD,
            });
            console.log('Watch_Face.Shortcuts');

            normal_stopwatch_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 301,
              y: 92,
              w: 58,
              h: 58,
              type: hmUI.data_type.STOP_WATCH,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_countdown_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 103,
              y: 92,
              w: 58,
              h: 58,
              type: hmUI.data_type.COUNT_DOWN,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 282,
              y: 178,
              w: 97,
              h: 73,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 282,
              y: 291,
              w: 97,
              h: 73,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}