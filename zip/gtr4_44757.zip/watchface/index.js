﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        //const logger = Logger.getLogger('watchface_SashaCX75');
        const logger = DeviceRuntimeCore.HmLogger.getLogger('watchface_SashaCX75')
        //end of ignored block

        //dynamic modify start

        
        console.log('user_functions.js');
        // start user_functions.js

const {
 width: D_W,
 height: D_H
} = hmSetting.getDeviceInfo();

const packageInfo = hmApp.packageInfo();
WF_ID = packageInfo.appId;

let kf = D_W / 466;

let normal_weather_image_progress_img_level_ic = ''

        let normal_fat_burning_TextCircle = new Array(3);
        let normal_fat_burning_TextCircle_ASCIIARRAY = new Array(10);
        let normal_fat_burning_TextCircle_img_width = 12;
        let normal_fat_burning_TextCircle_img_height = 14;
        let normal_fat_burning_TextCircle_unit = null;
        let normal_fat_burning_TextCircle_unit_width = 20;

let normal_puls_min_text_text_img = ''
let normal_puls_min_text_separator_img = ''
let normal_puls_max_text_text_img = ''



function loadSettings() {

tap_str = hmFS.SysProGetInt(`${WF_ID}_tap_str`) === undefined ? (hmFS.SysProSetInt(`${WF_ID}_tap_str`, 0), 0) : hmFS.SysProGetInt(`${WF_ID}_tap_str`);
block = hmFS.SysProGetInt(`${WF_ID}_block`) === undefined ? (hmFS.SysProSetInt(`${WF_ID}_block`, 0), 0) : hmFS.SysProGetInt(`${WF_ID}_block`);
	


}


let tap_str = 0
function clik_tap_str() {
 tap_str = (tap_str + 1) % 2
 hmFS.SysProSetInt(`${WF_ID}_tap_str`, tap_str);
 normal_analog_clock_time_pointer_hour.setProperty(hmUI.prop.VISIBLE, tap_str == 0);
 normal_analog_clock_time_pointer_minute.setProperty(hmUI.prop.VISIBLE, tap_str == 0);
 normal_analog_clock_time_pointer_second.setProperty(hmUI.prop.VISIBLE, tap_str == 0);
 vibro();
}


const vibrate = hmSensor.createSensor(hmSensor.id.VIBRATE)
let stopVibro_Timer = null;

function vibro(scene = 25) {
 vibrate.stop();
 vibrate.scene = scene;
 vibrate.start();
}

function stopVibro() {
 vibrate.stop();
 timer.stopTimer(stopVibro_Timer);
}

// Датчик пульса
let heart = hmSensor.createSensor(hmSensor.id.HEART);

function updateHeartMinMax() {
 let todayData = heart.today;
 if (!todayData || todayData.length === 0) return;

 let periodData = todayData.slice(-60); // последние 60 минут
 let valid = periodData.filter(v => v && v > 0);
 if (valid.length === 0) return;

 let minVal = Math.min(...valid);
 let maxVal = Math.max(...valid);

 normal_puls_min_text_text_img.setProperty(hmUI.prop.TEXT, minVal.toString().padStart(3, '0'));
 normal_puls_max_text_text_img.setProperty(hmUI.prop.TEXT, maxVal.toString().padStart(3, '0'));
}


function read_pressure() {
 console.log("read_pressure()");
 const file_name_alt = "../../../baro_altim/pressure.dat";
 const [fs_stat, err] = hmFS.stat(file_name_alt);
 if (err == 0) {
  let file_size = fs_stat.size;
  const len = file_size / 4;
  console.log(`size_alt: ${file_size}, lenght: ${len}`)
  const fh = hmFS.open(file_name_alt, hmFS.O_RDONLY)

  let array_buffer = new Float32Array(len);
  hmFS.read(fh, array_buffer.buffer, 0, file_size);
  hmFS.close(fh);
  console.log(`value ${array_buffer[array_buffer.length -1]}`);
  return array_buffer;
 } else {
  console.log('err:', err)
 }
 return null;
}

function getPressureValue(pressure_array) {
 console.log("getPressureValue()");
 if (pressure_array == null || pressure_array == undefined || pressure_array.length == 0) return 0;
 let start_index = pressure_array.length - 1;
 let end_index = start_index - 30 * 3; // 3 часа
 if (end_index < 0) end_index = 0;
 for (let index = start_index; index >= end_index; index--) {
  if (pressure_array[index] != 0) return parseInt(pressure_array[index] / 100);
 }
 return 0;
}

function changesPressure(pressure_array) {
 console.log("changesPressure()");
 if (pressure_array == null || pressure_array == undefined || pressure_array.length == 0) return 0;
 let start_index = pressure_array.length - 1;
 let end_index = start_index - 30 * 3; // 3 часа
 let value = pressure_array[start_index];
 let result = 0;
 if (end_index < 0) end_index = 0;
 for (let index = start_index; index >= end_index; index--) {
  let element = pressure_array[index];
  if (element != 0) {
   if (Math.abs(value - element) > 10) { // учитываем только если разниза больше 0,1 hPa
    value = value - element;
    console.log(`element = ${element}`);
    console.log(`pressere_changes = ${value}`);
    return value;
   }
  }
 }
 return result;
}

function hPa_To_mmHg(hPa_value = 0) {
 let mmHg = Math.round(hPa_value * 0.750064);
 return mmHg;
}

function updatePressere() {
 let pressure_array = read_pressure();
 let value = getPressureValue(pressure_array);
 value = hPa_To_mmHg(value); // если нужно перевести в мм.рт.ст.


 let pressere_changes_str = "=";
 //let color_pressere = 0x00ff00;
 let color_pressere_0 = value < 760 ? 0xffff00 : value > 760 ? 0xff0000 : 0x00ff00;

 let pressere_changes = changesPressure(pressure_array);
 if (pressere_changes < 0) {
  pressere_changes_str = "↓"; 
 }
 if (pressere_changes > 0) {
  pressere_changes_str = "↑"; 
 }
 //text_pressere_changes.setProperty(hmUI.prop.TEXT, pressere_changes_str);

let value_str = value == 0 ? "--" : value + pressere_changes_str;
 //let value_str = value == 0 ? "--" : value;

 normal_widget_text_7.setProperty(hmUI.prop.TEXT, value_str);
 //text_pressere.setProperty(hmUI.prop.COLOR, color_pressere_0);

 // Line_arr[2][1] = value_str;
}



let normal_block_FILL_RECT = ""
let btn_block = ""
let block = 0

function clik_block() {
 block = (block + 1) % 2
 hmFS.SysProSetInt(`${WF_ID}_block`, block);
 normal_widget_text_4.setProperty(hmUI.prop.TEXT, block == 0 ? 'ОТКР' : 'БЛОК');
normal_calorie_icon_img.setProperty(hmUI.prop.SRC, block == 0 ? 'ic_block_off.png' : 'ic_block_on.png');	
 normal_block_FILL_RECT.setProperty(hmUI.prop.VISIBLE, block == 1);
 btn_block.setProperty(hmUI.prop.VISIBLE, block == 1);
 vibro();
}


		// запуск приложения с заданным appId (если оно установлено) или системного приложения
function launchAppOrAppId(url, appId, page = 'page/index') {
 let appInstalled = false;
 try {
  const id16 = appId.toString(16).padStart(8, "0"); // переводим appId в 16-ричный формат
  const [fs_stat, err] = hmFS.stat_asset(`../../../js_apps/${id16}/app.json`); // проверяем наличие файла 'app.json' в папке приложения
  if (err == 0) { //  если файл есть,  то приложение установлено
   appInstalled = true;
  } else {
   console.log("err:", err);
  }
 } catch (error) {
  console.log("error:", error);
  console.log("FAIL: No access to hmFS.");
 }
 if (appInstalled) hmApp.startApp({
  appid: appId,
  url: page
 })
 else hmApp.startApp({
  url: url,
  native: true
 });
}


        // end user_functions.js

        let normal_background_bg_img = ''
        let normal_battery_current_text_font = ''
        let normal_humidity_current_text_font = ''
        let normal_widget_text_1 = ''
        let normal_widget_text_2 = ''
        let normal_widget_text_3 = ''
        let normal_widget_text_4 = ''
        let normal_widget_text_7 = ''
        let normal_digital_clock_img_time = ''
        let normal_image_img = ''
        let normal_heart_rate_image_progress_img_level = ''
        let normal_heart_rate_icon_img = ''
        let normal_heart_rate_text_text_img = ''
        let normal_date_img_date_week_img = ''
        let normal_date_img_date_month = ''
        let normal_date_img_date_day = ''
        let normal_weather_image_progress_img_level = ''
        let normal_temperature_max_min_text_img = ''
        let normal_temperature_current_text_img = ''
        let normal_temperature_icon_img = ''
        let normal_calorie_icon_img = ''
        let normal_calorie_current_text_img = ''
        let normal_step_icon_img = ''
        let normal_step_current_text_img = ''
        let normal_system_disconnect_img = ''
        let normal_system_clock_img = ''
        let normal_alarm_clock_current_text_font = ''
        let normal_analog_clock_time_pointer_hour = ''
        let normal_analog_clock_time_pointer_minute = ''
        let normal_analog_clock_time_pointer_second = ''
        let idle_background_bg = ''
        let idle_analog_clock_time_pointer_hour = ''
        let idle_analog_clock_time_pointer_minute = ''
        let Button_1 = ''
        let Button_2 = ''
        let Button_3 = ''
        let Button_4 = ''
        let Button_5 = ''
        let Button_6 = ''
        let Button_7 = ''


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            // FontName: Bebas22.ttf; FontSize: 22
            hmUI.createWidget(hmUI.widget.TEXT, {
              x: 464,
              y: 464,
              w: 324,
              h: 30,
              text_size: 22,
              char_space: 2,
              line_space: 0,
              font: 'fonts/Bebas22.ttf',
              color: 0xFFFFFFFF,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              text: "0123456789 _-.,:;`'%°\\/",
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // FontName: BebasNeue Bold.ttf; FontSize: 20
            hmUI.createWidget(hmUI.widget.TEXT, {
              x: 464,
              y: 464,
              w: 210,
              h: 28,
              text_size: 20,
              char_space: 0,
              line_space: 0,
              font: 'fonts/BebasNeue Bold.ttf',
              color: 0xFF000000,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              text: "0123456789 _-.,:;`'%°\\/",
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // FontName: BebasNeueAL-Bold.ttf; FontSize: 20
            hmUI.createWidget(hmUI.widget.TEXT, {
              x: 464,
              y: 464,
              w: 210,
              h: 25,
              text_size: 20,
              char_space: 0,
              line_space: 0,
              font: 'fonts/BebasNeueAL-Bold.ttf',
              color: 0xFF000000,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              text: "0123456789 _-.,:;`'%°\\/",
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            console.log('user_script_start.js');
            // start user_script_start.js

            loadSettings()

            hmUI.createWidget(hmUI.widget.TEXT, {
             x: D_W-2,
             y: D_W-2,
              w: 210 * kf,
              h: 28 * kf,
              text_size: 20 * kf,
              char_space: 0,
              line_space: 0,
              font: 'fonts/BebasNeue Bold.ttf',
              color: 0xFF000000,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              text: "0123456789 АБВГДЕЁЖЗИЙКЛМНОПРСТУФХЦЧШЩЪЫЬЭЮЯабвгдеёжзийклмнопрстуфхцчшщъыьэюя _-.,:;`'%°\\/",
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            hmUI.createWidget(hmUI.widget.TEXT, {
             x: 17 * kf,
             y: 17 * kf,
              w: 432 * kf,
              h: 432 * kf,
              text_size: 22 * kf,
              char_space: 2 * kf,
              line_space: 0,
              font: 'fonts/Bebas22.ttf',
              color: 0xFF000000,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              text: "0123456789 АБВГДЕЁЖЗИЙКЛМНОПРСТУФХЦЧШЩЪЫЬЭЮЯабвгдеёжзийклмнопрстуфхцчшщъыьэюя _-.,:;`'%°\\/↓↑",
              show_level: hmUI.show_level.ONLY_NORMAL,
            });



            // end user_script_start.js

            console.log('Watch_Face.ScreenNormal');
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 466,
              h: 466,
              src: 'bg.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_current_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 17,
              y: 17,
              w: 432,
              h: 432,
              text_size: 22,
              char_space: 2,
              font: 'fonts/Bebas22.ttf',
              color: 0xFFFFFFFF,
              // use_text_circle: true,
              start_angle: 141,
              end_angle: 180,
              mode: 1,
              // radius: 216,
              align_h: hmUI.align.CENTER_H,
              unit_type: 1,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_humidity_current_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 17,
              y: 17,
              w: 432,
              h: 432,
              text_size: 22,
              char_space: 2,
              font: 'fonts/Bebas22.ttf',
              color: 0xFFFFFFFF,
              // use_text_circle: true,
              start_angle: 90,
              end_angle: 128,
              mode: 1,
              // radius: 216,
              align_h: hmUI.align.CENTER_H,
              unit_type: 1,
              type: hmUI.data_type.HUMIDITY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_widget_text_1 = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 13,
              y: 13,
              w: 440,
              h: 440,
              text_size: 20,
              char_space: 0,
              font: 'fonts/BebasNeue Bold.ttf',
              color: 0xFF000000,
              // use_text_circle: true,
              start_angle: -92,
              end_angle: 0,
              mode: 0,
              // radius: 220,
              align_h: hmUI.align.CENTER_H,
              text: 'БУДИЛ',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_widget_text_2 = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 13,
              y: 13,
              w: 440,
              h: 440,
              text_size: 20,
              char_space: 0,
              font: 'fonts/BebasNeue Bold.ttf',
              color: 0xFF000000,
              // use_text_circle: true,
              start_angle: 0,
              end_angle: 94,
              mode: 0,
              // radius: 220,
              align_h: hmUI.align.CENTER_H,
              text: 'НАЙТИ',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_widget_text_3 = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 15,
              y: 15,
              w: 436,
              h: 436,
              text_size: 20,
              char_space: 1,
              font: 'fonts/BebasNeue Bold.ttf',
              color: 0xFF000000,
              // use_text_circle: true,
              start_angle: 180,
              end_angle: 272,
              mode: 1,
              // radius: 218,
              align_h: hmUI.align.CENTER_H,
              text: 'ТАЙМЕР',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_widget_text_4 = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 15,
              y: 15,
              w: 436,
              h: 436,
              text_size: 20,
              char_space: 1,
              font: 'fonts/BebasNeue Bold.ttf',
              color: 0xFF000000,
              // use_text_circle: true,
              start_angle: 90,
              end_angle: 177,
              mode: 1,
              // radius: 218,
              align_h: hmUI.align.CENTER_H,
              text: 'ОТКР',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_widget_text_7 = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 21,
              y: 21,
              w: 424,
              h: 424,
              text_size: 22,
              char_space: 1,
              font: 'fonts/Bebas22.ttf',
              color: 0xFFFFFFFF,
              // use_text_circle: true,
              start_angle: -90,
              end_angle: -49,
              mode: 0,
              // radius: 212,
              align_h: hmUI.align.CENTER_H,
              text: '754↑',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 253,
              hour_startY: 212,
              hour_array: ["H_0.png","H_1.png","H_2.png","H_3.png","H_4.png","H_5.png","H_6.png","H_7.png","H_8.png","H_9.png"],
              hour_zero: 1,
              hour_space: 0,
              hour_angle: 0,
              hour_unit_sc: 'H_10.png',
              hour_unit_tc: 'H_10.png',
              hour_unit_en: 'H_10.png',
              hour_align: hmUI.align.CENTER_H,

              minute_startX: 0,
              minute_startY: 0,
              minute_array: ["H_0.png","H_1.png","H_2.png","H_3.png","H_4.png","H_5.png","H_6.png","H_7.png","H_8.png","H_9.png"],
              minute_zero: 1,
              minute_space: 0,
              minute_angle: 0,
              minute_follow: 1,
              minute_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            console.log('user_script.js');
            // start user_script.js


            normal_weather_image_progress_img_level_ic = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
             x: 259 * kf,
             y: 264 * kf,
             image_array: ["wt_0.png", "wt_1.png", "wt_2.png", "wt_3.png", "wt_4.png", "wt_5.png", "wt_6.png", "wt_7.png", "wt_8.png", "wt_9.png", "wt_10.png", "wt_11.png", "wt_12.png", "wt_13.png", "wt_14.png", "wt_15.png", "wt_16.png", "wt_17.png", "wt_18.png", "wt_19.png", "wt_20.png", "wt_21.png", "wt_22.png", "wt_23.png", "wt_24.png", "wt_25.png", "wt_26.png", "wt_27.png", "wt_28.png"],
             image_length: 29,
             type: hmUI.data_type.WEATHER_CURRENT,
             show_level: hmUI.show_level.ONLY_NORMAL,
            });


            normal_fat_burning_TextCircle_ASCIIARRAY[0] = 'dig_b_0.png'; // set of images with numbers
            normal_fat_burning_TextCircle_ASCIIARRAY[1] = 'dig_b_1.png'; // set of images with numbers
            normal_fat_burning_TextCircle_ASCIIARRAY[2] = 'dig_b_2.png'; // set of images with numbers
            normal_fat_burning_TextCircle_ASCIIARRAY[3] = 'dig_b_3.png'; // set of images with numbers
            normal_fat_burning_TextCircle_ASCIIARRAY[4] = 'dig_b_4.png'; // set of images with numbers
            normal_fat_burning_TextCircle_ASCIIARRAY[5] = 'dig_b_5.png'; // set of images with numbers
            normal_fat_burning_TextCircle_ASCIIARRAY[6] = 'dig_b_6.png'; // set of images with numbers
            normal_fat_burning_TextCircle_ASCIIARRAY[7] = 'dig_b_7.png'; // set of images with numbers
            normal_fat_burning_TextCircle_ASCIIARRAY[8] = 'dig_b_8.png'; // set of images with numbers
            normal_fat_burning_TextCircle_ASCIIARRAY[9] = 'dig_b_9.png'; // set of images with numbers

            //#region TextCircle
            for (let i = 0; i < 3; i++) {
             normal_fat_burning_TextCircle[i] = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 466,
              h: 466,
              center_x: 233,
              center_y: 233,
              pos_x: 233 - normal_fat_burning_TextCircle_img_width / 2,
              pos_y: 233 - 121,
              src: 'dig_b_0.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
             });
             normal_fat_burning_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
            };

            normal_fat_burning_TextCircle_unit = hmUI.createWidget(hmUI.widget.IMG, {
             x: 0,
             y: 0,
             w: 466,
             h: 466,
             center_x: 233,
             center_y: 233,
             pos_x: 233 - normal_fat_burning_TextCircle_unit_width / 2,
             pos_y: 233 - 121,
             src: 'dig_b_pr.png',
             show_level: hmUI.show_level.ONLY_NORMAL,
            });
            normal_fat_burning_TextCircle_unit.setProperty(hmUI.prop.VISIBLE, false);
            //#endregion

            const step = hmSensor.createSensor(hmSensor.id.STEP);
            step.addEventListener(hmSensor.event.CHANGE, function () {
             step_text_update();
            });

            function toDegree(radian) {
             return radian * (180 / Math.PI);
            };

            let screenType = hmSetting.getScreenType();

            function step_text_update() {
             console.log('text_update()');

             console.log('update text circle fat_burning_FAT_BURRING');
             let valueFatBurning = parseInt(step.current / step.target * 100);
             let normal_fat_burning_circle_string = parseInt(valueFatBurning).toString();

             if (screenType != hmSetting.screen_type.AOD) {
              for (var i = 1; i < 3; i++) { // hide all symbols
               normal_fat_burning_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
              };
              normal_fat_burning_TextCircle_unit.setProperty(hmUI.prop.VISIBLE, false);
              let char_Angle = -50;
              if (valueFatBurning != null && valueFatBurning != undefined && isFinite(valueFatBurning) && normal_fat_burning_circle_string.length > 0 && normal_fat_burning_circle_string.length <= 3) { // display data if it was possible to get it
               let normal_fat_burning_TextCircle_img_angle = 0;
               let normal_fat_burning_TextCircle_dot_img_angle = 0;
               let normal_fat_burning_TextCircle_unit_angle = 0;
               normal_fat_burning_TextCircle_img_angle = toDegree(Math.atan2(normal_fat_burning_TextCircle_img_width / 2, 107));
               normal_fat_burning_TextCircle_unit_angle = toDegree(Math.atan2(normal_fat_burning_TextCircle_unit_width / 2, 107));
               // alignment = CENTER_H
               let normal_fat_burning_TextCircle_angleOffset = normal_fat_burning_TextCircle_img_angle * (normal_fat_burning_circle_string.length - 1);
               normal_fat_burning_TextCircle_angleOffset = normal_fat_burning_TextCircle_angleOffset + (normal_fat_burning_TextCircle_img_angle + normal_fat_burning_TextCircle_unit_angle + 0) / 2;
               char_Angle -= normal_fat_burning_TextCircle_angleOffset;
               // alignment end

               let firstSymbol = true;
               let index = 0;
               for (let char of normal_fat_burning_circle_string) {
                let charCode = char.charCodeAt() - 48;
                if (index >= 3) break;
                if (charCode >= 0 && charCode < 10) {
                 if (!firstSymbol) char_Angle += normal_fat_burning_TextCircle_img_angle;
                 firstSymbol = false;
                 normal_fat_burning_TextCircle[index].setProperty(hmUI.prop.ANGLE, char_Angle);
                 normal_fat_burning_TextCircle[index].setProperty(hmUI.prop.POS_X, 233 - normal_fat_burning_TextCircle_img_width / 2);
                 normal_fat_burning_TextCircle[index].setProperty(hmUI.prop.SRC, normal_fat_burning_TextCircle_ASCIIARRAY[charCode]);
                 normal_fat_burning_TextCircle[index].setProperty(hmUI.prop.VISIBLE, true);
                 char_Angle += normal_fat_burning_TextCircle_img_angle;
                 index++;
                }; // end if digit
               }; // end char of string
               char_Angle += normal_fat_burning_TextCircle_unit_angle;
               normal_fat_burning_TextCircle_unit.setProperty(hmUI.prop.ANGLE, char_Angle);
               normal_fat_burning_TextCircle_unit.setProperty(hmUI.prop.VISIBLE, true);
              } // end isFinite

             };

            };

            normal_puls_min_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
             x: (227 - 10) * kf,
             y: 366 * kf,
             font_array: ["dig_c_0.png", "dig_c_1.png", "dig_c_2.png", "dig_c_3.png", "dig_c_4.png", "dig_c_5.png", "dig_c_6.png", "dig_c_7.png", "dig_c_8.png", "dig_c_9.png"],
             padding: true,
             h_space: -1,
             align_h: hmUI.align.CENTER_H,
             // type: hmUI.data_type.SPO2,
             show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_puls_min_text_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
             x: 259 * kf,
             y: 365 * kf,
             src: 'dig_c_10.png',
             show_level: hmUI.show_level.ONLY_NORMAL,
            });


            normal_puls_max_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
             x: (265 - 10) * kf,
             y: 366 * kf,
             font_array: ["dig_c_0.png", "dig_c_1.png", "dig_c_2.png", "dig_c_3.png", "dig_c_4.png", "dig_c_5.png", "dig_c_6.png", "dig_c_7.png", "dig_c_8.png", "dig_c_9.png"],
             padding: true,
             h_space: -1,
             align_h: hmUI.align.CENTER_H,
             // type: hmUI.data_type.READINESS,
             show_level: hmUI.show_level.ONLY_NORMAL,
            });
            // end user_script.js

            normal_image_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'cap.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 124,
              y: 284,
              image_array: ["puls_tx_0.png","puls_tx_1.png","puls_tx_2.png","puls_tx_3.png","puls_tx_4.png","puls_tx_5.png"],
              image_length: 6,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 146,
              y: 328,
              src: 'bg_puls.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 228,
              y: 342,
              font_array: ["dig_a_0.png","dig_a_1.png","dig_a_2.png","dig_a_3.png","dig_a_4.png","dig_a_5.png","dig_a_6.png","dig_a_7.png","dig_a_8.png","dig_a_9.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 351,
              y: 178,
              week_en: ["week_0.png","week_1.png","week_2.png","week_3.png","week_4.png","week_5.png","week_6.png"],
              week_tc: ["week_0.png","week_1.png","week_2.png","week_3.png","week_4.png","week_5.png","week_6.png"],
              week_sc: ["week_0.png","week_1.png","week_2.png","week_3.png","week_4.png","week_5.png","week_6.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_month = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 310,
              month_startY: 178,
              month_sc_array: ["data_0.png","data_1.png","data_2.png","data_3.png","data_4.png","data_5.png","data_6.png","data_7.png","data_8.png","data_9.png"],
              month_tc_array: ["data_0.png","data_1.png","data_2.png","data_3.png","data_4.png","data_5.png","data_6.png","data_7.png","data_8.png","data_9.png"],
              month_en_array: ["data_0.png","data_1.png","data_2.png","data_3.png","data_4.png","data_5.png","data_6.png","data_7.png","data_8.png","data_9.png"],
              month_zero: 1,
              month_space: 0,
              month_align: hmUI.align.CENTER_H,
              month_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 258,
              day_startY: 178,
              day_sc_array: ["data_0.png","data_1.png","data_2.png","data_3.png","data_4.png","data_5.png","data_6.png","data_7.png","data_8.png","data_9.png"],
              day_tc_array: ["data_0.png","data_1.png","data_2.png","data_3.png","data_4.png","data_5.png","data_6.png","data_7.png","data_8.png","data_9.png"],
              day_en_array: ["data_0.png","data_1.png","data_2.png","data_3.png","data_4.png","data_5.png","data_6.png","data_7.png","data_8.png","data_9.png"],
              day_zero: 1,
              day_space: 0,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 171,
              y: 82,
              image_array: ["wi_0.png","wi_1.png","wi_2.png","wi_3.png","wi_4.png","wi_5.png","wi_6.png","wi_7.png","wi_8.png","wi_9.png","wi_10.png","wi_11.png","wi_12.png","wi_13.png","wi_14.png","wi_15.png","wi_16.png","wi_17.png","wi_18.png","wi_19.png","wi_20.png","wi_21.png","wi_22.png","wi_23.png","wi_24.png","wi_25.png","wi_26.png","wi_27.png","wi_28.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_max_min_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 222,
              y: 104,
              font_array: ["dig_c_0.png","dig_c_1.png","dig_c_2.png","dig_c_3.png","dig_c_4.png","dig_c_5.png","dig_c_6.png","dig_c_7.png","dig_c_8.png","dig_c_9.png"],
              padding: false,
              h_space: -1,
              unit_sc: 'dig_c_11.png',
              unit_tc: 'dig_c_11.png',
              unit_en: 'dig_c_11.png',
              negative_image: 'dig_c_10.png',
              invalid_image: 'dig_c_12.png',
              dot_image: 'dig_c_13.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_HIGH_LOW,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 233,
              y: 82,
              font_array: ["dig_a_0.png","dig_a_1.png","dig_a_2.png","dig_a_3.png","dig_a_4.png","dig_a_5.png","dig_a_6.png","dig_a_7.png","dig_a_8.png","dig_a_9.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'dig_a_g.png',
              unit_tc: 'dig_a_g.png',
              unit_en: 'dig_a_g.png',
              negative_image: 'dig_a_m.png',
              invalid_image: 'dig_a_v.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 166,
              y: 78,
              src: 'cap_weather.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_calorie_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 329,
              y: 338,
              src: 'ic_block_off.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_calorie_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 88,
              y: 242,
              font_array: ["dig_a_0.png","dig_a_1.png","dig_a_2.png","dig_a_3.png","dig_a_4.png","dig_a_5.png","dig_a_6.png","dig_a_7.png","dig_a_8.png","dig_a_9.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 292,
              y: 178,
              src: 'data_10.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 83,
              y: 206,
              font_array: ["dig_a_0.png","dig_a_1.png","dig_a_2.png","dig_a_3.png","dig_a_4.png","dig_a_5.png","dig_a_6.png","dig_a_7.png","dig_a_8.png","dig_a_9.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 148,
              y: 37,
              src: 'stat_BT.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 48,
              y: 54,
              src: 'stat_AL.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_alarm_clock_current_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 13,
              y: 13,
              w: 440,
              h: 440,
              text_size: 20,
              char_space: 0,
              font: 'fonts/BebasNeueAL-Bold.ttf',
              color: 0xFF000000,
              // use_text_circle: true,
              start_angle: -92,
              end_angle: 0,
              mode: 0,
              // radius: 220,
              align_h: hmUI.align.CENTER_H,
              padding: true,
              type: hmUI.data_type.ALARM_CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_hour = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              hour_path: 'str_H.png',
              hour_centerX: 233,
              hour_centerY: 233,
              hour_posX: 33,
              hour_posY: 139,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_minute = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              minute_path: 'str_M.png',
              minute_centerX: 233,
              minute_centerY: 233,
              minute_posX: 30,
              minute_posY: 199,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_second = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              second_path: 'str_S.png',
              second_centerX: 233,
              second_centerY: 233,
              second_posX: 20,
              second_posY: 230,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            console.log('Watch_Face.ScreenAOD');
            idle_background_bg = hmUI.createWidget(hmUI.widget.FILL_RECT, {
              x: 0,
              y: 0,
              w: 466,
              h: 466,
              color: '0xFF000000',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_analog_clock_time_pointer_hour = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              hour_path: 'str_H.png',
              hour_centerX: 233,
              hour_centerY: 233,
              hour_posX: 33,
              hour_posY: 139,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_analog_clock_time_pointer_minute = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              minute_path: 'str_M.png',
              minute_centerX: 233,
              minute_centerY: 233,
              minute_posX: 30,
              minute_posY: 199,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            console.log('Watch_Face.Buttons');
            Button_1 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 183,
              y: 183,
              w: 100,
              h: 100,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '0.png',
              normal_src: '0.png',
              click_func: (button_widget) => {
                clik_tap_str();
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_2 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 312,
              y: 183,
              w: 100,
              h: 100,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '0.png',
              normal_src: '0.png',
              click_func: (button_widget) => {
                //hmApp.startApp({url: 'ScheduleCalScreen', native: true });
launchAppOrAppId('ScheduleCalScreen', 1057409);
vibro();

              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_3 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 52,
              y: 52,
              w: 100,
              h: 100,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '0.png',
              normal_src: '0.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'AlarmInfoScreen', native: true });
vibro();
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_4 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 317,
              y: 52,
              w: 100,
              h: 100,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '0.png',
              normal_src: '0.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'FindPhoneScreen', native: true });
vibro();
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_5 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 186,
              y: 52,
              w: 100,
              h: 100,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '0.png',
              normal_src: '0.png',
              click_func: (button_widget) => {
                //hmApp.startApp({url: 'WeatherScreen', native: true });
launchAppOrAppId('WeatherScreen', 1051195);
vibro();

              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_6 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 317,
              y: 316,
              w: 100,
              h: 100,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '0.png',
              normal_src: '0.png',
              click_func: (button_widget) => {
                clik_block();
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_7 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 52,
              y: 316,
              w: 100,
              h: 100,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '0.png',
              normal_src: '0.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'CountdownAppScreen', native: true });
vibro();
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            console.log('user_script_end.js');
            // start user_script_end.js

    normal_block_FILL_RECT = hmUI.createWidget(hmUI.widget.FILL_RECT, {
     x: 0,
     y: 0,
     w: D_W,
     h: D_W,
     color: 0x000000,
     alpha: 0,
     show_level: hmUI.show_level.ONLY_NORMAL,
    });
    normal_block_FILL_RECT.setProperty(hmUI.prop.VISIBLE, block == 1);

    btn_block = hmUI.createWidget(hmUI.widget.BUTTON, {
     x: 317 * kf,
     y: 316 * kf,
     text: '',
     w: 100 * kf,
     h: 100 * kf,
     normal_src: '0_Empty.png',
     press_src: '0_Empty.png',
     //             click_func: () => {
     //                 vibro();
     //                 clik_tap_left();
     //             },
     longpress_func: () => {
      // vibro();
      clik_block();
     },
     show_level: hmUI.show_level.ONLY_NORMAL,
    });
    btn_block.setProperty(hmUI.prop.VISIBLE, block == 1);

    normal_analog_clock_time_pointer_hour.setProperty(hmUI.prop.VISIBLE, tap_str == 0);
    normal_analog_clock_time_pointer_minute.setProperty(hmUI.prop.VISIBLE, tap_str == 0);
    normal_analog_clock_time_pointer_second.setProperty(hmUI.prop.VISIBLE, tap_str == 0);
    normal_widget_text_4.setProperty(hmUI.prop.TEXT, block == 0 ? 'ОТКР' : 'БЛОК');
normal_calorie_icon_img.setProperty(hmUI.prop.SRC, block == 0 ? 'ic_block_off.png' : 'ic_block_on.png');	


    heart.addEventListener(hmSensor.event.CHANGE, function () {
     updateHeartMinMax();
    });
            // end user_script_end.js

            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                console.log('resume_call()');

                console.log('resume_call.js');
                // start resume_call.js

loadSettings();
step_text_update();
updateHeartMinMax();
updatePressere();
                // end resume_call.js

              }),
            });

                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}