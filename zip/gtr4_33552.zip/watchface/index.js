﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        const logger = Logger.getLogger('watchface_SashaCX75');
        //end of ignored block

        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_system_disconnect_img = ''
        let normal_system_clock_img = ''
        let normal_date_img_date_month_img = ''
        let normal_date_img_date_week_img = ''
        let normal_date_img_date_day = ''
        let normal_temperature_icon_img = ''
        let normal_city_name_text = ''
        let normal_temperature_high_text_img = ''
        let normal_temperature_high_separator_img = ''
        let normal_temperature_low_text_img = ''
        let normal_temperature_low_separator_img = ''
        let normal_temperature_current_text_img = ''
        let normal_weather_image_progress_img_level = ''
        let normal_moon_image_progress_img_level = ''
        let normal_battery_text_text_img = ''
        let normal_battery_image_progress_img_level = ''
        let normal_heart_rate_text_text_img = ''
        let normal_heart_rate_image_progress_img_level = ''
        let normal_stress_text_text_img = ''
        let normal_stress_image_progress_img_level = ''
        let normal_distance_text_text_img = ''
        let normal_calorie_current_text_img = ''
        let normal_step_current_text_img = ''
        let normal_step_image_progress_img_level = ''
        let normal_digital_clock_img_time = ''
        let normal_digital_clock_hour_separator_img = ''
        let idle_background_bg = ''
        let idle_system_disconnect_img = ''
        let idle_system_clock_img = ''
        let idle_date_img_date_day = ''
        let idle_temperature_icon_img = ''
        let idle_city_name_text = ''
        let idle_temperature_high_text_img = ''
        let idle_temperature_high_separator_img = ''
        let idle_temperature_low_text_img = ''
        let idle_temperature_low_separator_img = ''
        let idle_temperature_current_text_img = ''
        let idle_weather_image_progress_img_level = ''
        let idle_moon_image_progress_img_level = ''
        let idle_battery_text_text_img = ''
        let idle_heart_rate_text_text_img = ''
        let idle_heart_rate_image_progress_img_level = ''
        let idle_stress_text_text_img = ''
        let idle_stress_image_progress_img_level = ''
        let idle_digital_clock_img_time = ''
        let idle_digital_clock_hour_separator_img = ''
        let normal_sunrise_jumpable_img_click = ''
        let normal_temperature_jumpable_img_click = ''
        let normal_pai_jumpable_img_click = ''
        let normal_heart_jumpable_img_click = ''
        let normal_step_jumpable_img_click = ''
		
		let heart = hmSensor.createSensor(hmSensor.id.HEART);
	    let heartArr = ''
	   
	    function HeartUpdate() {
		   heartArr = heart.today
		   min_heart_txt.setProperty(hmUI.prop.TEXT, Math.min(...heartArr).toString())
		   max_heart_txt.setProperty(hmUI.prop.TEXT, Math.max(...heartArr).toString())
	    }
		
		heart.addEventListener(hmSensor.event.CHANGE, function() { HeartUpdate() })
		
		let sleep_time_txt = ''
		//let sleep_start_time_txt = ''
		//let sleep_end_time_txt = ''
		//let sleep_score_txt = ''

		const sleep = hmSensor.createSensor(hmSensor.id.SLEEP);
		let sleepInfo = sleep.getBasicInfo();
		
		let sleepTotalTime = sleep.getTotalTime();		
		let sleepStartTime = sleepInfo.startTime;
		let sleepEndTime = sleepInfo.endTime + 1;
		let sleepScore = sleepInfo.score;

		function updateSleepInfo() {
			sleepTotalTime = sleep.getTotalTime();
			sleepInfo = sleep.getBasicInfo();
			sleepStartTime = sleepInfo.startTime;
			if (sleepStartTime >= 24*60) {
				sleepStartTime -= 24*60
			}
			
			sleepEndTime = sleepInfo.endTime + 1;
			if (sleepEndTime >= 24*60) {
				sleepEndTime -= 24*60
			}

			sleep_time_txt.setProperty(hmUI.prop.TEXT, '' + Math.floor(sleepTotalTime / 60).toString().padStart(2, "0") + ':' + (sleepTotalTime % 60).toString().padStart(2, "0"));
			//sleep_start_time_txt.setProperty(hmUI.prop.TEXT, Math.floor(sleepStartTime / 60).toString().padStart(2, "0") + ':' + (sleepStartTime % 60).toString().padStart(2, "0"));
			//sleep_end_time_txt.setProperty(hmUI.prop.TEXT, Math.floor(sleepEndTime / 60).toString().padStart(2, "0") + ':' + (sleepEndTime % 60).toString().padStart(2, "0"));
			//sleep_score_txt.setProperty(hmUI.prop.TEXT, 'Очки: ' + String(sleepScore));
		}


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 466,
              h: 466,
              src: '3.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
			
			min_heart_txt = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 171,
              y: 295,
			  w: 100,
			  h: 50,
			  text_size: 24,
			  text: '',
			  color: 0x808080,
              align_h: hmUI.align.CENTR_H,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
			
			max_heart_txt = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 165,
              y: 358,
			  w: 100,
			  h: 50,
			  text_size: 24,
			  text: '',
			  color: 0xff0000,
              align_h: hmUI.align.CENTR_H,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
			
			sleep_time_txt = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 349,
              y: 208,
			  w: 100,
			  h: 50,
			  text_size: 27,
			  text: '',
			  color: 0xffcccc,
              align_h: hmUI.align.CENTR_H,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 118,
              y: 402,
              src: 'bt.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 312,
              y: 405,
              src: 'clock.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_month_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 105,
              month_startY: 307,
              month_sc_array: ["m_1.png","m_2.png","m_3.png","m_4.png","m_5.png","m_6.png","m_7.png","m_8.png","m_9.png","m_10.png","m_11.png","m_12.png"],
              month_tc_array: ["m_1.png","m_2.png","m_3.png","m_4.png","m_5.png","m_6.png","m_7.png","m_8.png","m_9.png","m_10.png","m_11.png","m_12.png"],
              month_en_array: ["m_1.png","m_2.png","m_3.png","m_4.png","m_5.png","m_6.png","m_7.png","m_8.png","m_9.png","m_10.png","m_11.png","m_12.png"],
              month_is_character: true ,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 93,
              y: 354,
              week_en: ["week_1.png","week_2.png","week_3.png","week_4.png","week_5.png","week_6.png","week_7.png"],
              week_tc: ["week_1.png","week_2.png","week_3.png","week_4.png","week_5.png","week_6.png","week_7.png"],
              week_sc: ["week_1.png","week_2.png","week_3.png","week_4.png","week_5.png","week_6.png","week_7.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 49,
              day_startY: 294,
              day_sc_array: ["69.png","70.png","71.png","72.png","73.png","74.png","75.png","76.png","77.png","78.png"],
              day_tc_array: ["69.png","70.png","71.png","72.png","73.png","74.png","75.png","76.png","77.png","78.png"],
              day_en_array: ["69.png","70.png","71.png","72.png","73.png","74.png","75.png","76.png","77.png","78.png"],
              day_zero: 1,
              day_space: -2,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 315,
              y: 90,
              src: 'line.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_city_name_text = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 133,
              y: 167,
              w: 150,
              h: 30,
              text_size: 22,
              char_space: 0,
              line_space: 0,
              color: 0xFFFF8C00,
              align_h: hmUI.align.LEFT,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_high_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 280,
              y: 91,
              font_array: ["n_0.png","n_1.png","n_2.png","n_3.png","n_4.png","n_5.png","n_6.png","n_7.png","n_8.png","n_9.png"],
              padding: false,
              h_space: -2,
              angle: 0,
              negative_image: 'minus1.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_HIGH,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_high_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 259,
              y: 80,
              src: 'max.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_low_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 321,
              y: 91,
              font_array: ["n_0.png","n_1.png","n_2.png","n_3.png","n_4.png","n_5.png","n_6.png","n_7.png","n_8.png","n_9.png"],
              padding: false,
              h_space: -2,
              angle: 0,
              negative_image: 'minus1.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_LOW,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_low_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 354,
              y: 80,
              src: 'min.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 250,
              y: 125,
              font_array: ["f_0.png","f_1.png","f_2.png","f_3.png","f_4.png","f_5.png","f_6.png","f_7.png","f_8.png","f_9.png"],
              padding: false,
              h_space: 0,
              angle: 0,
              unit_sc: 'gradus.png',
              unit_tc: 'gradus.png',
              unit_en: 'gradus.png',
              negative_image: 'minus.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 76,
              y: 23,
              image_array: ["w_1.png","w_2.png","w_3.png","w_4.png","w_5.png","w_6.png","w_7.png","w_8.png","w_9.png","w_10.png","w_11.png","w_12.png","w_13.png","w_14.png","w_15.png","w_16.png","w_17.png","w_18.png","w_19.png","w_20.png","w_21.png","w_22.png","w_23.png","w_24.png","w_25.png","w_26.png","w_27.png","w_28.png","w_29.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_moon_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 23,
              y: 128,
              image_array: ["moon_1.png","moon_2.png","moon_3.png","moon_4.png","moon_5.png","moon_6.png","moon_7.png","moon_8.png","moon_9.png","moon_10.png","moon_11.png","moon_12.png","moon_13.png","moon_14.png","moon_15.png","moon_16.png","moon_17.png","moon_18.png","moon_19.png","moon_20.png","moon_21.png","moon_22.png","moon_23.png","moon_24.png","moon_25.png","moon_26.png","moon_27.png","moon_28.png","moon_29.png","moon_30.png"],
              image_length: 30,
              type: hmUI.data_type.MOON,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 238,
              y: 410,
              font_array: ["f_0.png","f_1.png","f_2.png","f_3.png","f_4.png","f_5.png","f_6.png","f_7.png","f_8.png","f_9.png"],
              padding: false,
              h_space: 0,
              angle: 0,
              unit_sc: 'percent.png',
              unit_tc: 'percent.png',
              unit_en: 'percent.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 166,
              y: 412,
              image_array: ["11.png","12.png","13.png","14.png","15.png","16.png","17.png","18.png","19.png"],
              image_length: 9,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 249,
              y: 320,
              font_array: ["f_0.png","f_1.png","f_2.png","f_3.png","f_4.png","f_5.png","f_6.png","f_7.png","f_8.png","f_9.png"],
              padding: false,
              h_space: -1,
              angle: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 167,
              y: 328,
              image_array: ["heart_0.png","heart_1.png","heart_2.png","heart_3.png","heart_4.png","heart_5.png"],
              image_length: 6,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_stress_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 340,
              y: 362,
              font_array: ["f_0.png","f_1.png","f_2.png","f_3.png","f_4.png","f_5.png","f_6.png","f_7.png","f_8.png","f_9.png"],
              padding: false,
              h_space: -2,
              angle: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STRESS,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_stress_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 309,
              y: 357,
              image_array: ["stress1.png","stress2.png","stress3.png","stress4.png","stress5.png"],
              image_length: 5,
              type: hmUI.data_type.STRESS,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_distance_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 338,
              y: 320,
              font_array: ["f_0.png","f_1.png","f_2.png","f_3.png","f_4.png","f_5.png","f_6.png","f_7.png","f_8.png","f_9.png"],
              padding: false,
              h_space: -1,
              angle: 0,
              dot_image: 'dot.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.DISTANCE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_calorie_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 343,
              y: 264,
              font_array: ["f_0.png","f_1.png","f_2.png","f_3.png","f_4.png","f_5.png","f_6.png","f_7.png","f_8.png","f_9.png"],
              padding: false,
              h_space: 0,
              angle: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 346,
              y: 175,
              font_array: ["f_0.png","f_1.png","f_2.png","f_3.png","f_4.png","f_5.png","f_6.png","f_7.png","f_8.png","f_9.png"],
              padding: false,
              h_space: -1,
              angle: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 277,
              y: 136,
              image_array: ["5PTCircle0001.png","5PTCircle0002.png","5PTCircle0003.png","5PTCircle0004.png","5PTCircle0005.png","5PTCircle0006.png","5PTCircle0007.png","5PTCircle0008.png","5PTCircle0009.png","5PTCircle0010.png","5PTCircle0011.png","5PTCircle0012.png","5PTCircle0013.png","5PTCircle0014.png","5PTCircle0015.png","5PTCircle0016.png","5PTCircle0017.png","5PTCircle0018.png","5PTCircle0019.png","5PTCircle0020.png"],
              image_length: 20,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 10,
              hour_startY: 195,
              hour_array: ["101.png","102.png","103.png","104.png","105.png","106.png","107.png","108.png","109.png","110.png"],
              hour_zero: 1,
              hour_space: -25,
              hour_angle: 0,
              hour_align: hmUI.align.LEFT,

              minute_startX: 152,
              minute_startY: 195,
              minute_array: ["101.png","102.png","103.png","104.png","105.png","106.png","107.png","108.png","109.png","110.png"],
              minute_zero: 1,
              minute_space: -25,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_hour_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 148,
              y: 202,
              src: '111.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            idle_background_bg = hmUI.createWidget(hmUI.widget.FILL_RECT, {
              x: 0,
              y: 0,
              w: 466,
              h: 466,
              color: '0xFF000000',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 400,
              y: 190,
              src: 'bt.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 402,
              y: 257,
              src: 'clock.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 55,
              day_startY: 294,
              day_sc_array: ["69.png","70.png","71.png","72.png","73.png","74.png","75.png","76.png","77.png","78.png"],
              day_tc_array: ["69.png","70.png","71.png","72.png","73.png","74.png","75.png","76.png","77.png","78.png"],
              day_en_array: ["69.png","70.png","71.png","72.png","73.png","74.png","75.png","76.png","77.png","78.png"],
              day_zero: 1,
              day_space: -2,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_temperature_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 315,
              y: 90,
              src: 'line.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_city_name_text = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 133,
              y: 167,
              w: 150,
              h: 30,
              text_size: 22,
              char_space: 0,
              line_space: 0,
              color: 0xFFFF8C00,
              align_h: hmUI.align.LEFT,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_temperature_high_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 280,
              y: 91,
              font_array: ["n_0.png","n_1.png","n_2.png","n_3.png","n_4.png","n_5.png","n_6.png","n_7.png","n_8.png","n_9.png"],
              padding: false,
              h_space: -2,
              angle: 0,
              negative_image: 'minus1.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_HIGH,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_temperature_high_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 259,
              y: 80,
              src: 'max.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_temperature_low_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 321,
              y: 91,
              font_array: ["n_0.png","n_1.png","n_2.png","n_3.png","n_4.png","n_5.png","n_6.png","n_7.png","n_8.png","n_9.png"],
              padding: false,
              h_space: -2,
              angle: 0,
              negative_image: 'minus1.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_LOW,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_temperature_low_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 354,
              y: 80,
              src: 'min.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 250,
              y: 125,
              font_array: ["f_0.png","f_1.png","f_2.png","f_3.png","f_4.png","f_5.png","f_6.png","f_7.png","f_8.png","f_9.png"],
              padding: false,
              h_space: 0,
              angle: 0,
              unit_sc: 'gradus.png',
              unit_tc: 'gradus.png',
              unit_en: 'gradus.png',
              negative_image: 'minus.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 76,
              y: 23,
              image_array: ["w_1.png","w_2.png","w_3.png","w_4.png","w_5.png","w_6.png","w_7.png","w_8.png","w_9.png","w_10.png","w_11.png","w_12.png","w_13.png","w_14.png","w_15.png","w_16.png","w_17.png","w_18.png","w_19.png","w_20.png","w_21.png","w_22.png","w_23.png","w_24.png","w_25.png","w_26.png","w_27.png","w_28.png","w_29.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_moon_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 23,
              y: 128,
              image_array: ["moon_1.png","moon_2.png","moon_3.png","moon_4.png","moon_5.png","moon_6.png","moon_7.png","moon_8.png","moon_9.png","moon_10.png","moon_11.png","moon_12.png","moon_13.png","moon_14.png","moon_15.png","moon_16.png","moon_17.png","moon_18.png","moon_19.png","moon_20.png","moon_21.png","moon_22.png","moon_23.png","moon_24.png","moon_25.png","moon_26.png","moon_27.png","moon_28.png","moon_29.png","moon_30.png"],
              image_length: 30,
              type: hmUI.data_type.MOON,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 203,
              y: 433,
              font_array: ["f_0.png","f_1.png","f_2.png","f_3.png","f_4.png","f_5.png","f_6.png","f_7.png","f_8.png","f_9.png"],
              padding: false,
              h_space: 0,
              angle: 0,
              unit_sc: 'percent.png',
              unit_tc: 'percent.png',
              unit_en: 'percent.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 205,
              y: 336,
              font_array: ["f_0.png","f_1.png","f_2.png","f_3.png","f_4.png","f_5.png","f_6.png","f_7.png","f_8.png","f_9.png"],
              padding: false,
              h_space: -1,
              angle: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_heart_rate_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 167,
              y: 328,
              image_array: ["heart_0.png","heart_1.png","heart_2.png","heart_3.png","heart_4.png","heart_5.png"],
              image_length: 6,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_stress_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 340,
              y: 362,
              font_array: ["f_0.png","f_1.png","f_2.png","f_3.png","f_4.png","f_5.png","f_6.png","f_7.png","f_8.png","f_9.png"],
              padding: false,
              h_space: -2,
              angle: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STRESS,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_stress_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 309,
              y: 357,
              image_array: ["stress1.png","stress2.png","stress3.png","stress4.png","stress5.png"],
              image_length: 5,
              type: hmUI.data_type.STRESS,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 10,
              hour_startY: 195,
              hour_array: ["101.png","102.png","103.png","104.png","105.png","106.png","107.png","108.png","109.png","110.png"],
              hour_zero: 1,
              hour_space: -25,
              hour_angle: 0,
              hour_align: hmUI.align.LEFT,

              minute_startX: 152,
              minute_startY: 195,
              minute_array: ["101.png","102.png","103.png","104.png","105.png","106.png","107.png","108.png","109.png","110.png"],
              minute_zero: 1,
              minute_space: -25,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_hour_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 148,
              y: 202,
              src: '111.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            normal_sunrise_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 29,
              y: 135,
              w: 50,
              h: 50,
              src: 'Empty.png',
              type: hmUI.data_type.MOON_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 140,
              y: 55,
              w: 100,
              h: 100,
              src: 'Empty.png',
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            hmUI.createWidget(hmUI.widget.BUTTON, {
				 x: 60,      
				 y: 293,      
				 w: 100,       
				 h: 100,   
				 text: '',      
				 normal_src: 'Empty.png',      
				 press_src: 'Empty.png', 
				 click_func: () => {
				hmApp.startApp({ url: 'ScheduleCalScreen', native: true });   
				 },
				 show_level: hmUI.show_level.ONLY_NORMAL,
			});

            normal_heart_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 190,
              y: 293,
              w: 100,
              h: 100,
              src: 'Empty.png',
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 325,
              y: 152,
              w: 100,
              h: 50,
              src: 'Empty.png',
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            function scale_call() {

              console.log('Weather city name');
              const weatherSensor = hmSensor.createSensor(hmSensor.id.WEATHER);
              const weatherData = weatherSensor.getForecastWeather();
              normal_city_name_text.setProperty(hmUI.prop.TEXT, weatherData.cityName);

              console.log('Weather city name');
              idle_city_name_text.setProperty(hmUI.prop.TEXT, weatherData.cityName);

            };

            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                updateSleepInfo();
				HeartUpdate ()
				scale_call();
              }),
            });

                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}