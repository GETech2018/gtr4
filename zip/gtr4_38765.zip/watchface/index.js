﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        const logger = Logger.getLogger('watchface_SashaCX75');
        //end of ignored block

        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_pai_circle_scale = ''
        let normal_pai_day_text_img = ''
        let normal_distance_text_text_img = ''
        let normal_system_disconnect_img = ''
        let normal_calorie_circle_scale = ''
        let normal_calorie_current_text_img = ''
        let normal_heart_rate_text_text_img = ''
        let normal_sun_pointer_progress_img_pointer = ''
        let normal_sun_icon_img = ''
        let normal_sun_current_text_img = ''
        let normal_fat_burning_circle_scale = ''
        let normal_fat_burning_current_text_img = ''
        let normal_stand_circle_scale = ''
        let normal_stand_current_text_img = ''
        let normal_step_circle_scale = ''
        let normal_step_current_text_img = ''
        let normal_spo2_icon_img = ''
        let normal_stress_icon_img = ''
        let normal_date_img_date_week_img = ''
        let normal_date_img_date_month_img = ''
        let normal_date_img_date_day = ''
        let normal_date_day_separator_img = ''
        let normal_analog_clock_time_pointer_hour = ''
        let normal_analog_clock_time_pointer_minute = ''
        let normal_analog_clock_time_pointer_second = ''
        let idle_background_bg = ''
        let idle_battery_text_text_img = ''
        let idle_battery_text_separator_img = ''
        let idle_system_disconnect_img = ''
        let idle_date_img_date_week_img = ''
        let idle_date_img_date_month_img = ''
        let idle_date_img_date_day = ''
        let idle_date_day_separator_img = ''
        let idle_analog_clock_time_pointer_hour = ''
        let idle_analog_clock_time_pointer_minute = ''
        let normal_heart_jumpable_img_click = ''
		
		let heart = hmSensor.createSensor(hmSensor.id.HEART);
        let heartArr = ''

        function HeartUpdate() {
          heartArr = heart.today
          min_heart_txt.setProperty(hmUI.prop.TEXT, Math.min(...heartArr).toString())
          max_heart_txt.setProperty(hmUI.prop.TEXT, Math.max(...heartArr).toString())
        }

        heart.addEventListener(hmSensor.event.CHANGE, function () {
          HeartUpdate()
        })
		
		let btn_zona1 = ''
        let zona1_num = 0
        let zona1_all = 1
		
		function click_zona1() {
		  zona1_num = (zona1_num + 1) % (zona1_all + 1);
          if (zona1_num == 0) {		
		    normal_sun_pointer_progress_img_pointer.setProperty(hmUI.prop.VISIBLE, true);
            normal_sun_current_text_img.setProperty(hmUI.prop.VISIBLE, true);
		    normal_moon_pointer_progress_img_pointer.setProperty(hmUI.prop.VISIBLE, false);
            normal_moon_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
		    hmUI.showToast({
				text: 'Солнце'
            });
          };
		  
		 if (zona1_num == 1) {
			normal_sun_pointer_progress_img_pointer.setProperty(hmUI.prop.VISIBLE, false);
            normal_sun_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
		    normal_moon_pointer_progress_img_pointer.setProperty(hmUI.prop.VISIBLE, true);
            normal_moon_current_text_img.setProperty(hmUI.prop.VISIBLE, true);
		    hmUI.showToast({
				text: 'Луна'
            });
          };
        }
		
		let btn_zona2 = ''
        let zona2_num = 0
        let zona2_all = 1
		
		function click_zona2() {
		  zona2_num = (zona2_num + 1) % (zona2_all + 1);
          if (zona2_num == 0) {		
		    normal_stress_icon_img.setProperty(hmUI.prop.VISIBLE, true);
			normal_step_current_text_img.setProperty(hmUI.prop.VISIBLE, true);
            normal_fat_burning_circle_scale.setProperty(hmUI.prop.VISIBLE, true);
			normal_fat_burning_current_text_img.setProperty(hmUI.prop.VISIBLE, true);
			normal_stand_circle_scale.setProperty(hmUI.prop.VISIBLE, true);
			normal_stand_current_text_img.setProperty(hmUI.prop.VISIBLE, true);
			normal_spo2_icon_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_distance_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_calorie_circle_scale.setProperty(hmUI.prop.VISIBLE, false);
			normal_calorie_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_pai_circle_scale.setProperty(hmUI.prop.VISIBLE, false);
			normal_pai_day_text_img.setProperty(hmUI.prop.VISIBLE, false);
		    hmUI.showToast({
            });
          };
		  
		 if (zona2_num == 1) {
			normal_stress_icon_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_step_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
            normal_fat_burning_circle_scale.setProperty(hmUI.prop.VISIBLE, false);
			normal_fat_burning_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_stand_circle_scale.setProperty(hmUI.prop.VISIBLE, false);
			normal_stand_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_spo2_icon_img.setProperty(hmUI.prop.VISIBLE, true);
			normal_distance_text_text_img.setProperty(hmUI.prop.VISIBLE, true);
			normal_calorie_circle_scale.setProperty(hmUI.prop.VISIBLE, true);
			normal_calorie_current_text_img.setProperty(hmUI.prop.VISIBLE, true);
			normal_pai_circle_scale.setProperty(hmUI.prop.VISIBLE, true);
			normal_pai_day_text_img.setProperty(hmUI.prop.VISIBLE, true);
		    hmUI.showToast({
            });
          };
        }
		
		let bot_circle_btn = ''
        let bot_circle_state = 0 
        let bot_circle_state_txt = ''

        function click_bot_circle_Switcher() {

          let bot_circle_state_total = 3;

          bot_circle_state = (bot_circle_state + 1) % bot_circle_state_total;

          switch (bot_circle_state) {

              case 0:
 
                  normal_analog_clock_time_pointer_hour.setProperty(hmUI.prop.MORE, {
                    hour_path: 'h_1.png',
                    hour_centerX: 233,
                    hour_centerY: 233,
                    hour_posX: 17,
                    hour_posY: 148,
                    show_level: hmUI.show_level.ONLY_NORMAL,
                  });
      
                  normal_analog_clock_time_pointer_minute.setProperty(hmUI.prop.MORE, {
                    minute_path: 'm_2.png',
                    minute_centerX: 233,
                    minute_centerY: 233,
                    minute_posX: 21,
                    minute_posY: 228,
                    show_level: hmUI.show_level.ONLY_NORMAL,
                  });
				  
				  normal_analog_clock_time_pointer_second.setProperty(hmUI.prop.MORE, {
                    second_path: 's2.png',
                    second_centerX: 233,
                    second_centerY: 233,
                    second_posX: 15,
                    second_posY: 236,
                    show_level: hmUI.show_level.ONLY_NORMAL,
                  });
      
                  bot_circle_state_txt = 'Стрелки 1';
                  break;

              case 1:

                normal_analog_clock_time_pointer_hour.setProperty(hmUI.prop.MORE, {
                  hour_path: 'h2.png',
                  hour_centerX: 233,
                  hour_centerY: 233,
                  hour_posX: 22,
                  hour_posY: 156,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });
    
                normal_analog_clock_time_pointer_minute.setProperty(hmUI.prop.MORE, {
                  minute_path: 'm2.png',
                  minute_centerX: 233,
                  minute_centerY: 233,
                  minute_posX: 37,
                  minute_posY: 257,
                 show_level: hmUI.show_level.ONLY_NORMAL,
                });
				
				normal_analog_clock_time_pointer_second.setProperty(hmUI.prop.MORE, {
                    second_path: 's2.png',
                    second_centerX: 233,
                    second_centerY: 233,
                    second_posX: 15,
                    second_posY: 236,
                    show_level: hmUI.show_level.ONLY_NORMAL,
                  });
   
              bot_circle_state_txt = 'Стрелки 2';
                  break;

              case 2:

                    normal_analog_clock_time_pointer_hour.setProperty(hmUI.prop.MORE, {
                      hour_path: 'h_3.png',
                      hour_centerX: 233,
                      hour_centerY: 233,
                      hour_posX: 38,
                      hour_posY: 223,
                      show_level: hmUI.show_level.ONLY_NORMAL,
                    });
        
                    normal_analog_clock_time_pointer_minute.setProperty(hmUI.prop.MORE, {
                      minute_path: 'm_3.png',
                      minute_centerX: 233,
                      minute_centerY: 233,
                      minute_posX: 45,
                      minute_posY: 250,
                      show_level: hmUI.show_level.ONLY_NORMAL,
                    });
					
					normal_analog_clock_time_pointer_second.setProperty(hmUI.prop.MORE, {
                      second_path: 's_3.png',
                      second_centerX: 233,
                      second_centerY: 233,
                      second_posX: 24,
                      second_posY: 248,
                    show_level: hmUI.show_level.ONLY_NORMAL,
                  });
       
                  bot_circle_state_txt = 'Стрелки 3';
              break;
    
              default:
                  break;
          }

          hmUI.showToast({ text: bot_circle_state_txt });
      }


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            console.log('Watch_Face.ScreenNormal');
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 466,
              h: 466,
              src: 'bg_ru.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_pai_weekly_circle_scale = hmUI.createWidget(hmUI.widget.Circle_Scale, {
              // center_x: 113,
              // center_y: 222,
              // start_angle: 175,
              // end_angle: 300,
              // radius: 61,
              // line_width: 7,
              // line_cap: Rounded,
              // color: 0xFF31BCFF,
              // mirror: False,
              // inversion: False,
              // type: hmUI.data_type.PAI_WEEKLY,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            let screenType = hmSetting.getScreenType();
            normal_pai_circle_scale = hmUI.createWidget(hmUI.widget.ARC_PROGRESS, {
              center_x: 113,
              center_y: 222,
              start_angle: 175,
              end_angle: 300,
              radius: 58,
              line_width: 7,
              corner_flag: 0,
              color: 0xFF31BCFF,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            
            const pai = hmSensor.createSensor(hmSensor.id.PAI);
            pai.addEventListener(hmSensor.event.CHANGE, function() {
              scale_call();
            });

            normal_pai_day_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 91,
              y: 243,
              font_array: ["blue_0.png","blue_1.png","blue_2.png","blue_3.png","blue_4.png","blue_5.png","blue_6.png","blue_7.png","blue_8.png","blue_9.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.PAI_DAILY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_distance_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 83,
              y: 184,
              font_array: ["pink_0.png","pink_1.png","pink_2.png","pink_3.png","pink_4.png","pink_5.png","pink_6.png","pink_7.png","pink_8.png","pink_9.png"],
              padding: false,
              h_space: -2,
              dot_image: 'dot_1.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.DISTANCE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 225,
              y: 39,
              src: 'bt.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_cal_circle_scale = hmUI.createWidget(hmUI.widget.Circle_Scale, {
              // center_x: 119,
              // center_y: 223,
              // start_angle: 57,
              // end_angle: 188,
              // radius: 59,
              // line_width: 7,
              // line_cap: Rounded,
              // color: 0xFFFFA64D,
              // mirror: False,
              // inversion: False,
              // type: hmUI.data_type.CAL,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_calorie_circle_scale = hmUI.createWidget(hmUI.widget.ARC_PROGRESS, {
              center_x: 119,
              center_y: 223,
              start_angle: 57,
              end_angle: 188,
              radius: 56,
              line_width: 7,
              corner_flag: 0,
              color: 0xFFFFA64D,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            
            const calorie = hmSensor.createSensor(hmSensor.id.CALORIE);
            calorie.addEventListener(hmSensor.event.CHANGE, function() {
              scale_call();
            });

            normal_calorie_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 84,
              y: 213,
              font_array: ["cal_0.png","cal_1.png","cal_2.png","cal_3.png","cal_4.png","cal_5.png","cal_6.png","cal_7.png","cal_8.png","cal_9.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 211,
              y: 407,
              font_array: ["font_0.png","font_1.png","font_2.png","font_3.png","font_4.png","font_5.png","font_6.png","font_7.png","font_8.png","font_9.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
			
			min_heart_txt = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 322,
              y: 355,
              w: 50,
              h: 50,
              text_size: 20,
              text: '',
              color: 0xffffff,
              align_h: hmUI.align.RIGHT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            max_heart_txt = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 351,
              y: 305,
              w: 50,
              h: 50,
              text_size: 20,
              text: '',
              color: 0xffffff,
              align_h: hmUI.align.CENTR,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
			
			hmUI.createWidget(hmUI.widget.GRADKIENT_POLYLINE, {
              x: 97,
              y: 314,
              w: 250,
              h: 63,
              line_color: 0xcc2124,
              line_width: 3,
			  color_from:0x7fFF6452,
              color_to:0x7fFF6452,
              curve_style: true,
              type: hmUI.data_type.HEART
            });

            normal_sun_pointer_progress_img_pointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
              src: 'sun7.png',
              center_x: 352,
              center_y: 221,
              x: 22,
              y: 49,
              start_angle: -102,
              end_angle: 101,
              invalid_visible: false,
              type: hmUI.data_type.SUN_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
			
			normal_moon_pointer_progress_img_pointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
              src: 'moon7.png',
              center_x: 352,
              center_y: 221,
              x: 22,
              y: 49,
              start_angle: -102,
              end_angle: 101,
			  invalid_visible: false,
              type: hmUI.data_type.MOON_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sun_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 288,
              y: 154,
              src: 'mask.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sun_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 326,
              y: 229,
              font_array: ["fnt_0.png","fnt_1.png","fnt_2.png","fnt_3.png","fnt_4.png","fnt_5.png","fnt_6.png","fnt_7.png","fnt_8.png","fnt_9.png"],
              padding: false,
              h_space: 0,
              dot_image: 'dot.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.SUN_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
			
			normal_moon_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 326,
              y: 229,
              font_array: ["fnt_0.png","fnt_1.png","fnt_2.png","fnt_3.png","fnt_4.png","fnt_5.png","fnt_6.png","fnt_7.png","fnt_8.png","fnt_9.png"],
              padding: false,
              h_space: 0,
              dot_image: 'dot.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.MOON_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_fat_burning_circle_scale = hmUI.createWidget(hmUI.widget.Circle_Scale, {
              // center_x: 119,
              // center_y: 223,
              // start_angle: 57,
              // end_angle: 188,
              // radius: 59,
              // line_width: 7,
              // line_cap: Rounded,
              // color: 0xFF008040,
              // mirror: False,
              // inversion: False,
              // type: hmUI.data_type.FAT_BURNING,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_fat_burning_circle_scale = hmUI.createWidget(hmUI.widget.ARC_PROGRESS, {
              center_x: 119,
              center_y: 223,
              start_angle: 57,
              end_angle: 188,
              radius: 56,
              line_width: 7,
              corner_flag: 0,
              color: 0xFF008040,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            
            const fat_burning = hmSensor.createSensor(hmSensor.id.FAT_BURRING);
            fat_burning.addEventListener(hmSensor.event.CHANGE, function() {
              scale_call();
            });

            normal_fat_burning_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 90,
              y: 213,
              font_array: ["green_0.png","green_1.png","green_2.png","green_3.png","green_4.png","green_5.png","green_6.png","green_7.png","green_8.png","green_9.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.FAT_BURNING,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_stand_circle_scale = hmUI.createWidget(hmUI.widget.Circle_Scale, {
              // center_x: 113,
              // center_y: 222,
              // start_angle: 175,
              // end_angle: 300,
              // radius: 61,
              // line_width: 7,
              // line_cap: Rounded,
              // color: 0xFF0080C0,
              // mirror: False,
              // inversion: False,
              // type: hmUI.data_type.STAND,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_stand_circle_scale = hmUI.createWidget(hmUI.widget.ARC_PROGRESS, {
              center_x: 113,
              center_y: 222,
              start_angle: 175,
              end_angle: 300,
              radius: 58,
              line_width: 7,
              corner_flag: 0,
              color: 0xFF0080C0,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            
            const stand = hmSensor.createSensor(hmSensor.id.STAND);
            stand.addEventListener(hmSensor.event.CHANGE, function() {
              scale_call();
            });

            normal_stand_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 99,
              y: 243,
              font_array: ["blue_0.png","blue_1.png","blue_2.png","blue_3.png","blue_4.png","blue_5.png","blue_6.png","blue_7.png","blue_8.png","blue_9.png"],
              padding: true,
              h_space: 0,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.STAND,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_step_circle_scale = hmUI.createWidget(hmUI.widget.Circle_Scale, {
              // center_x: 114,
              // center_y: 218,
              // start_angle: -55,
              // end_angle: 60,
              // radius: 61,
              // line_width: 7,
              // line_cap: Rounded,
              // color: 0xFFB9005C,
              // mirror: False,
              // inversion: False,
              // type: hmUI.data_type.STEP,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_step_circle_scale = hmUI.createWidget(hmUI.widget.ARC_PROGRESS, {
              center_x: 114,
              center_y: 218,
              start_angle: -55,
              end_angle: 60,
              radius: 58,
              line_width: 7,
              corner_flag: 0,
              color: 0xFFB9005C,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            
            const step = hmSensor.createSensor(hmSensor.id.STEP);
            step.addEventListener(hmSensor.event.CHANGE, function() {
              scale_call();
            });

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 79,
              y: 184,
              font_array: ["pink_0.png","pink_1.png","pink_2.png","pink_3.png","pink_4.png","pink_5.png","pink_6.png","pink_7.png","pink_8.png","pink_9.png"],
              padding: false,
              h_space: -2,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_spo2_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 51,
              y: 157,
              src: 'icon_2.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_stress_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 51,
              y: 157,
              src: 'IMG_20230627_182937_401.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 243,
              y: 125,
              week_en: ["weekru_1.png","weekru_2.png","weekru_3.png","weekru_4.png","weekru_5.png","weekru_6.png","weekru_7.png"],
              week_tc: ["weekru_1.png","weekru_2.png","weekru_3.png","weekru_4.png","weekru_5.png","weekru_6.png","weekru_7.png"],
              week_sc: ["weekru_1.png","weekru_2.png","weekru_3.png","weekru_4.png","weekru_5.png","weekru_6.png","weekru_7.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_month_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 165,
              month_startY: 125,
              month_sc_array: ["month_1.png","month_2.png","month_3.png","month_4.png","month_5.png","month_6.png","month_7.png","month_8.png","month_9.png","month_10.png","month_11.png","month_12.png"],
              month_tc_array: ["month_1.png","month_2.png","month_3.png","month_4.png","month_5.png","month_6.png","month_7.png","month_8.png","month_9.png","month_10.png","month_11.png","month_12.png"],
              month_en_array: ["month_1.png","month_2.png","month_3.png","month_4.png","month_5.png","month_6.png","month_7.png","month_8.png","month_9.png","month_10.png","month_11.png","month_12.png"],
              month_is_character: true ,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 209,
              day_startY: 53,
              day_sc_array: ["date_0.png","date_1.png","date_2.png","date_3.png","date_4.png","date_5.png","date_6.png","date_7.png","date_8.png","date_9.png"],
              day_tc_array: ["date_0.png","date_1.png","date_2.png","date_3.png","date_4.png","date_5.png","date_6.png","date_7.png","date_8.png","date_9.png"],
              day_en_array: ["date_0.png","date_1.png","date_2.png","date_3.png","date_4.png","date_5.png","date_6.png","date_7.png","date_8.png","date_9.png"],
              day_zero: 1,
              day_space: 0,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_day_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 228,
              y: 120,
              src: 'unit.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_hour = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              hour_path: 'h_1.png',
              hour_centerX: 233,
              hour_centerY: 233,
              hour_posX: 17,
              hour_posY: 148,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_minute = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              minute_path: 'm_2.png',
              minute_centerX: 233,
              minute_centerY: 233,
              minute_posX: 21,
              minute_posY: 228,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_second = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              second_path: 's2.png',
              second_centerX: 233,
              second_centerY: 233,
              second_posX: 15,
              second_posY: 236,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            console.log('Watch_Face.ScreenAOD');
            idle_background_bg = hmUI.createWidget(hmUI.widget.FILL_RECT, {
              x: 0,
              y: 0,
              w: 466,
              h: 466,
              color: '0xFF000000',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 216,
              y: 429,
              font_array: ["font_0.png","font_1.png","font_2.png","font_3.png","font_4.png","font_5.png","font_6.png","font_7.png","font_8.png","font_9.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'bfh.png',
              unit_tc: 'bfh.png',
              unit_en: 'bfh.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_battery_text_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 223,
              y: 395,
              src: 'power.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 226,
              y: 30,
              src: 'bt.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 243,
              y: 125,
              week_en: ["weekru_1.png","weekru_2.png","weekru_3.png","weekru_4.png","weekru_5.png","weekru_6.png","weekru_7.png"],
              week_tc: ["weekru_1.png","weekru_2.png","weekru_3.png","weekru_4.png","weekru_5.png","weekru_6.png","weekru_7.png"],
              week_sc: ["weekru_1.png","weekru_2.png","weekru_3.png","weekru_4.png","weekru_5.png","weekru_6.png","weekru_7.png"],
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_month_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 165,
              month_startY: 125,
              month_sc_array: ["month_1.png","month_2.png","month_3.png","month_4.png","month_5.png","month_6.png","month_7.png","month_8.png","month_9.png","month_10.png","month_11.png","month_12.png"],
              month_tc_array: ["month_1.png","month_2.png","month_3.png","month_4.png","month_5.png","month_6.png","month_7.png","month_8.png","month_9.png","month_10.png","month_11.png","month_12.png"],
              month_en_array: ["month_1.png","month_2.png","month_3.png","month_4.png","month_5.png","month_6.png","month_7.png","month_8.png","month_9.png","month_10.png","month_11.png","month_12.png"],
              month_is_character: true ,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 207,
              day_startY: 54,
              day_sc_array: ["date_0.png","date_1.png","date_2.png","date_3.png","date_4.png","date_5.png","date_6.png","date_7.png","date_8.png","date_9.png"],
              day_tc_array: ["date_0.png","date_1.png","date_2.png","date_3.png","date_4.png","date_5.png","date_6.png","date_7.png","date_8.png","date_9.png"],
              day_en_array: ["date_0.png","date_1.png","date_2.png","date_3.png","date_4.png","date_5.png","date_6.png","date_7.png","date_8.png","date_9.png"],
              day_zero: 1,
              day_space: 0,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_day_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 228,
              y: 120,
              src: 'unit.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_analog_clock_time_pointer_hour = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              hour_path: 'h2.png',
              hour_centerX: 233,
              hour_centerY: 233,
              hour_posX: 22,
              hour_posY: 156,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_analog_clock_time_pointer_minute = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              minute_path: 'm2.png',
              minute_centerX: 233,
              minute_centerY: 233,
              minute_posX: 37,
              minute_posY: 257,
              show_level: hmUI.show_level.ONLY_AOD,
            });
            console.log('Watch_Face.Shortcuts');

            bot_circle_btn = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 201,
              y: 201,
              text: '',
              w: 68,
              h: 68,
              normal_src: 'Empty.png',
              press_src: 'Empty.png',
              click_func: () => {
                  click_bot_circle_Switcher();
              },
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            bot_circle_btn.setProperty(hmUI.prop.VISIBLE, true);

            hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 185,
              y: 111, 
              text: '',
              w: 100, 
              h: 50, 
              normal_src: 'Empty.png',
              press_src: 'Empty.png',
               click_func: () => {
              hmApp.startApp({ url: 'ScheduleCalScreen', native: true });
              },
               longpress_func: () => {
              hmApp.startApp({ url: 'todoListScreen', native: true });
              },
                show_level: hmUI.show_level.ONLY_NORMAL,
            });

           btn_zona1 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 310, 
              y: 175, 
              text: '',
              w: 100, 
              h: 100, 
              normal_src: 'Empty.png',
              press_src: 'Empty.png',
              click_func: () => {
				click_zona1();
                click_Vibrate();
              },
			  longpress_func: () => {
             hmApp.startApp({ url: "TideScreen", native: true });
             },
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            btn_zona1.setProperty(hmUI.prop.VISIBLE, true);
			normal_moon_pointer_progress_img_pointer.setProperty(hmUI.prop.VISIBLE, false);
            normal_moon_current_text_img.setProperty(hmUI.prop.VISIBLE, false);

            normal_heart_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 170,
              y: 319,
              w: 126,
              h: 49,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            btn_zona2 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 67, 
              y: 180, 
              text: '',
              w: 100, 
              h: 100, 
              normal_src: 'Empty.png',
              press_src: 'Empty.png',
              click_func: () => {
				click_zona2();
                click_Vibrate();
			  },
			  longpress_func: () => {
             hmApp.startApp({ url: "activityAppScreen", native: true });
             },
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            btn_zona2.setProperty(hmUI.prop.VISIBLE, true);
			normal_spo2_icon_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_distance_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_calorie_circle_scale.setProperty(hmUI.prop.VISIBLE, false);
			normal_calorie_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_pai_circle_scale.setProperty(hmUI.prop.VISIBLE, false);
			normal_pai_day_text_img.setProperty(hmUI.prop.VISIBLE, false);

            function scale_call() {
              console.log('scale_call()');

                console.log('update scales PAI');
                
                let valuePAI = pai.totalpai;
                let targetPAI = 100;
                let progressPAI = valuePAI/targetPAI;
                if (progressPAI > 1) progressPAI = 1;
                let progress_cs_normal_pai = progressPAI;

                if (screenType != hmSetting.screen_type.AOD) {

                  // normal_pai_circle_scale_circle_scale
                  let level = Math.round(progress_cs_normal_pai * 100);
                  if (normal_pai_circle_scale) {
                    normal_pai_circle_scale.setProperty(hmUI.prop.MORE, {                      
                      center_x: 113,
                      center_y: 222,
                      start_angle: 175,
                      end_angle: 300,
                      radius: 58,
                      line_width: 7,
                      corner_flag: 0,
                      color: 0xFF31BCFF,
                      show_level: hmUI.show_level.ONLY_NORMAL,
                      level: level,
                    });
                  };
                };

                console.log('update scales CALORIE');
                
                let valueCalories = calorie.current;
                let targetCalories = calorie.target;
                let progressCalories = valueCalories/targetCalories;
                if (progressCalories > 1) progressCalories = 1;
                let progress_cs_normal_calorie = progressCalories;

                if (screenType != hmSetting.screen_type.AOD) {

                  // normal_calorie_circle_scale_circle_scale
                  let level = Math.round(progress_cs_normal_calorie * 100);
                  if (normal_calorie_circle_scale) {
                    normal_calorie_circle_scale.setProperty(hmUI.prop.MORE, {                      
                      center_x: 119,
                      center_y: 223,
                      start_angle: 57,
                      end_angle: 188,
                      radius: 56,
                      line_width: 7,
                      corner_flag: 0,
                      color: 0xFFFFA64D,
                      show_level: hmUI.show_level.ONLY_NORMAL,
                      level: level,
                    });
                  };
                };

                console.log('update scales FAT_BURNING');
                
                let valueFatBurning = fat_burning.current;
                let targetFatBurning = fat_burning.target;
                let progressFatBurning = valueFatBurning/targetFatBurning;
                if (progressFatBurning > 1) progressFatBurning = 1;
                let progress_cs_normal_fat_burning = progressFatBurning;

                if (screenType != hmSetting.screen_type.AOD) {

                  // normal_fat_burning_circle_scale_circle_scale
                  let level = Math.round(progress_cs_normal_fat_burning * 100);
                  if (normal_fat_burning_circle_scale) {
                    normal_fat_burning_circle_scale.setProperty(hmUI.prop.MORE, {                      
                      center_x: 119,
                      center_y: 223,
                      start_angle: 57,
                      end_angle: 188,
                      radius: 56,
                      line_width: 7,
                      corner_flag: 0,
                      color: 0xFF008040,
                      show_level: hmUI.show_level.ONLY_NORMAL,
                      level: level,
                    });
                  };
                };

                console.log('update scales STAND');
                
                let valueStand = stand.current;
                let targetStand = stand.target;
                let progressStand = valueStand/targetStand;
                if (progressStand > 1) progressStand = 1;
                let progress_cs_normal_stand = progressStand;

                if (screenType != hmSetting.screen_type.AOD) {

                  // normal_stand_circle_scale_circle_scale
                  let level = Math.round(progress_cs_normal_stand * 100);
                  if (normal_stand_circle_scale) {
                    normal_stand_circle_scale.setProperty(hmUI.prop.MORE, {                      
                      center_x: 113,
                      center_y: 222,
                      start_angle: 175,
                      end_angle: 300,
                      radius: 58,
                      line_width: 7,
                      corner_flag: 0,
                      color: 0xFF0080C0,
                      show_level: hmUI.show_level.ONLY_NORMAL,
                      level: level,
                    });
                  };
                };

                console.log('update scales STEP');
                
                let valueStep = step.current;
                let targetStep = step.target;
                let progressStep = valueStep/targetStep;
                if (progressStep > 1) progressStep = 1;
                let progress_cs_normal_step = progressStep;

                if (screenType != hmSetting.screen_type.AOD) {

                  // normal_step_circle_scale_circle_scale
                  let level = Math.round(progress_cs_normal_step * 100);
                  if (normal_step_circle_scale) {
                    normal_step_circle_scale.setProperty(hmUI.prop.MORE, {                      
                      center_x: 114,
                      center_y: 218,
                      start_angle: -55,
                      end_angle: 60,
                      radius: 58,
                      line_width: 7,
                      corner_flag: 0,
                      color: 0xFFB9005C,
                      show_level: hmUI.show_level.ONLY_NORMAL,
                      level: level,
                    });
                  };
                };

            };

            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                console.log('resume_call()');
                HeartUpdate()
				scale_call();
              }),
            });

                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}