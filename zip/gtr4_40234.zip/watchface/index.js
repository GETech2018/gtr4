﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (()=>{
        //dynamic modify start
	
	    const lang = DeviceRuntimeCore.HmUtils.getLanguage()
		let bg = ''
		let alarm_clock_img = ''
		let normal_compass_icon_img = ''
        let normal_compass_direction_pointer_img = ''
        let normal_compass_text_img = ''
        let normal_compass_direction_img_level = ''
        let normal_compass_direction_arr = ["d_1.png", "d_2.png", "d_3.png", "d_4.png", "d_5.png", "d_6.png", "d_7.png", "d_8.png"];
        let normal_battery_icon_img = ''
        let normal_battery_pointer_progress_img_pointer = ''
		let normal_load_pointer_progress_img_pointer = ''
		let normal_training_load_current_text_img = ''
        let normal_battery_text_text_img = ''
        let normal_date_img_date_week_img = ''
        let normal_date_img_date_day = ''
        let normal_moon_image_progress_img_level = ''
        let normal_altimeter_icon_img = ''
        let normal_altimeter_pointer_progress_img_pointer = ''
        let normal_altimeter_text_text_img = ''
        let normal_wind_icon_img = ''
        let normal_wind_pointer_progress_img_pointer = ''
        let normal_wind_text_text_img = ''
        let normal_sun_icon_img = ''
        let normal_sun_high_text_img = ''
        let normal_sun_low_text_img = ''
        let normal_humidity_icon_img = ''
        let normal_humidity_pointer_progress_img_pointer = ''
        let normal_humidity_text_text_img = ''
        let normal_uvi_icon_img = ''
        let normal_uvi_pointer_progress_img_pointer = ''
        let normal_uvi_text_text_img = ''
        let normal_spo2_icon_img = ''
        let normal_spo2_text_text_img = ''
        let normal_stress_icon_img = ''
        let normal_stress_pointer_progress_img_pointer = ''
        let normal_stress_text_text_img = ''
        let normal_calorie_icon_img = ''
        let normal_calorie_circle_scale = ''
        let normal_calorie_current_text_img = ''
        let normal_heart_rate_icon_img = ''
        let normal_heart_rate_pointer_progress_img_pointer = ''
        let normal_heart_rate_text_text_img = ''
        let normal_pai_icon_img = ''
        let normal_pai_pointer_progress_img_pointer = ''
        let normal_pai_weekly_text_img = ''
        let normal_pai_day_text_img = ''
        let normal_fat_burning_icon_img = ''
        let normal_fat_burning_circle_scale = ''
        let normal_fat_burning_current_text_img = ''
        let normal_stand_icon_img = ''
        let normal_stand_circle_scale = ''
        let normal_stand_current_text_img = ''
        let normal_distance_icon_img = ''
        let normal_distance_text_text_img = ''
        let normal_step_icon_img = ''
        let normal_step_circle_scale = ''
        let normal_step_current_text_img = ''
        let normal_analog_clock_time_pointer_hour = ''
        let normal_analog_clock_time_pointer_minute = ''
        let normal_analog_clock_time_pointer_second = ''
		let normal_system_disconnect_img = ''
        let normal_stress_jumpable_img_click = ''
        let normal_pai_jumpable_img_click = ''
        let normal_spo2_jumpable_img_click = ''
        let normal_heart_jumpable_img_click = ''
		let normal_image_sleep = ''
		let normal_image_data = ''
		let normal_image_load = ''
		let normal_image_aqi = ''
		let normal_aqi_pointer_progress_img_pointer = ''
		let normal_image_alarm = ''
		let normal_image_pai = ''
		let normal_image_sunrise = ''
		let L = ''
		let G = ''
		let H = ''
		let normal_image_weight = ''
		let normal_temperature_current_text_img = ''
        let normal_weather_image_progress_img_level = ''
		let normal_weather_pointer_progress_img_pointer = ''
		let icon_bg = ''
		let normal_image_weather = ''
		let normal_image_floor = ''
		let normal_floor_current_text_img = ''
		let normal_image_altitude = ''
		let normal_altitude_current_text_img = ''
		let normal_image_age = ''
		let normal_image_height = ''
		
		const sleep = hmSensor.createSensor(hmSensor.id.SLEEP);
		//let sleepInfo = sleep.getBasicInfo();
		
		let sleepTotalTime = sleep.getTotalTime();

		let sleepStageArray = sleep.getSleepStageData();
		const modelData = sleep.getSleepStageModel();
		function updateSleepInfo() {
			sleepTotalTime = sleep.getTotalTime();
			sleepStageArray = sleep.getSleepStageData();
			//sleepInfo = sleep.getBasicInfo();
			
		let wakeTime = 0;
		sleepStageArray = sleep.getSleepStageData();
			
			for (let i = 0; i < sleepStageArray.length; i++) {
			  let data = sleepStageArray[i];
			  if (data.model == modelData.WAKE_STAGE){
					wakeTime += data.stop + 1 - data.start;
			  }

			}
			
			sleepTotalTime -= wakeTime;

		sleep_time_txt.setProperty(hmUI.prop.TEXT, '' + Math.floor(sleepTotalTime / 60).toString().padStart(2, "0") + ':' + (sleepTotalTime % 60).toString().padStart(2, "0"));
       
        }
		
		let btn_zona1 = ''
        let zona1_num = 0
        let zona1_all = 6
		
		function click_zona1() {
		  zona1_num = (zona1_num + 1) % (zona1_all + 1);
          if (zona1_num == 0) {
			normal_step_icon_img.setProperty(hmUI.prop.VISIBLE, true);  
			normal_step_current_text_img.setProperty(hmUI.prop.VISIBLE, true);
			normal_step_circle_scale.setProperty(hmUI.prop.VISIBLE, true);
			normal_distance_icon_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_distance_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_stand_icon_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_stand_circle_scale.setProperty(hmUI.prop.VISIBLE, false);
			normal_stand_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_fat_burning_icon_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_fat_burning_circle_scale.setProperty(hmUI.prop.VISIBLE, false);
			normal_fat_burning_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_pai_icon_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_pai_pointer_progress_img_pointer.setProperty(hmUI.prop.VISIBLE, false);
			normal_pai_day_text_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_image_pai.setProperty(hmUI.prop.VISIBLE, false);
			normal_pai_weekly_text_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_image_floor.setProperty(hmUI.prop.VISIBLE, false);
			normal_floor_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
		    hmUI.showToast({
				text: 'Steps'
            });
          };
            if (zona1_num == 1) {		  
		  	normal_step_icon_img.setProperty(hmUI.prop.VISIBLE, false);  
			normal_step_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_step_circle_scale.setProperty(hmUI.prop.VISIBLE, false);
			normal_distance_icon_img.setProperty(hmUI.prop.VISIBLE, true);
			normal_distance_text_text_img.setProperty(hmUI.prop.VISIBLE, true);
			normal_stand_icon_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_stand_circle_scale.setProperty(hmUI.prop.VISIBLE, false);
			normal_stand_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_fat_burning_icon_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_fat_burning_circle_scale.setProperty(hmUI.prop.VISIBLE, false);
			normal_fat_burning_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_pai_icon_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_pai_pointer_progress_img_pointer.setProperty(hmUI.prop.VISIBLE, false);
			normal_pai_day_text_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_image_pai.setProperty(hmUI.prop.VISIBLE, false);
			normal_pai_weekly_text_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_image_floor.setProperty(hmUI.prop.VISIBLE, false);
			normal_floor_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
		    hmUI.showToast({
				text: 'Distance'
            });
          };
           if (zona1_num == 2) {		  
		  	normal_step_icon_img.setProperty(hmUI.prop.VISIBLE, false);  
			normal_step_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_step_circle_scale.setProperty(hmUI.prop.VISIBLE, false);
			normal_distance_icon_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_distance_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_stand_icon_img.setProperty(hmUI.prop.VISIBLE, true);
			normal_stand_circle_scale.setProperty(hmUI.prop.VISIBLE, true);
			normal_stand_current_text_img.setProperty(hmUI.prop.VISIBLE, true);
			normal_fat_burning_icon_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_fat_burning_circle_scale.setProperty(hmUI.prop.VISIBLE, false);
			normal_fat_burning_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_pai_icon_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_pai_pointer_progress_img_pointer.setProperty(hmUI.prop.VISIBLE, false);
			normal_pai_day_text_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_image_pai.setProperty(hmUI.prop.VISIBLE, false);
			normal_pai_weekly_text_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_image_floor.setProperty(hmUI.prop.VISIBLE, false);
			normal_floor_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
		    hmUI.showToast({
				text: 'Stand'
            });
          };
		  if (zona1_num == 3) {		  
		  	normal_step_icon_img.setProperty(hmUI.prop.VISIBLE, false);  
			normal_step_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_step_circle_scale.setProperty(hmUI.prop.VISIBLE, false);
			normal_distance_icon_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_distance_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_stand_icon_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_stand_circle_scale.setProperty(hmUI.prop.VISIBLE, false);
			normal_stand_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_fat_burning_icon_img.setProperty(hmUI.prop.VISIBLE, true);
			normal_fat_burning_circle_scale.setProperty(hmUI.prop.VISIBLE, true);
			normal_fat_burning_current_text_img.setProperty(hmUI.prop.VISIBLE, true);
			normal_pai_icon_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_pai_pointer_progress_img_pointer.setProperty(hmUI.prop.VISIBLE, false);
			normal_pai_day_text_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_image_pai.setProperty(hmUI.prop.VISIBLE, false);
			normal_pai_weekly_text_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_image_floor.setProperty(hmUI.prop.VISIBLE, false);
			normal_floor_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
		    hmUI.showToast({
				text: 'Fat \n Burning'
            });
          };
		  if (zona1_num == 4) {		  
		  	normal_step_icon_img.setProperty(hmUI.prop.VISIBLE, false);  
			normal_step_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_step_circle_scale.setProperty(hmUI.prop.VISIBLE, false);
			normal_distance_icon_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_distance_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_stand_icon_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_stand_circle_scale.setProperty(hmUI.prop.VISIBLE, false);
			normal_stand_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_fat_burning_icon_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_fat_burning_circle_scale.setProperty(hmUI.prop.VISIBLE, false);
			normal_fat_burning_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_pai_icon_img.setProperty(hmUI.prop.VISIBLE, true);
			normal_pai_pointer_progress_img_pointer.setProperty(hmUI.prop.VISIBLE, true);
			normal_pai_day_text_img.setProperty(hmUI.prop.VISIBLE, true);
			normal_image_pai.setProperty(hmUI.prop.VISIBLE, false);
			normal_pai_weekly_text_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_image_floor.setProperty(hmUI.prop.VISIBLE, false);
			normal_floor_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
		    hmUI.showToast({
				text: 'PAI \n Day'
            });
          };
		  if (zona1_num == 5) {		  
		  	normal_step_icon_img.setProperty(hmUI.prop.VISIBLE, false);  
			normal_step_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_step_circle_scale.setProperty(hmUI.prop.VISIBLE, false);
			normal_distance_icon_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_distance_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_stand_icon_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_stand_circle_scale.setProperty(hmUI.prop.VISIBLE, false);
			normal_stand_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_fat_burning_icon_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_fat_burning_circle_scale.setProperty(hmUI.prop.VISIBLE, false);
			normal_fat_burning_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_pai_icon_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_pai_pointer_progress_img_pointer.setProperty(hmUI.prop.VISIBLE, false);
			normal_pai_day_text_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_image_pai.setProperty(hmUI.prop.VISIBLE, true);
			normal_pai_weekly_text_img.setProperty(hmUI.prop.VISIBLE, true);
			normal_image_floor.setProperty(hmUI.prop.VISIBLE, false);
			normal_floor_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
		    hmUI.showToast({
				text: 'PAI \n Week'
            });
          };
		  if (zona1_num == 6) {		  
		  	normal_step_icon_img.setProperty(hmUI.prop.VISIBLE, false);  
			normal_step_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_step_circle_scale.setProperty(hmUI.prop.VISIBLE, false);
			normal_distance_icon_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_distance_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_stand_icon_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_stand_circle_scale.setProperty(hmUI.prop.VISIBLE, false);
			normal_stand_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_fat_burning_icon_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_fat_burning_circle_scale.setProperty(hmUI.prop.VISIBLE, false);
			normal_fat_burning_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_pai_icon_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_pai_pointer_progress_img_pointer.setProperty(hmUI.prop.VISIBLE, false);
			normal_pai_day_text_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_image_pai.setProperty(hmUI.prop.VISIBLE, false);
			normal_pai_weekly_text_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_image_floor.setProperty(hmUI.prop.VISIBLE, true);
			normal_floor_current_text_img.setProperty(hmUI.prop.VISIBLE, true);
		    hmUI.showToast({
				text: 'Floors'
            });
          };
		}
		
		let btn_zona2 = ''
        let zona2_num = 0
        let zona2_all = 6
		
		function click_zona2() {
		  zona2_num = (zona2_num + 1) % (zona2_all + 1);
          if (zona2_num == 0) {
			normal_heart_rate_icon_img.setProperty(hmUI.prop.VISIBLE, true);
			normal_heart_rate_pointer_progress_img_pointer.setProperty(hmUI.prop.VISIBLE, true);
			normal_heart_rate_text_text_img.setProperty(hmUI.prop.VISIBLE, true);
			normal_calorie_icon_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_calorie_circle_scale.setProperty(hmUI.prop.VISIBLE, false);
			normal_calorie_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_stress_icon_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_stress_pointer_progress_img_pointer.setProperty(hmUI.prop.VISIBLE, false);
			normal_stress_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_spo2_icon_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_spo2_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_image_weight.setProperty(hmUI.prop.VISIBLE, false);
			L.setProperty(hmUI.prop.VISIBLE, false);
			normal_image_age.setProperty(hmUI.prop.VISIBLE, false);
			G.setProperty(hmUI.prop.VISIBLE, false);
			normal_image_height.setProperty(hmUI.prop.VISIBLE, false);
			H.setProperty(hmUI.prop.VISIBLE, false);
		    hmUI.showToast({
				text: 'Pulse'
            });
          };
            if (zona2_num == 1) {		  
		  	normal_heart_rate_icon_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_heart_rate_pointer_progress_img_pointer.setProperty(hmUI.prop.VISIBLE, false);
			normal_heart_rate_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_calorie_icon_img.setProperty(hmUI.prop.VISIBLE, true);
			normal_calorie_circle_scale.setProperty(hmUI.prop.VISIBLE, true);
			normal_calorie_current_text_img.setProperty(hmUI.prop.VISIBLE, true);
			normal_stress_icon_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_stress_pointer_progress_img_pointer.setProperty(hmUI.prop.VISIBLE, false);
			normal_stress_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_spo2_icon_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_spo2_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_image_weight.setProperty(hmUI.prop.VISIBLE, false);
			L.setProperty(hmUI.prop.VISIBLE, false);
			normal_image_age.setProperty(hmUI.prop.VISIBLE, false);
			G.setProperty(hmUI.prop.VISIBLE, false);
			normal_image_height.setProperty(hmUI.prop.VISIBLE, false);
			H.setProperty(hmUI.prop.VISIBLE, false);
		    hmUI.showToast({
				text: 'Calorie'
            });
          };
           if (zona2_num == 2) {		  
		  	normal_heart_rate_icon_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_heart_rate_pointer_progress_img_pointer.setProperty(hmUI.prop.VISIBLE, false);
			normal_heart_rate_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_calorie_icon_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_calorie_circle_scale.setProperty(hmUI.prop.VISIBLE, false);
			normal_calorie_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_stress_icon_img.setProperty(hmUI.prop.VISIBLE, true);
			normal_stress_pointer_progress_img_pointer.setProperty(hmUI.prop.VISIBLE, true);
			normal_stress_text_text_img.setProperty(hmUI.prop.VISIBLE, true);
			normal_spo2_icon_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_spo2_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_image_weight.setProperty(hmUI.prop.VISIBLE, false);
			L.setProperty(hmUI.prop.VISIBLE, false);
			normal_image_age.setProperty(hmUI.prop.VISIBLE, false);
			G.setProperty(hmUI.prop.VISIBLE, false);
			normal_image_height.setProperty(hmUI.prop.VISIBLE, false);
			H.setProperty(hmUI.prop.VISIBLE, false);
		    hmUI.showToast({
				text: 'Stress'
            });
          };
		  if (zona2_num == 3) {		  
		  	normal_heart_rate_icon_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_heart_rate_pointer_progress_img_pointer.setProperty(hmUI.prop.VISIBLE, false);
			normal_heart_rate_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_calorie_icon_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_calorie_circle_scale.setProperty(hmUI.prop.VISIBLE, false);
			normal_calorie_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_stress_icon_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_stress_pointer_progress_img_pointer.setProperty(hmUI.prop.VISIBLE, false);
			normal_stress_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_spo2_icon_img.setProperty(hmUI.prop.VISIBLE, true);
			normal_spo2_text_text_img.setProperty(hmUI.prop.VISIBLE, true);
			normal_image_weight.setProperty(hmUI.prop.VISIBLE, false);
			L.setProperty(hmUI.prop.VISIBLE, false);
			normal_image_age.setProperty(hmUI.prop.VISIBLE, false);
			G.setProperty(hmUI.prop.VISIBLE, false);
			normal_image_height.setProperty(hmUI.prop.VISIBLE, false);
			H.setProperty(hmUI.prop.VISIBLE, false);
		    hmUI.showToast({
				text: 'SpO2'
            });
          };
		  if (zona2_num == 4) {		  
		  	normal_heart_rate_icon_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_heart_rate_pointer_progress_img_pointer.setProperty(hmUI.prop.VISIBLE, false);
			normal_heart_rate_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_calorie_icon_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_calorie_circle_scale.setProperty(hmUI.prop.VISIBLE, false);
			normal_calorie_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_stress_icon_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_stress_pointer_progress_img_pointer.setProperty(hmUI.prop.VISIBLE, false);
			normal_stress_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_spo2_icon_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_spo2_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_image_weight.setProperty(hmUI.prop.VISIBLE, true);
			L.setProperty(hmUI.prop.VISIBLE, true);
			normal_image_age.setProperty(hmUI.prop.VISIBLE, false);
			G.setProperty(hmUI.prop.VISIBLE, false);
			normal_image_height.setProperty(hmUI.prop.VISIBLE, false);
			H.setProperty(hmUI.prop.VISIBLE, false);
		    hmUI.showToast({
				text: 'Your \n Weight'
            });
          };
		  if (zona2_num == 5) {		  
		  	normal_heart_rate_icon_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_heart_rate_pointer_progress_img_pointer.setProperty(hmUI.prop.VISIBLE, false);
			normal_heart_rate_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_calorie_icon_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_calorie_circle_scale.setProperty(hmUI.prop.VISIBLE, false);
			normal_calorie_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_stress_icon_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_stress_pointer_progress_img_pointer.setProperty(hmUI.prop.VISIBLE, false);
			normal_stress_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_spo2_icon_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_spo2_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_image_weight.setProperty(hmUI.prop.VISIBLE, false);
			L.setProperty(hmUI.prop.VISIBLE, false);
			normal_image_age.setProperty(hmUI.prop.VISIBLE, true);
			G.setProperty(hmUI.prop.VISIBLE, true);
			normal_image_height.setProperty(hmUI.prop.VISIBLE, false);
			H.setProperty(hmUI.prop.VISIBLE, false);
		    hmUI.showToast({
				text: 'Your \n Age'
            });
          };
		  if (zona2_num == 6) {		  
		  	normal_heart_rate_icon_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_heart_rate_pointer_progress_img_pointer.setProperty(hmUI.prop.VISIBLE, false);
			normal_heart_rate_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_calorie_icon_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_calorie_circle_scale.setProperty(hmUI.prop.VISIBLE, false);
			normal_calorie_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_stress_icon_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_stress_pointer_progress_img_pointer.setProperty(hmUI.prop.VISIBLE, false);
			normal_stress_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_spo2_icon_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_spo2_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_image_weight.setProperty(hmUI.prop.VISIBLE, false);
			L.setProperty(hmUI.prop.VISIBLE, false);
			normal_image_age.setProperty(hmUI.prop.VISIBLE, false);
			G.setProperty(hmUI.prop.VISIBLE, false);
			normal_image_height.setProperty(hmUI.prop.VISIBLE, true);
			H.setProperty(hmUI.prop.VISIBLE, true);
		    hmUI.showToast({
				text: 'Your \n Height'
            });
          };
		}
		
		let btn_zona3 = ''
        let zona3_num = 0
        let zona3_all = 9
		
		function click_zona3() {
		  zona3_num = (zona3_num + 1) % (zona3_all + 1);
          if (zona3_num == 0) {
			normal_uvi_icon_img.setProperty(hmUI.prop.VISIBLE, true);
			normal_uvi_pointer_progress_img_pointer.setProperty(hmUI.prop.VISIBLE, true);
			normal_uvi_text_text_img.setProperty(hmUI.prop.VISIBLE, true);
			normal_humidity_icon_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_humidity_pointer_progress_img_pointer.setProperty(hmUI.prop.VISIBLE, false);
			normal_humidity_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_sun_icon_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_sun_high_text_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_image_sunrise.setProperty(hmUI.prop.VISIBLE, false);
			normal_sun_low_text_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_wind_icon_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_wind_pointer_progress_img_pointer.setProperty(hmUI.prop.VISIBLE, false);
			normal_wind_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_altimeter_icon_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_altimeter_pointer_progress_img_pointer.setProperty(hmUI.prop.VISIBLE, false);
			normal_altimeter_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_moon_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, false);
			normal_image_aqi.setProperty(hmUI.prop.VISIBLE, false);
			normal_aqi_pointer_progress_img_pointer.setProperty(hmUI.prop.VISIBLE, false);
			normal_temperature_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_weather_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, false);
			normal_weather_pointer_progress_img_pointer.setProperty(hmUI.prop.VISIBLE, false);
			icon_bg.setProperty(hmUI.prop.VISIBLE, false);
			normal_image_weather.setProperty(hmUI.prop.VISIBLE, false);
		    hmUI.showToast({
				text: 'UVI'
            });
          };
            if (zona3_num == 1) {		  
		  	normal_uvi_icon_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_uvi_pointer_progress_img_pointer.setProperty(hmUI.prop.VISIBLE, false);
			normal_uvi_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_humidity_icon_img.setProperty(hmUI.prop.VISIBLE, true);
			normal_humidity_pointer_progress_img_pointer.setProperty(hmUI.prop.VISIBLE, true);
			normal_humidity_text_text_img.setProperty(hmUI.prop.VISIBLE, true);
			normal_sun_icon_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_sun_high_text_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_image_sunrise.setProperty(hmUI.prop.VISIBLE, false);
			normal_sun_low_text_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_wind_icon_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_wind_pointer_progress_img_pointer.setProperty(hmUI.prop.VISIBLE, false);
			normal_wind_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_altimeter_icon_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_altimeter_pointer_progress_img_pointer.setProperty(hmUI.prop.VISIBLE, false);
			normal_altimeter_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_moon_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, false);
			normal_image_aqi.setProperty(hmUI.prop.VISIBLE, false);
			normal_aqi_pointer_progress_img_pointer.setProperty(hmUI.prop.VISIBLE, false);
			normal_temperature_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_weather_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, false);
			normal_weather_pointer_progress_img_pointer.setProperty(hmUI.prop.VISIBLE, false);
			icon_bg.setProperty(hmUI.prop.VISIBLE, false);
			normal_image_weather.setProperty(hmUI.prop.VISIBLE, false);
		    hmUI.showToast({
				text: 'Humidity'
            });
          };
           if (zona3_num == 2) {		  
		  	normal_uvi_icon_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_uvi_pointer_progress_img_pointer.setProperty(hmUI.prop.VISIBLE, false);
			normal_uvi_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_humidity_icon_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_humidity_pointer_progress_img_pointer.setProperty(hmUI.prop.VISIBLE, false);
			normal_humidity_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_sun_icon_img.setProperty(hmUI.prop.VISIBLE, true);
			normal_sun_high_text_img.setProperty(hmUI.prop.VISIBLE, true);
			normal_image_sunrise.setProperty(hmUI.prop.VISIBLE, false);
			normal_sun_low_text_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_wind_icon_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_wind_pointer_progress_img_pointer.setProperty(hmUI.prop.VISIBLE, false);
			normal_wind_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_altimeter_icon_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_altimeter_pointer_progress_img_pointer.setProperty(hmUI.prop.VISIBLE, false);
			normal_altimeter_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_moon_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, false);
			normal_image_aqi.setProperty(hmUI.prop.VISIBLE, false);
			normal_aqi_pointer_progress_img_pointer.setProperty(hmUI.prop.VISIBLE, false);
			normal_temperature_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_weather_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, false);
			normal_weather_pointer_progress_img_pointer.setProperty(hmUI.prop.VISIBLE, false);
			icon_bg.setProperty(hmUI.prop.VISIBLE, false);
			normal_image_weather.setProperty(hmUI.prop.VISIBLE, false);
		    hmUI.showToast({
				text: 'SunRise'
            });
          };
		  if (zona3_num == 3) {		  
		  	normal_uvi_icon_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_uvi_pointer_progress_img_pointer.setProperty(hmUI.prop.VISIBLE, false);
			normal_uvi_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_humidity_icon_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_humidity_pointer_progress_img_pointer.setProperty(hmUI.prop.VISIBLE, false);
			normal_humidity_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_sun_icon_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_sun_high_text_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_image_sunrise.setProperty(hmUI.prop.VISIBLE, true);
			normal_sun_low_text_img.setProperty(hmUI.prop.VISIBLE, true);
			normal_wind_icon_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_wind_pointer_progress_img_pointer.setProperty(hmUI.prop.VISIBLE, false);
			normal_wind_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_altimeter_icon_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_altimeter_pointer_progress_img_pointer.setProperty(hmUI.prop.VISIBLE, false);
			normal_altimeter_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_moon_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, false);
			normal_image_aqi.setProperty(hmUI.prop.VISIBLE, false);
			normal_aqi_pointer_progress_img_pointer.setProperty(hmUI.prop.VISIBLE, false);
			normal_temperature_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_weather_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, false);
			normal_weather_pointer_progress_img_pointer.setProperty(hmUI.prop.VISIBLE, false);
			icon_bg.setProperty(hmUI.prop.VISIBLE, false);
			normal_image_weather.setProperty(hmUI.prop.VISIBLE, false);
		    hmUI.showToast({
				text: 'SunSet'
            });
          };
		  if (zona3_num == 4) {		  
		  	normal_uvi_icon_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_uvi_pointer_progress_img_pointer.setProperty(hmUI.prop.VISIBLE, false);
			normal_uvi_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_humidity_icon_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_humidity_pointer_progress_img_pointer.setProperty(hmUI.prop.VISIBLE, false);
			normal_humidity_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_sun_icon_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_sun_high_text_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_image_sunrise.setProperty(hmUI.prop.VISIBLE, false);
			normal_sun_low_text_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_wind_icon_img.setProperty(hmUI.prop.VISIBLE, true);
			normal_wind_pointer_progress_img_pointer.setProperty(hmUI.prop.VISIBLE, true);
			normal_wind_text_text_img.setProperty(hmUI.prop.VISIBLE, true);
			normal_altimeter_icon_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_altimeter_pointer_progress_img_pointer.setProperty(hmUI.prop.VISIBLE, false);
			normal_altimeter_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_moon_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, false);
			normal_image_aqi.setProperty(hmUI.prop.VISIBLE, false);
			normal_aqi_pointer_progress_img_pointer.setProperty(hmUI.prop.VISIBLE, false);
			normal_temperature_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_weather_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, false);
			normal_weather_pointer_progress_img_pointer.setProperty(hmUI.prop.VISIBLE, false);
			icon_bg.setProperty(hmUI.prop.VISIBLE, false);
			normal_image_weather.setProperty(hmUI.prop.VISIBLE, false);
		    hmUI.showToast({
				text: 'Wind'
            });
          };
		  if (zona3_num == 5) {		  
		  	normal_uvi_icon_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_uvi_pointer_progress_img_pointer.setProperty(hmUI.prop.VISIBLE, false);
			normal_uvi_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_humidity_icon_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_humidity_pointer_progress_img_pointer.setProperty(hmUI.prop.VISIBLE, false);
			normal_humidity_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_sun_icon_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_sun_high_text_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_image_sunrise.setProperty(hmUI.prop.VISIBLE, false);
			normal_sun_low_text_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_wind_icon_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_wind_pointer_progress_img_pointer.setProperty(hmUI.prop.VISIBLE, false);
			normal_wind_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_altimeter_icon_img.setProperty(hmUI.prop.VISIBLE, true);
			normal_altimeter_pointer_progress_img_pointer.setProperty(hmUI.prop.VISIBLE, true);
			normal_altimeter_text_text_img.setProperty(hmUI.prop.VISIBLE, true);
			normal_moon_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, false);
			normal_image_aqi.setProperty(hmUI.prop.VISIBLE, false);
			normal_aqi_pointer_progress_img_pointer.setProperty(hmUI.prop.VISIBLE, false);
			normal_temperature_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_weather_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, false);
			normal_weather_pointer_progress_img_pointer.setProperty(hmUI.prop.VISIBLE, false);
			icon_bg.setProperty(hmUI.prop.VISIBLE, false);
			normal_image_weather.setProperty(hmUI.prop.VISIBLE, false);
		    hmUI.showToast({
				text: 'Pressure'
            });
          };
		  if (zona3_num == 6) {		  
		  	normal_uvi_icon_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_uvi_pointer_progress_img_pointer.setProperty(hmUI.prop.VISIBLE, false);
			normal_uvi_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_humidity_icon_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_humidity_pointer_progress_img_pointer.setProperty(hmUI.prop.VISIBLE, false);
			normal_humidity_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_sun_icon_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_sun_high_text_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_image_sunrise.setProperty(hmUI.prop.VISIBLE, false);
			normal_sun_low_text_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_wind_icon_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_wind_pointer_progress_img_pointer.setProperty(hmUI.prop.VISIBLE, false);
			normal_wind_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_altimeter_icon_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_altimeter_pointer_progress_img_pointer.setProperty(hmUI.prop.VISIBLE, false);
			normal_altimeter_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_moon_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, true);
			normal_image_aqi.setProperty(hmUI.prop.VISIBLE, false);
			normal_aqi_pointer_progress_img_pointer.setProperty(hmUI.prop.VISIBLE, false);
			normal_temperature_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_weather_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, false);
			normal_weather_pointer_progress_img_pointer.setProperty(hmUI.prop.VISIBLE, false);
			icon_bg.setProperty(hmUI.prop.VISIBLE, false);
			normal_image_weather.setProperty(hmUI.prop.VISIBLE, false);
		    hmUI.showToast({
				text: 'Moon Phase'
            });
          };
		  if (zona3_num == 7) {		  
		  	normal_uvi_icon_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_uvi_pointer_progress_img_pointer.setProperty(hmUI.prop.VISIBLE, false);
			normal_uvi_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_humidity_icon_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_humidity_pointer_progress_img_pointer.setProperty(hmUI.prop.VISIBLE, false);
			normal_humidity_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_sun_icon_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_sun_high_text_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_image_sunrise.setProperty(hmUI.prop.VISIBLE, false);
			normal_sun_low_text_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_wind_icon_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_wind_pointer_progress_img_pointer.setProperty(hmUI.prop.VISIBLE, false);
			normal_wind_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_altimeter_icon_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_altimeter_pointer_progress_img_pointer.setProperty(hmUI.prop.VISIBLE, false);
			normal_altimeter_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_moon_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, false);
			normal_image_aqi.setProperty(hmUI.prop.VISIBLE, true);
			normal_aqi_pointer_progress_img_pointer.setProperty(hmUI.prop.VISIBLE, true);
			normal_temperature_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_weather_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, false);
			normal_weather_pointer_progress_img_pointer.setProperty(hmUI.prop.VISIBLE, false);
			icon_bg.setProperty(hmUI.prop.VISIBLE, false);
			normal_image_weather.setProperty(hmUI.prop.VISIBLE, false);
		    hmUI.showToast({
				text: 'AQI'
            });
          };
		  if (zona3_num == 8) {		  
		  	normal_uvi_icon_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_uvi_pointer_progress_img_pointer.setProperty(hmUI.prop.VISIBLE, false);
			normal_uvi_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_humidity_icon_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_humidity_pointer_progress_img_pointer.setProperty(hmUI.prop.VISIBLE, false);
			normal_humidity_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_sun_icon_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_sun_high_text_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_image_sunrise.setProperty(hmUI.prop.VISIBLE, false);
			normal_sun_low_text_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_wind_icon_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_wind_pointer_progress_img_pointer.setProperty(hmUI.prop.VISIBLE, false);
			normal_wind_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_altimeter_icon_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_altimeter_pointer_progress_img_pointer.setProperty(hmUI.prop.VISIBLE, false);
			normal_altimeter_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_moon_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, false);
			normal_image_aqi.setProperty(hmUI.prop.VISIBLE, false);
			normal_aqi_pointer_progress_img_pointer.setProperty(hmUI.prop.VISIBLE, false);
			normal_temperature_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_weather_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, true);
			normal_weather_pointer_progress_img_pointer.setProperty(hmUI.prop.VISIBLE, false);
			icon_bg.setProperty(hmUI.prop.VISIBLE, true);
			normal_image_weather.setProperty(hmUI.prop.VISIBLE, false);
		    hmUI.showToast({
				text: 'Weather'
            });
          };
		  if (zona3_num == 9) {		  
		  	normal_uvi_icon_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_uvi_pointer_progress_img_pointer.setProperty(hmUI.prop.VISIBLE, false);
			normal_uvi_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_humidity_icon_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_humidity_pointer_progress_img_pointer.setProperty(hmUI.prop.VISIBLE, false);
			normal_humidity_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_sun_icon_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_sun_high_text_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_image_sunrise.setProperty(hmUI.prop.VISIBLE, false);
			normal_sun_low_text_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_wind_icon_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_wind_pointer_progress_img_pointer.setProperty(hmUI.prop.VISIBLE, false);
			normal_wind_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_altimeter_icon_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_altimeter_pointer_progress_img_pointer.setProperty(hmUI.prop.VISIBLE, false);
			normal_altimeter_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_moon_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, false);
			normal_image_aqi.setProperty(hmUI.prop.VISIBLE, false);
			normal_aqi_pointer_progress_img_pointer.setProperty(hmUI.prop.VISIBLE, false);
			normal_temperature_current_text_img.setProperty(hmUI.prop.VISIBLE, true);
			normal_weather_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, false);
			normal_weather_pointer_progress_img_pointer.setProperty(hmUI.prop.VISIBLE, true);
			icon_bg.setProperty(hmUI.prop.VISIBLE, false);
			normal_image_weather.setProperty(hmUI.prop.VISIBLE, true);
		    hmUI.showToast({
				text: 'Temperature'
            });
          };
		}
		
		let btn_zona4 = ''
        let zona4_num = 0
        let zona4_all = 6
		
		function click_zona4() {
		  zona4_num = (zona4_num + 1) % (zona4_all + 1);
          if (zona4_num == 0) {
			normal_battery_icon_img.setProperty(hmUI.prop.VISIBLE, true);
			normal_battery_pointer_progress_img_pointer.setProperty(hmUI.prop.VISIBLE, true);
			normal_battery_text_text_img.setProperty(hmUI.prop.VISIBLE, true);
			normal_image_data.setProperty(hmUI.prop.VISIBLE, false);
			normal_date_img_date_week_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_date_img_date_day.setProperty(hmUI.prop.VISIBLE, false);
			normal_image_sleep.setProperty(hmUI.prop.VISIBLE, false);
			sleep_time_txt.setProperty(hmUI.prop.VISIBLE, false);
			normal_image_load.setProperty(hmUI.prop.VISIBLE, false);
			normal_load_pointer_progress_img_pointer.setProperty(hmUI.prop.VISIBLE, false);
			normal_training_load_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_image_alarm.setProperty(hmUI.prop.VISIBLE, false);
			alarm_clock_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_compass_icon_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_compass_direction_pointer_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_compass_text_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_compass_direction_img_level.setProperty(hmUI.prop.VISIBLE, false);
			normal_image_altitude.setProperty(hmUI.prop.VISIBLE, false);
			normal_altitude_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
		    hmUI.showToast({
				text: 'Battery'
            });
          };
            if (zona4_num == 1) {		  
		  	normal_battery_icon_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_battery_pointer_progress_img_pointer.setProperty(hmUI.prop.VISIBLE, false);
			normal_battery_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_image_data.setProperty(hmUI.prop.VISIBLE, true);
			normal_date_img_date_week_img.setProperty(hmUI.prop.VISIBLE, true);
			normal_date_img_date_day.setProperty(hmUI.prop.VISIBLE, true);
			normal_image_sleep.setProperty(hmUI.prop.VISIBLE, false);
			sleep_time_txt.setProperty(hmUI.prop.VISIBLE, false);
			normal_image_load.setProperty(hmUI.prop.VISIBLE, false);
			normal_load_pointer_progress_img_pointer.setProperty(hmUI.prop.VISIBLE, false);
			normal_training_load_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_image_alarm.setProperty(hmUI.prop.VISIBLE, false);
			alarm_clock_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_compass_icon_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_compass_direction_pointer_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_compass_text_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_compass_direction_img_level.setProperty(hmUI.prop.VISIBLE, false);
			normal_image_altitude.setProperty(hmUI.prop.VISIBLE, false);
			normal_altitude_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
		    hmUI.showToast({
				text: 'Date'
            });
          };
           if (zona4_num == 2) {		  
		  	normal_battery_icon_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_battery_pointer_progress_img_pointer.setProperty(hmUI.prop.VISIBLE, false);
			normal_battery_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_image_data.setProperty(hmUI.prop.VISIBLE, false);
			normal_date_img_date_week_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_date_img_date_day.setProperty(hmUI.prop.VISIBLE, false);
			normal_image_sleep.setProperty(hmUI.prop.VISIBLE, true);
			sleep_time_txt.setProperty(hmUI.prop.VISIBLE, true);
			normal_image_load.setProperty(hmUI.prop.VISIBLE, false);
			normal_load_pointer_progress_img_pointer.setProperty(hmUI.prop.VISIBLE, false);
			normal_training_load_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_image_alarm.setProperty(hmUI.prop.VISIBLE, false);
			alarm_clock_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_compass_icon_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_compass_direction_pointer_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_compass_text_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_compass_direction_img_level.setProperty(hmUI.prop.VISIBLE, false);
			normal_image_altitude.setProperty(hmUI.prop.VISIBLE, false);
			normal_altitude_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
		    hmUI.showToast({
				text: 'Sleep'
            });
          };
		  if (zona4_num == 3) {		  
		  	normal_battery_icon_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_battery_pointer_progress_img_pointer.setProperty(hmUI.prop.VISIBLE, false);
			normal_battery_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_image_data.setProperty(hmUI.prop.VISIBLE, false);
			normal_date_img_date_week_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_date_img_date_day.setProperty(hmUI.prop.VISIBLE, false);
			normal_image_sleep.setProperty(hmUI.prop.VISIBLE, false);
			sleep_time_txt.setProperty(hmUI.prop.VISIBLE, false);
			normal_image_load.setProperty(hmUI.prop.VISIBLE, true);
			normal_load_pointer_progress_img_pointer.setProperty(hmUI.prop.VISIBLE, true);
			normal_training_load_current_text_img.setProperty(hmUI.prop.VISIBLE, true);
			normal_image_alarm.setProperty(hmUI.prop.VISIBLE, false);
			alarm_clock_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_compass_icon_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_compass_direction_pointer_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_compass_text_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_compass_direction_img_level.setProperty(hmUI.prop.VISIBLE, false);
			normal_image_altitude.setProperty(hmUI.prop.VISIBLE, false);
			normal_altitude_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
		    hmUI.showToast({
				text: 'Training \n Load'
            });
          };
		  if (zona4_num == 4) {		  
		  	normal_battery_icon_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_battery_pointer_progress_img_pointer.setProperty(hmUI.prop.VISIBLE, false);
			normal_battery_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_image_data.setProperty(hmUI.prop.VISIBLE, false);
			normal_date_img_date_week_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_date_img_date_day.setProperty(hmUI.prop.VISIBLE, false);
			normal_image_sleep.setProperty(hmUI.prop.VISIBLE, false);
			sleep_time_txt.setProperty(hmUI.prop.VISIBLE, false);
			normal_image_load.setProperty(hmUI.prop.VISIBLE, false);
			normal_load_pointer_progress_img_pointer.setProperty(hmUI.prop.VISIBLE, false);
			normal_training_load_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_image_alarm.setProperty(hmUI.prop.VISIBLE, true);
			alarm_clock_img.setProperty(hmUI.prop.VISIBLE, true);
			normal_compass_icon_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_compass_direction_pointer_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_compass_text_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_compass_direction_img_level.setProperty(hmUI.prop.VISIBLE, false);
			normal_image_altitude.setProperty(hmUI.prop.VISIBLE, false);
			normal_altitude_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
		    hmUI.showToast({
				text: 'Alarm'
            });
          };
		  if (zona4_num == 5) {		  
		  	normal_battery_icon_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_battery_pointer_progress_img_pointer.setProperty(hmUI.prop.VISIBLE, false);
			normal_battery_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_image_data.setProperty(hmUI.prop.VISIBLE, false);
			normal_date_img_date_week_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_date_img_date_day.setProperty(hmUI.prop.VISIBLE, false);
			normal_image_sleep.setProperty(hmUI.prop.VISIBLE, false);
			sleep_time_txt.setProperty(hmUI.prop.VISIBLE, false);
			normal_image_load.setProperty(hmUI.prop.VISIBLE, false);
			normal_load_pointer_progress_img_pointer.setProperty(hmUI.prop.VISIBLE, false);
			normal_training_load_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_image_alarm.setProperty(hmUI.prop.VISIBLE, false);
			alarm_clock_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_compass_icon_img.setProperty(hmUI.prop.VISIBLE, true);
			normal_compass_direction_pointer_img.setProperty(hmUI.prop.VISIBLE, true);
			normal_compass_text_img.setProperty(hmUI.prop.VISIBLE, true);
			normal_compass_direction_img_level.setProperty(hmUI.prop.VISIBLE, true);
			normal_image_altitude.setProperty(hmUI.prop.VISIBLE, false);
			normal_altitude_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
		    hmUI.showToast({
				text: 'Compass'
            });
			if (compass) compass.start();
          };
		  if (zona4_num == 6) {		  
		  	normal_battery_icon_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_battery_pointer_progress_img_pointer.setProperty(hmUI.prop.VISIBLE, false);
			normal_battery_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_image_data.setProperty(hmUI.prop.VISIBLE, false);
			normal_date_img_date_week_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_date_img_date_day.setProperty(hmUI.prop.VISIBLE, false);
			normal_image_sleep.setProperty(hmUI.prop.VISIBLE, false);
			sleep_time_txt.setProperty(hmUI.prop.VISIBLE, false);
			normal_image_load.setProperty(hmUI.prop.VISIBLE, false);
			normal_load_pointer_progress_img_pointer.setProperty(hmUI.prop.VISIBLE, false);
			normal_training_load_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_image_alarm.setProperty(hmUI.prop.VISIBLE, false);
			alarm_clock_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_compass_icon_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_compass_direction_pointer_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_compass_text_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_compass_direction_img_level.setProperty(hmUI.prop.VISIBLE, false);
			normal_image_altitude.setProperty(hmUI.prop.VISIBLE, true);
			normal_altitude_current_text_img.setProperty(hmUI.prop.VISIBLE, true);
		    hmUI.showToast({
				text: 'Altitude'
            });
          };
		}
		
		let longPress_Timer = null;
	    let longPressDelay = 900; 
		
		function getLongPress1() {
		    if(longPress_Timer) timer.stopTimer(longPress_Timer);
			
			let url;

			switch(zona4_num) {
			   case 0:
					url = 'Settings_batteryManagerScreen';
				break;
			   case 1:
					url = 'ScheduleCalScreen';
				break;
			   case 2:
					url = 'Sleep_HomeScreen';
				break;
				case 3:
					url = 'SportStatusScreen';
				break;
				case 4:
					url = 'AlarmInfoScreen';
				break;
				case 5:
					url = 'CompassScreen';
				break;
				case 6:
					url = 'BaroAltimeterScreen';
				break;
			   default:
				break;
			}
			hmApp.startApp({ url: url, native: true });
			
	    }
		
		const curTime = hmSensor.createSensor(hmSensor.id.TIME);
		const weather = hmSensor.createSensor(hmSensor.id.WEATHER);
		let weatherData = weather.getForecastWeather();
		let forecastData = weatherData.forecastData;
		let sunData = weatherData.tideData;
		let today = '';
		let sunriseMins = '';
		let sunsetMins = '';
		let sunriseMins_def = 8 * 60;			
		let sunsetMins_def = 20 * 60;

		let curMins = '';
		
		let isDayBg = true;
		
		function autoToggleBg() {

			weatherData = weather.getForecastWeather();
			sunData = weatherData.tideData;
			if (sunData.count > 0){
				today = sunData.data[0];
				sunriseMins = today.sunrise.hour * 60 + today.sunrise.minute;
				sunsetMins = today.sunset.hour * 60 + today.sunset.minute;
			} else {
				sunriseMins = sunriseMins_def;
				sunsetMins = sunsetMins_def;
			}

			curMins = curTime.hour * 60 + curTime.minute;
			let isDayNow = (curMins >= sunriseMins) && (curMins < sunsetMins);
			
			if(isDayNow){
				if(!isDayBg){
					bg.setProperty(hmUI.prop.SRC, "day.png");
					icon_bg.setProperty(hmUI.prop.SRC, "weather.png");
					isDayBg = true;
				}
			} else {
				if(isDayBg){
					bg.setProperty(hmUI.prop.SRC, "night.png");
					icon_bg.setProperty(hmUI.prop.SRC, "weatherN.png");
					isDayBg = false;
				}
			}
		}
		
		


        //dynamic modify end
        const e = __$$hmAppManager$$__.currentApp;
        const o = e.current
          , {px: i} = (new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(e,o)),
        e.__globals__)
          , n = Logger.getLogger("watchface6");
        o.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            bg = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 466,
              h: 466,
			  src: 'day.png',
			  show_level: hmUI.show_level.ONLY_NORMAL,
			});
			
			icon_bg = hmUI.createWidget(hmUI.widget.IMG, {
              x: 158,
              y: 280,
			  src: 'weather.png',
			  show_level: hmUI.show_level.ONLY_NORMAL,
			});
			
			autoToggleBg();
			
			normal_compass_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 158,
              y: 40,
              src: 'compass.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            const deviceInfo = hmSetting.getDeviceInfo();
            
            // normal_compass_custom_pointer_img = hmUI.createWidget(hmUI.widget.CUSTOM_POINTER, {
              // src: 'Pointer12.png',
              // center_x: 232,
              // center_y: 114,
              // x: 74,
              // y: 74,
              // start_angle: 0,
              // end_angle: 360,
              // type: hmUI.data_type.COMPASS,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });


            //start of ignored block
            normal_compass_direction_pointer_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: deviceInfo.width,
              h: deviceInfo.height,
              pos_x: 232 - 74,
              pos_y: 114 - 74,
              center_x: 232,
              center_y: 114,
              src: 'Pointer12.png',
              angle: 0,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            //end of ignored block

            normal_compass_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 186,
              y: 85,
              font_array: ["num_0.png","num_1.png","num_2.png","num_3.png","num_4.png","num_5.png","num_6.png","num_7.png","num_8.png","num_9.png"],
              padding: false,
              h_space: -2,
              unit_sc: 'du.png',
              unit_tc: 'du.png',
              unit_en: 'du.png',
              align_h: hmUI.align.CENTER_H,
              // type: hmUI.data_type.COMPASS,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_compass_direction_img_level = hmUI.createWidget(hmUI.widget.IMG, {
              x: 211,
              y: 120,
              src: 'd_1.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
              // type: hmUI.data_type.COMPASS,
            });

            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 193,
              y: 311,
              image_array: ["w_1.png","w_2.png","w_3.png","w_4.png","w_5.png","w_6.png","w_7.png","w_8.png","w_9.png","w_10.png","w_11.png","w_12.png","w_13.png","w_14.png","w_15.png","w_16.png","w_17.png","w_18.png","w_19.png","w_20.png","w_21.png","w_22.png","w_23.png","w_24.png","w_25.png","w_26.png","w_27.png","w_28.png","w_29.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
			
			normal_image_weather = hmUI.createWidget(hmUI.widget.IMG, {
              x: 158,
              y: 280,
              src: 'temperature.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
			
			normal_weather_pointer_progress_img_pointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
              src: 'Pointer01.png',
              center_x: 233,
              center_y: 353,
              x: 16,
              y: 70,
              start_angle: -136,
              end_angle: 136,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 202,
              y: 385,
              font_array: ["num_0.png","num_1.png","num_2.png","num_3.png","num_4.png","num_5.png","num_6.png","num_7.png","num_8.png","num_9.png"],
              padding: false,
              h_space: -2,
              unit_sc: 'du.png',
              unit_tc: 'du.png',
              unit_en: 'du.png',
              negative_image: 'negative1.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
			
			normal_image_weight = hmUI.createWidget(hmUI.widget.IMG, {
              x: 267,
              y: 157,
              src: 'weight.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
			
			L = hmUI.createWidget(hmUI.widget.TEXT, {
                    x: 292,
                    y: 202,
                    w: 100,
                    h: 50,
                    color: 0xffffff,
                    text_size: 35,
                    align_h: hmUI.align.CENTER_H,
                    align_v: hmUI.align.CENTER_V,
                    text_style: hmUI.text_style.NONE,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
				
			normal_image_age = hmUI.createWidget(hmUI.widget.IMG, {
              x: 267,
              y: 157,
              src: 'age.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

			G = hmUI.createWidget(hmUI.widget.TEXT, {
                    x: 292,
                    y: 205,
                    w: 100,
                    h: 50,
                    color: 0xffffff,
                    text_size: 45,
                    align_h: hmUI.align.CENTER_H,
                    align_v: hmUI.align.CENTER_V,
                    text_style: hmUI.text_style.NONE,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
				
			normal_image_height = hmUI.createWidget(hmUI.widget.IMG, {
              x: 267,
              y: 157,
              src: 'heigh.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

			H = hmUI.createWidget(hmUI.widget.TEXT, {
                    x: 292,
                    y: 202,
                    w: 100,
                    h: 50,
                    color: 0xffffff,
                    text_size: 35,
                    align_h: hmUI.align.CENTER_H,
                    align_v: hmUI.align.CENTER_V,
                    text_style: hmUI.text_style.NONE,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
			
			normal_image_alarm = hmUI.createWidget(hmUI.widget.IMG, {
              x: 158,
              y: 40,
              src: 'clock.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
			
			alarm_clock_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 190,
              y: 120,
              font_array: ["num_0.png","num_1.png","num_2.png","num_3.png","num_4.png","num_5.png","num_6.png","num_7.png","num_8.png","num_9.png"],
              padding: true,
              h_space: 0,
              dot_image: 'colon.png',
			  invalid_image: 'negative2.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.ALARM_CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
			
			normal_image_altitude = hmUI.createWidget(hmUI.widget.IMG, {
              x: 158,
              y: 40,
              src: 'altitude.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
			
			normal_altitude_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 193,
              y: 107,
              font_array: ["num_0.png","num_1.png","num_2.png","num_3.png","num_4.png","num_5.png","num_6.png","num_7.png","num_8.png","num_9.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.ALTITUDE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
			
			normal_image_sleep = hmUI.createWidget(hmUI.widget.IMG, {
              x: 158,
              y: 40,
              src: 'sleep.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
			
			sleep_time_txt = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 195,			
              y: 110,			
			  w: 100,			
			  h: 50,			
			  text_size: 30,	
			  text: '',
			  color: 0xffffff,	
              align_h: hmUI.align.LEFT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
			
			normal_image_load = hmUI.createWidget(hmUI.widget.IMG, {
              x: 158,
              y: 40,
              src: 'training_load.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
			
			normal_load_pointer_progress_img_pointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
              src: 'Pointer.png',
              center_x: 232,
              center_y: 114,
              x: 11,
              y: 72,
              start_angle: -135,
              end_angle: 135,
              type: hmUI.data_type.TRAINING_LOAD,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
			
			normal_training_load_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 194,
              y: 80,
              font_array: ["n_0.png","n_1.png","n_2.png","n_3.png","n_4.png","n_5.png","n_6.png","n_7.png","n_8.png","n_9.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.TRAINING_LOAD,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
			
			normal_image_aqi = hmUI.createWidget(hmUI.widget.IMG, {
              x: 158,
              y: 280,
              src: 'AQI.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
			
			normal_aqi_pointer_progress_img_pointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
              src: 'Pointer01.png',
              center_x: 233,
              center_y: 354,
              x: 15,
              y: 70,
              start_angle: -133,
              end_angle: 136,
              type: hmUI.data_type.AQI,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 158,
              y: 40,
              src: 'battery.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_pointer_progress_img_pointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
              src: 'Pointer.png',
              center_x: 232,
              center_y: 114,
              x: 11,
              y: 72,
              start_angle: -135,
              end_angle: 135,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 194,
              y: 80,
              font_array: ["n_0.png","n_1.png","n_2.png","n_3.png","n_4.png","n_5.png","n_6.png","n_7.png","n_8.png","n_9.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
			
			normal_image_data = hmUI.createWidget(hmUI.widget.IMG, {
              x: 158,
              y: 40,
              src: 'date.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
			
			let dned=["week_0.png","week_1.png","week_2.png","week_3.png","week_4.png","week_5.png","week_6.png"]
			if(lang=='ru-RU'){
				dned=["weekru_0.png","weekru_1.png","weekru_2.png","weekru_3.png","weekru_4.png","weekru_5.png","weekru_6.png"]
			}

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 196,
              y: 80,
              week_en: dned,
              week_tc: ["week_0.png","week_1.png","week_2.png","week_3.png","week_4.png","week_5.png","week_6.png"],
              week_sc: ["week_0.png","week_1.png","week_2.png","week_3.png","week_4.png","week_5.png","week_6.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 207,
              day_startY: 105,
              day_sc_array: ["n_0.png","n_1.png","n_2.png","n_3.png","n_4.png","n_5.png","n_6.png","n_7.png","n_8.png","n_9.png"],
              day_tc_array: ["n_0.png","n_1.png","n_2.png","n_3.png","n_4.png","n_5.png","n_6.png","n_7.png","n_8.png","n_9.png"],
              day_en_array: ["n_0.png","n_1.png","n_2.png","n_3.png","n_4.png","n_5.png","n_6.png","n_7.png","n_8.png","n_9.png"],
              day_zero: 1,
              day_space: 0,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_moon_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 158,
              y: 280,
              image_array: ["moon_1.png","moon_2.png","moon_3.png","moon_4.png","moon_5.png","moon_6.png","moon_7.png","moon_8.png","moon_9.png","moon_10.png","moon_11.png","moon_12.png","moon_13.png","moon_14.png","moon_15.png","moon_16.png","moon_17.png","moon_18.png","moon_19.png","moon_20.png","moon_21.png","moon_22.png","moon_23.png","moon_24.png","moon_25.png","moon_26.png","moon_27.png","moon_28.png","moon_29.png","moon_30.png"],
              image_length: 30,
              type: hmUI.data_type.MOON,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_altimeter_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 158,
              y: 280,
              src: 'pressure.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_altimeter_pointer_progress_img_pointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
              src: 'Pointer.png',
              center_x: 233,
              center_y: 353,
              x: 11,
              y: 71,
              start_angle: -133,
              end_angle: 133,
              type: hmUI.data_type.ALTIMETER,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_altimeter_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 198,
              y: 336,
              font_array: ["num_0.png","num_1.png","num_2.png","num_3.png","num_4.png","num_5.png","num_6.png","num_7.png","num_8.png","num_9.png"],
              padding: false,
              h_space: -2,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.ALTIMETER,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_wind_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 158,
              y: 280,
              src: 'wind.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_wind_pointer_progress_img_pointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
              src: 'Pointer.png',
              center_x: 233,
              center_y: 353,
              x: 11,
              y: 70,
              start_angle: -133,
              end_angle: 133,
              type: hmUI.data_type.WIND,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_wind_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 207,
              y: 325,
              font_array: ["n_0.png","n_1.png","n_2.png","n_3.png","n_4.png","n_5.png","n_6.png","n_7.png","n_8.png","n_9.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WIND,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sun_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 158,
              y: 280,
              src: 'sunrise.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sun_high_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 183,
              y: 355,
              font_array: ["num_0.png","num_1.png","num_2.png","num_3.png","num_4.png","num_5.png","num_6.png","num_7.png","num_8.png","num_9.png"],
              padding: false,
              h_space: 0,
              dot_image: 'colon.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.SUN_RISE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
			
			normal_image_sunrise = hmUI.createWidget(hmUI.widget.IMG, {
              x: 158,
              y: 280,
              src: 'sunrise.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sun_low_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 183,
              y: 355,
              font_array: ["num_0.png","num_1.png","num_2.png","num_3.png","num_4.png","num_5.png","num_6.png","num_7.png","num_8.png","num_9.png"],
              padding: false,
              h_space: 0,
              dot_image: 'colon.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.SUN_SET,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_humidity_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 158,
              y: 280,
              src: 'humidity.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_humidity_pointer_progress_img_pointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
              src: 'Pointer.png',
              center_x: 233,
              center_y: 353,
              x: 11,
              y: 72,
              start_angle: -138,
              end_angle: 137,
              type: hmUI.data_type.HUMIDITY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_humidity_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 193,
              y: 323,
              font_array: ["n_0.png","n_1.png","n_2.png","n_3.png","n_4.png","n_5.png","n_6.png","n_7.png","n_8.png","n_9.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HUMIDITY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_uvi_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 158,
              y: 280,
              src: 'UVI.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_uvi_pointer_progress_img_pointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
              src: 'Pointer.png',
              center_x: 233,
              center_y: 354,
              x: 11,
              y: 72,
              start_angle: -133,
              end_angle: 136,
              type: hmUI.data_type.UVI,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_uvi_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 205,
              y: 323,
              font_array: ["n_0.png","n_1.png","n_2.png","n_3.png","n_4.png","n_5.png","n_6.png","n_7.png","n_8.png","n_9.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.UVI,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_spo2_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 267,
              y: 157,
              src: 'spO2.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_spo2_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 303,
              y: 213,
              font_array: ["n_0.png","n_1.png","n_2.png","n_3.png","n_4.png","n_5.png","n_6.png","n_7.png","n_8.png","n_9.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.SPO2,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_stress_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 267,
              y: 157,
              src: 'stress.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_stress_pointer_progress_img_pointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
              src: 'Pointer.png',
              center_x: 341,
              center_y: 231,
              x: 11,
              y: 71,
              start_angle: -139,
              end_angle: 137,
              type: hmUI.data_type.STRESS,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_stress_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 302,
              y: 202,
              font_array: ["n_0.png","n_1.png","n_2.png","n_3.png","n_4.png","n_5.png","n_6.png","n_7.png","n_8.png","n_9.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STRESS,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_calorie_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 267,
              y: 157,
              src: 'calorie.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_cal_circle_scale = hmUI.createWidget(hmUI.widget.Circle_Scale, {
              // center_x: 341,
              // center_y: 231,
              // start_angle: 0,
              // end_angle: 360,
              // radius: 62,
              // line_width: 10,
              // line_cap: Flat,
              // color: 0xFF0080FF,
              // mirror: False,
              // inversion: False,
              // type: hmUI.data_type.CAL,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            let screenType = hmSetting.getScreenType();
            normal_calorie_circle_scale = hmUI.createWidget(hmUI.widget.ARC_PROGRESS, {
              center_x: 341,
              center_y: 231,
              start_angle: 0,
              end_angle: 360,
              radius: 57,
              line_width: 10,
              corner_flag: 3,
              color: 0xFF0080FF,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            
            const calorie = hmSensor.createSensor(hmSensor.id.CALORIE);
            calorie.addEventListener(hmSensor.event.CHANGE, function() {
              scale_call();
            });

            normal_calorie_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 306,
              y: 225,
              font_array: ["num_0.png","num_1.png","num_2.png","num_3.png","num_4.png","num_5.png","num_6.png","num_7.png","num_8.png","num_9.png"],
              padding: false,
              h_space: -2,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 267,
              y: 157,
              src: 'heart.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_pointer_progress_img_pointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
              src: 'Pointer.png',
              center_x: 341,
              center_y: 231,
              x: 11,
              y: 72,
              start_angle: -130,
              end_angle: 133,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 302,
              y: 202,
              font_array: ["n_0.png","n_1.png","n_2.png","n_3.png","n_4.png","n_5.png","n_6.png","n_7.png","n_8.png","n_9.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_pai_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 50,
              y: 157,
              src: 'PAI.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_pai_pointer_progress_img_pointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
              src: 'Pointer.png',
              center_x: 124,
              center_y: 231,
              x: 11,
              y: 72,
              start_angle: -133,
              end_angle: 134,
              type: hmUI.data_type.PAI_WEEKLY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
			
			normal_image_pai = hmUI.createWidget(hmUI.widget.IMG, {
              x: 50,
              y: 157,
              src: 'PAI2.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_pai_weekly_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 97,
              y: 228,
              font_array: ["num_0.png","num_1.png","num_2.png","num_3.png","num_4.png","num_5.png","num_6.png","num_7.png","num_8.png","num_9.png"],
              padding: false,
              h_space: -3,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.PAI_WEEKLY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_pai_day_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 88,
              y: 200,
              font_array: ["n_0.png","n_1.png","n_2.png","n_3.png","n_4.png","n_5.png","n_6.png","n_7.png","n_8.png","n_9.png"],
              padding: false,
              h_space: -2,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.PAI_DAILY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_fat_burning_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 50,
              y: 157,
              src: 'fat.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_fat_burning_circle_scale = hmUI.createWidget(hmUI.widget.Circle_Scale, {
              // center_x: 124,
              // center_y: 231,
              // start_angle: 0,
              // end_angle: 360,
              // radius: 62,
              // line_width: 10,
              // line_cap: Flat,
              // color: 0xFF008000,
              // mirror: False,
              // inversion: False,
              // type: hmUI.data_type.FAT_BURNING,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_fat_burning_circle_scale = hmUI.createWidget(hmUI.widget.ARC_PROGRESS, {
              center_x: 124,
              center_y: 231,
              start_angle: 0,
              end_angle: 360,
              radius: 57,
              line_width: 10,
              corner_flag: 3,
              color: 0xFF008000,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            
            const fat_burning = hmSensor.createSensor(hmSensor.id.FAT_BURRING);
            fat_burning.addEventListener(hmSensor.event.CHANGE, function() {
              scale_call();
            });

            normal_fat_burning_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 95,
              y: 225,
              font_array: ["num_0.png","num_1.png","num_2.png","num_3.png","num_4.png","num_5.png","num_6.png","num_7.png","num_8.png","num_9.png"],
              padding: false,
              h_space: -1,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.FAT_BURNING,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
			
			normal_image_floor = hmUI.createWidget(hmUI.widget.IMG, {
              x: 50,
              y: 157,
              src: 'floor.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
			
			normal_floor_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 97,
              y: 230,
              font_array: ["num_0.png","num_1.png","num_2.png","num_3.png","num_4.png","num_5.png","num_6.png","num_7.png","num_8.png","num_9.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.FLOOR,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_stand_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 50,
              y: 157,
              src: 'stand.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_stand_circle_scale = hmUI.createWidget(hmUI.widget.Circle_Scale, {
              // center_x: 124,
              // center_y: 231,
              // start_angle: 0,
              // end_angle: 360,
              // radius: 62,
              // line_width: 10,
              // line_cap: Flat,
              // color: 0xFF0080FF,
              // mirror: False,
              // inversion: False,
              // type: hmUI.data_type.STAND,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_stand_circle_scale = hmUI.createWidget(hmUI.widget.ARC_PROGRESS, {
              center_x: 124,
              center_y: 231,
              start_angle: 0,
              end_angle: 360,
              radius: 57,
              line_width: 10,
              corner_flag: 3,
              color: 0xFF0080FF,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            
            const stand = hmSensor.createSensor(hmSensor.id.STAND);
            stand.addEventListener(hmSensor.event.CHANGE, function() {
              scale_call();
            });

            normal_stand_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 104,
              y: 225,
              font_array: ["num_0.png","num_1.png","num_2.png","num_3.png","num_4.png","num_5.png","num_6.png","num_7.png","num_8.png","num_9.png"],
              padding: true,
              h_space: -2,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.STAND,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_distance_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 50,
              y: 157,
              src: 'dist.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_distance_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 82,
              y: 225,
              font_array: ["num_0.png","num_1.png","num_2.png","num_3.png","num_4.png","num_5.png","num_6.png","num_7.png","num_8.png","num_9.png"],
              padding: false,
              h_space: -1,
              dot_image: 'dot1.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.DISTANCE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 50,
              y: 157,
              src: 'step.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_step_circle_scale = hmUI.createWidget(hmUI.widget.Circle_Scale, {
              // center_x: 124,
              // center_y: 231,
              // start_angle: 0,
              // end_angle: 360,
              // radius: 62,
              // line_width: 10,
              // line_cap: Flat,
              // color: 0xFFFFFF00,
              // mirror: False,
              // inversion: False,
              // type: hmUI.data_type.STEP,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_step_circle_scale = hmUI.createWidget(hmUI.widget.ARC_PROGRESS, {
              center_x: 124,
              center_y: 231,
              start_angle: 0,
              end_angle: 360,
              radius: 57,
              line_width: 10,
              corner_flag: 3,
              color: 0xFFFFFF00,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            
            const step = hmSensor.createSensor(hmSensor.id.STEP);
            step.addEventListener(hmSensor.event.CHANGE, function() {
              scale_call();
            });

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 80,
              y: 223,
              font_array: ["num_0.png","num_1.png","num_2.png","num_3.png","num_4.png","num_5.png","num_6.png","num_7.png","num_8.png","num_9.png"],
              padding: false,
              h_space: -3,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_hour = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              hour_path: 'hour.png',
              hour_centerX: 233,
              hour_centerY: 233,
              hour_posX: 25,
              hour_posY: 169,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_minute = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              minute_path: 'minute.png',
              minute_centerX: 233,
              minute_centerY: 233,
              minute_posX: 50,
              minute_posY: 241,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_second = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              second_path: 'second.png',
              second_centerX: 233,
              second_centerY: 233,
              second_posX: 22,
              second_posY: 239,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
			
			normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 222,
              y: 222,
              src: 'bluetooth_(10).png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            btn_zona1 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 75,
              y: 185,
              text: '',
              w: 100,
              h: 100,
              normal_src: 'Empty.png',
              press_src: 'Empty.png',
              click_func: () => {
				click_zona1();
                click_Vibrate();
              },
			  longpress_func: () => {
             hmApp.startApp({ url: "activityAppScreen", native: true });
             },
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            btn_zona1.setProperty(hmUI.prop.VISIBLE, true);
			normal_distance_icon_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_distance_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_stand_icon_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_stand_circle_scale.setProperty(hmUI.prop.VISIBLE, false);
			normal_stand_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_fat_burning_icon_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_fat_burning_circle_scale.setProperty(hmUI.prop.VISIBLE, false);
			normal_fat_burning_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_pai_icon_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_pai_pointer_progress_img_pointer.setProperty(hmUI.prop.VISIBLE, false);
			normal_pai_day_text_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_image_pai.setProperty(hmUI.prop.VISIBLE, false);
			normal_pai_weekly_text_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_image_floor.setProperty(hmUI.prop.VISIBLE, false);
			normal_floor_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
			

            btn_zona2 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 300,
              y: 185,
              text: '',
              w: 100,
              h: 100,
              normal_src: 'Empty.png',
              press_src: 'Empty.png',
              click_func: () => {
				click_zona2();
                click_Vibrate();
              },
			  longpress_func: () => {
             hmApp.startApp({ url: "heart_app_Screen", native: true });
             },
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            btn_zona2.setProperty(hmUI.prop.VISIBLE, true);
			normal_calorie_icon_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_calorie_circle_scale.setProperty(hmUI.prop.VISIBLE, false);
			normal_calorie_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_stress_icon_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_stress_pointer_progress_img_pointer.setProperty(hmUI.prop.VISIBLE, false);
			normal_stress_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_spo2_icon_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_spo2_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_image_weight.setProperty(hmUI.prop.VISIBLE, false);
			L.setProperty(hmUI.prop.VISIBLE, false);
			normal_image_age.setProperty(hmUI.prop.VISIBLE, false);
			G.setProperty(hmUI.prop.VISIBLE, false);
			normal_image_height.setProperty(hmUI.prop.VISIBLE, false);
			H.setProperty(hmUI.prop.VISIBLE, false);
			

           btn_zona3 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 190,
              y: 310,
              text: '',
              w: 100,
              h: 100,
              normal_src: 'Empty.png',
              press_src: 'Empty.png',
              click_func: () => {
				click_zona3();
                click_Vibrate();
              },
			  longpress_func: () => {
             hmApp.startApp({ url: "WeatherScreen", native: true });
             },
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            btn_zona3.setProperty(hmUI.prop.VISIBLE, true);
			normal_humidity_icon_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_humidity_pointer_progress_img_pointer.setProperty(hmUI.prop.VISIBLE, false);
			normal_humidity_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_sun_icon_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_sun_high_text_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_image_sunrise.setProperty(hmUI.prop.VISIBLE, false);
			normal_sun_low_text_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_wind_icon_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_wind_pointer_progress_img_pointer.setProperty(hmUI.prop.VISIBLE, false);
			normal_wind_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_altimeter_icon_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_altimeter_pointer_progress_img_pointer.setProperty(hmUI.prop.VISIBLE, false);
			normal_altimeter_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_moon_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, false);
			normal_image_aqi.setProperty(hmUI.prop.VISIBLE, false);
			normal_aqi_pointer_progress_img_pointer.setProperty(hmUI.prop.VISIBLE, false);
			normal_temperature_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_weather_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, false);
			normal_weather_pointer_progress_img_pointer.setProperty(hmUI.prop.VISIBLE, false);
			icon_bg.setProperty(hmUI.prop.VISIBLE, false);
			normal_image_weather.setProperty(hmUI.prop.VISIBLE, false);

            btn_zona4 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 185,
              y: 80,
              text: '',
              w: 100,
              h: 100,
              normal_src: 'Empty.png',
              press_src: 'Empty.png',
              click_func: () => {
				click_zona4();
                click_Vibrate();
             },
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            btn_zona4.setProperty(hmUI.prop.VISIBLE, true);
			normal_image_data.setProperty(hmUI.prop.VISIBLE, false);
			normal_date_img_date_week_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_date_img_date_day.setProperty(hmUI.prop.VISIBLE, false);
			normal_image_sleep.setProperty(hmUI.prop.VISIBLE, false);
			sleep_time_txt.setProperty(hmUI.prop.VISIBLE, false);
			normal_image_load.setProperty(hmUI.prop.VISIBLE, false);
			normal_load_pointer_progress_img_pointer.setProperty(hmUI.prop.VISIBLE, false);
			normal_training_load_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_image_alarm.setProperty(hmUI.prop.VISIBLE, false);
			alarm_clock_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_compass_icon_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_compass_direction_pointer_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_compass_text_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_compass_direction_img_level.setProperty(hmUI.prop.VISIBLE, false);
			normal_image_altitude.setProperty(hmUI.prop.VISIBLE, false);
			normal_altitude_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
			
			btn_zona4.addEventListener(hmUI.event.CLICK_DOWN, function () {
					if(longPress_Timer) timer.stopTimer(longPress_Timer);
					longPress_Timer = timer.createTimer(longPressDelay, 0, getLongPress1, {});
			});
			btn_zona4.addEventListener(hmUI.event.CLICK_UP, function () {
					if(longPress_Timer) timer.stopTimer(longPress_Timer);
			});

            function scale_call() {

                console.log('update scales CALORIE');
                
                let valueCalories = calorie.current;
                let targetCalories = calorie.target;
                let progressCalories = valueCalories/targetCalories;
                if (progressCalories > 1) progressCalories = 1;
                let progress_cs_normal_calorie = progressCalories;

                if (screenType != hmSetting.screen_type.AOD) {

                  // normal_calorie_circle_scale_circle_scale
                  let level = Math.round(progress_cs_normal_calorie * 100);
                  if (normal_calorie_circle_scale) {
                    normal_calorie_circle_scale.setProperty(hmUI.prop.MORE, {                      
                      center_x: 341,
                      center_y: 231,
                      start_angle: 0,
                      end_angle: 360,
                      radius: 57,
                      line_width: 10,
                      corner_flag: 3,
                      color: 0xFF0080FF,
                      show_level: hmUI.show_level.ONLY_NORMAL,
                      level: level,
                    });
                  };
                };

                console.log('update scales FAT_BURNING');
                
                let valueFatBurning = fat_burning.current;
                let targetFatBurning = fat_burning.target;
                let progressFatBurning = valueFatBurning/targetFatBurning;
                if (progressFatBurning > 1) progressFatBurning = 1;
                let progress_cs_normal_fat_burning = progressFatBurning;

                if (screenType != hmSetting.screen_type.AOD) {

                  // normal_fat_burning_circle_scale_circle_scale
                  let level = Math.round(progress_cs_normal_fat_burning * 100);
                  if (normal_fat_burning_circle_scale) {
                    normal_fat_burning_circle_scale.setProperty(hmUI.prop.MORE, {                      
                      center_x: 124,
                      center_y: 231,
                      start_angle: 0,
                      end_angle: 360,
                      radius: 57,
                      line_width: 10,
                      corner_flag: 3,
                      color: 0xFF008000,
                      show_level: hmUI.show_level.ONLY_NORMAL,
                      level: level,
                    });
                  };
                };

                console.log('update scales STAND');
                
                let valueStand = stand.current;
                let targetStand = stand.target;
                let progressStand = valueStand/targetStand;
                if (progressStand > 1) progressStand = 1;
                let progress_cs_normal_stand = progressStand;

                if (screenType != hmSetting.screen_type.AOD) {

                  // normal_stand_circle_scale_circle_scale
                  let level = Math.round(progress_cs_normal_stand * 100);
                  if (normal_stand_circle_scale) {
                    normal_stand_circle_scale.setProperty(hmUI.prop.MORE, {                      
                      center_x: 124,
                      center_y: 231,
                      start_angle: 0,
                      end_angle: 360,
                      radius: 57,
                      line_width: 10,
                      corner_flag: 3,
                      color: 0xFF0080FF,
                      show_level: hmUI.show_level.ONLY_NORMAL,
                      level: level,
                    });
                  };
                };

                console.log('update scales STEP');
                
                let valueStep = step.current;
                let targetStep = step.target;
                let progressStep = valueStep/targetStep;
                if (progressStep > 1) progressStep = 1;
                let progress_cs_normal_step = progressStep;

                if (screenType != hmSetting.screen_type.AOD) {

                  // normal_step_circle_scale_circle_scale
                  let level = Math.round(progress_cs_normal_step * 100);
                  if (normal_step_circle_scale) {
                    normal_step_circle_scale.setProperty(hmUI.prop.MORE, {                      
                      center_x: 124,
                      center_y: 231,
                      start_angle: 0,
                      end_angle: 360,
                      radius: 57,
                      line_width: 10,
                      corner_flag: 3,
                      color: 0xFFFFFF00,
                      show_level: hmUI.show_level.ONLY_NORMAL,
                      level: level,
                    });
                  };
                };

            };
			
			//start of ignored block
            console.log('compass_update()');
            if (screenType == hmSetting.screen_type.WATCHFACE){
              compass = hmSensor.createSensor(hmSensor.id.COMPASS);
              compass.start();

              if (compass.direction_angle && compass.direction  && compass.direction_angle != 'INVALID') { // initial data
                // Compass Pointer
                let compass_direction_angle = parseInt(compass.direction_angle);
                normal_compass_direction_pointer_img.setProperty(hmUI.prop.ANGLE, -compass_direction_angle);
                // Compass Number
                let normal_compass_direction_angle_text = compass_direction_angle.toString();
                normal_compass_text_img.setProperty(hmUI.prop.TEXT, normal_compass_direction_angle_text);
                // Compass Images
                let compass_direction_angle_img = compass_direction_angle + 45 / 2;
                let compass_direction_index = parseInt(compass_direction_angle_img/45);
                if (compass_direction_index > 7) compass_direction_index = 0;
                normal_compass_direction_img_level.setProperty(hmUI.prop.SRC, normal_compass_direction_arr[compass_direction_index]);

              } else { // error data
                normal_compass_direction_pointer_img.setProperty(hmUI.prop.ANGLE, 0);
                normal_compass_text_img.setProperty(hmUI.prop.TEXT, '-');
                normal_compass_direction_img_level.setProperty(hmUI.prop.SRC, normal_compass_direction_arr[0]);

              }

              compass.addEventListener(hmSensor.event.CHANGE, function (compass_res) { // change values when changing direction

                if (compass_res.calibration_status) {
                  // Compass Pointer
                  let compass_direction_angle = parseInt(compass_res.direction_angle);
                  normal_compass_direction_pointer_img.setProperty(hmUI.prop.ANGLE, -compass_direction_angle);
                  // Compass Number
                  let normal_compass_direction_angle_text = compass_direction_angle.toString();
                  normal_compass_text_img.setProperty(hmUI.prop.TEXT, normal_compass_direction_angle_text);
                  // Compass Images
                  let compass_direction_angle_img = compass_direction_angle + 45 / 2;
                  let compass_direction_index = parseInt(compass_direction_angle_img/45);
                  if (compass_direction_index > 7) compass_direction_index = 0;
                  normal_compass_direction_img_level.setProperty(hmUI.prop.SRC, normal_compass_direction_arr[compass_direction_index]);

                } else { // error data
                  normal_compass_direction_pointer_img.setProperty(hmUI.prop.ANGLE, 0);
                  normal_compass_text_img.setProperty(hmUI.prop.TEXT, '-');
                  normal_compass_direction_img_level.setProperty(hmUI.prop.SRC, normal_compass_direction_arr[0]);

                }

              }); // Listener end

            };
            //end of ignored block
			
			const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                console.log('resume_call()');
                autoToggleBg();
					scale_call();
					updateSleepInfo();
					L.setProperty(hmUI.prop.TEXT, hmSetting.getUserData().weight.toFixed(2).toString())
					G.setProperty(hmUI.prop.TEXT, hmSetting.getUserData().age.toString())
					H.setProperty(hmUI.prop.TEXT, hmSetting.getUserData().height.toFixed(2).toString())
                if (compass && screenType == hmSetting.screen_type.WATCHFACE) compass.start();

              }),
              pause_call: (function () {
                console.log('pause_call()');
                if (compass) compass.stop();

              }),
            });

                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
				logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}