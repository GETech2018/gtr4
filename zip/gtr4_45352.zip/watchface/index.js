﻿try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const logger = Logger.getLogger('plum');
        //end of ignored block

        // Plum (cantaloupe) - converted for Amazfit GTR 4 (466 x 466)
        // Original design: "Digi_104" by HMKWatch, Zepp OS version by ZduneX25.

        let introAnim = '';

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                console.log('Watch_Face.ScreenNormal');

                // background
                hmUI.createWidget(hmUI.widget.IMG, {
                    x: 0, y: 0, w: 466, h: 466,
                    src: '0002.png',
                    show_level: hmUI.show_level.ONLY_NORMAL,
                });

                // battery number (top of the face, next to the bolt that is part of the background)
                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                    x: 224, y: 36,
                    font_array: ['0097.png', '0098.png', '0099.png', '0100.png', '0101.png', '0102.png', '0103.png', '0104.png', '0105.png', '0106.png'],
                    padding: false, h_space: 1,
                    align_h: hmUI.align.LEFT,
                    type: hmUI.data_type.BATTERY,
                    show_level: hmUI.show_level.ONLY_NORMAL,
                });

                // PAI
                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                    x: 276, y: 360,
                    font_array: ['0043.png', '0044.png', '0045.png', '0046.png', '0047.png', '0048.png', '0049.png', '0050.png', '0051.png', '0052.png'],
                    padding: true, h_space: 4,
                    align_h: hmUI.align.CENTER_H,
                    type: hmUI.data_type.PAI_WEEKLY,
                    show_level: hmUI.show_level.ONLY_NORMAL,
                });

                // heart rate value
                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                    x: 124, y: 318,
                    font_array: ['0033.png', '0034.png', '0035.png', '0036.png', '0037.png', '0038.png', '0039.png', '0040.png', '0041.png', '0042.png'],
                    padding: true, h_space: 0,
                    align_h: hmUI.align.CENTER_H,
                    type: hmUI.data_type.HEART,
                    show_level: hmUI.show_level.ONLY_NORMAL,
                });

                // heart rate zone label
                hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
                    x: 127, y: 373,
                    image_array: ['0084.png', '0085.png', '0086.png', '0087.png', '0088.png', '0089.png'],
                    image_length: 6,
                    type: hmUI.data_type.HEART,
                    show_level: hmUI.show_level.ONLY_NORMAL,
                });

                // calories
                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                    x: 204, y: 407,
                    font_array: ['0043.png', '0044.png', '0045.png', '0046.png', '0047.png', '0048.png', '0049.png', '0050.png', '0051.png', '0052.png'],
                    padding: true, h_space: 4,
                    align_h: hmUI.align.CENTER_H,
                    type: hmUI.data_type.CAL,
                    show_level: hmUI.show_level.ONLY_NORMAL,
                });

                // steps
                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                    x: 276, y: 321,
                    font_array: ['0043.png', '0044.png', '0045.png', '0046.png', '0047.png', '0048.png', '0049.png', '0050.png', '0051.png', '0052.png'],
                    padding: true, h_space: 4,
                    align_h: hmUI.align.RIGHT,
                    type: hmUI.data_type.STEP,
                    show_level: hmUI.show_level.ONLY_NORMAL,
                });

                // weekday
                hmUI.createWidget(hmUI.widget.IMG_WEEK, {
                    x: 100, y: 109,
                    week_en: ['0065.png', '0066.png', '0067.png', '0068.png', '0069.png', '0070.png', '0071.png'],
                    show_level: hmUI.show_level.ONLY_NORMAL,
                });

                // month
                hmUI.createWidget(hmUI.widget.IMG_DATE, {
                    month_startX: 276, month_startY: 109,
                    month_en_array: ['0053.png', '0054.png', '0055.png', '0056.png', '0057.png', '0058.png', '0059.png', '0060.png', '0061.png', '0062.png', '0063.png', '0064.png'],
                    month_is_character: true,
                    show_level: hmUI.show_level.ONLY_NORMAL,
                });

                // day
                hmUI.createWidget(hmUI.widget.IMG_DATE, {
                    day_startX: 203, day_startY: 100,
                    day_en_array: ['0023.png', '0024.png', '0025.png', '0026.png', '0027.png', '0028.png', '0029.png', '0030.png', '0031.png', '0032.png'],
                    day_zero: 1, day_space: 0,
                    day_align: hmUI.align.CENTER_H,
                    day_is_character: false,
                    show_level: hmUI.show_level.ONLY_NORMAL,
                });

                // AM / PM
                hmUI.createWidget(hmUI.widget.IMG_TIME, {
                    am_x: 410, am_y: 206, am_en_path: '0082.png',
                    pm_x: 410, pm_y: 206, pm_en_path: '0083.png',
                    show_level: hmUI.show_level.ONLY_NORMAL,
                });

                // main time
                hmUI.createWidget(hmUI.widget.IMG_TIME, {
                    hour_startX: 71, hour_startY: 170,
                    hour_array: ['0003.png', '0004.png', '0005.png', '0006.png', '0007.png', '0008.png', '0009.png', '0010.png', '0011.png', '0012.png'],
                    hour_zero: 1, hour_space: 1,
                    hour_align: hmUI.align.LEFT,
                    minute_startX: 241, minute_startY: 170,
                    minute_array: ['0013.png', '0014.png', '0015.png', '0016.png', '0017.png', '0018.png', '0019.png', '0020.png', '0021.png', '0022.png'],
                    minute_zero: 1, minute_space: 1,
                    minute_follow: 0,
                    minute_align: hmUI.align.LEFT,
                    show_level: hmUI.show_level.ONLY_NORMAL,
                });

                // seconds
                hmUI.createWidget(hmUI.widget.IMG_TIME, {
                    second_startX: 406, second_startY: 234,
                    second_array: ['0072.png', '0073.png', '0074.png', '0075.png', '0076.png', '0077.png', '0078.png', '0079.png', '0080.png', '0081.png'],
                    second_zero: 1, second_space: 1,
                    second_follow: 0,
                    second_align: hmUI.align.LEFT,
                    show_level: hmUI.show_level.ONLY_NORMAL,
                });

                // always-on display
                hmUI.createWidget(hmUI.widget.IMG, {
                    x: 0, y: 0, w: 466, h: 466,
                    src: '0091.png',
                    show_level: hmUI.show_level.ONLY_AOD,
                });
                hmUI.createWidget(hmUI.widget.IMG_TIME, {
                    am_x: 410, am_y: 206, am_en_path: '0082.png',
                    pm_x: 410, pm_y: 206, pm_en_path: '0083.png',
                    show_level: hmUI.show_level.ONLY_AOD,
                });
                hmUI.createWidget(hmUI.widget.IMG_TIME, {
                    hour_startX: 71, hour_startY: 170,
                    hour_array: ['0003.png', '0004.png', '0005.png', '0006.png', '0007.png', '0008.png', '0009.png', '0010.png', '0011.png', '0012.png'],
                    hour_zero: 1, hour_space: 1,
                    hour_align: hmUI.align.LEFT,
                    minute_startX: 241, minute_startY: 170,
                    minute_array: ['0013.png', '0014.png', '0015.png', '0016.png', '0017.png', '0018.png', '0019.png', '0020.png', '0021.png', '0022.png'],
                    minute_zero: 1, minute_space: 1,
                    minute_follow: 0,
                    minute_align: hmUI.align.LEFT,
                    show_level: hmUI.show_level.ONLY_AOD,
                });

                // reveal animation when the screen wakes
                introAnim = hmUI.createWidget(hmUI.widget.IMG_ANIM, {
                    x: 0, y: 0,
                    anim_path: 'anim',
                    anim_prefix: 'animation',
                    anim_ext: 'png',
                    anim_fps: 60,
                    anim_size: 33,
                    repeat_count: 1,
                    anim_repeat: false,
                    anim_status: hmUI.anim_status.START,
                    show_level: hmUI.show_level.ONLY_NORMAL,
                });

                // tap areas: heart rate, steps and calories open their app screens
                hmUI.createWidget(hmUI.widget.IMG_CLICK, {
                    x: 86, y: 314, w: 132, h: 80,
                    type: hmUI.data_type.HEART,
                    show_level: hmUI.show_level.ONLY_NORMAL,
                });
                hmUI.createWidget(hmUI.widget.IMG_CLICK, {
                    x: 238, y: 318, w: 150, h: 36,
                    type: hmUI.data_type.STEP,
                    show_level: hmUI.show_level.ONLY_NORMAL,
                });
                hmUI.createWidget(hmUI.widget.IMG_CLICK, {
                    x: 172, y: 403, w: 124, h: 36,
                    type: hmUI.data_type.CAL,
                    show_level: hmUI.show_level.ONLY_NORMAL,
                });

                hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
                    resume_call: function () {
                        introAnim.setProperty(hmUI.prop.ANIM_STATUS, hmUI.anim_status.START);
                    },
                    pause_call: function () {
                        introAnim.setProperty(hmUI.prop.ANIM_STATUS, hmUI.anim_status.STOP);
                    },
                });
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}
