﻿/*
** Watch_Face_Editor tool
** watchface js version v2.1.1
** Copyright © SashaCX75. All Rights Reserved
*/

try {
  (() => {
    //start of ignored block
    const __$$app$$__ = __$$hmAppManager$$__.currentApp;
    function getApp() {
      return __$$app$$__.app;
    }
    function getCurrentPage() {
      return __$$app$$__.current && __$$app$$__.current.module;
    }
    const __$$module$$__ = __$$app$$__.current;
    const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
    const { px } = __$$app$$__.__globals__;
    const logger = Logger.getLogger('watchface_SashaCX75');
    //end of ignored block

    //dynamic modify start


    let normal_background_bg_img = ''
    let normal_image_img = ''
    let normal_image_img_button = ''
    let normal_battery_current_text_font = ''




    let normal_timerTimeUpdate = undefined;
    let normal_system_disconnect_img = ''
    let normal_analog_clock_pro_hour_pointer_img = ''
    let normal_analog_clock_pro_minute_pointer_img = ''
    let normal_timerUpdateSec = undefined;
    let normal_analog_clock_time_pointer_smooth_second = ''

    let normal_time_hour_min_text_font, normal_step_current_text_font, normal_time_second_text_font, normal_time_down_second_text_font = ''
    let normal_distance_current_text_font_km, normal_distance_current_text_font_mil, normal_time_plus_text_font, normal_time_mines_text_font = ''
    let normal_image_img_heart, normal_calorie_target_text_font, normal_calorie_current_text_font, normal_heart_rate_text_font, normal_text_current_cal_1, normal_text_current_cal_2, normal_text_target_cal_1, normal_text_target_cal_2 = ''
    let normal_weather_name_text, normal_weather_image_progress_img_level, normal_temperature_high_text_font, normal_temperature_low_text_font, normal_temperature_high_text_text_font, normal_temperature_low_text_text_font, normal_temperature_current_text_font = ''
    let normal_dow_text_font, normal_month_name_font, normal_sun_high_text_font, normal_sun_high_text_text_font, normal_sun_low_text_font, normal_sun_low_text_text_font = ''




    let image_top_img = ''
    let Button_1 = ''
    let Button_Switch_BG = ''
    let start = 0;

    let ButtonIndex = 0;
    let ButtonList = ['clear.png', 'button_distance_1.png', 'button_heart_1.png', 'button_weather_1.png', 'button_date_1.png', 'button_distance_2.png', 'button_heart_2.png', 'button_weather_2.png', 'button_date_2.png'];
    let backgroundIndex = 0;
    let backgroundList = ['bg1.png', 'bg2.png', 'bg3.png', 'bg4.png'];
    let MaskIndex = 0;
    let MaskList = ['mask1.png', 'mask2.png'];
    let OffList = ['off_1.png', 'off_2.png'];
    let MinList = ['min_1.png', 'min_2.png'];
    let HourList = ['hour_1.png', 'hour_2.png'];
    let SecList = ['sec_1.png', 'sec_2.png'];
    let PointList = ['point_1.png', 'point_2.png'];
    let ModeList = ['mode_1.png', 'mode_2.png', 'mode_3.png', 'mode_4.png', 'mode_5.png'];


    let normal_DOW_Array = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday'];
    let normal_Month_Array = ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'];


    let shotWeaterhNames =
      ['Cloudy',
        'Showers',
        'Snow Showers',
        'Sunny',
        'Overcast',
        'Light Rain',
        'Light Snow',
        'Moderate Rain',
        ' Moderate Snow',
        'Heavy Snow',
        'Heavy Rain',
        'Sandstorm',
        'Rain and Snow',
        'Fog',
        'Hazy',
        'T-Storms',
        'Snowstorm',
        'Floating dust',
        'Very Heavy Rainstorm',
        'Rain and Hail',
        'T-Storms and Hail',
        'Heavy Rainstorm',
        'Dust',
        'Heavy sand storm',
        'Rainstorm',
        'Unknown',
        'Cloudy Nighttime',
        'Showers Nighttime',
        'Sunny Nighttime'];

    const watchfaceId = hmApp.packageInfo().watchfaceId;
    let timeSensor = '';


    let km_string, mil_string = '';
    const distance = hmSensor.createSensor(hmSensor.id.DISTANCE);


    //dynamic modify end

    __$$module$$__.module = DeviceRuntimeCore.WatchFace({
      init_view() {
        //dynamic modify start


        // FontName: ostrich_sans_sans_black.ttf; FontSize: 35
        hmUI.createWidget(hmUI.widget.TEXT, {
          x: 464,
          y: 464,
          w: 349,
          h: 34,
          text_size: 35,
          char_space: 0,
          line_space: 0,
          font: 'fonts/ostrich_sans_sans_black.ttf',
          color: 0xFF000000,
          align_h: hmUI.align.LEFT,
          align_v: hmUI.align.TOP,
          text_style: hmUI.text_style.ELLIPSIS,
          text: "0123456789 _-.,:;`'%°\\/",
          show_level: hmUI.show_level.ONLY_NORMAL,
        });

        // FontName: ostrich_sans_sans_rounded_medium.ttf; FontSize: 100
        hmUI.createWidget(hmUI.widget.TEXT, {
          x: 464,
          y: 464,
          w: 819,
          h: 86,
          text_size: 100,
          char_space: 0,
          line_space: 0,
          font: 'fonts/ostrich_sans_sans_rounded_medium.ttf',
          color: 0xFFE9E5D1,
          align_h: hmUI.align.CENTER_H,
          align_v: hmUI.align.TOP,
          text_style: hmUI.text_style.ELLIPSIS,
          text: "0123456789 _-.,:;`'%°\\/",
          show_level: hmUI.show_level.ONLY_NORMAL,
        });

        // FontName: ostrich_sans_sans_black.ttf; FontSize: 40
        hmUI.createWidget(hmUI.widget.TEXT, {
          x: 464,
          y: 464,
          w: 394,
          h: 40,
          text_size: 40,
          char_space: 0,
          line_space: 0,
          font: 'fonts/ostrich_sans_sans_black.ttf',
          color: 0xFFE9E5D1,
          align_h: hmUI.align.LEFT,
          align_v: hmUI.align.TOP,
          text_style: hmUI.text_style.ELLIPSIS,
          text: "0123456789 _-.,:;`'%°\\/",
          show_level: hmUI.show_level.ONLY_NORMAL,
        });


        function display_0() {
          normal_time_hour_min_text_font.setProperty(hmUI.prop.VISIBLE, true);
          normal_step_current_text_font.setProperty(hmUI.prop.VISIBLE, false);
          normal_time_second_text_font.setProperty(hmUI.prop.VISIBLE, true);
          normal_time_down_second_text_font.setProperty(hmUI.prop.VISIBLE, true);
          normal_distance_current_text_font_km.setProperty(hmUI.prop.VISIBLE, false);
          normal_distance_current_text_font_mil.setProperty(hmUI.prop.VISIBLE, false);
          normal_time_plus_text_font.setProperty(hmUI.prop.VISIBLE, true);
          normal_time_mines_text_font.setProperty(hmUI.prop.VISIBLE, true);
          normal_time_plus_text_font.setProperty(hmUI.prop.MORE, {
            text: "+",
          });
          normal_time_mines_text_font.setProperty(hmUI.prop.MORE, {
            text: "-",
          });

          normal_image_img_heart.setProperty(hmUI.prop.VISIBLE, false);
          normal_calorie_target_text_font.setProperty(hmUI.prop.VISIBLE, false);
          normal_calorie_current_text_font.setProperty(hmUI.prop.VISIBLE, false);
          normal_heart_rate_text_font.setProperty(hmUI.prop.VISIBLE, false);
          normal_text_current_cal_1.setProperty(hmUI.prop.VISIBLE, false);
          normal_text_current_cal_2.setProperty(hmUI.prop.VISIBLE, false);
          normal_text_target_cal_1.setProperty(hmUI.prop.VISIBLE, false);
          normal_text_target_cal_2.setProperty(hmUI.prop.VISIBLE, false);

          normal_weather_name_text.setProperty(hmUI.prop.VISIBLE, false);
          normal_weather_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, false);
          normal_temperature_high_text_font.setProperty(hmUI.prop.VISIBLE, false);
          normal_temperature_low_text_font.setProperty(hmUI.prop.VISIBLE, false);
          normal_temperature_high_text_text_font.setProperty(hmUI.prop.VISIBLE, false);
          normal_temperature_low_text_text_font.setProperty(hmUI.prop.VISIBLE, false);
          normal_temperature_current_text_font.setProperty(hmUI.prop.VISIBLE, false);

          normal_dow_text_font.setProperty(hmUI.prop.VISIBLE, false);
          normal_month_name_font.setProperty(hmUI.prop.VISIBLE, false);
          normal_sun_high_text_font.setProperty(hmUI.prop.VISIBLE, false);
          normal_sun_high_text_text_font.setProperty(hmUI.prop.VISIBLE, false);
          normal_sun_low_text_font.setProperty(hmUI.prop.VISIBLE, false);
          normal_sun_low_text_text_font.setProperty(hmUI.prop.VISIBLE, false);
        };

        function display_1() {
          normal_time_hour_min_text_font.setProperty(hmUI.prop.VISIBLE, false);
          normal_step_current_text_font.setProperty(hmUI.prop.VISIBLE, true);
          normal_time_second_text_font.setProperty(hmUI.prop.VISIBLE, false);
          normal_time_down_second_text_font.setProperty(hmUI.prop.VISIBLE, false);

          normal_distance_current_text_font_km.setProperty(hmUI.prop.VISIBLE, true);
          normal_distance_current_text_font_mil.setProperty(hmUI.prop.VISIBLE, true);
          normal_time_plus_text_font.setProperty(hmUI.prop.VISIBLE, true);
          normal_time_mines_text_font.setProperty(hmUI.prop.VISIBLE, true);
          normal_time_plus_text_font.setProperty(hmUI.prop.MORE, {
            text: "km",
          });
          normal_time_mines_text_font.setProperty(hmUI.prop.MORE, {
            text: "mil",
          });

          normal_image_img_heart.setProperty(hmUI.prop.VISIBLE, false);
          normal_calorie_target_text_font.setProperty(hmUI.prop.VISIBLE, false);
          normal_calorie_current_text_font.setProperty(hmUI.prop.VISIBLE, false);
          normal_heart_rate_text_font.setProperty(hmUI.prop.VISIBLE, false);
          normal_text_current_cal_1.setProperty(hmUI.prop.VISIBLE, false);
          normal_text_current_cal_2.setProperty(hmUI.prop.VISIBLE, false);
          normal_text_target_cal_1.setProperty(hmUI.prop.VISIBLE, false);
          normal_text_target_cal_2.setProperty(hmUI.prop.VISIBLE, false);

          normal_weather_name_text.setProperty(hmUI.prop.VISIBLE, false);
          normal_weather_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, false);
          normal_temperature_high_text_font.setProperty(hmUI.prop.VISIBLE, false);
          normal_temperature_low_text_font.setProperty(hmUI.prop.VISIBLE, false);
          normal_temperature_high_text_text_font.setProperty(hmUI.prop.VISIBLE, false);
          normal_temperature_low_text_text_font.setProperty(hmUI.prop.VISIBLE, false);
          normal_temperature_current_text_font.setProperty(hmUI.prop.VISIBLE, false);

          normal_dow_text_font.setProperty(hmUI.prop.VISIBLE, false);
          normal_month_name_font.setProperty(hmUI.prop.VISIBLE, false);
          normal_sun_high_text_font.setProperty(hmUI.prop.VISIBLE, false);
          normal_sun_high_text_text_font.setProperty(hmUI.prop.VISIBLE, false);
          normal_sun_low_text_font.setProperty(hmUI.prop.VISIBLE, false);
          normal_sun_low_text_text_font.setProperty(hmUI.prop.VISIBLE, false);
        };

        function display_2() {
          normal_time_hour_min_text_font.setProperty(hmUI.prop.VISIBLE, false);
          normal_step_current_text_font.setProperty(hmUI.prop.VISIBLE, false);
          normal_time_second_text_font.setProperty(hmUI.prop.VISIBLE, false);
          normal_time_down_second_text_font.setProperty(hmUI.prop.VISIBLE, false);
          normal_distance_current_text_font_km.setProperty(hmUI.prop.VISIBLE, false);
          normal_distance_current_text_font_mil.setProperty(hmUI.prop.VISIBLE, false);
          normal_time_plus_text_font.setProperty(hmUI.prop.VISIBLE, false);
          normal_time_mines_text_font.setProperty(hmUI.prop.VISIBLE, false);

          normal_image_img_heart.setProperty(hmUI.prop.VISIBLE, true);
          normal_calorie_target_text_font.setProperty(hmUI.prop.VISIBLE, true);
          normal_calorie_current_text_font.setProperty(hmUI.prop.VISIBLE, true);
          normal_heart_rate_text_font.setProperty(hmUI.prop.VISIBLE, true);
          normal_text_current_cal_1.setProperty(hmUI.prop.VISIBLE, true);
          normal_text_current_cal_2.setProperty(hmUI.prop.VISIBLE, true);
          normal_text_target_cal_1.setProperty(hmUI.prop.VISIBLE, true);
          normal_text_target_cal_2.setProperty(hmUI.prop.VISIBLE, true);

          normal_weather_name_text.setProperty(hmUI.prop.VISIBLE, false);
          normal_weather_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, false);
          normal_temperature_high_text_font.setProperty(hmUI.prop.VISIBLE, false);
          normal_temperature_low_text_font.setProperty(hmUI.prop.VISIBLE, false);
          normal_temperature_high_text_text_font.setProperty(hmUI.prop.VISIBLE, false);
          normal_temperature_low_text_text_font.setProperty(hmUI.prop.VISIBLE, false);
          normal_temperature_current_text_font.setProperty(hmUI.prop.VISIBLE, false);

          normal_dow_text_font.setProperty(hmUI.prop.VISIBLE, false);
          normal_month_name_font.setProperty(hmUI.prop.VISIBLE, false);
          normal_sun_high_text_font.setProperty(hmUI.prop.VISIBLE, false);
          normal_sun_high_text_text_font.setProperty(hmUI.prop.VISIBLE, false);
          normal_sun_low_text_font.setProperty(hmUI.prop.VISIBLE, false);
          normal_sun_low_text_text_font.setProperty(hmUI.prop.VISIBLE, false);
        };

        function display_3() {
          normal_weather_name_text.setProperty(hmUI.prop.VISIBLE, true);
          normal_weather_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, true);
          normal_temperature_high_text_font.setProperty(hmUI.prop.VISIBLE, true);
          normal_temperature_low_text_font.setProperty(hmUI.prop.VISIBLE, true);
          normal_temperature_high_text_text_font.setProperty(hmUI.prop.VISIBLE, true);
          normal_temperature_low_text_text_font.setProperty(hmUI.prop.VISIBLE, true);
          normal_temperature_current_text_font.setProperty(hmUI.prop.VISIBLE, true);

          normal_time_hour_min_text_font.setProperty(hmUI.prop.VISIBLE, false);
          normal_step_current_text_font.setProperty(hmUI.prop.VISIBLE, false);
          normal_time_second_text_font.setProperty(hmUI.prop.VISIBLE, false);
          normal_time_down_second_text_font.setProperty(hmUI.prop.VISIBLE, false);
          normal_distance_current_text_font_km.setProperty(hmUI.prop.VISIBLE, false);
          normal_distance_current_text_font_mil.setProperty(hmUI.prop.VISIBLE, false);
          normal_time_plus_text_font.setProperty(hmUI.prop.VISIBLE, false);
          normal_time_mines_text_font.setProperty(hmUI.prop.VISIBLE, false);

          normal_image_img_heart.setProperty(hmUI.prop.VISIBLE, false);
          normal_calorie_target_text_font.setProperty(hmUI.prop.VISIBLE, false);
          normal_calorie_current_text_font.setProperty(hmUI.prop.VISIBLE, false);
          normal_heart_rate_text_font.setProperty(hmUI.prop.VISIBLE, false);
          normal_text_current_cal_1.setProperty(hmUI.prop.VISIBLE, false);
          normal_text_current_cal_2.setProperty(hmUI.prop.VISIBLE, false);
          normal_text_target_cal_1.setProperty(hmUI.prop.VISIBLE, false);
          normal_text_target_cal_2.setProperty(hmUI.prop.VISIBLE, false);

          normal_dow_text_font.setProperty(hmUI.prop.VISIBLE, false);
          normal_month_name_font.setProperty(hmUI.prop.VISIBLE, false);
          normal_sun_high_text_font.setProperty(hmUI.prop.VISIBLE, false);
          normal_sun_high_text_text_font.setProperty(hmUI.prop.VISIBLE, false);
          normal_sun_low_text_font.setProperty(hmUI.prop.VISIBLE, false);
          normal_sun_low_text_text_font.setProperty(hmUI.prop.VISIBLE, false);
        };

        function display_4() {
          normal_dow_text_font.setProperty(hmUI.prop.VISIBLE, true);
          normal_month_name_font.setProperty(hmUI.prop.VISIBLE, true);
          normal_sun_high_text_font.setProperty(hmUI.prop.VISIBLE, true);
          normal_sun_high_text_text_font.setProperty(hmUI.prop.VISIBLE, true);
          normal_sun_low_text_font.setProperty(hmUI.prop.VISIBLE, true);
          normal_sun_low_text_text_font.setProperty(hmUI.prop.VISIBLE, true);

          normal_time_hour_min_text_font.setProperty(hmUI.prop.VISIBLE, false);
          normal_step_current_text_font.setProperty(hmUI.prop.VISIBLE, false);
          normal_time_second_text_font.setProperty(hmUI.prop.VISIBLE, false);
          normal_time_down_second_text_font.setProperty(hmUI.prop.VISIBLE, false);
          normal_distance_current_text_font_km.setProperty(hmUI.prop.VISIBLE, false);
          normal_distance_current_text_font_mil.setProperty(hmUI.prop.VISIBLE, false);
          normal_time_plus_text_font.setProperty(hmUI.prop.VISIBLE, false);
          normal_time_mines_text_font.setProperty(hmUI.prop.VISIBLE, false);

          normal_image_img_heart.setProperty(hmUI.prop.VISIBLE, false);
          normal_calorie_target_text_font.setProperty(hmUI.prop.VISIBLE, false);
          normal_calorie_current_text_font.setProperty(hmUI.prop.VISIBLE, false);
          normal_heart_rate_text_font.setProperty(hmUI.prop.VISIBLE, false);
          normal_text_current_cal_1.setProperty(hmUI.prop.VISIBLE, false);
          normal_text_current_cal_2.setProperty(hmUI.prop.VISIBLE, false);
          normal_text_target_cal_1.setProperty(hmUI.prop.VISIBLE, false);
          normal_text_target_cal_2.setProperty(hmUI.prop.VISIBLE, false);

          normal_weather_name_text.setProperty(hmUI.prop.VISIBLE, false);
          normal_weather_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, false);
          normal_temperature_high_text_font.setProperty(hmUI.prop.VISIBLE, false);
          normal_temperature_low_text_font.setProperty(hmUI.prop.VISIBLE, false);
          normal_temperature_high_text_text_font.setProperty(hmUI.prop.VISIBLE, false);
          normal_temperature_low_text_text_font.setProperty(hmUI.prop.VISIBLE, false);
          normal_temperature_current_text_font.setProperty(hmUI.prop.VISIBLE, false);
        };


        //функция смены фона 
        //console.log('SwitchBackground');
        function switchBackground() {
          backgroundIndex++;
          if (backgroundIndex >= backgroundList.length) backgroundIndex = 0;
          hmFS.SysProSetInt(`backgroundIndex_${watchfaceId}`, backgroundIndex);
          normal_background_bg_img.setProperty(hmUI.prop.SRC, backgroundList[backgroundIndex]);
          vibro(28);
        };

        //функция смены экрана
        //console.log('SwitchMask');
        function switchMask() {
          MaskIndex++;
          if (MaskIndex >= MaskList.length) MaskIndex = 0;
          normal_image_img.setProperty(hmUI.prop.SRC, MaskList[MaskIndex]);
          normal_system_disconnect_img.setProperty(hmUI.prop.SRC, OffList[MaskIndex]);
          normal_analog_clock_time_pointer_smooth_second.setProperty(hmUI.prop.MORE, {
            second_path: SecList[MaskIndex],
            second_centerX: 233,
            second_centerY: 233,
            second_posX: 16,
            second_posY: 216,
            fresh_frequency: 20,
            second_cover_path: PointList[MaskIndex],
            second_cover_x: 201,
            second_cover_y: 201,
            show_level: hmUI.show_level.ONLY_NORMAL,
          });
          normal_analog_clock_pro_minute_pointer_img.setProperty(hmUI.prop.SRC, MinList[MaskIndex]);
          normal_analog_clock_pro_hour_pointer_img.setProperty(hmUI.prop.SRC, HourList[MaskIndex]);
          if (ButtonIndex > 0) {
            normal_image_img_button.setProperty(hmUI.prop.MORE, {
              src: ButtonList[ButtonIndex + (4 * MaskIndex)],
            });
          }
          vibro(28);
        };

        function switchApp() {
          switch (ButtonIndex) {
            case 0:
              hmApp.startApp({ url: "StopWatchScreen", native: true });
              break;
            case 1:
              hmApp.startApp({ url: "activityAppScreen", native: true });
              break;
            case 2:
              hmApp.startApp({ url: "heart_app_Screen", native: true });
              break;
            case 3:
              hmApp.startApp({ url: "WeatherScreen", native: true });
              break;
            case 4:
              hmApp.startApp({ url: "ScheduleCalScreen", native: true });
              break;
          }
          vibro(28);
        };


        //функция обработки нажатия кнопок 
        //console.log('SwitchButton');
        function switch_button(count) {
          if (ButtonIndex == count) {
            normal_image_img_button.setProperty(hmUI.prop.VISIBLE, false);
            ButtonIndex = 0;
          } else {
            ButtonIndex = count;
            normal_image_img_button.setProperty(hmUI.prop.MORE, {
              src: ButtonList[ButtonIndex + (4 * MaskIndex)],
            });
            normal_image_img_button.setProperty(hmUI.prop.VISIBLE, true);
          }
          normal_image_img_mode.setProperty(hmUI.prop.SRC, ModeList[ButtonIndex]);
          switch (ButtonIndex) {
            case 0:
              display_0();
              break;
            case 1:
              display_1();
              break;
            case 2:
              display_2();
              break;
            case 3:
              display_3();
              break;
            case 4:
              display_4();
              break;
          }

          vibro(28);
        };



        normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
          x: 33,
          y: 33,
          w: 400,
          h: 400,
          src: 'bg1.png',
          show_level: hmUI.show_level.ONLY_NORMAL,
        });

        normal_image_img_mode = hmUI.createWidget(hmUI.widget.IMG, {
          x: 100,
          y: 0,
          src: 'mode_1.png',
          show_level: hmUI.show_level.ONLY_NORMAL,
        });

        normal_image_img = hmUI.createWidget(hmUI.widget.IMG, {
          x: 0,
          y: 0,
          src: 'mask1.png',
          show_level: hmUI.show_level.ONLY_NORMAL,
        });

        normal_image_img_button = hmUI.createWidget(hmUI.widget.IMG, {
          x: 0,
          y: 0,
          src: 'button_clear.png',
          show_level: hmUI.show_level.ONLY_NORMAL,
        });

        normal_battery_current_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
          x: 166,
          y: 320,
          w: 70,
          h: 36,
          text_size: 35,
          char_space: 0,
          line_space: 0,
          font: 'fonts/ostrich_sans_sans_black.ttf',
          color: 0xFF000000,
          align_h: hmUI.align.LEFT,
          align_v: hmUI.align.TOP,
          unit_type: 1,
          text_style: hmUI.text_style.ELLIPSIS,
          type: hmUI.data_type.BATTERY,
          show_level: hmUI.show_level.ONLY_NORMAL,
        });

        if (!timeSensor) timeSensor = hmSensor.createSensor(hmSensor.id.TIME);
        let screenType = hmSetting.getScreenType();

        //--------------------------------------------------- цифровое время ---------------------------------------------------
        normal_time_hour_min_text_font = hmUI.createWidget(hmUI.widget.TEXT, {
          x: 153,
          y: 75,
          w: 160,
          h: 106,
          text_size: 100,
          char_space: 0,
          line_space: 0,
          font: 'fonts/ostrich_sans_sans_rounded_medium.ttf',
          color: 0xFFE9E5D1,
          align_h: hmUI.align.CENTER_H,
          align_v: hmUI.align.TOP,
          text_style: hmUI.text_style.ELLIPSIS,
          // padding: true,
          // unit_end: true,
          show_level: hmUI.show_level.ONLY_NORMAL,
        });

        normal_time_second_text_font = hmUI.createWidget(hmUI.widget.TEXT, {
          x: 340,
          y: 173,
          w: 40,
          h: 32,
          text_size: 40,
          char_space: 0,
          line_space: 0,
          font: 'fonts/ostrich_sans_sans_black.ttf',
          color: 0xFFE9E5D1,
          align_h: hmUI.align.LEFT,
          align_v: hmUI.align.TOP,
          text_style: hmUI.text_style.ELLIPSIS,
          // padding: true,
          show_level: hmUI.show_level.ONLY_NORMAL,
        });

        normal_time_down_second_text_font = hmUI.createWidget(hmUI.widget.TEXT, {
          x: 98,
          y: 173,
          w: 150,
          h: 40,
          text_size: 40,
          char_space: 0,
          line_space: 0,
          font: 'fonts/ostrich_sans_sans_black.ttf',
          color: 0xFFE9E5D1,
          align_h: hmUI.align.LEFT,
          align_v: hmUI.align.TOP,
          text_style: hmUI.text_style.ELLIPSIS,
          // padding: true,
          show_level: hmUI.show_level.ONLY_NORMAL,
        });

        normal_time_mines_text_font = hmUI.createWidget(hmUI.widget.TEXT, {
          x: 73,
          y: 128,
          w: 80,
          h: 40,
          text_size: 40,
          char_space: 0,
          line_space: 0,
          text: "-",
          font: 'fonts/ostrich_sans_sans_black.ttf',
          color: 0xFFB1AD9E,
          align_h: hmUI.align.CENTER_H,
          align_v: hmUI.align.TOP,
          text_style: hmUI.text_style.ELLIPSIS,
          // padding: true,
          show_level: hmUI.show_level.ONLY_NORMAL,
        });

        normal_time_plus_text_font = hmUI.createWidget(hmUI.widget.TEXT, {
          x: 316,
          y: 128,
          w: 80,
          h: 40,
          text_size: 40,
          char_space: 0,
          line_space: 0,
          text: "+",
          font: 'fonts/ostrich_sans_sans_black.ttf',
          color: 0xFFB1AD9E,
          align_h: hmUI.align.CENTER_H,
          align_v: hmUI.align.TOP,
          text_style: hmUI.text_style.ELLIPSIS,
          // padding: true,
          show_level: hmUI.show_level.ONLY_NORMAL,
        });
        //--------------------------------------------------- конец * цифровое время ---------------------------------------------------

        //--------------------------------------------------- дистанция ---------------------------------------------------

        normal_distance_current_text_font_km = hmUI.createWidget(hmUI.widget.TEXT, {
          x: 316,
          y: 173,
          w: 80,
          h: 30,
          text_size: 40,
          font: 'fonts/ostrich_sans_sans_black.ttf',
          color: 0xFFE9E5D1,
          align_h: hmUI.align.CENTER_H,
          align_v: hmUI.align.TOP,
          text_style: hmUI.text_style.ELLIPSIS,
          show_level: hmUI.show_level.ONLY_NORMAL,
        });

        normal_distance_current_text_font_mil = hmUI.createWidget(hmUI.widget.TEXT, {
          x: 70,
          y: 173,
          w: 80,
          h: 30,
          text_size: 40,
          font: 'fonts/ostrich_sans_sans_black.ttf',
          color: 0xFFE9E5D1,
          align_h: hmUI.align.CENTER_H,
          align_v: hmUI.align.TOP,
          //text_style: hmUI.text_style.ELLIPSIS,
          show_level: hmUI.show_level.ONLY_NORMAL,
        });

        normal_step_current_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
          x: 133,
          y: 75,
          w: 200,
          h: 106,
          text_size: 100,
          char_space: 0,
          line_space: 0,
          font: 'fonts/ostrich_sans_sans_rounded_medium.ttf',
          color: 0xFFE9E5D1,
          align_h: hmUI.align.CENTER_H,
          align_v: hmUI.align.TOP,
          text_style: hmUI.text_style.ELLIPSIS,
          type: hmUI.data_type.STEP,
          show_level: hmUI.show_level.ONLY_NORMAL,
        });

        //--------------------------------------------------- конец * дистанция ---------------------------------------------------

        //--------------------------------------------------- heart ---------------------------------------------------

        normal_image_img_heart = hmUI.createWidget(hmUI.widget.IMG, {
          x: 210,
          y: 60,
          src: 'heart.png',
          show_level: hmUI.show_level.ONLY_NORMAL,
        });

        normal_calorie_target_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
          x: 68,
          y: 176,
          w: 90,
          h: 36,
          text_size: 36,
          char_space: 0,
          line_space: 0,
          font: 'fonts/ostrich_sans_sans_black.ttf',
          color: 0xFFE9E5D1,
          align_h: hmUI.align.CENTER_H,
          align_v: hmUI.align.TOP,
          text_style: hmUI.text_style.ELLIPSIS,
          type: hmUI.data_type.CAL_TARGET,
          show_level: hmUI.show_level.ONLY_NORMAL,
        });

        normal_calorie_current_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
          x: 309,
          y: 176,
          w: 90,
          h: 36,
          text_size: 36,
          char_space: 0,
          line_space: 0,
          font: 'fonts/ostrich_sans_sans_black.ttf',
          color: 0xFFE9E5D1,
          align_h: hmUI.align.CENTER_H,
          align_v: hmUI.align.TOP,
          text_style: hmUI.text_style.ELLIPSIS,
          type: hmUI.data_type.CAL,
          show_level: hmUI.show_level.ONLY_NORMAL,
        });

        normal_heart_rate_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
          x: 173,
          y: 122,
          w: 120,
          h: 40,
          text_size: 40,
          char_space: 0,
          line_space: 0,
          font: 'fonts/ostrich_sans_sans_black.ttf',
          color: 0xFFE9E5D1,
          align_h: hmUI.align.CENTER_H,
          align_v: hmUI.align.TOP,
          //unit_type: 1,
          text_style: hmUI.text_style.ELLIPSIS,
          type: hmUI.data_type.HEART,
          show_level: hmUI.show_level.ONLY_NORMAL,
        });

        normal_text_current_cal_1 = hmUI.createWidget(hmUI.widget.TEXT, {
          x: 312,
          y: 127,
          w: 80,
          h: 20,
          text_size: 20,
          font: 'fonts/ostrich_sans_sans_black.ttf',
          color: 0xFFB1AD9E,
          text: 'current',
          align_h: hmUI.align.CENTER_H,
          align_v: hmUI.align.TOP,
          show_level: hmUI.show_level.ONLY_NORMAL,
        });

        normal_text_current_cal_2 = hmUI.createWidget(hmUI.widget.TEXT, {
          x: 312,
          y: 150,
          w: 80,
          h: 20,
          text_size: 20,
          font: 'fonts/ostrich_sans_sans_black.ttf',
          color: 0xFFB1AD9E,
          text: 'calories',
          align_h: hmUI.align.CENTER_H,
          align_v: hmUI.align.TOP,
          text_style: hmUI.text_style.ELLIPSIS,
          show_level: hmUI.show_level.ONLY_NORMAL,
        });

        normal_text_target_cal_1 = hmUI.createWidget(hmUI.widget.TEXT, {
          x: 75,
          y: 127,
          w: 80,
          h: 20,
          text_size: 20,
          font: 'fonts/ostrich_sans_sans_black.ttf',
          color: 0xFFB1AD9E,
          text: 'target',
          align_h: hmUI.align.CENTER_H,
          align_v: hmUI.align.TOP,
          text_style: hmUI.text_style.ELLIPSIS,
          show_level: hmUI.show_level.ONLY_NORMAL,
        });

        normal_text_target_cal_2 = hmUI.createWidget(hmUI.widget.TEXT, {
          x: 75,
          y: 150,
          w: 80,
          h: 20,
          text_size: 20,
          font: 'fonts/ostrich_sans_sans_black.ttf',
          color: 0xFFB1AD9E,
          text: 'calories',
          align_h: hmUI.align.CENTER_H,
          align_v: hmUI.align.TOP,
          text_style: hmUI.text_style.ELLIPSIS,
          show_level: hmUI.show_level.ONLY_NORMAL,
        });

        //--------------------------------------------------- end of heart ---------------------------------------------------

        //--------------------------------------------------- weather ---------------------------------------------------
        normal_weather_name_text = hmUI.createWidget(hmUI.widget.TEXT, {
          x: 133,
          y: 130,
          w: 200,
          h: 24,
          text_size: 24,
          char_space: 0,
          line_space: 0,
          font: 'fonts/ostrich_sans_sans_black.ttf',
          color: 0xFFE9E5D1,
          align_h: hmUI.align.CENTER_H,
          align_v: hmUI.align.TOP,
          text_style: hmUI.text_style.ELLIPSIS,
          show_level: hmUI.show_level.ONLY_NORMAL,
        });

        normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
          x: 182,
          y: 68,
          image_array: ["we1.png", "we10.png", "we11.png", "we12.png", "we13.png", "we14.png", "we15.png", "we15n.png", "we16.png", "we17.png", "we18.png", "we19.png", "we1n.png", "we2.png", "we20.png", "we21.png", "we22.png", "we23.png", "we24.png", "we25.png", "we26.png", "we2n.png", "we3.png", "we3n.png", "we4.png", "we4n.png", "we5.png", "we6.png", "we7.png"],
          image_length: 29,
          type: hmUI.data_type.WEATHER_CURRENT,
          show_level: hmUI.show_level.ONLY_NORMAL,
        });

        normal_temperature_high_text_font = hmUI.createWidget(hmUI.widget.TEXT, {
          x: 75,
          y: 176,
          w: 80,
          h: 36,
          text_size: 36,
          char_space: 0,
          line_space: 0,
          font: 'fonts/ostrich_sans_sans_black.ttf',
          color: 0xFFE9E5D1,
          align_h: hmUI.align.CENTER_H,
          align_v: hmUI.align.TOP,
          text_style: hmUI.text_style.ELLIPSIS,
          show_level: hmUI.show_level.ONLY_NORMAL,
        });

        normal_temperature_high_text_text_font = hmUI.createWidget(hmUI.widget.TEXT, {
          x: 75,
          y: 150,
          w: 80,
          h: 20,
          text_size: 20,
          font: 'fonts/ostrich_sans_sans_black.ttf',
          color: 0xFFB1AD9E,
          text: 'high',
          align_h: hmUI.align.CENTER_H,
          align_v: hmUI.align.TOP,
          text_style: hmUI.text_style.ELLIPSIS,
          show_level: hmUI.show_level.ONLY_NORMAL,
        });

        normal_temperature_low_text_font = hmUI.createWidget(hmUI.widget.TEXT, {
          x: 312,
          y: 176,
          w: 80,
          h: 36,
          text_size: 36,
          char_space: 0,
          line_space: 0,
          font: 'fonts/ostrich_sans_sans_black.ttf',
          color: 0xFFE9E5D1,
          align_h: hmUI.align.CENTER_H,
          align_v: hmUI.align.TOP,
          text_style: hmUI.text_style.ELLIPSIS,
          show_level: hmUI.show_level.ONLY_NORMAL,
        });

        normal_temperature_low_text_text_font = hmUI.createWidget(hmUI.widget.TEXT, {
          x: 312,
          y: 150,
          w: 80,
          h: 20,
          text_size: 20,
          font: 'fonts/ostrich_sans_sans_black.ttf',
          color: 0xFFB1AD9E,
          text: 'low',
          align_h: hmUI.align.CENTER_H,
          align_v: hmUI.align.TOP,
          text_style: hmUI.text_style.ELLIPSIS,
          show_level: hmUI.show_level.ONLY_NORMAL,
        });

        normal_temperature_current_text_font = hmUI.createWidget(hmUI.widget.TEXT, {
          x: 238,
          y: 73,
          w: 82,
          h: 60,
          text_size: 60,
          char_space: 0,
          line_space: 0,
          font: 'fonts/ostrich_sans_sans_rounded_medium.ttf',
          color: 0xFFE9E5D1,
          align_h: hmUI.align.LEFT,
          align_v: hmUI.align.TOP,
          text_style: hmUI.text_style.ELLIPSIS,
          show_level: hmUI.show_level.ONLY_NORMAL,
        });
        //--------------------------------------------------- end of weather ---------------------------------------------------

        //--------------------------------------------------- date ---------------------------------------------------

        normal_dow_text_font = hmUI.createWidget(hmUI.widget.TEXT, {
          x: 153,
          y: 70,
          w: 160,
          h: 36,
          text_size: 36,
          char_space: 0,
          line_space: 0,
          font: 'fonts/ostrich_sans_sans_black.ttf',
          color: 0xFFB1AD9E,
          align_h: hmUI.align.CENTER_H,
          align_v: hmUI.align.TOP,
          text_style: hmUI.text_style.ELLIPSIS,
          // unit_string: Monday, Tuesday, Wednesday, Thursday, Friday, Saturday, Sunday,
          show_level: hmUI.show_level.ONLY_NORMAL,
        });

        normal_month_name_font = hmUI.createWidget(hmUI.widget.TEXT, {
          x: 133,
          y: 107,
          w: 200,
          h: 60,
          text_size: 60,
          char_space: 0,
          line_space: 0,
          font: 'fonts/ostrich_sans_sans_rounded_medium.ttf',
          color: 0xFFE9E5D1,
          align_h: hmUI.align.CENTER_H,
          align_v: hmUI.align.TOP,
          text_style: hmUI.text_style.ELLIPSIS,
          // unit_string: January, February, March, April, May, June, July, August, September, October, November, December,
          show_level: hmUI.show_level.ONLY_NORMAL,
        });

        normal_sun_high_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
          x: 68,
          y: 176,
          w: 90,
          h: 36,
          text_size: 36,
          char_space: 0,
          line_space: 0,
          font: 'fonts/ostrich_sans_sans_black.ttf',
          color: 0xFFE9E5D1,
          align_h: hmUI.align.CENTER_H,
          align_v: hmUI.align.TOP,
          text_style: hmUI.text_style.ELLIPSIS,
          type: hmUI.data_type.SUN_RISE,
          show_level: hmUI.show_level.ONLY_NORMAL,
        });

        normal_sun_high_text_text_font = hmUI.createWidget(hmUI.widget.TEXT, {
          x: 72,
          y: 150,
          w: 80,
          h: 20,
          text_size: 20,
          font: 'fonts/ostrich_sans_sans_black.ttf',
          color: 0xFFB1AD9E,
          text: 'sunrise',
          align_h: hmUI.align.CENTER_H,
          align_v: hmUI.align.TOP,
          text_style: hmUI.text_style.ELLIPSIS,
          show_level: hmUI.show_level.ONLY_NORMAL,
        });

        normal_sun_low_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
          x: 309,
          y: 176,
          w: 90,
          h: 36,
          text_size: 36,
          char_space: 0,
          line_space: 0,
          font: 'fonts/ostrich_sans_sans_black.ttf',
          color: 0xFFE9E5D1,
          align_h: hmUI.align.CENTER_H,
          align_v: hmUI.align.TOP,
          text_style: hmUI.text_style.ELLIPSIS,
          type: hmUI.data_type.SUN_SET,
          show_level: hmUI.show_level.ONLY_NORMAL,
        });

        normal_sun_low_text_text_font = hmUI.createWidget(hmUI.widget.TEXT, {
          x: 312,
          y: 150,
          w: 80,
          h: 20,
          text_size: 20,
          font: 'fonts/ostrich_sans_sans_black.ttf',
          color: 0xFFB1AD9E,
          text: 'sunset',
          align_h: hmUI.align.CENTER_H,
          align_v: hmUI.align.TOP,
          text_style: hmUI.text_style.ELLIPSIS,
          show_level: hmUI.show_level.ONLY_NORMAL,
        });
        //---------------------------------------------------end of date---------------------------------------------------------

        normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
          x: 242,
          y: 314,
          src: 'off_1.png',
          type: hmUI.system_status.DISCONNECT,
          show_level: hmUI.show_level.ONLY_NORMAL,
        });

        const deviceInfo = hmSetting.getDeviceInfo();
        timeSensor.addEventListener(timeSensor.event.MINUTEEND, function () {
          let updateHour = timeSensor.minute == 0;

          time_update(updateHour, true);
        });

        // тени стрелок
        normal_analog_clock_pro_hour_pointer_img_sh = hmUI.createWidget(hmUI.widget.IMG, {
          x: 3,
          y: 3,
          w: deviceInfo.width,
          h: deviceInfo.height,
          pos_x: 233 - 19,
          pos_y: 233 - 146,
          center_x: 233,
          center_y: 233,
          src: 'hour_sh.png',
          angle: 0,
          show_level: hmUI.show_level.ONLY_NORMAL,
        });

        normal_analog_clock_pro_minute_pointer_img_sh = hmUI.createWidget(hmUI.widget.IMG, {
          x: 5,
          y: 5,
          w: deviceInfo.width,
          h: deviceInfo.height,
          pos_x: 233 - 16,
          pos_y: 233 - 200,
          center_x: 233,
          center_y: 233,
          src: 'min_sh.png',
          angle: 0,
          show_level: hmUI.show_level.ONLY_NORMAL,
        });

        normal_analog_clock_time_pointer_smooth_second_sh = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
          second_path: 'sec_sh.png',
          second_centerX: 238,
          second_centerY: 238,
          second_posX: 16,
          second_posY: 216,
          fresh_frequency: 25,
          second_cover_x: 201,
          second_cover_y: 201,
          show_level: hmUI.show_level.ONLY_NORMAL,
        });

        // аналоговые стрелки
        normal_analog_clock_pro_hour_pointer_img = hmUI.createWidget(hmUI.widget.IMG, {
          x: 0,
          y: 0,
          w: deviceInfo.width,
          h: deviceInfo.height,
          pos_x: 233 - 19,
          pos_y: 233 - 146,
          center_x: 233,
          center_y: 233,
          src: 'hour_1.png',
          angle: 0,
          show_level: hmUI.show_level.ONLY_NORMAL,
        });

        normal_analog_clock_pro_minute_pointer_img = hmUI.createWidget(hmUI.widget.IMG, {
          x: 0,
          y: 0,
          w: deviceInfo.width,
          h: deviceInfo.height,
          pos_x: 233 - 16,
          pos_y: 233 - 200,
          center_x: 233,
          center_y: 233,
          src: 'min_1.png',
          angle: 0,
          show_level: hmUI.show_level.ONLY_NORMAL,
        });

        normal_analog_clock_time_pointer_smooth_second = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
          second_path: 'sec_1.png',
          second_centerX: 233,
          second_centerY: 233,
          second_posX: 16,
          second_posY: 216,
          fresh_frequency: 25,
          second_cover_path: 'point_1.png',
          second_cover_x: 201,
          second_cover_y: 201,
          show_level: hmUI.show_level.ONLY_NORMAL,
        });

        image_top_img = hmUI.createWidget(hmUI.widget.IMG, {
          x: 201,
          y: 201,
          src: 'point_top.png',
          show_level: hmUI.show_level.ONLY_NORMAL,
        });

        //----------------------------------------------------------AOD---------------------------------------------------------------------------------

        idle_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
          x: 0,
          y: 0,
          w: 466,
          h: 466,
          src: 'bg_aod.png',
          show_level: hmUI.show_level.ONLY_AOD,
        });

        idle_analog_clock_time_pointer_hour = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
          hour_path: 'hour_2.png',
          hour_centerX: 233,
          hour_centerY: 233,
          hour_posX: 19,
          hour_posY: 146,
          hour_cover_path: 'point_2.png',
          hour_cover_x: 201,
          hour_cover_y: 201,
          show_level: hmUI.show_level.ONLY_AOD,
        });

        idle_analog_clock_time_pointer_minute = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
          minute_path: 'min_2.png',
          minute_centerX: 233,
          minute_centerY: 233,
          minute_posX: 16,
          minute_posY: 200,
          minute_cover_path: 'point_top_2.png',
          minute_cover_x: 201,
          minute_cover_y: 201,
          show_level: hmUI.show_level.ONLY_AOD,
        });

        //----------------------------------------------------------end AOD---------------------------------------------------------------------------------

        Button_Switch_BG = hmUI.createWidget(hmUI.widget.BUTTON, {
          x: 183,
          y: 183,
          w: 100,
          h: 100,
          text: '',
          color: 0xFFFF8C00,
          text_size: 25,
          press_src: 'clear.png',
          normal_src: 'clear.png',
          click_func: (button_widget) => {
            switchBackground();
          }, // end func
          show_level: hmUI.show_level.ONLY_NORMAL,
        }); // end button

        Button_Mask = hmUI.createWidget(hmUI.widget.BUTTON, {
          x: 183,
          y: 0,
          w: 100,
          h: 60,
          text: '',
          color: 0xFFFF8C00,
          text_size: 25,
          press_src: 'clear.png',
          normal_src: 'clear.png',
          click_func: (button_widget) => {
            switchMask();
          }, // end func
          show_level: hmUI.show_level.ONLY_NORMAL,
        }); // end button

        Button_App = hmUI.createWidget(hmUI.widget.BUTTON, {
          x: 183,
          y: 74,
          w: 100,
          h: 100,
          text: '',
          color: 0xFFFF8C00,
          text_size: 25,
          press_src: 'clear.png',
          normal_src: 'clear.png',
          click_func: (button_widget) => {
            switchApp();
          }, // end func
          show_level: hmUI.show_level.ONLY_NORMAL,
        }); // end button


        Button_Distance = hmUI.createWidget(hmUI.widget.BUTTON, {
          x: 24,
          y: 242,
          w: 100,
          h: 100,
          text: '',
          color: 0xFFFF8C00,
          text_size: 25,
          press_src: 'clear.png',
          normal_src: 'clear.png',
          click_func: (button_widget) => {
            switch_button(1);
          },
          show_level: hmUI.show_level.ONLY_NORMAL,
        }); // end button

        Button_Heart = hmUI.createWidget(hmUI.widget.BUTTON, {
          x: 120,
          y: 345,
          w: 100,
          h: 100,
          text: '',
          color: 0xFFFF8C00,
          text_size: 25,
          press_src: 'clear.png',
          normal_src: 'clear.png',
          click_func: (button_widget) => {
            switch_button(2);
          },
          show_level: hmUI.show_level.ONLY_NORMAL,
        }); // end button

        Button_Weather = hmUI.createWidget(hmUI.widget.BUTTON, {
          x: 246,
          y: 345,
          w: 100,
          h: 100,
          text: '',
          color: 0xFFFF8C00,
          text_size: 25,
          press_src: 'clear.png',
          normal_src: 'clear.png',
          click_func: (button_widget) => {
            switch_button(3);
          },
          show_level: hmUI.show_level.ONLY_NORMAL,
        }); // end button

        Button_Date = hmUI.createWidget(hmUI.widget.BUTTON, {
          x: 344,
          y: 242,
          w: 100,
          h: 100,
          text: '',
          color: 0xFFFF8C00,
          text_size: 25,
          press_src: 'clear.png',
          normal_src: 'clear.png',
          click_func: (button_widget) => {
            switch_button(4);
          },
          show_level: hmUI.show_level.ONLY_NORMAL,
        }); // end button

        // vibrate function
        const vibrate = hmSensor.createSensor(hmSensor.id.VIBRATE);
        let timer_StopVibrate = null;

        function vibro(scene = 25) {
          let stopDelay = 50;
          stopVibro();
          vibrate.stop();
          vibrate.scene = scene;
          if (scene < 23 || scene > 25) stopDelay = 1300;
          vibrate.start();
          timer_StopVibrate = timer.createTimer(stopDelay, 3000, stopVibro, {});
        }

        function stopVibro() {
          vibrate.stop();
          if (timer_StopVibrate) timer.stopTimer(timer_StopVibrate);
        }

        // end vibrate function

        //start of ignored block
        function time_update(updateHour = false, updateMinute = false) {
          //console.log('time_update()');
          let hour = timeSensor.hour;
          let minute = timeSensor.minute;
          let second = timeSensor.second;
          let format_hour = timeSensor.format_hour;

          //console.log('hour:min font');
          if (updateMinute) {
            let normal_HourMinStr = format_hour.toString();
            normal_HourMinStr = normal_HourMinStr.padStart(2, '0');
            normal_HourMinStr = normal_HourMinStr + ':' + minute.toString().padStart(2, '0')
            normal_time_hour_min_text_font.setProperty(hmUI.prop.TEXT, normal_HourMinStr);
          };

          //console.log('second font');
          let down_secondStr = String(60 - second);
          let normal_secondStr = second.toString();
          normal_secondStr = normal_secondStr.padStart(2, '0');
          down_secondStr = down_secondStr.padStart(2, '0')
          normal_time_second_text_font.setProperty(hmUI.prop.TEXT, normal_secondStr);
          normal_time_down_second_text_font.setProperty(hmUI.prop.TEXT, down_secondStr);
          if (updateMinute) {
            let normal_hour = hour;
            let normal_fullAngle_hour = 360;
            if (normal_hour > 11) normal_hour -= 12;
            let normal_angle_hour = 0 + normal_fullAngle_hour * normal_hour / 12 + (normal_fullAngle_hour / 12) * minute / 60;
            if (normal_analog_clock_pro_hour_pointer_img_sh) normal_analog_clock_pro_hour_pointer_img_sh.setProperty(hmUI.prop.ANGLE, normal_angle_hour);
            if (normal_analog_clock_pro_hour_pointer_img) normal_analog_clock_pro_hour_pointer_img.setProperty(hmUI.prop.ANGLE, normal_angle_hour);
          };



          let normal_fullAngle_minute = 360;
          let normal_angle_minute = 0 + normal_fullAngle_minute * (minute + second / 60) / 60;
          if (normal_analog_clock_pro_minute_pointer_img_sh) normal_analog_clock_pro_minute_pointer_img_sh.setProperty(hmUI.prop.ANGLE, normal_angle_minute);
          if (normal_analog_clock_pro_minute_pointer_img) normal_analog_clock_pro_minute_pointer_img.setProperty(hmUI.prop.ANGLE, normal_angle_minute);


          if (updateHour) {
            let normal_DOW_Str = normal_DOW_Array[timeSensor.week - 1];
            normal_dow_text_font.setProperty(hmUI.prop.TEXT, normal_DOW_Str);
            let normal_dayStr = timeSensor.day.toString();
            normal_dayStr = normal_dayStr.padStart(2, '0');
            let normal_Month_Str = normal_Month_Array[timeSensor.month - 1] + " " + normal_dayStr;
            normal_month_name_font.setProperty(hmUI.prop.TEXT, normal_Month_Str);
          };


          if (ButtonIndex == 1) {
            km_string = String((distance.current / 1000).toFixed(1));
            mil_string = String((distance.current / 1000 / 1.609).toFixed(1));
            normal_distance_current_text_font_km.setProperty(hmUI.prop.MORE, {
              text: km_string,
            });
            normal_distance_current_text_font_mil.setProperty(hmUI.prop.MORE, {
              text: mil_string,
            });
          }
        };

        function updateTemperature() {
          const weatherSensor = hmSensor.createSensor(hmSensor.id.WEATHER);
          let current = String(weatherSensor.current) + ' C';
          normal_temperature_current_text_font.setProperty(hmUI.prop.TEXT, current);
          let curAirIconIndex = weatherSensor.curAirIconIndex;
          normal_weather_name_text.setProperty(hmUI.prop.TEXT, shotWeaterhNames[curAirIconIndex]);
          let h_text = String(weatherSensor.high) + " C";
          let l_text = String(weatherSensor.low) + " C";
          normal_temperature_high_text_font.setProperty(hmUI.prop.TEXT, h_text);
          normal_temperature_low_text_font.setProperty(hmUI.prop.TEXT, l_text);
        };

        //end of ignored block
        const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
          resume_call: (function () {
            console.log('resume_call()');
            time_update(true, true);
            if (start == 0) {
              display_0();
              start = 1;
            };
            if (screenType == hmSetting.screen_type.WATCHFACE) {
              if (!normal_timerTimeUpdate) {
                normal_timerTimeUpdate = timer.createTimer(0, 1000, (function (option) {
                  let updateHour = timeSensor.minute == 0 && timeSensor.second < 2;
                  let updateMinute = timeSensor.second < 2;
                  time_update(updateHour, updateMinute);
                }));  // end timer 
              };  // end timer check
            };  // end screenType

            if (screenType == hmSetting.screen_type.WATCHFACE) {
              if (!normal_timerUpdateSec) {
                let animDelay = timeSensor.utc % 1000;
                let animRepeat = 1000;
                normal_timerUpdateSec = timer.createTimer(animDelay, animRepeat, (function (option) {
                  time_update(false, true);
                }));  // end timer 
              };  // end timer check
            };  // end screenType


            //SwitchBackground
            if (hmFS.SysProGetInt(`backgroundIndex_${watchfaceId}`) === undefined) {
              backgroundIndex = 0;
              hmFS.SysProSetInt(`backgroundIndex_${watchfaceId}`, backgroundIndex);
            } else {
              backgroundIndex = hmFS.SysProGetInt(`backgroundIndex_${watchfaceId}`);
            };
            if (screenType == hmSetting.screen_type.WATCHFACE && normal_background_bg_img) normal_background_bg_img.setProperty(hmUI.prop.SRC, backgroundList[backgroundIndex]);

            updateTemperature();
          }),
          pause_call: (function () {
            console.log('pause_call()');
            if (normal_timerTimeUpdate) {
              timer.stopTimer(normal_timerTimeUpdate);
              normal_timerTimeUpdate = undefined;
            }
            if (normal_timerUpdateSec) {
              timer.stopTimer(normal_timerUpdateSec);
              normal_timerUpdateSec = undefined;
            }

          }),
        });

        //dynamic modify end
      },
      onInit() {
        logger.log('index page.js on init invoke');
      },
      build() {
        this.init_view();
        logger.log('index page.js on ready invoke');
      },
      onDestroy() {
        logger.log('index page.js on destroy invoke');
      }
    });
    ;
  })();
} catch (e) {
  console.log('Mini Program Error', e);
  e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
  ;
}