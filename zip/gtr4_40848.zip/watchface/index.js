﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        const logger = Logger.getLogger('watchface_SashaCX75');
        //end of ignored block

        //dynamic modify start

        
        let normal_background_bg = ''
        let normal_frame_animation_1 = ''
        let normal_pai_icon_img = ''
        let normal_date_img_date_day = ''
        let normal_date_img_date_week_img = ''
        let normal_date_img_date_month_img = ''
        let normal_compass_icon_img = ''
        let normal_compass_text_img = ''
        let normal_compass_direction_pointer_img = ''
        let normal_compass_direction_img_level = ''
        let normal_compass_direction_arr = ["d_1.png", "d_2.png", "d_3.png", "d_4.png", "d_5.png", "d_6.png", "d_7.png", "d_8.png"];
        let normal_stress_icon_img = ''
        let normal_aqi_pointer_progress_img_pointer = ''
        let normal_uvi_icon_img = ''
        let normal_uvi_pointer_progress_img_pointer = ''
        let icon_bg = ''
        let normal_weather_image_progress_img_level = ''
        let normal_temperature_current_text_img = ''
        let normal_battery_icon_img = ''
        let normal_battery_text_text_img = ''
        let normal_battery_pointer_progress_img_pointer = ''
        let normal_heart_rate_icon_img = ''
        let normal_heart_rate_text_text_img = ''
        let normal_heart_rate_pointer_progress_img_pointer = ''
        let normal_calorie_icon_img = ''
        let normal_calorie_current_text_img = ''
        let normal_calorie_pointer_progress_img_pointer = ''
        let normal_step_icon_img = ''
        let normal_step_current_text_img = ''
        let normal_step_pointer_progress_img_pointer = ''
        let normal_moon_current_text_img = ''
        let normal_moon_pointer_progress_img_pointer = ''
        let normal_sun_current_text_img = ''
        let normal_sun_pointer_progress_img_pointer = ''
        let normal_humidity_pointer_progress_img_pointer = ''
        let normal_analog_clock_time_pointer_hour = ''
        let normal_analog_clock_time_pointer_minute = ''
        let normal_analog_clock_time_pointer_second = ''
        let idle_background_bg_img = ''
        let idle_battery_icon_img = ''
        let idle_battery_text_text_img = ''
        let idle_battery_pointer_progress_img_pointer = ''
        let idle_heart_rate_icon_img = ''
        let idle_heart_rate_text_text_img = ''
        let idle_heart_rate_pointer_progress_img_pointer = ''
        let idle_analog_clock_time_pointer_hour = ''
        let idle_analog_clock_time_pointer_minute = ''
        let normal_sunrise_jumpable_img_click = ''
        let normal_moon_jumpable_img_click = ''
        let Button_1 = ''
        let Button_2 = ''
        let Button_3 = ''
		
		const { width: DEVICE_WIDTH, height: DEVICE_HEIGHT } = hmSetting.getDeviceInfo();
		
		let group1 = ''
		let group2 = ''
		let group3 = ''
		let group4 = ''
		let group5 = ''
		let group6 = ''
		let group7 = ''
		
		let btn_zona1 = ''
        let zona1_num = 0
        let zona1_all = 1
		
		function click_zona1() {
		  zona1_num = (zona1_num + 1) % (zona1_all + 1);
          if (zona1_num == 0) {		
		    group4.setProperty(hmUI.prop.VISIBLE, true);
			group3.setProperty(hmUI.prop.VISIBLE, false);
		    hmUI.showToast({
            });
          };
		  
		 if (zona1_num == 1) {
			group4.setProperty(hmUI.prop.VISIBLE, false);
			group3.setProperty(hmUI.prop.VISIBLE, true);
		    hmUI.showToast({
            });
          };
        }
		
		let btn_zona2 = ''
        let zona2_num = 0
        let zona2_all = 1
		
		function click_zona2() {
		  zona2_num = (zona2_num + 1) % (zona2_all + 1);
          if (zona2_num == 0) {		
		    group6.setProperty(hmUI.prop.VISIBLE, true);
			group5.setProperty(hmUI.prop.VISIBLE, false);
		    hmUI.showToast({
            });
          };
		  
		 if (zona2_num == 1) {
			group6.setProperty(hmUI.prop.VISIBLE, false);
			group5.setProperty(hmUI.prop.VISIBLE, true);
		    hmUI.showToast({
            });
          };
        }
		
		let btn_zona3 = ''
        let zona3_num = 0
        let zona3_all = 3
		
		function click_zona3() {
		  zona3_num = (zona3_num + 1) % (zona3_all + 1);
          if (zona3_num == 0) {		
		    icon_bg.setProperty(hmUI.prop.VISIBLE, true);
            normal_weather_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, true);
			group2.setProperty(hmUI.prop.VISIBLE, false);
			group1.setProperty(hmUI.prop.VISIBLE, false);
			group7.setProperty(hmUI.prop.VISIBLE, false);
		    hmUI.showToast({
            });
          };
		  
		 if (zona3_num == 1) {
			icon_bg.setProperty(hmUI.prop.VISIBLE, false);
            normal_weather_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, false);
			group2.setProperty(hmUI.prop.VISIBLE, true);
			group1.setProperty(hmUI.prop.VISIBLE, false);
			group7.setProperty(hmUI.prop.VISIBLE, false);
		    hmUI.showToast({
            });
          };
		  
		  if (zona3_num == 2) {
			icon_bg.setProperty(hmUI.prop.VISIBLE, false);
            normal_weather_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, false);
			group2.setProperty(hmUI.prop.VISIBLE, false);
			group1.setProperty(hmUI.prop.VISIBLE, true);
			group7.setProperty(hmUI.prop.VISIBLE, false);
		    hmUI.showToast({
            });
          };
		  
		  if (zona3_num == 3) {
			icon_bg.setProperty(hmUI.prop.VISIBLE, false);
            normal_weather_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, false);
			group2.setProperty(hmUI.prop.VISIBLE, false);
			group1.setProperty(hmUI.prop.VISIBLE, false);
			group7.setProperty(hmUI.prop.VISIBLE, true);
		    hmUI.showToast({
            });
          };
        }
		
		const curTime = hmSensor.createSensor(hmSensor.id.TIME);
		const weather = hmSensor.createSensor(hmSensor.id.WEATHER);
		let weatherData = weather.getForecastWeather();
		let forecastData = weatherData.forecastData;
		let sunData = weatherData.tideData;
		let today = '';
		let sunriseMins = '';
		let sunsetMins = '';
		let sunriseMins_def = 8 * 60;			
		let sunsetMins_def = 20 * 60;

		let curMins = '';
		
		let isDayBg = true;
		
		function autoToggleBg() {

			weatherData = weather.getForecastWeather();
			sunData = weatherData.tideData;
			if (sunData.count > 0){
				today = sunData.data[0];
				sunriseMins = today.sunrise.hour * 60 + today.sunrise.minute;
				sunsetMins = today.sunset.hour * 60 + today.sunset.minute;
			} else {
				sunriseMins = sunriseMins_def;
				sunsetMins = sunsetMins_def;
			}

			curMins = curTime.hour * 60 + curTime.minute;
			let isDayNow = (curMins >= sunriseMins) && (curMins < sunsetMins);
			
			if(isDayNow){
				if(!isDayBg){
					icon_bg.setProperty(hmUI.prop.SRC, "day.png");
					isDayBg = true;
				}
			} else {
				if(isDayBg){
					icon_bg.setProperty(hmUI.prop.SRC, "night.png");
					isDayBg = false;
				}
			}
		}


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            console.log('Watch_Face.ScreenNormal');
            normal_background_bg = hmUI.createWidget(hmUI.widget.FILL_RECT, {
              x: 0,
              y: 0,
              w: 466,
              h: 466,
              color: '0xFF000000',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_frame_animation_1 = hmUI.createWidget(hmUI.widget.IMG_ANIM, {
              x: 107,
              y: 58,
              anim_path: "animation",
              anim_ext: "png",
              anim_prefix: "anim",
              anim_fps: 15,
              anim_size: 100,
              repeat_count: 0,
              anim_repeat: true,
              anim_status:hmUI.anim_status.START,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_pai_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'bg.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 218,
              day_startY: 153,
              day_sc_array: ["sm_0.png","sm_1.png","sm_2.png","sm_3.png","sm_4.png","sm_5.png","sm_6.png","sm_7.png","sm_8.png","sm_9.png"],
              day_tc_array: ["sm_0.png","sm_1.png","sm_2.png","sm_3.png","sm_4.png","sm_5.png","sm_6.png","sm_7.png","sm_8.png","sm_9.png"],
              day_en_array: ["sm_0.png","sm_1.png","sm_2.png","sm_3.png","sm_4.png","sm_5.png","sm_6.png","sm_7.png","sm_8.png","sm_9.png"],
              day_zero: 1,
              day_space: 0,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 0,
              y: 0,
              week_en: ["week_1.png","week_2.png","week_3.png","week_4.png","week_5.png","week_6.png","week_7.png"],
              week_tc: ["week_1.png","week_2.png","week_3.png","week_4.png","week_5.png","week_6.png","week_7.png"],
              week_sc: ["week_1.png","week_2.png","week_3.png","week_4.png","week_5.png","week_6.png","week_7.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_month_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 0,
              month_startY: 0,
              month_sc_array: ["m_1.png","m_2.png","m_3.png","m_4.png","m_5.png","m_6.png","m_7.png","m_8.png","m_9.png","m_10.png","m_11.png","m_12.png"],
              month_tc_array: ["m_1.png","m_2.png","m_3.png","m_4.png","m_5.png","m_6.png","m_7.png","m_8.png","m_9.png","m_10.png","m_11.png","m_12.png"],
              month_en_array: ["m_1.png","m_2.png","m_3.png","m_4.png","m_5.png","m_6.png","m_7.png","m_8.png","m_9.png","m_10.png","m_11.png","m_12.png"],
              month_is_character: true ,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
			
			group7 = hmUI.createWidget(hmUI.widget.GROUP, {
	                  x: 0,
	                  y: 0,
	                  w: DEVICE_WIDTH,
	                  h: DEVICE_HEIGHT,
            });

            normal_compass_icon_img = group7.createWidget(hmUI.widget.IMG, {
              x: 174,
              y: 309,
              src: 'compass.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_compass_text_img = group7.createWidget(hmUI.widget.TEXT_IMG, {
              x: 196,
              y: 347,
              font_array: ["sm_0.png","sm_1.png","sm_2.png","sm_3.png","sm_4.png","sm_5.png","sm_6.png","sm_7.png","sm_8.png","sm_9.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'du.png',
              unit_tc: 'du.png',
              unit_en: 'du.png',
              align_h: hmUI.align.CENTER_H,
              // type: hmUI.data_type.COMPASS,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            const deviceInfo = hmSetting.getDeviceInfo();
            
            // normal_compass_custom_pointer_img = hmUI.createWidget(hmUI.widget.CUSTOM_POINTER, {
              // src: 'Pointer12.png',
              // center_x: 233,
              // center_y: 369,
              // x: 9,
              // y: 55,
              // start_angle: 0,
              // end_angle: 360,
              // type: hmUI.data_type.COMPASS,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });


            //start of ignored block
            normal_compass_direction_pointer_img = group7.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: deviceInfo.width,
              h: deviceInfo.height,
              pos_x: 233 - 9,
              pos_y: 369 - 55,
              center_x: 233,
              center_y: 369,
              src: 'Pointer12.png',
              angle: 0,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            //end of ignored block

            normal_compass_direction_img_level = group7.createWidget(hmUI.widget.IMG, {
              x: 216,
              y: 364,
              src: 'd_1.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
              // img_error: 'direction-NULL.png',
              // type: hmUI.data_type.COMPASS,
            });
			
			group1 = hmUI.createWidget(hmUI.widget.GROUP, {
	                  x: 0,
	                  y: 0,
	                  w: DEVICE_WIDTH,
	                  h: DEVICE_HEIGHT,
            });

            normal_stress_icon_img = group1.createWidget(hmUI.widget.IMG, {
              x: 174,
              y: 309,
              src: 'AQI.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_aqi_pointer_progress_img_pointer = group1.createWidget(hmUI.widget.IMG_POINTER, {
              src: 'Pointer01.png',
              center_x: 234,
              center_y: 368,
              x: 13,
              y: 58,
              start_angle: -133,
              end_angle: 137,
              invalid_visible: false,
              type: hmUI.data_type.AQI,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
			
			group2 = hmUI.createWidget(hmUI.widget.GROUP, {
	                  x: 0,
	                  y: 0,
	                  w: DEVICE_WIDTH,
	                  h: DEVICE_HEIGHT,
            });

            normal_uvi_icon_img = group2.createWidget(hmUI.widget.IMG, {
              x: 174,
              y: 309,
              src: 'temperature.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_uvi_pointer_progress_img_pointer = group2.createWidget(hmUI.widget.IMG_POINTER, {
              src: 'Pointer09.png',
              center_x: 233,
              center_y: 369,
              x: 10,
              y: 59,
              start_angle: -140,
              end_angle: 140,
              invalid_visible: false,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            icon_bg = hmUI.createWidget(hmUI.widget.IMG, {
              x: 173,
              y: 308,
			  src: 'day.png',
			  show_level: hmUI.show_level.ONLY_NORMAL,
			});
			
			autoToggleBg();

            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 195,
              y: 327,
              image_array: ["w_1.png","w_2.png","w_3.png","w_4.png","w_5.png","w_6.png","w_7.png","w_8.png","w_9.png","w_10.png","w_11.png","w_12.png","w_13.png","w_14.png","w_15.png","w_16.png","w_17.png","w_18.png","w_19.png","w_20.png","w_21.png","w_22.png","w_23.png","w_24.png","w_25.png","w_26.png","w_27.png","w_28.png","w_29.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_text_img = group2.createWidget(hmUI.widget.TEXT_IMG, {
              x: 211,
              y: 398,
              font_array: ["sm_0.png","sm_1.png","sm_2.png","sm_3.png","sm_4.png","sm_5.png","sm_6.png","sm_7.png","sm_8.png","sm_9.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'du.png',
              unit_tc: 'du.png',
              unit_en: 'du.png',
              negative_image: 'fuhao.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
			
			group3 = hmUI.createWidget(hmUI.widget.GROUP, {
	                  x: 0,
	                  y: 0,
	                  w: DEVICE_WIDTH,
	                  h: DEVICE_HEIGHT,
            });

            normal_battery_icon_img = group3.createWidget(hmUI.widget.IMG, {
              x: 39,
              y: 157,
              src: 'battery.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_text_img = group3.createWidget(hmUI.widget.TEXT_IMG, {
              x: 85,
              y: 257,
              font_array: ["sm_0.png","sm_1.png","sm_2.png","sm_3.png","sm_4.png","sm_5.png","sm_6.png","sm_7.png","sm_8.png","sm_9.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'present.png',
              unit_tc: 'present.png',
              unit_en: 'present.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_pointer_progress_img_pointer = group3.createWidget(hmUI.widget.IMG_POINTER, {
              src: 'littleline.png',
              center_x: 115,
              center_y: 234,
              x: 21,
              y: 64,
              start_angle: -133,
              end_angle: 134,
              invalid_visible: false,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
			
			group4 = hmUI.createWidget(hmUI.widget.GROUP, {
	                  x: 0,
	                  y: 0,
	                  w: DEVICE_WIDTH,
	                  h: DEVICE_HEIGHT,
            });

            normal_heart_rate_icon_img = group4.createWidget(hmUI.widget.IMG, {
              x: 39,
              y: 157,
              src: 'heart.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_text_img = group4.createWidget(hmUI.widget.TEXT_IMG, {
              x: 92,
              y: 257,
              font_array: ["sm_0.png","sm_1.png","sm_2.png","sm_3.png","sm_4.png","sm_5.png","sm_6.png","sm_7.png","sm_8.png","sm_9.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_pointer_progress_img_pointer = group4.createWidget(hmUI.widget.IMG_POINTER, {
              src: 'littleline.png',
              center_x: 115,
              center_y: 234,
              x: 21,
              y: 64,
              start_angle: -133,
              end_angle: 135,
              invalid_visible: false,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
			
			group5 = hmUI.createWidget(hmUI.widget.GROUP, {
	                  x: 0,
	                  y: 0,
	                  w: DEVICE_WIDTH,
	                  h: DEVICE_HEIGHT,
            });

            normal_calorie_icon_img = group5.createWidget(hmUI.widget.IMG, {
              x: 276,
              y: 157,
              src: 'cal.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_calorie_current_text_img = group5.createWidget(hmUI.widget.TEXT_IMG, {
              x: 321,
              y: 257,
              font_array: ["sm_0.png","sm_1.png","sm_2.png","sm_3.png","sm_4.png","sm_5.png","sm_6.png","sm_7.png","sm_8.png","sm_9.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_calorie_pointer_progress_img_pointer = group5.createWidget(hmUI.widget.IMG_POINTER, {
              src: 'littleline.png',
              center_x: 350,
              center_y: 234,
              x: 21,
              y: 64,
              start_angle: -134,
              end_angle: 133,
              invalid_visible: false,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
			
			group6 = hmUI.createWidget(hmUI.widget.GROUP, {
	                  x: 0,
	                  y: 0,
	                  w: DEVICE_WIDTH,
	                  h: DEVICE_HEIGHT,
            });

            normal_step_icon_img = group6.createWidget(hmUI.widget.IMG, {
              x: 276,
              y: 157,
              src: 'step.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_text_img = group6.createWidget(hmUI.widget.TEXT_IMG, {
              x: 316,
              y: 257,
              font_array: ["sm_0.png","sm_1.png","sm_2.png","sm_3.png","sm_4.png","sm_5.png","sm_6.png","sm_7.png","sm_8.png","sm_9.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_pointer_progress_img_pointer = group6.createWidget(hmUI.widget.IMG_POINTER, {
              src: 'littleline.png',
              center_x: 350,
              center_y: 234,
              x: 21,
              y: 64,
              start_angle: -134,
              end_angle: 133,
              invalid_visible: false,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_moon_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 323,
              y: 124,
              font_array: ["sm_0.png","sm_1.png","sm_2.png","sm_3.png","sm_4.png","sm_5.png","sm_6.png","sm_7.png","sm_8.png","sm_9.png"],
              padding: false,
              h_space: 0,
              dot_image: 'dots.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.MOON_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_moon_pointer_progress_img_pointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
              src: 'sunmoon_moon.png',
              center_x: 233,
              center_y: 233,
              x: 47,
              y: 163,
              start_angle: -27,
              end_angle: 40,
              invalid_visible: false,
              type: hmUI.data_type.MOON_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sun_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 81,
              y: 124,
              font_array: ["sm_0.png","sm_1.png","sm_2.png","sm_3.png","sm_4.png","sm_5.png","sm_6.png","sm_7.png","sm_8.png","sm_9.png"],
              padding: false,
              h_space: 0,
              dot_image: 'dots.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.SUN_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sun_pointer_progress_img_pointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
              src: 'sunmoon_sun.png',
              center_x: 233,
              center_y: 233,
              x: 47,
              y: 192,
              start_angle: -30,
              end_angle: 40,
              invalid_visible: false,
              type: hmUI.data_type.SUN_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_humidity_pointer_progress_img_pointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
              src: 'weatherpinter.png',
              center_x: 233,
              center_y: 369,
              x: 11,
              y: 92,
              start_angle: -88,
              end_angle: -272,
              invalid_visible: false,
              type: hmUI.data_type.HUMIDITY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_hour = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              hour_path: 'h.png',
              hour_centerX: 233,
              hour_centerY: 233,
              hour_posX: 50,
              hour_posY: 233,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_minute = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              minute_path: 'min.png',
              minute_centerX: 233,
              minute_centerY: 233,
              minute_posX: 50,
              minute_posY: 233,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_second = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              second_path: 'second.png',
              second_centerX: 233,
              second_centerY: 233,
              second_posX: 50,
              second_posY: 233,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            console.log('Watch_Face.ScreenAOD');
            idle_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 466,
              h: 466,
              src: 'aodbg.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_battery_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 276,
              y: 157,
              src: 'battery.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 321,
              y: 257,
              font_array: ["sm_0.png","sm_1.png","sm_2.png","sm_3.png","sm_4.png","sm_5.png","sm_6.png","sm_7.png","sm_8.png","sm_9.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'present.png',
              unit_tc: 'present.png',
              unit_en: 'present.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_battery_pointer_progress_img_pointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
              src: 'littleline.png',
              center_x: 350,
              center_y: 234,
              x: 21,
              y: 64,
              start_angle: -133,
              end_angle: 134,
              invalid_visible: false,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_heart_rate_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 39,
              y: 157,
              src: 'heart.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 92,
              y: 257,
              font_array: ["sm_0.png","sm_1.png","sm_2.png","sm_3.png","sm_4.png","sm_5.png","sm_6.png","sm_7.png","sm_8.png","sm_9.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_heart_rate_pointer_progress_img_pointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
              src: 'littleline.png',
              center_x: 115,
              center_y: 234,
              x: 21,
              y: 64,
              start_angle: -133,
              end_angle: 135,
              invalid_visible: false,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_analog_clock_time_pointer_hour = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              hour_path: 'h2.png',
              hour_centerX: 233,
              hour_centerY: 233,
              hour_posX: 50,
              hour_posY: 233,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_analog_clock_time_pointer_minute = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              minute_path: 'min2.png',
              minute_centerX: 233,
              minute_centerY: 233,
              minute_posX: 50,
              minute_posY: 233,
              show_level: hmUI.show_level.ONLY_AOD,
            });
            console.log('Watch_Face.Shortcuts');

            btn_zona2 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 311,
              y: 194,
              text: '',
              w: 83,
              h: 83,
              normal_src: 'Empty.png',
              press_src: 'Empty.png',
              click_func: () => {
				click_zona2();
             },
			  longpress_func: () => {
             hmApp.startApp({ url: "activityAppScreen", native: true });
             },
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            btn_zona2.setProperty(hmUI.prop.VISIBLE, true);
			group5.setProperty(hmUI.prop.VISIBLE, false);

            btn_zona1 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 73,
              y: 194,
              text: '',
              w: 83,
              h: 83,
              normal_src: 'Empty.png',
              press_src: 'Empty.png',
              click_func: () => {
				click_zona1();
             },
			  longpress_func: () => {
             hmApp.startApp({ url: "heart_app_Screen", native: true });
             },
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            btn_zona1.setProperty(hmUI.prop.VISIBLE, true);
			group3.setProperty(hmUI.prop.VISIBLE, false);

            btn_zona3 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 193,
              y: 328,
              text: '',
              w: 83,
              h: 83,
              normal_src: 'Empty.png',
              press_src: 'Empty.png',
              click_func: () => {
				click_zona3();
             },
			  longpress_func: () => {
             hmApp.startApp({ url: "WeatherScreen", native: true });
             },
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            btn_zona3.setProperty(hmUI.prop.VISIBLE, true);
			group2.setProperty(hmUI.prop.VISIBLE, false);
			group1.setProperty(hmUI.prop.VISIBLE, false);
			group7.setProperty(hmUI.prop.VISIBLE, false);

            normal_sunrise_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 83,
              y: 97,
              w: 58,
              h: 49,
              type: hmUI.data_type.SUN_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_moon_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 330,
              y: 97,
              w: 58,
              h: 49,
              type: hmUI.data_type.MOON_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            console.log('Watch_Face.Buttons');
            Button_1 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 79,
              y: 316,
              w: 63,
              h: 63,
              text: '',
              color: 0xFFFF8C00,
              text_size: 24,
              press_src: 'Empty.png',
              normal_src: 'Empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'PhoneRecentCallScreen', native: true });
              }, // end func
              longpress_func: (button_widget) => {
                hmApp.startApp({url: 'PhoneContactsScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_2 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 325,
              y: 316,
              w: 63,
              h: 63,
              text: '',
              color: 0xFFFF8C00,
              text_size: 24,
              press_src: 'Empty.png',
              normal_src: 'Empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'Settings_homeScreen', native: true });
              }, // end func
              longpress_func: (button_widget) => {
                hmApp.startApp({url: 'VoiceMemoScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_3 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 199,
              y: 121,
              w: 68,
              h: 49,
              text: '',
              color: 0xFFFF8C00,
              text_size: 24,
              press_src: 'Empty.png',
              normal_src: 'Empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'ScheduleCalScreen', native: true });
              }, // end func
              longpress_func: (button_widget) => {
                hmApp.startApp({url: 'todoListScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            let screenType = hmSetting.getScreenType();
            //start of ignored block
            console.log('compass_update()');
            if (screenType == hmSetting.screen_type.WATCHFACE){
              compass = hmSensor.createSensor(hmSensor.id.COMPASS);
              compass.start();

              if (compass.direction_angle && compass.direction  && compass.direction_angle != 'INVALID') { // initial data
                // Compass Number
                let compass_direction_angle = parseInt(compass.direction_angle);
                let normal_compass_direction_angle_text = compass_direction_angle.toString();
                normal_compass_text_img.setProperty(hmUI.prop.TEXT, normal_compass_direction_angle_text);
                // Compass Pointer
                normal_compass_direction_pointer_img.setProperty(hmUI.prop.ANGLE, -compass_direction_angle);
                // Compass Images
                let compass_direction_angle_img = compass_direction_angle + 45 / 2;
                let compass_direction_index = parseInt(compass_direction_angle_img/45);
                if (compass_direction_index > 7) compass_direction_index = 0;
                normal_compass_direction_img_level.setProperty(hmUI.prop.SRC, normal_compass_direction_arr[compass_direction_index]);

              } else { // error data
                normal_compass_text_img.setProperty(hmUI.prop.TEXT, '-');
                normal_compass_direction_pointer_img.setProperty(hmUI.prop.ANGLE, 0);
                normal_compass_direction_img_level.setProperty(hmUI.prop.SRC, 'direction-NULL.png');

              }

              compass.addEventListener(hmSensor.event.CHANGE, function (compass_res) { // change values when changing direction

                if (compass_res.calibration_status) {
                  // Compass Number
                  let compass_direction_angle = parseInt(compass_res.direction_angle);
                  let normal_compass_direction_angle_text = compass_direction_angle.toString();
                  normal_compass_text_img.setProperty(hmUI.prop.TEXT, normal_compass_direction_angle_text);
                  // Compass Pointer
                  normal_compass_direction_pointer_img.setProperty(hmUI.prop.ANGLE, -compass_direction_angle);
                  // Compass Images
                  let compass_direction_angle_img = compass_direction_angle + 45 / 2;
                  let compass_direction_index = parseInt(compass_direction_angle_img/45);
                  if (compass_direction_index > 7) compass_direction_index = 0;
                  normal_compass_direction_img_level.setProperty(hmUI.prop.SRC, normal_compass_direction_arr[compass_direction_index]);

                } else { // error data
                  normal_compass_text_img.setProperty(hmUI.prop.TEXT, '-');
                  normal_compass_direction_pointer_img.setProperty(hmUI.prop.ANGLE, 0);
                  normal_compass_direction_img_level.setProperty(hmUI.prop.SRC, 'direction-NULL.png');

                }

              }); // Listener end

            };
            //end of ignored block

            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                console.log('resume_call()');
				autoToggleBg();
                normal_frame_animation_1.setProperty(hmUI.prop.ANIM_STATUS,hmUI.anim_status.START);
                if (compass && screenType == hmSetting.screen_type.WATCHFACE) compass.start();

              }),
              pause_call: (function () {
                console.log('pause_call()');
                normal_frame_animation_1.setProperty(hmUI.prop.ANIM_STATUS,hmUI.anim_status.STOP);
                if (compass) compass.stop();

              }),
            });

                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}