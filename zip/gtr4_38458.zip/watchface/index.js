﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        const logger = Logger.getLogger('watchface_SashaCX75');
        //end of ignored block

        //dynamic modify start

        
        console.log('user_functions.js');
        // start user_functions.js


        let normal_step_image_progress_img = ''
		

        // end user_functions.js

        let normal_city_name_text = ''
        let normal_weather_image_progress_img_level = ''
        let normal_temperature_icon_img = ''
        let normal_temperature_high_text_img = ''
        let normal_temperature_low_text_img = ''
        let normal_temperature_current_text_img = ''
        let normal_battery_image_progress_img_level = ''
        let normal_battery_text_text_img = ''
        let normal_pai_icon_img = ''
        let normal_pai_image_progress_img_level = ''
        let normal_pai_weekly_text_img = ''
        let normal_pai_day_text_img = ''
        let normal_heart_rate_image_progress_img_level = ''
        let normal_heart_rate_text_text_img = ''
        let normal_distance_icon_img = ''
        let normal_distance_text_text_img = ''
        let normal_step_icon_img = ''
        let normal_step_current_text_img = ''
        let normal_date_img_date_day = ''
        let normal_date_img_date_week_img = ''
        let normal_date_img_date_month_img = ''
        let normal_digital_clock_img_time_AmPm = ''
        let normal_digital_clock_img_time = ''
        let normal_digital_clock_hour_separator_img = ''
        let normal_temperature_jumpable_img_click = ''
        let normal_pai_jumpable_img_click = ''
        let normal_heart_jumpable_img_click = ''
        let normal_step_jumpable_img_click = ''


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            console.log('Watch_Face.ScreenNormal');
              const weatherSensor = hmSensor.createSensor(hmSensor.id.WEATHER);

            normal_city_name_text = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 130,
              y: 288,
              w: 260,
              h: 39,
              text_size: 26,
              char_space: 0,
              line_space: 0,
              color: 0xFFFFFFFF,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.NONE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 173,
              y: 330,
              image_array: ["wea_000.png","wea_001.png","wea_002.png","wea_003.png","wea_004.png","wea_005.png","wea_006.png","wea_007.png","wea_008.png","wea_009.png","wea_010.png","wea_011.png","wea_012.png","wea_013.png","wea_014.png","wea_015.png","wea_016.png","wea_017.png","wea_018.png","wea_019.png","wea_020.png","wea_021.png","wea_022.png","wea_023.png","wea_024.png","wea_025.png","wea_026.png","wea_027.png","wea_028.png"],
              image_length: 29,
              shortcut: true,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 222,
              y: 383,
              src: 'tinydig_014.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_high_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 246,
              y: 376,
              font_array: ["tinydig_000.png","tinydig_001.png","tinydig_002.png","tinydig_003.png","tinydig_004.png","tinydig_005.png","tinydig_006.png","tinydig_007.png","tinydig_008.png","tinydig_009.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'tinydig_012.png',
              unit_tc: 'tinydig_012.png',
              unit_en: 'tinydig_012.png',
              negative_image: 'tinydig_011.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.WEATHER_HIGH,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_low_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 178,
              y: 376,
              font_array: ["tinydig_000.png","tinydig_001.png","tinydig_002.png","tinydig_003.png","tinydig_004.png","tinydig_005.png","tinydig_006.png","tinydig_007.png","tinydig_008.png","tinydig_009.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'tinydig_012.png',
              unit_tc: 'tinydig_012.png',
              unit_en: 'tinydig_012.png',
              negative_image: 'tinydig_011.png',
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.WEATHER_LOW,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 209,
              y: 329,
              font_array: ["daydig_000.png","daydig_001.png","daydig_002.png","daydig_003.png","daydig_004.png","daydig_005.png","daydig_006.png","daydig_007.png","daydig_008.png","daydig_009.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'daydig_012.png',
              unit_tc: 'daydig_012.png',
              unit_en: 'daydig_012.png',
              negative_image: 'daydig_011.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 193,
              y: 424,
              image_array: ["bat_000.png","bat_001.png","bat_002.png","bat_003.png","bat_004.png","bat_005.png","bat_006.png","bat_007.png","bat_008.png","bat_009.png","bat_010.png","bat_011.png","bat_012.png","bat_013.png","bat_014.png","bat_015.png","bat_016.png","bat_017.png","bat_018.png","bat_019.png","bat_020.png","bat_021.png","bat_022.png","bat_023.png","bat_024.png","bat_025.png","bat_026.png","bat_027.png","bat_028.png","bat_029.png","bat_030.png","bat_031.png","bat_032.png","bat_033.png","bat_034.png","bat_035.png","bat_036.png","bat_037.png","bat_038.png","bat_039.png"],
              image_length: 40,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 205,
              y: 424,
              font_array: ["tinydig_000.png","tinydig_001.png","tinydig_002.png","tinydig_003.png","tinydig_004.png","tinydig_005.png","tinydig_006.png","tinydig_007.png","tinydig_008.png","tinydig_009.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'tinydig_013.png',
              unit_tc: 'tinydig_013.png',
              unit_en: 'tinydig_013.png',
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_pai_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 333,
              y: 331,
              src: 'pai_icon.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_pai_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 333,
              y: 331,
              image_array: ["pai_001.png"],
              image_length: 1,
              type: hmUI.data_type.PAI_WEEKLY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_pai_weekly_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 373,
              y: 340,
              font_array: ["daydig_000.png","daydig_001.png","daydig_002.png","daydig_003.png","daydig_004.png","daydig_005.png","daydig_006.png","daydig_007.png","daydig_008.png","daydig_009.png"],
              padding: false,
              h_space: -2,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.PAI_WEEKLY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_pai_day_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 310,
              y: 340,
              font_array: ["daydig_000.png","daydig_001.png","daydig_002.png","daydig_003.png","daydig_004.png","daydig_005.png","daydig_006.png","daydig_007.png","daydig_008.png","daydig_009.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.PAI_DAILY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 65,
              y: 334,
              image_array: ["heart_000.png","heart_001.png","heart_002.png","heart_003.png","heart_004.png","heart_005.png"],
              image_length: 6,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 79,
              y: 342,
              font_array: ["daydig_000.png","daydig_001.png","daydig_002.png","daydig_003.png","daydig_004.png","daydig_005.png","daydig_006.png","daydig_007.png","daydig_008.png","daydig_009.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_distance_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 302,
              y: 39,
              src: 'step_000.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_distance_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 290,
              y: 50,
              font_array: ["daydig_000.png","daydig_001.png","daydig_002.png","daydig_003.png","daydig_004.png","daydig_005.png","daydig_006.png","daydig_007.png","daydig_008.png","daydig_009.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'daydig_014.png',
              unit_tc: 'daydig_014.png',
              unit_en: 'daydig_014.png',
              imperial_unit_sc: 'daydig_013.png',
              imperial_unit_tc: 'daydig_013.png',
              imperial_unit_en: 'daydig_013.png',
              dot_image: 'daydig_010.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.DISTANCE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 100,
              y: 45,
              src: 'shoe_icon.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 100,
              y: 56,
              font_array: ["daydig_000.png","daydig_001.png","daydig_002.png","daydig_003.png","daydig_004.png","daydig_005.png","daydig_006.png","daydig_007.png","daydig_008.png","daydig_009.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 380,
              day_startY: 111,
              day_sc_array: ["daydig_000.png","daydig_001.png","daydig_002.png","daydig_003.png","daydig_004.png","daydig_005.png","daydig_006.png","daydig_007.png","daydig_008.png","daydig_009.png"],
              day_tc_array: ["daydig_000.png","daydig_001.png","daydig_002.png","daydig_003.png","daydig_004.png","daydig_005.png","daydig_006.png","daydig_007.png","daydig_008.png","daydig_009.png"],
              day_en_array: ["daydig_000.png","daydig_001.png","daydig_002.png","daydig_003.png","daydig_004.png","daydig_005.png","daydig_006.png","daydig_007.png","daydig_008.png","daydig_009.png"],
              day_zero: 0,
              day_space: -1,
              day_align: hmUI.align.LEFT,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 62,
              y: 115,
              week_en: ["wkday_001.png","wkday_002.png","wkday_003.png","wkday_004.png","wkday_005.png","wkday_006.png","wkday_007.png"],
              week_tc: ["wkday_001.png","wkday_002.png","wkday_003.png","wkday_004.png","wkday_005.png","wkday_006.png","wkday_007.png"],
              week_sc: ["wkday_001.png","wkday_002.png","wkday_003.png","wkday_004.png","wkday_005.png","wkday_006.png","wkday_007.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_month_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 242,
              month_startY: 115,
              month_sc_array: ["mon_001.png","mon_002.png","mon_003.png","mon_004.png","mon_005.png","mon_006.png","mon_007.png","mon_008.png","mon_009.png","mon_010.png","mon_011.png","mon_012.png"],
              month_tc_array: ["mon_001.png","mon_002.png","mon_003.png","mon_004.png","mon_005.png","mon_006.png","mon_007.png","mon_008.png","mon_009.png","mon_010.png","mon_011.png","mon_012.png"],
              month_en_array: ["mon_001.png","mon_002.png","mon_003.png","mon_004.png","mon_005.png","mon_006.png","mon_007.png","mon_008.png","mon_009.png","mon_010.png","mon_011.png","mon_012.png"],
              month_is_character: true ,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time_AmPm = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              am_x: 356,
              am_y: 222,
              am_sc_path: 'clk_am.png',
              am_en_path: 'clk_am.png',
              pm_x: 356,
              pm_y: 222,
              pm_sc_path: 'clk_pm.png',
              pm_en_path: 'clk_pm.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 50,
              hour_startY: 115,
              hour_array: ["hmdig_000.png","hmdig_001.png","hmdig_002.png","hmdig_003.png","hmdig_004.png","hmdig_005.png","hmdig_006.png","hmdig_007.png","hmdig_008.png","hmdig_009.png"],
              hour_zero: 0,
              hour_space: -8,
              hour_angle: 0,
              hour_align: hmUI.align.RIGHT,

              minute_startX: 214,
              minute_startY: 115,
              minute_array: ["hmdig_000.png","hmdig_001.png","hmdig_002.png","hmdig_003.png","hmdig_004.png","hmdig_005.png","hmdig_006.png","hmdig_007.png","hmdig_008.png","hmdig_009.png"],
              minute_zero: 1,
              minute_space: -2,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              second_startX: 352,
              second_startY: 145,
              second_array: ["secdig_000.png","secdig_001.png","secdig_002.png","secdig_003.png","secdig_004.png","secdig_005.png","secdig_006.png","secdig_007.png","secdig_008.png","secdig_009.png"],
              second_zero: 1,
              second_space: 0,
              second_angle: 0,
              second_follow: 0,
              second_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_hour_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 179,
              y: 107,
              src: 'hmdig_010.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            console.log('Watch_Face.Shortcuts');

            normal_temperature_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 158,
              y: 295,
              w: 152,
              h: 123,
              src: 'shoe_000.png',
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_pai_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 320,
              y: 311,
              w: 95,
              h: 100,
              src: 'pai_000.png',
              type: hmUI.data_type.PAI_WEEKLY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 55,
              y: 311,
              w: 92,
              h: 100,
              src: 'shoe_000.png',
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 88,
              y: 25,
              w: 94,
              h: 100,
              src: 'shoe_000.png',
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            console.log('user_script_end.js');
            // start user_script_end.js

		
	normal_step_image_progress_img = hmUI.createWidget(hmUI.widget.IMG, {
		x: 100,
		y: 45,
		src: "shoe_001.png",
		show_level: hmUI.show_level.ONLY_NORMAL,
        });
	
	normal_step_image_progress_img.setProperty(hmUI.prop.VISIBLE, false);
	
	const step = hmSensor.createSensor(hmSensor.id.STEP);

	step.addEventListener(hmSensor.event.CHANGE, function () {
		if ( step.current >= step.target ) {
			normal_step_image_progress_img.setProperty(hmUI.prop.VISIBLE, true);
		} else {
			normal_step_image_progress_img.setProperty(hmUI.prop.VISIBLE, false);
		};
	});
            // end user_script_end.js

            function scale_call() {
              console.log('scale_call()');

              console.log('Weather city name');
              let weatherData = weatherSensor.getForecastWeather();
              normal_city_name_text.setProperty(hmUI.prop.TEXT, weatherData.cityName);

            };

            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                console.log('resume_call()');
                scale_call();
              }),
            });

                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}