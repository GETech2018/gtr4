﻿/*
 ** Watch_Face_Editor tool
 ** watchface js version v2.1.1
 ** Copyright © SashaCX75. All Rights Reserved
 */

try {
  (() => {
    //start of ignored block
    const __$$app$$__ = __$$hmAppManager$$__.currentApp;
    function getApp() {
      return __$$app$$__.app;
    }
    function getCurrentPage() {
      return __$$app$$__.current && __$$app$$__.current.module;
    }
    const __$$module$$__ = __$$app$$__.current;
    const h = new DeviceRuntimeCore.WidgetFactory(
      new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__)
    );
    const { px } = __$$app$$__.__globals__;
    const logger = Logger.getLogger("watchface_SashaCX75");
    //end of ignored block

    //dynamic modify start
    const heart = hmSensor.createSensor(hmSensor.id.HEART);
    const step = hmSensor.createSensor(hmSensor.id.STEP);
    const weather = hmSensor.createSensor(hmSensor.id.WEATHER);
    const calorie = hmSensor.createSensor(hmSensor.id.CALORIE);
    const distance = hmSensor.createSensor(hmSensor.id.DISTANCE);
    const world_clock = hmSensor.createSensor(hmSensor.id.WORLD_CLOCK);
    let idle_digital_clock_minute_separator_img,
      idle_background_bg,
      idle_image_img,
      mil_text,
      km_text,
      step_text,
      bpm_text,
      gmt_text,
      cal_text,
      week_text,
      gmt_gmt_text,
      city_text,
      day_text;
    let normal_image_mask;
    let weatherData = weather.getForecastWeather();
    let background_hour = "";
    let background_sec = "";
    let normal_weather_image_progress_img_level = "";
    let normal_step_current_text_img = "";
    let normal_battery_circle_scale = "";
    let normal_image_img = "";
    let normal_digital_clock_img_time = "";
    let normal_digital_clock_hour_separator_img = "";
    let normal_digital_clock_minute_separator_img = "";
    let day_string = "";
    let week_string = ["mon,", "tue,", "wed,", "thu,", "fri,", "sat,", "sun,"];
    let w_string = "";
    let gmt_string = "";
    let cal_string = "";
    let step_string = "";
    let bpm_string = "";
    let km_string = "";
    let mil_string = "";
    let city_string = "";
    let month_string = [
      "jan",
      "feb",
      "mar",
      "apr",
      "may",
      "jun",
      "jul",
      "aug",
      "sep",
      "oct",
      "nov",
      "dec",
    ];
    let h_color = [
      0xffffff, 0xffffff, 0xffffff, 0xffffff, 0x00a9ef, 0x6dfd00, 0xfd008a,
      0xfd6600,
    ];

    let s_color = [
      0xfec400, 0x00b1fe, 0xfe0025, 0xfe00f9, 0x00a9ef, 0x6dfd00, 0xfd008a,
      0xfd6600,
    ];

    let b_color = [
      0x00bff0, 0xf0003f, 0x00f045, 0x83f000, 0x00a9ef, 0x6dfd00, 0xfd008a,
      0xfd6600,
    ];

    let index = 0;
    let screen_num = 0;
    let worldData = undefined;

    //dynamic modify end

    __$$module$$__.module = DeviceRuntimeCore.WatchFace({
      init_view() {
        //dynamic modify start
        const time = hmSensor.createSensor(hmSensor.id.TIME);
        world_clock.init();

        background_hour = hmUI.createWidget(hmUI.widget.FILL_RECT, {
          x: 65,
          y: 148,
          w: 235,
          h: 100,
          color: h_color[screen_num],
          show_level: hmUI.show_level.ONLY_NORMAL,
        });

        background_sec = hmUI.createWidget(hmUI.widget.FILL_RECT, {
          x: 300,
          y: 148,
          w: 103,
          h: 100,
          color: s_color[screen_num],
          show_level: hmUI.show_level.ONLY_NORMAL,
        });

        normal_image_img = hmUI.createWidget(hmUI.widget.IMG, {
          x: 0,
          y: 0,
          src: "bg_1.png",
          show_level: hmUI.show_level.ONLY_NORMAL,
        });

        normal_weather_image_progress_img_level = hmUI.createWidget(
          hmUI.widget.IMG_LEVEL,
          {
            x: 217,
            y: 59,
            image_array: [
              "weather_1.png",
              "weather_2.png",
              "weather_3.png",
              "weather_4.png",
              "weather_5.png",
              "weather_6.png",
              "weather_7.png",
              "weather_8.png",
              "weather_9.png",
              "weather_10.png",
              "weather_11.png",
              "weather_12.png",
              "weather_13.png",
              "weather_14.png",
              "weather_15.png",
              "weather_16.png",
              "weather_17.png",
              "weather_18.png",
              "weather_19.png",
              "weather_20.png",
              "weather_21.png",
              "weather_22.png",
              "weather_23.png",
              "weather_24.png",
              "weather_25.png",
              "weather_26.png",
              "weather_27.png",
              "weather_28.png",
              "weather_29.png",
            ],
            image_length: 29,
            type: hmUI.data_type.WEATHER_CURRENT,
            show_level: hmUI.show_level.ONLY_NORMAL,
          }
        );

        let screenType = hmSetting.getScreenType();

        normal_battery_circle_scale = hmUI.createWidget(
          hmUI.widget.ARC_PROGRESS,
          {
            center_x: 233,
            center_y: 233,
            start_angle: 0,
            end_angle: 360,
            radius: 225,
            line_width: 12,
            corner_flag: 3,
            color: b_color[screen_num],
            show_level: hmUI.show_level.ONLY_NORMAL,
          }
        );

        const battery = hmSensor.createSensor(hmSensor.id.BATTERY);
        battery.addEventListener(hmSensor.event.CHANGE, function () {
          scale_call();
        });

        normal_image_mask = hmUI.createWidget(hmUI.widget.IMG, {
          x: 0,
          y: 0,
          src: "mask_bat.png",
          show_level: hmUI.show_level.ONLY_NORMAL,
        });

        normal_digital_clock_img_time = hmUI.createWidget(
          hmUI.widget.IMG_TIME,
          {
            hour_startX: 67,
            hour_startY: 150,
            hour_array: [
              "hc_cl_0.png",
              "hc_cl_1.png",
              "hc_cl_2.png",
              "hc_cl_3.png",
              "hc_cl_4.png",
              "hc_cl_5.png",
              "hc_cl_6.png",
              "hc_cl_7.png",
              "hc_cl_8.png",
              "hc_cl_9.png",
            ],
            hour_zero: 1,
            hour_space: 0,
            hour_angle: 0,
            hour_align: hmUI.align.RIGHT,

            minute_startX: 186,
            minute_startY: 150,
            minute_array: [
              "hc_cl_0.png",
              "hc_cl_1.png",
              "hc_cl_2.png",
              "hc_cl_3.png",
              "hc_cl_4.png",
              "hc_cl_5.png",
              "hc_cl_6.png",
              "hc_cl_7.png",
              "hc_cl_8.png",
              "hc_cl_9.png",
            ],
            minute_zero: 1,
            minute_space: 0,
            minute_angle: 0,
            minute_follow: 0,
            minute_align: hmUI.align.CENTER_H,

            second_startX: 305,
            second_startY: 150,
            second_array: [
              "hc_cl_0.png",
              "hc_cl_1.png",
              "hc_cl_2.png",
              "hc_cl_3.png",
              "hc_cl_4.png",
              "hc_cl_5.png",
              "hc_cl_6.png",
              "hc_cl_7.png",
              "hc_cl_8.png",
              "hc_cl_9.png",
            ],
            second_zero: 1,
            second_space: 0,
            second_angle: 0,
            second_follow: 0,
            second_align: hmUI.align.LEFT,

            show_level: hmUI.show_level.ONLY_NORMAL,
          }
        );

        normal_digital_clock_hour_separator_img = hmUI.createWidget(
          hmUI.widget.IMG,
          {
            x: 163,
            y: 149,
            src: "hc_cl_10.png",
            show_level: hmUI.show_level.ONLY_NORMAL,
          }
        );

        normal_digital_clock_minute_separator_img = hmUI.createWidget(
          hmUI.widget.IMG,
          {
            x: 282,
            y: 149,
            src: "hc_cl_10.png",
            show_level: hmUI.show_level.ONLY_NORMAL,
          }
        );

        //----------------------------------------------------------------------------------------------------------------
        //----------------------------------------------------------------------------------------------------------------

        sunrise_text = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
          x: 255,
          y: 326,
          w: 80,
          h: 18,
          color: 0xffffff,
          text_size: 18,
          align_h: hmUI.align.CENTER_H,
          align_v: hmUI.align.CENTER_V,
          text_style: hmUI.text_style.NONE,
          font: "Marsek_Demi.ttf",
          type: hmUI.data_type.SUN_RISE,
          show_level: hmUI.show_level.ONLY_NORMAL,
        });

        sunset_text = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
          x: 255,
          y: 344,
          w: 80,
          h: 18,
          color: 0xffffff,
          text_size: 18,
          align_h: hmUI.align.CENTER_H,
          align_v: hmUI.align.CENTER_V,
          text_style: hmUI.text_style.NONE,
          font: "Marsek_Demi.ttf",
          type: hmUI.data_type.SUN_SET,
          show_level: hmUI.show_level.ONLY_NORMAL,
        });

        wind_text = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
          x: 50,
          y: 120,
          w: 100,
          h: 18,
          color: 0xffffff,
          text_size: 18,
          align_h: hmUI.align.RIGHT,
          align_v: hmUI.align.CENTER_V,
          text_style: hmUI.text_style.NONE,
          font: "Marsek_Demi.ttf",
          type: hmUI.data_type.WIND,
          //text: "22",
          show_level: hmUI.show_level.ONLY_NORMAL,
        });

        wind_mps_text = hmUI.createWidget(hmUI.widget.TEXT, {
          x: 130,
          y: 120,
          w: 100,
          h: 18,
          color: 0xffffff,
          text_size: 18,
          align_h: hmUI.align.CENTER_H,
          align_v: hmUI.align.CENTER_V,
          text_style: hmUI.text_style.NONE,
          font: "Marsek_Demi.ttf",
          text: "mps",
          show_level: hmUI.show_level.ONLY_NORMAL,
        });

        temp_text = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
          x: 138,
          y: 98,
          w: 100,
          h: 18,
          color: 0xffffff,
          text_size: 18,
          align_h: hmUI.align.RIGHT,
          align_v: hmUI.align.CENTER_V,
          text_style: hmUI.text_style.NONE,
          font: "Marsek_Demi.ttf",
          type: hmUI.data_type.WEATHER_CURRENT,
          //text: "2",
          show_level: hmUI.show_level.ONLY_NORMAL,
        });

        temp_text_c = hmUI.createWidget(hmUI.widget.TEXT, {
          x: 200,
          y: 98,
          w: 100,
          h: 18,
          color: 0xffffff,
          text_size: 18,
          align_h: hmUI.align.CENTER_H,
          align_v: hmUI.align.CENTER_V,
          text_style: hmUI.text_style.NONE,
          font: "Marsek_Demi.ttf",
          text: "°C",
          show_level: hmUI.show_level.ONLY_NORMAL,
        });

        altitude_text = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
          x: 220,
          y: 120,
          w: 100,
          h: 18,
          color: 0xffffff,
          text_size: 18,
          align_h: hmUI.align.RIGHT,
          align_v: hmUI.align.CENTER_V,
          text_style: hmUI.text_style.NONE,
          font: "Marsek_Demi.ttf",
          type: hmUI.data_type.ALTITUDE,
          show_level: hmUI.show_level.ONLY_NORMAL,
        });

        altitude_m_text = hmUI.createWidget(hmUI.widget.TEXT, {
          x: 295,
          y: 120,
          w: 100,
          h: 18,
          color: 0xffffff,
          text_size: 18,
          align_h: hmUI.align.CENTER_H,
          align_v: hmUI.align.CENTER_V,
          text_style: hmUI.text_style.NONE,
          font: "Marsek_Demi.ttf",
          text: "m",
          show_level: hmUI.show_level.ONLY_NORMAL,
        });

        city_text = hmUI.createWidget(hmUI.widget.TEXT, {
          x: 83,
          y: 375,
          w: 300,
          h: 18,
          color: 0xffffff,
          text_size: 18,
          align_h: hmUI.align.CENTER_H,
          align_v: hmUI.align.CENTER_V,
          text_style: hmUI.text_style.NONE,
          font: "Marsek_Demi.ttf",
          text: city_string,
          show_level: hmUI.show_level.ONLY_NORMAL,
        });

        day_text = hmUI.createWidget(hmUI.widget.TEXT, {
          x: 250,
          y: 246,
          w: 200,
          h: 23,
          color: 0xffffff,
          text_size: 23,
          align_h: hmUI.align.CENTER_H,
          align_v: hmUI.align.CENTER_V,
          text_style: hmUI.text_style.NONE,
          font: "Marsek_Demi.ttf",
          text: day_string,
          show_level: hmUI.show_level.ONLY_NORMAL,
        });

        week_text = hmUI.createWidget(hmUI.widget.TEXT, {
          x: 180,
          y: 246,
          w: 100,
          h: 23,
          color: s_color[screen_num],
          text_size: 23,
          align_h: hmUI.align.RIGHT,
          align_v: hmUI.align.CENTER_V,
          text_style: hmUI.text_style.NONE,
          font: "Marsek_Demi.ttf",
          text: week_string[1],
          show_level: hmUI.show_level.ONLY_NORMAL,
        });

        gmt_gmt_text = hmUI.createWidget(hmUI.widget.TEXT, {
          x: 50,
          y: 246,
          w: 100,
          h: 23,
          color: s_color[screen_num],
          text_size: 23,
          align_h: hmUI.align.CENTER_H,
          align_v: hmUI.align.CENTER_V,
          text_style: hmUI.text_style.NONE,
          font: "Marsek_Demi.ttf",
          text: "gmt",
          show_level: hmUI.show_level.ONLY_NORMAL,
        });

        gmt_text = hmUI.createWidget(hmUI.widget.TEXT, {
          x: 130,
          y: 246,
          w: 60,
          h: 23,
          color: 0xffffff,
          text_size: 23,
          align_h: hmUI.align.CENTER_H,
          align_v: hmUI.align.CENTER_V,
          text_style: hmUI.text_style.NONE,
          font: "Marsek_Demi.ttf",
          text: gmt_string,
          show_level: hmUI.show_level.ONLY_NORMAL,
        });

        cal_text = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
          x: 48,
          y: 276,
          w: 100,
          h: 23,
          color: 0xffffff,
          text_size: 23,
          align_h: hmUI.align.CENTER_H,
          align_v: hmUI.align.CENTER_V,
          text_style: hmUI.text_style.NONE,
          font: "Marsek_Demi.ttf",
          type: hmUI.data_type.CAL,
          show_level: hmUI.show_level.ONLY_NORMAL,
        });

        step_text = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
          x: 170,
          y: 276,
          w: 130,
          h: 23,
          color: 0xffffff,
          text_size: 23,
          align_h: hmUI.align.CENTER_H,
          align_v: hmUI.align.CENTER_V,
          text_style: hmUI.text_style.NONE,
          font: "Marsek_Demi.ttf",
          type: hmUI.data_type.STEP,
          show_level: hmUI.show_level.ONLY_NORMAL,
        });

        bpm_text = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
          x: 322,
          y: 276,
          w: 100,
          h: 23,
          color: 0xffffff,
          text_size: 23,
          align_h: hmUI.align.CENTER_H,
          align_v: hmUI.align.CENTER_V,
          text_style: hmUI.text_style.NONE,
          font: "Marsek_Demi.ttf",
          type: hmUI.data_type.HEART,
          show_level: hmUI.show_level.ONLY_NORMAL,
        });

        km_text = hmUI.createWidget(hmUI.widget.TEXT, {
          x: 95,
          y: 326,
          w: 80,
          h: 18,
          color: 0xffffff,
          text_size: 18,
          align_h: hmUI.align.CENTER_H,
          align_v: hmUI.align.CENTER_V,
          text_style: hmUI.text_style.NONE,
          font: "Marsek_Demi.ttf",
          text: km_string,
          show_level: hmUI.show_level.ONLY_NORMAL,
        });

        mil_text = hmUI.createWidget(hmUI.widget.TEXT, {
          x: 95,
          y: 344,
          w: 80,
          h: 18,
          color: 0xffffff,
          text_size: 18,
          align_h: hmUI.align.CENTER_H,
          align_v: hmUI.align.CENTER_V,
          text_style: hmUI.text_style.NONE,
          font: "Marsek_Demi.ttf",
          text: mil_string,
          show_level: hmUI.show_level.ONLY_NORMAL,
        });

        //----------------------------------------------------------------------------------------------------------------
        //----------------------------------------------------------------------------------------------------------------

        idle_background_bg = hmUI.createWidget(hmUI.widget.FILL_RECT, {
          x: 0,
          y: 0,
          w: 466,
          h: 466,
          color: "0x8b8b8b",
          show_level: hmUI.show_level.ONLY_AOD,
        });

        idle_image_img = hmUI.createWidget(hmUI.widget.IMG, {
          x: 0,
          y: 0,
          src: "bg_aod.png",
          show_level: hmUI.show_level.ONLY_AOD,
        });

        idle_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
          hour_startX: 125,
          hour_startY: 186,
          hour_array: [
            "hc_cl_0.png",
            "hc_cl_1.png",
            "hc_cl_2.png",
            "hc_cl_3.png",
            "hc_cl_4.png",
            "hc_cl_5.png",
            "hc_cl_6.png",
            "hc_cl_7.png",
            "hc_cl_8.png",
            "hc_cl_9.png",
          ],
          hour_zero: 1,
          hour_space: 0,
          hour_angle: 0,
          hour_align: hmUI.align.LEFT,

          minute_startX: 244,
          minute_startY: 186,
          minute_array: [
            "hc_cl_0.png",
            "hc_cl_1.png",
            "hc_cl_2.png",
            "hc_cl_3.png",
            "hc_cl_4.png",
            "hc_cl_5.png",
            "hc_cl_6.png",
            "hc_cl_7.png",
            "hc_cl_8.png",
            "hc_cl_9.png",
          ],
          minute_zero: 1,
          minute_space: 0,
          minute_angle: 0,
          minute_follow: 0,
          minute_align: hmUI.align.LEFT,

          show_level: hmUI.show_level.ONLY_AOD,
        });

        idle_digital_clock_minute_separator_img = hmUI.createWidget(
          hmUI.widget.IMG,
          {
            x: 221,
            y: 186,
            src: "hc_cl_10.png",
            show_level: hmUI.show_level.ONLY_AOD,
          }
        );

        //----------------------------------------------------------------------------------------------------------------
        //----------------------------------------------------------------------------------------------------------------

        function scale_call() {
          let valueBattery = battery.current;
          let targetBattery = 100;
          let progressBattery = valueBattery / targetBattery;
          if (progressBattery > 1) progressBattery = 1;
          let progress_cs_normal_battery = progressBattery;

          if (screenType != hmSetting.screen_type.AOD) {
            // normal_battery_circle_scale_circle_scale
            let level = Math.round(progress_cs_normal_battery * 100);
            if (normal_battery_circle_scale) {
              normal_battery_circle_scale.setProperty(hmUI.prop.MORE, {
                center_x: 233,
                center_y: 233,
                start_angle: 0,
                end_angle: 360,
                radius: 225,
                line_width: 12,
                corner_flag: 3,
                color: b_color[screen_num],
                show_level: hmUI.show_level.ONLY_NORMAL,
                level: level,
              });
            }
          }
        }

        function screen_change() {
          if (screen_num == 7) screen_num = 0;
          else {
            screen_num = screen_num + 1;
          }
          console.log(screen_num);
          hmUI.showToast({ text: "Theme " + parseInt(screen_num + 1) });
          background_hour.setProperty(hmUI.prop.COLOR, h_color[screen_num]);
          background_sec.setProperty(hmUI.prop.COLOR, s_color[screen_num]);
          normal_image_img.setProperty(
            hmUI.prop.SRC,
            "bg_" + parseInt(screen_num + 1) + ".png"
          );

          if (screen_num > 3) {
            gmt_gmt_text.setProperty(hmUI.prop.COLOR, 0x8b8b8b);
            week_text.setProperty(hmUI.prop.COLOR, 0x8b8b8b);
          } else {
            gmt_gmt_text.setProperty(hmUI.prop.COLOR, s_color[screen_num]);
            week_text.setProperty(hmUI.prop.COLOR, s_color[screen_num]);
          }

          normal_battery_circle_scale.setProperty(hmUI.prop.MORE, {
            center_x: 233,
            center_y: 233,
            start_angle: 0,
            end_angle: 360,
            radius: 225,
            line_width: 12,
            corner_flag: 3,
            color: b_color[screen_num],
            show_level: hmUI.show_level.ONLY_NORMAL,
          });
        }

        function updateDistance() {
          km_string = String((distance.current / 1000).toFixed(2));
          km_text.setProperty(hmUI.prop.MORE, {
            font: "Marsek_Demi.ttf",
            text: km_string,
          });
          mil_string = String((distance.current / 1000 / 1.609).toFixed(2));
          mil_text.setProperty(hmUI.prop.MORE, {
            font: "Marsek_Demi.ttf",
            text: mil_string,
          });
        }

        function updateDay() {
          day_string =
            time.day.toString() + " " + month_string[time.month - 1] + " ";
          day_text.setProperty(hmUI.prop.MORE, {
            font: "Marsek_Demi.ttf",
            text: day_string,
          });
          w_string = week_string[time.week - 1];
          week_text.setProperty(hmUI.prop.MORE, {
            font: "Marsek_Demi.ttf",
            text: w_string,
          });
        }

        function updateCity() {
          city_string = weatherData.cityName;
          city_text.setProperty(hmUI.prop.MORE, {
            //font: "Marsek_Demi.ttf",
            text: city_string,
          });
        }

        function updateGmt() {
          let a = new Date(time.utc);
          let hours = a.getUTCHours();
          let gmt = time.hour - hours;
          gmt_string = String(gmt);
          console.log(gmt_string);
          gmt_text.setProperty(hmUI.prop.MORE, {
            font: "Marsek_Demi.ttf",
            text: gmt_string,
          });
        }

        function TimeUpdate() {
          updateDistance();
          updateDay();
          updateCity();
          updateGmt();
        }

        time.addEventListener(time.event.MINUTEEND, function () {
          TimeUpdate();
        });

        const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
          resume_call: function () {
            scale_call();
            TimeUpdate();
          },
          pause_call: function () {},
        });

        normal_stopwatch_jumpable_img_click = hmUI.createWidget(
          hmUI.widget.IMG_CLICK,
          {
            x: 304,
            y: 142,
            w: 100,
            h: 100,
            type: hmUI.data_type.STOP_WATCH,
            show_level: hmUI.show_level.ONLY_NORMAL,
          }
        );

        normal_countdown_jumpable_img_click = hmUI.createWidget(
          hmUI.widget.IMG_CLICK,
          {
            x: 64,
            y: 142,
            w: 100,
            h: 100,
            type: hmUI.data_type.COUNT_DOWN,
            show_level: hmUI.show_level.ONLY_NORMAL,
          }
        );

        screen_button = hmUI.createWidget(hmUI.widget.BUTTON, {
          x: 183,
          y: 364,
          w: 100,
          h: 100,
          text: "",
          normal_src: "transparent.png",
          press_src: "transparent.png",
          click_func: () => {
            //vibro();
            screen_change();
          },
          show_level: hmUI.show_level.ONLY_NORMAL,
        });
        screen_button.setProperty(hmUI.prop.VISIBLE, true);

        normal_temperature_jumpable_img_click = hmUI.createWidget(
          hmUI.widget.IMG_CLICK,
          {
            x: 183,
            y: 29,
            w: 100,
            h: 100,
            type: hmUI.data_type.WEATHER_CURRENT,
            show_level: hmUI.show_level.ONLY_NORMAL,
          }
        );

        normal_pai_jumpable_img_click = hmUI.createWidget(
          hmUI.widget.IMG_CLICK,
          {
            x: 48,
            y: 247,
            w: 100,
            h: 100,
            type: hmUI.data_type.PAI_WEEKLY,
            show_level: hmUI.show_level.ONLY_NORMAL,
          }
        );

        normal_heart_jumpable_img_click = hmUI.createWidget(
          hmUI.widget.IMG_CLICK,
          {
            x: 319,
            y: 247,
            w: 100,
            h: 100,
            type: hmUI.data_type.HEART,
            show_level: hmUI.show_level.ONLY_NORMAL,
          }
        );

        normal_step_jumpable_img_click = hmUI.createWidget(
          hmUI.widget.IMG_CLICK,
          {
            x: 183,
            y: 247,
            w: 100,
            h: 100,
            type: hmUI.data_type.STEP,
            show_level: hmUI.show_level.ONLY_NORMAL,
          }
        );

        //dynamic modify end
      },
      onInit() {
        logger.log("index page.js on init invoke");
      },
      build() {
        this.init_view();
        logger.log("index page.js on ready invoke");
      },
      onDestroy() {
        logger.log("index page.js on destroy invoke");
      },
    });
  })();
} catch (e) {
  console.log("Mini Program Error", e);
  e &&
    e.stack &&
    e.stack.split(/\n/).forEach((i) => console.log("error stack", i));
}
