﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        const logger = Logger.getLogger('watchface_SashaCX75');
        //end of ignored block

        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_analog_clock_time_pointer_second = ''
        let normal_heart_rate_text_text_img = ''
        let normal_temperature_high_text_img = ''
        let normal_temperature_low_text_img = ''
        let normal_temperature_current_text_img = ''
        let normal_weather_image_progress_img_level = ''
        let normal_step_circle_scale = ''
        let normal_step_pointer_progress_img_pointer = ''
        let normal_step_current_text_img = ''
        let normal_date_img_date_day = ''
        let normal_date_img_date_month_img = ''
        let normal_digital_clock_img_time = ''
        let normal_digital_clock_hour_separator_img = ''
        let normal_digital_clock_img_time_AmPm = ''
        let normal_system_lock_img = ''
        let normal_system_dnd_img = ''
        let normal_system_disconnect_img = ''
        let normal_system_clock_img = ''
        let normal_week_pointer_progress_date_pointer = ''
        let normal_battery_pointer_progress_img_pointer = ''
        let normal_battery_text_text_img = ''
        let idle_digital_clock_img_time = ''
        let idle_digital_clock_hour_separator_img = ''
        let idle_digital_clock_img_time_AmPm = ''
        let Button_1 = ''
        let Button_2 = ''
        let Button_3 = ''
        let Button_4 = ''
        let Button_5 = ''
        let Button_6 = ''
        let Button_7 = ''


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            console.log('Watch_Face.ScreenNormal');
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 466,
              h: 466,
              src: 'AFFmAIN.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_second = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              second_path: 'sec1.png',
              second_centerX: 231,
              second_centerY: 235,
              second_posX: 146,
              second_posY: 146,
              second_cover_path: 'AFFmAIN.png',
              second_cover_x: 0,
              second_cover_y: 0,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 323,
              y: 360,
              font_array: ["dig_red_10.png","dig_red_11.png","dig_red_12.png","dig_red_13.png","dig_red_14.png","dig_red_15.png","dig_red_16.png","dig_red_17.png","dig_red_18.png","dig_red_19.png"],
              padding: false,
              h_space: -1,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_high_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 117,
              y: 320,
              font_array: ["dig_small_0.png","dig_small_1.png","dig_small_2.png","dig_small_3.png","dig_small_4.png","dig_small_5.png","dig_small_6.png","dig_small_7.png","dig_small_8.png","dig_small_9.png"],
              padding: false,
              h_space: -4,
              unit_sc: 'i6.png',
              unit_tc: 'i6.png',
              unit_en: 'i6.png',
              negative_image: 'i5.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_HIGH,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_low_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 53,
              y: 320,
              font_array: ["dig_small_0.png","dig_small_1.png","dig_small_2.png","dig_small_3.png","dig_small_4.png","dig_small_5.png","dig_small_6.png","dig_small_7.png","dig_small_8.png","dig_small_9.png"],
              padding: false,
              h_space: -4,
              unit_sc: 'i6.png',
              unit_tc: 'i6.png',
              unit_en: 'i6.png',
              negative_image: 'i5.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_LOW,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 85,
              y: 361,
              font_array: ["dig_red_10.png","dig_red_11.png","dig_red_12.png","dig_red_13.png","dig_red_14.png","dig_red_15.png","dig_red_16.png","dig_red_17.png","dig_red_18.png","dig_red_19.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'i2.png',
              unit_tc: 'i2.png',
              unit_en: 'i2.png',
              negative_image: 'i3.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 93,
              y: 282,
              image_array: ["wi01.png","wi02.png","wi03.png","wi04.png","wi05.png","wi06.png","wi07.png","wi08.png","wi09.png","wi10.png","wi11.png","wi12.png","wi13.png","wi14.png","wi15.png","wi16.png","wi17.png","wi18.png","wi19.png","wi20.png","wi21.png","wi22.png","wi23.png","wi24.png","wi25.png","wi26.png","wi27.png","wi28.png","wi29.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_step_circle_scale = hmUI.createWidget(hmUI.widget.Circle_Scale, {
              // center_x: 238,
              // center_y: 228,
              // start_angle: 93,
              // end_angle: -32,
              // radius: 111,
              // line_width: 13,
              // line_cap: Flat,
              // color: 0xFFB50E00,
              // mirror: False,
              // inversion: False,
              // type: hmUI.data_type.STEP,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            let screenType = hmSetting.getScreenType();
            normal_step_circle_scale = hmUI.createWidget(hmUI.widget.ARC_PROGRESS, {
              center_x: 238,
              center_y: 228,
              start_angle: 93,
              end_angle: -32,
              radius: 105,
              line_width: 13,
              corner_flag: 3,
              color: 0xFFB50E00,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            
            const step = hmSensor.createSensor(hmSensor.id.STEP);
            step.addEventListener(hmSensor.event.CHANGE, function() {
              scale_call();
            });

            normal_step_pointer_progress_img_pointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
              src: 'steps_point_red.png',
              center_x: 234,
              center_y: 233,
              x: 49,
              y: -90,
              start_angle: 254,
              end_angle: 127,
              invalid_visible: false,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 195,
              y: 160,
              font_array: ["dig_small_0.png","dig_small_1.png","dig_small_2.png","dig_small_3.png","dig_small_4.png","dig_small_5.png","dig_small_6.png","dig_small_7.png","dig_small_8.png","dig_small_9.png"],
              padding: false,
              h_space: -6,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 347,
              day_startY: 273,
              day_sc_array: ["dig_red_10.png","dig_red_11.png","dig_red_12.png","dig_red_13.png","dig_red_14.png","dig_red_15.png","dig_red_16.png","dig_red_17.png","dig_red_18.png","dig_red_19.png"],
              day_tc_array: ["dig_red_10.png","dig_red_11.png","dig_red_12.png","dig_red_13.png","dig_red_14.png","dig_red_15.png","dig_red_16.png","dig_red_17.png","dig_red_18.png","dig_red_19.png"],
              day_en_array: ["dig_red_10.png","dig_red_11.png","dig_red_12.png","dig_red_13.png","dig_red_14.png","dig_red_15.png","dig_red_16.png","dig_red_17.png","dig_red_18.png","dig_red_19.png"],
              day_zero: 1,
              day_space: 0,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_month_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 218,
              month_startY: 322,
              month_sc_array: ["mon_1.png","mon_2.png","mon_3.png","mon_4.png","mon_5.png","mon_6.png","mon_7.png","mon_8.png","mon_9.png","mon_10.png","mon_11.png","mon_12.png"],
              month_tc_array: ["mon_1.png","mon_2.png","mon_3.png","mon_4.png","mon_5.png","mon_6.png","mon_7.png","mon_8.png","mon_9.png","mon_10.png","mon_11.png","mon_12.png"],
              month_en_array: ["mon_1.png","mon_2.png","mon_3.png","mon_4.png","mon_5.png","mon_6.png","mon_7.png","mon_8.png","mon_9.png","mon_10.png","mon_11.png","mon_12.png"],
              month_is_character: true ,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 148,
              hour_startY: 367,
              hour_array: ["dig_cin_0.png","dig_cin_1.png","dig_cin_2.png","dig_cin_3.png","dig_cin_4.png","dig_cin_5.png","dig_cin_6.png","dig_cin_7.png","dig_cin_8.png","dig_cin_9.png"],
              hour_zero: 1,
              hour_space: 0,
              hour_angle: 0,
              hour_align: hmUI.align.LEFT,

              minute_startX: 242,
              minute_startY: 367,
              minute_array: ["dig_red_20.png","dig_red_21.png","dig_red_22.png","dig_red_23.png","dig_red_24.png","dig_red_25.png","dig_red_26.png","dig_red_27.png","dig_red_28.png","dig_red_29.png"],
              minute_zero: 1,
              minute_space: 0,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_hour_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 214,
              y: 367,
              src: 'i4.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time_AmPm = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              am_x: 120,
              am_y: 402,
              am_sc_path: 'am.png',
              am_en_path: 'am.png',
              pm_x: 120,
              pm_y: 402,
              pm_sc_path: 'pm.png',
              pm_en_path: 'pm.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_lock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 340,
              y: 316,
              src: 'y4.png',
              type: hmUI.system_status.LOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_dnd_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 324,
              y: 320,
              src: 'y3.png',
              type: hmUI.system_status.DISTURB,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 319,
              y: 401,
              src: 'y1.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 309,
              y: 330,
              src: 'y2.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_week_pointer_progress_date_pointer = hmUI.createWidget(hmUI.widget.DATE_POINTER, {
              src: 'indicizverg.png',
              center_x: 250,
              center_y: 301,
              posX: 47,
              posY: 64,
              start_angle: -123,
              end_angle: 91,
              type: hmUI.date.WEEK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_pointer_progress_img_pointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
              src: 'indic.png',
              center_x: 106,
              center_y: 226,
              x: 48,
              y: 64,
              start_angle: -125,
              end_angle: 124,
              invalid_visible: false,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 73,
              y: 257,
              font_array: ["dig_bra_0.png","dig_bra_1.png","dig_bra_2.png","dig_bra_3.png","dig_bra_4.png","dig_bra_5.png","dig_bra_6.png","dig_bra_7.png","dig_bra_8.png","dig_bra_9.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            console.log('Watch_Face.ScreenAOD');

            idle_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 148,
              hour_startY: 367,
              hour_array: ["aod0.png","aod1.png","aod2.png","aod3.png","aod4.png","aod5.png","aod6.png","aod7.png","aod8.png","aod9.png"],
              hour_zero: 1,
              hour_space: 0,
              hour_angle: 0,
              hour_align: hmUI.align.LEFT,

              minute_startX: 242,
              minute_startY: 367,
              minute_array: ["aod0.png","aod1.png","aod2.png","aod3.png","aod4.png","aod5.png","aod6.png","aod7.png","aod8.png","aod9.png"],
              minute_zero: 1,
              minute_space: 0,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_hour_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 214,
              y: 367,
              src: 'aod_i1.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time_AmPm = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              am_x: 120,
              am_y: 402,
              am_sc_path: 'aod_am.png',
              am_en_path: 'aod_am.png',
              pm_x: 120,
              pm_y: 402,
              pm_sc_path: 'aod_pm.png',
              pm_en_path: 'aod_pm.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });
            
            // disconnectAlert = hmUI.createWidget(hmUI.widget.DisconnectAlert, {
              // disconneсnt_vibrate_type: 0,
              // disconneсnt_toast_text: Bluetooth OFF,
              // conneсnt_vibrate_type: 0,
              // conneсnt_toast_text: Bluetooth ON,
            // });

            // vibration when connecting or disconnecting

            function checkConnection() {
              console.log('checkConnection()');
              hmBle.removeListener;
              hmBle.addListener(function (status) {
                if(!status) {
                  hmUI.showToast({text: "Bluetooth OFF"});
                  vibro(0);
                }
                if(status) {
                  hmUI.showToast({text: "Bluetooth ON"});
                  vibro(0);
                }
              });
            }

            // end vibration when connecting or disconnecting
            // vibrate function

            const vibrate = hmSensor.createSensor(hmSensor.id.VIBRATE);
            let timer_StopVibrate = null;


            function vibro(scene = 25) {
              let stopDelay = 50;
              stopVibro();
              vibrate.stop();
              vibrate.scene = scene;
              if(scene < 23 || scene > 25) stopDelay = 1300;
              vibrate.start();
              if (scene != 1) timer_StopVibrate = timer.createTimer(stopDelay, 3000, stopVibro, {});
            }

            function stopVibro(){
              vibrate.stop();
              if(timer_StopVibrate) timer.stopTimer(timer_StopVibrate);
            }

            // end vibrate function

            console.log('Watch_Face.Buttons');
            Button_1 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 193,
              y: 368,
              w: 77,
              h: 65,
              text: '',
              color: 0xFFFF8C00,
              text_size: 24,
              press_src: 'vuoto.png',
              normal_src: 'vuoto.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'AlarmInfoScreen', native: true });
vibro(25);
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_2 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 68,
              y: 178,
              w: 77,
              h: 78,
              text: '',
              color: 0xFFFF8C00,
              text_size: 24,
              press_src: 'vuoto.png',
              normal_src: 'vuoto.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'Settings_batteryManagerScreen', native: true });
vibro(25);
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_3 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 334,
              y: 251,
              w: 64,
              h: 64,
              text: '',
              color: 0xFFFF8C00,
              text_size: 24,
              press_src: 'vuoto.png',
              normal_src: 'vuoto.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'ScheduleCalScreen', native: true });
vibro(25);
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_4 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 199,
              y: 252,
              w: 107,
              h: 99,
              text: '',
              color: 0xFFFF8C00,
              text_size: 24,
              press_src: 'vuoto.png',
              normal_src: 'vuoto.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'ScheduleCalScreen', native: true });
vibro(25);
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_5 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 84,
              y: 288,
              w: 56,
              h: 118,
              text: '',
              color: 0xFFFF8C00,
              text_size: 24,
              press_src: 'vuoto.png',
              normal_src: 'vuoto.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'WeatherScreen', native: true });
vibro(25);
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_6 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 204,
              y: 159,
              w: 56,
              h: 50,
              text: '',
              color: 0xFFFF8C00,
              text_size: 24,
              press_src: 'vuoto.png',
              normal_src: 'vuoto.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'activityAppScreen', native: true });
vibro(25);
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_7 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 317,
              y: 336,
              w: 67,
              h: 65,
              text: '',
              color: 0xFFFF8C00,
              text_size: 24,
              press_src: 'vuoto.png',
              normal_src: 'vuoto.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'heart_app_Screen', native: true });
vibro(25);
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            function scale_call() {
              console.log('scale_call()');

                console.log('update scales STEP');
                
                let valueStep = step.current;
                let targetStep = step.target;
                let progressStep = valueStep/targetStep;
                if (progressStep > 1) progressStep = 1;
                let progress_cs_normal_step = progressStep;

                if (screenType != hmSetting.screen_type.AOD) {

                  // normal_step_circle_scale_circle_scale
                  let level = Math.round(progress_cs_normal_step * 100);
                  if (normal_step_circle_scale) {
                    normal_step_circle_scale.setProperty(hmUI.prop.MORE, {                      
                      center_x: 238,
                      center_y: 228,
                      start_angle: 93,
                      end_angle: -32,
                      radius: 105,
                      line_width: 13,
                      corner_flag: 3,
                      color: 0xFFB50E00,
                      show_level: hmUI.show_level.ONLY_NORMAL,
                      level: level,
                    });
                  };
                };

            };

            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                console.log('resume_call()');
                scale_call();
                checkConnection();
                stopVibro();

              }),
              pause_call: (function () {
                console.log('pause_call()');
                stopVibro();

              }),
            });

                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}