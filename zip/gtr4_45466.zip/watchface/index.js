    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        const logger = Logger.getLogger('watchface_SashaCX75');
        //end of ignored block

        //dynamic modify start
        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
            console.log('Watch_Face.ScreenNormal');
            hmUI.createWidget(hmUI.widget.IMG,{x:0,y:0,w:466,h:466,src:'background.png',show_level:hmUI.show_level.ONLY_NORMAL});
            const ringW = hmUI.createWidget(hmUI.widget.IMG,{x:0,y:0,w:466,h:466,src:'rg0.png',show_level:hmUI.show_level.ONLY_NORMAL});
            hmUI.createWidget(hmUI.widget.IMG_LEVEL,{x:211,y:79,image_array:["wx0.png", "wx1.png", "wx2.png", "wx3.png", "wx4.png", "wx5.png", "wx6.png", "wx7.png", "wx8.png", "wx9.png", "wx10.png", "wx11.png", "wx12.png", "wx13.png", "wx14.png", "wx15.png", "wx16.png", "wx17.png", "wx18.png", "wx19.png", "wx20.png", "wx21.png", "wx22.png", "wx23.png", "wx24.png", "blank.png", "wx26.png", "wx27.png", "wx28.png"],image_length:29,type:hmUI.data_type.WEATHER_CURRENT,show_level:hmUI.show_level.ONLY_NORMAL});
            hmUI.createWidget(hmUI.widget.TEXT_IMG,{x:0,y:116,w:466,font_array:["ts_48.png","ts_49.png","ts_50.png","ts_51.png","ts_52.png","ts_53.png","ts_54.png","ts_55.png","ts_56.png","ts_57.png"],padding:false,h_space:0,unit_sc:'ts_176.png',unit_tc:'ts_176.png',unit_en:'ts_176.png',negative_image:'ts_45.png',invalid_image:'ts_45.png',align_h:hmUI.align.CENTER_H,type:hmUI.data_type.WEATHER_CURRENT,show_level:hmUI.show_level.ONLY_NORMAL});
            hmUI.createWidget(hmUI.widget.IMG_WEEK,{x:129,y:161,week_en:["wk0.png","wk1.png","wk2.png","wk3.png","wk4.png","wk5.png","wk6.png"],week_tc:["wk0.png","wk1.png","wk2.png","wk3.png","wk4.png","wk5.png","wk6.png"],week_sc:["wk0.png","wk1.png","wk2.png","wk3.png","wk4.png","wk5.png","wk6.png"],show_level:hmUI.show_level.ONLY_NORMAL});
            hmUI.createWidget(hmUI.widget.IMG_DATE,{day_startX:213,day_startY:161,day_sc_array:["sd0.png","sd1.png","sd2.png","sd3.png","sd4.png","sd5.png","sd6.png","sd7.png","sd8.png","sd9.png"],day_tc_array:["sd0.png","sd1.png","sd2.png","sd3.png","sd4.png","sd5.png","sd6.png","sd7.png","sd8.png","sd9.png"],day_en_array:["sd0.png","sd1.png","sd2.png","sd3.png","sd4.png","sd5.png","sd6.png","sd7.png","sd8.png","sd9.png"],day_zero:1,day_space:0,day_align:hmUI.align.LEFT,day_is_character:false,show_level:hmUI.show_level.ONLY_NORMAL});
            hmUI.createWidget(hmUI.widget.IMG_DATE,{month_startX:263,month_startY:161,month_sc_array:["mo0.png","mo1.png","mo2.png","mo3.png","mo4.png","mo5.png","mo6.png","mo7.png","mo8.png","mo9.png","mo10.png","mo11.png"],month_tc_array:["mo0.png","mo1.png","mo2.png","mo3.png","mo4.png","mo5.png","mo6.png","mo7.png","mo8.png","mo9.png","mo10.png","mo11.png"],month_en_array:["mo0.png","mo1.png","mo2.png","mo3.png","mo4.png","mo5.png","mo6.png","mo7.png","mo8.png","mo9.png","mo10.png","mo11.png"],month_is_character:true,show_level:hmUI.show_level.ONLY_NORMAL});
            hmUI.createWidget(hmUI.widget.IMG_TIME,{hour_startX:59,hour_startY:200,hour_array:["ct0.png","ct1.png","ct2.png","ct3.png","ct4.png","ct5.png","ct6.png","ct7.png","ct8.png","ct9.png"],hour_zero:1,hour_space:0,hour_angle:0,hour_align:hmUI.align.LEFT,show_level:hmUI.show_level.ONLY_NORMAL});
            hmUI.createWidget(hmUI.widget.IMG_TIME,{minute_startX:247,minute_startY:200,minute_array:["ct0.png","ct1.png","ct2.png","ct3.png","ct4.png","ct5.png","ct6.png","ct7.png","ct8.png","ct9.png"],minute_zero:1,minute_space:0,minute_angle:0,minute_follow:0,minute_align:hmUI.align.LEFT,show_level:hmUI.show_level.ONLY_NORMAL});
            hmUI.createWidget(hmUI.widget.IMG,{x:222,y:200,src:'ctcolon.png',show_level:hmUI.show_level.ONLY_NORMAL});
            hmUI.createWidget(hmUI.widget.IMG,{x:140,y:281,src:'ic_steps.png',show_level:hmUI.show_level.ONLY_NORMAL});
            hmUI.createWidget(hmUI.widget.TEXT_IMG,{x:179,y:282,font_array:["vd_48.png","vd_49.png","vd_50.png","vd_51.png","vd_52.png","vd_53.png","vd_54.png","vd_55.png","vd_56.png","vd_57.png"],padding:false,h_space:0,unit_sc:'un_steps.png',unit_tc:'un_steps.png',unit_en:'un_steps.png',align_h:hmUI.align.LEFT,type:hmUI.data_type.STEP,show_level:hmUI.show_level.ONLY_NORMAL});
            hmUI.createWidget(hmUI.widget.IMG,{x:161,y:318,src:'ic_cal.png',show_level:hmUI.show_level.ONLY_NORMAL});
            hmUI.createWidget(hmUI.widget.TEXT_IMG,{x:188,y:319,font_array:["vd_48.png","vd_49.png","vd_50.png","vd_51.png","vd_52.png","vd_53.png","vd_54.png","vd_55.png","vd_56.png","vd_57.png"],padding:false,h_space:0,unit_sc:'un_cal.png',unit_tc:'un_cal.png',unit_en:'un_cal.png',align_h:hmUI.align.LEFT,type:hmUI.data_type.CAL,show_level:hmUI.show_level.ONLY_NORMAL});
            hmUI.createWidget(hmUI.widget.IMG,{x:172,y:355,src:'ic_hr.png',show_level:hmUI.show_level.ONLY_NORMAL});
            hmUI.createWidget(hmUI.widget.TEXT_IMG,{x:207,y:356,font_array:["vd_48.png","vd_49.png","vd_50.png","vd_51.png","vd_52.png","vd_53.png","vd_54.png","vd_55.png","vd_56.png","vd_57.png"],padding:false,h_space:0,unit_sc:'un_bpm.png',unit_tc:'un_bpm.png',unit_en:'un_bpm.png',invalid_image:'vd_45.png',align_h:hmUI.align.LEFT,type:hmUI.data_type.HEART,show_level:hmUI.show_level.ONLY_NORMAL});
            hmUI.createWidget(hmUI.widget.TEXT_IMG,{x:0,y:393,w:466,font_array:["vd_48.png","vd_49.png","vd_50.png","vd_51.png","vd_52.png","vd_53.png","vd_54.png","vd_55.png","vd_56.png","vd_57.png"],padding:false,h_space:0,unit_sc:'vd_37.png',unit_tc:'vd_37.png',unit_en:'vd_37.png',align_h:hmUI.align.CENTER_H,type:hmUI.data_type.BATTERY,show_level:hmUI.show_level.ONLY_NORMAL});
            console.log('Watch_Face.ScreenAOD');
            hmUI.createWidget(hmUI.widget.IMG_TIME,{hour_startX:59,hour_startY:200,hour_array:["ca0.png","ca1.png","ca2.png","ca3.png","ca4.png","ca5.png","ca6.png","ca7.png","ca8.png","ca9.png"],hour_zero:1,hour_space:0,hour_angle:0,hour_align:hmUI.align.LEFT,show_level:hmUI.show_level.ONLY_AOD});
            hmUI.createWidget(hmUI.widget.IMG_TIME,{minute_startX:247,minute_startY:200,minute_array:["ca0.png","ca1.png","ca2.png","ca3.png","ca4.png","ca5.png","ca6.png","ca7.png","ca8.png","ca9.png"],minute_zero:1,minute_space:0,minute_angle:0,minute_follow:0,minute_align:hmUI.align.LEFT,show_level:hmUI.show_level.ONLY_AOD});
            hmUI.createWidget(hmUI.widget.IMG,{x:222,y:200,src:'cacolon.png',show_level:hmUI.show_level.ONLY_AOD});
            console.log('Watch_Face.Shortcuts');
            hmUI.createWidget(hmUI.widget.IMG_CLICK,{x:150,y:70,w:166,h:90,type:hmUI.data_type.WEATHER_CURRENT,show_level:hmUI.show_level.ONLY_NORMAL});
            hmUI.createWidget(hmUI.widget.IMG_CLICK,{x:100,y:276,w:266,h:34,type:hmUI.data_type.STEP,show_level:hmUI.show_level.ONLY_NORMAL});
            hmUI.createWidget(hmUI.widget.IMG_CLICK,{x:100,y:313,w:266,h:34,type:hmUI.data_type.CAL,show_level:hmUI.show_level.ONLY_NORMAL});
            hmUI.createWidget(hmUI.widget.IMG_CLICK,{x:100,y:350,w:266,h:34,type:hmUI.data_type.HEART,show_level:hmUI.show_level.ONLY_NORMAL});
            hmUI.createWidget(hmUI.widget.BUTTON,{x:170,y:387,w:126,h:34,text:'',color:0xFFFF8C00,text_size:25,press_src:'blank.png',normal_src:'blank.png',click_func:(button_widget)=>{hmApp.startApp({url:'PowerSaveHintScreen',native:true});},show_level:hmUI.show_level.ONLY_NORMAL});
            hmUI.createWidget(hmUI.widget.BUTTON,{x:120,y:155,w:226,h:28,text:'',color:0xFFFF8C00,text_size:25,press_src:'blank.png',normal_src:'blank.png',click_func:(button_widget)=>{hmApp.startApp({url:'ScheduleCalScreen',native:true});},show_level:hmUI.show_level.ONLY_NORMAL});
            try {
              const compass = hmSensor.createSensor(hmSensor.id.COMPASS);
              const readAngle = function () {
                try { if (typeof compass.getDirectionAngle === 'function') { const g = compass.getDirectionAngle(); if (typeof g === 'number' && !isNaN(g)) return g; } } catch (e) {}
                const keys = ['direction_angle', 'directionAngle', 'angle'];
                for (let i = 0; i < keys.length; i++) {
                  const v = compass[keys[i]];
                  if (typeof v === 'number' && !isNaN(v)) return v;
                }
                return null;
              };
              let lastK = 0;
              const updRing = function () {
                try {
                  const a = readAngle();
                  if (a === null) return;
                  const k = Math.round((((a % 360) + 360) % 360) / 6) % 60;
                  if (k !== lastK) {
                    lastK = k;
                    ringW.setProperty(hmUI.prop.MORE, { x: 0, y: 0, w: 466, h: 466, src: 'rg' + k + '.png' });
                  }
                } catch (e) { console.log('ring update'); }
              };
              let tmr = null;
              const startT = function () { try { if (!tmr && typeof timer !== 'undefined') tmr = timer.createTimer(300, 300, updRing, {}); } catch (e) {} };
              const stopT = function () { try { if (tmr) { timer.stopTimer(tmr); tmr = null; } } catch (e) {} };
              compass.addEventListener(hmSensor.event.CHANGE, updRing);
              try { if (compass.start) compass.start(); } catch (e) {}
              startT();
              hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
                resume_call: function () { try { if (compass.start) compass.start(); } catch (e) {} startT(); updRing(); },
                pause_call: function () { try { if (compass.stop) compass.stop(); } catch (e) {} stopT(); }
              });
              updRing();
            } catch (e) { console.log('compass'); }
                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}