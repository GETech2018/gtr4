﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        const logger = Logger.getLogger('watchface_SashaCX75');
        //end of ignored block

        //dynamic modify start

        
        let normal_background_bg_img = ''
		let alarm_clock_img = ''
		let normal_image_alarm = ''
        let normal_altimeter_text_text_img = ''
        let normal_altimeter_text_separator_img = ''
		let normal_aqi_current_text_img = ''
		let normal_image_aqi = ''
        let normal_wind_text_text_img = ''
        let normal_wind_text_separator_img = ''
        let normal_weather_image_progress_img_level = ''
        let normal_temperature_current_text_img = ''
        let normal_humidity_text_text_img = ''
        let normal_humidity_text_separator_img = ''
        let normal_stress_text_text_img = ''
        let normal_stress_text_separator_img = ''
        let normal_spo2_text_text_img = ''
        let normal_spo2_text_separator_img = ''
        let normal_heart_rate_text_text_img = ''
        let normal_heart_rate_text_separator_img = ''
        let normal_distance_icon_img = ''
        let normal_distance_text_text_img = ''
		let normal_distance_image_progress_img_level = ''
        let normal_calorie_icon_img = ''
        let normal_calorie_current_text_img = ''
        let normal_calorie_image_progress_img_level = ''
        let normal_step_icon_img = ''
        let normal_step_current_text_img = ''
        let normal_step_image_progress_img_level = ''
        let normal_digital_clock_img_time = ''
        let normal_digital_clock_img_time_AmPm = ''
        let normal_date_img_date_day = ''
        let normal_date_img_date_month = ''
        let normal_date_month_separator_img = ''
        let normal_date_img_date_week_img = ''
        let normal_analog_clock_time_pointer_hour = ''
        let normal_analog_clock_time_pointer_minute = ''
        let normal_analog_clock_time_pointer_second = ''
        let normal_system_disconnect_img = ''
        let idle_analog_clock_time_pointer_hour = ''
        let idle_analog_clock_time_pointer_minute = ''
        let idle_system_disconnect_img = ''
        let normal_temperature_jumpable_img_click = ''
        let normal_stress_jumpable_img_click = ''
        let normal_heart_jumpable_img_click = ''
        let normal_step_jumpable_img_click = ''
		
		let bezel_img = ''
        let btn_bezel = ''
        let bezel_num = 1
        let bezel_all = 6
     
        function click_Bezel() {
                   if(bezel_num>=bezel_all) {bezel_num=1;}
                   else { bezel_num=bezel_num+1;}
                   hmUI.showToast({text: "<BackGround> " + parseInt(bezel_num) });
                   normal_background_bg_img.setProperty(hmUI.prop.SRC, "bg_" + parseInt(bezel_num) + ".png");
                   normal_analog_clock_time_pointer_hour.setProperty(hmUI.prop.MORE, {
                   hour_path: `mask_${bezel_num}.png`,
                    hour_centerX: 233,
                    hour_centerY: 233,
                    hour_posX: 35,
                    hour_posY: 173,
                    show_level: hmUI.show_level.ONLY_NORMAL,
                  } );
                   }
				   
		let btn_zona1 = ''
        let zona1_num = 0
        let zona1_all = 2
		
		function click_zona1() {
		  zona1_num = (zona1_num + 1) % (zona1_all + 1);
          if (zona1_num == 0) {		
		    normal_step_icon_img.setProperty(hmUI.prop.VISIBLE, true);
            normal_step_current_text_img.setProperty(hmUI.prop.VISIBLE, true);
			normal_step_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, true);
			normal_calorie_icon_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_calorie_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_calorie_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, false);
			normal_distance_icon_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_distance_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_distance_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, false);
          };
		  
		 if (zona1_num == 1) {
			normal_step_icon_img.setProperty(hmUI.prop.VISIBLE, false);
            normal_step_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_step_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, false);
			normal_calorie_icon_img.setProperty(hmUI.prop.VISIBLE, true);
			normal_calorie_current_text_img.setProperty(hmUI.prop.VISIBLE, true);
			normal_calorie_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, true);
			normal_distance_icon_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_distance_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_distance_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, false);
          };
		  
		  if (zona1_num == 2) {
			normal_step_icon_img.setProperty(hmUI.prop.VISIBLE, false);
            normal_step_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_step_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, false);
			normal_calorie_icon_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_calorie_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_calorie_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, false);
			normal_distance_icon_img.setProperty(hmUI.prop.VISIBLE, true);
			normal_distance_text_text_img.setProperty(hmUI.prop.VISIBLE, true);
			normal_distance_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, true);
          };
        }

		let btn_zona2 = ''
        let zona2_num = 0
        let zona2_all = 4
		
		function click_zona2() {
		  zona2_num = (zona2_num + 1) % (zona2_all + 1);
          if (zona2_num == 0) {		
		    normal_weather_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, true);
            normal_temperature_current_text_img.setProperty(hmUI.prop.VISIBLE, true);
			normal_humidity_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_humidity_text_separator_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_wind_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_wind_text_separator_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_altimeter_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_altimeter_text_separator_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_image_aqi.setProperty(hmUI.prop.VISIBLE, false);
			normal_aqi_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
          };
		  
		 if (zona2_num == 1) {
			normal_weather_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, false);
            normal_temperature_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_humidity_text_text_img.setProperty(hmUI.prop.VISIBLE, true);
			normal_humidity_text_separator_img.setProperty(hmUI.prop.VISIBLE, true);
			normal_wind_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_wind_text_separator_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_altimeter_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_altimeter_text_separator_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_image_aqi.setProperty(hmUI.prop.VISIBLE, false);
			normal_aqi_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
          };
		  
		  if (zona2_num == 2) {
			normal_weather_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, false);
            normal_temperature_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_humidity_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_humidity_text_separator_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_wind_text_text_img.setProperty(hmUI.prop.VISIBLE, true);
			normal_wind_text_separator_img.setProperty(hmUI.prop.VISIBLE, true);
			normal_altimeter_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_altimeter_text_separator_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_image_aqi.setProperty(hmUI.prop.VISIBLE, false);
			normal_aqi_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
          };
		  
		  if (zona2_num == 3) {
			normal_weather_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, false);
            normal_temperature_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_humidity_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_humidity_text_separator_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_wind_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_wind_text_separator_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_altimeter_text_text_img.setProperty(hmUI.prop.VISIBLE, true);
			normal_altimeter_text_separator_img.setProperty(hmUI.prop.VISIBLE, true);
			normal_image_aqi.setProperty(hmUI.prop.VISIBLE, false);
			normal_aqi_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
          };
		  
		  if (zona2_num == 4) {
			normal_weather_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, false);
            normal_temperature_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_humidity_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_humidity_text_separator_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_wind_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_wind_text_separator_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_altimeter_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_altimeter_text_separator_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_image_aqi.setProperty(hmUI.prop.VISIBLE, true);
			normal_aqi_current_text_img.setProperty(hmUI.prop.VISIBLE, true);
          };
        }
		
		let btn_zona3 = ''
        let zona3_num = 0
        let zona3_all = 2
		
		function click_zona3() {
		  zona3_num = (zona3_num + 1) % (zona3_all + 1);
          if (zona3_num == 0) {		
		    normal_heart_rate_text_text_img.setProperty(hmUI.prop.VISIBLE, true);
            normal_heart_rate_text_separator_img.setProperty(hmUI.prop.VISIBLE, true);
			normal_spo2_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_spo2_text_separator_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_stress_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_stress_text_separator_img.setProperty(hmUI.prop.VISIBLE, false);
          };
		  
		 if (zona3_num == 1) {
			normal_heart_rate_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
            normal_heart_rate_text_separator_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_spo2_text_text_img.setProperty(hmUI.prop.VISIBLE, true);
			normal_spo2_text_separator_img.setProperty(hmUI.prop.VISIBLE, true);
			normal_stress_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_stress_text_separator_img.setProperty(hmUI.prop.VISIBLE, false);
          };
		  
		  if (zona3_num == 2) {
			normal_heart_rate_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
            normal_heart_rate_text_separator_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_spo2_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_spo2_text_separator_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_stress_text_text_img.setProperty(hmUI.prop.VISIBLE, true);
			normal_stress_text_separator_img.setProperty(hmUI.prop.VISIBLE, true);
          };
        }
		
		let btn_zona4 = ''
        let zona4_num = 0
        let zona4_all = 1
		
		function click_zona4() {
		  zona4_num = (zona4_num + 1) % (zona4_all + 1);
          if (zona4_num == 0) {		
		    normal_date_img_date_day.setProperty(hmUI.prop.VISIBLE, true);
            normal_date_img_date_month.setProperty(hmUI.prop.VISIBLE, true);
			normal_date_month_separator_img.setProperty(hmUI.prop.VISIBLE, true);
			normal_image_alarm.setProperty(hmUI.prop.VISIBLE, false);
            alarm_clock_img.setProperty(hmUI.prop.VISIBLE, false);
          };
		  
		 if (zona4_num == 1) {
			normal_date_img_date_day.setProperty(hmUI.prop.VISIBLE, false);
            normal_date_img_date_month.setProperty(hmUI.prop.VISIBLE, false);
			normal_date_month_separator_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_image_alarm.setProperty(hmUI.prop.VISIBLE, true);
            alarm_clock_img.setProperty(hmUI.prop.VISIBLE, true);
          };
        }


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 466,
              h: 466,
              src: 'bg_1.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
			
			normal_image_alarm = hmUI.createWidget(hmUI.widget.IMG, {
              x: 322,
              y: 252,
              src: 'alarm.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
			
			alarm_clock_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 302,
              y: 223,
              font_array: ["5.png","6.png","7.png","8.png","9.png","10.png","11.png","12.png","13.png","14.png"],
              padding: true,
              h_space: 0,
              dot_image: 'dots.png',
			  invalid_image: 's_minus.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.ALARM_CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
			
			normal_image_aqi = hmUI.createWidget(hmUI.widget.IMG, {
              x: 217,
              y: 315,
              src: 'AQI.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
			
			normal_aqi_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 208,
              y: 360,
              font_array: ["5.png","6.png","7.png","8.png","9.png","10.png","11.png","12.png","13.png","14.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.AQI,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_altimeter_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 198,
              y: 360,
              font_array: ["5.png","6.png","7.png","8.png","9.png","10.png","11.png","12.png","13.png","14.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.ALTIMETER,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_altimeter_text_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 219,
              y: 315,
              src: 'KPA.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_wind_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 216,
              y: 360,
              font_array: ["5.png","6.png","7.png","8.png","9.png","10.png","11.png","12.png","13.png","14.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WIND,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_wind_text_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 218,
              y: 315,
              src: 'wind.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 211,
              y: 314,
              image_array: ["48.png","49.png","50.png","51.png","52.png","53.png","54.png","55.png","56.png","57.png","58.png","59.png","60.png","61.png","62.png","63.png","64.png","65.png","66.png","67.png","68.png","69.png","70.png","71.png","72.png","73.png","74.png","75.png","76.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 213,
              y: 362,
              font_array: ["77.png","78.png","79.png","80.png","81.png","82.png","83.png","84.png","85.png","86.png"],
              padding: false,
              h_space: 0,
              unit_sc: '89.png',
              unit_tc: '89.png',
              unit_en: '89.png',
              negative_image: '88.png',
              invalid_image: '87.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_humidity_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 208,
              y: 360,
              font_array: ["5.png","6.png","7.png","8.png","9.png","10.png","11.png","12.png","13.png","14.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HUMIDITY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_humidity_text_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 220,
              y: 315,
              src: 'humidity.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_stress_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 52,
              y: 243,
              font_array: ["5.png","6.png","7.png","8.png","9.png","10.png","11.png","12.png","13.png","14.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STRESS,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_stress_text_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 53,
              y: 270,
              src: 'stress.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_spo2_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 55,
              y: 243,
              font_array: ["5.png","6.png","7.png","8.png","9.png","10.png","11.png","12.png","13.png","14.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.SPO2,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_spo2_text_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 53,
              y: 270,
              src: 'spO2.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 52,
              y: 243,
              font_array: ["5.png","6.png","7.png","8.png","9.png","10.png","11.png","12.png","13.png","14.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 53,
              y: 270,
              src: 'pulse.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_distance_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 8,
              y: 11,
              src: 'distance.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_distance_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 104,
              y: 145,
              font_array: ["5.png","6.png","7.png","8.png","9.png","10.png","11.png","12.png","13.png","14.png"],
              padding: false,
              h_space: 0,
              dot_image: 'dot.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.DISTANCE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
			
			normal_distance_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 81,
              y: 80,
              image_array: ["16.png","17.png","18.png","19.png","20.png","21.png","22.png","23.png","24.png","25.png"],
              image_length: 10,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_calorie_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 8,
              y: 11,
              src: 'calorie.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_calorie_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 104,
              y: 145,
              font_array: ["5.png","6.png","7.png","8.png","9.png","10.png","11.png","12.png","13.png","14.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_calorie_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 81,
              y: 80,
              image_array: ["16.png","17.png","18.png","19.png","20.png","21.png","22.png","23.png","24.png","25.png"],
              image_length: 10,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 8,
              y: 11,
              src: 'steps.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 95,
              y: 145,
              font_array: ["5.png","6.png","7.png","8.png","9.png","10.png","11.png","12.png","13.png","14.png"],
              padding: false,
              h_space: 0,
              invalid_image: '15.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 81,
              y: 80,
              image_array: ["16.png","17.png","18.png","19.png","20.png","21.png","22.png","23.png","24.png","25.png"],
              image_length: 10,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 242,
              hour_startY: 97,
              hour_array: ["27.png","28.png","29.png","30.png","31.png","32.png","33.png","34.png","35.png","36.png"],
              hour_zero: 1,
              hour_space: 6,
              hour_angle: 0,
              hour_unit_sc: '37.png',
              hour_unit_tc: '37.png',
              hour_unit_en: '37.png',
              hour_align: hmUI.align.LEFT,

              minute_startX: 320,
              minute_startY: 97,
              minute_array: ["27.png","28.png","29.png","30.png","31.png","32.png","33.png","34.png","35.png","36.png"],
              minute_zero: 1,
              minute_space: 6,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time_AmPm = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              am_x: 241,
              am_y: 150,
              am_sc_path: '38.png',
              am_en_path: '38.png',
              pm_x: 241,
              pm_y: 150,
              pm_sc_path: '39.png',
              pm_en_path: '39.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 352,
              day_startY: 223,
              day_sc_array: ["5.png","6.png","7.png","8.png","9.png","10.png","11.png","12.png","13.png","14.png"],
              day_tc_array: ["5.png","6.png","7.png","8.png","9.png","10.png","11.png","12.png","13.png","14.png"],
              day_en_array: ["5.png","6.png","7.png","8.png","9.png","10.png","11.png","12.png","13.png","14.png"],
              day_zero: 1,
              day_space: 0,
              day_align: hmUI.align.LEFT,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_month = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 310,
              month_startY: 223,
              month_sc_array: ["5.png","6.png","7.png","8.png","9.png","10.png","11.png","12.png","13.png","14.png"],
              month_tc_array: ["5.png","6.png","7.png","8.png","9.png","10.png","11.png","12.png","13.png","14.png"],
              month_en_array: ["5.png","6.png","7.png","8.png","9.png","10.png","11.png","12.png","13.png","14.png"],
              month_zero: 1,
              month_space: 0,
              month_unit_sc: '40.png',
              month_unit_tc: '40.png',
              month_unit_en: '40.png',
              month_align: hmUI.align.RIGHT,
              month_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_month_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 333,
              y: 252,
              src: 'date.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 149,
              y: 269,
              week_en: ["41.png","42.png","43.png","44.png","45.png","46.png","47.png"],
              week_tc: ["41.png","42.png","43.png","44.png","45.png","46.png","47.png"],
              week_sc: ["41.png","42.png","43.png","44.png","45.png","46.png","47.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_hour = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              hour_path: 'mask_1.png',
              hour_centerX: 233,
              hour_centerY: 233,
              hour_posX: 35,
              hour_posY: 173,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_minute = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              minute_path: '91.png',
              minute_centerX: 233,
              minute_centerY: 233,
              minute_posX: 32,
              minute_posY: 204,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_second = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              second_path: '92.png',
              second_centerX: 233,
              second_centerY: 233,
              second_posX: 22,
              second_posY: 225,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 222,
              y: 222,
              src: 'bluetooth_(10).png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });



            idle_analog_clock_time_pointer_hour = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              hour_path: '93.png',
              hour_centerX: 233,
              hour_centerY: 233,
              hour_posX: 35,
              hour_posY: 173,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_analog_clock_time_pointer_minute = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              minute_path: '94.png',
              minute_centerX: 233,
              minute_centerY: 233,
              minute_posX: 32,
              minute_posY: 204,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 222,
              y: 222,
              src: 'bluetooth_(10).png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            btn_zona2 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 185,
              y: 300,
              text: '',
              w: 100,
              h: 100,
              normal_src: 'Empty.png',
              press_src: 'Empty.png',
              click_func: () => {
				click_zona2();
                click_Vibrate();
              },
			  longpress_func: () => {
             hmApp.startApp({ url: "WeatherScreen", native: true });
             },
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            btn_zona2.setProperty(hmUI.prop.VISIBLE, true);
			normal_humidity_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_humidity_text_separator_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_wind_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_wind_text_separator_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_altimeter_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_altimeter_text_separator_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_image_aqi.setProperty(hmUI.prop.VISIBLE, false);
			normal_aqi_current_text_img.setProperty(hmUI.prop.VISIBLE, false);

            btn_zona4 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 300,
              y: 215,
              text: '',
              w: 100,
              h: 55,
              normal_src: 'Empty.png',
              press_src: 'Empty.png',
              click_func: () => {
				click_zona4();
                click_Vibrate();
             },
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            btn_zona4.setProperty(hmUI.prop.VISIBLE, true);
			normal_image_alarm.setProperty(hmUI.prop.VISIBLE, false);
            alarm_clock_img.setProperty(hmUI.prop.VISIBLE, false);

            btn_zona3 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 45,
              y: 243,
              text: '',
              w: 80,
              h: 50,
              normal_src: 'Empty.png',
              press_src: 'Empty.png',
              click_func: () => {
				click_zona3();
                click_Vibrate();
              },
			  longpress_func: () => {
             hmApp.startApp({ url: "heart_app_Screen", native: true });
             },
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            btn_zona3.setProperty(hmUI.prop.VISIBLE, true);
			normal_spo2_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_spo2_text_separator_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_stress_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_stress_text_separator_img.setProperty(hmUI.prop.VISIBLE, false);

            btn_zona1 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 90,
              y: 90,
              text: '',
              w: 100,
              h: 100,
              normal_src: 'Empty.png',
              press_src: 'Empty.png',
              click_func: () => {
				click_zona1();
                click_Vibrate();
              },
			  longpress_func: () => {
             hmApp.startApp({ url: "activityAppScreen", native: true });
             },
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            btn_zona1.setProperty(hmUI.prop.VISIBLE, true);
            normal_calorie_icon_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_calorie_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_calorie_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, false);
			normal_distance_icon_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_distance_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_distance_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, false);
			
			btn_bezel = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 201,
              y: 201,
              text: '',
              w: 70,
              h: 70,
              normal_src: 'Empty.png',
              press_src: 'Empty.png',
              click_func: () => {
                  click_Bezel();
              },
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            btn_bezel.setProperty(hmUI.prop.VISIBLE, true);

                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}