﻿    /*
    ** Watch_Face_Editor tool v 18.1
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        //const logger = Logger.getLogger('watchface_SashaCX75');
        const logger = DeviceRuntimeCore.HmLogger.getLogger('watchface_SashaCX75')
        //end of ignored block

        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_moon_icon_img = ''
        let normal_moon_image_progress_img_level = ''
        let normal_system_disconnect_img = ''
        let normal_distance_current_text_font = ''
        let normal_step_TextRotate = new Array(5);
        let normal_step_TextRotate_ASCIIARRAY = new Array(10);
        let normal_step_TextRotate_img_width = 19;
        let normal_sun_icon_img = ''
        let normal_sun_high_text_font = ''
        let normal_sun_low_text_font = ''
        let normal_weather_image_progress_img_level = ''
        let normal_temperature_high_text_font = ''
        let normal_temperature_low_text_font = ''
        let normal_temperature_current_text_font = ''
        let normal_city_name_text = ''
        let normal_altitude_target_text_font = ''
        let normal_heart_rate_text_font = ''
        let normal_dow_text_font = ''
        let normal_DOW_Array = ['MONDAY', 'TUESDAY', 'WEDNESDAY', 'THURSDAY', 'FRIDAY', 'SATURDAY', 'SUNDAY'];
        let normal_date_img_date_year = ''
        let normal_date_img_date_month = ''
        let normal_date_img_date_day = ''
        let normal_battery_current_text_font = ''
        let normal_battery_image_progress_img_level = ''
        let normal_digital_clock_img_time = ''
        let normal_analog_clock_pro_second_pointer_img = ''
        let normal_timerUpdateSec = undefined;
        let idle_dow_text_font = ''
        let idle_DOW_Array = ['MON', 'TUE', 'WED', 'THU', 'FRI', 'SAT', 'SUN'];
        let idle_date_img_date_year = ''
        let idle_date_img_date_month = ''
        let idle_date_img_date_day = ''
        let idle_battery_current_text_font = ''
        let idle_battery_image_progress_img_level = ''
        let idle_digital_clock_img_time = ''
        let Button_1 = ''
        let Button_2 = ''
        let Button_3 = ''
        let Button_4 = ''
        let Button_5 = ''
        let Button_6 = ''
        let Button_7 = ''
        let timeSensor = '';


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            // FontName: 02.ttf; FontSize: 33; Cache: full
            hmUI.createWidget(hmUI.widget.TEXT, {
              x: 464,
              y: 464,
              w: 39,
              h: 39,
              text_size: 33,
              char_space: 0,
              line_space: 0,
              font: 'fonts/02.ttf',
              color: 0xFF00FFFF,
              align_h: hmUI.align.LEFT,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.NONE,
              text: "0123456789 ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz АБВГДЕЁЖЗИЙКЛМНОПРСТУФХЦЧШЩЪЫЬЭЮЯабвгдеёжзийклмнопрстуфхцчшщъыьэюя  ҐЄІЇґєії _+-.,:;`'%°\\/",
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // FontName: 01.ttf; FontSize: 32
            hmUI.createWidget(hmUI.widget.TEXT, {
              x: 464,
              y: 464,
              w: 366,
              h: 45,
              text_size: 32,
              char_space: -1,
              line_space: 0,
              font: 'fonts/01.ttf',
              color: 0xFFFFFFFF,
              align_h: hmUI.align.RIGHT,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              text: "0123456789 _+-.,:;`'%°\\/",
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // FontName: 03.ttf; FontSize: 25
            hmUI.createWidget(hmUI.widget.TEXT, {
              x: 464,
              y: 464,
              w: 339,
              h: 36,
              text_size: 25,
              char_space: 0,
              line_space: 0,
              font: 'fonts/03.ttf',
              color: 0xFF3AEFC5,
              align_h: hmUI.align.LEFT,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              text: "0123456789 _+-.,:;`'%°\\/",
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // FontName: 01.ttf; FontSize: 30
            hmUI.createWidget(hmUI.widget.TEXT, {
              x: 464,
              y: 464,
              w: 344,
              h: 44,
              text_size: 30,
              char_space: -1,
              line_space: 0,
              font: 'fonts/01.ttf',
              color: 0xFFFFFFFF,
              align_h: hmUI.align.LEFT,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              text: "0123456789 _+-.,:;`'%°\\/",
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // FontName: 01.ttf; FontSize: 38; Cache: full
            hmUI.createWidget(hmUI.widget.TEXT, {
              x: 464,
              y: 464,
              w: 45,
              h: 45,
              text_size: 38,
              char_space: 0,
              line_space: 1,
              font: 'fonts/01.ttf',
              color: 0xFFFF8C00,
              align_h: hmUI.align.LEFT,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.NONE,
              text: "0123456789 ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz АБВГДЕЁЖЗИЙКЛМНОПРСТУФХЦЧШЩЪЫЬЭЮЯабвгдеёжзийклмнопрстуфхцчшщъыьэюя  ҐЄІЇґєії _+-.,:;`'%°\\/",
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            console.log('Watch_Face.ScreenNormal');
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 466,
              h: 466,
              src: 'WF---Garmin-Instinct-3-BGV-2.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_moon_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 430,
              y: 187,
              src: 'System_BT_On.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_moon_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 115,
              y: 44,
              image_array: ["Moon_01.png","Moon_02.png","Moon_03.png","Moon_04.png","Moon_05.png","Moon_06.png","Moon_07.png","Moon_08.png","Moon_09.png","Moon_10.png","Moon_11.png","Moon_12.png","Moon_13.png","Moon_14.png","Moon_15.png","Moon_16.png","Moon_17.png","Moon_18.png","Moon_19.png","Moon_20.png","Moon_21.png","Moon_22.png","Moon_23.png","Moon_24.png","Moon_25.png","Moon_26.png","Moon_27.png","Moon_28.png","Moon_29.png","Moon_30.png"],
              image_length: 30,
              type: hmUI.data_type.MOON,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 431,
              y: 187,
              src: 'System_BT_OFF.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_distance_current_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 307,
              y: 305,
              w: 150,
              h: 35,
              text_size: 33,
              char_space: 0,
              font: 'fonts/02.ttf',
              color: 0xFF00FFFF,
              line_space: 0,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.LEFT,
              unit_type: 1,
              type: hmUI.data_type.DISTANCE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_step_text_rotate_img = hmUI.createWidget(hmUI.widget.Text_Rotate, {
              // x: 23,
              // y: 260,
              // font_array: ["WF---Garmin-Instinct-3-STEP-00.png","WF---Garmin-Instinct-3-STEP-01.png","WF---Garmin-Instinct-3-STEP-02.png","WF---Garmin-Instinct-3-STEP-03.png","WF---Garmin-Instinct-3-STEP-04.png","WF---Garmin-Instinct-3-STEP-05.png","WF---Garmin-Instinct-3-STEP-06.png","WF---Garmin-Instinct-3-STEP-07.png","WF---Garmin-Instinct-3-STEP-08.png","WF---Garmin-Instinct-3-STEP-09.png"],
              // zero: false,
              // unit_in_alignment: false,
              // h_space: 2,
              // angle: -90,
              // align_h: hmUI.align.LEFT,
              // type: hmUI.data_type.STEP,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_step_TextRotate_ASCIIARRAY[0] = 'WF---Garmin-Instinct-3-STEP-00.png';  // set of images with numbers
            normal_step_TextRotate_ASCIIARRAY[1] = 'WF---Garmin-Instinct-3-STEP-01.png';  // set of images with numbers
            normal_step_TextRotate_ASCIIARRAY[2] = 'WF---Garmin-Instinct-3-STEP-02.png';  // set of images with numbers
            normal_step_TextRotate_ASCIIARRAY[3] = 'WF---Garmin-Instinct-3-STEP-03.png';  // set of images with numbers
            normal_step_TextRotate_ASCIIARRAY[4] = 'WF---Garmin-Instinct-3-STEP-04.png';  // set of images with numbers
            normal_step_TextRotate_ASCIIARRAY[5] = 'WF---Garmin-Instinct-3-STEP-05.png';  // set of images with numbers
            normal_step_TextRotate_ASCIIARRAY[6] = 'WF---Garmin-Instinct-3-STEP-06.png';  // set of images with numbers
            normal_step_TextRotate_ASCIIARRAY[7] = 'WF---Garmin-Instinct-3-STEP-07.png';  // set of images with numbers
            normal_step_TextRotate_ASCIIARRAY[8] = 'WF---Garmin-Instinct-3-STEP-08.png';  // set of images with numbers
            normal_step_TextRotate_ASCIIARRAY[9] = 'WF---Garmin-Instinct-3-STEP-09.png';  // set of images with numbers

            //#region TextRotate
            for (let i = 0; i < 5; i++) {
              normal_step_TextRotate[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 466,
                h: 466,
                center_x: 23,
                center_y: 260,
                pos_x: 23,
                pos_y: 260,
                angle: -90,
                src: 'WF---Garmin-Instinct-3-STEP-00.png',
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
              normal_step_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
            };
            //#endregion
            
            const step = hmSensor.createSensor(hmSensor.id.STEP);
            step.addEventListener(hmSensor.event.CHANGE, function() {
              text_update();
            });

            normal_sun_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 205,
              y: 401,
              src: 'WF---Garmin-Instinct-3-SUNRISE-00.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sun_high_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 58,
              y: 400,
              w: 146,
              h: 30,
              text_size: 32,
              char_space: -1,
              font: 'fonts/01.ttf',
              color: 0xFFFFFFFF,
              line_space: 0,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.SUN_RISE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sun_low_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 265,
              y: 400,
              w: 146,
              h: 30,
              text_size: 32,
              char_space: -1,
              font: 'fonts/01.ttf',
              color: 0xFFFFFFFF,
              line_space: 0,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.SUN_SET,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 352,
              y: 112,
              image_array: ["0045.png","0046.png","0047.png","0048.png","0049.png","0050.png","0051.png","0052.png","0053.png","0054.png","0055.png","0056.png","0057.png","0058.png","0059.png","0060.png","0061.png","0062.png","0063.png","0064.png","0065.png","0066.png","0067.png","0068.png","0069.png","0070.png","0071.png","0072.png","0073.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_high_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 257,
              y: 171,
              w: 146,
              h: 24,
              text_size: 25,
              char_space: 0,
              font: 'fonts/03.ttf',
              color: 0xFF3AEFC5,
              line_space: 0,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.LEFT,
              unit_type: 1,
              type: hmUI.data_type.WEATHER_HIGH,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_low_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 257,
              y: 138,
              w: 146,
              h: 24,
              text_size: 25,
              char_space: 0,
              font: 'fonts/03.ttf',
              color: 0xFFFFFFFF,
              line_space: 0,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.LEFT,
              unit_type: 1,
              type: hmUI.data_type.WEATHER_LOW,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 356,
              y: 160,
              w: 146,
              h: 36,
              text_size: 30,
              char_space: -1,
              font: 'fonts/01.ttf',
              color: 0xFFFFFFFF,
              line_space: 0,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.LEFT,
              unit_type: 1,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
              const weatherSensor = hmSensor.createSensor(hmSensor.id.WEATHER);

            normal_city_name_text = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 171,
              y: 84,
              w: 150,
              h: 30,
              text_size: 16,
              char_space: 2,
              color: 0xFFFF8C00,
              line_space: 0,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.RIGHT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_altitude_target_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 307,
              y: 230,
              w: 146,
              h: 31,
              text_size: 33,
              char_space: 0,
              font: 'fonts/02.ttf',
              color: 0xFFFFFFFF,
              line_space: 0,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.ALTITUDE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 307,
              y: 267,
              w: 146,
              h: 31,
              text_size: 33,
              char_space: 0,
              font: 'fonts/02.ttf',
              color: 0xFFFFFFFF,
              line_space: 0,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            if (!timeSensor) timeSensor = hmSensor.createSensor(hmSensor.id.TIME);
            timeSensor.addEventListener(timeSensor.event.DAYCHANGE, function() {
              time_update(true);
            });

            normal_dow_text_font = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 159,
              y: 40,
              w: 148,
              h: 47,
              text_size: 30,
              char_space: 0,
              color: 0xFFFF8C00,
              line_space: 0,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.CENTER_H,
              // unit_string: MONDAY, TUESDAY, WEDNESDAY, THURSDAY, FRIDAY,  SATURDAY, SUNDAY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_year = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              year_startX: 249,
              year_startY: 21,
              year_sc_array: ["WF---Garmin-Instinct-3-DAY-00.png","WF---Garmin-Instinct-3-DAY-01.png","WF---Garmin-Instinct-3-DAY-02.png","WF---Garmin-Instinct-3-DAY-03.png","WF---Garmin-Instinct-3-DAY-04.png","WF---Garmin-Instinct-3-DAY-05.png","WF---Garmin-Instinct-3-DAY-06.png","WF---Garmin-Instinct-3-DAY-07.png","WF---Garmin-Instinct-3-DAY-08.png","WF---Garmin-Instinct-3-DAY-09.png"],
              year_tc_array: ["WF---Garmin-Instinct-3-DAY-00.png","WF---Garmin-Instinct-3-DAY-01.png","WF---Garmin-Instinct-3-DAY-02.png","WF---Garmin-Instinct-3-DAY-03.png","WF---Garmin-Instinct-3-DAY-04.png","WF---Garmin-Instinct-3-DAY-05.png","WF---Garmin-Instinct-3-DAY-06.png","WF---Garmin-Instinct-3-DAY-07.png","WF---Garmin-Instinct-3-DAY-08.png","WF---Garmin-Instinct-3-DAY-09.png"],
              year_en_array: ["WF---Garmin-Instinct-3-DAY-00.png","WF---Garmin-Instinct-3-DAY-01.png","WF---Garmin-Instinct-3-DAY-02.png","WF---Garmin-Instinct-3-DAY-03.png","WF---Garmin-Instinct-3-DAY-04.png","WF---Garmin-Instinct-3-DAY-05.png","WF---Garmin-Instinct-3-DAY-06.png","WF---Garmin-Instinct-3-DAY-07.png","WF---Garmin-Instinct-3-DAY-08.png","WF---Garmin-Instinct-3-DAY-09.png"],
              year_zero: 1,
              year_space: 0,
              year_align: hmUI.align.LEFT,
              year_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_month = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 207,
              month_startY: 21,
              month_sc_array: ["WF---Garmin-Instinct-3-DAY-00.png","WF---Garmin-Instinct-3-DAY-01.png","WF---Garmin-Instinct-3-DAY-02.png","WF---Garmin-Instinct-3-DAY-03.png","WF---Garmin-Instinct-3-DAY-04.png","WF---Garmin-Instinct-3-DAY-05.png","WF---Garmin-Instinct-3-DAY-06.png","WF---Garmin-Instinct-3-DAY-07.png","WF---Garmin-Instinct-3-DAY-08.png","WF---Garmin-Instinct-3-DAY-09.png"],
              month_tc_array: ["WF---Garmin-Instinct-3-DAY-00.png","WF---Garmin-Instinct-3-DAY-01.png","WF---Garmin-Instinct-3-DAY-02.png","WF---Garmin-Instinct-3-DAY-03.png","WF---Garmin-Instinct-3-DAY-04.png","WF---Garmin-Instinct-3-DAY-05.png","WF---Garmin-Instinct-3-DAY-06.png","WF---Garmin-Instinct-3-DAY-07.png","WF---Garmin-Instinct-3-DAY-08.png","WF---Garmin-Instinct-3-DAY-09.png"],
              month_en_array: ["WF---Garmin-Instinct-3-DAY-00.png","WF---Garmin-Instinct-3-DAY-01.png","WF---Garmin-Instinct-3-DAY-02.png","WF---Garmin-Instinct-3-DAY-03.png","WF---Garmin-Instinct-3-DAY-04.png","WF---Garmin-Instinct-3-DAY-05.png","WF---Garmin-Instinct-3-DAY-06.png","WF---Garmin-Instinct-3-DAY-07.png","WF---Garmin-Instinct-3-DAY-08.png","WF---Garmin-Instinct-3-DAY-09.png"],
              month_zero: 1,
              month_space: 0,
              month_unit_sc: '041.png',
              month_unit_tc: '041.png',
              month_unit_en: '041.png',
              month_align: hmUI.align.LEFT,
              month_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 169,
              day_startY: 21,
              day_sc_array: ["WF---Garmin-Instinct-3-DAY-00.png","WF---Garmin-Instinct-3-DAY-01.png","WF---Garmin-Instinct-3-DAY-02.png","WF---Garmin-Instinct-3-DAY-03.png","WF---Garmin-Instinct-3-DAY-04.png","WF---Garmin-Instinct-3-DAY-05.png","WF---Garmin-Instinct-3-DAY-06.png","WF---Garmin-Instinct-3-DAY-07.png","WF---Garmin-Instinct-3-DAY-08.png","WF---Garmin-Instinct-3-DAY-09.png"],
              day_tc_array: ["WF---Garmin-Instinct-3-DAY-00.png","WF---Garmin-Instinct-3-DAY-01.png","WF---Garmin-Instinct-3-DAY-02.png","WF---Garmin-Instinct-3-DAY-03.png","WF---Garmin-Instinct-3-DAY-04.png","WF---Garmin-Instinct-3-DAY-05.png","WF---Garmin-Instinct-3-DAY-06.png","WF---Garmin-Instinct-3-DAY-07.png","WF---Garmin-Instinct-3-DAY-08.png","WF---Garmin-Instinct-3-DAY-09.png"],
              day_en_array: ["WF---Garmin-Instinct-3-DAY-00.png","WF---Garmin-Instinct-3-DAY-01.png","WF---Garmin-Instinct-3-DAY-02.png","WF---Garmin-Instinct-3-DAY-03.png","WF---Garmin-Instinct-3-DAY-04.png","WF---Garmin-Instinct-3-DAY-05.png","WF---Garmin-Instinct-3-DAY-06.png","WF---Garmin-Instinct-3-DAY-07.png","WF---Garmin-Instinct-3-DAY-08.png","WF---Garmin-Instinct-3-DAY-09.png"],
              day_zero: 1,
              day_space: 0,
              day_unit_sc: '041.png',
              day_unit_tc: '041.png',
              day_unit_en: '041.png',
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_current_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 307,
              y: 345,
              w: 146,
              h: 31,
              text_size: 33,
              char_space: 0,
              font: 'fonts/02.ttf',
              color: 0xFFFFFFFF,
              line_space: 0,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.LEFT,
              unit_type: 1,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 254,
              y: 354,
              image_array: ["WF---Garmin-Instinct-3-BAT-00.png","WF---Garmin-Instinct-3-BAT-10.png","WF---Garmin-Instinct-3-BAT-20.png","WF---Garmin-Instinct-3-BAT-30.png","WF---Garmin-Instinct-3-BAT-40.png","WF---Garmin-Instinct-3-BAT-50.png","WF---Garmin-Instinct-3-BAT-60.png","WF---Garmin-Instinct-3-BAT-70.png","WF---Garmin-Instinct-3-BAT-80.png","WF---Garmin-Instinct-3-BAT-90.png"],
              image_length: 10,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 77,
              hour_startY: 136,
              hour_array: ["WF---Garmin-Instinct-3-HORA-00.png","WF---Garmin-Instinct-3-HORA-01.png","WF---Garmin-Instinct-3-HORA-02.png","WF---Garmin-Instinct-3-HORA-03.png","WF---Garmin-Instinct-3-HORA-04.png","WF---Garmin-Instinct-3-HORA-05.png","WF---Garmin-Instinct-3-HORA-06.png","WF---Garmin-Instinct-3-HORA-07.png","WF---Garmin-Instinct-3-HORA-08.png","WF---Garmin-Instinct-3-HORA-09.png"],
              hour_zero: 1,
              hour_space: 12,
              hour_angle: 0,
              alpha: 222,
              hour_align: hmUI.align.CENTER_H,

              minute_startX: 77,
              minute_startY: 237,
              minute_array: ["WF---Garmin-Instinct-3-HORA-00.png","WF---Garmin-Instinct-3-HORA-01.png","WF---Garmin-Instinct-3-HORA-02.png","WF---Garmin-Instinct-3-HORA-03.png","WF---Garmin-Instinct-3-HORA-04.png","WF---Garmin-Instinct-3-HORA-05.png","WF---Garmin-Instinct-3-HORA-06.png","WF---Garmin-Instinct-3-HORA-07.png","WF---Garmin-Instinct-3-HORA-08.png","WF---Garmin-Instinct-3-HORA-09.png"],
              minute_zero: 1,
              minute_space: 12,
              minute_angle: 0,
              minute_follow: 0,
              // alpha: 222,
              minute_align: hmUI.align.CENTER_H,

              second_startX: 144,
              second_startY: 338,
              second_array: ["WF---Garmin-Instinct-3-SEG-00.png","WF---Garmin-Instinct-3-SEG-01.png","WF---Garmin-Instinct-3-SEG-02.png","WF---Garmin-Instinct-3-SEG-03.png","WF---Garmin-Instinct-3-SEG-04.png","WF---Garmin-Instinct-3-SEG-05.png","WF---Garmin-Instinct-3-SEG-06.png","WF---Garmin-Instinct-3-SEG-07.png","WF---Garmin-Instinct-3-SEG-08.png","WF---Garmin-Instinct-3-SEG-09.png"],
              second_zero: 1,
              second_space: 4,
              second_angle: 0,
              second_follow: 0,
              // alpha: 222,
              second_align: hmUI.align.CENTER_H,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            const deviceInfo = hmSetting.getDeviceInfo();
            // normal_analog_clock_pro_second_pointer_img = hmUI.createWidget(hmUI.widget.TIME_POINTER_PRO, {
              // src: 'aaaaa.png',
              // center_x: 233,
              // center_y: 233,
              // x: 233,
              // y: 233,
              // start_angle: 0,
              // end_angle: 360,
              // type: hmUI.data_type.second,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });


            normal_analog_clock_pro_second_pointer_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: deviceInfo.width,
              h: deviceInfo.height,
              pos_x: 233 - 233,
              pos_y: 233 - 233,
              center_x: 233,
              center_y: 233,
              src: 'aaaaa.png',
              angle: 0,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            let screenType = hmSetting.getScreenType();

            console.log('Watch_Face.ScreenAOD');

            idle_dow_text_font = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 179,
              y: 45,
              w: 154,
              h: 40,
              text_size: 38,
              char_space: 0,
              font: 'fonts/01.ttf',
              alpha: 100,
              color: 0xFFFF8C00,
              line_space: 1,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.LEFT,
              // unit_string: MON, TUE, WED, THU, FRI, SAT, SUN,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_year = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              year_startX: 249,
              year_startY: 21,
              year_sc_array: ["WF---Garmin-Instinct-3-DAY-00.png","WF---Garmin-Instinct-3-DAY-01.png","WF---Garmin-Instinct-3-DAY-02.png","WF---Garmin-Instinct-3-DAY-03.png","WF---Garmin-Instinct-3-DAY-04.png","WF---Garmin-Instinct-3-DAY-05.png","WF---Garmin-Instinct-3-DAY-06.png","WF---Garmin-Instinct-3-DAY-07.png","WF---Garmin-Instinct-3-DAY-08.png","WF---Garmin-Instinct-3-DAY-09.png"],
              year_tc_array: ["WF---Garmin-Instinct-3-DAY-00.png","WF---Garmin-Instinct-3-DAY-01.png","WF---Garmin-Instinct-3-DAY-02.png","WF---Garmin-Instinct-3-DAY-03.png","WF---Garmin-Instinct-3-DAY-04.png","WF---Garmin-Instinct-3-DAY-05.png","WF---Garmin-Instinct-3-DAY-06.png","WF---Garmin-Instinct-3-DAY-07.png","WF---Garmin-Instinct-3-DAY-08.png","WF---Garmin-Instinct-3-DAY-09.png"],
              year_en_array: ["WF---Garmin-Instinct-3-DAY-00.png","WF---Garmin-Instinct-3-DAY-01.png","WF---Garmin-Instinct-3-DAY-02.png","WF---Garmin-Instinct-3-DAY-03.png","WF---Garmin-Instinct-3-DAY-04.png","WF---Garmin-Instinct-3-DAY-05.png","WF---Garmin-Instinct-3-DAY-06.png","WF---Garmin-Instinct-3-DAY-07.png","WF---Garmin-Instinct-3-DAY-08.png","WF---Garmin-Instinct-3-DAY-09.png"],
              year_zero: 1,
              year_space: 0,
              year_align: hmUI.align.LEFT,
              year_is_character: false,
              // alpha: 120,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_year.setAlpha(120);

            idle_date_img_date_month = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 207,
              month_startY: 21,
              month_sc_array: ["WF---Garmin-Instinct-3-DAY-00.png","WF---Garmin-Instinct-3-DAY-01.png","WF---Garmin-Instinct-3-DAY-02.png","WF---Garmin-Instinct-3-DAY-03.png","WF---Garmin-Instinct-3-DAY-04.png","WF---Garmin-Instinct-3-DAY-05.png","WF---Garmin-Instinct-3-DAY-06.png","WF---Garmin-Instinct-3-DAY-07.png","WF---Garmin-Instinct-3-DAY-08.png","WF---Garmin-Instinct-3-DAY-09.png"],
              month_tc_array: ["WF---Garmin-Instinct-3-DAY-00.png","WF---Garmin-Instinct-3-DAY-01.png","WF---Garmin-Instinct-3-DAY-02.png","WF---Garmin-Instinct-3-DAY-03.png","WF---Garmin-Instinct-3-DAY-04.png","WF---Garmin-Instinct-3-DAY-05.png","WF---Garmin-Instinct-3-DAY-06.png","WF---Garmin-Instinct-3-DAY-07.png","WF---Garmin-Instinct-3-DAY-08.png","WF---Garmin-Instinct-3-DAY-09.png"],
              month_en_array: ["WF---Garmin-Instinct-3-DAY-00.png","WF---Garmin-Instinct-3-DAY-01.png","WF---Garmin-Instinct-3-DAY-02.png","WF---Garmin-Instinct-3-DAY-03.png","WF---Garmin-Instinct-3-DAY-04.png","WF---Garmin-Instinct-3-DAY-05.png","WF---Garmin-Instinct-3-DAY-06.png","WF---Garmin-Instinct-3-DAY-07.png","WF---Garmin-Instinct-3-DAY-08.png","WF---Garmin-Instinct-3-DAY-09.png"],
              month_zero: 1,
              month_space: 0,
              month_unit_sc: '041.png',
              month_unit_tc: '041.png',
              month_unit_en: '041.png',
              month_align: hmUI.align.LEFT,
              month_is_character: false,
              // alpha: 120,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_month.setAlpha(120);

            idle_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 169,
              day_startY: 21,
              day_sc_array: ["WF---Garmin-Instinct-3-DAY-00.png","WF---Garmin-Instinct-3-DAY-01.png","WF---Garmin-Instinct-3-DAY-02.png","WF---Garmin-Instinct-3-DAY-03.png","WF---Garmin-Instinct-3-DAY-04.png","WF---Garmin-Instinct-3-DAY-05.png","WF---Garmin-Instinct-3-DAY-06.png","WF---Garmin-Instinct-3-DAY-07.png","WF---Garmin-Instinct-3-DAY-08.png","WF---Garmin-Instinct-3-DAY-09.png"],
              day_tc_array: ["WF---Garmin-Instinct-3-DAY-00.png","WF---Garmin-Instinct-3-DAY-01.png","WF---Garmin-Instinct-3-DAY-02.png","WF---Garmin-Instinct-3-DAY-03.png","WF---Garmin-Instinct-3-DAY-04.png","WF---Garmin-Instinct-3-DAY-05.png","WF---Garmin-Instinct-3-DAY-06.png","WF---Garmin-Instinct-3-DAY-07.png","WF---Garmin-Instinct-3-DAY-08.png","WF---Garmin-Instinct-3-DAY-09.png"],
              day_en_array: ["WF---Garmin-Instinct-3-DAY-00.png","WF---Garmin-Instinct-3-DAY-01.png","WF---Garmin-Instinct-3-DAY-02.png","WF---Garmin-Instinct-3-DAY-03.png","WF---Garmin-Instinct-3-DAY-04.png","WF---Garmin-Instinct-3-DAY-05.png","WF---Garmin-Instinct-3-DAY-06.png","WF---Garmin-Instinct-3-DAY-07.png","WF---Garmin-Instinct-3-DAY-08.png","WF---Garmin-Instinct-3-DAY-09.png"],
              day_zero: 1,
              day_space: 0,
              day_unit_sc: '041.png',
              day_unit_tc: '041.png',
              day_unit_en: '041.png',
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              // alpha: 120,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_day.setAlpha(120);

            idle_battery_current_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 307,
              y: 345,
              w: 146,
              h: 31,
              text_size: 33,
              char_space: 0,
              font: 'fonts/02.ttf',
              alpha: 100,
              color: 0xFFFFFFFF,
              line_space: 0,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.LEFT,
              unit_type: 1,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_battery_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 254,
              y: 354,
              image_array: ["WF---Garmin-Instinct-3-BAT-00.png","WF---Garmin-Instinct-3-BAT-10.png","WF---Garmin-Instinct-3-BAT-20.png","WF---Garmin-Instinct-3-BAT-30.png","WF---Garmin-Instinct-3-BAT-40.png","WF---Garmin-Instinct-3-BAT-50.png","WF---Garmin-Instinct-3-BAT-60.png","WF---Garmin-Instinct-3-BAT-70.png","WF---Garmin-Instinct-3-BAT-80.png","WF---Garmin-Instinct-3-BAT-90.png"],
              image_length: 10,
              // alpha: 100,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_battery_image_progress_img_level.setAlpha(100);

            idle_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 77,
              hour_startY: 136,
              hour_array: ["WF---Garmin-Instinct-3-HORA-00.png","WF---Garmin-Instinct-3-HORA-01.png","WF---Garmin-Instinct-3-HORA-02.png","WF---Garmin-Instinct-3-HORA-03.png","WF---Garmin-Instinct-3-HORA-04.png","WF---Garmin-Instinct-3-HORA-05.png","WF---Garmin-Instinct-3-HORA-06.png","WF---Garmin-Instinct-3-HORA-07.png","WF---Garmin-Instinct-3-HORA-08.png","WF---Garmin-Instinct-3-HORA-09.png"],
              hour_zero: 1,
              hour_space: 12,
              hour_angle: 0,
              alpha: 120,
              hour_align: hmUI.align.CENTER_H,

              minute_startX: 77,
              minute_startY: 237,
              minute_array: ["WF---Garmin-Instinct-3-HORA-00.png","WF---Garmin-Instinct-3-HORA-01.png","WF---Garmin-Instinct-3-HORA-02.png","WF---Garmin-Instinct-3-HORA-03.png","WF---Garmin-Instinct-3-HORA-04.png","WF---Garmin-Instinct-3-HORA-05.png","WF---Garmin-Instinct-3-HORA-06.png","WF---Garmin-Instinct-3-HORA-07.png","WF---Garmin-Instinct-3-HORA-08.png","WF---Garmin-Instinct-3-HORA-09.png"],
              minute_zero: 1,
              minute_space: 12,
              minute_angle: 0,
              minute_follow: 0,
              // alpha: 120,
              minute_align: hmUI.align.CENTER_H,

              show_level: hmUI.show_level.ONLY_AOD,
            });
            
            // disconnectAlert = hmUI.createWidget(hmUI.widget.DisconnectAlert, {
              // disconneсnt_vibrate_type: 9,
              // disconneсnt_toast_text: KD seu CEL?,
              // conneсnt_vibrate_type: 25,
              // conneсnt_toast_text: TD OK!,
            // });

            // vibration when connecting or disconnecting

            function checkConnection() {
              console.log('checkConnection()');
              hmBle.removeListener;
              hmBle.addListener(function (status) {
                if(!status) {
                  hmUI.showToast({text: "KD seu CEL?"});
                  vibro(9);
                }
                if(status) {
                  hmUI.showToast({text: "TD OK!"});
                  vibro(25);
                }
              });
            }

            // end vibration when connecting or disconnecting
            //#region vibrate function

            const vibrate = hmSensor.createSensor(hmSensor.id.VIBRATE);
            let timer_StopVibrate = null;


            function vibro(scene = 25) {
              let stopDelay = 50;
              stopVibro();
              vibrate.stop();
              vibrate.scene = scene;
              if(scene < 23 || scene > 25) stopDelay = 1300;
              vibrate.start();
              if (scene != 1) timer_StopVibrate = timer.createTimer(stopDelay, 3000, stopVibro, {});
            }

            function stopVibro(){
              vibrate.stop();
              if(timer_StopVibrate) timer.stopTimer(timer_StopVibrate);
            }

            //#endregion

            console.log('Watch_Face.Buttons');
            Button_1 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 184,
              y: -14,
              w: 97,
              h: 97,
              text: '',
              color: 0xFFFF8C00,
              text_size: 24,
              press_src: 'WF_-_Garmin_Instinct-BUTTONS.png',
              normal_src: 'WF_-_Garmin_Instinct-BUTTONS.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'ScheduleCalScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_2 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 236,
              y: 122,
              w: 176,
              h: 80,
              text: '',
              color: 0xFFFF8C00,
              text_size: 24,
              press_src: 'WF_-_Garmin_Instinct-BUTTONS.png',
              normal_src: 'WF_-_Garmin_Instinct-BUTTONS.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'WeatherScreen', native: true });
              }, // end func
              longpress_func: (button_widget) => {
                hmApp.startApp({ appid: 1051195, url: 'page/index', params: { from_wf: true} });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_3 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 236,
              y: 217,
              w: 127,
              h: 44,
              text: '',
              color: 0xFFFF8C00,
              text_size: 24,
              press_src: 'WF_-_Garmin_Instinct-BUTTONS.png',
              normal_src: 'WF_-_Garmin_Instinct-BUTTONS.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'BaroAltimeterScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_4 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 236,
              y: 264,
              w: 127,
              h: 44,
              text: '',
              color: 0xFFFF8C00,
              text_size: 24,
              press_src: 'WF_-_Garmin_Instinct-BUTTONS.png',
              normal_src: 'WF_-_Garmin_Instinct-BUTTONS.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'heart_app_Screen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_5 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 236,
              y: 340,
              w: 127,
              h: 44,
              text: '',
              color: 0xFFFF8C00,
              text_size: 24,
              press_src: 'WF_-_Garmin_Instinct-BUTTONS.png',
              normal_src: 'WF_-_Garmin_Instinct-BUTTONS.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'PowerSaveHintScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_6 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 142,
              y: 397,
              w: 181,
              h: 44,
              text: '',
              color: 0xFFFF8C00,
              text_size: 24,
              press_src: 'WF_-_Garmin_Instinct-BUTTONS.png',
              normal_src: 'WF_-_Garmin_Instinct-BUTTONS.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'TideScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_7 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 10,
              y: 155,
              w: 49,
              h: 150,
              text: '',
              color: 0xFFFF8C00,
              text_size: 24,
              press_src: 'WF_-_Garmin_Instinct-BUTTONS.png',
              normal_src: 'WF_-_Garmin_Instinct-BUTTONS.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'activityAppScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            //#region time_update
            function time_update(updateHour = false, updateMinute = false) {
              console.log('time_update()');
              let hour = timeSensor.hour;
              let minute = timeSensor.minute;
              let second = timeSensor.second;
              let format_hour = timeSensor.format_hour;

              console.log('day of week font');
              if (updateHour) {
                let normal_DOW_Str = normal_DOW_Array[timeSensor.week-1];
                normal_dow_text_font.setProperty(hmUI.prop.TEXT, normal_DOW_Str );
              };

              // Second Pointer
              let normal_fullAngle_second = 360;
              let normal_angle_second = 0 + normal_fullAngle_second*second/60;
              if (normal_analog_clock_pro_second_pointer_img) normal_analog_clock_pro_second_pointer_img.setProperty(hmUI.prop.ANGLE, normal_angle_second);

              console.log('day of week font');
              if (updateHour) {
                let idle_DOW_Str = idle_DOW_Array[timeSensor.week-1];
                idle_dow_text_font.setProperty(hmUI.prop.TEXT, idle_DOW_Str );
              };

            };

            //#endregion
            //#region text_update
            function text_update() {
              console.log('text_update()');

              console.log('update text rotate step_STEP');
              let valueStep = step.current;
              let normal_step_rotate_string = parseInt(valueStep).toString();

              if (screenType != hmSetting.screen_type.AOD) {
                for (var i = 1; i < 5; i++) {  // hide all symbols
                  normal_step_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                if (valueStep != null && valueStep != undefined && isFinite(valueStep) && normal_step_rotate_string.length > 0 && normal_step_rotate_string.length <= 5) {  // display data if it was possible to get it
                  let img_offset = 0;
                  
                  let index = 0;
                  for (let char of normal_step_rotate_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 5) break;
                    if (charCode >= 0 && charCode < 10) { 
                      normal_step_TextRotate[index].setProperty(hmUI.prop.POS_X, 23 + img_offset);
                      normal_step_TextRotate[index].setProperty(hmUI.prop.SRC, normal_step_TextRotate_ASCIIARRAY[charCode]);
                      normal_step_TextRotate[index].setProperty(hmUI.prop.VISIBLE, true);
                      img_offset += normal_step_TextRotate_img_width + 2;
                      index++;
                    };  // end if digit
                  };  // end char of string
                }  // end isFinite

              };

            };

            //#endregion
            function scale_call() {
              console.log('scale_call()');

              console.log('Weather city name');
              let weatherData = weatherSensor.getForecastWeather();
              let normal_cityNameStr = weatherData.cityName;
              normal_city_name_text.setProperty(hmUI.prop.TEXT, normal_cityNameStr);

            };

            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                console.log('resume_call()');
                scale_call();
                time_update(true, true);
                text_update();
                if (screenType == hmSetting.screen_type.WATCHFACE) {
                  if (!normal_timerUpdateSec) {
                    let animDelay = timeSensor.utc % 1000;
                    let animRepeat = 1000;
                    normal_timerUpdateSec = timer.createTimer(animDelay, animRepeat, (function (option) {
                      time_update(false, false);
                    }));  // end timer 
                  };  // end timer check
                };  // end screenType

                checkConnection();
                stopVibro();

              }),
              pause_call: (function () {
                console.log('pause_call()');
                if (normal_timerUpdateSec) {
                  timer.stopTimer(normal_timerUpdateSec);
                  normal_timerUpdateSec = undefined;
                }
                stopVibro();

              }),
            });

                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}