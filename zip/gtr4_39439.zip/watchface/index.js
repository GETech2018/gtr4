﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        const logger = Logger.getLogger('watchface_SashaCX75');
        //end of ignored block

        //dynamic modify start

        
        console.log('user_functions.js');
        // start user_functions.js

const { width: D_W, height: D_H } = hmSetting.getDeviceInfo();
        let groupVremya = ''
        let groupPogoda = ''
        let groupTap = ''
        let groupActiv = ''
//        let canvas0 = ''
//        let canvas = ''
        
		const battery = hmSensor.createSensor(hmSensor.id.BATTERY)
      const weatherSensor = hmSensor.createSensor(hmSensor.id.WEATHER);
         
         let normal_background_bg = ''  
        
      function makeAOD() {
      // color = hmFS.SysProGetInt('NUMNUM_color');

   
          
          

       const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
        resume_call: (function () {
         stopVibro();
        }),
        pause_call: (function () {
         hmApp.unregisterSpinEvent();
         stopVibro();
        }),
       });


      }

        
         

         
         
         
         let color_bg = [0xff0000, 0xFCB61C, 0x068FF9, 0xFFB900, 0xffffff, 0xf8e36c, 0xb84cf6, 0xa3fd1f, 0xfd912f, 0x8cffff, 0xff00a2];   

        
         let crownSensitivity = 70; // уровень чувствительности колесика
         let color = 0;
         let degreeSum = 0;

//         let MenuCirklDelay = 1000;
//         let MenuCirkl_Timer = null;


         function onDigitalCrown() {
       hmApp.registerSpinEvent(function (key, degree) {
        if (key === hmApp.key.HOME) {
         degreeSum += degree;
         if (Math.abs(degreeSum) > crownSensitivity) {


              // if (blok_btn == 0) {
              let step = degreeSum < 0 ? -1 : 1;
              color += step;
              color = color < 0 ? color_bg.length + color : color % color_bg.length;
              degreeSum = 0;

//              g_ACR_color.setProperty(hmUI.prop.VISIBLE, true);
//              if (MenuCirkl_Timer) clearTimeout(MenuCirkl_Timer);
//              MenuCirkl_Timer = setTimeout(() => {
//               g_ACR_color.setProperty(hmUI.prop.VISIBLE, false);
//              }, MenuCirklDelay);
                   
//        hmFS.SysProSetInt('NUMNUM_color', color);                   
//              });

              normal_background_bg.setProperty(hmUI.prop.COLOR, color_bg[color]);
//        normal_time_hour_text_font_1.setProperty(hmUI.prop.COLOR, color_bg[color]);
//        normal_time_hour_text_font_2.setProperty(hmUI.prop.COLOR, color_bg[color]);
			 
			 
//              normal_bat_text_font.setProperty(hmUI.prop.COLOR, color_bg[color]);
//              normal_heart_text_font.setProperty(hmUI.prop.COLOR, color_bg[color]);
//              normal_gradus_text_font.setProperty(hmUI.prop.COLOR, color_bg[color]);
//              normal_month_name_font.setProperty(hmUI.prop.COLOR, color_bg[color]);
             
             
//                   normal_battery_circle_scale.setProperty(hmUI.prop.MORE, {                      
//                      center_x: 134,
//                      center_y: 233,
//                      start_angle: -183,
//                      end_angle: 3,
//                      radius: 135,
//                      line_width: 197,
//                      corner_flag: 3,
//                      color: color_bg[color],
//                      show_level: hmUI.show_level.ONLY_NORMAL,
//                      //level: level,
//                    });
             
           
             
      //  hmFS.SysProSetInt('NUMNUM_color', color);                   
             
             
//              idle_background_bg.setProperty(hmUI.prop.COLOR, color_bg[color]);
              vibro();

        //  }
         }
        }
       }) // crown
      }       
         
         

            const vibrate = hmSensor.createSensor(hmSensor.id.VIBRATE)
            let stopVibro_Timer = null;

            function vibro(scene = 25) {
                let stopDelay = 50;
                vibrate.stop();
                vibrate.scene = scene;
                if (scene < 23 || scene > 25) stopDelay = 1220;
                vibrate.start();
                stopVibro_Timer = timer.createTimer(stopDelay, 0, stopVibro, {});
            }

            function stopVibro() {
                vibrate.stop();
                timer.stopTimer(stopVibro_Timer);
            }

        function click_Pogoda_on() {
          groupVremya.setProperty(hmUI.prop.VISIBLE, false);
          groupPogoda.setProperty(hmUI.prop.VISIBLE, true);
         }

         function click_Pogoda_off() {
          groupVremya.setProperty(hmUI.prop.VISIBLE, true);
          groupPogoda.setProperty(hmUI.prop.VISIBLE, false);
         }  

      function click_Activ_on() {
       groupVremya.setProperty(hmUI.prop.VISIBLE, false);
       groupActiv.setProperty(hmUI.prop.VISIBLE, true);
      }

      function click_Activ_off() {
       groupVremya.setProperty(hmUI.prop.VISIBLE, true);
       groupActiv.setProperty(hmUI.prop.VISIBLE, false);
      }



         let apps = [
          ['Нет действия', '-', `tap/i_tap_pusto.png`],
          ['Таймер', 'CountdownAppScreen', `tap/i_tap_obrat_otchet.png`],
          ['Секундомер', 'StopWatchScreen', `tap/i_tap_secundomer.png`],
          ['Мировые часы', 'WorldClockScreen', `tap/i_tap_mirivie_chasi.png`],
          ['Восход/закат', 'TideScreen', `tap/i_tap_voshod_zakat.png`],
          ['Сон', 'Sleep_HomeScreen', `tap/i_tap_son.png`],
          ['Стресс', 'StressHomeScreen', `tap/i_tap_stress.png`],
          ['SP02 (Кислород)', 'spo_HomeScreen', `tap/i_tap_kislorod.png`],
          ['Дыхание', 'RespirationsettingScreen', `tap/i_tap_dihanie.png`],
          ['Измерение одним касанием', 'oneKeyAppScreen', `tap/i_tap_1_kosanie.png`],
          ['Женский календарь', 'menstrualAppScreen', `tap/i_tap_gensk_calendar.png`],
          ['Найти телефон', 'FindPhoneScreen', `tap/i_tap_naiti_telo.png`],
          ['Музыка', 'PhoneMusicCtrlScreen', `tap/i_tap_musik.png`],
          ['Компас', 'CompassScreen', `tap/i_tap_kompas.png`],
          ['Набрать номер', 'DialCallScreen', `tap/i_tap_nabor.png`],
          ['Телефон', 'PhoneHomeScreen', `tap/i_tap_telefon.png`],
          ['Диктофон', 'VoiceMemoScreen', `tap/i_tap_dictofon.png`],
          ['Расписание', 'ScheduleListScreen', `tap/i_tap_raspisanie.png`],
          ['Список дел', 'todoListScreen', `tap/i_tap_spisok_del.png`],
          ['Календарь', 'ScheduleCalScreen', `tap/i_tap_calendar.png`],
          ['Погода', 'WeatherScreen', `tap/i_tap_pogoda.png`],
          ['Настройка', 'Settings_homeScreen', `tap/i_tap_sitting.png`],
          ['Камера', 'HidcameraScreen', `tap/i_tap_camera.png`],
          ['Пульс', 'heart_app_Screen', `tap/i_tap_puls.png`],
          ['Будильник', 'AlarmInfoScreen', `tap/i_tap_budilnik.png`],
          ['PAI', 'PAI_app_Screen', `tap/i_tap_pai.png`],
          ['Тренировка', 'SportListScreen', `tap/i_tap_trenerovka.png`],
          ['AOD', 'Settings_standbyModelScreen', `tap/i_tap_aod.png`],
          ['Экономия заряда', 'LowBatteryScreen', `tap/i_tap_LowBattery.png`],
          ['Давление/Высота', 'BaroAltimeterScreen', `tap/i_tap_barometr.png`]
         ];


         const tap_1_edit = hmUI.createWidget(hmUI.widget.WATCHFACE_EDIT_GROUP, {
          edit_id: 101,
          x: 171,
          y: 20,
          w: 124,
          h: 124,
          select_image: 'tap/edit_red_1.png',
          un_select_image: 'tap/edit_griin_1.png',
          default_type: 19,
          optional_types: [{
           type: 0,
           preview: apps[0][2],
           title_en: apps[0][0]
          }, {
           type: 1,
           preview: apps[1][2],
           title_en: apps[1][0]
          }, {
           type: 2,
           preview: apps[2][2],
           title_en: apps[2][0]
          }, {
           type: 3,
           preview: apps[3][2],
           title_en: apps[3][0]
          }, {
           type: 4,
           preview: apps[4][2],
           title_en: apps[4][0]
          }, {
           type: 5,
           preview: apps[5][2],
           title_en: apps[5][0]
          }, {
           type: 6,
           preview: apps[6][2],
           title_en: apps[6][0]
          }, {
           type: 7,
           preview: apps[7][2],
           title_en: apps[7][0]
          }, {
           type: 8,
           preview: apps[8][2],
           title_en: apps[8][0]
          }, {
           type: 9,
           preview: apps[9][2],
           title_en: apps[9][0]
          }, {
           type: 10,
           preview: apps[10][2],
           title_en: apps[10][0]
          }, {
           type: 11,
           preview: apps[11][2],
           title_en: apps[11][0]
          }, {
           type: 12,
           preview: apps[12][2],
           title_en: apps[12][0]
          }, {
           type: 13,
           preview: apps[13][2],
           title_en: apps[13][0]
          }, {
           type: 14,
           preview: apps[14][2],
           title_en: apps[14][0]
          }, {
           type: 15,
           preview: apps[15][2],
           title_en: apps[15][0]
          }, {
           type: 16,
           preview: apps[16][2],
           title_en: apps[16][0]
          }, {
           type: 17,
           preview: apps[17][2],
           title_en: apps[17][0]
          }, {
           type: 18,
           preview: apps[18][2],
           title_en: apps[18][0]
          }, {
           type: 19,
           preview: apps[19][2],
           title_en: apps[19][0]
          }, {
           type: 20,
           preview: apps[20][2],
           title_en: apps[20][0]
          }, {
           type: 21,
           preview: apps[21][2],
           title_en: apps[21][0]
          }, {
           type: 22,
           preview: apps[22][2],
           title_en: apps[22][0]
          }, {
           type: 23,
           preview: apps[23][2],
           title_en: apps[23][0]
          }, {
           type: 24,
           preview: apps[24][2],
           title_en: apps[24][0]
          }, {
           type: 25,
           preview: apps[25][2],
           title_en: apps[25][0]
          }, {
           type: 26,
           preview: apps[26][2],
           title_en: apps[26][0]
          }, {
           type: 27,
           preview: apps[27][2],
           title_en: apps[27][0]
          }, {
           type: 28,
           preview: apps[28][2],
           title_en: apps[28][0]
          }, {
           type: 29,
           preview: apps[29][2],
           title_en: apps[29][0]
          }, ],
          count: 30,
          tips_x: 135 - 171,
          tips_y: 150 - 20,
          tips_width: 195,
          tips_margin: 10,
          tips_BG: 'tap/tips_bg.png'
         })

         let tap_1_select = tap_1_edit.getProperty(hmUI.prop.CURRENT_TYPE)

         const tap_2_edit = hmUI.createWidget(hmUI.widget.WATCHFACE_EDIT_GROUP, {
          edit_id: 102,
          x: 301,
          y: 95,
          w: 124,
          h: 124,
          select_image: 'tap/edit_red_1.png',
          un_select_image: 'tap/edit_griin_1.png',
          default_type: 20,
          optional_types: [{
           type: 0,
           preview: apps[0][2],
           title_en: apps[0][0]
          }, {
           type: 1,
           preview: apps[1][2],
           title_en: apps[1][0]
          }, {
           type: 2,
           preview: apps[2][2],
           title_en: apps[2][0]
          }, {
           type: 3,
           preview: apps[3][2],
           title_en: apps[3][0]
          }, {
           type: 4,
           preview: apps[4][2],
           title_en: apps[4][0]
          }, {
           type: 5,
           preview: apps[5][2],
           title_en: apps[5][0]
          }, {
           type: 6,
           preview: apps[6][2],
           title_en: apps[6][0]
          }, {
           type: 7,
           preview: apps[7][2],
           title_en: apps[7][0]
          }, {
           type: 8,
           preview: apps[8][2],
           title_en: apps[8][0]
          }, {
           type: 9,
           preview: apps[9][2],
           title_en: apps[9][0]
          }, {
           type: 10,
           preview: apps[10][2],
           title_en: apps[10][0]
          }, {
           type: 11,
           preview: apps[11][2],
           title_en: apps[11][0]
          }, {
           type: 12,
           preview: apps[12][2],
           title_en: apps[12][0]
          }, {
           type: 13,
           preview: apps[13][2],
           title_en: apps[13][0]
          }, {
           type: 14,
           preview: apps[14][2],
           title_en: apps[14][0]
          }, {
           type: 15,
           preview: apps[15][2],
           title_en: apps[15][0]
          }, {
           type: 16,
           preview: apps[16][2],
           title_en: apps[16][0]
          }, {
           type: 17,
           preview: apps[17][2],
           title_en: apps[17][0]
          }, {
           type: 18,
           preview: apps[18][2],
           title_en: apps[18][0]
          }, {
           type: 19,
           preview: apps[19][2],
           title_en: apps[19][0]
          }, {
           type: 20,
           preview: apps[20][2],
           title_en: apps[20][0]
          }, {
           type: 21,
           preview: apps[21][2],
           title_en: apps[21][0]
          }, {
           type: 22,
           preview: apps[22][2],
           title_en: apps[22][0]
          }, {
           type: 23,
           preview: apps[23][2],
           title_en: apps[23][0]
          }, {
           type: 24,
           preview: apps[24][2],
           title_en: apps[24][0]
          }, {
           type: 25,
           preview: apps[25][2],
           title_en: apps[25][0]
          }, {
           type: 26,
           preview: apps[26][2],
           title_en: apps[26][0]
          }, {
           type: 27,
           preview: apps[27][2],
           title_en: apps[27][0]
          }, {
           type: 28,
           preview: apps[28][2],
           title_en: apps[28][0]
          }, {
           type: 29,
           preview: apps[29][2],
           title_en: apps[29][0]
          }, ],
          count: 30,
          tips_x: 266 - 301,
          tips_y: 225 - 95,
          tips_width: 195,
          tips_margin: 10,
          tips_BG: 'tap/tips_bg.png'
         })


         let tap_2_select = tap_2_edit.getProperty(hmUI.prop.CURRENT_TYPE)


         const tap_3_edit = hmUI.createWidget(hmUI.widget.WATCHFACE_EDIT_GROUP, {
          edit_id: 103,
          x: 301,
          y: 246,
          w: 124,
          h: 124,
          select_image: 'tap/edit_red_1.png',
          un_select_image: 'tap/edit_griin_1.png',
          default_type: 24,
          optional_types: [{
           type: 0,
           preview: apps[0][2],
           title_en: apps[0][0]
          }, {
           type: 1,
           preview: apps[1][2],
           title_en: apps[1][0]
          }, {
           type: 2,
           preview: apps[2][2],
           title_en: apps[2][0]
          }, {
           type: 3,
           preview: apps[3][2],
           title_en: apps[3][0]
          }, {
           type: 4,
           preview: apps[4][2],
           title_en: apps[4][0]
          }, {
           type: 5,
           preview: apps[5][2],
           title_en: apps[5][0]
          }, {
           type: 6,
           preview: apps[6][2],
           title_en: apps[6][0]
          }, {
           type: 7,
           preview: apps[7][2],
           title_en: apps[7][0]
          }, {
           type: 8,
           preview: apps[8][2],
           title_en: apps[8][0]
          }, {
           type: 9,
           preview: apps[9][2],
           title_en: apps[9][0]
          }, {
           type: 10,
           preview: apps[10][2],
           title_en: apps[10][0]
          }, {
           type: 11,
           preview: apps[11][2],
           title_en: apps[11][0]
          }, {
           type: 12,
           preview: apps[12][2],
           title_en: apps[12][0]
          }, {
           type: 13,
           preview: apps[13][2],
           title_en: apps[13][0]
          }, {
           type: 14,
           preview: apps[14][2],
           title_en: apps[14][0]
          }, {
           type: 15,
           preview: apps[15][2],
           title_en: apps[15][0]
          }, {
           type: 16,
           preview: apps[16][2],
           title_en: apps[16][0]
          }, {
           type: 17,
           preview: apps[17][2],
           title_en: apps[17][0]
          }, {
           type: 18,
           preview: apps[18][2],
           title_en: apps[18][0]
          }, {
           type: 19,
           preview: apps[19][2],
           title_en: apps[19][0]
          }, {
           type: 20,
           preview: apps[20][2],
           title_en: apps[20][0]
          }, {
           type: 21,
           preview: apps[21][2],
           title_en: apps[21][0]
          }, {
           type: 22,
           preview: apps[22][2],
           title_en: apps[22][0]
          }, {
           type: 23,
           preview: apps[23][2],
           title_en: apps[23][0]
          }, {
           type: 24,
           preview: apps[24][2],
           title_en: apps[24][0]
          }, {
           type: 25,
           preview: apps[25][2],
           title_en: apps[25][0]
          }, {
           type: 26,
           preview: apps[26][2],
           title_en: apps[26][0]
          }, {
           type: 27,
           preview: apps[27][2],
           title_en: apps[27][0]
          }, {
           type: 28,
           preview: apps[28][2],
           title_en: apps[28][0]
          }, {
           type: 29,
           preview: apps[29][2],
           title_en: apps[29][0]
          }, ],
          count: 30,
          tips_x: 266 - 301,
          tips_y: 184 - 246,
          tips_width: 195,
          tips_margin: 10,
          tips_BG: 'tap/tips_bg.png'
         })

         let tap_3_select = tap_3_edit.getProperty(hmUI.prop.CURRENT_TYPE)

         const tap_4_edit = hmUI.createWidget(hmUI.widget.WATCHFACE_EDIT_GROUP, {
          edit_id: 104,
          x: 171,
          y: 321,
          w: 124,
          h: 124,
          select_image: 'tap/edit_red_1.png',
          un_select_image: 'tap/edit_griin_1.png',
          default_type: 11,
          optional_types: [{
           type: 0,
           preview: apps[0][2],
           title_en: apps[0][0]
          }, {
           type: 1,
           preview: apps[1][2],
           title_en: apps[1][0]
          }, {
           type: 2,
           preview: apps[2][2],
           title_en: apps[2][0]
          }, {
           type: 3,
           preview: apps[3][2],
           title_en: apps[3][0]
          }, {
           type: 4,
           preview: apps[4][2],
           title_en: apps[4][0]
          }, {
           type: 5,
           preview: apps[5][2],
           title_en: apps[5][0]
          }, {
           type: 6,
           preview: apps[6][2],
           title_en: apps[6][0]
          }, {
           type: 7,
           preview: apps[7][2],
           title_en: apps[7][0]
          }, {
           type: 8,
           preview: apps[8][2],
           title_en: apps[8][0]
          }, {
           type: 9,
           preview: apps[9][2],
           title_en: apps[9][0]
          }, {
           type: 10,
           preview: apps[10][2],
           title_en: apps[10][0]
          }, {
           type: 11,
           preview: apps[11][2],
           title_en: apps[11][0]
          }, {
           type: 12,
           preview: apps[12][2],
           title_en: apps[12][0]
          }, {
           type: 13,
           preview: apps[13][2],
           title_en: apps[13][0]
          }, {
           type: 14,
           preview: apps[14][2],
           title_en: apps[14][0]
          }, {
           type: 15,
           preview: apps[15][2],
           title_en: apps[15][0]
          }, {
           type: 16,
           preview: apps[16][2],
           title_en: apps[16][0]
          }, {
           type: 17,
           preview: apps[17][2],
           title_en: apps[17][0]
          }, {
           type: 18,
           preview: apps[18][2],
           title_en: apps[18][0]
          }, {
           type: 19,
           preview: apps[19][2],
           title_en: apps[19][0]
          }, {
           type: 20,
           preview: apps[20][2],
           title_en: apps[20][0]
          }, {
           type: 21,
           preview: apps[21][2],
           title_en: apps[21][0]
          }, {
           type: 22,
           preview: apps[22][2],
           title_en: apps[22][0]
          }, {
           type: 23,
           preview: apps[23][2],
           title_en: apps[23][0]
          }, {
           type: 24,
           preview: apps[24][2],
           title_en: apps[24][0]
          }, {
           type: 25,
           preview: apps[25][2],
           title_en: apps[25][0]
          }, {
           type: 26,
           preview: apps[26][2],
           title_en: apps[26][0]
          }, {
           type: 27,
           preview: apps[27][2],
           title_en: apps[27][0]
          }, {
           type: 28,
           preview: apps[28][2],
           title_en: apps[28][0]
          }, {
           type: 29,
           preview: apps[29][2],
           title_en: apps[29][0]
          }, ],
          count: 30,
          tips_x: 135 - 171,
          tips_y: 257 - 321,
          tips_width: 195,
          tips_margin: 10,
          tips_BG: 'tap/tips_bg.png'
         })

         let tap_4_select = tap_4_edit.getProperty(hmUI.prop.CURRENT_TYPE)

         const tap_5_edit = hmUI.createWidget(hmUI.widget.WATCHFACE_EDIT_GROUP, {
          edit_id: 105,
          x: 40,
          y: 246,
          w: 124,
          h: 124,
          select_image: 'tap/edit_red_1.png',
          un_select_image: 'tap/edit_griin_1.png',
          default_type: 0,
          optional_types: [{
           type: 0,
           preview: apps[0][2],
           title_en: apps[0][0]
          }, {
           type: 1,
           preview: apps[1][2],
           title_en: apps[1][0]
          }, {
           type: 2,
           preview: apps[2][2],
           title_en: apps[2][0]
          }, {
           type: 3,
           preview: apps[3][2],
           title_en: apps[3][0]
          }, {
           type: 4,
           preview: apps[4][2],
           title_en: apps[4][0]
          }, {
           type: 5,
           preview: apps[5][2],
           title_en: apps[5][0]
          }, {
           type: 6,
           preview: apps[6][2],
           title_en: apps[6][0]
          }, {
           type: 7,
           preview: apps[7][2],
           title_en: apps[7][0]
          }, {
           type: 8,
           preview: apps[8][2],
           title_en: apps[8][0]
          }, {
           type: 9,
           preview: apps[9][2],
           title_en: apps[9][0]
          }, {
           type: 10,
           preview: apps[10][2],
           title_en: apps[10][0]
          }, {
           type: 11,
           preview: apps[11][2],
           title_en: apps[11][0]
          }, {
           type: 12,
           preview: apps[12][2],
           title_en: apps[12][0]
          }, {
           type: 13,
           preview: apps[13][2],
           title_en: apps[13][0]
          }, {
           type: 14,
           preview: apps[14][2],
           title_en: apps[14][0]
          }, {
           type: 15,
           preview: apps[15][2],
           title_en: apps[15][0]
          }, {
           type: 16,
           preview: apps[16][2],
           title_en: apps[16][0]
          }, {
           type: 17,
           preview: apps[17][2],
           title_en: apps[17][0]
          }, {
           type: 18,
           preview: apps[18][2],
           title_en: apps[18][0]
          }, {
           type: 19,
           preview: apps[19][2],
           title_en: apps[19][0]
          }, {
           type: 20,
           preview: apps[20][2],
           title_en: apps[20][0]
          }, {
           type: 21,
           preview: apps[21][2],
           title_en: apps[21][0]
          }, {
           type: 22,
           preview: apps[22][2],
           title_en: apps[22][0]
          }, {
           type: 23,
           preview: apps[23][2],
           title_en: apps[23][0]
          }, {
           type: 24,
           preview: apps[24][2],
           title_en: apps[24][0]
          }, {
           type: 25,
           preview: apps[25][2],
           title_en: apps[25][0]
          }, {
           type: 26,
           preview: apps[26][2],
           title_en: apps[26][0]
          }, {
           type: 27,
           preview: apps[27][2],
           title_en: apps[27][0]
          }, {
           type: 28,
           preview: apps[28][2],
           title_en: apps[28][0]
          }, {
           type: 29,
           preview: apps[29][2],
           title_en: apps[29][0]
          }, ],
          count: 30,
          tips_x: 5 - 40,
          tips_y: 184 - 246,
          tips_width: 195,
          tips_margin: 10,
          tips_BG: 'tap/tips_bg.png'
         })

         let tap_5_select = tap_5_edit.getProperty(hmUI.prop.CURRENT_TYPE)

         const tap_6_edit = hmUI.createWidget(hmUI.widget.WATCHFACE_EDIT_GROUP, {
          edit_id: 106,
          x: 40,
          y: 95,
          w: 124,
          h: 124,
          select_image: 'tap/edit_red_1.png',
          un_select_image: 'tap/edit_griin_1.png',
          default_type: 0,
          optional_types: [{
           type: 0,
           preview: apps[0][2],
           title_en: apps[0][0]
          }, {
           type: 1,
           preview: apps[1][2],
           title_en: apps[1][0]
          }, {
           type: 2,
           preview: apps[2][2],
           title_en: apps[2][0]
          }, {
           type: 3,
           preview: apps[3][2],
           title_en: apps[3][0]
          }, {
           type: 4,
           preview: apps[4][2],
           title_en: apps[4][0]
          }, {
           type: 5,
           preview: apps[5][2],
           title_en: apps[5][0]
          }, {
           type: 6,
           preview: apps[6][2],
           title_en: apps[6][0]
          }, {
           type: 7,
           preview: apps[7][2],
           title_en: apps[7][0]
          }, {
           type: 8,
           preview: apps[8][2],
           title_en: apps[8][0]
          }, {
           type: 9,
           preview: apps[9][2],
           title_en: apps[9][0]
          }, {
           type: 10,
           preview: apps[10][2],
           title_en: apps[10][0]
          }, {
           type: 11,
           preview: apps[11][2],
           title_en: apps[11][0]
          }, {
           type: 12,
           preview: apps[12][2],
           title_en: apps[12][0]
          }, {
           type: 13,
           preview: apps[13][2],
           title_en: apps[13][0]
          }, {
           type: 14,
           preview: apps[14][2],
           title_en: apps[14][0]
          }, {
           type: 15,
           preview: apps[15][2],
           title_en: apps[15][0]
          }, {
           type: 16,
           preview: apps[16][2],
           title_en: apps[16][0]
          }, {
           type: 17,
           preview: apps[17][2],
           title_en: apps[17][0]
          }, {
           type: 18,
           preview: apps[18][2],
           title_en: apps[18][0]
          }, {
           type: 19,
           preview: apps[19][2],
           title_en: apps[19][0]
          }, {
           type: 20,
           preview: apps[20][2],
           title_en: apps[20][0]
          }, {
           type: 21,
           preview: apps[21][2],
           title_en: apps[21][0]
          }, {
           type: 22,
           preview: apps[22][2],
           title_en: apps[22][0]
          }, {
           type: 23,
           preview: apps[23][2],
           title_en: apps[23][0]
          }, {
           type: 24,
           preview: apps[24][2],
           title_en: apps[24][0]
          }, {
           type: 25,
           preview: apps[25][2],
           title_en: apps[25][0]
          }, {
           type: 26,
           preview: apps[26][2],
           title_en: apps[26][0]
          }, {
           type: 27,
           preview: apps[27][2],
           title_en: apps[27][0]
          }, {
           type: 28,
           preview: apps[28][2],
           title_en: apps[28][0]
          }, {
           type: 29,
           preview: apps[29][2],
           title_en: apps[29][0]
          }, ],
          count: 30,
          tips_x: 5 - 40,
          tips_y: 225 - 95,

          tips_width: 195,
          tips_margin: 10,
          tips_BG: 'tap/tips_bg.png'
         })

         let tap_6_select = tap_6_edit.getProperty(hmUI.prop.CURRENT_TYPE)

         let btn_tap = ''
         let btn_click_tap_exit = ''

         let btn_Tap_zona_0 = ''
         let btn_Tap_zona_1 = ''
         let btn_Tap_zona_2 = ''
         let btn_Tap_zona_3 = ''
         let btn_Tap_zona_4 = ''
         let btn_Tap_zona_5 = ''

         function tap_zona_exit() {
          groupVremya.setProperty(hmUI.prop.VISIBLE, true);
          groupTap.setProperty(hmUI.prop.VISIBLE, false);
         }

         let tap_x_y = [
          [178, 26, 1],
          [308, 102, 1],
          [308, 253, 1],
          [178, 328, 0],
          [47, 253, 0],
          [47, 102, 0]
         ];

         function tap_run() {
          groupVremya.setProperty(hmUI.prop.VISIBLE, false);
          groupTap.setProperty(hmUI.prop.VISIBLE, true);
         }   


    			//-------------------------------- 
      //переменные для ргафика
      let weather_ic_array = []
      let weather_ic = []
      let DigDay = []
      let DigNight = []
      let yArrH = [];
      let arr_xH = [];
      let arr_yH = [];
      let arr_x = [];
      let arr_y = [];
      let arr_xL = [];
      let arr_yL = [];
      let yArrAll = [];
      let yArrL = [];
      let y_pogodaH = [];
      let y_pogodaL = [];
      let week_array = ["ПН", "ВТ", "СР", "ЧТ", "ПТ", "СБ", "ВС"];
      let week_text = []
      let data_text = []
      const ROOTPATH = "images/"
      var shag = 46;
      var x0 = 119 - 23 - 23;
      let dney = 8;
      let isDayIcons = false
      
      let shotWeaterhNames = ["Облачно", "Местами дождь", "Местами снег", "Cолнечно", "Пасмурно", "Слабый дождь", "Слабый снег", "Умеренный дождь", "Умеренный снег", "Сильный снегопад", "Сильный дождь", "Песчаная буря", "Мокрый снег", "Туман", "Дымка", "Дождь с грозой", "Метель", "Пыльно", "Ливень", "Дождь с градом", "Сильный дождь с градом", "Сильный дождь ", "Песчаная буря", "Сильная песчаная буря ", "Сильный дождь", "Неизвестная погода", "Облачно ночью", "Дождливо ночью", "Ясно ночью"];
        
        let app_activ_left = []
      let app_activ_right = []
      let app_activ_txt_left = []
      let app_activ_txt_right = []
      let activ_arr_left = [
       ['PAI', hmUI.data_type.PAI_WEEKLY, false],
       ['КАЛОРИЙ', hmUI.data_type.CAL, false],
       ['ШАГОВ', hmUI.data_type.STEP, false],
       ['РАЗМИНКА', hmUI.data_type.STAND, false],
       ['БУДИЛЬНИК', hmUI.data_type.ALARM_CLOCK, true],
       ['ЭТАЖ', hmUI.data_type.FLOOR, false]
      ];
      let activ_arr_right = [
       ['ЖИР', hmUI.data_type.FAT_BURNING, false],
       ['ПУЛЬС', hmUI.data_type.HEART, false],
       ['КМ', hmUI.data_type.DISTANCE, false],
       ['КИСЛОРОД', hmUI.data_type.SPO2, false],
       ['ТАЙМЕР', hmUI.data_type.COUNT_DOWN, true],
       ['СТРЕСС', hmUI.data_type.STRESS, false]
      ];   
        
      let tip_grafik = 0
      function click_tip_grafik() {
       tip_grafik = (tip_grafik + 1) % 2
       updateGrafik()
      }      


     // let timeSensor = ''

      let normal_city_name_text = ''


			
    			//-------------------------------- 
		 
  		//массив иконок для графика       
    		for (var i = 0; i <= 28; i++) {
          weather_ic_array.push(ROOTPATH + "Grafik/weather/" + i + ".png"); //0-28
    		}



      //обновление для   графика           
      function updateGrafik() {
      if (!timeSensor) timeSensor = hmSensor.createSensor(hmSensor.id.TIME);
      let day_num = [0, 31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31];
      let year = timeSensor.year;
      if (year % 4 == 0 && (year % 100 != 0 || year % 400 == 0)) { // Високосный год
       day_num[2] = 29
      } else {
       day_num[2] = 28
      }
          
          let current = weatherSensor.current;
          let curAirIconIndex = weatherSensor.curAirIconIndex;

          let temperature_current_temp = -100;
          if (weatherSensor.current != undefined && weatherSensor.current != 'undefined') {
           temperature_current_temp = weatherSensor.current;
          }; // end currentWeather; 

          let weatherData = weatherSensor.getForecastWeather();
          let forecastData = weatherData.forecastData;

          normal_city_name_text.setProperty(hmUI.prop.TEXT, weatherData.cityName + " " + temperature_current_temp + "°C");
          normal_weather_text_font.setProperty(hmUI.prop.TEXT, shotWeaterhNames[curAirIconIndex]);
       canvas.clear({
        x: 0,
        y: 0,
        w: 466,
        h: 466
       })

       canvas.drawCircle({
        center_x: 233,
        center_y: 233,
        radius: 233,
        color: 0x000000
       })

       for (let i = 0; i < dney - 1; i++) {
        canvas.drawRect({
         x1: 94 + shag * [i],
         y1: 93,
         x2: 94 + shag * [i] + 1,
         y2: 351,
         color: 0xc0c0c0
        })
       }


//       let weatherData = weatherSensor.getForecastWeather();
//       let forecastData = weatherData.forecastData;


       if (forecastData.count == 0) {
        for (let i = 0; i < dney; i++) {
         var invalidPath = "--";
         weather_ic[i].setProperty(hmUI.prop.SRC, ROOTPATH + "Grafik/weather/25.png");
        }
       } else {
        let weekDay = timeSensor.week - 1;
        let data_gr = timeSensor.day;
        let month_gr = timeSensor.month;

        for (let i = 0; i < dney; i++) {

         // let arr_y  = [252, 238, 252, 266, 238, 224, 308, 322];    

         yArrH[i] = forecastData.data[i].high;

         let element = forecastData.data[i];
         let iconIndex = element.index;
         weather_ic[i].setProperty(hmUI.prop.SRC, weather_ic_array[iconIndex]);
         let week2 = week_array[weekDay];
         week_text[i].setProperty(hmUI.prop.MORE, {
          color: weekDay < 5 ? "0xFFFFFFFF" : "0xFFFF0000",
          text: week2,
         });
         data_text[i].setProperty(hmUI.prop.MORE, {
          color: weekDay < 5 ? "0xFFFFFFFF" : "0xFFFF0000",
          text: data_gr,
         });
         weekDay = (weekDay + 1) % 7;
         data_gr = (data_gr + 1)
         if (data_gr > day_num[month_gr]) data_gr = 1
         if (i < dney - 1) yArrL[i] = forecastData.data[i].low;

        }
       }

       sunData = weatherData.tideData;
       if (sunData.count > 0) {
        today = sunData.data[0];
        sunriseMins = today.sunrise.hour * 60 + today.sunrise.minute;
        sunsetMins = today.sunset.hour * 60 + today.sunset.minute;
       } else {
        sunriseMins = sunriseMins_def;
        sunsetMins = sunsetMins_def;
       }
       curMins = timeSensor.hour * 60 + timeSensor.minute;
       let isDayNow = (curMins >= sunriseMins) && (curMins < sunsetMins);

       if (isDayNow) {
        if (!isDayIcons) {
         isDayIcons = true;
        }
       } else {
        if (isDayIcons) {
         isDayIcons = false;
        }
       }


       /*  
       normal_sun_high_text_font.setProperty(hmUI.prop.VISIBLE, isDayIcons == false && zona== 3);
         // normal_sun_vos_img.setProperty(hmUI.prop.VISIBLE, isDayIcons == false);
          normal_sun_low_text_font.setProperty(hmUI.prop.VISIBLE, isDayIcons == true && zona== 3);
         // normal_sun_zak_img.setProperty(hmUI.prop.VISIBLE, isDayIcons == true);	
         ic_img = isDayIcons == true ? ['ic_puls.png', 'ic_temp.png', 'ic_cal.png', 'ic_zak.png'] : ['ic_puls.png', 'ic_temp.png', 'ic_cal.png', 'ic_vos.png']; 
         ic_text = isDayIcons == true ? ["ПУЛЬС", "НОЧЬ/ДЕНЬ", "КАЛОРИЙ", "ЗАКАТ"] : ["ПУЛЬС", "НОЧЬ/ДЕНЬ", "КАЛОРИЙ",  "ВОСХОД"]; */


       shotWeaterhNames = isDayIcons == false ? ["Облачно ночью", "Местами дождь", "Местами снег", "Ясно ночью", "Пасмурно ночью", "Слабый дождь", "Слабый снег", "Умеренный дождь", "Умеренный снег", "Сильный снегопад", "Сильный дождь", "Песчаная буря", "Мокрый снег", "Туман", "Дымка", "Дождь с грозой", "Метель", "Пыльно", "Ливень", "Дождь с градом", "Сильный дождь с градом", "Сильный дождь ", "Песчаная буря", "Сильная песчаная буря", "Сильный дождь", "Неизвестная погода", "Облачно ночью", "Дождливо ночью", "Ясно ночью"] : ["Облачно", "Местами дождь", "Местами снег", "Cолнечно", "Пасмурно", "Слабый дождь", "Слабый снег", "Умеренный дождь", "Умеренный снег", "Сильный снегопад", "Сильный дождь", "Песчаная буря", "Мокрый снег", "Туман", "Дымка", "Дождь с грозой", "Метель", "Пыльно", "Ливень", "Дождь с градом", "Сильный дождь с градом", "Сильный дождь ", "Песчаная буря", "Сильная песчаная буря ", "Сильный дождь", "Неизвестная погода", "Облачно ночью", "Дождливо ночью", "Ясно ночью"];

       //  array_ic_weater = isDayIcons == false ?  ["Ъ", "Ы", "Э", "Ь", "Д", "Е", "Ж", "З", "И", "Й", "К", "Л", "М", "Н", "О", "П", "Р", "С", "У", "Ф", "Х", "Ц", "Ч", "Ш", "?", "Ъ", "Ы", "Ь"] : ["А", "Б", "В", "Г", "Д", "Е", "Ж", "З", "И", "Й", "К", "Л", "М", "Н", "О", "П", "Р", "С", "У", "Ф", "Х", "Ц", "Ч", "Ш", "?", "Ъ", "Ы", "Ь"];                


       let maxH = Math.max(...yArrH)
       let maxL = Math.min(...yArrL)
       let delta = 120 / (maxL - maxH)

       let RedArray = [];
       let BlueArray = [];


       if (tip_grafik == 0) {
        for (let i = 0; i < dney; i++) {
         arr_x[i] = x0 + shag * [i];
         arr_y[i] = yArrH[i] * delta + 162 - maxH * delta;
        }
        // let n = arr_x.length;
        splain(dney)

        for (let i = 0; i < dney - 1; i++) {
         arr_x[i] = x0 + 23 + shag * [i];
         arr_y[i] = yArrL[i] * delta + 162 - maxH * delta;
        }
        // n = dney - 1;
        splain(dney - 1)
       }
       if (tip_grafik == 1) {
        let k = 0
        for (let i = 0; i < dney; i++) {

         yArrAll[k] = yArrH[i]
         k = k + 1
         yArrAll[k] = yArrL[i]
         k = k + 1
        }


        for (let i = 0; i < yArrAll.length; i++) {
         arr_x[i] = x0 + shag / 2 * [i];
         arr_y[i] = yArrAll[i] * delta + 162 - maxH * delta;
        }
        //n = yArrAll.length - 1;
        splain(yArrAll.length - 1)
       }


       for (let i = 0; i < dney; i++) {
        if (tip_grafik == 0) {
         canvas.drawCircle({
          center_x: x0 + shag * [i],
          center_y: yArrH[i] * delta + 162 - maxH * delta,
          radius: 5,
          color: 0xFF0000
         })
        }
        y_pogodaH[i] = (yArrH[i] * delta + 145 - maxH * delta) - 5;
        DigDay[i].setProperty(hmUI.prop.more, {
         x: x0 - 23 - 5 + i * 45 * 1.02,
         y: y_pogodaH[i] - 18, //120-7//120-7/- 38
         w: 50,
         h: 40,
         color: "0xFFffffff",
         text_size: 27,
         text: yArrH[i],
         text_style: hmUI.text_style.NONE,
         align_h: hmUI.align.CENTER_H,
         align_v: hmUI.align.CENTER_V,
         show_level: hmUI.show_level.ONLY_NORMAL
        });

        if (i < dney - 1) {
         if (tip_grafik == 0) {
          canvas.drawCircle({
           center_x: x0 + 23 + shag * [i],
           center_y: yArrL[i] * delta + 162 - maxH * delta,
           radius: 5,
           color: 0x00eaff
          })
         }
         y_pogodaL[i] = (yArrL[i] * delta + 145 - maxH * delta) - 5;;
         DigNight[i].setProperty(hmUI.prop.more, {
          x: x0 - 23 - 5 + 23 + i * 45 * 1.02,
          y: y_pogodaL[i] + 19, //120-7 / - 1  
          w: 50,
          h: 40,
          color: "0xFFffffff",
          text_size: 27,
          text: yArrL[i],
          text_style: hmUI.text_style.NONE,
          align_h: hmUI.align.CENTER_H,
          align_v: hmUI.align.CENTER_V,
          show_level: hmUI.show_level.ONLY_NORMAL
         });
        } //dney - 1
       }; //dney                
      }
        
        
      function splain(n) {
       let arr_a = new Array(n).fill().map(() => new Array(1));
       let arr_b = new Array(n - 1).fill().map(() => new Array(1));
       let arr_c = new Array(n).fill().map(() => new Array(1));
       let arr_d = new Array(n - 1).fill().map(() => new Array(1));

       let arr_h = new Array(n - 1).fill().map(() => new Array(1));
       let arr_alpha = new Array(n).fill().map(() => new Array(1));
       let arr_l = new Array(n).fill().map(() => new Array(1));
       let arr_mu = new Array(n).fill().map(() => new Array(1));
       let arr_z = new Array(n).fill().map(() => new Array(1));

       for (var i = 0; i < n - 1; i++) {
        arr_h[i] = arr_x[i + 1] - arr_x[i];
       }

       for (var i = 1; i < n - 1; i++) {
        arr_alpha[i] = 3 * ((arr_y[i + 1] - arr_y[i]) / arr_h[i] - (arr_y[i] - arr_y[i - 1]) / arr_h[i - 1]);
       }

       arr_l[0] = 1;
       arr_mu[0] = 0;
       arr_z[0] = 0;

       for (var i = 1; i < n - 1; i++) {
        arr_l[i] = 2 * (arr_x[i + 1] - arr_x[i - 1]) - arr_h[i - 1] * arr_mu[i - 1];
        arr_mu[i] = arr_h[i] / arr_l[i];
        arr_z[i] = (arr_alpha[i] - arr_h[i - 1] * arr_z[i - 1]) / arr_l[i];
       }

       arr_l[n - 1] = 1;
       arr_z[n - 1] = 0;
       arr_c[n - 1] = 0;

       for (var j = n - 2; j >= 0; j--) {
        arr_c[j] = arr_z[j] - arr_mu[j] * arr_c[j + 1];
        arr_b[j] = (arr_y[j + 1] - arr_y[j]) / arr_h[j] - arr_h[j] * (arr_c[j + 1] + 2 * arr_c[j]) / 3;
        arr_d[j] = (arr_c[j + 1] - arr_c[j]) / (3 * arr_h[j]);
        arr_a[j] = arr_y[j];
       }

       for (var i = 0; i < n - 1; i++) {
        for (xi = arr_x[i]; xi < arr_x[i + 1] - 1; xi += 5) {
         yi = arr_a[i] + arr_b[i] * (xi - arr_x[i]) + arr_c[i] * Math.pow((xi - arr_x[i]), 2) + arr_d[i] * Math.pow((xi - arr_x[i]), 3);
			
       if (tip_grafik == 0) {
         canvas.drawImage({
          x: xi,
          y: yi,
          w: 5,
          h: 310 - yi,
          alpha: 127,
          image: n == dney ? 'images/Grafik/line_day.png' : 'images/Grafik/line_night.png'
         })
       }

         canvas.drawLine({
          x1: xi,
          y1: yi,
          x2: xi + 5,
          y2: arr_a[i] + arr_b[i] * (xi + 5 - arr_x[i]) + arr_c[i] * Math.pow((xi + 5 - arr_x[i]), 2) + arr_d[i] * Math.pow((xi + 5 - arr_x[i]), 3),
         // color: n == dney ? 0xff0000 : 0x00eaff//0x009cff  yArrAll.length - 1
          color: n == dney ? 0xff0000 : n == dney-1 ? 0x00eaff : 0x12a2fd//0x009cff
         })


        }
       }

      }
        // end user_functions.js

        let normal_image_img = ''
        let normal_time_hour_min_text_font = ''
        let normal_timerTimeUpdate = undefined;
        let normal_stand_icon_img = ''
        let normal_dow_text_font = ''
        let normal_DOW_Array = ['ПНД', 'ВТР', 'СРД', 'ЧТВ', 'ПТН', 'СБТ', 'ВСК', ];
        let normal_day_text_font = ''
        let normal_battery_current_text_font = ''
        let normal_battery_image_progress_img_level = ''
        let normal_calorie_icon_img = ''
        let normal_analog_clock_time_pointer_hour = ''
        let normal_analog_clock_time_pointer_minute = ''
        let normal_step_pointer_progress_img_pointer = ''
        let normal_analog_clock_pro_second_pointer_img = ''
        let normal_timerUpdateSecSmooth = undefined;
        let lastTime = 0;
        let idle_image_img = ''
        let idle_time_hour_min_text_font = ''
        let idle_timerTimeUpdate = undefined;
        let idle_stand_icon_img = ''
        let idle_dow_text_font = ''
        let idle_DOW_Array = ['ПНД', 'ВТР', 'СРД', 'ЧТВ', 'ПТН', 'СБТ', 'ВСК', ];
        let idle_day_text_font = ''
        let idle_battery_current_text_font = ''
        let idle_battery_image_progress_img_level = ''
        let idle_calorie_icon_img = ''
        let idle_analog_clock_time_pointer_hour = ''
        let idle_analog_clock_time_pointer_minute = ''
        let idle_step_pointer_progress_img_pointer = ''
        let timeSensor = ''


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            // FontName: DSCrystal_mod.ttf; FontSize: 157
            hmUI.createWidget(hmUI.widget.TEXT, {
              x: 464,
              y: 464,
              w: 1920,
              h: 204,
              text_size: 157,
              char_space: 0,
              line_space: 0,
              font: 'fonts/DSCrystal_mod.ttf',
              color: 0xFFFFFFFF,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.BOTTOM,
              text_style: hmUI.text_style.ELLIPSIS,
              text: "0123456789 _-.,:;`'%°\\/",
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // FontName: conthrax_sb.ttf; FontSize: 32; Cache: full
            hmUI.createWidget(hmUI.widget.TEXT, {
              x: 464,
              y: 464,
              w: 38,
              h: 38,
              text_size: 32,
              char_space: 0,
              line_space: 0,
              font: 'fonts/conthrax_sb.ttf',
              color: 0xFFFFFFFF,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.NONE,
              text: "0123456789 ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz АБВГДЕЁЖЗИЙКЛМНОПРСТУФХЦЧШЩЪЫЬЭЮЯабвгдеёжзийклмнопрстуфхцчшщъыьэюя  ҐЄІЇґєії _-.,:;`'%°\\/",
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // FontName: conthrax_sb.ttf; FontSize: 50
            hmUI.createWidget(hmUI.widget.TEXT, {
              x: 464,
              y: 464,
              w: 877,
              h: 72,
              text_size: 50,
              char_space: 0,
              line_space: 0,
              font: 'fonts/conthrax_sb.ttf',
              color: 0xFFFFFFFF,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              text: "0123456789 _-.,:;`'%°\\/",
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // FontName: conthrax_sb.ttf; FontSize: 29
            hmUI.createWidget(hmUI.widget.TEXT, {
              x: 464,
              y: 464,
              w: 510,
              h: 42,
              text_size: 29,
              char_space: 0,
              line_space: 0,
              font: 'fonts/conthrax_sb.ttf',
              color: 0xFFFFFFFF,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              text: "0123456789 _-.,:;`'%°\\/",
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            console.log('user_script_start.js');
            // start user_script_start.js

normal_background_bg = hmUI.createWidget(hmUI.widget.FILL_RECT, {
              x: 0,
              y: 0,
              w: 466,
              h: 466,
              color: color_bg[color],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            // end user_script_start.js

            console.log('Watch_Face.ScreenNormal');

            normal_image_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'bg_0.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            if (!timeSensor) timeSensor = hmSensor.createSensor(hmSensor.id.TIME);
            let screenType = hmSetting.getScreenType();
            normal_time_hour_min_text_font = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 0,
              y: 154,
              w: 466,
              h: 160,
              text_size: 157,
              char_space: 0,
              line_space: 0,
              font: 'fonts/DSCrystal_mod.ttf',
              color: 0xFFFFFFFF,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.BOTTOM,
              text_style: hmUI.text_style.ELLIPSIS,
              // padding: true,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_stand_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'bg.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            timeSensor.addEventListener(timeSensor.event.DAYCHANGE, function() {
              time_update(true);
            });

            normal_dow_text_font = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 0,
              y: 106,
              w: 466,
              h: 50,
              text_size: 32,
              char_space: 0,
              line_space: 0,
              font: 'fonts/conthrax_sb.ttf',
              color: 0xFFFFFFFF,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              // unit_string: ПНД, ВТР, СРД, ЧТВ, ПТН, СБТ, ВСК,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_day_text_font = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 0,
              y: 47,
              w: 466,
              h: 60,
              text_size: 50,
              char_space: 0,
              line_space: 0,
              font: 'fonts/conthrax_sb.ttf',
              color: 0xFFFFFFFF,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              // padding: true,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_current_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 0,
              y: 292,
              w: 466,
              h: 60,
              text_size: 29,
              char_space: 0,
              line_space: 0,
              font: 'fonts/conthrax_sb.ttf',
              color: 0xFFFFFFFF,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.CENTER_V,
              padding: true,
              text_style: hmUI.text_style.ELLIPSIS,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 126,
              y: 360,
              image_array: ["bat_0.png","bat_1.png","bat_2.png","bat_3.png","bat_4.png","bat_5.png","bat_6.png","bat_7.png","bat_8.png","bat_9.png"],
              image_length: 10,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
                
            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 159,
              y: 73,
              src: 'stat_B_off.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 286,
              y: 71,
              src: 'stat_H_on.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_calorie_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'cap_0.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_hour = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              hour_path: 'str_H.png',
              hour_centerX: 233,
              hour_centerY: 233,
              hour_posX: 233,
              hour_posY: 233,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_minute = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              minute_path: 'str_M.png',
              minute_centerX: 233,
              minute_centerY: 233,
              minute_posX: 233,
              minute_posY: 233,
              minute_cover_path: 'cap.png',
              minute_cover_x: 0,
              minute_cover_y: 0,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_pointer_progress_img_pointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
              src: 'str_Step.png',
              center_x: 233,
              center_y: 233,
              x: 18,
              y: 233,
              start_angle: 0,
              end_angle: -300,
              invalid_visible: false,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            const deviceInfo = hmSetting.getDeviceInfo();
            // normal_analog_clock_pro_second_pointer_img = hmUI.createWidget(hmUI.widget.TIME_POINTER_PRO, {
              // src: 'str_S.png',
              // center_x: 233,
              // center_y: 233,
              // x: 18,
              // y: 233,
              // start_angle: 0,
              // end_angle: 360,
              // type: hmUI.data_type.second,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });


            normal_analog_clock_pro_second_pointer_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: deviceInfo.width,
              h: deviceInfo.height,
              pos_x: 233 - 18,
              pos_y: 233 - 233,
              center_x: 233,
              center_y: 233,
              src: 'str_S.png',
              angle: 0,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            function startSecAnim(sec, animDuration) {
              const secAnim = {
                anim_steps: [{
                  anim_rate: 'linear',
                  anim_duration: animDuration,
                  anim_from: sec,
                  anim_to: sec + (360*(animDuration*6/1000))/360,
                  anim_key: 'angle',
                }],
                anim_fps: 15,
                anim_auto_start: 1,
                anim_repeat: 1,
                anim_auto_destroy: 1,
              }
              normal_analog_clock_pro_second_pointer_img.setProperty(hmUI.prop.ANIM, secAnim);
            }
            // normal_analog_clock_pro_smooth_second = hmUI.createWidget(hmUI.widget.SMOOTH_SECOND, {
              // type: 4,
              // fps: 15,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });



            console.log('Watch_Face.ScreenAOD');

            idle_image_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'bg_0.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_time_hour_min_text_font = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 0,
              y: 154,
              w: 466,
              h: 160,
              text_size: 157,
              char_space: 0,
              line_space: 0,
              font: 'fonts/DSCrystal_mod.ttf',
              color: 0xFFFFFFFF,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.BOTTOM,
              text_style: hmUI.text_style.ELLIPSIS,
              // padding: true,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_stand_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'bg.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_dow_text_font = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 0,
              y: 106,
              w: 466,
              h: 50,
              text_size: 32,
              char_space: 0,
              line_space: 0,
              font: 'fonts/conthrax_sb.ttf',
              color: 0xFFFFFFFF,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              // unit_string: ПНД, ВТР, СРД, ЧТВ, ПТН, СБТ, ВСК,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_day_text_font = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 0,
              y: 47,
              w: 466,
              h: 60,
              text_size: 50,
              char_space: 0,
              line_space: 0,
              font: 'fonts/conthrax_sb.ttf',
              color: 0xFFFFFFFF,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              // padding: true,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_battery_current_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 0,
              y: 292,
              w: 466,
              h: 60,
              text_size: 29,
              char_space: 0,
              line_space: 0,
              font: 'fonts/conthrax_sb.ttf',
              color: 0xFFFFFFFF,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.CENTER_V,
              padding: true,
              text_style: hmUI.text_style.ELLIPSIS,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_battery_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 126,
              y: 360,
              image_array: ["bat_0.png","bat_1.png","bat_2.png","bat_3.png","bat_4.png","bat_5.png","bat_6.png","bat_7.png","bat_8.png","bat_9.png"],
              image_length: 10,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_calorie_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'cap_0.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_analog_clock_time_pointer_hour = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              hour_path: 'str_H.png',
              hour_centerX: 233,
              hour_centerY: 233,
              hour_posX: 233,
              hour_posY: 233,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_analog_clock_time_pointer_minute = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              minute_path: 'str_M.png',
              minute_centerX: 233,
              minute_centerY: 233,
              minute_posX: 233,
              minute_posY: 233,
              minute_cover_path: 'cap.png',
              minute_cover_x: 0,
              minute_cover_y: 0,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_step_pointer_progress_img_pointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
              src: 'str_Step.png',
              center_x: 233,
              center_y: 233,
              x: 18,
              y: 233,
              start_angle: 0,
              end_angle: -300,
              invalid_visible: false,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_AOD,
            });

           // console.log('user_script_beforeShortcuts.js');
            // start user_script_beforeShortcuts.js

bg_edit_img = hmUI.createWidget(hmUI.widget.IMG, {
 x: 0,
 y: 0,
 src: 'tap/bg_edit.png',
 show_level: hmUI.show_level.ONLY_EDIT,
});

groupVremya = hmUI.createWidget(hmUI.widget.GROUP, {
 x: 0,
 y: 0,
 w: D_W,
 h: D_H,
}); 


groupTap = hmUI.createWidget(hmUI.widget.GROUP, {
 x: 0,
 y: 0,
 w: D_W,
 h: D_H,
});

i_tap_bg_img = groupTap.createWidget(hmUI.widget.IMG, {
 x: 0,
 y: 0,
 w: D_W,
 h: D_H,
 src: 'tap/i_tap_bg.png',
 show_level: hmUI.show_level.ONLY_NORMAL,
});


Tap_zona_0 = groupTap.createWidget(hmUI.widget.IMG, {
 x: tap_x_y[0][0],
 y: tap_x_y[0][1],
 src: apps[tap_1_select][2], //'tap/i_tap_calendar.png',
 show_level: hmUI.show_level.ONLY_NORMAL,
});

Tap_zona_1 = groupTap.createWidget(hmUI.widget.IMG, {
 x: tap_x_y[1][0],
 y: tap_x_y[1][1],
 src: apps[tap_2_select][2],
 show_level: hmUI.show_level.ONLY_NORMAL,
});

Tap_zona_2 = groupTap.createWidget(hmUI.widget.IMG, {
 x: tap_x_y[2][0],
 y: tap_x_y[2][1],
 src: apps[tap_3_select][2],
 show_level: hmUI.show_level.ONLY_NORMAL,
});

Tap_zona_3 = groupTap.createWidget(hmUI.widget.IMG, {
 x: tap_x_y[3][0],
 y: tap_x_y[3][1],
 src: apps[tap_4_select][2],
 show_level: hmUI.show_level.ONLY_NORMAL,
});

Tap_zona_4 = groupTap.createWidget(hmUI.widget.IMG, {
 x: tap_x_y[4][0],
 y: tap_x_y[4][1],
 src: apps[tap_5_select][2],
 show_level: hmUI.show_level.ONLY_NORMAL,
});

Tap_zona_5 = groupTap.createWidget(hmUI.widget.IMG, {
 x: tap_x_y[5][0],
 y: tap_x_y[5][1],
 src: apps[tap_6_select][2],
 show_level: hmUI.show_level.ONLY_NORMAL,
});


btn_Tap_zona_0 = groupTap.createWidget(hmUI.widget.BUTTON, {
 x: tap_x_y[0][0],
 y: tap_x_y[0][1],
 text: '',
 w: 113,
 h: 113,
 normal_src: '0_Empty.png',
 press_src: '0_Empty.png',
 click_func: () => {
  vibro();
  hmApp.startApp({
   url: apps[tap_1_select][1],
   native: true
  });
 },
 show_level: hmUI.show_level.ONLY_NORMAL,
});


btn_Tap_zona_1 = groupTap.createWidget(hmUI.widget.BUTTON, {
 x: tap_x_y[1][0],
 y: tap_x_y[1][1],
 text: '',
 w: 113,
 h: 113,
 normal_src: '0_Empty.png',
 press_src: '0_Empty.png',
 click_func: () => {
  vibro();
  hmApp.startApp({
   url: apps[tap_2_select][1],
   native: true
  });
 },
 show_level: hmUI.show_level.ONLY_NORMAL,
});

btn_Tap_zona_2 = groupTap.createWidget(hmUI.widget.BUTTON, {
 x: tap_x_y[2][0],
 y: tap_x_y[2][1],
 text: '',
 w: 113,
 h: 113,
 normal_src: '0_Empty.png',
 press_src: '0_Empty.png',
 click_func: () => {
  vibro();
  hmApp.startApp({
   url: apps[tap_3_select][1],
   native: true
  });
 },
 show_level: hmUI.show_level.ONLY_NORMAL,
});

btn_Tap_zona_3 = groupTap.createWidget(hmUI.widget.BUTTON, {
 x: tap_x_y[3][0],
 y: tap_x_y[3][1],
 text: '',
 w: 113,
 h: 113,
 normal_src: '0_Empty.png',
 press_src: '0_Empty.png',
 click_func: () => {
  vibro();
  hmApp.startApp({
   url: apps[tap_4_select][1],
   native: true
  });
 },
 show_level: hmUI.show_level.ONLY_NORMAL,
});

btn_Tap_zona_4 = groupTap.createWidget(hmUI.widget.BUTTON, {
 x: tap_x_y[4][0],
 y: tap_x_y[4][1],
 text: '',
 w: 113,
 h: 113,
 normal_src: '0_Empty.png',
 press_src: '0_Empty.png',
 click_func: () => {
  vibro();
  hmApp.startApp({
   url: apps[tap_5_select][1],
   native: true
  });
 },
 show_level: hmUI.show_level.ONLY_NORMAL,
});

btn_Tap_zona_5 = groupTap.createWidget(hmUI.widget.BUTTON, {
 x: tap_x_y[5][0],
 y: tap_x_y[5][1],
 text: '',
 w: 113,
 h: 113,
 normal_src: '0_Empty.png',
 press_src: '0_Empty.png',
 click_func: () => {
  vibro();
  hmApp.startApp({
   url: apps[tap_6_select][1],
   native: true
  });
 },
 show_level: hmUI.show_level.ONLY_NORMAL,
});


btn_tap = groupVremya.createWidget(hmUI.widget.BUTTON, {
 x: 183,
 y: 0,
 text: '',
 w: 100,
 h: 100,
 normal_src: '0_Empty.png',
 press_src: '0_Empty.png',
 click_func: () => {
  vibro();
  tap_run();
 },
 show_level: hmUI.show_level.ONLY_NORMAL,
});

btn_str = groupVremya.createWidget(hmUI.widget.BUTTON, {
 x: 183, //x кнопки
 y: 183, //y кнопки
 text: '',
 w: 100, //ширина кнопки
 h: 100, //высота кнопки
 normal_src: '0_Empty.png',
 press_src: '0_Empty.png',
 click_func: () => {
  vibro();
  click_Pogoda_on();
 },
 //           longpress_func: () => {
 //            vibro();
 //			   blok_btn_on();
 //           },
 show_level: hmUI.show_level.ONLY_NORMAL,
});

        btn_Activ = groupVremya.createWidget(hmUI.widget.BUTTON, {
         x: 183, //x кнопки
         y: 366, //y кнопки
         text: '',
         w: 100, //ширина кнопки
         h: 100, //высота кнопки
         normal_src: '0_Empty.png',
         press_src: '0_Empty.png',
         click_func: () => {
          vibro();
          click_Activ_on();
         },
         //           longpress_func: () => {
         //            vibro();
         //			   blok_btn_on();
         //           },
         show_level: hmUI.show_level.ONLY_NORMAL,
        });


btn_click_tap_exit = groupTap.createWidget(hmUI.widget.BUTTON, {
 x: 183,
 y: 183,
 text: '',
 w: 100,
 h: 100,
 normal_src: '0_Empty.png',
 press_src: '0_Empty.png',
 click_func: () => {
  vibro();
  tap_zona_exit();
 },
 show_level: hmUI.show_level.ONLY_NORMAL,
});


 
            // end user_script_beforeShortcuts.js

            //start of ignored block
            function time_update(updateHour = false, updateMinute = false) {
              console.log('time_update()');
              let hour = timeSensor.hour;
              let minute = timeSensor.minute;
              let second = timeSensor.second;
              let format_hour = timeSensor.format_hour;

              console.log('hour:min font');
              if (updateMinute) {
                let normal_HourMinStr = format_hour.toString();
                normal_HourMinStr = normal_HourMinStr.padStart(2, '0');
                normal_HourMinStr = normal_HourMinStr + ':' + minute.toString().padStart(2, '0')
                if (!timeSensor.is24Hour) {
                  if (hour > 11) normal_HourMinStr = 'pm ' + normal_HourMinStr
                  else normal_HourMinStr = 'am ' + normal_HourMinStr
                };
                normal_time_hour_min_text_font.setProperty(hmUI.prop.TEXT, normal_HourMinStr );
              };

              console.log('day of week font');
              if (updateHour) {
                let normal_DOW_Str = normal_DOW_Array[timeSensor.week-1];
                normal_dow_text_font.setProperty(hmUI.prop.TEXT, normal_DOW_Str );
              };

              console.log('day font');
              if (updateHour) {
                let normal_dayStr = timeSensor.day.toString();
                normal_dayStr = normal_dayStr.padStart(2, '0');
                normal_day_text_font.setProperty(hmUI.prop.TEXT, normal_dayStr );
              };

              console.log('hour:min font');
              if (updateMinute) {
                let idle_HourMinStr = format_hour.toString();
                idle_HourMinStr = idle_HourMinStr.padStart(2, '0');
                idle_HourMinStr = idle_HourMinStr + ':' + minute.toString().padStart(2, '0')
                if (!timeSensor.is24Hour) {
                  if (hour > 11) idle_HourMinStr = 'pm ' + idle_HourMinStr
                  else idle_HourMinStr = 'am ' + idle_HourMinStr
                };
                idle_time_hour_min_text_font.setProperty(hmUI.prop.TEXT, idle_HourMinStr );
              };

              console.log('day of week font');
              if (updateHour) {
                let idle_DOW_Str = idle_DOW_Array[timeSensor.week-1];
                idle_dow_text_font.setProperty(hmUI.prop.TEXT, idle_DOW_Str );
              };

              console.log('day font');
              if (updateHour) {
                let idle_dayStr = timeSensor.day.toString();
                idle_dayStr = idle_dayStr.padStart(2, '0');
                idle_day_text_font.setProperty(hmUI.prop.TEXT, idle_dayStr );
              };

            };

            //end of ignored block
            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                console.log('resume_call()');
                time_update(true, true);
                if (screenType == hmSetting.screen_type.WATCHFACE) {
                  if (!normal_timerTimeUpdate) {
                    normal_timerTimeUpdate = timer.createTimer(0, 1000, (function (option) {
                      let updateHour = timeSensor.minute == 0;
                      let updateMinute = timeSensor.second < 2;
                      time_update(updateHour, updateMinute);
                    }));  // end timer 
                  };  // end timer check
                };  // end screenType

                let secAngle = 0 + (360*6)*(timeSensor.second + ((timeSensor.utc % 1000) / 1000))/360;
                normal_analog_clock_pro_second_pointer_img.setProperty(hmUI.prop.ANGLE, secAngle);
                if (screenType == hmSetting.screen_type.WATCHFACE) {
                  if (!normal_timerUpdateSecSmooth) {
                    let duration = 0;
                    let animDuration = 5000;
                    if (timeSensor.second > 55) animDuration = 1000*(60.1 - (timeSensor.second - (timeSensor.utc % 1000) / 1000));
                    let diffTime = timeSensor.utc - lastTime;
                    if (diffTime < animDuration) duration = animDuration - diffTime;
                    normal_timerUpdateSecSmooth = timer.createTimer(duration, animDuration, (function (option) {
                      lastTime = timeSensor.utc;
                      secAngle = 0 + (360*6)*(timeSensor.second + ((timeSensor.utc % 1000) / 1000))/360;
                      startSecAnim(secAngle, animDuration);
                    }));  // end timer 
                  };  // end timer check
                };  // end screenType

                if (screenType == hmSetting.screen_type.AOD) {
                  if (!idle_timerTimeUpdate) {
                    idle_timerTimeUpdate = timer.createTimer(0, 1000, (function (option) {
                      let updateHour = timeSensor.minute == 0;
                      let updateMinute = timeSensor.second < 2;
                      time_update(updateHour, updateMinute);
                    }));  // end timer 
                  };  // end timer check
                };  // end screenType


                console.log('resume_call.js');
                // start resume_call.js

//          let current = weatherSensor.current;
//          let curAirIconIndex = weatherSensor.curAirIconIndex;
//
//          let temperature_current_temp = -100;
//          if (weatherSensor.current != undefined && weatherSensor.current != 'undefined') {
//           temperature_current_temp = weatherSensor.current;
//          }; // end currentWeather; 
//
//          let weatherData = weatherSensor.getForecastWeather();
//          let forecastData = weatherData.forecastData;
//
//          normal_city_name_text.setProperty(hmUI.prop.TEXT, weatherData.cityName + " " + temperature_current_temp + "°C");
//          normal_weather_text_font.setProperty(hmUI.prop.TEXT, shotWeaterhNames[curAirIconIndex]);


stopVibro();
updateGrafik();
onDigitalCrown();
//let str_valueStep = 'ШАГИ ' + step.current
//normal_step_current_text_font.setProperty(hmUI.prop.TEXT, str_valueStep );
//idle_step_current_text_font.setProperty(hmUI.prop.TEXT, str_valueStep );
                // end resume_call.js

              }),
              pause_call: (function () {
                console.log('pause_call()');
                if (normal_timerTimeUpdate) {
                  timer.stopTimer(normal_timerTimeUpdate);
                  normal_timerTimeUpdate = undefined;
                }
                if (normal_timerUpdateSecSmooth) {
                  timer.stopTimer(normal_timerUpdateSecSmooth);
                  normal_timerUpdateSecSmooth = undefined;
                }
                if (idle_timerTimeUpdate) {
                  timer.stopTimer(idle_timerTimeUpdate);
                  idle_timerTimeUpdate = undefined;
                }

                console.log('pause_call.js');
                // start pause_call.js

stopVibro();

            groupVremya.setProperty(hmUI.prop.VISIBLE, true);
           groupPogoda.setProperty(hmUI.prop.VISIBLE, false);
            groupTap.setProperty(hmUI.prop.VISIBLE, false);
          groupActiv.setProperty(hmUI.prop.VISIBLE, false);

                // end pause_call.js

              }),
            });

                //dynamic modify end
                
                
      //---------------------------    погода
        groupPogoda = hmUI.createWidget(hmUI.widget.GROUP, {
         x: 0,
         y: 0,
         w: D_W,
         h: D_H,
		show_level: hmUI.show_level.ONLY_NORMAL,
        });

        canvas0 = hmUI.createWidget(hmUI.widget.CANVAS, {
         x: 0,
         y: 0,
         w: 0,
         h: 0,
		//show_level: hmUI.show_level.ONLY_NORMAL,
        });
                
     
        canvas = groupPogoda.createWidget(hmUI.widget.CANVAS, {
         x: 0,
         y: 0,
         w: 466,
         h: 466,
		//show_level: hmUI.show_level.ONLY_NORMAL,
        });

        canvas.setPaint({
         color: 0x00ff00,
         line_width: 4
        })

        normal_weather_text_font = groupPogoda.createWidget(hmUI.widget.TEXT, {
         x: 0,
         y: 0,
         w: (466 - 0 * 2),
         h: (466 - 0 * 2),
         text_size: 24,
         //font: 'fonts/Oswald_Regular.ttf',
         color: 0xffffff,
         //text: "2022/05/29 12:23:59 SAT",
         // align_v: hmUI.align.TOP, //CENTER_V	
         align_h: hmUI.align.CENTER_H, //CENTER_H
         char_space: 0,
         start_angle: -90,
         end_angle: 90,
         unit_type: 0,
         // type: hmUI.data_type.CAL,
         show_level: hmUI.show_level.ONLY_NORMAL,
        })


         normal_city_name_text = groupPogoda.createWidget(hmUI.widget.TEXT, {
         x: 84,
         y: 47 + 5 + 2,
         w: 299,
         h: 32,
         text_size: 28,
         char_space: 0,
         line_space: 0,
         color: 0xFFFFFFFF,
         align_h: hmUI.align.CENTER_H,
         align_v: hmUI.align.CENTER_V,
         text_style: hmUI.text_style.NONE,
         show_level: hmUI.show_level.ONLY_NORMAL,
        });


        groupPogoda.createWidget(hmUI.widget.TEXT_FONT, {
         x: 0,
         y: 0,
         w: (466 - 0 * 2),
         h: (466 - 0 * 2),
         text_size: 24,
         //font: 'fonts/Oswald_Regular.ttf',
         color: 0xffffff,
         // text: "2022/05/29 12:23:59 SAT",
         // align_v: hmUI.align.TOP, //CENTER_V	
         align_h: hmUI.align.CENTER_H, //CENTER_H
         char_space: 0,
         start_angle: -180,
         end_angle: 0,
         unit_type: 0,
         type: hmUI.data_type.SUN_RISE,
         show_level: hmUI.show_level.ONLY_NORMAL,
        })

        groupPogoda.createWidget(hmUI.widget.TEXT_FONT, {
         x: 0,
         y: 0,
         w: (466 - 0 * 2),
         h: (466 - 0 * 2),
         text_size: 24,
         //font: 'fonts/Oswald_Regular.ttf',
         color: 0xffffff,
         // text: "2022/05/29 12:23:59 SAT",
         // align_v: hmUI.align.TOP, //CENTER_V	
         align_h: hmUI.align.CENTER_H, //CENTER_H
         char_space: 0,
         start_angle: 0,
         end_angle: 180,
         unit_type: 0,
         type: hmUI.data_type.SUN_SET,
         show_level: hmUI.show_level.ONLY_NORMAL,
        })


        groupPogoda.createWidget(hmUI.widget.IMG, {
         x: 19 + 12,
         y: 232 - 17,
         src: ROOTPATH + 'Grafik/ic_activ/ic_vos.png',
         show_level: hmUI.show_level.ONLY_NORMAL,
        });

        groupPogoda.createWidget(hmUI.widget.IMG, {
         x: 413 - 12,
         y: 232 - 17,
         src: ROOTPATH + 'Grafik/ic_activ/ic_zak.png',
         show_level: hmUI.show_level.ONLY_NORMAL,
        });

        groupPogoda.createWidget(hmUI.widget.IMG, {
         x: 177,
         y: 351,
         src: ROOTPATH + 'Grafik/ic_activ/bg_wind.png',
         show_level: hmUI.show_level.ONLY_NORMAL,
        });

        groupPogoda.createWidget(hmUI.widget.IMG_LEVEL, {
         x: 175,
         y: 351,
         image_array: [ROOTPATH + "Grafik/ic_activ/wind_0.png", ROOTPATH + "Grafik/ic_activ/wind_1.png", ROOTPATH + "Grafik/ic_activ/wind_2.png", ROOTPATH + "Grafik/ic_activ/wind_3.png", ROOTPATH + "Grafik/ic_activ/wind_4.png", ROOTPATH + "Grafik/ic_activ/wind_5.png", ROOTPATH + "Grafik/ic_activ/wind_6.png", ROOTPATH + "Grafik/ic_activ/wind_7.png"],
         image_length: 8,
         type: hmUI.data_type.WIND_DIRECTION,
         show_level: hmUI.show_level.ONLY_NORMAL,
        });

        groupPogoda.createWidget(hmUI.widget.TEXT_FONT, {
         x: 0,
         y: 370,
         w: 466,
         h: 40,
         text_size: 35,
         char_space: 0,
         line_space: 0,
         color: 0xFFFFFFFF,
         align_h: hmUI.align.CENTER_H,
         align_v: hmUI.align.CENTER_V,
         unit_type: 1,
         text_style: hmUI.text_style.ELLIPSIS,
         type: hmUI.data_type.WIND,
         show_level: hmUI.show_level.ONLY_NORMAL,
        });

        //            groupPogoda.createWidget(hmUI.widget.IMG, {
        //              x: 303,
        //              y: 396,
        //              src: ROOTPATH + 'Grafik/ic_activ/ic_davl.png',
        //              show_level: hmUI.show_level.ONLY_NORMAL,
        //            });

        groupPogoda.createWidget(hmUI.widget.IMG, {
         x: 318,
         y: 370,
         src: ROOTPATH + 'Grafik/ic_activ/ic_davl_txt.png',
         show_level: hmUI.show_level.ONLY_NORMAL,
        });

        groupPogoda.createWidget(hmUI.widget.TEXT_FONT, {
         x: 219,
         y: 22 + 7,
         w: 150,
         h: 30,
         text_size: 24,
         char_space: 0,
         line_space: 0,
         color: 0xFFFFFFFF,
         align_h: hmUI.align.LEFT,
         align_v: hmUI.align.CENTER_V,
         text_style: hmUI.text_style.ELLIPSIS,
         type: hmUI.data_type.ALTITUDE,
         show_level: hmUI.show_level.ONLY_NORMAL,
        });

        groupPogoda.createWidget(hmUI.widget.TEXT_FONT, {
         x: 271 - 14,
         y: 353,
         w: 150,
         h: 40,
         text_size: 35,
         char_space: 0,
         line_space: 0,
         color: 0xFFFFFFFF,
         align_h: hmUI.align.CENTER_H,
         align_v: hmUI.align.CENTER_V,
         text_style: hmUI.text_style.ELLIPSIS,
         type: hmUI.data_type.ALTIMETER,
         show_level: hmUI.show_level.ONLY_NORMAL,
        });

        groupPogoda.createWidget(hmUI.widget.IMG, {
         x: 179,
         y: 27 + 5,
         src: ROOTPATH + 'Grafik/ic_activ/ic_visota.png',
         show_level: hmUI.show_level.ONLY_NORMAL,
        });

        //           groupPogoda.createWidget(hmUI.widget.IMG, {
        //              x: 132,
        //              y: 398,
        //              src: ROOTPATH + 'Grafik/ic_activ/ic_vlag.png',
        //              show_level: hmUI.show_level.ONLY_NORMAL,
        //            });

        groupPogoda.createWidget(hmUI.widget.IMG, {
         x: 61,
         y: 369,
         src: ROOTPATH + 'Grafik/ic_activ/ic_vlag_txt.png',
         show_level: hmUI.show_level.ONLY_NORMAL,
        });

        groupPogoda.createWidget(hmUI.widget.TEXT_FONT, {
         x: 49 + 14,
         y: 353,
         w: 150,
         h: 40,
         text_size: 35,
         char_space: 0,
         line_space: 0,
         color: 0xFFFFFFFF,
         align_h: hmUI.align.CENTER_H,
         align_v: hmUI.align.CENTER_V,
         unit_type: 1,
         text_style: hmUI.text_style.ELLIPSIS,
         type: hmUI.data_type.HUMIDITY,
         show_level: hmUI.show_level.ONLY_NORMAL,
        });


        for (var i = 0; i < dney; i++) {
         week_text[i] = groupPogoda.createWidget(hmUI.widget.TEXT, {
          x: x0 - 3 - 23 + i * 46 * 1.0, //,107 + i * 45 * 1.02,
          y: 295 - 1 + 2, //- 21
          w: 50,
          h: 50,
          char_space: 0, //-1
          line_space: 0,
          color: "0xFFffffff",
          text: week_array[i],
          text_size: 22,
          text_style: hmUI.text_style.NONE,
          align_h: hmUI.align.CENTER_H,
          align_v: hmUI.align.CENTER_V,
          show_level: hmUI.show_level.ONLY_NORMAL
         });
         // hmUI.deleteWidget(data_text[i]);
         data_text[i] = groupPogoda.createWidget(hmUI.widget.TEXT, {
          x: x0 - 3 - 23 + i * 46 * 1.0, //,107 + i * 45 * 1.02,
          y: 295 - 1 + 2 + 20, //- 21
          w: 50,
          h: 50,

          char_space: 0, //-1
          line_space: 0,
          color: "0xFFffffff",
          text: 31,
          text_size: 22,
          text_style: hmUI.text_style.NONE,
          align_h: hmUI.align.CENTER_H,
          align_v: hmUI.align.CENTER_V,
          show_level: hmUI.show_level.ONLY_NORMAL
         });

         weather_ic[i] = groupPogoda.createWidget(hmUI.widget.IMG, {
          x: x0 - 23 + i * shag,
          y: 78 + 10, //- 10
          w: 40,
          h: 40,
          // src: weatherArray[i],
          shortcut: true,
          show_level: hmUI.show_level.ONLY_NORMAL,
         });

         DigDay[i] = groupPogoda.createWidget(hmUI.widget.TEXT);
         if (i < dney - 1) DigNight[i] = groupPogoda.createWidget(hmUI.widget.TEXT);

        }


        btn_Pogoda_off = groupPogoda.createWidget(hmUI.widget.BUTTON, {
         x: 183, //x кнопки
         y: 183, //y кнопки
         text: '',
         w: 100, //ширина кнопки
         h: 100, //высота кнопки
         normal_src: '0_Empty.png',
         press_src: 'press_100.png',
         click_func: () => {
          vibro(); //имя вызываемой функции
          click_Pogoda_off();
         },
         //           longpress_func: () => {
         //            vibro();
         //			   blok_btn_off();
         //           },
         show_level: hmUI.show_level.ONLY_NORMAL,
        });

        btn_tip_grafik = groupPogoda.createWidget(hmUI.widget.BUTTON, {
         x: 366, //x кнопки
         y: 183, //y кнопки
         text: '',
         w: 100, //ширина кнопки
         h: 100, //высота кнопки
         normal_src: '0_Empty.png',
         press_src: 'press_100.png',
         click_func: () => {
          vibro(); //имя вызываемой функции
          click_tip_grafik();
         },
         //           longpress_func: () => {
         //            vibro();
         //			   blok_btn_off();
         //           },
         show_level: hmUI.show_level.ONLY_NORMAL,
        });

        groupPogoda.createWidget(hmUI.widget.BUTTON, {
         x: 183,
         y: 366,
         w: 100,
         h: 100,
         text: '',
         normal_src: 'blank.png',
         press_src: 'blank.png',
         click_func: () => {
          hmApp.startApp({
           appid: 1051195,
           url: 'page/index',
           params: {
            from_wf: true,
           }

          });
         },
        });

        groupActiv = hmUI.createWidget(hmUI.widget.GROUP, {
         x: 0,
         y: 0,
         w: D_W,
         h: D_H,
        });

        groupActiv.createWidget(hmUI.widget.FILL_RECT, {
         x: 0,
         y: 0,
         w: 466,
         h: 466,
         color: 0x000000,
         show_level: hmUI.show_level.ONLY_NORMAL,
        });


       for (var i = 0; i < activ_arr_left.length; i++) {
         app_activ_txt_left[i] = groupActiv.createWidget(hmUI.widget.TEXT, {
          x: 65-50,
          y: 34 + 68 * i + 37-10,
          w: 150+50,
          h: 50,
          text: activ_arr_left[i][0],
          text_size: 27,
          char_space: 0,
          line_space: 0,
          color: 0xb4b4b4,
          //font: 'fonts/perfoc_bold.ttf',
          align_h: hmUI.align.RIGHT,
          align_v: hmUI.align.CENTER_V,
          text_style: hmUI.text_style.ELLIPSIS,
          show_level: hmUI.show_level.ONLY_NORMAL,
         });

         app_activ_left[i] = groupActiv.createWidget(hmUI.widget.TEXT_FONT, {
          x: 65,
          y: 40 + 68 * i-10,
          w: 150,
          h: 50,
          text_size: 40,
          char_space: 0,
          line_space: 0,
          color: 0xFFFFFFFF,
		padding: activ_arr_left[i][2],
          //font: 'fonts/perfoc_bold.ttf',
          align_h: hmUI.align.RIGHT,
          align_v: hmUI.align.CENTER_V,
          text_style: hmUI.text_style.ELLIPSIS,
          type: activ_arr_left[i][1],
          show_level: hmUI.show_level.ONLY_NORMAL,
         });
        }

         for (var i = 0; i < activ_arr_right.length; i++) {
         app_activ_txt_right[i] = groupActiv.createWidget(hmUI.widget.TEXT, {
          x: 248,
          y: 34 + 68 * i + 37-10,
          w: 150,
          h: 50,
          text: activ_arr_right[i][0],
          text_size: 27,
          char_space: 0,
          line_space: 0,
          color: 0xb4b4b4,
          //font: 'fonts/perfoc_bold.ttf',
          align_h: hmUI.align.LEFT,
          align_v: hmUI.align.CENTER_V,
          text_style: hmUI.text_style.ELLIPSIS,
          show_level: hmUI.show_level.ONLY_NORMAL,
         });

         app_activ_right[i] = groupActiv.createWidget(hmUI.widget.TEXT_FONT, {
          x: 248,
          y: 40 + 68 * i-10,
          w: 150,
          h: 50,
          text_size: 40,
          char_space: 0,
          line_space: 0,
          color: 0xFFFFFFFF,
		padding: activ_arr_right[i][2],
		//font: 'fonts/perfoc_bold.ttf',
          align_h: hmUI.align.LEFT,
          align_v: hmUI.align.CENTER_V,
          text_style: hmUI.text_style.ELLIPSIS,
          type: activ_arr_right[i][1],
          show_level: hmUI.show_level.ONLY_NORMAL,
         });
        }

        btn_Activ_off = groupActiv.createWidget(hmUI.widget.BUTTON, {
         x: 183, //x кнопки
         y: 366, //y кнопки
         text: '',
         w: 100, //ширина кнопки
         h: 100, //высота кнопки
         normal_src: '0_Empty.png',
         press_src: 'press_100.png',
         click_func: () => {
          vibro(); //имя вызываемой функции
          click_Activ_off();
         },
         show_level: hmUI.show_level.ONLY_NORMAL,
        });


                
                
groupVremya.setProperty(hmUI.prop.VISIBLE, true);
groupTap.setProperty(hmUI.prop.VISIBLE, false);
groupPogoda.setProperty(hmUI.prop.VISIBLE, false);
groupActiv.setProperty(hmUI.prop.VISIBLE, false);                  
                
                
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}