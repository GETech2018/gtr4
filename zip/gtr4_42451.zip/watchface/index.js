﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        const logger = Logger.getLogger('watchface_SashaCX75');
        //end of ignored block

        //dynamic modify start

        
        console.log('user_functions.js');
        // start user_functions.js


let bg_list = [
    'bg_1.png',
    'bg_2.png',
    'bg_3.png',
    'bg_4.png',
    'bg_5.png',
  
    
];

let crownSensitivity = 70;		// уровень чувствительности колесика
let bg_index = 0;
let degreeSum = 0;

function onDigitalCrown() {
    hmApp.registerSpinEvent(function (key, degree) {
            if (key === hmApp.key.HOME) {
                degreeSum += degree;
                if (Math.abs(degreeSum) > crownSensitivity){
                    let step = degreeSum < 0 ? -1 : 1;
                    bg_index += step;
                    bg_index = bg_index < 0 ? bg_list.length + bg_index : bg_index % bg_list.length;
                    degreeSum = 0;
                    
                    normal_background_bg_img.setProperty(hmUI.prop.SRC, bg_list[bg_index]);
                    hmUI.showToast({text: "<Цвет> " + parseInt(bg_index+1) });
                }
            }
        }
    ) // crown
}


        // end user_functions.js

        let normal_background_bg_img = ''
        let normal_image_img = ''
        let normal_system_disconnect_img = ''
        let normal_system_clock_img = ''
        let normal_day_text_font = ''
        let normal_month_name_font = ''
        let normal_Month_Array = ['Янв', 'Фев', 'Мрт', 'Апр', 'Май', 'Июн', 'Июл', 'Авг', 'Сен', 'Окт', 'Ноя', 'Дек', ];
        let normal_dow_text_font = ''
        let normal_DOW_Array = ['Пнд', 'Втр', 'Срд', 'Чтв', 'Птн', 'Сб', 'Вск'];
        let normal_battery_pointer_progress_img_pointer = ''
        let normal_battery_current_text_font = ''
        let normal_battery_image_progress_img_level = ''
        let normal_step_pointer_progress_img_pointer = ''
        let normal_step_current_text_font = ''
        let normal_step_image_progress_img_level = ''
        let normal_sunrise_TextRotate = new Array(5);
        let normal_sunrise_TextRotate_ASCIIARRAY = new Array(10);
        let normal_sunrise_TextRotate_img_width = 17;
        let normal_sunrise_TextRotate_dot_width = 12;
        let normal_sunrise_TextRotate_error_img_width = 12;
        let normal_sunset_TextRotate = new Array(5);
        let normal_sunset_TextRotate_ASCIIARRAY = new Array(10);
        let normal_sunset_TextRotate_img_width = 17;
        let normal_sunset_TextRotate_dot_width = 12;
        let normal_sunset_TextRotate_error_img_width = 12;
        let normal_city_name_text = ''
        let normal_weather_image_progress_img_level = ''
        let normal_temperature_current_text_font = ''
        let normal_pai_icon_img = ''
        let normal_time_hour_text_font = ''
        let normal_timerTimeUpdate = undefined;
        let normal_time_minute_text_font = ''
        let normal_analog_clock_pro_second_pointer_img = ''
        let normal_timerUpdateSecSmooth = undefined;
        let idle_background_bg_img = ''
        let idle_image_img = ''
        let idle_system_disconnect_img = ''
        let idle_system_clock_img = ''
        let idle_day_text_font = ''
        let idle_month_name_font = ''
        let idle_Month_Array = ['Янв', 'Фев', 'Мрт', 'Апр', 'Май', 'Июн', 'Июл', 'Авг', 'Сен', 'Окт', 'Ноя', 'Дек', ];
        let idle_dow_text_font = ''
        let idle_DOW_Array = ['Пнд', 'Втр', 'Срд', 'Чтв', 'Птн', 'Сб', 'Вск'];
        let idle_battery_pointer_progress_img_pointer = ''
        let idle_battery_current_text_font = ''
        let idle_battery_image_progress_img_level = ''
        let idle_step_pointer_progress_img_pointer = ''
        let idle_step_current_text_font = ''
        let idle_step_image_progress_img_level = ''
        let idle_sunrise_TextRotate = new Array(5);
        let idle_sunrise_TextRotate_ASCIIARRAY = new Array(10);
        let idle_sunrise_TextRotate_img_width = 17;
        let idle_sunrise_TextRotate_dot_width = 12;
        let idle_sunrise_TextRotate_error_img_width = 12;
        let idle_sunset_TextRotate = new Array(5);
        let idle_sunset_TextRotate_ASCIIARRAY = new Array(10);
        let idle_sunset_TextRotate_img_width = 17;
        let idle_sunset_TextRotate_dot_width = 12;
        let idle_sunset_TextRotate_error_img_width = 12;
        let idle_city_name_text = ''
        let idle_weather_image_progress_img_level = ''
        let idle_temperature_current_text_font = ''
        let idle_pai_icon_img = ''
        let idle_time_hour_text_font = ''
        let idle_timerTimeUpdate = undefined;
        let idle_time_minute_text_font = ''
        let idle_analog_clock_pro_second_pointer_img = ''
        let idle_timerUpdateSecSmooth = undefined;
        let Button_1 = ''
        let Button_2 = ''
        let Button_3 = ''
        let Button_4 = ''
        let Button_5 = ''
        let Button_6 = ''
        let timeSensor = ''


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            // FontName: wfs_rajdhani_semibold_0aaeba4b_c196_4d60_9299_2617721eaaa3.ttf; FontSize: 35
            hmUI.createWidget(hmUI.widget.TEXT, {
              x: 464,
              y: 464,
              w: 415,
              h: 54,
              text_size: 35,
              char_space: 0,
              line_space: 0,
              font: 'fonts/wfs_rajdhani_semibold_0aaeba4b_c196_4d60_9299_2617721eaaa3.ttf',
              color: 0xFFFFFFFF,
              align_h: hmUI.align.LEFT,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              text: "0123456789 _-.,:;`'%°\\/",
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // FontName: wfs_teko_regular_42cb0dd3_aad7_462e_a673_daedf52bb938.ttf; FontSize: 19; Cache: full
            hmUI.createWidget(hmUI.widget.TEXT, {
              x: 464,
              y: 464,
              w: 22,
              h: 22,
              text_size: 19,
              char_space: 0,
              line_space: 0,
              font: 'fonts/wfs_teko_regular_42cb0dd3_aad7_462e_a673_daedf52bb938.ttf',
              color: 0xFFFFFFFF,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.NONE,
              text: "0123456789 ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz АБВГДЕЁЖЗИЙКЛМНОПРСТУФХЦЧШЩЪЫЬЭЮЯабвгдеёжзийклмнопрстуфхцчшщъыьэюя  ҐЄІЇґєії _-.,:;`'%°\\/",
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // FontName: wfs_teko_regular_42cb0dd3_aad7_462e_a673_daedf52bb938.ttf; FontSize: 21; Cache: full
            hmUI.createWidget(hmUI.widget.TEXT, {
              x: 464,
              y: 464,
              w: 25,
              h: 25,
              text_size: 21,
              char_space: 0,
              line_space: 0,
              font: 'fonts/wfs_teko_regular_42cb0dd3_aad7_462e_a673_daedf52bb938.ttf',
              color: 0xFFFFFFFF,
              align_h: hmUI.align.LEFT,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.NONE,
              text: "0123456789 ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz АБВГДЕЁЖЗИЙКЛМНОПРСТУФХЦЧШЩЪЫЬЭЮЯабвгдеёжзийклмнопрстуфхцчшщъыьэюя  ҐЄІЇґєії _-.,:;`'%°\\/",
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // FontName: wfs_rajdhani_semibold_0aaeba4b_c196_4d60_9299_2617721eaaa3.ttf; FontSize: 26
            hmUI.createWidget(hmUI.widget.TEXT, {
              x: 464,
              y: 464,
              w: 310,
              h: 39,
              text_size: 26,
              char_space: 0,
              line_space: 0,
              font: 'fonts/wfs_rajdhani_semibold_0aaeba4b_c196_4d60_9299_2617721eaaa3.ttf',
              color: 0xFF858585,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              text: "0123456789 _-.,:;`'%°\\/",
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // FontName: wfs_rajdhani_semibold_0aaeba4b_c196_4d60_9299_2617721eaaa3.ttf; FontSize: 23; Cache: full
            hmUI.createWidget(hmUI.widget.TEXT, {
              x: 464,
              y: 464,
              w: 27,
              h: 27,
              text_size: 23,
              char_space: 0,
              line_space: 0,
              font: 'fonts/wfs_rajdhani_semibold_0aaeba4b_c196_4d60_9299_2617721eaaa3.ttf',
              color: 0xFF0C0C0C,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.NONE,
              text: "0123456789 ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz АБВГДЕЁЖЗИЙКЛМНОПРСТУФХЦЧШЩЪЫЬЭЮЯабвгдеёжзийклмнопрстуфхцчшщъыьэюя  ҐЄІЇґєії _-.,:;`'%°\\/",
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // FontName: wfs_rajdhani_semibold_0aaeba4b_c196_4d60_9299_2617721eaaa3.ttf; FontSize: 31
            hmUI.createWidget(hmUI.widget.TEXT, {
              x: 464,
              y: 464,
              w: 376,
              h: 49,
              text_size: 31,
              char_space: 0,
              line_space: 0,
              font: 'fonts/wfs_rajdhani_semibold_0aaeba4b_c196_4d60_9299_2617721eaaa3.ttf',
              color: 0xFFFFFFFF,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              text: "0123456789 _-.,:;`'%°\\/",
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // FontName: wfs_teko_regular_42cb0dd3_aad7_462e_a673_daedf52bb938.ttf; FontSize: 91
            hmUI.createWidget(hmUI.widget.TEXT, {
              x: 464,
              y: 464,
              w: 932,
              h: 158,
              text_size: 91,
              char_space: 0,
              line_space: 0,
              font: 'fonts/wfs_teko_regular_42cb0dd3_aad7_462e_a673_daedf52bb938.ttf',
              color: 0xFF000000,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              text: "0123456789 _-.,:;`'%°\\/",
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            console.log('Watch_Face.ScreenNormal');
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 466,
              h: 466,
              src: 'bg_1.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_image_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'mask_1.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 343,
              y: 333,
              src: 'y1.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 223,
              y: 420,
              src: 'y2.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            if (!timeSensor) timeSensor = hmSensor.createSensor(hmSensor.id.TIME);
            timeSensor.addEventListener(timeSensor.event.DAYCHANGE, function() {
              time_update(true);
            });

            normal_day_text_font = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 218,
              y: 335,
              w: 146,
              h: 36,
              text_size: 35,
              char_space: 0,
              line_space: 0,
              font: 'fonts/wfs_rajdhani_semibold_0aaeba4b_c196_4d60_9299_2617721eaaa3.ttf',
              color: 0xFFFFFFFF,
              align_h: hmUI.align.LEFT,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_month_name_font = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 199,
              y: 336,
              w: 146,
              h: 29,
              text_size: 19,
              char_space: 0,
              line_space: 0,
              font: 'fonts/wfs_teko_regular_42cb0dd3_aad7_462e_a673_daedf52bb938.ttf',
              color: 0xFFFFFFFF,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              // unit_string: Янв, Фев, Мрт, Апр, Май, Июн, Июл, Авг, Сен, Окт, Ноя, Дек,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_dow_text_font = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 171,
              y: 317,
              w: 146,
              h: 29,
              text_size: 21,
              char_space: 0,
              line_space: 0,
              font: 'fonts/wfs_teko_regular_42cb0dd3_aad7_462e_a673_daedf52bb938.ttf',
              color: 0xFFFFFFFF,
              align_h: hmUI.align.LEFT,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              // unit_string: Пнд, Втр, Срд, Чтв, Птн, Сб, Вск,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_pointer_progress_img_pointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
              src: 'uk_2.png',
              center_x: 327,
              center_y: 231,
              x: 49,
              y: 49,
              start_angle: -138,
              end_angle: 130,
              invalid_visible: false,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_current_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 262,
              y: 261,
              w: 146,
              h: 29,
              text_size: 26,
              char_space: 0,
              line_space: 0,
              font: 'fonts/wfs_rajdhani_semibold_0aaeba4b_c196_4d60_9299_2617721eaaa3.ttf',
              color: 0xFF858585,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.TOP,
              unit_type: 1,
              text_style: hmUI.text_style.ELLIPSIS,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 0,
              y: 0,
              image_array: ["zr_0.png","zr_1.png","zr_2.png","zr_3.png","zr_4.png","zr_5.png","zr_6.png","zr_7.png","zr_8.png","zr_9.png","zr_10.png"],
              image_length: 11,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_pointer_progress_img_pointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
              src: 'uk_2.png',
              center_x: 135,
              center_y: 233,
              x: 50,
              y: 49,
              start_angle: -130,
              end_angle: 136,
              invalid_visible: false,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 63,
              y: 261,
              w: 146,
              h: 29,
              text_size: 26,
              char_space: 0,
              line_space: 0,
              font: 'fonts/wfs_rajdhani_semibold_0aaeba4b_c196_4d60_9299_2617721eaaa3.ttf',
              color: 0xFF868686,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 0,
              y: 0,
              image_array: ["zrs_1.png","zrs_2.png","zrs_3.png","zrs_4.png","zrs_5.png","zrs_6.png","zrs_7.png","zrs_8.png","zrs_9.png","zrs_10.png"],
              image_length: 10,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_sunrise_text_rotate_img = hmUI.createWidget(hmUI.widget.Text_Rotate, {
              // x: 368,
              // y: 79,
              // font_array: ["41.png","42.png","43.png","44.png","45.png","46.png","47.png","48.png","49.png","50.png"],
              // zero: true,
              // unit_in_alignment: false,
              // h_space: -4,
              // angle: 60,
              // negative_image: '51.png',
              // invalid_image: '51.png',
              // dot_image: '51.png',
              // align_h: hmUI.align.LEFT,
              // type: hmUI.data_type.SUN_RISE,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_sunrise_TextRotate_ASCIIARRAY[0] = '41.png';  // set of images with numbers
            normal_sunrise_TextRotate_ASCIIARRAY[1] = '42.png';  // set of images with numbers
            normal_sunrise_TextRotate_ASCIIARRAY[2] = '43.png';  // set of images with numbers
            normal_sunrise_TextRotate_ASCIIARRAY[3] = '44.png';  // set of images with numbers
            normal_sunrise_TextRotate_ASCIIARRAY[4] = '45.png';  // set of images with numbers
            normal_sunrise_TextRotate_ASCIIARRAY[5] = '46.png';  // set of images with numbers
            normal_sunrise_TextRotate_ASCIIARRAY[6] = '47.png';  // set of images with numbers
            normal_sunrise_TextRotate_ASCIIARRAY[7] = '48.png';  // set of images with numbers
            normal_sunrise_TextRotate_ASCIIARRAY[8] = '49.png';  // set of images with numbers
            normal_sunrise_TextRotate_ASCIIARRAY[9] = '50.png';  // set of images with numbers

            //start of ignored block
            for (let i = 0; i < 5; i++) {
              normal_sunrise_TextRotate[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 466,
                h: 466,
                center_x: 368,
                center_y: 79,
                pos_x: 368,
                pos_y: 79,
                angle: 60,
                src: '41.png',
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
              normal_sunrise_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
            };
            //end of ignored block
            const weatherSensor = hmSensor.createSensor(hmSensor.id.WEATHER);

            // normal_sunset_text_rotate_img = hmUI.createWidget(hmUI.widget.Text_Rotate, {
              // x: 49,
              // y: 143,
              // font_array: ["41.png","42.png","43.png","44.png","45.png","46.png","47.png","48.png","49.png","50.png"],
              // zero: true,
              // unit_in_alignment: false,
              // h_space: -4,
              // angle: -60,
              // negative_image: '51.png',
              // invalid_image: '51.png',
              // dot_image: '51.png',
              // align_h: hmUI.align.LEFT,
              // type: hmUI.data_type.SUN_SET,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_sunset_TextRotate_ASCIIARRAY[0] = '41.png';  // set of images with numbers
            normal_sunset_TextRotate_ASCIIARRAY[1] = '42.png';  // set of images with numbers
            normal_sunset_TextRotate_ASCIIARRAY[2] = '43.png';  // set of images with numbers
            normal_sunset_TextRotate_ASCIIARRAY[3] = '44.png';  // set of images with numbers
            normal_sunset_TextRotate_ASCIIARRAY[4] = '45.png';  // set of images with numbers
            normal_sunset_TextRotate_ASCIIARRAY[5] = '46.png';  // set of images with numbers
            normal_sunset_TextRotate_ASCIIARRAY[6] = '47.png';  // set of images with numbers
            normal_sunset_TextRotate_ASCIIARRAY[7] = '48.png';  // set of images with numbers
            normal_sunset_TextRotate_ASCIIARRAY[8] = '49.png';  // set of images with numbers
            normal_sunset_TextRotate_ASCIIARRAY[9] = '50.png';  // set of images with numbers

            //start of ignored block
            for (let i = 0; i < 5; i++) {
              normal_sunset_TextRotate[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 466,
                h: 466,
                center_x: 49,
                center_y: 143,
                pos_x: 49,
                pos_y: 143,
                angle: -60,
                src: '41.png',
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
              normal_sunset_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
            };
            //end of ignored block

            normal_city_name_text = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 161,
              y: 53,
              w: 146,
              h: 29,
              text_size: 23,
              char_space: 0,
              line_space: 0,
              font: 'fonts/wfs_rajdhani_semibold_0aaeba4b_c196_4d60_9299_2617721eaaa3.ttf',
              color: 0xFF0C0C0C,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.NONE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 96,
              y: 318,
              image_array: ["85.png","86.png","87.png","88.png","89.png","90.png","91.png","92.png","93.png","94.png","95.png","96.png","97.png","98.png","99.png","100.png","101.png","102.png","103.png","104.png","105.png","106.png","107.png","108.png","109.png","110.png","111.png","112.png","113.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 83,
              y: 359,
              w: 146,
              h: 29,
              text_size: 31,
              char_space: 0,
              line_space: 0,
              font: 'fonts/wfs_rajdhani_semibold_0aaeba4b_c196_4d60_9299_2617721eaaa3.ttf',
              color: 0xFFFFFFFF,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.TOP,
              unit_type: 1,
              text_style: hmUI.text_style.ELLIPSIS,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_pai_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 226,
              y: 59,
              src: 'rz_1.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            let screenType = hmSetting.getScreenType();
            normal_time_hour_text_font = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 117,
              y: 61,
              w: 146,
              h: 100,
              text_size: 91,
              char_space: 0,
              line_space: 0,
              font: 'fonts/wfs_teko_regular_42cb0dd3_aad7_462e_a673_daedf52bb938.ttf',
              color: 0xFF000000,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              // padding: true,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_time_minute_text_font = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 200,
              y: 61,
              w: 146,
              h: 89,
              text_size: 91,
              char_space: 0,
              line_space: 0,
              font: 'fonts/wfs_teko_regular_42cb0dd3_aad7_462e_a673_daedf52bb938.ttf',
              color: 0xFF181818,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              // padding: true,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            const deviceInfo = hmSetting.getDeviceInfo();
            // normal_analog_clock_pro_second_pointer_img = hmUI.createWidget(hmUI.widget.TIME_POINTER_PRO, {
              // src: 'sec_1.png',
              // center_x: 235,
              // center_y: 189,
              // x: 48,
              // y: 49,
              // start_angle: 0,
              // end_angle: 360,
              // type: hmUI.data_type.second,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });


            normal_analog_clock_pro_second_pointer_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: deviceInfo.width,
              h: deviceInfo.height,
              pos_x: 235 - 48,
              pos_y: 189 - 49,
              center_x: 235,
              center_y: 189,
              src: 'sec_1.png',
              angle: 0,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_analog_clock_pro_smooth_second = hmUI.createWidget(hmUI.widget.SMOOTH_SECOND, {
              // type: 2,
              // fps: 15,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });



            console.log('Watch_Face.ScreenAOD');
            idle_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 466,
              h: 466,
              src: 'bg_5.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_image_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'mask_1.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 343,
              y: 333,
              src: 'y1.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 223,
              y: 420,
              src: 'y2.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_day_text_font = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 218,
              y: 335,
              w: 146,
              h: 36,
              text_size: 35,
              char_space: 0,
              line_space: 0,
              font: 'fonts/wfs_rajdhani_semibold_0aaeba4b_c196_4d60_9299_2617721eaaa3.ttf',
              color: 0xFFFFFFFF,
              align_h: hmUI.align.LEFT,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_month_name_font = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 199,
              y: 336,
              w: 146,
              h: 29,
              text_size: 19,
              char_space: 0,
              line_space: 0,
              font: 'fonts/wfs_teko_regular_42cb0dd3_aad7_462e_a673_daedf52bb938.ttf',
              color: 0xFFFFFFFF,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              // unit_string: Янв, Фев, Мрт, Апр, Май, Июн, Июл, Авг, Сен, Окт, Ноя, Дек,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_dow_text_font = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 171,
              y: 317,
              w: 146,
              h: 29,
              text_size: 21,
              char_space: 0,
              line_space: 0,
              font: 'fonts/wfs_teko_regular_42cb0dd3_aad7_462e_a673_daedf52bb938.ttf',
              color: 0xFFFFFFFF,
              align_h: hmUI.align.LEFT,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              // unit_string: Пнд, Втр, Срд, Чтв, Птн, Сб, Вск,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_battery_pointer_progress_img_pointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
              src: 'uk_2.png',
              center_x: 327,
              center_y: 231,
              x: 49,
              y: 49,
              start_angle: -138,
              end_angle: 130,
              invalid_visible: false,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_battery_current_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 262,
              y: 261,
              w: 146,
              h: 29,
              text_size: 26,
              char_space: 0,
              line_space: 0,
              font: 'fonts/wfs_rajdhani_semibold_0aaeba4b_c196_4d60_9299_2617721eaaa3.ttf',
              color: 0xFF858585,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.TOP,
              unit_type: 1,
              text_style: hmUI.text_style.ELLIPSIS,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_battery_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 0,
              y: 0,
              image_array: ["zr_0.png","zr_1.png","zr_2.png","zr_3.png","zr_4.png","zr_5.png","zr_6.png","zr_7.png","zr_8.png","zr_9.png","zr_10.png"],
              image_length: 11,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_step_pointer_progress_img_pointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
              src: 'uk_2.png',
              center_x: 135,
              center_y: 233,
              x: 50,
              y: 49,
              start_angle: -130,
              end_angle: 136,
              invalid_visible: false,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_step_current_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 63,
              y: 261,
              w: 146,
              h: 29,
              text_size: 26,
              char_space: 0,
              line_space: 0,
              font: 'fonts/wfs_rajdhani_semibold_0aaeba4b_c196_4d60_9299_2617721eaaa3.ttf',
              color: 0xFF868686,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_step_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 0,
              y: 0,
              image_array: ["zrs_1.png","zrs_2.png","zrs_3.png","zrs_4.png","zrs_5.png","zrs_6.png","zrs_7.png","zrs_8.png","zrs_9.png","zrs_10.png"],
              image_length: 10,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            // idle_sunrise_text_rotate_img = hmUI.createWidget(hmUI.widget.Text_Rotate, {
              // x: 368,
              // y: 79,
              // font_array: ["41.png","42.png","43.png","44.png","45.png","46.png","47.png","48.png","49.png","50.png"],
              // zero: true,
              // unit_in_alignment: false,
              // h_space: -4,
              // angle: 60,
              // negative_image: '51.png',
              // invalid_image: '51.png',
              // dot_image: '51.png',
              // align_h: hmUI.align.LEFT,
              // type: hmUI.data_type.SUN_RISE,
              // show_level: hmUI.show_level.ONLY_AOD,
            // });

            idle_sunrise_TextRotate_ASCIIARRAY[0] = '41.png';  // set of images with numbers
            idle_sunrise_TextRotate_ASCIIARRAY[1] = '42.png';  // set of images with numbers
            idle_sunrise_TextRotate_ASCIIARRAY[2] = '43.png';  // set of images with numbers
            idle_sunrise_TextRotate_ASCIIARRAY[3] = '44.png';  // set of images with numbers
            idle_sunrise_TextRotate_ASCIIARRAY[4] = '45.png';  // set of images with numbers
            idle_sunrise_TextRotate_ASCIIARRAY[5] = '46.png';  // set of images with numbers
            idle_sunrise_TextRotate_ASCIIARRAY[6] = '47.png';  // set of images with numbers
            idle_sunrise_TextRotate_ASCIIARRAY[7] = '48.png';  // set of images with numbers
            idle_sunrise_TextRotate_ASCIIARRAY[8] = '49.png';  // set of images with numbers
            idle_sunrise_TextRotate_ASCIIARRAY[9] = '50.png';  // set of images with numbers

            //start of ignored block
            for (let i = 0; i < 5; i++) {
              idle_sunrise_TextRotate[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 466,
                h: 466,
                center_x: 368,
                center_y: 79,
                pos_x: 368,
                pos_y: 79,
                angle: 60,
                src: '41.png',
                show_level: hmUI.show_level.ONLY_AOD,
              });
              idle_sunrise_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
            };
            //end of ignored block

            // idle_sunset_text_rotate_img = hmUI.createWidget(hmUI.widget.Text_Rotate, {
              // x: 49,
              // y: 143,
              // font_array: ["41.png","42.png","43.png","44.png","45.png","46.png","47.png","48.png","49.png","50.png"],
              // zero: true,
              // unit_in_alignment: false,
              // h_space: -4,
              // angle: -60,
              // negative_image: '51.png',
              // invalid_image: '51.png',
              // dot_image: '51.png',
              // align_h: hmUI.align.LEFT,
              // type: hmUI.data_type.SUN_SET,
              // show_level: hmUI.show_level.ONLY_AOD,
            // });

            idle_sunset_TextRotate_ASCIIARRAY[0] = '41.png';  // set of images with numbers
            idle_sunset_TextRotate_ASCIIARRAY[1] = '42.png';  // set of images with numbers
            idle_sunset_TextRotate_ASCIIARRAY[2] = '43.png';  // set of images with numbers
            idle_sunset_TextRotate_ASCIIARRAY[3] = '44.png';  // set of images with numbers
            idle_sunset_TextRotate_ASCIIARRAY[4] = '45.png';  // set of images with numbers
            idle_sunset_TextRotate_ASCIIARRAY[5] = '46.png';  // set of images with numbers
            idle_sunset_TextRotate_ASCIIARRAY[6] = '47.png';  // set of images with numbers
            idle_sunset_TextRotate_ASCIIARRAY[7] = '48.png';  // set of images with numbers
            idle_sunset_TextRotate_ASCIIARRAY[8] = '49.png';  // set of images with numbers
            idle_sunset_TextRotate_ASCIIARRAY[9] = '50.png';  // set of images with numbers

            //start of ignored block
            for (let i = 0; i < 5; i++) {
              idle_sunset_TextRotate[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 466,
                h: 466,
                center_x: 49,
                center_y: 143,
                pos_x: 49,
                pos_y: 143,
                angle: -60,
                src: '41.png',
                show_level: hmUI.show_level.ONLY_AOD,
              });
              idle_sunset_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
            };
            //end of ignored block

            idle_city_name_text = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 161,
              y: 53,
              w: 146,
              h: 29,
              text_size: 23,
              char_space: 0,
              line_space: 0,
              font: 'fonts/wfs_rajdhani_semibold_0aaeba4b_c196_4d60_9299_2617721eaaa3.ttf',
              color: 0xFF0C0C0C,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.NONE,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 96,
              y: 318,
              image_array: ["85.png","86.png","87.png","88.png","89.png","90.png","91.png","92.png","93.png","94.png","95.png","96.png","97.png","98.png","99.png","100.png","101.png","102.png","103.png","104.png","105.png","106.png","107.png","108.png","109.png","110.png","111.png","112.png","113.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_temperature_current_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 83,
              y: 359,
              w: 146,
              h: 29,
              text_size: 31,
              char_space: 0,
              line_space: 0,
              font: 'fonts/wfs_rajdhani_semibold_0aaeba4b_c196_4d60_9299_2617721eaaa3.ttf',
              color: 0xFFFFFFFF,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.TOP,
              unit_type: 1,
              text_style: hmUI.text_style.ELLIPSIS,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_pai_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 226,
              y: 59,
              src: 'rz_1.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_time_hour_text_font = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 117,
              y: 61,
              w: 146,
              h: 100,
              text_size: 91,
              char_space: 0,
              line_space: 0,
              font: 'fonts/wfs_teko_regular_42cb0dd3_aad7_462e_a673_daedf52bb938.ttf',
              color: 0xFF000000,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              // padding: true,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_time_minute_text_font = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 200,
              y: 61,
              w: 146,
              h: 89,
              text_size: 91,
              char_space: 0,
              line_space: 0,
              font: 'fonts/wfs_teko_regular_42cb0dd3_aad7_462e_a673_daedf52bb938.ttf',
              color: 0xFF181818,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              // padding: true,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            // idle_analog_clock_pro_second_pointer_img = hmUI.createWidget(hmUI.widget.TIME_POINTER_PRO, {
              // src: 'sec_1.png',
              // center_x: 235,
              // center_y: 189,
              // x: 48,
              // y: 49,
              // start_angle: 0,
              // end_angle: 360,
              // type: hmUI.data_type.second,
              // show_level: hmUI.show_level.ONLY_AOD,
            // });


            idle_analog_clock_pro_second_pointer_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: deviceInfo.width,
              h: deviceInfo.height,
              pos_x: 235 - 48,
              pos_y: 189 - 49,
              center_x: 235,
              center_y: 189,
              src: 'sec_1.png',
              angle: 0,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            // idle_analog_clock_pro_smooth_second = hmUI.createWidget(hmUI.widget.SMOOTH_SECOND, {
              // type: 2,
              // fps: 15,
              // show_level: hmUI.show_level.ONLY_AOD,
            // });


            console.log('Watch_Face.Buttons');
            Button_1 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 344,
              y: 73,
              w: 79,
              h: 73,
              text: '',
              color: 0xFFFF8C00,
              text_size: 24,
              press_src: 'null.png',
              normal_src: 'null.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'TideScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_2 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 33,
              y: 87,
              w: 79,
              h: 73,
              text: '',
              color: 0xFFFF8C00,
              text_size: 24,
              press_src: 'null.png',
              normal_src: 'null.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'TideScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_3 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 99,
              y: 198,
              w: 79,
              h: 73,
              text: '',
              color: 0xFFFF8C00,
              text_size: 24,
              press_src: 'null.png',
              normal_src: 'null.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'activityAppScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_4 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 291,
              y: 199,
              w: 79,
              h: 73,
              text: '',
              color: 0xFFFF8C00,
              text_size: 24,
              press_src: 'null.png',
              normal_src: 'null.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'LowBatteryScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_5 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 84,
              y: 305,
              w: 79,
              h: 73,
              text: '',
              color: 0xFFFF8C00,
              text_size: 24,
              press_src: 'null.png',
              normal_src: 'null.png',
              click_func: (button_widget) => {
                hmApp.startApp({ appid: 1051195, url: 'page/index', params: { from_wf: true} });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_6 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 197,
              y: 323,
              w: 79,
              h: 73,
              text: '',
              color: 0xFFFF8C00,
              text_size: 24,
              press_src: 'null.png',
              normal_src: 'null.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'ScheduleCalScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            //start of ignored block
            function time_update(updateHour = false, updateMinute = false) {
              console.log('time_update()');
              let hour = timeSensor.hour;
              let minute = timeSensor.minute;
              let second = timeSensor.second;
              let format_hour = timeSensor.format_hour;

              console.log('day font');
              if (updateHour) {
                let normal_dayStr = timeSensor.day.toString();
                normal_day_text_font.setProperty(hmUI.prop.TEXT, normal_dayStr );
              };

              console.log('month font');
              if (updateHour) {
                let normal_Month_Str = normal_Month_Array[timeSensor.month-1];
                normal_month_name_font.setProperty(hmUI.prop.TEXT, normal_Month_Str );
              };

              console.log('day of week font');
              if (updateHour) {
                let normal_DOW_Str = normal_DOW_Array[timeSensor.week-1];
                normal_dow_text_font.setProperty(hmUI.prop.TEXT, normal_DOW_Str );
                if (timeSensor.week >= 6) normal_dow_text_font.setProperty(hmUI.prop.COLOR, 0xFFFF0000);
                else normal_dow_text_font.setProperty(hmUI.prop.COLOR, 0xFFFFFFFF);
              };

              console.log('hour font');
              if (updateHour) {
                let normal_hourStr = format_hour.toString();
                normal_hourStr = normal_hourStr.padStart(2, '0');
                normal_time_hour_text_font.setProperty(hmUI.prop.TEXT, normal_hourStr );
              };

              console.log('minute font');
              if (updateMinute) {
                let normal_minuteStr = minute.toString();
                normal_minuteStr = normal_minuteStr.padStart(2, '0');
                normal_time_minute_text_font.setProperty(hmUI.prop.TEXT, normal_minuteStr );
              };

              let normal_fullAngle_second = 360;
              let normal_angle_second = 0 + normal_fullAngle_second*(second + (timeSensor.utc % 1000)/1000)/60;
              if (normal_analog_clock_pro_second_pointer_img) normal_analog_clock_pro_second_pointer_img.setProperty(hmUI.prop.ANGLE, normal_angle_second);

              console.log('day font');
              if (updateHour) {
                let idle_dayStr = timeSensor.day.toString();
                idle_day_text_font.setProperty(hmUI.prop.TEXT, idle_dayStr );
              };

              console.log('month font');
              if (updateHour) {
                let idle_Month_Str = idle_Month_Array[timeSensor.month-1];
                idle_month_name_font.setProperty(hmUI.prop.TEXT, idle_Month_Str );
              };

              console.log('day of week font');
              if (updateHour) {
                let idle_DOW_Str = idle_DOW_Array[timeSensor.week-1];
                idle_dow_text_font.setProperty(hmUI.prop.TEXT, idle_DOW_Str );
              };

              console.log('hour font');
              if (updateHour) {
                let idle_hourStr = format_hour.toString();
                idle_hourStr = idle_hourStr.padStart(2, '0');
                idle_time_hour_text_font.setProperty(hmUI.prop.TEXT, idle_hourStr );
              };

              console.log('minute font');
              if (updateMinute) {
                let idle_minuteStr = minute.toString();
                idle_minuteStr = idle_minuteStr.padStart(2, '0');
                idle_time_minute_text_font.setProperty(hmUI.prop.TEXT, idle_minuteStr );
              };

              let idle_fullAngle_second = 360;
              let idle_angle_second = 0 + idle_fullAngle_second*(second + (timeSensor.utc % 1000)/1000)/60;
              if (idle_analog_clock_pro_second_pointer_img) idle_analog_clock_pro_second_pointer_img.setProperty(hmUI.prop.ANGLE, idle_angle_second);

            };

            //end of ignored block
            //start of ignored block
            function text_update() {
              console.log('text_update()');
              let weatherData = weatherSensor.getForecastWeather();
              let tideData = weatherData.tideData;
              let sunrise_hour = -1;
              let sunrise_minute = -1;
              if (tideData.count > 0) {
                sunrise_hour = tideData.data[0].sunrise.hour;
                sunrise_minute = tideData.data[0].sunrise.minute;
              }; // end tideData;

              console.log('update text rotate sunrise_tideData');
              let sunriseTime = undefined;
              let normal_sunrise_rotate_string = undefined;
              if (sunrise_hour >= 0 && sunrise_minute >= 0) {
                sunriseTime = 0;
                normal_sunrise_rotate_string = String(sunrise_hour).padStart(2, '0') + '.' + String(sunrise_minute).padStart(2, '0');
              };

              if (screenType != hmSetting.screen_type.AOD) {
                for (var i = 1; i < 5; i++) {  // hide all symbols
                  normal_sunrise_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                if (sunriseTime != null && sunriseTime != undefined && isFinite(sunriseTime) && normal_sunrise_rotate_string.length > 0 && normal_sunrise_rotate_string.length <= 5) {  // display data if it was possible to get it
                  let img_offset = 0;
                  
                  let index = 0;
                  for (let char of normal_sunrise_rotate_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 5) break;
                    if (charCode >= 0 && charCode < 10) { 
                      normal_sunrise_TextRotate[index].setProperty(hmUI.prop.POS_X, 368 + img_offset);
                      normal_sunrise_TextRotate[index].setProperty(hmUI.prop.SRC, normal_sunrise_TextRotate_ASCIIARRAY[charCode]);
                      normal_sunrise_TextRotate[index].setProperty(hmUI.prop.VISIBLE, true);
                      img_offset += normal_sunrise_TextRotate_img_width + -4;
                      index++;
                    }  // end if digit
                    else { 
                      normal_sunrise_TextRotate[index].setProperty(hmUI.prop.POS_X, 368 + img_offset);
                      normal_sunrise_TextRotate[index].setProperty(hmUI.prop.SRC, '51.png');
                      normal_sunrise_TextRotate[index].setProperty(hmUI.prop.VISIBLE, true);
                      img_offset += normal_sunrise_TextRotate_dot_width + -4;
                      index++;
                    };  // end if dot point 
                  };  // end char of string
                }  // end isFinite
                else {
                  normal_sunrise_TextRotate[0].setProperty(hmUI.prop.POS_X, 368);
                  normal_sunrise_TextRotate[0].setProperty(hmUI.prop.SRC, '51.png');
                  normal_sunrise_TextRotate[0].setProperty(hmUI.prop.VISIBLE, true);
                };  // end else isFinite

              };
              let sunset_hour = -1;
              let sunset_minute = -1;
              if (tideData.count > 0) {
                sunset_hour = tideData.data[0].sunset.hour;
                sunset_minute = tideData.data[0].sunset.minute;
              }; // end tideData;

              console.log('update text rotate sunset_tideData');
              let sunsetTime = undefined;
              let normal_sunset_rotate_string = undefined;
              if (sunset_hour >= 0 && sunset_minute >= 0) {
                sunsetTime = 0;
                normal_sunset_rotate_string = String(sunset_hour).padStart(2, '0') + '.' + String(sunset_minute).padStart(2, '0');
              };

              if (screenType != hmSetting.screen_type.AOD) {
                for (var i = 1; i < 5; i++) {  // hide all symbols
                  normal_sunset_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                if (sunsetTime != null && sunsetTime != undefined && isFinite(sunsetTime) && normal_sunset_rotate_string.length > 0 && normal_sunset_rotate_string.length <= 5) {  // display data if it was possible to get it
                  let img_offset = 0;
                  
                  let index = 0;
                  for (let char of normal_sunset_rotate_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 5) break;
                    if (charCode >= 0 && charCode < 10) { 
                      normal_sunset_TextRotate[index].setProperty(hmUI.prop.POS_X, 49 + img_offset);
                      normal_sunset_TextRotate[index].setProperty(hmUI.prop.SRC, normal_sunset_TextRotate_ASCIIARRAY[charCode]);
                      normal_sunset_TextRotate[index].setProperty(hmUI.prop.VISIBLE, true);
                      img_offset += normal_sunset_TextRotate_img_width + -4;
                      index++;
                    }  // end if digit
                    else { 
                      normal_sunset_TextRotate[index].setProperty(hmUI.prop.POS_X, 49 + img_offset);
                      normal_sunset_TextRotate[index].setProperty(hmUI.prop.SRC, '51.png');
                      normal_sunset_TextRotate[index].setProperty(hmUI.prop.VISIBLE, true);
                      img_offset += normal_sunset_TextRotate_dot_width + -4;
                      index++;
                    };  // end if dot point 
                  };  // end char of string
                }  // end isFinite
                else {
                  normal_sunset_TextRotate[0].setProperty(hmUI.prop.POS_X, 49);
                  normal_sunset_TextRotate[0].setProperty(hmUI.prop.SRC, '51.png');
                  normal_sunset_TextRotate[0].setProperty(hmUI.prop.VISIBLE, true);
                };  // end else isFinite

              };

              console.log('update text rotate sunrise_tideData');
              let idle_sunrise_rotate_string = undefined;
              if (sunrise_hour >= 0 && sunrise_minute >= 0) {
                sunriseTime = 0;
                idle_sunrise_rotate_string = String(sunrise_hour).padStart(2, '0') + '.' + String(sunrise_minute).padStart(2, '0');
              };

              if (screenType == hmSetting.screen_type.AOD) {
                for (var i = 1; i < 5; i++) {  // hide all symbols
                  idle_sunrise_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                if (sunriseTime != null && sunriseTime != undefined && isFinite(sunriseTime) && idle_sunrise_rotate_string.length > 0 && idle_sunrise_rotate_string.length <= 5) {  // display data if it was possible to get it
                  let img_offset = 0;
                  
                  let index = 0;
                  for (let char of idle_sunrise_rotate_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 5) break;
                    if (charCode >= 0 && charCode < 10) { 
                      idle_sunrise_TextRotate[index].setProperty(hmUI.prop.POS_X, 368 + img_offset);
                      idle_sunrise_TextRotate[index].setProperty(hmUI.prop.SRC, idle_sunrise_TextRotate_ASCIIARRAY[charCode]);
                      idle_sunrise_TextRotate[index].setProperty(hmUI.prop.VISIBLE, true);
                      img_offset += idle_sunrise_TextRotate_img_width + -4;
                      index++;
                    }  // end if digit
                    else { 
                      idle_sunrise_TextRotate[index].setProperty(hmUI.prop.POS_X, 368 + img_offset);
                      idle_sunrise_TextRotate[index].setProperty(hmUI.prop.SRC, '51.png');
                      idle_sunrise_TextRotate[index].setProperty(hmUI.prop.VISIBLE, true);
                      img_offset += idle_sunrise_TextRotate_dot_width + -4;
                      index++;
                    };  // end if dot point 
                  };  // end char of string
                }  // end isFinite
                else {
                  idle_sunrise_TextRotate[0].setProperty(hmUI.prop.POS_X, 368);
                  idle_sunrise_TextRotate[0].setProperty(hmUI.prop.SRC, '51.png');
                  idle_sunrise_TextRotate[0].setProperty(hmUI.prop.VISIBLE, true);
                };  // end else isFinite

              };

              console.log('update text rotate sunset_tideData');
              let idle_sunset_rotate_string = undefined;
              if (sunset_hour >= 0 && sunset_minute >= 0) {
                sunsetTime = 0;
                idle_sunset_rotate_string = String(sunset_hour).padStart(2, '0') + '.' + String(sunset_minute).padStart(2, '0');
              };

              if (screenType == hmSetting.screen_type.AOD) {
                for (var i = 1; i < 5; i++) {  // hide all symbols
                  idle_sunset_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                if (sunsetTime != null && sunsetTime != undefined && isFinite(sunsetTime) && idle_sunset_rotate_string.length > 0 && idle_sunset_rotate_string.length <= 5) {  // display data if it was possible to get it
                  let img_offset = 0;
                  
                  let index = 0;
                  for (let char of idle_sunset_rotate_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 5) break;
                    if (charCode >= 0 && charCode < 10) { 
                      idle_sunset_TextRotate[index].setProperty(hmUI.prop.POS_X, 49 + img_offset);
                      idle_sunset_TextRotate[index].setProperty(hmUI.prop.SRC, idle_sunset_TextRotate_ASCIIARRAY[charCode]);
                      idle_sunset_TextRotate[index].setProperty(hmUI.prop.VISIBLE, true);
                      img_offset += idle_sunset_TextRotate_img_width + -4;
                      index++;
                    }  // end if digit
                    else { 
                      idle_sunset_TextRotate[index].setProperty(hmUI.prop.POS_X, 49 + img_offset);
                      idle_sunset_TextRotate[index].setProperty(hmUI.prop.SRC, '51.png');
                      idle_sunset_TextRotate[index].setProperty(hmUI.prop.VISIBLE, true);
                      img_offset += idle_sunset_TextRotate_dot_width + -4;
                      index++;
                    };  // end if dot point 
                  };  // end char of string
                }  // end isFinite
                else {
                  idle_sunset_TextRotate[0].setProperty(hmUI.prop.POS_X, 49);
                  idle_sunset_TextRotate[0].setProperty(hmUI.prop.SRC, '51.png');
                  idle_sunset_TextRotate[0].setProperty(hmUI.prop.VISIBLE, true);
                };  // end else isFinite

              };

            };

            //end of ignored block
            function scale_call() {
              console.log('scale_call()');

              console.log('Weather city name');
              let weatherData = weatherSensor.getForecastWeather();
              normal_city_name_text.setProperty(hmUI.prop.TEXT, weatherData.cityName);

              console.log('Weather city name');
              idle_city_name_text.setProperty(hmUI.prop.TEXT, weatherData.cityName);

            };

            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                console.log('resume_call()');
                scale_call();
                time_update(true, true);
                text_update();
                if (screenType == hmSetting.screen_type.WATCHFACE) {
                  if (!normal_timerTimeUpdate) {
                    normal_timerTimeUpdate = timer.createTimer(0, 1000, (function (option) {
                      let updateHour = timeSensor.minute == 0 && timeSensor.second < 2;
                      let updateMinute = timeSensor.second < 2;
                      time_update(updateHour, updateMinute);
                    }));  // end timer 
                  };  // end timer check
                };  // end screenType

                if (screenType == hmSetting.screen_type.WATCHFACE) {
                  if (!normal_timerUpdateSecSmooth) {
                    let animDelay = 0;
                    let animRepeat = 1000/15;
                    normal_timerUpdateSecSmooth = timer.createTimer(animDelay, animRepeat, (function (option) {
                      time_update(false, false);
                    }));  // end timer 
                  };  // end timer check
                };  // end screenType

                if (screenType == hmSetting.screen_type.AOD) {
                  if (!idle_timerTimeUpdate) {
                    idle_timerTimeUpdate = timer.createTimer(0, 1000, (function (option) {
                      let updateHour = timeSensor.minute == 0 && timeSensor.second < 2;
                      let updateMinute = timeSensor.second < 2;
                      time_update(updateHour, updateMinute);
                    }));  // end timer 
                  };  // end timer check
                };  // end screenType

                if (screenType == hmSetting.screen_type.AOD) {
                  if (!idle_timerUpdateSecSmooth) {
                    let animDelay = 0;
                    let animRepeat = 1000/15;
                    idle_timerUpdateSecSmooth = timer.createTimer(animDelay, animRepeat, (function (option) {
                      time_update(false, false);
                    }));  // end timer 
                  };  // end timer check
                };  // end screenType


                console.log('resume_call.js');
                // start resume_call.js

// if (!isAOD) snowfall.start();
                
                setTimeout(() => {
                    onDigitalCrown();
                }, 350);
                // end resume_call.js

              }),
              pause_call: (function () {
                console.log('pause_call()');
                if (normal_timerTimeUpdate) {
                  timer.stopTimer(normal_timerTimeUpdate);
                  normal_timerTimeUpdate = undefined;
                }
                if (normal_timerUpdateSecSmooth) {
                  timer.stopTimer(normal_timerUpdateSecSmooth);
                  normal_timerUpdateSecSmooth = undefined;
                }
                if (idle_timerTimeUpdate) {
                  timer.stopTimer(idle_timerTimeUpdate);
                  idle_timerTimeUpdate = undefined;
                }
                if (idle_timerUpdateSecSmooth) {
                  timer.stopTimer(idle_timerUpdateSecSmooth);
                  idle_timerUpdateSecSmooth = undefined;
                }

              }),
            });

                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}