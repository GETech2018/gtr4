/*
** Facemaker bundle tool v0.0.2
* *huamiOS watchface js version v2.0.1
* *Copyright © Huami. All Rights Reserved
*/


try {
	(() => {
		var __$$app$$__ = __$$hmAppManager$$__.currentApp;
		var __$$module$$__ = __$$app$$__.current;

		//drink is a name,can modify
		var h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__), 'drink');

		'use strict';

		//dynamic modify start
		let normal_background_bg_img0 = '';
		let normal_background_bg_img1 = '';
		let normal_digital_clock_img_hour_high3 = '';
		let normal_digital_clock_img_hour_high3_array = ['0004.png','0005.png','0006.png'];
		let normal_digital_clock_img_hour_low4 = '';
		let normal_digital_clock_img_hour_low4_array = ['0007.png','0008.png','0009.png','0010.png','0011.png','0012.png','0013.png','0014.png','0015.png','0016.png'];
		let normal_digital_clock_img_minute_high5 = '';
		let normal_digital_clock_img_minute_high5_array = ['0017.png','0018.png','0019.png','0020.png','0021.png','0022.png'];
		let normal_digital_clock_img_minute_low6 = '';
		let normal_digital_clock_img_minute_low6_array = ['0023.png','0024.png','0025.png','0026.png','0027.png','0028.png','0029.png','0030.png','0031.png','0032.png'];
		let normal_background_bg_img7 = '';
		let normal_date_img_date_week_img9 = '';
		let normal_date_current_date_monthday10 = '';
		let normal_date_current_date_month11 = '';
		let normal_background_bg_img12 = '';
		let normal_background_bg_img13 = '';
		let normal_date_current_date_year14 = '';
		let normal_battery_pointer_progress_img_pointer16 = '';
		let normal_background_bg_img17 = '';
		let normal_battery_current_text_img18 = '';
		let normal_heart_pointer_progress_img_pointer20 = '';
		let normal_background_bg_img21 = '';
		let normal_heart_current_text_img22 = '';
		let normal_background_bg_img23 = '';
		let normal_step_pointer_progress_img_pointer25 = '';
		let normal_step_current_text_img26 = '';
		let normal_background_bg_img27 = '';
		let normal_background_bg_img28 = '';
		let normal_distance_current_text_img30 = '';
		let normal_background_bg_img31 = '';
		let normal_background_bg_img32 = '';
		let normal_calories_current_text_img34 = '';
		let normal_background_bg_img35 = '';
		let normal_background_bg_img36 = '';
		let normal_alarm_status38 = '';
		//dynamic modify end

		//not required
		const logger = DeviceRuntimeCore.HmLogger.getLogger("yeguang");

		__$$module$$__.module = DeviceRuntimeCore.WatchFace({
			init_view() {

				let screenType = hmSetting.getScreenType();

				normal_background_bg_img0 = hmUI.createWidget(hmUI.widget.IMG, {
					x: -2,
					y: 0,
					w: 470,
					h: 470,
					src: '0002.png',
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_background_bg_img1 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 215,
					y: 332,
					w: 37,
					h: 38,
					src: '0003.png',
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				const timeSensor = hmSensor.createSensor(hmSensor.id.TIME);
				timeSensor.addEventListener(hmSensor.event.CHANGE, function() {
					updateImageCombos();
				});

				normal_digital_clock_img_hour_high3 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 38,
					y: 168,
					w: 38,
					h: 168,
					src: '0006.png',
					show_level: hmUI.show_level.ONLY_NORMAL,
				})

				normal_digital_clock_img_hour_low4 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 129,
					y: 168,
					w: 129,
					h: 168,
					src: '0016.png',
					show_level: hmUI.show_level.ONLY_NORMAL,
				})

				normal_digital_clock_img_minute_high5 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 246,
					y: 168,
					w: 246,
					h: 168,
					src: '0022.png',
					show_level: hmUI.show_level.ONLY_NORMAL,
				})

				normal_digital_clock_img_minute_low6 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 337,
					y: 168,
					w: 337,
					h: 168,
					src: '0032.png',
					show_level: hmUI.show_level.ONLY_NORMAL,
				})

				normal_background_bg_img7 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 216,
					y: 181,
					w: 34,
					h: 111,
					src: '0033.png',
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_date_img_date_week_img9 = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
					x: 94,
					y: 92,
					week_en: ["0034.png","0035.png","0036.png","0037.png","0038.png","0039.png","0040.png"],
					week_tc: ["0034.png","0035.png","0036.png","0037.png","0038.png","0039.png","0040.png"],
					week_sc: ["0034.png","0035.png","0036.png","0037.png","0038.png","0039.png","0040.png"],
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_date_current_date_monthday10 = hmUI.createWidget(hmUI.widget.IMG_DATE, {
					day_startX: 118,
					day_startY: 119,
					day_sc_array: ["0041.png","0042.png","0043.png","0044.png","0045.png","0046.png","0047.png","0048.png","0049.png","0050.png"],
					day_tc_array: ["0041.png","0042.png","0043.png","0044.png","0045.png","0046.png","0047.png","0048.png","0049.png","0050.png"],
					day_en_array: ["0041.png","0042.png","0043.png","0044.png","0045.png","0046.png","0047.png","0048.png","0049.png","0050.png"],
					day_zero: true,
					day_space: -4,
					day_align: hmUI.align.CENTER_H,
					day_is_character: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_date_current_date_month11 = hmUI.createWidget(hmUI.widget.IMG_DATE, {
					month_startX: 186,
					month_startY: 118,
					month_sc_array: ["0051.png","0052.png","0053.png","0054.png","0055.png","0056.png","0057.png","0058.png","0059.png","0060.png"],
					month_tc_array: ["0051.png","0052.png","0053.png","0054.png","0055.png","0056.png","0057.png","0058.png","0059.png","0060.png"],
					month_en_array: ["0051.png","0052.png","0053.png","0054.png","0055.png","0056.png","0057.png","0058.png","0059.png","0060.png"],
					month_zero: true,
					month_space: -5,
					month_align: hmUI.align.CENTER_H,
					month_is_character: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_background_bg_img12 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 171,
					y: 116,
					w: 16,
					h: 50,
					src: '0061.png',
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_background_bg_img13 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 235,
					y: 116,
					w: 16,
					h: 50,
					src: '0061.png',
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_date_current_date_year14 = hmUI.createWidget(hmUI.widget.IMG_DATE, {
					year_startX: 250,
					year_startY: 118,
					year_sc_array: ["0062.png","0063.png","0064.png","0065.png","0066.png","0067.png","0068.png","0069.png","0070.png","0071.png"],
					year_tc_array: ["0062.png","0063.png","0064.png","0065.png","0066.png","0067.png","0068.png","0069.png","0070.png","0071.png"],
					year_en_array: ["0062.png","0063.png","0064.png","0065.png","0066.png","0067.png","0068.png","0069.png","0070.png","0071.png"],
					year_zero: true,
					year_space: -5,
					year_align: hmUI.align.CENTER_H,
					year_is_character: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_battery_pointer_progress_img_pointer16 = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
					src: '0072.png',
					center_x: 233,
					center_y: 233,
					x: 13,
					y: 235,
					start_angle: 236,
					end_angle: 304,
					type: hmUI.data_type.BATTERY,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_background_bg_img17 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 58,
					y: 318,
					w: 28,
					h: 35,
					src: '0073.png',
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_battery_current_text_img18 = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
					x: 110,
					y: 321,
					font_array: ["0074.png","0075.png","0076.png","0077.png","0078.png","0079.png","0080.png","0081.png","0082.png","0083.png"],
					padding: false,
					h_space: -4,
					unit_sc: '0084.png',
					unit_tc: '0084.png',
					unit_en: '0084.png',
					align_h: hmUI.align.CENTER_H,
					type: hmUI.data_type.BATTERY,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_heart_pointer_progress_img_pointer20 = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
					src: '0085.png',
					center_x: 233,
					center_y: 233,
					x: 13,
					y: 235,
					start_angle: 124,
					end_angle: 56,
					type: hmUI.data_type.HEART,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_background_bg_img21 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 377,
					y: 317,
					w: 35,
					h: 35,
					src: '0086.png',
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_heart_current_text_img22 = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
					x: 255,
					y: 321,
					font_array: ["0087.png","0088.png","0089.png","0090.png","0091.png","0092.png","0093.png","0094.png","0095.png","0096.png"],
					padding: false,
					h_space: -4,
					invalid_image: '0097.png',
					align_h: hmUI.align.RIGHT,
					type: hmUI.data_type.HEART,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_background_bg_img23 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 322,
					y: 335,
					w: 43,
					h: 27,
					src: '0098.png',
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_step_pointer_progress_img_pointer25 = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
					src: '0099.png',
					center_x: 233,
					center_y: 233,
					x: 10,
					y: 234,
					start_angle: -45,
					end_angle: 45,
					type: hmUI.data_type.STEP,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_step_current_text_img26 = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
					x: 170,
					y: 37,
					font_array: ["0100.png","0101.png","0102.png","0103.png","0104.png","0105.png","0106.png","0107.png","0108.png","0109.png"],
					padding: false,
					h_space: -5,
					align_h: hmUI.align.CENTER_H,
					type: hmUI.data_type.STEP,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_background_bg_img27 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 130,
					y: 50,
					w: 39,
					h: 30,
					src: '0110.png',
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_background_bg_img28 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 297,
					y: 54,
					w: 33,
					h: 32,
					src: '0111.png',
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_distance_current_text_img30 = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
					x: 108,
					y: 380,
					font_array: ["0112.png","0113.png","0114.png","0115.png","0116.png","0117.png","0118.png","0119.png","0120.png","0121.png"],
					padding: false,
					h_space: -4,
					dot_image: '0122.png',
					align_h: hmUI.align.CENTER_H,
					type: hmUI.data_type.DISTANCE,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_background_bg_img31 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 83,
					y: 382,
					w: 21,
					h: 35,
					src: '0123.png',
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_background_bg_img32 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 154,
					y: 425,
					w: 33,
					h: 27,
					src: '0124.png',
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_calories_current_text_img34 = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
					x: 245,
					y: 380,
					font_array: ["0125.png","0126.png","0127.png","0128.png","0129.png","0130.png","0131.png","0132.png","0133.png","0134.png"],
					padding: false,
					h_space: -4,
					align_h: hmUI.align.CENTER_H,
					type: hmUI.data_type.CAL,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_background_bg_img35 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 355,
					y: 382,
					w: 25,
					h: 35,
					src: '0135.png',
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_background_bg_img36 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 271,
					y: 425,
					w: 42,
					h: 27,
					src: '0136.png',
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_alarm_status38 = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
					x: 215,
					y: 332,
					w: 37,
					h: 38,
					type: hmUI.system_status.CLOCK,
					src: '0137.png',
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				function updateImageCombos() {
					normal_digital_clock_img_hour_high3.setProperty(hmUI.prop.MORE, {
						src: normal_digital_clock_img_hour_high3_array[(timeSensor.hour.toString().length == 2 ? timeSensor.hour.toString().charAt(0) : 0)]
					})
					normal_digital_clock_img_hour_low4.setProperty(hmUI.prop.MORE, {
						src: normal_digital_clock_img_hour_low4_array[(timeSensor.hour.toString().length == 2 ? timeSensor.hour.toString().charAt(1) : timeSensor.hour.toString().charAt(0))]
					})
					normal_digital_clock_img_minute_high5.setProperty(hmUI.prop.MORE, {
						src: normal_digital_clock_img_minute_high5_array[(timeSensor.minute.toString().length == 2 ? timeSensor.minute.toString().charAt(0) : 0)]
					})
					normal_digital_clock_img_minute_low6.setProperty(hmUI.prop.MORE, {
						src: normal_digital_clock_img_minute_low6_array[(timeSensor.minute.toString().length == 2 ? timeSensor.minute.toString().charAt(1) : timeSensor.minute.toString().charAt(0))]
					})
				};

				const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
					resume_call: (function () {
						updateImageCombos();

					}),
					pause_call: (function () {
					}),
				})
			},

		onInit() {
			console.log('index page.js on init invoke')
			this.init_view()
		},
		onReady() {
			console.log('index page.js on ready invoke')
		},
		onShow() {
			console.log('index page.js on show invoke')
		},
		onHide() {
			console.log('index page.js on hide invoke')
		},
		onDestroy() {
			console.log('index page.js on destroy invoke')
		},
	});	})()
} catch (e) {
	console.log(e)
}