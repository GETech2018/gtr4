/*
** Facemaker bundle tool v0.0.2
* *huamiOS watchface js version v2.0.1
* *Copyright © Huami. All Rights Reserved
*/


try {
	(() => {
		var __$$app$$__ = __$$hmAppManager$$__.currentApp;
		var __$$module$$__ = __$$app$$__.current;

		//drink is a name,can modify
		var h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__), 'drink');

		'use strict';

		//dynamic modify start
		let normal_background_bg_img0 = '';
		let normal_battery_pointer_progress_img_pointer2 = '';
		let normal_battery_pointer_progress_img_pointer3 = '';
		let normal_date_img_date_monthday_high5 = '';
		let normal_date_img_date_monthday_high5_array = ['0005.png','0006.png','0007.png','0008.png','0009.png','0010.png','0011.png','0012.png','0013.png','0014.png'];
		let normal_date_img_date_monthday_low6 = '';
		let normal_date_img_date_monthday_low6_array = ['0005.png','0006.png','0007.png','0008.png','0009.png','0010.png','0011.png','0012.png','0013.png','0014.png'];
		let normal_analog_clock_time_pointer_hour8 = '';
		let normal_analog_clock_time_pointer_hour9 = '';
		let normal_analog_clock_time_pointer_minute10 = '';
		let normal_analog_clock_time_pointer_minute11 = '';
		let normal_analog_clock_time_pointer_second12 = '';
		let normal_analog_clock_time_pointer_second13 = '';
		let idle_analog_clock_time_pointer_hour16 = '';
		let idle_analog_clock_time_pointer_minute17 = '';
		//dynamic modify end

		//not required
		const logger = DeviceRuntimeCore.HmLogger.getLogger("yeguang");

		__$$module$$__.module = DeviceRuntimeCore.WatchFace({
			init_view() {

				let screenType = hmSetting.getScreenType();

				normal_background_bg_img0 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 0,
					y: 0,
					w: 466,
					h: 466,
					src: '0002.png',
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_battery_pointer_progress_img_pointer2 = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
					src: '0003.png',
					center_x: 163,
					center_y: 236,
					x: 8,
					y: 49,
					start_angle: 0,
					end_angle: 360,
					type: hmUI.data_type.BATTERY,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_battery_pointer_progress_img_pointer3 = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
					src: '0004.png',
					center_x: 163,
					center_y: 234,
					x: 8,
					y: 47,
					start_angle: 0,
					end_angle: 360,
					type: hmUI.data_type.BATTERY,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				const timeSensor = hmSensor.createSensor(hmSensor.id.TIME);
				timeSensor.addEventListener(hmSensor.event.CHANGE, function() {
					updateImageCombos();
				});

				normal_date_img_date_monthday_high5 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 348,
					y: 216,
					w: 348,
					h: 216,
					src: '0014.png',
					show_level: hmUI.show_level.ONLY_NORMAL,
				})

				normal_date_img_date_monthday_low6 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 366,
					y: 216,
					w: 366,
					h: 216,
					src: '0014.png',
					show_level: hmUI.show_level.ONLY_NORMAL,
				})

				normal_analog_clock_time_pointer_hour8 = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
					hour_path: '0015.png',
					hour_centerX: 233,
					hour_centerY: 237,
					hour_posX: 12,
					hour_posY: 147,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_analog_clock_time_pointer_hour9 = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
					hour_path: '0016.png',
					hour_centerX: 233,
					hour_centerY: 234,
					hour_posX: 12,
					hour_posY: 144,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_analog_clock_time_pointer_minute10 = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
					minute_path: '0017.png',
					minute_centerX: 233,
					minute_centerY: 237,
					minute_posX: 12,
					minute_posY: 199,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_analog_clock_time_pointer_minute11 = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
					minute_path: '0018.png',
					minute_centerX: 233,
					minute_centerY: 234,
					minute_posX: 12,
					minute_posY: 196,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_analog_clock_time_pointer_second12 = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
					second_path: '0019.png',
					second_centerX: 233,
					second_centerY: 237,
					second_posX: 8,
					second_posY: 192,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_analog_clock_time_pointer_second13 = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
					second_path: '0020.png',
					second_centerX: 233,
					second_centerY: 233,
					second_posX: 8,
					second_posY: 188,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				idle_analog_clock_time_pointer_hour16 = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
					hour_path: '0016.png',
					hour_centerX: 233,
					hour_centerY: 234,
					hour_posX: 12,
					hour_posY: 144,
					show_level: hmUI.show_level.ONAL_AOD,
				});

				idle_analog_clock_time_pointer_minute17 = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
					minute_path: '0018.png',
					minute_centerX: 233,
					minute_centerY: 234,
					minute_posX: 12,
					minute_posY: 196,
					show_level: hmUI.show_level.ONAL_AOD,
				});

				function updateImageCombos() {
					normal_date_img_date_monthday_high5.setProperty(hmUI.prop.MORE, {
						src: normal_date_img_date_monthday_high5_array[(timeSensor.day.toString().length == 2 ? timeSensor.day.toString().charAt(0) : 0)]
					})
					normal_date_img_date_monthday_low6.setProperty(hmUI.prop.MORE, {
						src: normal_date_img_date_monthday_low6_array[(timeSensor.day.toString().length == 2 ? timeSensor.day.toString().charAt(1) : timeSensor.day.toString().charAt(0))]
					})
				};

				const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
					resume_call: (function () {
						updateImageCombos();

					}),
					pause_call: (function () {
					}),
				})
			},

		onInit() {
			console.log('index page.js on init invoke')
			this.init_view()
		},
		onReady() {
			console.log('index page.js on ready invoke')
		},
		onShow() {
			console.log('index page.js on show invoke')
		},
		onHide() {
			console.log('index page.js on hide invoke')
		},
		onDestroy() {
			console.log('index page.js on destroy invoke')
		},
	});	})()
} catch (e) {
	console.log(e)
}