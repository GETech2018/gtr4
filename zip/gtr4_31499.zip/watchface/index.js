/*
** Facemaker bundle tool v0.0.2
* *huamiOS watchface js version v2.0.1
* *Copyright © Huami. All Rights Reserved
*/


try {
	(() => {
		var __$$app$$__ = __$$hmAppManager$$__.currentApp;
		var __$$module$$__ = __$$app$$__.current;

		//drink is a name,can modify
		var h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__), 'drink');

		'use strict';

		//dynamic modify start
		let normal_background_bg_img0 = '';
		let normal_digital_clock_img_hour_high2 = '';
		let normal_digital_clock_img_hour_high2_array = ['0003.png','0004.png','0005.png'];
		let normal_digital_clock_img_hour_low3 = '';
		let normal_digital_clock_img_hour_low3_array = ['0006.png','0007.png','0008.png','0009.png','0010.png','0011.png','0012.png','0013.png','0014.png','0015.png'];
		let normal_digital_clock_img_minute_high4 = '';
		let normal_digital_clock_img_minute_high4_array = ['0016.png','0017.png','0018.png','0019.png','0020.png','0021.png'];
		let normal_digital_clock_img_minute_low5 = '';
		let normal_digital_clock_img_minute_low5_array = ['0022.png','0023.png','0024.png','0025.png','0026.png','0027.png','0028.png','0029.png','0030.png','0031.png'];
		let normal_background_bg_img7 = '';
		let normal_step_current_text_img8 = '';
		let normal_background_bg_img10 = '';
		let normal_distance_current_text_img11 = '';
		let normal_background_bg_img13 = '';
		let normal_heart_current_text_img14 = '';
		let normal_background_bg_img16 = '';
		let normal_calories_current_text_img17 = '';
		let normal_background_bg_img19 = '';
		let normal_blood_oxygen_text_img20 = '';
		let normal_background_bg_img22 = '';
		let normal_battery_current_text_img23 = '';
		let normal_battery_current_line24 = '';
		let normal_weather_image_progress_img_level26 = '';
		let normal_temperature_current_text_img27 = '';
		let normal_date_img_date_week_img29 = '';
		let normal_date_current_date_monthday30 = '';
		let normal_date_current_date_month31 = '';
		let normal_background_bg_img32 = '';
		//dynamic modify end

		//not required
		const logger = DeviceRuntimeCore.HmLogger.getLogger("yeguang");

		__$$module$$__.module = DeviceRuntimeCore.WatchFace({
			init_view() {

				let screenType = hmSetting.getScreenType();

				normal_background_bg_img0 = hmUI.createWidget(hmUI.widget.IMG, {
					x: -3,
					y: -4,
					w: 470,
					h: 472,
					src: '0002.png',
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_digital_clock_img_hour_high2 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 141,
					y: 110,
					w: 141,
					h: 110,
					src: '0005.png',
					show_level: hmUI.show_level.ONLY_NORMAL,
				})

				normal_digital_clock_img_hour_low3 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 234,
					y: 110,
					w: 234,
					h: 110,
					src: '0015.png',
					show_level: hmUI.show_level.ONLY_NORMAL,
				})

				normal_digital_clock_img_minute_high4 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 141,
					y: 236,
					w: 141,
					h: 236,
					src: '0021.png',
					show_level: hmUI.show_level.ONLY_NORMAL,
				})

				normal_digital_clock_img_minute_low5 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 234,
					y: 236,
					w: 234,
					h: 236,
					src: '0031.png',
					show_level: hmUI.show_level.ONLY_NORMAL,
				})

				normal_background_bg_img7 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 143,
					y: 408,
					w: 41,
					h: 55,
					src: '0032.png',
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_step_current_text_img8 = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
					x: 107,
					y: 366,
					font_array: ["0033.png","0034.png","0035.png","0036.png","0037.png","0038.png","0039.png","0040.png","0041.png","0042.png"],
					padding: false,
					h_space: -5,
					align_h: hmUI.align.CENTER_H,
					type: hmUI.data_type.STEP,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_background_bg_img10 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 258,
					y: 402,
					w: 75,
					h: 55,
					src: '0043.png',
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_distance_current_text_img11 = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
					x: 241,
					y: 366,
					font_array: ["0044.png","0045.png","0046.png","0047.png","0048.png","0049.png","0050.png","0051.png","0052.png","0053.png"],
					padding: false,
					h_space: -5,
					dot_image: '0054.png',
					align_h: hmUI.align.CENTER_H,
					type: hmUI.data_type.DISTANCE,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_background_bg_img13 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 31,
					y: 302,
					w: 59,
					h: 50,
					src: '0055.png',
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_heart_current_text_img14 = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
					x: 27,
					y: 252,
					font_array: ["0056.png","0057.png","0058.png","0059.png","0060.png","0061.png","0062.png","0063.png","0064.png","0065.png"],
					padding: false,
					h_space: -5,
					invalid_image: '0066.png',
					align_h: hmUI.align.CENTER_H,
					type: hmUI.data_type.HEART,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_background_bg_img16 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 385,
					y: 300,
					w: 42,
					h: 50,
					src: '0067.png',
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_calories_current_text_img17 = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
					x: 363,
					y: 252,
					font_array: ["0068.png","0069.png","0070.png","0071.png","0072.png","0073.png","0074.png","0075.png","0076.png","0077.png"],
					padding: false,
					h_space: -5,
					align_h: hmUI.align.CENTER_H,
					type: hmUI.data_type.CAL,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_background_bg_img19 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 38,
					y: 113,
					w: 47,
					h: 50,
					src: '0078.png',
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_blood_oxygen_text_img20 = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
					x: 25,
					y: 174,
					font_array: ["0079.png","0080.png","0081.png","0082.png","0083.png","0084.png","0085.png","0086.png","0087.png","0088.png"],
					padding: false,
					h_space: -5,
					align_h: hmUI.align.CENTER_H,
					type: hmUI.data_type.SPO2,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_background_bg_img22 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 125,
					y: 13,
					w: 81,
					h: 49,
					src: '0089.png',
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_battery_current_text_img23 = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
					x: 112,
					y: 57,
					font_array: ["0090.png","0091.png","0092.png","0093.png","0094.png","0095.png","0096.png","0097.png","0098.png","0099.png"],
					padding: false,
					h_space: -5,
					unit_sc: '0100.png',
					unit_tc: '0100.png',
					unit_en: '0100.png',
					align_h: hmUI.align.CENTER_H,
					type: hmUI.data_type.BATTERY,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				if (screenType != hmSetting.screen_type.AOD) {
					normal_battery_current_line24 = hmUI.createWidget(hmUI.widget.FILL_RECT);
				}

				normal_weather_image_progress_img_level26 = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
					x: 266,
					y: 9,
					image_array: ["0101.png","0102.png","0103.png","0104.png","0105.png","0106.png","0103.png","0107.png","0108.png","0109.png","0110.png","0111.png","0112.png","0113.png","0114.png","0115.png","0109.png","0116.png","0117.png","0118.png","0119.png","0107.png","0120.png","0121.png","0122.png","0123.png","0124.png","0125.png","0126.png"],
					image_length: 29,
					type: hmUI.data_type.WEATHER_CURRENT,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_temperature_current_text_img27 = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
					x: 246,
					y: 57,
					font_array: ["0090.png","0091.png","0092.png","0093.png","0094.png","0095.png","0096.png","0097.png","0098.png","0099.png"],
					padding: false,
					h_space: -5,
					unit_sc: ["0128.png"],
					unit_tc: ["0128.png"],
					unit_en: ["0128.png"],
					negative_image: ["0127.png"],
					invalid_image: ["0129.png"],
					align_h: hmUI.align.CENTER_H,
					type: hmUI.data_type.WEATHER_CURRENT,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_date_img_date_week_img29 = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
					x: 366,
					y: 113,
					week_en: ["0130.png","0131.png","0132.png","0133.png","0134.png","0135.png","0136.png"],
					week_tc: ["0130.png","0131.png","0132.png","0133.png","0134.png","0135.png","0136.png"],
					week_sc: ["0130.png","0131.png","0132.png","0133.png","0134.png","0135.png","0136.png"],
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_date_current_date_monthday30 = hmUI.createWidget(hmUI.widget.IMG_DATE, {
					day_startX: 347,
					day_startY: 174,
					day_sc_array: ["0137.png","0138.png","0139.png","0140.png","0141.png","0142.png","0143.png","0144.png","0145.png","0146.png"],
					day_tc_array: ["0137.png","0138.png","0139.png","0140.png","0141.png","0142.png","0143.png","0144.png","0145.png","0146.png"],
					day_en_array: ["0137.png","0138.png","0139.png","0140.png","0141.png","0142.png","0143.png","0144.png","0145.png","0146.png"],
					day_zero: true,
					day_space: -5,
					day_align: hmUI.align.CENTER_H,
					day_is_character: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_date_current_date_month31 = hmUI.createWidget(hmUI.widget.IMG_DATE, {
					month_startX: 407,
					month_startY: 174,
					month_sc_array: ["0137.png","0138.png","0139.png","0140.png","0141.png","0142.png","0143.png","0144.png","0145.png","0146.png"],
					month_tc_array: ["0137.png","0138.png","0139.png","0140.png","0141.png","0142.png","0143.png","0144.png","0145.png","0146.png"],
					month_en_array: ["0137.png","0138.png","0139.png","0140.png","0141.png","0142.png","0143.png","0144.png","0145.png","0146.png"],
					month_zero: true,
					month_space: -5,
					month_align: hmUI.align.CENTER_H,
					month_is_character: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_background_bg_img32 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 395,
					y: 172,
					w: 15,
					h: 49,
					src: '0147.png',
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				const timeSensor = hmSensor.createSensor(hmSensor.id.TIME);
				timeSensor.addEventListener(hmSensor.event.CHANGE, function() {
					updateImageCombos();
				});

				const batterySensor = hmSensor.createSensor(hmSensor.id.BATTERY);
				batterySensor.addEventListener(hmSensor.event.CHANGE, function() {
				});

				function updateImageCombos() {
					normal_digital_clock_img_hour_high2.setProperty(hmUI.prop.MORE, {
						src: normal_digital_clock_img_hour_high2_array[(timeSensor.hour.toString().length == 2 ? timeSensor.hour.toString().charAt(0) : 0)]
					})
					normal_digital_clock_img_hour_low3.setProperty(hmUI.prop.MORE, {
						src: normal_digital_clock_img_hour_low3_array[(timeSensor.hour.toString().length == 2 ? timeSensor.hour.toString().charAt(1) : timeSensor.hour.toString().charAt(0))]
					})
					normal_digital_clock_img_minute_high4.setProperty(hmUI.prop.MORE, {
						src: normal_digital_clock_img_minute_high4_array[(timeSensor.minute.toString().length == 2 ? timeSensor.minute.toString().charAt(0) : 0)]
					})
					normal_digital_clock_img_minute_low5.setProperty(hmUI.prop.MORE, {
						src: normal_digital_clock_img_minute_low5_array[(timeSensor.minute.toString().length == 2 ? timeSensor.minute.toString().charAt(1) : timeSensor.minute.toString().charAt(0))]
					})
				};

				function updateScales() {
					var valueBattery = batterySensor.current;
					var targetBattery = 100;
					var progressBattery = valueBattery/targetBattery;

					if (progressBattery < 0) {
						progressBattery = 0;
					}

					if (progressBattery > 1) {
						progressBattery = 1;
					}

					var progress_ls_normal_battery = progressBattery;

					if (screenType != hmSetting.screen_type.AOD) {
						// initial parameters
						var start_x_normal_battery = 139;
						var start_y_normal_battery = 28;
						var lenght_ls_normal_battery = 45;
						var line_width_ls_normal_battery = 19;
						var color_ls_normal_battery = 0xFFEB8642;
						// calculated parameters
						var start_x_normal_battery_draw = start_x_normal_battery;
						var start_y_normal_battery_draw = start_y_normal_battery;
						lenght_ls_normal_battery = lenght_ls_normal_battery * progress_ls_normal_battery;
						var lenght_ls_normal_battery_draw = lenght_ls_normal_battery;
						var line_width_ls_normal_battery_draw = line_width_ls_normal_battery;
						if (lenght_ls_normal_battery < 0) {
							lenght_ls_normal_battery_draw = -lenght_ls_normal_battery;
							start_x_normal_battery_draw = start_x_normal_battery - lenght_ls_normal_battery_draw;
						}
						normal_battery_current_line24.setProperty(hmUI.prop.MORE, {
							x: start_x_normal_battery_draw,
							y: start_y_normal_battery_draw,
							w: lenght_ls_normal_battery_draw,
							h: line_width_ls_normal_battery_draw,
							color: color_ls_normal_battery,
						});

					};

				};

				const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
					resume_call: (function () {
						updateImageCombos();

						updateScales();

					}),
					pause_call: (function () {
					}),
				})
			},

		onInit() {
			console.log('index page.js on init invoke')
			this.init_view()
		},
		onReady() {
			console.log('index page.js on ready invoke')
		},
		onShow() {
			console.log('index page.js on show invoke')
		},
		onHide() {
			console.log('index page.js on hide invoke')
		},
		onDestroy() {
			console.log('index page.js on destroy invoke')
		},
	});	})()
} catch (e) {
	console.log(e)
}