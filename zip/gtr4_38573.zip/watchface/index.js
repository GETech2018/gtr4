﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        const logger = Logger.getLogger('watchface_SashaCX75');
        //end of ignored block

        //dynamic modify start

        
        let editBg = ''
        let normal_calorie_current_text_img = ''
        let normal_heart_rate_text_text_img = ''
        let normal_heart_rate_image_progress_img_level = ''
        let normal_uvi_text_text_img = ''
        let normal_humidity_text_text_img = ''
        let normal_distance_text_text_img = ''
        let normal_wind_text_text_img = ''
        let normal_altitude_target_text_img = ''
        let normal_altimeter_text_text_img = ''
        let normal_step_current_text_img = ''
        let normal_battery_linear_scale = ''
        let normal_battery_text_text_img = ''
        let normal_system_disconnect_img = ''
        let normal_system_clock_img = ''
        let normal_date_img_date_year = ''
        let normal_date_img_date_month_img = ''
        let normal_date_img_date_day = ''
        let normal_date_img_date_week_img = ''
        let normal_sun_current_text_img = ''
        let normal_sun_current_separator_img = ''
        let normal_moon_image_progress_img_level = ''
        let normal_city_name_text = ''
        let normal_temperature_high_text_img = ''
        let normal_temperature_low_text_img = ''
        let normal_temperature_current_text_img = ''
        let normal_weather_image_progress_img_level = ''
        let normal_digital_clock_img_time_AmPm = ''
        let normal_digital_clock_img_time = ''
        let normal_digital_clock_hour_separator_img = ''
        let idle_calorie_current_text_img = ''
        let idle_heart_rate_text_text_img = ''
        let idle_heart_rate_image_progress_img_level = ''
        let idle_uvi_text_text_img = ''
        let idle_humidity_text_text_img = ''
        let idle_distance_text_text_img = ''
        let idle_wind_text_text_img = ''
        let idle_altitude_target_text_img = ''
        let idle_altimeter_text_text_img = ''
        let idle_step_current_text_img = ''
        let idle_battery_linear_scale = ''
        let idle_battery_text_text_img = ''
        let idle_system_disconnect_img = ''
        let idle_system_clock_img = ''
        let idle_date_img_date_year = ''
        let idle_date_img_date_month_img = ''
        let idle_date_img_date_day = ''
        let idle_date_img_date_week_img = ''
        let idle_sun_current_text_img = ''
        let idle_sun_current_separator_img = ''
        let idle_moon_image_progress_img_level = ''
        let idle_city_name_text = ''
        let idle_temperature_high_text_img = ''
        let idle_temperature_low_text_img = ''
        let idle_temperature_current_text_img = ''
        let idle_weather_image_progress_img_level = ''
        let idle_digital_clock_img_time_AmPm = ''
        let idle_digital_clock_img_time = ''
        let idle_digital_clock_hour_separator_img = ''
        let normal_sunrise_jumpable_img_click = ''
        let normal_altimeter_jumpable_img_click = ''
        let normal_temperature_jumpable_img_click = ''
        let normal_heart_jumpable_img_click = ''
        let Button_1 = ''
        let Button_2 = ''
        let Button_3 = ''
        let Button_4 = ''
        let Button_5 = ''
        let Button_6 = ''


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            console.log('Watch_Face.ScreenNormal');
            editBg = hmUI.createWidget(hmUI.widget.WATCHFACE_EDIT_BG, {
              edit_id: 1002,
              x: 0,
              y: 0,
              // w: 466,
              // h: 466,
              // AOD_show: True,
              bg_config: [
                { id: 1, preview: 'bg_edit_1_preview.png', path: '02.png' },
                { id: 2, preview: 'bg_edit_2_preview.png', path: '01White.png' },
                { id: 3, preview: 'bg_edit_3_preview.png', path: '03Nau.png' },
                { id: 4, preview: 'bg_edit_4_preview.png', path: '04purble.png' },
              ],
              count: 4,
              default_id: 1,
              fg: '.png',
              tips_bg: '.png',
              tips_x: 0,
              tips_y: 0,
            });

            normal_calorie_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 383,
              y: 250,
              font_array: ["nho_0.png","nho_1.png","nho_2.png","nho_3.png","nho_4.png","nho_5.png","nho_6.png","nho_7.png","nho_8.png","nho_9.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 306,
              y: 374,
              font_array: ["nho_0.png","nho_1.png","nho_2.png","nho_3.png","nho_4.png","nho_5.png","nho_6.png","nho_7.png","nho_8.png","nho_9.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 207,
              y: 374,
              image_array: ["h01.png","h02.png","h03.png","h04.png","h05.png","h06.png"],
              image_length: 6,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_uvi_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 195,
              y: 334,
              font_array: ["nho_0.png","nho_1.png","nho_2.png","nho_3.png","nho_4.png","nho_5.png","nho_6.png","nho_7.png","nho_8.png","nho_9.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.UVI,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_humidity_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 102,
              y: 334,
              font_array: ["nho_0.png","nho_1.png","nho_2.png","nho_3.png","nho_4.png","nho_5.png","nho_6.png","nho_7.png","nho_8.png","nho_9.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.HUMIDITY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_distance_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 247,
              y: 293,
              font_array: ["nho_0.png","nho_1.png","nho_2.png","nho_3.png","nho_4.png","nho_5.png","nho_6.png","nho_7.png","nho_8.png","nho_9.png"],
              padding: false,
              h_space: 0,
              dot_image: 'Puntos.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.DISTANCE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_wind_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 394,
              y: 292,
              font_array: ["nho_0.png","nho_1.png","nho_2.png","nho_3.png","nho_4.png","nho_5.png","nho_6.png","nho_7.png","nho_8.png","nho_9.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.WIND,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_altitude_target_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 289,
              y: 333,
              font_array: ["nho_0.png","nho_1.png","nho_2.png","nho_3.png","nho_4.png","nho_5.png","nho_6.png","nho_7.png","nho_8.png","nho_9.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.ALTITUDE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_altimeter_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 103,
              y: 375,
              font_array: ["nho_0.png","nho_1.png","nho_2.png","nho_3.png","nho_4.png","nho_5.png","nho_6.png","nho_7.png","nho_8.png","nho_9.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.ALTIMETER,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 74,
              y: 292,
              font_array: ["nho_0.png","nho_1.png","nho_2.png","nho_3.png","nho_4.png","nho_5.png","nho_6.png","nho_7.png","nho_8.png","nho_9.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            let screenType = hmSetting.getScreenType();
            if (screenType != hmSetting.screen_type.AOD) {
              normal_battery_linear_scale = hmUI.createWidget(hmUI.widget.FILL_RECT);
            };

            // normal_battery_linear_scale = hmUI.createWidget(hmUI.widget.Linear_Scale, {
              // start_x: 217,
              // start_y: 451,
              // color: 0xFF00FF00,
              // lenght: 44,
              // line_width: 9,
              // line_cap: Rounded,
              // vertical: False,
              // mirror: False,
              // inversion: False,
              // type: hmUI.data_type.BATTERY,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });
            
            const battery = hmSensor.createSensor(hmSensor.id.BATTERY);
            battery.addEventListener(hmSensor.event.CHANGE, function() {
              scale_call();
            });

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 197,
              y: 414,
              font_array: ["nho_0.png","nho_1.png","nho_2.png","nho_3.png","nho_4.png","nho_5.png","nho_6.png","nho_7.png","nho_8.png","nho_9.png"],
              padding: false,
              h_space: 0,
              unit_sc: '0053.png',
              unit_tc: '0053.png',
              unit_en: '0053.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 355,
              y: 62,
              src: 's01.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 335,
              y: 99,
              src: 'Red-Alarm-Clock-PNG.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_year = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              year_startX: 198,
              year_startY: 248,
              year_sc_array: ["nho_0.png","nho_1.png","nho_2.png","nho_3.png","nho_4.png","nho_5.png","nho_6.png","nho_7.png","nho_8.png","nho_9.png"],
              year_tc_array: ["nho_0.png","nho_1.png","nho_2.png","nho_3.png","nho_4.png","nho_5.png","nho_6.png","nho_7.png","nho_8.png","nho_9.png"],
              year_en_array: ["nho_0.png","nho_1.png","nho_2.png","nho_3.png","nho_4.png","nho_5.png","nho_6.png","nho_7.png","nho_8.png","nho_9.png"],
              year_zero: 1,
              year_space: 0,
              year_align: hmUI.align.CENTER_H,
              year_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_month_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 123,
              month_startY: 258,
              month_sc_array: ["M01.png","M02.png","M03.png","M04.png","M05.png","M06.png","M07.png","M08.png","M09.png","M10.png","M11.png","M12.png"],
              month_tc_array: ["M01.png","M02.png","M03.png","M04.png","M05.png","M06.png","M07.png","M08.png","M09.png","M10.png","M11.png","M12.png"],
              month_en_array: ["M01.png","M02.png","M03.png","M04.png","M05.png","M06.png","M07.png","M08.png","M09.png","M10.png","M11.png","M12.png"],
              month_is_character: true ,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 73,
              day_startY: 248,
              day_sc_array: ["nho_0.png","nho_1.png","nho_2.png","nho_3.png","nho_4.png","nho_5.png","nho_6.png","nho_7.png","nho_8.png","nho_9.png"],
              day_tc_array: ["nho_0.png","nho_1.png","nho_2.png","nho_3.png","nho_4.png","nho_5.png","nho_6.png","nho_7.png","nho_8.png","nho_9.png"],
              day_en_array: ["nho_0.png","nho_1.png","nho_2.png","nho_3.png","nho_4.png","nho_5.png","nho_6.png","nho_7.png","nho_8.png","nho_9.png"],
              day_zero: 0,
              day_space: 0,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 5,
              y: 258,
              week_en: ["D1.png","D2.png","D3.png","D4.png","D5.png","D6.png","D7.png"],
              week_tc: ["D1.png","D2.png","D3.png","D4.png","D5.png","D6.png","D7.png"],
              week_sc: ["D1.png","D2.png","D3.png","D4.png","D5.png","D6.png","D7.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sun_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 45,
              y: 91,
              font_array: ["nho_0.png","nho_1.png","nho_2.png","nho_3.png","nho_4.png","nho_5.png","nho_6.png","nho_7.png","nho_8.png","nho_9.png"],
              padding: false,
              h_space: -2,
              dot_image: 'nho_hai_cham.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.SUN_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sun_current_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 76,
              y: 69,
              src: 'sol.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_moon_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 284,
              y: 79,
              image_array: ["moon_01.png","moon_02.png","moon_03.png","moon_04.png","moon_05.png","moon_06.png","moon_07.png","moon_08.png"],
              image_length: 8,
              type: hmUI.data_type.MOON,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
              const weatherSensor = hmSensor.createSensor(hmSensor.id.WEATHER);

            normal_city_name_text = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 150,
              y: 106,
              w: 150,
              h: 30,
              text_size: 21,
              char_space: 0,
              line_space: 0,
              color: 0xFF80FFFF,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_high_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 273,
              y: 35,
              font_array: ["nho_0.png","nho_1.png","nho_2.png","nho_3.png","nho_4.png","nho_5.png","nho_6.png","nho_7.png","nho_8.png","nho_9.png"],
              padding: false,
              h_space: 0,
              unit_sc: '0044.png',
              unit_tc: '0044.png',
              unit_en: '0044.png',
              negative_image: '0024.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_HIGH,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_low_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 112,
              y: 35,
              font_array: ["nho_0.png","nho_1.png","nho_2.png","nho_3.png","nho_4.png","nho_5.png","nho_6.png","nho_7.png","nho_8.png","nho_9.png"],
              padding: false,
              h_space: 0,
              unit_sc: '0044.png',
              unit_tc: '0044.png',
              unit_en: '0044.png',
              negative_image: '0024.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_LOW,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 185,
              y: 72,
              font_array: ["nho_0.png","nho_1.png","nho_2.png","nho_3.png","nho_4.png","nho_5.png","nho_6.png","nho_7.png","nho_8.png","nho_9.png"],
              padding: false,
              h_space: 3,
              unit_sc: '0044.png',
              unit_tc: '0044.png',
              unit_en: '0044.png',
              negative_image: '0024.png',
              invalid_image: 'invalid.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 198,
              y: 0,
              image_array: ["C01.png","C02.png","C03.png","C04.png","C05.png","C06.png","C07.png","C08.png","C09.png","C10.png","C11.png","C12.png","C13.png","C14.png","C15.png","C16.png","C17.png","C18.png","C19.png","C20.png","C21.png","C22.png","C23.png","C24.png","C25.png","C26.png","C27.png","C28.png","C29.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time_AmPm = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              am_x: 356,
              am_y: 130,
              am_sc_path: 'Clock_AM.png',
              am_en_path: 'Clock_AM.png',
              pm_x: 356,
              pm_y: 130,
              pm_sc_path: 'Clock_PM.png',
              pm_en_path: 'Clock_PM.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: -1,
              hour_startY: 78,
              hour_array: ["L0.png","L1.png","L2.png","L3.png","L4.png","L5.png","L6.png","L7.png","L8.png","L9.png"],
              hour_zero: 1,
              hour_space: -37,
              hour_angle: 0,
              hour_align: hmUI.align.CENTER_H,

              minute_startX: 175,
              minute_startY: 78,
              minute_array: ["L0.png","L1.png","L2.png","L3.png","L4.png","L5.png","L6.png","L7.png","L8.png","L9.png"],
              minute_zero: 1,
              minute_space: -38,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.CENTER_H,

              second_startX: 347,
              second_startY: 168,
              second_array: ["0.png","1.png","2.png","3.png","4.png","5.png","6.png","7.png","8.png","9.png"],
              second_zero: 1,
              second_space: 7,
              second_angle: 0,
              second_follow: 0,
              second_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_hour_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 167,
              y: 150,
              src: 's_dot.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            console.log('Watch_Face.ScreenAOD');

            idle_calorie_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 383,
              y: 250,
              font_array: ["nho_0.png","nho_1.png","nho_2.png","nho_3.png","nho_4.png","nho_5.png","nho_6.png","nho_7.png","nho_8.png","nho_9.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 306,
              y: 374,
              font_array: ["nho_0.png","nho_1.png","nho_2.png","nho_3.png","nho_4.png","nho_5.png","nho_6.png","nho_7.png","nho_8.png","nho_9.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_heart_rate_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 207,
              y: 374,
              image_array: ["h01.png","h02.png","h03.png","h04.png","h05.png","h06.png"],
              image_length: 6,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_uvi_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 195,
              y: 334,
              font_array: ["nho_0.png","nho_1.png","nho_2.png","nho_3.png","nho_4.png","nho_5.png","nho_6.png","nho_7.png","nho_8.png","nho_9.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.UVI,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_humidity_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 102,
              y: 334,
              font_array: ["nho_0.png","nho_1.png","nho_2.png","nho_3.png","nho_4.png","nho_5.png","nho_6.png","nho_7.png","nho_8.png","nho_9.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.HUMIDITY,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_distance_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 247,
              y: 293,
              font_array: ["nho_0.png","nho_1.png","nho_2.png","nho_3.png","nho_4.png","nho_5.png","nho_6.png","nho_7.png","nho_8.png","nho_9.png"],
              padding: false,
              h_space: 0,
              dot_image: 'Puntos.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.DISTANCE,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_wind_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 394,
              y: 292,
              font_array: ["nho_0.png","nho_1.png","nho_2.png","nho_3.png","nho_4.png","nho_5.png","nho_6.png","nho_7.png","nho_8.png","nho_9.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.WIND,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_altitude_target_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 289,
              y: 333,
              font_array: ["nho_0.png","nho_1.png","nho_2.png","nho_3.png","nho_4.png","nho_5.png","nho_6.png","nho_7.png","nho_8.png","nho_9.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.ALTITUDE,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_altimeter_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 103,
              y: 375,
              font_array: ["nho_0.png","nho_1.png","nho_2.png","nho_3.png","nho_4.png","nho_5.png","nho_6.png","nho_7.png","nho_8.png","nho_9.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.ALTIMETER,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 74,
              y: 292,
              font_array: ["nho_0.png","nho_1.png","nho_2.png","nho_3.png","nho_4.png","nho_5.png","nho_6.png","nho_7.png","nho_8.png","nho_9.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            if (screenType == hmSetting.screen_type.AOD) {
              idle_battery_linear_scale = hmUI.createWidget(hmUI.widget.FILL_RECT);
            };

            // idle_battery_linear_scale = hmUI.createWidget(hmUI.widget.Linear_Scale, {
              // start_x: 217,
              // start_y: 451,
              // color: 0xFF00FF00,
              // lenght: 44,
              // line_width: 9,
              // line_cap: Flat,
              // vertical: False,
              // mirror: False,
              // inversion: False,
              // type: hmUI.data_type.BATTERY,
              // show_level: hmUI.show_level.ONLY_AOD,
            // });

            idle_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 197,
              y: 414,
              font_array: ["nho_0.png","nho_1.png","nho_2.png","nho_3.png","nho_4.png","nho_5.png","nho_6.png","nho_7.png","nho_8.png","nho_9.png"],
              padding: false,
              h_space: 0,
              unit_sc: '0053.png',
              unit_tc: '0053.png',
              unit_en: '0053.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 355,
              y: 62,
              src: 's01.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 335,
              y: 99,
              src: 'Red-Alarm-Clock-PNG.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_year = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              year_startX: 198,
              year_startY: 248,
              year_sc_array: ["nho_0.png","nho_1.png","nho_2.png","nho_3.png","nho_4.png","nho_5.png","nho_6.png","nho_7.png","nho_8.png","nho_9.png"],
              year_tc_array: ["nho_0.png","nho_1.png","nho_2.png","nho_3.png","nho_4.png","nho_5.png","nho_6.png","nho_7.png","nho_8.png","nho_9.png"],
              year_en_array: ["nho_0.png","nho_1.png","nho_2.png","nho_3.png","nho_4.png","nho_5.png","nho_6.png","nho_7.png","nho_8.png","nho_9.png"],
              year_zero: 1,
              year_space: 0,
              year_align: hmUI.align.CENTER_H,
              year_is_character: false,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_month_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 123,
              month_startY: 258,
              month_sc_array: ["M01.png","M02.png","M03.png","M04.png","M05.png","M06.png","M07.png","M08.png","M09.png","M10.png","M11.png","M12.png"],
              month_tc_array: ["M01.png","M02.png","M03.png","M04.png","M05.png","M06.png","M07.png","M08.png","M09.png","M10.png","M11.png","M12.png"],
              month_en_array: ["M01.png","M02.png","M03.png","M04.png","M05.png","M06.png","M07.png","M08.png","M09.png","M10.png","M11.png","M12.png"],
              month_is_character: true ,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 73,
              day_startY: 248,
              day_sc_array: ["nho_0.png","nho_1.png","nho_2.png","nho_3.png","nho_4.png","nho_5.png","nho_6.png","nho_7.png","nho_8.png","nho_9.png"],
              day_tc_array: ["nho_0.png","nho_1.png","nho_2.png","nho_3.png","nho_4.png","nho_5.png","nho_6.png","nho_7.png","nho_8.png","nho_9.png"],
              day_en_array: ["nho_0.png","nho_1.png","nho_2.png","nho_3.png","nho_4.png","nho_5.png","nho_6.png","nho_7.png","nho_8.png","nho_9.png"],
              day_zero: 0,
              day_space: 0,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 5,
              y: 258,
              week_en: ["D1.png","D2.png","D3.png","D4.png","D5.png","D6.png","D7.png"],
              week_tc: ["D1.png","D2.png","D3.png","D4.png","D5.png","D6.png","D7.png"],
              week_sc: ["D1.png","D2.png","D3.png","D4.png","D5.png","D6.png","D7.png"],
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_sun_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 45,
              y: 91,
              font_array: ["nho_0.png","nho_1.png","nho_2.png","nho_3.png","nho_4.png","nho_5.png","nho_6.png","nho_7.png","nho_8.png","nho_9.png"],
              padding: false,
              h_space: -2,
              dot_image: 'nho_hai_cham.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.SUN_CURRENT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_sun_current_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 76,
              y: 69,
              src: 'sol.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_moon_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 284,
              y: 79,
              image_array: ["moon_01.png","moon_02.png","moon_03.png","moon_04.png","moon_05.png","moon_06.png","moon_07.png","moon_08.png"],
              image_length: 8,
              type: hmUI.data_type.MOON,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_city_name_text = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 150,
              y: 106,
              w: 150,
              h: 30,
              text_size: 21,
              char_space: 0,
              line_space: 0,
              color: 0xFF80FFFF,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_temperature_high_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 273,
              y: 35,
              font_array: ["nho_0.png","nho_1.png","nho_2.png","nho_3.png","nho_4.png","nho_5.png","nho_6.png","nho_7.png","nho_8.png","nho_9.png"],
              padding: false,
              h_space: 0,
              unit_sc: '0044.png',
              unit_tc: '0044.png',
              unit_en: '0044.png',
              negative_image: '0024.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_HIGH,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_temperature_low_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 112,
              y: 35,
              font_array: ["nho_0.png","nho_1.png","nho_2.png","nho_3.png","nho_4.png","nho_5.png","nho_6.png","nho_7.png","nho_8.png","nho_9.png"],
              padding: false,
              h_space: 0,
              unit_sc: '0044.png',
              unit_tc: '0044.png',
              unit_en: '0044.png',
              negative_image: '0024.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_LOW,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 185,
              y: 72,
              font_array: ["nho_0.png","nho_1.png","nho_2.png","nho_3.png","nho_4.png","nho_5.png","nho_6.png","nho_7.png","nho_8.png","nho_9.png"],
              padding: false,
              h_space: 3,
              unit_sc: '0044.png',
              unit_tc: '0044.png',
              unit_en: '0044.png',
              negative_image: '0024.png',
              invalid_image: 'invalid.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 198,
              y: 0,
              image_array: ["C01.png","C02.png","C03.png","C04.png","C05.png","C06.png","C07.png","C08.png","C09.png","C10.png","C11.png","C12.png","C13.png","C14.png","C15.png","C16.png","C17.png","C18.png","C19.png","C20.png","C21.png","C22.png","C23.png","C24.png","C25.png","C26.png","C27.png","C28.png","C29.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time_AmPm = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              am_x: 356,
              am_y: 130,
              am_sc_path: 'Clock_AM.png',
              am_en_path: 'Clock_AM.png',
              pm_x: 356,
              pm_y: 130,
              pm_sc_path: 'Clock_PM.png',
              pm_en_path: 'Clock_PM.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: -1,
              hour_startY: 78,
              hour_array: ["L0.png","L1.png","L2.png","L3.png","L4.png","L5.png","L6.png","L7.png","L8.png","L9.png"],
              hour_zero: 1,
              hour_space: -37,
              hour_angle: 0,
              hour_align: hmUI.align.CENTER_H,

              minute_startX: 175,
              minute_startY: 78,
              minute_array: ["L0.png","L1.png","L2.png","L3.png","L4.png","L5.png","L6.png","L7.png","L8.png","L9.png"],
              minute_zero: 1,
              minute_space: -38,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.CENTER_H,

              second_startX: 347,
              second_startY: 168,
              second_array: ["0.png","1.png","2.png","3.png","4.png","5.png","6.png","7.png","8.png","9.png"],
              second_zero: 1,
              second_space: 7,
              second_angle: 0,
              second_follow: 0,
              second_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_hour_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 167,
              y: 150,
              src: 's_dot.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });
            
            // disconnectAlert = hmUI.createWidget(hmUI.widget.DisconnectAlert, {
              // disconneсnt_vibrate_type: 1,
              // disconneсnt_toast_text: BT LOST,
              // conneсnt_vibrate_type: 1,
              // conneсnt_toast_text: BT ON,
            // });

            // vibration when connecting or disconnecting

            function checkConnection() {
              console.log('checkConnection()');
              hmBle.removeListener;
              hmBle.addListener(function (status) {
                if(!status) {
                  hmUI.showToast({text: "BT LOST"});
                  vibro(1);
                }
                if(status) {
                  hmUI.showToast({text: "BT ON"});
                  vibro(1);
                }
              });
            }

            // end vibration when connecting or disconnecting
            // vibrate function

            const vibrate = hmSensor.createSensor(hmSensor.id.VIBRATE);
            let timer_StopVibrate = null;


            function vibro(scene = 25) {
              let stopDelay = 50;
              stopVibro();
              vibrate.stop();
              vibrate.scene = scene;
              if(scene < 23 || scene > 25) stopDelay = 1300;
              vibrate.start();
              if (scene != 1) timer_StopVibrate = timer.createTimer(stopDelay, 3000, stopVibro, {});
            }

            function stopVibro(){
              vibrate.stop();
              if(timer_StopVibrate) timer.stopTimer(timer_StopVibrate);
            }

            // end vibrate function
            console.log('Watch_Face.Shortcuts');

            normal_sunrise_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 47,
              y: 76,
              w: 119,
              h: 63,
              type: hmUI.data_type.SUN_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_altimeter_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 67,
              y: 376,
              w: 152,
              h: 101,
              type: hmUI.data_type.ALTIMETER,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 86,
              y: 7,
              w: 79,
              h: 69,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 252,
              y: 376,
              w: 149,
              h: 110,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            console.log('Watch_Face.Buttons');
            Button_1 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 348,
              y: 142,
              w: 160,
              h: 99,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'transparent.png',
              normal_src: 'transparent.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'AlarmInfoScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_2 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 183,
              y: 142,
              w: 160,
              h: 99,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'transparent.png',
              normal_src: 'transparent.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'menstrualAppScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_3 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 6,
              y: 142,
              w: 178,
              h: 99,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'transparent.png',
              normal_src: 'transparent.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'WorldClockScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_4 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 168,
              y: 4,
              w: 147,
              h: 134,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'transparent.png',
              normal_src: 'transparent.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'WeatherScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_5 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 16,
              y: 246,
              w: 279,
              h: 49,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'transparent.png',
              normal_src: 'transparent.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'ScheduleCalScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_6 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 324,
              y: 54,
              w: 100,
              h: 79,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'transparent.png',
              normal_src: 'transparent.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'FindPhoneScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            function scale_call() {
              console.log('scale_call()');

                console.log('update scales BATTERY');
                
                let valueBattery = battery.current;
                let targetBattery = 100;
                let progressBattery = valueBattery/targetBattery;
                if (progressBattery > 1) progressBattery = 1;
                let progress_ls_normal_battery = progressBattery;

                if (screenType != hmSetting.screen_type.AOD) {

                  // normal_battery_linear_scale
                  // initial parameters
                  let start_x_normal_battery = 217;
                  let start_y_normal_battery = 451;
                  let lenght_ls_normal_battery = 44;
                  let line_width_ls_normal_battery = 9;
                  let color_ls_normal_battery = 0xFF00FF00;
                  
                  // calculated parameters
                  let start_x_normal_battery_draw = start_x_normal_battery;
                  let start_y_normal_battery_draw = start_y_normal_battery;
                  lenght_ls_normal_battery = lenght_ls_normal_battery * progress_ls_normal_battery;
                  let lenght_ls_normal_battery_draw = lenght_ls_normal_battery;
                  let line_width_ls_normal_battery_draw = line_width_ls_normal_battery;
                  if (lenght_ls_normal_battery < 0){
                    lenght_ls_normal_battery_draw = -lenght_ls_normal_battery;
                    start_x_normal_battery_draw = start_x_normal_battery - lenght_ls_normal_battery_draw;
                  };
                  
                  normal_battery_linear_scale.setProperty(hmUI.prop.MORE, {
                    x: start_x_normal_battery_draw,
                    y: start_y_normal_battery_draw,
                    w: lenght_ls_normal_battery_draw,
                    h: line_width_ls_normal_battery_draw,
                    radius: 4,
                    color: color_ls_normal_battery,
                  });
                };

              console.log('Weather city name');
              let weatherData = weatherSensor.getForecastWeather();
              normal_city_name_text.setProperty(hmUI.prop.TEXT, weatherData.cityName);

                console.log('update scales BATTERY');
                let progress_ls_idle_battery = progressBattery;

                if (screenType == hmSetting.screen_type.AOD) {

                  // idle_battery_linear_scale
                  // initial parameters
                  let start_x_idle_battery = 217;
                  let start_y_idle_battery = 451;
                  let lenght_ls_idle_battery = 44;
                  let line_width_ls_idle_battery = 9;
                  let color_ls_idle_battery = 0xFF00FF00;
                  
                  // calculated parameters
                  let start_x_idle_battery_draw = start_x_idle_battery;
                  let start_y_idle_battery_draw = start_y_idle_battery;
                  lenght_ls_idle_battery = lenght_ls_idle_battery * progress_ls_idle_battery;
                  let lenght_ls_idle_battery_draw = lenght_ls_idle_battery;
                  let line_width_ls_idle_battery_draw = line_width_ls_idle_battery;
                  if (lenght_ls_idle_battery < 0){
                    lenght_ls_idle_battery_draw = -lenght_ls_idle_battery;
                    start_x_idle_battery_draw = start_x_idle_battery - lenght_ls_idle_battery_draw;
                  };
                  
                  idle_battery_linear_scale.setProperty(hmUI.prop.MORE, {
                    x: start_x_idle_battery_draw,
                    y: start_y_idle_battery_draw,
                    w: lenght_ls_idle_battery_draw,
                    h: line_width_ls_idle_battery_draw,
                    color: color_ls_idle_battery,
                  });
                };

              console.log('Weather city name');
              idle_city_name_text.setProperty(hmUI.prop.TEXT, weatherData.cityName);

            };

            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                console.log('resume_call()');
                scale_call();
                checkConnection();
                stopVibro();

              }),
              pause_call: (function () {
                console.log('pause_call()');
                stopVibro();

              }),
            });

                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}