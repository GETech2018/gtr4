﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        const logger = Logger.getLogger('watchface_SashaCX75');
        //end of ignored block

        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_date_img_date_month = ''
        let normal_date_img_date_day = ''
        let normal_battery_text_text_img = ''
        let normal_digital_clock_img_time = ''
        let idle_digital_clock_img_time = ''
        let idle_hour_TextRotate = new Array(2);
        let idle_hour_TextRotate_ASCIIARRAY = new Array(10);
        let idle_hour_TextRotate_img_width = 201;
        let idle_timerTextUpdate = undefined;
        let idle_minute_TextRotate = new Array(2);
        let idle_minute_TextRotate_ASCIIARRAY = new Array(10);
        let idle_minute_TextRotate_img_width = 201;


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 466,
              h: 466,
              src: '0000.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_month = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 241,
              month_startY: 36,
              month_sc_array: ["0012.png","0013.png","0014.png","0015.png","0016.png","0017.png","0018.png","0019.png","0020.png","0021.png"],
              month_tc_array: ["0012.png","0013.png","0014.png","0015.png","0016.png","0017.png","0018.png","0019.png","0020.png","0021.png"],
              month_en_array: ["0012.png","0013.png","0014.png","0015.png","0016.png","0017.png","0018.png","0019.png","0020.png","0021.png"],
              month_zero: 0,
              month_space: -5,
              month_align: hmUI.align.LEFT,
              month_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 145,
              day_startY: 36,
              day_sc_array: ["0012.png","0013.png","0014.png","0015.png","0016.png","0017.png","0018.png","0019.png","0020.png","0021.png"],
              day_tc_array: ["0012.png","0013.png","0014.png","0015.png","0016.png","0017.png","0018.png","0019.png","0020.png","0021.png"],
              day_en_array: ["0012.png","0013.png","0014.png","0015.png","0016.png","0017.png","0018.png","0019.png","0020.png","0021.png"],
              day_zero: 0,
              day_space: -4,
              day_align: hmUI.align.RIGHT,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 205,
              y: 400,
              font_array: ["0012.png","0013.png","0014.png","0015.png","0016.png","0017.png","0018.png","0019.png","0020.png","0021.png"],
              padding: false,
              h_space: -6,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 50,
              hour_startY: 95,
              hour_array: ["0001.png","0002.png","0003.png","0004.png","0005.png","0006.png","0007.png","0008.png","0009.png","0010.png"],
              hour_zero: 1,
              hour_space: 0,
              hour_angle: 0,
              hour_align: hmUI.align.CENTER_H,

              minute_startX: 50,
              minute_startY: 237,
              minute_array: ["0001.png","0002.png","0003.png","0004.png","0005.png","0006.png","0007.png","0008.png","0009.png","0010.png"],
              minute_zero: 1,
              minute_space: 0,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.CENTER_H,

              second_startX: 396,
              second_startY: 213,
              second_array: ["0012.png","0013.png","0014.png","0015.png","0016.png","0017.png","0018.png","0019.png","0020.png","0021.png"],
              second_zero: 0,
              second_space: -6,
              second_angle: 0,
              second_follow: 0,
              second_align: hmUI.align.CENTER_H,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });



            idle_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 18,
              hour_startY: 54,
              hour_array: ["H1.0.png","H1.1.png","H1.2.png","H1.3.png","H1.4.png","H1.5.png","H1.6.png","H1.7.png","H1.8.png","H1.9.png"],
              hour_zero: 1,
              hour_space: 500,
              hour_angle: 0,
              hour_align: hmUI.align.CENTER_H,

              minute_startX: 88,
              minute_startY: 190,
              minute_array: ["M1.0.png","M1.1.png","M1.2.png","M1.3.png","M1.4.png","M1.5.png","M1.6.png","M1.7.png","M1.8.png","M1.9.png"],
              minute_zero: 1,
              minute_space: 500,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.CENTER_H,

              show_level: hmUI.show_level.ONLY_AOD,
            });

            // idle_hour_text_rotate_img = hmUI.createWidget(hmUI.widget.Text_Rotate, {
              // x: 350,
              // y: 6,
              // font_array: ["H2.0.png","H2.1.png","H2.2.png","H2.3.png","H2.4.png","H2.5.png","H2.6.png","H2.7.png","H2.8.png","H2.9.png"],
              // zero: true,
              // unit_in_alignment: false,
              // h_space: 500,
              // angle: 0,
              // align_h: hmUI.align.RIGHT,
              // type: hmUI.data_type.HOUR,
              // show_level: hmUI.show_level.ONLY_AOD,
            // });

            idle_hour_TextRotate_ASCIIARRAY[0] = 'H2.0.png';  // set of images with numbers
            idle_hour_TextRotate_ASCIIARRAY[1] = 'H2.1.png';  // set of images with numbers
            idle_hour_TextRotate_ASCIIARRAY[2] = 'H2.2.png';  // set of images with numbers
            idle_hour_TextRotate_ASCIIARRAY[3] = 'H2.3.png';  // set of images with numbers
            idle_hour_TextRotate_ASCIIARRAY[4] = 'H2.4.png';  // set of images with numbers
            idle_hour_TextRotate_ASCIIARRAY[5] = 'H2.5.png';  // set of images with numbers
            idle_hour_TextRotate_ASCIIARRAY[6] = 'H2.6.png';  // set of images with numbers
            idle_hour_TextRotate_ASCIIARRAY[7] = 'H2.7.png';  // set of images with numbers
            idle_hour_TextRotate_ASCIIARRAY[8] = 'H2.8.png';  // set of images with numbers
            idle_hour_TextRotate_ASCIIARRAY[9] = 'H2.9.png';  // set of images with numbers

            //start of ignored block
            for (let i = 0; i < 2; i++) {
              idle_hour_TextRotate[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 466,
                h: 466,
                center_x: 350,
                center_y: 6,
                pos_x: 350,
                pos_y: 6,
                angle: 0,
                src: 'H2.0.png',
                show_level: hmUI.show_level.ONLY_AOD,
              });
              idle_hour_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
            };
            //end of ignored block
            
            const timeNaw = hmSensor.createSensor(hmSensor.id.TIME);

            let screenType = hmSetting.getScreenType();
            // idle_minute_text_rotate_img = hmUI.createWidget(hmUI.widget.Text_Rotate, {
              // x: 439,
              // y: 140,
              // font_array: ["M2.0.png","M2.1.png","M2.2.png","M2.3.png","M2.4.png","M2.5.png","M2.6.png","M2.7.png","M2.8.png","M2.9.png"],
              // zero: true,
              // unit_in_alignment: false,
              // h_space: 500,
              // angle: 0,
              // align_h: hmUI.align.RIGHT,
              // type: hmUI.data_type.MINUTE,
              // show_level: hmUI.show_level.ONLY_AOD,
            // });

            idle_minute_TextRotate_ASCIIARRAY[0] = 'M2.0.png';  // set of images with numbers
            idle_minute_TextRotate_ASCIIARRAY[1] = 'M2.1.png';  // set of images with numbers
            idle_minute_TextRotate_ASCIIARRAY[2] = 'M2.2.png';  // set of images with numbers
            idle_minute_TextRotate_ASCIIARRAY[3] = 'M2.3.png';  // set of images with numbers
            idle_minute_TextRotate_ASCIIARRAY[4] = 'M2.4.png';  // set of images with numbers
            idle_minute_TextRotate_ASCIIARRAY[5] = 'M2.5.png';  // set of images with numbers
            idle_minute_TextRotate_ASCIIARRAY[6] = 'M2.6.png';  // set of images with numbers
            idle_minute_TextRotate_ASCIIARRAY[7] = 'M2.7.png';  // set of images with numbers
            idle_minute_TextRotate_ASCIIARRAY[8] = 'M2.8.png';  // set of images with numbers
            idle_minute_TextRotate_ASCIIARRAY[9] = 'M2.9.png';  // set of images with numbers

            //start of ignored block
            for (let i = 0; i < 2; i++) {
              idle_minute_TextRotate[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 466,
                h: 466,
                center_x: 439,
                center_y: 140,
                pos_x: 439,
                pos_y: 140,
                angle: 0,
                src: 'M2.0.png',
                show_level: hmUI.show_level.ONLY_AOD,
              });
              idle_minute_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
            };
            //end of ignored block

            function text_update() {

              console.log('update text rotate hour_TIME');
              let valueHour = timeNaw.hour;
              if (!timeNaw.is24Hour) {
                valueHour -= 12;
                if (valueHour < 1) valueHour += 12;
              };
              let idle_hour_rotate_string = parseInt(valueHour).toString();
              idle_hour_rotate_string = idle_hour_rotate_string.padStart(2, '0');

              if (screenType == hmSetting.screen_type.AOD) {
                for (var i = 1; i < 2; i++) {  // hide all symbols
                  idle_hour_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                if (valueHour != null && valueHour != undefined && isFinite(valueHour) && idle_hour_rotate_string.length > 0 && idle_hour_rotate_string.length < 6) {  // display data if it was possible to get it
                  let img_offset = 0;
                  // alignment = RIGHT
                  let idle_hour_TextRotate_posOffset = idle_hour_TextRotate_img_width * idle_hour_rotate_string.length;
                  idle_hour_TextRotate_posOffset = idle_hour_TextRotate_posOffset + 500 * (idle_hour_rotate_string.length - 1);
                  img_offset -= idle_hour_TextRotate_posOffset;
                  // alignment end
                  
                  let index = 0;
                  for (let char of idle_hour_rotate_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 2) break;
                    if (charCode >= 0 && charCode < 10) { 
                      idle_hour_TextRotate[index].setProperty(hmUI.prop.POS_X, 350 + img_offset);
                      idle_hour_TextRotate[index].setProperty(hmUI.prop.SRC, idle_hour_TextRotate_ASCIIARRAY[charCode]);
                      idle_hour_TextRotate[index].setProperty(hmUI.prop.VISIBLE, true);
                      img_offset += idle_hour_TextRotate_img_width + 500;
                      index++;
                    };  // end if digit
                  };  // end char of string
                }  // end isFinite

              };

              console.log('update text rotate minute_TIME');
              let valueMinute = timeNaw.minute;
              let idle_minute_rotate_string = parseInt(valueMinute).toString();
              idle_minute_rotate_string = idle_minute_rotate_string.padStart(2, '0');

              if (screenType == hmSetting.screen_type.AOD) {
                for (var i = 1; i < 2; i++) {  // hide all symbols
                  idle_minute_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                if (valueMinute != null && valueMinute != undefined && isFinite(valueMinute) && idle_minute_rotate_string.length > 0 && idle_minute_rotate_string.length < 6) {  // display data if it was possible to get it
                  let img_offset = 0;
                  // alignment = RIGHT
                  let idle_minute_TextRotate_posOffset = idle_minute_TextRotate_img_width * idle_minute_rotate_string.length;
                  idle_minute_TextRotate_posOffset = idle_minute_TextRotate_posOffset + 500 * (idle_minute_rotate_string.length - 1);
                  img_offset -= idle_minute_TextRotate_posOffset;
                  // alignment end
                  
                  let index = 0;
                  for (let char of idle_minute_rotate_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 2) break;
                    if (charCode >= 0 && charCode < 10) { 
                      idle_minute_TextRotate[index].setProperty(hmUI.prop.POS_X, 439 + img_offset);
                      idle_minute_TextRotate[index].setProperty(hmUI.prop.SRC, idle_minute_TextRotate_ASCIIARRAY[charCode]);
                      idle_minute_TextRotate[index].setProperty(hmUI.prop.VISIBLE, true);
                      img_offset += idle_minute_TextRotate_img_width + 500;
                      index++;
                    };  // end if digit
                  };  // end char of string
                }  // end isFinite

              };

            };

            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                text_update();
                if (screenType == hmSetting.screen_type.AOD) {
                  if (!idle_timerTextUpdate) {
                    idle_timerTextUpdate = timer.createTimer(0, 1000, (function (option) {
                      text_update();
                    }));  // end timer 
                  };  // end timer check
                };  // end screenType


              }),
              pause_call: (function () {
                if (idle_timerTextUpdate) {
                  timer.stopTimer(idle_timerTextUpdate);
                  idle_timerTextUpdate = undefined;
                }

              }),
            });

                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}