﻿
    /*
    ** Neo Digital watchface - Amazfit GTR 4 (466 x 466)
    ** old-style package format (API 1.0)
    */

    try {

      (() => {

        var __$$app$$__ = __$$hmAppManager$$__.currentApp;
        var __$$module$$__ = __$$app$$__.current;
        var h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__), 'drink');

        'use strict';

        const logger = DeviceRuntimeCore.HmLogger.getLogger("neo_digital");

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({

          init_view() {

            // ---------- background ----------
            hmUI.createWidget(hmUI.widget.IMG, { x: 0, y: 0, w: 466, h: 466, src: 'bg.png', show_level: hmUI.show_level.ONLY_NORMAL });

            // ---------- ghost rows (unlit digit slots) ----------
            hmUI.createWidget(hmUI.widget.IMG, { x: 213, y: 36, src: 'gbat.png', show_level: hmUI.show_level.ONLY_NORMAL });
            hmUI.createWidget(hmUI.widget.IMG, { x: 108, y: 320, src: 'ghr.png', show_level: hmUI.show_level.ONLY_NORMAL });
            hmUI.createWidget(hmUI.widget.IMG, { x: 266, y: 320, src: 'gstep.png', show_level: hmUI.show_level.ONLY_NORMAL });
            hmUI.createWidget(hmUI.widget.IMG, { x: 204, y: 383, src: 'gcal.png', show_level: hmUI.show_level.ONLY_NORMAL });

            // ---------- icons ----------
            hmUI.createWidget(hmUI.widget.IMG, { x: 172, y: 34, src: 'icb.png', show_level: hmUI.show_level.ONLY_NORMAL });
            hmUI.createWidget(hmUI.widget.IMG, { x: 60, y: 318, src: 'ich.png', show_level: hmUI.show_level.ONLY_NORMAL });
            hmUI.createWidget(hmUI.widget.IMG, { x: 218, y: 318, src: 'ics.png', show_level: hmUI.show_level.ONLY_NORMAL });
            hmUI.createWidget(hmUI.widget.IMG, { x: 162, y: 383, src: 'icf.png', show_level: hmUI.show_level.ONLY_NORMAL });

            // ---------- time ----------
            hmUI.createWidget(hmUI.widget.IMG, { x: 148, y: 184, src: 'colon.png', show_level: hmUI.show_level.ONLY_NORMAL });
            hmUI.createWidget(hmUI.widget.IMG, { x: 296, y: 184, src: 'colon.png', show_level: hmUI.show_level.ONLY_NORMAL });
            hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 20, hour_startY: 184, hour_array: ["tb0.png", "tb1.png", "tb2.png", "tb3.png", "tb4.png", "tb5.png", "tb6.png", "tb7.png", "tb8.png", "tb9.png"], hour_zero: 1, hour_space: 0, hour_align: hmUI.align.LEFT,
              minute_startX: 168, minute_startY: 184, minute_array: ["tb0.png", "tb1.png", "tb2.png", "tb3.png", "tb4.png", "tb5.png", "tb6.png", "tb7.png", "tb8.png", "tb9.png"], minute_zero: 1, minute_space: 0, minute_follow: 0, minute_align: hmUI.align.LEFT,
              second_startX: 316, second_startY: 184, second_array: ["tb0.png", "tb1.png", "tb2.png", "tb3.png", "tb4.png", "tb5.png", "tb6.png", "tb7.png", "tb8.png", "tb9.png"], second_zero: 1, second_space: 0, second_follow: 0, second_align: hmUI.align.LEFT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // ---------- date ----------
            hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 86, y: 104, week_en: ["wk0.png", "wk1.png", "wk2.png", "wk3.png", "wk4.png", "wk5.png", "wk6.png"], week_tc: ["wk0.png", "wk1.png", "wk2.png", "wk3.png", "wk4.png", "wk5.png", "wk6.png"], week_sc: ["wk0.png", "wk1.png", "wk2.png", "wk3.png", "wk4.png", "wk5.png", "wk6.png"], show_level: hmUI.show_level.ONLY_NORMAL,
            });
            hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 86, month_startY: 130, month_sc_array: ["mo0.png", "mo1.png", "mo2.png", "mo3.png", "mo4.png", "mo5.png", "mo6.png", "mo7.png", "mo8.png", "mo9.png", "mo10.png", "mo11.png"], month_tc_array: ["mo0.png", "mo1.png", "mo2.png", "mo3.png", "mo4.png", "mo5.png", "mo6.png", "mo7.png", "mo8.png", "mo9.png", "mo10.png", "mo11.png"], month_en_array: ["mo0.png", "mo1.png", "mo2.png", "mo3.png", "mo4.png", "mo5.png", "mo6.png", "mo7.png", "mo8.png", "mo9.png", "mo10.png", "mo11.png"], month_is_character: true,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 153, day_startY: 106, day_sc_array: ["td0.png", "td1.png", "td2.png", "td3.png", "td4.png", "td5.png", "td6.png", "td7.png", "td8.png", "td9.png"], day_tc_array: ["td0.png", "td1.png", "td2.png", "td3.png", "td4.png", "td5.png", "td6.png", "td7.png", "td8.png", "td9.png"], day_en_array: ["td0.png", "td1.png", "td2.png", "td3.png", "td4.png", "td5.png", "td6.png", "td7.png", "td8.png", "td9.png"],
              day_zero: 1, day_space: 0, day_align: hmUI.align.LEFT, day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // ---------- weather ----------
            hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 252, y: 104, image_array: ["wcloud.png", "wrain.png", "wsnow.png", "wstorm.png", "wrain.png", "wsnow.png", "wrain.png", "wfog.png", "wfog.png", "wfog.png", "wsnow.png", "wrain.png", "wrain.png", "wrain.png", "wfog.png", "wfog.png", "wfog.png", "wfog.png", "wclear.png", "wclear.png", "wpart.png", "wpart.png", "wcloud.png", "wcloud.png", "wclear.png", "wclear.png", "wclear.png", "wclear.png", "wclear.png"], image_length: 29, type: hmUI.data_type.WEATHER_CURRENT, show_level: hmUI.show_level.ONLY_NORMAL,
            });
            hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 304, y: 106, w: 100, h: 40, font_array: ["tw0.png", "tw1.png", "tw2.png", "tw3.png", "tw4.png", "tw5.png", "tw6.png", "tw7.png", "tw8.png", "tw9.png"], padding: false, h_space: 0, align_h: hmUI.align.LEFT,
              unit_sc: 'deg.png', unit_tc: 'deg.png', unit_en: 'deg.png',
              negative_image: 'minus.png',
              type: hmUI.data_type.WEATHER_CURRENT, show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // ---------- data fields ----------
            hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 213, y: 36, w: 78, h: 36, font_array: ["ts0.png", "ts1.png", "ts2.png", "ts3.png", "ts4.png", "ts5.png", "ts6.png", "ts7.png", "ts8.png", "ts9.png"], padding: false, h_space: 0, align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.BATTERY, show_level: hmUI.show_level.ONLY_NORMAL,
            });
            hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 108, y: 320, w: 78, h: 36, font_array: ["ts0.png", "ts1.png", "ts2.png", "ts3.png", "ts4.png", "ts5.png", "ts6.png", "ts7.png", "ts8.png", "ts9.png"], padding: false, h_space: 0, align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.HEART, show_level: hmUI.show_level.ONLY_NORMAL,
            });
            hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 266, y: 320, w: 130, h: 36, font_array: ["ts0.png", "ts1.png", "ts2.png", "ts3.png", "ts4.png", "ts5.png", "ts6.png", "ts7.png", "ts8.png", "ts9.png"], padding: false, h_space: 0, align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.STEP, show_level: hmUI.show_level.ONLY_NORMAL,
            });
            hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 204, y: 383, w: 104, h: 36, font_array: ["tc0.png", "tc1.png", "tc2.png", "tc3.png", "tc4.png", "tc5.png", "tc6.png", "tc7.png", "tc8.png", "tc9.png"], padding: false, h_space: 0, align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.CAL, show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // ---------- tap targets ----------
            hmUI.createWidget(hmUI.widget.IMG_CLICK, { x: 56, y: 314, w: 140, h: 48, src: 'dummy.png', type: hmUI.data_type.HEART, show_level: hmUI.show_level.ONLY_NORMAL });
            hmUI.createWidget(hmUI.widget.IMG_CLICK, { x: 214, y: 314, w: 190, h: 48, src: 'dummy.png', type: hmUI.data_type.STEP, show_level: hmUI.show_level.ONLY_NORMAL });
            hmUI.createWidget(hmUI.widget.IMG_CLICK, { x: 158, y: 374, w: 160, h: 56, src: 'dummy.png', type: hmUI.data_type.CAL, show_level: hmUI.show_level.ONLY_NORMAL });
            hmUI.createWidget(hmUI.widget.IMG_CLICK, { x: 170, y: 28, w: 140, h: 48, src: 'dummy.png', type: hmUI.data_type.BATTERY, show_level: hmUI.show_level.ONLY_NORMAL });
            hmUI.createWidget(hmUI.widget.IMG_CLICK, { x: 250, y: 98, w: 150, h: 54, src: 'dummy.png', type: hmUI.data_type.WEATHER_CURRENT, show_level: hmUI.show_level.ONLY_NORMAL });

            // ---------- always-on display ----------
            hmUI.createWidget(hmUI.widget.IMG, { x: 0, y: 0, w: 466, h: 466, src: 'aod_bg.png', show_level: hmUI.show_level.ONAL_AOD });
            hmUI.createWidget(hmUI.widget.IMG, { x: 223, y: 185, src: 'aod_colon.png', show_level: hmUI.show_level.ONAL_AOD });
            hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 95, hour_startY: 185, hour_array: ["aod_t0.png", "aod_t1.png", "aod_t2.png", "aod_t3.png", "aod_t4.png", "aod_t5.png", "aod_t6.png", "aod_t7.png", "aod_t8.png", "aod_t9.png"], hour_zero: 1, hour_space: 0, hour_align: hmUI.align.LEFT,
              minute_startX: 243, minute_startY: 185, minute_array: ["aod_t0.png", "aod_t1.png", "aod_t2.png", "aod_t3.png", "aod_t4.png", "aod_t5.png", "aod_t6.png", "aod_t7.png", "aod_t8.png", "aod_t9.png"], minute_zero: 1, minute_space: 0, minute_follow: 0, minute_align: hmUI.align.LEFT,
              show_level: hmUI.show_level.ONAL_AOD,
            });

          },

          onInit() {
            console.log('index page.js on init invoke')
            this.init_view()
          },

          onReady() {
            console.log('index page.js on ready invoke')
          },

          onShow() {
            console.log('index page.js on show invoke')
          },

          onHide() {
            console.log('index page.js on hide invoke')
          },

          onDestory() {
            console.log('index page.js on destory invoke')
          },
        });

      })()
    } catch (e) {
      console.log(e)
    }
