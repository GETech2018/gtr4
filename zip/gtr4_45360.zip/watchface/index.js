try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const logger = Logger.getLogger('sector2');
        //end of ignored block

        // Sector 2 - digital watchface for Amazfit GTR 4 (466 x 466)

        const NORMAL = hmUI.show_level.ONLY_NORMAL;
        const AOD = hmUI.show_level.ONLY_AOD;
        const SMALL = ['0022.png', '0023.png', '0024.png', '0025.png', '0026.png', '0027.png', '0028.png', '0029.png', '0030.png', '0031.png'];

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                // background: rings, minute labels, divider, icons
                hmUI.createWidget(hmUI.widget.IMG, {
                    x: 0, y: 0, w: 466, h: 466,
                    src: '0001.png',
                    show_level: NORMAL,
                });

                // temperature
                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                    x: 179, y: 86,
                    font_array: SMALL,
                    padding: false, h_space: 2,
                    align_h: hmUI.align.LEFT,
                    negative_image: '0049.png',
                    unit_en: '0050.png', unit_sc: '0050.png', unit_tc: '0050.png',
                    type: hmUI.data_type.WEATHER_CURRENT,
                    show_level: NORMAL,
                });

                // hour (right aligned), minutes
                hmUI.createWidget(hmUI.widget.IMG_TIME, {
                    hour_startX: 83, hour_startY: 142,
                    hour_array: ['0002.png', '0003.png', '0004.png', '0005.png', '0006.png', '0007.png', '0008.png', '0009.png', '0010.png', '0011.png'],
                    hour_zero: 0, hour_space: 4,
                    hour_align: hmUI.align.RIGHT,
                    minute_startX: 117, minute_startY: 241,
                    minute_array: ['0012.png', '0013.png', '0014.png', '0015.png', '0016.png', '0017.png', '0018.png', '0019.png', '0020.png', '0021.png'],
                    minute_zero: 1, minute_space: 2,
                    minute_follow: 0,
                    minute_align: hmUI.align.LEFT,
                    show_level: NORMAL,
                });

                // weekday + day of month
                hmUI.createWidget(hmUI.widget.IMG_WEEK, {
                    x: 112, y: 349,
                    week_en: ['0042.png', '0043.png', '0044.png', '0045.png', '0046.png', '0047.png', '0048.png'],
                    week_tc: ['0042.png', '0043.png', '0044.png', '0045.png', '0046.png', '0047.png', '0048.png'],
                    week_sc: ['0042.png', '0043.png', '0044.png', '0045.png', '0046.png', '0047.png', '0048.png'],
                    show_level: NORMAL,
                });
                hmUI.createWidget(hmUI.widget.IMG_DATE, {
                    day_startX: 191, day_startY: 350,
                    day_en_array: ['0032.png', '0033.png', '0034.png', '0035.png', '0036.png', '0037.png', '0038.png', '0039.png', '0040.png', '0041.png'],
                    day_sc_array: ['0032.png', '0033.png', '0034.png', '0035.png', '0036.png', '0037.png', '0038.png', '0039.png', '0040.png', '0041.png'],
                    day_tc_array: ['0032.png', '0033.png', '0034.png', '0035.png', '0036.png', '0037.png', '0038.png', '0039.png', '0040.png', '0041.png'],
                    day_zero: 0, day_space: 3,
                    day_align: hmUI.align.LEFT,
                    day_is_character: false,
                    show_level: NORMAL,
                });

                // right column: heart rate, calories, steps, distance, battery
                const rows = [
                    [102, hmUI.data_type.HEART],
                    [167, hmUI.data_type.CAL],
                    [232, hmUI.data_type.STEP],
                    [297, hmUI.data_type.DISTANCE],
                    [362, hmUI.data_type.BATTERY],
                ];
                rows.forEach(function (r) {
                    const cfg = {
                        x: 293, y: r[0] - 13,
                        font_array: SMALL,
                        padding: false, h_space: 2,
                        align_h: hmUI.align.LEFT,
                        type: r[1],
                        show_level: NORMAL,
                    };
                    if (r[1] === hmUI.data_type.DISTANCE) cfg.dot_image = '0051.png';
                    hmUI.createWidget(hmUI.widget.TEXT_IMG, cfg);
                });

                // seconds marker on the ring
                hmUI.createWidget(hmUI.widget.TIME_POINTER, {
                    second_centerX: 233, second_centerY: 233,
                    second_posX: 18, second_posY: 214,
                    second_path: '0072.png',
                    show_level: NORMAL,
                });

                // always-on display: dimmed time only
                hmUI.createWidget(hmUI.widget.IMG_TIME, {
                    hour_startX: 83, hour_startY: 142,
                    hour_array: ['0052.png', '0053.png', '0054.png', '0055.png', '0056.png', '0057.png', '0058.png', '0059.png', '0060.png', '0061.png'],
                    hour_zero: 0, hour_space: 4,
                    hour_align: hmUI.align.RIGHT,
                    minute_startX: 117, minute_startY: 241,
                    minute_array: ['0062.png', '0063.png', '0064.png', '0065.png', '0066.png', '0067.png', '0068.png', '0069.png', '0070.png', '0071.png'],
                    minute_zero: 1, minute_space: 2,
                    minute_follow: 0,
                    minute_align: hmUI.align.LEFT,
                    show_level: AOD,
                });

                // tap areas
                const taps = [
                    [108, 82, 124, 36, hmUI.data_type.WEATHER_CURRENT],
                    [80, 138, 156, 242, hmUI.data_type.ALARM_CLOCK],
                    [252, 84, 170, 36, hmUI.data_type.HEART],
                    [252, 149, 170, 36, hmUI.data_type.CAL],
                    [252, 214, 170, 36, hmUI.data_type.STEP],
                    [252, 279, 170, 36, hmUI.data_type.DISTANCE],
                    [252, 344, 170, 36, hmUI.data_type.BATTERY],
                ];
                taps.forEach(function (t) {
                    hmUI.createWidget(hmUI.widget.IMG_CLICK, {
                        x: t[0], y: t[1], w: t[2], h: t[3],
                        type: t[4],
                        show_level: NORMAL,
                    });
                });
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}
