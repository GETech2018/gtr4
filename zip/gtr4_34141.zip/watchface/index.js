/*
** Facemaker bundle tool v0.0.3
* *huamiOS watchface js version v2.0.1
* *Copyright © Huami. All Rights Reserved
*/


try {
	(() => {
		var __$$app$$__ = __$$hmAppManager$$__.currentApp;
		var __$$module$$__ = __$$app$$__.current;

		//drink is a name,can modify
		var h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__), 'drink');

		'use strict';

		//dynamic modify start
		let normal_img0 = '';
		let normal_img1 = '';
		let normal_img2 = '';
		let normal_img3 = '';
		let normal_img4 = '';
		let normal_img5 = '';
		let normal_img6 = '';
		let normal_img7 = '';
		let normal_img8 = '';
		let normal_date_imagecombo10 = '';
		let timeInterval;
		let normal_hour_high_imageset12 = '';
		let normal_hour_high_imageset12_array = ['0021.png','0022.png','0023.png'];
		let normal_hour_low_imageset13 = '';
		let normal_hour_low_imageset13_array = ['0021.png','0022.png','0023.png','0024.png','0025.png','0026.png','0027.png','0028.png','0029.png','0030.png'];
		let normal_minute_high_imageset14 = '';
		let normal_minute_high_imageset14_array = ['0021.png','0022.png','0023.png','0024.png','0025.png','0026.png'];
		let normal_minute_low_imageset15 = '';
		let normal_minute_low_imageset15_array = ['0021.png','0022.png','0023.png','0024.png','0025.png','0026.png','0027.png','0028.png','0029.png','0030.png'];
		let normal_second_low_imageset16 = '';
		let normal_second_low_imageset16_array = ['0031.png','0032.png','0031.png','0032.png','0031.png','0032.png','0031.png','0032.png','0031.png','0032.png'];
		let normal_steps_first_imageset18 = '';
		let normal_steps_first_imageset18_array = ['0021.png','0022.png','0023.png','0024.png','0025.png','0026.png','0027.png','0028.png','0029.png','0030.png'];
		let normal_steps_second_imageset19 = '';
		let normal_steps_second_imageset19_array = ['0021.png','0022.png','0023.png','0024.png','0025.png','0026.png','0027.png','0028.png','0029.png','0030.png'];
		let normal_steps_third_imageset20 = '';
		let normal_steps_third_imageset20_array = ['0021.png','0022.png','0023.png','0024.png','0025.png','0026.png','0027.png','0028.png','0029.png','0030.png'];
		let normal_steps_fourth_imageset21 = '';
		let normal_steps_fourth_imageset21_array = ['0021.png','0022.png','0023.png','0024.png','0025.png','0026.png','0027.png','0028.png','0029.png','0030.png'];
		let normal_steps_fifth_imageset22 = '';
		let normal_steps_fifth_imageset22_array = ['0021.png','0022.png','0023.png','0024.png','0025.png','0026.png','0027.png','0028.png','0029.png','0030.png'];
		let normal_heart_current_imagecombo24 = '';
		let normal_chrono_start_stop = '';
		let normal_chrono_start_stop_array = ['0044.png','0045.png'];
		let chronoInterval;
		let chronoIsRunning = false;
		let chronoStart = 0;
		let chronoStoppedAt = 0;
		let normal_chrono_milliseconds = new Array(3);
		let normal_chrono_milliseconds_padding = false;
		let normal_chrono_milliseconds_array = ['0046.png','0047.png','0048.png','0049.png','0050.png','0051.png','0052.png','0053.png','0054.png','0055.png'];
		let normal_chrono_seconds = new Array(2);
		let normal_chrono_seconds_padding = false;
		let normal_chrono_seconds_array = ['0056.png','0057.png','0058.png','0059.png','0060.png','0061.png','0062.png','0063.png','0064.png','0065.png'];
		let normal_chrono_minutes = new Array(2);
		let normal_chrono_minutes_padding = false;
		let normal_chrono_minutes_array = ['0056.png','0057.png','0058.png','0059.png','0060.png','0061.png','0062.png','0063.png','0064.png','0065.png'];
		let normal_chrono_hours = new Array(2);
		let normal_chrono_hours_padding = false;
		let normal_chrono_hours_array = ['0056.png','0057.png','0058.png','0059.png','0060.png','0061.png','0062.png','0063.png','0064.png','0065.png'];
		let normal_chrono_reset = '';
		let normal_chrono_reset_array = ['0066.png','0067.png'];
		let normal_minute_rotary27 = '';
		let normal_hour_rotary28 = '';
		let normal_second_rotary29 = '';
		let normal_steps_shortcut32 = '';
		let normal_sleep_shortcut33 = '';
		let normal_heart_shortcut34 = '';
		let idle_img36 = '';
		let idle_minute_rotary38 = '';
		let idle_hour_rotary39 = '';
		let idle_second_rotary40 = '';
		//dynamic modify end

		//not required
		const logger = DeviceRuntimeCore.HmLogger.getLogger("yeguang");

		__$$module$$__.module = DeviceRuntimeCore.WatchFace({
			init_view() {

				const timeSensor = hmSensor.createSensor(hmSensor.id.TIME);
				const stepSensor = hmSensor.createSensor(hmSensor.id.STEP);
				const vibrateSensor = hmSensor.createSensor(hmSensor.id.VIBRATE);
				let screenType = hmSetting.getScreenType();

				normal_img0 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 0,
					y: 0,
					w: 465,
					h: 465,
					src: '0002.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img1 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 329,
					y: 158,
					w: 41,
					h: 20,
					src: '0003.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img2 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 325,
					y: 228,
					w: 41,
					h: 17,
					src: '0004.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img3 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 288,
					y: 299,
					w: 79,
					h: 17,
					src: '0005.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img4 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 187,
					y: 159,
					w: 81,
					h: 20,
					src: '0006.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img5 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 273,
					y: 152,
					w: 53,
					h: 17,
					src: '0007.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img6 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 253,
					y: 221,
					w: 68,
					h: 17,
					src: '0008.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img7 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 253,
					y: 292,
					w: 30,
					h: 17,
					src: '0009.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img8 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 223,
					y: 116,
					w: 87,
					h: 40,
					src: '0010.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_date_imagecombo10 = hmUI.createWidget(hmUI.widget.IMG_DATE, {
					day_startX: 65,
					day_startY: 225,
					day_sc_array: ["0011.png","0012.png","0013.png","0014.png","0015.png","0016.png","0017.png","0018.png","0019.png","0020.png"],
					day_tc_array: ["0011.png","0012.png","0013.png","0014.png","0015.png","0016.png","0017.png","0018.png","0019.png","0020.png"],
					day_en_array: ["0011.png","0012.png","0013.png","0014.png","0015.png","0016.png","0017.png","0018.png","0019.png","0020.png"],
					day_zero: false,
					day_space: 0,
					day_align: hmUI.align.CENTER_H,
					day_is_character: false,
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_hour_high_imageset12 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 257,
					y: 177,
					w: 257,
					h: 177,
					src: '0023.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				})

				normal_hour_low_imageset13 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 280,
					y: 177,
					w: 280,
					h: 177,
					src: '0030.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				})

				normal_minute_high_imageset14 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 315,
					y: 177,
					w: 315,
					h: 177,
					src: '0026.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				})

				normal_minute_low_imageset15 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 338,
					y: 177,
					w: 338,
					h: 177,
					src: '0030.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				})

				normal_second_low_imageset16 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 302,
					y: 174,
					w: 302,
					h: 174,
					src: '0032.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				})

				normal_steps_first_imageset18 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 343,
					y: 316,
					w: 343,
					h: 316,
					src: '0030.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				})

				normal_steps_second_imageset19 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 320,
					y: 316,
					w: 320,
					h: 316,
					src: '0030.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				})

				normal_steps_third_imageset20 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 297,
					y: 316,
					w: 297,
					h: 316,
					src: '0030.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				})

				normal_steps_fourth_imageset21 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 275,
					y: 316,
					w: 275,
					h: 316,
					src: '0030.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				})

				normal_steps_fifth_imageset22 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 254,
					y: 316,
					w: 254,
					h: 316,
					src: '0030.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				})

				normal_heart_current_imagecombo24 = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
					x: 274,
					y: 248,
					font_array: ["0033.png","0034.png","0035.png","0036.png","0037.png","0038.png","0039.png","0040.png","0041.png","0042.png"],
					padding: false,
					h_space: 0,
					invalid_image: '0043.png',
					align_h: hmUI.align.RIGHT,
					type: hmUI.data_type.HEART,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_chrono_start_stop = hmUI.createWidget(hmUI.widget.IMG, {
					x: 123,
					y: 68,
					w: 59,
					h: 120,
					src: '0044.png',
					show_level: hmUI.show_level.ONLY_NORMAL
				});

				normal_chrono_start_stop.addEventListener(hmUI.event.CLICK_DOWN, (info) => {
					if (!chronoIsRunning) {
						chronoInterval = setInterval(updateChrono, 1);
						chronoIsRunning = true;
						chronoStart = chronoStart == 0 ? timeSensor.utc : chronoStart + (timeSensor.utc-chronoStoppedAt);
					} else {
						clearInterval(chronoInterval);
						chronoIsRunning = false;
						chronoStoppedAt = timeSensor.utc;
					}
					normal_chrono_start_stop.setProperty(hmUI.prop.MORE, {
						src: normal_chrono_start_stop_array[Number(chronoIsRunning)]
					})
					normal_chrono_reset.setProperty(hmUI.prop.MORE, {
						src: normal_chrono_reset_array[Number(chronoIsRunning)],
						enable: !chronoIsRunning
					})
					vibrateSensor.stop();
					vibrateSensor.scene = 25;
					vibrateSensor.start();
				});

				for (let i = 0; i < normal_chrono_milliseconds.length; i++) {
					normal_chrono_milliseconds[i] = hmUI.createWidget(hmUI.widget.IMG, {
						x: 314 + i * 16,
						y: 116,
						w: 16,
						h: 35,
						src: '0046.png',
						enable: false,
						show_level: hmUI.show_level.ONLY_NORMAL,
					})

				}

				for (let i = 0; i < normal_chrono_seconds.length; i++) {
					normal_chrono_seconds[i] = hmUI.createWidget(hmUI.widget.IMG, {
						x: 269 + i * 16,
						y: 116,
						w: 16,
						h: 35,
						src: '0056.png',
						enable: false,
						show_level: hmUI.show_level.ONLY_NORMAL,
					})

				}

				for (let i = 0; i < normal_chrono_minutes.length; i++) {
					normal_chrono_minutes[i] = hmUI.createWidget(hmUI.widget.IMG, {
						x: 228 + i * 16,
						y: 116,
						w: 16,
						h: 35,
						src: '0056.png',
						enable: false,
						show_level: hmUI.show_level.ONLY_NORMAL,
					})

				}

				for (let i = 0; i < normal_chrono_hours.length; i++) {
					normal_chrono_hours[i] = hmUI.createWidget(hmUI.widget.IMG, {
						x: 190 + i * 16,
						y: 116,
						w: 16,
						h: 35,
						src: '0056.png',
						enable: false,
						show_level: hmUI.show_level.ONLY_NORMAL,
					})

				}

				normal_chrono_reset = hmUI.createWidget(hmUI.widget.IMG, {
					x: 117,
					y: 272,
					w: 66,
					h: 120,
					src: '0067.png',
					show_level: hmUI.show_level.ONLY_NORMAL
				});

				normal_chrono_reset.addEventListener(hmUI.event.CLICK_DOWN, (info) => {
					chronoStart = 0;
					if (typeof normal_chrono_hours != 'undefined') {
						for (let i=0; i < normal_chrono_hours.length; i++) {
							normal_chrono_hours[i].setProperty(hmUI.prop.MORE, {
								src: normal_chrono_hours_array[0]
							})
						}
					}
					if (typeof normal_chrono_minutes != 'undefined') {
						for (let i=0; i < normal_chrono_minutes.length; i++) {
							normal_chrono_minutes[i].setProperty(hmUI.prop.MORE, {
								src: normal_chrono_minutes_array[0]
							})
						}
					}
					if (typeof normal_chrono_seconds != 'undefined') {
						for (let i=0; i < normal_chrono_seconds.length; i++) {
							normal_chrono_seconds[i].setProperty(hmUI.prop.MORE, {
								src: normal_chrono_seconds_array[0]
							})
						}
					}
					if (typeof normal_chrono_milliseconds != 'undefined') {
						for (let i=0; i < normal_chrono_milliseconds.length; i++) {
							normal_chrono_milliseconds[i].setProperty(hmUI.prop.MORE, {
								src: normal_chrono_milliseconds_array[0]
							})
						}
					}
					if (typeof normal_chrono_hours_rotary != 'undefined') {
						normal_chrono_hours_rotary.setProperty(hmUI.prop.MORE, {
							angle: normal_chrono_hours_rotary_start_angle
						})
					}

					if (typeof normal_chrono_minutes_rotary != 'undefined') {
						normal_chrono_minutes_rotary.setProperty(hmUI.prop.MORE, {
							angle: normal_chrono_minutes_rotary_start_angle
						})
					}

					if (typeof normal_chrono_seconds_rotary != 'undefined') {
						normal_chrono_seconds_rotary.setProperty(hmUI.prop.MORE, {
							angle: normal_chrono_seconds_rotary_start_angle
						})
					}

					vibrateSensor.stop();
					vibrateSensor.scene = 25;
					vibrateSensor.start();
				});

				normal_minute_rotary27 = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
					minute_path: '0068.png',
					minute_centerX: 234,
					minute_centerY: 233,
					minute_posX: 218,
					minute_posY: 218,
					minute_start_angle: 0,
					minute_end_angle: 360,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_hour_rotary28 = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
					hour_path: '0069.png',
					hour_centerX: 234,
					hour_centerY: 233,
					hour_posX: 217,
					hour_posY: 217,
					hour_start_angle: 0,
					hour_end_angle: 360,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_second_rotary29 = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
					second_path: '0070.png',
					second_centerX: 234,
					second_centerY: 233,
					second_posX: 233,
					second_posY: 233,
					second_start_angle: 0,
					second_end_angle: 360,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_steps_shortcut32 = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
					x: 249,
					y: 316,
					w: 112,
					h: 55,
					src: '',
					type: hmUI.data_type.STEP,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_sleep_shortcut33 = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
					x: 39,
					y: 183,
					w: 100,
					h: 100,
					src: '',
					type: hmUI.data_type.SLEEP,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_heart_shortcut34 = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
					x: 248,
					y: 244,
					w: 124,
					h: 51,
					src: '',
					type: hmUI.data_type.HEART,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				idle_img36 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 0,
					y: 0,
					w: 465,
					h: 465,
					src: '0071.png',
					enable: false,
					show_level: hmUI.show_level.ONAL_AOD,
				});

				idle_minute_rotary38 = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
					minute_path: '0072.png',
					minute_centerX: 233,
					minute_centerY: 233,
					minute_posX: 200,
					minute_posY: 201,
					minute_start_angle: 0,
					minute_end_angle: 360,
					show_level: hmUI.show_level.ONAL_AOD,
				});

				idle_hour_rotary39 = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
					hour_path: '0073.png',
					hour_centerX: 233,
					hour_centerY: 233,
					hour_posX: 200,
					hour_posY: 201,
					hour_start_angle: 0,
					hour_end_angle: 360,
					show_level: hmUI.show_level.ONAL_AOD,
				});

				idle_second_rotary40 = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
					second_path: '0074.png',
					second_centerX: 233,
					second_centerY: 233,
					second_posX: 200,
					second_posY: 201,
					second_start_angle: 0,
					second_end_angle: 360,
					show_level: hmUI.show_level.ONAL_AOD,
				});

				function updateChrono() {
					let curTime = timeSensor.utc;
					let curDiff = curTime-chronoStart;
					let curMilli = curDiff.toString().substr(curDiff.toString().length - 3).padStart(3, '0');
					let curSeconds = Math.floor((curDiff)/1000).toString().padStart(2, '0');
					let curMinutes = Math.floor(curSeconds/60).toString().padStart(2, '0');
					let curHours = Math.floor(curMinutes/60).toString().padStart(2, '0');
					if (typeof normal_chrono_hours != 'undefined' && normal_chrono_hours.length > 0) {
						for (let i=0; i < normal_chrono_hours.length; i++) {
							normal_chrono_hours[i].setProperty(hmUI.prop.MORE, {
								src: normal_chrono_hours_array[curHours.charAt(i)]
							})
						}
					}

					if (typeof normal_chrono_minutes != 'undefined' && normal_chrono_minutes.length > 0) {
						for (let i=0; i < normal_chrono_minutes.length; i++) {
							normal_chrono_minutes[i].setProperty(hmUI.prop.MORE, {
								src: normal_chrono_minutes_array[curMinutes.charAt(i)]
							})
						}
					}

					if (typeof normal_chrono_seconds != 'undefined' && normal_chrono_seconds.length > 0) {
						for (let i=0; i < normal_chrono_seconds.length; i++) {
							normal_chrono_seconds[i].setProperty(hmUI.prop.MORE, {
								src: normal_chrono_seconds_array[curSeconds.charAt(i)]
							})
						}
					}

					if (typeof normal_chrono_milliseconds != 'undefined' && normal_chrono_milliseconds.length > 0) {
						for (let i=0; i < normal_chrono_milliseconds.length; i++) {
							normal_chrono_milliseconds[i].setProperty(hmUI.prop.MORE, {
								src: normal_chrono_milliseconds_array[curMilli.charAt(i)]
							})
						}
					}

					if (typeof normal_chrono_hours_rotary != 'undefined') {
						let hsa = normal_chrono_hours_rotary_start_angle;
						let hea = normal_chrono_hours_rotary_end_angle;
						let hcw = hea > hsa;
						let hd = hcw ? hea - hsa : hsa - hea;
						let hfac = hd / 360;
						normal_chrono_hours_rotary.setProperty(hmUI.prop.MORE, {
							angle: (hcw ? (hsa + (parseInt(curHours) * (6 * hfac))) : (hsa - (parseInt(curHours) * (6 * hfac))))
						})
					}

					if (typeof normal_chrono_minutes_rotary != 'undefined') {
						let msa = normal_chrono_minutes_rotary_start_angle;
						let mea = normal_chrono_minutes_rotary_end_angle;
						let mcw = mea > msa;
						let md = mcw ? mea - msa : msa - mea;
						let mfac = md / 360;
						normal_chrono_minutes_rotary.setProperty(hmUI.prop.MORE, {
							angle: (mcw ? (msa + (parseInt(curMinutes) * (6 * mfac))) : (msa - (parseInt(curMinutes) * (6 * mfac))))
						})
					}

					if (typeof normal_chrono_seconds_rotary != 'undefined') {
						let ssa = normal_chrono_seconds_rotary_start_angle;
						let sea = normal_chrono_seconds_rotary_end_angle;
						let scw = sea > ssa;
						let sd = scw ? sea - ssa : ssa - sea;
						let sfac = sd / 360;
						normal_chrono_seconds_rotary.setProperty(hmUI.prop.MORE, {
							angle: (scw ? (ssa + ((parseInt(curSeconds) + (parseInt(curMilli) / 1000)) * (6 * sfac))) : (ssa - ((parseInt(curSeconds) + (parseInt(curMilli) / 1000)) * (6 * sfac))))
						})
					}

				}

				function updateTime() {
					normal_hour_high_imageset12.setProperty(hmUI.prop.MORE, {
						src: normal_hour_high_imageset12_array[(timeSensor.format_hour.toString().length == 2 ? timeSensor.format_hour.toString().charAt(0) : 0)]
					})
					normal_hour_low_imageset13.setProperty(hmUI.prop.MORE, {
						src: normal_hour_low_imageset13_array[(timeSensor.format_hour.toString().length == 2 ? timeSensor.format_hour.toString().charAt(1) : timeSensor.format_hour.toString().charAt(0))]
					})
					normal_minute_high_imageset14.setProperty(hmUI.prop.MORE, {
						src: normal_minute_high_imageset14_array[(timeSensor.minute.toString().length == 2 ? timeSensor.minute.toString().charAt(0) : 0)]
					})
					normal_minute_low_imageset15.setProperty(hmUI.prop.MORE, {
						src: normal_minute_low_imageset15_array[(timeSensor.minute.toString().length == 2 ? timeSensor.minute.toString().charAt(1) : timeSensor.minute.toString().charAt(0))]
					})
					normal_second_low_imageset16.setProperty(hmUI.prop.MORE, {
						src: normal_second_low_imageset16_array[(timeSensor.second.toString().length == 2 ? timeSensor.second.toString().charAt(1) : timeSensor.second.toString().charAt(0))]
					})
				}

				function updateSteps() {
					normal_steps_first_imageset18.setProperty(hmUI.prop.MORE, {
						src: normal_steps_first_imageset18_array[stepSensor.current.toString().padStart(5, '0').charAt(4)]
					})
					normal_steps_second_imageset19.setProperty(hmUI.prop.MORE, {
						src: normal_steps_second_imageset19_array[stepSensor.current.toString().padStart(5, '0').charAt(3)]
					})
					normal_steps_third_imageset20.setProperty(hmUI.prop.MORE, {
						src: normal_steps_third_imageset20_array[stepSensor.current.toString().padStart(5, '0').charAt(2)]
					})
					normal_steps_fourth_imageset21.setProperty(hmUI.prop.MORE, {
						src: normal_steps_fourth_imageset21_array[stepSensor.current.toString().padStart(5, '0').charAt(1)]
					})
					normal_steps_fifth_imageset22.setProperty(hmUI.prop.MORE, {
						src: normal_steps_fifth_imageset22_array[stepSensor.current.toString().padStart(5, '0').charAt(0)]
					})
				}

				timeSensor.addEventListener(hmSensor.event.CHANGE, function() {
					updateTime();
				});

				stepSensor.addEventListener(hmSensor.event.CHANGE, function() {
					updateSteps();
				});

				const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
					resume_call: (function () {
						if (chronoIsRunning) {
							chronoInterval = setInterval(updateChrono, 50);
						}
						updateTime();
						updateSteps();
						timeInterval = setInterval(updateTime, 1000);
					}),
					pause_call: (function () {
						clearInterval(timeInterval);
						clearInterval(chronoInterval);
					}),
				})
			},

		onInit() {
			console.log('index page.js on init invoke')
			this.init_view()
		},
		onReady() {
			console.log('index page.js on ready invoke')
		},
		onShow() {
			console.log('index page.js on show invoke')
		},
		onHide() {
			console.log('index page.js on hide invoke')
		},
		onDestroy() {
			console.log('index page.js on destroy invoke')
		},
	});	})()
} catch (e) {
	console.log(e)
}