/*
** Facemaker bundle tool v0.0.2
* *huamiOS watchface js version v2.0.1
* *Copyright © Huami. All Rights Reserved
*/


try {
	(() => {
		var __$$app$$__ = __$$hmAppManager$$__.currentApp;
		var __$$module$$__ = __$$app$$__.current;

		//drink is a name,can modify
		var h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__), 'drink');

		'use strict';

		//dynamic modify start
		let normal_background_bg_img0 = '';
		let normal_background_bg_img1 = '';
		let normal_background_bg_img2 = '';
		let normal_battery_image_progress_img_level4 = '';
		let normal_date_img_date_week_img6 = '';
		let normal_date_current_date_monthday7 = '';
		let normal_date_img_date_month8 = '';
		let normal_digital_clock_img_hour_high10 = '';
		let normal_digital_clock_img_hour_high10_array = ['0045.png','0046.png','0047.png'];
		let normal_digital_clock_img_hour_low11 = '';
		let normal_digital_clock_img_hour_low11_array = ['0048.png','0049.png','0050.png','0051.png','0052.png','0053.png','0054.png','0055.png','0056.png','0057.png'];
		let normal_digital_clock_img_minute_high12 = '';
		let normal_digital_clock_img_minute_high12_array = ['0048.png','0049.png','0050.png','0051.png','0052.png','0053.png'];
		let normal_digital_clock_img_minute_low13 = '';
		let normal_digital_clock_img_minute_low13_array = ['0048.png','0049.png','0050.png','0051.png','0052.png','0053.png','0054.png','0055.png','0056.png','0057.png'];
		let normal_digital_clock_img_second_high14 = '';
		let normal_digital_clock_img_second_high14_array = ['0048.png','0049.png','0050.png','0051.png','0052.png','0053.png'];
		let normal_digital_clock_img_second_low15 = '';
		let normal_digital_clock_img_second_low15_array = ['0048.png','0049.png','0050.png','0051.png','0052.png','0053.png','0054.png','0055.png','0056.png','0057.png'];
		let normal_digital_clock_img_second_low16 = '';
		let normal_digital_clock_img_second_low16_array = ['0058.png','0059.png','0058.png','0059.png','0058.png','0059.png','0058.png','0059.png','0058.png','0059.png'];
		let normal_heart_jumpable_img_click20 = '';
		let normal_step_jumpable_img_click21 = '';
		//dynamic modify end

		//not required
		const logger = DeviceRuntimeCore.HmLogger.getLogger("yeguang");

		__$$module$$__.module = DeviceRuntimeCore.WatchFace({
			init_view() {

				let screenType = hmSetting.getScreenType();

				normal_background_bg_img0 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 0,
					y: 0,
					w: 465,
					h: 465,
					src: '0002.png',
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_background_bg_img1 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 66,
					y: 172,
					w: 341,
					h: 96,
					src: '0003.png',
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_background_bg_img2 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 284,
					y: 173,
					w: 20,
					h: 94,
					src: '0004.png',
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_battery_image_progress_img_level4 = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
					x: 189,
					y: 327,
					image_array: ["0005.png","0006.png","0007.png","0008.png","0009.png","0010.png","0011.png","0012.png","0013.png","0014.png","0015.png"],
					image_length: 11,
					type: hmUI.data_type.BATTERY,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_date_img_date_week_img6 = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
					x: 44,
					y: 270,
					week_en: ["0016.png","0017.png","0018.png","0019.png","0020.png","0021.png","0022.png"],
					week_tc: ["0016.png","0017.png","0018.png","0019.png","0020.png","0021.png","0022.png"],
					week_sc: ["0016.png","0017.png","0018.png","0019.png","0020.png","0021.png","0022.png"],
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_date_current_date_monthday7 = hmUI.createWidget(hmUI.widget.IMG_DATE, {
					day_startX: 189,
					day_startY: 80,
					day_sc_array: ["0023.png","0024.png","0025.png","0026.png","0027.png","0028.png","0029.png","0030.png","0031.png","0032.png"],
					day_tc_array: ["0023.png","0024.png","0025.png","0026.png","0027.png","0028.png","0029.png","0030.png","0031.png","0032.png"],
					day_en_array: ["0023.png","0024.png","0025.png","0026.png","0027.png","0028.png","0029.png","0030.png","0031.png","0032.png"],
					day_zero: false,
					day_space: 0,
					day_align: hmUI.align.CENTER_H,
					day_is_character: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_date_img_date_month8 = hmUI.createWidget(hmUI.widget.IMG_DATE, {
					month_startX: 117,
					month_startY: 116,
					month_sc_array: ["0033.png","0034.png","0035.png","0036.png","0037.png","0038.png","0039.png","0040.png","0041.png","0042.png","0043.png","0044.png"],
					month_tc_array: ["0033.png","0034.png","0035.png","0036.png","0037.png","0038.png","0039.png","0040.png","0041.png","0042.png","0043.png","0044.png"],
					month_en_array: ["0033.png","0034.png","0035.png","0036.png","0037.png","0038.png","0039.png","0040.png","0041.png","0042.png","0043.png","0044.png"],
					month_is_character: true,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_digital_clock_img_hour_high10 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 66,
					y: 176,
					w: 67,
					h: 176,
					src: '0047.png',
					show_level: hmUI.show_level.ONLY_NORMAL,
				})

				normal_digital_clock_img_hour_low11 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 112,
					y: 172,
					w: 113,
					h: 172,
					src: '0057.png',
					show_level: hmUI.show_level.ONLY_NORMAL,
				})

				normal_digital_clock_img_minute_high12 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 186,
					y: 172,
					w: 187,
					h: 172,
					src: '0053.png',
					show_level: hmUI.show_level.ONLY_NORMAL,
				})

				normal_digital_clock_img_minute_low13 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 234,
					y: 172,
					w: 235,
					h: 172,
					src: '0057.png',
					show_level: hmUI.show_level.ONLY_NORMAL,
				})

				normal_digital_clock_img_second_high14 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 304,
					y: 172,
					w: 305,
					h: 172,
					src: '0053.png',
					show_level: hmUI.show_level.ONLY_NORMAL,
				})

				normal_digital_clock_img_second_low15 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 353,
					y: 172,
					w: 354,
					h: 172,
					src: '0057.png',
					show_level: hmUI.show_level.ONLY_NORMAL,
				})

				normal_digital_clock_img_second_low16 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 164,
					y: 172,
					w: 164,
					h: 172,
					src: '0059.png',
					show_level: hmUI.show_level.ONLY_NORMAL,
				})

				normal_heart_jumpable_img_click20 = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
					x: 303,
					y: 319,
					w: 70,
					h: 70,
					src: '',
					type: hmUI.data_type.HEART,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_step_jumpable_img_click21 = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
					x: 91,
					y: 322,
					w: 70,
					h: 70,
					src: '',
					type: hmUI.data_type.STEP,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				const timeSensor = hmSensor.createSensor(hmSensor.id.TIME);
				timeSensor.addEventListener(hmSensor.event.CHANGE, function() {
					updateImageCombos();
				});

				function updateImageCombos() {
					normal_digital_clock_img_hour_high10.setProperty(hmUI.prop.MORE, {
						src: normal_digital_clock_img_hour_high10_array[(timeSensor.hour.toString().length == 2 ? timeSensor.hour.toString().charAt(0) : 0)]
					})
					normal_digital_clock_img_hour_low11.setProperty(hmUI.prop.MORE, {
						src: normal_digital_clock_img_hour_low11_array[(timeSensor.hour.toString().length == 2 ? timeSensor.hour.toString().charAt(1) : timeSensor.hour.toString().charAt(0))]
					})
					normal_digital_clock_img_minute_high12.setProperty(hmUI.prop.MORE, {
						src: normal_digital_clock_img_minute_high12_array[(timeSensor.minute.toString().length == 2 ? timeSensor.minute.toString().charAt(0) : 0)]
					})
					normal_digital_clock_img_minute_low13.setProperty(hmUI.prop.MORE, {
						src: normal_digital_clock_img_minute_low13_array[(timeSensor.minute.toString().length == 2 ? timeSensor.minute.toString().charAt(1) : timeSensor.minute.toString().charAt(0))]
					})
					normal_digital_clock_img_second_high14.setProperty(hmUI.prop.MORE, {
						src: normal_digital_clock_img_second_high14_array[(timeSensor.second.toString().length == 2 ? timeSensor.second.toString().charAt(0) : 0)]
					})
					normal_digital_clock_img_second_low15.setProperty(hmUI.prop.MORE, {
						src: normal_digital_clock_img_second_low15_array[(timeSensor.second.toString().length == 2 ? timeSensor.second.toString().charAt(1) : timeSensor.second.toString().charAt(0))]
					})
					normal_digital_clock_img_second_low16.setProperty(hmUI.prop.MORE, {
						src: normal_digital_clock_img_second_low16_array[(timeSensor.second.toString().length == 2 ? timeSensor.second.toString().charAt(1) : timeSensor.second.toString().charAt(0))]
					})
				};

				const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
					resume_call: (function () {
						updateImageCombos();

					}),
					pause_call: (function () {
					}),
				})
			},

		onInit() {
			console.log('index page.js on init invoke')
			this.init_view()
		},
		onReady() {
			console.log('index page.js on ready invoke')
		},
		onShow() {
			console.log('index page.js on show invoke')
		},
		onHide() {
			console.log('index page.js on hide invoke')
		},
		onDestroy() {
			console.log('index page.js on destroy invoke')
		},
	});	})()
} catch (e) {
	console.log(e)
}