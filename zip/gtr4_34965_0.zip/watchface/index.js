﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        const logger = Logger.getLogger('watchface_SashaCX75');
        //end of ignored block

        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_system_disconnect_img = ''
        let normal_battery_icon_img = ''
        let normal_battery_linear_scale = ''
        let normal_date_img_date_month = ''
        let normal_date_img_date_day = ''
        let normal_date_img_date_week_img = ''
        let normal_digital_clock_img_time = ''
        let normal_digital_clock_img_time_AmPm = ''
        let normal_hour_TextCircle = new Array(2);
        let normal_hour_TextCircle_ASCIIARRAY = new Array(10);
        let normal_hour_TextCircle_img_width = 466;
        let normal_hour_TextCircle_img_height = 466;
        let normal_timerTextUpdate = undefined;
        let normal_hour_TextRotate = new Array(2);
        let normal_hour_TextRotate_ASCIIARRAY = new Array(10);
        let normal_hour_TextRotate_img_width = 466;


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 466,
              h: 466,
              src: 'FondMask.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 83,
              y: 83,
              src: 'BT.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 187,
              y: 333,
              src: 'Batterie.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            let screenType = hmSetting.getScreenType();
            if (screenType != hmSetting.screen_type.AOD) {
              normal_battery_linear_scale = hmUI.createWidget(hmUI.widget.FILL_RECT);
            };

            // normal_battery_linear_scale = hmUI.createWidget(hmUI.widget.Linear_Scale, {
              // start_x: 196,
              // start_y: 351,
              // color: 0xFF000000,
              // lenght: 70,
              // line_width: 29,
              // line_cap: Flat,
              // vertical: False,
              // mirror: False,
              // inversion: True,
              // type: hmUI.data_type.BATTERY,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });
            
            const battery = hmSensor.createSensor(hmSensor.id.BATTERY);
            battery.addEventListener(hmSensor.event.CHANGE, function() {
              scale_call();
            });

            normal_date_img_date_month = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 240,
              month_startY: 298,
              month_sc_array: ["Date0.png","Date1.png","Date2.png","Date3.png","Date4.png","Date5.png","Date6.png","Date7.png","Date8.png","Date9.png"],
              month_tc_array: ["Date0.png","Date1.png","Date2.png","Date3.png","Date4.png","Date5.png","Date6.png","Date7.png","Date8.png","Date9.png"],
              month_en_array: ["Date0.png","Date1.png","Date2.png","Date3.png","Date4.png","Date5.png","Date6.png","Date7.png","Date8.png","Date9.png"],
              month_zero: 1,
              month_space: 0,
              month_align: hmUI.align.LEFT,
              month_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 193,
              day_startY: 298,
              day_sc_array: ["Date0.png","Date1.png","Date2.png","Date3.png","Date4.png","Date5.png","Date6.png","Date7.png","Date8.png","Date9.png"],
              day_tc_array: ["Date0.png","Date1.png","Date2.png","Date3.png","Date4.png","Date5.png","Date6.png","Date7.png","Date8.png","Date9.png"],
              day_en_array: ["Date0.png","Date1.png","Date2.png","Date3.png","Date4.png","Date5.png","Date6.png","Date7.png","Date8.png","Date9.png"],
              day_zero: 1,
              day_space: 0,
              day_unit_sc: 'Separateur.png',
              day_unit_tc: 'Separateur.png',
              day_unit_en: 'Separateur.png',
              day_align: hmUI.align.LEFT,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 154,
              y: 259,
              week_en: ["Jour1.png","Jour2.png","Jour3.png","Jour4.png","Jour5.png","Jour6.png","Jour7.png"],
              week_tc: ["Jour1.png","Jour2.png","Jour3.png","Jour4.png","Jour5.png","Jour6.png","Jour7.png"],
              week_sc: ["Jour1.png","Jour2.png","Jour3.png","Jour4.png","Jour5.png","Jour6.png","Jour7.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 0,
              hour_startY: 0,
              hour_array: ["HeuresA0.png","HeuresA1.png","HeuresA2.png","HeuresA3.png","HeuresA4.png","HeuresA5.png","HeuresA6.png","HeuresA7.png","HeuresA8.png","HeuresA9.png"],
              hour_zero: 0,
              hour_space: 0,
              hour_angle: 0,
              hour_align: hmUI.align.LEFT,

              minute_startX: 179,
              minute_startY: 144,
              minute_array: ["Minute0.png","Minute1.png","Minute2.png","Minute3.png","Minute4.png","Minute5.png","Minute6.png","Minute7.png","Minute8.png","Minute9.png"],
              minute_zero: 1,
              minute_space: 2,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time_AmPm = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              am_x: 167,
              am_y: 86,
              am_sc_path: 'AM.png',
              am_en_path: 'AM.png',
              pm_x: 167,
              pm_y: 86,
              pm_sc_path: 'PM.png',
              pm_en_path: 'PM.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_hour_text_circle_img = hmUI.createWidget(hmUI.widget.Text_Circle, {
              // circle_center_X: 232,
              // circle_center_Y: 0,
              // font_array: ["HeuresA0.png","HeuresA1.png","HeuresA2.png","HeuresA3.png","HeuresA4.png","HeuresA5.png","HeuresA6.png","HeuresA7.png","HeuresA8.png","HeuresA9.png"],
              // radius: 0,
              // angle: 0,
              // char_space_angle: 0,
              // zero: false,
              // reverse_direction: false,
              // unit_in_alignment: false,
              // vertical_alignment: TOP,
              // horizontal_alignment: LEFT,
              // type: hmUI.data_type.HOUR,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_hour_TextCircle_ASCIIARRAY[0] = 'HeuresA0.png';  // set of images with numbers
            normal_hour_TextCircle_ASCIIARRAY[1] = 'HeuresA1.png';  // set of images with numbers
            normal_hour_TextCircle_ASCIIARRAY[2] = 'HeuresA2.png';  // set of images with numbers
            normal_hour_TextCircle_ASCIIARRAY[3] = 'HeuresA3.png';  // set of images with numbers
            normal_hour_TextCircle_ASCIIARRAY[4] = 'HeuresA4.png';  // set of images with numbers
            normal_hour_TextCircle_ASCIIARRAY[5] = 'HeuresA5.png';  // set of images with numbers
            normal_hour_TextCircle_ASCIIARRAY[6] = 'HeuresA6.png';  // set of images with numbers
            normal_hour_TextCircle_ASCIIARRAY[7] = 'HeuresA7.png';  // set of images with numbers
            normal_hour_TextCircle_ASCIIARRAY[8] = 'HeuresA8.png';  // set of images with numbers
            normal_hour_TextCircle_ASCIIARRAY[9] = 'HeuresA9.png';  // set of images with numbers

            //start of ignored block
            for (let i = 0; i < 2; i++) {
              normal_hour_TextCircle[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 466,
                h: 466,
                center_x: 232,
                center_y: 0,
                pos_x: 232 - normal_hour_TextCircle_img_width / 2,
                pos_y: 0 + 0,
                src: 'HeuresA0.png',
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
              normal_hour_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
            };
            //end of ignored block
            
            const timeNaw = hmSensor.createSensor(hmSensor.id.TIME);
            
            function toDegree (radian) {
              return radian * (180 / Math.PI);
            };

            // normal_hour_text_rotate_img = hmUI.createWidget(hmUI.widget.Text_Rotate, {
              // x: -466,
              // y: 0,
              // font_array: ["HeuresB0.png","HeuresB1.png","HeuresB2.png","HeuresB3.png","HeuresB4.png","HeuresB5.png","HeuresB6.png","HeuresB7.png","HeuresB8.png","HeuresB9.png"],
              // zero: false,
              // unit_in_alignment: false,
              // h_space: 0,
              // angle: 0,
              // align_h: hmUI.align.LEFT,
              // type: hmUI.data_type.HOUR,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_hour_TextRotate_ASCIIARRAY[0] = 'HeuresB0.png';  // set of images with numbers
            normal_hour_TextRotate_ASCIIARRAY[1] = 'HeuresB1.png';  // set of images with numbers
            normal_hour_TextRotate_ASCIIARRAY[2] = 'HeuresB2.png';  // set of images with numbers
            normal_hour_TextRotate_ASCIIARRAY[3] = 'HeuresB3.png';  // set of images with numbers
            normal_hour_TextRotate_ASCIIARRAY[4] = 'HeuresB4.png';  // set of images with numbers
            normal_hour_TextRotate_ASCIIARRAY[5] = 'HeuresB5.png';  // set of images with numbers
            normal_hour_TextRotate_ASCIIARRAY[6] = 'HeuresB6.png';  // set of images with numbers
            normal_hour_TextRotate_ASCIIARRAY[7] = 'HeuresB7.png';  // set of images with numbers
            normal_hour_TextRotate_ASCIIARRAY[8] = 'HeuresB8.png';  // set of images with numbers
            normal_hour_TextRotate_ASCIIARRAY[9] = 'HeuresB9.png';  // set of images with numbers

            //start of ignored block
            for (let i = 0; i < 2; i++) {
              normal_hour_TextRotate[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 466,
                h: 466,
                center_x: -466,
                center_y: 0,
                pos_x: -466,
                pos_y: 0,
                angle: 0,
                src: 'HeuresB0.png',
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
              normal_hour_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
            };
            //end of ignored block



            function text_update() {

              console.log('update text circle hour_TIME');
              let valueHour = timeNaw.hour;
              if (!timeNaw.is24Hour) {
                valueHour -= 12;
                if (valueHour < 1) valueHour += 12;
              };
              let normal_hour_circle_string = parseInt(valueHour).toString();

              if (screenType != hmSetting.screen_type.AOD) {
                for (var i = 1; i < 2; i++) {  // hide all symbols
                  normal_hour_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                let char_Angle = 0;
                if (valueHour != null && valueHour != undefined && isFinite(valueHour) && normal_hour_circle_string.length > 0 && normal_hour_circle_string.length < 6) {  // display data if it was possible to get it
                  let normal_hour_TextCircle_img_angle = 0;
                  let normal_hour_TextCircle_dot_img_angle = 0;
                  normal_hour_TextCircle_img_angle = toDegree(Math.atan2(normal_hour_TextCircle_img_width/2, 0));
                  
                  let firstSymbol = true;
                  let index = 0;
                  for (let char of normal_hour_circle_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 2) break;
                    if (charCode >= 0 && charCode < 10) { 
                      if (!firstSymbol) char_Angle += normal_hour_TextCircle_img_angle;
                      firstSymbol = false;
                      normal_hour_TextCircle[index].setProperty(hmUI.prop.ANGLE, char_Angle);
                      normal_hour_TextCircle[index].setProperty(hmUI.prop.POS_X, 232 - normal_hour_TextCircle_img_width / 2);
                      normal_hour_TextCircle[index].setProperty(hmUI.prop.SRC, normal_hour_TextCircle_ASCIIARRAY[charCode]);
                      normal_hour_TextCircle[index].setProperty(hmUI.prop.VISIBLE, true);
                      char_Angle += normal_hour_TextCircle_img_angle;
                      index++;
                    };  // end if digit
                  };  // end char of string
                }  // end isFinite

              };

              console.log('update text rotate hour_TIME');
              let normal_hour_rotate_string = parseInt(valueHour).toString();

              if (screenType != hmSetting.screen_type.AOD) {
                for (var i = 1; i < 2; i++) {  // hide all symbols
                  normal_hour_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                if (valueHour != null && valueHour != undefined && isFinite(valueHour) && normal_hour_rotate_string.length > 0 && normal_hour_rotate_string.length < 6) {  // display data if it was possible to get it
                  let img_offset = 0;
                  
                  let index = 0;
                  for (let char of normal_hour_rotate_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 2) break;
                    if (charCode >= 0 && charCode < 10) { 
                      normal_hour_TextRotate[index].setProperty(hmUI.prop.POS_X, -466 + img_offset);
                      normal_hour_TextRotate[index].setProperty(hmUI.prop.SRC, normal_hour_TextRotate_ASCIIARRAY[charCode]);
                      normal_hour_TextRotate[index].setProperty(hmUI.prop.VISIBLE, true);
                      img_offset += normal_hour_TextRotate_img_width;
                      index++;
                    };  // end if digit
                  };  // end char of string
                }  // end isFinite

              };

            };

            function scale_call() {

                console.log('update scales BATTERY');
                
                let valueBattery = battery.current;
                let targetBattery = 100;
                let progressBattery = valueBattery/targetBattery;
                if (progressBattery > 1) progressBattery = 1;
                let progress_ls_normal_battery = 1 - progressBattery;

                if (screenType != hmSetting.screen_type.AOD) {

                  // normal_battery_linear_scale
                  // initial parameters
                  let start_x_normal_battery = 266;
                  let start_y_normal_battery = 351;
                  let lenght_ls_normal_battery = -70;
                  let line_width_ls_normal_battery = 29;
                  let color_ls_normal_battery = 0xFF000000;
                  
                  // calculated parameters
                  let start_x_normal_battery_draw = start_x_normal_battery;
                  let start_y_normal_battery_draw = start_y_normal_battery;
                  lenght_ls_normal_battery = lenght_ls_normal_battery * progress_ls_normal_battery;
                  let lenght_ls_normal_battery_draw = lenght_ls_normal_battery;
                  let line_width_ls_normal_battery_draw = line_width_ls_normal_battery;
                  if (lenght_ls_normal_battery < 0){
                    lenght_ls_normal_battery_draw = -lenght_ls_normal_battery;
                    start_x_normal_battery_draw = start_x_normal_battery - lenght_ls_normal_battery_draw;
                  };
                  
                  normal_battery_linear_scale.setProperty(hmUI.prop.MORE, {
                    x: start_x_normal_battery_draw,
                    y: start_y_normal_battery_draw,
                    w: lenght_ls_normal_battery_draw,
                    h: line_width_ls_normal_battery_draw,
                    color: color_ls_normal_battery,
                  });
                };

            };

            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                scale_call();
                text_update();
                if (screenType == hmSetting.screen_type.WATCHFACE) {
                  if (!normal_timerTextUpdate) {
                    normal_timerTextUpdate = timer.createTimer(0, 1000, (function (option) {
                      text_update();
                    }));  // end timer 
                  };  // end timer check
                };  // end screenType


              }),
              pause_call: (function () {
                if (normal_timerTextUpdate) {
                  timer.stopTimer(normal_timerTextUpdate);
                  normal_timerTextUpdate = undefined;
                }

              }),
            });

                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}