﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        //const logger = Logger.getLogger('watchface_SashaCX75');
        const logger = DeviceRuntimeCore.HmLogger.getLogger('watchface_SashaCX75')
        //end of ignored block

        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_system_disconnect_img = ''
        let normal_system_clock_img = ''
        let normal_battery_text_text_img = ''
        let normal_battery_image_progress_img_level = ''
        let normal_heart_rate_text_text_img = ''
        let normal_step_current_text_img = ''
        let normal_step_image_progress_img_level = ''
        let normal_weather_image_progress_img_level = ''
        let normal_temperature_current_text_img = ''
        let normal_date_img_date_month_img = ''
        let normal_date_img_date_day = ''
        let normal_date_day_separator_img = ''
        let normal_date_img_date_week_img = ''
        let normal_digital_clock_img_time = ''
        let idle_background_bg_img = ''
        let idle_system_disconnect_img = ''
        let idle_system_clock_img = ''
        let idle_battery_text_text_img = ''
        let idle_battery_image_progress_img_level = ''
        let idle_heart_rate_text_text_img = ''
        let idle_step_current_text_img = ''
        let idle_step_image_progress_img_level = ''
        let idle_weather_image_progress_img_level = ''
        let idle_temperature_current_text_img = ''
        let idle_date_img_date_month_img = ''
        let idle_date_img_date_day = ''
        let idle_date_day_separator_img = ''
        let idle_date_img_date_week_img = ''
        let idle_digital_clock_img_time = ''


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            console.log('Watch_Face.ScreenNormal');
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 466,
              h: 466,
              src: 'Quadrante.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 324,
              y: 404,
              src: 'Off.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 115,
              y: 404,
              src: 'Sveglia.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 288,
              y: 50,
              font_array: ["Nr. Att_01.png","Nr. Att_02.png","Nr. Att_03.png","Nr. Att_04.png","Nr. Att_05.png","Nr. Att_06.png","Nr. Att_07.png","Nr. Att_08.png","Nr. Att_09.png","Nr. Att_10.png"],
              padding: false,
              h_space: 3,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 361,
              y: 77,
              image_array: ["Batteria_01.png","Batteria_02.png","Batteria_03.png","Batteria_04.png","Batteria_05.png","Batteria_06.png"],
              image_length: 6,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 113,
              y: 50,
              font_array: ["Nr. Att_01.png","Nr. Att_02.png","Nr. Att_03.png","Nr. Att_04.png","Nr. Att_05.png","Nr. Att_06.png","Nr. Att_07.png","Nr. Att_08.png","Nr. Att_09.png","Nr. Att_10.png"],
              padding: false,
              h_space: 2,
              invalid_image: 'Nr. Att_12.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 180,
              y: 22,
              font_array: ["Nr. Att_01.png","Nr. Att_02.png","Nr. Att_03.png","Nr. Att_04.png","Nr. Att_05.png","Nr. Att_06.png","Nr. Att_07.png","Nr. Att_08.png","Nr. Att_09.png","Nr. Att_10.png"],
              padding: false,
              h_space: 2,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 188,
              y: 61,
              image_array: ["Passi_01.png","Passi_02.png","Passi_03.png","Passi_04.png","Passi_05.png","Passi_06.png"],
              image_length: 6,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 347,
              y: 299,
              image_array: ["weatherl_00.png","weatherl_01.png","weatherl_02.png","weatherl_03.png","weatherl_04.png","weatherl_05.png","weatherl_06.png","weatherl_07.png","weatherl_08.png","weatherl_09.png","weatherl_10.png","weatherl_11.png","weatherl_12.png","weatherl_13.png","weatherl_14.png","weatherl_15.png","weatherl_16.png","weatherl_17.png","weatherl_18.png","weatherl_19.png","weatherl_20.png","weatherl_21.png","weatherl_22.png","weatherl_23.png","weatherl_24.png","weatherl_25.png","weatherl_26.png","weatherl_27.png","weatherl_28.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 252,
              y: 316,
              font_array: ["Nr. Att_01.png","Nr. Att_02.png","Nr. Att_03.png","Nr. Att_04.png","Nr. Att_05.png","Nr. Att_06.png","Nr. Att_07.png","Nr. Att_08.png","Nr. Att_09.png","Nr. Att_10.png"],
              padding: false,
              h_space: 2,
              unit_sc: 'Nr. Att_13.png',
              unit_tc: 'Nr. Att_13.png',
              unit_en: 'Nr. Att_13.png',
              imperial_unit_sc: 'Nr. Att_13.png',
              imperial_unit_tc: 'Nr. Att_13.png',
              imperial_unit_en: 'Nr. Att_13.png',
              negative_image: 'Nr. Att_11.png',
              invalid_image: 'Nr. Att_12.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            const temperatureUnit = hmSetting.getTemperatureUnit();
            //start of ignored block
            if (temperatureUnit == 1) {
              normal_temperature_current_text_img.setProperty(hmUI.prop.MORE, {
                x: 252,
                y: 316,
                font_array: ["Nr. Att_01.png","Nr. Att_02.png","Nr. Att_03.png","Nr. Att_04.png","Nr. Att_05.png","Nr. Att_06.png","Nr. Att_07.png","Nr. Att_08.png","Nr. Att_09.png","Nr. Att_10.png"],
                padding: false,
                h_space: 2,
                unit_sc: 'Nr. Att_13.png',
                unit_tc: 'Nr. Att_13.png',
                unit_en: 'Nr. Att_13.png',
                imperial_unit_sc: 'Nr. Att_13.png',
                imperial_unit_tc: 'Nr. Att_13.png',
                imperial_unit_en: 'Nr. Att_13.png',
                negative_image: 'Nr. Att_11.png',
                invalid_image: 'Nr. Att_12.png',
                align_h: hmUI.align.CENTER_H,
                type: hmUI.data_type.WEATHER_CURRENT,
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
            };
            //end of ignored block

            normal_date_img_date_month_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 133,
              month_startY: 342,
              month_sc_array: ["Mese_01.png","Mese_02.png","Mese_03.png","Mese_04.png","Mese_05.png","Mese_06.png","Mese_07.png","Mese_08.png","Mese_09.png","Mese_10.png","Mese_11.png","Mese_12.png"],
              month_tc_array: ["Mese_01.png","Mese_02.png","Mese_03.png","Mese_04.png","Mese_05.png","Mese_06.png","Mese_07.png","Mese_08.png","Mese_09.png","Mese_10.png","Mese_11.png","Mese_12.png"],
              month_en_array: ["Mese_01.png","Mese_02.png","Mese_03.png","Mese_04.png","Mese_05.png","Mese_06.png","Mese_07.png","Mese_08.png","Mese_09.png","Mese_10.png","Mese_11.png","Mese_12.png"],
              month_is_character: true ,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 63,
              day_startY: 342,
              day_sc_array: ["Nr. Att_01.png","Nr. Att_02.png","Nr. Att_03.png","Nr. Att_04.png","Nr. Att_05.png","Nr. Att_06.png","Nr. Att_07.png","Nr. Att_08.png","Nr. Att_09.png","Nr. Att_10.png"],
              day_tc_array: ["Nr. Att_01.png","Nr. Att_02.png","Nr. Att_03.png","Nr. Att_04.png","Nr. Att_05.png","Nr. Att_06.png","Nr. Att_07.png","Nr. Att_08.png","Nr. Att_09.png","Nr. Att_10.png"],
              day_en_array: ["Nr. Att_01.png","Nr. Att_02.png","Nr. Att_03.png","Nr. Att_04.png","Nr. Att_05.png","Nr. Att_06.png","Nr. Att_07.png","Nr. Att_08.png","Nr. Att_09.png","Nr. Att_10.png"],
              day_zero: 1,
              day_space: 2,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_day_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 113,
              y: 342,
              src: 'Nr. Att_11.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 41,
              y: 305,
              week_en: ["Giorno_01.png","Giorno_02.png","Giorno_03.png","Giorno_04.png","Giorno_05.png","Giorno_06.png","Giorno_07.png"],
              week_tc: ["Giorno_01.png","Giorno_02.png","Giorno_03.png","Giorno_04.png","Giorno_05.png","Giorno_06.png","Giorno_07.png"],
              week_sc: ["Giorno_01.png","Giorno_02.png","Giorno_03.png","Giorno_04.png","Giorno_05.png","Giorno_06.png","Giorno_07.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 36,
              hour_startY: 117,
              hour_array: ["Nr. Ore_01.png","Nr. Ore_02.png","Nr. Ore_03.png","Nr. Ore_04.png","Nr. Ore_05.png","Nr. Ore_06.png","Nr. Ore_07.png","Nr. Ore_08.png","Nr. Ore_09.png","Nr. Ore_10.png"],
              hour_zero: 1,
              hour_space: 5,
              hour_angle: 0,
              hour_align: hmUI.align.CENTER_H,

              minute_startX: 241,
              minute_startY: 117,
              minute_array: ["Nr. Ore_01.png","Nr. Ore_02.png","Nr. Ore_03.png","Nr. Ore_04.png","Nr. Ore_05.png","Nr. Ore_06.png","Nr. Ore_07.png","Nr. Ore_08.png","Nr. Ore_09.png","Nr. Ore_10.png"],
              minute_zero: 1,
              minute_space: 5,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              second_startX: 175,
              second_startY: 407,
              second_array: ["Nr. Sec_01.png","Nr. Sec_02.png","Nr. Sec_03.png","Nr. Sec_04.png","Nr. Sec_05.png","Nr. Sec_06.png","Nr. Sec_07.png","Nr. Sec_08.png","Nr. Sec_09.png","Nr. Sec_10.png"],
              second_zero: 1,
              second_space: 3,
              second_angle: 0,
              second_follow: 0,
              second_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            console.log('Watch_Face.ScreenAOD');
            idle_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 466,
              h: 466,
              src: 'Quadrante.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 324,
              y: 404,
              src: 'Off.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 115,
              y: 404,
              src: 'Sveglia.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 288,
              y: 50,
              font_array: ["Nr. Att_01.png","Nr. Att_02.png","Nr. Att_03.png","Nr. Att_04.png","Nr. Att_05.png","Nr. Att_06.png","Nr. Att_07.png","Nr. Att_08.png","Nr. Att_09.png","Nr. Att_10.png"],
              padding: false,
              h_space: 3,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_battery_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 361,
              y: 77,
              image_array: ["Batteria_01.png","Batteria_02.png","Batteria_03.png","Batteria_04.png","Batteria_05.png","Batteria_06.png"],
              image_length: 6,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 113,
              y: 50,
              font_array: ["Nr. Att_01.png","Nr. Att_02.png","Nr. Att_03.png","Nr. Att_04.png","Nr. Att_05.png","Nr. Att_06.png","Nr. Att_07.png","Nr. Att_08.png","Nr. Att_09.png","Nr. Att_10.png"],
              padding: false,
              h_space: 2,
              invalid_image: 'Nr. Att_12.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 180,
              y: 22,
              font_array: ["Nr. Att_01.png","Nr. Att_02.png","Nr. Att_03.png","Nr. Att_04.png","Nr. Att_05.png","Nr. Att_06.png","Nr. Att_07.png","Nr. Att_08.png","Nr. Att_09.png","Nr. Att_10.png"],
              padding: false,
              h_space: 2,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_step_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 188,
              y: 61,
              image_array: ["Passi_01.png","Passi_02.png","Passi_03.png","Passi_04.png","Passi_05.png","Passi_06.png"],
              image_length: 6,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 347,
              y: 299,
              image_array: ["weatherl_00.png","weatherl_01.png","weatherl_02.png","weatherl_03.png","weatherl_04.png","weatherl_05.png","weatherl_06.png","weatherl_07.png","weatherl_08.png","weatherl_09.png","weatherl_10.png","weatherl_11.png","weatherl_12.png","weatherl_13.png","weatherl_14.png","weatherl_15.png","weatherl_16.png","weatherl_17.png","weatherl_18.png","weatherl_19.png","weatherl_20.png","weatherl_21.png","weatherl_22.png","weatherl_23.png","weatherl_24.png","weatherl_25.png","weatherl_26.png","weatherl_27.png","weatherl_28.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 252,
              y: 316,
              font_array: ["Nr. Att_01.png","Nr. Att_02.png","Nr. Att_03.png","Nr. Att_04.png","Nr. Att_05.png","Nr. Att_06.png","Nr. Att_07.png","Nr. Att_08.png","Nr. Att_09.png","Nr. Att_10.png"],
              padding: false,
              h_space: 2,
              unit_sc: 'Nr. Att_13.png',
              unit_tc: 'Nr. Att_13.png',
              unit_en: 'Nr. Att_13.png',
              imperial_unit_sc: 'Nr. Att_13.png',
              imperial_unit_tc: 'Nr. Att_13.png',
              imperial_unit_en: 'Nr. Att_13.png',
              negative_image: 'Nr. Att_11.png',
              invalid_image: 'Nr. Att_12.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            //start of ignored block
            if (temperatureUnit == 1) {
              idle_temperature_current_text_img.setProperty(hmUI.prop.MORE, {
                x: 252,
                y: 316,
                font_array: ["Nr. Att_01.png","Nr. Att_02.png","Nr. Att_03.png","Nr. Att_04.png","Nr. Att_05.png","Nr. Att_06.png","Nr. Att_07.png","Nr. Att_08.png","Nr. Att_09.png","Nr. Att_10.png"],
                padding: false,
                h_space: 2,
                unit_sc: 'Nr. Att_13.png',
                unit_tc: 'Nr. Att_13.png',
                unit_en: 'Nr. Att_13.png',
                imperial_unit_sc: 'Nr. Att_13.png',
                imperial_unit_tc: 'Nr. Att_13.png',
                imperial_unit_en: 'Nr. Att_13.png',
                negative_image: 'Nr. Att_11.png',
                invalid_image: 'Nr. Att_12.png',
                align_h: hmUI.align.CENTER_H,
                type: hmUI.data_type.WEATHER_CURRENT,
                show_level: hmUI.show_level.ONLY_AOD,
              });
            };
            //end of ignored block

            idle_date_img_date_month_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 133,
              month_startY: 342,
              month_sc_array: ["Mese_01.png","Mese_02.png","Mese_03.png","Mese_04.png","Mese_05.png","Mese_06.png","Mese_07.png","Mese_08.png","Mese_09.png","Mese_10.png","Mese_11.png","Mese_12.png"],
              month_tc_array: ["Mese_01.png","Mese_02.png","Mese_03.png","Mese_04.png","Mese_05.png","Mese_06.png","Mese_07.png","Mese_08.png","Mese_09.png","Mese_10.png","Mese_11.png","Mese_12.png"],
              month_en_array: ["Mese_01.png","Mese_02.png","Mese_03.png","Mese_04.png","Mese_05.png","Mese_06.png","Mese_07.png","Mese_08.png","Mese_09.png","Mese_10.png","Mese_11.png","Mese_12.png"],
              month_is_character: true ,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 63,
              day_startY: 342,
              day_sc_array: ["Nr. Att_01.png","Nr. Att_02.png","Nr. Att_03.png","Nr. Att_04.png","Nr. Att_05.png","Nr. Att_06.png","Nr. Att_07.png","Nr. Att_08.png","Nr. Att_09.png","Nr. Att_10.png"],
              day_tc_array: ["Nr. Att_01.png","Nr. Att_02.png","Nr. Att_03.png","Nr. Att_04.png","Nr. Att_05.png","Nr. Att_06.png","Nr. Att_07.png","Nr. Att_08.png","Nr. Att_09.png","Nr. Att_10.png"],
              day_en_array: ["Nr. Att_01.png","Nr. Att_02.png","Nr. Att_03.png","Nr. Att_04.png","Nr. Att_05.png","Nr. Att_06.png","Nr. Att_07.png","Nr. Att_08.png","Nr. Att_09.png","Nr. Att_10.png"],
              day_zero: 1,
              day_space: 2,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_day_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 113,
              y: 342,
              src: 'Nr. Att_11.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 41,
              y: 305,
              week_en: ["Giorno_01.png","Giorno_02.png","Giorno_03.png","Giorno_04.png","Giorno_05.png","Giorno_06.png","Giorno_07.png"],
              week_tc: ["Giorno_01.png","Giorno_02.png","Giorno_03.png","Giorno_04.png","Giorno_05.png","Giorno_06.png","Giorno_07.png"],
              week_sc: ["Giorno_01.png","Giorno_02.png","Giorno_03.png","Giorno_04.png","Giorno_05.png","Giorno_06.png","Giorno_07.png"],
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 36,
              hour_startY: 117,
              hour_array: ["Nr. Ore_01.png","Nr. Ore_02.png","Nr. Ore_03.png","Nr. Ore_04.png","Nr. Ore_05.png","Nr. Ore_06.png","Nr. Ore_07.png","Nr. Ore_08.png","Nr. Ore_09.png","Nr. Ore_10.png"],
              hour_zero: 1,
              hour_space: 5,
              hour_angle: 0,
              hour_align: hmUI.align.CENTER_H,

              minute_startX: 241,
              minute_startY: 117,
              minute_array: ["Nr. Ore_01.png","Nr. Ore_02.png","Nr. Ore_03.png","Nr. Ore_04.png","Nr. Ore_05.png","Nr. Ore_06.png","Nr. Ore_07.png","Nr. Ore_08.png","Nr. Ore_09.png","Nr. Ore_10.png"],
              minute_zero: 1,
              minute_space: 5,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_AOD,
            });


                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}