﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        const logger = Logger.getLogger('watchface_SashaCX75');
        //end of ignored block

        //dynamic modify start

        
        console.log('user_functions.js');
        // start user_functions.js

/////////////////////////////////////////////////////////////////////////////////////////////////


        // Start change color white display
        let colornumber_mainDW = 1
        let totalcolors_mainDW = 6
        let namecolor_mainDW = ''

        function click_Whitescreen() {
            if(colornumber_mainDW >= totalcolors_mainDW) {
            colornumber_mainDW=1;
                }
            else {
                colornumber_mainDW = colornumber_mainDW +1;
            }

if ( colornumber_mainDW == 1) { namecolor_mainDW = "Blanco"}
if ( colornumber_mainDW == 2) { namecolor_mainDW = "Rojo"}
if ( colornumber_mainDW == 3) { namecolor_mainDW = "Azul"}
if ( colornumber_mainDW == 4) { namecolor_mainDW = "Amarillo"}
if ( colornumber_mainDW == 5) { namecolor_mainDW = "Naranja"}
if ( colornumber_mainDW == 6) { namecolor_mainDW = "Verde"}
hmUI.showToast({text: namecolor_mainDW });

             normal_calorie_icon_img.setProperty(hmUI.prop.SRC, "TopD_" + parseInt(colornumber_mainDW) + ".png");
                           
        }

//////////////////////////////////////////////////////////////////////////////////////////////////

        // Start change color style
        let colornumber_mainS = 1
        let totalcolors_mainS = 6
        let namecolor_mainS = ''

        function click_Style() {
            if(colornumber_mainS >= totalcolors_mainS) {
            colornumber_mainS=1;
                }
            else {
                colornumber_mainS = colornumber_mainS +1;
            }

if ( colornumber_mainS == 1) { namecolor_mainS = "Negro"}
if ( colornumber_mainS == 2) { namecolor_mainS = "Verde"}
if ( colornumber_mainS == 3) { namecolor_mainS = "Amarillo"}
if ( colornumber_mainS == 4) { namecolor_mainS = "Rojo"}
if ( colornumber_mainS == 5) { namecolor_mainS = "Marron"}
if ( colornumber_mainS == 6) { namecolor_mainS = "Azul"}
hmUI.showToast({text: namecolor_mainS });

             normal_image_img.setProperty(hmUI.prop.SRC, "C_" + parseInt(colornumber_mainS) + ".png");
        normal_heart_rate_icon_img.setProperty(hmUI.prop.SRC, "icon_heart" + parseInt(colornumber_mainS) + ".png");
     normal_battery_icon_img.setProperty(hmUI.prop.SRC, "icon_Battery" + parseInt(colornumber_mainS) + ".png");
                           
        }


//////////////////////////////////////////////////////////////////////////////////////////////////

         // Start change color CIRCLE BATT
        let colornumber_mainB = 1
        let totalcolors_mainB = 11
        let namecolor_mainB = ''

        function click_StyleB() {
            if(colornumber_mainB >= totalcolors_mainB) {
            colornumber_mainB=1;
                }
            else {
                colornumber_mainB = colornumber_mainB +1;
            }

if ( colornumber_mainB == 1) { namecolor_mainB = "3 COLORS"}
if ( colornumber_mainB == 2) { namecolor_mainB = "Verde"}
if ( colornumber_mainB == 3) { namecolor_mainB = "Amarillo"}
if ( colornumber_mainB == 4) { namecolor_mainB = "Rojo"}
if ( colornumber_mainB == 5) { namecolor_mainB = "Marron"}
if ( colornumber_mainB == 6) { namecolor_mainB = "Azul"}
if ( colornumber_mainB == 7) { namecolor_mainB = "Verde 2"}
if ( colornumber_mainB == 8) { namecolor_mainB = "Amarillo 2"}
if ( colornumber_mainB == 9) { namecolor_mainB = "Rojo 2"}
if ( colornumber_mainB == 10) { namecolor_mainB = "Azul 2"}
if ( colornumber_mainB == 11) { namecolor_mainB = "Naranja"}
hmUI.showToast({text: namecolor_mainB });

     normal_battery_icon_img.setProperty(hmUI.prop.SRC, "icon_Battery" + parseInt(colornumber_mainB) + ".png");
                           
        }

/////////////////////////////////////////////////////////////////////////////////////////////////

        // Start change color CIRCLE BATT
        let colornumber_mainP = 1
        let totalcolors_mainP = 11
        let namecolor_mainP = ''

        function click_StyleP() {
            if(colornumber_mainP >= totalcolors_mainP) {
            colornumber_mainP=1;
                }
            else {
                colornumber_mainP = colornumber_mainP +1;
            }

if ( colornumber_mainP == 1) { namecolor_mainP = "3 COLORS"}
if ( colornumber_mainP == 2) { namecolor_mainP = "Verde"}
if ( colornumber_mainP == 3) { namecolor_mainP = "Amarillo"}
if ( colornumber_mainP == 4) { namecolor_mainP = "Rojo"}
if ( colornumber_mainP == 5) { namecolor_mainP = "Marron"}
if ( colornumber_mainP == 6) { namecolor_mainP = "Azul"}
if ( colornumber_mainP == 7) { namecolor_mainP = "Verde 2"}
if ( colornumber_mainP == 8) { namecolor_mainP = "Amarillo 2"}
if ( colornumber_mainP == 9) { namecolor_mainP = "Rojo 2"}
if ( colornumber_mainP == 10) { namecolor_mainP = "Azul 2"}
if ( colornumber_mainP == 11) { namecolor_mainP = "Naranja"}
hmUI.showToast({text: namecolor_mainP });

 normal_heart_rate_icon_img.setProperty(hmUI.prop.SRC, "icon_heart" + parseInt(colornumber_mainP) + ".png");

                           
        }

/////////////////////////////////////////////////////////////////////////////////////////////////

        // Start change color style
        let colornumber_mainCC = 1
        let totalcolors_mainCC = 6
        let namecolor_mainCC = ''

        function click_StyleCC() {
            if(colornumber_mainCC >= totalcolors_mainCC) {
            colornumber_mainCC=1;
                }
            else {
                colornumber_mainCC = colornumber_mainCC +1;
            }

if ( colornumber_mainCC == 1) { namecolor_mainCC = "Negro"}
if ( colornumber_mainCC == 2) { namecolor_mainCC = "Verde"}
if ( colornumber_mainCC == 3) { namecolor_mainCC = "Amarillo"}
if ( colornumber_mainCC == 4) { namecolor_mainCC = "Rojo"}
if ( colornumber_mainCC == 5) { namecolor_mainCC = "Marron"}
if ( colornumber_mainCC == 6) { namecolor_mainCC = "Azul"}
hmUI.showToast({text: namecolor_mainCC });

             normal_image_img.setProperty(hmUI.prop.SRC, "C_" + parseInt(colornumber_mainCC) + ".png");
                           
        }



/////////////////////////////////////////////////////////////////////////////////////////////////
let deviceInfo = hmSetting.getDeviceInfo();
        // Start color change
        let colornumber = 1
        let totalcolors = 6
        let namecolor = ''
        let Rootpath = ''
        function click_Color() {
            if(colornumber>=totalcolors) {
            colornumber=1;
                }
            else {
                colornumber=colornumber+1;
            }

if ( colornumber == 1) { namecolor = "Blanco"
Rootpath = ''
}
if ( colornumber == 2) { namecolor = "Azul"
Rootpath = "Blue/"
}
if ( colornumber == 3) { namecolor = "Verde"
Rootpath = "Green/"
}
if ( colornumber == 4) { namecolor = "Naranja"
Rootpath = "Orange/"
}
if ( colornumber == 5) { namecolor = "Rojo"
Rootpath = "Red/"
}
if ( colornumber == 6) { namecolor = "Amarillo"
Rootpath = "Yellow/"
}
hmUI.showToast({text: namecolor });


            normal_digital_clock_img_time_minute.setProperty(hmUI.prop.MORE, {
              minute_startX: deviceInfo.width / 480 *181,
              minute_startY: deviceInfo.height / 480 *186,
              minute_array: [Rootpath+"Time_0.png",Rootpath+"Time_1.png",Rootpath+"Time_2.png",Rootpath+"Time_3.png",Rootpath+"Time_4.png",Rootpath+"Time_5.png",Rootpath+"Time_6.png",Rootpath+"Time_7.png",Rootpath+"Time_8.png",Rootpath+"Time_9.png"],
              minute_zero: 1,
              minute_space: 2,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time_hour.setProperty(hmUI.prop.MORE, {
              hour_startX: deviceInfo.width / 480 *181,
              hour_startY: deviceInfo.height / 480 *106,
              hour_array: [Rootpath+"Time_0.png",Rootpath+"Time_1.png",Rootpath+"Time_2.png",Rootpath+"Time_3.png",Rootpath+"Time_4.png",Rootpath+"Time_5.png",Rootpath+"Time_6.png",Rootpath+"Time_7.png",Rootpath+"Time_8.png",Rootpath+"Time_9.png"],
              hour_zero: 1,
              hour_space: 2,
              hour_angle: 0,
              hour_align: hmUI.align.LEFT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

}


/////////////////////////////////////////////////////////////////////////////////////////////////

        // Start Hour color change
        let colornumberH = 1
        let totalcolorsH = 6
        let namecolorH = ''
        function click_ColorH() {
            if(colornumberH >= totalcolorsH) {
            colornumberH=1;
                }
            else {
                colornumberH = colornumberH+1;
            }
if ( colornumberH == 1) { namecolorH = "Blanco"
Rootpath = ''
}
if ( colornumberH == 2) { namecolorH = "Azul"
Rootpath = "Blue/"
}
if ( colornumberH == 3) { namecolorH = "Verde"
Rootpath = "Green/"
}
if ( colornumberH == 4) { namecolorH = "Naranja"
Rootpath = "Orange/"
}
if ( colornumberH == 5) { namecolorH = "Rojo"
Rootpath = "Red/"
}
if ( colornumberH == 6) { namecolorH = "Amarillo"
Rootpath = "Yellow/"
}
hmUI.showToast({text: namecolorH });


            normal_digital_clock_img_time_minute.setProperty(hmUI.prop.MORE, {
              minute_startX: deviceInfo.width / 480 *181,
              minute_startY: deviceInfo.height / 480 *186,
              minute_array: [Rootpath+"Time_0.png",Rootpath+"Time_1.png",Rootpath+"Time_2.png",Rootpath+"Time_3.png",Rootpath+"Time_4.png",Rootpath+"Time_5.png",Rootpath+"Time_6.png",Rootpath+"Time_7.png",Rootpath+"Time_8.png",Rootpath+"Time_9.png"],
              minute_zero: 1,
              minute_space: 2,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });



}

/////////////////////////////////////////////////////////////////////////////////////////////////

        // Start Hour color change
        let colornumberM = 1
        let totalcolorsM = 6
        let namecolorM = ''
        function click_ColorM() {
            if(colornumberM >= totalcolorsM) {
            colornumberM=1;
                }
            else {
                colornumberM = colornumberM+1;
            }

if ( colornumberM == 1) { namecolorM = "Blanco"
Rootpath = ''
}
if ( colornumberM == 2) { namecolorM = "Azul"
Rootpath = "Blue/"
}
if ( colornumberM == 3) { namecolorM = "Verde"
Rootpath = "Green/"
}
if ( colornumberM == 4) { namecolorM = "Naranja"
Rootpath = "Orange/"
}
if ( colornumberM == 5) { namecolorM = "Rojo"
Rootpath = "Red/"
}
if ( colornumberM == 6) { namecolorM = "Amarillo"
Rootpath = "Yellow/"
}
hmUI.showToast({text: namecolorM });

            normal_digital_clock_img_time_hour.setProperty(hmUI.prop.MORE, {
              hour_startX: deviceInfo.width / 480 *181,
              hour_startY: deviceInfo.height / 480 *106,
              hour_array: [Rootpath+"Time_0.png",Rootpath+"Time_1.png",Rootpath+"Time_2.png",Rootpath+"Time_3.png",Rootpath+"Time_4.png",Rootpath+"Time_5.png",Rootpath+"Time_6.png",Rootpath+"Time_7.png",Rootpath+"Time_8.png",Rootpath+"Time_9.png"],
              hour_zero: 1,
              hour_space: 2,
              hour_angle: 0,
              hour_align: hmUI.align.LEFT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

}
        // end user_functions.js

        let normal_background_bg_img = ''
        let normal_system_disconnect_img = ''
        let normal_system_clock_img = ''
        let normal_sunset_TextCircle = new Array(5);
        let normal_sunset_TextCircle_ASCIIARRAY = new Array(10);
        let normal_sunset_TextCircle_img_width = 17;
        let normal_sunset_TextCircle_img_height = 17;
        let normal_sunset_TextCircle_dot_width = 6;
        let normal_sunrise_TextCircle = new Array(5);
        let normal_sunrise_TextCircle_ASCIIARRAY = new Array(10);
        let normal_sunrise_TextCircle_img_width = 17;
        let normal_sunrise_TextCircle_img_height = 17;
        let normal_sunrise_TextCircle_dot_width = 6;
        let normal_moon_high_text_img = ''
        let normal_moon_low_text_img = ''
        let normal_moon_image_progress_img_level = ''
        let normal_temperature_high_text_img = ''
        let normal_temperature_low_text_img = ''
        let normal_temperature_current_text_img = ''
        let normal_weather_image_progress_img_level = ''
        let normal_distance_TextRotate = new Array(5);
        let normal_distance_TextRotate_ASCIIARRAY = new Array(10);
        let normal_distance_TextRotate_img_width = 21;
        let normal_distance_TextRotate_dot_width = 6;
        let normal_distance_TextRotate_error_img_width = 21;
        let normal_distance_text_text_img = ''
        let normal_step_current_text_img = ''
        let normal_calorie_current_text_img = ''
        let normal_calorie_icon_img = ''
        let normal_image_img = ''
        let normal_heart_rate_icon_img = ''
        let normal_heart_rate_pointer_progress_img_pointer = ''
        let normal_heart_rate_text_text_img = ''
        let normal_battery_icon_img = ''
        let normal_battery_pointer_progress_img_pointer = ''
        let normal_battery_text_text_img = ''
        let normal_date_img_date_week_img = ''
        let normal_date_img_date_day = ''
        let normal_digital_clock_img_time_AmPm = ''
        let normal_digital_clock_img_time_second = ''
        let normal_digital_clock_img_time_minute = ''
        let normal_digital_clock_img_time_hour = ''
        let normal_analog_clock_pro_second_pointer_img = ''
        let normal_timerUpdateSecSmooth = undefined;
        let idle_system_disconnect_img = ''
        let idle_system_clock_img = ''
        let idle_sunset_TextCircle = new Array(5);
        let idle_sunset_TextCircle_ASCIIARRAY = new Array(10);
        let idle_sunset_TextCircle_img_width = 17;
        let idle_sunset_TextCircle_img_height = 17;
        let idle_sunset_TextCircle_dot_width = 6;
        let idle_sunrise_TextCircle = new Array(5);
        let idle_sunrise_TextCircle_ASCIIARRAY = new Array(10);
        let idle_sunrise_TextCircle_img_width = 17;
        let idle_sunrise_TextCircle_img_height = 17;
        let idle_sunrise_TextCircle_dot_width = 6;
        let idle_moon_image_progress_img_level = ''
        let idle_date_img_date_day = ''
        let idle_battery_current_text_font = ''
        let idle_digital_clock_img_time_AmPm = ''
        let idle_digital_clock_img_time_minute = ''
        let idle_digital_clock_img_time_hour = ''
        let normal_stopwatch_jumpable_img_click = ''
        let normal_countdown_jumpable_img_click = ''
        let normal_alarm_jumpable_img_click = ''
        let normal_sunrise_jumpable_img_click = ''
        let normal_temperature_jumpable_img_click = ''
        let normal_pai_jumpable_img_click = ''
        let normal_spo2_jumpable_img_click = ''
        let normal_heart_jumpable_img_click = ''
        let normal_step_jumpable_img_click = ''
        let Button_1 = ''
        let Button_2 = ''
        let Button_3 = ''
        let Button_4 = ''
        let Button_5 = ''
        let Button_6 = ''
        let Button_7 = ''
        let Button_8 = ''
        let Button_9 = ''
        let Button_10 = ''
        let Button_11 = ''
        let Button_12 = ''
        let Button_13 = ''
        let timeSensor = ''


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            console.log('Watch_Face.ScreenNormal');
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 466,
              h: 466,
              src: 'Bg1.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 223,
              y: 312,
              src: 'System_BT_OFF.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 297,
              y: 167,
              src: 'System_Alarm.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_sunset_text_circle_img = hmUI.createWidget(hmUI.widget.Text_Circle, {
              // circle_center_X: 233,
              // circle_center_Y: 233,
              // font_array: ["Act_cal_0.png","Act_cal_1.png","Act_cal_2.png","Act_cal_3.png","Act_cal_4.png","Act_cal_5.png","Act_cal_6.png","Act_cal_7.png","Act_cal_8.png","Act_cal_9.png"],
              // radius: 203,
              // angle: 13,
              // char_space_angle: 0,
              // dot_image: 'sunrise_set.png',
              // zero: true,
              // reverse_direction: false,
              // unit_in_alignment: true,
              // vertical_alignment: BOTTOM,
              // horizontal_alignment: LEFT,
              // type: hmUI.data_type.SUN_SET,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_sunset_TextCircle_ASCIIARRAY[0] = 'Act_cal_0.png';  // set of images with numbers
            normal_sunset_TextCircle_ASCIIARRAY[1] = 'Act_cal_1.png';  // set of images with numbers
            normal_sunset_TextCircle_ASCIIARRAY[2] = 'Act_cal_2.png';  // set of images with numbers
            normal_sunset_TextCircle_ASCIIARRAY[3] = 'Act_cal_3.png';  // set of images with numbers
            normal_sunset_TextCircle_ASCIIARRAY[4] = 'Act_cal_4.png';  // set of images with numbers
            normal_sunset_TextCircle_ASCIIARRAY[5] = 'Act_cal_5.png';  // set of images with numbers
            normal_sunset_TextCircle_ASCIIARRAY[6] = 'Act_cal_6.png';  // set of images with numbers
            normal_sunset_TextCircle_ASCIIARRAY[7] = 'Act_cal_7.png';  // set of images with numbers
            normal_sunset_TextCircle_ASCIIARRAY[8] = 'Act_cal_8.png';  // set of images with numbers
            normal_sunset_TextCircle_ASCIIARRAY[9] = 'Act_cal_9.png';  // set of images with numbers

            //start of ignored block
            for (let i = 0; i < 5; i++) {
              normal_sunset_TextCircle[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 466,
                h: 466,
                center_x: 233,
                center_y: 233,
                pos_x: 233 - normal_sunset_TextCircle_img_width / 2,
                pos_y: 233 - 220,
                src: 'Act_cal_0.png',
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
              normal_sunset_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
            };
            //end of ignored block
            const weatherSensor = hmSensor.createSensor(hmSensor.id.WEATHER);
            
            function toDegree (radian) {
              return radian * (180 / Math.PI);
            };

            // normal_sunrise_text_circle_img = hmUI.createWidget(hmUI.widget.Text_Circle, {
              // circle_center_X: 233,
              // circle_center_Y: 233,
              // font_array: ["Act_cal_0.png","Act_cal_1.png","Act_cal_2.png","Act_cal_3.png","Act_cal_4.png","Act_cal_5.png","Act_cal_6.png","Act_cal_7.png","Act_cal_8.png","Act_cal_9.png"],
              // radius: 204,
              // angle: -29,
              // char_space_angle: 0,
              // dot_image: 'sunrise_set.png',
              // zero: true,
              // reverse_direction: false,
              // unit_in_alignment: true,
              // vertical_alignment: BOTTOM,
              // horizontal_alignment: LEFT,
              // type: hmUI.data_type.SUN_RISE,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_sunrise_TextCircle_ASCIIARRAY[0] = 'Act_cal_0.png';  // set of images with numbers
            normal_sunrise_TextCircle_ASCIIARRAY[1] = 'Act_cal_1.png';  // set of images with numbers
            normal_sunrise_TextCircle_ASCIIARRAY[2] = 'Act_cal_2.png';  // set of images with numbers
            normal_sunrise_TextCircle_ASCIIARRAY[3] = 'Act_cal_3.png';  // set of images with numbers
            normal_sunrise_TextCircle_ASCIIARRAY[4] = 'Act_cal_4.png';  // set of images with numbers
            normal_sunrise_TextCircle_ASCIIARRAY[5] = 'Act_cal_5.png';  // set of images with numbers
            normal_sunrise_TextCircle_ASCIIARRAY[6] = 'Act_cal_6.png';  // set of images with numbers
            normal_sunrise_TextCircle_ASCIIARRAY[7] = 'Act_cal_7.png';  // set of images with numbers
            normal_sunrise_TextCircle_ASCIIARRAY[8] = 'Act_cal_8.png';  // set of images with numbers
            normal_sunrise_TextCircle_ASCIIARRAY[9] = 'Act_cal_9.png';  // set of images with numbers

            //start of ignored block
            for (let i = 0; i < 5; i++) {
              normal_sunrise_TextCircle[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 466,
                h: 466,
                center_x: 233,
                center_y: 233,
                pos_x: 233 - normal_sunrise_TextCircle_img_width / 2,
                pos_y: 233 - 221,
                src: 'Act_cal_0.png',
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
              normal_sunrise_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
            };
            //end of ignored block

            normal_moon_high_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 290,
              y: 401,
              font_array: ["Act_cal_0.png","Act_cal_1.png","Act_cal_2.png","Act_cal_3.png","Act_cal_4.png","Act_cal_5.png","Act_cal_6.png","Act_cal_7.png","Act_cal_8.png","Act_cal_9.png"],
              padding: false,
              h_space: 0,
              dot_image: 'sunrise_set.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.MOON_RISE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_moon_low_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 305,
              y: 340,
              font_array: ["Act_cal_0.png","Act_cal_1.png","Act_cal_2.png","Act_cal_3.png","Act_cal_4.png","Act_cal_5.png","Act_cal_6.png","Act_cal_7.png","Act_cal_8.png","Act_cal_9.png"],
              padding: false,
              h_space: 0,
              dot_image: 'sunrise_set.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.MOON_SET,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_moon_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 318,
              y: 357,
              image_array: ["moon01.png","moon02.png","moon03.png","moon04.png","moon05.png","moon06.png","moon07.png","moon08.png","moon09.png","moon10.png","moon11.png","moon12.png","moon13.png","moon14.png","moon15.png","moon16.png","moon17.png","moon18.png","moon19.png","moon20.png","moon21.png","moon22.png","moon23.png","moon24.png","moon25.png","moon26.png","moon27.png","moon28.png","moon29.png","moon30.png"],
              image_length: 30,
              type: hmUI.data_type.MOON,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_high_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 132,
              y: 340,
              font_array: ["Act_cal_0.png","Act_cal_1.png","Act_cal_2.png","Act_cal_3.png","Act_cal_4.png","Act_cal_5.png","Act_cal_6.png","Act_cal_7.png","Act_cal_8.png","Act_cal_9.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'Weather2_Symbo1.png',
              unit_tc: 'Weather2_Symbo1.png',
              unit_en: 'Weather2_Symbo1.png',
              negative_image: 'Weather2_Symbo2.png',
              invalid_image: 'Weather2_Symbo2.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_HIGH,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_low_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 41,
              y: 340,
              font_array: ["Act_cal_0.png","Act_cal_1.png","Act_cal_2.png","Act_cal_3.png","Act_cal_4.png","Act_cal_5.png","Act_cal_6.png","Act_cal_7.png","Act_cal_8.png","Act_cal_9.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'Weather2_Symbo1.png',
              unit_tc: 'Weather2_Symbo1.png',
              unit_en: 'Weather2_Symbo1.png',
              negative_image: 'Weather2_Symbo2.png',
              invalid_image: 'Weather2_Symbo2.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_LOW,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 100,
              y: 403,
              font_array: ["Act_Small_0.png","Act_Small_1.png","Act_Small_2.png","Act_Small_3.png","Act_Small_4.png","Act_Small_5.png","Act_Small_6.png","Act_Small_7.png","Act_Small_8.png","Act_Small_9.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'Weather_Symbo1.png',
              unit_tc: 'Weather_Symbo1.png',
              unit_en: 'Weather_Symbo1.png',
              negative_image: 'Weather_Symbo2.png',
              invalid_image: 'Weather_Symbo2.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 89,
              y: 343,
              image_array: ["Weather_icon_01.png","Weather_icon_02.png","Weather_icon_03.png","Weather_icon_04.png","Weather_icon_05.png","Weather_icon_06.png","Weather_icon_07.png","Weather_icon_08.png","Weather_icon_09.png","Weather_icon_10.png","Weather_icon_11.png","Weather_icon_12.png","Weather_icon_13.png","Weather_icon_14.png","Weather_icon_15.png","Weather_icon_16.png","Weather_icon_17.png","Weather_icon_18.png","Weather_icon_19.png","Weather_icon_20.png","Weather_icon_21.png","Weather_icon_22.png","Weather_icon_23.png","Weather_icon_24.png","Weather_icon_25.png","Weather_icon_26.png","Weather_icon_27.png","Weather_icon_28.png","Weather_icon_29.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_distance_text_rotate_img = hmUI.createWidget(hmUI.widget.Text_Rotate, {
              // x: 383,
              // y: 302,
              // font_array: ["Act_Small_0.png","Act_Small_1.png","Act_Small_2.png","Act_Small_3.png","Act_Small_4.png","Act_Small_5.png","Act_Small_6.png","Act_Small_7.png","Act_Small_8.png","Act_Small_9.png"],
              // zero: false,
              // unit_in_alignment: false,
              // h_space: 0,
              // angle: 0,
              // invalid_image: 'Act_Small_0.png',
              // dot_image: 'Dis_Dot.png',
              // align_h: hmUI.align.CENTER_H,
              // type: hmUI.data_type.DISTANCE,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_distance_TextRotate_ASCIIARRAY[0] = 'Act_Small_0.png';  // set of images with numbers
            normal_distance_TextRotate_ASCIIARRAY[1] = 'Act_Small_1.png';  // set of images with numbers
            normal_distance_TextRotate_ASCIIARRAY[2] = 'Act_Small_2.png';  // set of images with numbers
            normal_distance_TextRotate_ASCIIARRAY[3] = 'Act_Small_3.png';  // set of images with numbers
            normal_distance_TextRotate_ASCIIARRAY[4] = 'Act_Small_4.png';  // set of images with numbers
            normal_distance_TextRotate_ASCIIARRAY[5] = 'Act_Small_5.png';  // set of images with numbers
            normal_distance_TextRotate_ASCIIARRAY[6] = 'Act_Small_6.png';  // set of images with numbers
            normal_distance_TextRotate_ASCIIARRAY[7] = 'Act_Small_7.png';  // set of images with numbers
            normal_distance_TextRotate_ASCIIARRAY[8] = 'Act_Small_8.png';  // set of images with numbers
            normal_distance_TextRotate_ASCIIARRAY[9] = 'Act_Small_9.png';  // set of images with numbers

            //start of ignored block
            for (let i = 0; i < 5; i++) {
              normal_distance_TextRotate[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 466,
                h: 466,
                center_x: 383,
                center_y: 302,
                pos_x: 383,
                pos_y: 302,
                angle: 0,
                src: 'Act_Small_0.png',
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
              normal_distance_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
            };
            //end of ignored block
            
            const distance = hmSensor.createSensor(hmSensor.id.DISTANCE);
            distance.addEventListener(hmSensor.event.CHANGE, function() {
              text_update();
            });

            normal_distance_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 297,
              y: 310,
              font_array: ["E0.png","E1.png","E2.png","E3.png","E4.png","E5.png","E6.png","E7.png","E8.png","E9.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'Dis_KM.png',
              unit_tc: 'Dis_KM.png',
              unit_en: 'Dis_KM.png',
              imperial_unit_sc: 'Dis_Mi.png',
              imperial_unit_tc: 'Dis_Mi.png',
              imperial_unit_en: 'Dis_Mi.png',
              dot_image: '0_Empty.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.DISTANCE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 21,
              y: 294,
              font_array: ["Act_0.png","Act_1.png","Act_2.png","Act_3.png","Act_4.png","Act_5.png","Act_6.png","Act_7.png","Act_8.png","Act_9.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_calorie_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 373,
              y: 256,
              font_array: ["Act_cal_0.png","Act_cal_1.png","Act_cal_2.png","Act_cal_3.png","Act_cal_4.png","Act_cal_5.png","Act_cal_6.png","Act_cal_7.png","Act_cal_8.png","Act_cal_9.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_calorie_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 205,
              src: 'TopD_1.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_image_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 100,
              y: 42,
              src: 'C_1.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 373,
              y: 118,
              src: 'icon_heart1.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_pointer_progress_img_pointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
              src: 'Pointer1.png',
              center_x: 412,
              center_y: 156,
              x: 25,
              y: 41,
              start_angle: 237,
              end_angle: 555,
              invalid_visible: false,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 403,
              y: 211,
              font_array: ["Act1_black_0.png","Act1_black_1.png","Act1_black_2.png","Act1_black_3.png","Act1_black_4.png","Act1_black_5.png","Act1_black_6.png","Act1_black_7.png","Act1_black_8.png","Act1_black_9.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 16,
              y: 118,
              src: 'icon_Battery1.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_pointer_progress_img_pointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
              src: 'Pointer1.png',
              center_x: 55,
              center_y: 156,
              x: 25,
              y: 41,
              start_angle: 482,
              end_angle: 164,
              invalid_visible: false,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 2,
              y: 212,
              font_array: ["Act1_black_0.png","Act1_black_1.png","Act1_black_2.png","Act1_black_3.png","Act1_black_4.png","Act1_black_5.png","Act1_black_6.png","Act1_black_7.png","Act1_black_8.png","Act1_black_9.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'Batt_Unit.png',
              unit_tc: 'Batt_Unit.png',
              unit_en: 'Batt_Unit.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 197,
              y: 437,
              week_en: ["0085.png","0086.png","0087.png","0088.png","0089.png","0090.png","0091.png"],
              week_tc: ["0085.png","0086.png","0087.png","0088.png","0089.png","0090.png","0091.png"],
              week_sc: ["0085.png","0086.png","0087.png","0088.png","0089.png","0090.png","0091.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 209,
              day_startY: 378,
              day_sc_array: ["Act_0.png","Act_1.png","Act_2.png","Act_3.png","Act_4.png","Act_5.png","Act_6.png","Act_7.png","Act_8.png","Act_9.png"],
              day_tc_array: ["Act_0.png","Act_1.png","Act_2.png","Act_3.png","Act_4.png","Act_5.png","Act_6.png","Act_7.png","Act_8.png","Act_9.png"],
              day_en_array: ["Act_0.png","Act_1.png","Act_2.png","Act_3.png","Act_4.png","Act_5.png","Act_6.png","Act_7.png","Act_8.png","Act_9.png"],
              day_zero: 1,
              day_space: 1,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time_AmPm = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              am_x: 144,
              am_y: 163,
              am_sc_path: 'Clock_AM.png',
              am_en_path: 'Clock_AM.png',
              pm_x: 144,
              pm_y: 163,
              pm_sc_path: 'Clock_PM.png',
              pm_en_path: 'Clock_PM.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time_second = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              second_startX: 0,
              second_startY: 0,
              second_array: ["E0.png","E1.png","E2.png","E3.png","E4.png","E5.png","E6.png","E7.png","E8.png","E9.png"],
              second_zero: 0,
              second_space: 0,
              second_angle: 0,
              second_follow: 0,
              second_align: hmUI.align.LEFT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time_minute = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              minute_startX: 176,
              minute_startY: 181,
              minute_array: ["Time_0.png","Time_1.png","Time_2.png","Time_3.png","Time_4.png","Time_5.png","Time_6.png","Time_7.png","Time_8.png","Time_9.png"],
              minute_zero: 1,
              minute_space: 2,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time_hour = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 176,
              hour_startY: 103,
              hour_array: ["Time_0.png","Time_1.png","Time_2.png","Time_3.png","Time_4.png","Time_5.png","Time_6.png","Time_7.png","Time_8.png","Time_9.png"],
              hour_zero: 1,
              hour_space: 2,
              hour_angle: 0,
              hour_align: hmUI.align.LEFT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            const deviceInfo = hmSetting.getDeviceInfo();
            if (!timeSensor) timeSensor = hmSensor.createSensor(hmSensor.id.TIME);
            // normal_analog_clock_pro_second_pointer_img = hmUI.createWidget(hmUI.widget.TIME_POINTER_PRO, {
              // src: 'Hand_S1.png',
              // center_x: 233,
              // center_y: 171,
              // x: 27,
              // y: 141,
              // start_angle: 0,
              // end_angle: 360,
              // type: hmUI.data_type.second,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });


            normal_analog_clock_pro_second_pointer_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: deviceInfo.width,
              h: deviceInfo.height,
              pos_x: 233 - 27,
              pos_y: 171 - 141,
              center_x: 233,
              center_y: 171,
              src: 'Hand_S1.png',
              angle: 0,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            let screenType = hmSetting.getScreenType();
            // normal_analog_clock_pro_smooth_second = hmUI.createWidget(hmUI.widget.SMOOTH_SECOND, {
              // type: 2,
              // fps: 15,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });



            console.log('Watch_Face.ScreenAOD');

            idle_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 223,
              y: 312,
              src: 'System_BT_OFF.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 297,
              y: 167,
              src: 'System_Alarm.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            // idle_sunset_text_circle_img = hmUI.createWidget(hmUI.widget.Text_Circle, {
              // circle_center_X: 233,
              // circle_center_Y: 233,
              // font_array: ["Act_cal_0.png","Act_cal_1.png","Act_cal_2.png","Act_cal_3.png","Act_cal_4.png","Act_cal_5.png","Act_cal_6.png","Act_cal_7.png","Act_cal_8.png","Act_cal_9.png"],
              // radius: 200,
              // angle: 28,
              // char_space_angle: 0,
              // dot_image: 'sunrise_set.png',
              // zero: true,
              // reverse_direction: false,
              // unit_in_alignment: true,
              // vertical_alignment: BOTTOM,
              // horizontal_alignment: LEFT,
              // type: hmUI.data_type.SUN_SET,
              // show_level: hmUI.show_level.ONLY_AOD,
            // });

            idle_sunset_TextCircle_ASCIIARRAY[0] = 'Act_cal_0.png';  // set of images with numbers
            idle_sunset_TextCircle_ASCIIARRAY[1] = 'Act_cal_1.png';  // set of images with numbers
            idle_sunset_TextCircle_ASCIIARRAY[2] = 'Act_cal_2.png';  // set of images with numbers
            idle_sunset_TextCircle_ASCIIARRAY[3] = 'Act_cal_3.png';  // set of images with numbers
            idle_sunset_TextCircle_ASCIIARRAY[4] = 'Act_cal_4.png';  // set of images with numbers
            idle_sunset_TextCircle_ASCIIARRAY[5] = 'Act_cal_5.png';  // set of images with numbers
            idle_sunset_TextCircle_ASCIIARRAY[6] = 'Act_cal_6.png';  // set of images with numbers
            idle_sunset_TextCircle_ASCIIARRAY[7] = 'Act_cal_7.png';  // set of images with numbers
            idle_sunset_TextCircle_ASCIIARRAY[8] = 'Act_cal_8.png';  // set of images with numbers
            idle_sunset_TextCircle_ASCIIARRAY[9] = 'Act_cal_9.png';  // set of images with numbers

            //start of ignored block
            for (let i = 0; i < 5; i++) {
              idle_sunset_TextCircle[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 466,
                h: 466,
                center_x: 233,
                center_y: 233,
                pos_x: 233 - idle_sunset_TextCircle_img_width / 2,
                pos_y: 233 - 217,
                src: 'Act_cal_0.png',
                show_level: hmUI.show_level.ONLY_AOD,
              });
              idle_sunset_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
            };
            //end of ignored block

            // idle_sunrise_text_circle_img = hmUI.createWidget(hmUI.widget.Text_Circle, {
              // circle_center_X: 233,
              // circle_center_Y: 233,
              // font_array: ["Act_cal_0.png","Act_cal_1.png","Act_cal_2.png","Act_cal_3.png","Act_cal_4.png","Act_cal_5.png","Act_cal_6.png","Act_cal_7.png","Act_cal_8.png","Act_cal_9.png"],
              // radius: 201,
              // angle: -43,
              // char_space_angle: 0,
              // dot_image: 'sunrise_set.png',
              // zero: true,
              // reverse_direction: false,
              // unit_in_alignment: true,
              // vertical_alignment: BOTTOM,
              // horizontal_alignment: LEFT,
              // type: hmUI.data_type.SUN_RISE,
              // show_level: hmUI.show_level.ONLY_AOD,
            // });

            idle_sunrise_TextCircle_ASCIIARRAY[0] = 'Act_cal_0.png';  // set of images with numbers
            idle_sunrise_TextCircle_ASCIIARRAY[1] = 'Act_cal_1.png';  // set of images with numbers
            idle_sunrise_TextCircle_ASCIIARRAY[2] = 'Act_cal_2.png';  // set of images with numbers
            idle_sunrise_TextCircle_ASCIIARRAY[3] = 'Act_cal_3.png';  // set of images with numbers
            idle_sunrise_TextCircle_ASCIIARRAY[4] = 'Act_cal_4.png';  // set of images with numbers
            idle_sunrise_TextCircle_ASCIIARRAY[5] = 'Act_cal_5.png';  // set of images with numbers
            idle_sunrise_TextCircle_ASCIIARRAY[6] = 'Act_cal_6.png';  // set of images with numbers
            idle_sunrise_TextCircle_ASCIIARRAY[7] = 'Act_cal_7.png';  // set of images with numbers
            idle_sunrise_TextCircle_ASCIIARRAY[8] = 'Act_cal_8.png';  // set of images with numbers
            idle_sunrise_TextCircle_ASCIIARRAY[9] = 'Act_cal_9.png';  // set of images with numbers

            //start of ignored block
            for (let i = 0; i < 5; i++) {
              idle_sunrise_TextCircle[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 466,
                h: 466,
                center_x: 233,
                center_y: 233,
                pos_x: 233 - idle_sunrise_TextCircle_img_width / 2,
                pos_y: 233 - 218,
                src: 'Act_cal_0.png',
                show_level: hmUI.show_level.ONLY_AOD,
              });
              idle_sunrise_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
            };
            //end of ignored block

            idle_moon_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 215,
              y: 256,
              image_array: ["moon01.png","moon02.png","moon03.png","moon04.png","moon05.png","moon06.png","moon07.png","moon08.png","moon09.png","moon10.png","moon11.png","moon12.png","moon13.png","moon14.png","moon15.png","moon16.png","moon17.png","moon18.png","moon19.png","moon20.png","moon21.png","moon22.png","moon23.png","moon24.png","moon25.png","moon26.png","moon27.png","moon28.png","moon29.png","moon30.png"],
              image_length: 30,
              type: hmUI.data_type.MOON,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 209,
              day_startY: 378,
              day_sc_array: ["Act_0.png","Act_1.png","Act_2.png","Act_3.png","Act_4.png","Act_5.png","Act_6.png","Act_7.png","Act_8.png","Act_9.png"],
              day_tc_array: ["Act_0.png","Act_1.png","Act_2.png","Act_3.png","Act_4.png","Act_5.png","Act_6.png","Act_7.png","Act_8.png","Act_9.png"],
              day_en_array: ["Act_0.png","Act_1.png","Act_2.png","Act_3.png","Act_4.png","Act_5.png","Act_6.png","Act_7.png","Act_8.png","Act_9.png"],
              day_zero: 1,
              day_space: 1,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_battery_current_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 199,
              y: 427,
              w: 70,
              h: 50,
              text_size: 28,
              char_space: 0,
              line_space: 0,
              color: 0xFFFFFFFF,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.TOP,
              unit_type: 1,
              text_style: hmUI.text_style.ELLIPSIS,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time_AmPm = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              am_x: 144,
              am_y: 163,
              am_sc_path: 'Clock_AM.png',
              am_en_path: 'Clock_AM.png',
              pm_x: 144,
              pm_y: 163,
              pm_sc_path: 'Clock_PM.png',
              pm_en_path: 'Clock_PM.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time_minute = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              minute_startX: 176,
              minute_startY: 181,
              minute_array: ["Time_0.png","Time_1.png","Time_2.png","Time_3.png","Time_4.png","Time_5.png","Time_6.png","Time_7.png","Time_8.png","Time_9.png"],
              minute_zero: 1,
              minute_space: 2,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time_hour = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 176,
              hour_startY: 103,
              hour_array: ["Time_0.png","Time_1.png","Time_2.png","Time_3.png","Time_4.png","Time_5.png","Time_6.png","Time_7.png","Time_8.png","Time_9.png"],
              hour_zero: 1,
              hour_space: 2,
              hour_angle: 0,
              hour_align: hmUI.align.LEFT,
              show_level: hmUI.show_level.ONLY_AOD,
            });
            console.log('Watch_Face.Shortcuts');

            normal_stopwatch_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 202,
              y: 108,
              w: 65,
              h: 51,
              type: hmUI.data_type.STOP_WATCH,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_countdown_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 205,
              y: 187,
              w: 55,
              h: 50,
              type: hmUI.data_type.COUNT_DOWN,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_alarm_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 290,
              y: 153,
              w: 39,
              h: 38,
              type: hmUI.data_type.ALARM_CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sunrise_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 154,
              y: 18,
              w: 162,
              h: 25,
              type: hmUI.data_type.SUN_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 73,
              y: 339,
              w: 101,
              h: 80,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_pai_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 365,
              y: 239,
              w: 85,
              h: 34,
              type: hmUI.data_type.PAI_WEEKLY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_spo2_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 388,
              y: 129,
              w: 46,
              h: 52,
              type: hmUI.data_type.SPO2,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 397,
              y: 205,
              w: 66,
              h: 22,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 21,
              y: 250,
              w: 90,
              h: 23,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            console.log('Watch_Face.Buttons');
            Button_1 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 339,
              y: 47,
              w: 50,
              h: 40,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'FindPhoneScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_2 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 83,
              y: 49,
              w: 50,
              h: 40,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'PhoneHomeScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_3 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 328,
              y: 288,
              w: 101,
              h: 37,
              text: '',
              color: 0xFFFF8C00,
              text_size: 24,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'SportListScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_4 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 207,
              y: 364,
              w: 58,
              h: 54,
              text: '',
              color: 0xFFFF8C00,
              text_size: 24,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'ScheduleCalScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_5 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 29,
              y: 132,
              w: 48,
              h: 50,
              text: '',
              color: 0xFFFF8C00,
              text_size: 24,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'PowerSaveHintScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_6 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 205,
              y: 312,
              w: 52,
              h: 44,
              text: '',
              color: 0xFFFF8C00,
              text_size: 24,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                click_Color();
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_7 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 208,
              y: 52,
              w: 52,
              h: 44,
              text: '',
              color: 0xFFFF8C00,
              text_size: 24,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                click_ColorM();
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_8 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 208,
              y: 262,
              w: 52,
              h: 44,
              text: '',
              color: 0xFFFF8C00,
              text_size: 24,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                click_ColorH();
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_9 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 109,
              y: 154,
              w: 52,
              h: 44,
              text: '',
              color: 0xFFFF8C00,
              text_size: 24,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                click_Style();
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_10 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 90,
              y: 90,
              w: 35,
              h: 35,
              text: '',
              color: 0xFFFF8C00,
              text_size: 24,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                click_StyleB();
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_11 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 344,
              y: 90,
              w: 35,
              h: 35,
              text: '',
              color: 0xFFFF8C00,
              text_size: 24,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                click_StyleP();
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_12 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 334,
              y: 156,
              w: 35,
              h: 35,
              text: '',
              color: 0xFFFF8C00,
              text_size: 24,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                click_StyleCC();
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_13 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 186,
              y: 431,
              w: 96,
              h: 35,
              text: '',
              color: 0xFFFF8C00,
              text_size: 24,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                click_Whitescreen() ;
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            function time_update(updateHour = false, updateMinute = false) {
              console.log('time_update()');
              let hour = timeSensor.hour;
              let minute = timeSensor.minute;
              let second = timeSensor.second;
              let format_hour = timeSensor.format_hour;

              let normal_fullAngle_second = 360;
              let normal_angle_second = 0 + normal_fullAngle_second*(second + (timeSensor.utc % 1000)/1000)/60;
              if (normal_analog_clock_pro_second_pointer_img) normal_analog_clock_pro_second_pointer_img.setProperty(hmUI.prop.ANGLE, normal_angle_second);

            };

            function text_update() {
              console.log('text_update()');
              let weatherData = weatherSensor.getForecastWeather();
              let tideData = weatherData.tideData;
              let sunset_hour = -1;
              let sunset_minute = -1;
              if (tideData.count > 0) {
                sunset_hour = tideData.data[0].sunset.hour;
                sunset_minute = tideData.data[0].sunset.minute;
              }; // end tideData;

              console.log('update text circle sunset_tideData');
              let sunsetTime = undefined;
              let normal_sunset_circle_string = undefined;
              if (sunset_hour >= 0 && sunset_minute >= 0) {
                sunsetTime = 0;
                normal_sunset_circle_string = String(sunset_hour).padStart(2, '0') + '.' + String(sunset_minute).padStart(2, '0');
              };

              if (screenType != hmSetting.screen_type.AOD) {
                for (var i = 1; i < 5; i++) {  // hide all symbols
                  normal_sunset_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                let char_Angle = 13;
                if (sunsetTime != null && sunsetTime != undefined && isFinite(sunsetTime) && normal_sunset_circle_string.length > 0 && normal_sunset_circle_string.length < 6) {  // display data if it was possible to get it
                  let normal_sunset_TextCircle_img_angle = 0;
                  let normal_sunset_TextCircle_dot_img_angle = 0;
                  normal_sunset_TextCircle_img_angle = toDegree(Math.atan2(normal_sunset_TextCircle_img_width/2, 203));
                  normal_sunset_TextCircle_dot_img_angle = toDegree(Math.atan2(normal_sunset_TextCircle_dot_width/2, 203));
                  
                  let firstSymbol = true;
                  let index = 0;
                  for (let char of normal_sunset_circle_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 5) break;
                    if (charCode >= 0 && charCode < 10) { 
                      if (!firstSymbol) char_Angle += normal_sunset_TextCircle_img_angle;
                      firstSymbol = false;
                      normal_sunset_TextCircle[index].setProperty(hmUI.prop.ANGLE, char_Angle);
                      normal_sunset_TextCircle[index].setProperty(hmUI.prop.POS_X, 233 - normal_sunset_TextCircle_img_width / 2);
                      normal_sunset_TextCircle[index].setProperty(hmUI.prop.SRC, normal_sunset_TextCircle_ASCIIARRAY[charCode]);
                      normal_sunset_TextCircle[index].setProperty(hmUI.prop.VISIBLE, true);
                      char_Angle += normal_sunset_TextCircle_img_angle;
                      index++;
                    }  // end if digit
                    else { 
                      if (!firstSymbol) char_Angle += normal_sunset_TextCircle_dot_img_angle; 
                      firstSymbol = false;
                      normal_sunset_TextCircle[index].setProperty(hmUI.prop.ANGLE, char_Angle);
                      normal_sunset_TextCircle[index].setProperty(hmUI.prop.POS_X, 233 - normal_sunset_TextCircle_dot_width / 2);
                      normal_sunset_TextCircle[index].setProperty(hmUI.prop.SRC, 'sunrise_set.png');
                      normal_sunset_TextCircle[index].setProperty(hmUI.prop.VISIBLE, true);
                      char_Angle += normal_sunset_TextCircle_dot_img_angle;
                      index++;
                    };  // end if dot point 
                  };  // end char of string
                }  // end isFinite

              };
              let sunrise_hour = -1;
              let sunrise_minute = -1;
              if (tideData.count > 0) {
                sunrise_hour = tideData.data[0].sunrise.hour;
                sunrise_minute = tideData.data[0].sunrise.minute;
              }; // end tideData;

              console.log('update text circle sunrise_tideData');
              let sunriseTime = undefined;
              let normal_sunrise_circle_string = undefined;
              if (sunrise_hour >= 0 && sunrise_minute >= 0) {
                sunriseTime = 0;
                normal_sunrise_circle_string = String(sunrise_hour).padStart(2, '0') + '.' + String(sunrise_minute).padStart(2, '0');
              };

              if (screenType != hmSetting.screen_type.AOD) {
                for (var i = 1; i < 5; i++) {  // hide all symbols
                  normal_sunrise_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                let char_Angle = -29;
                if (sunriseTime != null && sunriseTime != undefined && isFinite(sunriseTime) && normal_sunrise_circle_string.length > 0 && normal_sunrise_circle_string.length < 6) {  // display data if it was possible to get it
                  let normal_sunrise_TextCircle_img_angle = 0;
                  let normal_sunrise_TextCircle_dot_img_angle = 0;
                  normal_sunrise_TextCircle_img_angle = toDegree(Math.atan2(normal_sunrise_TextCircle_img_width/2, 204));
                  normal_sunrise_TextCircle_dot_img_angle = toDegree(Math.atan2(normal_sunrise_TextCircle_dot_width/2, 204));
                  
                  let firstSymbol = true;
                  let index = 0;
                  for (let char of normal_sunrise_circle_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 5) break;
                    if (charCode >= 0 && charCode < 10) { 
                      if (!firstSymbol) char_Angle += normal_sunrise_TextCircle_img_angle;
                      firstSymbol = false;
                      normal_sunrise_TextCircle[index].setProperty(hmUI.prop.ANGLE, char_Angle);
                      normal_sunrise_TextCircle[index].setProperty(hmUI.prop.POS_X, 233 - normal_sunrise_TextCircle_img_width / 2);
                      normal_sunrise_TextCircle[index].setProperty(hmUI.prop.SRC, normal_sunrise_TextCircle_ASCIIARRAY[charCode]);
                      normal_sunrise_TextCircle[index].setProperty(hmUI.prop.VISIBLE, true);
                      char_Angle += normal_sunrise_TextCircle_img_angle;
                      index++;
                    }  // end if digit
                    else { 
                      if (!firstSymbol) char_Angle += normal_sunrise_TextCircle_dot_img_angle; 
                      firstSymbol = false;
                      normal_sunrise_TextCircle[index].setProperty(hmUI.prop.ANGLE, char_Angle);
                      normal_sunrise_TextCircle[index].setProperty(hmUI.prop.POS_X, 233 - normal_sunrise_TextCircle_dot_width / 2);
                      normal_sunrise_TextCircle[index].setProperty(hmUI.prop.SRC, 'sunrise_set.png');
                      normal_sunrise_TextCircle[index].setProperty(hmUI.prop.VISIBLE, true);
                      char_Angle += normal_sunrise_TextCircle_dot_img_angle;
                      index++;
                    };  // end if dot point 
                  };  // end char of string
                }  // end isFinite

              };

              console.log('update text rotate DISTANCE');
              let distanceCurrent = distance.current;
              let normal_distance_rotate_string = (distanceCurrent / 1000).toFixed(2);

              if (screenType != hmSetting.screen_type.AOD) {
                for (var i = 1; i < 5; i++) {  // hide all symbols
                  normal_distance_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                if (distanceCurrent != null && distanceCurrent != undefined && isFinite(distanceCurrent) && normal_distance_rotate_string.length > 0 && normal_distance_rotate_string.length < 6) {  // display data if it was possible to get it
                  let img_offset = 0;
                  // alignment = CENTER_H
                  let normal_distance_TextRotate_posOffset = normal_distance_TextRotate_img_width * normal_distance_rotate_string.length;
                  normal_distance_TextRotate_posOffset = normal_distance_TextRotate_posOffset - normal_distance_TextRotate_img_width + normal_distance_TextRotate_dot_width;
                  img_offset -= normal_distance_TextRotate_posOffset/2;
                  // alignment end
                  
                  let index = 0;
                  for (let char of normal_distance_rotate_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 5) break;
                    if (charCode >= 0 && charCode < 10) { 
                      normal_distance_TextRotate[index].setProperty(hmUI.prop.POS_X, 383 + img_offset);
                      normal_distance_TextRotate[index].setProperty(hmUI.prop.SRC, normal_distance_TextRotate_ASCIIARRAY[charCode]);
                      normal_distance_TextRotate[index].setProperty(hmUI.prop.VISIBLE, true);
                      img_offset += normal_distance_TextRotate_img_width;
                      index++;
                    }  // end if digit
                    else { 
                      normal_distance_TextRotate[index].setProperty(hmUI.prop.POS_X, 383 + img_offset);
                      normal_distance_TextRotate[index].setProperty(hmUI.prop.SRC, 'Dis_Dot.png');
                      normal_distance_TextRotate[index].setProperty(hmUI.prop.VISIBLE, true);
                      img_offset += normal_distance_TextRotate_dot_width;
                      index++;
                    };  // end if dot point 
                  };  // end char of string
                }  // end isFinite
                else {
                  normal_distance_TextRotate[0].setProperty(hmUI.prop.POS_X, 383 - normal_distance_TextRotate_error_img_width / 2);
                  normal_distance_TextRotate[0].setProperty(hmUI.prop.SRC, 'Act_Small_0.png');
                  normal_distance_TextRotate[0].setProperty(hmUI.prop.VISIBLE, true);
                };  // end else isFinite

              };

              console.log('update text circle sunset_tideData');
              let idle_sunset_circle_string = undefined;
              if (sunset_hour >= 0 && sunset_minute >= 0) {
                sunsetTime = 0;
                idle_sunset_circle_string = String(sunset_hour).padStart(2, '0') + '.' + String(sunset_minute).padStart(2, '0');
              };

              if (screenType == hmSetting.screen_type.AOD) {
                for (var i = 1; i < 5; i++) {  // hide all symbols
                  idle_sunset_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                let char_Angle = 28;
                if (sunsetTime != null && sunsetTime != undefined && isFinite(sunsetTime) && idle_sunset_circle_string.length > 0 && idle_sunset_circle_string.length < 6) {  // display data if it was possible to get it
                  let idle_sunset_TextCircle_img_angle = 0;
                  let idle_sunset_TextCircle_dot_img_angle = 0;
                  idle_sunset_TextCircle_img_angle = toDegree(Math.atan2(idle_sunset_TextCircle_img_width/2, 200));
                  idle_sunset_TextCircle_dot_img_angle = toDegree(Math.atan2(idle_sunset_TextCircle_dot_width/2, 200));
                  
                  let firstSymbol = true;
                  let index = 0;
                  for (let char of idle_sunset_circle_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 5) break;
                    if (charCode >= 0 && charCode < 10) { 
                      if (!firstSymbol) char_Angle += idle_sunset_TextCircle_img_angle;
                      firstSymbol = false;
                      idle_sunset_TextCircle[index].setProperty(hmUI.prop.ANGLE, char_Angle);
                      idle_sunset_TextCircle[index].setProperty(hmUI.prop.POS_X, 233 - idle_sunset_TextCircle_img_width / 2);
                      idle_sunset_TextCircle[index].setProperty(hmUI.prop.SRC, idle_sunset_TextCircle_ASCIIARRAY[charCode]);
                      idle_sunset_TextCircle[index].setProperty(hmUI.prop.VISIBLE, true);
                      char_Angle += idle_sunset_TextCircle_img_angle;
                      index++;
                    }  // end if digit
                    else { 
                      if (!firstSymbol) char_Angle += idle_sunset_TextCircle_dot_img_angle; 
                      firstSymbol = false;
                      idle_sunset_TextCircle[index].setProperty(hmUI.prop.ANGLE, char_Angle);
                      idle_sunset_TextCircle[index].setProperty(hmUI.prop.POS_X, 233 - idle_sunset_TextCircle_dot_width / 2);
                      idle_sunset_TextCircle[index].setProperty(hmUI.prop.SRC, 'sunrise_set.png');
                      idle_sunset_TextCircle[index].setProperty(hmUI.prop.VISIBLE, true);
                      char_Angle += idle_sunset_TextCircle_dot_img_angle;
                      index++;
                    };  // end if dot point 
                  };  // end char of string
                }  // end isFinite

              };

              console.log('update text circle sunrise_tideData');
              let idle_sunrise_circle_string = undefined;
              if (sunrise_hour >= 0 && sunrise_minute >= 0) {
                sunriseTime = 0;
                idle_sunrise_circle_string = String(sunrise_hour).padStart(2, '0') + '.' + String(sunrise_minute).padStart(2, '0');
              };

              if (screenType == hmSetting.screen_type.AOD) {
                for (var i = 1; i < 5; i++) {  // hide all symbols
                  idle_sunrise_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                let char_Angle = -43;
                if (sunriseTime != null && sunriseTime != undefined && isFinite(sunriseTime) && idle_sunrise_circle_string.length > 0 && idle_sunrise_circle_string.length < 6) {  // display data if it was possible to get it
                  let idle_sunrise_TextCircle_img_angle = 0;
                  let idle_sunrise_TextCircle_dot_img_angle = 0;
                  idle_sunrise_TextCircle_img_angle = toDegree(Math.atan2(idle_sunrise_TextCircle_img_width/2, 201));
                  idle_sunrise_TextCircle_dot_img_angle = toDegree(Math.atan2(idle_sunrise_TextCircle_dot_width/2, 201));
                  
                  let firstSymbol = true;
                  let index = 0;
                  for (let char of idle_sunrise_circle_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 5) break;
                    if (charCode >= 0 && charCode < 10) { 
                      if (!firstSymbol) char_Angle += idle_sunrise_TextCircle_img_angle;
                      firstSymbol = false;
                      idle_sunrise_TextCircle[index].setProperty(hmUI.prop.ANGLE, char_Angle);
                      idle_sunrise_TextCircle[index].setProperty(hmUI.prop.POS_X, 233 - idle_sunrise_TextCircle_img_width / 2);
                      idle_sunrise_TextCircle[index].setProperty(hmUI.prop.SRC, idle_sunrise_TextCircle_ASCIIARRAY[charCode]);
                      idle_sunrise_TextCircle[index].setProperty(hmUI.prop.VISIBLE, true);
                      char_Angle += idle_sunrise_TextCircle_img_angle;
                      index++;
                    }  // end if digit
                    else { 
                      if (!firstSymbol) char_Angle += idle_sunrise_TextCircle_dot_img_angle; 
                      firstSymbol = false;
                      idle_sunrise_TextCircle[index].setProperty(hmUI.prop.ANGLE, char_Angle);
                      idle_sunrise_TextCircle[index].setProperty(hmUI.prop.POS_X, 233 - idle_sunrise_TextCircle_dot_width / 2);
                      idle_sunrise_TextCircle[index].setProperty(hmUI.prop.SRC, 'sunrise_set.png');
                      idle_sunrise_TextCircle[index].setProperty(hmUI.prop.VISIBLE, true);
                      char_Angle += idle_sunrise_TextCircle_dot_img_angle;
                      index++;
                    };  // end if dot point 
                  };  // end char of string
                }  // end isFinite

              };

            };

            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                console.log('resume_call()');
                time_update(true, true);
                text_update();
                if (screenType == hmSetting.screen_type.WATCHFACE) {
                  if (!normal_timerUpdateSecSmooth) {
                    let animDelay = 0;
                    let animRepeat = 1000/15;
                    normal_timerUpdateSecSmooth = timer.createTimer(animDelay, animRepeat, (function (option) {
                      time_update(false, false);
                    }));  // end timer 
                  };  // end timer check
                };  // end screenType


              }),
              pause_call: (function () {
                console.log('pause_call()');
                if (normal_timerUpdateSecSmooth) {
                  timer.stopTimer(normal_timerUpdateSecSmooth);
                  normal_timerUpdateSecSmooth = undefined;
                }

              }),
            });

                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}