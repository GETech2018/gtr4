﻿
    /*
    ** Watch_Face_Editor tool
    ** watchface js version v1.0.1
    ** Copyright © CashaCX75. All Rights Reserved
    */

    try {

      (() => {

        var __$$app$$__ = __$$hmAppManager$$__.currentApp;
        var __$$module$$__ = __$$app$$__.current;
        //drink is a name,can modify
        var h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__), 'drink');

        'use strict';

        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_system_lock_img = ''
        let normal_system_dnd_img = ''
        let normal_system_disconnect_img = ''
        let normal_system_clock_img = ''
        let normal_temperature_current_text_img = ''
        let normal_step_current_text_img = ''
        let normal_heart_rate_text_text_img = ''
        let normal_battery_text_text_img = ''
        let normal_date_img_date_day = ''
        let normal_digital_clock_img_time = ''
        let normal_analog_clock_time_pointer_hour = ''
        let normal_analog_clock_time_pointer_minute = ''
        let normal_analog_clock_time_pointer_second = ''
        let idle_background_bg_img = ''
        let idle_system_lock_img = ''
        let idle_system_dnd_img = ''
        let idle_system_disconnect_img = ''
        let idle_system_clock_img = ''
        let idle_battery_text_text_img = ''
        let idle_date_img_date_day = ''
        let idle_digital_clock_img_time = ''
        let idle_analog_clock_time_pointer_hour = ''
        let idle_analog_clock_time_pointer_minute = ''
        let idle_analog_clock_time_pointer_second = ''


        //dynamic modify end

        //not required
        const logger = DeviceRuntimeCore.HmLogger.getLogger("yeguang");

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({

          init_view() {

            //dynamic modify start
                    
            
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 466,
              h: 466,
              src: 'GTR4_Digital_Analog_Bckg.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_lock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 145,
              y: 190,
              src: 'Locked_Black.png',
              type: hmUI.system_status.LOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_dnd_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 298,
              y: 190,
              src: 'DND_Black.png',
              type: hmUI.system_status.DISTURB,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 256,
              y: 190,
              src: 'BlueT_Black.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 186,
              y: 190,
              src: 'Alarm_Black.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 279,
              y: 148,
              font_array: ["D7_Small_Black_0.png","D7_Small_Black_1.png","D7_Small_Black_2.png","D7_Small_Black_3.png","D7_Small_Black_4.png","D7_Small_Black_5.png","D7_Small_Black_6.png","D7_Small_Black_7.png","D7_Small_Black_8.png","D7_Small_Black_9.png"],
              padding: false,
              h_space: 3,
              negative_image: 'D7_Small_Black_Minus.png',
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 158,
              y: 90,
              font_array: ["D7_Small_Black_0.png","D7_Small_Black_1.png","D7_Small_Black_2.png","D7_Small_Black_3.png","D7_Small_Black_4.png","D7_Small_Black_5.png","D7_Small_Black_6.png","D7_Small_Black_7.png","D7_Small_Black_8.png","D7_Small_Black_9.png"],
              padding: false,
              h_space: 4,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 95,
              y: 147,
              font_array: ["D7_Small_Black_0.png","D7_Small_Black_1.png","D7_Small_Black_2.png","D7_Small_Black_3.png","D7_Small_Black_4.png","D7_Small_Black_5.png","D7_Small_Black_6.png","D7_Small_Black_7.png","D7_Small_Black_8.png","D7_Small_Black_9.png"],
              padding: false,
              h_space: 4,
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 57,
              y: 215,
              font_array: ["D7_Small_Black_0.png","D7_Small_Black_1.png","D7_Small_Black_2.png","D7_Small_Black_3.png","D7_Small_Black_4.png","D7_Small_Black_5.png","D7_Small_Black_6.png","D7_Small_Black_7.png","D7_Small_Black_8.png","D7_Small_Black_9.png"],
              padding: false,
              h_space: 2,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 363,
              day_startY: 215,
              day_sc_array: ["D7_Small_Black_0.png","D7_Small_Black_1.png","D7_Small_Black_2.png","D7_Small_Black_3.png","D7_Small_Black_4.png","D7_Small_Black_5.png","D7_Small_Black_6.png","D7_Small_Black_7.png","D7_Small_Black_8.png","D7_Small_Black_9.png"],
              day_tc_array: ["D7_Small_Black_0.png","D7_Small_Black_1.png","D7_Small_Black_2.png","D7_Small_Black_3.png","D7_Small_Black_4.png","D7_Small_Black_5.png","D7_Small_Black_6.png","D7_Small_Black_7.png","D7_Small_Black_8.png","D7_Small_Black_9.png"],
              day_en_array: ["D7_Small_Black_0.png","D7_Small_Black_1.png","D7_Small_Black_2.png","D7_Small_Black_3.png","D7_Small_Black_4.png","D7_Small_Black_5.png","D7_Small_Black_6.png","D7_Small_Black_7.png","D7_Small_Black_8.png","D7_Small_Black_9.png"],
              day_zero: 1,
              day_space: 3,
              day_align: hmUI.align.LEFT,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 114,
              hour_startY: 278,
              hour_array: ["D7_Big_Blackpng_0.png","D7_Big_Blackpng_1.png","D7_Big_Blackpng_2.png","D7_Big_Blackpng_3.png","D7_Big_Blackpng_4.png","D7_Big_Blackpng_5.png","D7_Big_Blackpng_6.png","D7_Big_Blackpng_7.png","D7_Big_Blackpng_8.png","D7_Big_Blackpng_9.png"],
              hour_zero: 1,
              hour_space: 8,
              hour_align: hmUI.align.LEFT,

              minute_startX: 262,
              minute_startY: 278,
              minute_array: ["D7_Big_Blackpng_0.png","D7_Big_Blackpng_1.png","D7_Big_Blackpng_2.png","D7_Big_Blackpng_3.png","D7_Big_Blackpng_4.png","D7_Big_Blackpng_5.png","D7_Big_Blackpng_6.png","D7_Big_Blackpng_7.png","D7_Big_Blackpng_8.png","D7_Big_Blackpng_9.png"],
              minute_zero: 1,
              minute_space: 7,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_hour = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              hour_path: 'RW_Hour.png',
              hour_centerX: 233,
              hour_centerY: 233,
              hour_posX: 16,
              hour_posY: 152,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_minute = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              minute_path: 'RW_Minute.png',
              minute_centerX: 233,
              minute_centerY: 233,
              minute_posX: 15,
              minute_posY: 196,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_second = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              second_path: 'RW_Second.png',
              second_centerX: 233,
              second_centerY: 233,
              second_posX: 15,
              second_posY: 196,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            idle_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 466,
              h: 466,
              src: 'GTR4_Digital_Analog_Bckg_AOD.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_system_lock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 145,
              y: 190,
              src: 'Locked_White.png',
              type: hmUI.system_status.LOCK,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_system_dnd_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 298,
              y: 190,
              src: 'DND_White.png',
              type: hmUI.system_status.DISTURB,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 256,
              y: 190,
              src: 'BlueT_White.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 186,
              y: 190,
              src: 'Alarm_white.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 57,
              y: 215,
              font_array: ["D7_Small_White_0.png","D7_Small_White_1.png","D7_Small_White_2.png","D7_Small_White_3.png","D7_Small_White_4.png","D7_Small_White_5.png","D7_Small_White_6.png","D7_Small_White_7.png","D7_Small_White_8.png","D7_Small_White_9.png"],
              padding: false,
              h_space: 2,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 363,
              day_startY: 215,
              day_sc_array: ["D7_Small_White_0.png","D7_Small_White_1.png","D7_Small_White_2.png","D7_Small_White_3.png","D7_Small_White_4.png","D7_Small_White_5.png","D7_Small_White_6.png","D7_Small_White_7.png","D7_Small_White_8.png","D7_Small_White_9.png"],
              day_tc_array: ["D7_Small_White_0.png","D7_Small_White_1.png","D7_Small_White_2.png","D7_Small_White_3.png","D7_Small_White_4.png","D7_Small_White_5.png","D7_Small_White_6.png","D7_Small_White_7.png","D7_Small_White_8.png","D7_Small_White_9.png"],
              day_en_array: ["D7_Small_White_0.png","D7_Small_White_1.png","D7_Small_White_2.png","D7_Small_White_3.png","D7_Small_White_4.png","D7_Small_White_5.png","D7_Small_White_6.png","D7_Small_White_7.png","D7_Small_White_8.png","D7_Small_White_9.png"],
              day_zero: 1,
              day_space: 3,
              day_align: hmUI.align.LEFT,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 114,
              hour_startY: 278,
              hour_array: ["D7_Big_White_0.png","D7_Big_White_1.png","D7_Big_White_2.png","D7_Big_White_3.png","D7_Big_White_4.png","D7_Big_White_5.png","D7_Big_White_6.png","D7_Big_White_7.png","D7_Big_White_8.png","D7_Big_White_9.png"],
              hour_zero: 1,
              hour_space: 8,
              hour_align: hmUI.align.LEFT,

              minute_startX: 262,
              minute_startY: 278,
              minute_array: ["D7_Big_White_0.png","D7_Big_White_1.png","D7_Big_White_2.png","D7_Big_White_3.png","D7_Big_White_4.png","D7_Big_White_5.png","D7_Big_White_6.png","D7_Big_White_7.png","D7_Big_White_8.png","D7_Big_White_9.png"],
              minute_zero: 1,
              minute_space: 7,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_analog_clock_time_pointer_hour = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              hour_path: 'RW_Hour.png',
              hour_centerX: 233,
              hour_centerY: 233,
              hour_posX: 16,
              hour_posY: 152,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_analog_clock_time_pointer_minute = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              minute_path: 'RW_Minute.png',
              minute_centerX: 233,
              minute_centerY: 233,
              minute_posX: 15,
              minute_posY: 196,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_analog_clock_time_pointer_second = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              second_path: 'RW_Second.png',
              second_centerX: 233,
              second_centerY: 233,
              second_posX: 15,
              second_posY: 196,
              show_level: hmUI.show_level.ONLY_AOD,
            });


            //dynamic modify end
          },

          onInit() {
            console.log('index page.js on init invoke')

            this.init_view()

          },

          onReady() {
            console.log('index page.js on ready invoke')
          },

          onShow() {
            console.log('index page.js on show invoke')
          },

          onHide() {
            console.log('index page.js on hide invoke')
          },

          onDestory() {
            console.log('index page.js on destory invoke')
          },
        });

      })()
    } catch (e) {
      console.log(e)
    }
  