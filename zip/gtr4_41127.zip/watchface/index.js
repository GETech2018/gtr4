﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        const logger = Logger.getLogger('watchface_SashaCX75');
        //end of ignored block

        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_sun_icon_img = ''
        let normal_sun_pointer_progress_img_pointer = ''
        let normal_temperature_current_text_img = ''
        let normal_heart_rate_text_text_img = ''
        let normal_calorie_current_text_img = ''
        let normal_step_current_text_img = ''
        let normal_altitude_target_text_img = ''
        let normal_altimeter_text_text_img = ''
        let normal_moon_image_progress_img_level = ''
        let normal_date_img_date_week_img = ''
        let normal_battery_text_text_img = ''
        let normal_battery_image_progress_img_level = ''
        let normal_wind_image_progress_img_level = ''
        let normal_humidity_image_progress_img_level = ''
        let normal_uvi_image_progress_img_level = ''
        let normal_digital_clock_img_time_AmPm = ''
        let normal_digital_clock_img_time = ''
		let icon_bg = ''
        let idle_background_bg = ''
        let idle_date_img_date_year = ''
        let idle_date_img_date_month = ''
        let idle_date_img_date_day = ''
        let idle_date_img_date_week_img = ''
        let idle_digital_clock_img_time = ''
        let normal_step_jumpable_img_click = ''
        let normal_cal_jumpable_img_click = ''
        let normal_heart_jumpable_img_click = ''
        let normal_battery_jumpable_img_click = ''
        let normal_temperature_jumpable_img_click = ''
        let normal_altimeter_jumpable_img_click = ''
        let normal_countdown_jumpable_img_click = ''
        let normal_stopwatch_jumpable_img_click = ''
        let normal_alarm_jumpable_img_click = ''
        let normal_altitude_jumpable_img_click = ''
		
		const curTime = hmSensor.createSensor(hmSensor.id.TIME);
		const weather = hmSensor.createSensor(hmSensor.id.WEATHER);
		let weatherData = weather.getForecastWeather();
		let forecastData = weatherData.forecastData;
		let sunData = weatherData.tideData;
		let today = '';
		let sunriseMins = '';
		let sunsetMins = '';
		let sunriseMins_def = 8 * 60;			
		let sunsetMins_def = 20 * 60;

		let curMins = '';
		
		let isDayBg = true;
		
		function autoToggleBg() {

			weatherData = weather.getForecastWeather();
			sunData = weatherData.tideData;
			if (sunData.count > 0){
				today = sunData.data[0];
				sunriseMins = today.sunrise.hour * 60 + today.sunrise.minute;
				sunsetMins = today.sunset.hour * 60 + today.sunset.minute;
			} else {
				sunriseMins = sunriseMins_def;
				sunsetMins = sunsetMins_def;
			}

			curMins = curTime.hour * 60 + curTime.minute;
			let isDayNow = (curMins >= sunriseMins) && (curMins < sunsetMins);
			
			if(isDayNow){
				if(!isDayBg){
					icon_bg.setProperty(hmUI.prop.SRC, "day.png");
					isDayBg = true;
				}
			} else {
				if(isDayBg){
					icon_bg.setProperty(hmUI.prop.SRC, "night.png");
					isDayBg = false;
				}
			}
		}


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            console.log('Watch_Face.ScreenNormal');
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 466,
              h: 466,
              src: 'backgrounden.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            icon_bg = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
			  src: 'day.png',
			  show_level: hmUI.show_level.ONLY_NORMAL,
			});
			
			autoToggleBg();

            normal_sun_pointer_progress_img_pointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
              src: 'sunmoon_sun.png',
              center_x: 233,
              center_y: 233,
              x: 33,
              y: 215,
              start_angle: -62,
              end_angle: 66,
              invalid_visible: false,
              type: hmUI.data_type.SUN_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 190,
              y: 8,
              font_array: ["temp_0.png","temp_1.png","temp_2.png","temp_3.png","temp_4.png","temp_5.png","temp_6.png","temp_7.png","temp_8.png","temp_9.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'du.png',
              unit_tc: 'du.png',
              unit_en: 'du.png',
              negative_image: 'fu.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 110,
              y: 401,
              font_array: ["data_0.png","data_1.png","data_2.png","data_3.png","data_4.png","data_5.png","data_6.png","data_7.png","data_8.png","data_9.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_calorie_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 283,
              y: 401,
              font_array: ["data_0.png","data_1.png","data_2.png","data_3.png","data_4.png","data_5.png","data_6.png","data_7.png","data_8.png","data_9.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 179,
              y: 401,
              font_array: ["data_0.png","data_1.png","data_2.png","data_3.png","data_4.png","data_5.png","data_6.png","data_7.png","data_8.png","data_9.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_altitude_target_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 40,
              y: 326,
              font_array: ["data_0.png","data_1.png","data_2.png","data_3.png","data_4.png","data_5.png","data_6.png","data_7.png","data_8.png","data_9.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.ALTITUDE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_altimeter_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 131,
              y: 326,
              font_array: ["data_0.png","data_1.png","data_2.png","data_3.png","data_4.png","data_5.png","data_6.png","data_7.png","data_8.png","data_9.png"],
              padding: false,
              h_space: -2,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.ALTIMETER,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_moon_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 216,
              y: 429,
              image_array: ["1.png","2.png","3.png","4.png","5.png","6.png","7.png","8.png","9.png","10.png","11.png","12.png","13.png","14.png","15.png","16.png","17.png","18.png","19.png","20.png","21.png","22.png","23.png","24.png","25.png","26.png","27.png","28.png","29.png","30.png"],
              image_length: 30,
              type: hmUI.data_type.MOON,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 239,
              y: 320,
              week_en: ["week_1.png","week_2.png","week_3.png","week_4.png","week_5.png","week_6.png","week_7.png"],
              week_tc: ["week_1.png","week_2.png","week_3.png","week_4.png","week_5.png","week_6.png","week_7.png"],
              week_sc: ["week_1.png","week_2.png","week_3.png","week_4.png","week_5.png","week_6.png","week_7.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 396,
              y: 289,
              font_array: ["batt_0.png","batt_1.png","batt_2.png","batt_3.png","batt_4.png","batt_5.png","batt_6.png","batt_7.png","batt_8.png","batt_9.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 205,
              y: 291,
              image_array: ["battlvl_1.png","battlvl_2.png","battlvl_3.png","battlvl_4.png","battlvl_5.png","battlvl_6.png","battlvl_7.png","battlvl_8.png","battlvl_9.png","battlvl_10.png"],
              image_length: 10,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_wind_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 81,
              y: 18,
              image_array: ["windlvl_1.png","windlvl_2.png","windlvl_3.png","windlvl_4.png","windlvl_5.png"],
              image_length: 5,
              type: hmUI.data_type.WIND,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_humidity_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 373,
              y: 73,
              image_array: ["humilvl_1.png","humilvl_2.png","humilvl_3.png","humilvl_4.png","humilvl_5.png","humilvl_6.png","humilvl_7.png","humilvl_8.png","humilvl_9.png","humilvl_10.png"],
              image_length: 10,
              type: hmUI.data_type.HUMIDITY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_uvi_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 8,
              y: 118,
              image_array: ["uvilvl_1.png","uvilvl_2.png","uvilvl_3.png","uvilvl_4.png","uvilvl_5.png"],
              image_length: 5,
              type: hmUI.data_type.UVI,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time_AmPm = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              am_x: 320,
              am_y: 189,
              am_sc_path: 'am.png',
              am_en_path: 'am.png',
              pm_x: 320,
              pm_y: 189,
              pm_sc_path: 'pm.png',
              pm_en_path: 'pm.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 67,
              hour_startY: 189,
              hour_array: ["time_0.png","time_1.png","time_2.png","time_3.png","time_4.png","time_5.png","time_6.png","time_7.png","time_8.png","time_9.png"],
              hour_zero: 1,
              hour_space: 0,
              hour_angle: 0,
              hour_unit_sc: 'colon.png',
              hour_unit_tc: 'colon.png',
              hour_unit_en: 'colon.png',
              hour_align: hmUI.align.LEFT,

              minute_startX: 206,
              minute_startY: 189,
              minute_array: ["time_0.png","time_1.png","time_2.png","time_3.png","time_4.png","time_5.png","time_6.png","time_7.png","time_8.png","time_9.png"],
              minute_zero: 1,
              minute_space: 0,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              second_startX: 323,
              second_startY: 219,
              second_array: ["sec_0.png","sec_1.png","sec_2.png","sec_3.png","sec_4.png","sec_5.png","sec_6.png","sec_7.png","sec_8.png","sec_9.png"],
              second_zero: 1,
              second_space: 0,
              second_angle: 0,
              second_follow: 0,
              second_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            console.log('Watch_Face.ScreenAOD');
            idle_background_bg = hmUI.createWidget(hmUI.widget.FILL_RECT, {
              x: 0,
              y: 0,
              w: 466,
              h: 466,
              color: '0xFF000000',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_year = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              year_startX: 273,
              year_startY: 97,
              year_sc_array: ["temp_0.png","temp_1.png","temp_2.png","temp_3.png","temp_4.png","temp_5.png","temp_6.png","temp_7.png","temp_8.png","temp_9.png"],
              year_tc_array: ["temp_0.png","temp_1.png","temp_2.png","temp_3.png","temp_4.png","temp_5.png","temp_6.png","temp_7.png","temp_8.png","temp_9.png"],
              year_en_array: ["temp_0.png","temp_1.png","temp_2.png","temp_3.png","temp_4.png","temp_5.png","temp_6.png","temp_7.png","temp_8.png","temp_9.png"],
              year_zero: 0,
              year_space: 0,
              year_align: hmUI.align.CENTER_H,
              year_is_character: false,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_month = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 211,
              month_startY: 97,
              month_sc_array: ["temp_0.png","temp_1.png","temp_2.png","temp_3.png","temp_4.png","temp_5.png","temp_6.png","temp_7.png","temp_8.png","temp_9.png"],
              month_tc_array: ["temp_0.png","temp_1.png","temp_2.png","temp_3.png","temp_4.png","temp_5.png","temp_6.png","temp_7.png","temp_8.png","temp_9.png"],
              month_en_array: ["temp_0.png","temp_1.png","temp_2.png","temp_3.png","temp_4.png","temp_5.png","temp_6.png","temp_7.png","temp_8.png","temp_9.png"],
              month_zero: 1,
              month_space: 0,
              month_unit_sc: 'dot.png',
              month_unit_tc: 'dot.png',
              month_unit_en: 'dot.png',
              month_align: hmUI.align.CENTER_H,
              month_is_character: false,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 150,
              day_startY: 97,
              day_sc_array: ["temp_0.png","temp_1.png","temp_2.png","temp_3.png","temp_4.png","temp_5.png","temp_6.png","temp_7.png","temp_8.png","temp_9.png"],
              day_tc_array: ["temp_0.png","temp_1.png","temp_2.png","temp_3.png","temp_4.png","temp_5.png","temp_6.png","temp_7.png","temp_8.png","temp_9.png"],
              day_en_array: ["temp_0.png","temp_1.png","temp_2.png","temp_3.png","temp_4.png","temp_5.png","temp_6.png","temp_7.png","temp_8.png","temp_9.png"],
              day_zero: 1,
              day_space: 0,
              day_unit_sc: 'dot.png',
              day_unit_tc: 'dot.png',
              day_unit_en: 'dot.png',
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 146,
              y: 320,
              week_en: ["week_1.png","week_2.png","week_3.png","week_4.png","week_5.png","week_6.png","week_7.png"],
              week_tc: ["week_1.png","week_2.png","week_3.png","week_4.png","week_5.png","week_6.png","week_7.png"],
              week_sc: ["week_1.png","week_2.png","week_3.png","week_4.png","week_5.png","week_6.png","week_7.png"],
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 110,
              hour_startY: 189,
              hour_array: ["time_0.png","time_1.png","time_2.png","time_3.png","time_4.png","time_5.png","time_6.png","time_7.png","time_8.png","time_9.png"],
              hour_zero: 1,
              hour_space: 0,
              hour_angle: 0,
              hour_unit_sc: 'colon.png',
              hour_unit_tc: 'colon.png',
              hour_unit_en: 'colon.png',
              hour_align: hmUI.align.LEFT,

              minute_startX: 250,
              minute_startY: 189,
              minute_array: ["time_0.png","time_1.png","time_2.png","time_3.png","time_4.png","time_5.png","time_6.png","time_7.png","time_8.png","time_9.png"],
              minute_zero: 1,
              minute_space: 0,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_AOD,
            });
            console.log('Watch_Face.Shortcuts');

            normal_step_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 194,
              y: 388,
              w: 78,
              h: 39,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_cal_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 286,
              y: 388,
              w: 78,
              h: 39,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 97,
              y: 388,
              w: 78,
              h: 39,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 374,
              y: 283,
              w: 68,
              h: 34,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 6,
              y: 214,
              w: 49,
              h: 49,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_altimeter_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 134,
              y: 323,
              w: 73,
              h: 39,
              type: hmUI.data_type.ALTIMETER,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_countdown_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 228,
              y: 194,
              w: 68,
              h: 83,
              type: hmUI.data_type.COUNT_DOWN,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_stopwatch_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 328,
              y: 218,
              w: 68,
              h: 58,
              type: hmUI.data_type.STOP_WATCH,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_alarm_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 92,
              y: 194,
              w: 68,
              h: 83,
              type: hmUI.data_type.ALARM_CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_altitude_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 43,
              y: 323,
              w: 73,
              h: 39,
              type: hmUI.data_type.ALTITUDE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
			
			const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
			   console.log('resume_call()');
                autoToggleBg();
              }),
            });


                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}