﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        const logger = Logger.getLogger('watchface_SashaCX75');
        //end of ignored block

        //dynamic modify start

        
        let normal_background_bg_img = ''
		let alarm_clock_img = ''
        let normal_date_img_date_month = ''
        let normal_date_img_date_day = ''
        let normal_date_img_date_week_img = ''
        let normal_battery_text_text_img = ''
        let normal_battery_image_progress_img_level = ''
        let normal_system_disconnect_img = ''
        let normal_system_clock_img = ''
        let normal_temperature_current_text_img = ''
        let normal_weather_image_progress_img_level = ''
        let normal_distance_text_text_img = ''
        let normal_calorie_current_text_img = ''
        let normal_heart_rate_text_text_img = ''
        let normal_step_current_text_img = ''
        let normal_digital_clock_img_time = ''
        let idle_background_bg = ''
        let idle_date_img_date_month = ''
        let idle_date_img_date_day = ''
        let idle_date_img_date_week_img = ''
        let idle_battery_text_text_img = ''
        let idle_battery_image_progress_img_level = ''
        let idle_system_disconnect_img = ''
        let idle_digital_clock_img_time = ''
        let normal_alarm_jumpable_img_click = ''
        let normal_temperature_jumpable_img_click = ''
        let normal_heart_jumpable_img_click = ''
        let normal_step_jumpable_img_click = ''
		
		let heart = hmSensor.createSensor(hmSensor.id.HEART);
        let heartArr = ''

        function HeartUpdate() {
          heartArr = heart.today
          min_heart_txt.setProperty(hmUI.prop.TEXT, Math.min(...heartArr).toString())
          max_heart_txt.setProperty(hmUI.prop.TEXT, Math.max(...heartArr).toString())
        }

        heart.addEventListener(hmSensor.event.CHANGE, function () {
          HeartUpdate()
        })


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 466,
              h: 466,
              src: 'bg.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_month = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 247,
              month_startY: 195,
              month_sc_array: ["long_type_time_num_0.png","long_type_time_num_1.png","long_type_time_num_2.png","long_type_time_num_3.png","long_type_time_num_4.png","long_type_time_num_5.png","long_type_time_num_6.png","long_type_time_num_7.png","long_type_time_num_8.png","long_type_time_num_9.png"],
              month_tc_array: ["long_type_time_num_0.png","long_type_time_num_1.png","long_type_time_num_2.png","long_type_time_num_3.png","long_type_time_num_4.png","long_type_time_num_5.png","long_type_time_num_6.png","long_type_time_num_7.png","long_type_time_num_8.png","long_type_time_num_9.png"],
              month_en_array: ["long_type_time_num_0.png","long_type_time_num_1.png","long_type_time_num_2.png","long_type_time_num_3.png","long_type_time_num_4.png","long_type_time_num_5.png","long_type_time_num_6.png","long_type_time_num_7.png","long_type_time_num_8.png","long_type_time_num_9.png"],
              month_zero: 1,
              month_space: 0,
              month_align: hmUI.align.CENTER_H,
              month_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 202,
              day_startY: 195,
              day_sc_array: ["long_type_time_num_0.png","long_type_time_num_1.png","long_type_time_num_2.png","long_type_time_num_3.png","long_type_time_num_4.png","long_type_time_num_5.png","long_type_time_num_6.png","long_type_time_num_7.png","long_type_time_num_8.png","long_type_time_num_9.png"],
              day_tc_array: ["long_type_time_num_0.png","long_type_time_num_1.png","long_type_time_num_2.png","long_type_time_num_3.png","long_type_time_num_4.png","long_type_time_num_5.png","long_type_time_num_6.png","long_type_time_num_7.png","long_type_time_num_8.png","long_type_time_num_9.png"],
              day_en_array: ["long_type_time_num_0.png","long_type_time_num_1.png","long_type_time_num_2.png","long_type_time_num_3.png","long_type_time_num_4.png","long_type_time_num_5.png","long_type_time_num_6.png","long_type_time_num_7.png","long_type_time_num_8.png","long_type_time_num_9.png"],
              day_zero: 1,
              day_space: 0,
              day_unit_sc: 'dot.png',
              day_unit_tc: 'dot.png',
              day_unit_en: 'dot.png',
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 182,
              y: 155,
              week_en: ["ds_1.png","ds_2.png","ds_3.png","ds_4.png","ds_5.png","ds_6.png","ds_7.png"],
              week_tc: ["ds_1.png","ds_2.png","ds_3.png","ds_4.png","ds_5.png","ds_6.png","ds_7.png"],
              week_sc: ["ds_1.png","ds_2.png","ds_3.png","ds_4.png","ds_5.png","ds_6.png","ds_7.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 214,
              y: 32,
              font_array: ["font_0.png","font_1.png","font_2.png","font_3.png","font_4.png","font_5.png","font_6.png","font_7.png","font_8.png","font_9.png"],
              padding: false,
              h_space: 0,
              unit_sc: '%.png',
              unit_tc: '%.png',
              unit_en: '%.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 215,
              y: 5,
              image_array: ["p_1.png","p_2.png","p_3.png","p_4.png","p_5.png","p_6.png","p_7.png","p_8.png","p_9.png","p_10.png","p_11.png"],
              image_length: 11,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 223,
              y: 431,
              src: 'BT3.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 220,
              y: 246,
              src: 'alarm.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
			
			alarm_clock_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 220,
              y: 250,
              font_array: ["font_0.png","font_1.png","font_2.png","font_3.png","font_4.png","font_5.png","font_6.png","font_7.png","font_8.png","font_9.png"],
              padding: true,
              h_space: 0,
              dot_image: 'dots.png',
			  invalid_image: 's_minus.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.ALARM_CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 128,
              y: 375,
              font_array: ["long_type_time_num_0.png","long_type_time_num_1.png","long_type_time_num_2.png","long_type_time_num_3.png","long_type_time_num_4.png","long_type_time_num_5.png","long_type_time_num_6.png","long_type_time_num_7.png","long_type_time_num_8.png","long_type_time_num_9.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'gradus.png',
              unit_tc: 'gradus.png',
              unit_en: 'gradus.png',
              negative_image: 'minus.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 117,
              y: 300,
              image_array: ["w_1.png","w_2.png","w_3.png","w_4.png","w_5.png","w_6.png","w_7.png","w_8.png","w_9.png","w_10.png","w_11.png","w_12.png","w_13.png","w_14.png","w_15.png","w_16.png","w_17.png","w_18.png","w_19.png","w_20.png","w_21.png","w_22.png","w_23.png","w_24.png","w_25.png","w_26.png","w_27.png","w_28.png","w_29.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_distance_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 74,
              y: 233,
              font_array: ["long_type_time_num_0.png","long_type_time_num_1.png","long_type_time_num_2.png","long_type_time_num_3.png","long_type_time_num_4.png","long_type_time_num_5.png","long_type_time_num_6.png","long_type_time_num_7.png","long_type_time_num_8.png","long_type_time_num_9.png"],
              padding: false,
              h_space: 0,
              dot_image: 'dot.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.DISTANCE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_calorie_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 77,
              y: 159,
              font_array: ["long_type_time_num_0.png","long_type_time_num_1.png","long_type_time_num_2.png","long_type_time_num_3.png","long_type_time_num_4.png","long_type_time_num_5.png","long_type_time_num_6.png","long_type_time_num_7.png","long_type_time_num_8.png","long_type_time_num_9.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 341,
              y: 195,
              font_array: ["long_type_time_num_0.png","long_type_time_num_1.png","long_type_time_num_2.png","long_type_time_num_3.png","long_type_time_num_4.png","long_type_time_num_5.png","long_type_time_num_6.png","long_type_time_num_7.png","long_type_time_num_8.png","long_type_time_num_9.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
			
			min_heart_txt = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 353,
              y: 255,
              w: 50,
              h: 50,
              text_size: 20,
              text: '',
              color: 0xffffff,
              align_h: hmUI.align.RIGHT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            max_heart_txt = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 328,
              y: 255,
              w: 50,
              h: 50,
              text_size: 20,
              text: '',
              color: 0xffffff,
              align_h: hmUI.align.CENTR,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 278,
              y: 308,
              font_array: ["long_type_time_num_0.png","long_type_time_num_1.png","long_type_time_num_2.png","long_type_time_num_3.png","long_type_time_num_4.png","long_type_time_num_5.png","long_type_time_num_6.png","long_type_time_num_7.png","long_type_time_num_8.png","long_type_time_num_9.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 86,
              hour_startY: 60,
              hour_array: ["0001.png","0002.png","0003.png","0004.png","0005.png","0006.png","0007.png","0008.png","0009.png","0010.png"],
              hour_zero: 1,
              hour_space: -2,
              hour_angle: 0,
              hour_unit_sc: '0090.png',
              hour_unit_tc: '0090.png',
              hour_unit_en: '0090.png',
              hour_align: hmUI.align.LEFT,

              minute_startX: 191,
              minute_startY: 60,
              minute_array: ["0001.png","0002.png","0003.png","0004.png","0005.png","0006.png","0007.png","0008.png","0009.png","0010.png"],
              minute_zero: 1,
              minute_space: -2,
              minute_angle: 0,
              minute_follow: 0,
              minute_unit_sc: '0090.png',
              minute_unit_tc: '0090.png',
              minute_unit_en: '0090.png',
              minute_align: hmUI.align.LEFT,

              second_startX: 295,
              second_startY: 60,
              second_array: ["0001.png","0002.png","0003.png","0004.png","0005.png","0006.png","0007.png","0008.png","0009.png","0010.png"],
              second_zero: 1,
              second_space: -2,
              second_angle: 0,
              second_follow: 0,
              second_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            idle_background_bg = hmUI.createWidget(hmUI.widget.FILL_RECT, {
              x: 0,
              y: 0,
              w: 466,
              h: 466,
              color: '0xFF000000',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_month = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 242,
              month_startY: 100,
              month_sc_array: ["long_type_time_num_0.png","long_type_time_num_1.png","long_type_time_num_2.png","long_type_time_num_3.png","long_type_time_num_4.png","long_type_time_num_5.png","long_type_time_num_6.png","long_type_time_num_7.png","long_type_time_num_8.png","long_type_time_num_9.png"],
              month_tc_array: ["long_type_time_num_0.png","long_type_time_num_1.png","long_type_time_num_2.png","long_type_time_num_3.png","long_type_time_num_4.png","long_type_time_num_5.png","long_type_time_num_6.png","long_type_time_num_7.png","long_type_time_num_8.png","long_type_time_num_9.png"],
              month_en_array: ["long_type_time_num_0.png","long_type_time_num_1.png","long_type_time_num_2.png","long_type_time_num_3.png","long_type_time_num_4.png","long_type_time_num_5.png","long_type_time_num_6.png","long_type_time_num_7.png","long_type_time_num_8.png","long_type_time_num_9.png"],
              month_zero: 1,
              month_space: 0,
              month_align: hmUI.align.CENTER_H,
              month_is_character: false,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 197,
              day_startY: 100,
              day_sc_array: ["long_type_time_num_0.png","long_type_time_num_1.png","long_type_time_num_2.png","long_type_time_num_3.png","long_type_time_num_4.png","long_type_time_num_5.png","long_type_time_num_6.png","long_type_time_num_7.png","long_type_time_num_8.png","long_type_time_num_9.png"],
              day_tc_array: ["long_type_time_num_0.png","long_type_time_num_1.png","long_type_time_num_2.png","long_type_time_num_3.png","long_type_time_num_4.png","long_type_time_num_5.png","long_type_time_num_6.png","long_type_time_num_7.png","long_type_time_num_8.png","long_type_time_num_9.png"],
              day_en_array: ["long_type_time_num_0.png","long_type_time_num_1.png","long_type_time_num_2.png","long_type_time_num_3.png","long_type_time_num_4.png","long_type_time_num_5.png","long_type_time_num_6.png","long_type_time_num_7.png","long_type_time_num_8.png","long_type_time_num_9.png"],
              day_zero: 1,
              day_space: 0,
              day_unit_sc: 'dot.png',
              day_unit_tc: 'dot.png',
              day_unit_en: 'dot.png',
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 180,
              y: 70,
              week_en: ["ds_1.png","ds_2.png","ds_3.png","ds_4.png","ds_5.png","ds_6.png","ds_7.png"],
              week_tc: ["ds_1.png","ds_2.png","ds_3.png","ds_4.png","ds_5.png","ds_6.png","ds_7.png"],
              week_sc: ["ds_1.png","ds_2.png","ds_3.png","ds_4.png","ds_5.png","ds_6.png","ds_7.png"],
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 214,
              y: 427,
              font_array: ["font_0.png","font_1.png","font_2.png","font_3.png","font_4.png","font_5.png","font_6.png","font_7.png","font_8.png","font_9.png"],
              padding: false,
              h_space: 0,
              unit_sc: '%.png',
              unit_tc: '%.png',
              unit_en: '%.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_battery_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 215,
              y: 400,
              image_array: ["p_1.png","p_2.png","p_3.png","p_4.png","p_5.png","p_6.png","p_7.png","p_8.png","p_9.png","p_10.png","p_11.png"],
              image_length: 11,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 218,
              y: 166,
              src: 'BT3.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 86,
              hour_startY: 210,
              hour_array: ["0001.png","0002.png","0003.png","0004.png","0005.png","0006.png","0007.png","0008.png","0009.png","0010.png"],
              hour_zero: 1,
              hour_space: -2,
              hour_angle: 0,
              hour_unit_sc: '0090.png',
              hour_unit_tc: '0090.png',
              hour_unit_en: '0090.png',
              hour_align: hmUI.align.LEFT,

              minute_startX: 191,
              minute_startY: 210,
              minute_array: ["0001.png","0002.png","0003.png","0004.png","0005.png","0006.png","0007.png","0008.png","0009.png","0010.png"],
              minute_zero: 1,
              minute_space: -2,
              minute_angle: 0,
              minute_follow: 0,
              minute_unit_sc: '0090.png',
              minute_unit_tc: '0090.png',
              minute_unit_en: '0090.png',
              minute_align: hmUI.align.LEFT,

              second_startX: 295,
              second_startY: 210,
              second_array: ["0001.png","0002.png","0003.png","0004.png","0005.png","0006.png","0007.png","0008.png","0009.png","0010.png"],
              second_zero: 1,
              second_space: -2,
              second_angle: 0,
              second_follow: 0,
              second_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_AOD,
            });
            
            // disconnectAlert = hmUI.createWidget(hmUI.widget.DisconnectAlert, {
              // disconneсnt_vibrate_type: 9,
              // disconneсnt_toast_text: Signal LOST,
              // conneсnt_vibrate_type: 0,
              // conneсnt_toast_text: Signal FIND,
            // });

            // vibration when connecting or disconnecting

            function checkConnection() {
              hmBle.removeListener;
              hmBle.addListener(function (status) {
                if(!status) {
                  hmUI.showToast({text: "Signal LOST"});
                  vibro(9);
                }
                if(status) {
                  hmUI.showToast({text: "Signal FIND"});
                  vibro(0);
                }
              });
            }

            // end vibration when connecting or disconnecting
            // vibrate function

            const vibrate = hmSensor.createSensor(hmSensor.id.VIBRATE);
            let timer_StopVibrate = null;


            function vibro(scene = 25) {
              let stopDelay = 50;
              stopVibro();
              vibrate.stop();
              vibrate.scene = scene;
              if(scene < 23 || scene > 25) stopDelay = 1300;
              vibrate.start();
              timer_StopVibrate = timer.createTimer(stopDelay, 3000, stopVibro, {});
            }

            function stopVibro(){
              vibrate.stop();
              if(timer_StopVibrate) timer.stopTimer(timer_StopVibrate);
            }

            // end vibrate function

            normal_alarm_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 195,
              y: 245,
              w: 100,
              h: 40,
              src: 'Empty.png',
              type: hmUI.data_type.ALARM_CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 110,
              y: 310,
              w: 100,
              h: 100,
              src: 'Empty.png',
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 320,
              y: 165,
              w: 100,
              h: 100,
              src: 'Empty.png',
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 265,
              y: 300,
              w: 100,
              h: 55,
              src: 'Empty.png',
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
			
			hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 232,
              y: 370, 
              text: '',
              w: 64, 
              h: 45, 
              normal_src: 'Empty.png',
              press_src: 'Empty.png',
               click_func: () => {
              hmApp.startApp({ url: 'PhoneRecentCallScreen', native: true });
              },
               longpress_func: () => {
              hmApp.startApp({ url: 'PhoneContactsScreen', native: true });
              },
                show_level: hmUI.show_level.ONLY_NORMAL,
            });
			
			hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 305,
              y: 370, 
              text: '',
              w: 64, 
              h: 45, 
              normal_src: 'Empty.png',
              press_src: 'Empty.png',
               click_func: () => {
              hmApp.startApp({ url: 'Settings_homeScreen', native: true });
              },
               longpress_func: () => {
              hmApp.startApp({ url: 'HmReStartScreen', native: true });
              },
                show_level: hmUI.show_level.ONLY_NORMAL,
            });
			
			hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 200,
              y: 155, 
              text: '',
              w: 90, 
              h: 70, 
              normal_src: 'Empty.png',
              press_src: 'Empty.png',
               click_func: () => {
              hmApp.startApp({ url: 'ScheduleCalScreen', native: true });
              },
               longpress_func: () => {
              hmApp.startApp({ url: 'todoListScreen', native: true });
              },
                show_level: hmUI.show_level.ONLY_NORMAL,
            });

            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                HeartUpdate()
				checkConnection();
                stopVibro();

              }),
              pause_call: (function () {
                stopVibro();

              }),
            });

                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}