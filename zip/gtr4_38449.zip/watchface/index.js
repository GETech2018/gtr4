/*
 ** Watch_Face_Editor tool
 ** watchface js version v2.1.1
 ** Copyright © SashaCX75. All Rights Reserved
 */

try {
  (() => {
    //start of ignored block
    const __$$app$$__ = __$$hmAppManager$$__.currentApp;
    function getApp() {
      return __$$app$$__.app;
    }
    function getCurrentPage() {
      return __$$app$$__.current && __$$app$$__.current.module;
    }
    const __$$module$$__ = __$$app$$__.current;
    const h = new DeviceRuntimeCore.WidgetFactory(
      new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__)
    );
    const { px } = __$$app$$__.__globals__;
    const logger = Logger.getLogger("watchface_SashaCX75");
    //end of ignored block

    //dynamic modify start

    let normal_background_bg_img = "";
    let normal_moon_image_progress_img_level = "";
    let normal_date_img_date_month = "";
    let normal_date_month_separator_img = "";
    let normal_date_img_date_week_img = "";
    let normal_date_img_date_day = "";
    let normal_battery_linear_scale = "";
    let normal_battery_linear_scale_pointer_img = "";
    let normal_battery_text_text_img = "";
    let normal_step_target_text_img = "";
    let normal_step_current_text_img = "";
    let normal_step_image_progress_img_level = "";
    let normal_digital_clock_img_time_AmPm = "";
    let normal_digital_clock_img_time = "";
    let normal_digital_clock_minute_separator_img = "";
    let idle_background_bg_img = "";
    let idle_moon_image_progress_img_level = "";
    let idle_date_img_date_month = "";
    let idle_date_month_separator_img = "";
    let idle_date_img_date_week_img = "";
    let idle_date_img_date_day = "";
    let idle_battery_linear_scale = "";
    let idle_battery_linear_scale_pointer_img = "";
    let idle_battery_text_text_img = "";
    let idle_step_target_text_img = "";
    let idle_step_current_text_img = "";
    let idle_step_image_progress_img_level = "";
    let idle_digital_clock_img_time_AmPm = "";
    let idle_digital_clock_img_time = "";
    let idle_digital_clock_minute_separator_img = "";
    let normal_alarm_jumpable_img_click = "";
    let normal_step_jumpable_img_click = "";
    const step = hmSensor.createSensor(hmSensor.id.STEP);

    //---------------------------------------------------------------------------
    // смена картинки фона
    //---------------------------------------------------------------------------
    let btn_fon = "";
    let fon_num = 0;
    let fon_all = 5;

    function click_fon() {
      if (fon_num >= fon_all) {
        fon_num = 0;
      } else {
        fon_num = fon_num + 1;
      }
      hmUI.showToast({ text: "Фон " + parseInt(fon_num) });
      normal_background_bg_img.setProperty(
        hmUI.prop.SRC,
        "bg_" + parseInt(fon_num) + ".png"
      );
    }

    //dynamic modify end

    __$$module$$__.module = DeviceRuntimeCore.WatchFace({
      init_view() {
        //dynamic modify start

        normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
          x: 0,
          y: 0,
          w: 466,
          h: 466,
          src: "bg_0.png",
          show_level: hmUI.show_level.ONLY_NORMAL,
        });

        normal_moon_image_progress_img_level = hmUI.createWidget(
          hmUI.widget.IMG_LEVEL,
          {
            x: 59,
            y: 184,
            image_array: [
              "moon_0.png",
              "moon_1.png",
              "moon_2.png",
              "moon_3.png",
              "moon_4.png",
              "moon_5.png",
              "moon_6.png",
              "moon_7.png",
            ],
            image_length: 8,
            type: hmUI.data_type.MOON,
            show_level: hmUI.show_level.ONLY_NORMAL,
          }
        );

        normal_date_img_date_month = hmUI.createWidget(hmUI.widget.IMG_DATE, {
          month_startX: 282,
          month_startY: 67,
          month_sc_array: [
            "day_0.png",
            "day_1.png",
            "day_2.png",
            "day_3.png",
            "day_4.png",
            "day_5.png",
            "day_6.png",
            "day_7.png",
            "day_8.png",
            "day_9.png",
          ],
          month_tc_array: [
            "day_0.png",
            "day_1.png",
            "day_2.png",
            "day_3.png",
            "day_4.png",
            "day_5.png",
            "day_6.png",
            "day_7.png",
            "day_8.png",
            "day_9.png",
          ],
          month_en_array: [
            "day_0.png",
            "day_1.png",
            "day_2.png",
            "day_3.png",
            "day_4.png",
            "day_5.png",
            "day_6.png",
            "day_7.png",
            "day_8.png",
            "day_9.png",
          ],
          month_zero: 1,
          month_space: 0,
          month_align: hmUI.align.LEFT,
          month_is_character: false,
          show_level: hmUI.show_level.ONLY_NORMAL,
        });

        normal_date_month_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
          x: 267,
          y: 67,
          src: "day_10.png",
          show_level: hmUI.show_level.ONLY_NORMAL,
        });

        normal_date_img_date_week_img = hmUI.createWidget(
          hmUI.widget.IMG_WEEK,
          {
            x: 134,
            y: 67,
            week_en: [
              "week_0.png",
              "week_1.png",
              "week_2.png",
              "week_3.png",
              "week_4.png",
              "week_5.png",
              "week_6.png",
            ],
            week_tc: [
              "week_0.png",
              "week_1.png",
              "week_2.png",
              "week_3.png",
              "week_4.png",
              "week_5.png",
              "week_6.png",
            ],
            week_sc: [
              "week_0.png",
              "week_1.png",
              "week_2.png",
              "week_3.png",
              "week_4.png",
              "week_5.png",
              "week_6.png",
            ],
            show_level: hmUI.show_level.ONLY_NORMAL,
          }
        );

        normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
          day_startX: 220,
          day_startY: 67,
          day_sc_array: [
            "day_0.png",
            "day_1.png",
            "day_2.png",
            "day_3.png",
            "day_4.png",
            "day_5.png",
            "day_6.png",
            "day_7.png",
            "day_8.png",
            "day_9.png",
          ],
          day_tc_array: [
            "day_0.png",
            "day_1.png",
            "day_2.png",
            "day_3.png",
            "day_4.png",
            "day_5.png",
            "day_6.png",
            "day_7.png",
            "day_8.png",
            "day_9.png",
          ],
          day_en_array: [
            "day_0.png",
            "day_1.png",
            "day_2.png",
            "day_3.png",
            "day_4.png",
            "day_5.png",
            "day_6.png",
            "day_7.png",
            "day_8.png",
            "day_9.png",
          ],
          day_zero: 1,
          day_space: 0,
          day_align: hmUI.align.LEFT,
          day_is_character: false,
          show_level: hmUI.show_level.ONLY_NORMAL,
        });

        let screenType = hmSetting.getScreenType();
        if (screenType != hmSetting.screen_type.AOD) {
          normal_battery_linear_scale = hmUI.createWidget(
            hmUI.widget.FILL_RECT
          );
        }

        normal_battery_linear_scale_pointer_img = hmUI.createWidget(
          hmUI.widget.IMG
        );
        // normal_battery_linear_scale = hmUI.createWidget(hmUI.widget.Linear_Scale, {
        // start_x: 285,
        // start_y: 142,
        // color: 0xFF000000,
        // pointer: 'bat_0.png',
        // lenght: 80,
        // line_width: 10,
        // line_cap: Flat,
        // vertical: False,
        // mirror: False,
        // inversion: False,
        // type: hmUI.data_type.BATTERY,
        // show_level: hmUI.show_level.ONLY_NORMAL,
        // });

        const battery = hmSensor.createSensor(hmSensor.id.BATTERY);
        battery.addEventListener(hmSensor.event.CHANGE, function () {
          scale_call();
        });

        normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
          x: 281,
          y: 312,
          font_array: [
            "num_0.png",
            "num_1.png",
            "num_2.png",
            "num_3.png",
            "num_4.png",
            "num_5.png",
            "num_6.png",
            "num_7.png",
            "num_8.png",
            "num_9.png",
          ],
          padding: false,
          h_space: 0,
          align_h: hmUI.align.CENTER_H,
          type: hmUI.data_type.BATTERY,
          show_level: hmUI.show_level.ONLY_NORMAL,
        });

        normal_step_target_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
          x: 122,
          y: 312,
          font_array: [
            "num_0.png",
            "num_1.png",
            "num_2.png",
            "num_3.png",
            "num_4.png",
            "num_5.png",
            "num_6.png",
            "num_7.png",
            "num_8.png",
            "num_9.png",
          ],
          padding: false,
          h_space: 0,
          align_h: hmUI.align.LEFT,
          text: "",
          show_level: hmUI.show_level.ONLY_NORMAL,
        });

        normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
          x: 182,
          y: 364,
          font_array: [
            "num_0.png",
            "num_1.png",
            "num_2.png",
            "num_3.png",
            "num_4.png",
            "num_5.png",
            "num_6.png",
            "num_7.png",
            "num_8.png",
            "num_9.png",
          ],
          padding: false,
          h_space: 0,
          align_h: hmUI.align.CENTER_H,
          type: hmUI.data_type.STEP,
          show_level: hmUI.show_level.ONLY_NORMAL,
        });

        normal_step_image_progress_img_level = hmUI.createWidget(
          hmUI.widget.IMG_LEVEL,
          {
            x: 125,
            y: 128,
            image_array: [
              "health_0.png",
              "health_1.png",
              "health_2.png",
              "health_3.png",
              "health_4.png",
              "health_5.png",
              "health_6.png",
              "health_7.png",
              "health_8.png",
              "health_9.png",
              "health_10.png",
            ],
            image_length: 11,
            type: hmUI.data_type.STEP,
            show_level: hmUI.show_level.ONLY_NORMAL,
          }
        );

        normal_digital_clock_img_time_AmPm = hmUI.createWidget(
          hmUI.widget.IMG_TIME,
          {
            am_x: 365,
            am_y: 210,
            am_sc_path: "am_0.png",
            am_en_path: "am_0.png",
            pm_x: 365,
            pm_y: 210,
            pm_sc_path: "pm_0.png",
            pm_en_path: "pm_0.png",
            show_level: hmUI.show_level.ONLY_NORMAL,
          }
        );

        normal_digital_clock_img_time = hmUI.createWidget(
          hmUI.widget.IMG_TIME,
          {
            hour_startX: 96,
            hour_startY: 176,
            hour_array: [
              "big_num_0.png",
              "big_num_1.png",
              "big_num_2.png",
              "big_num_3.png",
              "big_num_4.png",
              "big_num_5.png",
              "big_num_6.png",
              "big_num_7.png",
              "big_num_8.png",
              "big_num_9.png",
            ],
            hour_zero: 1,
            hour_space: 0,
            hour_angle: 0,
            hour_align: hmUI.align.RIGHT,

            minute_startX: 244,
            minute_startY: 176,
            minute_array: [
              "big_num_0.png",
              "big_num_1.png",
              "big_num_2.png",
              "big_num_3.png",
              "big_num_4.png",
              "big_num_5.png",
              "big_num_6.png",
              "big_num_7.png",
              "big_num_8.png",
              "big_num_9.png",
            ],
            minute_zero: 1,
            minute_space: 0,
            minute_angle: 0,
            minute_follow: 0,
            minute_align: hmUI.align.LEFT,

            second_startX: 364,
            second_startY: 252,
            second_array: [
              "sec_0.png",
              "sec_1.png",
              "sec_2.png",
              "sec_3.png",
              "sec_4.png",
              "sec_5.png",
              "sec_6.png",
              "sec_7.png",
              "sec_8.png",
              "sec_9.png",
            ],
            second_zero: 1,
            second_space: 0,
            second_angle: 0,
            second_follow: 0,
            second_align: hmUI.align.LEFT,

            show_level: hmUI.show_level.ONLY_NORMAL,
          }
        );

        normal_digital_clock_minute_separator_img = hmUI.createWidget(
          hmUI.widget.IMG,
          {
            x: 221,
            y: 176,
            src: "big_num_10.png",
            show_level: hmUI.show_level.ONLY_NORMAL,
          }
        );

        idle_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
          x: 0,
          y: 0,
          w: 466,
          h: 466,
          src: "bg_aod.png",
          show_level: hmUI.show_level.ONLY_AOD,
        });

        idle_moon_image_progress_img_level = hmUI.createWidget(
          hmUI.widget.IMG_LEVEL,
          {
            x: 59,
            y: 184,
            image_array: [
              "moon_aod_0.png",
              "moon_aod_1.png",
              "moon_aod_2.png",
              "moon_aod_3.png",
              "moon_aod_4.png",
              "moon_aod_5.png",
              "moon_aod_6.png",
              "moon_aod_7.png",
            ],
            image_length: 8,
            type: hmUI.data_type.MOON,
            show_level: hmUI.show_level.ONLY_AOD,
          }
        );

        idle_date_img_date_month = hmUI.createWidget(hmUI.widget.IMG_DATE, {
          month_startX: 282,
          month_startY: 67,
          month_sc_array: [
            "day_aod_0.png",
            "day_aod_1.png",
            "day_aod_2.png",
            "day_aod_3.png",
            "day_aod_4.png",
            "day_aod_5.png",
            "day_aod_6.png",
            "day_aod_7.png",
            "day_aod_8.png",
            "day_aod_9.png",
          ],
          month_tc_array: [
            "day_aod_0.png",
            "day_aod_1.png",
            "day_aod_2.png",
            "day_aod_3.png",
            "day_aod_4.png",
            "day_aod_5.png",
            "day_aod_6.png",
            "day_aod_7.png",
            "day_aod_8.png",
            "day_aod_9.png",
          ],
          month_en_array: [
            "day_aod_0.png",
            "day_aod_1.png",
            "day_aod_2.png",
            "day_aod_3.png",
            "day_aod_4.png",
            "day_aod_5.png",
            "day_aod_6.png",
            "day_aod_7.png",
            "day_aod_8.png",
            "day_aod_9.png",
          ],
          month_zero: 1,
          month_space: 0,
          month_align: hmUI.align.LEFT,
          month_is_character: false,
          show_level: hmUI.show_level.ONLY_AOD,
        });

        idle_date_month_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
          x: 267,
          y: 67,
          src: "day_aod_10.png",
          show_level: hmUI.show_level.ONLY_AOD,
        });

        idle_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
          x: 134,
          y: 67,
          week_en: [
            "week_aod_0.png",
            "week_aod_1.png",
            "week_aod_2.png",
            "week_aod_3.png",
            "week_aod_4.png",
            "week_aod_5.png",
            "week_aod_6.png",
          ],
          week_tc: [
            "week_aod_0.png",
            "week_aod_1.png",
            "week_aod_2.png",
            "week_aod_3.png",
            "week_aod_4.png",
            "week_aod_5.png",
            "week_aod_6.png",
          ],
          week_sc: [
            "week_aod_0.png",
            "week_aod_1.png",
            "week_aod_2.png",
            "week_aod_3.png",
            "week_aod_4.png",
            "week_aod_5.png",
            "week_aod_6.png",
          ],
          show_level: hmUI.show_level.ONLY_AOD,
        });

        idle_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
          day_startX: 220,
          day_startY: 67,
          day_sc_array: [
            "day_aod_0.png",
            "day_aod_1.png",
            "day_aod_2.png",
            "day_aod_3.png",
            "day_aod_4.png",
            "day_aod_5.png",
            "day_aod_6.png",
            "day_aod_7.png",
            "day_aod_8.png",
            "day_aod_9.png",
          ],
          day_tc_array: [
            "day_aod_0.png",
            "day_aod_1.png",
            "day_aod_2.png",
            "day_aod_3.png",
            "day_aod_4.png",
            "day_aod_5.png",
            "day_aod_6.png",
            "day_aod_7.png",
            "day_aod_8.png",
            "day_aod_9.png",
          ],
          day_en_array: [
            "day_aod_0.png",
            "day_aod_1.png",
            "day_aod_2.png",
            "day_aod_3.png",
            "day_aod_4.png",
            "day_aod_5.png",
            "day_aod_6.png",
            "day_aod_7.png",
            "day_aod_8.png",
            "day_aod_9.png",
          ],
          day_zero: 1,
          day_space: 0,
          day_align: hmUI.align.LEFT,
          day_is_character: false,
          show_level: hmUI.show_level.ONLY_AOD,
        });

        if (screenType == hmSetting.screen_type.AOD) {
          idle_battery_linear_scale = hmUI.createWidget(hmUI.widget.FILL_RECT);
        }

        idle_battery_linear_scale_pointer_img = hmUI.createWidget(
          hmUI.widget.IMG
        );
        // idle_battery_linear_scale = hmUI.createWidget(hmUI.widget.Linear_Scale, {
        // start_x: 285,
        // start_y: 142,
        // color: 0xFFFFFFFF,
        // pointer: 'bat_0.png',
        // lenght: 80,
        // line_width: 10,
        // line_cap: Flat,
        // vertical: False,
        // mirror: False,
        // inversion: False,
        // type: hmUI.data_type.BATTERY,
        // show_level: hmUI.show_level.ONLY_AOD,
        // });

        idle_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
          x: 281,
          y: 312,
          font_array: [
            "num_aod_0.png",
            "num_aod_1.png",
            "num_aod_2.png",
            "num_aod_3.png",
            "num_aod_4.png",
            "num_aod_5.png",
            "num_aod_6.png",
            "num_aod_7.png",
            "num_aod_8.png",
            "num_aod_9.png",
          ],
          padding: false,
          h_space: 0,
          align_h: hmUI.align.CENTER_H,
          type: hmUI.data_type.BATTERY,
          show_level: hmUI.show_level.ONLY_AOD,
        });

        idle_step_target_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
          x: 123,
          y: 312,
          font_array: [
            "num_aod_0.png",
            "num_aod_1.png",
            "num_aod_2.png",
            "num_aod_3.png",
            "num_aod_4.png",
            "num_aod_5.png",
            "num_aod_6.png",
            "num_aod_7.png",
            "num_aod_8.png",
            "num_aod_9.png",
          ],
          padding: false,
          h_space: 0,
          align_h: hmUI.align.LEFT,
          text: "",
          show_level: hmUI.show_level.ONLY_AOD,
        });

        idle_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
          x: 182,
          y: 364,
          font_array: [
            "num_aod_0.png",
            "num_aod_1.png",
            "num_aod_2.png",
            "num_aod_3.png",
            "num_aod_4.png",
            "num_aod_5.png",
            "num_aod_6.png",
            "num_aod_7.png",
            "num_aod_8.png",
            "num_aod_9.png",
          ],
          padding: false,
          h_space: 0,
          align_h: hmUI.align.CENTER_H,
          type: hmUI.data_type.STEP,
          show_level: hmUI.show_level.ONLY_AOD,
        });

        idle_step_image_progress_img_level = hmUI.createWidget(
          hmUI.widget.IMG_LEVEL,
          {
            x: 125,
            y: 128,
            image_array: [
              "health_aod_0.png",
              "health_aod_1.png",
              "health_aod_2.png",
              "health_aod_3.png",
              "health_aod_4.png",
              "health_aod_5.png",
              "health_aod_6.png",
              "health_aod_7.png",
              "health_aod_8.png",
              "health_aod_9.png",
              "health_aod_10.png",
            ],
            image_length: 11,
            type: hmUI.data_type.STEP,
            show_level: hmUI.show_level.ONLY_AOD,
          }
        );

        idle_digital_clock_img_time_AmPm = hmUI.createWidget(
          hmUI.widget.IMG_TIME,
          {
            am_x: 365,
            am_y: 210,
            am_sc_path: "am_aod_0.png",
            am_en_path: "am_aod_0.png",
            pm_x: 365,
            pm_y: 210,
            pm_sc_path: "pm_aod_0.png",
            pm_en_path: "pm_aod_0.png",
            show_level: hmUI.show_level.ONLY_AOD,
          }
        );

        idle_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
          hour_startX: 96,
          hour_startY: 176,
          hour_array: [
            "big_num_aod_0.png",
            "big_num_aod_1.png",
            "big_num_aod_2.png",
            "big_num_aod_3.png",
            "big_num_aod_4.png",
            "big_num_aod_5.png",
            "big_num_aod_6.png",
            "big_num_aod_7.png",
            "big_num_aod_8.png",
            "big_num_aod_9.png",
          ],
          hour_zero: 1,
          hour_space: 0,
          hour_angle: 0,
          hour_align: hmUI.align.RIGHT,

          minute_startX: 244,
          minute_startY: 176,
          minute_array: [
            "big_num_aod_0.png",
            "big_num_aod_1.png",
            "big_num_aod_2.png",
            "big_num_aod_3.png",
            "big_num_aod_4.png",
            "big_num_aod_5.png",
            "big_num_aod_6.png",
            "big_num_aod_7.png",
            "big_num_aod_8.png",
            "big_num_aod_9.png",
          ],
          minute_zero: 1,
          minute_space: 0,
          minute_angle: 0,
          minute_follow: 0,
          minute_align: hmUI.align.LEFT,

          show_level: hmUI.show_level.ONLY_AOD,
        });

        idle_digital_clock_minute_separator_img = hmUI.createWidget(
          hmUI.widget.IMG,
          {
            x: 221,
            y: 176,
            src: "big_num_aod_10.png",
            show_level: hmUI.show_level.ONLY_AOD,
          }
        );

        image_top_img = hmUI.createWidget(hmUI.widget.IMG, {
          x: 0,
          y: 0,
          src: "wfs_top.png",
          show_level: hmUI.show_level.ONLY_NORMAL,
        });

        normal_alarm_jumpable_img_click = hmUI.createWidget(
          hmUI.widget.IMG_CLICK,
          {
            x: 183,
            y: 10,
            w: 100,
            h: 100,
            src: "wfs_clear.png",
            type: hmUI.data_type.ALARM_CLOCK,
            show_level: hmUI.show_level.ONLY_NORMAL,
          }
        );

        normal_step_jumpable_img_click = hmUI.createWidget(
          hmUI.widget.IMG_CLICK,
          {
            x: 183,
            y: 357,
            w: 100,
            h: 100,
            src: "wfs_clear.png",
            type: hmUI.data_type.STEP,
            show_level: hmUI.show_level.ONLY_NORMAL,
          }
        );

        function scale_call() {
          console.log("update scales BATTERY");

          let valueBattery = battery.current;
          let targetBattery = 100;
          let progressBattery = valueBattery / targetBattery;
          if (progressBattery > 1) progressBattery = 1;
          let progress_ls_normal_battery = progressBattery;

          if (screenType != hmSetting.screen_type.AOD) {
            // normal_battery_linear_scale
            // initial parameters
            let start_x_normal_battery = 285;
            let start_y_normal_battery = 142;
            let lenght_ls_normal_battery = 80;
            let line_width_ls_normal_battery = 10;
            let color_ls_normal_battery = 0xff000000;

            // calculated parameters
            let start_x_normal_battery_draw = start_x_normal_battery;
            let start_y_normal_battery_draw = start_y_normal_battery;
            lenght_ls_normal_battery =
              lenght_ls_normal_battery * progress_ls_normal_battery;
            let lenght_ls_normal_battery_draw = lenght_ls_normal_battery;
            let line_width_ls_normal_battery_draw =
              line_width_ls_normal_battery;
            if (lenght_ls_normal_battery < 0) {
              lenght_ls_normal_battery_draw = -lenght_ls_normal_battery;
              start_x_normal_battery_draw =
                start_x_normal_battery - lenght_ls_normal_battery_draw;
            }

            normal_battery_linear_scale.setProperty(hmUI.prop.MORE, {
              x: start_x_normal_battery_draw,
              y: start_y_normal_battery_draw,
              w: lenght_ls_normal_battery_draw,
              h: line_width_ls_normal_battery_draw,
              color: color_ls_normal_battery,
            });

            // pointers parameters
            let pointer_offset_x_ls_normal_battery = 1;
            let pointer_offset_y_ls_normal_battery = 5;
            normal_battery_linear_scale_pointer_img.setProperty(
              hmUI.prop.MORE,
              {
                x:
                  start_x_normal_battery +
                  lenght_ls_normal_battery -
                  pointer_offset_x_ls_normal_battery,
                y:
                  start_y_normal_battery_draw +
                  line_width_ls_normal_battery / 2 -
                  pointer_offset_y_ls_normal_battery,
                src: "bat_0.png",
                show_level: hmUI.show_level.ONLY_NORMAL,
              }
            );
          }

          console.log("update scales BATTERY");
          let progress_ls_idle_battery = progressBattery;

          if (screenType == hmSetting.screen_type.AOD) {
            // idle_battery_linear_scale
            // initial parameters
            let start_x_idle_battery = 285;
            let start_y_idle_battery = 142;
            let lenght_ls_idle_battery = 80;
            let line_width_ls_idle_battery = 10;
            let color_ls_idle_battery = 0xffffffff;

            // calculated parameters
            let start_x_idle_battery_draw = start_x_idle_battery;
            let start_y_idle_battery_draw = start_y_idle_battery;
            lenght_ls_idle_battery =
              lenght_ls_idle_battery * progress_ls_idle_battery;
            let lenght_ls_idle_battery_draw = lenght_ls_idle_battery;
            let line_width_ls_idle_battery_draw = line_width_ls_idle_battery;
            if (lenght_ls_idle_battery < 0) {
              lenght_ls_idle_battery_draw = -lenght_ls_idle_battery;
              start_x_idle_battery_draw =
                start_x_idle_battery - lenght_ls_idle_battery_draw;
            }

            idle_battery_linear_scale.setProperty(hmUI.prop.MORE, {
              x: start_x_idle_battery_draw,
              y: start_y_idle_battery_draw,
              w: lenght_ls_idle_battery_draw,
              h: line_width_ls_idle_battery_draw,
              color: color_ls_idle_battery,
            });

            // pointers parameters
            let pointer_offset_x_ls_idle_battery = 1;
            let pointer_offset_y_ls_idle_battery = 5;
            idle_battery_linear_scale_pointer_img.setProperty(hmUI.prop.MORE, {
              x:
                start_x_idle_battery +
                lenght_ls_idle_battery -
                pointer_offset_x_ls_idle_battery,
              y:
                start_y_idle_battery_draw +
                line_width_ls_idle_battery / 2 -
                pointer_offset_y_ls_idle_battery,
              src: "bat_0.png",
              show_level: hmUI.show_level.ONLY_AOD,
            });
          }
        }
        //---------------------------------------------------------------------------
        // процент от пройденного
        //---------------------------------------------------------------------------

        function target_percent() {
          let tp = Math.round((step.current / step.target) * 100);
          normal_step_target_text_img.setProperty(hmUI.prop.MORE, {
            x: 120,
            y: 312,
            font_array: [
              "num_0.png",
              "num_1.png",
              "num_2.png",
              "num_3.png",
              "num_4.png",
              "num_5.png",
              "num_6.png",
              "num_7.png",
              "num_8.png",
              "num_9.png",
            ],
            padding: false,
            h_space: 0,
            align_h: hmUI.align.LEFT,
            text: String(tp),
            show_level: hmUI.show_level.ONLY_NORMAL,
          });
        }

        function target_percent_aod() {
          let tp_aod = Math.round((step.current / step.target) * 100);
          idle_step_target_text_img.setProperty(hmUI.prop.MORE, {
            x: 120,
            y: 312,
            font_array: [
              "num_aod_0.png",
              "num_aod_1.png",
              "num_aod_2.png",
              "num_aod_3.png",
              "num_aod_4.png",
              "num_aod_5.png",
              "num_aod_6.png",
              "num_aod_7.png",
              "num_aod_8.png",
              "num_aod_9.png",
            ],
            padding: false,
            h_space: 0,
            align_h: hmUI.align.LEFT,
            text: String(tp_aod),
            show_level: hmUI.show_level.ONAL_AOD,
          });
        }

        //------------------------------------------------------------------------
        const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
          resume_call: function () {
            scale_call();
            if (screenType == hmSetting.screen_type.AOD) {
              target_percent_aod();
            } else {
              target_percent();
            }
          },
          pause_call: function () {},
        });

        //------------------------------------------------------------------------
        btn_fon = hmUI.createWidget(hmUI.widget.BUTTON, {
          x: 183,
          y: 183,
          text: "",
          w: 100,
          h: 100,
          normal_src: "wfs_clear.png",
          press_src: "wfs_clear.png",
          click_func: () => {
            click_fon();
            vibro(1);
          },
          show_level: hmUI.show_level.ONLY_NORMAL,
        });
        btn_fon.setProperty(hmUI.prop.VISIBLE, true);

        //dynamic modify end
      },
      onInit() {
        logger.log("index page.js on init invoke");
      },
      build() {
        this.init_view();
        logger.log("index page.js on ready invoke");
      },
      onDestroy() {
        logger.log("index page.js on destroy invoke");
      },
    });
  })();
} catch (e) {
  console.log("Mini Program Error", e);
  e &&
    e.stack &&
    e.stack.split(/\n/).forEach((i) => console.log("error stack", i));
}
