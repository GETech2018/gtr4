﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        //const logger = Logger.getLogger('watchface_SashaCX75');
        const logger = DeviceRuntimeCore.HmLogger.getLogger('watchface_SashaCX75')
        //end of ignored block

        //dynamic modify start

        
        console.log('user_functions.js');
        // start user_functions.js

const {
 width: D_W,
 height: D_H
} = hmSetting.getDeviceInfo();

const packageInfo = hmApp.packageInfo();
WF_ID = packageInfo.appId;

let kf = D_W/466;

let normal_weather_image_progress_img_level_ic = ''
let step_dot24 = []

let tap_time = 0
function clik_tap_time() {
 tap_time = (tap_time + 1) % 2
 // hmFS.SysProSetInt(`${WF_ID}_tap_left`, tap_left);
 normal_time_hour_text_font.setProperty(hmUI.prop.VISIBLE, tap_time == 0);
 normal_time_minute_text_font.setProperty(hmUI.prop.VISIBLE, tap_time == 0);
 normal_time_second_text_font.setProperty(hmUI.prop.VISIBLE, tap_time == 0);
 normal_widget_text_1.setProperty(hmUI.prop.VISIBLE, tap_time == 0);
 normal_stand_icon_img.setProperty(hmUI.prop.VISIBLE, tap_time == 0);
 vibro();
}

let tap_bat = 0

function clik_tap_bat() {
 tap_bat = (tap_bat + 1) % 2
 // hmFS.SysProSetInt(`${WF_ID}_tap_left`, tap_left);
 normal_stress_icon_img.setProperty(hmUI.prop.VISIBLE, tap_bat == 0);
 normal_widget_text_3.setProperty(hmUI.prop.VISIBLE, tap_bat == 0);
 //normal_battery_pointer_progress_img_pointer.setProperty(hmUI.prop.VISIBLE, tap_bat == 0);
 normal_battery_pointer_progress_img_pointer.setProperty(hmUI.prop.MORE, {
  src: 'str_bat.png',
  center_x: tap_bat == 0 ? 233*kf : 999*kf,
  center_y: 233*kf,
  x: 15*kf,
  y: 185*kf,
  start_angle: 228,
  end_angle: 133,
  invalid_visible: false,
  type: hmUI.data_type.BATTERY,
  show_level: hmUI.show_level.ONLY_NORMAL,
 });

 normal_battery_current_text_font.setProperty(hmUI.prop.VISIBLE, tap_bat == 0);
 normal_widget_text_2.setProperty(hmUI.prop.VISIBLE, tap_bat == 0);
 vibro();
}

let tap_str = 0

function clik_tap_str() {
 tap_str = (tap_str + 1) % 2
 // hmFS.SysProSetInt(`${WF_ID}_tap_left`, tap_left);
 normal_analog_clock_time_pointer_hour.setProperty(hmUI.prop.VISIBLE, tap_str == 0);
 normal_analog_clock_time_pointer_minute.setProperty(hmUI.prop.VISIBLE, tap_str == 0);
 normal_analog_clock_time_pointer_second.setProperty(hmUI.prop.VISIBLE, tap_str == 0);
 vibro();
}

const columnCounts = [4, 2, 4, 5, 5, 3, 4, 5, 2];
let globalIndex = 0;

const step = hmSensor.createSensor(hmSensor.id.STEP);
let target = step.target; // так работает

const TOTAL_DOTS = columnCounts.reduce((sum, count) => sum + count, 0);

// 3. Функция обновления цветов (исправленный синтаксис)
function update_step() {
 let current = step.current;
 let target = step.target;
 // Активных кругов = пропорция от 0 до 32
 let active = Math.min(Math.floor(current / target * TOTAL_DOTS), TOTAL_DOTS);

 for (let i = 0; i < TOTAL_DOTS; i++) {
  let color = (i < active) ? 0xdea745 : 0xffffff;
  step_dot24[i].setProperty(hmUI.prop.COLOR, color);
 }
}

const vibrate = hmSensor.createSensor(hmSensor.id.VIBRATE)
let stopVibro_Timer = null;

/*      function vibro(scene = 25) {
       let stopDelay = 50;
       vibrate.stop();
       vibrate.scene = scene;
       if (scene < 23 || scene > 25) stopDelay = 1220;
       vibrate.start();
       stopVibro_Timer = timer.createTimer(stopDelay, 0, stopVibro, {});
      }*/

function vibro(scene = 25) {
 //let stopDelay = 50;
 vibrate.stop();
 vibrate.scene = scene;
 vibrate.start();

 // stopVibro_Timer = timer.createTimer(stopDelay, 0, stopVibro, {});
}


function stopVibro() {
 vibrate.stop();
 timer.stopTimer(stopVibro_Timer);
}

function read_pressure() {
 console.log("read_pressure()");
 const file_name_alt = "../../../baro_altim/pressure.dat";
 const [fs_stat, err] = hmFS.stat(file_name_alt);
 if (err == 0) {
  let file_size = fs_stat.size;
  const len = file_size / 4;
  console.log(`size_alt: ${file_size}, lenght: ${len}`)
  const fh = hmFS.open(file_name_alt, hmFS.O_RDONLY)

  let array_buffer = new Float32Array(len);
  hmFS.read(fh, array_buffer.buffer, 0, file_size);
  hmFS.close(fh);
  console.log(`value ${array_buffer[array_buffer.length -1]}`);
  return array_buffer;
 } else {
  console.log('err:', err)
 }
 return null;
}

function getPressureValue(pressure_array) {
 console.log("getPressureValue()");
 if (pressure_array == null || pressure_array == undefined || pressure_array.length == 0) return 0;
 let start_index = pressure_array.length - 1;
 let end_index = start_index - 30 * 3; // 3 часа
 if (end_index < 0) end_index = 0;
 for (let index = start_index; index >= end_index; index--) {
  if (pressure_array[index] != 0) return parseInt(pressure_array[index] / 100);
 }
 return 0;
}

function changesPressure(pressure_array) {
 console.log("changesPressure()");
 if (pressure_array == null || pressure_array == undefined || pressure_array.length == 0) return 0;
 let start_index = pressure_array.length - 1;
 let end_index = start_index - 30 * 3; // 3 часа
 let value = pressure_array[start_index];
 let result = 0;
 if (end_index < 0) end_index = 0;
 for (let index = start_index; index >= end_index; index--) {
  let element = pressure_array[index];
  if (element != 0) {
   if (Math.abs(value - element) > 10) { // учитываем только если разниза больше 0,1 hPa
    value = value - element;
    console.log(`element = ${element}`);
    console.log(`pressere_changes = ${value}`);
    return value;
   }
  }
 }
 return result;
}

function hPa_To_mmHg(hPa_value = 0) {
 let mmHg = Math.round(hPa_value * 0.750064);
 return mmHg;
}

 function updatePressere() {
  let pressure_array = read_pressure();
  let value = getPressureValue(pressure_array);
  value = hPa_To_mmHg(value); // если нужно перевести в мм.рт.ст.


  let pressere_changes_str = "=";
  //let color_pressere = 0x00ff00;
  let color_pressere_0 = value < 760 ? 0xffff00 : value > 760 ? 0xff0000 : 0x00ff00;

  let pressere_changes = changesPressure(pressure_array);
  if (pressere_changes < 0) {
   pressere_changes_str = "↓"; /*color_pressere = 0xffff00;*/
  }
  if (pressere_changes > 0) {
   pressere_changes_str = "↑"; /*color_pressere = 0xff0000;*/
  }
  //text_pressere_changes.setProperty(hmUI.prop.TEXT, pressere_changes_str);

  let value_str = value == 0 ? "--" : value + pressere_changes_str;
  normal_widget_text_10.setProperty(hmUI.prop.TEXT, value_str);
  //text_pressere.setProperty(hmUI.prop.COLOR, color_pressere_0);

 // Line_arr[2][1] = value_str;
 }


let bars = [];
				
const hist_x = 177*kf;
const hist_y = 309*kf;
const hist_w = 112*kf;
const hist_h = 24*kf;
const hist_bars = 12;
const bar_space = 2;
const hist_time_minutes = 60;

// Расчёт ширины столбца и центрирование
let bar_width = Math.floor((hist_w - (hist_bars - 1) * bar_space) / hist_bars);
if (bar_width < 1) bar_width = 1;
const total_width = hist_bars * bar_width + (hist_bars - 1) * bar_space;
const start_x = hist_x + (hist_w - total_width) / 2;
				
// Датчик пульса
let heart = hmSensor.createSensor(hmSensor.id.HEART);

function updateHeartHistogram() {
  let todayData = heart.today;
  if (!todayData || todayData.length === 0) return;

  let periodData = todayData.slice(-hist_time_minutes);
  let groupSize = Math.ceil(hist_time_minutes / hist_bars);
  let rawBars = [];

  for (let i = 0; i < hist_bars; i++) {
    let start = i * groupSize;
    let end = Math.min(start + groupSize, periodData.length);
    let group = periodData.slice(start, end);
    let valid = group.filter(v => v && v > 0);
    if (valid.length === 0) rawBars.push(0);
    else {
      let avg = valid.reduce((a,b)=>a+b,0) / valid.length;
      rawBars.push(Math.round(avg));
    }
  }

  let nonZero = rawBars.filter(v => v > 0);
  if (nonZero.length === 0) return;
  let minVal = Math.min(...nonZero);
  let maxVal = Math.max(...nonZero);
  if (minVal === maxVal) { minVal = maxVal - 10; maxVal = maxVal + 10; }

  // Обновление текстовых виджетов min/max
  normal_widget_text_11.setProperty(hmUI.prop.TEXT, minVal.toString());
  normal_widget_text_12.setProperty(hmUI.prop.TEXT, maxVal.toString());

  // Обновление столбцов
  for (let i = 0; i < bars.length; i++) {
    let val = rawBars[i];
    if (val === 0) {
      bars[i].setProperty(hmUI.prop.VISIBLE, false);
      continue;
    }
    bars[i].setProperty(hmUI.prop.VISIBLE, true);
    let height = (val - minVal) / (maxVal - minVal) * hist_h;
    height = Math.min(hist_h, Math.max(0, height));
    let yPos = hist_y + (hist_h - height);
    bars[i].setProperty(hmUI.prop.MORE, {
      x: start_x + i * (bar_width + bar_space),
      y: yPos,
      w: bar_width,
      h: height
    });
  }
}				







        // end user_functions.js

        let normal_background_bg_img = ''
        let normal_hour_circle_scale = ''
        let normal_second_circle_scale = ''
        let normal_timerUpdateSec = undefined;
        let normal_image_img = ''
        let normal_stress_icon_img = ''
        let normal_stand_icon_img = ''
        let normal_time_hour_text_font = ''
        let normal_timerTimeUpdate = undefined;
        let normal_time_minute_text_font = ''
        let normal_time_second_text_font = ''
        let normal_dow_text_font = ''
        let normal_DOW_Array = ['ПН', 'ВТ', 'СР', 'ЧТ', 'ПТ', 'СБ', 'ВС'];
        let normal_day_month_font = ''
        let normal_widget_text_1 = ''
        let normal_widget_text_2 = ''
        let normal_widget_text_3 = ''
        let normal_widget_text_4 = ''
        let normal_widget_text_5 = ''
        let normal_widget_text_6 = ''
        let normal_widget_text_7 = ''
        let normal_widget_text_8 = ''
        let normal_widget_text_9 = ''
        let normal_widget_text_10 = ''
        let normal_widget_text_11 = ''
        let normal_widget_text_12 = ''
        let normal_battery_pointer_progress_img_pointer = ''
        let normal_battery_current_text_font = ''
        let normal_heart_rate_text_font = ''
        let normal_step_current_text_font = ''
        let normal_distance_current_text_font = ''
        let normal_weather_image_progress_img_level = ''
        let normal_temperature_max_min_text_font = ''
        let normal_temperature_current_text_font = ''
        let normal_calorie_current_text_font = ''
        let normal_alarm_clock_current_text_font = ''
        let normal_analog_clock_time_pointer_hour = ''
        let normal_analog_clock_time_pointer_minute = ''
        let normal_analog_clock_time_pointer_second = ''
        let normal_system_disconnect_img = ''
        let normal_system_clock_img = ''
        let Button_1 = ''
        let Button_2 = ''
        let Button_3 = ''
        let timeSensor = '';


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            // FontName: Oswald-Regular.ttf; FontSize: 53
            hmUI.createWidget(hmUI.widget.TEXT, {
              x: 464,
              y: 464,
              w: 633,
              h: 108,
              text_size: 53,
              char_space: 0,
              line_space: 0,
              font: 'fonts/Oswald-Regular.ttf',
              color: 0xFFFFFFFF,
              align_h: hmUI.align.RIGHT,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              text: "0123456789 _-.,:;`'%°\\/",
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // FontName: Oswald-Bold.ttf; FontSize: 20; Cache: full
            hmUI.createWidget(hmUI.widget.TEXT, {
              x: 464,
              y: 464,
              w: 24,
              h: 24,
              text_size: 20,
              char_space: 0,
              line_space: 0,
              font: 'fonts/Oswald-Bold.ttf',
              color: 0xFFE3B14E,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.NONE,
              text: "0123456789 ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz АБВГДЕЁЖЗИЙКЛМНОПРСТУФХЦЧШЩЪЫЬЭЮЯабвгдеёжзийклмнопрстуфхцчшщъыьэюя  ҐЄІЇґєії _-.,:;`'%°\\/",
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // FontName: Oswald-Bold.ttf; FontSize: 16
            hmUI.createWidget(hmUI.widget.TEXT, {
              x: 464,
              y: 464,
              w: 232,
              h: 34,
              text_size: 16,
              char_space: 1,
              line_space: 0,
              font: 'fonts/Oswald-Bold.ttf',
              color: 0xFFE3B14E,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              text: "0123456789 _-.,:;`'%°\\/",
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // FontName: Oswald-Bold.ttf; FontSize: 12
            hmUI.createWidget(hmUI.widget.TEXT, {
              x: 464,
              y: 464,
              w: 174,
              h: 25,
              text_size: 12,
              char_space: 1,
              line_space: 0,
              font: 'fonts/Oswald-Bold.ttf',
              color: 0xFFFFFFFF,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              text: "0123456789 _-.,:;`'%°\\/",
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // FontName: Oswald-Bold.ttf; FontSize: 14
            hmUI.createWidget(hmUI.widget.TEXT, {
              x: 464,
              y: 464,
              w: 196,
              h: 28,
              text_size: 14,
              char_space: 1,
              line_space: 0,
              font: 'fonts/Oswald-Bold.ttf',
              color: 0xFFFFFFFF,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              text: "0123456789 _-.,:;`'%°\\/",
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // FontName: HeadingSmallcaseProicv6-Bold.ttf; FontSize: 24
            hmUI.createWidget(hmUI.widget.TEXT, {
              x: 464,
              y: 464,
              w: 370,
              h: 34,
              text_size: 24,
              char_space: 1,
              line_space: 0,
              font: 'fonts/HeadingSmallcaseProicv6-Bold.ttf',
              color: 0xFFFFFFFF,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              text: "0123456789 _-.,:;`'%°\\/",
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // FontName: Oswald-Bold.ttf; FontSize: 22
            hmUI.createWidget(hmUI.widget.TEXT, {
              x: 464,
              y: 464,
              w: 292,
              h: 44,
              text_size: 22,
              char_space: 1,
              line_space: 0,
              font: 'fonts/Oswald-Bold.ttf',
              color: 0xFFFFFFFF,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              text: "0123456789 _-.,:;`'%°\\/",
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // FontName: Oswald-Bold.ttf; FontSize: 18
            hmUI.createWidget(hmUI.widget.TEXT, {
              x: 464,
              y: 464,
              w: 259,
              h: 38,
              text_size: 18,
              char_space: 1,
              line_space: 0,
              font: 'fonts/Oswald-Bold.ttf',
              color: 0xFFFFFFFF,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              text: "0123456789 _-.,:;`'%°\\/",
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // FontName: Oswald_AL-Bold.ttf; FontSize: 20
            hmUI.createWidget(hmUI.widget.TEXT, {
              x: 464,
              y: 464,
              w: 265,
              h: 42,
              text_size: 20,
              char_space: 0,
              line_space: 0,
              font: 'fonts/Oswald_AL-Bold.ttf',
              color: 0xFFFFFFFF,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              text: "0123456789 _-.,:;`'%°\\/",
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            console.log('user_script_start.js');
            // start user_script_start.js

            hmUI.createWidget(hmUI.widget.TEXT, {
              x: 464,
              y: 464,
              w: 295,
              h: 30,
              text_size: 22,
              char_space: 1,
              line_space: 0,
              font: 'fonts/Oswald-Bold.ttf',
              color: 0xFFFFFFFF,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              text: "0123456789 _-.,:;`'%°\\/↓↑",
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            // end user_script_start.js

            console.log('Watch_Face.ScreenNormal');
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 466,
              h: 466,
              src: 'bg.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            if (!timeSensor) timeSensor = hmSensor.createSensor(hmSensor.id.TIME);
            timeSensor.addEventListener(timeSensor.event.MINUTEEND, function() {
              time_update(true, true);
            });

            // normal_hour_circle_scale = hmUI.createWidget(hmUI.widget.Circle_Scale, {
              // center_x: 233,
              // center_y: 233,
              // start_angle: 0,
              // end_angle: 360,
              // radius: 200,
              // line_width: 110,
              // line_cap: Flat,
              // color: 0xFFFFFFFF,
              // mirror: False,
              // inversion: False,
              // alpha: 255,
              // type: hmUI.data_type.HOUR,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });


            normal_hour_circle_scale = hmUI.createWidget(hmUI.widget.ARC_PROGRESS, {
              center_x: 233,
              center_y: 233,
              start_angle: 0,
              end_angle: 360,
              radius: 145,
              line_width: 110,
              corner_flag: 3,
              color: 0xFFFFFFFF,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_second_circle_scale = hmUI.createWidget(hmUI.widget.Circle_Scale, {
              // center_x: 233,
              // center_y: 233,
              // start_angle: 0,
              // end_angle: 360,
              // radius: 233,
              // line_width: 32,
              // line_cap: Flat,
              // color: 0xFFE3B14E,
              // mirror: False,
              // inversion: False,
              // alpha: 255,
              // type: hmUI.data_type.SECOND,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });


            normal_second_circle_scale = hmUI.createWidget(hmUI.widget.ARC_PROGRESS, {
              center_x: 233,
              center_y: 233,
              start_angle: 0,
              end_angle: 360,
              radius: 217,
              line_width: 32,
              corner_flag: 3,
              color: 0xFFE3B14E,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            let screenType = hmSetting.getScreenType();
            // normal_time_circle_options = hmUI.createWidget(hmUI.widget.TIME_CIRCLE_OPTIONS, {
              // smooth: false,
              // format24h: false,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });


            normal_image_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'cap.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_stress_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 78,
              y: 322,
              src: 'cap_bat.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_stand_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 24,
              y: 21,
              src: 'cap_time.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_time_hour_text_font = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 25,
              y: 25,
              w: 416,
              h: 416,
              text_size: 53,
              char_space: 0,
              font: 'fonts/Oswald-Regular.ttf',
              color: 0xFFFFFFFF,
              // use_text_circle: true,
              start_angle: 0,
              end_angle: 300,
              mode: 0,
              // radius: 208,
              align_h: hmUI.align.RIGHT,
              // padding: true,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_time_minute_text_font = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 25,
              y: 25,
              w: 416,
              h: 416,
              text_size: 53,
              char_space: 0,
              font: 'fonts/Oswald-Regular.ttf',
              color: 0xFFFFFFFF,
              // use_text_circle: true,
              start_angle: 272,
              end_angle: 360,
              mode: 0,
              // radius: 208,
              align_h: hmUI.align.CENTER_H,
              // padding: true,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_time_second_text_font = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 25,
              y: 25,
              w: 416,
              h: 416,
              text_size: 53,
              char_space: 0,
              font: 'fonts/Oswald-Regular.ttf',
              color: 0xFFE3B14E,
              // use_text_circle: true,
              start_angle: -27,
              end_angle: 265,
              mode: 0,
              // radius: 208,
              align_h: hmUI.align.LEFT,
              // padding: true,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            timeSensor.addEventListener(timeSensor.event.DAYCHANGE, function() {
              time_update(true);
            });

            normal_dow_text_font = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 264,
              y: 206,
              w: 150,
              h: 30,
              text_size: 20,
              char_space: 0,
              font: 'fonts/Oswald-Bold.ttf',
              color: 0xFFE3B14E,
              line_space: 0,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.CENTER_H,
              // padding: true,
              // unit_string: ПН, ВТ, СР, ЧТ, ПТ, СБ, ВС,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_day_month_font = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 223,
              y: 206,
              w: 150,
              h: 30,
              text_size: 20,
              char_space: 0,
              font: 'fonts/Oswald-Bold.ttf',
              color: 0xFFFFFFFF,
              line_space: 0,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.CENTER_H,
              // padding: true,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_widget_text_1 = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 13,
              y: 13,
              w: 440,
              h: 440,
              text_size: 16,
              char_space: 1,
              font: 'fonts/Oswald-Bold.ttf',
              color: 0xFFE3B14E,
              // use_text_circle: true,
              start_angle: 271,
              end_angle: 360,
              mode: 0,
              // radius: 220,
              align_h: hmUI.align.CENTER_H,
              text: 'ВРЕМЯ',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_widget_text_2 = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 37,
              y: 37,
              w: 392,
              h: 392,
              text_size: 12,
              char_space: 1,
              font: 'fonts/Oswald-Bold.ttf',
              color: 0xFFFFFFFF,
              // use_text_circle: true,
              start_angle: 180,
              end_angle: 232,
              mode: 1,
              // radius: 196,
              align_h: hmUI.align.CENTER_H,
              text: 'БАТАРЕЯ',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_widget_text_3 = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 164,
              y: 434,
              w: 180,
              h: 180,
              text_size: 14,
              char_space: 1,
              font: 'fonts/Oswald-Bold.ttf',
              color: 0xFFFFFFFF,
              line_space: 0,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.NONE,
              align_h: hmUI.align.CENTER_H,
              text: '%',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_widget_text_4 = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 185,
              y: 173,
              w: 180,
              h: 30,
              text_size: 20,
              char_space: 1,
              font: 'fonts/Oswald-Bold.ttf',
              color: 0xFFFFFFFF,
              line_space: 0,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.NONE,
              align_h: hmUI.align.CENTER_H,
              text: '°C',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_widget_text_5 = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 278,
              y: 239,
              w: 70,
              h: 70,
              text_size: 24,
              char_space: 1,
              font: 'fonts/HeadingSmallcaseProicv6-Bold.ttf',
              color: 0xFFFFFFFF,
              line_space: 0,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.NONE,
              align_h: hmUI.align.CENTER_H,
              text: 'C',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_widget_text_6 = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 199,
              y: 239,
              w: 70,
              h: 70,
              text_size: 24,
              char_space: 1,
              font: 'fonts/HeadingSmallcaseProicv6-Bold.ttf',
              color: 0xFFFFFFFF,
              line_space: 0,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.NONE,
              align_h: hmUI.align.CENTER_H,
              text: 'S',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_widget_text_7 = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 117,
              y: 239,
              w: 70,
              h: 70,
              text_size: 24,
              char_space: 1,
              font: 'fonts/HeadingSmallcaseProicv6-Bold.ttf',
              color: 0xFFFFFFFF,
              line_space: 0,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.NONE,
              align_h: hmUI.align.CENTER_H,
              text: '^',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_widget_text_8 = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 167,
              y: 335,
              w: 100,
              h: 30,
              text_size: 16,
              char_space: 1,
              font: 'fonts/Oswald-Bold.ttf',
              color: 0xFFFFFFFF,
              line_space: 0,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.NONE,
              align_h: hmUI.align.CENTER_H,
              text: 'ЧС',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_widget_text_9 = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 107,
              y: 233,
              w: 100,
              h: 30,
              text_size: 16,
              char_space: 1,
              font: 'fonts/Oswald-Bold.ttf',
              color: 0xFFFFFFFF,
              line_space: 0,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.NONE,
              align_h: hmUI.align.LEFT,
              text: 'ПУТЬ',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_widget_text_10 = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 78,
              y: 276,
              w: 150,
              h: 30,
              text_size: 22,
              char_space: 1,
              font: 'fonts/Oswald-Bold.ttf',
              color: 0xFFFFFFFF,
              line_space: 0,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.NONE,
              align_h: hmUI.align.CENTER_H,
              text: '999',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_widget_text_11 = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 80,
              y: 299,
              w: 150,
              h: 30,
              text_size: 18,
              char_space: 1,
              font: 'fonts/Oswald-Bold.ttf',
              color: 0xFFFFFFFF,
              line_space: 0,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.NONE,
              align_h: hmUI.align.CENTER_H,
              text: '222',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_widget_text_12 = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 235,
              y: 299,
              w: 150,
              h: 30,
              text_size: 18,
              char_space: 1,
              font: 'fonts/Oswald-Bold.ttf',
              color: 0xFFFFFFFF,
              line_space: 0,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.NONE,
              align_h: hmUI.align.CENTER_H,
              text: '888',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_pointer_progress_img_pointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
              src: 'str_bat.png',
              center_x: 233,
              center_y: 233,
              x: 15,
              y: 185,
              start_angle: 228,
              end_angle: 133,
              invalid_visible: false,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_current_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 158,
              y: 429,
              w: 150,
              h: 30,
              text_size: 22,
              char_space: 0,
              font: 'fonts/Oswald-Bold.ttf',
              color: 0xFFFFFFFF,
              line_space: 0,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 237,
              y: 334,
              w: 150,
              h: 30,
              text_size: 22,
              char_space: 0,
              font: 'fonts/Oswald-Bold.ttf',
              color: 0xFFFFFFFF,
              line_space: 0,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 158,
              y: 276,
              w: 150,
              h: 30,
              text_size: 22,
              char_space: 0,
              font: 'fonts/Oswald-Bold.ttf',
              color: 0xFFFFFFFF,
              line_space: 0,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_distance_current_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 54,
              y: 231,
              w: 150,
              h: 30,
              text_size: 20,
              char_space: 0,
              font: 'fonts/Oswald-Bold.ttf',
              color: 0xFFFFFFFF,
              line_space: 0,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.DISTANCE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 144,
              y: 145,
              image_array: ["w_0.png","w_1.png","w_2.png","w_3.png","w_4.png","w_5.png","w_6.png","w_7.png","w_8.png","w_9.png","w_10.png","w_11.png","w_12.png","w_13.png","w_14.png","w_15.png","w_16.png","w_17.png","w_18.png","w_19.png","w_20.png","w_21.png","w_22.png","w_23.png","w_24.png","w_25.png","w_26.png","w_27.png","w_28.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_max_min_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 237,
              y: 231,
              w: 150,
              h: 30,
              text_size: 20,
              char_space: 0,
              font: 'fonts/Oswald-Bold.ttf',
              color: 0xFFFFFFFF,
              line_space: 0,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.CENTER_H,
              padding: true,
              unit_type: 1,
              type: hmUI.data_type.WEATHER_HIGH_LOW,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 230,
              y: 173,
              w: 150,
              h: 30,
              text_size: 20,
              char_space: 0,
              font: 'fonts/Oswald-Bold.ttf',
              color: 0xFFFFFFFF,
              line_space: 0,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_calorie_current_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 238,
              y: 276,
              w: 150,
              h: 30,
              text_size: 22,
              char_space: 0,
              font: 'fonts/Oswald-Bold.ttf',
              color: 0xFFFFFFFF,
              line_space: 0,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_alarm_clock_current_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 158,
              y: 121,
              w: 150,
              h: 30,
              text_size: 20,
              char_space: 0,
              font: 'fonts/Oswald_AL-Bold.ttf',
              color: 0xFFFFFFFF,
              line_space: 0,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.CENTER_H,
              padding: true,
              type: hmUI.data_type.ALARM_CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            console.log('user_script.js');
            // start user_script.js

			normal_weather_image_progress_img_level_ic = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
			 x: 190 - 3,
			 y: 174,
			 image_array: ["w_ic_0.png", "w_ic_1.png", "w_ic_2.png", "w_ic_3.png", "w_ic_4.png", "w_ic_5.png", "w_ic_6.png", "w_ic_7.png", "w_ic_8.png", "w_ic_9.png", "w_ic_10.png", "w_ic_11.png", "w_ic_12.png", "w_ic_13.png", "w_ic_14.png", "w_ic_15.png", "w_ic_16.png", "w_ic_17.png", "w_ic_18.png", "w_ic_19.png", "w_ic_20.png", "w_ic_21.png", "w_ic_22.png", "w_ic_23.png", "w_ic_24.png", "w_ic_25.png", "w_ic_26.png", "w_ic_27.png", "w_ic_28.png"],
			 image_length: 29,
			 type: hmUI.data_type.WEATHER_CURRENT,
			 show_level: hmUI.show_level.ONLY_NORMAL,
			});


for (let col = 0; col < columnCounts.length; col++) {
  const count = columnCounts[col];
  const centerX = 120 + col * 9;
  for (let j = 0; j < count; j++) {
    step_dot24[globalIndex] = hmUI.createWidget(hmUI.widget.CIRCLE, {
      center_x: centerX,
      center_y: 230 - j * 5,
      radius: 2,
      color: 0xdea745,
      alpha: 255,
      show_level: hmUI.show_level.ONLY_NORMAL,
    });
    globalIndex++;
  }
}

for (let i = 0; i < hist_bars; i++) {
  bars[i] = hmUI.createWidget(hmUI.widget.FILL_RECT, {
    x: start_x + i * (bar_width + bar_space),
    y: hist_y + hist_h,
    w: bar_width,
    h: 0,
    radius: 2,
    color: 0xdea745,
    alpha: 255,
    show_level: hmUI.show_level.ONLY_NORMAL,
  });
}

   
            // end user_script.js

            normal_analog_clock_time_pointer_hour = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              hour_path: 'str_H.png',
              hour_centerX: 233,
              hour_centerY: 233,
              hour_posX: 11,
              hour_posY: 117,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_minute = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              minute_path: 'str_M.png',
              minute_centerX: 233,
              minute_centerY: 233,
              minute_posX: 10,
              minute_posY: 155,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_second = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              second_path: 'str_S.png',
              second_centerX: 233,
              second_centerY: 233,
              second_posX: 9,
              second_posY: 211,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 210,
              y: 107,
              src: 'stat_BT.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 238,
              y: 107,
              src: 'stat_AL.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });



            console.log('Watch_Face.Buttons');
            Button_1 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 63,
              y: 60,
              w: 100,
              h: 100,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '0.png',
              normal_src: '0.png',
              click_func: (button_widget) => {
                clik_tap_time();
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_2 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 183,
              y: 367,
              w: 100,
              h: 100,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '0.png',
              normal_src: '0.png',
              click_func: (button_widget) => {
                clik_tap_bat();
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_3 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 183,
              y: 183,
              w: 100,
              h: 100,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '0.png',
              normal_src: '0.png',
              click_func: (button_widget) => {
                clik_tap_str();
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            console.log('user_script_end.js');
            // start user_script_end.js

step.addEventListener(hmSensor.event.CHANGE, function() {
  update_step();
});
// Подписка на изменения пульса
heart.addEventListener(hmSensor.event.CHANGE, function () {
  updateHeartHistogram();
});

            // end user_script_end.js

            //#region time_update
            function time_update(updateHour = false, updateMinute = false) {
              console.log('time_update()');
              let hour = timeSensor.hour;
              let minute = timeSensor.minute;
              let second = timeSensor.second;
              let format_hour = timeSensor.format_hour;

              if (updateMinute) { // Hour Circle
                let normal_circle_scale_hour = hour;
                if (normal_circle_scale_hour > 11) normal_circle_scale_hour -= 12;
                let normal_hourCircleProgress = normal_circle_scale_hour/12 + (minute/60)/12;
                normal_hourCircleProgress = normal_hourCircleProgress * 100;
                if (normal_hour_circle_scale) normal_hour_circle_scale.setProperty(hmUI.prop.LEVEL, normal_hourCircleProgress );
              };

              // Second Circle
              let normal_secondCircleProgress = 100 * second/60;
              if (normal_second_circle_scale) normal_second_circle_scale.setProperty(hmUI.prop.LEVEL, normal_secondCircleProgress );

              console.log('hour font');
              if (updateHour) {
                let normal_hourStr = format_hour.toString();
                normal_hourStr = normal_hourStr.padStart(2, '0');
                normal_time_hour_text_font.setProperty(hmUI.prop.TEXT, normal_hourStr );
              };

              console.log('minute font');
              if (updateMinute) {
                let normal_minuteStr = minute.toString();
                normal_minuteStr = normal_minuteStr.padStart(2, '0');
                normal_time_minute_text_font.setProperty(hmUI.prop.TEXT, normal_minuteStr );
              };

              console.log('second font');
                let normal_secondStr = second.toString();
                normal_secondStr = normal_secondStr.padStart(2, '0');
                normal_time_second_text_font.setProperty(hmUI.prop.TEXT, normal_secondStr );
              console.log('day of week font');
              if (updateHour) {
                let normal_DOW_Str = normal_DOW_Array[timeSensor.week-1];
                normal_dow_text_font.setProperty(hmUI.prop.TEXT, normal_DOW_Str );
              };

              console.log('day/month font');
              if (updateHour) {
                let normal_DayStr = timeSensor.day.toString();
                let normal_MonthStr = timeSensor.month.toString();
                normal_DayStr = normal_DayStr.padStart(2, '0');
                normal_MonthStr = normal_MonthStr.padStart(2, '0');
                let normal_DayMonthStr = '--';
                const dateFormat = hmSetting.getDateFormat();
                if (dateFormat == 0 || dateFormat == 2) {
                  normal_DayMonthStr = normal_MonthStr + '/' + normal_DayStr;
                }
                if (dateFormat == 1) {
                  normal_DayMonthStr = normal_DayStr + '/' + normal_MonthStr;
                }
                normal_day_month_font.setProperty(hmUI.prop.TEXT, normal_DayMonthStr );
              };

            };

            //#endregion
            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                console.log('resume_call()');
                time_update(true, true);
                if (screenType == hmSetting.screen_type.WATCHFACE) {
                  if (!normal_timerUpdateSec) {
                    let animDelay = timeSensor.utc % 1000;
                    let animRepeat = 1000;
                    normal_timerUpdateSec = timer.createTimer(animDelay, animRepeat, (function (option) {
                      time_update(false, false);
                    }));  // end timer 
                  };  // end timer check
                };  // end screenType

                if (screenType == hmSetting.screen_type.WATCHFACE) {
                  if (!normal_timerTimeUpdate) {
                    normal_timerTimeUpdate = timer.createTimer(0, 1000, (function (option) {
                      let updateHour = timeSensor.minute == 0 && timeSensor.second < 2;
                      let updateMinute = timeSensor.second < 2;
                      time_update(updateHour, updateMinute);
                    }));  // end timer 
                  };  // end timer check
                };  // end screenType


                console.log('resume_call.js');
                // start resume_call.js

update_step();

// Первоначальный вызов (данные могут быть уже доступны)
updateHeartHistogram();
  updatePressere();
                // end resume_call.js

              }),
              pause_call: (function () {
                console.log('pause_call()');
                if (normal_timerUpdateSec) {
                  timer.stopTimer(normal_timerUpdateSec);
                  normal_timerUpdateSec = undefined;
                }
                if (normal_timerTimeUpdate) {
                  timer.stopTimer(normal_timerTimeUpdate);
                  normal_timerTimeUpdate = undefined;
                }

              }),
            });

                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}