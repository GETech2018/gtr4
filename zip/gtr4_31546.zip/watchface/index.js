﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.0.1
    ** Copyright © CashaCX75. All Rights Reserved
    */

    try {
    (()=>{
        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_stress_icon_img = ''
        let normal_stress_text_text_img = ''
        let normal_spo2_text_text_img = ''
        let normal_spo2_text_separator_img = ''
        let normal_altimeter_icon_img = ''
        let normal_altimeter_text_text_img = ''
        let normal_wind_icon_img = ''
        let normal_wind_text_text_img = ''
        let normal_humidity_icon_img = ''
        let normal_humidity_text_text_img = ''
        let normal_uvi_icon_img = ''
        let normal_uvi_text_text_img = ''
        let normal_moon_image_progress_img_level = ''
        let normal_temperature_current_text_img = ''
        let normal_weather_image_progress_img_level = ''
        let normal_date_img_date_year = ''
        let normal_date_img_date_month = ''
        let normal_date_img_date_day = ''
        let normal_calorie_icon_img = ''
        let normal_calorie_current_text_img = ''
        let normal_distance_text_text_img = ''
        let normal_distance_text_separator_img = ''
        let normal_battery_icon_img = ''
        let normal_battery_text_text_img = ''
        let normal_step_icon_img = ''
        let normal_step_current_text_img = ''
        let normal_system_lock_img = ''
        let normal_system_dnd_img = ''
        let normal_system_disconnect_img = ''
        let normal_system_clock_img = ''
        let normal_heart_rate_icon_img = ''
        let normal_heart_rate_text_text_img = ''
        let normal_digital_clock_img_time = ''
        let normal_stopwatch_jumpable_img_click = ''
        let normal_countdown_jumpable_img_click = ''
        let normal_alarm_jumpable_img_click = ''
        let normal_pai_weekly_text_img = ''
        let normal_pai_weekly_separator_img = ''
        let normal_pai_day_text_img = ''
        let normal_pai_day_separator_img = ''

	let luft_index = 1
	let luft_count = 6

	let aktiv_index = 1
	let aktiv_count = 6

        //dynamic modify end
        const e = __$$hmAppManager$$__.currentApp;
        const o = e.current
          , {px: i} = (new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(e,o)),
        e.__globals__)
          , n = Logger.getLogger("watchface6");
        o.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 466,
              h: 466,
              src: 'bg_1.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_stress_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 80,
              y: 316,
              src: 'stress.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            normal_stress_icon_img.setProperty(hmUI.prop.VISIBLE, false);

            normal_stress_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 170,
              y: 322,
              font_array: ["Puls_0000.png","Puls_0001.png","Puls_0002.png","Puls_0003.png","Puls_0004.png","Puls_0005.png","Puls_0006.png","Puls_0007.png","Puls_0008.png","Puls_0009.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'hvr.png',
              unit_tc: 'hvr.png',
              unit_en: 'hvr.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STRESS,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            normal_stress_text_text_img.setProperty(hmUI.prop.VISIBLE, false);

            normal_spo2_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 173,
              y: 320,
              font_array: ["Puls_0000.png","Puls_0001.png","Puls_0002.png","Puls_0003.png","Puls_0004.png","Puls_0005.png","Puls_0006.png","Puls_0007.png","Puls_0008.png","Puls_0009.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'Puls_Prozent.png',
              unit_tc: 'Puls_Prozent.png',
              unit_en: 'Puls_Prozent.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.SPO2,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            normal_spo2_text_text_img.setProperty(hmUI.prop.VISIBLE, false);

            normal_spo2_text_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 86,
              y: 318,
              src: 'spo2.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            normal_spo2_text_separator_img.setProperty(hmUI.prop.VISIBLE, false);

            normal_altimeter_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 87,
              y: 90,
              src: 'Barometer.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            normal_altimeter_icon_img.setProperty(hmUI.prop.VISIBLE, false);

            normal_altimeter_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 157,
              y: 100,
              font_array: ["Puls_0000.png","Puls_0001.png","Puls_0002.png","Puls_0003.png","Puls_0004.png","Puls_0005.png","Puls_0006.png","Puls_0007.png","Puls_0008.png","Puls_0009.png"],
              padding: false,
              h_space: -5,
              unit_sc: 'hpa.png',
              unit_tc: 'hpa.png',
              unit_en: 'hpa.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.ALTIMETER,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            normal_altimeter_text_text_img.setProperty(hmUI.prop.VISIBLE, false);

            normal_wind_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 80,
              y: 90,
              src: 'Wind.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            normal_wind_icon_img.setProperty(hmUI.prop.VISIBLE, false);

            normal_wind_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 203,
              y: 100,
              font_array: ["Puls_0000.png","Puls_0001.png","Puls_0002.png","Puls_0003.png","Puls_0004.png","Puls_0005.png","Puls_0006.png","Puls_0007.png","Puls_0008.png","Puls_0009.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'Knoten.png',
              unit_tc: 'Knoten.png',
              unit_en: 'Knoten.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WIND,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            normal_wind_text_text_img.setProperty(hmUI.prop.VISIBLE, false);

            normal_humidity_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 88,
              y: 100,
              src: 'Feuchte.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            normal_humidity_icon_img.setProperty(hmUI.prop.VISIBLE, false);

            normal_humidity_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 173,
              y: 100,
              font_array: ["Puls_0000.png","Puls_0001.png","Puls_0002.png","Puls_0003.png","Puls_0004.png","Puls_0005.png","Puls_0006.png","Puls_0007.png","Puls_0008.png","Puls_0009.png"],
              padding: false,
              h_space: 4,
              unit_sc: 'Puls_Prozent.png',
              unit_tc: 'Puls_Prozent.png',
              unit_en: 'Puls_Prozent.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HUMIDITY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            normal_humidity_text_text_img.setProperty(hmUI.prop.VISIBLE, false);

            normal_uvi_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 79,
              y: 91,
              src: 'UV.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            normal_uvi_icon_img.setProperty(hmUI.prop.VISIBLE, false);

            normal_uvi_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 190,
              y: 98,
              font_array: ["Puls_0000.png","Puls_0001.png","Puls_0002.png","Puls_0003.png","Puls_0004.png","Puls_0005.png","Puls_0006.png","Puls_0007.png","Puls_0008.png","Puls_0009.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'uvi.png',
              unit_tc: 'uvi.png',
              unit_en: 'uvi.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.UVI,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            normal_uvi_text_text_img.setProperty(hmUI.prop.VISIBLE, false);

            normal_moon_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 315,
              y: 92,
              image_array: ["mes_56.png","mes_57.png","mes_58.png","mes_59.png","mes_60.png","mes_61.png","mes_62.png","mes_63.png","mes_64.png","mes_65.png","mes_66.png","mes_67.png","mes_68.png","mes_69.png","mes_70.png","mes_71.png","mes_72.png","mes_73.png","mes_74.png","mes_75.png","mes_76.png","mes_77.png","mes_78.png","mes_79.png","mes_80.png","mes_81.png","mes_82.png","mes_83.png","mes_84.png","mes_85.png"],
              image_length: 30,
              type: hmUI.data_type.MOON,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            normal_moon_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, false);

            normal_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 163,
              y: 99,
              font_array: ["Puls_0000.png","Puls_0001.png","Puls_0002.png","Puls_0003.png","Puls_0004.png","Puls_0005.png","Puls_0006.png","Puls_0007.png","Puls_0008.png","Puls_0009.png"],
              padding: false,
              h_space: -2,
              unit_sc: 'Puls_Grad.png',
              unit_tc: 'Puls_Grad.png',
              unit_en: 'Puls_Grad.png',
              negative_image: 'Puls_Minus.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            normal_temperature_current_text_img.setProperty(hmUI.prop.VISIBLE, false);

            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 85,
              y: 96,
              image_array: ["Weather_01.png","Weather_02.png","Weather_03.png","Weather_04.png","Weather_05.png","Weather_06.png","Weather_07.png","Weather_08.png","Weather_09.png","Weather_10.png","Weather_11.png","Weather_12.png","Weather_13.png","Weather_14.png","Weather_15.png","Weather_16.png","Weather_17.png","Weather_18.png","Weather_19.png","Weather_20.png","Weather_21.png","Weather_22.png","Weather_23.png","Weather_24.png","Weather_25.png","Weather_26.png","Weather_27.png","Weather_28.png","Weather_29.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            normal_weather_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, false);

            normal_date_img_date_year = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              year_startX: 248,
              year_startY: 100,
              year_sc_array: ["Puls_0000.png","Puls_0001.png","Puls_0002.png","Puls_0003.png","Puls_0004.png","Puls_0005.png","Puls_0006.png","Puls_0007.png","Puls_0008.png","Puls_0009.png"],
              year_tc_array: ["Puls_0000.png","Puls_0001.png","Puls_0002.png","Puls_0003.png","Puls_0004.png","Puls_0005.png","Puls_0006.png","Puls_0007.png","Puls_0008.png","Puls_0009.png"],
              year_en_array: ["Puls_0000.png","Puls_0001.png","Puls_0002.png","Puls_0003.png","Puls_0004.png","Puls_0005.png","Puls_0006.png","Puls_0007.png","Puls_0008.png","Puls_0009.png"],
              year_zero: 1,
              year_space: -5,
              year_align: hmUI.align.LEFT,
              year_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_month = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 164,
              month_startY: 100,
              month_sc_array: ["Puls_0000.png","Puls_0001.png","Puls_0002.png","Puls_0003.png","Puls_0004.png","Puls_0005.png","Puls_0006.png","Puls_0007.png","Puls_0008.png","Puls_0009.png"],
              month_tc_array: ["Puls_0000.png","Puls_0001.png","Puls_0002.png","Puls_0003.png","Puls_0004.png","Puls_0005.png","Puls_0006.png","Puls_0007.png","Puls_0008.png","Puls_0009.png"],
              month_en_array: ["Puls_0000.png","Puls_0001.png","Puls_0002.png","Puls_0003.png","Puls_0004.png","Puls_0005.png","Puls_0006.png","Puls_0007.png","Puls_0008.png","Puls_0009.png"],
              month_zero: 1,
              month_space: -5,
              month_unit_sc: 'Puls_Punkt.png',
              month_unit_tc: 'Puls_Punkt.png',
              month_unit_en: 'Puls_Punkt.png',
              month_align: hmUI.align.CENTER_H,
              month_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 83,
              day_startY: 100,
              day_sc_array: ["Puls_0000.png","Puls_0001.png","Puls_0002.png","Puls_0003.png","Puls_0004.png","Puls_0005.png","Puls_0006.png","Puls_0007.png","Puls_0008.png","Puls_0009.png"],
              day_tc_array: ["Puls_0000.png","Puls_0001.png","Puls_0002.png","Puls_0003.png","Puls_0004.png","Puls_0005.png","Puls_0006.png","Puls_0007.png","Puls_0008.png","Puls_0009.png"],
              day_en_array: ["Puls_0000.png","Puls_0001.png","Puls_0002.png","Puls_0003.png","Puls_0004.png","Puls_0005.png","Puls_0006.png","Puls_0007.png","Puls_0008.png","Puls_0009.png"],
              day_zero: 1,
              day_space: -5,
              day_unit_sc: 'Puls_Punkt.png',
              day_unit_tc: 'Puls_Punkt.png',
              day_unit_en: 'Puls_Punkt.png',
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_calorie_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 84,
              y: 320,
              src: 'Kalorien.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            normal_calorie_icon_img.setProperty(hmUI.prop.VISIBLE, false);

            normal_calorie_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 134,
              y: 320,
              font_array: ["Puls_0000.png","Puls_0001.png","Puls_0002.png","Puls_0003.png","Puls_0004.png","Puls_0005.png","Puls_0006.png","Puls_0007.png","Puls_0008.png","Puls_0009.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'Cal.png',
              unit_tc: 'Cal.png',
              unit_en: 'Cal.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            normal_calorie_current_text_img.setProperty(hmUI.prop.VISIBLE, false);

            normal_distance_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 133,
              y: 319,
              font_array: ["Puls_0000.png","Puls_0001.png","Puls_0002.png","Puls_0003.png","Puls_0004.png","Puls_0005.png","Puls_0006.png","Puls_0007.png","Puls_0008.png","Puls_0009.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'Km.png',
              unit_tc: 'Km.png',
              unit_en: 'Km.png',
              dot_image: 'Puls_Punkt.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.DISTANCE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            normal_distance_text_text_img.setProperty(hmUI.prop.VISIBLE, false);

            normal_distance_text_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 84,
              y: 316,
              src: 'Distanz.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            normal_distance_text_separator_img.setProperty(hmUI.prop.VISIBLE, false);

            normal_battery_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 173,
              y: 400,
              src: 'Blitz.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 207,
              y: 400,
              font_array: ["Bat_0000.png","Bat_0001.png","Bat_0002.png","Bat_0003.png","Bat_0004.png","Bat_0005.png","Bat_0006.png","Bat_0007.png","Bat_0008.png","Bat_0009.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'Bat_Prozent.png',
              unit_tc: 'Bat_Prozent.png',
              unit_en: 'Bat_Prozent.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 81,
              y: 317,
              src: 'Schritte.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 169,
              y: 320,
              font_array: ["Puls_0000.png","Puls_0001.png","Puls_0002.png","Puls_0003.png","Puls_0004.png","Puls_0005.png","Puls_0006.png","Puls_0007.png","Puls_0008.png","Puls_0009.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_lock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 271,
              y: 40,
              src: 'Schloss_1.png',
              type: hmUI.system_status.LOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_dnd_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 165,
              y: 42,
              src: 'DND_1.png',
              type: hmUI.system_status.DISTURB,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 199,
              y: 39,
              src: 'Bluetooth_1.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 236,
              y: 41,
              src: 'Wecker_1.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 87,
              y: 316,
              src: 'Herz.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            normal_heart_rate_icon_img.setProperty(hmUI.prop.VISIBLE, false);

            normal_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 157,
              y: 320,
              font_array: ["Puls_0000.png","Puls_0001.png","Puls_0002.png","Puls_0003.png","Puls_0004.png","Puls_0005.png","Puls_0006.png","Puls_0007.png","Puls_0008.png","Puls_0009.png"],
              padding: false,
              h_space: 1,
              unit_sc: 'bpm.png',
              unit_tc: 'bpm.png',
              unit_en: 'bpm.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            normal_heart_rate_text_text_img.setProperty(hmUI.prop.VISIBLE, false);

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 44,
              hour_startY: 196,
              hour_array: ["Zeit_0000.png","Zeit_0001.png","Zeit_0002.png","Zeit_0003.png","Zeit_0004.png","Zeit_0005.png","Zeit_0006.png","Zeit_0007.png","Zeit_0008.png","Zeit_0009.png"],
              hour_zero: 1,
              hour_space: -5,
              hour_unit_sc: 'Zeit_Doppelpunkt.png',
              hour_unit_tc: 'Zeit_Doppelpunkt.png',
              hour_unit_en: 'Zeit_Doppelpunkt.png',
              hour_align: hmUI.align.CENTER_H,

              minute_startX: 0,
              minute_startY: 0,
              minute_array: ["Zeit_0000.png","Zeit_0001.png","Zeit_0002.png","Zeit_0003.png","Zeit_0004.png","Zeit_0005.png","Zeit_0006.png","Zeit_0007.png","Zeit_0008.png","Zeit_0009.png"],
              minute_zero: 1,
              minute_space: -5,
              minute_follow: 1,
              minute_unit_sc: 'Zeit_Doppelpunkt.png',
              minute_unit_tc: 'Zeit_Doppelpunkt.png',
              minute_unit_en: 'Zeit_Doppelpunkt.png',
              minute_align: hmUI.align.LEFT,

              second_startX: 0,
              second_startY: 0,
              second_array: ["Zeit_0000.png","Zeit_0001.png","Zeit_0002.png","Zeit_0003.png","Zeit_0004.png","Zeit_0005.png","Zeit_0006.png","Zeit_0007.png","Zeit_0008.png","Zeit_0009.png"],
              second_zero: 1,
              second_space: -5,
              second_follow: 1,
              second_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_countdown_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 179,
              y: 182,
              w: 107,
              h: 100,
              src: 'leer.png',
              type: hmUI.data_type.COUNT_DOWN,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_alarm_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 45,
              y: 182,
              w: 107,
              h: 100,
              src: 'leer.png',
              type: hmUI.data_type.ALARM_CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // Button zum wechseln der Luftanzeigen
            hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 72,
              y: 88,
              text: '',
              w: 316,
              h: 65,
              normal_src: 'leer.png',
              press_src: 'leer.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
              click_func: () => {
                luft_index++;
                if(luft_index > luft_count) luft_index = 1;

            	normal_date_img_date_year.setProperty(hmUI.prop.VISIBLE, luft_index == 1);
           	normal_date_img_date_month.setProperty(hmUI.prop.VISIBLE, luft_index == 1);
            	normal_date_img_date_day.setProperty(hmUI.prop.VISIBLE, luft_index == 1);

		normal_moon_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, luft_index == 2);
		normal_temperature_current_text_img.setProperty(hmUI.prop.VISIBLE, luft_index == 2);
		normal_weather_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, luft_index == 2);

		normal_uvi_icon_img.setProperty(hmUI.prop.VISIBLE, luft_index == 3);
		normal_uvi_text_text_img.setProperty(hmUI.prop.VISIBLE, luft_index == 3);

		normal_humidity_icon_img.setProperty(hmUI.prop.VISIBLE, luft_index == 4);
		normal_humidity_text_text_img.setProperty(hmUI.prop.VISIBLE, luft_index == 4);

		normal_wind_icon_img.setProperty(hmUI.prop.VISIBLE, luft_index == 5);
		normal_wind_text_text_img.setProperty(hmUI.prop.VISIBLE, luft_index == 5);

		normal_altimeter_icon_img.setProperty(hmUI.prop.VISIBLE, luft_index == 6);
		normal_altimeter_text_text_img.setProperty(hmUI.prop.VISIBLE, luft_index == 6);

		if(luft_index == 1) hmUI.showToast({text: 'Datum aktiv'});
		if(luft_index == 2) hmUI.showToast({text: 'Wetter und Mond aktiv'});
		if(luft_index == 3) hmUI.showToast({text: 'UV-Index aktiv'});
		if(luft_index == 4) hmUI.showToast({text: 'Luftfeuchtigkeit aktiv'});
		if(luft_index == 5) hmUI.showToast({text: 'Windstärke aktiv'});
		if(luft_index == 6) hmUI.showToast({text: 'Barometer aktiv'});
              }
            });

            // Button zum wechseln der Aktivitäten
            hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 72,
              y: 310,
              text: '',
              w: 316,
              h: 65,
              normal_src: 'leer.png',
              press_src: 'leer.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
              click_func: () => {
                aktiv_index++;
                if(aktiv_index > aktiv_count) aktiv_index = 1;

            	normal_step_icon_img.setProperty(hmUI.prop.VISIBLE, aktiv_index == 1);
           	normal_step_current_text_img.setProperty(hmUI.prop.VISIBLE, aktiv_index == 1);

		normal_distance_text_text_img.setProperty(hmUI.prop.VISIBLE, aktiv_index == 2);
		normal_distance_text_separator_img.setProperty(hmUI.prop.VISIBLE, aktiv_index == 2);

		normal_heart_rate_icon_img.setProperty(hmUI.prop.VISIBLE, aktiv_index == 3);
		normal_heart_rate_text_text_img.setProperty(hmUI.prop.VISIBLE, aktiv_index == 3);

		normal_calorie_icon_img.setProperty(hmUI.prop.VISIBLE, aktiv_index == 4);
		normal_calorie_current_text_img.setProperty(hmUI.prop.VISIBLE, aktiv_index == 4);

		normal_spo2_text_text_img.setProperty(hmUI.prop.VISIBLE, aktiv_index == 5);
		normal_spo2_text_separator_img.setProperty(hmUI.prop.VISIBLE, aktiv_index == 5);

		normal_stress_icon_img.setProperty(hmUI.prop.VISIBLE, aktiv_index == 6);
		normal_stress_text_text_img.setProperty(hmUI.prop.VISIBLE, aktiv_index == 6);

		if(aktiv_index == 1) hmUI.showToast({text: 'Schritte aktiv'});
		if(aktiv_index == 2) hmUI.showToast({text: 'Distanz aktiv'});
		if(aktiv_index == 3) hmUI.showToast({text: 'Puls aktiv'});
		if(aktiv_index == 4) hmUI.showToast({text: 'Kalorien aktiv'});
		if(aktiv_index == 5) hmUI.showToast({text: 'Sauerstoff im Blut aktiv'});
		if(aktiv_index == 6) hmUI.showToast({text: 'Stress aktiv'});
              }
            });


                //dynamic modify end
            },
            onInit() {
                n.log("index page.js on init invoke")
            },
            build() {
                this.init_view(),
                n.log("index page.js on ready invoke")
            },
            onDestroy() {
                n.log("index page.js on destroy invoke")
            }
        })
    }
    )()
} catch (e) {
    console.log("Mini Program Error", e),
    e && e.stack && e.stack.split(/\n/).forEach((e=>console.log("error stack", e)))
}
