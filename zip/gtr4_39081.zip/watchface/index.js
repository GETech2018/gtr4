﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        const logger = Logger.getLogger('watchface_SashaCX75');
        //end of ignored block

        //dynamic modify start

        
        console.log('user_functions.js');
        // start user_functions.js

const { width: D_W, height: D_H } = hmSetting.getDeviceInfo();
        let groupVremya = ''
        let groupPogoda = ''
        let groupTap = ''
        
//         let normal_bat_text_font = ''
//         let normal_heart_text_font = ''
//         let normal_gradus_text_font = ''
//         let normal_step_current_text_font = ''
//         let normal_BATTERY_current_text_font = ''

         
       //  let normal_color_step_bg = ''  
         
//         let idle_bat_text_font = ''
//         let idle_heart_text_font = ''
//         let idle_gradus_text_font = ''
//         let idle_step_current_text_font = ''
//         let idle_BATTERY_current_text_font = ''

         
         
         let normal_background_bg = ''  
       //  let idle_background_bg = ''  
         
//         let idle_color_step_bg = ''  
         
//      function loadSettings() {
//
//       if (hmFS.SysProGetInt('NUMNUM_color') === undefined) {
//        color = 0;
//        hmFS.SysProSetInt('NUMNUM_color', color);
//       } else {
//        color = hmFS.SysProGetInt('NUMNUM_color');
//       }

//       if (hmFS.SysProGetInt('NUMNUM_blok_btn') === undefined) {
//        blok_btn = 0;
//        hmFS.SysProSetInt('NUMNUM_blok_btn', blok_btn);
//       } else {
//        blok_btn = hmFS.SysProGetInt('NUMNUM_blok_btn');
//       }

     // } 
         

         
        
      let blok_btn = 0

      function click_blok() {
       blok_btn = 1;

       normal_stat_block_img.setProperty(hmUI.prop.VISIBLE, true);


       groupVremya.setProperty(hmUI.prop.VISIBLE, false);
       btn_raz_block.setProperty(hmUI.prop.VISIBLE, true);

       //btn_blok.setProperty(hmUI.prop.VISIBLE, false);
       //btn_color.setProperty(hmUI.prop.VISIBLE, false);
       //btn_str.setProperty(hmUI.prop.VISIBLE, false);
       //btn_tap.setProperty(hmUI.prop.VISIBLE, false);
       //btn_zazblok.setProperty(hmUI.prop.VISIBLE, true);

      // hmFS.SysProSetInt('LIFETIME_blok_btn', blok_btn);
      }

      function click_zazblok() {
       blok_btn = 0
       normal_stat_block_img.setProperty(hmUI.prop.VISIBLE, false);

       groupVremya.setProperty(hmUI.prop.VISIBLE, true);
       btn_raz_block.setProperty(hmUI.prop.VISIBLE, false);

       //btn_blok.setProperty(hmUI.prop.VISIBLE, true);
       //btn_color.setProperty(hmUI.prop.VISIBLE, true);
       //btn_str.setProperty(hmUI.prop.VISIBLE, true);
       //btn_tap.setProperty(hmUI.prop.VISIBLE, true);
       //btn_zazblok.setProperty(hmUI.prop.VISIBLE, false);

      // hmFS.SysProSetInt('LIFETIME_blok_btn', blok_btn);
      }
         
         
         
         
      function makeAOD() {
      // color = hmFS.SysProGetInt('NUMNUM_color');

   
          
          

       const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
        resume_call: (function () {
         stopVibro();
            

            

        }),
        pause_call: (function () {
         hmApp.unregisterSpinEvent();



         stopVibro();


        }),
       });


      }
        
         let btn_zona_left = ''; 
         let zona_left = 0;

        
        function click_zona_left() {
           zona_left = (zona_left +1)%2 
            
        
          normal_day_text_font.setProperty(hmUI.prop.VISIBLE, zona_left == 0);
          normal_month_name_font.setProperty(hmUI.prop.VISIBLE, zona_left == 0);            
          normal_dow_text_font.setProperty(hmUI.prop.VISIBLE, zona_left == 0);
          normal_fix_zona_left_img.setProperty(hmUI.prop.VISIBLE, zona_left == 0);   
            
            
          normal_step_pointer_progress_img_pointer.setProperty(hmUI.prop.VISIBLE, zona_left == 1);
          normal_step_target_text_font.setProperty(hmUI.prop.VISIBLE, zona_left == 1);
          normal_step_current_text_font.setProperty(hmUI.prop.VISIBLE, zona_left == 1);
          normal_battery_icon_img.setProperty(hmUI.prop.VISIBLE, zona_left == 1);
normal_fat_burning_icon_img.setProperty(hmUI.prop.VISIBLE, zona_left == 1);            
            
         }
        
        
         let btn_zona_right = ''; 
         let zona_right = 0;

        
        function click_zona_right() {
           zona_right = (zona_right +1)%3 
            
         normal_temperature_icon_img.setProperty(hmUI.prop.VISIBLE, zona_right == 0);  
         normal_weather_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, zona_right == 0);  
         normal_temperature_current_text_font.setProperty(hmUI.prop.VISIBLE, zona_right != 1); 
            
//            normal_temperature_current_text_font.setProperty(hmUI.prop.X, zona_right == 0 ? 347:331); 
//            normal_temperature_current_text_font.setProperty(hmUI.prop.Y, zona_right == 0 ? 251:240);  
            
            normal_temperature_current_text_font.setProperty(hmUI.prop.MORE, { 
              x: zona_right == 0 ? 347:331,
              y: zona_right == 0 ? 251:240,
              w: 150,
              h: 40,
              text_size: 24,
              char_space: 0,
              line_space: 0,
              font: 'fonts/Minimalust_Small_Cap.ttf',
              color: 0xFFFFFFFF,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.CENTER_V,
              unit_type: 1,
              text_style: hmUI.text_style.ELLIPSIS,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });            
            
            
//            normal_weather_image_progress_img_level.setProperty(hmUI.prop.X, zona_right == 0 ? 383:374); 
//            normal_weather_image_progress_img_level.setProperty(hmUI.prop.W, zona_right == 0 ? 69:62); 
//            normal_weather_image_progress_img_level.setProperty(hmUI.prop.H, zona_right == 0 ? 61:55);  

            
            
         normal_fix_zona_puls_img.setProperty(hmUI.prop.VISIBLE, zona_right == 1);  
normal_fix_zona_bg_pr_right_img.setProperty(hmUI.prop.VISIBLE, zona_right != 0);   
normal_heart_rate_pointer_progress_img_pointer.setProperty(hmUI.prop.VISIBLE, zona_right == 1);  
normal_heart_rate_text_font.setProperty(hmUI.prop.VISIBLE, zona_right == 1);  

         normal_temperature_icon_img_2.setProperty(hmUI.prop.VISIBLE, zona_right == 2);  
normal_temperature_low_text_font.setProperty(hmUI.prop.VISIBLE, zona_right == 2);  
 normal_temperature_high_text_font.setProperty(hmUI.prop.VISIBLE, zona_right == 2);    
normal_WEATHER_CURRENT_pointer_progress_img_pointer.setProperty(hmUI.prop.VISIBLE, zona_right == 2);  
         normal_weather_image_progress_img_level_2.setProperty(hmUI.prop.VISIBLE, zona_right == 2);   
            
            normal_temperature_high_text_font_ic.setProperty(hmUI.prop.VISIBLE, zona_right == 2); 
            normal_temperature_low_text_font_ic.setProperty(hmUI.prop.VISIBLE, zona_right == 2); 
            
            
        }
        
        
         
         
         let color_bg = [0xff0000, 0xFCB61C, 0x068FF9, 0xb84cf6, 0xa3fd1f, 0x8cffff, 0xff00a2];   

        
         let crownSensitivity = 70; // уровень чувствительности колесика
         let color = 0;
         let degreeSum = 0;

//         let MenuCirklDelay = 1000;
//         let MenuCirkl_Timer = null;


         function onDigitalCrown() {
       hmApp.registerSpinEvent(function (key, degree) {
        if (key === hmApp.key.HOME) {
         degreeSum += degree;
         if (Math.abs(degreeSum) > crownSensitivity) {


               if (blok_btn == 0) {
              let step = degreeSum < 0 ? -1 : 1;
              color += step;
              color = color < 0 ? color_bg.length + color : color % color_bg.length;
              degreeSum = 0;

//              g_ACR_color.setProperty(hmUI.prop.VISIBLE, true);
//              if (MenuCirkl_Timer) clearTimeout(MenuCirkl_Timer);
//              MenuCirkl_Timer = setTimeout(() => {
//               g_ACR_color.setProperty(hmUI.prop.VISIBLE, false);
//              }, MenuCirklDelay);
                   
//        hmFS.SysProSetInt('NUMNUM_color', color);                   
//              });

              normal_background_bg.setProperty(hmUI.prop.COLOR, color_bg[color]);
//              normal_battery_current_text_font.setProperty(hmUI.prop.COLOR, color_bg[color]);
//              normal_heart_rate_text_font.setProperty(hmUI.prop.COLOR, color_bg[color]);
              normal_day_text_font.setProperty(hmUI.prop.COLOR, color_bg[color]);
//              normal_month_name_font.setProperty(hmUI.prop.COLOR, color_bg[color]);
             
             
normal_temperature_high_text_font_ic.setProperty(hmUI.prop.COLOR, color_bg[color]); 
normal_temperature_low_text_font_ic.setProperty(hmUI.prop.COLOR, color_bg[color]);

             
    
                min_img_time_0.setProperty(hmUI.prop.MORE, { 
              x: 26,
              y: 178,
              src: "c/" + color + "/M_" + parseInt(timeSensor.minute / 10)+ ".png",
              show_level: hmUI.show_level.ONLY_NORMAL,
            });                
                
                min_img_time_1.setProperty(hmUI.prop.MORE, { 
              x: 26-122+268,
              y: 178,
              src: "c/" + color + "/M_" + parseInt(timeSensor.minute  % 10)+ ".png",
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); 
             
             
             
            normal_battery_current_text_font.setProperty(hmUI.prop.MORE, { 
              x: 0,
              y: 427,
              w: 466,
              h: 40,
              text_size: 24,
              char_space: 0,
              line_space: 0,
              font: 'fonts/Minimalust_Small_Cap.ttf',
              color: color_bg[color],
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.CENTER_V,
              unit_type: 1,
              text_style: hmUI.text_style.ELLIPSIS,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_font.setProperty(hmUI.prop.MORE, { 
              x: 297,
              y: 275,
              w: 150,
              h: 40,
              text_size: 22,
              char_space: 0,
              line_space: 0,
              font: 'fonts/Minimalust_Small_Cap.ttf',
              color: color_bg[color],
              align_h: hmUI.align.RIGHT,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); 

             
             
             
//                   normal_battery_circle_scale.setProperty(hmUI.prop.MORE, {                      
//                      center_x: 134,
//                      center_y: 233,
//                      start_angle: -183,
//                      end_angle: 3,
//                      radius: 135,
//                      line_width: 197,
//                      corner_flag: 3,
//                      color: color_bg[color],
//                      show_level: hmUI.show_level.ONLY_NORMAL,
//                      //level: level,
//                    });
             
           
             
      //  hmFS.SysProSetInt('NUMNUM_color', color);                   
             
             
//              idle_background_bg.setProperty(hmUI.prop.COLOR, color_bg[color]);
              vibro();

         }
         }
        }
       }) // crown
      }       
         
         

            const vibrate = hmSensor.createSensor(hmSensor.id.VIBRATE)
            let stopVibro_Timer = null;

            function vibro(scene = 25) {
                let stopDelay = 50;
                vibrate.stop();
                vibrate.scene = scene;
                if (scene < 23 || scene > 25) stopDelay = 1220;
                vibrate.start();
                stopVibro_Timer = timer.createTimer(stopDelay, 0, stopVibro, {});
            }

            function stopVibro() {
                vibrate.stop();
                timer.stopTimer(stopVibro_Timer);
            }

        function click_Pogoda_on() {
          groupVremya.setProperty(hmUI.prop.VISIBLE, false);
          groupPogoda.setProperty(hmUI.prop.VISIBLE, true);
         }

         function click_Pogoda_off() {
          groupVremya.setProperty(hmUI.prop.VISIBLE, true);
          groupPogoda.setProperty(hmUI.prop.VISIBLE, false);
         }            

         let apps = [
          ['Нет действия', '-', `tap/i_tap_pusto.png`],
          ['Таймер', 'CountdownAppScreen', `tap/i_tap_obrat_otchet.png`],
          ['Секундомер', 'StopWatchScreen', `tap/i_tap_secundomer.png`],
          ['Мировые часы', 'WorldClockScreen', `tap/i_tap_mirivie_chasi.png`],
          ['Восход/закат', 'TideScreen', `tap/i_tap_voshod_zakat.png`],
          ['Сон', 'Sleep_HomeScreen', `tap/i_tap_son.png`],
          ['Стресс', 'StressHomeScreen', `tap/i_tap_stress.png`],
          ['SP02 (Кислород)', 'spo_HomeScreen', `tap/i_tap_kislorod.png`],
          ['Дыхание', 'RespirationsettingScreen', `tap/i_tap_dihanie.png`],
          ['Измерение одним касанием', 'oneKeyAppScreen', `tap/i_tap_1_kosanie.png`],
          ['Женский календарь', 'menstrualAppScreen', `tap/i_tap_gensk_calendar.png`],
          ['Найти телефон', 'FindPhoneScreen', `tap/i_tap_naiti_telo.png`],
          ['Музыка', 'PhoneMusicCtrlScreen', `tap/i_tap_musik.png`],
          ['Компас', 'CompassScreen', `tap/i_tap_kompas.png`],
          ['Набрать номер', 'DialCallScreen', `tap/i_tap_nabor.png`],
          ['Телефон', 'PhoneHomeScreen', `tap/i_tap_telefon.png`],
          ['Диктофон', 'VoiceMemoScreen', `tap/i_tap_dictofon.png`],
          ['Расписание', 'ScheduleListScreen', `tap/i_tap_raspisanie.png`],
          ['Список дел', 'todoListScreen', `tap/i_tap_spisok_del.png`],
          ['Календарь', 'ScheduleCalScreen', `tap/i_tap_calendar.png`],
          ['Погода', 'WeatherScreen', `tap/i_tap_pogoda.png`],
          ['Настройка', 'Settings_homeScreen', `tap/i_tap_sitting.png`],
          ['Камера', 'HidcameraScreen', `tap/i_tap_camera.png`],
          ['Пульс', 'heart_app_Screen', `tap/i_tap_puls.png`],
          ['Будильник', 'AlarmInfoScreen', `tap/i_tap_budilnik.png`],
          ['PAI', 'PAI_app_Screen', `tap/i_tap_pai.png`],
          ['Тренировка', 'SportListScreen', `tap/i_tap_trenerovka.png`],
          ['AOD', 'Settings_standbyModelScreen', `tap/i_tap_aod.png`],
          ['Экономия заряда', 'LowBatteryScreen', `tap/i_tap_LowBattery.png`],
          ['Давление/Высота', 'BaroAltimeterScreen', `tap/i_tap_barometr.png`]
         ];


         const tap_1_edit = hmUI.createWidget(hmUI.widget.WATCHFACE_EDIT_GROUP, {
          edit_id: 101,
          x: 171,
          y: 20,
          w: 124,
          h: 124,
          select_image: 'tap/edit_red_1.png',
          un_select_image: 'tap/edit_griin_1.png',
          default_type: 19,
          optional_types: [{
           type: 0,
           preview: apps[0][2],
           title_en: apps[0][0]
          }, {
           type: 1,
           preview: apps[1][2],
           title_en: apps[1][0]
          }, {
           type: 2,
           preview: apps[2][2],
           title_en: apps[2][0]
          }, {
           type: 3,
           preview: apps[3][2],
           title_en: apps[3][0]
          }, {
           type: 4,
           preview: apps[4][2],
           title_en: apps[4][0]
          }, {
           type: 5,
           preview: apps[5][2],
           title_en: apps[5][0]
          }, {
           type: 6,
           preview: apps[6][2],
           title_en: apps[6][0]
          }, {
           type: 7,
           preview: apps[7][2],
           title_en: apps[7][0]
          }, {
           type: 8,
           preview: apps[8][2],
           title_en: apps[8][0]
          }, {
           type: 9,
           preview: apps[9][2],
           title_en: apps[9][0]
          }, {
           type: 10,
           preview: apps[10][2],
           title_en: apps[10][0]
          }, {
           type: 11,
           preview: apps[11][2],
           title_en: apps[11][0]
          }, {
           type: 12,
           preview: apps[12][2],
           title_en: apps[12][0]
          }, {
           type: 13,
           preview: apps[13][2],
           title_en: apps[13][0]
          }, {
           type: 14,
           preview: apps[14][2],
           title_en: apps[14][0]
          }, {
           type: 15,
           preview: apps[15][2],
           title_en: apps[15][0]
          }, {
           type: 16,
           preview: apps[16][2],
           title_en: apps[16][0]
          }, {
           type: 17,
           preview: apps[17][2],
           title_en: apps[17][0]
          }, {
           type: 18,
           preview: apps[18][2],
           title_en: apps[18][0]
          }, {
           type: 19,
           preview: apps[19][2],
           title_en: apps[19][0]
          }, {
           type: 20,
           preview: apps[20][2],
           title_en: apps[20][0]
          }, {
           type: 21,
           preview: apps[21][2],
           title_en: apps[21][0]
          }, {
           type: 22,
           preview: apps[22][2],
           title_en: apps[22][0]
          }, {
           type: 23,
           preview: apps[23][2],
           title_en: apps[23][0]
          }, {
           type: 24,
           preview: apps[24][2],
           title_en: apps[24][0]
          }, {
           type: 25,
           preview: apps[25][2],
           title_en: apps[25][0]
          }, {
           type: 26,
           preview: apps[26][2],
           title_en: apps[26][0]
          }, {
           type: 27,
           preview: apps[27][2],
           title_en: apps[27][0]
          }, {
           type: 28,
           preview: apps[28][2],
           title_en: apps[28][0]
          }, {
           type: 29,
           preview: apps[29][2],
           title_en: apps[29][0]
          }, ],
          count: 30,
          tips_x: 135 - 171,
          tips_y: 150 - 20,
          tips_width: 195,
          tips_margin: 10,
          tips_BG: 'tap/tips_bg.png'
         })

         let tap_1_select = tap_1_edit.getProperty(hmUI.prop.CURRENT_TYPE)

         const tap_2_edit = hmUI.createWidget(hmUI.widget.WATCHFACE_EDIT_GROUP, {
          edit_id: 102,
          x: 301,
          y: 95,
          w: 124,
          h: 124,
          select_image: 'tap/edit_red_1.png',
          un_select_image: 'tap/edit_griin_1.png',
          default_type: 20,
          optional_types: [{
           type: 0,
           preview: apps[0][2],
           title_en: apps[0][0]
          }, {
           type: 1,
           preview: apps[1][2],
           title_en: apps[1][0]
          }, {
           type: 2,
           preview: apps[2][2],
           title_en: apps[2][0]
          }, {
           type: 3,
           preview: apps[3][2],
           title_en: apps[3][0]
          }, {
           type: 4,
           preview: apps[4][2],
           title_en: apps[4][0]
          }, {
           type: 5,
           preview: apps[5][2],
           title_en: apps[5][0]
          }, {
           type: 6,
           preview: apps[6][2],
           title_en: apps[6][0]
          }, {
           type: 7,
           preview: apps[7][2],
           title_en: apps[7][0]
          }, {
           type: 8,
           preview: apps[8][2],
           title_en: apps[8][0]
          }, {
           type: 9,
           preview: apps[9][2],
           title_en: apps[9][0]
          }, {
           type: 10,
           preview: apps[10][2],
           title_en: apps[10][0]
          }, {
           type: 11,
           preview: apps[11][2],
           title_en: apps[11][0]
          }, {
           type: 12,
           preview: apps[12][2],
           title_en: apps[12][0]
          }, {
           type: 13,
           preview: apps[13][2],
           title_en: apps[13][0]
          }, {
           type: 14,
           preview: apps[14][2],
           title_en: apps[14][0]
          }, {
           type: 15,
           preview: apps[15][2],
           title_en: apps[15][0]
          }, {
           type: 16,
           preview: apps[16][2],
           title_en: apps[16][0]
          }, {
           type: 17,
           preview: apps[17][2],
           title_en: apps[17][0]
          }, {
           type: 18,
           preview: apps[18][2],
           title_en: apps[18][0]
          }, {
           type: 19,
           preview: apps[19][2],
           title_en: apps[19][0]
          }, {
           type: 20,
           preview: apps[20][2],
           title_en: apps[20][0]
          }, {
           type: 21,
           preview: apps[21][2],
           title_en: apps[21][0]
          }, {
           type: 22,
           preview: apps[22][2],
           title_en: apps[22][0]
          }, {
           type: 23,
           preview: apps[23][2],
           title_en: apps[23][0]
          }, {
           type: 24,
           preview: apps[24][2],
           title_en: apps[24][0]
          }, {
           type: 25,
           preview: apps[25][2],
           title_en: apps[25][0]
          }, {
           type: 26,
           preview: apps[26][2],
           title_en: apps[26][0]
          }, {
           type: 27,
           preview: apps[27][2],
           title_en: apps[27][0]
          }, {
           type: 28,
           preview: apps[28][2],
           title_en: apps[28][0]
          }, {
           type: 29,
           preview: apps[29][2],
           title_en: apps[29][0]
          }, ],
          count: 30,
          tips_x: 266 - 301,
          tips_y: 225 - 95,
          tips_width: 195,
          tips_margin: 10,
          tips_BG: 'tap/tips_bg.png'
         })


         let tap_2_select = tap_2_edit.getProperty(hmUI.prop.CURRENT_TYPE)


         const tap_3_edit = hmUI.createWidget(hmUI.widget.WATCHFACE_EDIT_GROUP, {
          edit_id: 103,
          x: 301,
          y: 246,
          w: 124,
          h: 124,
          select_image: 'tap/edit_red_1.png',
          un_select_image: 'tap/edit_griin_1.png',
          default_type: 24,
          optional_types: [{
           type: 0,
           preview: apps[0][2],
           title_en: apps[0][0]
          }, {
           type: 1,
           preview: apps[1][2],
           title_en: apps[1][0]
          }, {
           type: 2,
           preview: apps[2][2],
           title_en: apps[2][0]
          }, {
           type: 3,
           preview: apps[3][2],
           title_en: apps[3][0]
          }, {
           type: 4,
           preview: apps[4][2],
           title_en: apps[4][0]
          }, {
           type: 5,
           preview: apps[5][2],
           title_en: apps[5][0]
          }, {
           type: 6,
           preview: apps[6][2],
           title_en: apps[6][0]
          }, {
           type: 7,
           preview: apps[7][2],
           title_en: apps[7][0]
          }, {
           type: 8,
           preview: apps[8][2],
           title_en: apps[8][0]
          }, {
           type: 9,
           preview: apps[9][2],
           title_en: apps[9][0]
          }, {
           type: 10,
           preview: apps[10][2],
           title_en: apps[10][0]
          }, {
           type: 11,
           preview: apps[11][2],
           title_en: apps[11][0]
          }, {
           type: 12,
           preview: apps[12][2],
           title_en: apps[12][0]
          }, {
           type: 13,
           preview: apps[13][2],
           title_en: apps[13][0]
          }, {
           type: 14,
           preview: apps[14][2],
           title_en: apps[14][0]
          }, {
           type: 15,
           preview: apps[15][2],
           title_en: apps[15][0]
          }, {
           type: 16,
           preview: apps[16][2],
           title_en: apps[16][0]
          }, {
           type: 17,
           preview: apps[17][2],
           title_en: apps[17][0]
          }, {
           type: 18,
           preview: apps[18][2],
           title_en: apps[18][0]
          }, {
           type: 19,
           preview: apps[19][2],
           title_en: apps[19][0]
          }, {
           type: 20,
           preview: apps[20][2],
           title_en: apps[20][0]
          }, {
           type: 21,
           preview: apps[21][2],
           title_en: apps[21][0]
          }, {
           type: 22,
           preview: apps[22][2],
           title_en: apps[22][0]
          }, {
           type: 23,
           preview: apps[23][2],
           title_en: apps[23][0]
          }, {
           type: 24,
           preview: apps[24][2],
           title_en: apps[24][0]
          }, {
           type: 25,
           preview: apps[25][2],
           title_en: apps[25][0]
          }, {
           type: 26,
           preview: apps[26][2],
           title_en: apps[26][0]
          }, {
           type: 27,
           preview: apps[27][2],
           title_en: apps[27][0]
          }, {
           type: 28,
           preview: apps[28][2],
           title_en: apps[28][0]
          }, {
           type: 29,
           preview: apps[29][2],
           title_en: apps[29][0]
          }, ],
          count: 30,
          tips_x: 266 - 301,
          tips_y: 184 - 246,
          tips_width: 195,
          tips_margin: 10,
          tips_BG: 'tap/tips_bg.png'
         })

         let tap_3_select = tap_3_edit.getProperty(hmUI.prop.CURRENT_TYPE)

         const tap_4_edit = hmUI.createWidget(hmUI.widget.WATCHFACE_EDIT_GROUP, {
          edit_id: 104,
          x: 171,
          y: 321,
          w: 124,
          h: 124,
          select_image: 'tap/edit_red_1.png',
          un_select_image: 'tap/edit_griin_1.png',
          default_type: 11,
          optional_types: [{
           type: 0,
           preview: apps[0][2],
           title_en: apps[0][0]
          }, {
           type: 1,
           preview: apps[1][2],
           title_en: apps[1][0]
          }, {
           type: 2,
           preview: apps[2][2],
           title_en: apps[2][0]
          }, {
           type: 3,
           preview: apps[3][2],
           title_en: apps[3][0]
          }, {
           type: 4,
           preview: apps[4][2],
           title_en: apps[4][0]
          }, {
           type: 5,
           preview: apps[5][2],
           title_en: apps[5][0]
          }, {
           type: 6,
           preview: apps[6][2],
           title_en: apps[6][0]
          }, {
           type: 7,
           preview: apps[7][2],
           title_en: apps[7][0]
          }, {
           type: 8,
           preview: apps[8][2],
           title_en: apps[8][0]
          }, {
           type: 9,
           preview: apps[9][2],
           title_en: apps[9][0]
          }, {
           type: 10,
           preview: apps[10][2],
           title_en: apps[10][0]
          }, {
           type: 11,
           preview: apps[11][2],
           title_en: apps[11][0]
          }, {
           type: 12,
           preview: apps[12][2],
           title_en: apps[12][0]
          }, {
           type: 13,
           preview: apps[13][2],
           title_en: apps[13][0]
          }, {
           type: 14,
           preview: apps[14][2],
           title_en: apps[14][0]
          }, {
           type: 15,
           preview: apps[15][2],
           title_en: apps[15][0]
          }, {
           type: 16,
           preview: apps[16][2],
           title_en: apps[16][0]
          }, {
           type: 17,
           preview: apps[17][2],
           title_en: apps[17][0]
          }, {
           type: 18,
           preview: apps[18][2],
           title_en: apps[18][0]
          }, {
           type: 19,
           preview: apps[19][2],
           title_en: apps[19][0]
          }, {
           type: 20,
           preview: apps[20][2],
           title_en: apps[20][0]
          }, {
           type: 21,
           preview: apps[21][2],
           title_en: apps[21][0]
          }, {
           type: 22,
           preview: apps[22][2],
           title_en: apps[22][0]
          }, {
           type: 23,
           preview: apps[23][2],
           title_en: apps[23][0]
          }, {
           type: 24,
           preview: apps[24][2],
           title_en: apps[24][0]
          }, {
           type: 25,
           preview: apps[25][2],
           title_en: apps[25][0]
          }, {
           type: 26,
           preview: apps[26][2],
           title_en: apps[26][0]
          }, {
           type: 27,
           preview: apps[27][2],
           title_en: apps[27][0]
          }, {
           type: 28,
           preview: apps[28][2],
           title_en: apps[28][0]
          }, {
           type: 29,
           preview: apps[29][2],
           title_en: apps[29][0]
          }, ],
          count: 30,
          tips_x: 135 - 171,
          tips_y: 257 - 321,
          tips_width: 195,
          tips_margin: 10,
          tips_BG: 'tap/tips_bg.png'
         })

         let tap_4_select = tap_4_edit.getProperty(hmUI.prop.CURRENT_TYPE)

         const tap_5_edit = hmUI.createWidget(hmUI.widget.WATCHFACE_EDIT_GROUP, {
          edit_id: 105,
          x: 40,
          y: 246,
          w: 124,
          h: 124,
          select_image: 'tap/edit_red_1.png',
          un_select_image: 'tap/edit_griin_1.png',
          default_type: 0,
          optional_types: [{
           type: 0,
           preview: apps[0][2],
           title_en: apps[0][0]
          }, {
           type: 1,
           preview: apps[1][2],
           title_en: apps[1][0]
          }, {
           type: 2,
           preview: apps[2][2],
           title_en: apps[2][0]
          }, {
           type: 3,
           preview: apps[3][2],
           title_en: apps[3][0]
          }, {
           type: 4,
           preview: apps[4][2],
           title_en: apps[4][0]
          }, {
           type: 5,
           preview: apps[5][2],
           title_en: apps[5][0]
          }, {
           type: 6,
           preview: apps[6][2],
           title_en: apps[6][0]
          }, {
           type: 7,
           preview: apps[7][2],
           title_en: apps[7][0]
          }, {
           type: 8,
           preview: apps[8][2],
           title_en: apps[8][0]
          }, {
           type: 9,
           preview: apps[9][2],
           title_en: apps[9][0]
          }, {
           type: 10,
           preview: apps[10][2],
           title_en: apps[10][0]
          }, {
           type: 11,
           preview: apps[11][2],
           title_en: apps[11][0]
          }, {
           type: 12,
           preview: apps[12][2],
           title_en: apps[12][0]
          }, {
           type: 13,
           preview: apps[13][2],
           title_en: apps[13][0]
          }, {
           type: 14,
           preview: apps[14][2],
           title_en: apps[14][0]
          }, {
           type: 15,
           preview: apps[15][2],
           title_en: apps[15][0]
          }, {
           type: 16,
           preview: apps[16][2],
           title_en: apps[16][0]
          }, {
           type: 17,
           preview: apps[17][2],
           title_en: apps[17][0]
          }, {
           type: 18,
           preview: apps[18][2],
           title_en: apps[18][0]
          }, {
           type: 19,
           preview: apps[19][2],
           title_en: apps[19][0]
          }, {
           type: 20,
           preview: apps[20][2],
           title_en: apps[20][0]
          }, {
           type: 21,
           preview: apps[21][2],
           title_en: apps[21][0]
          }, {
           type: 22,
           preview: apps[22][2],
           title_en: apps[22][0]
          }, {
           type: 23,
           preview: apps[23][2],
           title_en: apps[23][0]
          }, {
           type: 24,
           preview: apps[24][2],
           title_en: apps[24][0]
          }, {
           type: 25,
           preview: apps[25][2],
           title_en: apps[25][0]
          }, {
           type: 26,
           preview: apps[26][2],
           title_en: apps[26][0]
          }, {
           type: 27,
           preview: apps[27][2],
           title_en: apps[27][0]
          }, {
           type: 28,
           preview: apps[28][2],
           title_en: apps[28][0]
          }, {
           type: 29,
           preview: apps[29][2],
           title_en: apps[29][0]
          }, ],
          count: 30,
          tips_x: 5 - 40,
          tips_y: 184 - 246,
          tips_width: 195,
          tips_margin: 10,
          tips_BG: 'tap/tips_bg.png'
         })

         let tap_5_select = tap_5_edit.getProperty(hmUI.prop.CURRENT_TYPE)

         const tap_6_edit = hmUI.createWidget(hmUI.widget.WATCHFACE_EDIT_GROUP, {
          edit_id: 106,
          x: 40,
          y: 95,
          w: 124,
          h: 124,
          select_image: 'tap/edit_red_1.png',
          un_select_image: 'tap/edit_griin_1.png',
          default_type: 0,
          optional_types: [{
           type: 0,
           preview: apps[0][2],
           title_en: apps[0][0]
          }, {
           type: 1,
           preview: apps[1][2],
           title_en: apps[1][0]
          }, {
           type: 2,
           preview: apps[2][2],
           title_en: apps[2][0]
          }, {
           type: 3,
           preview: apps[3][2],
           title_en: apps[3][0]
          }, {
           type: 4,
           preview: apps[4][2],
           title_en: apps[4][0]
          }, {
           type: 5,
           preview: apps[5][2],
           title_en: apps[5][0]
          }, {
           type: 6,
           preview: apps[6][2],
           title_en: apps[6][0]
          }, {
           type: 7,
           preview: apps[7][2],
           title_en: apps[7][0]
          }, {
           type: 8,
           preview: apps[8][2],
           title_en: apps[8][0]
          }, {
           type: 9,
           preview: apps[9][2],
           title_en: apps[9][0]
          }, {
           type: 10,
           preview: apps[10][2],
           title_en: apps[10][0]
          }, {
           type: 11,
           preview: apps[11][2],
           title_en: apps[11][0]
          }, {
           type: 12,
           preview: apps[12][2],
           title_en: apps[12][0]
          }, {
           type: 13,
           preview: apps[13][2],
           title_en: apps[13][0]
          }, {
           type: 14,
           preview: apps[14][2],
           title_en: apps[14][0]
          }, {
           type: 15,
           preview: apps[15][2],
           title_en: apps[15][0]
          }, {
           type: 16,
           preview: apps[16][2],
           title_en: apps[16][0]
          }, {
           type: 17,
           preview: apps[17][2],
           title_en: apps[17][0]
          }, {
           type: 18,
           preview: apps[18][2],
           title_en: apps[18][0]
          }, {
           type: 19,
           preview: apps[19][2],
           title_en: apps[19][0]
          }, {
           type: 20,
           preview: apps[20][2],
           title_en: apps[20][0]
          }, {
           type: 21,
           preview: apps[21][2],
           title_en: apps[21][0]
          }, {
           type: 22,
           preview: apps[22][2],
           title_en: apps[22][0]
          }, {
           type: 23,
           preview: apps[23][2],
           title_en: apps[23][0]
          }, {
           type: 24,
           preview: apps[24][2],
           title_en: apps[24][0]
          }, {
           type: 25,
           preview: apps[25][2],
           title_en: apps[25][0]
          }, {
           type: 26,
           preview: apps[26][2],
           title_en: apps[26][0]
          }, {
           type: 27,
           preview: apps[27][2],
           title_en: apps[27][0]
          }, {
           type: 28,
           preview: apps[28][2],
           title_en: apps[28][0]
          }, {
           type: 29,
           preview: apps[29][2],
           title_en: apps[29][0]
          }, ],
          count: 30,
          tips_x: 5 - 40,
          tips_y: 225 - 95,

          tips_width: 195,
          tips_margin: 10,
          tips_BG: 'tap/tips_bg.png'
         })

         let tap_6_select = tap_6_edit.getProperty(hmUI.prop.CURRENT_TYPE)

         let btn_tap = ''
         let btn_click_tap_exit = ''

         let btn_Tap_zona_0 = ''
         let btn_Tap_zona_1 = ''
         let btn_Tap_zona_2 = ''
         let btn_Tap_zona_3 = ''
         let btn_Tap_zona_4 = ''
         let btn_Tap_zona_5 = ''

         function tap_zona_exit() {
          groupVremya.setProperty(hmUI.prop.VISIBLE, true);
          groupTap.setProperty(hmUI.prop.VISIBLE, false);
         }

         let tap_x_y = [
          [178, 26, 1],
          [308, 102, 1],
          [308, 253, 1],
          [178, 328, 0],
          [47, 253, 0],
          [47, 102, 0]
         ];

         function tap_run() {
          groupVremya.setProperty(hmUI.prop.VISIBLE, false);
          groupTap.setProperty(hmUI.prop.VISIBLE, true);
         }   
               
   		//переменные для ргафика
         let weatherArrayGrafik = [] //есть
         let weatherIconImgArrayGrafik = [] //есть
    		let weatherTxtImgArray = []
    		let weatherTxtImgArrayN = []
    		let pointred = new Array(6);
    		let pointblue = new Array(5);
    		let linered = new Array(6);
    		let lineblue = new Array(5);
    		let yArrH = new Array(6);
    		let yArrL = new Array(5);
    		let y_pogodaH = new Array(6);
    		let y_pogodaL = new Array(5);
    		let week_weater = ["ПН", "ВТ", "СР", "ЧТ", "ПТ", "СБ", "ВС"];
    		let week_weater_img = []
    		let day_weater_img = []
    		const ROOTPATH = "images/"

    		//let normal_city_name_text = ''
            let curTime = hmSensor.createSensor(hmSensor.id.TIME);


      let day_num = [0, 31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31];
      let year = curTime.year;
      if (year % 4 == 0 && (year % 100 != 0 || year % 400 == 0)) { // Високосный год
       day_num[2] = 29
      } else {
       day_num[2] = 28
      }

			
    			//-------------------------------- 
		 
  		//массив иконок для графика       
    		for (var i = 0; i <= 28; i++) {
          weatherArrayGrafik.push(ROOTPATH + "Grafik/weather/" + i + ".png"); //0-28

    		}

    		let weather = hmSensor.createSensor(hmSensor.id.WEATHER);
    		let weatherData = weather.getForecastWeather();
    		let forecastData = weatherData.forecastData;


    		//обновление для   графика           
    		function updateGrafik() {
				
//       weatherData = weather.getForecastWeather();
//       forecastData = weatherData.forecastData;
      // normal_city_name_text.setProperty(hmUI.prop.TEXT, weatherData.cityName);
				
    			if (forecastData.count == 0) {
    				for (let i = 0; i < 6; i++) {
    					var invalidPath = "--";
            weatherIconImgArrayGrafik[i].setProperty(hmUI.prop.SRC, ROOTPATH + "Grafik/weather/25.png");
    				}
    			} else {
        let weekDay = curTime.week - 1;
        let data_gr = curTime.day;
        let month_gr = curTime.month;

        for (let i = 0; i < 6; i++) {
         yArrH[i] = forecastData.data[i].high;
         let element = forecastData.data[i];
         let iconIndex = element.index;
         weatherIconImgArrayGrafik[i].setProperty(hmUI.prop.SRC, weatherArrayGrafik[iconIndex]);
         let week2 = week_weater[weekDay];
         week_weater_img[i].setProperty(hmUI.prop.MORE, {
          color: weekDay < 5 ? "0xFFFFFFFF" : "0xFFFF0000",
          text: week2,
         });
         day_weater_img[i].setProperty(hmUI.prop.MORE, {
          color: weekDay < 5 ? "0xFFFFFFFF" : "0xFFFF0000",
          text: data_gr,
         });
         weekDay = (weekDay + 1) % 7;
         data_gr = (data_gr + 1)
         if (data_gr > day_num[month_gr]) data_gr = 1
        }
       }


    			for (let i = 0; i < 5; i++) {
    				yArrL[i] = forecastData.data[i].low;
    			}
    			let maxH = Math.max(...yArrH)
    			let maxL = Math.min(...yArrL)
    			var shag = 46;
    			var x0 = 119;
    			for (let i = 0; i < 6; i++) {
    				pointred[i].setProperty(hmUI.prop.MORE, {
    					x: 119 + shag * [i] - 5,
    					y: (yArrH[i] * (120 / (maxL - maxH)) + 169 - 27 - maxH * (120 / (maxL - maxH))) - 5,
    					w: 10,
    					h: 10,
    					start_angle: -90,
    					end_angle: 270,
    					color: 0xFFFF0000,
    					line_width: 10,
    				});
    			};

    			for (let i = 0; i < 5; i++) {
    				yyyyy1 = (yArrH[i] * (120 / (maxL - maxH)) + 169 - 27 - maxH * (120 / (maxL - maxH))) - 5,
    					yyyyy2 = (yArrH[i + 1] * (120 / (maxL - maxH)) + 169 - 27 - maxH * (120 / (maxL - maxH))) - 5,
    					linered[i].setProperty(hmUI.prop.MORE, {
    						x: 0,
    						y: 0,
    						w: 164 + shag * i,
    						h: D_H,
    						pos_x: -31 + shag * i,
    						pos_y: yyyyy1 + 2,
    						center_x: 119 + shag * i,
    						center_y: yyyyy1,
    						angle: Math.atan((yyyyy2 - yyyyy1) / shag) * 180 / Math.PI,
						src: ROOTPATH + 'Grafik/line_red.png',
    					});
    			};
    			for (let i = 0; i < 5; i++) {
    				pointblue[i].setProperty(hmUI.prop.MORE, {
    					x: 119 + 23 + shag * [i] - 5,
    					y: (yArrL[i] * (120 / (maxL - maxH)) + 169 - 27 - maxH * (120 / (maxL - maxH))) - 5,
    					w: 10,
    					h: 10,
    					start_angle: -90,
    					end_angle: 270,
    					color: 0xFF00eaff,
    					line_width: 10,
    				});
    			};

    			for (let i = 0; i < 4; i++) {
    				yyyyy1 = (yArrL[i] * (120 / (maxL - maxH)) + 169 - 27 - maxH * (120 / (maxL - maxH))) - 5,
    					yyyyy2 = (yArrL[i + 1] * (120 / (maxL - maxH)) + 169 - 27 - maxH * (120 / (maxL - maxH))) - 5,
    					lineblue[i].setProperty(hmUI.prop.MORE, {
    						x: 0,
    						y: 0,
    						w: 164 + shag * i + 23,
    						h: D_H,
    						pos_x: -31 + shag * i + 23,
    						pos_y: yyyyy1 + 2,
    						center_x: 119 + shag * i + 23,
    						center_y: yyyyy1,
    						angle: Math.atan((yyyyy2 - yyyyy1) / shag) * 180 / Math.PI,
						src: ROOTPATH + 'Grafik/line_blue.png',
    					});
    			};

    			for (let i = 0; i < 5; i++) {
    				pointblue[i].setProperty(hmUI.prop.MORE, {
    					x: 119 + 23 + shag * [i] - 5,
    					y: (yArrL[i] * (120 / (maxL - maxH)) + 169 - 27 - maxH * (120 / (maxL - maxH))) - 5,
    					w: 10,
    					h: 10,
    					start_angle: -90,
    					end_angle: 270,
    					color: 0xFF00eaff,
    					line_width: 10,
    				});
    			};

    			for (let i = 0; i < 6; i++) {
    				y_pogodaH[i] = (yArrH[i] * (120 / (maxL - maxH)) + 169 - 24 - maxH * (120 / (maxL - maxH))) - 5;
    				weatherTxtImgArray[i].setProperty(hmUI.prop.more, {
    					x: 96 - 5 + i * 45 * 1.02,
    					y: y_pogodaH[i] - 38, //120-7
    					w: 50,
    					h: 40,
    					color: "0xFFffffff",
    					text_size: 27,
    					text: yArrH[i],
    					text_style: hmUI.text_style.NONE,
    					align_h: hmUI.align.CENTER_H,
    					align_v: hmUI.align.CENTER_V,
    					show_level: hmUI.show_level.ONLY_NORMAL
    				});
    			}

    			for (let i = 0; i < 5; i++) {
    				y_pogodaL[i] = (yArrL[i] * (120 / (maxL - maxH)) + 169 - 24 - maxH * (120 / (maxL - maxH))) - 5;;
    				weatherTxtImgArrayN[i].setProperty(hmUI.prop.more, {
    					x: 96 - 5 + 23 + i * 45 * 1.02,
    					y: y_pogodaL[i] - 1, //120-7
    					w: 50,
    					h: 40,
    					color: "0xFFffffff",
    					text_size: 27,
    					text: yArrL[i],
    					text_style: hmUI.text_style.NONE,
    					align_h: hmUI.align.CENTER_H,
    					align_v: hmUI.align.CENTER_V,
    					show_level: hmUI.show_level.ONLY_NORMAL
    				});
    			}
    		}
        // end user_functions.js

        let normal_fat_burning_icon_img = ''
        let normal_image_img = ''
        let normal_battery_icon_img = ''
        let normal_fix_zona_left_img = ''
        let normal_fix_zona_puls_img = ''
        let normal_fix_zona_bg_pr_right_img = ''
        let normal_battery_current_text_font = ''
        let normal_step_pointer_progress_img_pointer = ''
        let normal_step_target_text_font = ''
        let normal_step_current_text_font = ''
        let normal_temperature_icon_img = ''
        let normal_weather_image_progress_img_level = ''
        let normal_temperature_current_text_font = ''
        let normal_day_text_font = ''
        let normal_month_name_font = ''
        let normal_Month_Array = ['ЯНВ', 'ФЕВ', 'МАР', 'АПР', 'МАЙ', 'ИЮН', 'ИЮЛ', 'АВГ', 'СЕН', 'ОКТ', 'НОЯ', 'ДЕК', ];
        let normal_dow_text_font = ''
        let normal_DOW_Array = ['ПНД', 'ВТР', 'СРД', 'ЧТВ', 'ПТН', 'СБТ', 'ВСК', ];
        let normal_digital_clock_img_time = ''
        let normal_system_lock_img = ''
        let normal_system_disconnect_img = ''
        let normal_system_clock_img = ''
        let timeSensor = ''
       let normal_timerTimeUpdate = undefined;


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            // FontName: Minimalust_Small_Cap.ttf; FontSize: 24
            hmUI.createWidget(hmUI.widget.TEXT, {
              x: 464,
              y: 464,
              w: 310,
              h: 42,
              text_size: 24,
              char_space: 0,
              line_space: 0,
              font: 'fonts/Minimalust_Small_Cap.ttf',
              color: color_bg[color],
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              text: "0123456789 _-.,:;`'%°\\/",
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // FontName: Minimalust_Small_Cap.ttf; FontSize: 22
            hmUI.createWidget(hmUI.widget.TEXT, {
              x: 464,
              y: 464,
              w: 285,
              h: 38,
              text_size: 22,
              char_space: 0,
              line_space: 0,
              font: 'fonts/Minimalust_Small_Cap.ttf',
              color: 0xFF6F6F6F,
              align_h: hmUI.align.LEFT,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              text: "0123456789 _-.,:;`'%°\\/",
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // FontName: Minimalust_Small_Cap.ttf; FontSize: 66
            hmUI.createWidget(hmUI.widget.TEXT, {
              x: 464,
              y: 464,
              w: 852,
              h: 112,
              text_size: 66,
              char_space: 0,
              line_space: 0,
              font: 'fonts/Minimalust_Small_Cap.ttf',
              color: color_bg[color],
              align_h: hmUI.align.LEFT,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              text: "0123456789 _-.,:;`'%°\\/",
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // FontName: Minimalust_Small_Cap.ttf; FontSize: 24; Cache: full
            hmUI.createWidget(hmUI.widget.TEXT, {
              x: 464,
              y: 464,
              w: 28,
              h: 28,
              text_size: 24,
              char_space: 0,
              line_space: 0,
              font: 'fonts/Minimalust_Small_Cap.ttf',
              color: 0xFFFFFFFF,
              align_h: hmUI.align.LEFT,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.NONE,
              text: "0123456789 ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz АБВГДЕЁЖЗИЙКЛМНОПРСТУФХЦЧШЩЪЫЬЭЮЯабвгдеёжзийклмнопрстуфхцчшщъыьэюя  ҐЄІЇґєії _-.,:;`'%°\\/",
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
                
            hmUI.createWidget(hmUI.widget.TEXT, {
              x: 464,
              y: 464,
              w: 28,
              h: 28,
              text_size: 18,
              char_space: 0,
              line_space: 0,
              font: 'fonts/Minimalust_Small_Cap.ttf',
              color: 0xFFFFFFFF,
              align_h: hmUI.align.LEFT,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.NONE,
              text: "0123456789 ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz АБВГДЕЁЖЗИЙКЛМНОПРСТУФХЦЧШЩЪЫЬЭЮЯабвгдеёжзийклмнопрстуфхцчшщъыьэюя  ҐЄІЇґєії _-.,:;`'%°\\/",
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
                

            console.log('user_script_start.js');
            // start user_script_start.js

normal_background_bg = hmUI.createWidget(hmUI.widget.FILL_RECT, {
              x: 0,
              y: 0,
              w: 466,
              h: 466,
              color: color_bg[color],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

/*            normal_color_step_bg = hmUI.createWidget(hmUI.widget.FILL_RECT, {
              x: 333,
              y: 0,
              w: 133,
              h: 466,
              color: '0xFFbfbfbf',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });*/
            // end user_script_start.js

            console.log('Watch_Face.ScreenNormal');
                
                
            normal_fix_zona_bg_pr_right_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 432,
              y: 181,
              src: 'fix_zona_bg_pr_right.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });                 

            normal_fat_burning_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: -1,
              y: 139,
              src: 'fix_zona_bg_pr.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
                
            normal_step_pointer_progress_img_pointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
              src: 'str_pr.png',
              center_x: 233,
              center_y: 233,
              x: 60,
              y: 222,
              start_angle: 299,
              end_angle: 272,
              invalid_visible: false,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });  
                
            normal_heart_rate_pointer_progress_img_pointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
              src: 'str_pr.png',
              center_x: 233,
              center_y: 233,
              x: 60,
              y: 222,
              start_angle: 119,
              end_angle: 92,
              invalid_visible: false,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
                
            normal_WEATHER_CURRENT_pointer_progress_img_pointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
              src: 'str_pr.png',
              center_x: 233,
              center_y: 233,
              x: 60,
              y: 222,
              start_angle: 119,
              end_angle: 92,
              invalid_visible: false,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

               

            normal_image_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'bg_0.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
                
              
            normal_fix_zona_left_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: -1,
              y: 139,
              src: 'fix_zona.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });  
                
                
            normal_fix_zona_puls_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 375,
              y: 139,
              src: 'fix_zona_puls.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });  
                

            normal_battery_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: -1,
              y: 139,
              src: 'fix_step.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_current_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 0,
              y: 427,
              w: 466,
              h: 40,
              text_size: 24,
              char_space: 0,
              line_space: 0,
              font: 'fonts/Minimalust_Small_Cap.ttf',
              color: color_bg[color],
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.CENTER_V,
              unit_type: 1,
              text_style: hmUI.text_style.ELLIPSIS,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });



            normal_step_target_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 24,
              y: 275,
              w: 150,
              h: 40,
              text_size: 22,
              char_space: 0,
              line_space: 0,
              font: 'fonts/Minimalust_Small_Cap.ttf',
              color: 0xFF6F6F6F,
              align_h: hmUI.align.LEFT,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              type: hmUI.data_type.STEP_TARGET,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 24,
              y: 131,
              w: 150,
              h: 40,
              text_size: 22,
              char_space: 0,
              line_space: 0,
              font: 'fonts/Minimalust_Small_Cap.ttf',
              color: 0xFFFFFFFF,
              align_h: hmUI.align.LEFT,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 375,
              y: 139,
              src: 'fix_zona_weather.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
                
            normal_temperature_icon_img_2 = hmUI.createWidget(hmUI.widget.IMG, {
              x: 375,
              y: 139,
              src: 'fix_zona_weather_2.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
                
            normal_heart_rate_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 297,
              y: 275,
              w: 150,
              h: 40,
              text_size: 22,
              char_space: 0,
              line_space: 0,
              font: 'fonts/Minimalust_Small_Cap.ttf',
              color: color_bg[color],
              align_h: hmUI.align.RIGHT,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });                 
                

            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 383,
              y: 193,
              image_array: ["w_0.png","w_1.png","w_2.png","w_3.png","w_4.png","w_5.png","w_6.png","w_7.png","w_8.png","w_9.png","w_10.png","w_11.png","w_12.png","w_13.png","w_14.png","w_15.png","w_16.png","w_17.png","w_18.png","w_19.png","w_20.png","w_21.png","w_22.png","w_23.png","w_24.png","w_25.png","w_26.png","w_27.png","w_28.png"],
              image_length: 29,
    					auto_scale: true,
    					auto_scale_obj_fit: true,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
                
            normal_weather_image_progress_img_level_2 = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 374,
              y: 193,
              image_array: ["w2_0.png","w2_1.png","w2_2.png","w2_3.png","w2_4.png","w2_5.png","w2_6.png","w2_7.png","w2_8.png","w2_9.png","w2_10.png","w2_11.png","w2_12.png","w2_13.png","w2_14.png","w2_15.png","w2_16.png","w2_17.png","w2_18.png","w2_19.png","w2_20.png","w2_21.png","w2_22.png","w2_23.png","w2_24.png","w2_25.png","w2_26.png","w2_27.png","w2_28.png"],
              image_length: 29,
    					auto_scale: true,
    					auto_scale_obj_fit: true,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
                

            normal_temperature_current_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 347,
              y: 251,
              w: 150,
              h: 40,
              text_size: 24,
              char_space: 0,
              line_space: 0,
              font: 'fonts/Minimalust_Small_Cap.ttf',
              color: 0xFFFFFFFF,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.CENTER_V,
              unit_type: 1,
              text_style: hmUI.text_style.ELLIPSIS,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
                
            normal_temperature_low_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 303,
              y: 275,
              w: 150,
              h: 40,
              text_size: 24,
              char_space: 0,
              line_space: 0,
              font: 'fonts/Minimalust_Small_Cap.ttf',
              color: 0xFFFFFFFF,
              align_h: hmUI.align.RIGHT,
              align_v: hmUI.align.CENTER_V,
              unit_type: 1,
              text_style: hmUI.text_style.ELLIPSIS,
              type: hmUI.data_type.WEATHER_LOW,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_high_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 303,
              y: 152+2,
              w: 150,
              h: 40,
              text_size: 24,
              char_space: 0,
              line_space: 0,
              font: 'fonts/Minimalust_Small_Cap.ttf',
              color: 0xFFFFFFFF,
              align_h: hmUI.align.RIGHT,
              align_v: hmUI.align.CENTER_V,
              unit_type: 1,
              text_style: hmUI.text_style.ELLIPSIS,
              type: hmUI.data_type.WEATHER_HIGH,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
                
                normal_temperature_high_text_font_ic = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 303,
              y: 152+2-17,
              w: 150,
              h: 40,
              text: 'день',
            text_size: 18,
              char_space: 0,
              line_space: 0,
              font: 'fonts/Minimalust_Small_Cap.ttf',
              color: color_bg[color],
                align_h: hmUI.align.RIGHT,
              align_v: hmUI.align.CENTER_V,
              unit_type: 1,
              text_style: hmUI.text_style.ELLIPSIS,
             // type: hmUI.data_type.WEATHER_HIGH,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
                
            normal_temperature_low_text_font_ic = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 303,
              y: 275+17,
              w: 150,
              h: 40,
              text: 'ночь',
            text_size: 18,
              char_space: 0,
              line_space: 0,
              font: 'fonts/Minimalust_Small_Cap.ttf',
              color: color_bg[color],
              align_h: hmUI.align.RIGHT,
              align_v: hmUI.align.CENTER_V,
              unit_type: 1,
              text_style: hmUI.text_style.ELLIPSIS,
              //type: hmUI.data_type.WEATHER_LOW,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });                
                
                

            if (!timeSensor) timeSensor = hmSensor.createSensor(hmSensor.id.TIME);
            timeSensor.addEventListener(timeSensor.event.DAYCHANGE, function() {
              time_update(true);
            });

            normal_day_text_font = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 25,
              y: 180,
              w: 150,
              h: 100,
              text_size: 66,
              char_space: 0,
              line_space: 0,
              font: 'fonts/Minimalust_Small_Cap.ttf',
              color: color_bg[color],
              align_h: hmUI.align.LEFT,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              // padding: true,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_month_name_font = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 25,
              y: 255,
              w: 150,
              h: 30,
              text_size: 24,
              char_space: 0,
              line_space: 0,
              font: 'fonts/Minimalust_Small_Cap.ttf',
              color: 0xFFFFFFFF,
              align_h: hmUI.align.LEFT,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              // unit_string: ЯНВ, ФЕВ, МАР, АПР, МАЙ, ИЮН, ИЮЛ, АВГ, СЕН, ОКТ, НОЯ, ДЕК,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_dow_text_font = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 25,
              y: 173,
              w: 150,
              h: 30,
              text_size: 24,
              char_space: 0,
              line_space: 0,
              font: 'fonts/Minimalust_Small_Cap.ttf',
              color: 0xFFFFFFFF,
              align_h: hmUI.align.LEFT,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              // unit_string: ПНД, ВТР, СРД, ЧТВ, ПТН, СБТ, ВСК,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
                

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 26,
              hour_startY: -18,
              hour_array: ["H_0.png","H_1.png","H_2.png","H_3.png","H_4.png","H_5.png","H_6.png","H_7.png","H_8.png","H_9.png"],
              hour_zero: 1,
              hour_space: -122,
              hour_angle: 0,
              hour_align: hmUI.align.CENTER_H,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
                
                
                min_img_time_0 = hmUI.createWidget(hmUI.widget.IMG, {
              x: 26,
              y: 178,
              src: "c/" + color + "/M_" + parseInt(timeSensor.minute / 10)+ ".png",
              show_level: hmUI.show_level.ONLY_NORMAL,
            });                
                
                min_img_time_1 = hmUI.createWidget(hmUI.widget.IMG, {
              x: 26-122+268,
                    y: 178,
              src: "c/" + color + "/M_" + parseInt(timeSensor.minute  % 10)+ ".png",
              show_level: hmUI.show_level.ONLY_NORMAL,
            });                
                

                
                normal_stat_block_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 250,
              y: 11,
              src: 'stat_block_on.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); 
       normal_stat_block_img.setProperty(hmUI.prop.VISIBLE, false);
                
            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 221,
              y: 11,
              src: 'stat_B_off.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 193,
              y: 11,
              src: 'stat_H_on.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });



            console.log('user_script_beforeShortcuts.js');
            // start user_script_beforeShortcuts.js





bg_edit_img = hmUI.createWidget(hmUI.widget.IMG, {
 x: 0,
 y: 0,
 src: 'tap/bg_edit.png',
 show_level: hmUI.show_level.ONLY_EDIT,
});

groupVremya = hmUI.createWidget(hmUI.widget.GROUP, {
 x: 0,
 y: 0,
 w: D_W,
 h: D_H,
}); // 


groupTap = hmUI.createWidget(hmUI.widget.GROUP, {
 x: 0,
 y: 0,
 w: D_W,
 h: D_H,
});

i_tap_bg_img = groupTap.createWidget(hmUI.widget.IMG, {
 x: 0,
 y: 0,
 w: D_W,
 h: D_H,
 src: 'tap/i_tap_bg.png',
 show_level: hmUI.show_level.ONLY_NORMAL,
});


Tap_zona_0 = groupTap.createWidget(hmUI.widget.IMG, {
 x: tap_x_y[0][0],
 y: tap_x_y[0][1],
 src: apps[tap_1_select][2], //'tap/i_tap_calendar.png',
 show_level: hmUI.show_level.ONLY_NORMAL,
});

Tap_zona_1 = groupTap.createWidget(hmUI.widget.IMG, {
 x: tap_x_y[1][0],
 y: tap_x_y[1][1],
 src: apps[tap_2_select][2],
 show_level: hmUI.show_level.ONLY_NORMAL,
});

Tap_zona_2 = groupTap.createWidget(hmUI.widget.IMG, {
 x: tap_x_y[2][0],
 y: tap_x_y[2][1],
 src: apps[tap_3_select][2],
 show_level: hmUI.show_level.ONLY_NORMAL,
});

Tap_zona_3 = groupTap.createWidget(hmUI.widget.IMG, {
 x: tap_x_y[3][0],
 y: tap_x_y[3][1],
 src: apps[tap_4_select][2],
 show_level: hmUI.show_level.ONLY_NORMAL,
});

Tap_zona_4 = groupTap.createWidget(hmUI.widget.IMG, {
 x: tap_x_y[4][0],
 y: tap_x_y[4][1],
 src: apps[tap_5_select][2],
 show_level: hmUI.show_level.ONLY_NORMAL,
});

Tap_zona_5 = groupTap.createWidget(hmUI.widget.IMG, {
 x: tap_x_y[5][0],
 y: tap_x_y[5][1],
 src: apps[tap_6_select][2],
 show_level: hmUI.show_level.ONLY_NORMAL,
});


btn_Tap_zona_0 = groupTap.createWidget(hmUI.widget.BUTTON, {
 x: tap_x_y[0][0],
 y: tap_x_y[0][1],
 text: '',
 w: 113,
 h: 113,
 normal_src: '0_Empty.png',
 press_src: '0_Empty.png',
 click_func: () => {
  vibro();
  hmApp.startApp({
   url: apps[tap_1_select][1],
   native: true
  });
 },
 show_level: hmUI.show_level.ONLY_NORMAL,
});


btn_Tap_zona_1 = groupTap.createWidget(hmUI.widget.BUTTON, {
 x: tap_x_y[1][0],
 y: tap_x_y[1][1],
 text: '',
 w: 113,
 h: 113,
 normal_src: '0_Empty.png',
 press_src: '0_Empty.png',
 click_func: () => {
  vibro();
  hmApp.startApp({
   url: apps[tap_2_select][1],
   native: true
  });
 },
 show_level: hmUI.show_level.ONLY_NORMAL,
});

btn_Tap_zona_2 = groupTap.createWidget(hmUI.widget.BUTTON, {
 x: tap_x_y[2][0],
 y: tap_x_y[2][1],
 text: '',
 w: 113,
 h: 113,
 normal_src: '0_Empty.png',
 press_src: '0_Empty.png',
 click_func: () => {
  vibro();
  hmApp.startApp({
   url: apps[tap_3_select][1],
   native: true
  });
 },
 show_level: hmUI.show_level.ONLY_NORMAL,
});

btn_Tap_zona_3 = groupTap.createWidget(hmUI.widget.BUTTON, {
 x: tap_x_y[3][0],
 y: tap_x_y[3][1],
 text: '',
 w: 113,
 h: 113,
 normal_src: '0_Empty.png',
 press_src: '0_Empty.png',
 click_func: () => {
  vibro();
  hmApp.startApp({
   url: apps[tap_4_select][1],
   native: true
  });
 },
 show_level: hmUI.show_level.ONLY_NORMAL,
});

btn_Tap_zona_4 = groupTap.createWidget(hmUI.widget.BUTTON, {
 x: tap_x_y[4][0],
 y: tap_x_y[4][1],
 text: '',
 w: 113,
 h: 113,
 normal_src: '0_Empty.png',
 press_src: '0_Empty.png',
 click_func: () => {
  vibro();
  hmApp.startApp({
   url: apps[tap_5_select][1],
   native: true
  });
 },
 show_level: hmUI.show_level.ONLY_NORMAL,
});

btn_Tap_zona_5 = groupTap.createWidget(hmUI.widget.BUTTON, {
 x: tap_x_y[5][0],
 y: tap_x_y[5][1],
 text: '',
 w: 113,
 h: 113,
 normal_src: '0_Empty.png',
 press_src: '0_Empty.png',
 click_func: () => {
  vibro();
  hmApp.startApp({
   url: apps[tap_6_select][1],
   native: true
  });
 },
 show_level: hmUI.show_level.ONLY_NORMAL,
});


btn_tap = groupVremya.createWidget(hmUI.widget.BUTTON, {
 x: 183,
 y: 0,
 text: '',
 w: 100,
 h: 100,
 normal_src: '0_Empty.png',
 press_src: '0_Empty.png',
 click_func: () => {
  vibro();
  tap_run();
 },
 show_level: hmUI.show_level.ONLY_NORMAL,
});

btn_str = groupVremya.createWidget(hmUI.widget.BUTTON, {
 x: 183, //x кнопки
 y: 183, //y кнопки
 text: '',
 w: 100, //ширина кнопки
 h: 100, //высота кнопки
 normal_src: '0_Empty.png',
 press_src: '0_Empty.png',
 click_func: () => {
  vibro();
  click_Pogoda_on();
 },
 //           longpress_func: () => {
 //            vibro();
 //			   blok_btn_on();
 //           },
 show_level: hmUI.show_level.ONLY_NORMAL,
});
                
btn_zona_left = groupVremya.createWidget(hmUI.widget.BUTTON, {
 x: 0, //x кнопки
 y: 183, //y кнопки
 text: '',
 w: 100, //ширина кнопки
 h: 100, //высота кнопки
 normal_src: '0_Empty.png',
 press_src: '0_Empty.png',
 click_func: () => {
  vibro();
  click_zona_left();
 },
 //           longpress_func: () => {
 //            vibro();
 //			   blok_btn_on();
 //           },
 show_level: hmUI.show_level.ONLY_NORMAL,
});
       
                
                
btn_zona_right = groupVremya.createWidget(hmUI.widget.BUTTON, {
 x: 366, //x кнопки
 y: 183, //y кнопки
 text: '',
 w: 100, //ширина кнопки
 h: 100, //высота кнопки
 normal_src: '0_Empty.png',
 press_src: '0_Empty.png',
 click_func: () => {
  vibro();
  click_zona_right();
 },
 //           longpress_func: () => {
 //            vibro();
 //			   blok_btn_on();
 //           },
 show_level: hmUI.show_level.ONLY_NORMAL,
});  
      

        btn_block = groupVremya.createWidget(hmUI.widget.BUTTON, {
         x: 183,
         y: 366,
         text: '',
         w: 100,
         h: 100,
         normal_src: '0_Empty.png',
         press_src: '0_Empty.png',
         click_func: () => {
          vibro();
          click_blok();
         },
         show_level: hmUI.show_level.ONLY_NORMAL,
        });

        btn_raz_block = hmUI.createWidget(hmUI.widget.BUTTON, {
         x: 183,
         y: 366,
         text: '',
         w: 100,
         h: 100,
         normal_src: '0_Empty.png',
         press_src: '0_Empty.png',
         longpress_func: () => {
          vibro();
          click_zazblok();
         },
         show_level: hmUI.show_level.ONLY_NORMAL,
        });
        btn_raz_block.setProperty(hmUI.prop.VISIBLE, false);
                
                
                

btn_click_tap_exit = groupTap.createWidget(hmUI.widget.BUTTON, {
 x: 183,
 y: 183,
 text: '',
 w: 100,
 h: 100,
 normal_src: '0_Empty.png',
 press_src: '0_Empty.png',
 click_func: () => {
  vibro();
  tap_zona_exit();
 },
 show_level: hmUI.show_level.ONLY_NORMAL,
});


//---------------------------    погода
groupPogoda = hmUI.createWidget(hmUI.widget.GROUP, {
 x: 0,
 y: 20,
 w: D_W,
 h: D_H,
});

// фон
groupPogoda.createWidget(hmUI.widget.IMG, {
 x: 62,
 y: 71,
 w: 343,
 h: 323,
 src: ROOTPATH + 'Grafik/Grafik_bg.png',
 //alpha: 153,
 show_level: hmUI.show_level.ONLY_NORMAL,
});


for (var i = 0; i < 6; i++) {
 week_weater_img[i] = groupPogoda.createWidget(hmUI.widget.TEXT, {
  x: 93 + i * 46 * 1.0, //,107 + i * 45 * 1.02,
  y: 295 - 21 + 2,
  w: 50,
  h: 50,
  char_space: 0, //-1
  line_space: 0,
  color: "0xFFffffff",
  text: week_weater[i],
  text_size: 22,
  text_style: hmUI.text_style.NONE,
  align_h: hmUI.align.CENTER_H,
  align_v: hmUI.align.CENTER_V,
  show_level: hmUI.show_level.ONLY_NORMAL
 });

 hmUI.deleteWidget(day_weater_img[i]);

 day_weater_img[i] = groupPogoda.createWidget(hmUI.widget.TEXT, {
  x: 93 + i * 46 * 1.0, //,107 + i * 45 * 1.02,
  y: 295 - 21 + 2 + 20,
  w: 50,
  h: 50,
  char_space: 0, //-1
  line_space: 0,
  color: "0xFFffffff",
  text: 31,
  text_size: 22,
  text_style: hmUI.text_style.NONE,
  align_h: hmUI.align.CENTER_H,
  align_v: hmUI.align.CENTER_V,
  show_level: hmUI.show_level.ONLY_NORMAL
 });

 weatherIconImgArrayGrafik[i] = groupPogoda.createWidget(hmUI.widget.IMG, {
  x: 98 + i * 45 * 1.02,
  y: 78,
  w: 40,
  h: 40,
  // src: weatherArray[i],
  shortcut: true,
  show_level: hmUI.show_level.ONLY_NORMAL,
 });

}


for (var i = 0; i < 6; i++) {
 hmUI.deleteWidget(linered[i]);
 linered[i] = groupPogoda.createWidget(hmUI.widget.IMG);
 hmUI.deleteWidget(pointred[i]);
 pointred[i] = groupPogoda.createWidget(hmUI.widget.ARC);
 hmUI.deleteWidget(weatherTxtImgArray[i]);
 weatherTxtImgArray[i] = groupPogoda.createWidget(hmUI.widget.TEXT);
}
for (var i = 0; i < 5; i++) {
 hmUI.deleteWidget(lineblue[i]);
 lineblue[i] = groupPogoda.createWidget(hmUI.widget.IMG);
 hmUI.deleteWidget(pointblue[i]);
 pointblue[i] = groupPogoda.createWidget(hmUI.widget.ARC);
 hmUI.deleteWidget(weatherTxtImgArrayN[i]);
 weatherTxtImgArrayN[i] = groupPogoda.createWidget(hmUI.widget.TEXT);
}


btn_Pogoda_off = groupPogoda.createWidget(hmUI.widget.BUTTON, {
 x: 183, //x кнопки
 y: 183, //y кнопки
 text: '',
 w: 100, //ширина кнопки
 h: 100, //высота кнопки
 normal_src: '0_Empty.png',
 press_src: 'press_100.png',
 click_func: () => {
  vibro(); //имя вызываемой функции
  click_Pogoda_off();
 },
 //           longpress_func: () => {
 //            vibro();
 //			   blok_btn_off();
 //           },
 show_level: hmUI.show_level.ONLY_NORMAL,
});





//Button_1.setProperty(hmUI.prop.VISIBLE, false); //screen_mode

groupVremya.setProperty(hmUI.prop.VISIBLE, true);
groupTap.setProperty(hmUI.prop.VISIBLE, false);
groupPogoda.setProperty(hmUI.prop.VISIBLE, false);
                
          normal_step_pointer_progress_img_pointer.setProperty(hmUI.prop.VISIBLE, zona_left == 1);
          normal_step_target_text_font.setProperty(hmUI.prop.VISIBLE, zona_left == 1);
          normal_step_current_text_font.setProperty(hmUI.prop.VISIBLE, zona_left == 1);
          normal_battery_icon_img.setProperty(hmUI.prop.VISIBLE, zona_left == 1);
normal_fat_burning_icon_img.setProperty(hmUI.prop.VISIBLE, zona_left == 1); 
                
         normal_fix_zona_puls_img.setProperty(hmUI.prop.VISIBLE, zona_right == 1);  
normal_fix_zona_bg_pr_right_img.setProperty(hmUI.prop.VISIBLE, zona_right != 0);  
normal_heart_rate_pointer_progress_img_pointer.setProperty(hmUI.prop.VISIBLE, zona_right == 1);  
normal_heart_rate_text_font.setProperty(hmUI.prop.VISIBLE, zona_right == 1);  
                
         normal_temperature_icon_img_2.setProperty(hmUI.prop.VISIBLE, zona_right == 2);  
            normal_temperature_current_text_font.setProperty(hmUI.prop.X, zona_right == 0 ? 347:331); 
            normal_temperature_current_text_font.setProperty(hmUI.prop.Y, zona_right == 0 ? 251:240);  

normal_temperature_low_text_font.setProperty(hmUI.prop.VISIBLE, zona_right == 2);  
 normal_temperature_high_text_font.setProperty(hmUI.prop.VISIBLE, zona_right == 2);     
normal_WEATHER_CURRENT_pointer_progress_img_pointer.setProperty(hmUI.prop.VISIBLE, zona_right == 2);   
         normal_weather_image_progress_img_level_2.setProperty(hmUI.prop.VISIBLE, zona_right == 2);  
                
            normal_temperature_high_text_font_ic.setProperty(hmUI.prop.VISIBLE, zona_right == 2); 
            normal_temperature_low_text_font_ic.setProperty(hmUI.prop.VISIBLE, zona_right == 2); 

                
                
            // end user_script_beforeShortcuts.js

            let screenType = hmSetting.getScreenType();
            //start of ignored block
            function time_update(updateHour = false, updateMinute = false) {
              console.log('time_update()');
              let hour = timeSensor.hour;
              let minute = timeSensor.minute;
              let second = timeSensor.second;
              let format_hour = timeSensor.format_hour;

              console.log('day font');
              if (updateHour) {
                let normal_dayStr = timeSensor.day.toString();
                normal_dayStr = normal_dayStr.padStart(2, '0');
                normal_day_text_font.setProperty(hmUI.prop.TEXT, normal_dayStr );
              };

              console.log('month font');
              if (updateHour) {
                let normal_Month_Str = normal_Month_Array[timeSensor.month-1];
                normal_month_name_font.setProperty(hmUI.prop.TEXT, normal_Month_Str );
              };

              console.log('day of week font');
              if (updateHour) {
                let normal_DOW_Str = normal_DOW_Array[timeSensor.week-1];
                normal_dow_text_font.setProperty(hmUI.prop.TEXT, normal_DOW_Str );
              };

            };

            //end of ignored block
            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                console.log('resume_call()');
                time_update(true, true);

                console.log('resume_call.js');
                  
                min_img_time_0.setProperty(hmUI.prop.MORE, { 
              x: 26,
              y: 178,
              src: "c/" + color + "/M_" + parseInt(timeSensor.minute / 10)+ ".png",
              show_level: hmUI.show_level.ONLY_NORMAL,
            });                
                
                min_img_time_1.setProperty(hmUI.prop.MORE, { 
              x: 26-122+268,
              y: 178,
              src: "c/" + color + "/M_" + parseInt(timeSensor.minute  % 10)+ ".png",
              show_level: hmUI.show_level.ONLY_NORMAL,
            });                   
                  
                  
                  
                // start resume_call.js

stopVibro();
updateGrafik();
onDigitalCrown();
//let str_valueStep = 'ШАГИ ' + step.current
//normal_step_current_text_font.setProperty(hmUI.prop.TEXT, str_valueStep );
//idle_step_current_text_font.setProperty(hmUI.prop.TEXT, str_valueStep );
                // end resume_call.js

              }),
              pause_call: (function () {
                console.log('pause_call()');

                console.log('pause_call.js');
                // start pause_call.js

stopVibro();
             

            groupVremya.setProperty(hmUI.prop.VISIBLE, true);
           groupPogoda.setProperty(hmUI.prop.VISIBLE, false);
            groupTap.setProperty(hmUI.prop.VISIBLE, false);
                // end pause_call.js

              }),
            });

                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}