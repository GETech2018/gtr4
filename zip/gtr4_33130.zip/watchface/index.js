﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        const logger = Logger.getLogger('watchface_SashaCX75');
        //end of ignored block

        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_frame_animation_1 = ''
        let normal_system_lock_img = ''
        let normal_system_dnd_img = ''
        let normal_system_disconnect_img = ''
        let normal_system_clock_img = ''
        let normal_date_img_date_year = ''
        let normal_date_img_date_month = ''
        let normal_date_month_separator_img = ''
        let normal_date_img_date_day = ''
        let normal_date_day_separator_img = ''
        let normal_digital_clock_img_time = ''
        let normal_digital_clock_hour_separator_img = ''
        let idle_background_bg = ''
        let idle_system_lock_img = ''
        let idle_system_dnd_img = ''
        let idle_system_disconnect_img = ''
        let idle_system_clock_img = ''
        let idle_date_img_date_year = ''
        let idle_date_img_date_month = ''
        let idle_date_month_separator_img = ''
        let idle_date_img_date_day = ''
        let idle_date_day_separator_img = ''
        let idle_digital_clock_img_time = ''
        let idle_digital_clock_hour_separator_img = ''
        let normal_alarm_jumpable_img_click = ''
        let normal_altimeter_jumpable_img_click = ''
        let normal_stress_jumpable_img_click = ''
        let normal_pai_jumpable_img_click = ''
        let normal_spo2_jumpable_img_click = ''
		let normal_anim_h='';
		let normal_anim_h_group='';
		let anim_f=10;
		let fps_s=30;
		
		let batteryInfo_click = ''

        
        const battery = hmSensor.createSensor(hmSensor.id.BATTERY);
      
        const step = hmSensor.createSensor(hmSensor.id.STEP);
		
		const distance = hmSensor.createSensor(hmSensor.id.DISTANCE);
		
		const calorie = hmSensor.createSensor(hmSensor.id.CALORIE);
		
	    const heart_rate = hmSensor.createSensor(hmSensor.id.HEART);
		
		const stand = hmSensor.createSensor(hmSensor.id.STAND);
		
		const fatburn = hmSensor.createSensor(hmSensor.id.FAT_BURNING);
		
		let valueBattery = ''
        let valueStep = ''
		let valueDistance = ''
		let valueCalorie = ''
		let valueHeart_rate = ''
	    let valueStand = ''
		let valueFatburn = ''


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 466,
              h: 466,
              src: 'bg.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_frame_animation_1 = hmUI.createWidget(hmUI.widget.IMG_ANIM, {
              x: 0,
              y: 0,
              anim_path: "animation",
              anim_ext: "png",
              anim_prefix: "heart",
              anim_fps: 15,
              anim_size: 6,
              repeat_count: 0,
              anim_repeat: true,
              anim_status:hmUI.anim_status.START,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_lock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 216,
              y: 435,
              src: '0075.png',
              type: hmUI.system_status.LOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_dnd_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 422,
              y: 216,
              src: '0077.png',
              type: hmUI.system_status.DISTURB,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 217,
              y: 147,
              src: '0074.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 11,
              y: 216,
              src: '0076.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_year = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              year_startX: 250,
              year_startY: 123,
              year_sc_array: ["0043.png","0044.png","0045.png","0046.png","0047.png","0048.png","0049.png","0050.png","0051.png","0052.png"],
              year_tc_array: ["0043.png","0044.png","0045.png","0046.png","0047.png","0048.png","0049.png","0050.png","0051.png","0052.png"],
              year_en_array: ["0043.png","0044.png","0045.png","0046.png","0047.png","0048.png","0049.png","0050.png","0051.png","0052.png"],
              year_zero: 1,
              year_space: 0,
              year_align: hmUI.align.LEFT,
              year_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_month = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 213,
              month_startY: 123,
              month_sc_array: ["0043.png","0044.png","0045.png","0046.png","0047.png","0048.png","0049.png","0050.png","0051.png","0052.png"],
              month_tc_array: ["0043.png","0044.png","0045.png","0046.png","0047.png","0048.png","0049.png","0050.png","0051.png","0052.png"],
              month_en_array: ["0043.png","0044.png","0045.png","0046.png","0047.png","0048.png","0049.png","0050.png","0051.png","0052.png"],
              month_zero: 1,
              month_space: 0,
              month_align: hmUI.align.LEFT,
              month_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_month_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 241,
              y: 123,
              src: '0053.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 172,
              day_startY: 123,
              day_sc_array: ["0043.png","0044.png","0045.png","0046.png","0047.png","0048.png","0049.png","0050.png","0051.png","0052.png"],
              day_tc_array: ["0043.png","0044.png","0045.png","0046.png","0047.png","0048.png","0049.png","0050.png","0051.png","0052.png"],
              day_en_array: ["0043.png","0044.png","0045.png","0046.png","0047.png","0048.png","0049.png","0050.png","0051.png","0052.png"],
              day_zero: 1,
              day_space: 0,
              day_align: hmUI.align.LEFT,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_day_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 203,
              y: 123,
              src: '0053.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 60,
              hour_startY: 170,
              hour_array: ["0004.png","0005.png","0006.png","0007.png","0008.png","0009.png","0010.png","0011.png","0012.png","0013.png"],
              hour_zero: 1,
              hour_space: 0,
              hour_align: hmUI.align.LEFT,

              minute_startX: 261,
              minute_startY: 170,
              minute_array: ["0004.png","0005.png","0006.png","0007.png","0008.png","0009.png","0010.png","0011.png","0012.png","0013.png"],
              minute_zero: 1,
              minute_space: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_hour_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 223,
              y: 197,
              src: '0015.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            idle_background_bg = hmUI.createWidget(hmUI.widget.FILL_RECT, {
              x: 0,
              y: 0,
              w: 466,
              h: 466,
              color: '0xFF000000',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_system_lock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 220,
              y: 319,
              src: '0075.png',
              type: hmUI.system_status.LOCK,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_system_dnd_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 311,
              y: 319,
              src: '0077.png',
              type: hmUI.system_status.DISTURB,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 217,
              y: 147,
              src: '0074.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 123,
              y: 319,
              src: '0076.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_year = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              year_startX: 250,
              year_startY: 123,
              year_sc_array: ["0043.png","0044.png","0045.png","0046.png","0047.png","0048.png","0049.png","0050.png","0051.png","0052.png"],
              year_tc_array: ["0043.png","0044.png","0045.png","0046.png","0047.png","0048.png","0049.png","0050.png","0051.png","0052.png"],
              year_en_array: ["0043.png","0044.png","0045.png","0046.png","0047.png","0048.png","0049.png","0050.png","0051.png","0052.png"],
              year_zero: 1,
              year_space: 0,
              year_align: hmUI.align.LEFT,
              year_is_character: false,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_month = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 213,
              month_startY: 123,
              month_sc_array: ["0043.png","0044.png","0045.png","0046.png","0047.png","0048.png","0049.png","0050.png","0051.png","0052.png"],
              month_tc_array: ["0043.png","0044.png","0045.png","0046.png","0047.png","0048.png","0049.png","0050.png","0051.png","0052.png"],
              month_en_array: ["0043.png","0044.png","0045.png","0046.png","0047.png","0048.png","0049.png","0050.png","0051.png","0052.png"],
              month_zero: 1,
              month_space: 0,
              month_align: hmUI.align.LEFT,
              month_is_character: false,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_month_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 241,
              y: 123,
              src: '0053.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 172,
              day_startY: 123,
              day_sc_array: ["0043.png","0044.png","0045.png","0046.png","0047.png","0048.png","0049.png","0050.png","0051.png","0052.png"],
              day_tc_array: ["0043.png","0044.png","0045.png","0046.png","0047.png","0048.png","0049.png","0050.png","0051.png","0052.png"],
              day_en_array: ["0043.png","0044.png","0045.png","0046.png","0047.png","0048.png","0049.png","0050.png","0051.png","0052.png"],
              day_zero: 1,
              day_space: 0,
              day_align: hmUI.align.LEFT,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_day_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 203,
              y: 123,
              src: '0053.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 60,
              hour_startY: 170,
              hour_array: ["0004.png","0005.png","0006.png","0007.png","0008.png","0009.png","0010.png","0011.png","0012.png","0013.png"],
              hour_zero: 1,
              hour_space: 0,
              hour_align: hmUI.align.LEFT,

              minute_startX: 261,
              minute_startY: 170,
              minute_array: ["0004.png","0005.png","0006.png","0007.png","0008.png","0009.png","0010.png","0011.png","0012.png","0013.png"],
              minute_zero: 1,
              minute_space: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_hour_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 223,
              y: 197,
              src: '0015.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });
			
			function get_values (){
              valueBattery = battery.current; 
              valueStep = step.current;
			  valueDistance = distance.current;
			  valueCalorie = calorie.current;
			  valueHeart = heart_rate.last;
		      valueStand = stand.current;
			  valueFatburn = fatburn.current;
			}

			get_values ();
			
			battery.addEventListener(hmSensor.event.CHANGE, function () {
              get_values();
            });

            step.addEventListener(hmSensor.event.CHANGE, function () {
              get_values();
            });
			
			distance.addEventListener(hmSensor.event.CHANGE, function () {
              get_values();
            });
			
			calorie.addEventListener(hmSensor.event.CHANGE, function () {
              get_values();
            });
			
			heart_rate.addEventListener(hmSensor.event.CHANGE, function () {
              get_values();
            });
		
		    stand.addEventListener(hmSensor.event.CHANGE, function () {
              get_values();
            });
			
			fatburn.addEventListener(hmSensor.event.CHANGE, function () {
              get_values();
            });
			  
            
            // disconnectAlert = hmUI.createWidget(hmUI.widget.DisconnectAlert, {
              // disconneсnt_vibrate_type: 9,
              // disconneсnt_toast_text: Connect LOST,
              // conneсnt_vibrate_type: 0,
              // conneсnt_toast_text: Connect FIND,
            // });

            // vibration when connecting or disconnecting

            function checkConnection() {
              hmBle.removeListener;
              hmBle.addListener(function (status) {
                if(!status) {
                  hmUI.showToast({text: "Connect LOST"});
                  vibro(9);
                }
                if(status) {
                  hmUI.showToast({text: "Connect FIND"});
                  vibro(0);
                }
              });
            }

            // end vibration when connecting or disconnecting
            // vibrate function

            const vibrate = hmSensor.createSensor(hmSensor.id.VIBRATE);
            let timer_StopVibrate = null;


            function vibro(scene = 25) {
              let stopDelay = 50;
              stopVibro();
              vibrate.stop();
              vibrate.scene = scene;
              if(scene < 23 || scene > 25) stopDelay = 1300;
              vibrate.start();
              timer_StopVibrate = timer.createTimer(stopDelay, 3000, stopVibro, {});
            }

            function stopVibro(){
              vibrate.stop();
              if(timer_StopVibrate) timer.stopTimer(timer_StopVibrate);
            }

            // end vibrate function

            //настройки
			hmUI.createWidget(hmUI.widget.BUTTON, {
				 x: 294,        // координата кнопки X
				 y: 304,      // координата кнопки Y
				 w: 45,       // ширина кнопки
				 h: 45,      // высота кнопки
				 text: '',      // здесь можно написать текст, который будет на кнопке
				 normal_src: 'Empty.png',         // картинка кнопки, тут пустая
				 press_src: 'Empty.png', 
				 click_func: () => {
				hmApp.startApp({ url: 'Settings_homeScreen', native: true });         // вот тут вызывается нужное приложение
				 },
				 show_level: hmUI.show_level.ONLY_NORMAL,
			});		

            //календарь
			hmUI.createWidget(hmUI.widget.BUTTON, {
				 x: 211,        // координата кнопки X
				 y: 304,      // координата кнопки Y
				 w: 75,       // ширина кнопки
				 h: 180,      // высота кнопки
				 text: '',      // здесь можно написать текст, который будет на кнопке
				 normal_src: 'Empty.png',         // картинка кнопки, тут пустая
				 press_src: 'Empty.png', 
				 click_func: () => {
				hmApp.startApp({ url: 'ScheduleCalScreen', native: true });         // вот тут вызывается нужное приложение
				 },
				 show_level: hmUI.show_level.ONLY_NORMAL,
			});		

            //звонки
			hmUI.createWidget(hmUI.widget.BUTTON, {
				 x: 129,        // координата кнопки X
				 y: 303,      // координата кнопки Y
				 w: 45,       // ширина кнопки
				 h: 45,      // высота кнопки
				 text: '',      // здесь можно написать текст, который будет на кнопке
				 normal_src: 'blank.png',         // картинка кнопки, тут пустая
				 press_src: 'blank.png', 
				 click_func: () => {
				hmApp.startApp({ url: 'PhoneRecentCallScreen', native: true });         // вот тут вызывается нужное приложение
				 },
				 show_level: hmUI.show_level.ONLY_NORMAL,
			});		

            batteryInfo_click = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 160,
              y: 358,
              w: 150,
              h: 45,
              text: '',
              normal_src: 'Empty.png',
              press_src: 'Empty.png',
              click_func: () => {
                hmUI.showToast({ text: 'Step is' + valueStep + '' + '\n' + 'Distance is' + valueDistance + 'km' + '\n' + 'Calorie is' + valueCalorie + 'cal' });
              },
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            stressInfo_click = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 159,
              y: 62,
              w: 150,
              h: 45,
              text: '',
              normal_src: 'Empty.png',
              press_src: 'Empty.png',
              click_func: () => {
                hmUI.showToast({ text: 'Heart is' + valueHeart + 'bpm' + '\n' + 'Stand is'   + valueStand + '' + '\n' + 'Fatburn is' + valueFatburn +   'm' });
              },
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
			
			let anim_sz=10;
			
			
			function animation_call(){
				if(typeof normal_anim_h !== 'string'){
					hmUI.deleteWidget(normal_anim_h);
				}	
							
				if (hmSetting.getScreenType() != hmSetting.screen_type.AOD) {

					if(!isNaN(heart_rate.last) && heart_rate.last > 10){
						anim_sz=Math.ceil(30/(heart_rate.last/60));
					}else{
						anim_sz=20;
					}

					normal_anim_h = hmUI.createWidget(hmUI.widget.IMG_ANIM, {
						  anim_path: 'animation',
						  anim_prefix: 'heart',
						  anim_ext: 'png',
						  anim_fps: Math.ceil(heart_rate.last/10),//6,//30,
						  repeat_count: 0,
						  anim_size: 6,//anim_sz,
						  anim_status: hmUI.anim_status.START,
						  anim_repeat: true,
						  x: 220,//0,
						  y: 14,//0,
						  show_level: hmUI.show_level.ONLY_NORMAL,
						});	
//					normal_anim_h.setProperty(hmUI.prop.ANIM_STATUS, hmUI.anim_status.START);					
				}
			}

            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                normal_frame_animation_1.setProperty(hmUI.prop.ANIM_STATUS,hmUI.anim_status.START);
				animation_call();
                checkConnection();
                stopVibro();

              }),
              pause_call: (function () {
                normal_frame_animation_1.setProperty(hmUI.prop.ANIM_STATUS,hmUI.anim_status.STOP);
                stopVibro();

              }),
            });

                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}