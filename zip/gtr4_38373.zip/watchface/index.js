﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        const logger = Logger.getLogger('watchface_SashaCX75');
        //end of ignored block

        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_system_disconnect_img = ''
        let normal_system_clock_img = ''
        let normal_date_img_date_day = ''
        let normal_date_img_date_week_img = ''
        let normal_heart_rate_linear_scale = ''
        let normal_heart_rate_linear_scale_pointer_img = ''
        let normal_heart_rate_text_text_img = ''
        let normal_step_TextRotate = new Array(5);
        let normal_step_TextRotate_ASCIIARRAY = new Array(10);
        let normal_step_TextRotate_img_width = 25;
        let normal_battery_TextRotate = new Array(3);
        let normal_battery_TextRotate_ASCIIARRAY = new Array(10);
        let normal_battery_TextRotate_img_width = 25;
        let normal_digital_clock_img_time = ''
        let normal_analog_clock_time_pointer_second = ''
        let idle_system_disconnect_img = ''
        let idle_system_clock_img = ''
        let idle_date_img_date_day = ''
        let idle_date_img_date_week_img = ''
        let idle_battery_icon_img = ''
        let idle_battery_TextRotate = new Array(3);
        let idle_battery_TextRotate_ASCIIARRAY = new Array(10);
        let idle_battery_TextRotate_img_width = 25;
        let idle_digital_clock_img_time = ''
        let idle_digital_clock_minute_separator_img = ''
        let idle_analog_clock_time_pointer_second = ''
        let normal_alarm_jumpable_img_click = ''
        let normal_heart_jumpable_img_click = ''
        let normal_step_jumpable_img_click = ''
        let Button_1 = ''
        let Button_2 = ''


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            console.log('Watch_Face.ScreenNormal');
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 466,
              h: 466,
              src: '00.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 308,
              y: 407,
              src: 'bt9.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 124,
              y: 403,
              src: 'alar7.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 214,
              day_startY: 0,
              day_sc_array: ["s0.png","s1.png","s2.png","s3.png","s4.png","s5.png","s6.png","s7.png","s8.png","s9.png"],
              day_tc_array: ["s0.png","s1.png","s2.png","s3.png","s4.png","s5.png","s6.png","s7.png","s8.png","s9.png"],
              day_en_array: ["s0.png","s1.png","s2.png","s3.png","s4.png","s5.png","s6.png","s7.png","s8.png","s9.png"],
              day_zero: 1,
              day_space: 0,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 126,
              y: 28,
              week_en: ["D1.png","d2.png","d3.png","d4.png","d5.png","d6.png","d7.png"],
              week_tc: ["D1.png","d2.png","d3.png","d4.png","d5.png","d6.png","d7.png"],
              week_sc: ["D1.png","d2.png","d3.png","d4.png","d5.png","d6.png","d7.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            let screenType = hmSetting.getScreenType();
            if (screenType != hmSetting.screen_type.AOD) {
              normal_heart_rate_linear_scale = hmUI.createWidget(hmUI.widget.FILL_RECT);
            };

            normal_heart_rate_linear_scale_pointer_img = hmUI.createWidget(hmUI.widget.IMG);
            // normal_heart_rate_linear_scale = hmUI.createWidget(hmUI.widget.Linear_Scale, {
              // start_x: 173,
              // start_y: 435,
              // color: 0xFFFF0000,
              // pointer: 'BPM.png',
              // lenght: 121,
              // line_width: 3,
              // line_cap: Flat,
              // vertical: False,
              // mirror: False,
              // inversion: False,
              // type: hmUI.data_type.HEART,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });
            
            const heart_rate = hmSensor.createSensor(hmSensor.id.HEART);
            heart_rate.addEventListener(hmSensor.event.CHANGE, function() {
              scale_call();
            });

            normal_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 195,
              y: 365,
              font_array: ["X0.png","X1.png","X2.png","X3.png","X4.png","X5.png","X6.png","X7.png","X8.png","X9.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_step_text_rotate_img = hmUI.createWidget(hmUI.widget.Text_Rotate, {
              // x: 69,
              // y: 234,
              // font_array: ["X0.png","X1.png","X2.png","X3.png","X4.png","X5.png","X6.png","X7.png","X8.png","X9.png"],
              // zero: false,
              // unit_in_alignment: false,
              // h_space: 0,
              // angle: 90,
              // align_h: hmUI.align.CENTER_H,
              // type: hmUI.data_type.STEP,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_step_TextRotate_ASCIIARRAY[0] = 'X0.png';  // set of images with numbers
            normal_step_TextRotate_ASCIIARRAY[1] = 'X1.png';  // set of images with numbers
            normal_step_TextRotate_ASCIIARRAY[2] = 'X2.png';  // set of images with numbers
            normal_step_TextRotate_ASCIIARRAY[3] = 'X3.png';  // set of images with numbers
            normal_step_TextRotate_ASCIIARRAY[4] = 'X4.png';  // set of images with numbers
            normal_step_TextRotate_ASCIIARRAY[5] = 'X5.png';  // set of images with numbers
            normal_step_TextRotate_ASCIIARRAY[6] = 'X6.png';  // set of images with numbers
            normal_step_TextRotate_ASCIIARRAY[7] = 'X7.png';  // set of images with numbers
            normal_step_TextRotate_ASCIIARRAY[8] = 'X8.png';  // set of images with numbers
            normal_step_TextRotate_ASCIIARRAY[9] = 'X9.png';  // set of images with numbers

            //start of ignored block
            for (let i = 0; i < 5; i++) {
              normal_step_TextRotate[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 466,
                h: 466,
                center_x: 69,
                center_y: 234,
                pos_x: 69,
                pos_y: 234,
                angle: 90,
                src: 'X0.png',
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
              normal_step_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
            };
            //end of ignored block
            
            const step = hmSensor.createSensor(hmSensor.id.STEP);
            step.addEventListener(hmSensor.event.CHANGE, function() {
              text_update();
            });

            // normal_battery_text_rotate_img = hmUI.createWidget(hmUI.widget.Text_Rotate, {
              // x: 394,
              // y: 234,
              // font_array: ["X0.png","X1.png","X2.png","X3.png","X4.png","X5.png","X6.png","X7.png","X8.png","X9.png"],
              // zero: false,
              // unit_in_alignment: false,
              // h_space: 0,
              // angle: -90,
              // align_h: hmUI.align.CENTER_H,
              // type: hmUI.data_type.BATTERY,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_battery_TextRotate_ASCIIARRAY[0] = 'X0.png';  // set of images with numbers
            normal_battery_TextRotate_ASCIIARRAY[1] = 'X1.png';  // set of images with numbers
            normal_battery_TextRotate_ASCIIARRAY[2] = 'X2.png';  // set of images with numbers
            normal_battery_TextRotate_ASCIIARRAY[3] = 'X3.png';  // set of images with numbers
            normal_battery_TextRotate_ASCIIARRAY[4] = 'X4.png';  // set of images with numbers
            normal_battery_TextRotate_ASCIIARRAY[5] = 'X5.png';  // set of images with numbers
            normal_battery_TextRotate_ASCIIARRAY[6] = 'X6.png';  // set of images with numbers
            normal_battery_TextRotate_ASCIIARRAY[7] = 'X7.png';  // set of images with numbers
            normal_battery_TextRotate_ASCIIARRAY[8] = 'X8.png';  // set of images with numbers
            normal_battery_TextRotate_ASCIIARRAY[9] = 'X9.png';  // set of images with numbers

            //start of ignored block
            for (let i = 0; i < 3; i++) {
              normal_battery_TextRotate[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 466,
                h: 466,
                center_x: 394,
                center_y: 234,
                pos_x: 394,
                pos_y: 234,
                angle: -90,
                src: 'X0.png',
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
              normal_battery_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
            };
            //end of ignored block
            
            const battery = hmSensor.createSensor(hmSensor.id.BATTERY);
            battery.addEventListener(hmSensor.event.CHANGE, function() {
              text_update();
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 120,
              hour_startY: 66,
              hour_array: ["dig_0.png","dig_1.png","dig_2.png","dig_3.png","dig_4.png","dig_5.png","dig_6.png","dig_7.png","dig_8.png","dig_9.png"],
              hour_zero: 1,
              hour_space: 22,
              hour_angle: 0,
              hour_align: hmUI.align.CENTER_H,

              minute_startX: 119,
              minute_startY: 214,
              minute_array: ["0.png","1.png","2.png","3.png","4.png","5.png","6.png","7.png","8.png","9.png"],
              minute_zero: 1,
              minute_space: 22,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.CENTER_H,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_second = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              second_path: 'direc.png',
              second_centerX: 233,
              second_centerY: 233,
              second_posX: 10,
              second_posY: 233,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            console.log('Watch_Face.ScreenAOD');

            idle_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 308,
              y: 407,
              src: 'bt9.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 124,
              y: 403,
              src: 'alar7.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 214,
              day_startY: 0,
              day_sc_array: ["s0.png","s1.png","s2.png","s3.png","s4.png","s5.png","s6.png","s7.png","s8.png","s9.png"],
              day_tc_array: ["s0.png","s1.png","s2.png","s3.png","s4.png","s5.png","s6.png","s7.png","s8.png","s9.png"],
              day_en_array: ["s0.png","s1.png","s2.png","s3.png","s4.png","s5.png","s6.png","s7.png","s8.png","s9.png"],
              day_zero: 1,
              day_space: 0,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 126,
              y: 28,
              week_en: ["D1.png","d2.png","d3.png","d4.png","d5.png","d6.png","d7.png"],
              week_tc: ["D1.png","d2.png","d3.png","d4.png","d5.png","d6.png","d7.png"],
              week_sc: ["D1.png","d2.png","d3.png","d4.png","d5.png","d6.png","d7.png"],
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_battery_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 202,
              y: 371,
              src: 'Icon.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            // idle_battery_text_rotate_img = hmUI.createWidget(hmUI.widget.Text_Rotate, {
              // x: 225,
              // y: 426,
              // font_array: ["X0.png","X1.png","X2.png","X3.png","X4.png","X5.png","X6.png","X7.png","X8.png","X9.png"],
              // zero: false,
              // unit_in_alignment: false,
              // h_space: 0,
              // angle: 0,
              // align_h: hmUI.align.CENTER_H,
              // type: hmUI.data_type.BATTERY,
              // show_level: hmUI.show_level.ONLY_AOD,
            // });

            idle_battery_TextRotate_ASCIIARRAY[0] = 'X0.png';  // set of images with numbers
            idle_battery_TextRotate_ASCIIARRAY[1] = 'X1.png';  // set of images with numbers
            idle_battery_TextRotate_ASCIIARRAY[2] = 'X2.png';  // set of images with numbers
            idle_battery_TextRotate_ASCIIARRAY[3] = 'X3.png';  // set of images with numbers
            idle_battery_TextRotate_ASCIIARRAY[4] = 'X4.png';  // set of images with numbers
            idle_battery_TextRotate_ASCIIARRAY[5] = 'X5.png';  // set of images with numbers
            idle_battery_TextRotate_ASCIIARRAY[6] = 'X6.png';  // set of images with numbers
            idle_battery_TextRotate_ASCIIARRAY[7] = 'X7.png';  // set of images with numbers
            idle_battery_TextRotate_ASCIIARRAY[8] = 'X8.png';  // set of images with numbers
            idle_battery_TextRotate_ASCIIARRAY[9] = 'X9.png';  // set of images with numbers

            //start of ignored block
            for (let i = 0; i < 3; i++) {
              idle_battery_TextRotate[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 466,
                h: 466,
                center_x: 225,
                center_y: 426,
                pos_x: 225,
                pos_y: 426,
                angle: 0,
                src: 'X0.png',
                show_level: hmUI.show_level.ONLY_AOD,
              });
              idle_battery_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
            };
            //end of ignored block

            idle_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 120,
              hour_startY: 66,
              hour_array: ["0.png","1.png","2.png","3.png","4.png","5.png","6.png","7.png","8.png","9.png"],
              hour_zero: 1,
              hour_space: 22,
              hour_angle: 0,
              hour_align: hmUI.align.CENTER_H,

              minute_startX: 119,
              minute_startY: 214,
              minute_array: ["0.png","1.png","2.png","3.png","4.png","5.png","6.png","7.png","8.png","9.png"],
              minute_zero: 1,
              minute_space: 22,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.CENTER_H,

              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_minute_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'sharp.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_analog_clock_time_pointer_second = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              second_path: 'direc.png',
              second_centerX: 233,
              second_centerY: 233,
              second_posX: 10,
              second_posY: 233,
              show_level: hmUI.show_level.ONLY_AOD,
            });
            console.log('Watch_Face.Shortcuts');

            normal_alarm_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 115,
              y: 398,
              w: 50,
              h: 50,
              type: hmUI.data_type.ALARM_CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 169,
              y: 368,
              w: 125,
              h: 100,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 3,
              y: 185,
              w: 70,
              h: 100,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            console.log('Watch_Face.Buttons');
            Button_1 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 149,
              y: 3,
              w: 182,
              h: 64,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'transparent.png',
              normal_src: 'transparent.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'ScheduleCalScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_2 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 389,
              y: 174,
              w: 100,
              h: 118,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'transparent.png',
              normal_src: 'transparent.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'PowerSaveHintScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            function text_update() {
              console.log('text_update()');

              console.log('update text rotate step_STEP');
              let valueStep = step.current;
              let normal_step_rotate_string = parseInt(valueStep).toString();

              if (screenType != hmSetting.screen_type.AOD) {
                for (var i = 1; i < 5; i++) {  // hide all symbols
                  normal_step_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                if (valueStep != null && valueStep != undefined && isFinite(valueStep) && normal_step_rotate_string.length > 0 && normal_step_rotate_string.length < 6) {  // display data if it was possible to get it
                  let img_offset = 0;
                  // alignment = CENTER_H
                  let normal_step_TextRotate_posOffset = normal_step_TextRotate_img_width * normal_step_rotate_string.length;
                  img_offset -= normal_step_TextRotate_posOffset/2;
                  // alignment end
                  
                  let index = 0;
                  for (let char of normal_step_rotate_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 5) break;
                    if (charCode >= 0 && charCode < 10) { 
                      normal_step_TextRotate[index].setProperty(hmUI.prop.POS_X, 69 + img_offset);
                      normal_step_TextRotate[index].setProperty(hmUI.prop.SRC, normal_step_TextRotate_ASCIIARRAY[charCode]);
                      normal_step_TextRotate[index].setProperty(hmUI.prop.VISIBLE, true);
                      img_offset += normal_step_TextRotate_img_width;
                      index++;
                    };  // end if digit
                  };  // end char of string
                }  // end isFinite

              };

              console.log('update text rotate battery_BATTERY');
              let valueBattery = battery.current;
              let normal_battery_rotate_string = parseInt(valueBattery).toString();

              if (screenType != hmSetting.screen_type.AOD) {
                for (var i = 1; i < 3; i++) {  // hide all symbols
                  normal_battery_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                if (valueBattery != null && valueBattery != undefined && isFinite(valueBattery) && normal_battery_rotate_string.length > 0 && normal_battery_rotate_string.length < 6) {  // display data if it was possible to get it
                  let img_offset = 0;
                  // alignment = CENTER_H
                  let normal_battery_TextRotate_posOffset = normal_battery_TextRotate_img_width * normal_battery_rotate_string.length;
                  img_offset -= normal_battery_TextRotate_posOffset/2;
                  // alignment end
                  
                  let index = 0;
                  for (let char of normal_battery_rotate_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 3) break;
                    if (charCode >= 0 && charCode < 10) { 
                      normal_battery_TextRotate[index].setProperty(hmUI.prop.POS_X, 394 + img_offset);
                      normal_battery_TextRotate[index].setProperty(hmUI.prop.SRC, normal_battery_TextRotate_ASCIIARRAY[charCode]);
                      normal_battery_TextRotate[index].setProperty(hmUI.prop.VISIBLE, true);
                      img_offset += normal_battery_TextRotate_img_width;
                      index++;
                    };  // end if digit
                  };  // end char of string
                }  // end isFinite

              };

              console.log('update text rotate battery_BATTERY');
              let idle_battery_rotate_string = parseInt(valueBattery).toString();

              if (screenType == hmSetting.screen_type.AOD) {
                for (var i = 1; i < 3; i++) {  // hide all symbols
                  idle_battery_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                if (valueBattery != null && valueBattery != undefined && isFinite(valueBattery) && idle_battery_rotate_string.length > 0 && idle_battery_rotate_string.length < 6) {  // display data if it was possible to get it
                  let img_offset = 0;
                  // alignment = CENTER_H
                  let idle_battery_TextRotate_posOffset = idle_battery_TextRotate_img_width * idle_battery_rotate_string.length;
                  img_offset -= idle_battery_TextRotate_posOffset/2;
                  // alignment end
                  
                  let index = 0;
                  for (let char of idle_battery_rotate_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 3) break;
                    if (charCode >= 0 && charCode < 10) { 
                      idle_battery_TextRotate[index].setProperty(hmUI.prop.POS_X, 225 + img_offset);
                      idle_battery_TextRotate[index].setProperty(hmUI.prop.SRC, idle_battery_TextRotate_ASCIIARRAY[charCode]);
                      idle_battery_TextRotate[index].setProperty(hmUI.prop.VISIBLE, true);
                      img_offset += idle_battery_TextRotate_img_width;
                      index++;
                    };  // end if digit
                  };  // end char of string
                }  // end isFinite

              };

            };

            function scale_call() {
              console.log('scale_call()');

                console.log('update scales HEART');
                
                let valueHeartRate = heart_rate.last;
                let targetHeartRate = 179;
                let progressHeartRate = (valueHeartRate - 71)/(targetHeartRate - 71);
                if (progressHeartRate < 0) progressHeartRate = 0;
                if (progressHeartRate > 1) progressHeartRate = 1;
                let progress_ls_normal_heart_rate = progressHeartRate;

                if (screenType != hmSetting.screen_type.AOD) {

                  // normal_heart_rate_linear_scale
                  // initial parameters
                  let start_x_normal_heart_rate = 173;
                  let start_y_normal_heart_rate = 435;
                  let lenght_ls_normal_heart_rate = 121;
                  let line_width_ls_normal_heart_rate = 3;
                  let color_ls_normal_heart_rate = 0xFFFF0000;
                  
                  // calculated parameters
                  let start_x_normal_heart_rate_draw = start_x_normal_heart_rate;
                  let start_y_normal_heart_rate_draw = start_y_normal_heart_rate;
                  lenght_ls_normal_heart_rate = lenght_ls_normal_heart_rate * progress_ls_normal_heart_rate;
                  let lenght_ls_normal_heart_rate_draw = lenght_ls_normal_heart_rate;
                  let line_width_ls_normal_heart_rate_draw = line_width_ls_normal_heart_rate;
                  if (lenght_ls_normal_heart_rate < 0){
                    lenght_ls_normal_heart_rate_draw = -lenght_ls_normal_heart_rate;
                    start_x_normal_heart_rate_draw = start_x_normal_heart_rate - lenght_ls_normal_heart_rate_draw;
                  };
                  
                  normal_heart_rate_linear_scale.setProperty(hmUI.prop.MORE, {
                    x: start_x_normal_heart_rate_draw,
                    y: start_y_normal_heart_rate_draw,
                    w: lenght_ls_normal_heart_rate_draw,
                    h: line_width_ls_normal_heart_rate_draw,
                    color: color_ls_normal_heart_rate,
                  });
                  
                  // pointers parameters
                  let pointer_offset_x_ls_normal_heart_rate = 100;
                  let pointer_offset_y_ls_normal_heart_rate = 36;
                  normal_heart_rate_linear_scale_pointer_img.setProperty(hmUI.prop.MORE, {
                    x: start_x_normal_heart_rate + lenght_ls_normal_heart_rate - pointer_offset_x_ls_normal_heart_rate,
                    y: start_y_normal_heart_rate_draw + line_width_ls_normal_heart_rate / 2 - pointer_offset_y_ls_normal_heart_rate,
                    src: 'BPM.png',
                    show_level: hmUI.show_level.ONLY_NORMAL,
                  });
                };

            };

            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                console.log('resume_call()');
                scale_call();
                text_update();
              }),
            });

                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}