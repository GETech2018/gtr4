﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        const logger = Logger.getLogger('watchface_SashaCX75');
        //end of ignored block

        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_temperature_high_text_img = ''
        let normal_temperature_high_separator_img = ''
        let normal_temperature_low_text_img = ''
        let normal_temperature_low_separator_img = ''
        let normal_temperature_current_text_img = ''
        let normal_step_icon_img = ''
        let normal_step_current_text_img = ''
        let normal_step_current_separator_img = ''
        let normal_step_image_progress_img_level = ''
        let normal_altimeter_icon_img = ''
        let normal_altitude_target_text_img = ''
        let normal_compass_text_img = ''
        let normal_compass_separator_img = ''
        let normal_compass_direction_pointer_img = ''
        let normal_system_lock_img = ''
        let normal_system_disconnect_img = ''
        let normal_system_clock_img = ''
        let normal_battery_text_text_img = ''
        let normal_battery_image_progress_img_level = ''
        let normal_digital_clock_img_time_AmPm = ''
        let normal_digital_clock_img_time = ''
        let normal_digital_clock_hour_separator_img = ''
        let normal_analog_clock_time_pointer_smooth_second = ''
        let normal_date_img_date_year = ''
        let normal_date_year_separator_img = ''
        let normal_date_img_date_month = ''
        let normal_date_month_separator_img = ''
        let normal_date_img_date_day = ''
        let normal_date_img_date_week_img = ''
        let editGroup_1  = ''
        let image_top_img = ''
        let normal_countdown_jumpable_img_click = ''
        let normal_stopwatch_jumpable_img_click = ''
        let normal_altitude_jumpable_img_click = ''


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            console.log('Watch_Face.ScreenNormal');
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 466,
              h: 466,
              src: 'BGmaster.png',
              show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_EDIT,
            });

            normal_temperature_high_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 284,
              y: 36,
              font_array: ["k0.png","k1.png","k2.png","k3.png","k4.png","k5.png","k6.png","k7.png","k8.png","k9.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.WEATHER_HIGH,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_high_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 265,
              y: 40,
              src: 'maxArrow.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_low_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 213,
              y: 36,
              font_array: ["k0.png","k1.png","k2.png","k3.png","k4.png","k5.png","k6.png","k7.png","k8.png","k9.png"],
              padding: false,
              h_space: -3,
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.WEATHER_LOW,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_low_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 210,
              y: 40,
              src: 'minArrow.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 129,
              y: 36,
              font_array: ["k0.png","k1.png","k2.png","k3.png","k4.png","k5.png","k6.png","k7.png","k8.png","k9.png"],
              padding: false,
              h_space: -3,
              unit_sc: 'Celcius.png',
              unit_tc: 'Celcius.png',
              unit_en: 'Celcius.png',
              imperial_unit_sc: 'Faren.png',
              imperial_unit_tc: 'Faren.png',
              imperial_unit_en: 'Faren.png',
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            const temperatureUnit = hmSetting.getTemperatureUnit();
            //start of ignored block
            if (temperatureUnit == 1) {
              normal_temperature_current_text_img.setProperty(hmUI.prop.MORE, {
                x: 129,
                y: 36,
                font_array: ["k0.png","k1.png","k2.png","k3.png","k4.png","k5.png","k6.png","k7.png","k8.png","k9.png"],
                padding: false,
                h_space: -3,
                unit_sc: 'Faren.png',
                unit_tc: 'Faren.png',
                unit_en: 'Faren.png',
                imperial_unit_sc: 'Celcius.png',
                imperial_unit_tc: 'Celcius.png',
                imperial_unit_en: 'Celcius.png',
                align_h: hmUI.align.RIGHT,
                type: hmUI.data_type.WEATHER_CURRENT,
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
            };
            //end of ignored block

            normal_step_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 148,
              y: 329,
              src: 'SSA.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 298,
              y: 368,
              font_array: ["k0.png","k1.png","k2.png","k3.png","k4.png","k5.png","k6.png","k7.png","k8.png","k9.png"],
              padding: false,
              h_space: -2,
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 82,
              y: 336,
              src: 'stepText.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 148,
              y: 329,
              image_array: ["SSA.png","SSB.png","SSC.png","SSD.png","SSE.png","SSF.png","SSG.png","SSH.png","SSI.png","SSJ.png","SSK.png","SSL.png","SSM.png","SSN.png","SSO.png","SSP.png","SSQ.png","SSR.png","SSS.png","SST.png","SSU.png"],
              image_length: 21,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_altimeter_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 101,
              y: 155,
              src: 'AttitudeICO.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_altitude_target_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 78,
              y: 117,
              font_array: ["k0.png","k1.png","k2.png","k3.png","k4.png","k5.png","k6.png","k7.png","k8.png","k9.png"],
              padding: false,
              h_space: -1,
              unit_sc: 'AttitudeUnit.png',
              unit_tc: 'AttitudeUnit.png',
              unit_en: 'AttitudeUnit.png',
              negative_image: 'SymbolAtt.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.ALTITUDE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_compass_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 188,
              y: 104,
              font_array: ["k0.png","k1.png","k2.png","k3.png","k4.png","k5.png","k6.png","k7.png","k8.png","k9.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              // type: hmUI.data_type.COMPASS,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_compass_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 185,
              y: 70,
              src: 'comBg.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            const deviceInfo = hmSetting.getDeviceInfo();
            
            // normal_compass_custom_pointer_img = hmUI.createWidget(hmUI.widget.CUSTOM_POINTER, {
              // src: 'comAr.png',
              // center_x: 233,
              // center_y: 117,
              // x: 7,
              // y: 41,
              // start_angle: 0,
              // end_angle: 360,
              // type: hmUI.data_type.COMPASS,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });


            //start of ignored block
            normal_compass_direction_pointer_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: deviceInfo.width,
              h: deviceInfo.height,
              pos_x: 233 - 7,
              pos_y: 117 - 41,
              center_x: 233,
              center_y: 117,
              src: 'comAr.png',
              angle: 0,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            //end of ignored block

            normal_system_lock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 205,
              y: 153,
              src: 'lock.png',
              type: hmUI.system_status.LOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 205,
              y: -10,
              src: 'bt_dis.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 84,
              y: 210,
              src: 'alarm.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 204,
              y: 397,
              font_array: ["k0.png","k1.png","k2.png","k3.png","k4.png","k5.png","k6.png","k7.png","k8.png","k9.png"],
              padding: false,
              h_space: -3,
              unit_sc: 'persend.png',
              unit_tc: 'persend.png',
              unit_en: 'persend.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 208,
              y: 414,
              image_array: ["icons8-loading-bar-5.png","icons8-loading-bar-7.png","icons8-loading-bar-9.png","icons8-loading-bar-10.png","icons8-loading-bar-11.png","icons8-loading-bar-13.png","icons8-loading-bar-14.png","icons8-loading-bar-15.png","icons8-loading-bar-16.png","icons8-loading-bar-17.png","icons8-loading-bar-18.png","icons8-loading-bar-19.png","icons8-loading-bar-20.png","icons8-loading-bar-21.png"],
              image_length: 14,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time_AmPm = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              am_x: 333,
              am_y: 296,
              am_sc_path: 'D-AM.png',
              am_en_path: 'D-AM.png',
              pm_x: 333,
              pm_y: 296,
              pm_sc_path: 'D-PM.png',
              pm_en_path: 'D-PM.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 71,
              hour_startY: 239,
              hour_array: ["DG0.png","DG1.png","DG2.png","DG3.png","DG4.png","DG5.png","DG6.png","DG7.png","DG8.png","DG9.png"],
              hour_zero: 1,
              hour_space: -12,
              hour_angle: 0,
              hour_align: hmUI.align.RIGHT,

              minute_startX: 212,
              minute_startY: 239,
              minute_array: ["DG0.png","DG1.png","DG2.png","DG3.png","DG4.png","DG5.png","DG6.png","DG7.png","DG8.png","DG9.png"],
              minute_zero: 1,
              minute_space: -12,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              second_startX: 330,
              second_startY: 251,
              second_array: ["DS-0.png","DS-1.png","DS-2.png","DS-3.png","DS-4.png","DS-5.png","DS-6.png","DS-7.png","DS-8.png","DS-9.png"],
              second_zero: 1,
              second_space: -4,
              second_angle: 0,
              second_follow: 0,
              second_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_hour_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 169,
              y: 240,
              src: 'DG-dot.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_analog_clock_pro_second_pointer_img = hmUI.createWidget(hmUI.widget.TIME_POINTER_PRO, {
              // src: 'secAr.png',
              // center_x: 233,
              // center_y: 233,
              // x: 9,
              // y: 232,
              // start_angle: 0,
              // end_angle: 360,
              // type: hmUI.data_type.second,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });


            normal_analog_clock_time_pointer_smooth_second = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              second_path: 'secAr.png',
              second_centerX: 233,
              second_centerY: 233,
              second_posX: 9,
              second_posY: 232,
              fresh_frequency: 30,
              fresh_freqency: 30,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_analog_clock_pro_smooth_second = hmUI.createWidget(hmUI.widget.SMOOTH_SECOND, {
              // type: 3,
              // fps: 30,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });


            normal_date_img_date_year = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              year_startX: 322,
              year_startY: 215,
              year_sc_array: ["k0.png","k1.png","k2.png","k3.png","k4.png","k5.png","k6.png","k7.png","k8.png","k9.png"],
              year_tc_array: ["k0.png","k1.png","k2.png","k3.png","k4.png","k5.png","k6.png","k7.png","k8.png","k9.png"],
              year_en_array: ["k0.png","k1.png","k2.png","k3.png","k4.png","k5.png","k6.png","k7.png","k8.png","k9.png"],
              year_zero: 1,
              year_space: -3,
              year_align: hmUI.align.RIGHT,
              year_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_year_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 314,
              y: 219,
              src: 'dmyspace.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_month = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 275,
              month_startY: 215,
              month_sc_array: ["k0.png","k1.png","k2.png","k3.png","k4.png","k5.png","k6.png","k7.png","k8.png","k9.png"],
              month_tc_array: ["k0.png","k1.png","k2.png","k3.png","k4.png","k5.png","k6.png","k7.png","k8.png","k9.png"],
              month_en_array: ["k0.png","k1.png","k2.png","k3.png","k4.png","k5.png","k6.png","k7.png","k8.png","k9.png"],
              month_zero: 1,
              month_space: -3,
              month_align: hmUI.align.CENTER_H,
              month_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_month_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 267,
              y: 219,
              src: 'dmyspace.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 204,
              day_startY: 205,
              day_sc_array: ["DS-0.png","DS-1.png","DS-2.png","DS-3.png","DS-4.png","DS-5.png","DS-6.png","DS-7.png","DS-8.png","DS-9.png"],
              day_tc_array: ["DS-0.png","DS-1.png","DS-2.png","DS-3.png","DS-4.png","DS-5.png","DS-6.png","DS-7.png","DS-8.png","DS-9.png"],
              day_en_array: ["DS-0.png","DS-1.png","DS-2.png","DS-3.png","DS-4.png","DS-5.png","DS-6.png","DS-7.png","DS-8.png","DS-9.png"],
              day_zero: 1,
              day_space: -4,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 115,
              y: 208,
              week_en: ["DD1.png","DD2.png","DD3.png","DD4.png","DD5.png","DD6.png","DD7.png"],
              week_tc: ["DD1.png","DD2.png","DD3.png","DD4.png","DD5.png","DD6.png","DD7.png"],
              week_sc: ["DD1.png","DD2.png","DD3.png","DD4.png","DD5.png","DD6.png","DD7.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            console.log('Watch_Face.ScreenAOD');
            console.log('Watch_Face.Editable_Elements');

            editGroup_1 = hmUI.createWidget(hmUI.widget.WATCHFACE_EDIT_GROUP, {
              edit_id: 10021,
              x: 299,
              y: 92,
              w: 100,
              h: 100,
              select_image: 'circleSelect.png',
              un_select_image: 'Circle.png',
              default_type: hmUI.edit_type.STAND,
              optional_types: [
                { type: hmUI.edit_type.STAND, preview: 'ez(1)_STAND.png' },
                { type: hmUI.edit_type.HEART, preview: 'ez(1)_HEART.png' },
                { type: hmUI.edit_type.CAL, preview: 'ez(1)_CAL.png' },
                { type: hmUI.edit_type.SUN, preview: 'ez(1)_SUN.png' },
                { type: hmUI.edit_type.DISTANCE, preview: 'ez(1)_DISTANCE.png' },
                { type: hmUI.edit_type.UVI, preview: 'ez(1)_UVI.png' },
              ],
              count: 6,
              select_list: {
                title_font_size: 34,
                title_align_h: hmUI.align.CENTER_H,
                list_item_vspace: 8,
                list_tips_text_font_size: 32,
                list_tips_text_align_h: hmUI.align.LEFT
              },
              tips_BG: 'tooltipBG_1.png',
              tips_x: -99,
              tips_y: 0,
              tips_width: 100,
              tips_margin: 1,
            });

            const editType_1 = editGroup_1.getProperty(hmUI.prop.CURRENT_TYPE);

            switch (editType_1) {
              case hmUI.edit_type.CAL:
                hmUI.createWidget(hmUI.widget.IMG, {
                  x: 298,
                  y: 93,
                  src: 'calIcon.png',
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });

                hmUI.createWidget(hmUI.widget.IMG_POINTER, {
                  src: 'uvPoint.png',
                  center_x: 347,
                  center_y: 142,
                  x: -21,
                  y: -7,
                  start_angle: 150,
                  end_angle: 330,
                  invalid_visible: false,
                  type: hmUI.data_type.CAL,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });

                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                  x: 315,
                  y: 116,
                  font_array: ["k0.png","k1.png","k2.png","k3.png","k4.png","k5.png","k6.png","k7.png","k8.png","k9.png"],
                  padding: false,
                  h_space: -3,
                  align_h: hmUI.align.CENTER_H,
                  type: hmUI.data_type.CAL,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });
                break;

              case hmUI.edit_type.HEART:
                hmUI.createWidget(hmUI.widget.IMG, {
                  x: 298,
                  y: 93,
                  src: 'heartIcon.png',
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });

                hmUI.createWidget(hmUI.widget.IMG_POINTER, {
                  src: 'uvPoint.png',
                  center_x: 347,
                  center_y: 141,
                  x: -21,
                  y: -7,
                  start_angle: 150,
                  end_angle: 330,
                  invalid_visible: false,
                  type: hmUI.data_type.HEART,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });

                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                  x: 323,
                  y: 117,
                  font_array: ["k0.png","k1.png","k2.png","k3.png","k4.png","k5.png","k6.png","k7.png","k8.png","k9.png"],
                  padding: false,
                  h_space: -4,
                  align_h: hmUI.align.CENTER_H,
                  type: hmUI.data_type.HEART,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });
                break;

              case hmUI.edit_type.DISTANCE:
                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                  x: 307,
                  y: 117,
                  font_array: ["k0.png","k1.png","k2.png","k3.png","k4.png","k5.png","k6.png","k7.png","k8.png","k9.png"],
                  padding: false,
                  h_space: -3,
                  dot_image: 'dicimalMINI.png',
                  align_h: hmUI.align.CENTER_H,
                  type: hmUI.data_type.DISTANCE,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });

                hmUI.createWidget(hmUI.widget.IMG, {
                  x: 331,
                  y: 148,
                  src: 'RangICO.png',
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });
                break;

              case hmUI.edit_type.STAND:
                hmUI.createWidget(hmUI.widget.IMG, {
                  x: 329,
                  y: 156,
                  src: 'secAr.png',
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });

                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                  x: 350,
                  y: 117,
                  font_array: ["k0.png","k1.png","k2.png","k3.png","k4.png","k5.png","k6.png","k7.png","k8.png","k9.png"],
                  padding: false,
                  h_space: -2,
                  align_h: hmUI.align.LEFT,
                  type: hmUI.data_type.STAND_TARGET,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });

                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                  x: 277,
                  y: 117,
                  font_array: ["k0.png","k1.png","k2.png","k3.png","k4.png","k5.png","k6.png","k7.png","k8.png","k9.png"],
                  padding: false,
                  h_space: -2,
                  align_h: hmUI.align.RIGHT,
                  type: hmUI.data_type.STAND,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });

                editableZone_1_stand_current_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
                  x: 345,
                  y: 122,
                  src: 'dmyspace.png',
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });
                break;

              case hmUI.edit_type.UVI:
                 hmUI.createWidget(hmUI.widget.IMG, {
                  x: 298,
                  y: 93,
                  src: 'uvICON.png',
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });

                hmUI.createWidget(hmUI.widget.IMG_POINTER, {
                  src: 'uvPoint.png',
                  center_x: 346,
                  center_y: 139,
                  x: -16,
                  y: -5,
                  start_angle: 150,
                  end_angle: 330,
                  invalid_visible: false,
                  type: hmUI.data_type.UVI,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });

                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                  x: 329,
                  y: 116,
                  font_array: ["k0.png","k1.png","k2.png","k3.png","k4.png","k5.png","k6.png","k7.png","k8.png","k9.png"],
                  padding: false,
                  h_space: -2,
                  align_h: hmUI.align.CENTER_H,
                  type: hmUI.data_type.UVI,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });
                break;

              case hmUI.edit_type.SUN:
                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                  x: 308,
                  y: 117,
                  font_array: ["k0.png","k1.png","k2.png","k3.png","k4.png","k5.png","k6.png","k7.png","k8.png","k9.png"],
                  padding: false,
                  h_space: -2,
                  dot_image: 'colonMini.png',
                  align_h: hmUI.align.CENTER_H,
                  type: hmUI.data_type.SUN_CURRENT,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });

                hmUI.createWidget(hmUI.widget.IMG, {
                  x: 333,
                  y: 148,
                  src: 'sunrisePNG.png',
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });
                break;
            }; // end switch
            
            // disconnectAlert = hmUI.createWidget(hmUI.widget.DisconnectAlert, {
              // disconneсnt_vibrate_type: 9,
              // disconneсnt_toast_text: You have away from your Phone.,
              // conneсnt_vibrate_type: 25,
              // conneсnt_toast_text: Your Phone is here.,
            // });

            // vibration when connecting or disconnecting

            function checkConnection() {
              console.log('checkConnection()');
              hmBle.removeListener;
              hmBle.addListener(function (status) {
                if(!status) {
                  hmUI.showToast({text: "You have away from your Phone."});
                  vibro(9);
                }
                if(status) {
                  hmUI.showToast({text: "Your Phone is here."});
                  vibro(25);
                }
              });
            }

            // end vibration when connecting or disconnecting
            // vibrate function

            const vibrate = hmSensor.createSensor(hmSensor.id.VIBRATE);
            let timer_StopVibrate = null;


            function vibro(scene = 25) {
              let stopDelay = 50;
              stopVibro();
              vibrate.stop();
              vibrate.scene = scene;
              if(scene < 23 || scene > 25) stopDelay = 1300;
              vibrate.start();
              if (scene != 1) timer_StopVibrate = timer.createTimer(stopDelay, 3000, stopVibro, {});
            }

            function stopVibro(){
              vibrate.stop();
              if(timer_StopVibrate) timer.stopTimer(timer_StopVibrate);
            }

            // end vibrate function

            image_top_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: -2,
              y: 92,
              src: 'SPACE-item_2.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            console.log('Watch_Face.Shortcuts');

            normal_countdown_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 87,
              y: 250,
              w: 235,
              h: 78,
              type: hmUI.data_type.COUNT_DOWN,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_stopwatch_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 332,
              y: 251,
              w: 54,
              h: 74,
              type: hmUI.data_type.STOP_WATCH,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_altitude_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 77,
              y: 98,
              w: 83,
              h: 87,
              type: hmUI.data_type.ALTITUDE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            let screenType = hmSetting.getScreenType();
            //start of ignored block
            console.log('compass_update()');
            if (screenType == hmSetting.screen_type.WATCHFACE){
              compass = hmSensor.createSensor(hmSensor.id.COMPASS);
              compass.start();

              if (compass.direction_angle && compass.direction  && compass.direction_angle != 'INVALID') { // initial data
                // Compass Number
                let compass_direction_angle = parseInt(compass.direction_angle);
                let normal_compass_direction_angle_text = compass_direction_angle.toString();
                normal_compass_text_img.setProperty(hmUI.prop.TEXT, normal_compass_direction_angle_text);
                // Compass Pointer
                normal_compass_direction_pointer_img.setProperty(hmUI.prop.ANGLE, -compass_direction_angle);

              } else { // error data
                normal_compass_text_img.setProperty(hmUI.prop.TEXT, '-');
                normal_compass_direction_pointer_img.setProperty(hmUI.prop.ANGLE, 0);

              }

              compass.addEventListener(hmSensor.event.CHANGE, function (compass_res) { // change values when changing direction

                if (compass_res.calibration_status) {
                  // Compass Number
                  let compass_direction_angle = parseInt(compass_res.direction_angle);
                  let normal_compass_direction_angle_text = compass_direction_angle.toString();
                  normal_compass_text_img.setProperty(hmUI.prop.TEXT, normal_compass_direction_angle_text);
                  // Compass Pointer
                  normal_compass_direction_pointer_img.setProperty(hmUI.prop.ANGLE, -compass_direction_angle);

                } else { // error data
                  normal_compass_text_img.setProperty(hmUI.prop.TEXT, '-');
                  normal_compass_direction_pointer_img.setProperty(hmUI.prop.ANGLE, 0);

                }

              }); // Listener end

            };
            //end of ignored block

            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                console.log('resume_call()');
                if (compass && screenType == hmSetting.screen_type.WATCHFACE) compass.start();
                checkConnection();
                stopVibro();

              }),
              pause_call: (function () {
                console.log('pause_call()');
                if (compass) compass.stop();
                stopVibro();

              }),
            });

                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}