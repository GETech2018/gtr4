﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        const logger = Logger.getLogger('watchface_SashaCX75');
        //end of ignored block

        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_system_clock_img = ''
        let normal_date_img_date_week_img = ''
        let normal_heart_rate_text_text_img = ''
        let normal_distance_text_text_img = ''
        let normal_calorie_current_text_img = ''
        let normal_step_current_text_img = ''
        let normal_image_img = ''
        let normal_temperature_current_text_img = ''
        let normal_weather_image_progress_img_level = ''
        let normal_date_img_date_month_img = ''
        let normal_date_img_date_day = ''
        let normal_battery_image_progress_img_level = ''
        let normal_battery_text_text_img = ''
        let normal_digital_clock_img_time_AmPm = ''
        let normal_digital_clock_img_time = ''
        let normal_analog_clock_pro_hour_pointer_img = ''
        let normal_analog_clock_pro_minute_pointer_img = ''
        let normal_analog_clock_pro_second_pointer_img = ''
        let normal_timerUpdateSec = undefined;
        let idle_background_bg_img = ''
        let idle_system_clock_img = ''
        let idle_date_img_date_week_img = ''
        let idle_heart_rate_text_text_img = ''
        let idle_distance_text_text_img = ''
        let idle_calorie_current_text_img = ''
        let idle_step_current_text_img = ''
        let idle_image_img = ''
        let idle_temperature_current_text_img = ''
        let idle_weather_image_progress_img_level = ''
        let idle_date_img_date_month_img = ''
        let idle_date_img_date_day = ''
        let idle_battery_image_progress_img_level = ''
        let idle_battery_text_text_img = ''
        let idle_digital_clock_img_time_AmPm = ''
        let idle_digital_clock_img_time = ''
        let idle_analog_clock_pro_hour_pointer_img = ''
        let idle_analog_clock_pro_minute_pointer_img = ''
        let idle_analog_clock_pro_second_pointer_img = ''
        let idle_timerUpdateSec = undefined;
        let timeSensor = ''


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            console.log('Watch_Face.ScreenNormal');
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 466,
              h: 466,
              src: '466_3.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 42,
              y: 260,
              src: '0075.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 103,
              y: 382,
              week_en: ["m0043.png","m0044.png","m0045.png","m0046.png","m0047.png","m0048.png","m0049.png"],
              week_tc: ["m0043.png","m0044.png","m0045.png","m0046.png","m0047.png","m0048.png","m0049.png"],
              week_sc: ["m0043.png","m0044.png","m0045.png","m0046.png","m0047.png","m0048.png","m0049.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 380,
              y: 267,
              font_array: ["WF0_Frame0047.png","WF0_Frame0048.png","WF0_Frame0049.png","WF0_Frame0050.png","WF0_Frame0051.png","WF0_Frame0052.png","WF0_Frame0053.png","WF0_Frame0054.png","WF0_Frame0055.png","WF0_Frame0056.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_distance_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 294,
              y: 354,
              font_array: ["WF0_Frame0047.png","WF0_Frame0048.png","WF0_Frame0049.png","WF0_Frame0050.png","WF0_Frame0051.png","WF0_Frame0052.png","WF0_Frame0053.png","WF0_Frame0054.png","WF0_Frame0055.png","WF0_Frame0056.png"],
              padding: false,
              h_space: 0,
              unit_sc: '0042.png',
              unit_tc: '0042.png',
              unit_en: '0042.png',
              dot_image: '0039.png',
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.DISTANCE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_calorie_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 294,
              y: 380,
              font_array: ["WF0_Frame0047.png","WF0_Frame0048.png","WF0_Frame0049.png","WF0_Frame0050.png","WF0_Frame0051.png","WF0_Frame0052.png","WF0_Frame0053.png","WF0_Frame0054.png","WF0_Frame0055.png","WF0_Frame0056.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 202,
              y: 410,
              font_array: ["WF0_Frame0047.png","WF0_Frame0048.png","WF0_Frame0049.png","WF0_Frame0050.png","WF0_Frame0051.png","WF0_Frame0052.png","WF0_Frame0053.png","WF0_Frame0054.png","WF0_Frame0055.png","WF0_Frame0056.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_image_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 206,
              y: 268,
              src: 'wfs_points_113d9760_a00c_46d1_864c_9403f38f898e.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 241,
              y: 196,
              font_array: ["WF0_Frame0047.png","WF0_Frame0048.png","WF0_Frame0049.png","WF0_Frame0050.png","WF0_Frame0051.png","WF0_Frame0052.png","WF0_Frame0053.png","WF0_Frame0054.png","WF0_Frame0055.png","WF0_Frame0056.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'gp.png',
              unit_tc: 'gp.png',
              unit_en: 'gp.png',
              negative_image: 'gt.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 369,
              y: 179,
              image_array: ["weather_icon_01.png","weather_icon_02.png","weather_icon_03.png","weather_icon_04.png","weather_icon_05.png","weather_icon_06.png","weather_icon_07.png","weather_icon_08.png","weather_icon_09.png","weather_icon_10.png","weather_icon_11.png","weather_icon_12.png","weather_icon_13.png","weather_icon_14.png","weather_icon_15.png","weather_icon_16.png","weather_icon_17.png","weather_icon_18.png","weather_icon_19.png","weather_icon_20.png","weather_icon_21.png","weather_icon_22.png","weather_icon_23.png","weather_icon_24.png","weather_icon_25.png","weather_icon_26.png","weather_icon_27.png","weather_icon_28.png","weather_icon_29.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_month_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 104,
              month_startY: 355,
              month_sc_array: ["d0053.png","d0054.png","d0055.png","d0056.png","d0057.png","d0058.png","d0059.png","d0060.png","d0061.png","d0062.png","d0063.png","d0064.png"],
              month_tc_array: ["d0053.png","d0054.png","d0055.png","d0056.png","d0057.png","d0058.png","d0059.png","d0060.png","d0061.png","d0062.png","d0063.png","d0064.png"],
              month_en_array: ["d0053.png","d0054.png","d0055.png","d0056.png","d0057.png","d0058.png","d0059.png","d0060.png","d0061.png","d0062.png","d0063.png","d0064.png"],
              month_is_character: true ,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 189,
              day_startY: 355,
              day_sc_array: ["p0.png","p1.png","p2.png","p3.png","p4.png","p5.png","p6.png","p7.png","p8.png","p9.png"],
              day_tc_array: ["p0.png","p1.png","p2.png","p3.png","p4.png","p5.png","p6.png","p7.png","p8.png","p9.png"],
              day_en_array: ["p0.png","p1.png","p2.png","p3.png","p4.png","p5.png","p6.png","p7.png","p8.png","p9.png"],
              day_zero: 0,
              day_space: 0,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 11,
              y: 3,
              image_array: ["b2.png","b3.png","b4.png","b5.png","b6.png","b7.png","b8.png","b9.png","b99.png","b999.png"],
              image_length: 10,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 245,
              y: 148,
              font_array: ["WF0_Frame0047.png","WF0_Frame0048.png","WF0_Frame0049.png","WF0_Frame0050.png","WF0_Frame0051.png","WF0_Frame0052.png","WF0_Frame0053.png","WF0_Frame0054.png","WF0_Frame0055.png","WF0_Frame0056.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time_AmPm = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              am_x: -15,
              am_y: 28,
              am_sc_path: 'wfs_am_9f6ace29_ffd9_42b0_9456_0089028c4694.png',
              am_en_path: 'wfs_am_9f6ace29_ffd9_42b0_9456_0089028c4694.png',
              pm_x: -15,
              pm_y: 28,
              pm_sc_path: 'wfs_pm_f06d9694_516b_478c_b114_e139e24dd530.png',
              pm_en_path: 'wfs_pm_f06d9694_516b_478c_b114_e139e24dd530.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 102,
              hour_startY: 262,
              hour_array: ["wfs_0_caeed31e_9284_496d_8754_f5435249bc8c.png","wfs_1_9a5a428a_355d_476f_8f78_2c5ac1b388aa.png","wfs_2_9924e7b2_8357_4edc_b178_eb5890a86a65.png","wfs_3_cdb47a35_fa54_4293_b707_ff7e3b8d6cf7.png","wfs_4_75bc2677_7c2c_4727_94b5_582ed975d537.png","wfs_5_e5f67c04_229a_4c16_be71_592983b58205.png","wfs_6_77ccba1e_8e9a_4a70_8463_bd2401c4eec9.png","wfs_7_cbe63b6d_5c1d_4f57_b4cb_ac2119acfadb.png","wfs_8_cc9df689_9c4f_4552_890e_8873bee0f4d5.png","wfs_9_fe1b0831_5367_47b6_a598_fddb4ae6b056.png"],
              hour_zero: 1,
              hour_space: 0,
              hour_angle: 0,
              hour_align: hmUI.align.LEFT,

              minute_startX: 232,
              minute_startY: 262,
              minute_array: ["wfs_0_caeed31e_9284_496d_8754_f5435249bc8c.png","wfs_1_9a5a428a_355d_476f_8f78_2c5ac1b388aa.png","wfs_2_9924e7b2_8357_4edc_b178_eb5890a86a65.png","wfs_3_cdb47a35_fa54_4293_b707_ff7e3b8d6cf7.png","wfs_4_75bc2677_7c2c_4727_94b5_582ed975d537.png","wfs_5_e5f67c04_229a_4c16_be71_592983b58205.png","wfs_6_77ccba1e_8e9a_4a70_8463_bd2401c4eec9.png","wfs_7_cbe63b6d_5c1d_4f57_b4cb_ac2119acfadb.png","wfs_8_cc9df689_9c4f_4552_890e_8873bee0f4d5.png","wfs_9_fe1b0831_5367_47b6_a598_fddb4ae6b056.png"],
              minute_zero: 1,
              minute_space: 0,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              second_startX: 351,
              second_startY: 292,
              second_array: ["p0.png","p1.png","p2.png","p3.png","p4.png","p5.png","p6.png","p7.png","p8.png","p9.png"],
              second_zero: 1,
              second_space: 0,
              second_angle: 0,
              second_follow: 0,
              second_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            const deviceInfo = hmSetting.getDeviceInfo();
            if (!timeSensor) timeSensor = hmSensor.createSensor(hmSensor.id.TIME);
            timeSensor.addEventListener(timeSensor.event.MINUTEEND, function() {
              let updateHour = timeSensor.minute == 0;

              time_update(UpdateHour, true);
            });

            // normal_analog_clock_pro_hour_pointer_img = hmUI.createWidget(hmUI.widget.TIME_POINTER_PRO, {
              // src: 'wfs_h_9b0a73b5_4696_431b_837b_e9ad8d6bfc08.png',
              // center_x: 129,
              // center_y: 158,
              // x: 68,
              // y: 68,
              // start_angle: 0,
              // end_angle: 360,
              // type: hmUI.data_type.hour,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });


            normal_analog_clock_pro_hour_pointer_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: deviceInfo.width,
              h: deviceInfo.height,
              pos_x: 129 - 68,
              pos_y: 158 - 68,
              center_x: 129,
              center_y: 158,
              src: 'wfs_h_9b0a73b5_4696_431b_837b_e9ad8d6bfc08.png',
              angle: 0,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_analog_clock_pro_minute_pointer_img = hmUI.createWidget(hmUI.widget.TIME_POINTER_PRO, {
              // src: 'wfs_m_a53f9b94_a783_433e_80fb_a6022f37ba39.png',
              // center_x: 129,
              // center_y: 158,
              // x: 68,
              // y: 73,
              // start_angle: 0,
              // end_angle: 360,
              // type: hmUI.data_type.minute,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });


            normal_analog_clock_pro_minute_pointer_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: deviceInfo.width,
              h: deviceInfo.height,
              pos_x: 129 - 68,
              pos_y: 158 - 73,
              center_x: 129,
              center_y: 158,
              src: 'wfs_m_a53f9b94_a783_433e_80fb_a6022f37ba39.png',
              angle: 0,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_analog_clock_pro_second_pointer_img = hmUI.createWidget(hmUI.widget.TIME_POINTER_PRO, {
              // src: 'wfs_s_d8bbd6c0_09c2_4c27_8514_d871fce3e869.png',
              // center_x: 129,
              // center_y: 158,
              // x: 67,
              // y: 71,
              // start_angle: 0,
              // end_angle: 360,
              // type: hmUI.data_type.second,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });


            normal_analog_clock_pro_second_pointer_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: deviceInfo.width,
              h: deviceInfo.height,
              pos_x: 129 - 67,
              pos_y: 158 - 71,
              center_x: 129,
              center_y: 158,
              src: 'wfs_s_d8bbd6c0_09c2_4c27_8514_d871fce3e869.png',
              angle: 0,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            let screenType = hmSetting.getScreenType();

            console.log('Watch_Face.ScreenAOD');
            idle_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 466,
              h: 466,
              src: '466_3.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 42,
              y: 260,
              src: '0075.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 103,
              y: 382,
              week_en: ["m0043.png","m0044.png","m0045.png","m0046.png","m0047.png","m0048.png","m0049.png"],
              week_tc: ["m0043.png","m0044.png","m0045.png","m0046.png","m0047.png","m0048.png","m0049.png"],
              week_sc: ["m0043.png","m0044.png","m0045.png","m0046.png","m0047.png","m0048.png","m0049.png"],
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 380,
              y: 267,
              font_array: ["WF0_Frame0047.png","WF0_Frame0048.png","WF0_Frame0049.png","WF0_Frame0050.png","WF0_Frame0051.png","WF0_Frame0052.png","WF0_Frame0053.png","WF0_Frame0054.png","WF0_Frame0055.png","WF0_Frame0056.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_distance_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 294,
              y: 354,
              font_array: ["WF0_Frame0047.png","WF0_Frame0048.png","WF0_Frame0049.png","WF0_Frame0050.png","WF0_Frame0051.png","WF0_Frame0052.png","WF0_Frame0053.png","WF0_Frame0054.png","WF0_Frame0055.png","WF0_Frame0056.png"],
              padding: false,
              h_space: 0,
              unit_sc: '0042.png',
              unit_tc: '0042.png',
              unit_en: '0042.png',
              dot_image: '0039.png',
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.DISTANCE,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_calorie_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 294,
              y: 380,
              font_array: ["WF0_Frame0047.png","WF0_Frame0048.png","WF0_Frame0049.png","WF0_Frame0050.png","WF0_Frame0051.png","WF0_Frame0052.png","WF0_Frame0053.png","WF0_Frame0054.png","WF0_Frame0055.png","WF0_Frame0056.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 202,
              y: 410,
              font_array: ["WF0_Frame0047.png","WF0_Frame0048.png","WF0_Frame0049.png","WF0_Frame0050.png","WF0_Frame0051.png","WF0_Frame0052.png","WF0_Frame0053.png","WF0_Frame0054.png","WF0_Frame0055.png","WF0_Frame0056.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_image_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 206,
              y: 268,
              src: 'wfs_points_113d9760_a00c_46d1_864c_9403f38f898e.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 241,
              y: 196,
              font_array: ["WF0_Frame0047.png","WF0_Frame0048.png","WF0_Frame0049.png","WF0_Frame0050.png","WF0_Frame0051.png","WF0_Frame0052.png","WF0_Frame0053.png","WF0_Frame0054.png","WF0_Frame0055.png","WF0_Frame0056.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'gp.png',
              unit_tc: 'gp.png',
              unit_en: 'gp.png',
              negative_image: 'gt.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 369,
              y: 179,
              image_array: ["weather_icon_01.png","weather_icon_02.png","weather_icon_03.png","weather_icon_04.png","weather_icon_05.png","weather_icon_06.png","weather_icon_07.png","weather_icon_08.png","weather_icon_09.png","weather_icon_10.png","weather_icon_11.png","weather_icon_12.png","weather_icon_13.png","weather_icon_14.png","weather_icon_15.png","weather_icon_16.png","weather_icon_17.png","weather_icon_18.png","weather_icon_19.png","weather_icon_20.png","weather_icon_21.png","weather_icon_22.png","weather_icon_23.png","weather_icon_24.png","weather_icon_25.png","weather_icon_26.png","weather_icon_27.png","weather_icon_28.png","weather_icon_29.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_month_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 104,
              month_startY: 355,
              month_sc_array: ["d0053.png","d0054.png","d0055.png","d0056.png","d0057.png","d0058.png","d0059.png","d0060.png","d0061.png","d0062.png","d0063.png","d0064.png"],
              month_tc_array: ["d0053.png","d0054.png","d0055.png","d0056.png","d0057.png","d0058.png","d0059.png","d0060.png","d0061.png","d0062.png","d0063.png","d0064.png"],
              month_en_array: ["d0053.png","d0054.png","d0055.png","d0056.png","d0057.png","d0058.png","d0059.png","d0060.png","d0061.png","d0062.png","d0063.png","d0064.png"],
              month_is_character: true ,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 189,
              day_startY: 355,
              day_sc_array: ["p0.png","p1.png","p2.png","p3.png","p4.png","p5.png","p6.png","p7.png","p8.png","p9.png"],
              day_tc_array: ["p0.png","p1.png","p2.png","p3.png","p4.png","p5.png","p6.png","p7.png","p8.png","p9.png"],
              day_en_array: ["p0.png","p1.png","p2.png","p3.png","p4.png","p5.png","p6.png","p7.png","p8.png","p9.png"],
              day_zero: 0,
              day_space: 0,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_battery_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 11,
              y: 3,
              image_array: ["b2.png","b3.png","b4.png","b5.png","b6.png","b7.png","b8.png","b9.png","b99.png","b999.png"],
              image_length: 10,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 245,
              y: 148,
              font_array: ["WF0_Frame0047.png","WF0_Frame0048.png","WF0_Frame0049.png","WF0_Frame0050.png","WF0_Frame0051.png","WF0_Frame0052.png","WF0_Frame0053.png","WF0_Frame0054.png","WF0_Frame0055.png","WF0_Frame0056.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time_AmPm = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              am_x: -15,
              am_y: 28,
              am_sc_path: 'wfs_am_9f6ace29_ffd9_42b0_9456_0089028c4694.png',
              am_en_path: 'wfs_am_9f6ace29_ffd9_42b0_9456_0089028c4694.png',
              pm_x: -15,
              pm_y: 28,
              pm_sc_path: 'wfs_pm_f06d9694_516b_478c_b114_e139e24dd530.png',
              pm_en_path: 'wfs_pm_f06d9694_516b_478c_b114_e139e24dd530.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 102,
              hour_startY: 262,
              hour_array: ["wfs_0_caeed31e_9284_496d_8754_f5435249bc8c.png","wfs_1_9a5a428a_355d_476f_8f78_2c5ac1b388aa.png","wfs_2_9924e7b2_8357_4edc_b178_eb5890a86a65.png","wfs_3_cdb47a35_fa54_4293_b707_ff7e3b8d6cf7.png","wfs_4_75bc2677_7c2c_4727_94b5_582ed975d537.png","wfs_5_e5f67c04_229a_4c16_be71_592983b58205.png","wfs_6_77ccba1e_8e9a_4a70_8463_bd2401c4eec9.png","wfs_7_cbe63b6d_5c1d_4f57_b4cb_ac2119acfadb.png","wfs_8_cc9df689_9c4f_4552_890e_8873bee0f4d5.png","wfs_9_fe1b0831_5367_47b6_a598_fddb4ae6b056.png"],
              hour_zero: 1,
              hour_space: 0,
              hour_angle: 0,
              hour_align: hmUI.align.LEFT,

              minute_startX: 232,
              minute_startY: 262,
              minute_array: ["wfs_0_caeed31e_9284_496d_8754_f5435249bc8c.png","wfs_1_9a5a428a_355d_476f_8f78_2c5ac1b388aa.png","wfs_2_9924e7b2_8357_4edc_b178_eb5890a86a65.png","wfs_3_cdb47a35_fa54_4293_b707_ff7e3b8d6cf7.png","wfs_4_75bc2677_7c2c_4727_94b5_582ed975d537.png","wfs_5_e5f67c04_229a_4c16_be71_592983b58205.png","wfs_6_77ccba1e_8e9a_4a70_8463_bd2401c4eec9.png","wfs_7_cbe63b6d_5c1d_4f57_b4cb_ac2119acfadb.png","wfs_8_cc9df689_9c4f_4552_890e_8873bee0f4d5.png","wfs_9_fe1b0831_5367_47b6_a598_fddb4ae6b056.png"],
              minute_zero: 1,
              minute_space: 0,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              second_startX: 351,
              second_startY: 292,
              second_array: ["p0.png","p1.png","p2.png","p3.png","p4.png","p5.png","p6.png","p7.png","p8.png","p9.png"],
              second_zero: 1,
              second_space: 0,
              second_angle: 0,
              second_follow: 0,
              second_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_AOD,
            });

            // idle_analog_clock_pro_hour_pointer_img = hmUI.createWidget(hmUI.widget.TIME_POINTER_PRO, {
              // src: 'wfs_h_9b0a73b5_4696_431b_837b_e9ad8d6bfc08.png',
              // center_x: 129,
              // center_y: 158,
              // x: 68,
              // y: 68,
              // start_angle: 0,
              // end_angle: 360,
              // type: hmUI.data_type.hour,
              // show_level: hmUI.show_level.ONLY_AOD,
            // });


            idle_analog_clock_pro_hour_pointer_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: deviceInfo.width,
              h: deviceInfo.height,
              pos_x: 129 - 68,
              pos_y: 158 - 68,
              center_x: 129,
              center_y: 158,
              src: 'wfs_h_9b0a73b5_4696_431b_837b_e9ad8d6bfc08.png',
              angle: 0,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            // idle_analog_clock_pro_minute_pointer_img = hmUI.createWidget(hmUI.widget.TIME_POINTER_PRO, {
              // src: 'wfs_m_a53f9b94_a783_433e_80fb_a6022f37ba39.png',
              // center_x: 129,
              // center_y: 158,
              // x: 68,
              // y: 73,
              // start_angle: 0,
              // end_angle: 360,
              // type: hmUI.data_type.minute,
              // show_level: hmUI.show_level.ONLY_AOD,
            // });


            idle_analog_clock_pro_minute_pointer_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: deviceInfo.width,
              h: deviceInfo.height,
              pos_x: 129 - 68,
              pos_y: 158 - 73,
              center_x: 129,
              center_y: 158,
              src: 'wfs_m_a53f9b94_a783_433e_80fb_a6022f37ba39.png',
              angle: 0,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            // idle_analog_clock_pro_second_pointer_img = hmUI.createWidget(hmUI.widget.TIME_POINTER_PRO, {
              // src: 'wfs_s_d8bbd6c0_09c2_4c27_8514_d871fce3e869.png',
              // center_x: 129,
              // center_y: 158,
              // x: 67,
              // y: 71,
              // start_angle: 0,
              // end_angle: 360,
              // type: hmUI.data_type.second,
              // show_level: hmUI.show_level.ONLY_AOD,
            // });


            idle_analog_clock_pro_second_pointer_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: deviceInfo.width,
              h: deviceInfo.height,
              pos_x: 129 - 67,
              pos_y: 158 - 71,
              center_x: 129,
              center_y: 158,
              src: 'wfs_s_d8bbd6c0_09c2_4c27_8514_d871fce3e869.png',
              angle: 0,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            function time_update(updateHour = false, updateMinute = false) {
              console.log('time_update()');
              let hour = timeSensor.hour;
              let minute = timeSensor.minute;
              let second = timeSensor.second;
              let format_hour = timeSensor.format_hour;

              if (updateHour) {
                let normal_hour = hour;
                let normal_fullAngle_hour = 360;
                if (normal_hour > 11) normal_hour -= 12;
                let normal_angle_hour = 0 + normal_fullAngle_hour*normal_hour/12 + (normal_fullAngle_hour/12)*minute/60;
                if (normal_analog_clock_pro_hour_pointer_img) normal_analog_clock_pro_hour_pointer_img.setProperty(hmUI.prop.ANGLE, normal_angle_hour);
              };

              if (updateMinute) {
                let normal_fullAngle_minute = 360;
                let normal_angle_minute = 0 + normal_fullAngle_minute*minute/60;
                if (normal_analog_clock_pro_minute_pointer_img) normal_analog_clock_pro_minute_pointer_img.setProperty(hmUI.prop.ANGLE, normal_angle_minute);
              };

              let normal_fullAngle_second = 360;
              let normal_angle_second = 0 + normal_fullAngle_second*second/60;
              if (normal_analog_clock_pro_second_pointer_img) normal_analog_clock_pro_second_pointer_img.setProperty(hmUI.prop.ANGLE, normal_angle_second);

              if (updateHour) {
                let idle_hour = hour;
                let idle_fullAngle_hour = 360;
                if (idle_hour > 11) idle_hour -= 12;
                let idle_angle_hour = 0 + idle_fullAngle_hour*idle_hour/12 + (idle_fullAngle_hour/12)*minute/60;
                if (idle_analog_clock_pro_hour_pointer_img) idle_analog_clock_pro_hour_pointer_img.setProperty(hmUI.prop.ANGLE, idle_angle_hour);
              };

              if (updateMinute) {
                let idle_fullAngle_minute = 360;
                let idle_angle_minute = 0 + idle_fullAngle_minute*minute/60;
                if (idle_analog_clock_pro_minute_pointer_img) idle_analog_clock_pro_minute_pointer_img.setProperty(hmUI.prop.ANGLE, idle_angle_minute);
              };

              let idle_fullAngle_second = 360;
              let idle_angle_second = 0 + idle_fullAngle_second*second/60;
              if (idle_analog_clock_pro_second_pointer_img) idle_analog_clock_pro_second_pointer_img.setProperty(hmUI.prop.ANGLE, idle_angle_second);

            };

            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                console.log('resume_call()');
                time_update(true, true);
                if (screenType == hmSetting.screen_type.WATCHFACE) {
                  if (!normal_timerUpdateSec) {
                    let animDelay = timeSensor.utc % 1000;
                    let animRepeat = 1000;
                    normal_timerUpdateSec = timer.createTimer(animDelay, animRepeat, (function (option) {
                      time_update(false, false);
                    }));  // end timer 
                  };  // end timer check
                };  // end screenType

                if (screenType == hmSetting.screen_type.AOD) {
                  if (!idle_timerUpdateSec) {
                    let animDelay = timeSensor.utc % 1000;
                    let animRepeat = 1000;
                    idle_timerUpdateSec = timer.createTimer(animDelay, animRepeat, (function (option) {
                      time_update(false, false);
                    }));  // end timer 
                  };  // end timer check
                };  // end screenType


              }),
              pause_call: (function () {
                console.log('pause_call()');
                if (normal_timerUpdateSec) {
                  timer.stopTimer(normal_timerUpdateSec);
                  normal_timerUpdateSec = undefined;
                }
                if (idle_timerUpdateSec) {
                  timer.stopTimer(idle_timerUpdateSec);
                  idle_timerUpdateSec = undefined;
                }

              }),
            });

                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}