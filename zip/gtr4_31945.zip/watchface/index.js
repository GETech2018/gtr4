﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.0.1
    ** Copyright © CashaCX75. All Rights Reserved
    */

    try {
    (()=>{
        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_sun_high_text_img = ''
        let normal_sun_low_text_img = ''
        let normal_system_disconnect_img = ''
        let normal_battery_text_text_img = ''
        let normal_battery_image_progress_img_level = ''
        let normal_moon_image_progress_img_level = ''
        let normal_wind_text_text_img = ''
        let normal_wind_image_progress_img_level = ''
        let normal_uvi_text_text_img = ''
        let normal_spo2_text_text_img = ''
        let normal_heart_rate_text_text_img = ''
        let normal_heart_rate_image_progress_img_level = ''
        let normal_step_current_text_img = ''
        let normal_altimeter_text_text_img = ''
        let normal_date_img_date_week_img = ''
        let normal_date_img_date_day = ''
        let normal_date_img_date_month_img = ''
        let normal_temperature_current_text_img = ''
        let normal_weather_image_progress_img_level = ''
        let normal_digital_clock_img_time = ''
        let idle_temperature_current_text_img = ''
        let idle_weather_image_progress_img_level = ''
        let idle_digital_clock_img_time = ''
        let normal_stopwatch_jumpable_img_click = ''
        let normal_countdown_jumpable_img_click = ''
        let normal_sleep_jumpable_img_click = ''
        let normal_sunrise_jumpable_img_click = ''
        let normal_temperature_jumpable_img_click = ''
        let normal_spo2_jumpable_img_click = ''
        let normal_heart_jumpable_img_click = ''
        let normal_step_jumpable_img_click = ''
        let normal_altimeter_jumpable_img_click = ''


        //dynamic modify end
        const e = __$$hmAppManager$$__.currentApp;
        const o = e.current
          , {px: i} = (new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(e,o)),
        e.__globals__)
          , n = Logger.getLogger("watchface6");
        o.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 466,
              h: 466,
              src: 'bj.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sun_high_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 96,
              y: 78,
              font_array: ["rr0.png","rr1.png","rr2.png","rr3.png","rr4.png","rr5.png","rr6.png","rr7.png","rr8.png","rr9.png"],
              padding: false,
              h_space: 0,
              dot_image: 'fgf.png',
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.SUN_RISE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sun_low_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 75,
              y: 114,
              font_array: ["rr0.png","rr1.png","rr2.png","rr3.png","rr4.png","rr5.png","rr6.png","rr7.png","rr8.png","rr9.png"],
              padding: false,
              h_space: 0,
              dot_image: 'fgf.png',
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.SUN_SET,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 258,
              y: 15,
              src: 'ly001.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 240,
              y: 431,
              font_array: ["hb0.png","hb1.png","hb2.png","hb3.png","hb4.png","hb5.png","hb6.png","hb7.png","hb8.png","hb9.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'bfh.png',
              unit_tc: 'bfh.png',
              unit_en: 'bfh.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 191,
              y: 431,
              image_array: ["d0.png","d1.png","d2.png","d3.png","d4.png","d5.png","d6.png","d7.png","d8.png"],
              image_length: 9,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_moon_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 151,
              y: 13,
              image_array: ["yue001.png","yue002.png","yue003.png","yue004.png","yue005.png","yue006.png","yue007.png","yue008.png","yue009.png","yue010.png","yue011.png","yue012.png","yue013.png","yue014.png","yue015.png","yue016.png","yue017.png","yue018.png","yue019.png","yue020.png","yue021.png","yue022.png","yue023.png","yue024.png","yue025.png","yue026.png","yue027.png","yue028.png","yue029.png","yue030.png"],
              image_length: 30,
              type: hmUI.data_type.MOON,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_wind_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 296,
              y: 52,
              font_array: ["hb0.png","hb1.png","hb2.png","hb3.png","hb4.png","hb5.png","hb6.png","hb7.png","hb8.png","hb9.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'ji.png',
              unit_tc: 'ji.png',
              unit_en: 'ji.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WIND,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_wind_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 219,
              y: 46,
              image_array: ["f1.png","f2.png","f3.png","f4.png","f5.png","f6.png","f7.png","f8.png"],
              image_length: 8,
              type: hmUI.data_type.WIND,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_uvi_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 159,
              y: 222,
              font_array: ["hb0.png","hb1.png","hb2.png","hb3.png","hb4.png","hb5.png","hb6.png","hb7.png","hb8.png","hb9.png"],
              padding: false,
              h_space: 0,
              invalid_image: 'cuowu.png',
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.UVI,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_spo2_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 54,
              y: 222,
              font_array: ["hb0.png","hb1.png","hb2.png","hb3.png","hb4.png","hb5.png","hb6.png","hb7.png","hb8.png","hb9.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'bfh.png',
              unit_tc: 'bfh.png',
              unit_en: 'bfh.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.SPO2,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 45,
              y: 342,
              font_array: ["x00.png","x01.png","x02.png","x03.png","x04.png","x05.png","x06.png","x07.png","x08.png","x09.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 69,
              y: 367,
              image_array: ["xl1.png","xl2.png","xl3.png","xl4.png","xl5.png","xl6.png"],
              image_length: 6,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 65,
              y: 277,
              font_array: ["bushu0.png","bushu1.png","bushu2.png","bushu3.png","bushu4.png","bushu5.png","bushu6.png","bushu7.png","bushu8.png","bushu9.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_altimeter_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 69,
              y: 168,
              font_array: ["bushu0.png","bushu1.png","bushu2.png","bushu3.png","bushu4.png","bushu5.png","bushu6.png","bushu7.png","bushu8.png","bushu9.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.ALTIMETER,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 370,
              y: 280,
              week_en: ["xq1.png","xq2.png","xq3.png","xq4.png","xq5.png","xq6.png","xq7.png"],
              week_tc: ["xq1.png","xq2.png","xq3.png","xq4.png","xq5.png","xq6.png","xq7.png"],
              week_sc: ["xq1.png","xq2.png","xq3.png","xq4.png","xq5.png","xq6.png","xq7.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 323,
              day_startY: 286,
              day_sc_array: ["ri00.png","ri01.png","ri02.png","ri03.png","ri04.png","ri05.png","ri06.png","ri07.png","ri08.png","ri09.png"],
              day_tc_array: ["ri00.png","ri01.png","ri02.png","ri03.png","ri04.png","ri05.png","ri06.png","ri07.png","ri08.png","ri09.png"],
              day_en_array: ["ri00.png","ri01.png","ri02.png","ri03.png","ri04.png","ri05.png","ri06.png","ri07.png","ri08.png","ri09.png"],
              day_zero: 1,
              day_space: 3,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_month_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 231,
              month_startY: 284,
              month_sc_array: ["yf01.png","yf02.png","yf03.png","yf04.png","yf05.png","yf06.png","yf07.png","yf08.png","yf09.png","yf10.png","yf11.png","yf12.png"],
              month_tc_array: ["yf01.png","yf02.png","yf03.png","yf04.png","yf05.png","yf06.png","yf07.png","yf08.png","yf09.png","yf10.png","yf11.png","yf12.png"],
              month_en_array: ["yf01.png","yf02.png","yf03.png","yf04.png","yf05.png","yf06.png","yf07.png","yf08.png","yf09.png","yf10.png","yf11.png","yf12.png"],
              month_is_character: true ,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 339,
              y: 102,
              font_array: ["qw0.png","qw1.png","qw2.png","qw3.png","qw4.png","qw5.png","qw6.png","qw7.png","qw8.png","qw9.png"],
              padding: false,
              h_space: -1,
              unit_sc: 'qwds1.png',
              unit_tc: 'qwds1.png',
              unit_en: 'qwds1.png',
              negative_image: 'qefh.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 178,
              y: 92,
              image_array: ["t001.png","t002.png","t003.png","t004.png","t005.png","t006.png","t007.png","t008.png","t009.png","t010.png","t011.png","t012.png","t013.png","t014.png","t015.png","t016.png","t017.png","t018.png","t019.png","t020.png","t021.png","t022.png","t023.png","t024.png","t025.png","t026.png","t027.png","t028.png","t029.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 231,
              hour_startY: 160,
              hour_array: ["sz0000.png","sz0001.png","sz0002.png","sz0003.png","sz0004.png","sz0005.png","sz0006.png","sz0008.png","sz0009.png","sz007.png"],
              hour_zero: 1,
              hour_space: 0,
              hour_align: hmUI.align.LEFT,

              minute_startX: 363,
              minute_startY: 163,
              minute_array: ["fz0000.png","fz0001.png","fz0002.png","fz0003.png","fz0004.png","fz0005.png","fz0006.png","fz0007.png","fz0008.png","fz0009.png"],
              minute_zero: 1,
              minute_space: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              second_startX: 397,
              second_startY: 245,
              second_array: ["r0.png","r1.png","r2.png","r3.png","r4.png","r5.png","r6.png","r7.png","r8.png","r9.png"],
              second_zero: 0,
              second_space: 0,
              second_follow: 0,
              second_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });



            idle_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 86,
              y: 249,
              font_array: ["qw0.png","qw1.png","qw2.png","qw3.png","qw4.png","qw5.png","qw6.png","qw7.png","qw8.png","qw9.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'qwds1.png',
              unit_tc: 'qwds1.png',
              unit_en: 'qwds1.png',
              negative_image: 'qefh.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 49,
              y: 191,
              image_array: ["t001.png","t002.png","t003.png","t004.png","t005.png","t006.png","t007.png","t008.png","t009.png","t010.png","t011.png","t012.png","t013.png","t014.png","t015.png","t016.png","t017.png","t018.png","t019.png","t020.png","t021.png","t022.png","t023.png","t024.png","t025.png","t026.png","t027.png","t028.png","t029.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 216,
              hour_startY: 182,
              hour_array: ["sz0000.png","sz0001.png","sz0002.png","sz0003.png","sz0004.png","sz0005.png","sz0006.png","sz0008.png","sz0009.png","sz007.png"],
              hour_zero: 1,
              hour_space: 0,
              hour_align: hmUI.align.LEFT,

              minute_startX: 342,
              minute_startY: 188,
              minute_array: ["fz0000.png","fz0001.png","fz0002.png","fz0003.png","fz0004.png","fz0005.png","fz0006.png","fz0007.png","fz0008.png","fz0009.png"],
              minute_zero: 1,
              minute_space: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_AOD,
            });

            normal_stopwatch_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 360,
              y: 161,
              w: 103,
              h: 111,
              src: '0000.png',
              type: hmUI.data_type.STOP_WATCH,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_countdown_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 228,
              y: 157,
              w: 124,
              h: 112,
              src: '0000.png',
              type: hmUI.data_type.COUNT_DOWN,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sleep_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 148,
              y: 425,
              w: 180,
              h: 44,
              src: '0000.png',
              type: hmUI.data_type.SLEEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sunrise_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 43,
              y: 10,
              w: 137,
              h: 131,
              src: '0000.png',
              type: hmUI.data_type.SUN_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 194,
              y: 77,
              w: 226,
              h: 63,
              src: '0000.png',
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_spo2_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 10,
              y: 211,
              w: 106,
              h: 41,
              src: '0000.png',
              type: hmUI.data_type.SPO2,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 33,
              y: 329,
              w: 75,
              h: 78,
              src: '0000.png',
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 9,
              y: 267,
              w: 204,
              h: 44,
              src: '0000.png',
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_altimeter_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 15,
              y: 154,
              w: 192,
              h: 44,
              src: '0000.png',
              type: hmUI.data_type.ALTIMETER,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


                //dynamic modify end
            },
            onInit() {
                n.log("index page.js on init invoke")
            },
            build() {
                this.init_view(),
                n.log("index page.js on ready invoke")
            },
            onDestroy() {
                n.log("index page.js on destroy invoke")
            }
        })
    }
    )()
} catch (e) {
    console.log("Mini Program Error", e),
    e && e.stack && e.stack.split(/\n/).forEach((e=>console.log("error stack", e)))
}
