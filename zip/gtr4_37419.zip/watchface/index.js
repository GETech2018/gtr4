﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        const logger = Logger.getLogger('watchface_SashaCX75');
        //end of ignored block

        //dynamic modify start

        
        let normal_background_bg_img = ''
		let normal_compass_angle_img = ''
		let normal_compass_text_img = ''
		//let normal_compass_text = ''
		let normal_compass_direction_img = ''
		let compass = null 
        // let clockTimer = null
        let normal_system_disconnect_img = ''
        let normal_system_clock_img = ''
        let normal_date_img_date_day = ''
        let normal_date_img_date_week_img = ''
        let normal_pai_icon_img = ''
        let normal_battery_text_text_img = ''
        let normal_battery_pointer_progress_img_pointer = ''
        let normal_heart_rate_text_text_img = ''
        let normal_heart_rate_image_progress_img_level = ''
        let normal_step_current_text_img = ''
        let normal_step_pointer_progress_img_pointer = ''
        let normal_analog_clock_pro_second_pointer_img = ''
        let normal_timerUpdateSecSmooth = undefined;
        let normal_analog_clock_time_pointer_minute = ''
        let normal_analog_clock_time_pointer_hour = ''
        let normal_analog_clock_time_pointer_second = ''
        let idle_background_bg_img = ''
        let idle_analog_clock_time_pointer_hour = ''
        let idle_analog_clock_time_pointer_minute = ''
        let idle_system_disconnect_img = ''
        let normal_spo2_jumpable_img_click = ''
        let normal_heart_jumpable_img_click = ''
        let normal_step_jumpable_img_click = ''
        let timeSensor = ''
		
		let btn_bezel = ''
        let bezel_num = 1
        let bezel_all = 6
     
        function click_Bezel() {
            if(bezel_num>=bezel_all) {bezel_num=1;}
            else { bezel_num=bezel_num+1;}
            hmUI.showToast({text: "<Color> " + parseInt(bezel_num) });
            normal_background_bg_img.setProperty(hmUI.prop.SRC, "bg_" + parseInt(bezel_num) + ".png");
        }
		
		let bot_circle_btn = ''
        let bot_circle_state = 0

        function click_bot_circle_Switcher() {

          let bot_circle_state_total = 4;

          bot_circle_state = (bot_circle_state + 1) % bot_circle_state_total;

          switch (bot_circle_state) {

              case 0:
 
                  normal_analog_clock_time_pointer_hour.setProperty(hmUI.prop.MORE, {
                    hour_path: 'hour_1.png',
                    hour_centerX: 233,
                    hour_centerY: 233,
                    hour_posX: 21,
                    hour_posY: 240,
                    show_level: hmUI.show_level.ONLY_NORMAL,
                  });
      
                  normal_analog_clock_time_pointer_minute.setProperty(hmUI.prop.MORE, {
                    minute_path: 'minute_1.png',
                    minute_centerX: 233,
                    minute_centerY: 233,
                    minute_posX: 22,
                    minute_posY: 230,
                    show_level: hmUI.show_level.ONLY_NORMAL,
                  });
				  
				  normal_analog_clock_time_pointer_second.setProperty(hmUI.prop.MORE, {
                    second_path: 'second_1.png',
                    second_centerX: 233,
                    second_centerY: 233,
                    second_posX: 22,
                    second_posY: 239,
                    show_level: hmUI.show_level.ONLY_NORMAL,
                  });
      
                  bot_circle_state_txt = 'Hands 1';
                  break;

              case 1:

                normal_analog_clock_time_pointer_hour.setProperty(hmUI.prop.MORE, {
                  hour_path: 'hour_2.png',
                  hour_centerX: 233,
                  hour_centerY: 233,
                  hour_posX: 23,
                  hour_posY: 150,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });
    
                normal_analog_clock_time_pointer_minute.setProperty(hmUI.prop.MORE, {
                  minute_path: 'minute_2.png',
                  minute_centerX: 233,
                  minute_centerY: 233,
                  minute_posX: 23,
                  minute_posY: 226,
                 show_level: hmUI.show_level.ONLY_NORMAL,
                });
				
				normal_analog_clock_time_pointer_second.setProperty(hmUI.prop.MORE, {
                  second_path: 'second_2.png',
                  second_centerX: 233,
                  second_centerY: 233,
                  second_posX: 13,
                  second_posY: 227,
                show_level: hmUI.show_level.ONLY_NORMAL,
                });
   
              bot_circle_state_txt = 'Hands 2';
                  break;
				  
			case 2:

                normal_analog_clock_time_pointer_hour.setProperty(hmUI.prop.MORE, {
                  hour_path: 'hour_3.png',
                  hour_centerX: 233,
                  hour_centerY: 233,
                  hour_posX: 24,
                  hour_posY: 153,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });
    
                normal_analog_clock_time_pointer_minute.setProperty(hmUI.prop.MORE, {
                  minute_path: 'minute_3.png',
                  minute_centerX: 233,
                  minute_centerY: 233,
                  minute_posX: 24,
                  minute_posY: 213,
                 show_level: hmUI.show_level.ONLY_NORMAL,
                });
				
				normal_analog_clock_time_pointer_second.setProperty(hmUI.prop.MORE, {
                  second_path: 'second_3.png',
                  second_centerX: 233,
                  second_centerY: 233,
                  second_posX: 14,
                  second_posY: 226,
                show_level: hmUI.show_level.ONLY_NORMAL,
                });
   
              bot_circle_state_txt = 'Hands 3';
                  break;

			case 3:

                normal_analog_clock_time_pointer_hour.setProperty(hmUI.prop.MORE, {
                  hour_path: 'hour_4.png',
                  hour_centerX: 233,
                  hour_centerY: 233,
                  hour_posX: 54,
                  hour_posY: 233,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });
    
                normal_analog_clock_time_pointer_minute.setProperty(hmUI.prop.MORE, {
                  minute_path: 'minute_4.png',
                  minute_centerX: 233,
                  minute_centerY: 233,
                  minute_posX: 55,
                  minute_posY: 232,
                 show_level: hmUI.show_level.ONLY_NORMAL,
                });
				
				normal_analog_clock_time_pointer_second.setProperty(hmUI.prop.MORE, {
                  second_path: 'second_4.png',
                  second_centerX: 233,
                  second_centerY: 233,
                  second_posX: 21,
                  second_posY: 232,
                show_level: hmUI.show_level.ONLY_NORMAL,
                });
   
              bot_circle_state_txt = 'Hands 4';
                  break;	  
    
              default:
                  break;
          }

          hmUI.showToast({ text: bot_circle_state_txt });
      }
	  
	    let btn_zona1 = ''
        let zona1_num = 0
        let zona1_all = 1
		
		function click_zona1() {
		  zona1_num = (zona1_num + 1) % (zona1_all + 1);
          if (zona1_num == 0) {		
		    normal_compass_angle_img.setProperty(hmUI.prop.VISIBLE, true);
            normal_compass_text_img.setProperty(hmUI.prop.VISIBLE, true);
			normal_compass_direction_img.setProperty(hmUI.prop.VISIBLE, true);
			normal_analog_clock_time_pointer_second.setProperty(hmUI.prop.VISIBLE, true);
			normal_date_img_date_day.setProperty(hmUI.prop.VISIBLE, false);
			normal_analog_clock_pro_second_pointer_img.setProperty(hmUI.prop.VISIBLE, false);
          };
		  
		 if (zona1_num == 1) {
			normal_compass_angle_img.setProperty(hmUI.prop.VISIBLE, false);
            normal_compass_text_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_compass_direction_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_date_img_date_day.setProperty(hmUI.prop.VISIBLE, true);
			normal_analog_clock_time_pointer_second.setProperty(hmUI.prop.VISIBLE, false);
			normal_analog_clock_pro_second_pointer_img.setProperty(hmUI.prop.VISIBLE, true);
          };
        }
		
		let delay_Timer = null;
        let clicks = 0;
        let clicksDelay = 400;       
		

          function checkClicks() {

            switch(clicks) {
              case 1:
                click_Bezel();
             break;
              case 2:
                click_bot_circle_Switcher(); 
             break;
              case 3:
                click_zona1();
             //break;
             // case 4:
               // функции на 4-ной клик
             //break;
              default:
             break;
           }
            
           timer.stopTimer(delay_Timer);
           clicks = 0;

          }
            
        
      
              function getClick() {		
      
            clicks++;
            if(delay_Timer) timer.stopTimer(delay_Timer);
            delay_Timer = timer.createTimer(clicksDelay, 0, checkClicks, {});
      
              }


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            console.log('Watch_Face.ScreenNormal');
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 466,
              h: 466,
              src: 'bg_1.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 113,
              y: 122,
              src: 'bt.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 329,
              y: 122,
              src: 'alarm.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 205,
              day_startY: 80,
              day_sc_array: ["date_0.png","date_1.png","date_2.png","date_3.png","date_4.png","date_5.png","date_6.png","date_7.png","date_8.png","date_9.png"],
              day_tc_array: ["date_0.png","date_1.png","date_2.png","date_3.png","date_4.png","date_5.png","date_6.png","date_7.png","date_8.png","date_9.png"],
              day_en_array: ["date_0.png","date_1.png","date_2.png","date_3.png","date_4.png","date_5.png","date_6.png","date_7.png","date_8.png","date_9.png"],
              day_zero: 1,
              day_space: 0,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 164,
              y: 137,
              week_en: ["week_1.png","week_2.png","week_3.png","week_4.png","week_5.png","week_6.png","week_7.png"],
              week_tc: ["week_1.png","week_2.png","week_3.png","week_4.png","week_5.png","week_6.png","week_7.png"],
              week_sc: ["week_1.png","week_2.png","week_3.png","week_4.png","week_5.png","week_6.png","week_7.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
			
			normal_compass_angle_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              pos_x: 0,
              pos_y: 0,
              center_x: 466 / 2,
              center_y: 466 / 2,
              angle: 0,
              src: 'bgpoint.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
			
			normal_compass_direction_img = hmUI.createWidget(hmUI.widget.IMG, {
                x: 205,
                y: 115,
                src: 'direction-NULL.png',
                show_level: hmUI.show_level.ONLY_NORMAL,
            });
			
			normal_compass_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 185,
              y: 80,
              font_array: ["data-0.png","data-1.png","data-2.png","data-3.png","data-4.png","data-5.png","data-6.png","data-7.png","data-8.png","data-9.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'data-degrees.png',
              unit_tc: 'data-degrees.png',
              unit_en: 'data-degrees.png',
            //   unit_sc: 'data-dash.png',
            //   unit_tc: 'data-dash.png',
            //   unit_en: 'data-dash.png',
              align_h: hmUI.align.CENTER_H,
            //   type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
			
			normal_compass_text = hmUI.createWidget(hmUI.widget.TEXT, {
                x: 120,
                y: 350,
                w: 140,
                h: 50,
                color: 0xe02020,
                text_size: 36,
                align_h: hmUI.align.CENTER_H,
                align_v: hmUI.align.CENTER_V,
                text_style: hmUI.text_style.NONE,
                text: '',
                show_level: hmUI.show_level.ONLY_NORMAL,
              })

            normal_pai_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'bg2.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 90,
              y: 245,
              font_array: ["num_0.png","num_1.png","num_2.png","num_3.png","num_4.png","num_5.png","num_6.png","num_7.png","num_8.png","num_9.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'percent.png',
              unit_tc: 'percent.png',
              unit_en: 'percent.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_pointer_progress_img_pointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
              src: 'batpoint.png',
              center_x: 128,
              center_y: 231,
              x: 82,
              y: 82,
              start_angle: 0,
              end_angle: 360,
              invalid_visible: false,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 204,
              y: 380,
              font_array: ["num_0.png","num_1.png","num_2.png","num_3.png","num_4.png","num_5.png","num_6.png","num_7.png","num_8.png","num_9.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 151,
              y: 269,
              image_array: ["heart_1.png","heart_2.png","heart_3.png","heart_4.png","heart_5.png","heart_6.png"],
              image_length: 6,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 292,
              y: 245,
              font_array: ["num_0.png","num_1.png","num_2.png","num_3.png","num_4.png","num_5.png","num_6.png","num_7.png","num_8.png","num_9.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_pointer_progress_img_pointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
              src: 'batpoint.png',
              center_x: 339,
              center_y: 232,
              x: 82,
              y: 82,
              start_angle: 0,
              end_angle: 360,
              invalid_visible: false,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            const deviceInfo = hmSetting.getDeviceInfo();
            if (!timeSensor) timeSensor = hmSensor.createSensor(hmSensor.id.TIME);
            // normal_analog_clock_pro_second_pointer_img = hmUI.createWidget(hmUI.widget.TIME_POINTER_PRO, {
              // src: 'sec_bezel.png',
              // center_x: 233,
              // center_y: 233,
              // x: 267,
              // y: 267,
              // start_angle: 0,
              // end_angle: 360,
              // type: hmUI.data_type.second,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });


            normal_analog_clock_pro_second_pointer_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: deviceInfo.width,
              h: deviceInfo.height,
              pos_x: 233 - 267,
              pos_y: 233 - 267,
              center_x: 233,
              center_y: 233,
              src: 'sec_bezel.png',
              angle: 0,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            let screenType = hmSetting.getScreenType();
            // normal_analog_clock_pro_smooth_second = hmUI.createWidget(hmUI.widget.SMOOTH_SECOND, {
              // type: 2,
              // fps: 6,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });


            normal_analog_clock_time_pointer_minute = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              minute_path: 'minute_1.png',
              minute_centerX: 233,
              minute_centerY: 233,
              minute_posX: 22,
              minute_posY: 230,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_hour = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              hour_path: 'hour_1.png',
              hour_centerX: 233,
              hour_centerY: 233,
              hour_posX: 21,
              hour_posY: 240,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_second = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              second_path: 'second_1.png',
              second_centerX: 233,
              second_centerY: 233,
              second_posX: 22,
              second_posY: 239,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            console.log('Watch_Face.ScreenAOD');
            idle_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 466,
              h: 466,
              src: 'aodbg.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_analog_clock_time_pointer_hour = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              hour_path: 'hour_2.png',
              hour_centerX: 233,
              hour_centerY: 233,
              hour_posX: 23,
              hour_posY: 149,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_analog_clock_time_pointer_minute = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              minute_path: 'minute_2.png',
              minute_centerX: 233,
              minute_centerY: 233,
              minute_posX: 23,
              minute_posY: 226,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 222,
              y: 222,
              src: 'bt.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_AOD,
            });
            console.log('Watch_Face.Shortcuts');

            hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 84,
              y: 195,
              w: 65,
              h: 65,
			  text: '',
			  normal_src: 'Empty.png',
			  press_src: 'Empty.png',
			  click_func: () => {
				hmApp.startApp({ url: 'Settings_batteryManagerScreen', native: true });
			  },
			  show_level: hmUI.show_level.ONLY_NORMAL,
			});

            normal_heart_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 185,
              y: 305,
              w: 100,
              h: 100,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 302,
              y: 195,
              w: 80,
              h: 80,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
			
			bot_circle_btn = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 202,
              y: 202,
              text: '',
              w: 65,
              h: 65,
              normal_src: 'Empty.png',
              press_src: 'Empty.png',
              click_func: () => {
                  getClick();
                  //vibro(9);
              },
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
              bot_circle_btn.setProperty(hmUI.prop.VISIBLE, true);
			  
			btn_zona1 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 0,
              y: 0,
              text: '',
              w: 65,
              h: 65,
              normal_src: 'Empty.png',
              press_src: 'Empty.png',
              click_func: () => {
				click_zona1();
                click_Vibrate();
             },
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            btn_zona1.setProperty(hmUI.prop.VISIBLE, true);
			normal_date_img_date_day.setProperty(hmUI.prop.VISIBLE, false);
			normal_analog_clock_pro_second_pointer_img.setProperty(hmUI.prop.VISIBLE, false);
			
			hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 95,
              y: 325, 
              text: '',
              w: 55, 
              h: 55, 
              normal_src: 'Empty.png',
              press_src: 'Empty.png',
			   click_func: () => { 
              hmApp.startApp({ url: 'PhoneRecentCallScreen', native: true });
              },
               longpress_func: () => {
              hmApp.startApp({ url: 'PhoneContactsScreen', native: true });
              },
                show_level: hmUI.show_level.ONLY_NORMAL,
            });
			
			hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 315,
              y: 325, 
              text: '',
              w: 55, 
              h: 55, 
              normal_src: 'Empty.png',
              press_src: 'Empty.png',
               click_func: () => {   
              hmApp.startApp({ url: 'LocalMusicScreen', native: true });
              },
               longpress_func: () => {
              hmApp.startApp({ url: 'PhoneMusicCtrlScreen', native: true });
              },
                show_level: hmUI.show_level.ONLY_NORMAL,
            });

            function time_update(updateHour = false, updateMinute = false) {
              console.log('time_update()');
              let hour = timeSensor.hour;
              let minute = timeSensor.minute;
              let second = timeSensor.second;

              let normal_fullAngle_second = 360;
              let normal_angle_second = 0 + normal_fullAngle_second*(second + (timeSensor.utc % 1000)/1000)/60;
              if (normal_analog_clock_pro_second_pointer_img) normal_analog_clock_pro_second_pointer_img.setProperty(hmUI.prop.ANGLE, normal_angle_second);

            };
			
			const screen_type = hmSetting.getScreenType()
            if(screen_type == hmSetting.screen_type.WATCHFACE){
                compass = hmSensor.createSensor(hmSensor.id.COMPASS)
                compass.start()

               if (compass.direction_angle && compass.direction  && compass.direction_angle != 'INVALID') {
                    let compass_direction_angle = `${compass.direction_angle}`;
                    let compass_direction_angle_direction = `${compass.direction_angle}° ${compass.direction}`;
                    normal_compass_text_img.setProperty(hmUI.prop.TEXT, compass_direction_angle);
                    //normal_compass_text.setProperty(hmUI.prop.TEXT, compass_direction_angle_direction);
                    // compass_text.setProperty(hmUI.prop.TEXT,`${compass.direction_angle}°${compass.direction}`)
                    normal_compass_angle_img.setProperty(hmUI.prop.ANGLE, -compass.direction_angle);
                    normal_compass_direction_img.setProperty(hmUI.prop.SRC, `direction-${compass.direction}.png`);
                } else {
                    normal_compass_text_img.setProperty(hmUI.prop.TEXT,`- -`);
                    //normal_compass_text.setProperty(hmUI.prop.TEXT,`- -`);
                    normal_compass_angle_img.setProperty(hmUI.prop.ANGLE, 0);
                    normal_compass_direction_img.setProperty(hmUI.prop.SRC, "direction-NULL.png");
                }


                compass.addEventListener(hmSensor.event.CHANGE, function (compass_res) { // меняем надписи при изменении направления
                    if (compass_res.calibration_status) {
                        let compass_direction_angle = `${compass_res.direction_angle}`;
                        let compass_direction_angle_direction = `${compass_res.direction_angle}° ${compass_res.direction}`;
                        normal_compass_text_img.setProperty(hmUI.prop.TEXT, compass_direction_angle);
                        //normal_compass_text.setProperty(hmUI.prop.TEXT, compass_direction_angle_direction);
                        normal_compass_angle_img.setProperty(hmUI.prop.ANGLE, -compass_res.direction_angle);
                        normal_compass_direction_img.setProperty(hmUI.prop.SRC, `direction-${compass_res.direction}.png`);
                    } else {
                        normal_compass_text_img.setProperty(hmUI.prop.TEXT,`- -`);
                        //normal_compass_text.setProperty(hmUI.prop.TEXT,`- -`);
                        normal_compass_angle_img.setProperty(hmUI.prop.ANGLE, 0);
                        normal_compass_direction_img.setProperty(hmUI.prop.SRC, "direction-NULL.png");
                    }

                })
            }

            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                console.log('resume_call()');
                // if (compass) {
                    //     const screenType = hmSetting.getScreenType()
                    //     if(screenType == hmSetting.screen_type.WATCHFACE){
                    //         clockTimer = timer.createTimer(500, 0, (function (option) {
                    //             compass.start()
                    //             timer.stopTimer(clockTimer)
                    //             clockTimer = null
                    //             }
                    //         ))
                    //     }
      
                    // }
                    if (compass) compass.start();
				time_update(true, true);
                if (screenType == hmSetting.screen_type.WATCHFACE) {
                  if (!normal_timerUpdateSecSmooth) {
                    let animDelay = 0;
                    let animRepeat = 1000/6;
                    normal_timerUpdateSecSmooth = timer.createTimer(animDelay, animRepeat, (function (option) {
                      time_update(false, false);
                    }));  // end timer 
                  };  // end timer check
                };  // end screenType


              }),
              pause_call: (function () {
                console.log('pause_call()');
                // if(clockTimer) {
                    //     timer.stopTimer(clockTimer)
                    //     clockTimer = null
                    // }
                    if (compass) compass.stop();
				if (normal_timerUpdateSecSmooth) {
                  timer.stopTimer(normal_timerUpdateSecSmooth);
                  normal_timerUpdateSecSmooth = undefined;
                }

              }),
            });

                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}