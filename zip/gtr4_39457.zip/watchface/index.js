﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        const logger = Logger.getLogger('watchface_SashaCX75');
        //end of ignored block

        //dynamic modify start

        
        let normal_analog_clock_time_pointer_second = ''
        let normal_pai_icon_img = ''
        let normal_battery_pointer_progress_img_pointer = ''
        let normal_digital_clock_img_time = ''


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            console.log('Watch_Face.ScreenNormal');

            normal_analog_clock_time_pointer_second = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              second_path: 'bezelsecon.png',
              second_centerX: 233,
              second_centerY: 233,
              second_posX: 226,
              second_posY: 226,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_pai_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'bg.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_pointer_progress_img_pointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
              src: 'wfs_min_350a9624_397a_49d4_a651_f7488db5061f.png',
              center_x: 233,
              center_y: 233,
              x: 36,
              y: 208,
              start_angle: -157,
              end_angle: -23,
              invalid_visible: false,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 195,
              hour_startY: 180,
              hour_array: ["wfs_0_31db4855_32e6_489b_a53e_3135e8f1a190.png","wfs_1_030ea17d_fee5_422b_a62f_700e9ad12845.png","wfs_2_9ac50aae_d4d0_422e_bf77_ff8c167c9baf.png","wfs_3_5e214ee8_da6a_4f7e_b10c_fd08a1b0aa18.png","wfs_4_6b2a9dd9_5690_4a1f_834c_32ad6184301e.png","wfs_5_658bf497_157f_4565_b81f_55b6bac2c391.png","wfs_6_5d2bb7ef_7bbe_47d9_8721_446592546046.png","wfs_7_6ee3494b_f37b_42f5_be3f_7ae15bcfe138.png","wfs_8_3dd3e97f_917e_43b5_aba5_b7a25308082a.png","wfs_9_32db485f_03f0_4f24_8a62_fd8413f767dd.png"],
              hour_zero: 1,
              hour_space: 5,
              hour_angle: 0,
              hour_align: hmUI.align.LEFT,

              minute_startX: 195,
              minute_startY: 243,
              minute_array: ["wfs_0_31db4855_32e6_489b_a53e_3135e8f1a190.png","wfs_1_030ea17d_fee5_422b_a62f_700e9ad12845.png","wfs_2_9ac50aae_d4d0_422e_bf77_ff8c167c9baf.png","wfs_3_5e214ee8_da6a_4f7e_b10c_fd08a1b0aa18.png","wfs_4_6b2a9dd9_5690_4a1f_834c_32ad6184301e.png","wfs_5_658bf497_157f_4565_b81f_55b6bac2c391.png","wfs_6_5d2bb7ef_7bbe_47d9_8721_446592546046.png","wfs_7_6ee3494b_f37b_42f5_be3f_7ae15bcfe138.png","wfs_8_3dd3e97f_917e_43b5_aba5_b7a25308082a.png","wfs_9_32db485f_03f0_4f24_8a62_fd8413f767dd.png"],
              minute_zero: 1,
              minute_space: 5,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });




                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}