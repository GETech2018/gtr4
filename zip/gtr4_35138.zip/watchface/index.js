﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        const logger = Logger.getLogger('watchface_SashaCX75');
        //end of ignored block

        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_step_current_text_img = ''
        let normal_heart_rate_text_text_img = ''
        let normal_digital_clock_img_time = ''
		
		let heart = hmSensor.createSensor(hmSensor.id.HEART);
        let heartArr = ''

        function HeartUpdate() {
          heartArr = heart.today
          min_heart_txt.setProperty(hmUI.prop.TEXT, Math.min(...heartArr).toString())
          max_heart_txt.setProperty(hmUI.prop.TEXT, Math.max(...heartArr).toString())
        }

        heart.addEventListener(hmSensor.event.CHANGE, function () {
          HeartUpdate()
        })


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 466,
              h: 466,
              src: 'bg.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 278,
              y: 135,
              font_array: ["n_0.png","n_1.png","n_2.png","n_3.png","n_4.png","n_5.png","n_6.png","n_7.png","n_8.png","n_9.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 210,
              y: 380,
              font_array: ["nm_0.png","nm_1.png","nm_2.png","nm_3.png","nm_4.png","nm_5.png","nm_6.png","nm_7.png","nm_8.png","nm_9.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'icon.png',
              unit_tc: 'icon.png',
              unit_en: 'icon.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
			
			min_heart_txt = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 70,
              y: 130,
              w: 50,
              h: 50,
              text_size: 25,
              text: '',
              color: 0xffffff,
              align_h: hmUI.align.LEFT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            max_heart_txt = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 140,
              y: 130,
              w: 50,
              h: 50,
              text_size: 25,
              text: '',
              color: 0xffffff,
              align_h: hmUI.align.CENTR,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
			
			hmUI.createWidget(hmUI.widget.GRADKIENT_POLYLINE, {
              x: 45,
              y: 225,
              w: 350,
              h: 100,
              line_color: 0xcc2124,
              line_width: 3,
              curve_style: true,
              type: hmUI.data_type.HEART
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 132,
              hour_startY: 50,
              hour_array: ["time_0.png","time_1.png","time_2.png","time_3.png","time_4.png","time_5.png","time_6.png","time_7.png","time_8.png","time_9.png"],
              hour_zero: 1,
              hour_space: 0,
              hour_angle: 0,
              hour_align: hmUI.align.RIGHT,

              minute_startX: 249,
              minute_startY: 50,
              minute_array: ["time_0.png","time_1.png","time_2.png","time_3.png","time_4.png","time_5.png","time_6.png","time_7.png","time_8.png","time_9.png"],
              minute_zero: 1,
              minute_space: 0,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              second_startX: 337,
              second_startY: 79,
              second_array: ["n_0.png","n_1.png","n_2.png","n_3.png","n_4.png","n_5.png","n_6.png","n_7.png","n_8.png","n_9.png"],
              second_zero: 1,
              second_space: 0,
              second_angle: 0,
              second_follow: 0,
              second_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });
			
			const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                HeartUpdate()

              }),
              pause_call: (function () {

              }),
            });




                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}