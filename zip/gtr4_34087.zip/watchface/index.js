/*
** Facemaker bundle tool v0.0.3
* *huamiOS watchface js version v2.0.1
* *Copyright © Huami. All Rights Reserved
*/


try {
	(() => {
		var __$$app$$__ = __$$hmAppManager$$__.currentApp;
		var __$$module$$__ = __$$app$$__.current;

		//drink is a name,can modify
		var h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__), 'drink');

		'use strict';

		//dynamic modify start
		let normal_img0 = '';
		let normal_img1 = '';
		let normal_img2 = '';
		let normal_steps_rotary4 = '';
		let normal_battery_rotary6 = '';
		let normal_minute_rotary8 = '';
		let normal_hour_rotary9 = '';
		let normal_second_rotary10 = '';
		let normal_img11 = '';
		let timeInterval;
		let normal_second_low_imageset13 = '';
		let normal_second_low_imageset13_array = ['0010.png','0011.png','0010.png','0011.png','0010.png','0011.png','0010.png','0011.png','0010.png','0011.png'];
		let normal_hour_high_imageset14 = '';
		let normal_hour_high_imageset14_array = ['0012.png','0013.png','0014.png'];
		let normal_hour_low_imageset15 = '';
		let normal_hour_low_imageset15_array = ['0012.png','0013.png','0014.png','0015.png','0016.png','0017.png','0018.png','0019.png','0020.png','0021.png'];
		let normal_minute_high_imageset16 = '';
		let normal_minute_high_imageset16_array = ['0012.png','0013.png','0014.png','0015.png','0016.png','0017.png'];
		let normal_minute_low_imageset17 = '';
		let normal_minute_low_imageset17_array = ['0012.png','0013.png','0014.png','0015.png','0016.png','0017.png','0018.png','0019.png','0020.png','0021.png'];
		let normal_second_high_imageset18 = '';
		let normal_second_high_imageset18_array = ['0022.png','0023.png','0024.png','0025.png','0026.png','0027.png'];
		let normal_second_low_imageset19 = '';
		let normal_second_low_imageset19_array = ['0022.png','0023.png','0024.png','0025.png','0026.png','0027.png','0028.png','0029.png','0030.png','0031.png'];
		let normal_date_imagecombo21 = '';
		let normal_month_imageset22 = '';
		let normal_week_imageset23 = '';
		let normal_sleep_shortcut26 = '';
		let normal_steps_shortcut27 = '';
		let idle_img29 = '';
		let idle_minute_rotary31 = '';
		let idle_hour_rotary32 = '';
		let idle_second_sweep_rotary33 = '';
		let clock_timer;
		//dynamic modify end

		//not required
		const logger = DeviceRuntimeCore.HmLogger.getLogger("yeguang");

		__$$module$$__.module = DeviceRuntimeCore.WatchFace({
			init_view() {

				const timeSensor = hmSensor.createSensor(hmSensor.id.TIME);
				let screenType = hmSetting.getScreenType();

				normal_img0 = hmUI.createWidget(hmUI.widget.IMG, {
					x: -8,
					y: -7,
					w: 481,
					h: 480,
					src: '0002.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img1 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 158,
					y: 342,
					w: 128,
					h: 60,
					src: '0003.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img2 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 294,
					y: 367,
					w: 28,
					h: 30,
					src: '0004.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_steps_rotary4 = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
					src: '0005.png',
					center_x: 234,
					center_y: 234,
					x: 241,
					y: 240,
					start_angle: 138,
					end_angle: 41,
					type: hmUI.data_type.STEP,
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_battery_rotary6 = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
					src: '0005.png',
					center_x: 234,
					center_y: 234,
					x: 241,
					y: 240,
					start_angle: -139,
					end_angle: -42,
					type: hmUI.data_type.BATTERY,
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_minute_rotary8 = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
					minute_path: '0006.png',
					minute_centerX: 233,
					minute_centerY: 233,
					minute_posX: 233,
					minute_posY: 233,
					minute_start_angle: 0,
					minute_end_angle: 360,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_hour_rotary9 = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
					hour_path: '0007.png',
					hour_centerX: 234,
					hour_centerY: 233,
					hour_posX: 234,
					hour_posY: 233,
					hour_start_angle: 0,
					hour_end_angle: 360,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_second_rotary10 = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
					second_path: '0008.png',
					second_centerX: 233,
					second_centerY: 233,
					second_posX: 233,
					second_posY: 233,
					second_start_angle: 0,
					second_end_angle: 360,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img11 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 0,
					y: 1,
					w: 465,
					h: 465,
					src: '0009.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_second_low_imageset13 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 214,
					y: 343,
					w: 215,
					h: 343,
					src: '0011.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				})

				normal_hour_high_imageset14 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 159,
					y: 343,
					w: 158,
					h: 343,
					src: '0014.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				})

				normal_hour_low_imageset15 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 186,
					y: 343,
					w: 187,
					h: 343,
					src: '0021.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				})

				normal_minute_high_imageset16 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 230,
					y: 343,
					w: 229,
					h: 343,
					src: '0017.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				})

				normal_minute_low_imageset17 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 259,
					y: 343,
					w: 258,
					h: 343,
					src: '0021.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				})

				normal_second_high_imageset18 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 294,
					y: 368,
					w: 293,
					h: 368,
					src: '0027.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				})

				normal_second_low_imageset19 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 310,
					y: 368,
					w: 309,
					h: 368,
					src: '0031.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				})

				normal_date_imagecombo21 = hmUI.createWidget(hmUI.widget.IMG_DATE, {
					day_startX: 213,
					day_startY: 79,
					day_sc_array: ["0032.png","0033.png","0034.png","0035.png","0036.png","0037.png","0038.png","0039.png","0040.png","0041.png"],
					day_tc_array: ["0032.png","0033.png","0034.png","0035.png","0036.png","0037.png","0038.png","0039.png","0040.png","0041.png"],
					day_en_array: ["0032.png","0033.png","0034.png","0035.png","0036.png","0037.png","0038.png","0039.png","0040.png","0041.png"],
					day_zero: false,
					day_space: 0,
					day_align: hmUI.align.LEFT,
					day_is_character: false,
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_month_imageset22 = hmUI.createWidget(hmUI.widget.IMG_DATE, {
					month_startX: 176,
					month_startY: 114,
					month_sc_array: ["0042.png","0043.png","0044.png","0045.png","0046.png","0047.png","0048.png","0049.png","0050.png","0051.png","0052.png","0053.png"],
					month_tc_array: ["0042.png","0043.png","0044.png","0045.png","0046.png","0047.png","0048.png","0049.png","0050.png","0051.png","0052.png","0053.png"],
					month_en_array: ["0042.png","0043.png","0044.png","0045.png","0046.png","0047.png","0048.png","0049.png","0050.png","0051.png","0052.png","0053.png"],
					month_is_character: true,
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_week_imageset23 = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
					x: 154,
					y: 46,
					week_en: ["0054.png","0055.png","0056.png","0057.png","0058.png","0059.png","0060.png"],
					week_tc: ["0054.png","0055.png","0056.png","0057.png","0058.png","0059.png","0060.png"],
					week_sc: ["0054.png","0055.png","0056.png","0057.png","0058.png","0059.png","0060.png"],
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_sleep_shortcut26 = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
					x: 183,
					y: 183,
					w: 100,
					h: 100,
					src: '',
					type: hmUI.data_type.SLEEP,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_steps_shortcut27 = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
					x: 312,
					y: 114,
					w: 50,
					h: 50,
					src: '',
					type: hmUI.data_type.STEP,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				idle_img29 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 0,
					y: 0,
					w: 467,
					h: 466,
					src: '0061.png',
					enable: false,
					show_level: hmUI.show_level.ONAL_AOD,
				});

				idle_minute_rotary31 = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
					minute_path: '0062.png',
					minute_centerX: 234,
					minute_centerY: 233,
					minute_posX: 234,
					minute_posY: 233,
					minute_start_angle: 0,
					minute_end_angle: 360,
					show_level: hmUI.show_level.ONAL_AOD,
				});

				idle_hour_rotary32 = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
					hour_path: '0063.png',
					hour_centerX: 234,
					hour_centerY: 233,
					hour_posX: 234,
					hour_posY: 233,
					hour_start_angle: 0,
					hour_end_angle: 360,
					show_level: hmUI.show_level.ONAL_AOD,
				});

				idle_second_sweep_rotary33 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 0,
					y: 0,
					w: 466,
					h: 466,
					center_x: 233,
					center_y: 233,
					pos_x: 0,
					pos_y: 0,
					src: '0009.png',
					enable: false,
					show_level: hmUI.show_level.ONAL_AOD,
				});

				function updateTime() {
					normal_second_low_imageset13.setProperty(hmUI.prop.MORE, {
						src: normal_second_low_imageset13_array[(timeSensor.second.toString().length == 2 ? timeSensor.second.toString().charAt(1) : timeSensor.second.toString().charAt(0))]
					})
					normal_hour_high_imageset14.setProperty(hmUI.prop.MORE, {
						src: normal_hour_high_imageset14_array[(timeSensor.format_hour.toString().length == 2 ? timeSensor.format_hour.toString().charAt(0) : 0)]
					})
					normal_hour_low_imageset15.setProperty(hmUI.prop.MORE, {
						src: normal_hour_low_imageset15_array[(timeSensor.format_hour.toString().length == 2 ? timeSensor.format_hour.toString().charAt(1) : timeSensor.format_hour.toString().charAt(0))]
					})
					normal_minute_high_imageset16.setProperty(hmUI.prop.MORE, {
						src: normal_minute_high_imageset16_array[(timeSensor.minute.toString().length == 2 ? timeSensor.minute.toString().charAt(0) : 0)]
					})
					normal_minute_low_imageset17.setProperty(hmUI.prop.MORE, {
						src: normal_minute_low_imageset17_array[(timeSensor.minute.toString().length == 2 ? timeSensor.minute.toString().charAt(1) : timeSensor.minute.toString().charAt(0))]
					})
					normal_second_high_imageset18.setProperty(hmUI.prop.MORE, {
						src: normal_second_high_imageset18_array[(timeSensor.second.toString().length == 2 ? timeSensor.second.toString().charAt(0) : 0)]
					})
					normal_second_low_imageset19.setProperty(hmUI.prop.MORE, {
						src: normal_second_low_imageset19_array[(timeSensor.second.toString().length == 2 ? timeSensor.second.toString().charAt(1) : timeSensor.second.toString().charAt(0))]
					})
				}

				timeSensor.addEventListener(hmSensor.event.CHANGE, function() {
					updateTime();
				});

				const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
					resume_call: (function () {
						const animFps = 60;
						const animRepeat = 1000/animFps;
						const animProgress = 6/animFps;
						let animAngle = 0;
						let animDelay = 0;
						clock_timer = timer.createTimer(animDelay, animRepeat, (function(option) {
							animAngle = timeSensor.second * 6 + ((timeSensor.utc % 1000) / 1000) * 6;
							idle_second_sweep_rotary33.setProperty(hmUI.prop.ANGLE, animAngle);
						}));

						updateTime();
						timeInterval = setInterval(updateTime, 1000);
					}),
					pause_call: (function () {
						timer.stopTimer(clock_timer);
						clearInterval(timeInterval);
					}),
				})
			},

		onInit() {
			console.log('index page.js on init invoke')
			this.init_view()
		},
		onReady() {
			console.log('index page.js on ready invoke')
		},
		onShow() {
			console.log('index page.js on show invoke')
		},
		onHide() {
			console.log('index page.js on hide invoke')
		},
		onDestroy() {
			console.log('index page.js on destroy invoke')
						timer.stopTimer(clock_timer);
		},
	});	})()
} catch (e) {
	console.log(e)
}