﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        const logger = Logger.getLogger('watchface_SashaCX75');
        //end of ignored block

        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_heart_rate_text_text_img = ''
        let normal_heart_rate_text_separator_img = ''
        let normal_heart_rate_pointer_progress_img_pointer = ''
        let normal_calorie_current_text_img = ''
        let normal_calorie_current_separator_img = ''
        let normal_calorie_pointer_progress_img_pointer = ''
        let normal_step_current_text_img = ''
        let normal_step_current_separator_img = ''
        let normal_step_pointer_progress_img_pointer = ''
        let normal_battery_icon_img = ''
        let normal_battery_image_progress_img_level = ''
        let normal_battery_text_text_img = ''
        let normal_battery_text_separator_img = ''
        let normal_date_img_date_week_img = ''
        let normal_date_img_date_day = ''
        let normal_moon_image_progress_img_level = ''
        let normal_compass_direction_pointer_img = ''
        let normal_analog_clock_time_pointer_hour = ''
        let normal_analog_clock_time_pointer_minute = ''
        let normal_analog_clock_time_pointer_second = ''
        let idle_background_bg_img = ''
        let idle_battery_icon_img = ''
        let idle_battery_text_text_img = ''
        let idle_date_img_date_week_img = ''
        let idle_date_img_date_day = ''
        let idle_analog_clock_time_pointer_hour = ''
        let idle_analog_clock_time_pointer_minute = ''
        let normal_step_jumpable_img_click = ''
        let normal_moon_jumpable_img_click = ''
        let normal_countdown_jumpable_img_click = ''
        let Button_1 = ''
        let Button_2 = ''
        let Button_3 = ''
		
		let btn_zona1 = ''
        let zona1_num = 0
        let zona1_all = 2
		
		function click_zona1() {
		  zona1_num = (zona1_num + 1) % (zona1_all + 1);
          if (zona1_num == 0) {		
		    normal_step_current_text_img.setProperty(hmUI.prop.VISIBLE, true);
            normal_step_current_separator_img.setProperty(hmUI.prop.VISIBLE, true);
			normal_step_pointer_progress_img_pointer.setProperty(hmUI.prop.VISIBLE, true);
			normal_calorie_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_calorie_current_separator_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_calorie_pointer_progress_img_pointer.setProperty(hmUI.prop.VISIBLE, false);
			normal_heart_rate_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_heart_rate_text_separator_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_heart_rate_pointer_progress_img_pointer.setProperty(hmUI.prop.VISIBLE, false);
		    hmUI.showToast({
            });
          };
		  
		 if (zona1_num == 1) {
			normal_step_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
            normal_step_current_separator_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_step_pointer_progress_img_pointer.setProperty(hmUI.prop.VISIBLE, false);
			normal_calorie_current_text_img.setProperty(hmUI.prop.VISIBLE, true);
			normal_calorie_current_separator_img.setProperty(hmUI.prop.VISIBLE, true);
			normal_calorie_pointer_progress_img_pointer.setProperty(hmUI.prop.VISIBLE, true);
			normal_heart_rate_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_heart_rate_text_separator_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_heart_rate_pointer_progress_img_pointer.setProperty(hmUI.prop.VISIBLE, false);
		    hmUI.showToast({
            });
          };
		  
		  if (zona1_num == 2) {
			normal_step_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
            normal_step_current_separator_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_step_pointer_progress_img_pointer.setProperty(hmUI.prop.VISIBLE, false);
			normal_calorie_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_calorie_current_separator_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_calorie_pointer_progress_img_pointer.setProperty(hmUI.prop.VISIBLE, false);
			normal_heart_rate_text_text_img.setProperty(hmUI.prop.VISIBLE, true);
			normal_heart_rate_text_separator_img.setProperty(hmUI.prop.VISIBLE, true);
			normal_heart_rate_pointer_progress_img_pointer.setProperty(hmUI.prop.VISIBLE, true);
		    hmUI.showToast({
            });
          };
        }
		
		let longPress_Timer = null;
	    let longPressDelay = 900;   // задержка на долгое нажатие в мс
		
		function getLongPress1() {
		    if(longPress_Timer) timer.stopTimer(longPress_Timer);
			
			let url;

			switch(zona1_num) {
			   case 0:
					url = 'activityAppScreen';
				break;
			   case 1:
					url = 'PAI_app_Screen';
				break;
			   case 2:
					url = 'heart_app_Screen';
				break;
			   default:
				break;
			}
			hmApp.startApp({ url: url, native: true });
			
	    }


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            console.log('Watch_Face.ScreenNormal');
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 466,
              h: 466,
              src: 'bg.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 117,
              y: 257,
              font_array: ["A100_055.png","A100_056.png","A100_057.png","A100_058.png","A100_059.png","A100_060.png","A100_061.png","A100_062.png","A100_063.png","A100_064.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 100,
              y: 164,
              src: 'heart.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_pointer_progress_img_pointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
              src: 'A100_012.png',
              center_x: 144,
              center_y: 232,
              x: 19,
              y: 95,
              start_angle: -180,
              end_angle: 0,
              invalid_visible: false,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_calorie_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 106,
              y: 257,
              font_array: ["A100_055.png","A100_056.png","A100_057.png","A100_058.png","A100_059.png","A100_060.png","A100_061.png","A100_062.png","A100_063.png","A100_064.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_calorie_current_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 100,
              y: 167,
              src: 'call.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_calorie_pointer_progress_img_pointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
              src: 'A100_012.png',
              center_x: 144,
              center_y: 232,
              x: 19,
              y: 95,
              start_angle: -180,
              end_angle: 0,
              invalid_visible: false,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 98,
              y: 257,
              font_array: ["A100_055.png","A100_056.png","A100_057.png","A100_058.png","A100_059.png","A100_060.png","A100_061.png","A100_062.png","A100_063.png","A100_064.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 100,
              y: 164,
              src: 'step_0.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_pointer_progress_img_pointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
              src: 'A100_012.png',
              center_x: 144,
              center_y: 232,
              x: 19,
              y: 95,
              start_angle: -180,
              end_angle: 0,
              invalid_visible: false,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 186,
              y: 369,
              src: 'A100_013.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 0,
              y: 0,
              image_array: ["batt_1.png","batt_2.png","batt_3.png","batt_4.png","batt_5.png","batt_6.png"],
              image_length: 6,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 207,
              y: 372,
              font_array: ["A100_019.png","A100_020.png","A100_021.png","A100_022.png","A100_023.png","A100_024.png","A100_025.png","A100_026.png","A100_027.png","A100_028.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'A100_011.png',
              unit_tc: 'A100_011.png',
              unit_en: 'A100_011.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 216,
              y: 0,
              src: 'A100_036.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 183,
              y: 76,
              week_en: ["A100_029.png","A100_030.png","A100_031.png","A100_032.png","A100_033.png","A100_034.png","A100_035.png"],
              week_tc: ["A100_029.png","A100_030.png","A100_031.png","A100_032.png","A100_033.png","A100_034.png","A100_035.png"],
              week_sc: ["A100_029.png","A100_030.png","A100_031.png","A100_032.png","A100_033.png","A100_034.png","A100_035.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 252,
              day_startY: 78,
              day_sc_array: ["A100_019.png","A100_020.png","A100_021.png","A100_022.png","A100_023.png","A100_024.png","A100_025.png","A100_026.png","A100_027.png","A100_028.png"],
              day_tc_array: ["A100_019.png","A100_020.png","A100_021.png","A100_022.png","A100_023.png","A100_024.png","A100_025.png","A100_026.png","A100_027.png","A100_028.png"],
              day_en_array: ["A100_019.png","A100_020.png","A100_021.png","A100_022.png","A100_023.png","A100_024.png","A100_025.png","A100_026.png","A100_027.png","A100_028.png"],
              day_zero: 1,
              day_space: 0,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_moon_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 273,
              y: 117,
              image_array: ["A100_039.png","A100_040.png","A100_041.png","A100_042.png","A100_043.png","A100_044.png","A100_045.png","A100_046.png"],
              image_length: 8,
              type: hmUI.data_type.MOON,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            const deviceInfo = hmSetting.getDeviceInfo();
            
            // normal_compass_custom_pointer_img = hmUI.createWidget(hmUI.widget.CUSTOM_POINTER, {
              // src: 'A100_014.png',
              // center_x: 329,
              // center_y: 292,
              // x: 55,
              // y: 55,
              // start_angle: 0,
              // end_angle: 360,
              // type: hmUI.data_type.COMPASS,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });


            //start of ignored block
            normal_compass_direction_pointer_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: deviceInfo.width,
              h: deviceInfo.height,
              pos_x: 329 - 55,
              pos_y: 292 - 55,
              center_x: 329,
              center_y: 292,
              src: 'A100_014.png',
              angle: 0,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            //end of ignored block

            normal_analog_clock_time_pointer_hour = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              hour_path: 'A100_006.png',
              hour_centerX: 233,
              hour_centerY: 233,
              hour_posX: 25,
              hour_posY: 226,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_minute = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              minute_path: 'A100_004.png',
              minute_centerX: 233,
              minute_centerY: 233,
              minute_posX: 25,
              minute_posY: 226,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_second = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              second_path: 'A100_005.png',
              second_centerX: 233,
              second_centerY: 233,
              second_posX: 25,
              second_posY: 226,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            console.log('Watch_Face.ScreenAOD');
            idle_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 466,
              h: 466,
              src: 'A100_016.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_battery_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 186,
              y: 369,
              src: 'A100_013.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 207,
              y: 372,
              font_array: ["A100_019.png","A100_020.png","A100_021.png","A100_022.png","A100_023.png","A100_024.png","A100_025.png","A100_026.png","A100_027.png","A100_028.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'A100_011.png',
              unit_tc: 'A100_011.png',
              unit_en: 'A100_011.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 183,
              y: 76,
              week_en: ["A100_029.png","A100_030.png","A100_031.png","A100_032.png","A100_033.png","A100_034.png","A100_035.png"],
              week_tc: ["A100_029.png","A100_030.png","A100_031.png","A100_032.png","A100_033.png","A100_034.png","A100_035.png"],
              week_sc: ["A100_029.png","A100_030.png","A100_031.png","A100_032.png","A100_033.png","A100_034.png","A100_035.png"],
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 252,
              day_startY: 78,
              day_sc_array: ["A100_019.png","A100_020.png","A100_021.png","A100_022.png","A100_023.png","A100_024.png","A100_025.png","A100_026.png","A100_027.png","A100_028.png"],
              day_tc_array: ["A100_019.png","A100_020.png","A100_021.png","A100_022.png","A100_023.png","A100_024.png","A100_025.png","A100_026.png","A100_027.png","A100_028.png"],
              day_en_array: ["A100_019.png","A100_020.png","A100_021.png","A100_022.png","A100_023.png","A100_024.png","A100_025.png","A100_026.png","A100_027.png","A100_028.png"],
              day_zero: 1,
              day_space: 0,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_analog_clock_time_pointer_hour = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              hour_path: 'A100_006.png',
              hour_centerX: 233,
              hour_centerY: 233,
              hour_posX: 25,
              hour_posY: 226,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_analog_clock_time_pointer_minute = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              minute_path: 'A100_003.png',
              minute_centerX: 233,
              minute_centerY: 233,
              minute_posX: 25,
              minute_posY: 226,
              show_level: hmUI.show_level.ONLY_AOD,
            });
            console.log('Watch_Face.Shortcuts');

            btn_zona1 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 87,
              y: 180,
              text: '',
              w: 97,
              h: 97,
              normal_src: 'Empty.png',
              press_src: 'Empty.png',
              click_func: () => {
				click_zona1();
                click_Vibrate();
             },
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            btn_zona1.setProperty(hmUI.prop.VISIBLE, true);
			normal_calorie_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_calorie_current_separator_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_calorie_pointer_progress_img_pointer.setProperty(hmUI.prop.VISIBLE, false);
			normal_heart_rate_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_heart_rate_text_separator_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_heart_rate_pointer_progress_img_pointer.setProperty(hmUI.prop.VISIBLE, false);
			
			btn_zona1.addEventListener(hmUI.event.CLICK_DOWN, function () {
					if(longPress_Timer) timer.stopTimer(longPress_Timer);
					longPress_Timer = timer.createTimer(longPressDelay, 0, getLongPress1, {});
			});
			btn_zona1.addEventListener(hmUI.event.CLICK_UP, function () {
					if(longPress_Timer) timer.stopTimer(longPress_Timer);
			});

            normal_moon_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 291,
              y: 136,
              w: 78,
              h: 78,
              type: hmUI.data_type.MOON_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_countdown_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 199,
              y: 199,
              w: 68,
              h: 68,
              type: hmUI.data_type.COUNT_DOWN,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            console.log('Watch_Face.Buttons');
            Button_1 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 184,
              y: 85,
              w: 97,
              h: 39,
              text: '',
              color: 0xFFFF8C00,
              text_size: 24,
              press_src: 'Empty.png',
              normal_src: 'Empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'ScheduleCalScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_2 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 291,
              y: 254,
              w: 78,
              h: 78,
              text: '',
              color: 0xFFFF8C00,
              text_size: 24,
              press_src: 'Empty.png',
              normal_src: 'Empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'CompassScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_3 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 194,
              y: 355,
              w: 78,
              h: 78,
              text: '',
              color: 0xFFFF8C00,
              text_size: 24,
              press_src: 'Empty.png',
              normal_src: 'Empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'Settings_batteryManagerScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            let screenType = hmSetting.getScreenType();
            //start of ignored block
            console.log('compass_update()');
            if (screenType == hmSetting.screen_type.WATCHFACE){
              compass = hmSensor.createSensor(hmSensor.id.COMPASS);
              compass.start();

              if (compass.direction_angle && compass.direction  && compass.direction_angle != 'INVALID') { // initial data
                // Compass Pointer
                let compass_direction_angle = parseInt(compass.direction_angle);
                normal_compass_direction_pointer_img.setProperty(hmUI.prop.ANGLE, -compass_direction_angle);

              } else { // error data
                normal_compass_direction_pointer_img.setProperty(hmUI.prop.ANGLE, 0);

              }

              compass.addEventListener(hmSensor.event.CHANGE, function (compass_res) { // change values when changing direction

                if (compass_res.calibration_status) {
                  // Compass Pointer
                  let compass_direction_angle = parseInt(compass_res.direction_angle);
                  normal_compass_direction_pointer_img.setProperty(hmUI.prop.ANGLE, -compass_direction_angle);

                } else { // error data
                  normal_compass_direction_pointer_img.setProperty(hmUI.prop.ANGLE, 0);

                }

              }); // Listener end

            };
            //end of ignored block

            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                console.log('resume_call()');
                if (compass && screenType == hmSetting.screen_type.WATCHFACE) compass.start();

              }),
              pause_call: (function () {
                console.log('pause_call()');
                if (compass) compass.stop();

              }),
            });

                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}