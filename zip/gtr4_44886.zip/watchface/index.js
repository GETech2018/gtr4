﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        //const logger = Logger.getLogger('watchface_SashaCX75');
        const logger = DeviceRuntimeCore.HmLogger.getLogger('watchface_SashaCX75')
        //end of ignored block

        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_system_disconnect_img = ''
        let normal_system_clock_img = ''
        let normal_battery_icon_img = ''
        let normal_battery_linear_scale = ''
        let normal_battery_text_text_img = ''
        let normal_temperature_current_text_img = ''
        let normal_weather_image_progress_img_level = ''
        let normal_distance_text_text_img = ''
        let normal_heart_rate_text_text_img = ''
        let normal_heart_rate_text_separator_img = ''
        let normal_step_current_text_img = ''
        let normal_date_img_date_day = ''
        let normal_date_img_date_week_img = ''
        let normal_digital_clock_img_time_AmPm = ''
        let normal_digital_clock_img_time = ''
        let normal_analog_clock_time_pointer_hour = ''
        let normal_analog_clock_time_pointer_minute = ''
        let normal_analog_clock_time_pointer_second = ''
        let idle_background_bg_img = ''
        let idle_system_disconnect_img = ''
        let idle_system_clock_img = ''
        let idle_battery_icon_img = ''
        let idle_battery_linear_scale = ''
        let idle_battery_text_text_img = ''
        let idle_temperature_current_text_img = ''
        let idle_weather_image_progress_img_level = ''
        let idle_distance_text_text_img = ''
        let idle_heart_rate_text_text_img = ''
        let idle_heart_rate_text_separator_img = ''
        let idle_step_current_text_img = ''
        let idle_date_img_date_day = ''
        let idle_date_img_date_week_img = ''
        let idle_digital_clock_img_time_AmPm = ''
        let idle_digital_clock_img_time = ''
        let idle_analog_clock_time_pointer_hour = ''
        let idle_analog_clock_time_pointer_minute = ''
        let idle_analog_clock_time_pointer_second = ''
        let normal_alarm_jumpable_img_click = ''
        let normal_temperature_jumpable_img_click = ''
        let normal_heart_jumpable_img_click = ''
        let normal_step_jumpable_img_click = ''
        let Button_1 = ''


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            console.log('Watch_Face.ScreenNormal');
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 466,
              h: 466,
              src: 'background1.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 93,
              y: 344,
              src: 'bluetoothoff.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 340,
              y: 343,
              src: 'alarm.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 175,
              y: 329,
              src: 'bat_0.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            let screenType = hmSetting.getScreenType();
            if (screenType != hmSetting.screen_type.AOD) {
              normal_battery_linear_scale = hmUI.createWidget(hmUI.widget.FILL_RECT);
            };

            // normal_battery_linear_scale = hmUI.createWidget(hmUI.widget.Linear_Scale, {
              // start_x: 178,
              // start_y: 332,
              // color: 0xFFA6A6A6,
              // lenght: 25,
              // line_width: 11,
              // line_cap: Flat,
              // vertical: False,
              // mirror: False,
              // inversion: False,
              // alpha: 255,
              // type: hmUI.data_type.BATTERY,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });
            
            const battery = hmSensor.createSensor(hmSensor.id.BATTERY);
            battery.addEventListener(hmSensor.event.CHANGE, function() {
              scale_call();
            });

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 227,
              y: 329,
              font_array: ["num0_0.png","num0_1.png","num0_2.png","num0_3.png","num0_4.png","num0_5.png","num0_6.png","num0_7.png","num0_8.png","num0_9.png"],
              padding: false,
              h_space: 1,
              unit_sc: 'procent.png',
              unit_tc: 'procent.png',
              unit_en: 'procent.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 123,
              y: 252,
              font_array: ["dig0_0.png","dig0_1.png","dig0_2.png","dig0_3.png","dig0_4.png","dig0_5.png","dig0_6.png","dig0_7.png","dig0_8.png","dig0_9.png"],
              padding: false,
              h_space: 1,
              unit_sc: 'celcius_black.png',
              unit_tc: 'celcius_black.png',
              unit_en: 'celcius_black.png',
              negative_image: 'minus_black.png',
              invalid_image: 'dbminus_black.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 130,
              y: 173,
              image_array: ["weather0_0.png","weather0_1.png","weather0_2.png","weather0_3.png","weather0_4.png","weather0_5.png","weather0_6.png","weather0_7.png","weather0_8.png","weather0_9.png","weather0_10.png","weather0_11.png","weather0_12.png","weather0_13.png","weather0_14.png","weather0_15.png","weather0_16.png","weather0_17.png","weather0_18.png","weather0_19.png","weather0_20.png","weather0_21.png","weather0_22.png","weather0_23.png","weather0_24.png","weather0_25.png","weather0_26.png","weather0_27.png","weather0_28.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_distance_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 275,
              y: 195,
              font_array: ["dig0_0.png","dig0_1.png","dig0_2.png","dig0_3.png","dig0_4.png","dig0_5.png","dig0_6.png","dig0_7.png","dig0_8.png","dig0_9.png"],
              padding: false,
              h_space: 1,
              dot_image: 'dot_black.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.DISTANCE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 235,
              y: 287,
              font_array: ["dig0_0.png","dig0_1.png","dig0_2.png","dig0_3.png","dig0_4.png","dig0_5.png","dig0_6.png","dig0_7.png","dig0_8.png","dig0_9.png"],
              padding: false,
              h_space: 1,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 196,
              y: 283,
              src: 'hart_black.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 270,
              y: 252,
              font_array: ["dig0_0.png","dig0_1.png","dig0_2.png","dig0_3.png","dig0_4.png","dig0_5.png","dig0_6.png","dig0_7.png","dig0_8.png","dig0_9.png"],
              padding: false,
              h_space: 1,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 212,
              day_startY: 137,
              day_sc_array: ["num0_0.png","num0_1.png","num0_2.png","num0_3.png","num0_4.png","num0_5.png","num0_6.png","num0_7.png","num0_8.png","num0_9.png"],
              day_tc_array: ["num0_0.png","num0_1.png","num0_2.png","num0_3.png","num0_4.png","num0_5.png","num0_6.png","num0_7.png","num0_8.png","num0_9.png"],
              day_en_array: ["num0_0.png","num0_1.png","num0_2.png","num0_3.png","num0_4.png","num0_5.png","num0_6.png","num0_7.png","num0_8.png","num0_9.png"],
              day_zero: 1,
              day_space: 3,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 0,
              y: 0,
              week_en: ["day0_0.png","day0_1.png","day0_2.png","day0_3.png","day0_4.png","day0_5.png","day0_6.png"],
              week_tc: ["day0_0.png","day0_1.png","day0_2.png","day0_3.png","day0_4.png","day0_5.png","day0_6.png"],
              week_sc: ["day0_0.png","day0_1.png","day0_2.png","day0_3.png","day0_4.png","day0_5.png","day0_6.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time_AmPm = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              am_x: 216,
              am_y: 395,
              am_sc_path: 'am.png',
              am_en_path: 'am.png',
              pm_x: 216,
              pm_y: 395,
              pm_sc_path: 'pm.png',
              pm_en_path: 'pm.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 155,
              hour_startY: 366,
              hour_array: ["num1_0.png","num1_1.png","num1_2.png","num1_3.png","num1_4.png","num1_5.png","num1_6.png","num1_7.png","num1_8.png","num1_9.png"],
              hour_zero: 1,
              hour_space: 1,
              hour_angle: 0,
              hour_align: hmUI.align.CENTER_H,

              minute_startX: 243,
              minute_startY: 366,
              minute_array: ["num1_0.png","num1_1.png","num1_2.png","num1_3.png","num1_4.png","num1_5.png","num1_6.png","num1_7.png","num1_8.png","num1_9.png"],
              minute_zero: 1,
              minute_space: 1,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.CENTER_H,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_hour = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              hour_path: 'minute0.png',
              hour_centerX: 233,
              hour_centerY: 233,
              hour_posX: 24,
              hour_posY: 219,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_minute = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              minute_path: 'minute0.png',
              minute_centerX: 233,
              minute_centerY: 233,
              minute_posX: 24,
              minute_posY: 219,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_second = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              second_path: 'sec0.png',
              second_centerX: 233,
              second_centerY: 233,
              second_posX: 24,
              second_posY: 219,
              second_cover_path: 'timetop.png',
              second_cover_x: 182,
              second_cover_y: 182,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            console.log('Watch_Face.ScreenAOD');
            idle_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 466,
              h: 466,
              src: 'background1.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 93,
              y: 344,
              src: 'bluetoothoff.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 340,
              y: 343,
              src: 'alarm.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_battery_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 175,
              y: 329,
              src: 'bat_0.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            if (screenType == hmSetting.screen_type.AOD) {
              idle_battery_linear_scale = hmUI.createWidget(hmUI.widget.FILL_RECT);
            };

            // idle_battery_linear_scale = hmUI.createWidget(hmUI.widget.Linear_Scale, {
              // start_x: 178,
              // start_y: 332,
              // color: 0xFFA6A6A6,
              // lenght: 25,
              // line_width: 11,
              // line_cap: Flat,
              // vertical: False,
              // mirror: False,
              // inversion: False,
              // alpha: 255,
              // type: hmUI.data_type.BATTERY,
              // show_level: hmUI.show_level.ONLY_AOD,
            // });

            idle_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 227,
              y: 329,
              font_array: ["num0_0.png","num0_1.png","num0_2.png","num0_3.png","num0_4.png","num0_5.png","num0_6.png","num0_7.png","num0_8.png","num0_9.png"],
              padding: false,
              h_space: 1,
              unit_sc: 'procent.png',
              unit_tc: 'procent.png',
              unit_en: 'procent.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 123,
              y: 252,
              font_array: ["dig0_0.png","dig0_1.png","dig0_2.png","dig0_3.png","dig0_4.png","dig0_5.png","dig0_6.png","dig0_7.png","dig0_8.png","dig0_9.png"],
              padding: false,
              h_space: 1,
              unit_sc: 'celcius_black.png',
              unit_tc: 'celcius_black.png',
              unit_en: 'celcius_black.png',
              negative_image: 'minus_black.png',
              invalid_image: 'dbminus_black.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 130,
              y: 173,
              image_array: ["weather0_0.png","weather0_1.png","weather0_2.png","weather0_3.png","weather0_4.png","weather0_5.png","weather0_6.png","weather0_7.png","weather0_8.png","weather0_9.png","weather0_10.png","weather0_11.png","weather0_12.png","weather0_13.png","weather0_14.png","weather0_15.png","weather0_16.png","weather0_17.png","weather0_18.png","weather0_19.png","weather0_20.png","weather0_21.png","weather0_22.png","weather0_23.png","weather0_24.png","weather0_25.png","weather0_26.png","weather0_27.png","weather0_28.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_distance_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 275,
              y: 195,
              font_array: ["dig0_0.png","dig0_1.png","dig0_2.png","dig0_3.png","dig0_4.png","dig0_5.png","dig0_6.png","dig0_7.png","dig0_8.png","dig0_9.png"],
              padding: false,
              h_space: 1,
              dot_image: 'dot_black.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.DISTANCE,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 235,
              y: 287,
              font_array: ["dig0_0.png","dig0_1.png","dig0_2.png","dig0_3.png","dig0_4.png","dig0_5.png","dig0_6.png","dig0_7.png","dig0_8.png","dig0_9.png"],
              padding: false,
              h_space: 1,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_heart_rate_text_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 196,
              y: 283,
              src: 'hart_black.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 270,
              y: 252,
              font_array: ["dig0_0.png","dig0_1.png","dig0_2.png","dig0_3.png","dig0_4.png","dig0_5.png","dig0_6.png","dig0_7.png","dig0_8.png","dig0_9.png"],
              padding: false,
              h_space: 1,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 212,
              day_startY: 137,
              day_sc_array: ["num0_0.png","num0_1.png","num0_2.png","num0_3.png","num0_4.png","num0_5.png","num0_6.png","num0_7.png","num0_8.png","num0_9.png"],
              day_tc_array: ["num0_0.png","num0_1.png","num0_2.png","num0_3.png","num0_4.png","num0_5.png","num0_6.png","num0_7.png","num0_8.png","num0_9.png"],
              day_en_array: ["num0_0.png","num0_1.png","num0_2.png","num0_3.png","num0_4.png","num0_5.png","num0_6.png","num0_7.png","num0_8.png","num0_9.png"],
              day_zero: 1,
              day_space: 3,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 0,
              y: 0,
              week_en: ["day0_0.png","day0_1.png","day0_2.png","day0_3.png","day0_4.png","day0_5.png","day0_6.png"],
              week_tc: ["day0_0.png","day0_1.png","day0_2.png","day0_3.png","day0_4.png","day0_5.png","day0_6.png"],
              week_sc: ["day0_0.png","day0_1.png","day0_2.png","day0_3.png","day0_4.png","day0_5.png","day0_6.png"],
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time_AmPm = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              am_x: 216,
              am_y: 395,
              am_sc_path: 'am.png',
              am_en_path: 'am.png',
              pm_x: 216,
              pm_y: 395,
              pm_sc_path: 'pm.png',
              pm_en_path: 'pm.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 155,
              hour_startY: 366,
              hour_array: ["num1_0.png","num1_1.png","num1_2.png","num1_3.png","num1_4.png","num1_5.png","num1_6.png","num1_7.png","num1_8.png","num1_9.png"],
              hour_zero: 1,
              hour_space: 1,
              hour_angle: 0,
              hour_align: hmUI.align.CENTER_H,

              minute_startX: 243,
              minute_startY: 366,
              minute_array: ["num1_0.png","num1_1.png","num1_2.png","num1_3.png","num1_4.png","num1_5.png","num1_6.png","num1_7.png","num1_8.png","num1_9.png"],
              minute_zero: 1,
              minute_space: 1,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.CENTER_H,

              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_analog_clock_time_pointer_hour = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              hour_path: 'hour2.png',
              hour_centerX: 233,
              hour_centerY: 233,
              hour_posX: 24,
              hour_posY: 219,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_analog_clock_time_pointer_minute = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              minute_path: 'minute2.png',
              minute_centerX: 233,
              minute_centerY: 233,
              minute_posX: 24,
              minute_posY: 219,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_analog_clock_time_pointer_second = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              second_path: 'sec2.png',
              second_centerX: 233,
              second_centerY: 233,
              second_posX: 24,
              second_posY: 219,
              second_cover_path: 'timetop.png',
              second_cover_x: 182,
              second_cover_y: 182,
              show_level: hmUI.show_level.ONLY_AOD,
            });
            console.log('Watch_Face.Shortcuts');

            normal_alarm_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 326,
              y: 331,
              w: 58,
              h: 58,
              src: 'shortcut.png',
              type: hmUI.data_type.ALARM_CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 111,
              y: 194,
              w: 68,
              h: 78,
              src: 'shortcut.png',
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 185,
              y: 281,
              w: 97,
              h: 58,
              src: 'shortcut.png',
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 286,
              y: 194,
              w: 68,
              h: 78,
              src: 'shortcut.png',
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            console.log('Watch_Face.Buttons');
            Button_1 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 201,
              y: 200,
              w: 60,
              h: 60,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'shortcut.png',
              normal_src: 'shortcut.png',
              click_func: (button_widget) => {
                // CAMBIO DE COLOR DE AGUJAS

if (typeof colornumber === 'undefined') {
    colornumber = 0
}

colornumber++

if (colornumber > 5) {
    colornumber = 0
}


// ======================
// HORA NORMAL
// ======================

normal_analog_clock_time_pointer_hour.setProperty(hmUI.prop.MORE, {

    hour_path: 'hour' + colornumber + '.png',

    hour_centerX: 233,
    hour_centerY: 233,

    hour_posX: 24,
    hour_posY: 219,
})


// ======================
// MINUTOS NORMAL
// ======================

normal_analog_clock_time_pointer_minute.setProperty(hmUI.prop.MORE, {

    minute_path: 'minute' + colornumber + '.png',

    minute_centerX: 233,
    minute_centerY: 233,

    minute_posX: 24,
    minute_posY: 219,
})


// ======================
// SEGUNDOS NORMAL
// ======================

normal_analog_clock_time_pointer_second.setProperty(hmUI.prop.MORE, {

    second_path: 'sec' + colornumber + '.png',

    second_centerX: 233,
    second_centerY: 233,

    second_posX: 24,
    second_posY: 219,

    second_cover_path: 'timetop.png',

    second_cover_x: 182,
    second_cover_y: 182,
})


// ======================
// HORA AOD
// ======================

idle_analog_clock_time_pointer_hour.setProperty(hmUI.prop.MORE, {

    hour_path: 'hour' + colornumber + '.png',

    hour_centerX: 233,
    hour_centerY: 233,

    hour_posX: 23,
    hour_posY: 150,

    show_level: hmUI.show_level.ONAL_AOD,
})


// ======================
// MINUTOS AOD
// ======================

idle_analog_clock_time_pointer_minute.setProperty(hmUI.prop.MORE, {

    minute_path: 'minute' + colornumber + '.png',

    minute_centerX: 233,
    minute_centerY: 233,

    minute_posX: 23,
    minute_posY: 220,

    show_level: hmUI.show_level.ONAL_AOD,
})


// ======================
// VIBRACIÓN
// ======================

const vibrate = hmSensor.createSensor(hmSensor.id.VIBRATE)

vibrate.stop()

vibrate.scene = 25

vibrate.start()


// ======================
// MENSAJE
// ======================

hmUI.showToast({
    text: 'Color ' + colornumber
})
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            function scale_call() {
              console.log('scale_call()');

                console.log('update scales BATTERY');
                
                let valueBattery = battery.current;
                let targetBattery = 100;
                let progressBattery = valueBattery/targetBattery;
                if (progressBattery > 1) progressBattery = 1;
                let progress_ls_normal_battery = progressBattery;

                if (screenType != hmSetting.screen_type.AOD) {

                  // normal_battery_linear_scale
                  // initial parameters
                  let start_x_normal_battery = 178;
                  let start_y_normal_battery = 332;
                  let lenght_ls_normal_battery = 25;
                  let line_width_ls_normal_battery = 11;
                  let color_ls_normal_battery = 0xFFA6A6A6;
                  
                  // calculated parameters
                  let start_x_normal_battery_draw = start_x_normal_battery;
                  let start_y_normal_battery_draw = start_y_normal_battery;
                  lenght_ls_normal_battery = lenght_ls_normal_battery * progress_ls_normal_battery;
                  let lenght_ls_normal_battery_draw = lenght_ls_normal_battery;
                  let line_width_ls_normal_battery_draw = line_width_ls_normal_battery;
                  if (lenght_ls_normal_battery < 0){
                    lenght_ls_normal_battery_draw = -lenght_ls_normal_battery;
                    start_x_normal_battery_draw = start_x_normal_battery - lenght_ls_normal_battery_draw;
                  };
                  
                  normal_battery_linear_scale.setProperty(hmUI.prop.MORE, {
                    x: start_x_normal_battery_draw,
                    y: start_y_normal_battery_draw,
                    w: lenght_ls_normal_battery_draw,
                    h: line_width_ls_normal_battery_draw,
                    color: color_ls_normal_battery,
                  });
                };

                console.log('update scales BATTERY');
                let progress_ls_idle_battery = progressBattery;

                if (screenType == hmSetting.screen_type.AOD) {

                  // idle_battery_linear_scale
                  // initial parameters
                  let start_x_idle_battery = 178;
                  let start_y_idle_battery = 332;
                  let lenght_ls_idle_battery = 25;
                  let line_width_ls_idle_battery = 11;
                  let color_ls_idle_battery = 0xFFA6A6A6;
                  
                  // calculated parameters
                  let start_x_idle_battery_draw = start_x_idle_battery;
                  let start_y_idle_battery_draw = start_y_idle_battery;
                  lenght_ls_idle_battery = lenght_ls_idle_battery * progress_ls_idle_battery;
                  let lenght_ls_idle_battery_draw = lenght_ls_idle_battery;
                  let line_width_ls_idle_battery_draw = line_width_ls_idle_battery;
                  if (lenght_ls_idle_battery < 0){
                    lenght_ls_idle_battery_draw = -lenght_ls_idle_battery;
                    start_x_idle_battery_draw = start_x_idle_battery - lenght_ls_idle_battery_draw;
                  };
                  
                  idle_battery_linear_scale.setProperty(hmUI.prop.MORE, {
                    x: start_x_idle_battery_draw,
                    y: start_y_idle_battery_draw,
                    w: lenght_ls_idle_battery_draw,
                    h: line_width_ls_idle_battery_draw,
                    color: color_ls_idle_battery,
                  });
                };

            };

            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                console.log('resume_call()');
                scale_call();
              }),
            });

                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}