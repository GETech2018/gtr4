﻿
    /*
    ** Watch_Face_Editor tool
    ** watchface js version v1.0.1
    ** Copyright © CashaCX75. All Rights Reserved
    */

    try {

      (() => {

        var __$$app$$__ = __$$hmAppManager$$__.currentApp;
        var __$$module$$__ = __$$app$$__.current;
        //drink is a name,can modify
        var h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__), 'drink');

        'use strict';

        //dynamic modify start

        
        let normal_background_bg = ''
        let normal_heart_rate_icon_img = ''
        let normal_heart_rate_circle_scale = ''
        let normal_heart_rate_text_text_img = ''
        let normal_battery_icon_img = ''
        let normal_battery_circle_scale = ''
        let normal_battery_text_text_img = ''
        let normal_battery_text_separator_img = ''
        let normal_date_img_date_day = ''
        let normal_date_day_separator_img = ''
        let normal_date_img_date_week_img = ''
        let normal_pai_icon_img = ''
        let normal_step_icon_img = ''
        let normal_step_current_text_img = ''
        let normal_step_current_separator_img = ''
        let normal_date_img_date_month_img = ''
        let normal_digital_clock_img_time_AmPm = ''
        let normal_digital_clock_img_time = ''
        let normal_digital_clock_hour_separator_img = ''
        let normal_digital_clock_minute_separator_img = ''
        let idle_background_bg = ''
        let idle_battery_icon_img = ''
        let idle_digital_clock_img_time_AmPm = ''
        let idle_digital_clock_img_time = ''
        let idle_digital_clock_hour_separator_img = ''
        let idle_digital_clock_minute_separator_img = ''
        let idle_step_icon_img = ''


        //dynamic modify end

        //not required
        const logger = DeviceRuntimeCore.HmLogger.getLogger("yeguang");

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({

          init_view() {

            //dynamic modify start
                    
            
            normal_background_bg = hmUI.createWidget(hmUI.widget.FILL_RECT, {
              x: 0,
              y: 0,
              w: 466,
              h: 466,
              color: '0xFF000000',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 415,
              y: 178,
              src: 'icon_heart_lightgrey.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_heart_circle_scale = hmUI.createWidget(hmUI.widget.Circle_Scale, {
              // center_x: 235,
              // center_y: 232,
              // start_angle: 60,
              // end_angle: 120,
              // radius: 233,
              // line_width: 15,
              // color: 0xFFD8D6D6,
              // mirror: False,
              // inversion: False,
              // type: hmUI.data_type.HEART,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            let screenType = hmSetting.getScreenType();
            if (screenType != hmSetting.screen_type.AOD) {
              normal_heart_rate_circle_scale = hmUI.createWidget(hmUI.widget.ARC);
            };
            
            const heart_rate = hmSensor.createSensor(hmSensor.id.HEART);
            heart_rate.addEventListener(hmSensor.event.CHANGE, function() {
              scale_call();
            });

            normal_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 377,
              y: 185,
              font_array: ["red_NBatt0001.png","red_NBatt0002.png","red_NBatt0003.png","red_NBatt0004.png","red_NBatt0005.png","red_NBatt0006.png","red_NBatt0007.png","red_NBatt0008.png","red_NBatt0009.png","red_NBatt0010.png"],
              padding: false,
              h_space: -73,
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 417,
              y: 246,
              src: 'red_Batt.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_battery_circle_scale = hmUI.createWidget(hmUI.widget.Circle_Scale, {
              // center_x: 237,
              // center_y: 233,
              // start_angle: 60,
              // end_angle: 120,
              // radius: 233,
              // line_width: 10,
              // color: 0xFF991502,
              // mirror: False,
              // inversion: False,
              // type: hmUI.data_type.BATTERY,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            
            if (screenType != hmSetting.screen_type.AOD) {
              normal_battery_circle_scale = hmUI.createWidget(hmUI.widget.ARC);
            };
            
            const battery = hmSensor.createSensor(hmSensor.id.BATTERY);
            battery.addEventListener(hmSensor.event.CHANGE, function() {
              scale_call();
            });

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 375,
              y: 217,
              font_array: ["red_NBatt0001.png","red_NBatt0002.png","red_NBatt0003.png","red_NBatt0004.png","red_NBatt0005.png","red_NBatt0006.png","red_NBatt0007.png","red_NBatt0008.png","red_NBatt0009.png","red_NBatt0010.png"],
              padding: false,
              h_space: -72,
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 421,
              y: 349,
              src: 'red_incon5.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 144,
              day_startY: 388,
              day_sc_array: ["red_Date0001.png","red_Date0002.png","red_Date0003.png","red_Date0004.png","red_Date0005.png","red_Date0006.png","red_Date0007.png","red_Date0008.png","red_Date0009.png","red_Date0010.png"],
              day_tc_array: ["red_Date0001.png","red_Date0002.png","red_Date0003.png","red_Date0004.png","red_Date0005.png","red_Date0006.png","red_Date0007.png","red_Date0008.png","red_Date0009.png","red_Date0010.png"],
              day_en_array: ["red_Date0001.png","red_Date0002.png","red_Date0003.png","red_Date0004.png","red_Date0005.png","red_Date0006.png","red_Date0007.png","red_Date0008.png","red_Date0009.png","red_Date0010.png"],
              day_zero: 1,
              day_space: -72,
              day_align: hmUI.align.LEFT,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_day_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 232,
              y: 376,
              src: 'red_Icon2.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 134,
              y: 356,
              week_en: ["red_Day0001.png","red_Day0002.png","red_Day0003.png","red_Day0004.png","red_Day0005.png","red_Day0006.png","red_Day0007.png"],
              week_tc: ["red_Day0001.png","red_Day0002.png","red_Day0003.png","red_Day0004.png","red_Day0005.png","red_Day0006.png","red_Day0007.png"],
              week_sc: ["red_Day0001.png","red_Day0002.png","red_Day0003.png","red_Day0004.png","red_Day0005.png","red_Day0006.png","red_Day0007.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_pai_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 433,
              y: 232,
              src: 'red_Icon4.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 260,
              y: 368,
              src: 'red_Steps.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 216,
              y: 388,
              font_array: ["red_Date0001.png","red_Date0002.png","red_Date0003.png","red_Date0004.png","red_Date0005.png","red_Date0006.png","red_Date0007.png","red_Date0008.png","red_Date0009.png","red_Date0010.png"],
              padding: false,
              h_space: -72,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 418,
              y: 115,
              src: 'red_incon5.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_month_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 144,
              month_startY: 49,
              month_sc_array: ["red_Month0001.png","red_Month0002.png","red_Month0003.png","red_Month0004.png","red_Month0005.png","red_Month0006.png","red_Month0007.png","red_Month0008.png","red_Month0009.png","red_Month0010.png","red_Month0011.png","red_Month0012.png"],
              month_tc_array: ["red_Month0001.png","red_Month0002.png","red_Month0003.png","red_Month0004.png","red_Month0005.png","red_Month0006.png","red_Month0007.png","red_Month0008.png","red_Month0009.png","red_Month0010.png","red_Month0011.png","red_Month0012.png"],
              month_en_array: ["red_Month0001.png","red_Month0002.png","red_Month0003.png","red_Month0004.png","red_Month0005.png","red_Month0006.png","red_Month0007.png","red_Month0008.png","red_Month0009.png","red_Month0010.png","red_Month0011.png","red_Month0012.png"],
              month_is_character: true ,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time_AmPm = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              am_x: 300,
              am_y: 261,
              am_sc_path: '0041.png',
              am_en_path: '0041.png',
              pm_x: 300,
              pm_y: 261,
              pm_sc_path: '0042.png',
              pm_en_path: '0042.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: -93,
              hour_startY: -40,
              hour_array: ["red_HR0001.png","red_HR0002.png","red_HR0003.png","red_HR0004.png","red_HR0005.png","red_HR0006.png","red_HR0007.png","red_HR0008.png","red_HR0009.png","red_HR0010.png"],
              hour_zero: 1,
              hour_space: -446,
              hour_align: hmUI.align.CENTER_H,

              minute_startX: 271,
              minute_startY: 277,
              minute_array: ["red_Min0001.png","red_Min0002.png","red_Min0003.png","red_Min0004.png","red_Min0005.png","red_Min0006.png","red_Min0007.png","red_Min0008.png","red_Min0009.png","red_Min0010.png"],
              minute_zero: 1,
              minute_space: -68,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_hour_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 297,
              y: 342,
              src: 'red_Icon1.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_minute_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 132,
              y: 342,
              src: 'red_Icon1.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            idle_background_bg = hmUI.createWidget(hmUI.widget.FILL_RECT, {
              x: 0,
              y: 0,
              w: 466,
              h: 466,
              color: '0xFF000000',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_battery_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 157,
              y: -3,
              src: 'Logo_4.51z.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time_AmPm = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              am_x: 300,
              am_y: 261,
              am_sc_path: '0041.png',
              am_en_path: '0041.png',
              pm_x: 300,
              pm_y: 261,
              pm_sc_path: '0042.png',
              pm_en_path: '0042.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: -93,
              hour_startY: -40,
              hour_array: ["red_HR0001.png","red_HR0002.png","red_HR0003.png","red_HR0004.png","red_HR0005.png","red_HR0006.png","red_HR0007.png","red_HR0008.png","red_HR0009.png","red_HR0010.png"],
              hour_zero: 1,
              hour_space: -446,
              hour_align: hmUI.align.CENTER_H,

              minute_startX: 271,
              minute_startY: 277,
              minute_array: ["red_Min0001.png","red_Min0002.png","red_Min0003.png","red_Min0004.png","red_Min0005.png","red_Min0006.png","red_Min0007.png","red_Min0008.png","red_Min0009.png","red_Min0010.png"],
              minute_zero: 1,
              minute_space: -68,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_hour_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 297,
              y: 425,
              src: 'red_Icon1.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_minute_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 132,
              y: 420,
              src: 'red_Icon1.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_step_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: -49,
              y: 0,
              src: 'Picture69.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            function scale_call() {

                console.log('update scales HEART');
                
                let valueHeartRate = heart_rate.last;
                let targetHeartRate = 179;
                let progressHeartRate = (valueHeartRate - 71)/(targetHeartRate - 71);
                if (progressHeartRate < 0) progressHeartRate = 0;
                if (progressHeartRate > 1) progressHeartRate = 1;
                let progress_cs_normal_heart_rate = progressHeartRate;

                if (screenType != hmSetting.screen_type.AOD) {

                  // normal_heart_rate_circle_scale
                  // initial parameters
                  let start_angle_normal_heart_rate = -30;
                  let end_angle_normal_heart_rate = 30;
                  let center_x_normal_heart_rate = 235;
                  let center_y_normal_heart_rate = 232;
                  let radius_normal_heart_rate = 233;
                  let line_width_cs_normal_heart_rate = 15;
                  let color_cs_normal_heart_rate = 0xFFD8D6D6;
                  
                  // calculated parameters
                  let arcX_normal_heart_rate = center_x_normal_heart_rate - radius_normal_heart_rate;
                  let arcY_normal_heart_rate = center_y_normal_heart_rate - radius_normal_heart_rate;
                  let CircleWidth_normal_heart_rate = 2 * radius_normal_heart_rate;
                  let angle_offset_normal_heart_rate = end_angle_normal_heart_rate - start_angle_normal_heart_rate;
                  angle_offset_normal_heart_rate = angle_offset_normal_heart_rate * progress_cs_normal_heart_rate;
                  let end_angle_normal_heart_rate_draw = start_angle_normal_heart_rate + angle_offset_normal_heart_rate;
                  
                  normal_heart_rate_circle_scale.setProperty(hmUI.prop.MORE, {
                    x: arcX_normal_heart_rate,
                    y: arcY_normal_heart_rate,
                    w: CircleWidth_normal_heart_rate,
                    h: CircleWidth_normal_heart_rate,
                    start_angle: start_angle_normal_heart_rate,
                    end_angle: end_angle_normal_heart_rate_draw,
                    color: color_cs_normal_heart_rate,
                    line_width: line_width_cs_normal_heart_rate,
                  });
                };

                console.log('update scales BATTERY');
                
                let valueBattery = battery.current;
                let targetBattery = 100;
                let progressBattery = valueBattery/targetBattery;
                if (progressBattery > 1) progressBattery = 1;
                let progress_cs_normal_battery = progressBattery;

                if (screenType != hmSetting.screen_type.AOD) {

                  // normal_battery_circle_scale
                  // initial parameters
                  let start_angle_normal_battery = -30;
                  let end_angle_normal_battery = 30;
                  let center_x_normal_battery = 237;
                  let center_y_normal_battery = 233;
                  let radius_normal_battery = 233;
                  let line_width_cs_normal_battery = 10;
                  let color_cs_normal_battery = 0xFF991502;
                  
                  // calculated parameters
                  let arcX_normal_battery = center_x_normal_battery - radius_normal_battery;
                  let arcY_normal_battery = center_y_normal_battery - radius_normal_battery;
                  let CircleWidth_normal_battery = 2 * radius_normal_battery;
                  let angle_offset_normal_battery = end_angle_normal_battery - start_angle_normal_battery;
                  angle_offset_normal_battery = angle_offset_normal_battery * progress_cs_normal_battery;
                  let end_angle_normal_battery_draw = start_angle_normal_battery + angle_offset_normal_battery;
                  
                  normal_battery_circle_scale.setProperty(hmUI.prop.MORE, {
                    x: arcX_normal_battery,
                    y: arcY_normal_battery,
                    w: CircleWidth_normal_battery,
                    h: CircleWidth_normal_battery,
                    start_angle: start_angle_normal_battery,
                    end_angle: end_angle_normal_battery_draw,
                    color: color_cs_normal_battery,
                    line_width: line_width_cs_normal_battery,
                  });
                };

            };

            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                scale_call();
              }),
            });

            //dynamic modify end
          },

          onInit() {
            console.log('index page.js on init invoke')

            this.init_view()

          },

          onReady() {
            console.log('index page.js on ready invoke')
          },

          onShow() {
            console.log('index page.js on show invoke')
          },

          onHide() {
            console.log('index page.js on hide invoke')
          },

          onDestory() {
            heart_rate.removeEventListener(heart.event.CURRENT, hrCurrListener);
            console.log('index page.js on destory invoke')
          },
        });

      })()
    } catch (e) {
      console.log(e)
    }
  