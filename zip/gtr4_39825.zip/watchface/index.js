﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        const logger = Logger.getLogger('watchface_SashaCX75');
        //end of ignored block

        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_day_text_font = ''
        let normal_dow_text_font = ''
        let normal_DOW_Array = ['LU', 'MA', 'MI', 'JU', 'VI', 'SA', 'DO'];
        let normal_system_lock_img = ''
        let normal_system_disconnect_img = ''
        let normal_system_clock_img = ''
        let normal_moon_image_progress_img_level = ''
        let normal_group_ForecastWeather = ''
        let normal_forecast_date_week_font = new Array(5);
        let normal_forecast_date_week_font_Array = ['LU', 'MA', 'MI', 'JU', 'VI', 'SA', 'DO'];
        let normal_forecast_low_text_font = new Array(5);
        let normal_forecast_high_text_font = new Array(5);
        let normal_forecast_image_progress_img_level = new Array(5);
        let normal_forecast_image_array = ['S095.png', 'S096.png', 'S097.png', 'S098.png', 'S099.png', 'S100.png', 'S101.png', 'S102.png', 'S103.png', 'S104.png', 'S105.png', 'S106.png', 'S107.png', 'S108.png', 'S109.png', 'S110.png', 'S111.png', 'S112.png', 'S113.png', 'S114.png', 'S115.png', 'S116.png', 'S117.png', 'S118.png', 'S119.png', 'S120.png', 'S121.png', 'S122.png', 'transparent.png'];
        let normal_sun_high_text_font = ''
        let normal_sun_low_text_font = ''
        let normal_calorie_current_text_img = ''
        let normal_heart_rate_text_text_img = ''
        let normal_distance_text_text_img = ''
        let normal_battery_pointer_progress_img_pointer = ''
        let normal_battery_text_text_img = ''
        let normal_step_pointer_progress_img_pointer = ''
        let normal_step_current_text_img = ''
        let normal_weather_image_progress_img_level = ''
        let normal_temperature_current_text_img = ''
        let normal_digital_clock_img_time_AmPm = ''
        let normal_digital_clock_img_time = ''
        let idle_background_bg_img = ''
        let idle_day_text_font = ''
        let idle_dow_text_font = ''
        let idle_DOW_Array = ['LU', 'MA', 'MI', 'JU', 'VI', 'SA', 'DO'];
        let idle_system_clock_img = ''
        let idle_battery_text_text_img = ''
        let idle_digital_clock_img_time_AmPm = ''
        let idle_digital_clock_img_time = ''
        let normal_alarm_jumpable_img_click = ''
        let normal_sunrise_jumpable_img_click = ''
        let normal_altimeter_jumpable_img_click = ''
        let normal_temperature_jumpable_img_click = ''
        let normal_pai_jumpable_img_click = ''
        let normal_heart_jumpable_img_click = ''
        let normal_step_jumpable_img_click = ''
        let Button_1 = ''
        let Button_2 = ''
        let Button_3 = ''
        let timeSensor = ''


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            console.log('Watch_Face.ScreenNormal');
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 466,
              h: 466,
              src: '0.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            if (!timeSensor) timeSensor = hmSensor.createSensor(hmSensor.id.TIME);
            timeSensor.addEventListener(timeSensor.event.DAYCHANGE, function() {
              time_update(true);
            });

            normal_day_text_font = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 381,
              y: 91,
              w: 55,
              h: 45,
              text_size: 40,
              char_space: 0,
              line_space: 0,
              color: 0xFFFFFFFF,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              // padding: true,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_dow_text_font = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 373,
              y: 131,
              w: 75,
              h: 50,
              text_size: 40,
              char_space: 0,
              line_space: 0,
              color: 0xFF00FFFF,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              // unit_string: LU, MA, MI, JU, VI, SA, DO,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_lock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 123,
              y: 400,
              src: 'bloc.png',
              type: hmUI.system_status.LOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 126,
              y: 28,
              src: 'bt6.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 374,
              y: 65,
              src: 'alar.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_moon_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 379,
              y: 294,
              image_array: ["Moon11.png","Moon12.png","Moon13.png","Moon14.png","Moon15.png","Moon16.png","Moon17.png","Moon18.png","Moon19.png","Moon20.png","Moon21.png","Moon22.png","Moon23.png","Moon24.png","Moon25.png","Moon26.png","Moon27.png","Moon28.png","Moon29.png","Moon30.png","Moon31.png","Moon32.png","Moon33.png","Moon34.png","Moon35.png","Moon36.png","Moon37.png","Moon38.png","Moon39.png","Moon40.png"],
              image_length: 30,
              type: hmUI.data_type.MOON,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            let screenType = hmSetting.getScreenType();            
            // normal_Weather_FewDays = hmUI.createWidget(hmUI.widget.FewDays, {
              // x: 159,
              // y: 99,
              // ColumnWidth: 39,
              // DaysCount: 5,
            // });
            
            normal_group_ForecastWeather = hmUI.createWidget(hmUI.widget.GROUP, {
              x: 159,
              y: 99,
              h: 0,
              w: 0,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_forecast_date_week_font = normal_group_ForecastWeather.createWidget(hmUI.widget.TEXT_Options, {
              // x: 11,
              // y: 49,
              // w: 39,
              // h: 31,
              // text_size: 20,
              // char_space: 0,
              // line_space: 0,
              // color: 0xFFFFFFFF,
              // color_2: 0xFFFF0000,
              // use_color_2: False,
              // align_h: hmUI.align.CENTER_H,
              // align_v: hmUI.align.CENTER_V,
              // text_style: hmUI.text_style.ELLIPSIS,
              // type: hmUI.data_type.forecast_date_week_img,
              // unit_string: LU, MA, MI, JU, VI, SA, DO,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            //start of ignored block
            if (screenType == hmSetting.screen_type.WATCHFACE) {
              for (let i = 0; i < 5; i++) {
                normal_forecast_date_week_font[i] = normal_group_ForecastWeather.createWidget(hmUI.widget.TEXT, {
                  x: 11 + i*39,
                  y: 49,
                  w: 39,
                  h: 31,
                  text_size: 20,
                  char_space: 0,
                  line_space: 0,
                  color: 0xFFFFFFFF,
                  // color_2: 0xFFFF0000,
                  align_h: hmUI.align.CENTER_H,
                  align_v: hmUI.align.CENTER_V,
                  text_style: hmUI.text_style.ELLIPSIS,
                  // unit_string: LU, MA, MI, JU, VI, SA, DO,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });
              };
            };
            //end of ignored block

            // normal_forecast_low_text_font = normal_group_ForecastWeather.createWidget(hmUI.widget.TEXT_Options, {
              // x: 11,
              // y: 33,
              // w: 39,
              // h: 30,
              // text_size: 20,
              // char_space: 0,
              // line_space: 0,
              // color: 0xFF00FFFF,
              // color_2: 0xFFFF0000,
              // use_color_2: False,
              // align_h: hmUI.align.CENTER_H,
              // align_v: hmUI.align.CENTER_V,
              // text_style: hmUI.text_style.ELLIPSIS,
              // type: hmUI.data_type.forecast_low_text_font,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            //start of ignored block
            if (screenType == hmSetting.screen_type.WATCHFACE) {
              for (let i = 0; i < 5; i++) {
                normal_forecast_low_text_font[i] = normal_group_ForecastWeather.createWidget(hmUI.widget.TEXT, {
                  x: 11 + i*39,
                  y: 33,
                  w: 39,
                  h: 30,
                  text_size: 20,
                  char_space: 0,
                  line_space: 0,
                  color: 0xFF00FFFF,
                  align_h: hmUI.align.CENTER_H,
                  align_v: hmUI.align.CENTER_V,
                  text_style: hmUI.text_style.ELLIPSIS,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });
              };
            };
            //end of ignored block

            // normal_forecast_high_text_font = normal_group_ForecastWeather.createWidget(hmUI.widget.TEXT_Options, {
              // x: 11,
              // y: 14,
              // w: 38,
              // h: 30,
              // text_size: 20,
              // char_space: 0,
              // line_space: 0,
              // color: 0xFFFFFF00,
              // color_2: 0xFFFF0000,
              // use_color_2: False,
              // align_h: hmUI.align.CENTER_H,
              // align_v: hmUI.align.CENTER_V,
              // text_style: hmUI.text_style.ELLIPSIS,
              // type: hmUI.data_type.forecast_high_text_font,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            //start of ignored block
            if (screenType == hmSetting.screen_type.WATCHFACE) {
              for (let i = 0; i < 5; i++) {
                normal_forecast_high_text_font[i] = normal_group_ForecastWeather.createWidget(hmUI.widget.TEXT, {
                  x: 11 + i*39,
                  y: 14,
                  w: 38,
                  h: 30,
                  text_size: 20,
                  char_space: 0,
                  line_space: 0,
                  color: 0xFFFFFF00,
                  align_h: hmUI.align.CENTER_H,
                  align_v: hmUI.align.CENTER_V,
                  text_style: hmUI.text_style.ELLIPSIS,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });
              };
            };
            //end of ignored block

            // normal_forecast_image_progress_img_level = normal_group_ForecastWeather.createWidget(hmUI.widget.IMG_LEVEL_Options, {
              // x: 12,
              // y: -7,
              // image_array: ["S095.png","S096.png","S097.png","S098.png","S099.png","S100.png","S101.png","S102.png","S103.png","S104.png","S105.png","S106.png","S107.png","S108.png","S109.png","S110.png","S111.png","S112.png","S113.png","S114.png","S115.png","S116.png","S117.png","S118.png","S119.png","S120.png","S121.png","S122.png","transparent.png"],
              // image_length: 29,
              // type: hmUI.data_type.forecast_image,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            //start of ignored block
            if (screenType == hmSetting.screen_type.WATCHFACE) {
              for (let i = 0; i < 5; i++) {
                normal_forecast_image_progress_img_level[i] = normal_group_ForecastWeather.createWidget(hmUI.widget.IMG, {
                  x: 12 + i*39,
                  y: -7,
                  src: normal_forecast_image_array[25],
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });
              };
            };
            //end of ignored block

            normal_sun_high_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 381,
              y: 250,
              w: 80,
              h: 30,
              text_size: 30,
              char_space: 0,
              line_space: 0,
              color: 0xFFFFFFFF,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              type: hmUI.data_type.SUN_RISE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sun_low_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 381,
              y: 190,
              w: 80,
              h: 32,
              text_size: 30,
              char_space: 0,
              line_space: 0,
              color: 0xFFFFFFFF,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              type: hmUI.data_type.SUN_SET,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_calorie_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 266,
              y: 406,
              font_array: ["ao0.png","ao1.png","ao2.png","ao3.png","ao4.png","ao5.png","ao6.png","ao7.png","ao8.png","ao9.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 266,
              y: 353,
              font_array: ["ao0.png","ao1.png","ao2.png","ao3.png","ao4.png","ao5.png","ao6.png","ao7.png","ao8.png","ao9.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_distance_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 266,
              y: 295,
              font_array: ["ao0.png","ao1.png","ao2.png","ao3.png","ao4.png","ao5.png","ao6.png","ao7.png","ao8.png","ao9.png"],
              padding: false,
              h_space: 0,
              dot_image: 'Punto.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.DISTANCE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_pointer_progress_img_pointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
              src: 'progr.png',
              center_x: 104,
              center_y: 104,
              x: 6,
              y: 40,
              start_angle: -91,
              end_angle: 91,
              invalid_visible: false,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 81,
              y: 132,
              font_array: ["ao0.png","ao1.png","ao2.png","ao3.png","ao4.png","ao5.png","ao6.png","ao7.png","ao8.png","ao9.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'por.png',
              unit_tc: 'por.png',
              unit_en: 'por.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_pointer_progress_img_pointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
              src: 'progr.png',
              center_x: 104,
              center_y: 359,
              x: 6,
              y: 40,
              start_angle: 270,
              end_angle: 90,
              invalid_visible: false,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 67,
              y: 295,
              font_array: ["ao0.png","ao1.png","ao2.png","ao3.png","ao4.png","ao5.png","ao6.png","ao7.png","ao8.png","ao9.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 178,
              y: -7,
              image_array: ["0095.png","0096.png","0097.png","0098.png","0099.png","0100.png","0101.png","0102.png","0103.png","0104.png","0105.png","0106.png","0107.png","0108.png","0109.png","0110.png","0111.png","0112.png","0113.png","0114.png","0115.png","0116.png","0117.png","0118.png","0119.png","0120.png","0121.png","0122.png","0123.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 300,
              y: 36,
              font_array: ["ao0.png","ao1.png","ao2.png","ao3.png","ao4.png","ao5.png","ao6.png","ao7.png","ao8.png","ao9.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'GRAD-.png',
              unit_tc: 'GRAD-.png',
              unit_en: 'GRAD-.png',
              negative_image: 'nega1.png',
              invalid_image: 'inv.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time_AmPm = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              am_x: 319,
              am_y: 188,
              am_sc_path: 'ha.png',
              am_en_path: 'ha.png',
              pm_x: 315,
              pm_y: 188,
              pm_sc_path: 'hp.png',
              pm_en_path: 'hp.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 15,
              hour_startY: 181,
              hour_array: ["0020.png","0021.png","0022.png","0023.png","0024.png","0025.png","0026.png","0027.png","0028.png","0029.png"],
              hour_zero: 1,
              hour_space: -17,
              hour_angle: 0,
              hour_align: hmUI.align.CENTER_H,

              minute_startX: 160,
              minute_startY: 181,
              minute_array: ["0020.png","0021.png","0022.png","0023.png","0024.png","0025.png","0026.png","0027.png","0028.png","0029.png"],
              minute_zero: 1,
              minute_space: -17,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.CENTER_H,

              second_startX: 309,
              second_startY: 211,
              second_array: ["0002.png","0003.png","0004.png","0005.png","0006.png","0007.png","0008.png","0009.png","0010.png","0011.png"],
              second_zero: 1,
              second_space: 0,
              second_angle: 0,
              second_follow: 0,
              second_align: hmUI.align.CENTER_H,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            console.log('Watch_Face.ScreenAOD');
            idle_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 466,
              h: 466,
              src: 'aod.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_day_text_font = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 308,
              y: 200,
              w: 55,
              h: 45,
              text_size: 40,
              char_space: 0,
              line_space: 0,
              color: 0xFFFFFFFF,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              // padding: true,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_dow_text_font = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 300,
              y: 231,
              w: 75,
              h: 50,
              text_size: 40,
              char_space: 0,
              line_space: 0,
              color: 0xFFFFFFFF,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              // unit_string: LU, MA, MI, JU, VI, SA, DO,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 374,
              y: 65,
              src: 'alar.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 81,
              y: 132,
              font_array: ["ao0.png","ao1.png","ao2.png","ao3.png","ao4.png","ao5.png","ao6.png","ao7.png","ao8.png","ao9.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'por.png',
              unit_tc: 'por.png',
              unit_en: 'por.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time_AmPm = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              am_x: 319,
              am_y: 188,
              am_sc_path: 'ha.png',
              am_en_path: 'ha.png',
              pm_x: 315,
              pm_y: 188,
              pm_sc_path: 'hp.png',
              pm_en_path: 'hp.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 15,
              hour_startY: 181,
              hour_array: ["0020.png","0021.png","0022.png","0023.png","0024.png","0025.png","0026.png","0027.png","0028.png","0029.png"],
              hour_zero: 1,
              hour_space: -17,
              hour_angle: 0,
              hour_align: hmUI.align.CENTER_H,

              minute_startX: 160,
              minute_startY: 181,
              minute_array: ["0020.png","0021.png","0022.png","0023.png","0024.png","0025.png","0026.png","0027.png","0028.png","0029.png"],
              minute_zero: 1,
              minute_space: -17,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.CENTER_H,

              show_level: hmUI.show_level.ONLY_AOD,
            });
            console.log('Watch_Face.Shortcuts');

            normal_alarm_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 374,
              y: 59,
              w: 40,
              h: 40,
              type: hmUI.data_type.ALARM_CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sunrise_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 370,
              y: 183,
              w: 92,
              h: 100,
              type: hmUI.data_type.SUN_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_altimeter_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 382,
              y: 296,
              w: 50,
              h: 50,
              type: hmUI.data_type.ALTIMETER,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 172,
              y: 7,
              w: 190,
              h: 175,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_pai_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 166,
              y: 401,
              w: 150,
              h: 50,
              type: hmUI.data_type.PAI_WEEKLY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 168,
              y: 347,
              w: 155,
              h: 50,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 23,
              y: 289,
              w: 137,
              h: 50,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            console.log('Watch_Face.Buttons');
            Button_1 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 372,
              y: 353,
              w: 50,
              h: 40,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'transparent.png',
              normal_src: 'transparent.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'PhoneHomeScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_2 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 377,
              y: 102,
              w: 67,
              h: 80,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'transparent.png',
              normal_src: 'transparent.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'ScheduleCalScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_3 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 61,
              y: 72,
              w: 95,
              h: 105,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'transparent.png',
              normal_src: 'transparent.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'PowerSaveHintScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            const weatherSensor = hmSensor.createSensor(hmSensor.id.WEATHER);
            //start of ignored block
            function weather_few_days() {
              console.log('weather_few_days()');
              let weatherData = weatherSensor.getForecastWeather();
              let forecastData = weatherData.forecastData;

              for (let i = 0; i < 5; i++) {
                // DayOfWeek font
                if (screenType == hmSetting.screen_type.WATCHFACE) {
                  let dowIndex = timeSensor.week - 1;
                  dowIndex += i;
                  while (dowIndex >= 7) {dowIndex -= 7;}
                  normal_forecast_date_week_font[i].setProperty(hmUI.prop.TEXT, normal_forecast_date_week_font_Array[dowIndex]);
                };
              
                // Number_Font_Min
                let minTemperature = '-';
                if (i < forecastData.count) minTemperature = forecastData.data[i].low.toString();
                if (screenType == hmSetting.screen_type.WATCHFACE) {
                  normal_forecast_low_text_font[i].setProperty(hmUI.prop.TEXT, minTemperature);
                };
                
                // Number_Font_Max
                let maxTemperature = '-';
                if (i < forecastData.count) maxTemperature = forecastData.data[i].high.toString();
                if (screenType == hmSetting.screen_type.WATCHFACE) {
                  normal_forecast_high_text_font[i].setProperty(hmUI.prop.TEXT, maxTemperature);
                };
                
                // Images
                if (screenType == hmSetting.screen_type.WATCHFACE) {
                  let weatherIndex = 25
                  if (i < forecastData.count) weatherIndex = forecastData.data[i].index;
                  normal_forecast_image_progress_img_level[i].setProperty(hmUI.prop.SRC, normal_forecast_image_array[weatherIndex]);
                };
              
              };  // end for

            };
            //end of ignored block

            //start of ignored block
            function time_update(updateHour = false, updateMinute = false) {
              console.log('time_update()');
              let hour = timeSensor.hour;
              let minute = timeSensor.minute;
              let second = timeSensor.second;
              let format_hour = timeSensor.format_hour;

              console.log('day font');
              if (updateHour) {
                let normal_dayStr = timeSensor.day.toString();
                normal_dayStr = normal_dayStr.padStart(2, '0');
                normal_day_text_font.setProperty(hmUI.prop.TEXT, normal_dayStr );
              };

              console.log('day of week font');
              if (updateHour) {
                let normal_DOW_Str = normal_DOW_Array[timeSensor.week-1];
                normal_dow_text_font.setProperty(hmUI.prop.TEXT, normal_DOW_Str );
              };

              console.log('day font');
              if (updateHour) {
                let idle_dayStr = timeSensor.day.toString();
                idle_dayStr = idle_dayStr.padStart(2, '0');
                idle_day_text_font.setProperty(hmUI.prop.TEXT, idle_dayStr );
              };

              console.log('day of week font');
              if (updateHour) {
                let idle_DOW_Str = idle_DOW_Array[timeSensor.week-1];
                idle_dow_text_font.setProperty(hmUI.prop.TEXT, idle_DOW_Str );
              };

            };

            //end of ignored block
            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                console.log('resume_call()');
                time_update(true, true);

                weather_few_days();
              }),
            });

                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}