/*
** Facemaker bundle tool v0.0.3
* *huamiOS watchface js version v2.0.1
* *Copyright © Huami. All Rights Reserved
*/


try {
	(() => {
		var __$$app$$__ = __$$hmAppManager$$__.currentApp;
		var __$$module$$__ = __$$app$$__.current;

		//drink is a name,can modify
		var h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__), 'drink');

		'use strict';

		//dynamic modify start
		let normal_img0 = '';
		let normal_img1 = '';
		let timeInterval;
		let normal_hour_high_imageset3 = '';
		let normal_hour_high_imageset3_array = ['0004.png','0005.png','0006.png'];
		let normal_hour_low_imageset4 = '';
		let normal_hour_low_imageset4_array = ['0007.png','0008.png','0009.png','0010.png','0011.png','0012.png','0013.png','0014.png','0015.png','0016.png'];
		let normal_minute_high_imageset5 = '';
		let normal_minute_high_imageset5_array = ['0017.png','0018.png','0019.png','0020.png','0021.png','0022.png'];
		let normal_minute_low_imageset6 = '';
		let normal_minute_low_imageset6_array = ['0023.png','0024.png','0025.png','0026.png','0027.png','0028.png','0029.png','0030.png','0031.png','0032.png'];
		let normal_img7 = '';
		let normal_img9 = '';
		let normal_second_rotary10 = '';
		let normal_battery_rotary12 = '';
		let normal_img13 = '';
		let normal_img14 = '';
		let normal_img16 = '';
		let normal_week_imageset17 = '';
		let normal_date_imagecombo18 = '';
		let normal_month_imagecombo19 = '';
		let normal_img20 = '';
		let normal_steps_imagecombo22 = '';
		let normal_img23 = '';
		let normal_img24 = '';
		let normal_steps_rotary25 = '';
		let normal_distance_imagecombo27 = '';
		let normal_img28 = '';
		let normal_calories_imagecombo30 = '';
		let normal_img31 = '';
		let normal_heart_current_imagecombo33 = '';
		let normal_img34 = '';
		let normal_blood_oxygen_imagecombo36 = '';
		let normal_img37 = '';
		let normal_alarm_status39 = '';
		let normal_bt_status40 = '';
		let normal_lock_status41 = '';
		//dynamic modify end

		//not required
		const logger = DeviceRuntimeCore.HmLogger.getLogger("yeguang");

		__$$module$$__.module = DeviceRuntimeCore.WatchFace({
			init_view() {

				const timeSensor = hmSensor.createSensor(hmSensor.id.TIME);
				let screenType = hmSetting.getScreenType();

				normal_img0 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 0,
					y: 0,
					w: 466,
					h: 466,
					src: '0002.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img1 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 3,
					y: 232,
					w: 45,
					h: 3,
					src: '0003.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_hour_high_imageset3 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 82,
					y: 166,
					w: 82,
					h: 166,
					src: '0006.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				})

				normal_hour_low_imageset4 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 152,
					y: 166,
					w: 152,
					h: 166,
					src: '0016.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				})

				normal_minute_high_imageset5 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 249,
					y: 166,
					w: 249,
					h: 166,
					src: '0022.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				})

				normal_minute_low_imageset6 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 319,
					y: 166,
					w: 319,
					h: 166,
					src: '0032.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				})

				normal_img7 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 214,
					y: 169,
					w: 39,
					h: 114,
					src: '0033.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img9 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 51,
					y: 51,
					w: 365,
					h: 365,
					src: '0034.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_second_rotary10 = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
					second_path: '0035.png',
					second_centerX: 233,
					second_centerY: 233,
					second_posX: 49,
					second_posY: 179,
					second_start_angle: 0,
					second_end_angle: 360,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_battery_rotary12 = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
					src: '0036.png',
					center_x: 233,
					center_y: 233,
					x: 11,
					y: 251,
					start_angle: 230,
					end_angle: 130,
					type: hmUI.data_type.BATTERY,
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img13 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 39,
					y: 328,
					w: 43,
					h: 41,
					src: '0037.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img14 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 389,
					y: 329,
					w: 43,
					h: 41,
					src: '0038.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img16 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 93,
					y: 306,
					w: 280,
					h: 30,
					src: '0039.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_week_imageset17 = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
					x: 100,
					y: 331,
					week_en: ["0040.png","0041.png","0042.png","0043.png","0044.png","0045.png","0046.png"],
					week_tc: ["0040.png","0041.png","0042.png","0043.png","0044.png","0045.png","0046.png"],
					week_sc: ["0040.png","0041.png","0042.png","0043.png","0044.png","0045.png","0046.png"],
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_date_imagecombo18 = hmUI.createWidget(hmUI.widget.IMG_DATE, {
					day_startX: 168,
					day_startY: 331,
					day_sc_array: ["0047.png","0048.png","0049.png","0050.png","0051.png","0052.png","0053.png","0054.png","0055.png","0056.png"],
					day_tc_array: ["0047.png","0048.png","0049.png","0050.png","0051.png","0052.png","0053.png","0054.png","0055.png","0056.png"],
					day_en_array: ["0047.png","0048.png","0049.png","0050.png","0051.png","0052.png","0053.png","0054.png","0055.png","0056.png"],
					day_zero: true,
					day_space: -15,
					day_align: hmUI.align.CENTER_H,
					day_is_character: false,
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_month_imagecombo19 = hmUI.createWidget(hmUI.widget.IMG_DATE, {
					month_startX: 236,
					month_startY: 331,
					month_sc_array: ["0047.png","0048.png","0049.png","0050.png","0051.png","0052.png","0053.png","0054.png","0055.png","0056.png"],
					month_tc_array: ["0047.png","0048.png","0049.png","0050.png","0051.png","0052.png","0053.png","0054.png","0055.png","0056.png"],
					month_en_array: ["0047.png","0048.png","0049.png","0050.png","0051.png","0052.png","0053.png","0054.png","0055.png","0056.png"],
					month_zero: true,
					month_space: -15,
					month_align: hmUI.align.CENTER_H,
					month_is_character: false,
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img20 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 219,
					y: 328,
					w: 27,
					h: 74,
					src: '0057.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_steps_imagecombo22 = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
					x: 174,
					y: 63,
					font_array: ["0058.png","0059.png","0060.png","0061.png","0062.png","0063.png","0064.png","0065.png","0066.png","0067.png"],
					padding: false,
					h_space: -14,
					align_h: hmUI.align.CENTER_H,
					type: hmUI.data_type.STEP,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img23 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 154,
					y: 82,
					w: 23,
					h: 30,
					src: '0068.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img24 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 285,
					y: 83,
					w: 39,
					h: 39,
					src: '0069.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_steps_rotary25 = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
					src: '0070.png',
					center_x: 233,
					center_y: 233,
					x: 11,
					y: 251,
					start_angle: -50,
					end_angle: 50,
					type: hmUI.data_type.STEP,
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_distance_imagecombo27 = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
					x: 109,
					y: 116,
					font_array: ["0071.png","0072.png","0073.png","0074.png","0075.png","0076.png","0077.png","0078.png","0079.png","0080.png"],
					padding: false,
					h_space: -13,
					dot_image: '0081.png',
					align_h: hmUI.align.CENTER_H,
					type: hmUI.data_type.DISTANCE,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img28 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 104,
					y: 129,
					w: 18,
					h: 25,
					src: '0082.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_calories_imagecombo30 = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
					x: 274,
					y: 116,
					font_array: ["0083.png","0084.png","0085.png","0086.png","0087.png","0088.png","0089.png","0090.png","0091.png","0092.png"],
					padding: false,
					h_space: -14,
					align_h: hmUI.align.CENTER_H,
					type: hmUI.data_type.CAL,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img31 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 252,
					y: 127,
					w: 25,
					h: 30,
					src: '0093.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_heart_current_imagecombo33 = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
					x: -7,
					y: 182,
					font_array: ["0094.png","0095.png","0096.png","0097.png","0098.png","0099.png","0100.png","0101.png","0102.png","0103.png"],
					padding: false,
					h_space: -14,
					invalid_image: '0104.png',
					align_h: hmUI.align.CENTER_H,
					type: hmUI.data_type.HEART,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img34 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 8,
					y: 139,
					w: 51,
					h: 48,
					src: '0105.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_blood_oxygen_imagecombo36 = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
					x: -6,
					y: 236,
					font_array: ["0094.png","0095.png","0096.png","0097.png","0098.png","0099.png","0100.png","0101.png","0102.png","0103.png"],
					padding: false,
					h_space: -14,
					align_h: hmUI.align.CENTER_H,
					type: hmUI.data_type.SPO2,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img37 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 8,
					y: 275,
					w: 55,
					h: 57,
					src: '0106.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_alarm_status39 = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
					x: 427,
					y: 212,
					w: 37,
					h: 38,
					type: hmUI.system_status.CLOCK,
					src: '0107.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_bt_status40 = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
					x: 412,
					y: 281,
					w: 35,
					h: 41,
					type: hmUI.system_status.DISCONNECT,
					src: '0108.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_lock_status41 = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
					x: 410,
					y: 143,
					w: 40,
					h: 43,
					type: hmUI.system_status.LOCK,
					src: '0109.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				function updateTime() {
					normal_hour_high_imageset3.setProperty(hmUI.prop.MORE, {
						src: normal_hour_high_imageset3_array[(timeSensor.format_hour.toString().length == 2 ? timeSensor.format_hour.toString().charAt(0) : 0)]
					})
					normal_hour_low_imageset4.setProperty(hmUI.prop.MORE, {
						src: normal_hour_low_imageset4_array[(timeSensor.format_hour.toString().length == 2 ? timeSensor.format_hour.toString().charAt(1) : timeSensor.format_hour.toString().charAt(0))]
					})
					normal_minute_high_imageset5.setProperty(hmUI.prop.MORE, {
						src: normal_minute_high_imageset5_array[(timeSensor.minute.toString().length == 2 ? timeSensor.minute.toString().charAt(0) : 0)]
					})
					normal_minute_low_imageset6.setProperty(hmUI.prop.MORE, {
						src: normal_minute_low_imageset6_array[(timeSensor.minute.toString().length == 2 ? timeSensor.minute.toString().charAt(1) : timeSensor.minute.toString().charAt(0))]
					})
				}

				timeSensor.addEventListener(hmSensor.event.CHANGE, function() {
					updateTime();
				});

				const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
					resume_call: (function () {
						updateTime();
						timeInterval = setInterval(updateTime, 1000);
					}),
					pause_call: (function () {
						clearInterval(timeInterval);
					}),
				})
			},

		onInit() {
			console.log('index page.js on init invoke')
			this.init_view()
		},
		onReady() {
			console.log('index page.js on ready invoke')
		},
		onShow() {
			console.log('index page.js on show invoke')
		},
		onHide() {
			console.log('index page.js on hide invoke')
		},
		onDestroy() {
			console.log('index page.js on destroy invoke')
		},
	});	})()
} catch (e) {
	console.log(e)
}