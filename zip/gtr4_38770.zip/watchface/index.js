﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        const logger = Logger.getLogger('watchface_SashaCX75');
        //end of ignored block

        //dynamic modify start

        
        let normal_background_bg = ''
        let normal_date_img_date_week_img = ''
        let normal_stress_icon_img = ''
        let normal_image_img = ''
        let normal_altitude_target_text_img = ''
        let normal_altimeter_icon_img = ''
        let normal_sun_high_text_font = ''
        let normal_sun_low_text_font = ''
        let normal_pai_icon_img = ''
        let normal_step_icon_img = ''
        let normal_step_TextCircle = new Array(5);
        let normal_step_TextCircle_ASCIIARRAY = new Array(10);
        let normal_step_TextCircle_img_width = 16;
        let normal_step_TextCircle_img_height = 28;
        let normal_fat_burning_icon_img = ''
        let normal_date_img_date_month_img = ''
        let normal_date_img_date_day = ''
        let normal_heart_rate_text_text_img = ''
        let normal_calorie_TextCircle = new Array(4);
        let normal_calorie_TextCircle_ASCIIARRAY = new Array(10);
        let normal_calorie_TextCircle_img_width = 16;
        let normal_calorie_TextCircle_img_height = 28;
        let normal_humidity_icon_img = ''
        let normal_humidity_text_text_img = ''
        let normal_digital_clock_img_time = ''
        let normal_wind_text_text_img = ''
        let normal_wind_direction_image_progress_img_level = ''
        let normal_city_name_text = ''
        let normal_temperature_high_text_img = ''
        let normal_temperature_low_text_img = ''
        let normal_temperature_current_text_img = ''
        let normal_weather_image_progress_img_level = ''
        let normal_battery_circle_scale = ''
        let normal_battery_text_text_img = ''
        let normal_system_disconnect_img = ''
        let normal_system_clock_img = ''
        let normal_rotate_animation_img_1 = '';
        let normal_rotate_animation_param_1 = null;
        let normal_rotate_animation_lastTime_1 = 0;
        let timer_anim_rotate_1;
        let normal_rotate_animation_count_1 = 0;
        let idle_background_bg = ''
        let idle_image_img = ''
        let idle_date_img_date_month_img = ''
        let idle_date_img_date_day = ''
        let idle_date_img_date_week_img = ''
        let idle_digital_clock_img_time = ''
        let image_top_img = ''


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            // FontName: Bebas11.ttf; FontSize: 26
            hmUI.createWidget(hmUI.widget.TEXT, {
              x: 452,
              y: 452,
              w: 259,
              h: 37,
              text_size: 26,
              char_space: 0,
              line_space: 0,
              font: 'fonts/Bebas11.ttf',
              color: 0xFFC0C0C0,
              align_h: hmUI.align.LEFT,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              text: "0123456789 _-.,:;`'%°\\/",
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // FontName: Bebas11.ttf; FontSize: 25; Cache: full
            hmUI.createWidget(hmUI.widget.TEXT, {
              x: 452,
              y: 452,
              w: 30,
              h: 30,
              text_size: 25,
              char_space: 0,
              line_space: 0,
              font: 'fonts/Bebas11.ttf',
              color: 0xFFAFAFAF,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.NONE,
              text: "0123456789 ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz АБВГДЕЁЖЗИЙКЛМНОПРСТУФХЦЧШЩЪЫЬЭЮЯабвгдеёжзийклмнопрстуфхцчшщъыьэюя  ҐЄІЇґєії _-.,:;`'%°\\/",
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            console.log('Watch_Face.ScreenNormal');
            normal_background_bg = hmUI.createWidget(hmUI.widget.FILL_RECT, {
              x: 0,
              y: 0,
              w: 454,
              h: 454,
              color: '0xFFC0C0C0',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 97,
              y: 292,
              week_en: ["week_0.png","week_1.png","week_2.png","week_3.png","week_4.png","week_5.png","week_6.png"],
              week_tc: ["week_0.png","week_1.png","week_2.png","week_3.png","week_4.png","week_5.png","week_6.png"],
              week_sc: ["week_0.png","week_1.png","week_2.png","week_3.png","week_4.png","week_5.png","week_6.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_stress_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 395,
              y: 272,
              src: 'bg_fix_btn.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_image_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'bg_0.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_altitude_target_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 202,
              y: 103,
              font_array: ["dig_al_0.png","dig_al_1.png","dig_al_2.png","dig_al_3.png","dig_al_4.png","dig_al_5.png","dig_al_6.png","dig_al_7.png","dig_al_8.png","dig_al_9.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'dig_c_M.png',
              unit_tc: 'dig_c_M.png',
              unit_en: 'dig_c_M.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.ALTITUDE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_altimeter_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 207,
              y: 72,
              src: 'ic_visota.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sun_high_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 142,
              y: 98,
              w: 150,
              h: 30,
              text_size: 26,
              char_space: 0,
              line_space: 0,
              font: 'fonts/Bebas11.ttf',
              color: 0xFFC0C0C0,
              align_h: hmUI.align.LEFT,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              type: hmUI.data_type.SUN_RISE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sun_low_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 159,
              y: 98,
              w: 150,
              h: 30,
              text_size: 26,
              char_space: 0,
              line_space: 0,
              font: 'fonts/Bebas11.ttf',
              color: 0xFFC0C0C0,
              align_h: hmUI.align.RIGHT,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              type: hmUI.data_type.SUN_SET,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_pai_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'cap.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 200,
              y: 431,
              src: 'ic_step_txt.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_step_text_circle_img = hmUI.createWidget(hmUI.widget.Text_Circle, {
              // circle_center_X: 225,
              // circle_center_Y: 225,
              // font_array: ["data_0.png","data_1.png","data_2.png","data_3.png","data_4.png","data_5.png","data_6.png","data_7.png","data_8.png","data_9.png"],
              // radius: 181,
              // angle: -180,
              // char_space_angle: 1,
              // zero: false,
              // reverse_direction: true,
              // unit_in_alignment: false,
              // vertical_alignment: CENTER_V,
              // horizontal_alignment: CENTER_H,
              // type: hmUI.data_type.STEP,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_step_TextCircle_ASCIIARRAY[0] = 'data_0.png';  // set of images with numbers
            normal_step_TextCircle_ASCIIARRAY[1] = 'data_1.png';  // set of images with numbers
            normal_step_TextCircle_ASCIIARRAY[2] = 'data_2.png';  // set of images with numbers
            normal_step_TextCircle_ASCIIARRAY[3] = 'data_3.png';  // set of images with numbers
            normal_step_TextCircle_ASCIIARRAY[4] = 'data_4.png';  // set of images with numbers
            normal_step_TextCircle_ASCIIARRAY[5] = 'data_5.png';  // set of images with numbers
            normal_step_TextCircle_ASCIIARRAY[6] = 'data_6.png';  // set of images with numbers
            normal_step_TextCircle_ASCIIARRAY[7] = 'data_7.png';  // set of images with numbers
            normal_step_TextCircle_ASCIIARRAY[8] = 'data_8.png';  // set of images with numbers
            normal_step_TextCircle_ASCIIARRAY[9] = 'data_9.png';  // set of images with numbers

            //start of ignored block
            for (let i = 0; i < 5; i++) {
              normal_step_TextCircle[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 454,
                h: 454,
                center_x: 225,
                center_y: 225,
                pos_x: 225 - normal_step_TextCircle_img_width / 2,
                pos_y: 225 + 167,
                src: 'data_0.png',
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
              normal_step_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
            };
            //end of ignored block
            
            const step = hmSensor.createSensor(hmSensor.id.STEP);
            step.addEventListener(hmSensor.event.CHANGE, function() {
              text_update();
            });
            
            function toDegree (radian) {
              return radian * (180 / Math.PI);
            };

            normal_fat_burning_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 171,
              y: 334,
              src: 'bg_fix_data.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_month_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 220,
              month_startY: 334,
              month_sc_array: ["mo_0.png","mo_1.png","mo_2.png","mo_3.png","mo_4.png","mo_5.png","mo_6.png","mo_7.png","mo_8.png","mo_9.png","mo_10.png","mo_11.png"],
              month_tc_array: ["mo_0.png","mo_1.png","mo_2.png","mo_3.png","mo_4.png","mo_5.png","mo_6.png","mo_7.png","mo_8.png","mo_9.png","mo_10.png","mo_11.png"],
              month_en_array: ["mo_0.png","mo_1.png","mo_2.png","mo_3.png","mo_4.png","mo_5.png","mo_6.png","mo_7.png","mo_8.png","mo_9.png","mo_10.png","mo_11.png"],
              month_is_character: true ,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 180,
              day_startY: 340,
              day_sc_array: ["data_0.png","data_1.png","data_2.png","data_3.png","data_4.png","data_5.png","data_6.png","data_7.png","data_8.png","data_9.png"],
              day_tc_array: ["data_0.png","data_1.png","data_2.png","data_3.png","data_4.png","data_5.png","data_6.png","data_7.png","data_8.png","data_9.png"],
              day_en_array: ["data_0.png","data_1.png","data_2.png","data_3.png","data_4.png","data_5.png","data_6.png","data_7.png","data_8.png","data_9.png"],
              day_zero: 1,
              day_space: 0,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 301,
              y: 369,
              font_array: ["dig_s_0.png","dig_s_1.png","dig_s_2.png","dig_s_3.png","dig_s_4.png","dig_s_5.png","dig_s_6.png","dig_s_7.png","dig_s_8.png","dig_s_9.png"],
              padding: false,
              h_space: 0,
              angle: -35,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_calorie_text_circle_img = hmUI.createWidget(hmUI.widget.Text_Circle, {
              // circle_center_X: 225,
              // circle_center_Y: 225,
              // font_array: ["data_0.png","data_1.png","data_2.png","data_3.png","data_4.png","data_5.png","data_6.png","data_7.png","data_8.png","data_9.png"],
              // radius: 194,
              // angle: -156,
              // char_space_angle: 0,
              // zero: true,
              // reverse_direction: true,
              // unit_in_alignment: true,
              // vertical_alignment: BOTTOM,
              // horizontal_alignment: RIGHT,
              // type: hmUI.data_type.CAL,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_calorie_TextCircle_ASCIIARRAY[0] = 'data_0.png';  // set of images with numbers
            normal_calorie_TextCircle_ASCIIARRAY[1] = 'data_1.png';  // set of images with numbers
            normal_calorie_TextCircle_ASCIIARRAY[2] = 'data_2.png';  // set of images with numbers
            normal_calorie_TextCircle_ASCIIARRAY[3] = 'data_3.png';  // set of images with numbers
            normal_calorie_TextCircle_ASCIIARRAY[4] = 'data_4.png';  // set of images with numbers
            normal_calorie_TextCircle_ASCIIARRAY[5] = 'data_5.png';  // set of images with numbers
            normal_calorie_TextCircle_ASCIIARRAY[6] = 'data_6.png';  // set of images with numbers
            normal_calorie_TextCircle_ASCIIARRAY[7] = 'data_7.png';  // set of images with numbers
            normal_calorie_TextCircle_ASCIIARRAY[8] = 'data_8.png';  // set of images with numbers
            normal_calorie_TextCircle_ASCIIARRAY[9] = 'data_9.png';  // set of images with numbers

            //start of ignored block
            for (let i = 0; i < 4; i++) {
              normal_calorie_TextCircle[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 454,
                h: 454,
                center_x: 225,
                center_y: 225,
                pos_x: 225 - normal_calorie_TextCircle_img_width / 2,
                pos_y: 225 + 166,
                src: 'data_0.png',
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
              normal_calorie_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
            };
            //end of ignored block
            
            const calorie = hmSensor.createSensor(hmSensor.id.CALORIE);
            calorie.addEventListener(hmSensor.event.CHANGE, function() {
              text_update();
            });

            normal_humidity_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'bg_fix_sec.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_humidity_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 34,
              y: 223,
              font_array: ["dig_s_0.png","dig_s_1.png","dig_s_2.png","dig_s_3.png","dig_s_4.png","dig_s_5.png","dig_s_6.png","dig_s_7.png","dig_s_8.png","dig_s_9.png"],
              padding: false,
              h_space: 0,
              angle: -84,
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.HUMIDITY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 98,
              hour_startY: 183,
              hour_array: ["H_0.png","H_1.png","H_2.png","H_3.png","H_4.png","H_5.png","H_6.png","H_7.png","H_8.png","H_9.png"],
              hour_zero: 1,
              hour_space: 0,
              hour_angle: 0,
              hour_align: hmUI.align.CENTER_H,

              minute_startX: 244,
              minute_startY: 183,
              minute_array: ["H_0.png","H_1.png","H_2.png","H_3.png","H_4.png","H_5.png","H_6.png","H_7.png","H_8.png","H_9.png"],
              minute_zero: 1,
              minute_space: 0,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.CENTER_H,

              second_startX: 370,
              second_startY: 240,
              second_array: ["H1_0.png","H1_1.png","H1_2.png","H1_3.png","H1_4.png","H1_5.png","H1_6.png","H1_7.png","H1_8.png","H1_9.png"],
              second_zero: 1,
              second_space: 0,
              second_angle: 0,
              second_follow: 0,
              second_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_wind_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 356,
              y: 107,
              font_array: ["dig_s_0.png","dig_s_1.png","dig_s_2.png","dig_s_3.png","dig_s_4.png","dig_s_5.png","dig_s_6.png","dig_s_7.png","dig_s_8.png","dig_s_9.png"],
              padding: false,
              h_space: 0,
              angle: 60,
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.WIND,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_wind_direction_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 301,
              y: 58,
              image_array: ["wind_0.png","wind_1.png","wind_2.png","wind_3.png","wind_4.png","wind_5.png","wind_6.png","wind_7.png"],
              image_length: 8,
              type: hmUI.data_type.WIND_DIRECTION,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
              const weatherSensor = hmSensor.createSensor(hmSensor.id.WEATHER);

            normal_city_name_text = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 105,
              y: 119,
              w: 244,
              h: 41,
              text_size: 25,
              char_space: 0,
              line_space: 0,
              font: 'fonts/Bebas11.ttf',
              color: 0xFFAFAFAF,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.NONE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_high_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 144,
              y: 51,
              font_array: ["dig_a_0.png","dig_a_1.png","dig_a_2.png","dig_a_3.png","dig_a_4.png","dig_a_5.png","dig_a_6.png","dig_a_7.png","dig_a_8.png","dig_a_9.png"],
              padding: false,
              h_space: 0,
              angle: -22,
              unit_sc: 'dig_a_p.png',
              unit_tc: 'dig_a_p.png',
              unit_en: 'dig_a_p.png',
              negative_image: 'dig_a_m.png',
              invalid_image: 'dig_a_p.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.WEATHER_HIGH,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_low_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 98,
              y: 81,
              font_array: ["dig_a_0.png","dig_a_1.png","dig_a_2.png","dig_a_3.png","dig_a_4.png","dig_a_5.png","dig_a_6.png","dig_a_7.png","dig_a_8.png","dig_a_9.png"],
              padding: false,
              h_space: 0,
              angle: -39,
              unit_sc: 'dig_a_p.png',
              unit_tc: 'dig_a_p.png',
              unit_en: 'dig_a_p.png',
              negative_image: 'dig_a_m.png',
              invalid_image: 'dig_a_p.png',
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.WEATHER_LOW,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 47,
              y: 141,
              font_array: ["dig_s_0.png","dig_s_1.png","dig_s_2.png","dig_s_3.png","dig_s_4.png","dig_s_5.png","dig_s_6.png","dig_s_7.png","dig_s_8.png","dig_s_9.png"],
              padding: false,
              h_space: 0,
              angle: -57,
              negative_image: 'dig_a_m.png',
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 0,
              y: 0,
              image_array: ["ww_0.png","ww_1.png","ww_2.png","ww_3.png","ww_4.png","ww_5.png","ww_6.png","ww_7.png","ww_8.png","ww_9.png","ww_10.png","ww_11.png","ww_12.png","ww_13.png","ww_14.png","ww_15.png","ww_16.png","ww_17.png","ww_18.png","ww_19.png","ww_20.png","ww_21.png","ww_22.png","ww_23.png","ww_24.png","ww_25.png","ww_26.png","ww_27.png","ww_28.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_battery_circle_scale = hmUI.createWidget(hmUI.widget.Circle_Scale, {
              // center_x: 225,
              // center_y: 225,
              // start_angle: -132,
              // end_angle: -99,
              // radius: 219,
              // line_width: 17,
              // line_cap: Flat,
              // color: 0xFFC0C0C0,
              // mirror: False,
              // inversion: False,
              // type: hmUI.data_type.BATTERY,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            let screenType = hmSetting.getScreenType();
            normal_battery_circle_scale = hmUI.createWidget(hmUI.widget.ARC_PROGRESS, {
              center_x: 225,
              center_y: 225,
              start_angle: -132,
              end_angle: -99,
              radius: 211,
              line_width: 17,
              corner_flag: 3,
              color: 0xFFC0C0C0,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            
            const battery = hmSensor.createSensor(hmSensor.id.BATTERY);
            battery.addEventListener(hmSensor.event.CHANGE, function() {
              scale_call();
            });

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 50,
              y: 287,
              font_array: ["dig_a_0.png","dig_a_1.png","dig_a_2.png","dig_a_3.png","dig_a_4.png","dig_a_5.png","dig_a_6.png","dig_a_7.png","dig_a_8.png","dig_a_9.png"],
              padding: false,
              h_space: 0,
              angle: 62,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 110,
              y: 156,
              src: 'status_B_off.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 255,
              y: 153,
              src: 'status_H_on.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_rotate_animation_img_1 = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 455,
              h: 455,
              pos_x: 375,
              pos_y: 205,
              center_x: 390,
              center_y: 220,
              angle: 0,
              src: 'animation/ic_sec.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_rotate_animation_param_1 = {
              anim_steps: [{
                anim_rate: 'linear',
                anim_duration: 10000,
                anim_from: 0,
                anim_to: 360,
                anim_key: "angle",
              }],
              anim_fps: 15,
              anim_auto_start: 1,
              anim_repeat: 1,
              anim_auto_destroy: 1,
            };

            let now = hmSensor.createSensor(hmSensor.id.TIME);

            function anim_rotate_1_complete_call() {
              normal_rotate_animation_img_1.setProperty(hmUI.prop.ANIM, normal_rotate_animation_param_1);
              normal_rotate_animation_lastTime_1 = now.utc;
              normal_rotate_animation_count_1 = normal_rotate_animation_count_1 - 1;
              if(normal_rotate_animation_count_1 < -1) normal_rotate_animation_count_1 = - 1;
              if(normal_rotate_animation_count_1 == 0) stop_anim_rotate_1();
            }; // end animation callback function
            
            function stop_anim_rotate_1() {
              if (timer_anim_rotate_1) {
                timer.stopTimer(timer_anim_rotate_1);
                timer_anim_rotate_1 = undefined;
              };
            }; // end stop_anim_rotate function

            // normal_rotate_anime_1 = hmUI.createWidget(hmUI.widget.Rotate_Animation, {
              // start_angle: 0,
              // end_angle: 360,
              // pos_x: 15,
              // pos_y: 15,
              // center_x: 390,
              // center_y: 220,
              // src: 'ic_sec.png',
              // anim_fps: 15,
              // anim_duration: 10000,
              // repeat_count: 0,
              // anim_two_sides: False,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });


            console.log('Watch_Face.ScreenAOD');
            idle_background_bg = hmUI.createWidget(hmUI.widget.FILL_RECT, {
              x: 0,
              y: 0,
              w: 454,
              h: 454,
              color: '0xFF383838',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_image_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'bg_0.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_month_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 220,
              month_startY: 333,
              month_sc_array: ["mo_0.png","mo_1.png","mo_2.png","mo_3.png","mo_4.png","mo_5.png","mo_6.png","mo_7.png","mo_8.png","mo_9.png","mo_10.png","mo_11.png"],
              month_tc_array: ["mo_0.png","mo_1.png","mo_2.png","mo_3.png","mo_4.png","mo_5.png","mo_6.png","mo_7.png","mo_8.png","mo_9.png","mo_10.png","mo_11.png"],
              month_en_array: ["mo_0.png","mo_1.png","mo_2.png","mo_3.png","mo_4.png","mo_5.png","mo_6.png","mo_7.png","mo_8.png","mo_9.png","mo_10.png","mo_11.png"],
              month_is_character: true ,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 180,
              day_startY: 339,
              day_sc_array: ["data_0.png","data_1.png","data_2.png","data_3.png","data_4.png","data_5.png","data_6.png","data_7.png","data_8.png","data_9.png"],
              day_tc_array: ["data_0.png","data_1.png","data_2.png","data_3.png","data_4.png","data_5.png","data_6.png","data_7.png","data_8.png","data_9.png"],
              day_en_array: ["data_0.png","data_1.png","data_2.png","data_3.png","data_4.png","data_5.png","data_6.png","data_7.png","data_8.png","data_9.png"],
              day_zero: 1,
              day_space: 0,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 98,
              y: 291,
              week_en: ["week_0.png","week_1.png","week_2.png","week_3.png","week_4.png","week_5.png","week_6.png"],
              week_tc: ["week_0.png","week_1.png","week_2.png","week_3.png","week_4.png","week_5.png","week_6.png"],
              week_sc: ["week_0.png","week_1.png","week_2.png","week_3.png","week_4.png","week_5.png","week_6.png"],
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 89,
              hour_startY: 182,
              hour_array: ["H_0.png","H_1.png","H_2.png","H_3.png","H_4.png","H_5.png","H_6.png","H_7.png","H_8.png","H_9.png"],
              hour_zero: 1,
              hour_space: 0,
              hour_angle: 0,
              hour_align: hmUI.align.CENTER_H,

              minute_startX: 248,
              minute_startY: 182,
              minute_array: ["H_0.png","H_1.png","H_2.png","H_3.png","H_4.png","H_5.png","H_6.png","H_7.png","H_8.png","H_9.png"],
              minute_zero: 1,
              minute_space: 0,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.CENTER_H,

              show_level: hmUI.show_level.ONLY_AOD,
            });

            image_top_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'ic_txt_Circle+KK.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            //start of ignored block
            function text_update() {
              console.log('text_update()');

              console.log('update text circle step_STEP');
              let valueStep = step.current;
              let normal_step_circle_string = parseInt(valueStep).toString();

              if (screenType != hmSetting.screen_type.AOD) {
                for (var i = 1; i < 5; i++) {  // hide all symbols
                  normal_step_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                let char_Angle = 0;
                if (valueStep != null && valueStep != undefined && isFinite(valueStep) && normal_step_circle_string.length > 0 && normal_step_circle_string.length < 6) {  // display data if it was possible to get it
                  let normal_step_TextCircle_img_angle = 0;
                  let normal_step_TextCircle_dot_img_angle = 0;
                  normal_step_TextCircle_img_angle = toDegree(Math.atan2(normal_step_TextCircle_img_width/2, 181));
                  // alignment = CENTER_H
                  let normal_step_TextCircle_angleOffset = normal_step_TextCircle_img_angle * (normal_step_circle_string.length - 1);
                  normal_step_TextCircle_angleOffset = normal_step_TextCircle_angleOffset + 1 * (normal_step_circle_string.length - 1) / 2;
                  normal_step_TextCircle_angleOffset = -normal_step_TextCircle_angleOffset;
                  char_Angle -= normal_step_TextCircle_angleOffset;
                  // alignment end
                  
                  let firstSymbol = true;
                  let index = 0;
                  for (let char of normal_step_circle_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 5) break;
                    if (charCode >= 0 && charCode < 10) { 
                      if (!firstSymbol) char_Angle -= normal_step_TextCircle_img_angle;
                      firstSymbol = false;
                      normal_step_TextCircle[index].setProperty(hmUI.prop.ANGLE, char_Angle);
                      normal_step_TextCircle[index].setProperty(hmUI.prop.POS_X, 225 - normal_step_TextCircle_img_width / 2);
                      normal_step_TextCircle[index].setProperty(hmUI.prop.SRC, normal_step_TextCircle_ASCIIARRAY[charCode]);
                      normal_step_TextCircle[index].setProperty(hmUI.prop.VISIBLE, true);
                      char_Angle -= normal_step_TextCircle_img_angle + 1;
                      index++;
                    };  // end if digit
                  };  // end char of string
                }  // end isFinite

              };

              console.log('update text circle calorie_CALORIE');
              let valueCalories = calorie.current;
              let normal_calorie_circle_string = parseInt(valueCalories).toString();
              normal_calorie_circle_string = normal_calorie_circle_string.padStart(4, '0');

              if (screenType != hmSetting.screen_type.AOD) {
                for (var i = 1; i < 4; i++) {  // hide all symbols
                  normal_calorie_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                let char_Angle = 24;
                if (valueCalories != null && valueCalories != undefined && isFinite(valueCalories) && normal_calorie_circle_string.length > 0 && normal_calorie_circle_string.length < 6) {  // display data if it was possible to get it
                  let normal_calorie_TextCircle_img_angle = 0;
                  let normal_calorie_TextCircle_dot_img_angle = 0;
                  normal_calorie_TextCircle_img_angle = toDegree(Math.atan2(normal_calorie_TextCircle_img_width/2, 194));
                  // alignment = RIGHT
                  let normal_calorie_TextCircle_angleOffset = normal_calorie_TextCircle_img_angle * (normal_calorie_circle_string.length - 1);
                  normal_calorie_TextCircle_angleOffset = -normal_calorie_TextCircle_angleOffset;
                  char_Angle -= 2 * normal_calorie_TextCircle_angleOffset;
                  // alignment end
                  
                  let firstSymbol = true;
                  let index = 0;
                  for (let char of normal_calorie_circle_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 4) break;
                    if (charCode >= 0 && charCode < 10) { 
                      if (!firstSymbol) char_Angle -= normal_calorie_TextCircle_img_angle;
                      firstSymbol = false;
                      normal_calorie_TextCircle[index].setProperty(hmUI.prop.ANGLE, char_Angle);
                      normal_calorie_TextCircle[index].setProperty(hmUI.prop.POS_X, 225 - normal_calorie_TextCircle_img_width / 2);
                      normal_calorie_TextCircle[index].setProperty(hmUI.prop.SRC, normal_calorie_TextCircle_ASCIIARRAY[charCode]);
                      normal_calorie_TextCircle[index].setProperty(hmUI.prop.VISIBLE, true);
                      char_Angle -= normal_calorie_TextCircle_img_angle;
                      index++;
                    };  // end if digit
                  };  // end char of string
                }  // end isFinite

              };

            };

            //end of ignored block
            function scale_call() {
              console.log('scale_call()');

              console.log('Weather city name');
              let weatherData = weatherSensor.getForecastWeather();
              normal_city_name_text.setProperty(hmUI.prop.TEXT, weatherData.cityName);

                console.log('update scales BATTERY');
                
                let valueBattery = battery.current;
                let targetBattery = 100;
                let progressBattery = valueBattery/targetBattery;
                if (progressBattery > 1) progressBattery = 1;
                let progress_cs_normal_battery = progressBattery;

                if (screenType != hmSetting.screen_type.AOD) {

                  // normal_battery_circle_scale_circle_scale
                  let level = Math.round(progress_cs_normal_battery * 100);
                  if (normal_battery_circle_scale) {
                    normal_battery_circle_scale.setProperty(hmUI.prop.MORE, {                      
                      center_x: 225,
                      center_y: 225,
                      start_angle: -132,
                      end_angle: -99,
                      radius: 211,
                      line_width: 17,
                      corner_flag: 3,
                      color: 0xFFC0C0C0,
                      show_level: hmUI.show_level.ONLY_NORMAL,
                      level: level,
                    });
                  };
                };

            };

            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                console.log('resume_call()');
                scale_call();
                text_update();

                let nawAnimationTime = now.utc;;
                
                let delay_anim_rotate_1 = 0;
                let repeat_anim_rotate_1 = 10000;
                delay_anim_rotate_1 = repeat_anim_rotate_1 - (nawAnimationTime - normal_rotate_animation_lastTime_1);
                if(delay_anim_rotate_1 < 0) delay_anim_rotate_1 = 0; 
                if((nawAnimationTime - normal_rotate_animation_lastTime_1) > repeat_anim_rotate_1) {
                  normal_rotate_animation_count_1 = 0;
                  timer_anim_rotate_1_mirror = false;
                };

                if (!timer_anim_rotate_1) {
                  timer_anim_rotate_1 = timer.createTimer(delay_anim_rotate_1, repeat_anim_rotate_1, (function (option) {
                    anim_rotate_1_complete_call()
                  })); // end timer create
                };

              }),
              pause_call: (function () {
                console.log('pause_call()');
                stop_anim_rotate_1();

              }),
            });

                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}