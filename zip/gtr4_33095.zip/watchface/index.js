﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        const logger = Logger.getLogger('watchface_SashaCX75');
        //end of ignored block

        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_system_disconnect_img = ''
        let normal_heart_rate_text_text_img = ''
        let normal_heart_rate_text_separator_img = ''
        let normal_calorie_current_text_img = ''
        let normal_calorie_current_separator_img = ''
        let normal_distance_text_text_img = ''
        let normal_distance_text_separator_img = ''
        let normal_step_current_text_img = ''
        let normal_step_current_separator_img = ''
        let normal_stand_image_progress_img_level = ''
        let normal_battery_pointer_progress_img_pointer = ''
        let normal_date_img_date_day = ''
        let normal_analog_clock_time_pointer_hour = ''
        let normal_analog_clock_time_pointer_minute = ''
        let normal_analog_clock_time_pointer_second = ''
        let normal_analog_clock_pro_second_pointer_img = ''
        let normal_timerUpdateSecSmooth = undefined;
        let idle_background_bg_img = ''
        let idle_system_disconnect_img = ''
        let idle_heart_rate_text_text_img = ''
        let idle_heart_rate_text_separator_img = ''
        let idle_stand_image_progress_img_level = ''
        let idle_battery_pointer_progress_img_pointer = ''
        let idle_date_img_date_day = ''
        let idle_analog_clock_time_pointer_hour = ''
        let idle_analog_clock_time_pointer_minute = ''
        let idle_analog_clock_time_pointer_second = ''
        let normal_spo2_jumpable_img_click = ''
        let timeSensor = ''
		
		
		
		let btn_zona2 = ''
        let zona2_num = 0
        let zona2_all = 4
		
		function click_zona2() {
		  zona2_num = (zona2_num + 1) % (zona2_all + 1);
          if (zona2_num == 0) {
			normal_step_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
            normal_step_current_separator_img.setProperty(hmUI.prop.VISIBLE, false); 
            normal_distance_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
            normal_distance_text_separator_img.setProperty(hmUI.prop.VISIBLE, false);
            normal_calorie_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
            normal_calorie_current_separator_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_heart_rate_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_heart_rate_text_separator_img.setProperty(hmUI.prop.VISIBLE, false);
		    hmUI.showToast({		
            });
          };
          if (zona2_num == 1) {		  
		  	normal_step_current_text_img.setProperty(hmUI.prop.VISIBLE, true);
            normal_step_current_separator_img.setProperty(hmUI.prop.VISIBLE, true); 
            normal_distance_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
            normal_distance_text_separator_img.setProperty(hmUI.prop.VISIBLE, false);
            normal_calorie_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
            normal_calorie_current_separator_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_heart_rate_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_heart_rate_text_separator_img.setProperty(hmUI.prop.VISIBLE, false);
		    hmUI.showToast({
              text: 'Steps'				
            });
          };
          if (zona2_num == 2) {		  
		  	normal_step_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
            normal_step_current_separator_img.setProperty(hmUI.prop.VISIBLE, false); 
            normal_distance_text_text_img.setProperty(hmUI.prop.VISIBLE, true);
            normal_distance_text_separator_img.setProperty(hmUI.prop.VISIBLE, true);
            normal_calorie_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
            normal_calorie_current_separator_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_heart_rate_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_heart_rate_text_separator_img.setProperty(hmUI.prop.VISIBLE, false);
		    hmUI.showToast({
              text: 'Distance'				
            });
          };
		  if (zona2_num == 3) {		  
		  	normal_step_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
            normal_step_current_separator_img.setProperty(hmUI.prop.VISIBLE, false); 
            normal_distance_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
            normal_distance_text_separator_img.setProperty(hmUI.prop.VISIBLE, false);
            normal_calorie_current_text_img.setProperty(hmUI.prop.VISIBLE, true);
            normal_calorie_current_separator_img.setProperty(hmUI.prop.VISIBLE, true);
			normal_heart_rate_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_heart_rate_text_separator_img.setProperty(hmUI.prop.VISIBLE, false);
		    hmUI.showToast({
			  text: 'Calorie'	
			});
          };
          if (zona2_num == 4) {		  
		  	normal_step_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
            normal_step_current_separator_img.setProperty(hmUI.prop.VISIBLE, false); 
            normal_distance_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
            normal_distance_text_separator_img.setProperty(hmUI.prop.VISIBLE, false);
            normal_calorie_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
            normal_calorie_current_separator_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_heart_rate_text_text_img.setProperty(hmUI.prop.VISIBLE, true);
			normal_heart_rate_text_separator_img.setProperty(hmUI.prop.VISIBLE, true);
		    hmUI.showToast({
			  text: 'Heart Rate'	
            });
          };
		}
		
		let batteryInfo_click = ''
		
		const battery = hmSensor.createSensor(hmSensor.id.BATTERY);
		
		let valueBattery = ''
		
		
		let bot_circle_btn = ''
        let bot_circle_state = 0 // смена цвета стрелок
        let bot_circle_state_txt = ''

        function click_bot_circle_Switcher() {

          let bot_circle_state_total = 2;

          bot_circle_state = (bot_circle_state + 1) % bot_circle_state_total;

          switch (bot_circle_state) {

              case 0:
 
                  normal_analog_clock_time_pointer_hour.setProperty(hmUI.prop.MORE, {
                    hour_path: 'hand_h1.png',
                    hour_centerX: 233,
                    hour_centerY: 233,
                    hour_posX: 19,
                    hour_posY: 138,
                    show_level: hmUI.show_level.ONLY_NORMAL,
                  });
      
                  normal_analog_clock_time_pointer_minute.setProperty(hmUI.prop.MORE, {
                    minute_path: 'hand_m1.png',
                    minute_centerX: 233,
                    minute_centerY: 233,
                    minute_posX: 19,
                    minute_posY: 205,
                    show_level: hmUI.show_level.ONLY_NORMAL,
                  });
      
                  bot_circle_state_txt = 'Hands 1';
                  break;

              case 1:

                normal_analog_clock_time_pointer_hour.setProperty(hmUI.prop.MORE, {
                  hour_path: 'hand_h2.png',
                  hour_centerX: 233,
                  hour_centerY: 233,
                  hour_posX: 19,
                  hour_posY: 138,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });
    
                normal_analog_clock_time_pointer_minute.setProperty(hmUI.prop.MORE, {
                  minute_path: 'hand_m2.png',
                  minute_centerX: 233,
                  minute_centerY: 233,
                  minute_posX: 19,
                  minute_posY: 205,
                 show_level: hmUI.show_level.ONLY_NORMAL,
                });
   
              bot_circle_state_txt = 'Hands 2';
                  break;
    
              default:
                  break;
          }

          hmUI.showToast({ text: bot_circle_state_txt });
      }

	    let bezel_img = ''
        let btn_bezel = ''
        let bezel_num = 1
        let bezel_all = 3
     
        function click_Bezel() {
                   if(bezel_num>=bezel_all) {bezel_num=1;}
                   else { bezel_num=bezel_num+1;}
                   hmUI.showToast({text: "<BackGround> " + parseInt(bezel_num) });
                   normal_background_bg_img.setProperty(hmUI.prop.SRC, "bg_" + parseInt(bezel_num) + ".png");
                   }  

        let delay_Timer = null;
        let clicks = 0;
        let clicksDelay = 400;       // задержка между кликами в мс 
		
		//--------------------- обработка множественных кликов (тапов) 1, 2, 3, ...  ---------------------		
          function checkClicks() {

            switch(clicks) {
              case 1:
                click_Bezel();
             break;
              case 2:
                click_bot_ssmoth_Switcher(); // функции на двойной клик
             break;
              case 3:
                click_bot_circle_Switcher(); // функции на тройной клик
             //break;
             // case 4:
               // функции на 4-ной клик
             //break;
              default:
             break;
           }
            
           timer.stopTimer(delay_Timer);
           clicks = 0;

          }
            
        
      
              function getClick() {		
      
            clicks++;
            if(delay_Timer) timer.stopTimer(delay_Timer);
            delay_Timer = timer.createTimer(clicksDelay, 0, checkClicks, {});
      
              }

      //let sec_smoth_btn = ''
      let sec_smoth_state = 0 // 0 - тип 1, 1 - тип 2
      let sec_smoth_state_txt = ''

      function click_bot_ssmoth_Switcher() {

        let bot_sec_state_total = 2;

        sec_smoth_state = (sec_smoth_state + 1) % bot_sec_state_total;

        switch (sec_smoth_state) {

            case 0:
              normal_analog_clock_time_pointer_second.setProperty(hmUI.prop.VISIBLE, true);
              normal_analog_clock_pro_second_pointer_img.setProperty(hmUI.prop.VISIBLE, false);
      
              sec_smoth_state_txt = 'Normal Seconds';
                break;

            case 1:

              normal_analog_clock_time_pointer_second.setProperty(hmUI.prop.VISIBLE, false);
              normal_analog_clock_pro_second_pointer_img.setProperty(hmUI.prop.VISIBLE, true);

              sec_smoth_state_txt = 'Smooth Seconds';
                break;

            default:
                break;
        }

        hmUI.showToast({ text: sec_smoth_state_txt });
      }
		


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 466,
              h: 466,
              src: 'bg_1.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 198,
              y: 20,
              src: 'bt.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 209,
              y: 350,
              font_array: ["0026.png","0027.png","0028.png","0029.png","0030.png","0031.png","0032.png","0033.png","0034.png","0035.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 177,
              y: 266,
              src: 'heart2.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_calorie_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 201,
              y: 350,
              font_array: ["0026.png","0027.png","0028.png","0029.png","0030.png","0031.png","0032.png","0033.png","0034.png","0035.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_calorie_current_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 177,
              y: 266,
              src: 'cal2.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_distance_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 200,
              y: 350,
              font_array: ["0026.png","0027.png","0028.png","0029.png","0030.png","0031.png","0032.png","0033.png","0034.png","0035.png"],
              padding: false,
              h_space: 0,
              dot_image: '0061.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.DISTANCE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_distance_text_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 177,
              y: 266,
              src: 'distance.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 195,
              y: 350,
              font_array: ["0026.png","0027.png","0028.png","0029.png","0030.png","0031.png","0032.png","0033.png","0034.png","0035.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 177,
              y: 266,
              src: 'step2.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_stand_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 0,
              y: 0,
              image_array: ["0013.png","0014.png","0015.png","0016.png","0017.png","0018.png","0019.png","0020.png","0021.png","0022.png","0023.png","0024.png"],
              image_length: 12,
              type: hmUI.data_type.STAND,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_pointer_progress_img_pointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
              src: 'mask_1.png',
              center_x: 233,
              center_y: 286,
              x: 126,
              y: 126,
              start_angle: 18,
              end_angle: 360,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 379,
              day_startY: 219,
              day_sc_array: ["0003.png","0004.png","0005.png","0006.png","0007.png","0008.png","0009.png","0010.png","0011.png","0012.png"],
              day_tc_array: ["0003.png","0004.png","0005.png","0006.png","0007.png","0008.png","0009.png","0010.png","0011.png","0012.png"],
              day_en_array: ["0003.png","0004.png","0005.png","0006.png","0007.png","0008.png","0009.png","0010.png","0011.png","0012.png"],
              day_zero: 0,
              day_space: 0,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_hour = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              hour_path: 'hand_h2.png',
              hour_centerX: 233,
              hour_centerY: 233,
              hour_posX: 19,
              hour_posY: 138,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_minute = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              minute_path: 'hand_m2.png',
              minute_centerX: 233,
              minute_centerY: 233,
              minute_posX: 19,
              minute_posY: 205,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_second = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              second_path: '0060.png',
              second_centerX: 233,
              second_centerY: 233,
              second_posX: 19,
              second_posY: 222,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            const deviceInfo = hmSetting.getDeviceInfo();
            if (!timeSensor) timeSensor = hmSensor.createSensor(hmSensor.id.TIME);
            // normal_analog_clock_pro_second_pointer_img = hmUI.createWidget(hmUI.widget.TIME_POINTER_PRO, {
              // src: '0060.png',
              // center_x: 233,
              // center_y: 233,
              // x: 19,
              // y: 222,
              // start_angle: 0,
              // end_angle: 360,
              // type: hmUI.data_type.second,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });


            normal_analog_clock_pro_second_pointer_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: deviceInfo.width,
              h: deviceInfo.height,
              pos_x: 233 - 19,
              pos_y: 233 - 222,
              center_x: 233,
              center_y: 233,
              src: '0060.png',
              angle: 0,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            let screenType = hmSetting.getScreenType();
            // normal_analog_clock_pro_smooth_second = hmUI.createWidget(hmUI.widget.SMOOTH_SECOND, {
              // type: 2,
              // fps: 6,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });
			
			bot_circle_btn = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 185,
              y: 185,
              text: '',
              w: 97,
              h: 97,
              normal_src: 'Empty.png',
              press_src: 'Empty.png',
              click_func: () => {
                  getClick();
                  //vibro(9);
              },
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
              bot_circle_btn.setProperty(hmUI.prop.VISIBLE, true);
  
              normal_analog_clock_pro_second_pointer_img.setProperty(hmUI.prop.VISIBLE, false);



            idle_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 466,
              h: 466,
              src: 'bg_1.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 198,
              y: 20,
              src: 'bt.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 209,
              y: 350,
              font_array: ["0026.png","0027.png","0028.png","0029.png","0030.png","0031.png","0032.png","0033.png","0034.png","0035.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_heart_rate_text_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 177,
              y: 266,
              src: 'heart2.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_stand_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 0,
              y: 0,
              image_array: ["0013.png","0014.png","0015.png","0016.png","0017.png","0018.png","0019.png","0020.png","0021.png","0022.png","0023.png","0024.png"],
              image_length: 12,
              type: hmUI.data_type.STAND,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_battery_pointer_progress_img_pointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
              src: 'mask_1.png',
              center_x: 233,
              center_y: 286,
              x: 126,
              y: 126,
              start_angle: 18,
              end_angle: 360,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 379,
              day_startY: 219,
              day_sc_array: ["0003.png","0004.png","0005.png","0006.png","0007.png","0008.png","0009.png","0010.png","0011.png","0012.png"],
              day_tc_array: ["0003.png","0004.png","0005.png","0006.png","0007.png","0008.png","0009.png","0010.png","0011.png","0012.png"],
              day_en_array: ["0003.png","0004.png","0005.png","0006.png","0007.png","0008.png","0009.png","0010.png","0011.png","0012.png"],
              day_zero: 0,
              day_space: 0,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_analog_clock_time_pointer_hour = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              hour_path: 'hand_h2.png',
              hour_centerX: 233,
              hour_centerY: 233,
              hour_posX: 19,
              hour_posY: 138,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_analog_clock_time_pointer_minute = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              minute_path: 'hand_m2.png',
              minute_centerX: 233,
              minute_centerY: 233,
              minute_posX: 19,
              minute_posY: 205,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_analog_clock_time_pointer_second = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              second_path: '0060.png',
              second_centerX: 233,
              second_centerY: 233,
              second_posX: 19,
              second_posY: 222,
              second_cover_path: 'A100_066.png',
              second_cover_x: 0,
              second_cover_y: 0,
              show_level: hmUI.show_level.ONLY_AOD,
            });
			
			function get_values (){
			  valueBattery = battery.current;
			}

			get_values ();
			
			battery.addEventListener(hmSensor.event.CHANGE, function () {
              get_values();
            });
			  
            
            // disconnectAlert = hmUI.createWidget(hmUI.widget.DisconnectAlert, {
              // disconneсnt_vibrate_type: 9,
              // disconneсnt_toast_text: Bluetooth OFF,
              // conneсnt_vibrate_type: 0,
              // conneсnt_toast_text: Bluetooth ON,
            // });

            // vibration when connecting or disconnecting

            function checkConnection() {
              hmBle.removeListener;
              hmBle.addListener(function (status) {
                if(!status) {
                  hmUI.showToast({text: "Bluetooth OFF"});
                  vibro(9);
                }
                if(status) {
                  hmUI.showToast({text: "Bluetooth ON"});
                  vibro(0);
                }
              });
            }

            // end vibration when connecting or disconnecting
            // vibrate function

            const vibrate = hmSensor.createSensor(hmSensor.id.VIBRATE);
            let timer_StopVibrate = null;


            function vibro(scene = 25) {
              let stopDelay = 50;
              stopVibro();
              vibrate.stop();
              vibrate.scene = scene;
              if(scene < 23 || scene > 25) stopDelay = 1300;
              vibrate.start();
              timer_StopVibrate = timer.createTimer(stopDelay, 3000, stopVibro, {});
            }

            function stopVibro(){
              vibrate.stop();
              if(timer_StopVibrate) timer.stopTimer(timer_StopVibrate);
            }

            // end vibrate function
			
			batteryInfo_click = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 209,
              y: 106,
              w: 50,
              h: 50,
              text: '',
              normal_src: 'Empty.png',
              press_src: 'Empty.png',
              click_func: () => {
                hmUI.showToast({ text: 'Battery is ' + valueBattery + '%' });
              },
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            btn_zona2 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 186, //x кнопки
              y: 266, //y кнопки
              text: '',
              w: 105, //ширина кнопки
              h: 115, //высота кнопки
              normal_src: 'Empty.png',
              press_src: 'Empty.png',
              click_func: () => {
                click_zona2();
                click_Vibrate(); //имя вызываемой функции
              },
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            btn_zona2.setProperty(hmUI.prop.VISIBLE, true);
			
			normal_step_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
            normal_step_current_separator_img.setProperty(hmUI.prop.VISIBLE, false); 
            normal_distance_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
            normal_distance_text_separator_img.setProperty(hmUI.prop.VISIBLE, false);
            normal_calorie_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
            normal_calorie_current_separator_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_heart_rate_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_heart_rate_text_separator_img.setProperty(hmUI.prop.VISIBLE, false);
			
			// календарь
			hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 365,
              y: 200,
              w: 75,
              h: 75,
			  text: '',
			  normal_src: 'Empty.png',
			  press_src: 'Empty.png',
			  click_func: () => {
				hmApp.startApp({ url: 'ScheduleCalScreen', native: true });
			  },
			  show_level: hmUI.show_level.ONLY_NORMAL, 
            });
			  
            function time_update(updateHour = false, updateMinute = false) {
              let hour = timeSensor.hour;
              let minute = timeSensor.minute;
              let second = timeSensor.second;

              let normal_fullAngle_second = 360;
              let normal_angle_second = 0 + normal_fullAngle_second*(second + (timeSensor.utc % 1000)/1000)/60;
              if (normal_analog_clock_pro_second_pointer_img) normal_analog_clock_pro_second_pointer_img.setProperty(hmUI.prop.ANGLE, normal_angle_second);

            };

            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                time_update(true, true);
                if (screenType == hmSetting.screen_type.WATCHFACE) {
                  if (!normal_timerUpdateSecSmooth) {
                    let animDelay = 0;
                    let animRepeat = 1000/6;
                    normal_timerUpdateSecSmooth = timer.createTimer(animDelay, animRepeat, (function (option) {
                      time_update(false, false);
                    }));  // end timer 
                  };  // end timer check
                };  // end screenType

                checkConnection();
                stopVibro();

              }),
              pause_call: (function () {
                if (normal_timerUpdateSecSmooth) {
                  timer.stopTimer(normal_timerUpdateSecSmooth);
                  normal_timerUpdateSecSmooth = undefined;
                }
                stopVibro();

              }),
            });

                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}