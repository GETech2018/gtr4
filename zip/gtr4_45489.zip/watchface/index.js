try {
(function () {
  var __$$app$$__ = __$$hmAppManager$$__.currentApp;
  var __$$module$$__ = __$$app$$__.current;
  var logger = Logger.getLogger('watchface_brush_clock');
  var built = false, W = [], ts = null;

  function arr(dir) { var a = []; for (var i = 0; i < 10; i++) { a.push(dir + i + '.png'); } return a; }
  function setSrc(w, s) { try { w.setProperty(hmUI.prop.SRC, s); } catch (e) {} }
  function update() {
    try {
      if (!built || !ts) { return; }
      try { if (hmSetting.getScreenType() === hmSetting.screen_type.AOD) { return; } } catch (e0) {}
      var h = ts.hour, m = ts.minute;
      var d = [Math.floor(h / 10), h % 10, Math.floor(m / 10), m % 10];
      for (var i = 0; i < 4; i++) { setSrc(W[i], 'images/d/' + d[i] + '.png'); }
    } catch (e) {}
  }
  function build() {
    if (built) { return; }
    var N = hmUI.show_level.ONLY_NORMAL, A = hmUI.show_level.ONLY_AOD;
    hmUI.createWidget(hmUI.widget.IMG, { x: 0, y: 0, w: 466, h: 466, src: 'images/bg.png', show_level: N });
    var slots = [
    { x: 115, y: 48 },
    { x: 187, y: 48 },
    { x: 115, y: 204 },
    { x: 187, y: 204 }
    ];
    for (var i = 0; i < 4; i++) {
      W.push(hmUI.createWidget(hmUI.widget.IMG, { x: slots[i].x, y: slots[i].y, w: 181, h: 214, src: 'images/d/0.png', show_level: N }));
    }
    // always-on display: smaller, dimmer digits (system driven)
    hmUI.createWidget(hmUI.widget.IMG_TIME, {
      hour_zero: 1, hour_startX: 149, hour_startY: 100, hour_array: arr('images/a/'), hour_space: 0, hour_align: hmUI.align.LEFT,
      minute_zero: 1, minute_startX: 149, minute_startY: 230, minute_array: arr('images/a/'), minute_space: 0, minute_align: hmUI.align.LEFT,
      show_level: A });
    ts = hmSensor.createSensor(hmSensor.id.TIME);
    built = true;
    try { ts.addEventListener(ts.event.MINUTEEND, update); } catch (e1) {}
    try { ts.addEventListener(ts.event.CHANGE, update); } catch (e2) {}
    try { hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, { resume_call: update, pause_call: function () {} }); } catch (e3) {}
    update();
  }
  __$$module$$__.module = DeviceRuntimeCore.WatchFace({
    init_view: function () { build(); },
    onInit: function () { logger.log('brush clock on init'); },
    build: function () { this.init_view(); logger.log('brush clock on ready'); },
    onDestroy: function () { logger.log('brush clock on destroy'); }
  });
})();
} catch (e) {
  console.log('Mini Program Error', e);
}
