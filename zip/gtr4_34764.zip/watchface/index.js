﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        const logger = Logger.getLogger('watchface_SashaCX75');
        //end of ignored block

        //dynamic modify start

        
        let normal_background_bg_img = ''
		let alarm_clock_img = ''
        let normal_system_disconnect_img = ''
        let normal_system_clock_img = ''
		let normal_compass_angle_img = ''
		let normal_compass_text_img = ''
		let normal_compass_text = ''
		let normal_compass_direction_img = ''
		let compass = null
		// let clockTimer = null
        let normal_calorie_current_text_img = ''
        let normal_step_current_text_img = ''
        let normal_heart_rate_text_text_img = ''
        let normal_date_img_date_month_img = ''
        let normal_date_img_date_day = ''
        let normal_date_img_date_week_img = ''
        let normal_battery_text_text_img = ''
        let normal_battery_image_progress_img_level = ''
        let normal_digital_clock_img_time_AmPm = ''
        let normal_digital_clock_img_time = ''
		
		let btn_bezel = ''
        let bezel_num = 1
        let bezel_all = 2
     
        function click_Bezel() {
            if(bezel_num>=bezel_all) {bezel_num=1;}
            else { bezel_num=bezel_num+1;}
            hmUI.showToast({text: "<Light> " + parseInt(bezel_num) });
            normal_background_bg_img.setProperty(hmUI.prop.SRC, "bg_" + parseInt(bezel_num) + ".png");
        }


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 466,
              h: 466,
              src: 'bg_1.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
			
			alarm_clock_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 165,
              y: 257,
              font_array: ["24.png","25.png","26.png","27.png","28.png","29.png","30.png","31.png","32.png","33.png"],
              padding: true,
              h_space: 0,
              dot_image: 'dot.png',
			  invalid_image: 's_minus.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.ALARM_CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 62,
              y: 275,
              src: 'BT3.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 136,
              y: 257,
              src: 'alarm5.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
			
			normal_compass_angle_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 22,
              y: 50,
              pos_x: 0,
              pos_y: 0,
              center_x: 205 / 2,
              center_y: 205 / 2,
              angle: 0,
              src: 'bgpoint.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
			
			normal_compass_direction_img = hmUI.createWidget(hmUI.widget.IMG, {
                x: 95,
                y: 110,
                src: 'NULL.png',
                show_level: hmUI.show_level.ONLY_NORMAL,
            });
			
			normal_compass_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 75,
              y: 145,
              font_array: ["data-0.png","data-1.png","data-2.png","data-3.png","data-4.png","data-5.png","data-6.png","data-7.png","data-8.png","data-9.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'data-degrees.png',
              unit_tc: 'data-degrees.png',
              unit_en: 'data-degrees.png',
            //   unit_sc: 'data-dash.png',
            //   unit_tc: 'data-dash.png',
            //   unit_en: 'data-dash.png',
              align_h: hmUI.align.CENTER_H,
            //   type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
			
			normal_compass_text = hmUI.createWidget(hmUI.widget.TEXT, {
                x: 157,
                y: 350,
                w: 140,
                h: 50,
                color: 0xe02020,
                text_size: 36,
                align_h: hmUI.align.CENTER_H,
                align_v: hmUI.align.CENTER_V,
                text_style: hmUI.text_style.NONE,
                text: '',
                show_level: hmUI.show_level.ONLY_NORMAL,
              })

            normal_calorie_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 334,
              y: 147,
              font_array: ["f_0.png","f_1.png","f_2.png","f_3.png","f_4.png","f_5.png","f_6.png","f_7.png","f_8.png","f_9.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 300,
              y: 108,
              font_array: ["f_0.png","f_1.png","f_2.png","f_3.png","f_4.png","f_5.png","f_6.png","f_7.png","f_8.png","f_9.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 283,
              y: 74,
              font_array: ["f_0.png","f_1.png","f_2.png","f_3.png","f_4.png","f_5.png","f_6.png","f_7.png","f_8.png","f_9.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_month_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 310,
              month_startY: 251,
              month_sc_array: ["34.png","35.png","36.png","37.png","38.png","39.png","40.png","41.png","42.png","43.png","44.png","45.png"],
              month_tc_array: ["34.png","35.png","36.png","37.png","38.png","39.png","40.png","41.png","42.png","43.png","44.png","45.png"],
              month_en_array: ["34.png","35.png","36.png","37.png","38.png","39.png","40.png","41.png","42.png","43.png","44.png","45.png"],
              month_is_character: true ,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 270,
              day_startY: 257,
              day_sc_array: ["24.png","25.png","26.png","27.png","28.png","29.png","30.png","31.png","32.png","33.png"],
              day_tc_array: ["24.png","25.png","26.png","27.png","28.png","29.png","30.png","31.png","32.png","33.png"],
              day_en_array: ["24.png","25.png","26.png","27.png","28.png","29.png","30.png","31.png","32.png","33.png"],
              day_zero: 1,
              day_space: 0,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 230,
              y: 180,
              week_en: ["17.png","18.png","19.png","20.png","21.png","22.png","23.png"],
              week_tc: ["17.png","18.png","19.png","20.png","21.png","22.png","23.png"],
              week_sc: ["17.png","18.png","19.png","20.png","21.png","22.png","23.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 143,
              y: 360,
              font_array: ["f_0.png","f_1.png","f_2.png","f_3.png","f_4.png","f_5.png","f_6.png","f_7.png","f_8.png","f_9.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 210,
              y: 349,
              image_array: ["51.png","52.png","53.png","54.png","55.png","56.png","57.png","58.png","59.png","60.png"],
              image_length: 10,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time_AmPm = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              am_x: 115,
              am_y: 315,
              am_sc_path: '46.png',
              am_en_path: '46.png',
              pm_x: 115,
              pm_y: 315,
              pm_sc_path: '47.png',
              pm_en_path: '47.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 165,
              hour_startY: 283,
              hour_array: ["61.png","62.png","63.png","64.png","65.png","66.png","67.png","68.png","69.png","70.png"],
              hour_zero: 1,
              hour_space: 0,
              hour_angle: 0,
              hour_align: hmUI.align.RIGHT,

              minute_startX: 272,
              minute_startY: 283,
              minute_array: ["61.png","62.png","63.png","64.png","65.png","66.png","67.png","68.png","69.png","70.png"],
              minute_zero: 1,
              minute_space: 0,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              second_startX: 365,
              second_startY: 309,
              second_array: ["71.png","72.png","73.png","74.png","75.png","76.png","77.png","78.png","79.png","80.png"],
              second_zero: 1,
              second_space: 0,
              second_angle: 0,
              second_follow: 0,
              second_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });
			
			btn_bezel = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 50,
              y: 345,
              text: '',
              w: 97,
              h: 97,
              normal_src: 'null.png',
              press_src: 'null.png',
              click_func: () => {
                  click_Bezel();
                  vibro();
              },
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            btn_bezel.setProperty(hmUI.prop.VISIBLE, true);
			
			const screen_type = hmSetting.getScreenType()
            if(screen_type == hmSetting.screen_type.WATCHFACE){
                compass = hmSensor.createSensor(hmSensor.id.COMPASS)
                compass.start()

                if (compass.direction_angle && compass.direction  && compass.direction_angle != 'INVALID') { // устанавливаем первоночальные надписи
                    let compass_direction_angle = `${compass.direction_angle}`;
                    let compass_direction_angle_direction = `${compass.direction_angle}° ${compass.direction}`;
                    normal_compass_text_img.setProperty(hmUI.prop.TEXT, compass_direction_angle);
                    // normal_compass_text.setProperty(hmUI.prop.TEXT, compass_direction_angle_direction);
                    // compass_text.setProperty(hmUI.prop.TEXT,`${compass.direction_angle}°${compass.direction}`)
                    normal_compass_angle_img.setProperty(hmUI.prop.ANGLE, -compass.direction_angle);
                    normal_compass_direction_img.setProperty(hmUI.prop.SRC, `direction-${compass.direction}.png`);
                } else {
                    normal_compass_text_img.setProperty(hmUI.prop.TEXT,`- -`);
                    // normal_compass_text.setProperty(hmUI.prop.TEXT,`- -`);
                    normal_compass_angle_img.setProperty(hmUI.prop.ANGLE, 0);
                    normal_compass_direction_img.setProperty(hmUI.prop.SRC, "direction-NULL.png");
                }


                compass.addEventListener(hmSensor.event.CHANGE, function (compass_res) { // меняем надписи при изменении направления
                    if (compass_res.calibration_status) {
                        let compass_direction_angle = `${compass_res.direction_angle}`;
                        let compass_direction_angle_direction = `${compass_res.direction_angle}° ${compass_res.direction}`;
                        normal_compass_text_img.setProperty(hmUI.prop.TEXT, compass_direction_angle);
                        // normal_compass_text.setProperty(hmUI.prop.TEXT, compass_direction_angle_direction);
                        normal_compass_angle_img.setProperty(hmUI.prop.ANGLE, -compass_res.direction_angle);
                        normal_compass_direction_img.setProperty(hmUI.prop.SRC, `direction-${compass_res.direction}.png`);
                    } else {
                        normal_compass_text_img.setProperty(hmUI.prop.TEXT,`- -`);
                        // normal_compass_text.setProperty(hmUI.prop.TEXT,`- -`);
                        normal_compass_angle_img.setProperty(hmUI.prop.ANGLE, 0);
                        normal_compass_direction_img.setProperty(hmUI.prop.SRC, "direction-NULL.png");
                    }

                })
            }

            // hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
            //     resume_call: function () {
            //       console.log('ui resume');
      
            //         if (compass) {
            //             const screenType = hmSetting.getScreenType()
            //             if(screenType == hmSetting.screen_type.WATCHFACE){
            //                 clockTimer = timer.createTimer(500, 0, (function (option) {
            //                     compass.start()
            //                     timer.stopTimer(clockTimer)
            //                     clockTimer = null
            //                     }
            //                 ))
            //             }
      
            //         }
            //     },
            //     pause_call: function () {
            //         console.log('ui pause');
            //         if(clockTimer) {
            //             timer.stopTimer(clockTimer)
            //             clockTimer = null
            //         }
            //         compass.stop()
            //     },
            // })




                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}