﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.0.1
    ** Copyright © CashaCX75. All Rights Reserved
    */

    try {
    (()=>{
        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_battery_pointer_progress_img_pointer = ''
        let normal_rotate_animation_img_1 = '';
        let normal_rotate_animation_param_1 = null;
        let normal_rotate_animation_lastTime_1 = 0;
        let timer_anim_rotate_1;
        let normal_rotate_animation_count_1 = 0;
        let normal_rotate_animation_img_2 = '';
        let normal_rotate_animation_param_2 = null;
        let normal_rotate_animation_lastTime_2 = 0;
        let timer_anim_rotate_2;
        let normal_rotate_animation_count_2 = 0;
        let normal_rotate_animation_img_3 = '';
        let normal_rotate_animation_param_3 = null;
        let normal_rotate_animation_lastTime_3 = 0;
        let timer_anim_rotate_3;
        let normal_rotate_animation_count_3 = 0;
        let normal_frame_animation_1 = ''
        let normal_frame_animation_2 = ''
        let normal_temperature_icon_img = ''
        let normal_analog_clock_time_pointer_hour = ''
        let normal_analog_clock_time_pointer_minute = ''
        let idle_analog_clock_time_pointer_hour = ''
        let idle_analog_clock_time_pointer_minute = ''


        //dynamic modify end
        const e = __$$hmAppManager$$__.currentApp;
        const o = e.current
          , {px: i} = (new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(e,o)),
        e.__globals__)
          , n = Logger.getLogger("watchface6");
        o.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 466,
              h: 466,
              src: 'FON1.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_pointer_progress_img_pointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
              src: 'POWER.png',
              center_x: 74,
              center_y: 255,
              x: 45,
              y: 44,
              start_angle: 178,
              end_angle: 357,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_rotate_animation_img_1 = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 467,
              h: 467,
              pos_x: 270,
              pos_y: 219,
              center_x: 354,
              center_y: 303,
              angle: 0,
              src: 'animation/anim_100.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_rotate_animation_param_1 = {
              anim_rate: 'linear',
              anim_duration: 20000,
              anim_from: 0,
              anim_to: 360,
              anim_fps: 15,
              anim_key: "angle",
            };

            let now = hmSensor.createSensor(hmSensor.id.TIME);

            function anim_rotate_1_complete_call() {
              normal_rotate_animation_count_1 = normal_rotate_animation_count_1 - 1;
              if(normal_rotate_animation_count_1 < -1) normal_rotate_animation_count_1 = - 1;
                normal_rotate_animation_img_1.setProperty(hmUI.prop.ANIM, normal_rotate_animation_param_1);
                normal_rotate_animation_lastTime_1 = now.utc;
              if(normal_rotate_animation_count_1 == 0) stop_anim_rotate_1();
            }; // end animation callback function
            
            function stop_anim_rotate_1() {
              if (timer_anim_rotate_1) {
                timer.stopTimer(timer_anim_rotate_1);
                timer_anim_rotate_1 = undefined;
              };
            }; // end stop_anim_rotate function

            // normal_rotate_anime_1 = hmUI.createWidget(hmUI.widget.Rotate_Animation, {
              // start_angle: 0,
              // end_angle: 360,
              // pos_x: 84,
              // pos_y: 84,
              // center_x: 354,
              // center_y: 303,
              // src: 'anim_100.png',
              // anim_fps: 15,
              // anim_duration: 20000,
              // repeat_count: 0,
              // anim_two_sides: False,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_rotate_animation_img_2 = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 467,
              h: 467,
              pos_x: 24,
              pos_y: 219,
              center_x: 108,
              center_y: 303,
              angle: 0,
              src: 'animation/anim_100.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_rotate_animation_param_2 = {
              anim_rate: 'linear',
              anim_duration: 20000,
              anim_from: 0,
              anim_to: 360,
              anim_fps: 15,
              anim_key: "angle",
            };

            function anim_rotate_2_complete_call() {
              normal_rotate_animation_count_2 = normal_rotate_animation_count_2 - 1;
              if(normal_rotate_animation_count_2 < -1) normal_rotate_animation_count_2 = - 1;
                normal_rotate_animation_img_2.setProperty(hmUI.prop.ANIM, normal_rotate_animation_param_2);
                normal_rotate_animation_lastTime_2 = now.utc;
              if(normal_rotate_animation_count_2 == 0) stop_anim_rotate_2();
            }; // end animation callback function
            
            function stop_anim_rotate_2() {
              if (timer_anim_rotate_2) {
                timer.stopTimer(timer_anim_rotate_2);
                timer_anim_rotate_2 = undefined;
              };
            }; // end stop_anim_rotate function

            // normal_rotate_anime_2 = hmUI.createWidget(hmUI.widget.Rotate_Animation, {
              // start_angle: 0,
              // end_angle: 360,
              // pos_x: 84,
              // pos_y: 84,
              // center_x: 108,
              // center_y: 303,
              // src: 'anim_100.png',
              // anim_fps: 15,
              // anim_duration: 20000,
              // repeat_count: 0,
              // anim_two_sides: False,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_rotate_animation_img_3 = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 467,
              h: 467,
              pos_x: 174,
              pos_y: 128,
              center_x: 233,
              center_y: 185,
              angle: 0,
              src: 'animation/anim_101.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_rotate_animation_param_3 = {
              anim_rate: 'linear',
              anim_duration: 40000,
              anim_from: 0,
              anim_to: 360,
              anim_fps: 15,
              anim_key: "angle",
            };

            function anim_rotate_3_complete_call() {
              normal_rotate_animation_count_3 = normal_rotate_animation_count_3 - 1;
              if(normal_rotate_animation_count_3 < -1) normal_rotate_animation_count_3 = - 1;
                normal_rotate_animation_img_3.setProperty(hmUI.prop.ANIM, normal_rotate_animation_param_3);
                normal_rotate_animation_lastTime_3 = now.utc;
              if(normal_rotate_animation_count_3 == 0) stop_anim_rotate_3();
            }; // end animation callback function
            
            function stop_anim_rotate_3() {
              if (timer_anim_rotate_3) {
                timer.stopTimer(timer_anim_rotate_3);
                timer_anim_rotate_3 = undefined;
              };
            }; // end stop_anim_rotate function

            // normal_rotate_anime_3 = hmUI.createWidget(hmUI.widget.Rotate_Animation, {
              // start_angle: 0,
              // end_angle: 360,
              // pos_x: 59,
              // pos_y: 57,
              // center_x: 233,
              // center_y: 185,
              // src: 'anim_101.png',
              // anim_fps: 15,
              // anim_duration: 40000,
              // repeat_count: 0,
              // anim_two_sides: False,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_frame_animation_1 = hmUI.createWidget(hmUI.widget.IMG_ANIM, {
              x: 117,
              y: 222,
              anim_path: "animation",
              anim_ext: "png",
              anim_prefix: "anim",
              anim_fps: 15,
              anim_size: 11,
              repeat_count: 0,
              anim_repeat: true,
              anim_status:hmUI.anim_status.START,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_frame_animation_2 = hmUI.createWidget(hmUI.widget.IMG_ANIM, {
              x: 172,
              y: 30,
              anim_path: "animation",
              anim_ext: "png",
              anim_prefix: "first_anim_isikv",
              anim_fps: 15,
              anim_size: 50,
              repeat_count: 0,
              anim_repeat: true,
              anim_status:hmUI.anim_status.START,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'fON2.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_hour = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              hour_path: 'HOUR.png',
              hour_centerX: 232,
              hour_centerY: 159,
              hour_posX: 38,
              hour_posY: 182,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_minute = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              minute_path: 'MINUT.png',
              minute_centerX: 233,
              minute_centerY: 158,
              minute_posX: 38,
              minute_posY: 180,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });



            idle_analog_clock_time_pointer_hour = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              hour_path: 'HOUR.png',
              hour_centerX: 232,
              hour_centerY: 159,
              hour_posX: 38,
              hour_posY: 182,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_analog_clock_time_pointer_minute = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              minute_path: 'MINUT.png',
              minute_centerX: 233,
              minute_centerY: 158,
              minute_posX: 38,
              minute_posY: 180,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {

                let nawAnimationTime = now.utc;;
                
                let delay_anim_rotate_1 = 0;
                let repeat_anim_rotate_1 = 20000;
                delay_anim_rotate_1 = repeat_anim_rotate_1 - (nawAnimationTime - normal_rotate_animation_lastTime_1);
                if(delay_anim_rotate_1 < 0) delay_anim_rotate_1 = 0; 
                if((nawAnimationTime - normal_rotate_animation_lastTime_1) > repeat_anim_rotate_1) {
                  normal_rotate_animation_count_1 = 0;
                  timer_anim_rotate_1_mirror = false;
                };

                if (!timer_anim_rotate_1) {
                  timer_anim_rotate_1 = timer.createTimer(delay_anim_rotate_1, repeat_anim_rotate_1, (function (option) {
                    anim_rotate_1_complete_call()
                  })); // end timer create
                };
                
                let delay_anim_rotate_2 = 0;
                let repeat_anim_rotate_2 = 20000;
                delay_anim_rotate_2 = repeat_anim_rotate_2 - (nawAnimationTime - normal_rotate_animation_lastTime_2);
                if(delay_anim_rotate_2 < 0) delay_anim_rotate_2 = 0; 
                if((nawAnimationTime - normal_rotate_animation_lastTime_2) > repeat_anim_rotate_2) {
                  normal_rotate_animation_count_2 = 0;
                  timer_anim_rotate_2_mirror = false;
                };

                if (!timer_anim_rotate_2) {
                  timer_anim_rotate_2 = timer.createTimer(delay_anim_rotate_2, repeat_anim_rotate_2, (function (option) {
                    anim_rotate_2_complete_call()
                  })); // end timer create
                };
                
                let delay_anim_rotate_3 = 0;
                let repeat_anim_rotate_3 = 40000;
                delay_anim_rotate_3 = repeat_anim_rotate_3 - (nawAnimationTime - normal_rotate_animation_lastTime_3);
                if(delay_anim_rotate_3 < 0) delay_anim_rotate_3 = 0; 
                if((nawAnimationTime - normal_rotate_animation_lastTime_3) > repeat_anim_rotate_3) {
                  normal_rotate_animation_count_3 = 0;
                  timer_anim_rotate_3_mirror = false;
                };

                if (!timer_anim_rotate_3) {
                  timer_anim_rotate_3 = timer.createTimer(delay_anim_rotate_3, repeat_anim_rotate_3, (function (option) {
                    anim_rotate_3_complete_call()
                  })); // end timer create
                };
                normal_frame_animation_1.setProperty(hmUI.prop.ANIM_STATUS,hmUI.anim_status.START);
                normal_frame_animation_2.setProperty(hmUI.prop.ANIM_STATUS,hmUI.anim_status.START);

              }),
              pause_call: (function () {
                stop_anim_rotate_1();
                stop_anim_rotate_2();
                stop_anim_rotate_3();
                normal_frame_animation_1.setProperty(hmUI.prop.ANIM_STATUS,hmUI.anim_status.STOP);
                normal_frame_animation_2.setProperty(hmUI.prop.ANIM_STATUS,hmUI.anim_status.STOP);

              }),
            });

                //dynamic modify end
            },
            onInit() {
                n.log("index page.js on init invoke")
            },
            build() {
                this.init_view(),
                n.log("index page.js on ready invoke")
            },
            onDestroy() {
                n.log("index page.js on destroy invoke")
            }
        })
    }
    )()
} catch (e) {
    console.log("Mini Program Error", e),
    e && e.stack && e.stack.split(/\n/).forEach((e=>console.log("error stack", e)))
}
