﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        const logger = Logger.getLogger('watchface_SashaCX75');
        //end of ignored block

        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_system_lock_img = ''
        let normal_system_dnd_img = ''
        let normal_system_disconnect_img = ''
        let normal_system_clock_img = ''
        let normal_sun_high_text_img = ''
        let normal_sun_high_separator_img = ''
        let normal_sun_low_text_img = ''
        let normal_sun_low_separator_img = ''
        let normal_moon_image_progress_img_level = ''
        let normal_temperature_current_text_img = ''
        let normal_weather_image_progress_img_level = ''
        let normal_date_img_date_month = ''
        let normal_date_img_date_day = ''
        let normal_battery_text_text_img = ''
        let normal_calorie_current_text_img = ''
        let normal_heart_rate_text_text_img = ''
        let normal_distance_text_text_img = ''
        let normal_step_current_text_img = ''
        let normal_digital_clock_img_time = ''
        let normal_digital_clock_hour_separator_img = ''
        let idle_background_bg = ''
        let idle_system_lock_img = ''
        let idle_system_dnd_img = ''
        let idle_system_disconnect_img = ''
        let idle_system_clock_img = ''
        let idle_sun_high_text_img = ''
        let idle_sun_high_separator_img = ''
        let idle_sun_low_text_img = ''
        let idle_sun_low_separator_img = ''
        let idle_temperature_current_text_img = ''
        let idle_weather_image_progress_img_level = ''
        let idle_date_img_date_month = ''
        let idle_date_img_date_day = ''
        let idle_digital_clock_img_time = ''
        let idle_digital_clock_hour_separator_img = ''
        let normal_sunrise_jumpable_img_click = ''
        let normal_temperature_jumpable_img_click = ''
        let normal_pai_jumpable_img_click = ''
        let normal_spo2_jumpable_img_click = ''
        let normal_heart_jumpable_img_click = ''
        let normal_step_jumpable_img_click = ''
		
		let btn_zona1 = ''
        let zona1_num = 0
        let zona1_all = 1
		
		function click_zona1() {
		  zona1_num = (zona1_num + 1) % (zona1_all + 1);
          if (zona1_num == 0) {		
		    normal_weather_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, true);
            normal_moon_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, false);
		    hmUI.showToast({
				text: 'Weather'
            });
          };
		  
		 if (zona1_num == 1) {
			normal_weather_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, false);
            normal_moon_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, true);
		    hmUI.showToast({
				text: 'Moon Phase'
            });
          };
        }


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 466,
              h: 466,
              src: '34.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_lock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 219,
              y: 79,
              src: 'lock_(2).png',
              type: hmUI.system_status.LOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_dnd_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 218,
              y: 326,
              src: 'dnd_(2).png',
              type: hmUI.system_status.DISTURB,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 82,
              y: 392,
              src: 'bluetooth_(10).png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 359,
              y: 392,
              src: 'free-icon-notification-bell-3541850.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sun_high_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 146,
              y: 307,
              font_array: ["f_0.png","f_1.png","f_2.png","f_3.png","f_4.png","f_5.png","f_6.png","f_7.png","f_8.png","f_9.png"],
              padding: false,
              h_space: 0,
              angle: 0,
              dot_image: 'dot.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.SUN_RISE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sun_high_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 149,
              y: 265,
              src: 'sunr.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sun_low_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 265,
              y: 307,
              font_array: ["f_0.png","f_1.png","f_2.png","f_3.png","f_4.png","f_5.png","f_6.png","f_7.png","f_8.png","f_9.png"],
              padding: false,
              h_space: 0,
              angle: 0,
              dot_image: 'dot.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.SUN_SET,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sun_low_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 269,
              y: 265,
              src: 'suns.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_moon_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 162,
              y: 134,
              image_array: ["moon_01.png","moon_02.png","moon_03.png","moon_04.png","moon_05.png","moon_06.png","moon_07.png","moon_08.png","moon_09.png","moon_10.png","moon_11.png","moon_12.png","moon_13.png","moon_14.png","moon_15.png","moon_16.png","moon_17.png","moon_18.png","moon_19.png","moon_20.png","moon_21.png","moon_22.png","moon_23.png","moon_24.png","moon_25.png","moon_26.png","moon_27.png","moon_28.png","moon_29.png","moon_30.png"],
              image_length: 30,
              type: hmUI.data_type.MOON,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 211,
              y: 116,
              font_array: ["45.png","46.png","47.png","48.png","49.png","50.png","51.png","52.png","53.png","54.png"],
              padding: false,
              h_space: -2,
              angle: 0,
              negative_image: 'minus.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 145,
              y: 135,
              image_array: ["w_1.png","w_2.png","w_3.png","w_4.png","w_5.png","w_6.png","w_7.png","w_8.png","w_9.png","w_10.png","w_11.png","w_12.png","w_13.png","w_14.png","w_15.png","w_16.png","w_17.png","w_18.png","w_19.png","w_20.png","w_21.png","w_22.png","w_23.png","w_24.png","w_25.png","w_26.png","w_27.png","w_28.png","w_29.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_month = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 314,
              month_startY: 55,
              month_sc_array: ["45.png","46.png","47.png","48.png","49.png","50.png","51.png","52.png","53.png","54.png"],
              month_tc_array: ["45.png","46.png","47.png","48.png","49.png","50.png","51.png","52.png","53.png","54.png"],
              month_en_array: ["45.png","46.png","47.png","48.png","49.png","50.png","51.png","52.png","53.png","54.png"],
              month_zero: 1,
              month_space: -2,
              month_align: hmUI.align.CENTER_H,
              month_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 268,
              day_startY: 55,
              day_sc_array: ["45.png","46.png","47.png","48.png","49.png","50.png","51.png","52.png","53.png","54.png"],
              day_tc_array: ["45.png","46.png","47.png","48.png","49.png","50.png","51.png","52.png","53.png","54.png"],
              day_en_array: ["45.png","46.png","47.png","48.png","49.png","50.png","51.png","52.png","53.png","54.png"],
              day_zero: 1,
              day_space: -2,
              day_unit_sc: 'dot_1.png',
              day_unit_tc: 'dot_1.png',
              day_unit_en: 'dot_1.png',
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 123,
              y: 55,
              font_array: ["45.png","46.png","47.png","48.png","49.png","50.png","51.png","52.png","53.png","54.png"],
              padding: false,
              h_space: -2,
              angle: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_calorie_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 397,
              y: 270,
              font_array: ["45.png","46.png","47.png","48.png","49.png","50.png","51.png","52.png","53.png","54.png"],
              padding: false,
              h_space: -2,
              angle: 0,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 27,
              y: 270,
              font_array: ["45.png","46.png","47.png","48.png","49.png","50.png","51.png","52.png","53.png","54.png"],
              padding: false,
              h_space: -2,
              angle: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_distance_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 14,
              y: 185,
              font_array: ["45.png","46.png","47.png","48.png","49.png","50.png","51.png","52.png","53.png","54.png"],
              padding: false,
              h_space: -3,
              angle: 0,
              dot_image: '55.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.DISTANCE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 385,
              y: 185,
              font_array: ["45.png","46.png","47.png","48.png","49.png","50.png","51.png","52.png","53.png","54.png"],
              padding: false,
              h_space: -4,
              angle: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 133,
              hour_startY: 345,
              hour_array: ["2.png","3.png","4.png","5.png","6.png","7.png","8.png","9.png","10.png","11.png"],
              hour_zero: 1,
              hour_space: 0,
              hour_angle: 0,
              hour_align: hmUI.align.LEFT,

              minute_startX: 244,
              minute_startY: 345,
              minute_array: ["2.png","3.png","4.png","5.png","6.png","7.png","8.png","9.png","10.png","11.png"],
              minute_zero: 1,
              minute_space: 0,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              second_startX: 211,
              second_startY: 414,
              second_array: ["12.png","13.png","14.png","15.png","16.png","17.png","18.png","19.png","20.png","21.png"],
              second_zero: 1,
              second_space: 0,
              second_angle: 0,
              second_follow: 0,
              second_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_hour_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 223,
              y: 341,
              src: '22.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            idle_background_bg = hmUI.createWidget(hmUI.widget.FILL_RECT, {
              x: 0,
              y: 0,
              w: 466,
              h: 466,
              color: '0xFF000000',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_system_lock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 219,
              y: 79,
              src: 'lock_(2).png',
              type: hmUI.system_status.LOCK,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_system_dnd_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 218,
              y: 326,
              src: 'dnd_(2).png',
              type: hmUI.system_status.DISTURB,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 82,
              y: 392,
              src: 'bluetooth_(10).png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 359,
              y: 392,
              src: 'free-icon-notification-bell-3541850.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_sun_high_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 146,
              y: 307,
              font_array: ["f_0.png","f_1.png","f_2.png","f_3.png","f_4.png","f_5.png","f_6.png","f_7.png","f_8.png","f_9.png"],
              padding: false,
              h_space: 0,
              angle: 0,
              dot_image: 'dot.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.SUN_RISE,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_sun_high_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 149,
              y: 265,
              src: 'sunr.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_sun_low_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 265,
              y: 307,
              font_array: ["f_0.png","f_1.png","f_2.png","f_3.png","f_4.png","f_5.png","f_6.png","f_7.png","f_8.png","f_9.png"],
              padding: false,
              h_space: 0,
              angle: 0,
              dot_image: 'dot.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.SUN_SET,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_sun_low_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 269,
              y: 265,
              src: 'suns.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 211,
              y: 116,
              font_array: ["45.png","46.png","47.png","48.png","49.png","50.png","51.png","52.png","53.png","54.png"],
              padding: false,
              h_space: -2,
              angle: 0,
              negative_image: 'minus.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 145,
              y: 135,
              image_array: ["w_1.png","w_2.png","w_3.png","w_4.png","w_5.png","w_6.png","w_7.png","w_8.png","w_9.png","w_10.png","w_11.png","w_12.png","w_13.png","w_14.png","w_15.png","w_16.png","w_17.png","w_18.png","w_19.png","w_20.png","w_21.png","w_22.png","w_23.png","w_24.png","w_25.png","w_26.png","w_27.png","w_28.png","w_29.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_month = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 246,
              month_startY: 20,
              month_sc_array: ["45.png","46.png","47.png","48.png","49.png","50.png","51.png","52.png","53.png","54.png"],
              month_tc_array: ["45.png","46.png","47.png","48.png","49.png","50.png","51.png","52.png","53.png","54.png"],
              month_en_array: ["45.png","46.png","47.png","48.png","49.png","50.png","51.png","52.png","53.png","54.png"],
              month_zero: 1,
              month_space: -2,
              month_align: hmUI.align.CENTER_H,
              month_is_character: false,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 200,
              day_startY: 20,
              day_sc_array: ["45.png","46.png","47.png","48.png","49.png","50.png","51.png","52.png","53.png","54.png"],
              day_tc_array: ["45.png","46.png","47.png","48.png","49.png","50.png","51.png","52.png","53.png","54.png"],
              day_en_array: ["45.png","46.png","47.png","48.png","49.png","50.png","51.png","52.png","53.png","54.png"],
              day_zero: 1,
              day_space: -2,
              day_unit_sc: 'dot_1.png',
              day_unit_tc: 'dot_1.png',
              day_unit_en: 'dot_1.png',
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 133,
              hour_startY: 345,
              hour_array: ["2.png","3.png","4.png","5.png","6.png","7.png","8.png","9.png","10.png","11.png"],
              hour_zero: 1,
              hour_space: 0,
              hour_angle: 0,
              hour_align: hmUI.align.LEFT,

              minute_startX: 244,
              minute_startY: 345,
              minute_array: ["2.png","3.png","4.png","5.png","6.png","7.png","8.png","9.png","10.png","11.png"],
              minute_zero: 1,
              minute_space: 0,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              second_startX: 211,
              second_startY: 414,
              second_array: ["12.png","13.png","14.png","15.png","16.png","17.png","18.png","19.png","20.png","21.png"],
              second_zero: 1,
              second_space: 0,
              second_angle: 0,
              second_follow: 0,
              second_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_hour_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 223,
              y: 341,
              src: '22.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            normal_sunrise_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 159,
              y: 287,
              w: 155,
              h: 40,
              src: 'Empty.png',
              type: hmUI.data_type.SUN_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            btn_zona1 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 190, 
              y: 158, 
              text: '',
              w: 100, 
              h: 100, 
              normal_src: 'Empty.png',
              press_src: 'Empty.png',
              click_func: () => {
				click_zona1();
                click_Vibrate();
              },
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            btn_zona1.setProperty(hmUI.prop.VISIBLE, true);
			normal_moon_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, false);

            normal_pai_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 370,
              y: 268,
              w: 80,
              h: 80,
              src: 'Empty.png',
              type: hmUI.data_type.PAI_WEEKLY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            hmUI.createWidget(hmUI.widget.BUTTON, {
				 x: 269,       
				 y: 22,      
				 w: 80,       
				 h: 80,      
				 text: '',    
				 normal_src: 'Empty.png',      
				 press_src: 'Empty.png', 
				 click_func: () => {	 
				hmApp.startApp({ url: 'ScheduleCalScreen', native: true });
				 },
				 show_level: hmUI.show_level.ONLY_NORMAL,
			});

            normal_heart_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 19,
              y: 265,
              w: 80,
              h: 80,
              src: 'Empty.png',
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 370,
              y: 128,
              w: 80,
              h: 80,
              src: 'Empty.png',
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}