﻿/*
 ** Watch_Face_Editor tool
 ** watchface js version v2.1.1
 ** Copyright © SashaCX75. All Rights Reserved
 */

try {
  (() => {
    //start of ignored block
    const __$$app$$__ = __$$hmAppManager$$__.currentApp;
    function getApp() {
      return __$$app$$__.app;
    }
    function getCurrentPage() {
      return __$$app$$__.current && __$$app$$__.current.module;
    }
    const __$$module$$__ = __$$app$$__.current;
    const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
    const { px } = __$$app$$__.__globals__;
    const logger = Logger.getLogger("watchface_SashaCX75");
    //end of ignored block

    //dynamic modify start

    class ImgWidget {
      constructor(data) {
        this._widget = hmUI.createWidget(hmUI.widget.IMG, data);

        this._angle = data.angle;
        this._visible = true;
      }

      get angle() {
        return this._angle;
      }
      set angle(value) {
        if (this._widget) {
          this._angle = value;
          this._widget.setProperty(hmUI.prop.ANGLE, this._angle);
        }
      }

      get visible() {
        return this._visible;
      }
      set visible(value) {
        if (this._widget) {
          this._visible = value;
          this._widget.setProperty(hmUI.prop.VISIBLE, this._visible);
        }
      }
    }

    let normal_date_img = "";
    let normal_background_bg_img = "";
    let normal_world_clock_pointer_img = "";
    let normal_analog_clock_pro_hour_pointer_img = "";
    let normal_analog_clock_pro_minute_pointer_img = "";
    let normal_analog_clock_pro_second_pointer_img = "";
    let normal_analog_clock_pro_second_cover_pointer_img = "";

    let idle_background_bg_img = "";
    let idle_world_clock_pointer_img = "";
    let idle_analog_clock_time_pointer_hour = "";
    let idle_analog_clock_time_pointer_minute = "";

    let timeSensor = "";

    let wt_angle_delta = 360 / 24 / 60;
    let wt_target_angle = 0;
    let wt_index = 0;
    let worldData = undefined;

    let timer_main = undefined;
    let pushback_timer = undefined;
    let timer_animate_wt = undefined;

    //dynamic modify end

    __$$module$$__.module = DeviceRuntimeCore.WatchFace({
      init_view() {
        //dynamic modify start

        const world_clock = hmSensor.createSensor(hmSensor.id.WORLD_CLOCK);
        world_clock.init();

        if (hmFS.SysProGetInt("LUMINOX_WT_INDEX")) wt_index = hmFS.SysProGetInt("LUMINOX_WT_INDEX");

        const timeNaw = hmSensor.createSensor(hmSensor.id.TIME);
        const screenType = hmSetting.getScreenType();
        const deviceInfo = hmSetting.getDeviceInfo();
        if (!timeSensor) timeSensor = hmSensor.createSensor(hmSensor.id.TIME);
        timeSensor.addEventListener(timeSensor.event.MINUTEEND, function () {
          update_time(true, true);
        });

        normal_date_img = new ImgWidget({
          x: 0,
          y: 0,
          w: deviceInfo.width,
          h: deviceInfo.height,
          pos_x: 0,
          pos_y: 0,
          center_x: 233,
          center_y: 233,
          src: "date.png",
          angle: 0,
          show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_AOD,
        });

        normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
          x: 0,
          y: 0,
          w: 466,
          h: 466,
          src: "normal_bg.png",
          show_level: hmUI.show_level.ONLY_NORMAL,
        });

        normal_world_clock_pointer_img = new ImgWidget({
          x: 0,
          y: 0,
          w: deviceInfo.width,
          h: deviceInfo.height,
          pos_x: 233 - 41,
          pos_y: 233 - 232,
          center_x: 233,
          center_y: 233,
          src: "arrow_wt.png",
          angle: 0,
          show_level: hmUI.show_level.ONLY_NORMAL,
        });

        normal_analog_clock_pro_hour_pointer_img = new ImgWidget({
          x: 0,
          y: 0,
          w: deviceInfo.width,
          h: deviceInfo.height,
          pos_x: 233 - 41,
          pos_y: 233 - 232,
          center_x: 233,
          center_y: 233,
          src: "arrow_normal_hr.png",
          angle: 0,
          show_level: hmUI.show_level.ONLY_NORMAL,
        });

        normal_analog_clock_pro_minute_pointer_img = new ImgWidget({
          x: 0,
          y: 0,
          w: deviceInfo.width,
          h: deviceInfo.height,
          pos_x: 233 - 41,
          pos_y: 233 - 232,
          center_x: 233,
          center_y: 233,
          src: "arrow_normal_min.png",
          angle: 0,
          show_level: hmUI.show_level.ONLY_NORMAL,
        });

        normal_analog_clock_pro_second_pointer_img = new ImgWidget({
          x: 0,
          y: 0,
          w: deviceInfo.width,
          h: deviceInfo.height,
          pos_x: 233 - 41,
          pos_y: 233 - 232,
          center_x: 233,
          center_y: 233,
          src: "arrow_normal_sec.png",
          angle: 0,
          show_level: hmUI.show_level.ONLY_NORMAL,
        });

        normal_analog_clock_pro_second_cover_pointer_img = hmUI.createWidget(hmUI.widget.IMG, {
          x: 0,
          y: 0,
          src: "center.png",
          show_level: hmUI.show_level.ONLY_NORMAL,
        });

        idle_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
          x: 0,
          y: 0,
          w: 466,
          h: 466,
          src: "idle_bg.png",
          show_level: hmUI.show_level.ONLY_AOD,
        });

        idle_world_clock_pointer_img = new ImgWidget({
          x: 0,
          y: 0,
          w: deviceInfo.width,
          h: deviceInfo.height,
          pos_x: 233 - 41,
          pos_y: 233 - 232,
          center_x: 233,
          center_y: 233,
          src: "arrow_wt_idle.png",
          angle: 0,
          show_level: hmUI.show_level.ONLY_AOD,
        });

        idle_analog_clock_time_pointer_hour = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
          hour_path: "arrow_idle_hr.png",
          hour_centerX: 233,
          hour_centerY: 233,
          hour_posX: 41,
          hour_posY: 232,
          show_level: hmUI.show_level.ONLY_AOD,
        });

        idle_analog_clock_time_pointer_minute = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
          minute_path: "arrow_idle_min.png",
          minute_centerX: 233,
          minute_centerY: 233,
          minute_posX: 41,
          minute_posY: 232,
          show_level: hmUI.show_level.ONLY_AOD,
        });

        let centerButton = hmUI.createWidget(hmUI.widget.BUTTON, {
          x: 233 - 50, // x coordinate of the button
          y: 233 - 50, // y coordinate of the button
          text: "",
          w: 100, // button width
          h: 100, // button height
          normal_src: "_empty.png", // transparent image
          press_src: "_empty.png", // transparent image
          show_level: hmUI.show_level.ONLY_NORMAL,
          click_func: () => {
            centerButtonClick();
          },
        });

        function update_time(updateHour = false, updateMinute = false) {
          const hour = timeSensor.hour;
          const minute = timeSensor.minute;
          const second = timeSensor.second;
          const fullAngle = 360;

          if (updateHour) {
            let normal_hour = hour;

            if (normal_hour > 11) normal_hour -= 12;
            const normal_angle_hour = 0 + (fullAngle * normal_hour) / 12 + ((fullAngle / 12) * minute) / 60;
            normal_analog_clock_pro_hour_pointer_img.angle = normal_angle_hour;
          }

          if (updateMinute) {
            const normal_angle_minute = 0 + (fullAngle * (minute + second / 60)) / 60;
            normal_analog_clock_pro_minute_pointer_img.angle = normal_angle_minute;

            // also update world_clock
            worldData = getWTData(wt_index);
            update_world_clock();
          }

          if (updateHour && updateMinute && lastDay != timeSensor.day) {
            // check and update only when it's required
            lastDay = timeSensor.day;
            const currentDayAngle = (fullAngle / 31) * (timeSensor.day - 1);

            normal_date_img.angle = currentDayAngle;
          }
        }

        function updateSec() {
          const second = timeSensor.second;
          const fullAngle = 360;

          const normal_angle_second = (fullAngle / 60) * second;
          normal_analog_clock_pro_second_pointer_img.angle = normal_angle_second + 1;
          if (!pushback_timer) {
            pushback_timer = timer.createTimer(30, 30, (opt) => {
              const normal_angle_second = (fullAngle / 60) * second;
              normal_analog_clock_pro_second_pointer_img.angle = normal_angle_second;

              timer.stopTimer(pushback_timer);
              pushback_timer = undefined;
            });
          }
        }

        let lastDay = 0;

        let onlyShowCity = true;
        function centerButtonClick() {
          const count = world_clock.getWorldClockCount();
          worldData = getWTData(wt_index);
          if (!worldData) return;

          if (onlyShowCity) {
            hmUI.showToast({ text: worldData.city + " (" + (wt_index + 1) + "/" + count + ")" });
            onlyShowCity = false;
          } else {
            wt_index++;
            if (wt_index == count) wt_index = 0;

            worldData = getWTData(wt_index);
            hmFS.SysProSetInt("LUMINOX_WT_INDEX", wt_index);
            hmUI.showToast({ text: worldData.city + " (" + (wt_index + 1) + "/" + count + ")" });

            update_world_clock();
          }
        }

        function getWTData(idx) {
          return world_clock.getWorldClockInfo(idx);
        }

        function update_world_clock() {
          if (worldData) {
            normal_world_clock_pointer_img.visible = true;
            idle_world_clock_pointer_img.visible = true;
            wt_target_angle = (worldData.hour * 60 + worldData.minute) * wt_angle_delta;

            if (!timer_animate_wt) {
              timer_animate_wt = timer.createTimer(0, 30, function (option) {
                animate_wt();
              });
            }
          } else {
            normal_world_clock_pointer_img.visible = false;
            idle_world_clock_pointer_img.visible = false;
          }
        }

        function valuesAreClose(firstValue, secondValue, tolerance = 10) {
          return Math.abs(firstValue - secondValue) <= tolerance;
        }

        function animate_wt() {
          let wt_current_angle = normal_world_clock_pointer_img.angle;
          const da = wt_current_angle > wt_target_angle ? -3 : 3;

          wt_current_angle += da;
          if (wt_current_angle >= 360) wt_current_angle = wt_current_angle - 360;
          if (valuesAreClose(wt_current_angle, wt_target_angle, 4)) wt_current_angle = wt_target_angle;

          normal_world_clock_pointer_img.angle = wt_current_angle;
          idle_world_clock_pointer_img.angle = wt_current_angle;

          if (timer_animate_wt && wt_current_angle == wt_target_angle) {
            timer.stopTimer(timer_animate_wt);
            timer_animate_wt = undefined;
          }
        }

        const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
          resume_call: function () {
            onlyShowCity = true;
            worldData = getWTData(wt_index);
            update_time(true, true);
            updateSec();

            if (screenType == hmSetting.screen_type.WATCHFACE) {
              if (!timer_main) {
                const animDelay = timeSensor.utc % 1000;
                const animRepeat = 1000;
                timer_main = timer.createTimer(animDelay, animRepeat, function (option) {
                  update_time(false, true);
                  updateSec();
                }); // end timer
              } // end timer check
            } // end screenType
          },
          pause_call: function () {
            if (timer_main) {
              timer.stopTimer(timer_main);
              timer_main = undefined;
            }
          },
        });

        //dynamic modify end
      },
      onInit() {
        logger.log("index page.js on init invoke");
      },
      build() {
        this.init_view();
        logger.log("index page.js on ready invoke");
      },
      onDestroy() {
        logger.log("index page.js on destroy invoke");
      },
    });
  })();
} catch (e) {
  console.log("Mini Program Error", e);
  e && e.stack && e.stack.split(/\n/).forEach((i) => console.log("error stack", i));
}
