﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        const logger = Logger.getLogger('watchface_SashaCX75');
        //end of ignored block

        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_day_pointer_progress_date_pointer = ''
        let normal_moon_image_progress_img_level = ''
        let normal_sun_high_text_img = ''
        let normal_sun_high_separator_img = ''
        let normal_sun_low_text_img = ''
        let normal_sun_low_separator_img = ''
        let normal_hour_TextCircle = new Array(2);
        let normal_hour_TextCircle_ASCIIARRAY = new Array(10);
        let normal_hour_TextCircle_img_width = 43;
        let normal_hour_TextCircle_img_height = 43;
        let normal_timerTextUpdate = undefined;
        let normal_minute_TextCircle = new Array(2);
        let normal_minute_TextCircle_ASCIIARRAY = new Array(10);
        let normal_minute_TextCircle_img_width = 43;
        let normal_minute_TextCircle_img_height = 43;
        let normal_second_TextCircle = new Array(2);
        let normal_second_TextCircle_ASCIIARRAY = new Array(10);
        let normal_second_TextCircle_img_width = 43;
        let normal_second_TextCircle_img_height = 43;
        let normal_system_disconnect_img = ''
        let idle_background_bg_img = ''
        let idle_day_pointer_progress_date_pointer = ''
        let idle_moon_image_progress_img_level = ''
        let idle_sun_high_text_img = ''
        let idle_sun_high_separator_img = ''
        let idle_sun_low_text_img = ''
        let idle_sun_low_separator_img = ''
        let idle_hour_TextCircle = new Array(2);
        let idle_hour_TextCircle_ASCIIARRAY = new Array(10);
        let idle_hour_TextCircle_img_width = 43;
        let idle_hour_TextCircle_img_height = 43;
        let idle_timerTextUpdate = undefined;
        let idle_minute_TextCircle = new Array(2);
        let idle_minute_TextCircle_ASCIIARRAY = new Array(10);
        let idle_minute_TextCircle_img_width = 43;
        let idle_minute_TextCircle_img_height = 43;
        let idle_second_TextCircle = new Array(2);
        let idle_second_TextCircle_ASCIIARRAY = new Array(10);
        let idle_second_TextCircle_img_width = 43;
        let idle_second_TextCircle_img_height = 43;
        let idle_system_disconnect_img = ''
        let normal_stopwatch_jumpable_img_click = ''
        let normal_countdown_jumpable_img_click = ''
        let normal_alarm_jumpable_img_click = ''


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 466,
              h: 466,
              src: 'back-00.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_day_pointer_progress_date_pointer = hmUI.createWidget(hmUI.widget.DATE_POINTER, {
              src: 'calendario.png',
              center_x: 233,
              center_y: 233,
              posX: 212,
              posY: 212,
              start_angle: -9,
              end_angle: 349,
              cover_path: 'back-01.png',
              cover_x: 0,
              cover_y: 0,
              type: hmUI.date.DAY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_moon_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 21,
              y: 188,
              image_array: ["moon-00.png","moon-01.png","moon-02.png","moon-03.png","moon-04.png","moon-05.png","moon-06.png","moon-07.png","moon-08.png"],
              image_length: 9,
              type: hmUI.data_type.MOON,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sun_high_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 107,
              y: 372,
              font_array: ["AOD-0064.png","AOD-0065.png","AOD-0066.png","AOD-0067.png","AOD-0068.png","AOD-0069.png","AOD-0070.png","AOD-0071.png","AOD-0072.png","AOD-0073.png"],
              padding: false,
              h_space: 0,
              angle: 25,
              dot_image: 'aod-duepunti.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.SUN_RISE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sun_high_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 25,
              y: 286,
              src: 'ico-alba.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sun_low_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 264,
              y: 404,
              font_array: ["AOD-0064.png","AOD-0065.png","AOD-0066.png","AOD-0067.png","AOD-0068.png","AOD-0069.png","AOD-0070.png","AOD-0071.png","AOD-0072.png","AOD-0073.png"],
              padding: false,
              h_space: 0,
              angle: -25,
              dot_image: 'aod-duepunti.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.SUN_SET,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sun_low_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 322,
              y: 293,
              src: 'ico-tramonto.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_hour_text_circle_img = hmUI.createWidget(hmUI.widget.Text_Circle, {
              // circle_center_X: 233,
              // circle_center_Y: 233,
              // font_array: ["num-00.png","num-01.png","num-02.png","num-03.png","num-04.png","num-05.png","num-06.png","num-07.png","num-08.png","num-09.png"],
              // radius: 171,
              // angle: -48,
              // char_space_angle: 1,
              // zero: true,
              // reverse_direction: false,
              // unit_in_alignment: true,
              // vertical_alignment: BOTTOM,
              // horizontal_alignment: LEFT,
              // type: hmUI.data_type.HOUR,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_hour_TextCircle_ASCIIARRAY[0] = 'num-00.png';  // set of images with numbers
            normal_hour_TextCircle_ASCIIARRAY[1] = 'num-01.png';  // set of images with numbers
            normal_hour_TextCircle_ASCIIARRAY[2] = 'num-02.png';  // set of images with numbers
            normal_hour_TextCircle_ASCIIARRAY[3] = 'num-03.png';  // set of images with numbers
            normal_hour_TextCircle_ASCIIARRAY[4] = 'num-04.png';  // set of images with numbers
            normal_hour_TextCircle_ASCIIARRAY[5] = 'num-05.png';  // set of images with numbers
            normal_hour_TextCircle_ASCIIARRAY[6] = 'num-06.png';  // set of images with numbers
            normal_hour_TextCircle_ASCIIARRAY[7] = 'num-07.png';  // set of images with numbers
            normal_hour_TextCircle_ASCIIARRAY[8] = 'num-08.png';  // set of images with numbers
            normal_hour_TextCircle_ASCIIARRAY[9] = 'num-09.png';  // set of images with numbers

            //start of ignored block
            for (let i = 0; i < 2; i++) {
              normal_hour_TextCircle[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 466,
                h: 466,
                center_x: 233,
                center_y: 233,
                pos_x: 233 - normal_hour_TextCircle_img_width / 2,
                pos_y: 233 - 214,
                src: 'num-00.png',
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
              normal_hour_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
            };
            //end of ignored block
            
            const timeNaw = hmSensor.createSensor(hmSensor.id.TIME);

            let screenType = hmSetting.getScreenType();            
            function toDegree (radian) {
              return radian * (180 / Math.PI);
            };

            // normal_minute_text_circle_img = hmUI.createWidget(hmUI.widget.Text_Circle, {
              // circle_center_X: 233,
              // circle_center_Y: 233,
              // font_array: ["num-00.png","num-01.png","num-02.png","num-03.png","num-04.png","num-05.png","num-06.png","num-07.png","num-08.png","num-09.png"],
              // radius: 171,
              // angle: -7,
              // char_space_angle: 1,
              // zero: true,
              // reverse_direction: false,
              // unit_in_alignment: true,
              // vertical_alignment: BOTTOM,
              // horizontal_alignment: LEFT,
              // type: hmUI.data_type.MINUTE,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_minute_TextCircle_ASCIIARRAY[0] = 'num-00.png';  // set of images with numbers
            normal_minute_TextCircle_ASCIIARRAY[1] = 'num-01.png';  // set of images with numbers
            normal_minute_TextCircle_ASCIIARRAY[2] = 'num-02.png';  // set of images with numbers
            normal_minute_TextCircle_ASCIIARRAY[3] = 'num-03.png';  // set of images with numbers
            normal_minute_TextCircle_ASCIIARRAY[4] = 'num-04.png';  // set of images with numbers
            normal_minute_TextCircle_ASCIIARRAY[5] = 'num-05.png';  // set of images with numbers
            normal_minute_TextCircle_ASCIIARRAY[6] = 'num-06.png';  // set of images with numbers
            normal_minute_TextCircle_ASCIIARRAY[7] = 'num-07.png';  // set of images with numbers
            normal_minute_TextCircle_ASCIIARRAY[8] = 'num-08.png';  // set of images with numbers
            normal_minute_TextCircle_ASCIIARRAY[9] = 'num-09.png';  // set of images with numbers

            //start of ignored block
            for (let i = 0; i < 2; i++) {
              normal_minute_TextCircle[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 466,
                h: 466,
                center_x: 233,
                center_y: 233,
                pos_x: 233 - normal_minute_TextCircle_img_width / 2,
                pos_y: 233 - 214,
                src: 'num-00.png',
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
              normal_minute_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
            };
            //end of ignored block

            // normal_second_text_circle_img = hmUI.createWidget(hmUI.widget.Text_Circle, {
              // circle_center_X: 233,
              // circle_center_Y: 233,
              // font_array: ["num-00.png","num-01.png","num-02.png","num-03.png","num-04.png","num-05.png","num-06.png","num-07.png","num-08.png","num-09.png"],
              // radius: 171,
              // angle: 33,
              // char_space_angle: 1,
              // zero: true,
              // reverse_direction: false,
              // unit_in_alignment: true,
              // vertical_alignment: BOTTOM,
              // horizontal_alignment: LEFT,
              // type: hmUI.data_type.SECOND,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_second_TextCircle_ASCIIARRAY[0] = 'num-00.png';  // set of images with numbers
            normal_second_TextCircle_ASCIIARRAY[1] = 'num-01.png';  // set of images with numbers
            normal_second_TextCircle_ASCIIARRAY[2] = 'num-02.png';  // set of images with numbers
            normal_second_TextCircle_ASCIIARRAY[3] = 'num-03.png';  // set of images with numbers
            normal_second_TextCircle_ASCIIARRAY[4] = 'num-04.png';  // set of images with numbers
            normal_second_TextCircle_ASCIIARRAY[5] = 'num-05.png';  // set of images with numbers
            normal_second_TextCircle_ASCIIARRAY[6] = 'num-06.png';  // set of images with numbers
            normal_second_TextCircle_ASCIIARRAY[7] = 'num-07.png';  // set of images with numbers
            normal_second_TextCircle_ASCIIARRAY[8] = 'num-08.png';  // set of images with numbers
            normal_second_TextCircle_ASCIIARRAY[9] = 'num-09.png';  // set of images with numbers

            //start of ignored block
            for (let i = 0; i < 2; i++) {
              normal_second_TextCircle[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 466,
                h: 466,
                center_x: 233,
                center_y: 233,
                pos_x: 233 - normal_second_TextCircle_img_width / 2,
                pos_y: 233 - 214,
                src: 'num-00.png',
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
              normal_second_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
            };
            //end of ignored block

            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 21,
              y: 188,
              src: 'ico-bluetooth.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            idle_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 466,
              h: 466,
              src: 'back-00.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_day_pointer_progress_date_pointer = hmUI.createWidget(hmUI.widget.DATE_POINTER, {
              src: 'calendario.png',
              center_x: 233,
              center_y: 233,
              posX: 212,
              posY: 212,
              start_angle: -9,
              end_angle: 349,
              cover_path: 'back-01.png',
              cover_x: 0,
              cover_y: 0,
              type: hmUI.date.DAY,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_moon_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 21,
              y: 188,
              image_array: ["moon-00.png","moon-01.png","moon-02.png","moon-03.png","moon-04.png","moon-05.png","moon-06.png","moon-07.png","moon-08.png"],
              image_length: 9,
              type: hmUI.data_type.MOON,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_sun_high_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 107,
              y: 372,
              font_array: ["AOD-0064.png","AOD-0065.png","AOD-0066.png","AOD-0067.png","AOD-0068.png","AOD-0069.png","AOD-0070.png","AOD-0071.png","AOD-0072.png","AOD-0073.png"],
              padding: false,
              h_space: 0,
              angle: 25,
              dot_image: 'aod-duepunti.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.SUN_RISE,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_sun_high_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 25,
              y: 286,
              src: 'ico-alba.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_sun_low_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 264,
              y: 404,
              font_array: ["AOD-0064.png","AOD-0065.png","AOD-0066.png","AOD-0067.png","AOD-0068.png","AOD-0069.png","AOD-0070.png","AOD-0071.png","AOD-0072.png","AOD-0073.png"],
              padding: false,
              h_space: 0,
              angle: -25,
              dot_image: 'aod-duepunti.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.SUN_SET,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_sun_low_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 322,
              y: 293,
              src: 'ico-tramonto.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            // idle_hour_text_circle_img = hmUI.createWidget(hmUI.widget.Text_Circle, {
              // circle_center_X: 233,
              // circle_center_Y: 233,
              // font_array: ["num-00.png","num-01.png","num-02.png","num-03.png","num-04.png","num-05.png","num-06.png","num-07.png","num-08.png","num-09.png"],
              // radius: 171,
              // angle: -48,
              // char_space_angle: 1,
              // zero: true,
              // reverse_direction: false,
              // unit_in_alignment: true,
              // vertical_alignment: BOTTOM,
              // horizontal_alignment: LEFT,
              // type: hmUI.data_type.HOUR,
              // show_level: hmUI.show_level.ONLY_AOD,
            // });

            idle_hour_TextCircle_ASCIIARRAY[0] = 'num-00.png';  // set of images with numbers
            idle_hour_TextCircle_ASCIIARRAY[1] = 'num-01.png';  // set of images with numbers
            idle_hour_TextCircle_ASCIIARRAY[2] = 'num-02.png';  // set of images with numbers
            idle_hour_TextCircle_ASCIIARRAY[3] = 'num-03.png';  // set of images with numbers
            idle_hour_TextCircle_ASCIIARRAY[4] = 'num-04.png';  // set of images with numbers
            idle_hour_TextCircle_ASCIIARRAY[5] = 'num-05.png';  // set of images with numbers
            idle_hour_TextCircle_ASCIIARRAY[6] = 'num-06.png';  // set of images with numbers
            idle_hour_TextCircle_ASCIIARRAY[7] = 'num-07.png';  // set of images with numbers
            idle_hour_TextCircle_ASCIIARRAY[8] = 'num-08.png';  // set of images with numbers
            idle_hour_TextCircle_ASCIIARRAY[9] = 'num-09.png';  // set of images with numbers

            //start of ignored block
            for (let i = 0; i < 2; i++) {
              idle_hour_TextCircle[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 466,
                h: 466,
                center_x: 233,
                center_y: 233,
                pos_x: 233 - idle_hour_TextCircle_img_width / 2,
                pos_y: 233 - 214,
                src: 'num-00.png',
                show_level: hmUI.show_level.ONLY_AOD,
              });
              idle_hour_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
            };
            //end of ignored block

            // idle_minute_text_circle_img = hmUI.createWidget(hmUI.widget.Text_Circle, {
              // circle_center_X: 233,
              // circle_center_Y: 233,
              // font_array: ["num-00.png","num-01.png","num-02.png","num-03.png","num-04.png","num-05.png","num-06.png","num-07.png","num-08.png","num-09.png"],
              // radius: 171,
              // angle: -7,
              // char_space_angle: 1,
              // zero: true,
              // reverse_direction: false,
              // unit_in_alignment: true,
              // vertical_alignment: BOTTOM,
              // horizontal_alignment: LEFT,
              // type: hmUI.data_type.MINUTE,
              // show_level: hmUI.show_level.ONLY_AOD,
            // });

            idle_minute_TextCircle_ASCIIARRAY[0] = 'num-00.png';  // set of images with numbers
            idle_minute_TextCircle_ASCIIARRAY[1] = 'num-01.png';  // set of images with numbers
            idle_minute_TextCircle_ASCIIARRAY[2] = 'num-02.png';  // set of images with numbers
            idle_minute_TextCircle_ASCIIARRAY[3] = 'num-03.png';  // set of images with numbers
            idle_minute_TextCircle_ASCIIARRAY[4] = 'num-04.png';  // set of images with numbers
            idle_minute_TextCircle_ASCIIARRAY[5] = 'num-05.png';  // set of images with numbers
            idle_minute_TextCircle_ASCIIARRAY[6] = 'num-06.png';  // set of images with numbers
            idle_minute_TextCircle_ASCIIARRAY[7] = 'num-07.png';  // set of images with numbers
            idle_minute_TextCircle_ASCIIARRAY[8] = 'num-08.png';  // set of images with numbers
            idle_minute_TextCircle_ASCIIARRAY[9] = 'num-09.png';  // set of images with numbers

            //start of ignored block
            for (let i = 0; i < 2; i++) {
              idle_minute_TextCircle[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 466,
                h: 466,
                center_x: 233,
                center_y: 233,
                pos_x: 233 - idle_minute_TextCircle_img_width / 2,
                pos_y: 233 - 214,
                src: 'num-00.png',
                show_level: hmUI.show_level.ONLY_AOD,
              });
              idle_minute_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
            };
            //end of ignored block

            // idle_second_text_circle_img = hmUI.createWidget(hmUI.widget.Text_Circle, {
              // circle_center_X: 233,
              // circle_center_Y: 233,
              // font_array: ["num-00.png","num-01.png","num-02.png","num-03.png","num-04.png","num-05.png","num-06.png","num-07.png","num-08.png","num-09.png"],
              // radius: 171,
              // angle: 33,
              // char_space_angle: 1,
              // zero: true,
              // reverse_direction: false,
              // unit_in_alignment: true,
              // vertical_alignment: BOTTOM,
              // horizontal_alignment: LEFT,
              // type: hmUI.data_type.SECOND,
              // show_level: hmUI.show_level.ONLY_AOD,
            // });

            idle_second_TextCircle_ASCIIARRAY[0] = 'num-00.png';  // set of images with numbers
            idle_second_TextCircle_ASCIIARRAY[1] = 'num-01.png';  // set of images with numbers
            idle_second_TextCircle_ASCIIARRAY[2] = 'num-02.png';  // set of images with numbers
            idle_second_TextCircle_ASCIIARRAY[3] = 'num-03.png';  // set of images with numbers
            idle_second_TextCircle_ASCIIARRAY[4] = 'num-04.png';  // set of images with numbers
            idle_second_TextCircle_ASCIIARRAY[5] = 'num-05.png';  // set of images with numbers
            idle_second_TextCircle_ASCIIARRAY[6] = 'num-06.png';  // set of images with numbers
            idle_second_TextCircle_ASCIIARRAY[7] = 'num-07.png';  // set of images with numbers
            idle_second_TextCircle_ASCIIARRAY[8] = 'num-08.png';  // set of images with numbers
            idle_second_TextCircle_ASCIIARRAY[9] = 'num-09.png';  // set of images with numbers

            //start of ignored block
            for (let i = 0; i < 2; i++) {
              idle_second_TextCircle[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 466,
                h: 466,
                center_x: 233,
                center_y: 233,
                pos_x: 233 - idle_second_TextCircle_img_width / 2,
                pos_y: 233 - 214,
                src: 'num-00.png',
                show_level: hmUI.show_level.ONLY_AOD,
              });
              idle_second_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
            };
            //end of ignored block

            idle_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 21,
              y: 188,
              src: 'ico-bluetooth.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_AOD,
            });
            
            // disconnectAlert = hmUI.createWidget(hmUI.widget.DisconnectAlert, {
              // disconneсnt_vibrate_type: 9,
              // disconneсnt_toast_text: WATCH DISCONNECTED,
              // conneсnt_vibrate_type: 9,
              // conneсnt_toast_text: WATCH CONNECTED,
            // });

            // vibration when connecting or disconnecting

            function checkConnection() {
              hmBle.removeListener;
              hmBle.addListener(function (status) {
                if(!status) {
                  hmUI.showToast({text: "WATCH DISCONNECTED"});
                  vibro(9);
                }
                if(status) {
                  hmUI.showToast({text: "WATCH CONNECTED"});
                  vibro(9);
                }
              });
            }

            // end vibration when connecting or disconnecting
            // vibrate function

            const vibrate = hmSensor.createSensor(hmSensor.id.VIBRATE);
            let timer_StopVibrate = null;


            function vibro(scene = 25) {
              let stopDelay = 50;
              stopVibro();
              vibrate.stop();
              vibrate.scene = scene;
              if(scene < 23 || scene > 25) stopDelay = 1300;
              vibrate.start();
              timer_StopVibrate = timer.createTimer(stopDelay, 3000, stopVibro, {});
            }

            function stopVibro(){
              vibrate.stop();
              if(timer_StopVibrate) timer.stopTimer(timer_StopVibrate);
            }

            // end vibrate function

            normal_stopwatch_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 60,
              y: 40,
              w: 100,
              h: 80,
              type: hmUI.data_type.STOP_WATCH,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_countdown_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 317,
              y: 40,
              w: 100,
              h: 80,
              type: hmUI.data_type.COUNT_DOWN,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_alarm_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 186,
              y: 8,
              w: 100,
              h: 60,
              type: hmUI.data_type.ALARM_CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            function text_update() {

              console.log('update text circle hour_TIME');
              let valueHour = timeNaw.hour;
              if (!timeNaw.is24Hour) {
                valueHour -= 12;
                if (valueHour < 1) valueHour += 12;
              };
              let normal_hour_circle_string = parseInt(valueHour).toString();
              normal_hour_circle_string = normal_hour_circle_string.padStart(2, '0');

              if (screenType != hmSetting.screen_type.AOD) {
                for (var i = 1; i < 2; i++) {  // hide all symbols
                  normal_hour_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                let char_Angle = -48;
                if (valueHour != null && valueHour != undefined && isFinite(valueHour) && normal_hour_circle_string.length > 0 && normal_hour_circle_string.length < 6) {  // display data if it was possible to get it
                  let normal_hour_TextCircle_img_angle = 0;
                  let normal_hour_TextCircle_dot_img_angle = 0;
                  normal_hour_TextCircle_img_angle = toDegree(Math.atan2(normal_hour_TextCircle_img_width/2, 171));
                  
                  let firstSymbol = true;
                  let index = 0;
                  for (let char of normal_hour_circle_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 2) break;
                    if (charCode >= 0 && charCode < 10) { 
                      if (!firstSymbol) char_Angle += normal_hour_TextCircle_img_angle;
                      firstSymbol = false;
                      normal_hour_TextCircle[index].setProperty(hmUI.prop.ANGLE, char_Angle);
                      normal_hour_TextCircle[index].setProperty(hmUI.prop.POS_X, 233 - normal_hour_TextCircle_img_width / 2);
                      normal_hour_TextCircle[index].setProperty(hmUI.prop.SRC, normal_hour_TextCircle_ASCIIARRAY[charCode]);
                      normal_hour_TextCircle[index].setProperty(hmUI.prop.VISIBLE, true);
                      char_Angle += normal_hour_TextCircle_img_angle + 1;
                      index++;
                    };  // end if digit
                  };  // end char of string
                }  // end isFinite

              };

              console.log('update text circle minute_TIME');
              let valueMinute = timeNaw.minute;
              let normal_minute_circle_string = parseInt(valueMinute).toString();
              normal_minute_circle_string = normal_minute_circle_string.padStart(2, '0');

              if (screenType != hmSetting.screen_type.AOD) {
                for (var i = 1; i < 2; i++) {  // hide all symbols
                  normal_minute_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                let char_Angle = -7;
                if (valueMinute != null && valueMinute != undefined && isFinite(valueMinute) && normal_minute_circle_string.length > 0 && normal_minute_circle_string.length < 6) {  // display data if it was possible to get it
                  let normal_minute_TextCircle_img_angle = 0;
                  let normal_minute_TextCircle_dot_img_angle = 0;
                  normal_minute_TextCircle_img_angle = toDegree(Math.atan2(normal_minute_TextCircle_img_width/2, 171));
                  
                  let firstSymbol = true;
                  let index = 0;
                  for (let char of normal_minute_circle_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 2) break;
                    if (charCode >= 0 && charCode < 10) { 
                      if (!firstSymbol) char_Angle += normal_minute_TextCircle_img_angle;
                      firstSymbol = false;
                      normal_minute_TextCircle[index].setProperty(hmUI.prop.ANGLE, char_Angle);
                      normal_minute_TextCircle[index].setProperty(hmUI.prop.POS_X, 233 - normal_minute_TextCircle_img_width / 2);
                      normal_minute_TextCircle[index].setProperty(hmUI.prop.SRC, normal_minute_TextCircle_ASCIIARRAY[charCode]);
                      normal_minute_TextCircle[index].setProperty(hmUI.prop.VISIBLE, true);
                      char_Angle += normal_minute_TextCircle_img_angle + 1;
                      index++;
                    };  // end if digit
                  };  // end char of string
                }  // end isFinite

              };

              console.log('update text circle second_TIME');
              let valueSecond = timeNaw.second;
              let normal_second_circle_string = parseInt(valueSecond).toString();
              normal_second_circle_string = normal_second_circle_string.padStart(2, '0');

              if (screenType != hmSetting.screen_type.AOD) {
                for (var i = 1; i < 2; i++) {  // hide all symbols
                  normal_second_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                let char_Angle = 33;
                if (valueSecond != null && valueSecond != undefined && isFinite(valueSecond) && normal_second_circle_string.length > 0 && normal_second_circle_string.length < 6) {  // display data if it was possible to get it
                  let normal_second_TextCircle_img_angle = 0;
                  let normal_second_TextCircle_dot_img_angle = 0;
                  normal_second_TextCircle_img_angle = toDegree(Math.atan2(normal_second_TextCircle_img_width/2, 171));
                  
                  let firstSymbol = true;
                  let index = 0;
                  for (let char of normal_second_circle_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 2) break;
                    if (charCode >= 0 && charCode < 10) { 
                      if (!firstSymbol) char_Angle += normal_second_TextCircle_img_angle;
                      firstSymbol = false;
                      normal_second_TextCircle[index].setProperty(hmUI.prop.ANGLE, char_Angle);
                      normal_second_TextCircle[index].setProperty(hmUI.prop.POS_X, 233 - normal_second_TextCircle_img_width / 2);
                      normal_second_TextCircle[index].setProperty(hmUI.prop.SRC, normal_second_TextCircle_ASCIIARRAY[charCode]);
                      normal_second_TextCircle[index].setProperty(hmUI.prop.VISIBLE, true);
                      char_Angle += normal_second_TextCircle_img_angle + 1;
                      index++;
                    };  // end if digit
                  };  // end char of string
                }  // end isFinite

              };

              console.log('update text circle hour_TIME');
              let idle_hour_circle_string = parseInt(valueHour).toString();
              idle_hour_circle_string = idle_hour_circle_string.padStart(2, '0');

              if (screenType == hmSetting.screen_type.AOD) {
                for (var i = 1; i < 2; i++) {  // hide all symbols
                  idle_hour_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                let char_Angle = -48;
                if (valueHour != null && valueHour != undefined && isFinite(valueHour) && idle_hour_circle_string.length > 0 && idle_hour_circle_string.length < 6) {  // display data if it was possible to get it
                  let idle_hour_TextCircle_img_angle = 0;
                  let idle_hour_TextCircle_dot_img_angle = 0;
                  idle_hour_TextCircle_img_angle = toDegree(Math.atan2(idle_hour_TextCircle_img_width/2, 171));
                  
                  let firstSymbol = true;
                  let index = 0;
                  for (let char of idle_hour_circle_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 2) break;
                    if (charCode >= 0 && charCode < 10) { 
                      if (!firstSymbol) char_Angle += idle_hour_TextCircle_img_angle;
                      firstSymbol = false;
                      idle_hour_TextCircle[index].setProperty(hmUI.prop.ANGLE, char_Angle);
                      idle_hour_TextCircle[index].setProperty(hmUI.prop.POS_X, 233 - idle_hour_TextCircle_img_width / 2);
                      idle_hour_TextCircle[index].setProperty(hmUI.prop.SRC, idle_hour_TextCircle_ASCIIARRAY[charCode]);
                      idle_hour_TextCircle[index].setProperty(hmUI.prop.VISIBLE, true);
                      char_Angle += idle_hour_TextCircle_img_angle + 1;
                      index++;
                    };  // end if digit
                  };  // end char of string
                }  // end isFinite

              };

              console.log('update text circle minute_TIME');
              let idle_minute_circle_string = parseInt(valueMinute).toString();
              idle_minute_circle_string = idle_minute_circle_string.padStart(2, '0');

              if (screenType == hmSetting.screen_type.AOD) {
                for (var i = 1; i < 2; i++) {  // hide all symbols
                  idle_minute_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                let char_Angle = -7;
                if (valueMinute != null && valueMinute != undefined && isFinite(valueMinute) && idle_minute_circle_string.length > 0 && idle_minute_circle_string.length < 6) {  // display data if it was possible to get it
                  let idle_minute_TextCircle_img_angle = 0;
                  let idle_minute_TextCircle_dot_img_angle = 0;
                  idle_minute_TextCircle_img_angle = toDegree(Math.atan2(idle_minute_TextCircle_img_width/2, 171));
                  
                  let firstSymbol = true;
                  let index = 0;
                  for (let char of idle_minute_circle_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 2) break;
                    if (charCode >= 0 && charCode < 10) { 
                      if (!firstSymbol) char_Angle += idle_minute_TextCircle_img_angle;
                      firstSymbol = false;
                      idle_minute_TextCircle[index].setProperty(hmUI.prop.ANGLE, char_Angle);
                      idle_minute_TextCircle[index].setProperty(hmUI.prop.POS_X, 233 - idle_minute_TextCircle_img_width / 2);
                      idle_minute_TextCircle[index].setProperty(hmUI.prop.SRC, idle_minute_TextCircle_ASCIIARRAY[charCode]);
                      idle_minute_TextCircle[index].setProperty(hmUI.prop.VISIBLE, true);
                      char_Angle += idle_minute_TextCircle_img_angle + 1;
                      index++;
                    };  // end if digit
                  };  // end char of string
                }  // end isFinite

              };

              console.log('update text circle second_TIME');
              let idle_second_circle_string = parseInt(valueSecond).toString();
              idle_second_circle_string = idle_second_circle_string.padStart(2, '0');

              if (screenType == hmSetting.screen_type.AOD) {
                for (var i = 1; i < 2; i++) {  // hide all symbols
                  idle_second_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                let char_Angle = 33;
                if (valueSecond != null && valueSecond != undefined && isFinite(valueSecond) && idle_second_circle_string.length > 0 && idle_second_circle_string.length < 6) {  // display data if it was possible to get it
                  let idle_second_TextCircle_img_angle = 0;
                  let idle_second_TextCircle_dot_img_angle = 0;
                  idle_second_TextCircle_img_angle = toDegree(Math.atan2(idle_second_TextCircle_img_width/2, 171));
                  
                  let firstSymbol = true;
                  let index = 0;
                  for (let char of idle_second_circle_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 2) break;
                    if (charCode >= 0 && charCode < 10) { 
                      if (!firstSymbol) char_Angle += idle_second_TextCircle_img_angle;
                      firstSymbol = false;
                      idle_second_TextCircle[index].setProperty(hmUI.prop.ANGLE, char_Angle);
                      idle_second_TextCircle[index].setProperty(hmUI.prop.POS_X, 233 - idle_second_TextCircle_img_width / 2);
                      idle_second_TextCircle[index].setProperty(hmUI.prop.SRC, idle_second_TextCircle_ASCIIARRAY[charCode]);
                      idle_second_TextCircle[index].setProperty(hmUI.prop.VISIBLE, true);
                      char_Angle += idle_second_TextCircle_img_angle + 1;
                      index++;
                    };  // end if digit
                  };  // end char of string
                }  // end isFinite

              };

            };

            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                text_update();
                if (screenType == hmSetting.screen_type.WATCHFACE) {
                  if (!normal_timerTextUpdate) {
                    normal_timerTextUpdate = timer.createTimer(0, 1000, (function (option) {
                      text_update();
                    }));  // end timer 
                  };  // end timer check
                };  // end screenType

                if (screenType == hmSetting.screen_type.AOD) {
                  if (!idle_timerTextUpdate) {
                    idle_timerTextUpdate = timer.createTimer(0, 1000, (function (option) {
                      text_update();
                    }));  // end timer 
                  };  // end timer check
                };  // end screenType

                checkConnection();
                stopVibro();

              }),
              pause_call: (function () {
                if (normal_timerTextUpdate) {
                  timer.stopTimer(normal_timerTextUpdate);
                  normal_timerTextUpdate = undefined;
                }
                if (idle_timerTextUpdate) {
                  timer.stopTimer(idle_timerTextUpdate);
                  idle_timerTextUpdate = undefined;
                }
                stopVibro();

              }),
            });

// *************************** Calendario
            hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 390,
              y: 215,
              w: 80,
              h: 50,
			  text: '',
			  normal_src: 'Empty.png',
			  press_src: 'Empty.png',
			  click_func: () => {
				hmApp.startApp({ url: 'ScheduleCalScreen', native: true });
			  },
			  show_level: hmUI.show_level.ONLY_NORMAL, 
            });


                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}
