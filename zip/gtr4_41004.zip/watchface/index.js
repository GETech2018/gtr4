﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        const logger = Logger.getLogger('watchface_SashaCX75');
        //end of ignored block

        //dynamic modify start

        
        let editBg = ''
        let normal_system_disconnect_img = ''
        let normal_system_clock_img = ''
        let normal_weather_image_progress_img_level = ''
        let normal_temperature_current_text_img = ''
        let normal_battery_TextRotate = new Array(3);
        let normal_battery_TextRotate_ASCIIARRAY = new Array(10);
        let normal_battery_TextRotate_img_width = 37;
        let normal_battery_image_progress_img_level = ''
        let normal_date_img_date_month_img = ''
        let normal_date_img_date_day = ''
        let normal_digital_clock_img_time = ''


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            console.log('Watch_Face.ScreenNormal');
            editBg = hmUI.createWidget(hmUI.widget.WATCHFACE_EDIT_BG, {
              edit_id: 1002,
              x: 0,
              y: 0,
              // w: 466,
              // h: 466,
              // AOD_show: False,
              bg_config: [
                { id: 1, preview: 'bg_edit_1_preview.png', path: '0000.png' },
                { id: 2, preview: 'bg_edit_2_preview.png', path: '2.png' },
                { id: 3, preview: 'bg_edit_3_preview.png', path: '3.png' },
                { id: 4, preview: 'bg_edit_4_preview.png', path: '4.png' },
                { id: 5, preview: 'bg_edit_5_preview.png', path: '5.png' },
                { id: 6, preview: 'bg_edit_6_preview.png', path: '6.png' },
                { id: 7, preview: 'bg_edit_7_preview.png', path: '7.png' },
                { id: 8, preview: 'bg_edit_8_preview.png', path: '8.png' },
                { id: 9, preview: 'bg_edit_9_preview.png', path: '9.png' },
              ],
              count: 9,
              default_id: 1,
              fg: '.png',
              tips_bg: '.png',
              tips_x: 0,
              tips_y: 0,
              show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_EDIT,
            });

            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 335,
              y: 394,
              src: '200.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 100,
              y: 390,
              src: '0075.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 100,
              y: 31,
              image_array: ["0044.png","0045.png","0046.png","0047.png","0048.png","0049.png","0050.png","0051.png","0052.png","0053.png","0054.png","0055.png","0056.png","0057.png","0058.png","0059.png","0060.png","0061.png","0062.png","0063.png","0064.png","0065.png","0066.png","0067.png","0068.png","0069.png","0070.png","0071.png","0072.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 312,
              y: 50,
              font_array: ["400.png","401.png","402.png","403.png","404.png","405.png","406.png","407.png","408.png","409.png"],
              padding: false,
              h_space: 0,
              unit_sc: '301.png',
              unit_tc: '301.png',
              unit_en: '301.png',
              negative_image: '300.png',
              invalid_image: '302.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_battery_text_rotate_img = hmUI.createWidget(hmUI.widget.Text_Rotate, {
              // x: 413,
              // y: 244,
              // font_array: ["0011.png","0012.png","0013.png","0014.png","0015.png","0016.png","0017.png","0018.png","0019.png","0020.png"],
              // zero: false,
              // unit_in_alignment: false,
              // h_space: 0,
              // angle: -90,
              // align_h: hmUI.align.CENTER_H,
              // type: hmUI.data_type.BATTERY,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_battery_TextRotate_ASCIIARRAY[0] = '0011.png';  // set of images with numbers
            normal_battery_TextRotate_ASCIIARRAY[1] = '0012.png';  // set of images with numbers
            normal_battery_TextRotate_ASCIIARRAY[2] = '0013.png';  // set of images with numbers
            normal_battery_TextRotate_ASCIIARRAY[3] = '0014.png';  // set of images with numbers
            normal_battery_TextRotate_ASCIIARRAY[4] = '0015.png';  // set of images with numbers
            normal_battery_TextRotate_ASCIIARRAY[5] = '0016.png';  // set of images with numbers
            normal_battery_TextRotate_ASCIIARRAY[6] = '0017.png';  // set of images with numbers
            normal_battery_TextRotate_ASCIIARRAY[7] = '0018.png';  // set of images with numbers
            normal_battery_TextRotate_ASCIIARRAY[8] = '0019.png';  // set of images with numbers
            normal_battery_TextRotate_ASCIIARRAY[9] = '0020.png';  // set of images with numbers

            //start of ignored block
            for (let i = 0; i < 3; i++) {
              normal_battery_TextRotate[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 466,
                h: 466,
                center_x: 413,
                center_y: 244,
                pos_x: 413,
                pos_y: 244,
                angle: -90,
                src: '0011.png',
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
              normal_battery_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
            };
            //end of ignored block
            
            const battery = hmSensor.createSensor(hmSensor.id.BATTERY);
            battery.addEventListener(hmSensor.event.CHANGE, function() {
              text_update();
            });

            normal_battery_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 426,
              y: 153,
              image_array: ["0101.png","0102.png","0103.png","0104.png","0105.png","0106.png","0107.png"],
              image_length: 7,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_month_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 195,
              month_startY: 10,
              month_sc_array: ["d0053.png","d0054.png","d0055.png","d0056.png","d0057.png","d0058.png","d0059.png","d0060.png","d0061.png","d0062.png","d0063.png","d0064.png"],
              month_tc_array: ["d0053.png","d0054.png","d0055.png","d0056.png","d0057.png","d0058.png","d0059.png","d0060.png","d0061.png","d0062.png","d0063.png","d0064.png"],
              month_en_array: ["d0053.png","d0054.png","d0055.png","d0056.png","d0057.png","d0058.png","d0059.png","d0060.png","d0061.png","d0062.png","d0063.png","d0064.png"],
              month_is_character: true ,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 157,
              day_startY: 33,
              day_sc_array: ["wfs_0_482ad812_d31d_4a07_a060_3e7ca079aab6.png","wfs_1_2f77404e_f357_448a_af59_09531db154b7.png","wfs_2_97b8da55_b4e7_41e5_81b8_10e567e5bf96.png","wfs_3_68d4f059_c6c2_4bf4_ad22_0927fee014a7.png","wfs_4_8e67f4f7_7f54_4121_ad99_837e10ec3270.png","wfs_5_100e00cc_b781_4477_b3cc_5680f78d7921.png","wfs_6_0e501e10_2f0e_4017_b8d3_90f38a5848a4.png","wfs_7_14ef4679_7ed9_4413_bfe9_f8e6d2644f2c.png","wfs_8_125c738b_fcc2_4dd5_9da8_c7e1426202ad.png","wfs_9_a3baacf8_1c45_4c92_8e23_f47a03e7b559.png"],
              day_tc_array: ["wfs_0_482ad812_d31d_4a07_a060_3e7ca079aab6.png","wfs_1_2f77404e_f357_448a_af59_09531db154b7.png","wfs_2_97b8da55_b4e7_41e5_81b8_10e567e5bf96.png","wfs_3_68d4f059_c6c2_4bf4_ad22_0927fee014a7.png","wfs_4_8e67f4f7_7f54_4121_ad99_837e10ec3270.png","wfs_5_100e00cc_b781_4477_b3cc_5680f78d7921.png","wfs_6_0e501e10_2f0e_4017_b8d3_90f38a5848a4.png","wfs_7_14ef4679_7ed9_4413_bfe9_f8e6d2644f2c.png","wfs_8_125c738b_fcc2_4dd5_9da8_c7e1426202ad.png","wfs_9_a3baacf8_1c45_4c92_8e23_f47a03e7b559.png"],
              day_en_array: ["wfs_0_482ad812_d31d_4a07_a060_3e7ca079aab6.png","wfs_1_2f77404e_f357_448a_af59_09531db154b7.png","wfs_2_97b8da55_b4e7_41e5_81b8_10e567e5bf96.png","wfs_3_68d4f059_c6c2_4bf4_ad22_0927fee014a7.png","wfs_4_8e67f4f7_7f54_4121_ad99_837e10ec3270.png","wfs_5_100e00cc_b781_4477_b3cc_5680f78d7921.png","wfs_6_0e501e10_2f0e_4017_b8d3_90f38a5848a4.png","wfs_7_14ef4679_7ed9_4413_bfe9_f8e6d2644f2c.png","wfs_8_125c738b_fcc2_4dd5_9da8_c7e1426202ad.png","wfs_9_a3baacf8_1c45_4c92_8e23_f47a03e7b559.png"],
              day_zero: 0,
              day_space: -7,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 57,
              hour_startY: 88,
              hour_array: ["0001.png","0002.png","0003.png","0004.png","0005.png","0006.png","0007.png","0008.png","0009.png","0010.png"],
              hour_zero: 1,
              hour_space: 0,
              hour_angle: 0,
              hour_align: hmUI.align.LEFT,

              minute_startX: 57,
              minute_startY: 234,
              minute_array: ["0001.png","0002.png","0003.png","0004.png","0005.png","0006.png","0007.png","0008.png","0009.png","0010.png"],
              minute_zero: 1,
              minute_space: 0,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              second_startX: 157,
              second_startY: 383,
              second_array: ["wfs_0_482ad812_d31d_4a07_a060_3e7ca079aab6.png","wfs_1_2f77404e_f357_448a_af59_09531db154b7.png","wfs_2_97b8da55_b4e7_41e5_81b8_10e567e5bf96.png","wfs_3_68d4f059_c6c2_4bf4_ad22_0927fee014a7.png","wfs_4_8e67f4f7_7f54_4121_ad99_837e10ec3270.png","wfs_5_100e00cc_b781_4477_b3cc_5680f78d7921.png","wfs_6_0e501e10_2f0e_4017_b8d3_90f38a5848a4.png","wfs_7_14ef4679_7ed9_4413_bfe9_f8e6d2644f2c.png","wfs_8_125c738b_fcc2_4dd5_9da8_c7e1426202ad.png","wfs_9_a3baacf8_1c45_4c92_8e23_f47a03e7b559.png"],
              second_zero: 1,
              second_space: -7,
              second_angle: 0,
              second_follow: 0,
              second_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });



            let screenType = hmSetting.getScreenType();
            //start of ignored block
            function text_update() {
              console.log('text_update()');

              console.log('update text rotate battery_BATTERY');
              let valueBattery = battery.current;
              let normal_battery_rotate_string = parseInt(valueBattery).toString();

              if (screenType != hmSetting.screen_type.AOD) {
                for (var i = 1; i < 3; i++) {  // hide all symbols
                  normal_battery_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                if (valueBattery != null && valueBattery != undefined && isFinite(valueBattery) && normal_battery_rotate_string.length > 0 && normal_battery_rotate_string.length <= 3) {  // display data if it was possible to get it
                  let img_offset = 0;
                  // alignment = CENTER_H
                  let normal_battery_TextRotate_posOffset = normal_battery_TextRotate_img_width * normal_battery_rotate_string.length;
                  img_offset -= normal_battery_TextRotate_posOffset/2;
                  // alignment end
                  
                  let index = 0;
                  for (let char of normal_battery_rotate_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 3) break;
                    if (charCode >= 0 && charCode < 10) { 
                      normal_battery_TextRotate[index].setProperty(hmUI.prop.POS_X, 413 + img_offset);
                      normal_battery_TextRotate[index].setProperty(hmUI.prop.SRC, normal_battery_TextRotate_ASCIIARRAY[charCode]);
                      normal_battery_TextRotate[index].setProperty(hmUI.prop.VISIBLE, true);
                      img_offset += normal_battery_TextRotate_img_width;
                      index++;
                    };  // end if digit
                  };  // end char of string
                }  // end isFinite

              };

            };

            //end of ignored block
            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                console.log('resume_call()');
                text_update();
              }),
            });

                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}