﻿    /*
    ** Watch_Face_Editor tool v 18.2
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        //const logger = Logger.getLogger('watchface_SashaCX75');
        const logger = DeviceRuntimeCore.HmLogger.getLogger('watchface_SashaCX75')
        //end of ignored block

        //dynamic modify start

        
        console.log('user_functions.js');
        // start user_functions.js

/////////////////////////////////////////////////////////////////////////////////
// User functions
/////////////////////////////////////////////////////////////////////////////////

// variables for languages
let displayedLangValue = 0; // default: en
let displayedLangCode = 'en';
let supportedLangCodes = ['en', 'es', 'fr', 'de','id', 'pl', 'it', 'pt', 'nl', 'tr', 'ro', 'cs', 'fi', 'nb', 'da', 'sv', 'hu', 'ms','sk'];

// translations are here for supported languages, only latin
let normal_DOW_Array_en = ['MON', 'TUE', 'WED', 'THU', 'FRI', 'SAT', 'SUN'];
let normal_DOW_Array_es = ['LUN', 'MAR', 'MIE', 'JUE', 'VIE', 'SAB', 'DOM'];
let normal_DOW_Array_fr = ['LUN', 'MAR', 'MER', 'JEU', 'VEN', 'SAM', 'DIM'];
let normal_DOW_Array_de = ['MON', 'DIE', 'MIT', 'DON', 'FRE', 'SAM', 'SON'];
let normal_DOW_Array_id = ['SEN', 'SEL', 'RAB', 'KAM', 'JUM', 'SAB', 'MIN'];
let normal_DOW_Array_pl = ['PON', 'WTO', 'ŚRO', 'CZW', 'PIĄ', 'SOB', 'NIE'];
let normal_DOW_Array_it = ['LUN', 'MAR', 'MER', 'GIO', 'VEN', 'SAB', 'DOM'];
let normal_DOW_Array_pt = ['SEG', 'TER', 'QUA', 'QUI', 'SEX', 'SAB', 'DOM'];
let normal_DOW_Array_nl = ['MAA', 'DIN', 'WOE', 'DON', 'VRI', 'ZAT', 'ZON'];
let normal_DOW_Array_tr = ['PAZ', 'SAL', 'ÇAR', 'PER', 'CUM', 'CUT', 'PAZ'];
let normal_DOW_Array_ro = ['LUN', 'MAR', 'MIE', 'JOI', 'VIN', 'SAM', 'DUM'];
let normal_DOW_Array_cs = ['PON', 'ÚTE', 'STŘ', 'ČTV', 'PÁT', 'SOB', 'NED'];
let normal_DOW_Array_fi = ['MAA', 'TII', 'KES', 'TOR', 'PER', 'LAU', 'SUN'];
let normal_DOW_Array_nb = ['MAN', 'TIR', 'ONS', 'TOR', 'FRE', 'LØR', 'SØN'];
let normal_DOW_Array_da = ['MAN', 'TIR', 'ONS', 'TOR', 'FRE', 'LØR', 'SØN'];
let normal_DOW_Array_sv = ['MÅN', 'TIS', 'ONS', 'TOR', 'FRE', 'LÖR', 'SÖN'];
let normal_DOW_Array_hu = ['HÉT', 'KED', 'SZE', 'CSÜ', 'PÉN', 'SZO', 'VAS'];
let normal_DOW_Array_ms = ['ISN', 'SEL', 'RAB', 'KHA', 'JUM', 'SAB', 'AHA'];
let normal_DOW_Array_sk = ['PON', 'UTO', 'STR', 'ŠTV', 'PIA', 'SOB', 'NED'];

let normal_Month_Array_en = ['JAN', 'FEB', 'MAR', 'APR', 'MAY', 'JUN', 'JUL', 'AUG', 'SEP', 'OCT', 'NOV', 'DEC', ];
let normal_Month_Array_es = ['ENE', 'FEB', 'MAR', 'ABR', 'MAY', 'JUN', 'JUL', 'AGO', 'SEP', 'OCT', 'NOV', 'DIC', ];
let normal_Month_Array_fr = ['JAN', 'FEV', 'MAR', 'AVR', 'MAI', 'JUN', 'JLT', 'AUT', 'SEP', 'OCT', 'NOV', 'DEC', ];
let normal_Month_Array_de = ['JAN', 'FEB', 'MAR', 'APR', 'MAI', 'JUN', 'JUL', 'AUG', 'SEP', 'OKT', 'NOV', 'DEZ', ];
let normal_Month_Array_id = ['JAN', 'FEB', 'MAR', 'APR', 'MEI', 'JUN', 'JUL', 'AGU', 'SEP', 'OKT', 'NOV', 'DES', ];
let normal_Month_Array_pl = ['STY', 'LUT', 'MAR', 'KWI', 'MAJ', 'CZE', 'LIP', 'SIE', 'WRZ', 'PAŹ', 'LIS', 'GRU', ];
let normal_Month_Array_it = ['GEN', 'FEB', 'MAR', 'APR', 'MAG', 'GIU', 'LUG', 'AGO', 'SET', 'OTT', 'NOV', 'DIC', ];
let normal_Month_Array_pt = ['JAN', 'FEV', 'MAR', 'ABR', 'MAI', 'JUN', 'JUL', 'AGO', 'SET', 'OUT', 'NOV', 'DEZ', ];
let normal_Month_Array_nl = ['JAN', 'FEB', 'MAA', 'APR', 'MEI', 'JUN', 'JUL', 'AUG', 'SEP', 'OKT', 'NOV', 'DEC', ];
let normal_Month_Array_tr = ['OCA', 'ŞUB', 'MAR', 'NIS', 'MAY', 'HAZ', 'TEM', 'AĞU', 'EYL', 'EKI', 'KAS', 'ARA', ];
let normal_Month_Array_ro = ['IAN', 'FEB', 'MAR', 'APR', 'MAI', 'IUN', 'IUL', 'AUG', 'SEP', 'OCT', 'NOI', 'DEC', ];
let normal_Month_Array_cs = ['LED', 'ÚNO', 'BŘE', 'DUB', 'KVĚ', 'ČVN', 'ČVC', 'SRP', 'ZÁŘ', 'ŘÍJ', 'LIS', 'PRO', ];
let normal_Month_Array_fi = ['TAM', 'HEL', 'MAA', 'HUH', 'TOU', 'KES', 'HEI', 'ELO', 'SYY', 'LOK', 'MAR', 'JOU', ];
let normal_Month_Array_nb = ['JAN', 'FEB', 'MAR', 'APR', 'MAI', 'JUN', 'JUL', 'AUG', 'SEP', 'OKT', 'NOV', 'DES', ];
let normal_Month_Array_da = ['JAN', 'FEB', 'MAR', 'APR', 'MAJ', 'JUN', 'JUL', 'AUG', 'SEP', 'OKT', 'NOV', 'DEC', ];
let normal_Month_Array_sv = ['JAN', 'FEB', 'MAR', 'APR', 'MAJ', 'JUN', 'JUL', 'AUG', 'SEP', 'OKT', 'NOV', 'DEC', ];
let normal_Month_Array_hu = ['JAN', 'FEB', 'MÁR', 'ÁPR', 'MÁJ', 'JÚN', 'JÚL', 'AUG', 'SZE', 'OKT', 'NOV', 'DEC', ];
let normal_Month_Array_ms = ['JÁN', 'FEB', 'MAC', 'APR', 'MEI', 'JUN', 'JUL', 'OGO', 'SEP', 'OKT', 'NOV', 'DIS', ];
let normal_Month_Array_sk = ['JAN', 'FEB', 'MAR', 'APR', 'MÁJ', 'JÚN', 'JÚL', 'AUG', 'SEP', 'OKT', 'NOV', 'DES', ];

// set default displayed language if supported by watchface, else english
// do not change order, cf https://docs.zepp.com/docs/v2/reference/related-resources/language-list/
let currentLangCode='en'
let zeppLangCodes = ['zh', 'zh', 'en', 'es', 'ru', 'ko', 'fr', 'de', 'id', 'pl', 'it', 'ja', 'th', 'ar', 'vi', 'pt', 'nl', 'tr', 'uk', 'iw', 'pt', 'ro', 'cs', 'el', 'sr', 'ca', 'fi', 'nb', 'da', 'sv', 'hu', 'ms', 'sk', 'hi'];
let currentLangValue = hmSetting.getLanguage();
if (currentLangValue <= zeppLangCodes.length-1)
	currentLangCode = zeppLangCodes[currentLangValue];
for(let i = 0; i < supportedLangCodes.length; i++) {
	if (supportedLangCodes[i]==currentLangCode) {
		displayedLangValue = i;
		displayedLangCode = supportedLangCodes[displayedLangValue];
		break;
	}
}

// switch displayed language
function switch_language() {
	if (displayedLangValue >= supportedLangCodes.length-1) {
		displayedLangValue=0;
	}
	else {
		displayedLangValue++;
	}
	displayedLangCode = supportedLangCodes[displayedLangValue];
	//hmUI.showToast({text: 'Language ' + displayedLangCode});	
	
	UpdateElementsDate();	
}

// hide/display flag
let flag_display = false;
function hide_flag() {
	flag_display = !flag_display;
	UpdateElementsFlag();	
}

// update displayed date language
function UpdateElementsDate(){	
	// day of week
	for(let i = 0; i < normal_DOW_Array.length; i++) {
		normal_DOW_Array[i]=eval('normal_DOW_Array_' + displayedLangCode + '[i]');		
	}
	normal_DOW_Str = normal_DOW_Array[timeSensor.week-1];
    normal_dow_text_font.setProperty(hmUI.prop.TEXT, normal_DOW_Str );	
	
	// month 
	for(let j = 0; j < normal_Month_Array.length; j++) {
		normal_Month_Array[j]=eval('normal_Month_Array_' + displayedLangCode + '[j]');		
	}
    normal_Month_Str = normal_Month_Array[timeSensor.month-1];
    normal_month_name_font.setProperty(hmUI.prop.TEXT, normal_Month_Str );		
	
	Button_3.setProperty(hmUI.prop.MORE, {
	  x: 351,
	  y: 262,
	  w: 90,
	  h: 90,
	  text: '',
	  color: 0xFFFF8C00,
	  text_size: 25,
	  press_src: 'flag_' + displayedLangCode + '.png',
	  normal_src: 'flag_' + displayedLangCode + '.png',
	  click_func: (button_widget) => {
		switch_language()
	  }, // end func
	  show_level: hmUI.show_level.ONLY_NORMAL
	})	// end Button_3
}

// update flag visibility
function UpdateElementsFlag() {
	Button_3.setProperty(hmUI.prop.VISIBLE, flag_display);
}

// switch displayed element
let displayedElement = 1 
function switch_info() {
	if (displayedElement >= 3) {
		displayedElement=1;
	}
	else {
		displayedElement++;
	}	
	UpdateElementsInfo();	
}

// update displayed element
function UpdateElementsInfo(){		
	normal_step_current_text_img.setProperty(hmUI.prop.VISIBLE, (displayedElement==1));
	normal_step_icon_img.setProperty(hmUI.prop.VISIBLE, (displayedElement==1));
	
	normal_heart_rate_text_text_img.setProperty(hmUI.prop.VISIBLE, (displayedElement==2));
	normal_heart_rate_icon_img.setProperty(hmUI.prop.VISIBLE, (displayedElement==2));
	
	normal_calorie_current_text_img.setProperty(hmUI.prop.VISIBLE, (displayedElement==3));
	normal_calorie_icon_img.setProperty(hmUI.prop.VISIBLE, (displayedElement==3));

	switch (displayedElement) {
	  case 1:
		normal_step_jumpable_img_click.setProperty(hmUI.prop.TYPE, hmUI.data_type.STEP);
		break;
	  case 2:
		normal_step_jumpable_img_click.setProperty(hmUI.prop.TYPE, hmUI.data_type.HEART);
		break;
	  case 3:
		normal_step_jumpable_img_click.setProperty(hmUI.prop.TYPE, hmUI.data_type.CAL);
		break;
	}	
}
	
/////////////////////////////
// end user functions	
////////////////////////////

        // end user_functions.js

        let normal_background_bg_img = ''
        let normal_heart_rate_icon_img = ''
        let normal_heart_rate_text_text_img = ''
        let normal_calorie_icon_img = ''
        let normal_calorie_current_text_img = ''
        let normal_step_icon_img = ''
        let normal_step_current_text_img = ''
        let normal_battery_text_text_img = ''
        let normal_battery_image_progress_img_level = ''
        let normal_weather_image_progress_img_level = ''
        let normal_temperature_current_text_img = ''
        let normal_system_disconnect_img = ''
        let normal_system_clock_img = ''
        let normal_month_name_font = ''
        let normal_Month_Array = ['JAN', 'FEB', 'MAR', 'APR', 'MAY', 'JUN', 'JLT', 'AUG', 'SEP', 'OCT', 'NOV', 'DEC', ];
        let normal_date_img_date_day = ''
        let normal_dow_text_font = ''
        let normal_DOW_Array = ['MON', 'TUE', 'WED', 'THU', 'FRI', 'SAT', 'SUN'];
        let normal_digital_clock_img_time = ''
        let normal_analog_clock_time_pointer_second = ''
        let idle_digital_clock_img_time = ''
        let normal_step_jumpable_img_click = ''
        let normal_battery_jumpable_img_click = ''
        let normal_temperature_jumpable_img_click = ''
        let normal_countdown_jumpable_img_click = ''
        let normal_stopwatch_jumpable_img_click = ''
        let normal_alarm_jumpable_img_click = ''
        let Button_1 = ''
        let Button_2 = ''
        let Button_3 = ''
        let Button_4 = ''
        let timeSensor = '';


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            // FontName: agencygothicct-light.ttf; FontSize: 90; Cache: full
            hmUI.createWidget(hmUI.widget.TEXT, {
              x: 464,
              y: 464,
              w: 108,
              h: 108,
              text_size: 90,
              char_space: 0,
              line_space: 0,
              font: 'fonts/agencygothicct-light.ttf',
              color: 0xFFF99F21,
              align_h: hmUI.align.LEFT,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.NONE,
              text: "0123456789 ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz АБВГДЕЁЖЗИЙКЛМНОПРСТУФХЦЧШЩЪЫЬЭЮЯабвгдеёжзийклмнопрстуфхцчшщъыьэюя  ҐЄІЇґєії _+-.,:;`'%°\\/",
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            console.log('Watch_Face.ScreenNormal');
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 466,
              h: 466,
              src: '0000.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 93,
              y: 341,
              src: 'ico_pulse.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 176,
              y: 337,
              font_array: ["0033.png","0034.png","0035.png","0036.png","0037.png","0038.png","0039.png","0040.png","0041.png","0042.png"],
              padding: false,
              h_space: 8,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_calorie_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 93,
              y: 341,
              src: 'ico_1.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_calorie_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 176,
              y: 337,
              font_array: ["0033.png","0034.png","0035.png","0036.png","0037.png","0038.png","0039.png","0040.png","0041.png","0042.png"],
              padding: false,
              h_space: 8,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 93,
              y: 341,
              src: 'step.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 176,
              y: 337,
              font_array: ["0033.png","0034.png","0035.png","0036.png","0037.png","0038.png","0039.png","0040.png","0041.png","0042.png"],
              padding: false,
              h_space: 8,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 45,
              y: 303,
              font_array: ["0043.png","0044.png","0045.png","0046.png","0047.png","0048.png","0049.png","0050.png","0051.png","0052.png"],
              padding: false,
              h_space: 4,
              unit_sc: '0055.png',
              unit_tc: '0055.png',
              unit_en: '0055.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 64,
              y: 166,
              image_array: ["b0093.png","b0094.png","b0095.png","b0096.png","b0097.png","b0098.png","b0099.png","b0100.png","b0101.png","b0102.png"],
              image_length: 10,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 374,
              y: 174,
              image_array: ["set_5_56x56_meteo_1.png","set_5_56x56_meteo_2.png","set_5_56x56_meteo_3.png","set_5_56x56_meteo_4.png","set_5_56x56_meteo_5.png","set_5_56x56_meteo_6.png","set_5_56x56_meteo_7.png","set_5_56x56_meteo_8.png","set_5_56x56_meteo_9.png","set_5_56x56_meteo_10.png","set_5_56x56_meteo_11.png","set_5_56x56_meteo_12.png","set_5_56x56_meteo_13.png","set_5_56x56_meteo_14.png","set_5_56x56_meteo_15.png","set_5_56x56_meteo_16.png","set_5_56x56_meteo_17.png","set_5_56x56_meteo_18.png","set_5_56x56_meteo_19.png","set_5_56x56_meteo_20.png","set_5_56x56_meteo_21.png","set_5_56x56_meteo_22.png","set_5_56x56_meteo_23.png","set_5_56x56_meteo_24.png","set_5_56x56_meteo_25.png","set_5_56x56_meteo_26.png","set_5_56x56_meteo_27.png","set_5_56x56_meteo_28.png","set_5_56x56_meteo_29.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 377,
              y: 231,
              font_array: ["0043.png","0044.png","0045.png","0046.png","0047.png","0048.png","0049.png","0050.png","0051.png","0052.png"],
              padding: false,
              h_space: 4,
              unit_sc: '0053.png',
              unit_tc: '0053.png',
              unit_en: '0053.png',
              negative_image: '0054.png',
              invalid_image: '0054.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 56,
              y: 120,
              src: 'bt_off.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 268,
              y: 284,
              src: '0058.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            if (!timeSensor) timeSensor = hmSensor.createSensor(hmSensor.id.TIME);
            timeSensor.addEventListener(timeSensor.event.DAYCHANGE, function() {
              time_update(true);
            });

            normal_month_name_font = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 272,
              y: 50,
              w: 150,
              h: 90,
              text_size: 90,
              char_space: 0,
              font: 'fonts/agencygothicct-light.ttf',
              color: 0xFFF99F21,
              line_space: 0,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.LEFT,
              // unit_string: JAN, FEB, MAR, APR, MAY, JUN, JLT, AUG, SEP, OCT, NOV, DEC,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 205,
              day_startY: 44,
              day_sc_array: ["0021.png","0022.png","0023.png","0024.png","0025.png","0026.png","0027.png","0028.png","0029.png","0030.png"],
              day_tc_array: ["0021.png","0022.png","0023.png","0024.png","0025.png","0026.png","0027.png","0028.png","0029.png","0030.png"],
              day_en_array: ["0021.png","0022.png","0023.png","0024.png","0025.png","0026.png","0027.png","0028.png","0029.png","0030.png"],
              day_zero: 1,
              day_space: 6,
              day_align: hmUI.align.LEFT,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_dow_text_font = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 83,
              y: 50,
              w: 118,
              h: 90,
              text_size: 90,
              char_space: 0,
              font: 'fonts/agencygothicct-light.ttf',
              color: 0xFFC0C0C0,
              line_space: 0,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.RIGHT,
              // unit_string: MON, TUE, WED, THU, FRI, SAT, SUN,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 116,
              hour_startY: 151,
              hour_array: ["0001.png","0002.png","0003.png","0004.png","0005.png","0006.png","0007.png","0008.png","0009.png","0010.png"],
              hour_zero: 1,
              hour_space: 22,
              hour_angle: 0,
              hour_align: hmUI.align.LEFT,

              minute_startX: 264,
              minute_startY: 153,
              minute_array: ["0011.png","0012.png","0013.png","0014.png","0015.png","0016.png","0017.png","0018.png","0019.png","0020.png"],
              minute_zero: 1,
              minute_space: 12,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              second_startX: 315,
              second_startY: 275,
              second_array: ["0043.png","0044.png","0045.png","0046.png","0047.png","0048.png","0049.png","0050.png","0051.png","0052.png"],
              second_zero: 1,
              second_space: 10,
              second_angle: 0,
              second_follow: 0,
              second_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_second = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              second_path: '0104.png',
              second_centerX: 233,
              second_centerY: 233,
              second_posX: 15,
              second_posY: 237,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            console.log('Watch_Face.ScreenAOD');

            idle_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 116,
              hour_startY: 151,
              hour_array: ["0001.png","0002.png","0003.png","0004.png","0005.png","0006.png","0007.png","0008.png","0009.png","0010.png"],
              hour_zero: 1,
              hour_space: 22,
              hour_angle: 0,
              hour_align: hmUI.align.LEFT,

              minute_startX: 264,
              minute_startY: 153,
              minute_array: ["0011.png","0012.png","0013.png","0014.png","0015.png","0016.png","0017.png","0018.png","0019.png","0020.png"],
              minute_zero: 1,
              minute_space: 12,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              second_startX: 315,
              second_startY: 275,
              second_array: ["0043.png","0044.png","0045.png","0046.png","0047.png","0048.png","0049.png","0050.png","0051.png","0052.png"],
              second_zero: 1,
              second_space: 10,
              second_angle: 0,
              second_follow: 0,
              second_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_AOD,
            });
            console.log('Watch_Face.Shortcuts');

            normal_step_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 174,
              y: 327,
              w: 185,
              h: 102,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 10,
              y: 150,
              w: 100,
              h: 162,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 359,
              y: 150,
              w: 100,
              h: 162,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_countdown_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 254,
              y: 150,
              w: 100,
              h: 121,
              type: hmUI.data_type.COUNT_DOWN,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_stopwatch_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 116,
              y: 150,
              w: 124,
              h: 162,
              type: hmUI.data_type.STOP_WATCH,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_alarm_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 254,
              y: 272,
              w: 100,
              h: 50,
              type: hmUI.data_type.ALARM_CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            console.log('Watch_Face.Buttons');
            Button_1 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 208,
              y: 25,
              w: 151,
              h: 120,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'BoutonTransparent.png',
              normal_src: 'BoutonTransparent.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'ScheduleCalScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_2 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 76,
              y: 315,
              w: 96,
              h: 120,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'BoutonTransparent.png',
              normal_src: 'BoutonTransparent.png',
              click_func: (button_widget) => {
                switch_info()
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_3 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 351,
              y: 262,
              w: 90,
              h: 90,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'flag_en.png',
              normal_src: 'flag_en.png',
              click_func: (button_widget) => {
                switch_language()
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_4 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 102,
              y: 25,
              w: 105,
              h: 120,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'BoutonTransparent.png',
              normal_src: 'BoutonTransparent.png',
              click_func: (button_widget) => {
                hide_flag()
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            console.log('user_script_end.js');
            // start user_script_end.js

UpdateElementsDate();
UpdateElementsInfo();
UpdateElementsFlag();	
            // end user_script_end.js

            let screenType = hmSetting.getScreenType();
            //#region time_update
            function time_update(updateHour = false, updateMinute = false) {
              console.log('time_update()');
              let hour = timeSensor.hour;
              let minute = timeSensor.minute;
              let second = timeSensor.second;
              let format_hour = timeSensor.format_hour;

              console.log('month font');
              if (updateHour) {
                let normal_Month_Str = normal_Month_Array[timeSensor.month-1];
                normal_month_name_font.setProperty(hmUI.prop.TEXT, normal_Month_Str );
              };

              console.log('day of week font');
              if (updateHour) {
                let normal_DOW_Str = normal_DOW_Array[timeSensor.week-1];
                normal_dow_text_font.setProperty(hmUI.prop.TEXT, normal_DOW_Str );
              };

            };

            //#endregion
            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                console.log('resume_call()');
                time_update(true, true);
              }),
            });

                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}