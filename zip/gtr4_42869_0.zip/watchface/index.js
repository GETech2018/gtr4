﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        const logger = Logger.getLogger('watchface_SashaCX75');
        //end of ignored block

        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_image_img = ''
        let normal_heart_rate_circle_scale = ''
        let normal_heart_rate_text_text_img = ''
        let normal_sun_current_text_img = ''
        let normal_moon_high_text_img = ''
        let normal_moon_image_progress_img_level = ''
        let normal_battery_text_text_img = ''
        let normal_distance_text_text_img = ''
        let normal_step_circle_scale = ''
        let normal_step_current_text_img = ''
        let normal_weather_image_progress_img_level = ''
        let normal_temperature_current_text_img = ''
        let normal_date_img_date_week_img = ''
        let normal_date_img_date_month = ''
        let normal_date_img_date_day = ''
        let normal_analog_clock_pro_second_pointer_img = ''
        let normal_timerUpdateSec = undefined;
        let normal_digital_clock_img_time_AmPm = ''
        let normal_digital_clock_img_time = ''
        let normal_system_dnd_img = ''
        let normal_system_disconnect_img = ''
        let normal_system_clock_img = ''
        let idle_background_bg = ''
        let idle_system_disconnect_img = ''
        let idle_system_clock_img = ''
        let idle_digital_clock_img_time_AmPm = ''
        let idle_digital_clock_img_time = ''
        let Button_1 = ''
        let Button_2 = ''
        let Button_3 = ''
        let Button_4 = ''
        let Button_5 = ''
        let Button_6 = ''
        let Button_7 = ''
        let timeSensor = '';

let colornumber_main = 1
let totalcolors_main = 20
let namecolor_main = ''

function click_Color() {
    if (colornumber_main >= totalcolors_main) {
        colornumber_main = 1;
    }
    else {
        colornumber_main = colornumber_main + 1;
    }


    normal_background_bg_img.setProperty(hmUI.prop.SRC, "bg" + parseInt(colornumber_main) + ".png");

}
        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            console.log('Watch_Face.ScreenNormal');
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 466,
              h: 466,
              src: 'bg2.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_image_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'themask.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_heart_circle_scale = hmUI.createWidget(hmUI.widget.Circle_Scale, {
              // center_x: 209,
              // center_y: 141,
              // start_angle: -180,
              // end_angle: 180,
              // radius: 28,
              // line_width: 10,
              // line_cap: Rounded,
              // color: 0xFF040404,
              // mirror: False,
              // inversion: True,
              // alpha: 255,
              // type: hmUI.data_type.HEART,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            let screenType = hmSetting.getScreenType();
            normal_heart_rate_circle_scale = hmUI.createWidget(hmUI.widget.ARC_PROGRESS, {
              center_x: 209,
              center_y: 141,
              start_angle: 180,
              end_angle: -180,
              radius: 23,
              line_width: 10,
              corner_flag: 0,
              color: 0xFF040404,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            
            const heart_rate = hmSensor.createSensor(hmSensor.id.HEART);
            heart_rate.addEventListener(hmSensor.event.CHANGE, function() {
              scale_call();
            });

            normal_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 240,
              y: 133,
              font_array: ["numsmall_00.png","numsmall_01.png","numsmall_02.png","numsmall_03.png","numsmall_04.png","numsmall_05.png","numsmall_06.png","numsmall_07.png","numsmall_08.png","numsmall_09.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'numsmall_bpm.png',
              unit_tc: 'numsmall_bpm.png',
              unit_en: 'numsmall_bpm.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sun_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 240,
              y: 74,
              font_array: ["numsmall_00.png","numsmall_01.png","numsmall_02.png","numsmall_03.png","numsmall_04.png","numsmall_05.png","numsmall_06.png","numsmall_07.png","numsmall_08.png","numsmall_09.png"],
              padding: false,
              h_space: 0,
              dot_image: 'numsmall_dots.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.SUN_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_moon_high_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 240,
              y: 26,
              font_array: ["numsmall_00.png","numsmall_01.png","numsmall_02.png","numsmall_03.png","numsmall_04.png","numsmall_05.png","numsmall_06.png","numsmall_07.png","numsmall_08.png","numsmall_09.png"],
              padding: false,
              h_space: 0,
              dot_image: 'numsmall_dots.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.MOON_RISE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_moon_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 195,
              y: 23,
              image_array: ["Moon_01.png","Moon_02.png","Moon_03.png","Moon_04.png","Moon_05.png","Moon_06.png","Moon_07.png","Moon_08.png","Moon_09.png","Moon_10.png","Moon_11.png","Moon_12.png","Moon_13.png","Moon_14.png","Moon_15.png","Moon_16.png","Moon_17.png","Moon_18.png","Moon_19.png","Moon_20.png","Moon_21.png","Moon_22.png","Moon_23.png","Moon_24.png","Moon_25.png","Moon_26.png","Moon_27.png","Moon_28.png","Moon_29.png","Moon_30.png"],
              image_length: 30,
              type: hmUI.data_type.MOON,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 240,
              y: 413,
              font_array: ["numsmall_00.png","numsmall_01.png","numsmall_02.png","numsmall_03.png","numsmall_04.png","numsmall_05.png","numsmall_06.png","numsmall_07.png","numsmall_08.png","numsmall_09.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'numsmall_batt.png',
              unit_tc: 'numsmall_batt.png',
              unit_en: 'numsmall_batt.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_distance_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 240,
              y: 363,
              font_array: ["numsmall_00.png","numsmall_01.png","numsmall_02.png","numsmall_03.png","numsmall_04.png","numsmall_05.png","numsmall_06.png","numsmall_07.png","numsmall_08.png","numsmall_09.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'numsmall_km.png',
              unit_tc: 'numsmall_km.png',
              unit_en: 'numsmall_km.png',
              imperial_unit_sc: 'numsmall_mi.png',
              imperial_unit_tc: 'numsmall_mi.png',
              imperial_unit_en: 'numsmall_mi.png',
              dot_image: 'numsmall_sep.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.DISTANCE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_step_circle_scale = hmUI.createWidget(hmUI.widget.Circle_Scale, {
              // center_x: 209,
              // center_y: 316,
              // start_angle: -180,
              // end_angle: 180,
              // radius: 28,
              // line_width: 10,
              // line_cap: Rounded,
              // color: 0xFF060606,
              // mirror: False,
              // inversion: True,
              // alpha: 255,
              // type: hmUI.data_type.STEP,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_step_circle_scale = hmUI.createWidget(hmUI.widget.ARC_PROGRESS, {
              center_x: 209,
              center_y: 316,
              start_angle: 180,
              end_angle: -180,
              radius: 23,
              line_width: 10,
              corner_flag: 0,
              color: 0xFF060606,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            
            const step = hmSensor.createSensor(hmSensor.id.STEP);
            step.addEventListener(hmSensor.event.CHANGE, function() {
              scale_call();
            });

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 240,
              y: 306,
              font_array: ["numsmall_00.png","numsmall_01.png","numsmall_02.png","numsmall_03.png","numsmall_04.png","numsmall_05.png","numsmall_06.png","numsmall_07.png","numsmall_08.png","numsmall_09.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 65,
              y: 70,
              image_array: ["0052.png","0053.png","0054.png","0055.png","0056.png","0057.png","0058.png","0059.png","0060.png","0061.png","0062.png","0063.png","0064.png","0065.png","0066.png","0067.png","0068.png","0069.png","0070.png","0071.png","0072.png","0073.png","0074.png","0075.png","0076.png","0077.png","0078.png","0079.png","0080.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 57,
              y: 131,
              font_array: ["numsm_00.png","numsm_01.png","numsm_02.png","numsm_03.png","numsm_04.png","numsm_05.png","numsm_06.png","numsm_07.png","numsm_08.png","numsm_09.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'numsm_tmp.png',
              unit_tc: 'numsm_tmp.png',
              unit_en: 'numsm_tmp.png',
              imperial_unit_sc: 'numsm_tmp.png',
              imperial_unit_tc: 'numsm_tmp.png',
              imperial_unit_en: 'numsm_tmp.png',
              negative_image: 'numsm_min.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            const temperatureUnit = hmSetting.getTemperatureUnit();
            //start of ignored block
            if (temperatureUnit == 1) {
              normal_temperature_current_text_img.setProperty(hmUI.prop.MORE, {
                x: 57,
                y: 131,
                font_array: ["numsm_00.png","numsm_01.png","numsm_02.png","numsm_03.png","numsm_04.png","numsm_05.png","numsm_06.png","numsm_07.png","numsm_08.png","numsm_09.png"],
                padding: false,
                h_space: 0,
                unit_sc: 'numsm_tmp.png',
                unit_tc: 'numsm_tmp.png',
                unit_en: 'numsm_tmp.png',
                imperial_unit_sc: 'numsm_tmp.png',
                imperial_unit_tc: 'numsm_tmp.png',
                imperial_unit_en: 'numsm_tmp.png',
                negative_image: 'numsm_min.png',
                align_h: hmUI.align.CENTER_H,
                type: hmUI.data_type.WEATHER_CURRENT,
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
            };
            //end of ignored block

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 58,
              y: 341,
              week_en: ["dw_00.png","dw_01.png","dw_02.png","dw_03.png","dw_04.png","dw_05.png","dw_06.png"],
              week_tc: ["dw_00.png","dw_01.png","dw_02.png","dw_03.png","dw_04.png","dw_05.png","dw_06.png"],
              week_sc: ["dw_00.png","dw_01.png","dw_02.png","dw_03.png","dw_04.png","dw_05.png","dw_06.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_month = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 101,
              month_startY: 315,
              month_sc_array: ["numsm_00.png","numsm_01.png","numsm_02.png","numsm_03.png","numsm_04.png","numsm_05.png","numsm_06.png","numsm_07.png","numsm_08.png","numsm_09.png"],
              month_tc_array: ["numsm_00.png","numsm_01.png","numsm_02.png","numsm_03.png","numsm_04.png","numsm_05.png","numsm_06.png","numsm_07.png","numsm_08.png","numsm_09.png"],
              month_en_array: ["numsm_00.png","numsm_01.png","numsm_02.png","numsm_03.png","numsm_04.png","numsm_05.png","numsm_06.png","numsm_07.png","numsm_08.png","numsm_09.png"],
              month_zero: 1,
              month_space: -3,
              month_align: hmUI.align.LEFT,
              month_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 55,
              day_startY: 315,
              day_sc_array: ["numsm_00.png","numsm_01.png","numsm_02.png","numsm_03.png","numsm_04.png","numsm_05.png","numsm_06.png","numsm_07.png","numsm_08.png","numsm_09.png"],
              day_tc_array: ["numsm_00.png","numsm_01.png","numsm_02.png","numsm_03.png","numsm_04.png","numsm_05.png","numsm_06.png","numsm_07.png","numsm_08.png","numsm_09.png"],
              day_en_array: ["numsm_00.png","numsm_01.png","numsm_02.png","numsm_03.png","numsm_04.png","numsm_05.png","numsm_06.png","numsm_07.png","numsm_08.png","numsm_09.png"],
              day_zero: 1,
              day_space: -3,
              day_unit_sc: 'numsm_dot.png',
              day_unit_tc: 'numsm_dot.png',
              day_unit_en: 'numsm_dot.png',
              day_align: hmUI.align.RIGHT,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            const deviceInfo = hmSetting.getDeviceInfo();
            if (!timeSensor) timeSensor = hmSensor.createSensor(hmSensor.id.TIME);
            // normal_analog_clock_pro_second_pointer_img = hmUI.createWidget(hmUI.widget.TIME_POINTER_PRO, {
              // src: 'hand_secs2.png',
              // center_x: 97,
              // center_y: 233,
              // x: 42,
              // y: 70,
              // start_angle: 0,
              // end_angle: 360,
              // type: hmUI.data_type.second,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });


            normal_analog_clock_pro_second_pointer_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: deviceInfo.width,
              h: deviceInfo.height,
              pos_x: 97 - 42,
              pos_y: 233 - 70,
              center_x: 97,
              center_y: 233,
              src: 'hand_secs2.png',
              angle: 0,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time_AmPm = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              am_x: 300,
              am_y: 214,
              am_sc_path: 'time_am.png',
              am_en_path: 'time_am.png',
              pm_x: 300,
              pm_y: 214,
              pm_sc_path: 'time_pm.png',
              pm_en_path: 'time_pm.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 39,
              hour_startY: 205,
              hour_array: ["numbl_00.png","numbl_01.png","numbl_02.png","numbl_03.png","numbl_04.png","numbl_05.png","numbl_06.png","numbl_07.png","numbl_08.png","numbl_09.png"],
              hour_zero: 1,
              hour_space: -2,
              hour_angle: 0,
              hour_align: hmUI.align.CENTER_H,

              minute_startX: 179,
              minute_startY: 207,
              minute_array: ["numw_00.png","numw_01.png","numw_02.png","numw_03.png","numw_04.png","numw_05.png","numw_06.png","numw_07.png","numw_08.png","numw_09.png"],
              minute_zero: 1,
              minute_space: -2,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_dnd_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 359,
              y: 251,
              src: 'status_dnd.png',
              type: hmUI.system_status.DISTURB,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 361,
              y: 232,
              src: 'status_nobt.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 360,
              y: 213,
              src: 'status_alarmon.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            console.log('Watch_Face.ScreenAOD');
            idle_background_bg = hmUI.createWidget(hmUI.widget.FILL_RECT, {
              x: 0,
              y: 0,
              w: 466,
              h: 466,
              color: '0xFF000000',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 361,
              y: 232,
              src: 'status_nobt.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 360,
              y: 213,
              src: 'status_alarmon.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time_AmPm = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              am_x: 300,
              am_y: 214,
              am_sc_path: 'time_am.png',
              am_en_path: 'time_am.png',
              pm_x: 300,
              pm_y: 214,
              pm_sc_path: 'time_pm.png',
              pm_en_path: 'time_pm.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 39,
              hour_startY: 205,
              hour_array: ["numw_00.png","numw_01.png","numw_02.png","numw_03.png","numw_04.png","numw_05.png","numw_06.png","numw_07.png","numw_08.png","numw_09.png"],
              hour_zero: 1,
              hour_space: -2,
              hour_angle: 0,
              hour_align: hmUI.align.CENTER_H,

              minute_startX: 179,
              minute_startY: 207,
              minute_array: ["numw_00.png","numw_01.png","numw_02.png","numw_03.png","numw_04.png","numw_05.png","numw_06.png","numw_07.png","numw_08.png","numw_09.png"],
              minute_zero: 1,
              minute_space: -2,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_AOD,
            });

            console.log('Watch_Face.Buttons');
            Button_1 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 44,
              y: 378,
              w: 97,
              h: 39,
              text: '',
              color: 0xFFFF8C00,
              text_size: 24,
              press_src: '_WFbyTRK88PL.png',
              normal_src: '_WFbyTRK88PL.png',
              click_func: (button_widget) => {
                click_Color();
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_2 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 53,
              y: 316,
              w: 86,
              h: 53,
              text: '',
              color: 0xFFFF8C00,
              text_size: 24,
              press_src: '_WFbyTRK88PL.png',
              normal_src: '_WFbyTRK88PL.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'ScheduleCalScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_3 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 53,
              y: 71,
              w: 86,
              h: 87,
              text: '',
              color: 0xFFFF8C00,
              text_size: 24,
              press_src: '_WFbyTRK88PL.png',
              normal_src: '_WFbyTRK88PL.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'WeatherScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_4 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 194,
              y: 25,
              w: 141,
              h: 68,
              text: '',
              color: 0xFFFF8C00,
              text_size: 24,
              press_src: '_WFbyTRK88PL.png',
              normal_src: '_WFbyTRK88PL.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'TideScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_5 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 194,
              y: 126,
              w: 141,
              h: 39,
              text: '',
              color: 0xFFFF8C00,
              text_size: 24,
              press_src: '_WFbyTRK88PL.png',
              normal_src: '_WFbyTRK88PL.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'heart_app_Screen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_6 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 194,
              y: 299,
              w: 141,
              h: 39,
              text: '',
              color: 0xFFFF8C00,
              text_size: 24,
              press_src: '_WFbyTRK88PL.png',
              normal_src: '_WFbyTRK88PL.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'activityAppScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_7 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 363,
              y: 215,
              w: 141,
              h: 39,
              text: '',
              color: 0xFFFF8C00,
              text_size: 24,
              press_src: '_WFbyTRK88PL.png',
              normal_src: '_WFbyTRK88PL.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'AlarmInfoScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            //start of ignored block
            function time_update(updateHour = false, updateMinute = false) {
              console.log('time_update()');
              let hour = timeSensor.hour;
              let minute = timeSensor.minute;
              let second = timeSensor.second;
              let format_hour = timeSensor.format_hour;

              let normal_fullAngle_second = 360;
              let normal_angle_second = 0 + normal_fullAngle_second*second/60;
              if (normal_analog_clock_pro_second_pointer_img) normal_analog_clock_pro_second_pointer_img.setProperty(hmUI.prop.ANGLE, normal_angle_second);

            };

            //end of ignored block
            function scale_call() {
              console.log('scale_call()');

                console.log('update scales HEART');
                
                let valueHeartRate = heart_rate.last;
                let targetHeartRate = 179;
                let progressHeartRate = (valueHeartRate - 71)/(targetHeartRate - 71);
                if (progressHeartRate < 0) progressHeartRate = 0;
                if (progressHeartRate > 1) progressHeartRate = 1;
                let progress_cs_normal_heart_rate = 1 - progressHeartRate;

                if (screenType != hmSetting.screen_type.AOD) {

                  // normal_heart_rate_circle_scale_circle_scale
                  let level = Math.round(progress_cs_normal_heart_rate * 100);
                  if (normal_heart_rate_circle_scale) {
                    normal_heart_rate_circle_scale.setProperty(hmUI.prop.MORE, {                      
                      center_x: 209,
                      center_y: 141,
                      start_angle: 180,
                      end_angle: -180,
                      radius: 23,
                      line_width: 10,
                      corner_flag: 0,
                      color: 0xFF040404,
                      show_level: hmUI.show_level.ONLY_NORMAL,
                      level: level,
                    });
                  };
                };

                console.log('update scales STEP');
                
                let valueStep = step.current;
                let targetStep = step.target;
                let progressStep = valueStep/targetStep;
                if (progressStep > 1) progressStep = 1;
                let progress_cs_normal_step = 1 - progressStep;

                if (screenType != hmSetting.screen_type.AOD) {

                  // normal_step_circle_scale_circle_scale
                  let level = Math.round(progress_cs_normal_step * 100);
                  if (normal_step_circle_scale) {
                    normal_step_circle_scale.setProperty(hmUI.prop.MORE, {                      
                      center_x: 209,
                      center_y: 316,
                      start_angle: 180,
                      end_angle: -180,
                      radius: 23,
                      line_width: 10,
                      corner_flag: 0,
                      color: 0xFF060606,
                      show_level: hmUI.show_level.ONLY_NORMAL,
                      level: level,
                    });
                  };
                };

            };

            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                console.log('resume_call()');
                scale_call();
                time_update(true, true);
                if (screenType == hmSetting.screen_type.WATCHFACE) {
                  if (!normal_timerUpdateSec) {
                    let animDelay = timeSensor.utc % 1000;
                    let animRepeat = 1000;
                    normal_timerUpdateSec = timer.createTimer(animDelay, animRepeat, (function (option) {
                      time_update(false, false);
                    }));  // end timer 
                  };  // end timer check
                };  // end screenType


              }),
              pause_call: (function () {
                console.log('pause_call()');
                if (normal_timerUpdateSec) {
                  timer.stopTimer(normal_timerUpdateSec);
                  normal_timerUpdateSec = undefined;
                }

              }),
            });

                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}