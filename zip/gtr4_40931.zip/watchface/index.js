﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        const logger = Logger.getLogger('watchface_SashaCX75');
        //end of ignored block

        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_frame_animation_1 = ''
        let normal_battery_icon_img = ''
        let normal_battery_text_text_img = ''
        let normal_battery_pointer_progress_img_pointer = ''
        let normal_fat_burning_icon_img = ''
        let normal_fat_burning_pointer_progress_img_pointer = ''
        let normal_fat_burning_current_text_img = ''
        let normal_stand_icon_img = ''
        let normal_stand_pointer_progress_img_pointer = ''
        let normal_stand_target_text_img = ''
        let normal_stand_current_text_img = ''
        let normal_heart_rate_icon_img = ''
        let normal_heart_rate_pointer_progress_img_pointer = ''
        let normal_heart_rate_text_text_img = ''
        let normal_calorie_icon_img = ''
        let normal_calorie_pointer_progress_img_pointer = ''
        let normal_calorie_current_text_img = ''
        let normal_step_icon_img = ''
        let normal_step_pointer_progress_img_pointer = ''
        let normal_step_current_text_img = ''
        let normal_date_img_date_week_img = ''
        let normal_date_img_date_day = ''
		let normal_analog_clock_pro_hour_pointer_img = "";
        let normal_analog_clock_pro_minute_pointer_img = "";
        let normal_analog_clock_pro_second_pointer_img = "";
        let normal_world_clock_pointer_img = "";
        let normal_timerUpdate = undefined;
        let normal_timerUpdateSec = undefined;
        let normal_pai_icon_img = ''
        let idle_background_bg_img = ''
		let idle_analog_clock_time_pointer_hour = "";
        let idle_analog_clock_time_pointer_minute = "";
        let idle_world_clock_pointer_img = "";
        let timeSensor = "";

        let wt_angle_delta = 360 / 24 / 60;
        let wt_current_angle = 0;
        let wt_target_angle = 0;
        let index = 0;
        let worldData = undefined;

        let timer_animate_seconds = undefined;
        let timer_animate_wt = undefined;
        let idle_date_img_date_week_img = ''
        let idle_date_img_date_day = ''
        let idle_pai_icon_img = ''
        let normal_step_jumpable_img_click = ''
        let normal_cal_jumpable_img_click = ''
        let normal_heart_jumpable_img_click = ''
        let normal_pai_jumpable_img_click = ''
        let normal_battery_jumpable_img_click = ''
        let normal_stand_jumpable_img_click = ''
        let normal_fatBurning_jumpable_img_click = ''
        let Button_1 = ''
        let Button_2 = ''
        let Button_3 = ''
		
		const { width: DEVICE_WIDTH, height: DEVICE_HEIGHT } = hmSetting.getDeviceInfo();
		
		let group1 = ''
		let group2 = ''
		let group3 = ''
		let group4 = ''
		let group5 = ''
		let group6 = ''
		
		let cc = 0
		
		let element_index = 0; 
        let element_count = 7;
		
		function click_PLUS() {
			element_index = (element_index + 1) % element_count;
			apply_content_switch();
		}
		
		function click_MINUS() {
			if (element_index == 0) {
			element_index = element_count - 1;
				} else {
			element_index = (element_index - 1) % element_count;
				}	
			apply_content_switch();
		}

		function apply_content_switch() {
			
			  normal_date_img_date_week_img.setProperty(hmUI.prop.VISIBLE, element_index == 0);
			  normal_date_img_date_day.setProperty(hmUI.prop.VISIBLE, element_index == 0);
			  Button_3.setProperty(hmUI.prop.VISIBLE, element_index == 0);

			  group6.setProperty(hmUI.prop.VISIBLE, element_index == 1);
			  normal_step_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, element_index == 1);

			  group5.setProperty(hmUI.prop.VISIBLE, element_index == 2);
			  normal_cal_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, element_index == 2);
			  
			  group4.setProperty(hmUI.prop.VISIBLE, element_index == 3);
			  normal_heart_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, element_index == 3);
			  
			  group3.setProperty(hmUI.prop.VISIBLE, element_index == 4);
			  normal_stand_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, element_index == 4);
			  
			  group2.setProperty(hmUI.prop.VISIBLE, element_index == 5);
			  normal_fatBurning_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, element_index == 5);
			  
			  group1.setProperty(hmUI.prop.VISIBLE, element_index == 6);
			  normal_battery_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, element_index == 6);
        };


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            console.log('Watch_Face.ScreenNormal');
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 466,
              h: 466,
              src: 'A100_025.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_frame_animation_1 = hmUI.createWidget(hmUI.widget.IMG_ANIM, {
              x: 55,
              y: 55,
              anim_path: "animation",
              anim_ext: "png",
              anim_prefix: "first_anim",
              anim_fps: 15,
              anim_size: 240,
              repeat_count: 0,
              anim_repeat: true,
              anim_status:hmUI.anim_status.START,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
			
			group1 = hmUI.createWidget(hmUI.widget.GROUP, {
	                  x: 0,
	                  y: 0,
	                  w: DEVICE_WIDTH,
	                  h: DEVICE_HEIGHT,
            });

            normal_battery_icon_img = group1.createWidget(hmUI.widget.IMG, {
              x: 144,
              y: 246,
              src: 'bat.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_text_img = group1.createWidget(hmUI.widget.TEXT_IMG, {
              x: 207,
              y: 345,
              font_array: ["A100_236.png","A100_237.png","A100_238.png","A100_239.png","A100_240.png","A100_241.png","A100_242.png","A100_243.png","A100_244.png","A100_245.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_pointer_progress_img_pointer = group1.createWidget(hmUI.widget.IMG_POINTER, {
              src: 'A100_309.png',
              center_x: 233,
              center_y: 335,
              x: 15,
              y: 53,
              start_angle: 0,
              end_angle: 360,
              invalid_visible: false,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
			
			const deviceInfo = hmSetting.getDeviceInfo();
			
			group2 = hmUI.createWidget(hmUI.widget.GROUP, {
	                  x: 0,
	                  y: 0,
	                  w: DEVICE_WIDTH,
	                  h: DEVICE_HEIGHT,
            });

            normal_fat_burning_icon_img = group2.createWidget(hmUI.widget.IMG, {
              x: 144,
              y: 246,
              src: 'fat.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_fat_burning_pointer_progress_img_pointer = group2.createWidget(hmUI.widget.IMG_POINTER, {
              src: 'A100_308.png',
              center_x: 233,
              center_y: 335,
              x: 9,
              y: 75,
              start_angle: 0,
              end_angle: 360,
              invalid_visible: false,
              type: hmUI.data_type.FAT_BURNING,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_fat_burning_current_text_img = group2.createWidget(hmUI.widget.TEXT_IMG, {
              x: 207,
              y: 320,
              font_array: ["A100_236.png","A100_237.png","A100_238.png","A100_239.png","A100_240.png","A100_241.png","A100_242.png","A100_243.png","A100_244.png","A100_245.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.FAT_BURNING,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
			
			group3 = hmUI.createWidget(hmUI.widget.GROUP, {
	                  x: 0,
	                  y: 0,
	                  w: DEVICE_WIDTH,
	                  h: DEVICE_HEIGHT,
            });

            normal_stand_icon_img = group3.createWidget(hmUI.widget.IMG, {
              x: 144,
              y: 246,
              src: 'stnd.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_stand_pointer_progress_img_pointer = group3.createWidget(hmUI.widget.IMG_POINTER, {
              src: 'A100_308.png',
              center_x: 233,
              center_y: 335,
              x: 9,
              y: 75,
              start_angle: 0,
              end_angle: 360,
              invalid_visible: false,
              type: hmUI.data_type.STAND,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_stand_target_text_img = group3.createWidget(hmUI.widget.TEXT_IMG, {
              x: 239,
              y: 319,
              font_array: ["A100_236.png","A100_237.png","A100_238.png","A100_239.png","A100_240.png","A100_241.png","A100_242.png","A100_243.png","A100_244.png","A100_245.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STAND_TARGET,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_stand_current_text_img = group3.createWidget(hmUI.widget.TEXT_IMG, {
              x: 155,
              y: 319,
              font_array: ["A100_236.png","A100_237.png","A100_238.png","A100_239.png","A100_240.png","A100_241.png","A100_242.png","A100_243.png","A100_244.png","A100_245.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'A100_248.png',
              unit_tc: 'A100_248.png',
              unit_en: 'A100_248.png',
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.STAND,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
			
			group4 = hmUI.createWidget(hmUI.widget.GROUP, {
	                  x: 0,
	                  y: 0,
	                  w: DEVICE_WIDTH,
	                  h: DEVICE_HEIGHT,
            });

            normal_heart_rate_icon_img = group4.createWidget(hmUI.widget.IMG, {
              x: 144,
              y: 246,
              src: 'bpm.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_pointer_progress_img_pointer = group4.createWidget(hmUI.widget.IMG_POINTER, {
              src: 'A100_308.png',
              center_x: 233,
              center_y: 335,
              x: 9,
              y: 75,
              start_angle: 0,
              end_angle: 360,
              invalid_visible: false,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_text_img = group4.createWidget(hmUI.widget.TEXT_IMG, {
              x: 207,
              y: 320,
              font_array: ["A100_236.png","A100_237.png","A100_238.png","A100_239.png","A100_240.png","A100_241.png","A100_242.png","A100_243.png","A100_244.png","A100_245.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
			
			group5 = hmUI.createWidget(hmUI.widget.GROUP, {
	                  x: 0,
	                  y: 0,
	                  w: DEVICE_WIDTH,
	                  h: DEVICE_HEIGHT,
            });

            normal_calorie_icon_img = group5.createWidget(hmUI.widget.IMG, {
              x: 144,
              y: 246,
              src: 'cal.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_calorie_pointer_progress_img_pointer = group5.createWidget(hmUI.widget.IMG_POINTER, {
              src: 'A100_308.png',
              center_x: 233,
              center_y: 335,
              x: 9,
              y: 75,
              start_angle: -132,
              end_angle: 132,
              invalid_visible: false,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_calorie_current_text_img = group5.createWidget(hmUI.widget.TEXT_IMG, {
              x: 198,
              y: 319,
              font_array: ["A100_236.png","A100_237.png","A100_238.png","A100_239.png","A100_240.png","A100_241.png","A100_242.png","A100_243.png","A100_244.png","A100_245.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
			
			group6 = hmUI.createWidget(hmUI.widget.GROUP, {
	                  x: 0,
	                  y: 0,
	                  w: DEVICE_WIDTH,
	                  h: DEVICE_HEIGHT,
            });

            normal_step_icon_img = group6.createWidget(hmUI.widget.IMG, {
              x: 144,
              y: 246,
              src: 'stp.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_pointer_progress_img_pointer = group6.createWidget(hmUI.widget.IMG_POINTER, {
              src: 'A100_308.png',
              center_x: 233,
              center_y: 335,
              x: 9,
              y: 75,
              start_angle: -132,
              end_angle: 132,
              invalid_visible: false,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_text_img = group6.createWidget(hmUI.widget.TEXT_IMG, {
              x: 189,
              y: 319,
              font_array: ["A100_236.png","A100_237.png","A100_238.png","A100_239.png","A100_240.png","A100_241.png","A100_242.png","A100_243.png","A100_244.png","A100_245.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 144,
              y: 246,
              week_en: ["week_1.png","week_2.png","week_3.png","week_4.png","week_5.png","week_6.png","week_7.png"],
              week_tc: ["week_1.png","week_2.png","week_3.png","week_4.png","week_5.png","week_6.png","week_7.png"],
              week_sc: ["week_1.png","week_2.png","week_3.png","week_4.png","week_5.png","week_6.png","week_7.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 214,
              day_startY: 314,
              day_sc_array: ["A100_225.png","A100_226.png","A100_227.png","A100_228.png","A100_229.png","A100_230.png","A100_231.png","A100_232.png","A100_233.png","A100_234.png"],
              day_tc_array: ["A100_225.png","A100_226.png","A100_227.png","A100_228.png","A100_229.png","A100_230.png","A100_231.png","A100_232.png","A100_233.png","A100_234.png"],
              day_en_array: ["A100_225.png","A100_226.png","A100_227.png","A100_228.png","A100_229.png","A100_230.png","A100_231.png","A100_232.png","A100_233.png","A100_234.png"],
              day_zero: 1,
              day_space: 0,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_pai_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 162,
              y: 90,
              src: 'logo.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
			
			const world_clock = hmSensor.createSensor(hmSensor.id.WORLD_CLOCK);
            world_clock.init();
            if (hmFS.SysProGetInt("SEIKO_wt_index")) index = hmFS.SysProGetInt("SEIKO_wt_index");

            if (!timeSensor) timeSensor = hmSensor.createSensor(hmSensor.id.TIME);
            timeSensor.addEventListener(timeSensor.event.MINUTEEND, function () {
              time_update(true, true);
            });
			
			normal_world_clock_pointer_img = hmUI.createWidget(hmUI.widget.IMG, {
          x: 0,
          y: 0,
          w: deviceInfo.width,
          h: deviceInfo.height,
          pos_x: 233 - 7,
          pos_y: 233 - 213,
          center_x: 233,
          center_y: 233,
          src: "wt.png",
          angle: 0,
          show_level: hmUI.show_level.ONLY_NORMAL,
        });

        normal_analog_clock_pro_hour_pointer_img = hmUI.createWidget(hmUI.widget.IMG, {
          x: 0,
          y: 0,
          w: deviceInfo.width,
          h: deviceInfo.height,
          pos_x: 233 - 33,
          pos_y: 233 - 233,
          center_x: 233,
          center_y: 233,
          src: "A100_003.png",
          angle: 0,
          show_level: hmUI.show_level.ONLY_NORMAL,
        });

        normal_analog_clock_pro_minute_pointer_img = hmUI.createWidget(hmUI.widget.IMG, {
          x: 0,
          y: 0,
          w: deviceInfo.width,
          h: deviceInfo.height,
          pos_x: 233 - 33,
          pos_y: 233 - 233,
          center_x: 233,
          center_y: 233,
          src: "A100_005.png",
          angle: 0,
          show_level: hmUI.show_level.ONLY_NORMAL,
        });

        normal_analog_clock_pro_second_pointer_img = hmUI.createWidget(hmUI.widget.IMG, {
          x: 0,
          y: 0,
          w: deviceInfo.width,
          h: deviceInfo.height,
          pos_x: 233 - 26,
          pos_y: 233 - 233,
          center_x: 233,
          center_y: 233,
          src: "A100_007.png",
          angle: 0,
          show_level: hmUI.show_level.ONLY_NORMAL,
        });

        let screenType = hmSetting.getScreenType();


            console.log('Watch_Face.ScreenAOD');
            idle_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 466,
              h: 466,
              src: 'A100_026.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });
			
			idle_pai_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 162,
              y: 90,
              src: 'logo.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });
			
			idle_world_clock_pointer_img = hmUI.createWidget(hmUI.widget.IMG, {
          x: 0,
          y: 0,
          w: deviceInfo.width,
          h: deviceInfo.height,
          pos_x: 233 - 7,
          pos_y: 233 - 213,
          center_x: 233,
          center_y: 233,
          src: "wt.png",
          angle: 0,
          show_level: hmUI.show_level.ONLY_AOD,
        });

        idle_analog_clock_time_pointer_hour = hmUI.createWidget(hmUI.widget.IMG, {
          x: 0,
          y: 0,
          w: deviceInfo.width,
          h: deviceInfo.height,
          pos_x: 233 - 33,
          pos_y: 233 - 233,
          center_x: 233,
          center_y: 233,
          src: "A100_003.png",
          angle: 0,
          show_level: hmUI.show_level.ONLY_AOD,
        });

        idle_analog_clock_time_pointer_minute = hmUI.createWidget(hmUI.widget.IMG, {
          x: 0,
          y: 0,
          w: deviceInfo.width,
          h: deviceInfo.height,
          pos_x: 233 - 33,
          pos_y: 233 - 233,
          center_x: 233,
          center_y: 233,
          src: "A100_005.png",
          angle: 0,
          show_level: hmUI.show_level.ONLY_AOD,
        });

            idle_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 144,
              y: 246,
              week_en: ["A100_266.png","A100_267.png","A100_268.png","A100_269.png","A100_270.png","A100_271.png","A100_272.png"],
              week_tc: ["A100_266.png","A100_267.png","A100_268.png","A100_269.png","A100_270.png","A100_271.png","A100_272.png"],
              week_sc: ["A100_266.png","A100_267.png","A100_268.png","A100_269.png","A100_270.png","A100_271.png","A100_272.png"],
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 214,
              day_startY: 314,
              day_sc_array: ["A100_225.png","A100_226.png","A100_227.png","A100_228.png","A100_229.png","A100_230.png","A100_231.png","A100_232.png","A100_233.png","A100_234.png"],
              day_tc_array: ["A100_225.png","A100_226.png","A100_227.png","A100_228.png","A100_229.png","A100_230.png","A100_231.png","A100_232.png","A100_233.png","A100_234.png"],
              day_en_array: ["A100_225.png","A100_226.png","A100_227.png","A100_228.png","A100_229.png","A100_230.png","A100_231.png","A100_232.png","A100_233.png","A100_234.png"],
              day_zero: 1,
              day_space: 0,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_AOD,
            });
            console.log('Watch_Face.Shortcuts');

            normal_step_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 195,
              y: 290,
              w: 85,
              h: 85,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_cal_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 195,
              y: 290,
              w: 85,
              h: 85,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 195,
              y: 290,
              w: 85,
              h: 85,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            let gmtButton = hmUI.createWidget(hmUI.widget.BUTTON, {
          x: 197, // x coordinate of the button
          y: 197, // y coordinate of the button
          text: "",
          w: 75, // button width
          h: 75, // button height
          normal_src: "Empty.png", // transparent image
          press_src: "Empty.png", // transparent image
          show_level: hmUI.show_level.ONLY_NORMAL,
          click_func: () => {
            gmtButtonClick();
          },
        });

            normal_battery_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 195,
              y: 290,
              w: 85,
              h: 85,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_stand_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 195,
              y: 290,
              w: 85,
              h: 85,
              type: hmUI.data_type.STAND,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_fatBurning_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 195,
              y: 290,
              w: 85,
              h: 85,
              type: hmUI.data_type.FAT_BURNING,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            console.log('Watch_Face.Buttons');
            Button_1 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 350,
              y: 290,
              w: 75,
              h: 75,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'Empty.png',
              normal_src: 'Empty.png',
              click_func: (button_widget) => {
                click_PLUS();
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_2 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 40,
              y: 290,
              w: 75,
              h: 75,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'Empty.png',
              normal_src: 'Empty.png',
              click_func: (button_widget) => {
                click_MINUS();
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_3 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 195,
              y: 290,
              w: 85,
              h: 85,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'Empty.png',
              normal_src: 'Empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'ScheduleCalScreen', native: true });
              }, // end func
              longpress_func: (button_widget) => {
                hmApp.startApp({url: 'todoListScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button
			
			if (cc ==0 ){
			  
			  group6.setProperty(hmUI.prop.VISIBLE, false);
			  normal_step_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, false);
			  
			  group5.setProperty(hmUI.prop.VISIBLE, false);
			  normal_cal_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, false);

              group4.setProperty(hmUI.prop.VISIBLE, false);
			  normal_heart_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, false);
			  
			  group3.setProperty(hmUI.prop.VISIBLE, false);
			  normal_stand_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, false);
			  
			  group2.setProperty(hmUI.prop.VISIBLE, false);
			  normal_fatBurning_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, false);
			  
			  group1.setProperty(hmUI.prop.VISIBLE, false);
			  normal_battery_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, false);
			cc = 1;
			}
			
			function time_update(updateHour = false, updateMinute = false) {
          let hour = timeSensor.hour;
          let minute = timeSensor.minute;
          let second = timeSensor.second;

          if (updateHour) {
            let normal_hour = hour;
            let normal_fullAngle_hour = 360;
            if (normal_hour > 11) normal_hour -= 12;
            let normal_angle_hour = 0 + (normal_fullAngle_hour * normal_hour) / 12 + ((normal_fullAngle_hour / 12) * minute) / 60;

            // normal
            if (normal_analog_clock_pro_hour_pointer_img) normal_analog_clock_pro_hour_pointer_img.setProperty(hmUI.prop.ANGLE, normal_angle_hour);
            // aod
            if (idle_analog_clock_time_pointer_hour) idle_analog_clock_time_pointer_hour.setProperty(hmUI.prop.ANGLE, normal_angle_hour);
          }

          if (updateMinute) {
            let normal_fullAngle_minute = 360;
            let normal_angle_minute = 0 + (normal_fullAngle_minute * (minute + second / 60)) / 60;

            // normal
            if (normal_analog_clock_pro_minute_pointer_img) normal_analog_clock_pro_minute_pointer_img.setProperty(hmUI.prop.ANGLE, normal_angle_minute);
            // aod
            if (idle_analog_clock_time_pointer_minute) idle_analog_clock_time_pointer_minute.setProperty(hmUI.prop.ANGLE, normal_angle_minute);

            // gmt
            worldData = getWorldData(index);
            update_world_clock(false);
          }
        }

        let lastAngleSeconds = 0;
        let second_current_angle = 0;

        function time_update_sec() {
          // start timer
          second_current_angle = getSecondsNormalAngle(timeSensor.second - 1);
          lastAngleSeconds = getSecondsNormalAngle(timeSensor.second);
          setSeconds(second_current_angle);

          if (!timer_animate_seconds) {
            timer_animate_seconds = timer.createTimer(30, 30, function (option) {
              animate_seconds();
            });
          }
        }

        function animate_seconds() {
          second_current_angle += 360 / 60 / 3;

          setSeconds(second_current_angle);

          if (timer_animate_seconds && second_current_angle == lastAngleSeconds) {
            timer.stopTimer(timer_animate_seconds);
            timer_animate_seconds = undefined;

            lastAngleSeconds = second_current_angle;
          }
        }

        function setSeconds(angle) {
          if (normal_analog_clock_pro_second_pointer_img) normal_analog_clock_pro_second_pointer_img.setProperty(hmUI.prop.ANGLE, angle);
        }

        function getSecondsNormalAngle(second) {
          let normal_fullAngle_second = 360;
          let normal_angle_second = 0 + (normal_fullAngle_second * second) / 60;

          return normal_angle_second;
        }

        function gmtButtonClick() {
          let count = world_clock.getWorldClockCount();

          index++;
          if (index == count) index = 0;

          hmFS.SysProSetInt("SEIKO_wt_index", index);

          worldData = getWorldData(index);
          if (worldData) hmUI.showToast({ text: worldData.city + " (" + (index + 1) + "/" + count + ")" });
          update_world_clock();
        }

        function getWorldData(idx) {
          let count = world_clock.getWorldClockCount();
          let data = undefined;

          if (idx >= count) idx = 0;
          if (count > 0 && idx < count) data = world_clock.getWorldClockInfo(idx);

          return data;
        }

        function update_world_clock(animate = true) {
          if (worldData) {
            if (normal_world_clock_pointer_img) normal_world_clock_pointer_img.setProperty(hmUI.prop.VISIBLE, true);
            if (idle_world_clock_pointer_img) idle_world_clock_pointer_img.setProperty(hmUI.prop.VISIBLE, true);
            wt_target_angle = (worldData.hour * 60 + worldData.minute) * wt_angle_delta;

            if (animate) {
              if (!timer_animate_wt) {
                timer_animate_wt = timer.createTimer(0, 30, function (option) {
                  animate_wt();
                });
              }
            } else {
              wt_current_angle = wt_target_angle;
              set_wt(wt_target_angle);
            }
          } else {
            if (normal_world_clock_pointer_img) normal_world_clock_pointer_img.setProperty(hmUI.prop.VISIBLE, false);
            if (idle_world_clock_pointer_img) idle_world_clock_pointer_img.setProperty(hmUI.prop.VISIBLE, false);
          }
        }
		
		function valuesAreClose(firstValue, secondValue, tolerance = 10) {
          return Math.abs(firstValue - secondValue) <= tolerance;
        }

        function animate_wt() {
          let da = wt_current_angle > wt_target_angle ? -3 : 3;
          wt_current_angle += da;
          if (wt_current_angle >= 360) wt_current_angle = wt_current_angle - 360;
          if (valuesAreClose(wt_current_angle, wt_target_angle, 4)) wt_current_angle = wt_target_angle;

          set_wt(wt_current_angle);

          if (timer_animate_wt && wt_current_angle == wt_target_angle) {
            timer.stopTimer(timer_animate_wt);
            timer_animate_wt = undefined;
          }
        }

        function set_wt(angle) {
          if (normal_world_clock_pointer_img) normal_world_clock_pointer_img.setProperty(hmUI.prop.ANGLE, angle);
          if (idle_world_clock_pointer_img) idle_world_clock_pointer_img.setProperty(hmUI.prop.ANGLE, angle);
        }

            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                console.log('resume_call()');
				worldData = getWorldData(index);
            time_update(true, true);
            // init seconds arrow angle
            second_current_angle = getSecondsNormalAngle(timeSensor.second - 1);
            lastAngleSeconds = getSecondsNormalAngle(timeSensor.second);
            setSeconds(second_current_angle);

            if (screenType == hmSetting.screen_type.WATCHFACE) {
              if (!normal_timerUpdate) {
                let animDelay = timeSensor.utc % 1000;
                let animRepeat = 1000;
                normal_timerUpdate = timer.createTimer(animDelay, animRepeat, function (option) {
                  time_update(false, false);
                }); // end timer
              } // end timer check
            } // end screenType
            if (screenType == hmSetting.screen_type.WATCHFACE) {
              if (!normal_timerUpdateSec) {
                normal_timerUpdateSec = timer.createTimer(0, 1000, function (option) {
                  time_update_sec();
                }); // end timer
              } // end timer check
            } // end screenType
                normal_frame_animation_1.setProperty(hmUI.prop.ANIM_STATUS,hmUI.anim_status.START);

              }),
              pause_call: (function () {
                console.log('pause_call()');
				if (normal_timerUpdateSec) {
              timer.stopTimer(normal_timerUpdateSec);
              normal_timerUpdateSec = undefined;
            }
                normal_frame_animation_1.setProperty(hmUI.prop.ANIM_STATUS,hmUI.anim_status.STOP);

              }),
            });

                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}