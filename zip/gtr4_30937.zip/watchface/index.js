﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.0.1
    ** Copyright © CashaCX75. All Rights Reserved
    */

    try {
    (()=>{
        //dynamic modify start


        let normal_background_bg_img = ''
        let normal_moon_image_progress_img_level = ''
        let normal_temperature_icon_img = ''
        let normal_temperature_current_text_img = ''
        let normal_weather_image_progress_img_level = ''
        let normal_calorie_current_text_img = ''
        let normal_heart_rate_text_text_img = ''
        let normal_distance_text_text_img = ''
        let normal_step_current_text_img = ''
        let normal_date_img_date_month_img = ''
        let normal_date_img_date_day = ''
        let normal_date_img_date_week_img = ''
        let normal_system_disconnect_img = ''
        let normal_system_clock_img = ''
        let normal_battery_pointer_progress_img_pointer = ''
        let normal_battery_text_text_img = ''
        let normal_digital_clock_img_time_AmPm = ''
        let normal_digital_clock_img_time = ''
        let normal_digital_clock_hour_separator_img = ''
        let normal_analog_clock_time_pointer_hour = ''
        let normal_analog_clock_time_pointer_minute = ''
        let normal_analog_clock_time_pointer_second = ''
        let normal_sunrise_jumpable_img_click = ''
        let normal_temperature_jumpable_img_click = ''
        let normal_heart_jumpable_img_click = ''
        let normal_step_jumpable_img_click = ''
        let idle_background_bg_img = ''
        let idle_system_disconnect_img = ''
        let idle_system_clock_img = ''
        let idle_battery_pointer_progress_img_pointer = ''
        let idle_battery_text_text_img = ''
        let idle_analog_clock_time_pointer_hour = ''
        let idle_analog_clock_time_pointer_minute = ''

        //vibrate (add destroy at end)
        const vibrate = hmSensor.createSensor(hmSensor.id.VIBRATE)
        function click_Vibrate() {
           vibrate.stop()
           vibrate.scene = 25
           vibrate.start()
        }

        //hands postitions
        let hourx = 24
        let houry = 198
        let minutex = 24
        let minutey = 207
        let secondx = 26
        let secondy = 241

        //Secondhand switch pointer-ball
        let btnsec = ''
        let lsecond = false

        function click_Second() {
            click_Vibrate();
            if (lsecond) {
            secondx=26;
            secondy=241;
            lsecond=false;
            } else {
            secondx=6;
            secondy=228;
            lsecond=true;
            }

            if (!lsecond) {hmUI.showToast({text: "Pointer"});};
            if (lsecond) {hmUI.showToast({text: "Ball"});};

            //call hands function to update hands
            call_change_Hands(colornumber);
        }

        // Start color change
        let btncolor = ''
        let colornumber = 2
        let totalcolors = 5

        function click_Color() {
            colornumber=(colornumber+1) % (totalcolors+1);
            click_Vibrate();
            hmUI.showToast({text: "Handscolor " + parseInt(colornumber) });

            //call hands function to change to correct hands
            call_change_Hands(colornumber);
        }

        // Give handsnumber. Must exist
        function call_change_Hands(handsnumber) {
           switch (handsnumber) {
               case 1:
                  hourstring='hour1.png';
                  minutestring='minute1.png';
                  if (!lsecond) {secondstring='sec1.png';} else {secondstring='secr1.png';}; break;
               case 2:
                  hourstring='hour2.png';
                  minutestring='minute2.png';
                  if (!lsecond) {secondstring='sec2.png';} else {secondstring='secr2.png';}; break;
               case 3:
                  hourstring='hour3.png';
                  minutestring='minute3.png';
                  if (!lsecond) {secondstring='sec3.png';} else {secondstring='secr3.png';}; break;
               case 4:
                  hourstring='hour4.png';
                  minutestring='minute4.png';
                  if (!lsecond) {secondstring='sec4.png';} else {secondstring='secr4.png';}; break;
               case 5:
                  hourstring='hour5.png';
                  minutestring='minute5.png';
                  if (!lsecond) {secondstring='sec5.png';} else {secondstring='secr5.png';}; break;;
               default:
                  hourstring='hour0.png';
                  minutestring='minute0.png';
                  if (!lsecond) {secondstring='sec0.png';} else {secondstring='secr0.png';}; break;
             }

             normal_analog_clock_time_pointer_hour.setProperty(hmUI.prop.MORE, {
             hour_path: hourstring,
             hour_centerX: 233,
             hour_centerY: 233,
             hour_posX: hourx,
             hour_posY: houry,
             show_level: hmUI.show_level.ONLY_NORMAL,
             });

             normal_analog_clock_time_pointer_minute.setProperty(hmUI.prop.MORE, {
             minute_path: minutestring,
             minute_centerX: 233,
             minute_centerY: 233,
             minute_posX: minutex,
             minute_posY: minutey,
             show_level: hmUI.show_level.ONLY_NORMAL,
             });

             normal_analog_clock_time_pointer_second.setProperty(hmUI.prop.MORE, {
             second_path: secondstring,
             second_centerX: 233,
             second_centerY: 233,
             second_posX: secondx,
             second_posY: secondy,
             second_cover_path: 'timedop.png',
             second_cover_x: 200,
             second_cover_y: 199,
             show_level: hmUI.show_level.ONLY_NORMAL,
             });
        }

        // Start brightness change
        let btnbackground = ''
        let backgroundnumber = 2
        let totalbackgrounds = 3

        function click_Background() {
            backgroundnumber=(backgroundnumber+1) % (totalbackgrounds+1);
            if (backgroundnumber==0) { backgroundnumber=1; }; //0 does not exist
            click_Vibrate();
            hmUI.showToast({text: "Brightness " + parseInt(backgroundnumber) });

            normal_background_bg_img.setProperty(hmUI.prop.SRC, "background" + parseInt(backgroundnumber) + ".png");
        }

        //languages (initialize in start init_view)
        let monthArray = null
        let dayArray = null
        let ln = 0
        let btnlanguage = ''
        let languagenumber = 0
        let totallanguages = 3
        let langchange = false

        function click_Language() {
            languagenumber=(languagenumber+1) % (totallanguages+1);
            click_Vibrate();
            showlanguageonscreen();

            call_change_Language(languagenumber);

            normal_date_img_date_month_img.setProperty(hmUI.prop.MORE, {
              month_startX: 141,
              month_startY: 113,
              month_sc_array: monthArray,
              month_tc_array: monthArray,
              month_en_array: monthArray,
              month_is_character: true ,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            normal_date_img_date_week_img.setProperty(hmUI.prop.MORE, {
              x: 100,
              y: 78,
              week_en: DayArray,
              week_tc: DayArray,
              week_sc: DayArray,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            //langchange will not work without going out of the screen.
            langchange=true;
            const result = hmSetting.setScreenOff();
        }

        function showlanguageonscreen() {
              if(languagenumber==0) hmUI.showToast({text: 'English'});
              if(languagenumber==1) hmUI.showToast({text: 'Dutch'});
              if(languagenumber==2) hmUI.showToast({text: 'Spanish'});
              if(languagenumber==3) hmUI.showToast({text: 'Polish'});
        }

        function call_change_Language(ln) {
            monthArray=null;dayArray=null;
            monthArray = ["month" + parseInt(ln) + "_0.png",
                          "month" + parseInt(ln) + "_1.png",
                          "month" + parseInt(ln) + "_2.png",
                          "month" + parseInt(ln) + "_3.png",
                          "month" + parseInt(ln) + "_4.png",
                          "month" + parseInt(ln) + "_5.png",
                          "month" + parseInt(ln) + "_6.png",
                          "month" + parseInt(ln) + "_7.png",
                          "month" + parseInt(ln) + "_8.png",
                          "month" + parseInt(ln) + "_9.png",
                          "month" + parseInt(ln) + "_10.png",
                          "month" + parseInt(ln) + "_11.png"]
            DayArray = ["day" + parseInt(ln) + "_0.png",
                        "day" + parseInt(ln) + "_1.png",
                        "day" + parseInt(ln) + "_2.png",
                        "day" + parseInt(ln) + "_3.png",
                        "day" + parseInt(ln) + "_4.png",
                        "day" + parseInt(ln) + "_5.png",
                        "day" + parseInt(ln) + "_6.png"]
        }

        // Option change
        let btnoption = ''
        let optionnumber = 0
        let totaloptions = 4

        function click_Option() {
            optionnumber=(optionnumber+1) % (totaloptions+1);
            click_Vibrate();
            switch (optionnumber) {
               case 1:
                      normal_moon_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, true); break;
               case 2:
                      normal_digital_clock_img_time_AmPm.setProperty(hmUI.prop.VISIBLE, false);
                      normal_digital_clock_img_time.setProperty(hmUI.prop.VISIBLE, false);
                      normal_digital_clock_hour_separator_img.setProperty(hmUI.prop.VISIBLE, false); break;
               case 3:
                      normal_moon_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, false); break;
               case 4:
                      normal_weather_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, false);
                      normal_temperature_current_text_img.setProperty(hmUI.prop.VISIBLE, false); break;
               default:
                      normal_digital_clock_img_time_AmPm.setProperty(hmUI.prop.VISIBLE, true);
                      normal_digital_clock_img_time.setProperty(hmUI.prop.VISIBLE, true);
                      normal_digital_clock_hour_separator_img.setProperty(hmUI.prop.VISIBLE, true);
                      normal_weather_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, true);
                      normal_temperature_current_text_img.setProperty(hmUI.prop.VISIBLE, true); break;
            }
            hmUI.showToast({text: "Option " + parseInt(optionnumber) });
        }

        //dynamic modify end
        const e = __$$hmAppManager$$__.currentApp;
        const o = e.current
          , {px: i} = (new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(e,o)),
        e.__globals__)
          , n = Logger.getLogger("watchface6");
        o.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
            //initialize default language
            call_change_Language(0);

            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 466,
              h: 466,
              src: 'background2.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_moon_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 102,
              y: 275,
              image_array: ["Moon_30_01.png","Moon_30_02.png","Moon_30_03.png","Moon_30_04.png","Moon_30_05.png","Moon_30_06.png","Moon_30_07.png","Moon_30_08.png","Moon_30_09.png","Moon_30_10.png","Moon_30_11.png","Moon_30_12.png","Moon_30_13.png","Moon_30_14.png","Moon_30_15.png","Moon_30_16.png","Moon_30_17.png","Moon_30_18.png","Moon_30_19.png","Moon_30_20.png","Moon_30_21.png","Moon_30_22.png","Moon_30_23.png","Moon_30_24.png","Moon_30_25.png","Moon_30_26.png","Moon_30_27.png","Moon_30_28.png","Moon_30_29.png","Moon_30_30.png"],
              image_length: 30,
              type: hmUI.data_type.MOON,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            normal_moon_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, false);

            normal_temperature_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'backmerge1.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 316,
              y: 123,
              font_array: ["dig_0.png","dig_1.png","dig_2.png","dig_3.png","dig_4.png","dig_5.png","dig_6.png","dig_7.png","dig_8.png","dig_9.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'dig_cel.png',
              unit_tc: 'dig_cel.png',
              unit_en: 'dig_cel.png',
              negative_image: 'dig_min.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 320,
              y: 79,
              image_array: ["weather_0.png","weather_1.png","weather_2.png","weather_3.png","weather_4.png","weather_5.png","weather_6.png","weather_7.png","weather_8.png","weather_9.png","weather_10.png","weather_11.png","weather_12.png","weather_13.png","weather_14.png","weather_15.png","weather_16.png","weather_17.png","weather_18.png","weather_19.png","weather_20.png","weather_21.png","weather_22.png","weather_23.png","weather_24.png","weather_25.png","weather_26.png","weather_27.png","weather_28.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_calorie_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 310,
              y: 203,
              font_array: ["dig_0.png","dig_1.png","dig_2.png","dig_3.png","dig_4.png","dig_5.png","dig_6.png","dig_7.png","dig_8.png","dig_9.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 324,
              y: 169,
              font_array: ["dig_0.png","dig_1.png","dig_2.png","dig_3.png","dig_4.png","dig_5.png","dig_6.png","dig_7.png","dig_8.png","dig_9.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_distance_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 92,
              y: 203,
              font_array: ["dig_0.png","dig_1.png","dig_2.png","dig_3.png","dig_4.png","dig_5.png","dig_6.png","dig_7.png","dig_8.png","dig_9.png"],
              padding: false,
              h_space: 0,
              dot_image: 'dig_punt.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.DISTANCE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 92,
              y: 169,
              font_array: ["dig_0.png","dig_1.png","dig_2.png","dig_3.png","dig_4.png","dig_5.png","dig_6.png","dig_7.png","dig_8.png","dig_9.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_month_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 141,
              month_startY: 113,
              month_sc_array: monthArray,
              month_tc_array: monthArray,
              month_en_array: monthArray,
              month_is_character: true ,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 96,
              day_startY: 117,
              day_sc_array: ["small_0.png","small_1.png","small_2.png","small_3.png","small_4.png","small_5.png","small_6.png","small_7.png","small_8.png","small_9.png"],
              day_tc_array: ["small_0.png","small_1.png","small_2.png","small_3.png","small_4.png","small_5.png","small_6.png","small_7.png","small_8.png","small_9.png"],
              day_en_array: ["small_0.png","small_1.png","small_2.png","small_3.png","small_4.png","small_5.png","small_6.png","small_7.png","small_8.png","small_9.png"],
              day_zero: 1,
              day_space: -6,
              day_align: hmUI.align.LEFT,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 100,
              y: 78,
              week_en: DayArray,
              week_tc: DayArray,
              week_sc: DayArray,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 218,
              y: 381,
              src: 'bluetoothoff.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 215,
              y: 265,
              src: 'alarm-small3.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_pointer_progress_img_pointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
              src: 'batt.png',
              center_x: 233,
              center_y: 365,
              x: 11,
              y: 54,
              start_angle: 28,
              end_angle: 333,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 208,
              y: 326,
              font_array: ["batt_0.png","batt_1.png","batt_2.png","batt_3.png","batt_4.png","batt_5.png","batt_6.png","batt_7.png","batt_8.png","batt_9.png"],
              padding: false,
              h_space: -3,
              unit_sc: 'batt_procent.png',
              unit_tc: 'batt_procent.png',
              unit_en: 'batt_procent.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time_AmPm = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              am_x: 384,
              am_y: 291,
              am_sc_path: 'am.png',
              am_en_path: 'am.png',
              pm_x: 384,
              pm_y: 291,
              pm_sc_path: 'pm.png',
              pm_en_path: 'pm.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 287,
              hour_startY: 248,
              hour_array: ["time3_0.png","time3_1.png","time3_2.png","time3_3.png","time3_4.png","time3_5.png","time3_6.png","time3_7.png","time3_8.png","time3_9.png"],
              hour_zero: 1,
              hour_space: -4,
              hour_align: hmUI.align.LEFT,

              minute_startX: 360,
              minute_startY: 248,
              minute_array: ["time3_0.png","time3_1.png","time3_2.png","time3_3.png","time3_4.png","time3_5.png","time3_6.png","time3_7.png","time3_8.png","time3_9.png"],
              minute_zero: 1,
              minute_space: -4,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_hour_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 350,
              y: 264,
              src: 'timepixel.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_hour = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              hour_path: 'hour2.png',
              hour_centerX: 233,
              hour_centerY: 233,
              hour_posX: hourx,
              hour_posY: houry,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_minute = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              minute_path: 'minute2.png',
              minute_centerX: 233,
              minute_centerY: 233,
              minute_posX: minutex,
              minute_posY: minutey,
              minute_cover_path: 'timedop.png',
              minute_cover_x: 200,
              minute_cover_y: 199,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_second = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              second_path: 'sec2.png',
              second_centerX: 233,
              second_centerY: 233,
              second_posX: secondx,
              second_posY: secondy,
              second_cover_path: 'timedop.png',
              second_cover_x: 200,
              second_cover_y: 199,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            idle_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 466,
              h: 466,
              src: 'background3.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 218,
              y: 381,
              src: 'bluetoothoff.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 215,
              y: 265,
              src: 'alarm-small3.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_battery_pointer_progress_img_pointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
              src: 'batt.png',
              center_x: 233,
              center_y: 365,
              x: 11,
              y: 54,
              start_angle: 28,
              end_angle: 333,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 208,
              y: 326,
              font_array: ["batt_0.png","batt_1.png","batt_2.png","batt_3.png","batt_4.png","batt_5.png","batt_6.png","batt_7.png","batt_8.png","batt_9.png"],
              padding: false,
              h_space: -3,
              unit_sc: 'batt_procent.png',
              unit_tc: 'batt_procent.png',
              unit_en: 'batt_procent.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_analog_clock_time_pointer_hour = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              hour_path: 'hour3.png',
              hour_centerX: 233,
              hour_centerY: 233,
              hour_posX: hourx,
              hour_posY: houry,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_analog_clock_time_pointer_minute = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              minute_path: 'minute3.png',
              minute_centerX: 233,
              minute_centerY: 233,
              minute_posX: minutex,
              minute_posY: minutey,
              minute_cover_path: 'timedop.png',
              minute_cover_x: 200,
              minute_cover_y: 199,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            normal_sunrise_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 75,
              y: 246,
              w: 97,
              h: 68,
              src: 'shortcut.png',
              type: hmUI.data_type.SUN_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 295,
              y: 77,
              w: 102,
              h: 68,
              src: 'shortcut.png',
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 295,
              y: 159,
              w: 102,
              h: 68,
              src: 'shortcut.png',
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 63,
              y: 159,
              w: 102,
              h: 68,
              src: 'shortcut.png',
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // Change color background shortcut start
            btncolor = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 32,
              y: 342,
              text: '',
              w: 97,
              h: 78,
              normal_src: 'shortcut.png',
              press_src: 'shortcut.png',
              click_func: () => {
               click_Color();
              },
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            btncolor.setProperty(hmUI.prop.VISIBLE, true);
            //Change color background shortcut end

            // Change brightness background shortcut start
            btnbackground = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 336,
              y: 342,
              text: '',
              w: 97,
              h: 78,
              normal_src: 'shortcut.png',
              press_src: 'shortcut.png',
              click_func: () => {
               click_Background();
              },
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            btnbackground.setProperty(hmUI.prop.VISIBLE, true);
            // Change brightness shortcut end

            // Change option shortcut start
            btnoption = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 135,
              y: 420,
              text: '',
              w: 91,
              h: 387,
              normal_src: 'shortcut.png',
              press_src: 'shortcut.png',
              click_func: () => {
               click_Option();
              },
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            btnoption.setProperty(hmUI.prop.VISIBLE, true);
            // Change option shortcut end

            // Change secondhand shortcut start
            btnsec = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 240,
              y: 420,
              text: '',
              w: 91,
              h: 37,
              normal_src: 'shortcut.png',
              press_src: 'shortcut.png',
              click_func: () => {
               click_Second();
              },
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            btnsec.setProperty(hmUI.prop.VISIBLE, true);
            // Change secondhand shortcut end

            // Change language shortcut start
            btnlanguage = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 95,
              y: 86,
              text: '',
              w: 131,
              h: 53,
              normal_src: 'shortcut.png',
              press_src: 'shortcut.png',
              click_func: () => {
               click_Language();
              },
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            btnlanguage.setProperty(hmUI.prop.VISIBLE, true);
            // Change brightness shortcut end

            //because langchange require screen switch.
            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
					resume_call: (function () {
                       if (langchange) {
                             showlanguageonscreen();
                             langchange=false;
                       }
					}),
				})

            //dynamic modify end
            },
            onInit() {
                n.log("index page.js on init invoke")
            },
            build() {
                this.init_view(),
                n.log("index page.js on ready invoke")
            },
            onDestroy() {
                n.log("index page.js on destroy invoke")
                vibrate && vibrate.stop();
            },
            onDestory() {
                n.log("index page.js on destroy invoke")
                vibrate && vibrate.stop();
            }
        })
    }
    )()
} catch (e) {
    console.log("Mini Program Error", e),
    e && e.stack && e.stack.split(/\n/).forEach((e=>console.log("error stack", e)))
}
