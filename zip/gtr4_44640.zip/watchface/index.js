﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        //const logger = Logger.getLogger('watchface_SashaCX75');
        const logger = DeviceRuntimeCore.HmLogger.getLogger('watchface_SashaCX75')
        //end of ignored block

        //dynamic modify start

        
        console.log('user_functions.js');
        // start user_functions.js

/////////////////////////////////////////////////////////////////////////////////
// User functions
/////////////////////////////////////////////////////////////////////////////////

// variables for languages
let displayedLangValue = 0; // default: en
let displayedLangCode = 'en';
let supportedLangCodes = ['en', 'es', 'fr', 'de','id', 'pl', 'it', 'pt', 'nl', 'tr', 'ro', 'cs', 'fi', 'nb', 'da', 'sv', 'hu', 'ms','sk'];

// translations are here for supported languages, only latin
let normal_DOW_Array_en = ['MON', 'TUE', 'WED', 'THU', 'FRI', 'SAT', 'SUN'];
let normal_DOW_Array_es = ['LUN', 'MAR', 'MER', 'GIO', 'VEN', 'SAB', 'DOM'];
let normal_DOW_Array_fr = ['LUN', 'MAR', 'MER', 'JEU', 'VEN', 'SAM', 'DIM'];
let normal_DOW_Array_de = ['MON', 'DIE', 'MIT', 'DON', 'FRE', 'SAM', 'SON'];
let normal_DOW_Array_id = ['SEN', 'SEL', 'RAB', 'KAM', 'JUM', 'SAB', 'MIN'];
let normal_DOW_Array_pl = ['PON', 'WTO', 'ŚRO', 'CZW', 'PIĄ', 'SOB', 'NIE'];
let normal_DOW_Array_it = ['LUN', 'MAR', 'MER', 'GIO', 'VEN', 'SAB', 'DOM'];
let normal_DOW_Array_pt = ['SEG', 'TER', 'QUA', 'QUI', 'SEX', 'SAB', 'DOM'];
let normal_DOW_Array_nl = ['MAN', 'DIN', 'WOE', 'DON', 'VRI', 'ZAT', 'ZON'];
let normal_DOW_Array_tr = ['PAZ', 'SAL', 'ÇAR', 'PER', 'CUM', 'CUT', 'PAZ'];
let normal_DOW_Array_ro = ['LUN', 'MAR', 'MIE', 'JOI', 'VIN', 'SAM', 'DUM'];
let normal_DOW_Array_cs = ['PON', 'ÚTE', 'STŘ', 'ČTV', 'PÁT', 'SOB', 'NED'];
let normal_DOW_Array_fi = ['MAA', 'TII', 'KES', 'TOR', 'PER', 'LAU', 'SUN'];
let normal_DOW_Array_nb = ['MAN', 'TIR', 'ONS', 'TOR', 'FRE', 'LØR', 'SØN'];
let normal_DOW_Array_da = ['MAN', 'TIR', 'ONS', 'TOR', 'FRE', 'LØR', 'SØN'];
let normal_DOW_Array_sv = ['MÅN', 'TIS', 'ONS', 'TOR', 'FRE', 'LÖR', 'SÖN'];
let normal_DOW_Array_hu = ['MÅN', 'TIS', 'ONS', 'TOR', 'FRE', 'LÖR', 'SÖN'];
let normal_DOW_Array_ms = ['ISN', 'SEL', 'RAB', 'KHA', 'JUM', 'SAB', 'AHA'];
let normal_DOW_Array_sk = ['PON', 'UTO', 'STR', 'ŠTV', 'PIA', 'SOB', 'NED'];

let normal_Month_Array_en = ['JAN', 'FEB', 'MAR', 'APR', 'MAI', 'JUN', 'JLT', 'AUG', 'SEP', 'OCT', 'NOV', 'DEC', ];
let normal_Month_Array_es = ['ENE', 'FEB', 'MAR', 'ABR', 'MAY', 'JUN', 'JLT', 'AGO', 'SEP', 'OCT', 'NOV', 'DIC', ];
let normal_Month_Array_fr = ['JAN', 'FEV', 'MAR', 'AVR', 'MAI', 'JUN', 'JLT', 'AOU', 'SEP', 'OCT', 'NOV', 'DEC', ];
let normal_Month_Array_de = ['JAN', 'FEB', 'MAR', 'APR', 'MAI', 'JUN', 'JUL', 'AUG', 'SEP', 'OKT', 'NOV', 'DEZ', ];
let normal_Month_Array_id = ['JAN', 'FEB', 'MAR', 'APR', 'MEI', 'JUN', 'JUL', 'AGU', 'SEP', 'OKT', 'NOV', 'DES', ];
let normal_Month_Array_pl = ['STY', 'LUT', 'MAR', 'KWI', 'MAJ', 'CZE', 'LIP', 'SIE', 'WRZ', 'PAŹ', 'LIS', 'GRU', ];
let normal_Month_Array_it = ['GEN', 'FEB', 'MAR', 'APR', 'MAG', 'GIU', 'LUG', 'AGO', 'SET', 'OTT', 'NOV', 'DIC', ];
let normal_Month_Array_pt = ['JAN', 'FEV', 'MAR', 'ABR', 'MAI', 'JUN', 'JUL', 'AGO', 'SET', 'OUT', 'NOV', 'DEZ', ];
let normal_Month_Array_nl = ['JAN', 'FEB', 'MAA', 'APR', 'MEI', 'JUN', 'JUL', 'AUG', 'SEP', 'OKT', 'NOV', 'DEC', ];
let normal_Month_Array_tr = ['OCA', 'ŞUB', 'MAR', 'NIS', 'MAY', 'HAZ', 'TEM', 'AĞU', 'EYL', 'EKI', 'KAS', 'ARA', ];
let normal_Month_Array_ro = ['IAN', 'FEB', 'MAR', 'APR', 'MAI', 'IUN', 'IUL', 'AOU', 'SEP', 'OCT', 'NOI', 'DEC', ];
let normal_Month_Array_cs = ['LED', 'ÚNO', 'BŘE', 'DUB', 'KVĚ', 'ČVN', 'ČVC', 'SRP', 'ZÁŘ', 'ŘÍJ', 'LIS', 'PRO', ];
let normal_Month_Array_fi = ['TAM', 'HEL', 'MAA', 'HUH', 'TOU', 'KES', 'HEI', 'ELO', 'SYY', 'LOK', 'MAR', 'JOU', ];
let normal_Month_Array_nb = ['JAN', 'FEB', 'MAR', 'APR', 'MAI', 'JUN', 'JUL', 'AUG', 'SEP', 'OKT', 'NOV', 'DES', ];
let normal_Month_Array_da = ['JAN', 'FEB', 'MAR', 'APR', 'MAJ', 'JUN', 'JUL', 'AUG', 'SEP', 'OKT', 'NOV', 'DEC', ];
let normal_Month_Array_sv = ['JAN', 'FEB', 'MAR', 'APR', 'MAJ', 'JUN', 'JUL', 'AUG', 'SEP', 'OKT', 'NOV', 'DEC', ];
let normal_Month_Array_hu = ['JÁN', 'FEB', 'MÁR', 'ÁPR', 'MÁJ', 'JÚN', 'JÚL', 'AUG', 'SZE', 'OKT', 'NOV', 'DEC', ];
let normal_Month_Array_ms = ['JÁN', 'FEB', 'MÁR', 'ÁPR', 'MÁJ', 'JÚN', 'JÚL', 'AUG', 'SZE', 'OKT', 'NOV', 'DEC', ];
let normal_Month_Array_sk = ['JAN', 'FEB', 'MAC', 'APR', 'MEI', 'JUN', 'JUL', 'OGO', 'SEP', 'OKT', 'NOV', 'DIS', ];

// set default displayed language if supported by watchface, else english
// do not change order, cf https://docs.zepp.com/docs/v2/reference/related-resources/language-list/
let currentLangCode='en'
let zeppLangCodes = ['zh', 'zh', 'en', 'es', 'ru', 'ko', 'fr', 'de', 'id', 'pl', 'it', 'ja', 'th', 'ar', 'vi', 'pt', 'nl', 'tr', 'uk', 'iw', 'pt', 'ro', 'cs', 'el', 'sr', 'ca', 'fi', 'nb', 'da', 'sv', 'hu', 'ms', 'sk', 'hi'];
let currentLangValue = hmSetting.getLanguage();
if (currentLangValue <= zeppLangCodes.length-1)
	currentLangCode = zeppLangCodes[currentLangValue];
for(let i = 0; i < supportedLangCodes.length; i++) {
	if (supportedLangCodes[i]==currentLangCode) {
		displayedLangValue = i;
		displayedLangCode = supportedLangCodes[displayedLangValue];
		break;
	}
}

// switch displayed language
function switch_language() {
	if (displayedLangValue >= supportedLangCodes.length-1) {
		displayedLangValue=0;
	}
	else {
		displayedLangValue++;
	}
	displayedLangCode = supportedLangCodes[displayedLangValue];
	hmUI.showToast({text: 'Language ' + displayedLangCode});	
	UpdateElementsDate();	
}

// update displayed date language
function UpdateElementsDate(){	
	// day of week
	for(let i = 0; i < normal_DOW_Array.length; i++) {
		normal_DOW_Array[i]=eval('normal_DOW_Array_' + displayedLangCode + '[i]');		
	}
	normal_DOW_Str = normal_DOW_Array[timeSensor.week-1];
    normal_dow_text_font.setProperty(hmUI.prop.TEXT, normal_DOW_Str );		
	
	
	// month 
	for(let j = 0; j < normal_Month_Array.length; j++) {
		normal_Month_Array[j]=eval('normal_Month_Array_' + displayedLangCode + '[j]');		
	}
    normal_Month_Str = normal_Month_Array[timeSensor.month-1];
    normal_month_name_font.setProperty(hmUI.prop.TEXT, normal_Month_Str );	
}

// switch displayed element
let displayedElement = 1 
function switch_info() {
	if (displayedElement >= 4) {
		displayedElement=1;
	}
	else {
		displayedElement++;
	}	
	UpdateElementsInfo();	
}

// update displayed element
function UpdateElementsInfo(){		
	normal_battery_current_text_font.setProperty(hmUI.prop.VISIBLE, (displayedElement==1));
	normal_battery_icon_img.setProperty(hmUI.prop.VISIBLE, (displayedElement==1));
	normal_battery_image_progress_img_progress.setProperty(hmUI.prop.VISIBLE, (displayedElement==1));		
	
	normal_step_current_text_font.setProperty(hmUI.prop.VISIBLE, (displayedElement==2));
	normal_step_icon_img.setProperty(hmUI.prop.VISIBLE, (displayedElement==2));
	normal_step_image_progress_img_progress.setProperty(hmUI.prop.VISIBLE, (displayedElement==2));
	
	normal_heart_rate_text_font.setProperty(hmUI.prop.VISIBLE, (displayedElement==3));
	normal_heart_rate_icon_img.setProperty(hmUI.prop.VISIBLE, (displayedElement==3));
	normal_heart_rate_image_progress_img_progress.setProperty(hmUI.prop.VISIBLE, (displayedElement==3));
	
	normal_calorie_current_text_font.setProperty(hmUI.prop.VISIBLE, (displayedElement==4));
	normal_calorie_icon_img.setProperty(hmUI.prop.VISIBLE, (displayedElement==4));
	normal_calorie_image_progress_img_progress.setProperty(hmUI.prop.VISIBLE, (displayedElement==4));

	switch (displayedElement) {
	  case 1:
		normal_battery_jumpable_img_click.setProperty(hmUI.prop.TYPE, hmUI.data_type.BATTERY);
		break;
	  case 2:
		normal_battery_jumpable_img_click.setProperty(hmUI.prop.TYPE, hmUI.data_type.STEP);
		break;
	  case 3:
		normal_battery_jumpable_img_click.setProperty(hmUI.prop.TYPE, hmUI.data_type.HEART);
		break;
	  case 4:
		normal_battery_jumpable_img_click.setProperty(hmUI.prop.TYPE, hmUI.data_type.CAL);
		break;
	}	
}
	
/////////////////////////////
// end user functions	
////////////////////////////

        // end user_functions.js

        let normal_background_bg_img = ''
        let normal_calorie_icon_img = ''
        let normal_calorie_current_text_font = ''
        let normal_calorie_image_progress_img_progress = ''
        let normal_weather_image_progress_img_level = ''
        let normal_temperature_current_text_font = ''
        let normal_heart_rate_icon_img = ''
        let normal_heart_rate_text_font = ''
        let normal_heart_rate_image_progress_img_progress = ''
        let normal_step_icon_img = ''
        let normal_step_current_text_font = ''
        let normal_step_image_progress_img_progress = ''
        let normal_battery_icon_img = ''
        let normal_battery_current_text_font = ''
        let normal_battery_image_progress_img_progress = ''
        let normal_system_disconnect_img = ''
        let normal_system_clock_img = ''
        let normal_month_name_font = ''
        let normal_Month_Array = ['JAN', 'FEB', 'MAR', 'APR', 'MAI', 'JUN', 'JLT', 'AUG', 'SEP', 'OCT', 'NOV', 'DEC', ];
        let normal_day_text_font = ''
        let normal_dow_text_font = ''
        let normal_DOW_Array = ['MON', 'TUE', 'WED', 'THU', 'FRI', 'SAT', 'SUN'];
        let normal_digital_clock_img_time = ''
        let normal_digital_clock_hour_separator_img = ''
        let normal_analog_clock_time_pointer_second = ''
        let idle_digital_clock_img_time = ''
        let idle_digital_clock_hour_separator_img = ''
        let normal_battery_jumpable_img_click = ''
        let normal_temperature_jumpable_img_click = ''
        let normal_countdown_jumpable_img_click = ''
        let normal_stopwatch_jumpable_img_click = ''
        let normal_alarm_jumpable_img_click = ''
        let Button_1 = ''
        let Button_2 = ''
        let Button_3 = ''
        let Button_Switch_BG = ''

        let backgroundIndex = 0;
        let backgroundList = ['bck_0.png', 'bck_1.png', 'bck_2.png'];
        let backgroundToastList = ['Back %s', 'Back %s', 'Back %s'];
        const watchfaceId = hmApp.packageInfo().watchfaceId;
        let timeSensor = '';


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            //#region SwitchBackground
            console.log('SwitchBackground');
            function switchBackground() {
              backgroundIndex++;
              if (backgroundIndex >= backgroundList.length) backgroundIndex = 0;
              hmFS.SysProSetInt(`backgroundIndex_${watchfaceId}`, backgroundIndex);
              let toastText = backgroundToastList[backgroundIndex].replace('%s', `${backgroundIndex + 1}`);
              if (toastText.length > 0) hmUI.showToast({text: toastText});
              normal_background_bg_img.setProperty(hmUI.prop.SRC, backgroundList[backgroundIndex]);
            };
            //#endregion

            console.log('Watch_Face.ScreenNormal');
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 466,
              h: 466,
              src: 'bck_0.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_calorie_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 75,
              y: 340,
              src: 'ico_1.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_calorie_current_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 113,
              y: 322,
              w: 240,
              h: 80,
              text_size: 80,
              char_space: 0,
              color: 0xFFE3DDC5,
              line_space: 0,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_calorie_image_progress_img_progress = hmUI.createWidget(hmUI.widget.IMG_PROGRESS, {
              x: [100,100,100,100,100],
              y: [405,405,405,405,405],
              image_array: ["Batt1.png","Batt2.png","Batt3.png","Batt4.png","Batt5.png"],
              image_length: 5,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 130,
              y: 18,
              image_array: ["w_0.png","w_1.png","w_2.png","w_3.png","w_4.png","w_5.png","w_6.png","w_7.png","w_8.png","w_9.png","w_10.png","w_11.png","w_12.png","w_13.png","w_14.png","w_15.png","w_16.png","w_17.png","w_18.png","w_19.png","w_20.png","w_21.png","w_22.png","w_23.png","w_24.png","w_25.png","w_26.png","w_27.png","w_28.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 190,
              y: 12,
              w: 86,
              h: 50,
              text_size: 50,
              char_space: 0,
              color: 0xFFE3DDC5,
              line_space: 0,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.NONE,
              align_h: hmUI.align.CENTER_H,
              unit_type: 1,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 75,
              y: 340,
              src: 'ico_pulse.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 113,
              y: 322,
              w: 240,
              h: 80,
              text_size: 80,
              char_space: 0,
              color: 0xFFE3DDC5,
              line_space: 0,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_image_progress_img_progress = hmUI.createWidget(hmUI.widget.IMG_PROGRESS, {
              x: [100,100,100,100,100,0],
              y: [405,405,405,405,405,0],
              image_array: ["Coeur1.png","Coeur2.png","Coeur3.png","Coeur4.png","Coeur5.png","ico_1.png"],
              image_length: 6,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 74,
              y: 340,
              src: 'step.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 113,
              y: 322,
              w: 240,
              h: 80,
              text_size: 80,
              char_space: 0,
              color: 0xFFE3DDC5,
              line_space: 0,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_image_progress_img_progress = hmUI.createWidget(hmUI.widget.IMG_PROGRESS, {
              x: [100,100,100,100,100],
              y: [405,405,405,405,405],
              image_array: ["Batt1.png","Batt2.png","Batt3.png","Batt4.png","Batt5.png"],
              image_length: 5,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 75,
              y: 340,
              src: 'ico_batt.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_current_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 113,
              y: 322,
              w: 240,
              h: 80,
              text_size: 80,
              char_space: 0,
              color: 0xFFE3DDC5,
              line_space: 0,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.CENTER_H,
              unit_type: 1,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_image_progress_img_progress = hmUI.createWidget(hmUI.widget.IMG_PROGRESS, {
              x: [100,100,100,100,100],
              y: [405,405,405,405,405],
              image_array: ["Batt1.png","Batt2.png","Batt3.png","Batt4.png","Batt5.png"],
              image_length: 5,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 316,
              y: 37,
              src: 'bt_off.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 221,
              y: 219,
              src: '0029.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            if (!timeSensor) timeSensor = hmSensor.createSensor(hmSensor.id.TIME);
            timeSensor.addEventListener(timeSensor.event.DAYCHANGE, function() {
              time_update(true);
            });

            normal_month_name_font = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 281,
              y: 85,
              w: 110,
              h: 50,
              text_size: 50,
              char_space: 0,
              color: 0xFFFF4A4A,
              line_space: 0,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.LEFT,
              // unit_string: JAN, FEB, MAR, APR, MAI, JUN, JLT, AUG, SEP, OCT, NOV, DEC,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_day_text_font = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 200,
              y: 85,
              w: 65,
              h: 50,
              text_size: 50,
              char_space: 0,
              color: 0xFFE3DDC5,
              line_space: 0,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.CENTER_H,
              // padding: true,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_dow_text_font = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 52,
              y: 85,
              w: 135,
              h: 50,
              text_size: 50,
              char_space: 4,
              color: 0xFF00A673,
              line_space: 0,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.CENTER_H,
              // unit_string: MON, TUE, WED, THU, FRI, SAT, SUN,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 30,
              hour_startY: 171,
              hour_array: ["0002.png","0003.png","0004.png","0005.png","0006.png","0007.png","0008.png","0009.png","0010.png","0011.png"],
              hour_zero: 1,
              hour_space: 0,
              hour_angle: 0,
              hour_align: hmUI.align.LEFT,

              minute_startX: 247,
              minute_startY: 171,
              minute_array: ["0002.png","0003.png","0004.png","0005.png","0006.png","0007.png","0008.png","0009.png","0010.png","0011.png"],
              minute_zero: 1,
              minute_space: 0,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_hour_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 217,
              y: 182,
              src: '0055.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_second = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              second_path: '0042.png',
              second_centerX: 233,
              second_centerY: 233,
              second_posX: 6,
              second_posY: 234,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            console.log('Watch_Face.ScreenAOD');

            idle_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 30,
              hour_startY: 171,
              hour_array: ["0002.png","0003.png","0004.png","0005.png","0006.png","0007.png","0008.png","0009.png","0010.png","0011.png"],
              hour_zero: 1,
              hour_space: 0,
              hour_angle: 0,
              hour_align: hmUI.align.LEFT,

              minute_startX: 247,
              minute_startY: 171,
              minute_array: ["0002.png","0003.png","0004.png","0005.png","0006.png","0007.png","0008.png","0009.png","0010.png","0011.png"],
              minute_zero: 1,
              minute_space: 0,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_hour_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 217,
              y: 182,
              src: '0055.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });
            console.log('Watch_Face.Shortcuts');

            normal_battery_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 141,
              y: 333,
              w: 175,
              h: 73,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 115,
              y: 14,
              w: 199,
              h: 64,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_countdown_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 264,
              y: 166,
              w: 170,
              h: 131,
              type: hmUI.data_type.COUNT_DOWN,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_stopwatch_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 28,
              y: 166,
              w: 170,
              h: 131,
              type: hmUI.data_type.STOP_WATCH,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_alarm_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 199,
              y: 166,
              w: 64,
              h: 131,
              type: hmUI.data_type.ALARM_CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            console.log('Watch_Face.Buttons');
            Button_1 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 57,
              y: 88,
              w: 210,
              h: 50,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'BoutonTransparent.png',
              normal_src: 'BoutonTransparent.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'ScheduleCalScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_2 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 34,
              y: 301,
              w: 106,
              h: 117,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'BoutonTransparent.png',
              normal_src: 'BoutonTransparent.png',
              click_func: (button_widget) => {
                switch_info()
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_3 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 268,
              y: 88,
              w: 138,
              h: 50,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'BoutonTransparent.png',
              normal_src: 'BoutonTransparent.png',
              click_func: (button_widget) => {
                switch_language()
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            console.log('Watch_Face.SwitchBackground');
            // Button_Switch_BG = hmUI.createWidget(hmUI.widget.SwitchBackground, {
              // x: 319,
              // y: 316,
              // w: 109,
              // h: 90,
              // text: '',
              // color: 0xFFFF8C00,
              // text_size: 25,
              // press_src: 'set.png',
              // normal_src: 'set.png',
              // bg_list: bck_0|bck_1|bck_2,
              // toast_list: Back %s|Back %s|Back %s,
              // use_crown: False,
              // use_in_AOD: False,
              // vibro: False,
            // });

            Button_Switch_BG = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 319,
              y: 316,
              w: 109,
              h: 90,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'set.png',
              normal_src: 'set.png',
              click_func: (button_widget) => {
                switchBackground();
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            let screenType = hmSetting.getScreenType();
            console.log('user_script_end.js');
            // start user_script_end.js

UpdateElementsDate();
UpdateElementsInfo();
            // end user_script_end.js

            //#region time_update
            function time_update(updateHour = false, updateMinute = false) {
              console.log('time_update()');
              let hour = timeSensor.hour;
              let minute = timeSensor.minute;
              let second = timeSensor.second;
              let format_hour = timeSensor.format_hour;

              console.log('month font');
              if (updateHour) {
                let normal_Month_Str = normal_Month_Array[timeSensor.month-1];
                normal_month_name_font.setProperty(hmUI.prop.TEXT, normal_Month_Str );
              };

              console.log('day font');
              if (updateHour) {
                let normal_dayStr = timeSensor.day.toString();
                normal_dayStr = normal_dayStr.padStart(2, '0');
                normal_day_text_font.setProperty(hmUI.prop.TEXT, normal_dayStr );
              };

              console.log('day of week font');
              if (updateHour) {
                let normal_DOW_Str = normal_DOW_Array[timeSensor.week-1];
                normal_dow_text_font.setProperty(hmUI.prop.TEXT, normal_DOW_Str );
              };

            };

            //#endregion
            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                console.log('resume_call()');
                time_update(true, true);

                //SwitchBackground
                if (hmFS.SysProGetInt(`backgroundIndex_${watchfaceId}`) === undefined) {
                  backgroundIndex = 0;
                  hmFS.SysProSetInt(`backgroundIndex_${watchfaceId}`, backgroundIndex);
                } else {
                  backgroundIndex = hmFS.SysProGetInt(`backgroundIndex_${watchfaceId}`);
                };
                if (screenType == hmSetting.screen_type.WATCHFACE && normal_background_bg_img) normal_background_bg_img.setProperty(hmUI.prop.SRC, backgroundList[backgroundIndex]);
              }),
            });

                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}