﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        const logger = Logger.getLogger('watchface_SashaCX75');
        //end of ignored block

        //dynamic modify start

        
        console.log('user_functions.js');
        // start user_functions.js

//////////////////////////////////////////////////////////////////////////////////////////////////

        // Start color change
        let btncolor = ''
        let colornumber = 1
        let totalcolors = 5
        let namecolor = ''

        function click_Color() {
            if(colornumber>=totalcolors) {
            colornumber=1;
                }
            else {
                colornumber=colornumber+1;
            }

if ( colornumber == 1) { namecolor = "BLUE"}
if ( colornumber == 2) { namecolor = "GREEN"}
if ( colornumber == 3) { namecolor = "RED"}
if ( colornumber == 4) { namecolor = "YELLOW"}
if ( colornumber == 5) { namecolor = "BLACK & WHITE"}
hmUI.showToast({text: namecolor });

             //hmUI.showToast({text: "color " + parseInt(colornumber) });
             normal_background_bg_img.setProperty(hmUI.prop.SRC, "main" + parseInt(colornumber) + ".png");
                           
        }

/////////////////////////////////////////////////////////////////////////////////////////////////
        // end user_functions.js

        let normal_background_bg_img = ''
        let normal_system_disconnect_img = ''
        let normal_system_clock_img = ''
        let normal_date_img_date_week_img = ''
        let normal_date_img_date_year = ''
        let normal_date_img_date_month_img = ''
        let normal_date_img_date_day = ''
        let normal_step_current_text_img = ''
        let normal_heart_rate_text_text_img = ''
        let normal_battery_text_text_img = ''
        let normal_digital_clock_img_time_AmPm = ''
        let normal_digital_clock_img_time = ''
        let idle_background_bg_img = ''
        let idle_system_disconnect_img = ''
        let idle_system_clock_img = ''
        let idle_date_img_date_week_img = ''
        let idle_date_img_date_year = ''
        let idle_date_img_date_month_img = ''
        let idle_date_img_date_day = ''
        let idle_step_current_text_img = ''
        let idle_heart_rate_text_text_img = ''
        let idle_battery_text_text_img = ''
        let idle_digital_clock_img_time_AmPm = ''
        let idle_digital_clock_img_time = ''
        let normal_stopwatch_jumpable_img_click = ''
        let normal_countdown_jumpable_img_click = ''
        let normal_alarm_jumpable_img_click = ''
        let normal_temperature_jumpable_img_click = ''
        let normal_spo2_jumpable_img_click = ''
        let normal_heart_jumpable_img_click = ''


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            console.log('Watch_Face.ScreenNormal');
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 466,
              h: 466,
              src: 'main1.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 353,
              y: 358,
              src: 'System_BT_OFF.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 51,
              y: 370,
              src: 'System_Alarm.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 155,
              y: 287,
              week_en: ["Week1.png","Week2.png","Week3.png","Week4.png","Week5.png","Week6.png","Week7.png"],
              week_tc: ["Week1.png","Week2.png","Week3.png","Week4.png","Week5.png","Week6.png","Week7.png"],
              week_sc: ["Week1.png","Week2.png","Week3.png","Week4.png","Week5.png","Week6.png","Week7.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_year = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              year_startX: 274,
              year_startY: 133,
              year_sc_array: ["Act_SMALL_Font_01.png","Act_SMALL_Font_02.png","Act_SMALL_Font_03.png","Act_SMALL_Font_04.png","Act_SMALL_Font_05.png","Act_SMALL_Font_06.png","Act_SMALL_Font_07.png","Act_SMALL_Font_08.png","Act_SMALL_Font_09.png","Act_SMALL_Font_10.png"],
              year_tc_array: ["Act_SMALL_Font_01.png","Act_SMALL_Font_02.png","Act_SMALL_Font_03.png","Act_SMALL_Font_04.png","Act_SMALL_Font_05.png","Act_SMALL_Font_06.png","Act_SMALL_Font_07.png","Act_SMALL_Font_08.png","Act_SMALL_Font_09.png","Act_SMALL_Font_10.png"],
              year_en_array: ["Act_SMALL_Font_01.png","Act_SMALL_Font_02.png","Act_SMALL_Font_03.png","Act_SMALL_Font_04.png","Act_SMALL_Font_05.png","Act_SMALL_Font_06.png","Act_SMALL_Font_07.png","Act_SMALL_Font_08.png","Act_SMALL_Font_09.png","Act_SMALL_Font_10.png"],
              year_zero: 1,
              year_space: 4,
              year_align: hmUI.align.CENTER_H,
              year_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_month_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 187,
              month_startY: 135,
              month_sc_array: ["month_short_01.png","month_short_02.png","month_short_03.png","month_short_04.png","month_short_05.png","month_short_06.png","month_short_07.png","month_short_08.png","month_short_09.png","month_short_10.png","month_short_11.png","month_short_12.png"],
              month_tc_array: ["month_short_01.png","month_short_02.png","month_short_03.png","month_short_04.png","month_short_05.png","month_short_06.png","month_short_07.png","month_short_08.png","month_short_09.png","month_short_10.png","month_short_11.png","month_short_12.png"],
              month_en_array: ["month_short_01.png","month_short_02.png","month_short_03.png","month_short_04.png","month_short_05.png","month_short_06.png","month_short_07.png","month_short_08.png","month_short_09.png","month_short_10.png","month_short_11.png","month_short_12.png"],
              month_is_character: true ,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 128,
              day_startY: 133,
              day_sc_array: ["Act_SMALL_Font_01.png","Act_SMALL_Font_02.png","Act_SMALL_Font_03.png","Act_SMALL_Font_04.png","Act_SMALL_Font_05.png","Act_SMALL_Font_06.png","Act_SMALL_Font_07.png","Act_SMALL_Font_08.png","Act_SMALL_Font_09.png","Act_SMALL_Font_10.png"],
              day_tc_array: ["Act_SMALL_Font_01.png","Act_SMALL_Font_02.png","Act_SMALL_Font_03.png","Act_SMALL_Font_04.png","Act_SMALL_Font_05.png","Act_SMALL_Font_06.png","Act_SMALL_Font_07.png","Act_SMALL_Font_08.png","Act_SMALL_Font_09.png","Act_SMALL_Font_10.png"],
              day_en_array: ["Act_SMALL_Font_01.png","Act_SMALL_Font_02.png","Act_SMALL_Font_03.png","Act_SMALL_Font_04.png","Act_SMALL_Font_05.png","Act_SMALL_Font_06.png","Act_SMALL_Font_07.png","Act_SMALL_Font_08.png","Act_SMALL_Font_09.png","Act_SMALL_Font_10.png"],
              day_zero: 1,
              day_space: 4,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 277,
              y: 355,
              font_array: ["Act_SMALL_Font_01.png","Act_SMALL_Font_02.png","Act_SMALL_Font_03.png","Act_SMALL_Font_04.png","Act_SMALL_Font_05.png","Act_SMALL_Font_06.png","Act_SMALL_Font_07.png","Act_SMALL_Font_08.png","Act_SMALL_Font_09.png","Act_SMALL_Font_10.png"],
              padding: false,
              h_space: 2,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 165,
              y: 355,
              font_array: ["Act_SMALL_Font_01.png","Act_SMALL_Font_02.png","Act_SMALL_Font_03.png","Act_SMALL_Font_04.png","Act_SMALL_Font_05.png","Act_SMALL_Font_06.png","Act_SMALL_Font_07.png","Act_SMALL_Font_08.png","Act_SMALL_Font_09.png","Act_SMALL_Font_10.png"],
              padding: false,
              h_space: 1,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 218,
              y: 41,
              font_array: ["Act_Font_01.png","Act_Font_02.png","Act_Font_03.png","Act_Font_04.png","Act_Font_05.png","Act_Font_06.png","Act_Font_07.png","Act_Font_08.png","Act_Font_09.png","Act_Font_10.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time_AmPm = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              am_x: 60,
              am_y: 229,
              am_sc_path: 'Clock_AM.png',
              am_en_path: 'Clock_AM.png',
              pm_x: 60,
              pm_y: 229,
              pm_sc_path: 'Clock_PM.png',
              pm_en_path: 'Clock_PM.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 119,
              hour_startY: 207,
              hour_array: ["Time_01.png","Time_02.png","Time_03.png","Time_04.png","Time_05.png","Time_06.png","Time_07.png","Time_08.png","Time_09.png","Time_10.png"],
              hour_zero: 1,
              hour_space: 2,
              hour_angle: 0,
              hour_align: hmUI.align.LEFT,

              minute_startX: 243,
              minute_startY: 207,
              minute_array: ["Time_01.png","Time_02.png","Time_03.png","Time_04.png","Time_05.png","Time_06.png","Time_07.png","Time_08.png","Time_09.png","Time_10.png"],
              minute_zero: 1,
              minute_space: 2,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              second_startX: 362,
              second_startY: 219,
              second_array: ["Time_Small_01.png","Time_Small_02.png","Time_Small_03.png","Time_Small_04.png","Time_Small_05.png","Time_Small_06.png","Time_Small_07.png","Time_Small_08.png","Time_Small_09.png","Time_Small_10.png"],
              second_zero: 1,
              second_space: 3,
              second_angle: 0,
              second_follow: 0,
              second_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            console.log('user_script.js');
            // start user_script.js
// calendar
	hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 354,
              y: 41,
              w: 106,
              h: 106,
	 text: '',
	  normal_src: '0_Empty.png',
	  press_src: '0_Empty.png',
	  click_func: () => {
	hmApp.startApp({ url: 'ScheduleCalScreen', native: true });
	  },
	  show_level: hmUI.show_level.ONLY_NORMAL,
	});
/////////////////////////////////////////////////////////////////////////////////

            normal_step_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 288,
              y: 362,
              w: 98,
              h: 40,
              src: '0_Empty.png',
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


//////////////////////////////////////////////////////////////////////////////////////////////////  
          // Change color background shortcut start
            btncolor = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 32,
              y: 39,
              text: '',
              w: 106,
              h: 106,
              normal_src: '0_Empty.png',
              press_src: '0_Empty.png',
              click_func: () => {
               click_Color();
              },
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            btncolor.setProperty(hmUI.prop.VISIBLE, true);
            //Change color background shortcut end

    
//////////////////////////////////////////////////////////////////////////////////////////////////
/////////////////Show element at the first time //////////
            // end user_script.js


            console.log('Watch_Face.ScreenAOD');
            idle_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 466,
              h: 466,
              src: 'main5.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 353,
              y: 358,
              src: 'System_BT_OFF.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 51,
              y: 370,
              src: 'System_Alarm.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 155,
              y: 287,
              week_en: ["Week1.png","Week2.png","Week3.png","Week4.png","Week5.png","Week6.png","Week7.png"],
              week_tc: ["Week1.png","Week2.png","Week3.png","Week4.png","Week5.png","Week6.png","Week7.png"],
              week_sc: ["Week1.png","Week2.png","Week3.png","Week4.png","Week5.png","Week6.png","Week7.png"],
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_year = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              year_startX: 274,
              year_startY: 133,
              year_sc_array: ["Act_SMALL_Font_01.png","Act_SMALL_Font_02.png","Act_SMALL_Font_03.png","Act_SMALL_Font_04.png","Act_SMALL_Font_05.png","Act_SMALL_Font_06.png","Act_SMALL_Font_07.png","Act_SMALL_Font_08.png","Act_SMALL_Font_09.png","Act_SMALL_Font_10.png"],
              year_tc_array: ["Act_SMALL_Font_01.png","Act_SMALL_Font_02.png","Act_SMALL_Font_03.png","Act_SMALL_Font_04.png","Act_SMALL_Font_05.png","Act_SMALL_Font_06.png","Act_SMALL_Font_07.png","Act_SMALL_Font_08.png","Act_SMALL_Font_09.png","Act_SMALL_Font_10.png"],
              year_en_array: ["Act_SMALL_Font_01.png","Act_SMALL_Font_02.png","Act_SMALL_Font_03.png","Act_SMALL_Font_04.png","Act_SMALL_Font_05.png","Act_SMALL_Font_06.png","Act_SMALL_Font_07.png","Act_SMALL_Font_08.png","Act_SMALL_Font_09.png","Act_SMALL_Font_10.png"],
              year_zero: 1,
              year_space: 4,
              year_align: hmUI.align.CENTER_H,
              year_is_character: false,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_month_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 187,
              month_startY: 135,
              month_sc_array: ["month_short_01.png","month_short_02.png","month_short_03.png","month_short_04.png","month_short_05.png","month_short_06.png","month_short_07.png","month_short_08.png","month_short_09.png","month_short_10.png","month_short_11.png","month_short_12.png"],
              month_tc_array: ["month_short_01.png","month_short_02.png","month_short_03.png","month_short_04.png","month_short_05.png","month_short_06.png","month_short_07.png","month_short_08.png","month_short_09.png","month_short_10.png","month_short_11.png","month_short_12.png"],
              month_en_array: ["month_short_01.png","month_short_02.png","month_short_03.png","month_short_04.png","month_short_05.png","month_short_06.png","month_short_07.png","month_short_08.png","month_short_09.png","month_short_10.png","month_short_11.png","month_short_12.png"],
              month_is_character: true ,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 128,
              day_startY: 133,
              day_sc_array: ["Act_SMALL_Font_01.png","Act_SMALL_Font_02.png","Act_SMALL_Font_03.png","Act_SMALL_Font_04.png","Act_SMALL_Font_05.png","Act_SMALL_Font_06.png","Act_SMALL_Font_07.png","Act_SMALL_Font_08.png","Act_SMALL_Font_09.png","Act_SMALL_Font_10.png"],
              day_tc_array: ["Act_SMALL_Font_01.png","Act_SMALL_Font_02.png","Act_SMALL_Font_03.png","Act_SMALL_Font_04.png","Act_SMALL_Font_05.png","Act_SMALL_Font_06.png","Act_SMALL_Font_07.png","Act_SMALL_Font_08.png","Act_SMALL_Font_09.png","Act_SMALL_Font_10.png"],
              day_en_array: ["Act_SMALL_Font_01.png","Act_SMALL_Font_02.png","Act_SMALL_Font_03.png","Act_SMALL_Font_04.png","Act_SMALL_Font_05.png","Act_SMALL_Font_06.png","Act_SMALL_Font_07.png","Act_SMALL_Font_08.png","Act_SMALL_Font_09.png","Act_SMALL_Font_10.png"],
              day_zero: 1,
              day_space: 4,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 277,
              y: 355,
              font_array: ["Act_SMALL_Font_01.png","Act_SMALL_Font_02.png","Act_SMALL_Font_03.png","Act_SMALL_Font_04.png","Act_SMALL_Font_05.png","Act_SMALL_Font_06.png","Act_SMALL_Font_07.png","Act_SMALL_Font_08.png","Act_SMALL_Font_09.png","Act_SMALL_Font_10.png"],
              padding: false,
              h_space: 2,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 165,
              y: 355,
              font_array: ["Act_SMALL_Font_01.png","Act_SMALL_Font_02.png","Act_SMALL_Font_03.png","Act_SMALL_Font_04.png","Act_SMALL_Font_05.png","Act_SMALL_Font_06.png","Act_SMALL_Font_07.png","Act_SMALL_Font_08.png","Act_SMALL_Font_09.png","Act_SMALL_Font_10.png"],
              padding: false,
              h_space: 1,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 218,
              y: 41,
              font_array: ["Act_Font_01.png","Act_Font_02.png","Act_Font_03.png","Act_Font_04.png","Act_Font_05.png","Act_Font_06.png","Act_Font_07.png","Act_Font_08.png","Act_Font_09.png","Act_Font_10.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time_AmPm = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              am_x: 60,
              am_y: 229,
              am_sc_path: 'Clock_AM.png',
              am_en_path: 'Clock_AM.png',
              pm_x: 60,
              pm_y: 229,
              pm_sc_path: 'Clock_PM.png',
              pm_en_path: 'Clock_PM.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 119,
              hour_startY: 207,
              hour_array: ["Time_01.png","Time_02.png","Time_03.png","Time_04.png","Time_05.png","Time_06.png","Time_07.png","Time_08.png","Time_09.png","Time_10.png"],
              hour_zero: 1,
              hour_space: 2,
              hour_angle: 0,
              hour_align: hmUI.align.LEFT,

              minute_startX: 243,
              minute_startY: 207,
              minute_array: ["Time_01.png","Time_02.png","Time_03.png","Time_04.png","Time_05.png","Time_06.png","Time_07.png","Time_08.png","Time_09.png","Time_10.png"],
              minute_zero: 1,
              minute_space: 2,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              second_startX: 362,
              second_startY: 219,
              second_array: ["Time_Small_01.png","Time_Small_02.png","Time_Small_03.png","Time_Small_04.png","Time_Small_05.png","Time_Small_06.png","Time_Small_07.png","Time_Small_08.png","Time_Small_09.png","Time_Small_10.png"],
              second_zero: 1,
              second_space: 3,
              second_angle: 0,
              second_follow: 0,
              second_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_AOD,
            });
            console.log('Watch_Face.Shortcuts');

            normal_stopwatch_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 216,
              y: 205,
              w: 30,
              h: 59,
              src: '0_Empty.png',
              type: hmUI.data_type.STOP_WATCH,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_countdown_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 359,
              y: 215,
              w: 73,
              h: 41,
              src: '0_Empty.png',
              type: hmUI.data_type.COUNT_DOWN,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_alarm_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 38,
              y: 349,
              w: 70,
              h: 77,
              type: hmUI.data_type.ALARM_CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 1,
              y: 178,
              w: 52,
              h: 108,
              src: '0_Empty.png',
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_spo2_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 114,
              y: 332,
              w: 49,
              h: 66,
              type: hmUI.data_type.SPO2,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 165,
              y: 350,
              w: 60,
              h: 67,
              src: '0_Empty.png',
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}