﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        const logger = Logger.getLogger('watchface_SashaCX75');
        //end of ignored block

        //dynamic modify start

        
        // start user_functions.js
// Start color Style change
        let colornumber_main = 1
        let totalcolors_main = 6
        let namecolor_main = ''

        function click_Color() {
            if(colornumber_main>=totalcolors_main) {
            colornumber_main=1;
                }
            else {
                colornumber_main=colornumber_main+1;
            }

if ( colornumber_main == 1) { namecolor_main = "Gray Style"}
if ( colornumber_main == 2) { namecolor_main = "Yellow Style"}
if ( colornumber_main == 3) { namecolor_main = "Orange Style"}
if ( colornumber_main == 4) { namecolor_main = "Blue Style"}
if ( colornumber_main == 5) { namecolor_main = "Green Style"}
if ( colornumber_main == 6) { namecolor_main = "Red Style"}
hmUI.showToast({text: namecolor_main });

             //hmUI.showToast({text: "color " + parseInt(colornumber_main) });
             normal_background_bg_img.setProperty(hmUI.prop.SRC, "bottom" + parseInt(colornumber_main) + ".png");
             normal_image_img.setProperty(hmUI.prop.SRC, "top" + parseInt(colornumber_main) + ".png");
                           
        }



        // Start change only backgournd colors
        let colornumber_main2 = 1
        let totalcolors_main2 = 6
        let namecolor_main2 = ''

        function click_Color2() {
            if(colornumber_main2>=totalcolors_main2) {
            colornumber_main2=1;
                }
            else {
                colornumber_main2=colornumber_main2+1;
            }

if ( colornumber_main2 == 1) { namecolor_main2 = "Gray BG"}
if ( colornumber_main2 == 2) { namecolor_main2 = "Yellow BG"}
if ( colornumber_main2 == 3) { namecolor_main2 = "Orange BG"}
if ( colornumber_main2 == 4) { namecolor_main2 = "Blue BG"}
if ( colornumber_main2 == 5) { namecolor_main2 = "Green BG"}
if ( colornumber_main2 == 6) { namecolor_main2 = "Red BG"}
hmUI.showToast({text: namecolor_main2 });

             //hmUI.showToast({text: "color " + parseInt(colornumber_main) });
             normal_background_bg_img.setProperty(hmUI.prop.SRC, "bottom" + parseInt(colornumber_main2) + ".png");
     //        normal_image_img.setProperty(hmUI.prop.SRC, "top" + parseInt(colornumber_main) + ".png");
                           
        }



        // Start change only top colors
        let colornumber_main3 = 1
        let totalcolors_main3 = 6
        let namecolor_main3 = ''

        function click_Color3() {
            if(colornumber_main3>=totalcolors_main3) {
            colornumber_main3=1;
                }
            else {
                colornumber_main3=colornumber_main3+1;
            }

if ( colornumber_main3 == 1) { namecolor_main3 = "Gray top"}
if ( colornumber_main3 == 2) { namecolor_main3 = "Yellow top "}
if ( colornumber_main3 == 3) { namecolor_main3 = "Orange top"}
if ( colornumber_main3 == 4) { namecolor_main3 = "Blue top"}
if ( colornumber_main3 == 5) { namecolor_main3 = "Green top"}
if ( colornumber_main3 == 6) { namecolor_main3 = "Red top"}
hmUI.showToast({text: namecolor_main3 });

             //hmUI.showToast({text: "color " + parseInt(colornumber_main) });
        //     normal_background_bg_img.setProperty(hmUI.prop.SRC, "bottom" + parseInt(colornumber_main3) + ".png");
              normal_image_img.setProperty(hmUI.prop.SRC, "top" + parseInt(colornumber_main3) + ".png");
                           
        }
/////////////////////////////////////////////////////////////////////////////////////////////////







//////////////////////////////////////////////////

        // change element 
        let btn_element_1 = ''
        let elementnumber_1 = 1
        let total_elemente = 8

        function click_elemente() {
            if(elementnumber_1==total_elemente) {
            elementnumber_1=1;
                UpdateElementeOne();
                }
            else {
                elementnumber_1=elementnumber_1+1;
                if(elementnumber_1==2) {
                  UpdateElementeTwo();
                }
                if(elementnumber_1==3) {
                  UpdateElementeThree();
                }
                if(elementnumber_1==4) {
                  UpdateElementeFour();
                }
                if(elementnumber_1==5) {
                  UpdateElementeFive();
                }
                if(elementnumber_1==6) {
                  UpdateElementeSix();
                }
                if(elementnumber_1==7) {
                  UpdateElementeSeven();
                }

                if(elementnumber_1==8) {
                  UpdateElementeEight();
                }
            }
            if(elementnumber_1==1) hmUI.showToast({text: 'Steps'});
            if(elementnumber_1==2) hmUI.showToast({text: 'Distance'});
            if(elementnumber_1==3) hmUI.showToast({text: 'Calories'});
            if(elementnumber_1==4) hmUI.showToast({text: 'Heart Rate'});
            if(elementnumber_1==5) hmUI.showToast({text: 'Oxygen blood'});
            if(elementnumber_1==6) hmUI.showToast({text: 'Battery'});
            if(elementnumber_1==7) hmUI.showToast({text: 'Weather'});
            if(elementnumber_1==8) hmUI.showToast({text: 'Barometer'});

        }

        //Steps
        function UpdateElementeOne(){



       normal_altimeter_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
       normal_altimeter_text_separator_img.setProperty(hmUI.prop.VISIBLE, false);

       normal_temperature_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
       normal_temperature_current_separator_img.setProperty(hmUI.prop.VISIBLE, false);
       normal_weather_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, false);

       normal_battery_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, false);
       normal_battery_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
       normal_battery_text_separator_img.setProperty(hmUI.prop.VISIBLE, false);
   
       normal_distance_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
       normal_distance_text_separator_img.setProperty(hmUI.prop.VISIBLE, false);

       normal_calorie_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
       normal_calorie_current_separator_img.setProperty(hmUI.prop.VISIBLE, false);

       normal_step_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, true);
       normal_step_current_text_img.setProperty(hmUI.prop.VISIBLE, true);
       normal_step_current_separator_img.setProperty(hmUI.prop.VISIBLE, true);

       normal_heart_rate_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
       normal_heart_rate_text_separator_img.setProperty(hmUI.prop.VISIBLE, false);
       normal_heart_rate_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, false);

       normal_spo2_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
       normal_spo2_text_separator_img.setProperty(hmUI.prop.VISIBLE, false);


        normal_step_pointer_progress_img_pointer.setProperty(hmUI.prop.VISIBLE, true);
        normal_step_icon_img.setProperty(hmUI.prop.VISIBLE, true);
        normal_calorie_pointer_progress_img_pointer.setProperty(hmUI.prop.VISIBLE, false);
        normal_calorie_icon_img .setProperty(hmUI.prop.VISIBLE, false);



        normal_temperature_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, false);
        normal_pai_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, false);
        normal_spo2_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, false);
        normal_heart_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, false);
        normal_step_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, true);

        }

        //Distance
        function UpdateElementeTwo(){

       normal_altimeter_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
       normal_altimeter_text_separator_img.setProperty(hmUI.prop.VISIBLE, false);

       normal_temperature_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
       normal_temperature_current_separator_img.setProperty(hmUI.prop.VISIBLE, false);
       normal_weather_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, false);

       normal_battery_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, false);
       normal_battery_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
       normal_battery_text_separator_img.setProperty(hmUI.prop.VISIBLE, false);
   
       normal_distance_text_text_img.setProperty(hmUI.prop.VISIBLE, true);
       normal_distance_text_separator_img.setProperty(hmUI.prop.VISIBLE, true);

       normal_calorie_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
       normal_calorie_current_separator_img.setProperty(hmUI.prop.VISIBLE, false);

       normal_step_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, false);
       normal_step_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
       normal_step_current_separator_img.setProperty(hmUI.prop.VISIBLE, false);

       normal_heart_rate_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
       normal_heart_rate_text_separator_img.setProperty(hmUI.prop.VISIBLE, false);
       normal_heart_rate_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, false);

       normal_spo2_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
       normal_spo2_text_separator_img.setProperty(hmUI.prop.VISIBLE, false);

        normal_temperature_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, false);
        normal_pai_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, false);
        normal_spo2_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, false);
        normal_heart_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, false);
        normal_step_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, true);

        normal_step_pointer_progress_img_pointer.setProperty(hmUI.prop.VISIBLE, true);
        normal_step_icon_img.setProperty(hmUI.prop.VISIBLE, true);
        normal_calorie_pointer_progress_img_pointer.setProperty(hmUI.prop.VISIBLE, false);
        normal_calorie_icon_img .setProperty(hmUI.prop.VISIBLE, false);

        }

       //Calories
        function UpdateElementeThree(){

       normal_altimeter_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
       normal_altimeter_text_separator_img.setProperty(hmUI.prop.VISIBLE, false);

       normal_temperature_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
       normal_temperature_current_separator_img.setProperty(hmUI.prop.VISIBLE, false);
       normal_weather_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, false);

       normal_battery_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, false);
       normal_battery_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
       normal_battery_text_separator_img.setProperty(hmUI.prop.VISIBLE, false);
   
       normal_distance_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
       normal_distance_text_separator_img.setProperty(hmUI.prop.VISIBLE, false);

       normal_calorie_current_text_img.setProperty(hmUI.prop.VISIBLE, true);
       normal_calorie_current_separator_img.setProperty(hmUI.prop.VISIBLE, true);

       normal_step_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, false);
       normal_step_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
       normal_step_current_separator_img.setProperty(hmUI.prop.VISIBLE, false);

       normal_heart_rate_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
       normal_heart_rate_text_separator_img.setProperty(hmUI.prop.VISIBLE, false);
       normal_heart_rate_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, false);

       normal_spo2_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
       normal_spo2_text_separator_img.setProperty(hmUI.prop.VISIBLE, false);

        normal_temperature_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, false);
        normal_pai_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, true);
        normal_spo2_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, false);
        normal_heart_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, false);
        normal_step_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, false);

        normal_step_pointer_progress_img_pointer.setProperty(hmUI.prop.VISIBLE, false);
        normal_step_icon_img.setProperty(hmUI.prop.VISIBLE, false);
        normal_calorie_pointer_progress_img_pointer.setProperty(hmUI.prop.VISIBLE, true);
        normal_calorie_icon_img .setProperty(hmUI.prop.VISIBLE, true);

        }


       //Heart Rate
        function UpdateElementeFour(){

       normal_altimeter_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
       normal_altimeter_text_separator_img.setProperty(hmUI.prop.VISIBLE, false);

       normal_temperature_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
       normal_temperature_current_separator_img.setProperty(hmUI.prop.VISIBLE, false);
       normal_weather_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, false);

       normal_battery_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, false);
       normal_battery_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
       normal_battery_text_separator_img.setProperty(hmUI.prop.VISIBLE, false);
   
       normal_distance_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
       normal_distance_text_separator_img.setProperty(hmUI.prop.VISIBLE, false);

       normal_calorie_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
       normal_calorie_current_separator_img.setProperty(hmUI.prop.VISIBLE, false);

       normal_step_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, false);
       normal_step_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
       normal_step_current_separator_img.setProperty(hmUI.prop.VISIBLE, false);

       normal_heart_rate_text_text_img.setProperty(hmUI.prop.VISIBLE, true);
       normal_heart_rate_text_separator_img.setProperty(hmUI.prop.VISIBLE, true);
       normal_heart_rate_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, true);

       normal_spo2_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
       normal_spo2_text_separator_img.setProperty(hmUI.prop.VISIBLE, false);

        normal_temperature_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, false);
        normal_pai_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, false);
        normal_spo2_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, false);
        normal_heart_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, true);
        normal_step_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, false);

        normal_step_pointer_progress_img_pointer.setProperty(hmUI.prop.VISIBLE, false);
        normal_step_icon_img.setProperty(hmUI.prop.VISIBLE, false);
        normal_calorie_pointer_progress_img_pointer.setProperty(hmUI.prop.VISIBLE, true);
        normal_calorie_icon_img .setProperty(hmUI.prop.VISIBLE, true);
        }

       //Oxygen Blood
        function UpdateElementeFive(){

       normal_altimeter_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
       normal_altimeter_text_separator_img.setProperty(hmUI.prop.VISIBLE, false);

       normal_temperature_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
       normal_temperature_current_separator_img.setProperty(hmUI.prop.VISIBLE, false);
       normal_weather_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, false);

       normal_battery_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, false);
       normal_battery_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
       normal_battery_text_separator_img.setProperty(hmUI.prop.VISIBLE, false);
   
       normal_distance_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
       normal_distance_text_separator_img.setProperty(hmUI.prop.VISIBLE, false);

       normal_calorie_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
       normal_calorie_current_separator_img.setProperty(hmUI.prop.VISIBLE, false);

       normal_step_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, false);
       normal_step_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
       normal_step_current_separator_img.setProperty(hmUI.prop.VISIBLE, false);

       normal_heart_rate_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
       normal_heart_rate_text_separator_img.setProperty(hmUI.prop.VISIBLE, false);
       normal_heart_rate_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, false);

       normal_spo2_text_text_img.setProperty(hmUI.prop.VISIBLE, true);
       normal_spo2_text_separator_img.setProperty(hmUI.prop.VISIBLE, true);

        normal_temperature_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, false);
        normal_pai_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, false);
        normal_spo2_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, true);
        normal_heart_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, false);
        normal_step_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, false);

        normal_step_pointer_progress_img_pointer.setProperty(hmUI.prop.VISIBLE, false);
        normal_step_icon_img.setProperty(hmUI.prop.VISIBLE, false);
        normal_calorie_pointer_progress_img_pointer.setProperty(hmUI.prop.VISIBLE, true);
        normal_calorie_icon_img .setProperty(hmUI.prop.VISIBLE, true);

        }


       //Battery
        function UpdateElementeSix(){

       normal_altimeter_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
       normal_altimeter_text_separator_img.setProperty(hmUI.prop.VISIBLE, false);

       normal_temperature_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
       normal_temperature_current_separator_img.setProperty(hmUI.prop.VISIBLE, false);
       normal_weather_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, false);

       normal_battery_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, true);
       normal_battery_text_text_img.setProperty(hmUI.prop.VISIBLE, true);
       normal_battery_text_separator_img.setProperty(hmUI.prop.VISIBLE, true);
   
       normal_distance_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
       normal_distance_text_separator_img.setProperty(hmUI.prop.VISIBLE, false);

       normal_calorie_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
       normal_calorie_current_separator_img.setProperty(hmUI.prop.VISIBLE, false);

       normal_step_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, false);
       normal_step_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
       normal_step_current_separator_img.setProperty(hmUI.prop.VISIBLE, false);

       normal_heart_rate_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
       normal_heart_rate_text_separator_img.setProperty(hmUI.prop.VISIBLE, false);
       normal_heart_rate_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, false);

       normal_spo2_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
       normal_spo2_text_separator_img.setProperty(hmUI.prop.VISIBLE, false);

        normal_temperature_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, false);
        normal_pai_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, false);
        normal_spo2_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, false);
        normal_heart_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, false);
        normal_step_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, false);

        normal_step_pointer_progress_img_pointer.setProperty(hmUI.prop.VISIBLE, false);
        normal_step_icon_img.setProperty(hmUI.prop.VISIBLE, false);
        normal_calorie_pointer_progress_img_pointer.setProperty(hmUI.prop.VISIBLE, true);
        normal_calorie_icon_img .setProperty(hmUI.prop.VISIBLE, true);
        }


       //Weather
        function UpdateElementeSeven(){

       normal_altimeter_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
       normal_altimeter_text_separator_img.setProperty(hmUI.prop.VISIBLE, false);

       normal_temperature_current_text_img.setProperty(hmUI.prop.VISIBLE, true);
       normal_temperature_current_separator_img.setProperty(hmUI.prop.VISIBLE, true);
       normal_weather_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, true);

       normal_battery_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, false);
       normal_battery_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
       normal_battery_text_separator_img.setProperty(hmUI.prop.VISIBLE, false);
   
       normal_distance_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
       normal_distance_text_separator_img.setProperty(hmUI.prop.VISIBLE, false);

       normal_calorie_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
       normal_calorie_current_separator_img.setProperty(hmUI.prop.VISIBLE, false);

       normal_step_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, false);
       normal_step_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
       normal_step_current_separator_img.setProperty(hmUI.prop.VISIBLE, false);

       normal_heart_rate_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
       normal_heart_rate_text_separator_img.setProperty(hmUI.prop.VISIBLE, false);
       normal_heart_rate_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, false);

       normal_spo2_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
       normal_spo2_text_separator_img.setProperty(hmUI.prop.VISIBLE, false);

        normal_temperature_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, true);
        normal_pai_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, false);
        normal_spo2_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, false);
        normal_heart_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, false);
        normal_step_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, false);

        normal_step_pointer_progress_img_pointer.setProperty(hmUI.prop.VISIBLE, false);
        normal_step_icon_img.setProperty(hmUI.prop.VISIBLE, false);
        normal_calorie_pointer_progress_img_pointer.setProperty(hmUI.prop.VISIBLE, true);
        normal_calorie_icon_img .setProperty(hmUI.prop.VISIBLE, true);
        }


       //Altimeter
        function UpdateElementeEight(){

       normal_altimeter_text_text_img.setProperty(hmUI.prop.VISIBLE, true);
       normal_altimeter_text_separator_img.setProperty(hmUI.prop.VISIBLE, true);

       normal_temperature_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
       normal_temperature_current_separator_img.setProperty(hmUI.prop.VISIBLE, false);
       normal_weather_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, false);

       normal_battery_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, false);
       normal_battery_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
       normal_battery_text_separator_img.setProperty(hmUI.prop.VISIBLE, false);
   
       normal_distance_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
       normal_distance_text_separator_img.setProperty(hmUI.prop.VISIBLE, false);

       normal_calorie_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
       normal_calorie_current_separator_img.setProperty(hmUI.prop.VISIBLE, false);

       normal_step_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, false);
       normal_step_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
       normal_step_current_separator_img.setProperty(hmUI.prop.VISIBLE, false);

       normal_heart_rate_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
       normal_heart_rate_text_separator_img.setProperty(hmUI.prop.VISIBLE, false);
       normal_heart_rate_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, false);

       normal_spo2_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
       normal_spo2_text_separator_img.setProperty(hmUI.prop.VISIBLE, false);

        normal_temperature_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, false);
        normal_pai_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, false);
        normal_spo2_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, false);
        normal_heart_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, false);
        normal_step_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, false);

        normal_step_pointer_progress_img_pointer.setProperty(hmUI.prop.VISIBLE, false);
        normal_step_icon_img.setProperty(hmUI.prop.VISIBLE, false);
        normal_calorie_pointer_progress_img_pointer.setProperty(hmUI.prop.VISIBLE, true);
        normal_calorie_icon_img .setProperty(hmUI.prop.VISIBLE, true);
        }
        // end user_functions.js

        let normal_background_bg_img = ''
        let normal_analog_clock_pro_second_pointer_img = ''
        let normal_timerUpdateSec = undefined;
        let normal_image_img = ''
        let normal_altimeter_text_text_img = ''
        let normal_altimeter_text_separator_img = ''
        let normal_temperature_current_text_img = ''
        let normal_temperature_current_separator_img = ''
        let normal_weather_image_progress_img_level = ''
        let normal_battery_image_progress_img_level = ''
        let normal_battery_text_text_img = ''
        let normal_battery_text_separator_img = ''
        let normal_distance_text_text_img = ''
        let normal_distance_text_separator_img = ''
        let normal_calorie_pointer_progress_img_pointer = ''
        let normal_calorie_icon_img = ''
        let normal_calorie_current_text_img = ''
        let normal_calorie_current_separator_img = ''
        let normal_step_image_progress_img_level = ''
        let normal_step_current_text_img = ''
        let normal_step_current_separator_img = ''
        let normal_step_pointer_progress_img_pointer = ''
        let normal_step_icon_img = ''
        let normal_spo2_text_text_img = ''
        let normal_spo2_text_separator_img = ''
        let normal_heart_rate_pointer_progress_img_pointer = ''
        let normal_heart_rate_icon_img = ''
        let normal_heart_rate_text_text_img = ''
        let normal_heart_rate_text_separator_img = ''
        let normal_heart_rate_image_progress_img_level = ''
        let normal_moon_image_progress_img_level = ''
        let normal_date_img_date_week_img = ''
        let normal_date_img_date_day = ''
        let normal_digital_clock_img_time_second = ''
        let normal_digital_clock_second_separator_img = ''
        let normal_digital_clock_img_time_minute = ''
        let normal_digital_clock_minute_separator_img = ''
        let normal_digital_clock_img_time_hour = ''
        let normal_digital_clock_hour_separator_img = ''
        let normal_digital_clock_img_time_AmPm = ''
        let normal_system_dnd_img = ''
        let normal_system_disconnect_img = ''
        let normal_system_clock_img = ''
        let normal_analog_clock_time_pointer_hour = ''
        let normal_analog_clock_time_pointer_minute = ''
        let idle_background_bg_img = ''
        let idle_analog_clock_pro_second_pointer_img = ''
        let idle_timerUpdateSec = undefined;
        let idle_image_img = ''
        let idle_battery_image_progress_img_level = ''
        let idle_battery_text_text_img = ''
        let idle_battery_text_separator_img = ''
        let idle_calorie_pointer_progress_img_pointer = ''
        let idle_calorie_icon_img = ''
        let idle_heart_rate_pointer_progress_img_pointer = ''
        let idle_heart_rate_icon_img = ''
        let idle_moon_image_progress_img_level = ''
        let idle_date_img_date_week_img = ''
        let idle_date_img_date_day = ''
        let idle_digital_clock_img_time_second = ''
        let idle_digital_clock_second_separator_img = ''
        let idle_digital_clock_img_time_minute = ''
        let idle_digital_clock_minute_separator_img = ''
        let idle_digital_clock_img_time_hour = ''
        let idle_digital_clock_hour_separator_img = ''
        let idle_digital_clock_img_time_AmPm = ''
        let idle_system_dnd_img = ''
        let idle_system_disconnect_img = ''
        let idle_system_clock_img = ''
        let idle_analog_clock_time_pointer_hour = ''
        let idle_analog_clock_time_pointer_minute = ''
        let normal_stopwatch_jumpable_img_click = ''
        let normal_countdown_jumpable_img_click = ''
        let normal_alarm_jumpable_img_click = ''
        let normal_sunrise_jumpable_img_click = ''
        let normal_temperature_jumpable_img_click = ''
        let normal_pai_jumpable_img_click = ''
        let normal_spo2_jumpable_img_click = ''
        let normal_heart_jumpable_img_click = ''
        let normal_step_jumpable_img_click = ''
        let Button_1 = ''
        let Button_2 = ''
        let Button_3 = ''
        let Button_4 = ''
        let Button_5 = ''
        let timeSensor = ''


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 466,
              h: 466,
              src: 'bottom1.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            const deviceInfo = hmSetting.getDeviceInfo();
            if (!timeSensor) timeSensor = hmSensor.createSensor(hmSensor.id.TIME);
            // normal_analog_clock_pro_second_pointer_img = hmUI.createWidget(hmUI.widget.TIME_POINTER_PRO, {
              // src: 's.png',
              // center_x: 233,
              // center_y: 233,
              // x: 235,
              // y: 232,
              // start_angle: 0,
              // end_angle: 360,
              // type: hmUI.data_type.second,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });


            normal_analog_clock_pro_second_pointer_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: deviceInfo.width,
              h: deviceInfo.height,
              pos_x: 233 - 235,
              pos_y: 233 - 232,
              center_x: 233,
              center_y: 233,
              src: 's.png',
              angle: 0,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            let screenType = hmSetting.getScreenType();
            normal_image_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'top6.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_altimeter_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 181,
              y: 325,
              font_array: ["t0.png","t1.png","t2.png","t3.png","t4.png","t5.png","t6.png","t7.png","t8.png","t9.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.ALTIMETER,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_altimeter_text_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 186,
              y: 318,
              src: 'icon_Baro.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 221,
              y: 325,
              font_array: ["t0.png","t1.png","t2.png","t3.png","t4.png","t5.png","t6.png","t7.png","t8.png","t9.png"],
              padding: false,
              h_space: -2,
              unit_sc: 'Weather_Symbo1.png',
              unit_tc: 'Weather_Symbo1.png',
              unit_en: 'Weather_Symbo1.png',
              negative_image: 'Weather_Symbo2.png',
              invalid_image: 'Weather_Symbo2.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 194,
              y: 318,
              src: 'icon_wea.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 173,
              y: 333,
              image_array: ["Weather_icon_01.png","Weather_icon_02.png","Weather_icon_03.png","Weather_icon_04.png","Weather_icon_05.png","Weather_icon_06.png","Weather_icon_07.png","Weather_icon_08.png","Weather_icon_09.png","Weather_icon_10.png","Weather_icon_11.png","Weather_icon_12.png","Weather_icon_13.png","Weather_icon_14.png","Weather_icon_15.png","Weather_icon_16.png","Weather_icon_17.png","Weather_icon_18.png","Weather_icon_19.png","Weather_icon_20.png","Weather_icon_21.png","Weather_icon_22.png","Weather_icon_23.png","Weather_icon_24.png","Weather_icon_25.png","Weather_icon_26.png","Weather_icon_27.png","Weather_icon_28.png","Weather_icon_29.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 184,
              y: 289,
              image_array: ["b1.png","b2.png","b3.png","b4.png","b5.png","b6.png","b7.png"],
              image_length: 7,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 183,
              y: 325,
              font_array: ["t0.png","t1.png","t2.png","t3.png","t4.png","t5.png","t6.png","t7.png","t8.png","t9.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'Batt_symbo.png',
              unit_tc: 'Batt_symbo.png',
              unit_en: 'Batt_symbo.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 198,
              y: 318,
              src: 'icon_Batt.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_distance_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 166,
              y: 325,
              font_array: ["t0.png","t1.png","t2.png","t3.png","t4.png","t5.png","t6.png","t7.png","t8.png","t9.png"],
              padding: false,
              h_space: -2,
              unit_sc: 'dis_KM.png',
              unit_tc: 'dis_KM.png',
              unit_en: 'dis_KM.png',
              imperial_unit_sc: 'dis_Mi.png',
              imperial_unit_tc: 'dis_Mi.png',
              imperial_unit_en: 'dis_Mi.png',
              dot_image: 'dot.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.DISTANCE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_distance_text_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 195,
              y: 318,
              src: 'icon_dis.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_calorie_pointer_progress_img_pointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
              src: 'cal_point.png',
              center_x: 373,
              center_y: 233,
              x: 53,
              y: 53,
              start_angle: 225,
              end_angle: 495,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_calorie_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 321,
              y: 180,
              src: 'cal_icon.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_calorie_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 181,
              y: 325,
              font_array: ["t0.png","t1.png","t2.png","t3.png","t4.png","t5.png","t6.png","t7.png","t8.png","t9.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_calorie_current_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 195,
              y: 318,
              src: 'icon_Cal.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 210,
              y: 300,
              image_array: ["s1.png","s2.png","s3.png","s4.png","s5.png"],
              image_length: 5,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 169,
              y: 325,
              font_array: ["t0.png","t1.png","t2.png","t3.png","t4.png","t5.png","t6.png","t7.png","t8.png","t9.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 207,
              y: 318,
              src: 'icon_Steps.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_pointer_progress_img_pointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
              src: 'cal_point.png',
              center_x: 373,
              center_y: 233,
              x: 53,
              y: 53,
              start_angle: 225,
              end_angle: 495,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 321,
              y: 180,
              src: 'step_icon.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_spo2_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 187,
              y: 326,
              font_array: ["t0.png","t1.png","t2.png","t3.png","t4.png","t5.png","t6.png","t7.png","t8.png","t9.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'Batt_symbo.png',
              unit_tc: 'Batt_symbo.png',
              unit_en: 'Batt_symbo.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.SPO2,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_spo2_text_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 172,
              y: 315,
              src: 'icon_O2.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_pointer_progress_img_pointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
              src: 'heart_point.png',
              center_x: 91,
              center_y: 233,
              x: 53,
              y: 53,
              start_angle: 225,
              end_angle: 495,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 39,
              y: 180,
              src: 'heart_icon.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 193,
              y: 325,
              font_array: ["t0.png","t1.png","t2.png","t3.png","t4.png","t5.png","t6.png","t7.png","t8.png","t9.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 185,
              y: 318,
              src: 'icon_pulse.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 191,
              y: 301,
              image_array: ["Zone1.png","Zone2.png","Zone3.png","Zone4.png","Zone5.png","Zone6.png"],
              image_length: 6,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_moon_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 219,
              y: 160,
              image_array: ["Moon_01.png","Moon_02.png","Moon_03.png","Moon_04.png","Moon_05.png","Moon_06.png","Moon_07.png","Moon_08.png","Moon_09.png","Moon_10.png","Moon_11.png","Moon_12.png","Moon_13.png","Moon_14.png","Moon_15.png","Moon_16.png","Moon_17.png","Moon_18.png","Moon_19.png","Moon_20.png","Moon_21.png","Moon_22.png","Moon_23.png","Moon_24.png","Moon_25.png","Moon_26.png","Moon_27.png","Moon_28.png","Moon_29.png","Moon_30.png"],
              image_length: 30,
              type: hmUI.data_type.MOON,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 232,
              y: 38,
              week_en: ["w1.png","w2.png","w3.png","w4.png","w5.png","w6.png","w7.png"],
              week_tc: ["w1.png","w2.png","w3.png","w4.png","w5.png","w6.png","w7.png"],
              week_sc: ["w1.png","w2.png","w3.png","w4.png","w5.png","w6.png","w7.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 193,
              day_startY: 38,
              day_sc_array: ["d0.png","d1.png","d2.png","d3.png","d4.png","d5.png","d6.png","d7.png","d8.png","d9.png"],
              day_tc_array: ["d0.png","d1.png","d2.png","d3.png","d4.png","d5.png","d6.png","d7.png","d8.png","d9.png"],
              day_en_array: ["d0.png","d1.png","d2.png","d3.png","d4.png","d5.png","d6.png","d7.png","d8.png","d9.png"],
              day_zero: 1,
              day_space: 0,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time_second = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              second_startX: 286,
              second_startY: 84,
              second_array: ["d0.png","d1.png","d2.png","d3.png","d4.png","d5.png","d6.png","d7.png","d8.png","d9.png"],
              second_zero: 1,
              second_space: 0,
              second_angle: 0,
              second_follow: 0,
              second_align: hmUI.align.LEFT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_second_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 182,
              y: 388,
              src: 'ST.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time_minute = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              minute_startX: 232,
              minute_startY: 64,
              minute_array: ["t0.png","t1.png","t2.png","t3.png","t4.png","t5.png","t6.png","t7.png","t8.png","t9.png"],
              minute_zero: 1,
              minute_space: 0,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_minute_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 147,
              y: 125,
              src: '24H.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time_hour = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 161,
              hour_startY: 64,
              hour_array: ["t0.png","t1.png","t2.png","t3.png","t4.png","t5.png","t6.png","t7.png","t8.png","t9.png"],
              hour_zero: 1,
              hour_space: 0,
              hour_angle: 0,
              hour_align: hmUI.align.LEFT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_hour_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 218,
              y: 60,
              src: 'maohao.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time_AmPm = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              am_x: 142,
              am_y: 120,
              am_sc_path: 'Clock_AM.png',
              am_en_path: 'Clock_AM.png',
              pm_x: 142,
              pm_y: 120,
              pm_sc_path: 'Clock_PM.png',
              pm_en_path: 'Clock_PM.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_dnd_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 227,
              y: 393,
              src: 'System_DND.png',
              type: hmUI.system_status.DISTURB,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 177,
              y: 387,
              src: 'System_BT_OFF.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 268,
              y: 389,
              src: 'System_Alarm.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_hour = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              hour_path: 'h.png',
              hour_centerX: 233,
              hour_centerY: 233,
              hour_posX: 23,
              hour_posY: 232,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_minute = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              minute_path: 'm_xp.png',
              minute_centerX: 233,
              minute_centerY: 233,
              minute_posX: 23,
              minute_posY: 232,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            idle_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 466,
              h: 466,
              src: 'bottom1.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            // idle_analog_clock_pro_second_pointer_img = hmUI.createWidget(hmUI.widget.TIME_POINTER_PRO, {
              // src: 's.png',
              // center_x: 233,
              // center_y: 233,
              // x: 235,
              // y: 232,
              // start_angle: 0,
              // end_angle: 360,
              // type: hmUI.data_type.second,
              // show_level: hmUI.show_level.ONLY_AOD,
            // });


            idle_analog_clock_pro_second_pointer_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: deviceInfo.width,
              h: deviceInfo.height,
              pos_x: 233 - 235,
              pos_y: 233 - 232,
              center_x: 233,
              center_y: 233,
              src: 's.png',
              angle: 0,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_image_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'top1.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_battery_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 184,
              y: 289,
              image_array: ["b1.png","b2.png","b3.png","b4.png","b5.png","b6.png","b7.png"],
              image_length: 7,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 183,
              y: 325,
              font_array: ["t0.png","t1.png","t2.png","t3.png","t4.png","t5.png","t6.png","t7.png","t8.png","t9.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'Batt_symbo.png',
              unit_tc: 'Batt_symbo.png',
              unit_en: 'Batt_symbo.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_battery_text_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 198,
              y: 318,
              src: 'icon_Batt.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_calorie_pointer_progress_img_pointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
              src: 'cal_point.png',
              center_x: 373,
              center_y: 233,
              x: 53,
              y: 53,
              start_angle: -135,
              end_angle: 135,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_calorie_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 321,
              y: 180,
              src: 'cal_icon.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_heart_rate_pointer_progress_img_pointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
              src: 'heart_point.png',
              center_x: 91,
              center_y: 233,
              x: 53,
              y: 53,
              start_angle: -135,
              end_angle: 135,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_heart_rate_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 39,
              y: 180,
              src: 'heart_icon.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_moon_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 219,
              y: 160,
              image_array: ["Moon_01.png","Moon_02.png","Moon_03.png","Moon_04.png","Moon_05.png","Moon_06.png","Moon_07.png","Moon_08.png","Moon_09.png","Moon_10.png","Moon_11.png","Moon_12.png","Moon_13.png","Moon_14.png","Moon_15.png","Moon_16.png","Moon_17.png","Moon_18.png","Moon_19.png","Moon_20.png","Moon_21.png","Moon_22.png","Moon_23.png","Moon_24.png","Moon_25.png","Moon_26.png","Moon_27.png","Moon_28.png","Moon_29.png","Moon_30.png"],
              image_length: 30,
              type: hmUI.data_type.MOON,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 232,
              y: 38,
              week_en: ["w1.png","w2.png","w3.png","w4.png","w5.png","w6.png","w7.png"],
              week_tc: ["w1.png","w2.png","w3.png","w4.png","w5.png","w6.png","w7.png"],
              week_sc: ["w1.png","w2.png","w3.png","w4.png","w5.png","w6.png","w7.png"],
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 193,
              day_startY: 38,
              day_sc_array: ["d0.png","d1.png","d2.png","d3.png","d4.png","d5.png","d6.png","d7.png","d8.png","d9.png"],
              day_tc_array: ["d0.png","d1.png","d2.png","d3.png","d4.png","d5.png","d6.png","d7.png","d8.png","d9.png"],
              day_en_array: ["d0.png","d1.png","d2.png","d3.png","d4.png","d5.png","d6.png","d7.png","d8.png","d9.png"],
              day_zero: 1,
              day_space: 0,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time_second = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              second_startX: 286,
              second_startY: 84,
              second_array: ["d0.png","d1.png","d2.png","d3.png","d4.png","d5.png","d6.png","d7.png","d8.png","d9.png"],
              second_zero: 1,
              second_space: 0,
              second_angle: 0,
              second_follow: 0,
              second_align: hmUI.align.LEFT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_second_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 182,
              y: 388,
              src: 'ST.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time_minute = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              minute_startX: 232,
              minute_startY: 64,
              minute_array: ["t0.png","t1.png","t2.png","t3.png","t4.png","t5.png","t6.png","t7.png","t8.png","t9.png"],
              minute_zero: 1,
              minute_space: 0,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_minute_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 147,
              y: 125,
              src: '24H.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time_hour = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 161,
              hour_startY: 64,
              hour_array: ["t0.png","t1.png","t2.png","t3.png","t4.png","t5.png","t6.png","t7.png","t8.png","t9.png"],
              hour_zero: 1,
              hour_space: 0,
              hour_angle: 0,
              hour_align: hmUI.align.LEFT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_hour_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 218,
              y: 60,
              src: 'maohao.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time_AmPm = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              am_x: 142,
              am_y: 120,
              am_sc_path: 'Clock_AM.png',
              am_en_path: 'Clock_AM.png',
              pm_x: 142,
              pm_y: 120,
              pm_sc_path: 'Clock_PM.png',
              pm_en_path: 'Clock_PM.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_system_dnd_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 227,
              y: 393,
              src: 'System_DND.png',
              type: hmUI.system_status.DISTURB,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 177,
              y: 387,
              src: 'System_BT_OFF.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 268,
              y: 389,
              src: 'System_Alarm.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_analog_clock_time_pointer_hour = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              hour_path: 'h.png',
              hour_centerX: 233,
              hour_centerY: 233,
              hour_posX: 23,
              hour_posY: 232,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_analog_clock_time_pointer_minute = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              minute_path: 'm_xp.png',
              minute_centerX: 233,
              minute_centerY: 233,
              minute_posX: 23,
              minute_posY: 232,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            normal_stopwatch_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 277,
              y: 81,
              w: 48,
              h: 39,
              type: hmUI.data_type.STOP_WATCH,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_countdown_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 215,
              y: 75,
              w: 20,
              h: 46,
              type: hmUI.data_type.COUNT_DOWN,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_alarm_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 259,
              y: 380,
              w: 43,
              h: 46,
              type: hmUI.data_type.ALARM_CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sunrise_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 207,
              y: 151,
              w: 46,
              h: 36,
              type: hmUI.data_type.SUN_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 185,
              y: 334,
              w: 104,
              h: 34,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_pai_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 184,
              y: 332,
              w: 105,
              h: 36,
              type: hmUI.data_type.PAI_WEEKLY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_spo2_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 185,
              y: 335,
              w: 108,
              h: 34,
              type: hmUI.data_type.SPO2,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 186,
              y: 335,
              w: 104,
              h: 34,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 186,
              y: 335,
              w: 94,
              h: 33,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            Button_1 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 184,
              y: 30,
              w: 98,
              h: 39,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'ScheduleCalScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_2 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 205,
              y: 205,
              w: 65,
              h: 55,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'short.png',
              normal_src: 'short.png',
              click_func: (button_widget) => {
                /// change elemente
                click_elemente()
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_3 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 206,
              y: 414,
              w: 65,
              h: 55,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'short.png',
              normal_src: 'short.png',
              click_func: (button_widget) => {
                /// change color style
                click_Color()
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_4 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 6,
              y: 205,
              w: 65,
              h: 55,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'short.png',
              normal_src: 'short.png',
              click_func: (button_widget) => {
                /// change color background
                click_Color2()
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_5 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 410,
              y: 205,
              w: 65,
              h: 55,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'short.png',
              normal_src: 'short.png',
              click_func: (button_widget) => {
                /// change color Top
                click_Color3()
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            function time_update(updateHour = false, updateMinute = false) {
              let hour = timeSensor.hour;
              let minute = timeSensor.minute;
              let second = timeSensor.second;

              let normal_fullAngle_second = 360;
              let normal_angle_second = 0 + normal_fullAngle_second*second/60;
              if (normal_analog_clock_pro_second_pointer_img) normal_analog_clock_pro_second_pointer_img.setProperty(hmUI.prop.ANGLE, normal_angle_second);

              let idle_fullAngle_second = 360;
              let idle_angle_second = 0 + idle_fullAngle_second*second/60;
              if (idle_analog_clock_pro_second_pointer_img) idle_analog_clock_pro_second_pointer_img.setProperty(hmUI.prop.ANGLE, idle_angle_second);

            };

            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                time_update(true, true);
                if (screenType == hmSetting.screen_type.WATCHFACE) {
                  if (!normal_timerUpdateSec) {
                    let animDelay = timeSensor.utc % 1000;
                    let animRepeat = 1000;
                    normal_timerUpdateSec = timer.createTimer(animDelay, animRepeat, (function (option) {
                      time_update(false, false);
                    }));  // end timer 
                  };  // end timer check
                };  // end screenType

                if (screenType == hmSetting.screen_type.AOD) {
                  if (!idle_timerUpdateSec) {
                    let animDelay = timeSensor.utc % 1000;
                    let animRepeat = 1000;
                    idle_timerUpdateSec = timer.createTimer(animDelay, animRepeat, (function (option) {
                      time_update(false, false);
                    }));  // end timer 
                  };  // end timer check
                };  // end screenType


              }),
              pause_call: (function () {
                if (normal_timerUpdateSec) {
                  timer.stopTimer(normal_timerUpdateSec);
                  normal_timerUpdateSec = undefined;
                }
                if (idle_timerUpdateSec) {
                  timer.stopTimer(idle_timerUpdateSec);
                  idle_timerUpdateSec = undefined;
                }

              }),
            });

                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}