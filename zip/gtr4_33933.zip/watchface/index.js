﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        const logger = Logger.getLogger('watchface_SashaCX75');
        //end of ignored block

        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_sun_image_progress_img_level = ''
        let normal_sun_pointer_progress_img_pointer = ''
		let normal_moon_pointer_progress_img_pointer = ''
        let normal_pai_icon_img = ''
        let normal_heart_rate_text_text_img = ''
        let normal_heart_rate_image_progress_img_level = ''
        let normal_calorie_current_text_img = ''
        let normal_battery_text_text_img = ''
        let normal_battery_image_progress_img_level = ''
        let normal_distance_text_text_img = ''
        let normal_system_disconnect_img = ''
        let normal_system_clock_img = ''
        let normal_step_current_text_img = ''
        let normal_city_name_text = ''
        let normal_digital_clock_img_time = ''
        let idle_background_bg = ''
        let idle_heart_rate_text_text_img = ''
        let idle_heart_rate_image_progress_img_level = ''
        let idle_battery_text_text_img = ''
        let idle_battery_image_progress_img_level = ''
        let idle_city_name_text = ''
        let idle_digital_clock_img_time = ''
		
		let sleep_time_txt = ''
		let sleep_start_time_txt = ''
		let sleep_end_time_txt = ''
		let sleep_score_txt = ''

		const sleep = hmSensor.createSensor(hmSensor.id.SLEEP);
		let sleepInfo = sleep.getBasicInfo();
		
		let sleepTotalTime = sleep.getTotalTime();		
		let sleepStartTime = sleepInfo.startTime;
		let sleepEndTime = sleepInfo.endTime + 1;
		let sleepScore = sleepInfo.score;

		function updateSleepInfo() {
			sleepTotalTime = sleep.getTotalTime();
			sleepInfo = sleep.getBasicInfo();
			sleepStartTime = sleepInfo.startTime;
			if (sleepStartTime >= 24*60) {
				sleepStartTime -= 24*60
			}
			
			sleepEndTime = sleepInfo.endTime + 1;
			if (sleepEndTime >= 24*60) {
				sleepEndTime -= 24*60
			}

			sleep_time_txt.setProperty(hmUI.prop.TEXT, '' + Math.floor(sleepTotalTime / 60).toString().padStart(2, "0") + ':' + (sleepTotalTime % 60).toString().padStart(2, "0"));
			sleep_start_time_txt.setProperty(hmUI.prop.TEXT, Math.floor(sleepStartTime / 60).toString().padStart(2, "0") + ':' + (sleepStartTime % 60).toString().padStart(2, "0"));
			sleep_end_time_txt.setProperty(hmUI.prop.TEXT, Math.floor(sleepEndTime / 60).toString().padStart(2, "0") + ':' + (sleepEndTime % 60).toString().padStart(2, "0"));
			sleep_score_txt.setProperty(hmUI.prop.TEXT, '' + String(sleepScore));
		}


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 466,
              h: 466,
              src: 'bg.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sun_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 0,
              y: 0,
              image_array: ["sun_1.png","sun_2.png","sun_3.png","sun_4.png","sun_5.png","sun_6.png","sun_7.png","sun_8.png","sun_9.png"],
              image_length: 9,
              type: hmUI.data_type.SUN_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sun_pointer_progress_img_pointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
              src: '6.png',
              center_x: 233,
              center_y: 233,
              x: 92,
              y: 250,
              start_angle: -104,
              end_angle: 118,
              type: hmUI.data_type.SUN_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
			
			normal_moon_pointer_progress_img_pointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
              src: '7.png',
              center_x: 233,
              center_y: 233,
              x: 92,
              y: 160,
              start_angle: -104,
              end_angle: 118,
              type: hmUI.data_type.MOON_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_pai_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: '30.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
			
			sleep_time_txt = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 245,			// координата X
              y: 280,			// координата Y
			  w: 100,			// ширина 	
			  h: 50,			// высота	
			  text_size: 25,	// размер текста
			  text: '',
			  color: 0xffcccc,	// цвет текста
              align_h: hmUI.align.CENTER_H,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
			
			sleep_start_time_txt = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 225,
              y: 310,
			  w: 100,
			  h: 50,
			  text_size: 25,
			  text: '',
			  color: 0x00ff00,
              align_h: hmUI.align.CENTER_H,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
			
			sleep_end_time_txt = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 220,
              y: 340,
			  w: 100,
			  h: 50,
			  text_size: 25,
			  text: '',
			  color: 0x9999ff,
              align_h: hmUI.align.LEFT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
			
			sleep_score_txt = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 375,
              y: 295,
			  w: 100,
			  h: 50,
			  text_size: 40,
			  text: '',
			  color: 0xffffff,
              align_h: hmUI.align.LEFT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 104,
              y: 332,
              font_array: ["89.png","90.png","91.png","92.png","93.png","94.png","95.png","96.png","97.png","98.png"],
              padding: false,
              h_space: 0,
              angle: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 58,
              y: 330,
              image_array: ["h_0.png","h_1.png","h_2.png","h_3.png","h_4.png","h_5.png"],
              image_length: 6,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_calorie_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 316,
              y: 403,
              font_array: ["118.png","119.png","120.png","121.png","122.png","123.png","124.png","125.png","126.png","127.png"],
              padding: false,
              h_space: 0,
              angle: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 218,
              y: 436,
              font_array: ["118.png","119.png","120.png","121.png","122.png","123.png","124.png","125.png","126.png","127.png"],
              padding: false,
              h_space: 0,
              angle: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 197,
              y: 431,
              image_array: ["bat_1.png","bat_2.png","bat_3.png","bat_4.png","bat_5.png","bat_6.png","bat_7.png","bat_8.png","bat_9.png","bat_10.png"],
              image_length: 10,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_distance_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 211,
              y: 403,
              font_array: ["118.png","119.png","120.png","121.png","122.png","123.png","124.png","125.png","126.png","127.png"],
              padding: false,
              h_space: 0,
              angle: 0,
              dot_image: 'dot.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.DISTANCE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 223,
              y: 244,
              src: 'bluetooth_(10).png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 430,
              y: 245,
              src: 'free-icon-notification-bell-3541850.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 98,
              y: 403,
              font_array: ["118.png","119.png","120.png","121.png","122.png","123.png","124.png","125.png","126.png","127.png"],
              padding: false,
              h_space: 0,
              angle: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_city_name_text = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 273,
              y: 236,
              w: 150,
              h: 30,
              text_size: 23,
              char_space: 3,
              line_space: 0,
              color: 0xFFFF8C00,
              align_h: hmUI.align.LEFT,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 15,
              hour_startY: 245,
              hour_array: ["106.png","107.png","108.png","109.png","110.png","111.png","112.png","113.png","114.png","115.png"],
              hour_zero: 1,
              hour_space: 0,
              hour_angle: 0,
              hour_unit_sc: '116.png',
              hour_unit_tc: '116.png',
              hour_unit_en: '116.png',
              hour_align: hmUI.align.LEFT,

              minute_startX: 91,
              minute_startY: 245,
              minute_array: ["106.png","107.png","108.png","109.png","110.png","111.png","112.png","113.png","114.png","115.png"],
              minute_zero: 1,
              minute_space: 0,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              second_startX: 158,
              second_startY: 285,
              second_array: ["89.png","90.png","91.png","92.png","93.png","94.png","95.png","96.png","97.png","98.png"],
              second_zero: 1,
              second_space: 0,
              second_angle: 0,
              second_follow: 0,
              second_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            idle_background_bg = hmUI.createWidget(hmUI.widget.FILL_RECT, {
              x: 0,
              y: 0,
              w: 466,
              h: 466,
              color: '0xFF000000',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 104,
              y: 332,
              font_array: ["89.png","90.png","91.png","92.png","93.png","94.png","95.png","96.png","97.png","98.png"],
              padding: false,
              h_space: 0,
              angle: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_heart_rate_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 58,
              y: 330,
              image_array: ["h_0.png","h_1.png","h_2.png","h_3.png","h_4.png","h_5.png"],
              image_length: 6,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 218,
              y: 436,
              font_array: ["118.png","119.png","120.png","121.png","122.png","123.png","124.png","125.png","126.png","127.png"],
              padding: false,
              h_space: 0,
              angle: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_battery_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 197,
              y: 431,
              image_array: ["bat_1.png","bat_2.png","bat_3.png","bat_4.png","bat_5.png","bat_6.png","bat_7.png","bat_8.png","bat_9.png","bat_10.png"],
              image_length: 10,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_city_name_text = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 273,
              y: 236,
              w: 150,
              h: 30,
              text_size: 23,
              char_space: 3,
              line_space: 0,
              color: 0xFFFF8C00,
              align_h: hmUI.align.LEFT,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 15,
              hour_startY: 245,
              hour_array: ["106.png","107.png","108.png","109.png","110.png","111.png","112.png","113.png","114.png","115.png"],
              hour_zero: 1,
              hour_space: 0,
              hour_angle: 0,
              hour_unit_sc: '116.png',
              hour_unit_tc: '116.png',
              hour_unit_en: '116.png',
              hour_align: hmUI.align.LEFT,

              minute_startX: 91,
              minute_startY: 245,
              minute_array: ["106.png","107.png","108.png","109.png","110.png","111.png","112.png","113.png","114.png","115.png"],
              minute_zero: 1,
              minute_space: 0,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              second_startX: 158,
              second_startY: 285,
              second_array: ["89.png","90.png","91.png","92.png","93.png","94.png","95.png","96.png","97.png","98.png"],
              second_zero: 1,
              second_space: 0,
              second_angle: 0,
              second_follow: 0,
              second_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_AOD,
            });
            
            // disconnectAlert = hmUI.createWidget(hmUI.widget.DisconnectAlert, {
              // disconneсnt_vibrate_type: 9,
              // disconneсnt_toast_text: Connect LOST,
              // conneсnt_vibrate_type: 0,
              // conneсnt_toast_text: Connect FIND,
            // });

            // vibration when connecting or disconnecting

            function checkConnection() {
              hmBle.removeListener;
              hmBle.addListener(function (status) {
                if(!status) {
                  hmUI.showToast({text: "Connect LOST"});
                  vibro(9);
                }
                if(status) {
                  hmUI.showToast({text: "Connect FIND"});
                  vibro(0);
                }
              });
            }

            // end vibration when connecting or disconnecting
            // vibrate function

            const vibrate = hmSensor.createSensor(hmSensor.id.VIBRATE);
            let timer_StopVibrate = null;


            function vibro(scene = 25) {
              let stopDelay = 50;
              stopVibro();
              vibrate.stop();
              vibrate.scene = scene;
              if(scene < 23 || scene > 25) stopDelay = 1300;
              vibrate.start();
              timer_StopVibrate = timer.createTimer(stopDelay, 3000, stopVibro, {});
            }

            function stopVibro(){
              vibrate.stop();
              if(timer_StopVibrate) timer.stopTimer(timer_StopVibrate);
            }

            // end vibrate function

            function scale_call() {

              console.log('Weather city name');
              const weatherSensor = hmSensor.createSensor(hmSensor.id.WEATHER);
              const weatherData = weatherSensor.getForecastWeather();
              normal_city_name_text.setProperty(hmUI.prop.TEXT, weatherData.cityName);

              console.log('Weather city name');
              idle_city_name_text.setProperty(hmUI.prop.TEXT, weatherData.cityName);

            };

            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
				scale_call();
                checkConnection();
                stopVibro();
				updateSleepInfo();

              }),
              pause_call: (function () {
                stopVibro();

              }),
            });

                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}