//****************************************//
//*           Dual Time Analog           *//
//*                                      *//
//*   Designed & Edited : Wong Kam Fei   *//
//* Script Written by DeepSeek & ChatGPT *//
//****************************************//

try {
    (() => {
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() { return __$$app$$__.app; }
        function getCurrentPage() { return __$$app$$__.current && __$$app$$__.current.module; }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;

        const { width: DEVICE_WIDTH, height: DEVICE_HEIGHT } = hmSetting.getDeviceInfo();
        const radius = DEVICE_WIDTH / 2, centerX = DEVICE_WIDTH / 2, centerY = DEVICE_WIDTH / 2;
        const koeff = DEVICE_WIDTH / 480; // scaling factor
        let isAOD = hmSetting.getScreenType() == hmSetting.screen_type.AOD;

        // Function to scale values depending on screen size
        function sc(v) { return v * koeff; }

        const curTime = hmSensor.createSensor(hmSensor.id.TIME);
        const worldClock = hmSensor.createSensor(hmSensor.id.WORLD_CLOCK);
        const battery = hmSensor.createSensor(hmSensor.id.BATTERY);

        let LocalTimeText, AmPm, secsText, WorldTimeText, WAmPm, WorldCityName, WorldDateText, WorldCityNameWTO;
        let LocalMonthText, LocalDayText, LocalWeekdayText, Local_city_name_text;
        let battery_empty_img, normal_battery_image_progress_img_level;
        let normal_battery_current_text_font;
        let clockIndex = -1;
        let reInitClock = isAOD ? false : true;
        const clockSize = sc(60);
        const secSize = sc(40);

        // Set mainColor based on AOD mode
        const mainColor = isAOD ? 0xFFA9A9A9 : 0xFFFFFFFF;
        let secTimer = null;

        // Global variable for time format (12-hour or 24-hour)
        let is24HourFormat = hmFS.SysProGetInt('time_format') || 0; // 0 for 12-hour, 1 for 24-hour

        // Analog clock variables
        let analog_clock_time_pointer_hour, analog_clock_time_pointer_minute;
        let world_clock_hour_pointer_img, world_clock_minute_pointer_img;
        let analog_clock_pro_second_pointer_img;
        let Bg_img;

        // Time format button variables
        let timeFormatButtonBorder, timeFormatButton;

        // Settings window variables
        let settingsWindowGroup = null;
        let isSettingsOpen = false;

        // Widget visibility states
        let showLocalTime = true;
        let showWorldTime = true;
        let showLocalDate = true;
        let showWorldDateText = true;
        let showLocalWeekdayText = true;
        let showWorldCountryFlag = true;

        // AOD visibility states
        let showLocalTimeAOD = true;
        let showWorldTimeAOD = true;
        let showLocalDateAOD = true;
        let showWorldDateTextAOD = true;
        let showLocalWeekdayTextAOD = true;
        let showWorldCountryFlagAOD = true;

        // World city display mode variables
        let worldCityDisplayMode = 0; // 0: WorldCityName, 1: WorldCityNameWTO, 2: CityCode, 3: WorldCityOffsetText, 4: Hide all
        let WorldCityCodeText; // New widget for city code only

        // Smooth animation variables
        let wt_current_angle_hour = 0;
        let wt_current_angle_minute = 0;
        let wt_target_angle_hour = 0;
        let wt_target_angle_minute = 0;
        let wt_smooth_timer = null;
        let analog_update_timer = null;

        // City change button references
        let leftCityButtonStroke, leftCityButton, rightCityButtonStroke, rightCityButton;

        // City offset text widget
        let WorldCityOffsetText;

        // GMT Zone text widget
        let GMTZoneText;

        // City Image widgets for gradual animation
        let WorldCountryFlagA, WorldCountryFlagB;
        let currentFlagWidget = 'A'; // Track which widget is currently visible
        let flagAnimationTimer = null;
        let currentCityCode = ''; // Track current city code to prevent unnecessary animations

        // World Map variables
        let worldMapImg = null;
        let currentMapX = -320; // Initial position for GMT 0
        let targetMapX = -320;
        let mapAnimationTimer = null;
        let mapAnimationStartTime = 0;
        const mapAnimationDuration = 2000; // Changed from 3000 to 2000 milliseconds

        // Vibrate function
        const vibrate = hmSensor.createSensor(hmSensor.id.VIBRATE);
        function click_Vibrate() {
            vibrate.stop();
            vibrate.scene = 27;
            vibrate.start();
        }

        // ==============================================
        //  WORLD CITY DISPLAY MODE FUNCTIONS
        // ==============================================

        // Function to cycle through world city display modes
        function cycleWorldCityDisplayMode() {
            worldCityDisplayMode = (worldCityDisplayMode + 1) % 5;
            hmFS.SysProSetInt('worldCityDisplayMode', worldCityDisplayMode);
            
            updateWorldCityDisplay();
            
            // Show toast ONLY when manually toggling
            let toastText = "";
            switch(worldCityDisplayMode) {
                case 0: // World City Name
                    toastText = "World City Name";
                    break;
                case 1: // World City + Time Offset
                    toastText = "World City Name + Time Offset";
                    break;
                case 2: // City Code only
                    toastText = "World City Code";
                    break;
                case 3: // City Code + Time Offset
                    toastText = "World City Code + Time Offset";
                    break;
                case 4: // Hide all
                    toastText = "Hide City Info";
                    break;
            }
            
            // Show toast only when manually toggling (not during AOD transitions)
            hmUI.showToast({ text: toastText });
            click_Vibrate();
        }

        // Function to update world city display based on current mode
        function updateWorldCityDisplay() {
            // Hide all widgets first
            if (WorldCityName) WorldCityName.setProperty(hmUI.prop.VISIBLE, false);
            if (WorldCityNameWTO) WorldCityNameWTO.setProperty(hmUI.prop.VISIBLE, false);
            if (WorldCityCodeText) WorldCityCodeText.setProperty(hmUI.prop.VISIBLE, false);
            if (WorldCityOffsetText) WorldCityOffsetText.setProperty(hmUI.prop.VISIBLE, false);
            
            // Show appropriate widget based on mode
            switch(worldCityDisplayMode) {
                case 0: // World City Name
                    if (WorldCityName) WorldCityName.setProperty(hmUI.prop.VISIBLE, true);
                    break;
                case 1: // World City + Time Offset
                    if (WorldCityNameWTO) WorldCityNameWTO.setProperty(hmUI.prop.VISIBLE, true);
                    break;
                case 2: // City Code only
                    if (WorldCityCodeText) WorldCityCodeText.setProperty(hmUI.prop.VISIBLE, true);
                    break;
                case 3: // City Code + Time Offset
                    if (WorldCityOffsetText) WorldCityOffsetText.setProperty(hmUI.prop.VISIBLE, true);
                    break;
                case 4: // Hide all
                    // All widgets already hidden above
                    break;
            }
        }

        // ==============================================
        //  SETTINGS WINDOW FUNCTIONS
        // ==============================================
        function showSettingsWindow() {
            if (isSettingsOpen || isAOD) return;
            isSettingsOpen = true;
            
            // Create settings window group
            settingsWindowGroup = hmUI.createWidget(hmUI.widget.GROUP, {
                x: 0,
                y: 0,
                w: DEVICE_WIDTH,
                h: DEVICE_HEIGHT,
            });
            
            // Semi-transparent background
            settingsWindowGroup.createWidget(hmUI.widget.FILL_RECT, {
                x: 0,
                y: 0,
                w: DEVICE_WIDTH,
                h: DEVICE_HEIGHT,
                color: 0xCC000000,
                alpha: 100,
            });
            
            // Settings window background
            const windowWidth = sc(330);
            const windowHeight = sc(360);
            const windowX = (DEVICE_WIDTH - windowWidth) / 2;
            const windowY = (DEVICE_HEIGHT - windowHeight) / 2;
            
            settingsWindowGroup.createWidget(hmUI.widget.FILL_RECT, {
                x: windowX,
                y: windowY,
                w: windowWidth,
                h: windowHeight,
                color: 0x222222,
				alpha: 100,
                radius: sc(20),
            });

            settingsWindowGroup.createWidget(hmUI.widget.STROKE_RECT, {
                x: windowX - sc(2),
                y: windowY - sc(2),
                w: windowWidth + sc(4),
                h: windowHeight + sc(4),
                color: 0xFFFFFF,
                line_width: sc(4),
                radius: sc(22),
            });

            settingsWindowGroup.createWidget(hmUI.widget.STROKE_RECT, {
                x: windowX - sc(2),
                y: windowY - sc(2),
                w: windowWidth - sc(75),
                h: sc(60),
                color: 0xFFFFFF,
                line_width: sc(4),
                radius: sc(22),
            });
            
            // Time format toggle button - now narrower with label
            const timeFormatButtonY = windowY + sc(6);
            settingsWindowGroup.createWidget(hmUI.widget.STROKE_RECT, {
                x: windowX + sc(15),
                y: timeFormatButtonY + sc(2),
                w: sc(71),
                h: sc(40),
                radius: sc(20),
                color: 0xFFFFFF,
                line_width: sc(3),
            });

            // Store time format button reference for updates
			let timeFormatButtonRef = settingsWindowGroup.createWidget(hmUI.widget.BUTTON, {
				x: windowX + sc(18),
				y: timeFormatButtonY + sc(5),
				w: sc(65),
				h: sc(34),
				text: is24HourFormat ? '24H' : '12H',
				text_size: sc(26),
				color: 0xFFFFFF,
				align_h: hmUI.align.CENTER_H,
				align_v: hmUI.align.CENTER_V,
				normal_color: 0x444444,
				press_color: 0x666666,
				radius: sc(17),
				click_func: () => {
					is24HourFormat = !is24HourFormat;
					hmFS.SysProSetInt('time_format', is24HourFormat ? 1 : 0);
					
					// Update button text immediately
					timeFormatButtonRef.setProperty(hmUI.prop.TEXT, is24HourFormat ? '24H' : '12H');
					
					updateTime();
					updateTextPositions(); // Add this line to update positions
					click_Vibrate();
				}
			});
            
            // Add "Time Format" label to the right of the button
            settingsWindowGroup.createWidget(hmUI.widget.TEXT, {
                x: windowX + sc(80), // Same x position as other toggle button labels
                y: timeFormatButtonY,
                w: sc(170),
                h: sc(40),
                text: "Time Format",
                color: 0xFFFFFF,
                text_size: sc(26),
                align_h: hmUI.align.CENTER_H,
                align_v: hmUI.align.CENTER_V,
            });

            // Add "AOD" label above the AOD toggle column
            settingsWindowGroup.createWidget(hmUI.widget.TEXT, {
                x: windowX + sc(255),
                y: timeFormatButtonY,
                w: sc(65),
                h: sc(45),
                text: "AOD",
                color: 0xFFFFFF,
                text_size: sc(30),
                align_h: hmUI.align.CENTER_H,
                align_v: hmUI.align.CENTER_V,
            });
            
            // Widget visibility toggle buttons
            const toggleButtons = [
                { label: "Local Time", state: showLocalTime, aodState: showLocalTimeAOD, key: 'show_LocalTime', aodKey: 'show_LocalTimeAOD' },
                { label: "World Time", state: showWorldTime, aodState: showWorldTimeAOD, key: 'show_WorldTime', aodKey: 'show_WorldTimeAOD' },
                { label: "Local Date", state: showLocalDate, aodState: showLocalDateAOD, key: 'show_LocalDate', aodKey: 'show_LocalDateAOD' },
                { label: "Weekday", state: showLocalWeekdayText, aodState: showLocalWeekdayTextAOD, key: 'show_LocalWeekdayText', aodKey: 'show_LocalWeekdayTextAOD' },
                { label: "World Date", state: showWorldDateText, aodState: showWorldDateTextAOD, key: 'show_WorldDateText', aodKey: 'show_WorldDateTextAOD' },
                { label: "Flag", state: showWorldCountryFlag, aodState: showWorldCountryFlagAOD, key: 'show_WorldCountryFlag', aodKey: 'show_WorldCountryFlagAOD' }
            ];
            
            const buttonStartY = windowY + sc(60);
            const buttonHeight = sc(45);
            const buttonSpacing = sc(5);
            
            // Store toggle button references for updates
            let toggleButtonRefs = [];
            let aodToggleButtonRefs = [];
            let aodToggleButtonClickRefs = [];
            
            toggleButtons.forEach((buttonConfig, index) => {
                const yPos = buttonStartY + (index * (buttonHeight + buttonSpacing));
                
                // Main Toggle button - left side
                const toggleButtonRef = settingsWindowGroup.createWidget(hmUI.widget.IMG, {
                    x: windowX + sc(15),
                    y: yPos,
                    w: sc(65),
                    h: buttonHeight,
                    src: buttonConfig.state ? "On_Icon.png" : "Off_Icon.png",
                });
                
                // Create invisible button over the main toggle for click handling
                settingsWindowGroup.createWidget(hmUI.widget.BUTTON, {
                    x: windowX + sc(15),
                    y: yPos,
                    w: sc(65),
                    h: buttonHeight,
                    normal_src: 'transparent.png',
                    press_src: 'transparent.png',
                    click_func: (() => {
                        const currentConfig = buttonConfig;
                        const currentIndex = index;
                        return () => {
                            currentConfig.state = !currentConfig.state;
                            hmFS.SysProSetBool(currentConfig.key, currentConfig.state);
                            updateWidgetVisibility(currentConfig.key, currentConfig.state);
                            
                            // Update main toggle button image immediately
                            toggleButtonRef.setProperty(
                                hmUI.prop.SRC, 
                                currentConfig.state ? "On_Icon.png" : "Off_Icon.png"
                            );
                            
                            // Show/hide AOD toggle based on main toggle state
                            const aodToggleRef = aodToggleButtonRefs[currentIndex];
                            const aodToggleClickRef = aodToggleButtonClickRefs[currentIndex];
                            if (aodToggleRef && aodToggleClickRef) {
                                aodToggleRef.setProperty(hmUI.prop.VISIBLE, currentConfig.state);
                                aodToggleClickRef.setProperty(hmUI.prop.VISIBLE, currentConfig.state);
                            }
                            
                            click_Vibrate();
                        };
                    })()
                });
                
                // AOD Toggle button - right side (initially visible/hidden based on main toggle state)
                const aodToggleButtonRef = settingsWindowGroup.createWidget(hmUI.widget.IMG, {
                    x: windowX + sc(250),
                    y: yPos,
                    w: sc(65),
                    h: buttonHeight,
                    src: buttonConfig.aodState ? "On_Icon.png" : "Off_Icon.png",
                    visible: buttonConfig.state // Only visible if main toggle is ON
                });
                
                // Create invisible button over the AOD toggle for click handling
                const aodToggleClickRef = settingsWindowGroup.createWidget(hmUI.widget.BUTTON, {
                    x: windowX + sc(250),
                    y: yPos,
                    w: sc(65),
                    h: buttonHeight,
                    normal_src: 'transparent.png',
                    press_src: 'transparent.png',
                    visible: buttonConfig.state, // Only visible if main toggle is ON
                    click_func: (() => {
                        const currentConfig = buttonConfig;
                        const currentIndex = index;
                        return () => {
                            currentConfig.aodState = !currentConfig.aodState;
                            hmFS.SysProSetBool(currentConfig.aodKey, currentConfig.aodState);
                            updateAODVisibility(currentConfig.aodKey, currentConfig.aodState);
                            
                            // Update AOD toggle button image immediately
                            const aodToggleRef = aodToggleButtonRefs[currentIndex];
                            if (aodToggleRef) {
                                aodToggleRef.setProperty(
                                    hmUI.prop.SRC, 
                                    currentConfig.aodState ? "On_Icon.png" : "Off_Icon.png"
                                );
                            }
                            
                            click_Vibrate();
                        };
                    })()
                });
                
                toggleButtonRefs.push(toggleButtonRef);
                aodToggleButtonRefs.push(aodToggleButtonRef);
                aodToggleButtonClickRefs.push(aodToggleClickRef);
                
                // Label - between main toggle and AOD toggle
                settingsWindowGroup.createWidget(hmUI.widget.TEXT, {
                    x: windowX + sc(85),
                    y: yPos,
                    w: sc(160),
                    h: buttonHeight,
                    text: buttonConfig.label,
                    color: 0xFFFFFF,
                    text_size: sc(30),
                    align_h: hmUI.align.CENTER_H,
                    align_v: hmUI.align.CENTER_V,
                });
            });

            // Function to refresh AOD toggle visibility
            function refreshAODToggleVisibility() {
                toggleButtons.forEach((buttonConfig, index) => {
                    const aodToggleRef = aodToggleButtonRefs[index];
                    const aodToggleClickRef = aodToggleButtonClickRefs[index];
                    if (aodToggleRef && aodToggleClickRef) {
                        aodToggleRef.setProperty(hmUI.prop.VISIBLE, buttonConfig.state);
                        aodToggleClickRef.setProperty(hmUI.prop.VISIBLE, buttonConfig.state);
                    }
                });
            }

            // Refresh AOD toggle visibility when settings window opens
            refreshAODToggleVisibility();
            
            // Close button (X) - placed below the window
            const closeButtonY = windowY + windowHeight + sc(2);
            settingsWindowGroup.createWidget(hmUI.widget.BUTTON, {
                x: centerX - sc(27),
                y: closeButtonY,
                w: sc(54),
                h: sc(60),
                radius: sc(10),
                text: "X",
                color: 0x000000,
                text_size: sc(50),
                normal_color: 0xFF0000,
                press_color: 0xCC0000,
                align_h: hmUI.align.CENTER_H,
                align_v: hmUI.align.CENTER_V,
                click_func: () => {
                    hmUI.deleteWidget(settingsWindowGroup);
                    settingsWindowGroup = null;
                    isSettingsOpen = false;
                }
            });
        }

        function updateWidgetVisibility(widgetKey, isVisible) {
            // Save the setting immediately
            hmFS.SysProSetBool(widgetKey, isVisible);
            
            switch(widgetKey) {
                case 'show_LocalTime':
                    showLocalTime = isVisible;
                    if (LocalTimeText) {
                        LocalTimeText.setProperty(hmUI.prop.VISIBLE, isVisible && (!isAOD || showLocalTimeAOD));
                    }
                    if (AmPm) {
                        AmPm.setProperty(hmUI.prop.VISIBLE, isVisible && (!isAOD || showLocalTimeAOD) && !is24HourFormat);
                    }
                    break;
                    
                case 'show_WorldTime':
                    showWorldTime = isVisible;
                    if (WorldTimeText) {
                        WorldTimeText.setProperty(hmUI.prop.VISIBLE, isVisible && (!isAOD || showWorldTimeAOD));
                    }
                    if (WAmPm) {
                        WAmPm.setProperty(hmUI.prop.VISIBLE, isVisible && (!isAOD || showWorldTimeAOD) && !is24HourFormat);
                    }
                    break;
                    
				case 'show_LocalDate':
					showLocalDate = isVisible;
					if (LocalMonthText) {
                        LocalMonthText.setProperty(hmUI.prop.VISIBLE, isVisible && (!isAOD || showLocalDateAOD));
                    }
					if (LocalDayText) {
                        LocalDayText.setProperty(hmUI.prop.VISIBLE, isVisible && (!isAOD || showLocalDateAOD));
                    }
					break;
                    
                case 'show_WorldDateText':
                    showWorldDateText = isVisible;
                    if (WorldDateText) {
                        WorldDateText.setProperty(hmUI.prop.VISIBLE, isVisible && (!isAOD || showWorldDateTextAOD));
                    }
                    break;
                    
                case 'show_LocalWeekdayText':
                    showLocalWeekdayText = isVisible;
                    if (LocalWeekdayText) {
                        LocalWeekdayText.setProperty(hmUI.prop.VISIBLE, isVisible && (!isAOD || showLocalWeekdayTextAOD));
                    }
                    break;
                    
                case 'show_WorldCountryFlag':
                    showWorldCountryFlag = isVisible;
                    if (WorldCountryFlagA) {
                        WorldCountryFlagA.setProperty(hmUI.prop.VISIBLE, isVisible && (!isAOD || showWorldCountryFlagAOD));
                    }
                    if (WorldCountryFlagB) {
                        WorldCountryFlagB.setProperty(hmUI.prop.VISIBLE, isVisible && (!isAOD || showWorldCountryFlagAOD) && currentFlagWidget === 'B');
                    }
                    break;
            }
        }

        function updateAODVisibility(widgetKey, isVisible) {
            // Save the setting immediately
            hmFS.SysProSetBool(widgetKey, isVisible);
            
            switch(widgetKey) {
                case 'show_LocalTimeAOD':
                    showLocalTimeAOD = isVisible;
                    if (LocalTimeText && isAOD) {
                        LocalTimeText.setProperty(hmUI.prop.VISIBLE, showLocalTime && isVisible);
                    }
                    if (AmPm && isAOD) {
                        AmPm.setProperty(hmUI.prop.VISIBLE, showLocalTime && isVisible && !is24HourFormat);
                    }
                    break;
                    
                case 'show_WorldTimeAOD':
                    showWorldTimeAOD = isVisible;
                    if (WorldTimeText && isAOD) {
                        WorldTimeText.setProperty(hmUI.prop.VISIBLE, showWorldTime && isVisible);
                    }
                    if (WAmPm && isAOD) {
                        WAmPm.setProperty(hmUI.prop.VISIBLE, showWorldTime && isVisible && !is24HourFormat);
                    }
                    break;
                    
				case 'show_LocalDateAOD':
					showLocalDateAOD = isVisible;
					if (LocalMonthText && isAOD) {
                        LocalMonthText.setProperty(hmUI.prop.VISIBLE, showLocalDate && isVisible);
                    }
					if (LocalDayText && isAOD) {
                        LocalDayText.setProperty(hmUI.prop.VISIBLE, showLocalDate && isVisible);
                    }
					break;
                    
                case 'show_WorldDateTextAOD':
                    showWorldDateTextAOD = isVisible;
                    if (WorldDateText && isAOD) {
                        WorldDateText.setProperty(hmUI.prop.VISIBLE, showWorldDateText && isVisible);
                    }
                    break;
                    
                case 'show_LocalWeekdayTextAOD':
                    showLocalWeekdayTextAOD = isVisible;
                    if (LocalWeekdayText && isAOD) {
                        LocalWeekdayText.setProperty(hmUI.prop.VISIBLE, showLocalWeekdayText && isVisible);
                    }
                    break;
                    
                case 'show_WorldCountryFlagAOD':
                    showWorldCountryFlagAOD = isVisible;
                    if (WorldCountryFlagA && isAOD) {
                        WorldCountryFlagA.setProperty(hmUI.prop.VISIBLE, showWorldCountryFlag && isVisible);
                    }
                    if (WorldCountryFlagB && isAOD) {
                        WorldCountryFlagB.setProperty(hmUI.prop.VISIBLE, showWorldCountryFlag && isVisible && currentFlagWidget === 'B');
                    }
                    break;
            }
        }

        function loadWidgetVisibility() {
            showLocalTime = hmFS.SysProGetBool('show_LocalTime') !== false;
            showWorldTime = hmFS.SysProGetBool('show_WorldTime') !== false;
            showLocalDate = hmFS.SysProGetBool('show_LocalDate') !== false;
            showWorldDateText = hmFS.SysProGetBool('show_WorldDateText') !== false;
            showLocalWeekdayText = hmFS.SysProGetBool('show_LocalWeekdayText') !== false;
            showWorldCountryFlag = hmFS.SysProGetBool('show_WorldCountryFlag') !== false;
            
            // Load AOD visibility settings
            showLocalTimeAOD = hmFS.SysProGetBool('show_LocalTimeAOD') !== false;
            showWorldTimeAOD = hmFS.SysProGetBool('show_WorldTimeAOD') !== false;
            showLocalDateAOD = hmFS.SysProGetBool('show_LocalDateAOD') !== false;
            showWorldDateTextAOD = hmFS.SysProGetBool('show_WorldDateTextAOD') !== false;
            showLocalWeekdayTextAOD = hmFS.SysProGetBool('show_LocalWeekdayTextAOD') !== false;
            showWorldCountryFlagAOD = hmFS.SysProGetBool('show_WorldCountryFlagAOD') !== false;
            
            // Load time format setting
            is24HourFormat = hmFS.SysProGetInt('time_format') || 0;
            
            // Load world city display mode (default to 0 - WorldCityName)
            worldCityDisplayMode = hmFS.SysProGetInt('worldCityDisplayMode');
            if (worldCityDisplayMode === undefined || worldCityDisplayMode === null) {
                worldCityDisplayMode = 0; // Default to World City Name
                hmFS.SysProSetInt('worldCityDisplayMode', worldCityDisplayMode);
            }
        }

        function initializeDefaultSettings() {
            if (hmFS.SysProGetBool('show_LocalTime') === undefined) {
                hmFS.SysProSetBool('show_LocalTime', true);
            }
            if (hmFS.SysProGetBool('show_WorldTime') === undefined) {
                hmFS.SysProSetBool('show_WorldTime', true);
            }
			if (hmFS.SysProGetBool('show_LocalDate') === undefined) {
				hmFS.SysProSetBool('show_LocalDate', true);
			}
            if (hmFS.SysProGetBool('show_WorldDateText') === undefined) {
                hmFS.SysProSetBool('show_WorldDateText', true);
            }
            if (hmFS.SysProGetBool('show_LocalWeekdayText') === undefined) {
                hmFS.SysProSetBool('show_LocalWeekdayText', true);
            }
            if (hmFS.SysProGetBool('show_WorldCountryFlag') === undefined) {
                hmFS.SysProSetBool('show_WorldCountryFlag', true);
            }

            // Initialize AOD visibility settings
            if (hmFS.SysProGetBool('show_LocalTimeAOD') === undefined) {
                hmFS.SysProSetBool('show_LocalTimeAOD', true);
            }
            if (hmFS.SysProGetBool('show_WorldTimeAOD') === undefined) {
                hmFS.SysProSetBool('show_WorldTimeAOD', true);
            }
			if (hmFS.SysProGetBool('show_LocalDateAOD') === undefined) {
				hmFS.SysProSetBool('show_LocalDateAOD', true);
			}
            if (hmFS.SysProGetBool('show_WorldDateTextAOD') === undefined) {
                hmFS.SysProSetBool('show_WorldDateTextAOD', true);
            }
            if (hmFS.SysProGetBool('show_LocalWeekdayTextAOD') === undefined) {
                hmFS.SysProSetBool('show_LocalWeekdayTextAOD', true);
            }
            if (hmFS.SysProGetBool('show_WorldCountryFlagAOD') === undefined) {
                hmFS.SysProSetBool('show_WorldCountryFlagAOD', true);
            }
            
            if (hmFS.SysProGetInt('time_format') === undefined) {
                hmFS.SysProSetInt('time_format', 0); // Default to 12-hour format
            }
            
            if (hmFS.SysProGetInt('worldCityDisplayMode') === undefined) {
                hmFS.SysProSetInt('worldCityDisplayMode', 0); // Default to World City Name
            }
        }

        // Function to apply visibility settings to all widgets after they are created
        function applyWidgetVisibility() {
            if (LocalTimeText) {
                LocalTimeText.setProperty(hmUI.prop.VISIBLE, showLocalTime && (!isAOD || showLocalTimeAOD));
            }
            if (AmPm) {
                AmPm.setProperty(hmUI.prop.VISIBLE, showLocalTime && (!isAOD || showLocalTimeAOD) && !is24HourFormat);
            }
            if (WorldTimeText) {
                WorldTimeText.setProperty(hmUI.prop.VISIBLE, showWorldTime && (!isAOD || showWorldTimeAOD));
            }
            if (WAmPm) {
                WAmPm.setProperty(hmUI.prop.VISIBLE, showWorldTime && (!isAOD || showWorldTimeAOD) && !is24HourFormat);
            }
            if (LocalMonthText) {
                LocalMonthText.setProperty(hmUI.prop.VISIBLE, showLocalDate && (!isAOD || showLocalDateAOD));
            }
            if (LocalDayText) {
                LocalDayText.setProperty(hmUI.prop.VISIBLE, showLocalDate && (!isAOD || showLocalDateAOD));
            }
            if (WorldDateText) {
                WorldDateText.setProperty(hmUI.prop.VISIBLE, showWorldDateText && (!isAOD || showWorldDateTextAOD));
            }
            if (LocalWeekdayText) {
                LocalWeekdayText.setProperty(hmUI.prop.VISIBLE, showLocalWeekdayText && (!isAOD || showLocalWeekdayTextAOD));
            }
            if (WorldCountryFlagA) {
                WorldCountryFlagA.setProperty(hmUI.prop.VISIBLE, showWorldCountryFlag && (!isAOD || showWorldCountryFlagAOD));
            }
            if (WorldCountryFlagB) {
                WorldCountryFlagB.setProperty(hmUI.prop.VISIBLE, showWorldCountryFlag && (!isAOD || showWorldCountryFlagAOD) && currentFlagWidget === 'B');
            }
            
            // Apply world city display mode
            updateWorldCityDisplay();
            
            // World clock hands are controlled by city selection only, not visibility toggle
        }

        // ==============================================
        //  EXISTING FUNCTIONS (Mostly unchanged)
        // ==============================================

        // World Map Animation Functions
        function startMapAnimation() {
            if (mapAnimationTimer) {
                clearTimeout(mapAnimationTimer);
                mapAnimationTimer = null;
            }
            
            mapAnimationStartTime = Date.now();
            animateMap();
        }
        
        function animateMap() {
            const now = Date.now();
            const elapsed = now - mapAnimationStartTime;
            
            if (elapsed < mapAnimationDuration) {
                const progress = elapsed / mapAnimationDuration;
                // Use easing function for smooth animation
                const easeProgress = easeInOutCubic(progress);
                const newX = currentMapX + (targetMapX - currentMapX) * easeProgress;
                
                if (worldMapImg) {
                    worldMapImg.setProperty(hmUI.prop.X, newX);
                }
                
                mapAnimationTimer = setTimeout(animateMap, 200); // Reduced from 16ms to 200ms
            } else {
                // Animation complete
                if (worldMapImg) {
                    worldMapImg.setProperty(hmUI.prop.X, targetMapX);
                }
                currentMapX = targetMapX;
                mapAnimationTimer = null;
            }
        }
        
        function easeInOutCubic(t) {
            return t < 0.5 ? 4 * t * t * t : 1 - Math.pow(-2 * t + 2, 3) / 2;
        }

        // Flag Animation Functions
        function animateFlagChange(newImagePath, newCityCode) {
            // Only animate if the city code actually changed
            if (newCityCode === currentCityCode) {
                return;
            }
            
            currentCityCode = newCityCode;
            
            if (flagAnimationTimer) {
                clearInterval(flagAnimationTimer);
                flagAnimationTimer = null;
            }

            const fadeDuration = 2000; // 2 seconds
            const steps = 20; // Number of animation steps
            const stepInterval = fadeDuration / steps;
            let currentStep = 0;

            // Determine which widget to fade in and which to fade out
            const fadeOutWidget = currentFlagWidget === 'A' ? WorldCountryFlagA : WorldCountryFlagB;
            const fadeInWidget = currentFlagWidget === 'A' ? WorldCountryFlagB : WorldCountryFlagA;

            // Set the new image to the widget that will fade in
            try {
                fadeInWidget.setProperty(hmUI.prop.SRC, newImagePath);
                fadeInWidget.setProperty(hmUI.prop.VISIBLE, showWorldCountryFlag && (!isAOD || showWorldCountryFlagAOD));
                fadeInWidget.setProperty(hmUI.prop.ALPHA, 0); // Start fully transparent
            } catch (e) {
                console.log(`Image ${newImagePath} not found, using default`);
                fadeInWidget.setProperty(hmUI.prop.SRC, "default_city.png");
                fadeInWidget.setProperty(hmUI.prop.VISIBLE, showWorldCountryFlag && (!isAOD || showWorldCountryFlagAOD));
                fadeInWidget.setProperty(hmUI.prop.ALPHA, 0);
            }

            flagAnimationTimer = setInterval(() => {
                currentStep++;
                const progress = currentStep / steps;
                
                // Calculate alpha values (0-255)
                const fadeOutAlpha = Math.floor(255 * (1 - progress));
                const fadeInAlpha = Math.floor(255 * progress);
                
                // Apply alpha values
                fadeOutWidget.setProperty(hmUI.prop.ALPHA, fadeOutAlpha);
                fadeInWidget.setProperty(hmUI.prop.ALPHA, fadeInAlpha);
                
                if (currentStep >= steps) {
                    // Animation complete
                    clearInterval(flagAnimationTimer);
                    flagAnimationTimer = null;
                    
                    // Hide the faded out widget completely
                    fadeOutWidget.setProperty(hmUI.prop.VISIBLE, false);
                    fadeOutWidget.setProperty(hmUI.prop.ALPHA, 255); // Reset alpha for next use
                    
                    // Ensure fade in widget is fully visible
                    fadeInWidget.setProperty(hmUI.prop.ALPHA, 255);
                    
                    // Switch current widget reference
                    currentFlagWidget = currentFlagWidget === 'A' ? 'B' : 'A';
                }
            }, stepInterval);
        }

        // *** Function to set Local Time & World Time Start ***
        function updateTime() {
            updateLocalTime();
            updateWorldTime();

            // Always update analog clocks (now in digital mode too)
            updateAnalogClocks();
    
			// Update text positions based on time format
			updateTextPositions();			
        }

		function updateTextPositions() {
			// Adjust Local Time position based on time format
			if (LocalTimeText) {
				if (is24HourFormat) {
					// 24H format - center position
					LocalTimeText.setProperty(hmUI.prop.X, 0);
					LocalTimeText.setProperty(hmUI.prop.ALIGN_H, hmUI.align.CENTER_H);
				} else {
					// 12H format - shift left to make space for AM/PM
					LocalTimeText.setProperty(hmUI.prop.X, sc(-18));
					LocalTimeText.setProperty(hmUI.prop.ALIGN_H, hmUI.align.CENTER_H);
				}
			}
			
			// Adjust World Time position based on time format
			if (WorldTimeText) {
				if (is24HourFormat) {
					// 24H format - center position
					WorldTimeText.setProperty(hmUI.prop.X, 0);
					WorldTimeText.setProperty(hmUI.prop.ALIGN_H, hmUI.align.CENTER_H);
				} else {
					// 12H format - shift left to make space for AM/PM
					WorldTimeText.setProperty(hmUI.prop.X, sc(-16));
					WorldTimeText.setProperty(hmUI.prop.ALIGN_H, hmUI.align.CENTER_H);
				}
			}
			
			// Also adjust AM/PM visibility based on time format
			if (AmPm) {
				AmPm.setProperty(hmUI.prop.VISIBLE, showLocalTime && (!isAOD || showLocalTimeAOD) && !is24HourFormat);
			}
			if (WAmPm) {
				WAmPm.setProperty(hmUI.prop.VISIBLE, showWorldTime && (!isAOD || showWorldTimeAOD) && !is24HourFormat);
			}
		}

        // Helper function to format hours, minutes, and AM/PM
        function formatTime(hour, minute) {
            let period = 'AM';
            if (is24HourFormat) {
                return {
                    formattedHour: hour.toString().padStart(2, "0"),
                    formattedMinute: minute.toString().padStart(2, "0"),
                    period: ''
                };
            } else {
                if (hour >= 12) {
                    period = 'PM';
                    if (hour > 12) {
                        hour -= 12;
                    }
                } else if (hour === 0) {
                    hour = 12;
                }
                return {
                    formattedHour: hour.toString().padStart(2, "0"),
                    formattedMinute: minute.toString().padStart(2, "0"),
                    period: period
                };
            }
        }

        // Helper function to get formatted date and weekday
        function getFormattedDateAndWeekday(date) {
            const monthNames = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];
            const weekdayNames = ["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"];
            let month = monthNames[date.getMonth()];
            let day = date.getDate().toString().padStart(2, '0');
            let weekday = weekdayNames[date.getDay()];
            return {
                month: month,
                day: day,
                weekday: weekday
            };
        }

        function updateLocalTime() {
            let { formattedHour, formattedMinute, period } = formatTime(curTime.hour, curTime.minute);

            // Set the LocalTimeText and AmPm properties
            LocalTimeText.setProperty(hmUI.prop.TEXT, `${formattedHour}:${formattedMinute}`);
            AmPm.setProperty(hmUI.prop.TEXT, period);

            // Get the current date and split month and weekday for separate display
            const currentDate = new Date();
            const { month, weekday, day } = getFormattedDateAndWeekday(currentDate);

            // Set month and weekday separately for LocalDate
            LocalMonthText.setProperty(hmUI.prop.TEXT, month); // Show only the month (e.g., "Jan")
            LocalWeekdayText.setProperty(hmUI.prop.TEXT, weekday); // Show only the weekday (e.g., "Sun")
            LocalDayText.setProperty(hmUI.prop.TEXT, day); // Show only the day (dd)

            if (!isAOD) updateSeconds();
        }

        function updateWorldTime() {
            let worldHour = '--';
            let worldMinute = '--';
            let timeZoneHour = 0;
            let timeZoneMinute = 0;
            let worldData = null;

            if (clockIndex > -1) {
                worldData = worldClock.getWorldClockInfo(clockIndex);
                worldHour = worldData.hour !== undefined ? parseInt(worldData.hour) : '--';
                worldMinute = worldData.minute !== undefined ? parseInt(worldData.minute) : '--';
                timeZoneHour = parseInt(worldData.timeZoneHour);
                timeZoneMinute = parseInt(worldData.timeZoneMinute);
                
                // REMOVED: Flag update from here to prevent animation on every time update
            } else {
                WorldTimeText.setProperty(hmUI.prop.TEXT, '');
                WAmPm.setProperty(hmUI.prop.TEXT, '');
                WorldDateText.setProperty(hmUI.prop.TEXT, '');
                // Show/hide city offset based on whether a world city is configured
                // WorldCityOffsetText visibility now controlled by updateWorldCityDisplay()

                // Update all city name widgets
                if (typeof WorldCityName !== 'undefined') {
                    WorldCityName.setProperty(hmUI.prop.TEXT, 'Add City');
                }
                if (typeof WorldCityNameWTO !== 'undefined') {
                    WorldCityNameWTO.setProperty(hmUI.prop.TEXT, 'Add City');
                }
                if (typeof WorldCityCodeText !== 'undefined') {
                    WorldCityCodeText.setProperty(hmUI.prop.TEXT, '---');
                }

                // Hide world clock hands if no city selected
                world_clock_hour_pointer_img.setProperty(hmUI.prop.VISIBLE, false);
                world_clock_minute_pointer_img.setProperty(hmUI.prop.VISIBLE, false);
                
                // Update city image to default when no city selected (without animation)
                if (WorldCountryFlagA && WorldCountryFlagB && currentCityCode !== 'default') {
                    currentCityCode = 'default';
                    // Set without animation for default state
                    WorldCountryFlagA.setProperty(hmUI.prop.SRC, "default_city.png");
                    WorldCountryFlagA.setProperty(hmUI.prop.VISIBLE, showWorldCountryFlag && (!isAOD || showWorldCountryFlagAOD));
                    WorldCountryFlagA.setProperty(hmUI.prop.ALPHA, 255);
                    WorldCountryFlagB.setProperty(hmUI.prop.VISIBLE, false);
                }
                
                // Update GMT text
                GMTZoneText.setProperty(hmUI.prop.TEXT, "GMT ?");
                return;
            }

            let curTotalMinutes = curTime.hour * 60 + curTime.minute;
            let timeZoneOffset = timeZoneHour * 60 + timeZoneMinute;
            let totalOffset = curTotalMinutes + timeZoneOffset;

            let displayDate = new Date();
            if (totalOffset >= 24 * 60) {
                displayDate.setDate(displayDate.getDate() + 1);
            } else if (totalOffset < 0) {
                displayDate.setDate(displayDate.getDate() - 1);
            }

            let { formattedHour, formattedMinute, period: worldPeriod } = formatTime(worldHour, worldMinute);
            WorldTimeText.setProperty(hmUI.prop.TEXT, `${formattedHour}:${formattedMinute}`);
            WAmPm.setProperty(hmUI.prop.TEXT, is24HourFormat ? '' : worldPeriod);

            const { month, day } = getFormattedDateAndWeekday(displayDate);
            WorldDateText.setProperty(hmUI.prop.TEXT, `${month} ${day}`);

            // Calculate time offset
            const timeZoneOffsetTotal = timeZoneHour + (timeZoneMinute / 60);
            const offsetSign = timeZoneOffsetTotal >= 0 ? '+' : '-';
            const offsetHours = Math.abs(timeZoneHour);
            const offsetMinutes = Math.abs(timeZoneMinute);

            // Format offset string with two-digit minutes
            let offsetString = '';
            if (offsetMinutes === 0) {
                offsetString = `${offsetSign}${offsetHours}hr`;
            } else {
                // Format minutes as two digits (e.g., 30, 45)
                offsetString = `${offsetSign}${offsetHours}.${offsetMinutes.toString().padStart(2, '0')}`;
            }

            // Get city code
            const cityCode = worldData.cityCode || "---";

            // Update all city text widgets
            if (typeof WorldCityName !== 'undefined') {
                WorldCityName.setProperty(hmUI.prop.TEXT, worldData.city);
            }
            if (typeof WorldCityNameWTO !== 'undefined') {
                WorldCityNameWTO.setProperty(hmUI.prop.TEXT, `${worldData.city} ${offsetString}`);
            }
            if (typeof WorldCityCodeText !== 'undefined') {
                WorldCityCodeText.setProperty(hmUI.prop.TEXT, cityCode);
            }

            // Update offset text - visibility controlled by updateWorldCityDisplay()
            WorldCityOffsetText.setProperty(hmUI.prop.TEXT, `${cityCode} ${offsetString}`);

            // --- Calculate and show actual GMT offset ---
            if (clockIndex > -1 && worldData) {
                // Try to get local GMT offset from TIME sensor
                let localGMTOffsetMin = curTime.timezone;

                // If not available, fallback to JS Date
                if (localGMTOffsetMin === undefined || isNaN(localGMTOffsetMin)) {
                    // getTimezoneOffset() = minutes behind UTC, so invert sign
                    localGMTOffsetMin = -(new Date().getTimezoneOffset());
                }

                // WORLD_CLOCK offset relative to local
                const cityOffsetMin = (worldData.timeZoneHour * 60) + worldData.timeZoneMinute;

                // Absolute GMT offset (in hours, may include .5)
                const cityGMTOffsetHr = (localGMTOffsetMin + cityOffsetMin) / 60;

                // Round to nearest 0.5
                const rounded = Math.round(cityGMTOffsetHr * 2) / 2;

                // Format string
                let offsetStr = "GMT ";
                if (rounded > 0) offsetStr += "+" + rounded;
                else offsetStr += rounded;

                GMTZoneText.setProperty(hmUI.prop.TEXT, offsetStr);
                
                // Update world map position based on GMT offset
                if (worldMapImg) {
                    // Calculate target position: -320 - (rounded * 120)
                    targetMapX = -320 - (rounded * 20);
                    
                    // Start animation immediately (removed 0.5 second delay)
                    startMapAnimation();
                }
            } else {
                // No city selected - set to default GMT 0 position
                GMTZoneText.setProperty(hmUI.prop.TEXT, "GMT ?");
                
                // Set map to default GMT 0 position
                if (worldMapImg) {
                    targetMapX = -320; // GMT 0 position
                    startMapAnimation();
                }
            }

            // Update target angles for world clock analog hands
            updateWorldClockTargetAngles();

            // Show world clock hands if a city is selected (not affected by World Time toggle)
            world_clock_hour_pointer_img.setProperty(hmUI.prop.VISIBLE, clockIndex > -1);
            world_clock_minute_pointer_img.setProperty(hmUI.prop.VISIBLE, clockIndex > -1);
        }

        function updateSeconds() {
            let curSecond = curTime.second.toString().padStart(2, "0");
            secsText.setProperty(hmUI.prop.TEXT, curSecond);
        }

        function toggleWorldClock(step = 1) {
            const count = worldClock.getWorldClockCount();
            if (count) {
                clockIndex = (clockIndex + step + count) % count;
                const worldData = worldClock.getWorldClockInfo(clockIndex);

                // Update city image with animation ONLY when city actually changes
                if (worldData.cityCode && WorldCountryFlagA && WorldCountryFlagB) {
                    const cityCode = worldData.cityCode;
                    const imagePath = `${cityCode}.png`;
                    
                    // Use the new animation function - this will only animate if city code changed
                    animateFlagChange(imagePath, cityCode);
                }

                // Update all city name widgets
                if (typeof WorldCityName !== 'undefined') {
                    WorldCityName.setProperty(hmUI.prop.TEXT, worldData.city);
                }
                if (typeof WorldCityNameWTO !== 'undefined') {
                    WorldCityNameWTO.setProperty(hmUI.prop.TEXT, worldData.city);
                }
                if (typeof WorldCityCodeText !== 'undefined') {
                    WorldCityCodeText.setProperty(hmUI.prop.TEXT, worldData.cityCode || "---");
                }

                // REMOVED: Show toast - hmUI.showToast({ text: worldData.city });

                updateWorldTime();
                hmFS.SysProSetInt('dt_wf_clockIndex', clockIndex);

                // Show world clock hands if a city is selected (not affected by World Time toggle)
                world_clock_hour_pointer_img.setProperty(hmUI.prop.VISIBLE, clockIndex > -1);
                world_clock_minute_pointer_img.setProperty(hmUI.prop.VISIBLE, clockIndex > -1);
                
                // IMPORTANT: Re-apply the world city display mode to ensure correct visibility
                updateWorldCityDisplay();
            }
        }

        function initWorldClock() {
            if (reInitClock) {
                clockIndex = -1;
                worldClock.uninit();
                hmFS.SysProSetInt('dt_wf_clockIndex', 0);
                reInitClock = false;
            }
            worldClock.init();
            let count = worldClock.getWorldClockCount();
            if (count > 0) {
                clockIndex = hmFS.SysProGetInt('dt_wf_clockIndex') || 0;
                const worldData = worldClock.getWorldClockInfo(clockIndex);

                // Update city image - set initial image without animation
                if (worldData.cityCode && WorldCountryFlagA && WorldCountryFlagB) {
                    const cityCode = worldData.cityCode;
                    const imagePath = `${cityCode}.png`;
                    
                    // Set initial image without animation
                    currentCityCode = cityCode;
                    try {
                        WorldCountryFlagA.setProperty(hmUI.prop.SRC, imagePath);
                        WorldCountryFlagA.setProperty(hmUI.prop.VISIBLE, showWorldCountryFlag && (!isAOD || showWorldCountryFlagAOD));
                        WorldCountryFlagA.setProperty(hmUI.prop.ALPHA, 255);
                        WorldCountryFlagB.setProperty(hmUI.prop.VISIBLE, false);
                    } catch (e) {
                        console.log(`Image ${imagePath} not found, using default`);
                        WorldCountryFlagA.setProperty(hmUI.prop.SRC, "default_city.png");
                        WorldCountryFlagA.setProperty(hmUI.prop.VISIBLE, showWorldCountryFlag && (!isAOD || showWorldCountryFlagAOD));
                        WorldCountryFlagA.setProperty(hmUI.prop.ALPHA, 255);
                        WorldCountryFlagB.setProperty(hmUI.prop.VISIBLE, false);
                        currentCityCode = 'default';
                    }
                }

                // Update all city name widgets
                if (typeof WorldCityName !== 'undefined') {
                    WorldCityName.setProperty(hmUI.prop.TEXT, worldData.city);
                }
                if (typeof WorldCityNameWTO !== 'undefined') {
                    WorldCityNameWTO.setProperty(hmUI.prop.TEXT, worldData.city);
                }
                if (typeof WorldCityCodeText !== 'undefined') {
                    WorldCityCodeText.setProperty(hmUI.prop.TEXT, worldData.cityCode || "---");
                }

                hmFS.SysProSetInt('dt_wf_clockIndex', clockIndex);

                // Show world clock hands if a city is selected (not affected by World Time toggle)
                world_clock_hour_pointer_img.setProperty(hmUI.prop.VISIBLE, true);
                world_clock_minute_pointer_img.setProperty(hmUI.prop.VISIBLE, true);
            } else {
                // Update all city name widgets
                if (typeof WorldCityName !== 'undefined') {
                    WorldCityName.setProperty(hmUI.prop.TEXT, 'Add City');
                }
                if (typeof WorldCityNameWTO !== 'undefined') {
                    WorldCityNameWTO.setProperty(hmUI.prop.TEXT, 'Add City');
                }
                if (typeof WorldCityCodeText !== 'undefined') {
                    WorldCityCodeText.setProperty(hmUI.prop.TEXT, '---');
                }

                // Set default city image when no cities (without animation)
                if (WorldCountryFlagA && WorldCountryFlagB) {
                    currentCityCode = 'default';
                    WorldCountryFlagA.setProperty(hmUI.prop.SRC, "default_city.png");
                    WorldCountryFlagA.setProperty(hmUI.prop.VISIBLE, showWorldCountryFlag && (!isAOD || showWorldCountryFlagAOD));
                    WorldCountryFlagA.setProperty(hmUI.prop.ALPHA, 255);
                    WorldCountryFlagB.setProperty(hmUI.prop.VISIBLE, false);
                }

                // Hide world clock hands if no city selected
                world_clock_hour_pointer_img.setProperty(hmUI.prop.VISIBLE, false);
                world_clock_minute_pointer_img.setProperty(hmUI.prop.VISIBLE, false);
                
                // Update GMT text
                GMTZoneText.setProperty(hmUI.prop.TEXT, "GMT ?");
            }
        }

        function startSecTimer() {
            if (!secTimer) {
                setTimeout(() => {
                    worldClock.init();
                    secTimer = setInterval(updateSeconds, 1000);
                }, 1000 - (curTime.utc % 1000));
            }
        }

        function stopSecTimer() {
            if (secTimer) clearInterval(secTimer);
            secTimer = null;
        }

        // *** Analog Clock Functions (battery-friendly) ***
        function updateAnalogClocks() {
            updateLocalAnalogClock();
            updateWorldClockTargetAngles();
        }

        function updateLocalAnalogClock() {
            let hour = curTime.hour;
            let minute = curTime.minute;
            let second = curTime.second;

            // Calculate angles for local clock
            let normal_hour = hour % 12; // Convert to 12-hour format
            let normal_angle_hour = (360 * normal_hour) / 12 + (360 / 12) * (minute / 60);
            let normal_angle_minute = (360 * minute) / 60 + (360 / 60) * (second / 60);
            
            // Set angles for local clock hands
            analog_clock_time_pointer_hour.setProperty(hmUI.prop.ANGLE, normal_angle_hour);
            analog_clock_time_pointer_minute.setProperty(hmUI.prop.ANGLE, normal_angle_minute);
            
            // Only update seconds in normal mode (not AOD)
            if (!isAOD) {
                let second_angle = (360 * second) / 60;
                analog_clock_pro_second_pointer_img.setProperty(hmUI.prop.ANGLE, second_angle);
            }
        }

        function updateWorldClockTargetAngles() {
            if (clockIndex > -1) {
                const worldData = worldClock.getWorldClockInfo(clockIndex);
                if (worldData && worldData.hour !== undefined && worldData.minute !== undefined) {
                    let worldHour = parseInt(worldData.hour);
                    let worldMinute = parseInt(worldData.minute);
                    let worldSecond = curTime.second; // Use current seconds for smooth movement

                    // Calculate target angles for world clock with second precision
                    let normal_hour = worldHour % 12;
                    wt_target_angle_hour = (360 * normal_hour) / 12 + (360 / 12) * (worldMinute / 60) + (360 / 12 / 60) * (worldSecond / 60);
                    wt_target_angle_minute = (360 * worldMinute) / 60 + (360 / 60) * (worldSecond / 60);

                    // Start smooth animation if not already running
                    if (!wt_smooth_timer && !isAOD) {
                        wt_smooth_timer = timer.createTimer(0, 100, animateWorldClockSmooth); 
                    }
                    
                    // For AOD mode, set the angles directly without animation
                    if (isAOD) {
                        wt_current_angle_hour = wt_target_angle_hour;
                        wt_current_angle_minute = wt_target_angle_minute;
                        world_clock_hour_pointer_img.setProperty(hmUI.prop.ANGLE, wt_current_angle_hour);
                        world_clock_minute_pointer_img.setProperty(hmUI.prop.ANGLE, wt_current_angle_minute);
                    }
                }
            }
        }

        function animateWorldClockSmooth() {
            // Update target angles with current time
            updateWorldClockTargetAngles();
            
            // Smooth interpolation for normal mode
            wt_current_angle_hour += (wt_target_angle_hour - wt_current_angle_hour) * 0.2;
            wt_current_angle_minute += (wt_target_angle_minute - wt_current_angle_minute) * 0.2;

            // Update world clock hands
            world_clock_hour_pointer_img.setProperty(hmUI.prop.ANGLE, wt_current_angle_hour);
            world_clock_minute_pointer_img.setProperty(hmUI.prop.ANGLE, wt_current_angle_minute);
        }

        // *** Vibration Functions ***
        let timer_StopVibrate = null;

        function vibro(scene = 25) {
            let stopDelay = 50;
            stopVibro();
            vibrate.stop();
            vibrate.scene = scene;
            if(scene < 23 || scene > 25) stopDelay = 1300;
            vibrate.start();
            if (scene != 1) timer_StopVibrate = timer.createTimer(stopDelay, 3000, stopVibro, {});
        }

        function stopVibro(){
            vibrate.stop();
            if(timer_StopVibrate) timer.stopTimer(timer_StopVibrate);
        }

        // *** Connection Check Function ***
        function checkConnection() {
            console.log('checkConnection()');
            hmBle.removeListener;
            hmBle.addListener(function (status) {
                if(!status) {
                    hmUI.showToast({text: "Connection Lost"});
                    vibro(9);
                }
                if(status) {
                    hmUI.showToast({text: "Connection Restored"});
                    vibro(9);
                }
            });
        }

        // *** Helper button style function ***
        function strokeBtn(props) {
            let rectProps = {
              x: props.x,
              y: props.y,
              w: props.w,
              h: props.h,
              radius: props.radius,
              line_width: props.line_width || 4,
              color: props.strokeColor,
              show_level: hmUI.show_level.ONLY_NORMAL,
            }

            let btnProps = {
              x: props.x + 3,
              y: props.y + 3,
              w: props.w - 6,
              h: props.h - 6,
              text: props.text || '',
              text_size: props.text_size || 50,
              color: props.textColor || 0xffffff,
              radius: props.radius - 4,
              normal_color: props.normal_color || 0x222222,
              press_color: props.press_color || 0x454545,
              click_func: props.click_func,
              show_level: hmUI.show_level.ONLY_NORMAL,
            }

            let gr = props.group || hmUI;
            gr.createWidget(hmUI.widget.BUTTON, btnProps);
        }

        //----------------------------

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                // Initialize default settings first
                initializeDefaultSettings();
                
                // Load widget visibility settings
                loadWidgetVisibility();
                
                // Preload fonts for both digital and analog hands
                hmUI.createWidget(hmUI.widget.TEXT, {
                  x: DEVICE_WIDTH-2,
                  y: DEVICE_HEIGHT-2,
                  w: sc(324),
                  h: sc(155),
                  text_size: sc(clockSize),
                  char_space: 0,
                  line_space: 0,
                  font: 'fonts/Zepp_Number.ttf',
                  color: 0xffffff,
                  align_h: hmUI.align.RIGHT,
                  align_v: hmUI.align.TOP,
                  text_style: hmUI.text_style.ELLIPSIS,
                  text: "0123456789 :-",
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });

                hmUI.createWidget(hmUI.widget.TEXT, {
                  x: DEVICE_WIDTH-2,
                  y: DEVICE_HEIGHT-2,
                  w: sc(324),
                  h: sc(41),
                  text_size: sc(secSize),
                  char_space: 0,
                  line_space: 0,
                  font: 'fonts/Zepp_Number.ttf',
                  color: 0xffffff,
                  align_h: hmUI.align.RIGHT,
                  align_v: hmUI.align.TOP,
                  text_style: hmUI.text_style.ELLIPSIS,
                  text: "0123456789",
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });

                // Background color
                hmUI.createWidget(hmUI.widget.FILL_RECT, {
                  x: 0,
                  y: 0,
                  w: DEVICE_WIDTH,
                  h: DEVICE_HEIGHT,
				  radius: DEVICE_WIDTH,
                  color: 0x969696,
                });

				// Hide in Black color
                secsText = hmUI.createWidget(hmUI.widget.TEXT, {
                  x: sc(0),
                  y: sc(0),
                  w: sc(82),
                  h: sc(62),
                  text_size: sc(5),
                  char_space: sc(0),
                  line_space: 0,
                  text: '00',
                  font: 'fonts/Zepp_Number.ttf',
                  color: 0x000000,
                  align_h: hmUI.align.LEFT,
                  align_v: hmUI.align.CENTER_V,
                  text_style: hmUI.text_style.ELLIPSIS,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });

				// Hide in Black color
                Local_city_name_text = hmUI.createWidget(hmUI.widget.TEXT, {
                  x: sc(0),
                  y: sc(0),
                  w: DEVICE_WIDTH - sc(124),
                  h: sc(50),
                  text_size: sc(5),
                  char_space: 0,
                  line_space: 0,
                  color: 0x000000,
                  align_h: hmUI.align.CENTER_H,
                  align_v: hmUI.align.CENTER_V,
                  text_style: hmUI.text_style.NONE,
                });

                // World Map Image - UPDATED Y POSITION
                worldMapImg = hmUI.createWidget(hmUI.widget.IMG, {
                    x: currentMapX, // Initial position for GMT 0
                    y: sc(105), // CHANGED from sc(115) to sc(105)
                    w: sc(1120), // Width of the world map image
                    h: sc(270),
                    src: "World Zone.png",
                });

                // Analog background image (initially hidden)
                Bg_img = hmUI.createWidget(hmUI.widget.IMG, {
                  x: 0,
                  y: 0,
                  w: DEVICE_WIDTH,
                  h: DEVICE_HEIGHT,
                  src: isAOD ? "BG1_Idle.png" : "BG1.png",
                  show_level: hmUI.show_level.ALL,
                });

                // GMT Zone text widget
                GMTZoneText = hmUI.createWidget(hmUI.widget.TEXT, {
                  x: 0,
                  y: 0,
                  w: DEVICE_WIDTH,
                  h: sc(40),
                  text_size: sc(5),
                  text: 'GMT 0',
                  color: 0x000000,
                  align_h: hmUI.align.LEFT,
                  align_v: hmUI.align.CENTER_V,
                  text_style: hmUI.text_style.ELLIPSIS,
                  visible: true,
                });

                LocalMonthText = hmUI.createWidget(hmUI.widget.TEXT, {
                  x: sc(360),
                  y: centerY - sc(50),
                  w: sc(70),
                  h: sc(50),
                  text_size: sc(secSize),
                  char_space: 0,
                  line_space: 0,
                  text: '',
                  font: 'fonts/Zepp_Number.ttf',
                  color: mainColor,
                  align_h: hmUI.align.RIGHT,
                  align_v: hmUI.align.CENTER_V,
                  text_style: hmUI.text_style.ELLIPSIS,
                  show_level: hmUI.show_level.ALL, // Changed from ONLY_NORMAL
                  visible: showLocalDate && (!isAOD || showLocalDateAOD)
                });

                // Digital display elements
                LocalDayText = hmUI.createWidget(hmUI.widget.TEXT, {
                  x: sc(435),
                  y: centerY - sc(50),
                  w: sc(50),
                  h: sc(50),
                  text_size: sc(secSize),
                  char_space: 0,
                  line_space: 0,
                  text: '',
                  font: 'fonts/Zepp_Number.ttf',
                  color: mainColor,
                  align_h: hmUI.align.LEFT,
                  align_v: hmUI.align.CENTER_V,
                  text_style: hmUI.text_style.ELLIPSIS,
                  show_level: hmUI.show_level.ALL, // Changed from ONLY_NORMAL
                  visible: showLocalDate && (!isAOD || showLocalDateAOD)
                });

                LocalWeekdayText = hmUI.createWidget(hmUI.widget.TEXT, {
                  x: sc(393),
                  y: centerY,
                  w: sc(70),
                  h: sc(50),
                  text_size: sc(secSize),
                  char_space: 0,
                  line_space: 0,
                  text: '',
                  font: 'fonts/Zepp_Number.ttf',
                  color: mainColor,
                  align_h: hmUI.align.CENTER_H,
                  align_v: hmUI.align.CENTER_V,
                  text_style: hmUI.text_style.ELLIPSIS,
                  show_level: hmUI.show_level.ALL, // Changed from ONLY_NORMAL
                  visible: showLocalWeekdayText && (!isAOD || showLocalWeekdayTextAOD)
                });

                LocalTimeText = hmUI.createWidget(hmUI.widget.TEXT, {
                  x: is24HourFormat ? 0 : sc(-18),
                  y: sc(20),
                  w: DEVICE_WIDTH,
                  h: sc(80),
                  text_size: sc(clockSize),
                  char_space: 0,
                  line_space: 0,
                  text: '00:00',
                  font: 'fonts/Zepp_Number.ttf',
                  color: mainColor,
                  align_h: hmUI.align.CENTER_H,
                  align_v: hmUI.align.CENTER_V,
                  text_style: hmUI.text_style.ELLIPSIS,
                  show_level: hmUI.show_level.ALL, // Changed from ONLY_NORMAL
                  visible: showLocalTime && (!isAOD || showLocalTimeAOD)
                });

                AmPm = hmUI.createWidget(hmUI.widget.TEXT, {
                  x: centerX + sc(32),
                  y: sc(30),
                  w: sc(82),
                  h: sc(50),
                  text_size: sc(secSize),
                  char_space: 0,
                  line_space: 0,
                  text: '00',
                  font: 'fonts/Zepp_Number.ttf',
                  color: mainColor,
                  align_h: hmUI.align.LEFT,
                  align_v: hmUI.align.CENTER_V,
                  text_style: hmUI.text_style.ELLIPSIS,
                  show_level: hmUI.show_level.ALL, // Changed from ONLY_NORMAL
                  visible: showLocalTime && (!isAOD || showLocalTimeAOD) && !is24HourFormat
                });

                battery_empty_img = hmUI.createWidget(hmUI.widget.IMG, {
                  x: sc(70),
                  y: sc(72),
                  src: 'Bat-lvl-1.png',
                });

                normal_battery_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
                  x: sc(70),
                  y: sc(72),
                  image_array: ["Bat-lvl-1.png","Bat-lvl-2.png","Bat-lvl-3.png","Bat-lvl-4.png","Bat-lvl-5.png","Bat-lvl-6.png","Bat-lvl-7.png","Bat-lvl-8.png","Bat-lvl-9.png","Bat-lvl-10.png"],
                  image_length: 10,
                  type: hmUI.data_type.BATTERY,
                });

                normal_battery_current_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
                  x: sc(83),
                  y: sc(72),
                  w: sc(103),
                  h: sc(50),
                  text_size: sc(45),
                  char_space: 0,
                  line_space: 0,
                  font: 'fonts/Zepp_Number.ttf',
                  color: isAOD ? 0xFFE6E6E6 : mainColor,
                  align_h: hmUI.align.CENTER_H,
                  align_v: hmUI.align.CENTER_V,
                  unit_type: 1,
                  text_style: hmUI.text_style.ELLIPSIS,
                  type: hmUI.data_type.BATTERY,
                });

                // WorldCityName widget (city name only) - INITIALLY VISIBLE BASED ON MODE
                WorldCityName = hmUI.createWidget(hmUI.widget.TEXT, {
                  x: sc(62),
                  y: centerY + sc(120),
                  w: DEVICE_WIDTH - sc(124),
                  h: sc(52),
                  text_size: sc(37),
                  char_space: 0,
                  line_space: 0,
                  text: '',
                  color: mainColor,
                  align_h: hmUI.align.CENTER_H,
                  align_v: hmUI.align.TOP,
                  text_style: hmUI.text_style.NONE,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                  visible: worldCityDisplayMode === 0 // Use the loaded setting
                });

                // WorldCityNameWTO widget (city name + time offset) - INITIALLY HIDDEN
                WorldCityNameWTO = hmUI.createWidget(hmUI.widget.TEXT, {
                  x: sc(62),
                  y: centerY + sc(120),
                  w: DEVICE_WIDTH - sc(124),
                  h: sc(52),
                  text_size: sc(37),
                  char_space: 0,
                  line_space: 0,
                  text: '',
                  color: mainColor,
                  align_h: hmUI.align.CENTER_H,
                  align_v: hmUI.align.TOP,
                  text_style: hmUI.text_style.NONE,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                  visible: worldCityDisplayMode === 1 // Use the loaded setting
                });

                // World City Code text widget (city code only) - INITIALLY HIDDEN
                WorldCityCodeText = hmUI.createWidget(hmUI.widget.TEXT, {
                    x: sc(62),
                    y: centerY + sc(120),
                    w: DEVICE_WIDTH - sc(124),
                    h: sc(52),
                    text_size: sc(37),
                    char_space: 0,
                    line_space: 0,
                    text: '',
                    color: mainColor,
                    align_h: hmUI.align.CENTER_H,
                    align_v: hmUI.align.CENTER_V,
                    text_style: hmUI.text_style.ELLIPSIS,
                    visible: worldCityDisplayMode === 2, // Use the loaded setting
                    show_level: hmUI.show_level.ONLY_NORMAL,
                });

                // City offset text widget - INITIALLY HIDDEN
                WorldCityOffsetText = hmUI.createWidget(hmUI.widget.TEXT, {
                  x: sc(62),
                  y: centerY + sc(120),
                  w: DEVICE_WIDTH - sc(124),
                  h: sc(52),
                  text_size: sc(37),
                  char_space: 0,
                  line_space: 0,
                  text: '',
                  color: mainColor,
                  align_h: hmUI.align.CENTER_H,
                  align_v: hmUI.align.CENTER_V,
                  text_style: hmUI.text_style.ELLIPSIS,
                  visible: worldCityDisplayMode === 3, // Use the loaded setting
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });

                // City Image Widgets for gradual animation
                WorldCountryFlagA = hmUI.createWidget(hmUI.widget.IMG, {
                    x: sc(20),
                    y: centerY + sc(2),
                    w: sc(100),
                    h: sc(130),
                    src: "default_city.png", // Default image when no city selected
                    show_level: hmUI.show_level.ALL, // Changed from ONLY_NORMAL
                    visible: showWorldCountryFlag && (!isAOD || showWorldCountryFlagAOD),
                    alpha: 255
                });

                WorldCountryFlagB = hmUI.createWidget(hmUI.widget.IMG, {
                    x: sc(20),
                    y: centerY + sc(2),
                    w: sc(100),
                    h: sc(130),
                    src: "default_city.png", // Default image when no city selected
                    show_level: hmUI.show_level.ALL, // Changed from ONLY_NORMAL
                    visible: false,
                    alpha: 0
                });

                WorldDateText = hmUI.createWidget(hmUI.widget.TEXT, {
                  x: sc(20),
                  y: centerY - sc(50),
                  w: sc(100),
                  h: sc(50),
                  text_size: sc(secSize),
                  char_space: 0,
                  line_space: 0,
                  text: '',
                  font: 'fonts/Zepp_Number.ttf',
                  color: mainColor,
                  align_h: hmUI.align.CENTER_H,
                  align_v: hmUI.align.CENTER_V,
                  text_style: hmUI.text_style.ELLIPSIS,
                  show_level: hmUI.show_level.ALL, // Changed from ONLY_NORMAL
                  visible: showWorldDateText && (!isAOD || showWorldDateTextAOD)
                });
				
                WorldTimeText = hmUI.createWidget(hmUI.widget.TEXT, {
                  x: is24HourFormat ? 0 : sc(-16),
                  y: centerY + sc(170),
                  w: DEVICE_WIDTH,
                  h: sc(60),
                  text_size: sc(50),
                  char_space: 0,
                  line_space: 0,
                  text: '00:00',
                  font: 'fonts/Zepp_Number.ttf',
                  color: mainColor,
                  align_h: hmUI.align.CENTER_H,
                  align_v: hmUI.align.CENTER_V,
                  text_style: hmUI.text_style.ELLIPSIS,
                  show_level: hmUI.show_level.ALL, // Changed from ONLY_NORMAL
                  visible: showWorldTime && (!isAOD || showWorldTimeAOD)
                });

                WAmPm = hmUI.createWidget(hmUI.widget.TEXT, {
                  x: centerX + sc(30),
                  y: centerY + sc(175),
                  w: sc(82),
                  h: sc(50),
                  text_size: sc(secSize),
                  char_space: 0,
                  line_space: 0,
                  text: '00',
                  font: 'fonts/Zepp_Number.ttf',
                  color: mainColor,
                  align_h: hmUI.align.LEFT,
                  align_v: hmUI.align.CENTER_V,
                  text_style: hmUI.text_style.ELLIPSIS,
                  show_level: hmUI.show_level.ALL, // Changed from ONLY_NORMAL
                  visible: showWorldTime && (!isAOD || showWorldTimeAOD) && !is24HourFormat
                });

                normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
                  x: sc(420),
                  y: sc(135),
                  src: 'Statuses-BlueTooth.png',
                  type: hmUI.system_status.DISCONNECT,
                });

                // *** Settings button (replaces time format button) ***
                hmUI.createWidget(hmUI.widget.BUTTON, {
                    x: sc(350),
                    y: sc(60),
                    w: sc(80),
                    h: sc(80),
                    normal_src: 'Icon-Settings.png',
                    press_src: 'Icon-Settings.png',
					alpha: 125,
                    show_level: hmUI.show_level.ONLY_NORMAL,
                    click_func: showSettingsWindow,
                });

                // World clock analog hands
                world_clock_hour_pointer_img = hmUI.createWidget(hmUI.widget.IMG, {
                  x: 0,
                  y: 0,
                  w: DEVICE_WIDTH,
                  h: DEVICE_HEIGHT,
                  pos_x: centerX - sc(25),
                  pos_y: centerY - sc(155),
                  center_x: centerX,
                  center_y: centerY,
                  src: isAOD ? "idle_world_hour.png" : "World_hour.png",
                  angle: 0,
                  show_level: hmUI.show_level.ALL,
                  visible: false,
				  enable: false // Make non-interactive
                 });

                world_clock_minute_pointer_img = hmUI.createWidget(hmUI.widget.IMG, {
                  x: 0,
                  y: 0,
                  w: DEVICE_WIDTH,
                  h: DEVICE_HEIGHT,
                  pos_x: centerX - sc(25),
                  pos_y: centerY - sc(207),
                  center_x: centerX,
                  center_y: centerY,
                  src: isAOD ? "idle_world_minute.png" : "World_minute.png",
                  angle: 0,
                  show_level: hmUI.show_level.ALL,
                  visible: false,
				  enable: false // Make non-interactive
                 });

                // Create analog clock components (hands)
                analog_clock_time_pointer_hour = hmUI.createWidget(hmUI.widget.IMG, {
                  x: 0,
                  y: 0,
                  w: DEVICE_WIDTH,
                  h: DEVICE_HEIGHT,
                  pos_x: centerX - sc(25),
                  pos_y: centerY - sc(155),
                  center_x: centerX,
                  center_y: centerY,
                  src: isAOD ? "idle_hours.png" : "Local_hours.png",
                  angle: 0,
                  show_level: hmUI.show_level.ALL,
                  visible: false,
				  enable: false // Make non-interactive
                 });

                analog_clock_time_pointer_minute = hmUI.createWidget(hmUI.widget.IMG, {
                  x: 0,
                  y: 0,
                  w: DEVICE_WIDTH,
                  h: DEVICE_HEIGHT,
                  pos_x: centerX - sc(25),
                  pos_y: centerY - sc(207),
                  center_x: centerX,
                  center_y: centerY,
                  src: isAOD ? "idle_minutes.png" : "Local_minutes.png",
                  angle: 0,
                  show_level: hmUI.show_level.ALL,
                  visible: false,
				  enable: false // Make non-interactive
                 });

                // Second hand
                analog_clock_pro_second_pointer_img = hmUI.createWidget(hmUI.widget.IMG, {
                  x: 0,
                  y: 0,
                  w: DEVICE_WIDTH,
                  h: DEVICE_HEIGHT,
                  pos_x: centerX - sc(25),
                  pos_y: centerY - sc(203),
                  center_x: centerX,
                  center_y: centerY,
                  src: "Seconds.png",
                  angle: 0,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                  visible: false,
				  enable: false // Make non-interactive
                 });

                // *** City navigation buttons (Transparent) ***
                leftCityButton = hmUI.createWidget(hmUI.widget.BUTTON, {
                  x: 1 + 3,
                  y: DEVICE_HEIGHT/2 - 31 + 3,
                  w: 62 - 6,
                  h: 62 - 6,
                  text: '', // No text
				  normal_src: 'transparent.png',
				  press_src: 'transparent.png',
                  show_level: hmUI.show_level.ONLY_NORMAL,
                  click_func: () => {
                    toggleWorldClock(-1);
                    click_Vibrate();
                  },
                });

                rightCityButton = hmUI.createWidget(hmUI.widget.BUTTON, {
                  x: DEVICE_WIDTH - 62 + 3,
                  y: DEVICE_HEIGHT/2 - 31 + 3,
                  w: 62 - 6,
                  h: 62 - 6,
                  text: '', // No text
				  normal_src: 'transparent.png',
				  press_src: 'transparent.png',
                  show_level: hmUI.show_level.ONLY_NORMAL,
                  click_func: () => {
                    toggleWorldClock(1);
                    click_Vibrate();
                  },
                });

                // Transparent always-visible buttons for convenience
                hmUI.createWidget(hmUI.widget.BUTTON, {
                  x: 1,
                  y: DEVICE_HEIGHT/2 - 31,
                  w: 62,
                  h: 62,
                  text: '',
                  normal_src: 'transparent.png',
                  press_src: 'transparent.png',
                  click_func: () => {
                    toggleWorldClock(-1);
                    click_Vibrate();
                  },
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });

                hmUI.createWidget(hmUI.widget.BUTTON, {
                  x: DEVICE_WIDTH - 62,
                  y: DEVICE_HEIGHT/2 - 31,
                  w: 62,
                  h: 62,
                  text: '',
                  normal_src: 'transparent.png',
                  press_src: 'transparent.png',
                  click_func: () => {
                    toggleWorldClock(1);
                    click_Vibrate();
                  },
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });

                // Shortcuts and jumpable elements (unchanged)
                hmUI.createWidget(hmUI.widget.BUTTON, {
                  x: sc(62), // Changed from centerY - sc(50)
                  y: centerY + sc(120), // New position
                  w: DEVICE_WIDTH - sc(124),
                  h: sc(70),
                  text: '',
                  normal_src: 'blank.png',
                  press_src: 'blank.png',
                  click_func: () => {
                    hmApp.startApp({ url: 'WorldClockScreen', native: true });
                    reInitClock = true;
                  },
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });

                // World City Display Mode Toggle Button
                hmUI.createWidget(hmUI.widget.BUTTON, {
                  x: centerX - sc(50),
                  y: DEVICE_HEIGHT - sc(50),
                  w: sc(100),
                  h: sc(50),
                  text: '',
                  normal_src: 'blank.png',
                  press_src: 'blank.png',
                  click_func: cycleWorldCityDisplayMode,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });

                // Hide time hands button (new feature)
                hmUI.createWidget(hmUI.widget.BUTTON, {
                  x: sc(185),
                  y: sc(185),
                  w: sc(110),
                  h: sc(110),
                  text: '',
                  normal_src: 'transparent.png',
                  press_src: 'transparent.png',
                  click_func: () => {
                    // Hide all time hands
                    analog_clock_time_pointer_hour.setProperty(hmUI.prop.VISIBLE, false);
                    analog_clock_time_pointer_minute.setProperty(hmUI.prop.VISIBLE, false);
                    analog_clock_pro_second_pointer_img.setProperty(hmUI.prop.VISIBLE, false);
                    world_clock_hour_pointer_img.setProperty(hmUI.prop.VISIBLE, false);
                    world_clock_minute_pointer_img.setProperty(hmUI.prop.VISIBLE, false);

                    hmUI.showToast({ text: "Hide 5 second" });

                    // Restore after 5 seconds
                    setTimeout(() => {
                      analog_clock_time_pointer_hour.setProperty(hmUI.prop.VISIBLE, true);
                      analog_clock_time_pointer_minute.setProperty(hmUI.prop.VISIBLE, true);
                      // Show seconds hands only if not AOD
                      analog_clock_pro_second_pointer_img.setProperty(hmUI.prop.VISIBLE, !isAOD);
                      world_clock_hour_pointer_img.setProperty(hmUI.prop.VISIBLE, clockIndex > -1);
                      world_clock_minute_pointer_img.setProperty(hmUI.prop.VISIBLE, clockIndex > -1);
                    }, 5000);
                  },
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });

                hmUI.createWidget(hmUI.widget.BUTTON, {
                  x: sc(103),
                  y: 0,
                  w: sc(274),
                  h: sc(77),
                  text: '',
                  normal_src: 'shortcut.png',
                  press_src: 'shortcut.png',
                  click_func: () => {
                    hmApp.startApp({ url: 'ScheduleCalScreen', native: true });
                  },
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });

                normal_battery_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
                  x: sc(70),
                  y: sc(72),
                  w: sc(103),
                  h: sc(50),
                  type: hmUI.data_type.BATTERY,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });

                // Initialize world clock index and UI state
                if(isAOD) {
                    clockIndex = hmFS.SysProGetInt('dt_wf_clockIndex');
                    // FIX: Force update analog clocks immediately in AOD mode
                    updateLocalAnalogClock();
                }

                // Apply visibility settings to all widgets
                applyWidgetVisibility();
				
				// Update text positions based on initial time format
				updateTextPositions();

                // Events
                curTime.addEventListener(curTime.event.MINUTEEND, function () {
                    initWorldClock();
                    updateTime();
                });

                // Local city name fetch
                function scale_call() {
                  console.log('Weather city name');
                  const weatherSensor = hmSensor.createSensor(hmSensor.id.WEATHER);
                  const weatherData = weatherSensor.getForecastWeather();
                  Local_city_name_text.setProperty(hmUI.prop.TEXT, weatherData.cityName);
                };

                // Widget delegate: resume/pause lifecycle
                const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
                  resume_call: (function () {
                    // Update isAOD flag
                    isAOD = hmSetting.getScreenType() == hmSetting.screen_type.AOD;
                    
                    // Re-apply widget visibility for current mode
                    applyWidgetVisibility();
                    
                    scale_call();
                    initWorldClock();
                    updateTime();
                    checkConnection();
                    if (!isAOD) startSecTimer();

                    // FIX for AOD wake alignment - Add this block
                    if (clockIndex > -1) {
                        updateWorldClockTargetAngles();
                        wt_current_angle_hour = wt_target_angle_hour;
                        wt_current_angle_minute = wt_target_angle_minute;
                        world_clock_hour_pointer_img.setProperty(hmUI.prop.ANGLE, wt_current_angle_hour);
                        world_clock_minute_pointer_img.setProperty(hmUI.prop.ANGLE, wt_current_angle_minute);
                    }

				// Start analog update timer - BATTERY OPTIMIZED VERSION
				if (!analog_update_timer) {
					if (!isAOD) {
						// Normal mode → update every second
						analog_update_timer = timer.createTimer(0, 1000, updateAnalogClocks);
					} else {
						// AOD mode → update immediately and then every minute (not every 100ms)
						updateLocalAnalogClock(); // Immediate update
						analog_update_timer = timer.createTimer(0, 60000, updateLocalAnalogClock); // Once per minute
					}
				}

				// Start world clock smooth animation timer - BATTERY OPTIMIZED
				if (clockIndex > -1 && !wt_smooth_timer && !isAOD) {
					updateWorldClockTargetAngles();
					wt_smooth_timer = timer.createTimer(0, 1000, updateWorldClockTargetAngles); // Changed from 100ms to 1000ms
				} else if (isAOD && wt_smooth_timer) {
					timer.stopTimer(wt_smooth_timer);
					wt_smooth_timer = null;
					// FIX: Update world clock angles directly in AOD mode
					if (clockIndex > -1) {
						updateWorldClockTargetAngles();
					}
				}

                  }),
                  pause_call: (function () {
                    stopSecTimer();
                    console.log('pause_call()');
                    stopVibro();

                    // Stop analog update timer
                    if (analog_update_timer) {
                        timer.stopTimer(analog_update_timer);
                        analog_update_timer = null;
                    }

                    // Stop world clock smooth animation timer
                    if (wt_smooth_timer) {
                        timer.stopTimer(wt_smooth_timer);
                        wt_smooth_timer = null;
                    }

                    // Stop flag animation timer
                    if (flagAnimationTimer) {
                        clearInterval(flagAnimationTimer);
                        flagAnimationTimer = null;
                    }

                    // Close settings window if open
                    if (settingsWindowGroup) {
                        hmUI.deleteWidget(settingsWindowGroup);
                        settingsWindowGroup = null;
                        isSettingsOpen = false;
                    }
                  }),
                });
            },
            onInit() {
            },
            build() {
                this.init_view();
            },
            onDestroy() {
                worldClock.uninit();

                // Stop timers
                if (secTimer) clearInterval(secTimer);
                if (analog_update_timer) {
                    timer.stopTimer(analog_update_timer);
                    analog_update_timer = null;
                }
                if (wt_smooth_timer) {
                    timer.stopTimer(wt_smooth_timer);
                    wt_smooth_timer = null;
                }
                if (flagAnimationTimer) {
                    clearInterval(flagAnimationTimer);
                    flagAnimationTimer = null;
                }

                // Close settings window if open
                if (settingsWindowGroup) {
                    hmUI.deleteWidget(settingsWindowGroup);
                    settingsWindowGroup = null;
                }
            }
        });
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
}