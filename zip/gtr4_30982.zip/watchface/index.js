﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.0.1
    ** Copyright © CashaCX75. All Rights Reserved
    */

    try {
    (()=>{
        //dynamic modify start

        
        let normal_background_bg = ''
        // let normal_analog_clock_time_pointer_second = ''
        let normal_battery_image_progress_img_level = ''
        let normal_step_icon_img = ''
        let normal_step_image_progress_img_level = ''
        let normal_heart_rate_text_text_img = ''
        let normal_date_img_date_day = ''
        let normal_date_img_date_year = ''
        let normal_date_img_date_month_img = ''
        let normal_system_disconnect_img = ''
        let normal_date_img_date_week_img = ''
        let normal_digital_clock_img_time = ''
        let normal_analog_clock_time_pointer_hour = ''
        let normal_analog_clock_time_pointer_minute = ''

        let idle_background_bg_img = ''
        let idle_system_disconnect_img = ''
        let idle_digital_clock_img_time = ''
        let normal_alarm_jumpable_img_click = ''
        let normal_heart_jumpable_img_click = ''
        let normal_step_jumpable_img_click = ''


        //dynamic modify end
        const e = __$$hmAppManager$$__.currentApp;
        const o = e.current
          , {px: i} = (new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(e,o)),
        e.__globals__)
          , n = Logger.getLogger("watchface6");
        o.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            normal_background_bg = hmUI.createWidget(hmUI.widget.FILL_RECT, {
              x: 0,
              y: 0,
              w: 466,
              h: 466,
              color: '0xFF000000',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_analog_clock_time_pointer_second = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
            //  second_path: 'hand_sec.png',
            //  second_centerX: 233,
            //  second_centerY: 233,
            //  second_posX: 233,
            //  second_posY: 233,
            //  second_cover_path: 'hand_sec_dot.png',
            //  second_cover_x: 0,
            //  second_cover_y: 0,
            //  show_level: hmUI.show_level.ONLY_NORMAL,
            // });

        // SMOOTH SECONDS Definition
        let second_centerX = 233;
        let second_centerY = 233;
        let second_posX = 233;
        let second_posY = 233;
        let second_path = "hand_sec.png";
        // ----------------------------
        let sec_pointer;
        let clock_timer;
        let animAngle = 0;
        let animDelay = 0;
        const animFps = 30;                             // Frames per second 
        const animRepeat = 1000 / animFps;              // then execute every <animRepeat>ms
        const deviceInfo = hmSetting.getDeviceInfo();   // Needed for automatic screen size detection
        // SMOOTH SECONDS Definition End

        sec_pointer = hmUI.createWidget(hmUI.widget.IMG, {
          x: 0,
          y: 0,
          w: deviceInfo.width,
          h: deviceInfo.height,
          pos_x: second_centerX - second_posX,
          pos_y: second_centerY - second_posY,
          center_x: second_centerX,
          center_y: second_centerY,
          src: second_path,
          angle: 0,
          show_level: hmUI.show_level.ONLY_NORMAL,
        });

        let bazel = hmUI.createWidget(hmUI.widget.IMG, {
          x: 0,
          y: 0,
          src: 'false_hand_sec_dot.png',
          angle: 0,
          show_level: hmUI.show_level.ONLY_NORMAL,
        });

        const now = hmSensor.createSensor(hmSensor.id.TIME);

        const vDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
          resume_call: (function () {
            console.log('ui resume');

            if (!clock_timer) {
              console.log('createTimer');
              clock_timer = timer.createTimer(animDelay, animRepeat, (function (option) {
                animAngle = (now.second * 6) + (((now.utc % 1000) / 1000) * 6);
                sec_pointer.setProperty(hmUI.prop.ANGLE, animAngle);
              }));
            }
          }),
          pause_call: (function () {
            console.log('ui pause');
            if (clock_timer) {
              timer.stopTimer(clock_timer);
              clock_timer = undefined;
              console.log('stopTimer');
            }
          }),

        });
        // End Smooth Seconds



            normal_battery_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 233,
              y: 282,
              image_array: ["DOWN_progress_01.png","DOWN_progress_02.png","DOWN_progress_03.png","DOWN_progress_04.png","DOWN_progress_05.png","DOWN_progress_06.png","DOWN_progress_07.png","DOWN_progress_08.png","DOWN_progress_09.png","DOWN_progress_10.png"],
              image_length: 10,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'hand_sec_dot.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 236,
              y: 61,
              image_array: ["UP_progress_01.png","UP_progress_02.png","UP_progress_03.png","UP_progress_04.png","UP_progress_05.png","UP_progress_06.png","UP_progress_07.png","UP_progress_8.png"],
              image_length: 8,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 369,
              y: 154,
              font_array: ["numbers_hearth_00.png","numbers_hearth_01.png","numbers_hearth_02.png","numbers_hearth_03.png","numbers_hearth_04.png","numbers_hearth_05.png","numbers_hearth_06.png","numbers_hearth_07.png","numbers_hearth_08.png","numbers_hearth_09.png"],
              padding: false,
              h_space: -1,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 211,
              day_startY: 30,
              day_sc_array: ["Numbers_L_00.png","Numbers_L_01.png","Numbers_L_02.png","Numbers_L_03.png","Numbers_L_04.png","Numbers_L_05.png","Numbers_L_06.png","Numbers_L_07.png","Numbers_L_08.png","Numbers_L_09.png"],
              day_tc_array: ["Numbers_L_00.png","Numbers_L_01.png","Numbers_L_02.png","Numbers_L_03.png","Numbers_L_04.png","Numbers_L_05.png","Numbers_L_06.png","Numbers_L_07.png","Numbers_L_08.png","Numbers_L_09.png"],
              day_en_array: ["Numbers_L_00.png","Numbers_L_01.png","Numbers_L_02.png","Numbers_L_03.png","Numbers_L_04.png","Numbers_L_05.png","Numbers_L_06.png","Numbers_L_07.png","Numbers_L_08.png","Numbers_L_09.png"],
              day_zero: 1,
              day_space: 0,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_year = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              year_startX: 188,
              year_startY: 420,
              year_sc_array: ["Numbers_L_00.png","Numbers_L_01.png","Numbers_L_02.png","Numbers_L_03.png","Numbers_L_04.png","Numbers_L_05.png","Numbers_L_06.png","Numbers_L_07.png","Numbers_L_08.png","Numbers_L_09.png"],
              year_tc_array: ["Numbers_L_00.png","Numbers_L_01.png","Numbers_L_02.png","Numbers_L_03.png","Numbers_L_04.png","Numbers_L_05.png","Numbers_L_06.png","Numbers_L_07.png","Numbers_L_08.png","Numbers_L_09.png"],
              year_en_array: ["Numbers_L_00.png","Numbers_L_01.png","Numbers_L_02.png","Numbers_L_03.png","Numbers_L_04.png","Numbers_L_05.png","Numbers_L_06.png","Numbers_L_07.png","Numbers_L_08.png","Numbers_L_09.png"],
              year_zero: 1,
              year_space: 0,
              year_align: hmUI.align.CENTER_H,
              year_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_month_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 188,
              month_startY: 397,
              month_sc_array: ["month_01.png","month_02.png","month_03.png","month_04.png","month_05.png","month_06.png","month_07.png","month_08.png","month_09.png","month_10.png","month_11.png","month_12.png"],
              month_tc_array: ["month_01.png","month_02.png","month_03.png","month_04.png","month_05.png","month_06.png","month_07.png","month_08.png","month_09.png","month_10.png","month_11.png","month_12.png"],
              month_en_array: ["month_01.png","month_02.png","month_03.png","month_04.png","month_05.png","month_06.png","month_07.png","month_08.png","month_09.png","month_10.png","month_11.png","month_12.png"],
              month_is_character: true ,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 366,
              y: 282,
              src: 'bluetooth.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 188,
              y: 50,
              week_en: ["week_day_01.png","week_day_02.png","week_day_03.png","week_day_04.png","week_day_05.png","week_day_06.png","week_day_07.png"],
              week_tc: ["week_day_01.png","week_day_02.png","week_day_03.png","week_day_04.png","week_day_05.png","week_day_06.png","week_day_07.png"],
              week_sc: ["week_day_01.png","week_day_02.png","week_day_03.png","week_day_04.png","week_day_05.png","week_day_06.png","week_day_07.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 304,
              hour_startY: 208,
              hour_array: ["Numbers_Big_00.png","Numbers_Big_01.png","Numbers_Big_02.png","Numbers_Big_03.png","Numbers_Big_04.png","Numbers_Big_05.png","Numbers_Big_06.png","Numbers_Big_07.png","Numbers_Big_08.png","Numbers_Big_09.png"],
              hour_zero: 1,
              hour_space: 1,
              hour_align: hmUI.align.LEFT,

              minute_startX: 369,
              minute_startY: 208,
              minute_array: ["Numbers_Big_00.png","Numbers_Big_01.png","Numbers_Big_02.png","Numbers_Big_03.png","Numbers_Big_04.png","Numbers_Big_05.png","Numbers_Big_06.png","Numbers_Big_07.png","Numbers_Big_08.png","Numbers_Big_09.png"],
              minute_zero: 1,
              minute_space: 1,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_hour = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              hour_path: 'hand_hour.png',
              hour_centerX: 233,
              hour_centerY: 233,
              hour_posX: 233,
              hour_posY: 233,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_minute = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              minute_path: 'hand_minute.png',
              minute_centerX: 233,
              minute_centerY: 233,
              minute_posX: 233,
              minute_posY: 233,
              minute_cover_path: 'dot_2.png',
              minute_cover_x: 0,
              minute_cover_y: 0,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            idle_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 466,
              h: 466,
              src: 'aod_main.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 366,
              y: 282,
              src: 'bluetooth.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 304,
              hour_startY: 208,
              hour_array: ["Numbers_Big_00.png","Numbers_Big_01.png","Numbers_Big_02.png","Numbers_Big_03.png","Numbers_Big_04.png","Numbers_Big_05.png","Numbers_Big_06.png","Numbers_Big_07.png","Numbers_Big_08.png","Numbers_Big_09.png"],
              hour_zero: 1,
              hour_space: 1,
              hour_align: hmUI.align.LEFT,

              minute_startX: 369,
              minute_startY: 208,
              minute_array: ["Numbers_Big_00.png","Numbers_Big_01.png","Numbers_Big_02.png","Numbers_Big_03.png","Numbers_Big_04.png","Numbers_Big_05.png","Numbers_Big_06.png","Numbers_Big_07.png","Numbers_Big_08.png","Numbers_Big_09.png"],
              minute_zero: 1,
              minute_space: 1,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_AOD,
            });
            
            // disconnectAlert = hmUI.createWidget(hmUI.widget.DisconnectAlert, {
              // disconneсnt_vibrate_type: 9,
              // conneсnt_vibrate_type: 9,
              // conneсnt_toast_text: CONNECTION RESTORED,
            // });

            // vibration when connecting or disconnecting

            function checkConnection() {
              hmBle.removeListener;
              hmBle.addListener(function (status) {
                if(!status) {
                  vibro(9);
                }
                if(status) {
                  hmUI.showToast({text: "CONNECTION RESTORED"});
                  vibro(9);
                }
              });
            }

            // end vibration when connecting or disconnecting
            // vibrate function

            const vibrate = hmSensor.createSensor(hmSensor.id.VIBRATE);
            let timer_StopVibrate = null;


            function vibro(scene = 25) {
              let stopDelay = 50;
              stopVibro();
              vibrate.scene = scene;
              if(scene < 23 || scene > 25) stopDelay = 1300;
              vibrate.start();
              timer_StopVibrate = timer.createTimer(stopDelay, 3000, stopVibro, {});
            }

            function stopVibro(){
              vibrate.stop();
              if(timer_StopVibrate) timer.stopTimer(timer_StopVibrate);
            }

            // end vibrate function

            normal_alarm_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 300,
              y: 205,
              w: 124,
              h: 55,
              src: 'click_e.png',
              type: hmUI.data_type.ALARM_CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 357,
              y: 128,
              w: 70,
              h: 70,
              src: 'click_e.png',
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 241,
              y: 73,
              w: 107,
              h: 100,
              src: 'click_e.png',
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                checkConnection();
                stopVibro();

              }),
              pause_call: (function () {
                stopVibro();

              }),
            });

                //dynamic modify end
            },
            onInit() {
                n.log("index page.js on init invoke")
            },
            build() {
                this.init_view(),
                n.log("index page.js on ready invoke")
            },
            onDestroy() {
                n.log("index page.js on destroy invoke")
            }
        })
    }
    )()
} catch (e) {
    console.log("Mini Program Error", e),
    e && e.stack && e.stack.split(/\n/).forEach((e=>console.log("error stack", e)))
}

