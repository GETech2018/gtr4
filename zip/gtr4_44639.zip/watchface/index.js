﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        //const logger = Logger.getLogger('watchface_SashaCX75');
        const logger = DeviceRuntimeCore.HmLogger.getLogger('watchface_SashaCX75')
        //end of ignored block

        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_temperature_icon_img = ''
        let normal_temperature_current_text_font = ''
        let normal_altimeter_icon_img = ''
        let normal_altitude_target_text_font = ''
        let normal_distance_icon_img = ''
        let normal_distance_current_text_font = ''
        let normal_step_icon_img = ''
        let normal_step_current_text_font = ''
        let normal_heart_rate_icon_img = ''
        let normal_heart_rate_text_font = ''
        let normal_calorie_icon_img = ''
        let normal_system_disconnect_img = ''
        let normal_analog_clock_time_pointer_hour = ''
        let normal_analog_clock_time_pointer_minute = ''
        let normal_analog_clock_time_pointer_second = ''
        let normal_step_jumpable_img_click = ''
        let normal_heart_jumpable_img_click = ''
        let normal_battery_jumpable_img_click = ''
		
		// добавляем сенсор погоды для получения числового значения температуры
		let weatherSensor = hmSensor.createSensor(hmSensor.id.WEATHER);

		// функция получения значения температуры
		function getTemperature() {
			let val = weatherSensor.current;		// получаем значение текущей температуры
			//let min = weatherSensor.low;			// получаем значение минимальной температуры
			//let max = weatherSensor.high;			// получаем значение максимальной температуры

			if (!isFinite(val)) return '--'			// если на входе не число - возвращаем прочерки
			val = Math.round(val);
			if (val > 0) val = '+' + val;			// если температура положительная - добавляем знак плюс
			val += '°';								// добавляем символ градуса
			
			return val
		}

		// функция обновления температуры (обновления виджета)
		// надо добавить вызов этой функции при включении экрана и каждую минуту
		function updateWeather() {
			normal_temperature_current_text_font.setProperty(hmUI.prop.TEXT_FONT, getTemperature());
		}
		
		let btn_zona1 = ''       
        let zona1_num = 0       
        let zona1_all = 5

        function click_zona1() {		  
        zona1_num = (zona1_num + 1) % (zona1_all + 1);  
        if (zona1_num == 0) {
          normal_calorie_icon_img.setProperty(hmUI.prop.VISIBLE, true);
		  normal_heart_rate_icon_img.setProperty(hmUI.prop.VISIBLE, false);
          normal_heart_rate_text_font.setProperty(hmUI.prop.VISIBLE, false);
		  normal_step_icon_img.setProperty(hmUI.prop.VISIBLE, false);
          normal_step_current_text_font.setProperty(hmUI.prop.VISIBLE, false);
		  normal_distance_icon_img.setProperty(hmUI.prop.VISIBLE, false);
          normal_distance_current_text_font.setProperty(hmUI.prop.VISIBLE, false);
          normal_altimeter_icon_img.setProperty(hmUI.prop.VISIBLE, false);
          normal_altitude_target_text_font.setProperty(hmUI.prop.VISIBLE, false);
          normal_temperature_icon_img.setProperty(hmUI.prop.VISIBLE, false);
          normal_temperature_current_text_font.setProperty(hmUI.prop.VISIBLE, false);
             hmUI.showToast({     
          });        
        };
		
		if (zona1_num == 1) {
          normal_calorie_icon_img.setProperty(hmUI.prop.VISIBLE, false);
		  normal_heart_rate_icon_img.setProperty(hmUI.prop.VISIBLE, true);
          normal_heart_rate_text_font.setProperty(hmUI.prop.VISIBLE, true);
		  normal_step_icon_img.setProperty(hmUI.prop.VISIBLE, false);
          normal_step_current_text_font.setProperty(hmUI.prop.VISIBLE, false);
		  normal_distance_icon_img.setProperty(hmUI.prop.VISIBLE, false);
          normal_distance_current_text_font.setProperty(hmUI.prop.VISIBLE, false);
          normal_altimeter_icon_img.setProperty(hmUI.prop.VISIBLE, false);
          normal_altitude_target_text_font.setProperty(hmUI.prop.VISIBLE, false);
          normal_temperature_icon_img.setProperty(hmUI.prop.VISIBLE, false);
          normal_temperature_current_text_font.setProperty(hmUI.prop.VISIBLE, false);
             hmUI.showToast({     
          });        
        };
		
		if (zona1_num == 2) {
          normal_calorie_icon_img.setProperty(hmUI.prop.VISIBLE, false);
		  normal_heart_rate_icon_img.setProperty(hmUI.prop.VISIBLE, false);
          normal_heart_rate_text_font.setProperty(hmUI.prop.VISIBLE, false);
		  normal_step_icon_img.setProperty(hmUI.prop.VISIBLE, true);
          normal_step_current_text_font.setProperty(hmUI.prop.VISIBLE, true);
		  normal_distance_icon_img.setProperty(hmUI.prop.VISIBLE, false);
          normal_distance_current_text_font.setProperty(hmUI.prop.VISIBLE, false);
          normal_altimeter_icon_img.setProperty(hmUI.prop.VISIBLE, false);
          normal_altitude_target_text_font.setProperty(hmUI.prop.VISIBLE, false);
          normal_temperature_icon_img.setProperty(hmUI.prop.VISIBLE, false);
          normal_temperature_current_text_font.setProperty(hmUI.prop.VISIBLE, false);
             hmUI.showToast({     
          });        
        };
		
		if (zona1_num == 3) {
          normal_calorie_icon_img.setProperty(hmUI.prop.VISIBLE, false);
		  normal_heart_rate_icon_img.setProperty(hmUI.prop.VISIBLE, false);
          normal_heart_rate_text_font.setProperty(hmUI.prop.VISIBLE, false);
		  normal_step_icon_img.setProperty(hmUI.prop.VISIBLE, false);
          normal_step_current_text_font.setProperty(hmUI.prop.VISIBLE, false);
		  normal_distance_icon_img.setProperty(hmUI.prop.VISIBLE, true);
          normal_distance_current_text_font.setProperty(hmUI.prop.VISIBLE, true);
          normal_altimeter_icon_img.setProperty(hmUI.prop.VISIBLE, false);
          normal_altitude_target_text_font.setProperty(hmUI.prop.VISIBLE, false);
          normal_temperature_icon_img.setProperty(hmUI.prop.VISIBLE, false);
          normal_temperature_current_text_font.setProperty(hmUI.prop.VISIBLE, false);
             hmUI.showToast({     
          });        
        };
		
		if (zona1_num == 4) {
          normal_calorie_icon_img.setProperty(hmUI.prop.VISIBLE, false);
		  normal_heart_rate_icon_img.setProperty(hmUI.prop.VISIBLE, false);
          normal_heart_rate_text_font.setProperty(hmUI.prop.VISIBLE, false);
		  normal_step_icon_img.setProperty(hmUI.prop.VISIBLE, false);
          normal_step_current_text_font.setProperty(hmUI.prop.VISIBLE, false);
		  normal_distance_icon_img.setProperty(hmUI.prop.VISIBLE, false);
          normal_distance_current_text_font.setProperty(hmUI.prop.VISIBLE, false);
          normal_altimeter_icon_img.setProperty(hmUI.prop.VISIBLE, true);
          normal_altitude_target_text_font.setProperty(hmUI.prop.VISIBLE, true);
          normal_temperature_icon_img.setProperty(hmUI.prop.VISIBLE, false);
          normal_temperature_current_text_font.setProperty(hmUI.prop.VISIBLE, false);
             hmUI.showToast({     
          });        
        };
		
		if (zona1_num == 5) {
          normal_calorie_icon_img.setProperty(hmUI.prop.VISIBLE, false);
		  normal_heart_rate_icon_img.setProperty(hmUI.prop.VISIBLE, false);
          normal_heart_rate_text_font.setProperty(hmUI.prop.VISIBLE, false);
		  normal_step_icon_img.setProperty(hmUI.prop.VISIBLE, false);
          normal_step_current_text_font.setProperty(hmUI.prop.VISIBLE, false);
		  normal_distance_icon_img.setProperty(hmUI.prop.VISIBLE, false);
          normal_distance_current_text_font.setProperty(hmUI.prop.VISIBLE, false);
          normal_altimeter_icon_img.setProperty(hmUI.prop.VISIBLE, false);
          normal_altitude_target_text_font.setProperty(hmUI.prop.VISIBLE, false);
          normal_temperature_icon_img.setProperty(hmUI.prop.VISIBLE, true);
          normal_temperature_current_text_font.setProperty(hmUI.prop.VISIBLE, true);
             hmUI.showToast({     
          });        
        };
	   }


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            // FontName: conthrax-book.ttf; FontSize: 40
            hmUI.createWidget(hmUI.widget.TEXT, {
              x: 464,
              y: 464,
              w: 716,
              h: 67,
              text_size: 40,
              char_space: 1,
              line_space: 0,
              font: 'fonts/conthrax-book.ttf',
              color: 0xFFFFFFFF,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              text: "0123456789 _-.,:;`'%°\\/",
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            console.log('Watch_Face.ScreenNormal');
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 466,
              h: 466,
              src: 'ball.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 107,
              y: 277,
              src: 'weather.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 159,
              y: 303,
              w: 160,
              h: 39,
              text_size: 40,
              char_space: 1,
              font: 'fonts/conthrax-book.ttf',
              color: 0xFFFFFFFF,
              line_space: 0,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.CENTER_H,
              unit_type: 1,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_altimeter_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 110,
              y: 277,
              src: 'alti.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_altitude_target_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 161,
              y: 298,
              w: 150,
              h: 49,
              text_size: 40,
              char_space: 1,
              font: 'fonts/conthrax-book.ttf',
              color: 0xFFFFFFFF,
              line_space: 0,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.ALTITUDE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_distance_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 107,
              y: 277,
              src: 'dist.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_distance_current_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 159,
              y: 293,
              w: 150,
              h: 55,
              text_size: 40,
              char_space: 1,
              font: 'fonts/conthrax-book.ttf',
              color: 0xFFFFFFFF,
              line_space: 0,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.DISTANCE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 151,
              y: 277,
              src: 'step.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 139,
              y: 298,
              w: 194,
              h: 52,
              text_size: 40,
              char_space: 1,
              font: 'fonts/conthrax-book.ttf',
              color: 0xFFFFFFFF,
              line_space: 0,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 151,
              y: 277,
              src: 'pulse.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 158,
              y: 298,
              w: 150,
              h: 46,
              text_size: 40,
              char_space: 1,
              font: 'fonts/conthrax-book.ttf',
              color: 0xFFFFFFFF,
              line_space: 0,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_calorie_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 156,
              y: 258,
              src: 'horse.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 156,
              y: 258,
              src: 'blue.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_hour = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              hour_path: 'h.png',
              hour_centerX: 233,
              hour_centerY: 233,
              hour_posX: 26,
              hour_posY: 144,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_minute = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              minute_path: 'm.png',
              minute_centerX: 233,
              minute_centerY: 233,
              minute_posX: 16,
              minute_posY: 222,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_second = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              second_path: 'sec.png',
              second_centerX: 233,
              second_centerY: 233,
              second_posX: 17,
              second_posY: 215,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            console.log('Watch_Face.Shortcuts');

            normal_step_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 381,
              y: 193,
              w: 80,
              h: 80,
              src: 'empty.png',
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 4,
              y: 193,
              w: 80,
              h: 80,
              src: 'empty.png',
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 193,
              y: 382,
              w: 80,
              h: 80,
              src: 'empty.png',
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
			
			btn_zona1 = hmUI.createWidget(hmUI.widget.BUTTON, {             
              x: 193,             
              y: 283,              
              text: '',              
              w: 80,             
              h: 80,             
              normal_src: 'Empty.png',              
              press_src: 'Empty.png',             
              click_func: () => {				  
               click_zona1();               
               click_Vibrate();             
              },              
              show_level: hmUI.show_level.ONLY_NORMAL,            
            });
            
             btn_zona1.setProperty(hmUI.prop.VISIBLE, true);
          normal_heart_rate_icon_img.setProperty(hmUI.prop.VISIBLE, false);
          normal_heart_rate_text_font.setProperty(hmUI.prop.VISIBLE, false);
		  normal_step_icon_img.setProperty(hmUI.prop.VISIBLE, false);
          normal_step_current_text_font.setProperty(hmUI.prop.VISIBLE, false);
		  normal_distance_icon_img.setProperty(hmUI.prop.VISIBLE, false);
          normal_distance_current_text_font.setProperty(hmUI.prop.VISIBLE, false);
          normal_altimeter_icon_img.setProperty(hmUI.prop.VISIBLE, false);
          normal_altitude_target_text_font.setProperty(hmUI.prop.VISIBLE, false);
          normal_temperature_icon_img.setProperty(hmUI.prop.VISIBLE, false);
          normal_temperature_current_text_font.setProperty(hmUI.prop.VISIBLE, false);
		  
		  hmUI.createWidget(hmUI.widget.BUTTON, {
            x: 193,        // координата кнопки X
            y: 6,      // координата кнопки Y
            w: 80,       // ширина кнопки
            h: 80,      // высота кнопки
            text: '',      // здесь можно написать текст, который будет на кнопке
            normal_src: 'empty.png',         // картинка кнопки, тут пустая
            press_src: 'empty.png',           // картинка кнопки при нажатии, тут пустая
            click_func: () => {
	        hmApp.startApp({ appid: 1057409, url: 'page/index' });         // вот тут вызывается нужное приложение
            },
            show_level: hmUI.show_level.ONLY_NORMAL,
            });
			
			hmUI.createWidget(hmUI.widget.BUTTON, {
            x: 194,        // координата кнопки X
            y: 194,      // координата кнопки Y
            w: 80,       // ширина кнопки
            h: 80,      // высота кнопки
            text: '',      // здесь можно написать текст, который будет на кнопке
            normal_src: 'empty.png',         // картинка кнопки, тут пустая
            press_src: 'empty.png',           // картинка кнопки при нажатии, тут пустая
            click_func: () => {
	        hmApp.startApp({ appid: 1051195, url: 'page/index', params: { from_wf: true} });         // вот тут вызывается нужное приложение
            },
            show_level: hmUI.show_level.ONLY_NORMAL,
            });


                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}