﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        //const logger = Logger.getLogger('watchface_SashaCX75');
        const logger = DeviceRuntimeCore.HmLogger.getLogger('watchface_SashaCX75')
        //end of ignored block

        //dynamic modify start

        
        console.log('user_functions.js');
        // start user_functions.js

const {
    width: D_W,
    height: D_H
   } = hmSetting.getDeviceInfo();

    const packageInfo = hmApp.packageInfo(); 
    WF_ID = packageInfo.appId;	

let kf = D_W / 466;

//   const baro = hmSensor.createSensor(hmSensor.id.BARO);
//    const pressureValue = baro.pressure;
//    const altitudeValue = baro.altitude;
    
      const windDirectionStr = [
       ['Северный', 'N', 'С'], // 0
       ['Сев-Вос', 'NE', 'СВ'], // 1
       ['Восточный', 'E', 'В'], // 2
       ['Юго-Вос', 'SE', 'ЮВ'], // 3
       ['Южный', 'S', 'Ю'], // 4
       ['Юго-Зап', 'SW', 'ЮЗ'], // 5
       ['Западный', 'W', 'З'], // 6
       ['Сев-Зап', 'NW', 'СЗ'], // 7
      ];



function getWindDescription(angle, lang) {
    const normalizedAngle = parseFloat(angle) % 360;
    const index = Math.floor((normalizedAngle + 22.5) / 45) % 8;
    return windDirectionStr[index][lang];
} 
    

 let screenTypeJS = hmSetting.getScreenType();

/********  класс Провайдер погоды  ********/
/******				v1.4			*******/
/******		2025 © leXxiR [4pda]	*******/

	class WeatherProvider {
	  constructor(props = {}) {
		this.props = {
			night_icons: [],											// индексы иконок для замены день-ночь
			index: hmFS.SysProGetInt('WeatherProviderIndex') ?? 0,		// текущий индекс провайдера (сохраняется и считывается из памяти)
			show_toast: true,											// показывать всплывающее сообщение при переключении провайдера
			temp_widget: null,											// виджет TEXT для отображения температуры
			temp_max_widget: null,										// виджет TEXT для отображения максимальной температуры
			temp_min_widget: null,										// виджет TEXT для отображения минимальной температуры
			temp_feels_widget: null,									// виджет TEXT для отображения ощущаемой температуры
chance_Of_Rain: null,									// виджет TEXT для отображения осадков            
			description_widget: null,									// виджет TEXT для отображения текстового описания текущей погоды
			cityName_widget: null,										// виджет TEXT для отображения названия города
			windDirection_widget: null,										// виджет TEXT для отображения направления ветра
			windSpeed_widget: null,										// виджет TEXT для отображения скорости ветра
			icon_widget: null,											// виджет IMG для отображения значка погоды
			time_sensor: null,											// сенсор времени, если не задан, то создается новый
			weather_sensor: null,										// сенсор погоды, если не задан, то создается новый
			file_name: 'weather.json',									// имя файла с погодными данными
			auto_update: true,											// автоматическое обновление погоды (нет необходимости добавлять weatherProvider.update() в event.MINUTEEND и WIDGET_DELEGATE)
			lang: hmSetting.getLanguage() == 4 ? 0 : 1,					// языка устройства	(Русский = 0 / Английский = 1)
			...props,
		};

		this.providers = [
						{name: ['Zepp', 'Zepp'], appId: null},							// 0
						{name: ['Погодный сервис', 'Weather service'], appId: 1065824},	// 1
						{name: ['RuWeather', 'RWeather'], appId: 1066654},				// 2
					]

		this.description = [
				['Облачно', 'Временами дождь', 'Временами снег', 'Ясно', 'Пасмурно', 'Слабый дождь', 'Слабый снег', 'Умеренный дождь', 'Умеренный снег', 'Сильный снегопад', 'Сильный дождь', 'Песчаная буря', 'Мокрый снег', 'Туман', 'Дымка', 'Дождь с грозой', 'Метель', 'Пыльно', 'Ливень', 'Дождь с градом', 'Сильный дождь с градом', 'Сильный дождь', 'Пыльная буря', 'Сильная песчаная буря', 'Сильный дождь', 'Обновите погоду', 'Облачно ночью', 'Дождливо ночью', 'Ясно ночью'],
				['Cloudy', 'Showers', 'Snow Showers', 'Sunny', 'Overcast', 'Light Rain', 'Light Snow', 'Moderate Rain', 'Moderate Snow', 'Heavy Snow', 'Heavy Rain', 'Sandstorm', 'Rain and Snow', 'Fog', 'Hazy', 'T-Storms', 'Snowstorm', 'Floating dust', 'Very Heavy Rainstorm', 'Rain and Hail', 'T-Storms and Hail', 'Heavy Rainstorm', 'Dust', 'Heavy sand storm', 'Rainstorm', 'Unknown', 'Cloudy Nighttime', 'Showers Nighttime', 'Sunny Nighttime'],
			]

		this.last = {
			weatherIcon: 25,
			weatherDescription:  'Нет данных',
			temperature: '--',
			temperatureFeels: '--',
			chanceOfRain: '--',
			temperatureMax: '--',
			temperatureMin: '--',
			cityName: '--',
            windDirection: 0,
        windSpeed: '--',
            modTime: null,
		}

		if (!this.props.time_sensor) this.props.time_sensor = hmSensor.createSensor(hmSensor.id.TIME);
		if (!this.props.weather_sensor) this.props.weather_sensor = hmSensor.createSensor(hmSensor.id.WEATHER);
		if (isFinite(props.index)) hmFS.SysProSetInt('WeatherProviderIndex', props.index);
		if (this.props.auto_update) this.createHandlers();
	  }

	// создание обработчиков автоматического обновления погоды
		createHandlers() {
			this.props.time_sensor.addEventListener(this.props.time_sensor.event.MINUTEEND, () => this.update());

			this.widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
			  resume_call: ( () => this.update() )
			})
		}

	// служебные функции
		arrayBufferToCyrillic(buffer) {
		  let result = '';
		  const bytes = new Uint8Array(buffer);

		  let i = 0;
		  while (i < bytes.length) {
			let byte1 = bytes[i++];
			
			if (byte1 < 0x80) {								// Обработка 1-байтовых символов (ASCII)
			  result += String.fromCharCode(byte1);
			} else if (byte1 >= 0xC0 && byte1 < 0xE0) {		// Обработка 2-байтовых символов (UTF-8 кодировка для кириллицы)
			  let byte2 = bytes[i++];
			  let charCode = ((byte1 & 0x1F) << 6) | (byte2 & 0x3F);
			  result += String.fromCharCode(charCode);
			} else if (byte1 >= 0xE0 && byte1 < 0xF0) {		// Обработка 3-байтовых символов (например, для UTF-8)
			  let byte2 = bytes[i++];
			  let byte3 = bytes[i++];
			  let charCode = ((byte1 & 0x0F) << 12) | ((byte2 & 0x3F) << 6) | (byte3 & 0x3F);
			  result += String.fromCharCode(charCode);
			}
		  }

		  return result
		}

	// чтение погодных данных из файла
		readFile(app_id) {
		  if (!app_id) return null				
		  let str_result = "";
		  try {
			const [fs_stat, err] = hmFS.stat(this.props.file_name, {
			  appid: app_id,
			});
			if (err == 0) {
			  const fh = hmFS.open(this.props.file_name, hmFS.O_RDONLY, {
				appid: app_id,
			  });

			  const len = fs_stat.size;
			  let array_buffer = new ArrayBuffer(len);
			  hmFS.read(fh, array_buffer, 0, len);
			  hmFS.close(fh);
			  str_result = this.arrayBufferToCyrillic(array_buffer);

			  return str_result;
			} else {
			  console.log("err:", err);
			}
		  } catch (error) {
			console.log("error:", error);
			console.log("FAIL: No access to hmFS.");
		  }
		  return null;
		}

	// получить время последнего изменеия файла
		getFileModTime(app_id) {
		  if (!app_id) return null
		  try {
			const [fs_stat, err] = hmFS.stat(this.props.file_name, {
			  appid: app_id,
			});
			
			if (err == 0) {
			  return fs_stat.mtime
			} else {
			  console.log("ModTime err:", err);
			}
		  } catch (error) {
			console.log("ModTime error:", error);
			console.log("FAIL: No access to hmFS.");
		  }
			return null
		}

	// проверка времени суток: возвращает true, если сейчас день
		isDayNow() {
			const sunData = this.props.weather_sensor.getForecastWeather().tideData;
			let sunriseMins = 8 * 60;			// время восхода
			let sunsetMins = 20 * 60;			// и заката по умолчанию

			if (sunData.count > 0){
				const today = sunData.data[0];
				sunriseMins = today.sunrise.hour * 60 + today.sunrise.minute;
				sunsetMins = today.sunset.hour * 60 + today.sunset.minute;
			}

			const curMins = curTime.hour * 60 + curTime.minute;
			const nowIsDay = (curMins >= sunriseMins) && (curMins < sunsetMins);

			return nowIsDay
		}


	// сопоставление индекса иконки погоды из приложений WeatherService и RuWeather с иконками погоды от Zepp 
		getZeppIconIndex(index, app_id = null) {
			
			if (!app_id)  return index;			//	если нет app_id, то не меняем индекс иконки

			let newIndex = 25;
			
			if (app_id == 1065824) {					// WeatherService
				switch(index) {
				   case 1:
						newIndex = 3;
					break;
				   case 2:
						newIndex = 0;
					break;
				   case 3:
				   case 4:
						newIndex = 4;
					break;
				   case 5:
						newIndex = 1;
					break;
				   case 6:
						newIndex = 5;
					break;
				   case 7:
						newIndex = 10;
					break;
				   case 8:
						newIndex = 15;
					break;
				   case 9:
						newIndex = 6;
					break;
				   case 10:
						newIndex = 8;
					break;
				   case 11:
						newIndex = 9;
					break;
				   case 12:
						newIndex = 12;
					break;
				   case 13:
						newIndex = 13;
					break;
				   case 14:
						newIndex = 17;
					break;
				   default:
						newIndex = 25;
					break;
				}
			} else if (app_id == 1066654) {					// RuWeather
				newIndex = index - 1;
			}

			return newIndex
		}

	// температура со знаком
		tempWithSign(val){
			val = parseFloat(val);
			if (!isFinite(val)) return '--'		// если на входе не число - возвращаем прочерки
			val = Math.round(val);
			if (val > 0) val = '+' + val;
			val += '°';
			
			return val
		}
        
		tempWithSign0(val){
			val = parseFloat(val);
			if (!isFinite(val)) return '--'		// если на входе не число - возвращаем прочерки
			val = Math.round(val);
			if (val > 0) val = '' + val;
			val += '';
			
			return val
		}
        
        
		
		rainWithSign(val){
			val = parseFloat(val);
			if (!isFinite(val)) return '--'		// если на входе не число - возвращаем прочерки
//			val = Math.round(val);
//			if (val > 0) val = '+' + val;
			val += '';
			
			return val
		}
		

	//получение погодных данных из Zepp
		getZeppWeatherData() {
			const iconIndex = this.props.weather_sensor.curAirIconIndex ?? 25;
			const data = {
				weatherIcon: iconIndex,
				weatherDescription:  this.description[this.props.lang][iconIndex],
				temperature: this.props.weather_sensor.current ?? '--',
				temperatureFeels: '--',
				chanceOfRain: '--',
                windDirection: 0,
                windSpeed: '--',
				temperatureMax: this.props.weather_sensor.high ?? '--',
				temperatureMin: this.props.weather_sensor.low ?? '--',
				cityName: this.props.weather_sensor.getForecastWeather().cityName ?? '--',
			}

			return data
		}

	//получение погодных данных из файла приложения
		getAppWeatherData(app_id) {
			const data = {
				weatherIcon: 25,
				weatherDescription:  'Нет данных',
				temperature: '--',
				temperatureFeels: '--',
				chanceOfRain: '--',
                windDirection: 0,
                windSpeed: '--',
				temperatureMax: '--',
				temperatureMin: '--',
				cityName: '--',
			}

			// читаем данные из файла данных приложения
			let weather_str = this.readFile(app_id);
			let weatherJson = JSON.parse(weather_str);
	  
			if (weatherJson) {
				if (isFinite(weatherJson.weatherIcon)) {		// считываем индекс иконки погоды и сразу переводим в нумерацию Zepp
				  data.weatherIcon = this.getZeppIconIndex(parseInt(weatherJson.weatherIcon), app_id);
				}

				if (weatherJson?.weatherDescriptionExtended?.length) {
				  data.weatherDescription = weatherJson.weatherDescriptionExtended;
				  data.weatherDescription = data.weatherDescription.replace(data.weatherDescription[0], data.weatherDescription[0].toUpperCase());

				} else data.weatherDescription = this.description[data.weatherIcon];

				if (isFinite(weatherJson.temperature)) {
				  data.temperature = parseFloat(weatherJson.temperature);
				  data.temperature = Math.round(data.temperature);
				}
				
				if (isFinite(weatherJson.temperatureFeels)){
					data.temperatureFeels = parseFloat(weatherJson.temperatureFeels);
					data.temperatureFeels = Math.round(data.temperatureFeels);
				}
					
				if (isFinite(weatherJson.chanceOfRain)){
					data.chanceOfRain = parseFloat(weatherJson.chanceOfRain);
					data.chanceOfRain = Math.round(data.chanceOfRain);
				}
					
				  
				if (isFinite(weatherJson.temperatureMax)){
					data.temperatureMax = parseFloat(weatherJson.temperatureMax);
					data.temperatureMax = Math.round(data.temperatureMax);
				}
				  
				if (isFinite(weatherJson.temperatureMin)){
					data.temperatureMin = parseFloat(weatherJson.temperatureMin);
					data.temperatureMin = Math.round(data.temperatureMin);
				}
                
				if (isFinite(weatherJson.windDirection)){
					data.windDirection = parseFloat(weatherJson.windDirection);
					//data.windDirection = Math.round(data.windDirection);
				}
                
        if (isFinite(weatherJson.windSpeed)) {
         data.windSpeed = parseFloat(weatherJson.windSpeed);
         data.windSpeed > 10 ? data.windSpeed = Math.round(data.windSpeed) : data.windSpeed = data.windSpeed.toFixed(1);
        }
                
                
				
				if (weatherJson.city) {
				  data.cityName = weatherJson.city;
				}
			}
			
			return data
		}

	//получение погодных данных из файла приложения или Zepp
		getWeatherData(app_id = null) {
			if (!app_id) return this.getZeppWeatherData()		// если нет app_id, то получаем данные от Zepp
			else return this.getAppWeatherData(app_id);			// иначе читаем данные из файла данных приложения
		}

	// обновить виджеты, используя данные текущего провайдера
		update() {
			let curIcon = parseInt(this.last.weatherIcon);				// текущий индекс значка погоды без учета времени суток (т.е. число без "n")

			const modTime = this.getFileModTime(this.providers[this.props.index].appId);		// время изменеия файла с данными
			
			if (!modTime || this.last.modTime != modTime){										// если не получено время изменеия или оно отличается от последнего времени изменеия
				const newData = this.getWeatherData(this.providers[this.props.index].appId);	// тогда читаем новые данные из файла
				this.last.modTime = modTime;

				let val = this.tempWithSign0(newData.temperature);
				if (val != this.last.temperature){
					this.last.temperature = val;
					if (this.props.temp_widget) this.props.temp_widget.setProperty(hmUI.prop.TEXT, val);
				}

				val = this.tempWithSign0(newData.temperatureMax);
				if (val != this.last.temperatureMax){
					this.last.temperatureMax = val;
					if (this.props.temp_max_widget) this.props.temp_max_widget.setProperty(hmUI.prop.TEXT, val);
				}

				val = this.tempWithSign0(newData.temperatureMin);
				if (val != this.last.temperatureMin){
					this.last.temperatureMin = val;
					if (this.props.temp_min_widget) this.props.temp_min_widget.setProperty(hmUI.prop.TEXT, val);
				}

				val = this.tempWithSign(newData.temperatureFeels);
				if (val != this.last.temperatureFeels){
					this.last.temperatureFeels = val;
					if (this.props.temp_feels_widget) this.props.temp_feels_widget.setProperty(hmUI.prop.TEXT, val);
				}
					
					val = this.rainWithSign(newData.chanceOfRain);
					if (val != this.last.chanceOfRain){
						this.last.chanceOfRain = val;
						if (this.props.chance_Of_Rain) this.props.chance_Of_Rain.setProperty(hmUI.prop.TEXT, val);
					}	
                    
				val = newData.windDirection;
				if (val != this.last.windDirection){
					this.last.windDirection = val;
					if (this.props.windDirection_widget) this.props.windDirection_widget.setProperty(hmUI.prop.TEXT, val);
				}
                
                
				val = newData.windSpeed;
				if (val != this.last.windSpeed){
					this.last.windSpeed = val;
					if (this.props.windSpeed_widget) this.props.windSpeed_widget.setProperty(hmUI.prop.TEXT, val);
				}
                

				val = newData.cityName;
				if (val != this.last.cityName){
					this.last.cityName = val;
					if (this.props.cityName_widget) this.props.cityName_widget.setProperty(hmUI.prop.TEXT, val);
				}

				val = newData.weatherDescription;
				if (val != this.last.weatherDescription){
					this.last.weatherDescription = val;
					if (this.props.description_widget) this.props.description_widget.setProperty(hmUI.prop.TEXT, val);
				}

				
				curIcon = newData.weatherIcon;						// получаем текущий индекс значка погоды
			}

			if (this.props.night_icons.includes(curIcon) && !this.isDayNow()){		// если он в списке ночных иконок и сейчас "ночь", то добавляем суффикс 'n'
				curIcon += 'n';
			}

			if (curIcon != this.last.weatherIcon){
				this.last.weatherIcon = curIcon;
				if (this.props.icon_widget) this.props.icon_widget.setProperty(hmUI.prop.SRC, 'w_${curIcon}.png');
			}
		}

	// переключить на следующего провайдера
		next(show_toast = this.props.show_toast) {
			const v = (this.props.index + 1) % this.providers.length;
			this.provider = v;
			if (show_toast) hmUI.showToast({text: this.name});
		}

	// переключить на предыдующего провайдера
		prev(show_toast = this.props.show_toast) {
			const v = (this.props.index - 1 + this.providers.length) % this.providers.length;
			this.provider = v;
			if (show_toast) hmUI.showToast({text: this.name});
		}

	// переключить назад или вперед
		toggle(dir, show_toast = this.props.show_toast) {
			if (dir > 0) this.next(show_toast)
			else this.prev(show_toast);
		}
		
	// установить провайдера по индексу
		set provider(v) {
			this.props.index = v;
			hmFS.SysProSetInt('WeatherProviderIndex', v);
			this.update();
		}

	// получить индекс текущего провайдера
		get index() {
			return this.props.index
		}

	// получить название текущего провайдера
		get name() {
			return this.providers[this.props.index].name[this.props.lang]
		}
        
	// получить название города
		get cityName() {
			return this.last.cityName
		}

	// получить напрвление ветра
		get windDirection() {
			return this.last.windDirection
		}
        
	// получить скорость ветра
		get windSpeed() {
			return this.last.windSpeed
		}

	// получить текущую температуру
		get temperature() {
			return this.last.temperature
		}

	// получить максимальную температуру
		get temperatureMax() {
			return this.last.temperatureMax
		}

	// получить минимальную температуру
		get temperatureMin() {
			return this.last.temperatureMin
		}

	// получить ощущаемую температуру
		get temperatureFeels() {
			return this.last.temperatureFeels
		}
			
		get chanceOfRain() {
			return this.last.chanceOfRain
		}
			

	// получить описание погоды
		get weatherDescription() {
			return this.last.weatherDescription
		}

	// удалить
	  delete() {
		this.providers = null;
		this.props = null;
		this.last = null;
		this.description = null;
		if (this.widgetDelegate) {
			hmUI.deleteWidget(this.widgetDelegate);
			this.widgetDelegate = null;
		}
	  }

	}			

	
      let normal_M_icon_img = ''
      let idle_M_icon_img = ''
        let normal_timerTimeUpdate2 = undefined;
        let normal_weather_circle_scale = ''
        let normal_heart_rate_text_font_bg = ''
        let normal_sun_circle_scale = ''
		
		
		
		
		
//let timeSensor = hmSensor.createSensor(hmSensor.id.TIME);	  

      
      let groupVremya = ''
      let groupPogoda = ''
      let groupTap = ''
    //  let groupActiv = ''
      //let canvas0 = ''
      //let canvas = ''


      let alpha_grey = 76
	  
	  
	  
      let normal_unit_ic_up = ''	  
      let normal_unit_ic_dw = ''	
	  
      let normal_progress_bg_0 = ''	
      let normal_progress_bg_1 = ''	
      let normal_progress_bg_2 = ''	
      let normal_progress_bg_3 = ''	



      const weatherSensor = hmSensor.createSensor(hmSensor.id.WEATHER);
     // const battery = hmSensor.createSensor(hmSensor.id.BATTERY)
     // const step = hmSensor.createSensor(hmSensor.id.STEP);
     // const heart_rate = hmSensor.createSensor(hmSensor.id.HEART); //heart_rate.last
      const distance = hmSensor.createSensor(hmSensor.id.DISTANCE);
//      const calorie = hmSensor.createSensor(hmSensor.id.CALORIE);
//      const stand = hmSensor.createSensor(hmSensor.id.STAND)
//      const pai = hmSensor.createSensor(hmSensor.id.PAI);
//      const fatburn = hmSensor.createSensor(hmSensor.id.FAT_BURRING);
//      const spo2 = hmSensor.createSensor(hmSensor.id.SPO2);
//      const stress = hmSensor.createSensor(hmSensor.id.STRESS);

let normal_background_bg = ''

let normal_weater_ic = ''




function read_pressure() {
 console.log("read_pressure()");
 const file_name_alt = "../../../baro_altim/pressure.dat";
 const [fs_stat, err] = hmFS.stat(file_name_alt);
 if (err == 0) {
  let file_size = fs_stat.size;
  const len = file_size / 4;
  console.log(`size_alt: ${file_size}, lenght: ${len}`)
  const fh = hmFS.open(file_name_alt, hmFS.O_RDONLY)

  let array_buffer = new Float32Array(len);
  hmFS.read(fh, array_buffer.buffer, 0, file_size);
  hmFS.close(fh);
  console.log(`value ${array_buffer[array_buffer.length -1]}`);
  return array_buffer;
 } else {
  console.log('err:', err)
 }
 return null;
}

function getPressureValue(pressure_array) {
 console.log("getPressureValue()");
 if (pressure_array == null || pressure_array == undefined || pressure_array.length == 0) return 0;
 let start_index = pressure_array.length - 1;
 let end_index = start_index - 30 * 3; // 3 часа
 if (end_index < 0) end_index = 0;
 for (let index = start_index; index >= end_index; index--) {
  if (pressure_array[index] != 0) return parseInt(pressure_array[index] / 100);
 }
 return 0;
}

function changesPressure(pressure_array) {
 console.log("changesPressure()");
 if (pressure_array == null || pressure_array == undefined || pressure_array.length == 0) return 0;
 let start_index = pressure_array.length - 1;
 let end_index = start_index - 30 * 3; // 3 часа
 let value = pressure_array[start_index];
 let result = 0;
 if (end_index < 0) end_index = 0;
 for (let index = start_index; index >= end_index; index--) {
  let element = pressure_array[index];
  if (element != 0) {
   if (Math.abs(value - element) > 10) { // учитываем только если разниза больше 0,1 hPa
    value = value - element;
    console.log(`element = ${element}`);
    console.log(`pressere_changes = ${value}`);
    return value;
   }
  }
 }
 return result;
}

function hPa_To_mmHg(hPa_value = 0) {
 let mmHg = Math.round(hPa_value * 0.750064);
 return mmHg;
}
//#endregion

let text_pressere; // отображаем давление
let text_pressere_changes; // отображаем изменение давления 


function makeAOD() {
 //loadSettings()

 const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
  resume_call: (function () {

   stopVibro();
  }),

  pause_call: (function () {

   //    hmApp.unregisterSpinEvent();
   stopVibro();
  }),
 });


}


let Activ_color_alpha = ''
let menu = 0
let color_ic = 0
let Activ_color = 0



let Btn_set_ = []
let Shag_Y = 66

let color_bg = [
[0xFF0000, 0xFF4500, 0xDC143C, 0xFF69B4, 0xFF1493, 0xFF8C00, 0xFFA500, 0xFFD700, 0xFFFF00, 0x228B22, 0x32CD32, 0x00FF00, 0x98FF98, 0x50C878, 0x00FFFF, 0x00CED1, 0x40E0D0, 0x7FFFD4, 0x0000FF, 0x1E90FF, 0x007FFF, 0x00008B, 0x4B0082, 0x800080, 0x9932CC, 0x8A2BE2, 0xDA70D6, 0xA52A2A, 0xD2691E, 0x8B4513, 0x926226, 0xFFFFFF, 0xD3D3D3, 0x808080, 0x505050, 0x000000],
[0x0068a4, 0x842721, 0xceb372, 0x59775b, 0x6b3278, 0x5a595b, 0xf29851, 0xbdbebe, 0x444645, 0x765d58],
[0xdfdfdf, 0x7d7c7d, 0xd1cb8d, 0x638672, 0x025591, 0x7e438c, 0xac4b45, 0xf4a462, 0x8f7e7b],
	
[0xff0000, 0xff0000, 0xFCB61C, 0x068FF9, 0xFFB900, 0xffffff, 0xf8e36c, 0xb84cf6, 0xa3fd1f, 0xfd912f, 0x8cffff, 0xff00a2, 0x8a8a8a],
	
	
	
];

let colorNames = ["Красный", "Алый", "Малиновый", "Тёмно-красный", "Бордовый", "Розовый", "Оранжевый", "Горчичный", "Золотой", "Жёлтый", "Лимонный", "Мятный", "Изумрудный", "Лесной зелёный", "Оливковый", "Зелёный", "Бирюзовый", "Голубой", "Лазурный", "Синий", "Тёмно-синий", "Индиго", "Пурпурный", "Пурпурный (маджента)", "Белый", "Медовый", "Бежевый", "Светло-серый", "Серый", "Тёмно-серый", "Коричневый", "Чёрный"];

let app_TF = []
let app_ic = []
let app_ACR_text = []

let app_text_arr = [
 ['КАЛОРИИ', hmUI.data_type.CAL, false, 0, 'ic_app_0.png'],
 ['КМ', hmUI.data_type.DISTANCE, false, 0, 'ic_app_1.png'],
 ['ММ.РТ.СТ', hmUI.data_type.ALTIMETER, false, 0, 'ic_app_2.png'],
 ['ВЫСОТА', hmUI.data_type.ALTITUDE, false, 0, 'ic_app_3.png'],
 ['ВЛАЖНОСТЬ', hmUI.data_type.HUMIDITY, false, 1, 'ic_app_4.png'],
 ['НОЧЬ/ДЕНЬ', hmUI.data_type.WEATHER_HIGH_LOW, false, 0, 'ic_app_5.png'],
 ['ВОСХОД', hmUI.data_type.SUN_RISE, false, 0, 'ic_app_7.png'],
 ['СТРЕСС', hmUI.data_type.STRESS, false, 0, 'ic_app_8.png'],
 ['КИСЛОРОД', hmUI.data_type.SPO2, false, 0, 'ic_app_9.png'],
 ['PAI', hmUI.data_type.PAI_DAILY, false, 0, 'ic_app_10.png'],
 ['ЖИР', hmUI.data_type.FAT_BURNING, false, 0, 'ic_app_11.png'],
 ['УФ', hmUI.data_type.UVI, false, 0, 'ic_app_12.png'],
 ['РАЗМИНКА', hmUI.data_type.STAND, false, 0, 'ic_app_13.png'],
 /* ['БУДИЛЬНИК', hmUI.data_type.ALARM_CLOCK, true, 0, 'ic_app_14.png'],*/
 ['ТАЙМЕР', hmUI.data_type.COUNT_DOWN, true, 0, 'ic_app_15.png'],
 ['ЭТАЖ', hmUI.data_type.FLOOR, false, 0, 'ic_app_16.png'],
 ['ВЕТЕР', hmUI.data_type.WIND, false, 0, 'ic_app_17.png'],
 ['ПУЛЬС', hmUI.data_type.HEART, false, 0, 'ic_app_18.png'],
];

let Line_arr = [
 ['C', '--', 'SENS', 'КАЛОРИИ', 0xff791f, '', '--'], //0 калории
 ['L', '--', 0, 'ЭТАЖ', 0x00ff0c, hmUI.data_type.FLOOR, false], //1 ЭТАЖ
 ['^', '--', 'SENS', 'ДАВЛЕНИЕ', 0x12c200, '', '--'], //2 давление
 ['t', '--', 0, 'ГОТОВНОСТЬ', 0xccff66, hmUI.data_type.READINESS, false], //3  ГОТОВНОСТЬ
 ['I', '--', 'SENS', 'PAI', 0xff51d4, '', '--'], //4 pai
 ['O', '--', 'SENS', 'КИСЛОРОД', 0xe400ff, '', '--'], //5 o2
 ['R', '--', 'SENS', 'РАЗМИНКА', 0x01a8ff, '', '--'], //6 разминка
 ['G', '--', 'SENS', 'ЖИР', 0xd7c637, '', '--'], //7 жир
 ['V', '--', 1, 'ВАЛЖНОСТЬ', 0x00ff90, hmUI.data_type.HUMIDITY, false], //8 ВАЛЖНОСТЬ
 ['!', '--', 'SENS', 'СТРЕСС', 0xfcff00, '', '--'], //9 стресс
 ['a', '--', 'SENS', 'СОН', 0x25ced4, '', '--'], //10 сон
 [']', '--', 'SENS', 'ОСАДКИ', 0xFF0000, '', '--'], //11 садки
 ['=', '--', 'SENS', 'ОЩУЩАЕМАЯ', 0xff7e3f, '', '--'], // 12 ощущаемая
 ['W', '--', 'SENS', 'ВЕТЕР', 0x01f6ff, '', '--'], //13 ВЕТЕР
 ['f', '--', 'SENS', 'МИРОВОЕ', 0x21a5d1, '', '--'], //14 МИРОВОЕ
 ['S', '--', 'SENS', 'ШАГИ %', 0x01f6ff, '', '--'], //15 ШАГИ %
 ['U', '--', 0, 'УФ', 0x01f6ff, hmUI.data_type.UVI, false], //16 УФ
 ['E', '--', 'SENS', 'ВЫСОТА', 0x00ff06, '', '--'], //17 ВЫСОТА
 ['T', '--', 0, 'ТАЙМЕР', 0x00ff06, hmUI.data_type.COUNT_DOWN, true], //18 ТАЙМЕР
 ['r', '--', 0, 'AQI', 0xccff33, hmUI.data_type.AQI, false], //19 AQI
 ['K', '--', 'SENS', 'ВОС/ЗАК', 0x01f6ff, '', '--'], //20 ВОС/ЗАК
 ['', '', '', 'ПУСТО'], //21 пусто
];

let CONF_MAIN = [{ // 0. Вертикальный градиент (3 цвета)
 name: 'ЦВЕТ', // кнопка
 id: 11, // при старте
 len: color_bg[0].length, // длина
 type: 'color', // цвет или данные
 colorArrayIndex: 0 // ← явно указываем индекс массива
},/* { // 1. Горизонтальный градиент (2 цвета)
 name: 'БЕЗЕЛЬ', // кнопка
 id: 0,
 len: color_bg[2].length, // длина
 type: 'color',
 colorArrayIndex: 2 // ← явно указываем индекс массива
}, { // 2. Одноцветный прямоугольник
 name: '3 КРУГА ТИП', // кнопка
 id: 0,
 len: color_bg[2].length, // длина
 type: 'color',
 colorArrayIndex: 2 // ← явно указываем индекс массива
}, { // 3. Одноцветный прямоугольник
 name: 'АНАЛОГ ВИД', // кнопка
 id: 0,
 len: 4, // длина
 type: 'png',
}, { // 4. Одноцветный прямоугольник
 name: 'АНАЛОГ ЦВЕТ', // кнопка
 id: 0,
 len: color_bg[0].length, // длина
 type: 'color',
 colorArrayIndex: 0 // ← явно указываем индекс массива
}, { // 5. Одноцветный прямоугольник
 name: 'ПРОГРЕСС ВИД', // кнопка
 id: 0,
 len: 2, // длина
 type: 'png',
}, { // 6. Одноцветный прямоугольник
 name: 'ПРОГРЕСС ЦВЕТ', // кнопка
 id: 0,
 len: color_bg[0].length, // длина
 type: 'color', // цвет или данные
 colorArrayIndex: 0 // ← явно указываем индекс массива
},{ // 7. Одноцветный прямоугольник
 name: 'AOD тип', // кнопка
 id: 0,
 len: 3, // длина
 type: 'png_crown_off', // Новый тип - коронка отключается после выхода
}, { // 8. Кнопка конфигурации
  name: 'конфигурация',
  id: 0,
  len: 3, // 3 позиции: 0,1,2
  type: 'save_conf',
 },*/{ // 8. Одноцветный прямоугольник
 name: ['КОРОНКА ОТКЛЮЧЕНА', 'КОРОНКА ВКЛЮЧЕНА'],
 id: 0,
 len: 2,
 type: 'toggle', // тип: переключатель ВКЛ/ВЫКЛ
 //toggleBgColors: [0x800000, 0x008000], // Темно-красный для ОТКЛЮЧЕНА, Зеленый для ВКЛЮЧЕНА
}]

function loadSettings() {
    color_ic = hmFS.SysProGetInt(`${WF_ID}_color_ic`) === undefined ? (hmFS.SysProSetInt(`${WF_ID}_color_ic`, 0), 0) : hmFS.SysProGetInt(`${WF_ID}_color_ic`);
    tip_grafik = hmFS.SysProGetInt(`${WF_ID}_tip_grafik`) === undefined ? (hmFS.SysProSetInt(`${WF_ID}_tip_grafik`, 0), 0) : hmFS.SysProGetInt(`${WF_ID}_tip_grafik`);
    right = hmFS.SysProGetInt(`${WF_ID}_right`) === undefined ? (hmFS.SysProSetInt(`${WF_ID}_right`, 0), 0) : hmFS.SysProGetInt(`${WF_ID}_right`);	
    left = hmFS.SysProGetInt(`${WF_ID}_left`) === undefined ? (hmFS.SysProSetInt(`${WF_ID}_left`, 0), 0) : hmFS.SysProGetInt(`${WF_ID}_left`);	
	block = hmFS.SysProGetInt(`${WF_ID}_block`) === undefined ? (hmFS.SysProSetInt(`${WF_ID}_block`, 0), 0) : hmFS.SysProGetInt(`${WF_ID}_block`);

    if (hmFS.SysProGetInt(`${WF_ID}_crown`) === undefined) {
        crown = 0;
        hmFS.SysProSetInt(`${WF_ID}_crown`, crown);
    } else {
        crown = hmFS.SysProGetInt(`${WF_ID}_crown`);
    }

    fix_gsm = hmFS.SysProGetInt(`${WF_ID}_fix_gsm`) === undefined ? (hmFS.SysProSetInt(`${WF_ID}_fix_gsm`, 0), 0) : hmFS.SysProGetInt(`${WF_ID}_fix_gsm`);
	
    // ЗАГРУЖАЕМ ВСЕ КНОПКИ (включая 7-ю) - УБЕРИТЕ -1
    for (let i = 0; i < CONF_MAIN.length; i++) {
        const defaultValue = CONF_MAIN[i].id;
        CONF_MAIN[i].id = hmFS.SysProGetInt(`${WF_ID}_color_` + i) === undefined
            ? (hmFS.SysProSetInt(`${WF_ID}_color_` + i, defaultValue), defaultValue)
            : hmFS.SysProGetInt(`${WF_ID}_color_` + i);
    }
	
}

function update_app() {
// distStr = parseInt(step.current * 100 / step.target)
// normal_widget_text_1.setProperty(hmUI.prop.TEXT, String(distStr));
  let distanceCurrent = distance.current;
normal_widget_text_9.setProperty( hmUI.prop.TEXT,(distanceCurrent < 0 ? 0 : distanceCurrent / 1000).toFixed(2).toString());
normal_widget_text_10.setProperty( hmUI.prop.TEXT,(distanceCurrent < 0 ? 0 : distanceCurrent / 1000).toFixed(2).toString());
}


            function time_update2(updateHour = false, updateMinute = false) {

             // let hour = timeSensor.hour;
             let minute = timeSensor.minute;
             //              let second = timeSensor.second;
             //              let format_hour = timeSensor.format_hour;

             /*              console.log('hour font');
                           if (updateHour) {
                             let normal_hourStr = format_hour.toString();
                             normal_time_hour_text_font.setProperty(hmUI.prop.TEXT, normal_hourStr );
                           };*/
             normal_heart_rate_icon_img.setProperty(hmUI.prop.VISIBLE, hmBle.connectStatus());
             if (updateMinute) {
              normal_M_icon_img.setProperty(hmUI.prop.SRC, 'M_' + minute % 60 + '.png')
              idle_M_icon_img.setProperty(hmUI.prop.SRC, 'M_' + minute % 60 + '.png')
             };
            };



let right = 0;
function click_right() {
right = (right + 1)%3
 hmFS.SysProSetInt(`${WF_ID}_right`, right);

normal_temperature_low_text_font.setProperty(hmUI.prop.VISIBLE, right == 0 && left == 0);
normal_temperature_high_text_font.setProperty(hmUI.prop.VISIBLE, right == 0 && left == 0);
normal_temperature_icon_img.setProperty(hmUI.prop.VISIBLE, right == 0 && left == 0);
normal_weather_circle_scale.setProperty(hmUI.prop.VISIBLE, right == 0 && left == 0);	
normal_calorie_icon_img.setProperty(hmUI.prop.VISIBLE, right == 1 && left == 0);	
normal_calorie_circle_scale.setProperty(hmUI.prop.VISIBLE, right == 1 && left == 0);
normal_calorie_current_text_font.setProperty(hmUI.prop.VISIBLE, right == 1 && left == 0);
normal_sun_low_text_font.setProperty(hmUI.prop.VISIBLE, right == 2 && left == 0);
normal_sun_high_text_font.setProperty(hmUI.prop.VISIBLE, right == 2 && left == 0);
normal_sun_icon_img.setProperty(hmUI.prop.VISIBLE, right == 2 && left == 0);
normal_sun_circle_scale.setProperty(hmUI.prop.VISIBLE, right == 2 && left == 0);	
	
autoToggleWeatherIcons();
	
 vibro();
}

let left = 0;
function click_left() {
left = (left + 1)%2
hmFS.SysProSetInt(`${WF_ID}_left`, left);

normal_temperature_low_text_font.setProperty(hmUI.prop.VISIBLE, right == 0 && left == 0);
normal_temperature_high_text_font.setProperty(hmUI.prop.VISIBLE, right == 0 && left == 0);
normal_temperature_icon_img.setProperty(hmUI.prop.VISIBLE, right == 0 && left == 0);
normal_weather_circle_scale.setProperty(hmUI.prop.VISIBLE, right == 0 && left == 0);
normal_calorie_icon_img.setProperty(hmUI.prop.VISIBLE, right == 1 && left == 0);
normal_calorie_circle_scale.setProperty(hmUI.prop.VISIBLE, right == 1 && left == 0);
normal_calorie_current_text_font.setProperty(hmUI.prop.VISIBLE, right == 1 && left == 0);
normal_sun_low_text_font.setProperty(hmUI.prop.VISIBLE, right == 2 && left == 0);
normal_sun_high_text_font.setProperty(hmUI.prop.VISIBLE, right == 2 && left == 0);
normal_sun_icon_img.setProperty(hmUI.prop.VISIBLE, right == 2 && left == 0);
normal_sun_circle_scale.setProperty(hmUI.prop.VISIBLE, right == 2 && left == 0);
	

normal_heart_rate_text_font_bg.setProperty(hmUI.prop.VISIBLE,  left == 0);
normal_widget_text_1.setProperty(hmUI.prop.VISIBLE,  left == 0);
normal_widget_text_6.setProperty(hmUI.prop.VISIBLE,  left == 0);
normal_widget_text_7.setProperty(hmUI.prop.VISIBLE,  left == 0);
normal_widget_text_8.setProperty(hmUI.prop.VISIBLE,  left == 0);
normal_widget_text_9.setProperty(hmUI.prop.VISIBLE,  left == 0);
normal_widget_text_10.setProperty(hmUI.prop.VISIBLE,  left == 0);
normal_month_name_font.setProperty(hmUI.prop.VISIBLE,  left == 0);
normal_dow_text_font.setProperty(hmUI.prop.VISIBLE,  left == 0);
normal_day_text_font.setProperty(hmUI.prop.VISIBLE,  left == 0);
normal_pai_icon_img.setProperty(hmUI.prop.VISIBLE,  left == 0);
//normal_heart_rate_icon_img.setProperty(hmUI.prop.VISIBLE,  left == 0);
normal_heart_rate_circle_scale_2.setProperty(hmUI.prop.VISIBLE,  left == 0);
normal_heart_rate_text_font.setProperty(hmUI.prop.VISIBLE,  left == 0);
normal_step_circle_scale.setProperty(hmUI.prop.VISIBLE,  left == 0);
normal_step_current_text_font.setProperty(hmUI.prop.VISIBLE,  left == 0);
normal_battery_circle_scale.setProperty(hmUI.prop.VISIBLE,  left == 0);
normal_battery_current_text_font.setProperty(hmUI.prop.VISIBLE,  left == 0);
normal_alarm_clock_current_text_font.setProperty(hmUI.prop.VISIBLE,  left == 0);
normal_system_clock_img.setProperty(hmUI.prop.VISIBLE,  left == 0);
	
normal_widget_text_2.setProperty(hmUI.prop.X,  left == 0 ? 306* kf:202* kf);
normal_widget_text_2.setProperty(hmUI.prop.Y,  left == 0 ? 376* kf:394* kf);
	
//Button_3.setProperty(hmUI.prop.X,  left == 0 ? 278* kf:183* kf);
//Button_3.setProperty(hmUI.prop.Y,  left == 0 ? 347* kf:366* kf);
	
	            Button_3.setProperty(hmUI.prop.MORE, {
	             x: left == 0 ? 278 * kf : 183 * kf,
	             y: left == 0 ? 347 * kf : 366 * kf,
	             w: 100,
	             h: 100,
	             text: '',
	             color: 0xFFFF8C00,
	             text_size: 25,
	             press_src: '0.png',
	             normal_src: '0.png',
	             click_func: (button_widget) => {
	              clik_block();
	              vibro();
	             }, // end func
	             show_level: hmUI.show_level.ONLY_NORMAL,
	            }); // end button	
	
	
	
//btn_block.setProperty(hmUI.prop.X,  left == 0 ? 278* kf:183* kf);
//btn_block.setProperty(hmUI.prop.Y,  left == 0 ? 347* kf:366* kf);
	
    btn_block.setProperty(hmUI.prop.MORE, {
     x: left == 0 ? 278 * kf : 183 * kf,
     y: left == 0 ? 347 * kf : 366 * kf,
     text: '',
     w: 100 * kf,
     h: 100 * kf,
     normal_src: '0_Empty.png',
     press_src: '0_Empty.png',
     click_func: (button_widget) => {
      //vibro();
      hmUI.showToast({
       text: "Для разблокировки нужно долгое нажатие",
      });
     },
     longpress_func: () => {
      // vibro();
      //MenuCirkl_Timer_on(3) 
      vibro();
      clik_block();
     },
     show_level: hmUI.show_level.ONLY_NORMAL,
    });
	
	
	
	
 vibro();
}



      const hour_pointer = [
       [70, 211], // 0
       [60, 148], // 1
       [40, 129], // 2
       [63, 129], // 3
      ];

      const minute_pointer = [
       [61, 207], // 0
       [59, 205], // 1
       [36, 192], // 2
       [61, 207], // 3
      ];

function start_WG() {

 // Для коронки 0 (основной фон)
 const colorInfo0 = getColorInfo(0);
	
normal_temperature_low_text_font.setProperty(hmUI.prop.VISIBLE, right == 0 && left == 0);
normal_temperature_high_text_font.setProperty(hmUI.prop.VISIBLE, right == 0 && left == 0);
normal_temperature_icon_img.setProperty(hmUI.prop.VISIBLE, right == 0 && left == 0);
normal_weather_circle_scale.setProperty(hmUI.prop.VISIBLE, right == 0 && left == 0);
normal_calorie_icon_img.setProperty(hmUI.prop.VISIBLE, right == 1 && left == 0);
normal_calorie_circle_scale.setProperty(hmUI.prop.VISIBLE, right == 1 && left == 0);
normal_calorie_current_text_font.setProperty(hmUI.prop.VISIBLE, right == 1 && left == 0);
normal_sun_low_text_font.setProperty(hmUI.prop.VISIBLE, right == 2 && left == 0);
normal_sun_high_text_font.setProperty(hmUI.prop.VISIBLE, right == 2 && left == 0);
normal_sun_icon_img.setProperty(hmUI.prop.VISIBLE, right == 2 && left == 0);
normal_sun_circle_scale.setProperty(hmUI.prop.VISIBLE, right == 2 && left == 0);
	
normal_heart_rate_text_font_bg.setProperty(hmUI.prop.VISIBLE,  left == 0);
normal_widget_text_1.setProperty(hmUI.prop.VISIBLE,  left == 0);
normal_widget_text_6.setProperty(hmUI.prop.VISIBLE,  left == 0);
normal_widget_text_7.setProperty(hmUI.prop.VISIBLE,  left == 0);
normal_widget_text_8.setProperty(hmUI.prop.VISIBLE,  left == 0);
normal_widget_text_9.setProperty(hmUI.prop.VISIBLE,  left == 0);
normal_widget_text_10.setProperty(hmUI.prop.VISIBLE,  left == 0);
normal_month_name_font.setProperty(hmUI.prop.VISIBLE,  left == 0);
normal_dow_text_font.setProperty(hmUI.prop.VISIBLE,  left == 0);
normal_day_text_font.setProperty(hmUI.prop.VISIBLE,  left == 0);
normal_pai_icon_img.setProperty(hmUI.prop.VISIBLE,  left == 0);
//normal_heart_rate_icon_img.setProperty(hmUI.prop.VISIBLE,  left == 0);
normal_heart_rate_circle_scale_2.setProperty(hmUI.prop.VISIBLE,  left == 0);
normal_heart_rate_text_font.setProperty(hmUI.prop.VISIBLE,  left == 0);
normal_step_circle_scale.setProperty(hmUI.prop.VISIBLE,  left == 0);
normal_step_current_text_font.setProperty(hmUI.prop.VISIBLE,  left == 0);
normal_battery_circle_scale.setProperty(hmUI.prop.VISIBLE,  left == 0);
normal_battery_current_text_font.setProperty(hmUI.prop.VISIBLE,  left == 0);
normal_alarm_clock_current_text_font.setProperty(hmUI.prop.VISIBLE,  left == 0);
normal_system_clock_img.setProperty(hmUI.prop.VISIBLE,  left == 0);	
	
normal_widget_text_2.setProperty(hmUI.prop.X,  left == 0 ? 306* kf:202* kf);
normal_widget_text_2.setProperty(hmUI.prop.Y,  left == 0 ? 376* kf:394* kf);
	
//Button_3.setProperty(hmUI.prop.X,  left == 0 ? 278* kf:183* kf);
//Button_3.setProperty(hmUI.prop.Y,  left == 0 ? 347* kf:366* kf);
	
	            Button_3.setProperty(hmUI.prop.MORE, {
	             x: left == 0 ? 278 * kf : 183 * kf,
	             y: left == 0 ? 347 * kf : 366 * kf,
	             w: 100,
	             h: 100,
	             text: '',
	             color: 0xFFFF8C00,
	             text_size: 25,
	             press_src: '0.png',
	             normal_src: '0.png',
	             click_func: (button_widget) => {
	              clik_block();
	              vibro();
	             }, // end func
	             show_level: hmUI.show_level.ONLY_NORMAL,
	            }); // end button
	
	
	
//btn_block.setProperty(hmUI.prop.X,  left == 0 ? 278* kf:183* kf);
//btn_block.setProperty(hmUI.prop.Y,  left == 0 ? 347* kf:366* kf);
	
    btn_block.setProperty(hmUI.prop.MORE, {
     x: left == 0 ? 278 * kf : 183 * kf,
     y: left == 0 ? 347 * kf : 366 * kf,
     text: '',
     w: 100 * kf,
     h: 100 * kf,
     normal_src: '0_Empty.png',
     press_src: '0_Empty.png',
     click_func: (button_widget) => {
      //vibro();
      hmUI.showToast({
       text: "Для разблокировки нужно долгое нажатие",
      });
     },
     longpress_func: () => {
      // vibro();
      //MenuCirkl_Timer_on(3) 
      vibro();
      clik_block();
     },
     show_level: hmUI.show_level.ONLY_NORMAL,
    });	
	


 };

let normal_block_FILL_RECT = ""
let btn_block = ""
let block = 0

function clik_block() {
 block = (block + 1) % 2
 hmFS.SysProSetInt(`${WF_ID}_block`, block);
// normal_widget_text_4.setProperty(hmUI.prop.TEXT, block == 0 ? 'ОТКР' : 'БЛОК');
normal_widget_text_2.setProperty(hmUI.prop.TEXT, block == 0 ? '{' : '}');	
 normal_block_FILL_RECT.setProperty(hmUI.prop.VISIBLE, block == 1);
 btn_block.setProperty(hmUI.prop.VISIBLE, block == 1);
// vibro();
}



let ARC_set = [
 [383, 107, 18],
 [398, 129, 22],
 [412, 159, 26],
 [423, 192, 30],
 [427, 233, 34],
 [423, 274, 30],
 [412, 307, 26],
 [398, 337, 22],
 [383, 359, 18],
]

let menu_ARC_color = [];
let normal_left_data = [];
let normal_right_data = [];
let normal_up_data = [];

function app_update() {
 let distanceCurrent = distance.current;
}
		
		

// Состояния экрана
const SCREEN_STATE = {
    MAIN: 'MAIN',
    SETTINGS: 'SETTINGS', 
    CROWN_MODE: 'CROWN_MODE'
};
		
// Текущее состояние экрана
let currentScreenState = SCREEN_STATE.MAIN;		
		
// ====================== ПОИСК ЭЛЕМЕНТОВ ПО ТИПУ ======================

// Функция для поиска индекса элемента по типу
function findConfigIndex(type) {
    for (let i = 0; i < CONF_MAIN.length; i++) {
        if (CONF_MAIN[i].type === type) {
            return i;
        }
    }
    return -1;
}		
		
let crownSensitivity = 70; // уровень чувствительности колесика
let color = 0;
let color_str = 0;
let bridg = 127;
let crown = 0
let text_start = 70		
		
let set = 0;
let degreeSum = 0;
let MenuCirkl_Timer = null;

let debugCounter = 0;

function showDebug(message) {
    hmUI.showToast({text: message});
}

// ====================== ОБРАБОТКА ЦИФРОВОЙ КОРОНКИ ======================

function onDigitalCrown() {
    hmApp.registerSpinEvent((key, degree) => {
        if (key !== hmApp.key.HOME) return;
        degreeSum += degree;
        if (Math.abs(degreeSum) <= crownSensitivity) return;
        
        const step = Math.sign(degreeSum);
        
        // Находим toggle элемент
        const toggleIndex = findConfigIndex('toggle');
        
        // 1. В состоянии SETTINGS коронка НЕ РАБОТАЕТ
        if (currentScreenState === SCREEN_STATE.SETTINGS) {
            degreeSum = 0;
            return;
        }
        

        
        // 3. На главном экране
        if (currentScreenState === SCREEN_STATE.MAIN) {
            // Проверяем, включена ли коронка на главном экране
            if (toggleIndex !== -1 && CONF_MAIN[toggleIndex].id === 0) {
                degreeSum = 0;
                return;
            }
            
            // Для png_crown_off НЕ обрабатываем на главном экране
            if (crown < CONF_MAIN.length && CONF_MAIN[crown].type === 'png_crown_off') {
                degreeSum = 0;
                return;
            }
            
            // Меняем параметры
            crown_color(crown, step, false);
            
            // ПОКАЗЫВАЕМ ПРОГРЕСС И ЗАПУСКАЕМ ТАЙМЕР
            g_ACR_panel.setProperty(hmUI.prop.VISIBLE, true);
            if (crown < CONF_MAIN.length && CONF_MAIN[crown].type === 'color') {
                g_ACR_color_PROGRES.setProperty(hmUI.prop.VISIBLE, true);
                updateCrownColorElements();
            }
            updateProgressArc();
            
            // ЗАПУСК ТАЙМЕРА
            if (MenuCirkl_Timer) timer.stopTimer(MenuCirkl_Timer);
            MenuCirkl_Timer = timer.createTimer(1000, 1, () => {
                g_ACR_color_PROGRES.setProperty(hmUI.prop.VISIBLE, false);
                g_ACR_panel.setProperty(hmUI.prop.VISIBLE, false);
                bg_app_text.setProperty(hmUI.prop.VISIBLE, false);
                Line_arr.forEach((_, i) => app_ACR_text[i].setProperty(hmUI.prop.VISIBLE, false));
                timer.stopTimer(MenuCirkl_Timer);
            });
            
            degreeSum = 0;
            return;
        }
        
        // 4. В режиме коронки
        if (currentScreenState === SCREEN_STATE.CROWN_MODE) {
            // Для toggle типа не обрабатываем
            if (crown < CONF_MAIN.length && CONF_MAIN[crown].type === 'toggle') {
                degreeSum = 0;
                return;
            }
            
            // Меняем параметры
            crown_color(crown, step, false);
            
            // Обновляем панель коронки
            g_ACR_panel.setProperty(hmUI.prop.VISIBLE, true);
            
            // Для цветовых элементов показываем цветовой прогресс
            if (crown < CONF_MAIN.length && CONF_MAIN[crown].type === 'color') {
                g_ACR_color_PROGRES.setProperty(hmUI.prop.VISIBLE, true);
                updateCrownColorElements();
            } else {
                g_ACR_color_PROGRES.setProperty(hmUI.prop.VISIBLE, false);
            }
            
            // Обновляем дугу прогресса
            updateProgressArc();
            
            degreeSum = 0;
            return;
        }
        
        degreeSum = 0;
    });
}


// ====================== УПРАВЛЕНИЕ СОСТОЯНИЯМИ ======================
function changeState(newState) {
    const oldState = currentScreenState;
    currentScreenState = newState;
    
    // Всегда скрываем элементы при смене состояния
    g_ACR_panel.setProperty(hmUI.prop.VISIBLE, false);
    g_ACR_color_PROGRES.setProperty(hmUI.prop.VISIBLE, false);
    bg_app_text.setProperty(hmUI.prop.VISIBLE, false);
    Line_arr.forEach((_, i) => app_ACR_text[i].setProperty(hmUI.prop.VISIBLE, false));
    
    
    switch (newState) {
        case SCREEN_STATE.MAIN:
            groupVremya.setProperty(hmUI.prop.VISIBLE, true);
            g_Set.setProperty(hmUI.prop.VISIBLE, false);
            g_btn_crown.setProperty(hmUI.prop.VISIBLE, false);
            
            // Восстанавливаем состояние через start_WG() для основного режима
            start_WG();
            
            break;
            
        case SCREEN_STATE.SETTINGS:
            groupVremya.setProperty(hmUI.prop.VISIBLE, true);
            g_Set.setProperty(hmUI.prop.VISIBLE, true);
            g_btn_crown.setProperty(hmUI.prop.VISIBLE, false);
            updateButtons();
            
            // Восстанавливаем состояние через start_WG()
            start_WG();
            
            MenuCirkl_Timer_on();
            break;
            
        case SCREEN_STATE.CROWN_MODE:
            groupVremya.setProperty(hmUI.prop.VISIBLE, true);
            g_Set.setProperty(hmUI.prop.VISIBLE, false);
            g_btn_crown.setProperty(hmUI.prop.VISIBLE, true);
            
            // Восстанавливаем состояние через start_WG()
            start_WG();
            
            // Показываем панель коронки
            g_ACR_panel.setProperty(hmUI.prop.VISIBLE, true);
            
            // Обновляем элементы в зависимости от типа
            if (crown < CONF_MAIN.length) {
                if (CONF_MAIN[crown].type === 'color') {
                    g_ACR_color_PROGRES.setProperty(hmUI.prop.VISIBLE, true);
                    updateCrownColorElements();
                } else if (CONF_MAIN[crown].type === 'text') {
                    g_ACR_color_PROGRES.setProperty(hmUI.prop.VISIBLE, false);
                    updateText();
                } else if (CONF_MAIN[crown].type === 'png' || CONF_MAIN[crown].type === 'png_crown_off') {
                    g_ACR_color_PROGRES.setProperty(hmUI.prop.VISIBLE, false);
                }
            }
            
            break;
    }
}		




// ====================== КНОПКИ ЛЕВО/ПРАВО ======================


function click_btn_crown_left() {
    if (menu === 1 && Activ_color === 1) {
        handleColorChange(-1);
        return;
    }
	
	
    if (currentScreenState !== SCREEN_STATE.CROWN_MODE) return;
    
    if (CONF_MAIN[crown].type !== 'toggle') {
        crown_color(crown, -1, false);
        
        g_ACR_panel.setProperty(hmUI.prop.VISIBLE, true);
        if (CONF_MAIN[crown].type === 'color') {
            g_ACR_color_PROGRES.setProperty(hmUI.prop.VISIBLE, true);
            updateCrownColorElements();
        } else {
            g_ACR_color_PROGRES.setProperty(hmUI.prop.VISIBLE, false);
        }
        updateProgressArc();
    }
}

function click_btn_crown_right() {
    if (menu === 1 && Activ_color === 1) {
        handleColorChange(1);
        return;
    }

	
	
    if (currentScreenState !== SCREEN_STATE.CROWN_MODE) return;
    
    if (CONF_MAIN[crown].type !== 'toggle') {
        crown_color(crown, 1, false);
        
        g_ACR_panel.setProperty(hmUI.prop.VISIBLE, true);
        if (CONF_MAIN[crown].type === 'color') {
            g_ACR_color_PROGRES.setProperty(hmUI.prop.VISIBLE, true);
            updateCrownColorElements();
        } else {
            g_ACR_color_PROGRES.setProperty(hmUI.prop.VISIBLE, false);
        }
        updateProgressArc();
    }
}





// ====================== НАСТРОЙКИ ======================
/*function click_Set_on() {
    changeState(SCREEN_STATE.SETTINGS);
}*/


function click_Set_on() {
    changeState(SCREEN_STATE.SETTINGS);
}


function click_crown(index) {
    const toggleIndex = CONF_MAIN.length - 1;
    const isToggle = index === toggleIndex;
    
    // Если коронка отключена и это не toggle-кнопка - блокируем нажатие
    if (CONF_MAIN[toggleIndex].id === 0 && !isToggle) {
        return;
    }
    
    // Обработка toggle-кнопки
    if (isToggle && CONF_MAIN[index].type === 'toggle') {
        CONF_MAIN[index].id = (CONF_MAIN[index].id + 1) % 2;
        hmFS.SysProSetInt(`${WF_ID}_color_` + index, CONF_MAIN[index].id);
        
        crown = index;
        updateButtons();
        vibro();
        return;
    }
    
    // Вся остальная логика без изменений
    if (currentScreenState === SCREEN_STATE.CROWN_MODE && CONF_MAIN[index].type === 'save_conf') {
        return;
    }
    
    if (currentScreenState === SCREEN_STATE.SETTINGS && CONF_MAIN[index].type === 'save_conf') {
        CONF_MAIN[index].id = (CONF_MAIN[index].id + 1) % CONF_MAIN[index].len;
        hmFS.SysProSetInt(`${WF_ID}_color_` + index, CONF_MAIN[index].id);
        
        crown = index;
        updateButtons();
        g_ACR_panel.setProperty(hmUI.prop.VISIBLE, true);
        updateProgressArc();
        vibro();
        return;
    }
    
    if (currentScreenState === SCREEN_STATE.SETTINGS) {
        crown = index;
        updateButtons();
        g_ACR_panel.setProperty(hmUI.prop.VISIBLE, true);
        updateProgressArc();
        updateCrownColorElements();
        updateText();
        vibro();
    }
}



function click_Set_off() {
    const toggleIndex = CONF_MAIN.length - 1;
    
    // ЕСЛИ ВЫБРАНА TOGGLE-КНОПКА
    if (crown === toggleIndex) {
        hmFS.SysProSetInt(`${WF_ID}_crown`, crown); // ← Сохраняем
        changeState(SCREEN_STATE.MAIN);
    } else {
        // Для всех остальных кнопок - старая логика
        if (CONF_MAIN[toggleIndex].id === 0) {
            hmFS.SysProSetInt(`${WF_ID}_crown`, crown); // ← Сохраняем
            changeState(SCREEN_STATE.MAIN);
        } else {
            hmFS.SysProSetInt(`${WF_ID}_crown`, crown); // ← Сохраняем
            changeState(SCREEN_STATE.CROWN_MODE);
        }
    }
}

// Функция для выхода из CROWN_MODE должна быть отдельной
function click_btn_crown_exit() {
    if (menu === 1 && Activ_color === 1) {
        // Выходим из режима выбора цвета
        Activ_color = 0;
        ic_activ_color_off_img.setProperty(hmUI.prop.VISIBLE, true);
        hmFS.SysProSetInt('PT31', 0);
        g_ACR_color_PROGRES.setProperty(hmUI.prop.VISIBLE, false);
        g_ACR_panel.setProperty(hmUI.prop.VISIBLE, false);
        g_btn_crown.setProperty(hmUI.prop.VISIBLE, false);
//        btn_Activ_color.setProperty(hmUI.prop.VISIBLE, true);
//        btn_Activ_off.setProperty(hmUI.prop.VISIBLE, true);
        return;
    }
    changeState(SCREEN_STATE.MAIN);
}

function updateCrownColorElements() {
    // Показываем прогресс только для COLOR типа
    g_ACR_color_PROGRES.setProperty(hmUI.prop.VISIBLE, CONF_MAIN[crown].type === 'color');
    
    if (CONF_MAIN[crown].type === 'color') {
        updateProgressArc(); // ✓ Без параметров - использует значения по умолчанию из CONF_MAIN[crown]
        
        // Обновляем цветные элементы
        const colorInfo = getColorInfo();
        updateArcElements(CONF_MAIN[crown].id, colorInfo.colorArray);
    }
}


function updateColorUI(index, colorArray) {


 // Обновление цветовых арок
 for (let i = 0; i < ARC_set.length; i++) {
  const colorIndex = index - 4 + i;
  const colorValue = colorArray[colorIndex];
  const hasColor = colorValue !== undefined && colorValue !== null;

  menu_ARC_color[i].setProperty(hmUI.prop.MORE, {
   center_x: ARC_set[i][0],
   center_y: ARC_set[i][1],
   radius: ARC_set[i][2] / 2,
   color: hasColor ? colorValue : 0,
   alpha: hasColor ? 255 : 0,
   show_level: hmUI.show_level.ONLY_NORMAL,
  });
 }
}

// ====================== УНИВЕРСАЛЬНЫЕ ФУНКЦИИ ======================
function updateColorElements(targetIndex, colorArray, isMainColor = false) {


 // Обновление цветовых арок
 for (let i = 0; i < ARC_set.length; i++) {
  const colorIndex = targetIndex - 4 + i;
  const colorValue = colorArray[colorIndex];
  const hasColor = colorValue !== undefined && colorValue !== null;

  menu_ARC_color[i].setProperty(hmUI.prop.MORE, {
   center_x: ARC_set[i][0],
   center_y: ARC_set[i][1],
   radius: ARC_set[i][2] / 2,
   color: hasColor ? colorValue : 0,
   alpha: hasColor ? 255 : 0,
   show_level: hmUI.show_level.ONLY_NORMAL,
  });
 }

 // Для основного цвета обновляем прогресс
 if (isMainColor) {
  updateProgressArc(colorArray.length, targetIndex);
 }
}

function updateArcElements(startIndex, colorArray) {
    for (let i = 0; i < ARC_set.length; i++) {
        const colorIndex = startIndex - 4 + i;
        const colorValue = colorArray[colorIndex];
        const hasColor = colorValue !== undefined && colorValue !== null;

        menu_ARC_color[i].setProperty(hmUI.prop.MORE, {
            center_x: ARC_set[i][0],
            center_y: ARC_set[i][1],
            radius: ARC_set[i][2] / 2,
            color: hasColor ? colorValue : 0,
            alpha: hasColor ? 255 : 0,
            show_level: hmUI.show_level.ONLY_NORMAL,
        });
    }
}

// ====================== ОСНОВНЫЕ ФУНКЦИИ (БЕЗ ИЗМЕНЕНИЙ) ======================
function handleColorChange(step) {
    color_ic = Math.max(0, Math.min(color_bg[1].length - 1, color_ic + step));
    degreeSum = 0;
    hmFS.SysProSetInt(`${WF_ID}_color_ic`, color_ic);

    updateColorUI(color_ic, color_bg[1]);
    updateProgressArc(color_bg[1].length, color_ic); // ✓ Правильно: передаем длину массива цветов и индекс
    g_ACR_panel.setProperty(hmUI.prop.VISIBLE, true);
    g_ACR_color_PROGRES.setProperty(hmUI.prop.VISIBLE, true);
    vibro();
}

const KEY_SENSITIVITY = 3; // Чувствительность кнопок (2-быстро, 5-медленно)

function onKeyEvent() {
  let pressCounter = 0;

  hmApp.registerKeyEvent((key, action) => {
    if (action !== hmApp.action.CLICK) return;

    const direction = (key === hmApp.key.UP) ? 1 : -1;
    pressCounter++;

    if (pressCounter < KEY_SENSITIVITY) return;
    pressCounter = 0;



    // 2. В состоянии SETTINGS - НЕ обрабатываем (кнопки вверх/вниз не работают в настройках)
    if (currentScreenState === SCREEN_STATE.SETTINGS) {
      return;
    }

    // 3. На главном экране (MAIN)
    if (currentScreenState === SCREEN_STATE.MAIN) {
      // Для png_crown_off НЕ обрабатываем на главном экране
      const aodIndex = findConfigIndex('png_crown_off');
      if (aodIndex !== -1 && crown === aodIndex && CONF_MAIN[aodIndex].type === 'png_crown_off') {
        return;
      }

      // Меняем параметры
      crown_color(crown, direction, false);

      // ПОКАЗЫВАЕМ ПРОГРЕСС И ЗАПУСКАЕМ ТАЙМЕР
      g_ACR_panel.setProperty(hmUI.prop.VISIBLE, true);
      if (CONF_MAIN[crown].type === 'color') {
        g_ACR_color_PROGRES.setProperty(hmUI.prop.VISIBLE, true);
        updateCrownColorElements();
      }
      updateProgressArc();

      // ЗАПУСК ТАЙМЕРА
      if (MenuCirkl_Timer) timer.stopTimer(MenuCirkl_Timer);
      MenuCirkl_Timer = timer.createTimer(1000, 1, () => {
        g_ACR_color_PROGRES.setProperty(hmUI.prop.VISIBLE, false);
        g_ACR_panel.setProperty(hmUI.prop.VISIBLE, false);
        bg_app_text.setProperty(hmUI.prop.VISIBLE, false);
        Line_arr.forEach((_, i) => app_ACR_text[i].setProperty(hmUI.prop.VISIBLE, false));
        timer.stopTimer(MenuCirkl_Timer);
      });

      vibro();
      return;
    }

    // 4. В режиме коронки (CROWN_MODE)
    if (currentScreenState === SCREEN_STATE.CROWN_MODE) {
      // Для toggle типа не обрабатываем
      if (CONF_MAIN[crown].type === 'toggle') {
        return;
      }

      // Меняем параметры
      crown_color(crown, direction, false);

      // Обновляем панель коронки
      g_ACR_panel.setProperty(hmUI.prop.VISIBLE, true);

      // Для цветовых элементов показываем цветовой прогресс
      if (CONF_MAIN[crown].type === 'color') {
        g_ACR_color_PROGRES.setProperty(hmUI.prop.VISIBLE, true);
        updateCrownColorElements();
      } else {
        // Для всех остальных типов (включая png_crown_off) скрываем цветовой прогресс
        g_ACR_color_PROGRES.setProperty(hmUI.prop.VISIBLE, false);
      }

      // Обновляем дугу прогресса
      updateProgressArc();

      vibro();
      return;
    }
  });
}
		
		
// ====================== ФУНКЦИИ С МИНИМАЛЬНЫМИ ИЗМЕНЕНИЯМИ ======================
function MenuCirkl_Timer_off() {
 if (btn_on == 0) {
  if (MenuCirkl_Timer) timer.stopTimer(MenuCirkl_Timer);
  MenuCirkl_Timer = timer.createTimer(1000, 1, () => {
   g_ACR_color_PROGRES.setProperty(hmUI.prop.VISIBLE, false);
   g_ACR_panel.setProperty(hmUI.prop.VISIBLE, false);
   bg_app_text.setProperty(hmUI.prop.VISIBLE, false);
   Line_arr.forEach((_, i) => app_ACR_text[i].setProperty(hmUI.prop.VISIBLE, false));
   timer.stopTimer(MenuCirkl_Timer);
  });
 }
}

function MenuCirkl_Timer_on() {
 if (btn_on == 0) {
  if (MenuCirkl_Timer) timer.stopTimer(MenuCirkl_Timer);
  MenuCirkl_Timer = timer.createTimer(1000, 1, () => {
   g_Set.setProperty(hmUI.prop.VISIBLE, true);
   timer.stopTimer(MenuCirkl_Timer);
  });
 }
}


// ====================== ФУНКЦИИ БЕЗ ИЗМЕНЕНИЙ ======================
function handleCrownNavigation() {
 crown_color(crown, 0, true);
}
		
function processCrownAction(step) {


    if (Activ_color === 0 && menu === 0) {
        // Используем currentScreenState напрямую
        if (currentScreenState === SCREEN_STATE.SETTINGS) {
            // В настройках меняем выбранную кнопку
            handleCrownNavigation();
            
            // Показываем прогресс в настройках и запускаем таймер
            g_ACR_panel.setProperty(hmUI.prop.VISIBLE, true);
            updateProgressArc();
            MenuCirkl_Timer_off();
            
            return true;
        } else if (currentScreenState === SCREEN_STATE.CROWN_MODE) {
            // В режиме коронки меняем параметры
            crown_color(crown, step, false);
            return true;
        } else if (currentScreenState === SCREEN_STATE.MAIN) {
            // На главном экране, если коронка включена
            if (CONF_MAIN[CONF_MAIN.length - 1].id === 1) {
                // Проверяем тип элемента - для 'png_crown_off' не обрабатываем
                if (CONF_MAIN[crown].type === 'png_crown_off') {
                    return false;
                }
                
                crown_color(crown, step, false);
                return true;
            }
        }
    }

    return false;
}		


// Вспомогательная функция для обновления текстовых элементов
function updateText() {
    // Показываем/скрываем текстовые элементы в зависимости от типа
    const isTextType = CONF_MAIN[crown].type === 'text';
    bg_app_text.setProperty(hmUI.prop.VISIBLE, isTextType);
    
    Line_arr.forEach((_, i) => {
        app_ACR_text[i].setProperty(hmUI.prop.VISIBLE, isTextType);
        // Подсвечиваем выбранный элемент
        if (isTextType) {
            app_ACR_text[i].setProperty(hmUI.prop.COLOR, 
                CONF_MAIN[crown].id == i ? 0xff0000 : 0xffffff);
        }
    });
    
    // Для не-текстовых типов скрываем текстовые элементы
    if (!isTextType) {
        bg_app_text.setProperty(hmUI.prop.VISIBLE, false);
        Line_arr.forEach((_, i) => app_ACR_text[i].setProperty(hmUI.prop.VISIBLE, false));
    }
}		

function offKeyEvent() {
 try {
  hmApp.unregisterKeyEvent();
 } catch (e) {
  console.log("Unregister key event error:", e);
 }
}

function updateProgressArc(len = CONF_MAIN[crown].len, id = CONF_MAIN[crown].id) {
 menu_ARC_PROGRES.setProperty(hmUI.prop.MORE, {
  center_x: D_W / 2,
  center_y: D_W / 2,
  start_angle: 45 + 81 / len * id,
  end_angle: 45 + 9 + 81 / len * (id + 1),
  radius: 219 + 8,
  line_width: 8,
  corner_flag: 0,
  color: 0xFF0000,
  level: 100,
  show_level: hmUI.show_level.ONLY_NORMAL
 });
 menu_ARC_PROGRES.setProperty(hmUI.prop.VISIBLE, true);
}

function updateButtons() {
    const toggleIndex = CONF_MAIN.length - 1;
    const isCrownEnabled = CONF_MAIN[toggleIndex].id === 1;
    
    for (let i = 0; i < CONF_MAIN.length; i++) {
        const yPos = CONF_MAIN.length <= 5 
            ? 70 + i * Shag_Y 
            : i < Math.ceil(CONF_MAIN.length / 2) 
                ? 70 + i * Shag_Y 
                : 70 + i * Shag_Y - Shag_Y * Math.ceil(CONF_MAIN.length / 2);
        
        const xPos = CONF_MAIN.length <= 5 
            ? 153 
            : i < Math.ceil(CONF_MAIN.length / 2) 
                ? 70 
                : 233;
        
        // Определяем, активна ли кнопка
        const isToggleButton = (i === toggleIndex && CONF_MAIN[i].type === 'toggle');
        const isActive = isCrownEnabled || isToggleButton;
        
        let buttonText = '';
        if (CONF_MAIN[i].type === 'save_conf') {
            buttonText = 'конфигурация ' + (CONF_MAIN[i].id + 1);
        } else if (CONF_MAIN[i].type === 'toggle') {
            buttonText = Array.isArray(CONF_MAIN[i].name) 
                ? CONF_MAIN[i].name[CONF_MAIN[i].id] 
                : CONF_MAIN[i].name + ' ' + (CONF_MAIN[i].id + 1);
        } else {
            buttonText = CONF_MAIN[i].name + ' ' + (CONF_MAIN[i].id + 1);
        }
        
        // Определяем цвет кнопки
        let normalColor;
        if (CONF_MAIN[i].type === 'toggle') {
            normalColor = CONF_MAIN[i].id === 0 ? 0x800000 : 0x008000; // Темно-красный/Темно-зеленый
        } else {
            if (!isActive) {
                normalColor = 0x333333; // Серый для неактивных кнопок
            } else {
                normalColor = (i === crown) ? 0x800000 : 0x000000; // Красный/Черный
            }
        }
        
        // Текст кнопки
        let textColor = isActive ? 0xFFFFFFFF : 0x888888; // Белый для активных, серый для неактивных
        
        Btn_set_[i].setProperty(hmUI.prop.MORE, {
            x: xPos,
            y: yPos,
            w: 160,
            h: 60,
            text: buttonText,
            char_space: 0,
            line_space: -35,
            color: textColor,
            text_size: 24,
            radius: 12,
            press_color: isActive ? 0xFFFF0000 : 0x333333,
            normal_color: normalColor,
            text_style: hmUI.text_style.WRAP
        });
    }
}
		
// Функция для обработки текста приложения
function click_app_text_on_off() {
 // Позиционирование текста
 Line_arr.forEach((_, i) => {
  app_ACR_text[i].setProperty(hmUI.prop.X, i < Line_arr.length / 2 ? 68 : 233);
  app_ACR_text[i].setProperty(hmUI.prop.Y, i < Line_arr.length / 2 ? text_start + i * 21 : text_start + (i - Line_arr.length / 2) * 21);
 });

 // Отображение элементов
 bg_app_text.setProperty(hmUI.prop.VISIBLE, true);
 Line_arr.forEach((_, i) => app_ACR_text[i].setProperty(hmUI.prop.VISIBLE, true));
 g_ACR_panel.setProperty(hmUI.prop.VISIBLE, true);

 // Скрываем цветовые элементы
 g_ACR_color_PROGRES.setProperty(hmUI.prop.VISIBLE, false);

 // Установка цветов текста
 Line_arr.forEach((_, i) => {
  app_ACR_text[i].setProperty(hmUI.prop.COLOR,
   CONF_MAIN[crown].id == i ? 0xff0000 : 0xffffff);
 });
}



		
// Обновляем crown_color
function crown_color(crown_index, step, only_nav = false) {
    if (only_nav) {
        crown = crown_index;
        return;
    }
    
    const currentItem = CONF_MAIN[crown_index];
    const oldId = currentItem.id;
    let newId;
    
    if (currentItem.type === 'toggle' || currentItem.type === 'save_conf') {
        // Для save_conf циклическое переключение 0→1→2→0
        newId = (oldId + step + currentItem.len) % currentItem.len;
    } else {
        newId = oldId + step;
        
        // Одинаковая логика для всех типов
        if (newId < 0) {
            newId = 0;
        } else if (newId >= currentItem.len) {
            newId = currentItem.len - 1;
        }
    }
    
    if (oldId !== newId) {
        CONF_MAIN[crown_index].id = newId;
        hmFS.SysProSetInt(`${WF_ID}_color_` + crown_index, newId);
        switch_crown(crown_index);
        vibro();
    } else {
        // ВИБРАЦИЯ ПРИ ПОПЫТКЕ ВЫЙТИ ЗА ГРАНИЦЫ
        // Если значение не изменилось, но мы пытались изменить (шаг не 0)
        // и находимся на границе (0 или max)
        if (step !== 0) {
            const isMinBorder = (oldId === 0 && step < 0);
            const isMaxBorder = (oldId === currentItem.len - 1 && step > 0);
            
            if (isMinBorder || isMaxBorder) {
                vibro(); // Вибрация при попытке выйти за границы
            }
        }
    }
}

function getColorInfo(crownIndex = crown) {
    const colorArrayIndex = CONF_MAIN[crownIndex].colorArrayIndex || 0;
    const colorArray = color_bg[colorArrayIndex];
    const colorIndex = Math.min(CONF_MAIN[crownIndex].id, colorArray.length - 1);
    const colorValue = colorArray[colorIndex];
    
    return {
        colorArrayIndex,
        colorArray,
        colorIndex,
        colorValue
    };
}


function switch_crown_0() {
 const colorInfo = getColorInfo(); // Использует текущий crown по умолчанию
 normal_background.setProperty(hmUI.prop.COLOR, colorInfo.colorValue);
/*// normal_analog_clock_pro_second_cover_pointer_img.setProperty(hmUI.prop.SRC, 'cap_str_' + colorInfo.colorIndex + '.png');
   normal_widget_text_3.setProperty(hmUI.prop.COLOR, colorInfo.colorValue);
normal_widget_text_1.setProperty(hmUI.prop.COLOR, colorInfo.colorValue);
normal_widget_text_4.setProperty(hmUI.prop.COLOR, colorInfo.colorValue);
normal_widget_text_5.setProperty(hmUI.prop.COLOR, colorInfo.colorValue);
normal_widget_text_6.setProperty(hmUI.prop.COLOR, colorInfo.colorValue);
normal_widget_text_7.setProperty(hmUI.prop.COLOR, colorInfo.colorValue);
	
            normal_heart_rate_circle_scale_2.setProperty(hmUI.prop.MORE, {
              center_x: 233,
              center_y: 233,
              start_angle: 279,
              end_angle: 351,
              radius: 219,
              line_width: 10,
              corner_flag: 0,
              type: hmUI.data_type.HEART,
              color: colorInfo.colorValue,
              // mirror: False,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
	
            normal_step_circle_scale.setProperty(hmUI.prop.MORE, {
              center_x: 233,
              center_y: 233,
              start_angle: 171,
              end_angle: 99,
              radius: 219,
              line_width: 10,
              corner_flag: 0,
              color: colorInfo.colorValue,
              type: hmUI.data_type.STEP,
				show_level: hmUI.show_level.ONLY_NORMAL,
            });	
	
            normal_battery_circle_scale.setProperty(hmUI.prop.MORE, {
              center_x: 233,
              center_y: 233,
              start_angle: 261,
              end_angle: 189,
              radius: 219,
              line_width: 10,
              corner_flag: 0,
              color: colorInfo.colorValue,
              type: hmUI.data_type.BATTERY,
				show_level: hmUI.show_level.ONLY_NORMAL,
            });	
	
	
            normal_progress_bg_0.setProperty(hmUI.prop.MORE, {
              center_x: 233,
              center_y: 233,
              start_angle: 279,
              end_angle: 351,
              radius: 219,
              line_width: 10,
              corner_flag: 0,
              color: colorInfo.colorValue,
              level: 100,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_progress_bg_1.setProperty(hmUI.prop.MORE, {
              center_x: 233,
              center_y: 233,
              start_angle: 81,
              end_angle: 9,
              radius: 219,
              line_width: 10,
              corner_flag: 0,
              color: colorInfo.colorValue,
              level: 100,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_progress_bg_2.setProperty(hmUI.prop.MORE, {
              center_x: 233,
              center_y: 233,
              start_angle: 261,
              end_angle: 189,
              radius: 219,
              line_width: 10,
              corner_flag: 0,
              color: colorInfo.colorValue,
              level: 100,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_progress_bg_3.setProperty(hmUI.prop.MORE, {
              center_x: 233,
              center_y: 233,
              start_angle: 171,
              end_angle: 99,
              radius: 219,
              line_width: 10,
              corner_flag: 0,
              color: colorInfo.colorValue,
              level: 100,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });*/

 vibro();
}

function switch_crown_1() {
   const colorInfo = getColorInfo();
//    normal_stress_icon_img.setProperty(hmUI.prop.SRC, 'bezel_' + colorInfo.colorIndex + '.png');
  //  vibro();
}

function switch_crown_2() {
   const colorInfo = getColorInfo();
   /*  normal_vo2max_icon_img.setProperty(hmUI.prop.SRC, 'cap_circl_' + colorInfo.colorIndex + '.png');
*/   // vibro();
}

function switch_crown_3() {
 const colorInfo = getColorInfo();
 const colorInfo4 = getColorInfo(4);

/* normal_analog_clock_pro_hour_pointer_img.setProperty(hmUI.prop.MORE, {
  x: 0,
  y: 0,
  w: D_W,
  h: D_H,
  pos_x: 233 - hour_pointer[colorInfo.colorIndex][0],
  pos_y: 233 - hour_pointer[colorInfo.colorIndex][1],
  center_x: 233,
  center_y: 233,
  src: 'str_H_' + colorInfo4.colorIndex + '_' + colorInfo.colorIndex + '.png',
  // angle: 0,
  show_level: hmUI.show_level.ONLY_NORMAL,
 });

 normal_analog_clock_pro_minute_pointer_img.setProperty(hmUI.prop.MORE, {
  x: 0,
  y: 0,
  w: D_W,
  h: D_H,
  pos_x: 233 - minute_pointer[colorInfo.colorIndex][0],
  pos_y: 233 - minute_pointer[colorInfo.colorIndex][1],
  center_x: 233,
  center_y: 233,
  src: colorInfo.colorIndex == 0 ? 'str_M_' + colorInfo4.colorIndex + '_0.png' : colorInfo.colorIndex == 3 ? 'str_M_' + colorInfo4.colorIndex + '_0.png' : 'str_M_' + colorInfo4.colorIndex + '_' + colorInfo.colorIndex + '.png',
  //angle: 0,
  show_level: hmUI.show_level.ONLY_NORMAL,
 });

 //vibro();
}

function switch_crown_4() {
 const colorInfo = getColorInfo();
 const colorInfo3 = getColorInfo(3);
	
 normal_analog_clock_pro_hour_pointer_img.setProperty(hmUI.prop.SRC, 'str_H_' + colorInfo.colorIndex + '_' + colorInfo3.colorIndex + '.png');
	
 normal_analog_clock_pro_minute_pointer_img.setProperty(hmUI.prop.SRC, colorInfo3.colorIndex == 0 ? 'str_M_' + colorInfo.colorIndex + '_0.png' : colorInfo3.colorIndex == 3 ? 'str_M_' + colorInfo.colorIndex + '_0.png' : 'str_M_' + colorInfo.colorIndex + '_' + colorInfo3.colorIndex + '.png');	

 //vibro();
}

function switch_crown_5() {
 const colorInfo = getColorInfo();
	const colorInfo6 = getColorInfo(6);

 normal_battery_pointer_progress_img_pointer.setProperty(hmUI.prop.MORE, {
  src: 'str_bat_s_' + colorInfo6.colorIndex + '_' + colorInfo.colorIndex + '.png',
  center_x: 125,
  center_y: 233,
  x: colorInfo.colorIndex == 0 ? 9 : 10,
  y: colorInfo.colorIndex == 0 ? 31 : 22,
  start_angle: 0,
  end_angle: 360,
  invalid_visible: false,
  type: hmUI.data_type.BATTERY,
  show_level: hmUI.show_level.ONLY_NORMAL,
 });

 normal_heart_rate_pointer_progress_img_pointer.setProperty(hmUI.prop.MORE, {
  src: 'str_bat_' + colorInfo6.colorIndex + '_' + colorInfo.colorIndex + '.png',
  center_x: 233,
  center_y: 131,
  x: colorInfo.colorIndex == 0 ? 12 : 10,
  y: colorInfo.colorIndex == 0 ? 57 : 62,
  start_angle: 0,
  end_angle: 360,
  invalid_visible: false,
  type: hmUI.data_type.HEART,
  show_level: hmUI.show_level.ONLY_NORMAL,
 });

 normal_step_pointer_progress_img_pointer.setProperty(hmUI.prop.MORE, {
  src: 'str_bat_' + colorInfo6.colorIndex + '_' + colorInfo.colorIndex + '.png',
  center_x: 233,
  center_y: 336,
  x: colorInfo.colorIndex == 0 ? 12 : 10,
  y: colorInfo.colorIndex == 0 ? 57 : 62,
  start_angle: 0,
  end_angle: 360,
  invalid_visible: false,
  type: hmUI.data_type.STEP,
  show_level: hmUI.show_level.ONLY_NORMAL,
 });

 //vibro();
}

function switch_crown_6() {
 const colorInfo = getColorInfo();
 const colorInfo5 = getColorInfo(5);

 normal_battery_pointer_progress_img_pointer.setProperty(hmUI.prop.MORE, {
  src: 'str_bat_s_' + colorInfo.colorIndex + '_' + colorInfo5.colorIndex + '.png',
  center_x: 125,
  center_y: 233,
  x: colorInfo5.colorIndex == 0 ? 9 : 10,
  y: colorInfo5.colorIndex == 0 ? 31 : 22,
  start_angle: 0,
  end_angle: 360,
  invalid_visible: false,
  type: hmUI.data_type.BATTERY,
  show_level: hmUI.show_level.ONLY_NORMAL,
 });

 normal_heart_rate_pointer_progress_img_pointer.setProperty(hmUI.prop.MORE, {
  src: 'str_bat_' + colorInfo.colorIndex + '_' + colorInfo5.colorIndex + '.png',
  center_x: 233,
  center_y: 131,
  x: colorInfo5.colorIndex == 0 ? 12 : 10,
  y: colorInfo5.colorIndex == 0 ? 57 : 62,
  start_angle: 0,
  end_angle: 360,
  invalid_visible: false,
  type: hmUI.data_type.HEART,
  show_level: hmUI.show_level.ONLY_NORMAL,
 });

 normal_step_pointer_progress_img_pointer.setProperty(hmUI.prop.MORE, {
  src: 'str_bat_' + colorInfo.colorIndex + '_' + colorInfo5.colorIndex + '.png',
  center_x: 233,
  center_y: 336,
  x: colorInfo5.colorIndex == 0 ? 12 : 10,
  y: colorInfo5.colorIndex == 0 ? 57 : 62,
  start_angle: 0,
  end_angle: 360,
  invalid_visible: false,
  type: hmUI.data_type.STEP,
  show_level: hmUI.show_level.ONLY_NORMAL,
 });

 normal_wt_circle_scale_bg.setProperty(hmUI.prop.MORE, {
  center_x: 233,
  center_y: 130,
  start_angle: -150,
  end_angle: 150,
  radius: 62,
  line_width: 4,
  corner_flag: 0,
  color: colorInfo.colorValue,
  level: 100,
  show_level: hmUI.show_level.ONLY_NORMAL,
 });

 normal_dw_circle_scale_bg.setProperty(hmUI.prop.MORE, {
  center_x: 233,
  center_y: 336,
  start_angle: -150,
  end_angle: 150,
  radius: 62,
  line_width: 4,
  corner_flag: 0,
  color: colorInfo.colorValue,
  level: 100,
  show_level: hmUI.show_level.ONLY_NORMAL,
 });

 normal_wt_circle_scale.setProperty(hmUI.prop.MORE, {
  center_x: 233,
  center_y: 130,
  start_angle: -150,
  end_angle: 150,
  radius: 62,
  line_width: 4,
  corner_flag: 0,
  color: colorInfo.colorValue,
  type: hmUI.data_type.WEATHER_CURRENT,
  show_level: hmUI.show_level.ONLY_NORMAL,
 });

 normal_cal_circle_scale.setProperty(hmUI.prop.MORE, {
  center_x: 233,
  center_y: 130,
  start_angle: -150,
  end_angle: 150,
  radius: 62,
  line_width: 4,
  corner_flag: 0,
  color: colorInfo.colorValue,
  type: hmUI.data_type.CAL,
  show_level: hmUI.show_level.ONLY_NORMAL,
 });

 normal_step_circle_scale.setProperty(hmUI.prop.MORE, {
  center_x: 233,
  center_y: 336,
  start_angle: -150,
  end_angle: 150,
  radius: 62,
  line_width: 4,
  corner_flag: 0,
  color: colorInfo.colorValue,
  type: hmUI.data_type.STEP,
  show_level: hmUI.show_level.ONLY_NORMAL,
 });

 normal_sun_circle_scale.setProperty(hmUI.prop.MORE, {
  center_x: 233,
  center_y: 130,
  start_angle: -150,
  end_angle: 150,
  radius: 62,
  line_width: 4,
  corner_flag: 0,
  color: colorInfo.colorValue,
  //type: hmUI.data_type.WEATHER_CURRENT,
  show_level: hmUI.show_level.ONLY_NORMAL,
 });

 normal_unit_ic_up.setProperty(hmUI.prop.COLOR, colorInfo.colorValue);
 normal_unit_text_circ_up.setProperty(hmUI.prop.COLOR, colorInfo.colorValue);
 normal_unit_text_circ_dw.setProperty(hmUI.prop.COLOR, colorInfo.colorValue);
 normal_unit_ic_dw.setProperty(hmUI.prop.COLOR, colorInfo.colorValue);
 normal_weater_ic.setProperty(hmUI.prop.COLOR, colorInfo.colorValue);
 normal_timeDifference_gmt_text.setProperty(hmUI.prop.COLOR, colorInfo.colorValue);
 normal_cityName_gmt_text.setProperty(hmUI.prop.COLOR, colorInfo.colorValue);
*/
 //vibro();
}

function switch_crown_4() {
 const colorInfo = getColorInfo();
 const colorInfo3 = getColorInfo(3);
/*	
 normal_analog_clock_pro_hour_pointer_img.setProperty(hmUI.prop.SRC, 'str_H_' + colorInfo.colorIndex + '_' + colorInfo3.colorIndex + '.png');
	
 normal_analog_clock_pro_minute_pointer_img.setProperty(hmUI.prop.SRC, colorInfo3.colorIndex == 0 ? 'str_M_' + colorInfo.colorIndex + '_0.png' : colorInfo3.colorIndex == 3 ? 'str_M_' + colorInfo.colorIndex + '_0.png' : 'str_M_' + colorInfo.colorIndex + '_' + colorInfo3.colorIndex + '.png');	
*/
 //vibro();
}

function switch_crown_5() {
 const colorInfo = getColorInfo();
	const colorInfo6 = getColorInfo(6);

/* normal_battery_pointer_progress_img_pointer.setProperty(hmUI.prop.MORE, {
  src: 'str_bat_s_' + colorInfo6.colorIndex + '_' + colorInfo.colorIndex + '.png',
  center_x: 125,
  center_y: 233,
  x: colorInfo.colorIndex == 0 ? 9 : 10,
  y: colorInfo.colorIndex == 0 ? 31 : 22,
  start_angle: 0,
  end_angle: 360,
  invalid_visible: false,
  type: hmUI.data_type.BATTERY,
  show_level: hmUI.show_level.ONLY_NORMAL,
 });

 normal_heart_rate_pointer_progress_img_pointer.setProperty(hmUI.prop.MORE, {
  src: 'str_bat_' + colorInfo6.colorIndex + '_' + colorInfo.colorIndex + '.png',
  center_x: 233,
  center_y: 131,
  x: colorInfo.colorIndex == 0 ? 12 : 10,
  y: colorInfo.colorIndex == 0 ? 57 : 62,
  start_angle: 0,
  end_angle: 360,
  invalid_visible: false,
  type: hmUI.data_type.HEART,
  show_level: hmUI.show_level.ONLY_NORMAL,
 });

 normal_step_pointer_progress_img_pointer.setProperty(hmUI.prop.MORE, {
  src: 'str_bat_' + colorInfo6.colorIndex + '_' + colorInfo.colorIndex + '.png',
  center_x: 233,
  center_y: 336,
  x: colorInfo.colorIndex == 0 ? 12 : 10,
  y: colorInfo.colorIndex == 0 ? 57 : 62,
  start_angle: 0,
  end_angle: 360,
  invalid_visible: false,
  type: hmUI.data_type.STEP,
  show_level: hmUI.show_level.ONLY_NORMAL,
 });*/

 //vibro();
}

function switch_crown_6() {
 const colorInfo = getColorInfo();
 const colorInfo5 = getColorInfo(5);

/* normal_battery_pointer_progress_img_pointer.setProperty(hmUI.prop.MORE, {
  src: 'str_bat_s_' + colorInfo.colorIndex + '_' + colorInfo5.colorIndex + '.png',
  center_x: 125,
  center_y: 233,
  x: colorInfo5.colorIndex == 0 ? 9 : 10,
  y: colorInfo5.colorIndex == 0 ? 31 : 22,
  start_angle: 0,
  end_angle: 360,
  invalid_visible: false,
  type: hmUI.data_type.BATTERY,
  show_level: hmUI.show_level.ONLY_NORMAL,
 });

 normal_heart_rate_pointer_progress_img_pointer.setProperty(hmUI.prop.MORE, {
  src: 'str_bat_' + colorInfo.colorIndex + '_' + colorInfo5.colorIndex + '.png',
  center_x: 233,
  center_y: 131,
  x: colorInfo5.colorIndex == 0 ? 12 : 10,
  y: colorInfo5.colorIndex == 0 ? 57 : 62,
  start_angle: 0,
  end_angle: 360,
  invalid_visible: false,
  type: hmUI.data_type.HEART,
  show_level: hmUI.show_level.ONLY_NORMAL,
 });

 normal_step_pointer_progress_img_pointer.setProperty(hmUI.prop.MORE, {
  src: 'str_bat_' + colorInfo.colorIndex + '_' + colorInfo5.colorIndex + '.png',
  center_x: 233,
  center_y: 336,
  x: colorInfo5.colorIndex == 0 ? 12 : 10,
  y: colorInfo5.colorIndex == 0 ? 57 : 62,
  start_angle: 0,
  end_angle: 360,
  invalid_visible: false,
  type: hmUI.data_type.STEP,
  show_level: hmUI.show_level.ONLY_NORMAL,
 });

 normal_wt_circle_scale_bg.setProperty(hmUI.prop.MORE, {
  center_x: 233,
  center_y: 130,
  start_angle: -150,
  end_angle: 150,
  radius: 62,
  line_width: 4,
  corner_flag: 0,
  color: colorInfo.colorValue,
  level: 100,
  show_level: hmUI.show_level.ONLY_NORMAL,
 });

 normal_dw_circle_scale_bg.setProperty(hmUI.prop.MORE, {
  center_x: 233,
  center_y: 336,
  start_angle: -150,
  end_angle: 150,
  radius: 62,
  line_width: 4,
  corner_flag: 0,
  color: colorInfo.colorValue,
  level: 100,
  show_level: hmUI.show_level.ONLY_NORMAL,
 });

 normal_wt_circle_scale.setProperty(hmUI.prop.MORE, {
  center_x: 233,
  center_y: 130,
  start_angle: -150,
  end_angle: 150,
  radius: 62,
  line_width: 4,
  corner_flag: 0,
  color: colorInfo.colorValue,
  type: hmUI.data_type.WEATHER_CURRENT,
  show_level: hmUI.show_level.ONLY_NORMAL,
 });

 normal_cal_circle_scale.setProperty(hmUI.prop.MORE, {
  center_x: 233,
  center_y: 130,
  start_angle: -150,
  end_angle: 150,
  radius: 62,
  line_width: 4,
  corner_flag: 0,
  color: colorInfo.colorValue,
  type: hmUI.data_type.CAL,
  show_level: hmUI.show_level.ONLY_NORMAL,
 });

 normal_step_circle_scale.setProperty(hmUI.prop.MORE, {
  center_x: 233,
  center_y: 336,
  start_angle: -150,
  end_angle: 150,
  radius: 62,
  line_width: 4,
  corner_flag: 0,
  color: colorInfo.colorValue,
  type: hmUI.data_type.STEP,
  show_level: hmUI.show_level.ONLY_NORMAL,
 });

 normal_sun_circle_scale.setProperty(hmUI.prop.MORE, {
  center_x: 233,
  center_y: 130,
  start_angle: -150,
  end_angle: 150,
  radius: 62,
  line_width: 4,
  corner_flag: 0,
  color: colorInfo.colorValue,
  //type: hmUI.data_type.WEATHER_CURRENT,
  show_level: hmUI.show_level.ONLY_NORMAL,
 });

 normal_unit_ic_up.setProperty(hmUI.prop.COLOR, colorInfo.colorValue);
 normal_unit_text_circ_up.setProperty(hmUI.prop.COLOR, colorInfo.colorValue);
 normal_unit_text_circ_dw.setProperty(hmUI.prop.COLOR, colorInfo.colorValue);
 normal_unit_ic_dw.setProperty(hmUI.prop.COLOR, colorInfo.colorValue);
 normal_weater_ic.setProperty(hmUI.prop.COLOR, colorInfo.colorValue);
 normal_timeDifference_gmt_text.setProperty(hmUI.prop.COLOR, colorInfo.colorValue);
 normal_cityName_gmt_text.setProperty(hmUI.prop.COLOR, colorInfo.colorValue);*/

 //vibro();
}





function switch_crown_7() {

//CONF_MAIN[crown].name = CONF_MAIN[crown].id == 0 ? 'ккккк': 'ггггг'
//    vibro();
}

		
function switch_crown_8() {
// Обновляем текст кнопки при изменении состояния toggle
    updateButtons();	

   vibro();
}
		
function switch_crown_9() {
	
//CONF_MAIN[crown].name = CONF_MAIN[crown].id == 0 ? 'ккккк': 'ггггг'
//    vibro();
}


// Создаём массив, где каждый элемент — соответствующая функция
const crownFunctions = [
 switch_crown_0, // crown === 0
 switch_crown_1, // crown === 1
 switch_crown_2, // crown === 2
 switch_crown_3, // crown === 3
 switch_crown_4, // crown === 4
 switch_crown_5, // crown === 5
 switch_crown_6, // crown === 6
 switch_crown_7, // crown === 7
 switch_crown_8, // crown === 8
 switch_crown_9, // crown === 8
];

// Функция переключения коронок с проверкой на отключение
function switch_crown(crown) {
    if (crown >= 0 && crown < crownFunctions.length) {
        crownFunctions[crown]();
    }
}


const vibrate = hmSensor.createSensor(hmSensor.id.VIBRATE)
let stopVibro_Timer = null;

/*      function vibro(scene = 25) {
       let stopDelay = 50;
       vibrate.stop();
       vibrate.scene = scene;
       if (scene < 23 || scene > 25) stopDelay = 1220;
       vibrate.start();
       stopVibro_Timer = timer.createTimer(stopDelay, 0, stopVibro, {});
      }*/

function vibro(scene = 25) {
 //let stopDelay = 50;
 vibrate.stop();
 vibrate.scene = scene;
 vibrate.start();

 // stopVibro_Timer = timer.createTimer(stopDelay, 0, stopVibro, {});
}


function stopVibro() {
 vibrate.stop();
 timer.stopTimer(stopVibro_Timer);
}

function click_Pogoda_on() {
 normal_background_Pogoda.setProperty(hmUI.prop.VISIBLE, true);
 // updateGrafik()       
 menu = 2
 groupVremya.setProperty(hmUI.prop.VISIBLE, false);
 groupPogoda.setProperty(hmUI.prop.VISIBLE, true);


 updateGrafik()

}

function click_Pogoda_off() {
 normal_background_Pogoda.setProperty(hmUI.prop.VISIBLE, false);
 menu = 0
 groupVremya.setProperty(hmUI.prop.VISIBLE, true);
 groupPogoda.setProperty(hmUI.prop.VISIBLE, false);

}



let apps = [
 ['Нет действия', '-', `tap/i_tap_pusto.png`, 0, 'page/index'],
 ['Таймер', 'CountdownAppScreen', `tap/i_tap_obrat_otchet.png`, 0, 'page/index'],
 ['Секундомер', 'StopWatchScreen', `tap/i_tap_secundomer.png`, 0, 'page/index'],
 ['Мировые часы', 'WorldClockScreen', `tap/i_tap_mirivie_chasi.png`, 0, 'page/index'],
 ['Восход/закат', 'TideScreen', `tap/i_tap_voshod_zakat.png`, 0, 'page/index'],
 ['Сон', 'Sleep_HomeScreen', `tap/i_tap_son.png`, 0, 'page/index'],
 ['Стресс', 'StressHomeScreen', `tap/i_tap_stress.png`, 0, 'page/index'],
 ['SP02 (Кислород)', 'spo_HomeScreen', `tap/i_tap_kislorod.png`, 0, 'page/index'],
 ['Дыхание', 'RespirationsettingScreen', `tap/i_tap_dihanie.png`, 0, 'page/index'],
 ['Измерение одним касанием', 'oneKeyAppScreen', `tap/i_tap_1_kosanie.png`, 0, 'page/index'],
 ['Женский календарь', 'menstrualAppScreen', `tap/i_tap_gensk_calendar.png`, 0, 'page/index'],
 ['Найти телефон', 'FindPhoneScreen', `tap/i_tap_naiti_telo.png`, 0, 'page/index'],
 ['Музыка', 'LocalMusicScreen', `tap/i_tap_musik.png`, 0, 'page/index'], //'PhoneMusicCtrlScreen'
 ['Компас', 'CompassScreen', `tap/i_tap_kompas.png`, 0, 'page/index'],
 ['Набрать номер', 'DialCallScreen', `tap/i_tap_nabor.png`, 0, 'page/index'],
 ['Телефон', 'PhoneHomeScreen', `tap/i_tap_telefon.png`, 0, 'page/index'],
 ['Диктофон', 'VoiceMemoScreen', `tap/i_tap_dictofon.png`, 0, 'page/index'],
 ['Расписание', 'ScheduleListScreen', `tap/i_tap_raspisanie.png`, 0, 'page/index'],
 ['Список дел', 'todoListScreen', `tap/i_tap_spisok_del.png`, 0, 'page/index'],
 ['Календарь', 'ScheduleCalScreen', `tap/i_tap_calendar.png`, 0, 'page/index'],
 ['Погода', 'WeatherScreen', `tap/i_tap_pogoda.png`, 0, 'page/index'],
 ['Настройка', 'Settings_homeScreen', `tap/i_tap_sitting.png`, 0, 'page/index'],
 ['Камера', 'HidcameraScreen', `tap/i_tap_camera.png`, 0, 'page/index'],
 ['Пульс', 'heart_app_Screen', `tap/i_tap_puls.png`, 0, 'page/index'],
 ['Будильник', 'AlarmInfoScreen', `tap/i_tap_budilnik.png`, 0, 'page/index'],
 ['PAI', 'PAI_app_Screen', `tap/i_tap_pai.png`, 0, 'page/index'],
 ['Тренировка', 'SportListScreen', `tap/i_tap_trenerovka.png`, 0, 'page/index'],
 ['AOD', 'Settings_standbyModelScreen', `tap/i_tap_aod.png`, 0, 'page/index'],
 ['Экономия заряда', 'LowBatteryScreen', `tap/i_tap_LowBattery.png`, 0, 'page/index'],
 ['Давление/Высота', 'BaroAltimeterScreen', `tap/i_tap_barometr.png`, 0, 'page/index'],
 ['Погода LeXxiR', '1051195', `tap/i_tap_LeXxiR.png`, 1, 'page/index'],
 ['Календарь Sasha', '1057409', `tap/i_tap_calen_Sasha.png`, 1, 'page/index'],
 ['Flow', '1038314', `tap/i_tap_flow.png`, 1, 'page/gtr/home/index.page'],
 ['Ночной режим', 'Settings_nsModeHomeScreen', `tap/i_tap_night_Mode_Screen.png`, 0, 'page/index'],
 ['Говорящие часы', '1066653', `tap/i_tap_talking_watch.png`, 1, 'page/index.page'],
 ['Перезагрузка', 'HmReStartScreen', `tap/i_tap_restart.png`, 0, 'page/index'],
];


let btn_tap = ''
let btn_click_tap_exit = ''


function tap_zona_exit() {
 groupVremya.setProperty(hmUI.prop.VISIBLE, true);
 groupTap.setProperty(hmUI.prop.VISIBLE, false);

}


function tap_run() {
 groupVremya.setProperty(hmUI.prop.VISIBLE, false);
 groupTap.setProperty(hmUI.prop.VISIBLE, true);
}


//-------------------------------- 
//переменные для ргафика
let weather_ic_array = []
let weather_ic = []
let DigDay = []
let DigNight = []
let yArrH = [];
let arr_xH = [];
let arr_yH = [];
let arr_x = [];
let arr_y = [];
let arr_xL = [];
let arr_yL = [];
let yArrAll = [];
let yArrL = [];
let y_pogodaH = [];
let y_pogodaL = [];
let week_array = ["ПН", "ВТ", "СР", "ЧТ", "ПТ", "СБ", "ВС"];
let week_text = []
let data_text = []
const ROOTPATH = "images/"
var shag = 46*kf;
var x0 = 73*kf;
let dney = 8;
let isDayIcons = false

let shotWeaterhNames = ["Облачно", "Местами дождь", "Местами снег", "Cолнечно", "Пасмурно", "Слабый дождь", "Слабый снег", "Умеренный дождь", "Умеренный снег", "Сильный снегопад", "Сильный дождь", "Песчаная буря", "Мокрый снег", "Туман", "Дымка", "Дождь с грозой", "Метель", "Пыльно", "Ливень", "Дождь с градом", "Сильный дождь с градом", "Сильный дождь ", "Песчаная буря", "Сильная песчаная буря ", "Сильный дождь", "Неизвестная погода", "Облачно ночью", "Дождливо ночью", "Ясно ночью"];


let tip_grafik = 0

function click_tip_grafik() {
 tip_grafik = (tip_grafik + 1) % 2
 hmFS.SysProSetInt(`${WF_ID}_tip_grafik`, tip_grafik);
 ic_graf_img.setProperty(hmUI.prop.SRC, "images/Grafik/ic_graf_" + tip_grafik + ".png");
 click_Pogoda_off();
 normal_background_Pogoda.setProperty(hmUI.prop.VISIBLE, true);
 setTimeout(() => {
  click_Pogoda_on()
  tip()
 }, 150);
}
let fix_gsm = 1;

function click_fix_gms() {
 fix_gsm = (fix_gsm + 1) % 2
 hmFS.SysProSetInt(`${WF_ID}_fix_gsm`, fix_gsm);
 fix_gsm_text_font.setProperty(hmUI.prop.TEXT, fix_gsm == 0 ? '+0' : '+1');
 click_Pogoda_off();
 normal_background_Pogoda.setProperty(hmUI.prop.VISIBLE, true);
 setTimeout(() => {
  click_Pogoda_on()
  updateGrafik()
  app_update();
 }, 150);
}


 let normal_city_name_text_0 = ''

 //-------------------------------- 

 //массив иконок для графика       
 for (var i = 0; i <= 28; i++) {
  weather_ic_array.push(ROOTPATH + "Grafik/weather/" + i + ".png"); //0-28
 }



function getSunTimes(weatherData, fix_gsm) {
  let tideData = weatherData.tideData;

  // Получение времени заката
  let sunset_hour = -1;
  let sunset_minute = -1;
  if (tideData.count > 0) {
   sunset_hour = tideData.data[0].sunset.hour + fix_gsm;
   sunset_minute = tideData.data[0].sunset.minute;
  }

  let normal_sunset = undefined;
  if (sunset_hour >= 0 && sunset_minute >= 0) {
   normal_sunset = String(sunset_hour).padStart(2, '0') + ':' + String(sunset_minute).padStart(2, '0');
  }

  // Получение времени восхода
  let sunrise_hour = -1;
  let sunrise_minute = -1;
  if (tideData.count > 0) {
   sunrise_hour = tideData.data[0].sunrise.hour + fix_gsm;
   sunrise_minute = tideData.data[0].sunrise.minute;
  }

  let normal_sunrise = undefined;
  if (sunrise_hour >= 0 && sunrise_minute >= 0) {
   normal_sunrise = String(sunrise_hour).padStart(2, '0') + ':' + String(sunrise_minute).padStart(2, '0');
  }

  return {
   normal_sunset_circle_string: normal_sunset,
   normal_sunrise_circle_string: normal_sunrise
  };
 }



 function autoToggleWeatherIcons() {
   // const weatherSensor = hmSensor.createSensor(hmSensor.id.WEATHER);
  let weatherData = weatherSensor.getForecastWeather();
  let tideData = weatherData.tideData;
    let forecastData = weatherData.forecastData;
	 
  sunData = weatherData.tideData;
  if (sunData.count > 0) {
   today = sunData.data[0];
   sunriseMins = (today.sunrise.hour + fix_gsm) * 60 + today.sunrise.minute;
   sunsetMins = (today.sunset.hour + fix_gsm) * 60 + today.sunset.minute;
  } else {
   sunriseMins = sunriseMins_def;
   sunsetMins = sunsetMins_def;
  }
  curMins = timeSensor.hour * 60 + timeSensor.minute;
  let isDayNow = (curMins >= sunriseMins) && (curMins < sunsetMins);

//if (isDayNow !== isDayIcons) isDayIcons = isDayNow;
isDayIcons = isDayNow;
	 
  const {
   normal_sunset_circle_string,
   normal_sunrise_circle_string
  } = getSunTimes(weatherData, fix_gsm);
	 
    let currentTemp = weatherSensor.current;
    if (typeof currentTemp !== 'number' || isNaN(currentTemp)) {
        return;
    }

normal_widget_text_1.setProperty(hmUI.prop.TEXT, currentTemp + "°С");

     let low = forecastData.data[0].low;
    let high = forecastData.data[0].high;	
	 
//    const HOT_ICON = "hot.png";
//    const COLD_ICON = "cold.png";
//    const NORM_ICON = "norm.png";	 

   let iconColor= (currentTemp >= high) ? 0xff0000 :((currentTemp <= low) ? 0x00ffff : 0xffffff);
    let icon = (currentTemp >= high) ? ">" :((currentTemp <= low) ? "<" : ">");

normal_widget_text_8.setProperty(hmUI.prop.COLOR, right == 0 && left == 0 ? iconColor:0xffffff); 
normal_widget_text_8.setProperty(hmUI.prop.TEXT, right == 0 && left == 0 ? icon : right == 1  && left == 0 ? 'C' : (!isDayIcons && right == 2  && left == 0) ? 'K' : 'J'); 
	 

  // Получаем часы и минуты из строки формата "HH:MM"
  const [sunriseHours, sunriseMinutes] = normal_sunrise_circle_string.split(':').map(Number);
  const [sunsetHours, sunsetMinutes] = normal_sunset_circle_string.split(':').map(Number);
	 
	 
  let T_N = curMins;
  let T_V = sunriseHours * 60 + sunriseMinutes;
  let T_Z = sunsetHours * 60 + sunsetMinutes;


  let T_24 = T_Z - T_N;
  let level_SUN_CURRENT_day = (T_N - T_V) / (T_Z - T_V) * 100;
  let level_SUN_CURRENT_night = T_24 < 0 ? (T_N - T_Z) / ((24 * 60 - T_Z) + T_V) * 100 : (24 * 60 - T_Z + T_N) / ((24 * 60 - T_Z) + T_V) * 100;
	 
normal_sun_circle_scale.setProperty(hmUI.prop.MORE, {
 center_x: D_W/2,
 center_y: D_W/2,
 start_angle: 80,
 end_angle: 25,
 radius: 217*kf,
 line_width: 6*kf,
 corner_flag: 3,
   //color: isDayIcons ? 0xffef42 : 0x42ffeb,
 color: 0xFFFFFFFF,
 level: isDayIcons ? level_SUN_CURRENT_day : level_SUN_CURRENT_night,
 show_level: hmUI.show_level.ONLY_NORMAL,
});

	 

  shotWeaterhNames = isDayIcons == false ? ["Облачно ночью", "Местами дождь", "Местами снег", "Ясно ночью", "Пасмурно ночью", "Слабый дождь", "Слабый снег", "Умеренный дождь", "Умеренный снег", "Сильный снегопад", "Сильный дождь", "Песчаная буря", "Мокрый снег", "Туман", "Дымка", "Дождь с грозой", "Метель", "Пыльно", "Ливень", "Дождь с градом", "Сильный дождь с градом", "Сильный дождь ", "Песчаная буря", "Сильная песчаная буря", "Сильный дождь", "Неизвестная погода", "Облачно ночью", "Дождливо ночью", "Ясно ночью"] : ["Облачно", "Местами дождь", "Местами снег", "Cолнечно", "Пасмурно", "Слабый дождь", "Слабый снег", "Умеренный дождь", "Умеренный снег", "Сильный снегопад", "Сильный дождь", "Песчаная буря", "Мокрый снег", "Туман", "Дымка", "Дождь с грозой", "Метель", "Пыльно", "Ливень", "Дождь с градом", "Сильный дождь с градом", "Сильный дождь ", "Песчаная буря", "Сильная песчаная буря ", "Сильный дождь", "Неизвестная погода", "Облачно ночью", "Дождливо ночью", "Ясно ночью"];

//  array_ic_weater = isDayIcons == false ? ["Ъ", "Ы", "Э", "Ь", "Д", "Е", "Ж", "З", "И", "Й", "К", "Л", "М", "Н", "О", "П", "Р", "С", "У", "Ф", "Х", "Ц", "Ч", "Ш", "?", "Ъ", "Ы", "Ь"] : ["А", "Б", "В", "Г", "Д", "Е", "Ж", "З", "И", "Й", "К", "Л", "М", "Н", "О", "П", "Р", "С", "У", "Ф", "Х", "Ц", "Ч", "Ш", "?", "Ъ", "Ы", "Ь"];

  let current = weatherSensor.current;
  let curAirIconIndex = weatherSensor.curAirIconIndex;
  //  normal_city_name_text.setProperty(hmUI.prop.TEXT, shotWeaterhNames[curAirIconIndex]);

  //normal_weater_ic.setProperty(hmUI.prop.TEXT, array_ic_weater[curAirIconIndex]);
	 
normal_widget_text_6.setProperty(hmUI.prop.TEXT, shotWeaterhNames[curAirIconIndex].toUpperCase());	 
normal_widget_text_7.setProperty(hmUI.prop.TEXT, shotWeaterhNames[curAirIconIndex].toUpperCase());	 
  


 }




//обновление для   графика           
 function updateGrafik() {

  autoToggleWeatherIcons()

    //const now = getCurrentDate();   
     const now = new Date();
       // текущая дата (реальная или тестовая)
    const year = now.getFullYear();
    const month = now.getMonth() + 1;                 // 1–12
    const day = now.getDate();
    const weekDay = now.getDay();                     // 0=вс, 1=пн ... 6=сб
    const weekIdx = weekDay === 0 ? 6 : weekDay - 1;  // 0=пн .. 6=вс

  let current = weatherSensor.current;
  let curAirIconIndex = weatherSensor.curAirIconIndex;

  let temperature_current_temp = -100;
  if (weatherSensor.current != undefined && weatherSensor.current != 'undefined') {
   temperature_current_temp = weatherSensor.current;
  }; // end currentWeather; 

  let weatherData = weatherSensor.getForecastWeather();
  let forecastData = weatherData.forecastData;

  const {
   normal_sunset_circle_string,
   normal_sunrise_circle_string
  } = getSunTimes(weatherData, fix_gsm);


  normal_temp_text_font.setProperty(hmUI.prop.TEXT, temperature_current_temp + "°С");
  normal_weather_text_font.setProperty(hmUI.prop.TEXT, shotWeaterhNames[curAirIconIndex].toUpperCase());
  normal_city_name_text_0.setProperty(hmUI.prop.TEXT, normal_sunrise_circle_string + "   " + weatherData.cityName.toUpperCase() + "   " + normal_sunset_circle_string);
	 



   // График прогноза
    if (forecastData.count == 0) {
        for (let i = 0; i < dney; i++) {
            weather_ic[i].setProperty(hmUI.prop.SRC, ROOTPATH + "Grafik/weather/25.png");
        }
    } else {
        let curWeek = weekIdx;
        let curYear = year;
        let curMonth = month;
        let curDay = day;

        for (let i = 0; i < dney; i++) {
            yArrH[i] = forecastData.data[i].high;

            const element = forecastData.data[i];
            const iconIndex = element.index;
            weather_ic[i].setProperty(hmUI.prop.SRC, weather_ic_array[iconIndex]);

            const weekName = week_array[curWeek];
            week_text[i].setProperty(hmUI.prop.MORE, {
                color: curWeek < 5 ? "0xFFFFFFFF" : "0xFFFF0000",
                text: weekName,
            });

            data_text[i].setProperty(hmUI.prop.MORE, {
                color: curWeek < 5 ? "0xFFFFFFFF" : "0xFFFF0000",
                text: curDay,
            });

            // Переход к следующему дню
            curWeek = (curWeek + 1) % 7;
            const nextDate = new Date(curYear, curMonth - 1, curDay + 1);
            curDay = nextDate.getDate();
            curMonth = nextDate.getMonth() + 1;
            curYear = nextDate.getFullYear();

            if (i < dney - 1) yArrL[i] = forecastData.data[i].low;
        }
    }
  tip();

 }

 function tip() {

  canvas.clear({
   x: 0,
   y: 0,
   w: D_W,
   h: D_W,
  })

  canvas.setPaint({
   color: 0x00ff00,
   line_width: 4
  })

  for (let i = 0; i < dney - 1; i++) {
   canvas.drawRect({
    x1: 94  + shag * [i],
    y1: 93 ,
    x2: 94  + shag * [i] + 1,
    y2: 351 ,
    color: 0xc0c0c0
   })
  }


  let maxH = Math.max(...yArrH)
  let maxL = Math.min(...yArrL)
  let delta = 120  / (maxL - maxH)

  let RedArray = [];
  let BlueArray = [];

  if (tip_grafik == 0) {
   for (let i = 0; i < dney; i++) {
    arr_x[i] = x0 + shag * [i];
    arr_y[i] = yArrH[i] * delta + 162  - maxH * delta;
   }
   // let n = arr_x.length;
   splain(dney)

   for (let i = 0; i < dney - 1; i++) {
    arr_x[i] = x0 + 23  + shag * [i];
    arr_y[i] = yArrL[i] * delta + 162  - maxH * delta;
   }
   // n = dney - 1;
   splain(dney - 1)
  }
  if (tip_grafik == 1) {
   let k = 0
   for (let i = 0; i < dney; i++) {

    yArrAll[k] = yArrH[i]
    k = k + 1
    yArrAll[k] = yArrL[i]
    k = k + 1

   }


   for (let i = 0; i < yArrAll.length; i++) {
    arr_x[i] = x0 + shag / 2 * [i];
    arr_y[i] = yArrAll[i] * delta + 162  - maxH * delta;
   }
   //n = yArrAll.length - 1;
   splain(yArrAll.length - 1)
  }


  for (let i = 0; i < dney; i++) {
   if (tip_grafik == 0) {
    canvas.drawCircle({
     center_x: x0 + shag * [i],
     center_y: yArrH[i] * delta + 162  - maxH * delta,
     radius: 5 ,
     color: 0xFF0000
    })
   }
   y_pogodaH[i] = (yArrH[i] * delta + 145  - maxH * delta) - 5;
   DigDay[i].setProperty(hmUI.prop.more, {
    x: x0 - 28  + i * 45*kf  * 1.02,
    y: y_pogodaH[i] - 18 , //120-7//120-7/- 38
    w: 50 ,
    h: 40 ,
    color: "0xFFffffff",
    text_size: 27*kf ,
    text: yArrH[i],
    text_style: hmUI.text_style.NONE,
    align_h: hmUI.align.CENTER_H,
    align_v: hmUI.align.CENTER_V,
    show_level: hmUI.show_level.ONLY_NORMAL
   });

   if (i < dney - 1) {
    if (tip_grafik == 0) {
     canvas.drawCircle({
      center_x: x0 + 23  + shag * [i],
      center_y: yArrL[i] * delta + 162  - maxH * delta,
      radius: 5 ,
      color: 0x00eaff
     })
    }
    y_pogodaL[i] = (yArrL[i] * delta + 145  - maxH * delta) - 5;;
    DigNight[i].setProperty(hmUI.prop.more, {
     x: x0 - 5  + i * 45*kf * 1.02,
     y: y_pogodaL[i] + 19 , //120-7 / - 1  
     w: 50 ,
     h: 40 ,
     color: "0xFFffffff",
     text_size: 27*kf,
     text: yArrL[i],
     text_style: hmUI.text_style.NONE,
     align_h: hmUI.align.CENTER_H,
     align_v: hmUI.align.CENTER_V,
     show_level: hmUI.show_level.ONLY_NORMAL
    });
   } //dney - 1
  }; //dney   
 }


 function splain(n) {
  let arr_a = new Array(n).fill().map(() => new Array(1));
  let arr_b = new Array(n - 1).fill().map(() => new Array(1));
  let arr_c = new Array(n).fill().map(() => new Array(1));
  let arr_d = new Array(n - 1).fill().map(() => new Array(1));

  let arr_h = new Array(n - 1).fill().map(() => new Array(1));
  let arr_alpha = new Array(n).fill().map(() => new Array(1));
  let arr_l = new Array(n).fill().map(() => new Array(1));
  let arr_mu = new Array(n).fill().map(() => new Array(1));
  let arr_z = new Array(n).fill().map(() => new Array(1));

  for (var i = 0; i < n - 1; i++) {
   arr_h[i] = arr_x[i + 1] - arr_x[i];
  }

  for (var i = 1; i < n - 1; i++) {
   arr_alpha[i] = 3 * ((arr_y[i + 1] - arr_y[i]) / arr_h[i] - (arr_y[i] - arr_y[i - 1]) / arr_h[i - 1]);
  }

  arr_l[0] = 1;
  arr_mu[0] = 0;
  arr_z[0] = 0;

  for (var i = 1; i < n - 1; i++) {
   arr_l[i] = 2 * (arr_x[i + 1] - arr_x[i - 1]) - arr_h[i - 1] * arr_mu[i - 1];
   arr_mu[i] = arr_h[i] / arr_l[i];
   arr_z[i] = (arr_alpha[i] - arr_h[i - 1] * arr_z[i - 1]) / arr_l[i];
  }

  arr_l[n - 1] = 1;
  arr_z[n - 1] = 0;
  arr_c[n - 1] = 0;

  for (var j = n - 2; j >= 0; j--) {
   arr_c[j] = arr_z[j] - arr_mu[j] * arr_c[j + 1];
   arr_b[j] = (arr_y[j + 1] - arr_y[j]) / arr_h[j] - arr_h[j] * (arr_c[j + 1] + 2 * arr_c[j]) / 3;
   arr_d[j] = (arr_c[j + 1] - arr_c[j]) / (3 * arr_h[j]);
   arr_a[j] = arr_y[j];
  }

  for (var i = 0; i < n - 1; i++) {
   for (xi = arr_x[i]; xi < arr_x[i + 1] - 1; xi += 5) {
    yi = arr_a[i] + arr_b[i] * (xi - arr_x[i]) + arr_c[i] * Math.pow((xi - arr_x[i]), 2) + arr_d[i] * Math.pow((xi - arr_x[i]), 3);

    if (tip_grafik == 0) {
     canvas.drawImage({
      x: xi,
      y: yi,
      w: 5,
      h: 310 - yi,
      alpha: 127,
      image: n == dney ? 'images/Grafik/line_day.png' : 'images/Grafik/line_night.png'
     })
    }

    canvas.drawLine({
     x1: xi,
     y1: yi,
     x2: xi + 5,
     y2: arr_a[i] + arr_b[i] * (xi + 5 - arr_x[i]) + arr_c[i] * Math.pow((xi + 5 - arr_x[i]), 2) + arr_d[i] * Math.pow((xi + 5 - arr_x[i]), 3),
     // color: n == dney ? 0xff0000 : 0x00eaff//0x009cff  yArrAll.length - 1
     color: n == dney ? 0xff0000 : n == dney - 1 ? 0x00eaff : 0x12a2fd //0x009cff
    })


   }
  }

 }




 function updatePressere() {
  let pressure_array = read_pressure();
  let value = getPressureValue(pressure_array);
  value = hPa_To_mmHg(value); // если нужно перевести в мм.рт.ст.


  let pressere_changes_str = "=";
  //let color_pressere = 0x00ff00;
  let color_pressere_0 = value < 760 ? 0xffff00 : value > 760 ? 0xff0000 : 0x00ff00;

  let pressere_changes = changesPressure(pressure_array);
  if (pressere_changes < 0) {
   pressere_changes_str = "↓"; /*color_pressere = 0xffff00;*/
  }
  if (pressere_changes > 0) {
   pressere_changes_str = "↑"; /*color_pressere = 0xff0000;*/
  }
  //text_pressere_changes.setProperty(hmUI.prop.TEXT, pressere_changes_str);

  let value_str = value == 0 ? "--" : value + pressere_changes_str;
  text_pressere.setProperty(hmUI.prop.TEXT, value_str);
  text_pressere.setProperty(hmUI.prop.COLOR, color_pressere_0);

 // Line_arr[2][1] = value_str;
 }


// ---- масштабируемые константы ----
const SQUARE_SIZE = 112 * kf;
const INNER_DIAMETER = 302 * kf;
const OUTER_DIAMETER = D_W;
const OFFSET = -6 * kf;            // сдвиг масштабируем
const EDIT_W = 124 * kf;           // ширина области редактирования
const EDIT_H = 124 * kf;
const BUTTON_W = 113 * kf;         // размер кликабельной зоны
const BUTTON_H = 113 * kf;
const TIPS_WIDTH = 195 * kf;       // ширина подсказки
const TIPS_MARGIN = 10 * kf;
const COMMON_TIPS_X = -35 * kf;    // общий сдвиг подсказки по X

// ---- массив конфигураций (с масштабированными tipsY) ----
const tapConfigs = Array.from({ length: 6 }, (_, i) => {
  const angle = -Math.PI / 2 + i * (2 * Math.PI / 6);
  const centerX = (OUTER_DIAMETER / 2) + (INNER_DIAMETER / 2) * Math.cos(angle);
  const centerY = (OUTER_DIAMETER / 2) + (INNER_DIAMETER / 2) * Math.sin(angle);

  const x = Math.round(centerX - SQUARE_SIZE / 2) + Math.round(OFFSET);
  const y = Math.round(centerY - SQUARE_SIZE / 2) + Math.round(OFFSET);

  let defaultType, tipsY_base;
  switch (i) {
    case 0: defaultType = 19; tipsY_base = 130; break;
    case 1: defaultType = 20; tipsY_base = 130; break;
    case 2: defaultType = 24; tipsY_base = -62; break;
    case 3: defaultType = 11; tipsY_base = -64; break;
    case 4: defaultType = 35; tipsY_base = -62; break;
    case 5: defaultType = 0;  tipsY_base = 130; break;
  }

  return {
    id: 101 + i,
    x: x,
    y: y,
    defaultType: defaultType,
    tipsX: COMMON_TIPS_X,
    tipsY: Math.round(tipsY_base * kf)   // масштабируем вертикальный сдвиг
  };
});

// ---- позиции квадратов (без OFFSET, только центры) ----
const tapPositions = Array.from({ length: 6 }, (_, i) => {
  const angle = -Math.PI / 2 + i * (2 * Math.PI / 6);
  const centerX = (OUTER_DIAMETER / 2) + (INNER_DIAMETER / 2) * Math.cos(angle);
  const centerY = (OUTER_DIAMETER / 2) + (INNER_DIAMETER / 2) * Math.sin(angle);
  return {
    x: Math.round(centerX - SQUARE_SIZE / 2),
    y: Math.round(centerY - SQUARE_SIZE / 2),
    index: i
  };
});

// ---- получение выбранных типов приложений ----
const tapSelections = [];
for (let i = 0; i < tapConfigs.length; i++) {
  const config = tapConfigs[i];
  const edit = hmUI.createWidget(hmUI.widget.WATCHFACE_EDIT_GROUP, {
    edit_id: config.id,
    x: config.x,
    y: config.y,
    w: Math.round(EDIT_W),
    h: Math.round(EDIT_H),
    select_image: 'tap/edit_red_1.png',
    un_select_image: 'tap/edit_griin_1.png',
    default_type: config.defaultType,
    optional_types: apps.map((app, index) => ({
      type: index,
      preview: app[2],
      title_en: app[0]
    })),
    count: apps.length,
    tips_x: Math.round(config.tipsX),
    tips_y: Math.round(config.tipsY),
    tips_width: Math.round(TIPS_WIDTH),
    tips_margin: Math.round(TIPS_MARGIN),
    tips_BG: 'tap/tips_bg.png'
  });
  // небольшая задержка (лучше использовать setTimeout, но цикл оставлен как в оригинале)
  for (let c = 0; c < 1000; c++) {}
  tapSelections[i] = edit.getProperty(hmUI.prop.CURRENT_TYPE);
}

// ---- создание интерфейса с иконками и кнопками ----
function createTapInterface() {
  const groupTap = hmUI.createWidget(hmUI.widget.GROUP, {
    x: 0, y: 0, w: D_W, h: D_H,
    show_level: hmUI.show_level.ONLY_NORMAL
  });

  groupTap.createWidget(hmUI.widget.IMG, {
    x: 0, y: 0, w: D_W, h: D_H,
    src: 'tap/i_tap_bg.png',
    show_level: hmUI.show_level.ONLY_NORMAL,
  });

  for (let i = 0; i < 6; i++) {
    const pos = tapPositions[i];
    const appIndex = tapSelections[i];
    if (appIndex === undefined) continue;

    // иконка приложения
    groupTap.createWidget(hmUI.widget.IMG, {
      x: pos.x,
      y: pos.y,
      src: apps[appIndex][2],
      show_level: hmUI.show_level.ONLY_NORMAL,
    });

    // невидимая кнопка
    groupTap.createWidget(hmUI.widget.BUTTON, {
      x: pos.x,
      y: pos.y,
      w: Math.round(BUTTON_W),
      h: Math.round(BUTTON_H),
      normal_src: '0_Empty.png',
      press_src: '0_Empty.png',
      click_func: () => {
        vibro();
        const app = apps[appIndex];
        hmApp.startApp({
          appid: app[3] === 0 ? '' : app[1],
          url: app[3] === 0 ? app[1] : app[4],
          native: app[3] === 0,
          params: app[3] === 0 ? null : { from_wf: true }
        });
      },
      show_level: hmUI.show_level.ONLY_NORMAL,
    });
  }
  return groupTap;
}
	 

 const TIME_ZONES = [
  "UTC", "CET", "КЛГ", "МСК", "САМ", "ЕКБ", "ОМСК", "КРАС",
  "ИРК", "ЯКУ", "ВЛД", "МАГ", "КАМ", "SST", "HST", "AKST",
  "PST", "MST", "CST", "EST", "AST", "BRT", "GST", "CVT"
 ];



let normal_unit_font = [];
function createUnitText(x, y, visible) {
  const widget = hmUI.createWidget(hmUI.widget.TEXT, {
    x, y,
    w: 150,
    h: 80,
    text_size: 19,
    text: '',
    font: 'fonts/Oswald-Medium.ttf',
    color: 0x90ffff,
    align_h: hmUI.align.CENTER_H,
    align_v: hmUI.align.CENTER_V,
    show_level: hmUI.show_level.ONLY_NORMAL
  });
  widget.setProperty(hmUI.prop.VISIBLE, visible);
  return widget;
} 
 
let normal_ic = [];
function createIconWidget(x, y, index) {
  const id = CONF_MAIN[index].id;
  const widget = hmUI.createWidget(hmUI.widget.TEXT, {
    x, y,
    w: 80,
    h: 80,
    text_size: 34,
    text: Line_arr[id][0],
    char_space: 0,
    line_space: 0,
    font: 'fonts/ic_Sever1.ttf',
    color: Line_arr[id][4],
    align_h: hmUI.align.CENTER_H,
    align_v: hmUI.align.CENTER_V,
    text_style: hmUI.text_style.ELLIPSIS,
    show_level: hmUI.show_level.ONLY_NORMAL
  });
  widget.setProperty(hmUI.prop.VISIBLE, id != 16 && id != 20 && id != 14);
  return widget;
}


let normal_uvi_img = [];
function createUviImg(x, y, visible) {
    const widget = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
    x, y,
    image_array: ["images/APP/uv_0.png", "images/APP/uv_1.png", "images/Grafik/ic_activ/uv_2.png", "images/APP/uv_3.png", "images/APP/uv_4.png"],
    image_length: 5,
    type: hmUI.data_type.UVI,
    show_level: hmUI.show_level.ONLY_NORMAL,
    });
    widget.setProperty(hmUI.prop.VISIBLE, visible);
    return widget;
} 

let normal_sun_img = [];
function createSunImg(x, y, visible) {
    const widget = hmUI.createWidget(hmUI.widget.IMG, {
    x, y,
    src: 'images/APP/ic_vos_n.png',
    show_level: hmUI.show_level.ONLY_NORMAL,
    });
    widget.setProperty(hmUI.prop.VISIBLE, visible);
    return widget;
} 

  //let normal_data = Array(3*2).fill().map(() => []);

// Объявляем массив для виджетов данных
const normal_data = [[], [], [], [], [], []]; // Индексы 0-5, будем использовать 3,4,5
// Функция для создания виджета данных для конкретной позиции
function createDataWidget(i, position) {
  // Определяем параметры для каждой позиции
  const positionConfig = {
    3: { x: 12, y: 299 },   // Левая позиция
    4: { x: 309, y: 299 },  // Правая позиция
    5: { x: 158, y: 29 }      // Верхняя позиция
  };
  const config = positionConfig[position];
  // Создаем виджет
  const widget = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
    x: config.x,
    y: config.y,
    w: 150,
    h: 60,
    text_size: 33,
    char_space: 0,
    line_space: 0,
    font: 'fonts/Oswald-Regular.ttf',
    color: color_bg[0][CONF_MAIN[1].id],
    align_h: hmUI.align.CENTER_H,
    align_v: hmUI.align.CENTER_V,
    text_style: hmUI.text_style.ELLIPSIS,
    unit_type: Line_arr[i][2],
    padding: Line_arr[i][6],
    type: Line_arr[i][5],
    show_level: hmUI.show_level.ONLY_NORMAL
  });
  // Устанавливаем видимость ВНУТРИ функции
  widget.setProperty(hmUI.prop.VISIBLE, CONF_MAIN[position].id == i);
  return widget;
}


// Объявляем массив для текстовых виджетов значений
const normal_sensor_value = []; // Индексы 3,4,5 для left, right, up
// Функция для создания текстовых виджетов значений
function createValueWidget(position) {
  // Конфигурация позиций (только координаты, ширина всегда 150)
  const positionConfig = {
    3: { x: 12, y: 299 },   // Левая позиция
    4: { x: 309, y: 299 },  // Правая позиция
    5: { x: 158, y: 29 }    // Верхняя позиция
  };
  const id = CONF_MAIN[position].id;
  const config = positionConfig[position];
  const widget = hmUI.createWidget(hmUI.widget.TEXT, {
    x: config.x,
    y: config.y,
    w: 150,  // Фиксированная ширина для всех виджетов
    h: 60,
    text_size: 33,
    text: Line_arr[id][1],
    char_space: 0,
    line_space: 0,
    font: 'fonts/Oswald-Regular.ttf',
    color: color_bg[0][CONF_MAIN[1].id],
    align_h: hmUI.align.CENTER_H,
    align_v: hmUI.align.CENTER_V,
    text_style: hmUI.text_style.ELLIPSIS,
    show_level: hmUI.show_level.ONLY_NORMAL
  });
  // Устанавливаем видимость сразу
  widget.setProperty(hmUI.prop.VISIBLE, Line_arr[id][5] == '');
  return widget;
}
 
 
        // end user_functions.js

        let normal_widget_text_1 = ''
        let normal_widget_text_2 = ''
        let normal_widget_text_6 = ''
        let normal_widget_text_7 = ''
        let normal_widget_text_8 = ''
        let normal_widget_text_9 = ''
        let normal_widget_text_10 = ''
        let normal_digital_clock_img_time_hour = ''
        let normal_month_name_font = ''
        let normal_Month_Array = ['ЯНВ', 'ФЕВ', 'МАР', 'АПР', 'МАЙ', 'ИЮН', 'ИЮЛ', 'АВГ', 'СЕН', 'ОКТ', 'НОЯ', 'ДЕК', ];
        let normal_dow_text_font = ''
        let normal_DOW_Array = ['ПНД', 'ВТР', 'СРД', 'ЧТВ', 'ПТН', 'СБТ', 'ВСК'];
        let normal_day_text_font = ''
        let normal_pai_icon_img = ''
        let normal_heart_rate_icon_img = ''
        let normal_heart_rate_circle_scale_2 = ''
        let normal_heart_rate_text_font = ''
        let normal_step_circle_scale = ''
        let normal_step_current_text_font = ''
        let normal_battery_circle_scale = ''
        let normal_battery_current_text_font = ''
        let normal_calorie_icon_img = ''
        let normal_calorie_circle_scale = ''
        let normal_calorie_current_text_font = ''
        let normal_temperature_icon_img = ''
        let normal_temperature_low_text_font = ''
        let normal_temperature_high_text_font = ''
        let normal_sun_icon_img = ''
        let normal_sun_low_text_font = ''
        let normal_sun_high_text_font = ''
        let normal_alarm_clock_current_text_font = ''
        let normal_system_clock_img = ''
        let idle_background_bg = ''
        let idle_digital_clock_img_time_hour = ''
        let Button_1 = ''
        let Button_2 = ''
        let Button_3 = ''
        let timeSensor = '';


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            // FontName: Roboto-Black.ttf; FontSize: 27
            hmUI.createWidget(hmUI.widget.TEXT, {
              x: 464,
              y: 464,
              w: 382,
              h: 40,
              text_size: 27,
              char_space: 0,
              line_space: 0,
              font: 'fonts/Roboto-Black.ttf',
              color: 0xFFFFFFFF,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              text: "0123456789 _-.,:;`'%°\\/",
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // FontName: HeadingSmallcaseProicv7-Bold.ttf; FontSize: 32
            hmUI.createWidget(hmUI.widget.TEXT, {
              x: 464,
              y: 464,
              w: 448,
              h: 46,
              text_size: 32,
              char_space: 0,
              line_space: 0,
              font: 'fonts/HeadingSmallcaseProicv7-Bold.ttf',
              color: 0xFF808080,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              text: "0123456789 _-.,:;`'%°\\/",
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // FontName: HeadingSmallcaseProicv7-Bold.ttf; FontSize: 40
            hmUI.createWidget(hmUI.widget.TEXT, {
              x: 464,
              y: 464,
              w: 538,
              h: 55,
              text_size: 40,
              char_space: 0,
              line_space: 0,
              font: 'fonts/HeadingSmallcaseProicv7-Bold.ttf',
              color: 0xFFFF0000,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              text: "0123456789 _-.,:;`'%°\\/",
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // FontName: 9_segment_black.ttf; FontSize: 40
            hmUI.createWidget(hmUI.widget.TEXT, {
              x: 464,
              y: 464,
              w: 625,
              h: 48,
              text_size: 40,
              char_space: 0,
              line_space: 0,
              font: 'fonts/9_segment_black.ttf',
              color: 0xFF000000,
              align_h: hmUI.align.RIGHT,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              text: "0123456789 _-.,:;`'%°\\/",
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // FontName: Roboto-Black.ttf; FontSize: 27; Cache: full
            hmUI.createWidget(hmUI.widget.TEXT, {
              x: 464,
              y: 464,
              w: 32,
              h: 32,
              text_size: 27,
              char_space: 0,
              line_space: 0,
              font: 'fonts/Roboto-Black.ttf',
              color: 0xFFFFFFFF,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.NONE,
              text: "0123456789 ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz АБВГДЕЁЖЗИЙКЛМНОПРСТУФХЦЧШЩЪЫЬЭЮЯабвгдеёжзийклмнопрстуфхцчшщъыьэюя  ҐЄІЇґєії _-.,:;`'%°\\/",
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // FontName: Roboto-Black.ttf; FontSize: 41
            hmUI.createWidget(hmUI.widget.TEXT, {
              x: 464,
              y: 464,
              w: 573,
              h: 61,
              text_size: 41,
              char_space: 0,
              line_space: 0,
              font: 'fonts/Roboto-Black.ttf',
              color: 0xFFFFFFFF,
              align_h: hmUI.align.LEFT,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              text: "0123456789 _-.,:;`'%°\\/",
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // FontName: 9_segment_black.ttf; FontSize: 45
            hmUI.createWidget(hmUI.widget.TEXT, {
              x: 464,
              y: 464,
              w: 688,
              h: 54,
              text_size: 45,
              char_space: 0,
              line_space: 0,
              font: 'fonts/9_segment_black.ttf',
              color: 0xFFFFFFFF,
              align_h: hmUI.align.RIGHT,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              text: "0123456789 _-.,:;`'%°\\/",
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // FontName: Roboto-Black.ttf; FontSize: 22
            hmUI.createWidget(hmUI.widget.TEXT, {
              x: 464,
              y: 464,
              w: 313,
              h: 33,
              text_size: 22,
              char_space: 0,
              line_space: 0,
              font: 'fonts/Roboto-Black.ttf',
              color: 0xFFFFFFFF,
              align_h: hmUI.align.RIGHT,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              text: "0123456789 _-.,:;`'%°\\/",
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // FontName: Roboto_A2-Black.ttf; FontSize: 29
            hmUI.createWidget(hmUI.widget.TEXT, {
              x: 464,
              y: 464,
              w: 400,
              h: 42,
              text_size: 29,
              char_space: 0,
              line_space: 0,
              font: 'fonts/Roboto_A2-Black.ttf',
              color: 0xFFFFFFFF,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              text: "0123456789 _-.,:;`'%°\\/",
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            console.log('user_script_start.js');
            // start user_script_start.js

loadSettings()

hmUI.createWidget(hmUI.widget.TEXT, {
 x: D_W+2,
 y: D_W+2,
 w: 42*kf,
 h: 42*kf,
 text_size: 27*kf,
 char_space: 0,
 line_space: 0,
 font: 'fonts/Bebas22.ttf',
 color: 0xFFFFFF00,
 align_h: hmUI.align.LEFT,
 align_v: hmUI.align.CENTER_V,
 text_style: hmUI.text_style.NONE,
 text: "0123456789 ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz АБВГДЕЁЖЗИЙКЛМНОПРСТУФХЦЧШЩЪЫЬЭЮЯабвгдеёжзийклмнопрстуфхцчшщъыьэюя  ҐЄІЇґєії _-.,:;`'%°\\/←→↓↑",
 show_level: hmUI.show_level.ONLY_NORMAL,
});

hmUI.createWidget(hmUI.widget.TEXT, {
 x: D_W+2,
 y: D_W+2,
 w: 42*kf,
 h: 42*kf,
 text_size: 33*kf,
 char_space: 0,
 line_space: 0,
 font: 'fonts/Bebas22.ttf',
 color: 0xFFFFFF00,
 align_h: hmUI.align.LEFT,
 align_v: hmUI.align.CENTER_V,
 text_style: hmUI.text_style.NONE,
 text: "0123456789 ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz АБВГДЕЁЖЗИЙКЛМНОПРСТУФХЦЧШЩЪЫЬЭЮЯабвгдеёжзийклмнопрстуфхцчшщъыьэюя  ҐЄІЇґєії _-.,:;`'%°\\/←→↓↑",
 show_level: hmUI.show_level.ONLY_NORMAL,
});

hmUI.createWidget(hmUI.widget.TEXT, {
 x: D_W+2,
 y: D_W+2,
 w: 328*kf,
 h: 48*kf,
 text_size: 35*kf,
 char_space: 0,
 line_space: 0,
 font: 'fonts/Bebas22.ttf',
 color: 0xFFFFFFFF,
 align_h: hmUI.align.CENTER_H,
 align_v: hmUI.align.CENTER_V,
 text_style: hmUI.text_style.ELLIPSIS,
 text: "0123456789 ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz АБВГДЕЁЖЗИЙКЛМНОПРСТУФХЦЧШЩЪЫЬЭЮЯабвгдеёжзийклмнопрстуфхцчшщъыьэюя  ҐЄІЇґєії _-.,:;`'%°\\/←→↓↑",
 show_level: hmUI.show_level.ONLY_NORMAL,
});


            hmUI.createWidget(hmUI.widget.TEXT, {
             x: D_W + 2,
             y: D_W + 2,
             w: 538 * kf,
             h: 70 * kf,
             text_size: 40 * kf,
             char_space: 0,
             line_space: 0,
             font: 'fonts/HeadingSmallcaseProicv7-Bold.ttf',
             color: 0xFFFF0000,
             align_h: hmUI.align.CENTER_H,
             align_v: hmUI.align.CENTER_V,
             text_style: hmUI.text_style.ELLIPSIS,
             text: "0123456789 _-.,:;`'%°\\/<>KJC{}",
             show_level: hmUI.show_level.ONLY_NORMAL,
            });



if (screenTypeJS == hmSetting.screen_type.WATCHFACE) {
 normal_background = hmUI.createWidget(hmUI.widget.FILL_RECT, {
  x: 0,
  y: 0,
  w: D_W,
  h: D_W,
  color: color_bg[0][CONF_MAIN[0].id],
  //color: 0xFFFF0000,
  show_level: hmUI.show_level.ONLY_NORMAL,
 });
}

//if (!timeSensor) timeSensor = hmSensor.createSensor(hmSensor.id.TIME);

normal_M_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
 x: 0,
 y: 0,
  w: D_W,
  h: D_W,
 src: 'M_0.png',
auto_scale: true,
 show_level: hmUI.show_level.ONLY_NORMAL,
});






            // end user_script_start.js

            console.log('Watch_Face.ScreenNormal');

            normal_widget_text_1 = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 1,
              y: 1,
              w: 464,
              h: 464,
              text_size: 27,
              char_space: 0,
              font: 'fonts/Roboto-Black.ttf',
              color: 0xFFFFFFFF,
              // use_text_circle: true,
              start_angle: 90,
              end_angle: 270,
              mode: 1,
              // radius: 232,
              align_h: hmUI.align.CENTER_H,
              text: '-25°C',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_widget_text_2 = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 306,
              y: 376,
              w: 50,
              h: 50,
              text_size: 32,
              char_space: 0,
              font: 'fonts/HeadingSmallcaseProicv7-Bold.ttf',
              color: 0xFF808080,
              line_space: 0,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.CENTER_H,
              text: '{}',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_widget_text_6 = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 68,
              y: 66,
              w: 342,
              h: 73,
              text_size: 27,
              char_space: 0,
              color: 0xFF000000,
              line_space: -16,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.WRAP,
              align_h: hmUI.align.CENTER_H,
              text: 'СИЛЬНЫЙ ДОЖДЬ С ГРАДОМ',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_widget_text_7 = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 66,
              y: 64,
              w: 340,
              h: 73,
              text_size: 27,
              char_space: 0,
              color: 0xFFFFFFFF,
              line_space: -16,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.WRAP,
              align_h: hmUI.align.CENTER_H,
              text: 'СИЛЬНЫЙ ДОЖДЬ С ГРАДОМ',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_widget_text_8 = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 380,
              y: 210,
              w: 70,
              h: 70,
              text_size: 40,
              char_space: 0,
              font: 'fonts/HeadingSmallcaseProicv7-Bold.ttf',
              color: 0xFFFF0000,
              line_space: 0,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.CENTER_H,
              text: '<>KJC',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_widget_text_9 = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 253,
              y: 326,
              w: 150,
              h: 50,
              text_size: 40,
              char_space: 0,
              font: 'fonts/9_segment_black.ttf',
              color: 0xFF000000,
              line_space: 0,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.RIGHT,
              text: '88.88',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_widget_text_10 = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 251,
              y: 324,
              w: 150,
              h: 50,
              text_size: 40,
              char_space: 0,
              font: 'fonts/9_segment_black.ttf',
              color: 0xFFFFFFFF,
              line_space: 0,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.RIGHT,
              text: '88.88',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time_hour = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 127,
              hour_startY: 144,
              hour_array: ["H_0.png","H_1.png","H_2.png","H_3.png","H_4.png","H_5.png","H_6.png","H_7.png","H_8.png","H_9.png"],
              hour_zero: 1,
              hour_space: -17,
              hour_angle: 0,
              hour_align: hmUI.align.LEFT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            if (!timeSensor) timeSensor = hmSensor.createSensor(hmSensor.id.TIME);
            timeSensor.addEventListener(timeSensor.event.DAYCHANGE, function() {
              time_update(true);
            });

            normal_month_name_font = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 221,
              y: 20,
              w: 150,
              h: 70,
              text_size: 27,
              char_space: 0,
              font: 'fonts/Roboto-Black.ttf',
              color: 0xFFFFFFFF,
              line_space: 0,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.CENTER_H,
              // unit_string: ЯНВ, ФЕВ, МАР, АПР, МАЙ, ИЮН, ИЮЛ, АВГ, СЕН, ОКТ, НОЯ, ДЕК,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_dow_text_font = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 97,
              y: 20,
              w: 150,
              h: 70,
              text_size: 27,
              char_space: 0,
              font: 'fonts/Roboto-Black.ttf',
              color: 0xFFFFFFFF,
              line_space: 0,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.CENTER_H,
              // unit_string: ПНД, ВТР, СРД, ЧТВ, ПТН, СБТ, ВСК,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_day_text_font = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 158,
              y: 16,
              w: 150,
              h: 70,
              text_size: 41,
              char_space: 0,
              font: 'fonts/Roboto-Black.ttf',
              color: 0xFFFFFFFF,
              line_space: 0,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.CENTER_H,
              // padding: true,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_pai_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'cap.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            console.log('user_script.js');
            // start user_script.js
            normal_heart_rate_text_font_bg = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: (3+2)*kf,
              y: (324+2)*kf,
              w: 150*kf,
              h: 50*kf,
              text_size: 40*kf,
              char_space: 0,
              font: 'fonts/9_segment_black.ttf',
              color: 0x000000,
              line_space: 0,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            // end user_script.js

            normal_heart_rate_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 218,
              y: 12,
              src: 'stat_BT.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_circle_scale_2 = hmUI.createWidget(hmUI.widget.ARC_PROGRESS, {
              center_x: 233,
              center_y: 233,
              start_angle: 193,
              end_angle: 257,
              radius: 217,
              line_width: 6,
              corner_flag: 3,
              type: hmUI.data_type.HEART,
              color: 0xFFFFFFFF,
              // mirror: False,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 3,
              y: 324,
              w: 150,
              h: 50,
              text_size: 40,
              char_space: 0,
              font: 'fonts/9_segment_black.ttf',
              color: 0xFFFFFFFF,
              line_space: 0,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_step_circle_scale = hmUI.createWidget(hmUI.widget.Circle_Scale, {
              // center_x: 233,
              // center_y: 233,
              // start_angle: 167,
              // end_angle: 103,
              // radius: 220,
              // line_width: 6,
              // line_cap: Flat,
              // color: 0xFFFFFFFF,
              // mirror: False,
              // inversion: False,
              // alpha: 255,
              // type: hmUI.data_type.STEP,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            let screenType = hmSetting.getScreenType();
            normal_step_circle_scale = hmUI.createWidget(hmUI.widget.ARC_PROGRESS, {
              center_x: 233,
              center_y: 233,
              start_angle: 167,
              end_angle: 103,
              radius: 217,
              line_width: 6,
              corner_flag: 3,
              color: 0xFFFFFFFF,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            
            const step = hmSensor.createSensor(hmSensor.id.STEP);
            step.addEventListener(hmSensor.event.CHANGE, function() {
              scale_call();
            });

            normal_step_current_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 160,
              y: 388,
              w: 150,
              h: 50,
              text_size: 45,
              char_space: 0,
              font: 'fonts/9_segment_black.ttf',
              color: 0xFFFFFFFF,
              line_space: 0,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_battery_circle_scale = hmUI.createWidget(hmUI.widget.Circle_Scale, {
              // center_x: 233,
              // center_y: 233,
              // start_angle: 283,
              // end_angle: 347,
              // radius: 220,
              // line_width: 6,
              // line_cap: Flat,
              // color: 0xFFFFFFFF,
              // mirror: False,
              // inversion: False,
              // alpha: 255,
              // type: hmUI.data_type.BATTERY,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_battery_circle_scale = hmUI.createWidget(hmUI.widget.ARC_PROGRESS, {
              center_x: 233,
              center_y: 233,
              start_angle: 283,
              end_angle: 347,
              radius: 217,
              line_width: 6,
              corner_flag: 3,
              color: 0xFFFFFFFF,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            
            const battery = hmSensor.createSensor(hmSensor.id.BATTERY);
            battery.addEventListener(hmSensor.event.CHANGE, function() {
              scale_call();
            });

            normal_battery_current_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 1,
              y: 1,
              w: 464,
              h: 464,
              text_size: 27,
              char_space: 0,
              font: 'fonts/Roboto-Black.ttf',
              color: 0xFFFFFFFF,
              // use_text_circle: true,
              start_angle: 200,
              end_angle: 282,
              mode: 0,
              // radius: 232,
              align_h: hmUI.align.RIGHT,
              unit_type: 1,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_calorie_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 279,
              y: 18,
              src: 'bg_cal_pr.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_cal_circle_scale = hmUI.createWidget(hmUI.widget.Circle_Scale, {
              // center_x: 233,
              // center_y: 233,
              // start_angle: 77,
              // end_angle: 13,
              // radius: 220,
              // line_width: 6,
              // line_cap: Flat,
              // color: 0xFFFFFFFF,
              // mirror: False,
              // inversion: False,
              // alpha: 255,
              // type: hmUI.data_type.CAL,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_calorie_circle_scale = hmUI.createWidget(hmUI.widget.ARC_PROGRESS, {
              center_x: 233,
              center_y: 233,
              start_angle: 77,
              end_angle: 13,
              radius: 217,
              line_width: 6,
              corner_flag: 3,
              color: 0xFFFFFFFF,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            
            const calorie = hmSensor.createSensor(hmSensor.id.CALORIE);
            calorie.addEventListener(hmSensor.event.CHANGE, function() {
              scale_call();
            });

            normal_calorie_current_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: -1,
              y: -1,
              w: 468,
              h: 468,
              text_size: 27,
              char_space: 0,
              font: 'fonts/Roboto-Black.ttf',
              color: 0xFFFFFFFF,
              // use_text_circle: true,
              start_angle: 80,
              end_angle: 150,
              mode: 0,
              // radius: 234,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 279,
              y: 18,
              src: 'bg_weather_pr.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_low_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: -1,
              y: -1,
              w: 468,
              h: 468,
              text_size: 27,
              char_space: 0,
              font: 'fonts/Roboto-Black.ttf',
              color: 0xFFFFFFFF,
              // use_text_circle: true,
              start_angle: 87,
              end_angle: 150,
              mode: 0,
              // radius: 234,
              align_h: hmUI.align.LEFT,
              unit_type: 1,
              type: hmUI.data_type.WEATHER_LOW,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_high_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: -1,
              y: -1,
              w: 468,
              h: 468,
              text_size: 27,
              char_space: 0,
              font: 'fonts/Roboto-Black.ttf',
              color: 0xFFFFFFFF,
              // use_text_circle: true,
              start_angle: -20,
              end_angle: 21,
              mode: 0,
              // radius: 234,
              align_h: hmUI.align.RIGHT,
              unit_type: 1,
              type: hmUI.data_type.WEATHER_HIGH,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sun_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 279,
              y: 18,
              src: 'bg_sun_pr.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sun_low_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 1,
              y: 1,
              w: 464,
              h: 464,
              text_size: 22,
              char_space: 0,
              font: 'fonts/Roboto-Black.ttf',
              color: 0xFFFFFFFF,
              // use_text_circle: true,
              start_angle: -20,
              end_angle: 25,
              mode: 0,
              // radius: 232,
              align_h: hmUI.align.RIGHT,
              unit_type: 1,
              type: hmUI.data_type.SUN_SET,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sun_high_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 1,
              y: 1,
              w: 464,
              h: 464,
              text_size: 22,
              char_space: 0,
              font: 'fonts/Roboto-Black.ttf',
              color: 0xFFFFFFFF,
              // use_text_circle: true,
              start_angle: 0,
              end_angle: 180,
              mode: 0,
              // radius: 232,
              align_h: hmUI.align.CENTER_H,
              unit_type: 1,
              type: hmUI.data_type.SUN_RISE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_alarm_clock_current_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 10,
              y: 235,
              w: 150,
              h: 30,
              text_size: 29,
              char_space: 0,
              font: 'fonts/Roboto_A2-Black.ttf',
              color: 0xFFFFFFFF,
              line_space: 0,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.CENTER_H,
              padding: true,
              type: hmUI.data_type.ALARM_CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 74,
              y: 205,
              src: 'stat_AL.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            console.log('Watch_Face.ScreenAOD');
            idle_background_bg = hmUI.createWidget(hmUI.widget.FILL_RECT, {
              x: 0,
              y: 0,
              w: 466,
              h: 466,
              color: '0xFFD2D2D2',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            console.log('AOD_user_script.js');
            // start AOD_user_script.js
idle_M_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
 x: 0,
 y: 0,
  w: D_W,
  h: D_W,
 src: 'M_0.png',
auto_scale: true,
 show_level: hmUI.show_level.ONLY_AOD,
});
            // end AOD_user_script.js

            idle_digital_clock_img_time_hour = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 127,
              hour_startY: 144,
              hour_array: ["H_0.png","H_1.png","H_2.png","H_3.png","H_4.png","H_5.png","H_6.png","H_7.png","H_8.png","H_9.png"],
              hour_zero: 1,
              hour_space: -17,
              hour_angle: 0,
              hour_align: hmUI.align.LEFT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            console.log('user_script_beforeShortcuts.js');
            // start user_script_beforeShortcuts.js

normal_weather_circle_scale = hmUI.createWidget(hmUI.widget.ARC_PROGRESS, {
 center_x: D_W/2,
 center_y: D_W/2,
 start_angle: 84,
 end_angle: 20,
 radius: 217*kf,
 line_width: 6*kf,
 corner_flag: 3,
 color: 0xFFFFFFFF,
 type: hmUI.data_type.WEATHER_CURRENT,
 show_level: hmUI.show_level.ONLY_NORMAL,
});

normal_sun_circle_scale = hmUI.createWidget(hmUI.widget.ARC_PROGRESS, {
 center_x: D_W/2,
 center_y: D_W/2,
 start_angle: 80,
 end_angle: 25,
 radius: 217*kf,
 line_width: 6*kf,
 corner_flag: 3,
 color: 0xFFFFFFFF,
 show_level: hmUI.show_level.ONLY_NORMAL,
});


bg_edit_img = hmUI.createWidget(hmUI.widget.IMG, {
         x: 0,
         y: 0,
         src: 'tap/bg_edit.png',
         show_level: hmUI.show_level.ONLY_EDIT,
        });   
        
                if (screenTypeJS == hmSetting.screen_type.WATCHFACE) {
       groupTap = createTapInterface();
        
        groupVremya = hmUI.createWidget(hmUI.widget.GROUP, {
         x: 0,
         y: 0,
         w: D_W,
         h: D_H,
        }); //

        btn_tap = groupVremya.createWidget(hmUI.widget.BUTTON, {
         x: 96,
         y: 28,
         text: '',
         w: 100,
         h: 100,
         normal_src: '0_Empty.png',
         press_src: '0_Empty.png',
         click_func: () => {
          vibro();
          tap_run();
         },
         show_level: hmUI.show_level.ONLY_NORMAL,
        });

        btn_str = groupVremya.createWidget(hmUI.widget.BUTTON, {
         x: 183, //x кнопки
         y: 183, //y кнопки
         text: '',
         w: 100, //ширина кнопки
         h: 100, //высота кнопки
         normal_src: '0_Empty.png',
         press_src: '0_Empty.png',
         click_func: () => {
          vibro();
          click_Pogoda_on();
         },
         //           longpress_func: () => {
         //            vibro();
         //			   blok_btn_on();
         //           },
         show_level: hmUI.show_level.ONLY_NORMAL,
        });



        btn_click_tap_exit = groupTap.createWidget(hmUI.widget.BUTTON, {
         x: 183,
         y: 183,
         text: '',
         w: 100,
         h: 100,
         normal_src: '0_Empty.png',
         press_src: '0_Empty.png',
         click_func: () => {
          vibro();
          tap_zona_exit();
         },
         show_level: hmUI.show_level.ONLY_NORMAL,
        });



        normal_background_Pogoda = hmUI.createWidget(hmUI.widget.FILL_RECT, {
         x: 0,
         y: 0,
         w: D_W,
         h: D_W,
         color: 0x000000,
         show_level: hmUI.show_level.ONLY_NORMAL,
        });
        normal_background_Pogoda.setProperty(hmUI.prop.VISIBLE, false);

        //---------------------------    погода
        groupPogoda = hmUI.createWidget(hmUI.widget.GROUP, {
         x: 0,
         y: 0,
         w: D_W,
         h: D_H,
         show_level: hmUI.show_level.ONLY_NORMAL,
        });

        canvas = groupPogoda.createWidget(hmUI.widget.CANVAS, {
         x: 0,
         y: 0,
         w: 466,
         h: 466,
         show_level: hmUI.show_level.ONLY_NORMAL,
        });

        canvas.setPaint({
         color: 0x00ff00,
         line_width: 4
        })

        normal_temp_text_font = groupPogoda.createWidget(hmUI.widget.TEXT, {
         x: 115,
         y: 47 + 5 + 6 + 2 - 29 - 29,
         w: 236,
         h: 32,
         text_size: 27,
         char_space: 0,
         line_space: 0,
         font: 'fonts/Bebas22.ttf',
         color: 0xFFFFFFFF,
         align_h: hmUI.align.CENTER_H,
         align_v: hmUI.align.CENTER_V,
         text_style: hmUI.text_style.NONE,
         show_level: hmUI.show_level.ONLY_NORMAL,
        })

        normal_weather_text_font = groupPogoda.createWidget(hmUI.widget.TEXT, {
         x: 115,
         y: 47 + 5 + 6 + 2 - 29,
         w: 236,
         h: 32,
         text_size: 27,
         char_space: 0,
         line_space: 0,
         font: 'fonts/Bebas22.ttf',
         color: 0xFFFFFFFF,
         align_h: hmUI.align.CENTER_H,
         align_v: hmUI.align.CENTER_V,
         text_style: hmUI.text_style.NONE,
         show_level: hmUI.show_level.ONLY_NORMAL,
        })

        normal_city_name_text_0 = groupPogoda.createWidget(hmUI.widget.TEXT, {
         x: 74,
         y: 47 + 5 + 6 + 2,
         w: 318,
         h: 32,
         text_size: 27,
         char_space: 0,
         line_space: 0,
         font: 'fonts/Bebas22.ttf',
         color: 0xFFFFFFFF,
         align_h: hmUI.align.CENTER_H,
         align_v: hmUI.align.CENTER_V,
         text_style: hmUI.text_style.NONE,
         show_level: hmUI.show_level.ONLY_NORMAL,
        });

        ic_graf_img = groupPogoda.createWidget(hmUI.widget.IMG, {
         x: 414,
         y: 212,
         src: 'images/Grafik/ic_graf_0.png',
         show_level: hmUI.show_level.ONLY_NORMAL,
        });


        groupPogoda.createWidget(hmUI.widget.CIRCLE, {
         center_x: 31,
         center_y: 233,
         radius: 21,
         color: 0xbdbabd,
         // alpha: color_ic == 0 ? 0 : 255,
         show_level: hmUI.show_level.ONLY_NORMAL,
        });

        fix_gsm_text_font = groupPogoda.createWidget(hmUI.widget.TEXT, {
         x: 10,
         y: 212 + 2,
         w: 42,
         h: 42,
         text: fix_gsm == 0 ? '+0' : '+1',
         text_size: 27,
         char_space: 0,
         line_space: 0,
         font: 'fonts/Bebas22.ttf',
         color: 0x000000,
         align_h: hmUI.align.CENTER_H,
         align_v: hmUI.align.CENTER_V,
         text_style: hmUI.text_style.NONE,
         show_level: hmUI.show_level.ONLY_NORMAL,
        })

    windSpeedText = groupPogoda.createWidget(hmUI.widget.TEXT, {
         x: 0,
         y: 399,
         w: 466,
         h: 40,
         text_size: 35,
         char_space: 0,
         line_space: 0,
         color: 0xFFFFFFFF,
         font: 'fonts/Bebas22.ttf',
         align_h: hmUI.align.CENTER_H,
         align_v: hmUI.align.CENTER_V,
         unit_type: 1,
         text_style: hmUI.text_style.ELLIPSIS,
        // type: hmUI.data_type.WIND,
         show_level: hmUI.show_level.ONLY_NORMAL,
        });
        
  chanceOfRainText = groupPogoda.createWidget(hmUI.widget.TEXT, {
   x: 210,
   y: 357,
   w: 150,
   h: 40,
   // text: '100%',
   text_size: 35,
   char_space: 0,
   line_space: 0,
   color: 0xFFFFFFFF,
   font: 'fonts/Bebas22.ttf',
   align_h: hmUI.align.LEFT,
   align_v: hmUI.align.CENTER_V,
   unit_type: 1,
   text_style: hmUI.text_style.ELLIPSIS,
   // type: hmUI.data_type.HUMIDITY,
   show_level: hmUI.show_level.ONLY_NORMAL,
  });

  RainImg = groupPogoda.createWidget(hmUI.widget.IMG, {
   x: 169,
   y: 359,
   src: 'images/Grafik/ic_activ/ic_rain_on.png',
   show_level: hmUI.show_level.ONLY_NORMAL,
  });

  groupPogoda.createWidget(hmUI.widget.IMG, {
   x: 285,
   y: 360,
   src: ROOTPATH + 'Grafik/ic_activ/ic_davl_txt.png',
   show_level: hmUI.show_level.ONLY_NORMAL,
  });

  groupPogoda.createWidget(hmUI.widget.IMG_LEVEL, {
   x: 12,
   y: 166,
   image_array: ["images/Grafik/ic_activ/uv_0.png", "images/Grafik/ic_activ/uv_1.png", "images/Grafik/ic_activ/uv_2.png", "images/Grafik/ic_activ/uv_3.png", "images/Grafik/ic_activ/uv_4.png"],
   image_length: 5,
   type: hmUI.data_type.UVI,
   show_level: hmUI.show_level.ONLY_NORMAL,
  });

  groupPogoda.createWidget(hmUI.widget.IMG_LEVEL, {
   x: 66,
   y: 358,
   image_array: ["images/Grafik/ic_activ/vl_0.png", "images/Grafik/ic_activ/vl_1.png", "images/Grafik/ic_activ/vl_2.png", "images/Grafik/ic_activ/vl_3.png", "images/Grafik/ic_activ/vl_4.png", "images/Grafik/ic_activ/vl_5.png", "images/Grafik/ic_activ/vl_6.png", "images/Grafik/ic_activ/vl_7.png", "images/Grafik/ic_activ/vl_8.png", "images/Grafik/ic_activ/vl_9.png"],
   image_length: 10,
   type: hmUI.data_type.HUMIDITY,
   show_level: hmUI.show_level.ONLY_NORMAL,
  });


  groupPogoda.createWidget(hmUI.widget.TEXT_FONT, {
   x: -43,
   y: 265 + 5,
   w: 150,
   h: 30,
   text_size: 27,
   font: 'fonts/Bebas22.ttf',
   char_space: 0,
   line_space: 0,
   color: 0xFFFFFFFF,
   align_h: hmUI.align.CENTER_H,
   align_v: hmUI.align.CENTER_V,
   text_style: hmUI.text_style.ELLIPSIS,
   type: hmUI.data_type.UVI,
   show_level: hmUI.show_level.ONLY_NORMAL,
  });

        groupPogoda.createWidget(hmUI.widget.IMG, {
         x: 420,
         y: 171,
         src: ROOTPATH + 'Grafik/ic_activ/ic_visota.png',
         show_level: hmUI.show_level.ONLY_NORMAL,
        });

        groupPogoda.createWidget(hmUI.widget.TEXT_FONT, {
         x: 359,
         y: 265 + 5,
         w: 150,
         h: 30,
         text_size: 27,
         font: 'fonts/Bebas22.ttf',
         char_space: 0,
         line_space: 0,
         color: 0xFFFFFFFF,
         align_h: hmUI.align.CENTER_H,
         align_v: hmUI.align.CENTER_V,
         text_style: hmUI.text_style.ELLIPSIS,
         type: hmUI.data_type.ALTITUDE,
         show_level: hmUI.show_level.ONLY_NORMAL,
        });

        text_pressere = groupPogoda.createWidget(hmUI.widget.TEXT, {
         x: 347,
         y: 357,
         w: 150,
         h: 40,
         color: 0xffffff,
         font: 'fonts/Bebas22.ttf',
         text_size: 35,
         align_h: hmUI.align.LEFT,
         align_v: hmUI.align.CENTER_V,
         text_style: hmUI.text_style.NONE,
         text: "--",
        });


        groupPogoda.createWidget(hmUI.widget.TEXT_FONT, {
         x: 97,
         y: 357,
         w: 150,
         h: 40,
         text_size: 35,
         char_space: 0,
         line_space: 0,
         color: 0xFFFFFFFF,
         font: 'fonts/Bebas22.ttf',
         align_h: hmUI.align.LEFT,
         align_v: hmUI.align.CENTER_V,
         unit_type: 1,
         text_style: hmUI.text_style.ELLIPSIS,
         type: hmUI.data_type.HUMIDITY,
         show_level: hmUI.show_level.ONLY_NORMAL,
        });


        for (var i = 0; i < dney; i++) {
         week_text[i] = groupPogoda.createWidget(hmUI.widget.TEXT, {
          x: x0 - 3 - 23 + i * 46 * 1.0, //,107 + i * 45 * 1.02,
          y: 295 - 1 + 2, //- 21
          w: 50,
          h: 50,
          char_space: 0, //-1
          line_space: 0,
          color: "0xFFffffff",
          text: week_array[i],
          text_size: 22,
          text_style: hmUI.text_style.NONE,
          align_h: hmUI.align.CENTER_H,
          align_v: hmUI.align.CENTER_V,
          show_level: hmUI.show_level.ONLY_NORMAL
         });
         // hmUI.deleteWidget(data_text[i]);
         data_text[i] = groupPogoda.createWidget(hmUI.widget.TEXT, {
          x: x0 - 3 - 23 + i * 46 * 1.0, //,107 + i * 45 * 1.02,
          y: 295 - 1 + 2 + 20, //- 21
          w: 50,
          h: 50,

          char_space: 0, //-1
          line_space: 0,
          color: "0xFFffffff",
          text: 31,
          text_size: 22,
          text_style: hmUI.text_style.NONE,
          align_h: hmUI.align.CENTER_H,
          align_v: hmUI.align.CENTER_V,
          show_level: hmUI.show_level.ONLY_NORMAL
         });

         weather_ic[i] = groupPogoda.createWidget(hmUI.widget.IMG, {
          x: x0 - 23 + i * shag,
          y: 78 + 10, //- 10
          w: 40,
          h: 40,
          // src: weatherArray[i],
          shortcut: true,
          show_level: hmUI.show_level.ONLY_NORMAL,
         });

         DigDay[i] = groupPogoda.createWidget(hmUI.widget.TEXT);
         if (i < dney - 1) DigNight[i] = groupPogoda.createWidget(hmUI.widget.TEXT);

        }


        btn_Pogoda_off = groupPogoda.createWidget(hmUI.widget.BUTTON, {
         x: 183, //x кнопки
         y: 183, //y кнопки
         text: '',
         w: 100, //ширина кнопки
         h: 100, //высота кнопки
         normal_src: '0_Empty.png',
         press_src: 'press_100.png',
         click_func: () => {
          vibro(); //имя вызываемой функции
          click_Pogoda_off();
         },
         //           longpress_func: () => {
         //            vibro();
         //			   blok_btn_off();
         //           },
         show_level: hmUI.show_level.ONLY_NORMAL,
        });

        btn_tip_grafik = groupPogoda.createWidget(hmUI.widget.BUTTON, {
         x: 366, //x кнопки
         y: 183, //y кнопки
         text: '',
         w: 100, //ширина кнопки
         h: 100, //высота кнопки
         normal_src: '0_Empty.png',
         press_src: 'press_100.png',
         click_func: () => {
          vibro(); //имя вызываемой функции
          click_tip_grafik();
         },
         //           longpress_func: () => {
         //            vibro();
         //			   blok_btn_off();
         //           },
         show_level: hmUI.show_level.ONLY_NORMAL,
        });

        groupPogoda.createWidget(hmUI.widget.BUTTON, {
         x: 0,
         y: 183,
         w: 100,
         h: 100,
         text: '',
         normal_src: 'blank.png',
         press_src: 'images/Grafik/press_100.png',
         click_func: () => {

          vibro(); //имя вызываемой функции
          click_fix_gms();

          //          hmApp.startApp({
          //           appid: 1051195,
          //           url: 'page/index',
          //           params: {
          //            from_wf: true,
          //           }
          //          });

         },
        });



        g_ACR_panel = hmUI.createWidget(hmUI.widget.GROUP, {
         x: 0,
         y: 0,
         w: D_W,
         h: D_H,
        })

        //цвет	
        menu_ARC_PROGRES_bg = g_ACR_panel.createWidget(hmUI.widget.ARC_PROGRESS, {
         center_x: 233,
         center_y: 233,
         start_angle: 60 - 15,
         end_angle: 120 + 15,
         radius: 219 + 8,
         line_width: 8,
         corner_flag: 0,
         color: 0xFF5b5b5b,
         level: 100,
         show_level: hmUI.show_level.ONLY_NORMAL,
        });

        menu_ARC_PROGRES = g_ACR_panel.createWidget(hmUI.widget.ARC_PROGRESS, {
         center_x: 233,
         center_y: 233,
         start_angle: 45 + 90 / CONF_MAIN[0].len * (-CONF_MAIN[0].id * 95), // start_angle: 45 + 90 / array * gde,
         end_angle: 135 + 90 / CONF_MAIN[0].len * (-CONF_MAIN[0].id * 95), //end_angle: 135 + 90 / array * gde,
         radius: 219,
         line_width: 16,
         corner_flag: 0,
         color: 0xFF0000, //0xFF007eff
         level: 100 / CONF_MAIN[0].len, //level: pointer,
         show_level: hmUI.show_level.ONLY_NORMAL,
        });
        g_ACR_panel.setProperty(hmUI.prop.VISIBLE, false);


        g_ACR_color_PROGRES = hmUI.createWidget(hmUI.widget.GROUP, {
         x: 0,
         y: 0,
         w: D_W,
         h: D_H,
        })

        for (let i = 0; i < ARC_set.length; i++) {
         menu_ARC_color[i] = g_ACR_color_PROGRES.createWidget(hmUI.widget.CIRCLE, {
          center_x: ARC_set[i][0],
          center_y: ARC_set[i][1],
          radius: ARC_set[i][2] / 2,
          color: color_bg[0][i],
          alpha: 255,
          show_level: hmUI.show_level.ONLY_NORMAL,
         });
        };

        CIRCLE_select = g_ACR_color_PROGRES.createWidget(hmUI.widget.ARC_PROGRESS, {
         center_x: ARC_set[4][0],
         center_y: ARC_set[4][1],
         radius: ARC_set[4][2] / 2 + 6,
         start_angle: 0,
         end_angle: 360,
         line_width: 6,
         corner_flag: 3,
         color: 0xff0000,
         //alpha: 255,
         level: 100,
         show_level: hmUI.show_level.ONLY_NORMAL,
        });

        g_ACR_color_PROGRES.setProperty(hmUI.prop.VISIBLE, false);
					
       
        bg_app_text = hmUI.createWidget(hmUI.widget.FILL_RECT, {
        // x: crown == 1 ? 233 - 163 : 233 + 163,
        x: 68,
         y: 4+text_start,
         w: 331,
         h: Line_arr.length/2 * 21 + 21 / 2,
         color: 0x000000,
         alpha: 178,
         show_level: hmUI.show_level.ONLY_NORMAL,
        });
        
        
        bg_app_text.setProperty(hmUI.prop.VISIBLE, false);

        for (let i = 0; i < Line_arr.length; i++) {
         app_ACR_text[i] = hmUI.createWidget(hmUI.widget.TEXT, {
//          x: crown == 1 ? 233 - 166 : 233 + 166,
//          y: 70 + 25 + i * 21 - 22,
                        x: i<Line_arr.length/2 ? 68:233,
                        y: i<Line_arr.length/2 ? text_start + i*21 : text_start + (i-Line_arr.length/2)*21,
          w: 166,
          h: 30,
          text: Line_arr[i][3],
          text_size: 21,
          char_space: 0,
          line_space: 0,
          //font: 'fonts/Bebas22.ttf',
          color: CONF_MAIN[1].id == i ? 0xff0000 : 0xffffff,
          align_h: hmUI.align.CENTER_H,
          align_v: hmUI.align.CENTER_V,
          text_style: hmUI.text_style.NONE,
          show_level: hmUI.show_level.ONLY_NORMAL,
         });
         app_ACR_text[i].setProperty(hmUI.prop.VISIBLE, false);
        };
        
        bg_app_text.setProperty(hmUI.prop.VISIBLE, false);	
					
					
	//updateButtons();				
					
					
            // end user_script_beforeShortcuts.js

            console.log('Watch_Face.Buttons');
            Button_1 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 366,
              y: 183,
              w: 100,
              h: 100,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '0.png',
              normal_src: '0.png',
              click_func: (button_widget) => {
                click_right();
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_2 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 0,
              y: 183,
              w: 100,
              h: 100,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '0.png',
              normal_src: '0.png',
              click_func: (button_widget) => {
                click_left();

              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_3 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 278,
              y: 347,
              w: 100,
              h: 100,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '0.png',
              normal_src: '0.png',
              click_func: (button_widget) => {
                clik_block();
 vibro();
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            console.log('user_script_end.js');
            // start user_script_end.js



        g_Set = hmUI.createWidget(hmUI.widget.GROUP, {
         x: 0,
         y: 0,
         w: D_W,
         h: D_H,
        })

        normal_background_Set = g_Set.createWidget(hmUI.widget.FILL_RECT, {
         x: 0,
         y: 0,
         w: D_W,
         h: D_H,
         color: 0x000000,
         // radius: 12,
         alpha: 153,
         show_level: hmUI.show_level.ONLY_NORMAL,
        });

        for (let i = 0; i < CONF_MAIN.length; i++) {
         Btn_set_[i] = g_Set.createWidget(hmUI.widget.BUTTON, {
          x: CONF_MAIN.length <= 5 ? 153 : i < Math.ceil(CONF_MAIN.length / 2) ? 70 : D_W/2,
          y: CONF_MAIN.length <= 5 ? 70 + i * Shag_Y : i < Math.ceil(CONF_MAIN.length / 2) ? 70 + i * Shag_Y : 70 + i * Shag_Y - Shag_Y * Math.ceil(CONF_MAIN.length / 2),
          w: 160,
          h: 60,
          text: CONF_MAIN[i].name,
          char_space: 0,
          line_space: -35,
          color: 0xFFFFFFFF,
          text_size: 24,
          radius: 12,
          press_color: 0xFFFF0000,
          normal_color: i != crown ? 0x000000 : 0x800000,
          click_func: () => {
           vibro();
           click_crown(i);
          },
          text_style: hmUI.text_style.WRAP,
          show_level: hmUI.show_level.ONLY_NORMAL,
         }); // end button
        };

        btn_Set_exit = g_Set.createWidget(hmUI.widget.BUTTON, {
         x: 203, //x кнопки
         y: 70 + Shag_Y * 5, //y кнопки
         w: 60,
         h: 60,
         text: "ОК",
         char_space: 0,
         line_space: -35,
         color: 0xFFFFFFFF,
         text_size: 24,
         radius: 12,
         press_color: 0xFFFF0000,
         normal_color: 0xFF000000,
         click_func: () => {
          vibro();
          click_Set_off();
         },
         text_style: hmUI.text_style.WRAP,
         show_level: hmUI.show_level.ONLY_NORMAL,
        });
        g_Set.setProperty(hmUI.prop.VISIBLE, false);

        btn_crown = groupVremya.createWidget(hmUI.widget.BUTTON, {
         x: 270, //x кнопки
         y: 28, //y кнопки
         text: '',
         w: 100, //ширина кнопки
         h: 100, //высота кнопки
         normal_src: '0_Empty.png',
         press_src: '0_Empty.png',
         click_func: () => {
          // vibro();
          click_Set_on();
         },
         //           longpress_func: () => {
         //            vibro();
         //			   blok_btn_on();
         //           },
         show_level: hmUI.show_level.ONLY_NORMAL,
        });



        g_btn_crown = hmUI.createWidget(hmUI.widget.GROUP, {
         x: 0,
         y: 0,
         w: D_W,
         h: D_H,
        })
        
g_btn_crown.createWidget(hmUI.widget.TEXT, {
  x: 14,
  y: 14,
  w: (D_W - 14 * 2),
  h: (D_H - 14 * 2),
  text_size: 33,
        color: 0xffffff,
  text: "←",
  font: 'fonts/Bebas22.ttf',
  align_h: hmUI.align.CENTER_H,
  char_space: 1,
  start_angle: 37-90,
  end_angle: 37+90,
  show_level: hmUI.show_level.ONLY_NORMAL,	
})	
        
g_btn_crown.createWidget(hmUI.widget.TEXT, {
  x: 14,
  y: 14,
  w: (D_W - 14 * 2),
  h: (D_H - 14 * 2),
  text_size: 33,
        color: 0xffffff,
  text: "→",
  font: 'fonts/Bebas22.ttf',
  align_h: hmUI.align.CENTER_H,
  char_space: 1,
  start_angle: 143-90,
  end_angle: 143+90,
  show_level: hmUI.show_level.ONLY_NORMAL,	
})        
				
        normal_background_btn_crown = g_btn_crown.createWidget(hmUI.widget.FILL_RECT, {
         x: 0,
         y: 0,
         w: D_W,
         h: D_H,
         color: 0x000000,
         alpha: 0,
         show_level: hmUI.show_level.ONLY_NORMAL,
        });
	        
        btn_crown_left = g_btn_crown.createWidget(hmUI.widget.BUTTON, {
         x: 305, //x кнопки
         y: 31, //y кнопки
         w: 100,
         h: 100,
         //text: "<<",
         char_space: 0,
         line_space: -35,
         color: 0xFFFFFFFF,
         text_size: 50,
         radius: 12,
         normal_src: '0_Empty.png',
         press_src: '0_Empty.png',
         //         press_color: 0xFFFF0000,
         //         normal_color: 0xFF800000,
         click_func: () => {
          vibro();
          click_btn_crown_left();
         },
         text_style: hmUI.text_style.WRAP,
         show_level: hmUI.show_level.ONLY_NORMAL,
        });	
				
        btn_crown_right = g_btn_crown.createWidget(hmUI.widget.BUTTON, {
         x: 305, //x кнопки
         y: 335, //y кнопки
         w: 100,
         h: 100,
         //text: ">>",
         char_space: 0,
         line_space: -35,
         color: 0xFFFFFFFF,
         text_size: 50,
         radius: 12,
             normal_src: '0_Empty.png',
             press_src: '0_Empty.png',
//         press_color: 0xFFFF0000,
//         normal_color: 0xFF800000,
         click_func: () => {
          vibro();
          click_btn_crown_right();
         },
         text_style: hmUI.text_style.WRAP,
         show_level: hmUI.show_level.ONLY_NORMAL,
        });		

        btn_crown_exit = g_btn_crown.createWidget(hmUI.widget.BUTTON, {
         x: 203, //x кнопки
         y: 400, //y кнопки
         w: 60,
         h: 60,
         text: "ОК",
         char_space: 0,
         line_space: -35,
         color: 0xFFFFFFFF,
         text_size: 24,
         radius: 12,
         press_color: 0xFFFF0000,
         normal_color: 0xFF800000,
         click_func: () => {
          vibro();
          click_btn_crown_exit();
         },
         text_style: hmUI.text_style.WRAP,
         show_level: hmUI.show_level.ONLY_NORMAL,
        });
        g_btn_crown.setProperty(hmUI.prop.VISIBLE, false);					


        groupVremya.setProperty(hmUI.prop.VISIBLE, true);
        groupTap.setProperty(hmUI.prop.VISIBLE, false);
        groupPogoda.setProperty(hmUI.prop.VISIBLE, false);
//        groupActiv.setProperty(hmUI.prop.VISIBLE, false);
//        groupSleep.setProperty(hmUI.prop.VISIBLE, false);
        
          };  // end screenType
          
                
      const weatherProvider = new WeatherProvider({
       //				night_icons: [0, 1, 2, 3, 14],
       index: 1, // текущий индекс провайдера (сохраняется и считывается из памяти)
       //				show_toast: false,
       //				temp_widget: tempText,
       //				temp_max_widget: tempMaxText,
       //				temp_min_widget: tempMinText,
       // temp_feels_widget: tempFeelsText,


       //			icon_widget_Rain: RainImg,
       //			chance_Of_Rain: chanceOfRainText,
       //			chance_Of_Rain2: normal_voshod_text_font,
       //			chance_Of_Rain3: normal_rain_font,
       //			windSpeed_widget: windSpeedText,


       //				description_widget: descriptionText,
       //				cityName_widget: cityNameText,
       //				icon_widget: weatherImg,
       //				time_sensor: curTime,
       //				weather_sensor: weather,
      });  
      




    normal_block_FILL_RECT = hmUI.createWidget(hmUI.widget.FILL_RECT, {
     x: 0,
     y: 0,
     w: D_W,
     h: D_W,
     color: 0x000000,
     alpha: 0,
     show_level: hmUI.show_level.ONLY_NORMAL,
    });
    normal_block_FILL_RECT.setProperty(hmUI.prop.VISIBLE, block == 1);

    btn_block = hmUI.createWidget(hmUI.widget.BUTTON, {
     x: 278 * kf,
     y: 347 * kf,
     text: '',
     w: 100 * kf,
     h: 100 * kf,
     normal_src: '0_Empty.png',
     press_src: '0_Empty.png',
	click_func: (button_widget) => {
		//vibro();
        hmUI.showToast({text: "Для разблокировки нужно долгое нажатие",});
		 },				  
     longpress_func: () => {
      // vibro();
	//MenuCirkl_Timer_on(3) 
		vibro();
      clik_block();
     },
     show_level: hmUI.show_level.ONLY_NORMAL,
    });
    btn_block.setProperty(hmUI.prop.VISIBLE, block == 1);
normal_widget_text_2.setProperty(hmUI.prop.TEXT, block == 0 ? '{' : '}');

start_WG()



                
            // end user_script_end.js

            //#region time_update
            function time_update(updateHour = false, updateMinute = false) {
              console.log('time_update()');
              let hour = timeSensor.hour;
              let minute = timeSensor.minute;
              let second = timeSensor.second;
              let format_hour = timeSensor.format_hour;

              console.log('month font');
              if (updateHour) {
                let normal_Month_Str = normal_Month_Array[timeSensor.month-1];
                normal_month_name_font.setProperty(hmUI.prop.TEXT, normal_Month_Str );
              };

              console.log('day of week font');
              if (updateHour) {
                let normal_DOW_Str = normal_DOW_Array[timeSensor.week-1];
                normal_dow_text_font.setProperty(hmUI.prop.TEXT, normal_DOW_Str );
              };

              console.log('day font');
              if (updateHour) {
                let normal_dayStr = timeSensor.day.toString();
                normal_dayStr = normal_dayStr.padStart(2, '0');
                normal_day_text_font.setProperty(hmUI.prop.TEXT, normal_dayStr );
              };

            };

            //#endregion
            function scale_call() {
              console.log('scale_call()');

                console.log('update scales STEP');
                
                let valueStep = step.current;
                let targetStep = step.target;
                let progressStep = valueStep/targetStep;
                if (progressStep > 1) progressStep = 1;
                let progress_cs_normal_step = progressStep;

                if (screenType != hmSetting.screen_type.AOD) {

                  // normal_step_circle_scale_circle_scale
                  let level = Math.round(progress_cs_normal_step * 100);
                  if (normal_step_circle_scale) {
                    normal_step_circle_scale.setProperty(hmUI.prop.MORE, {                      
                      center_x: 233,
                      center_y: 233,
                      start_angle: 167,
                      end_angle: 103,
                      radius: 217,
                      line_width: 6,
                      corner_flag: 3,
                      color: 0xFFFFFFFF,
                      show_level: hmUI.show_level.ONLY_NORMAL,
                      level: level,
                    });
                  };
                };

                console.log('update scales BATTERY');
                
                let valueBattery = battery.current;
                let targetBattery = 100;
                let progressBattery = valueBattery/targetBattery;
                if (progressBattery > 1) progressBattery = 1;
                let progress_cs_normal_battery = progressBattery;

                if (screenType != hmSetting.screen_type.AOD) {

                  // normal_battery_circle_scale_circle_scale
                  let level = Math.round(progress_cs_normal_battery * 100);
                  if (normal_battery_circle_scale) {
                    normal_battery_circle_scale.setProperty(hmUI.prop.MORE, {                      
                      center_x: 233,
                      center_y: 233,
                      start_angle: 283,
                      end_angle: 347,
                      radius: 217,
                      line_width: 6,
                      corner_flag: 3,
                      color: 0xFFFFFFFF,
                      show_level: hmUI.show_level.ONLY_NORMAL,
                      level: level,
                    });
                  };
                };

                console.log('update scales CALORIE');
                
                let valueCalories = calorie.current;
                let targetCalories = calorie.target;
                let progressCalories = valueCalories/targetCalories;
                if (progressCalories > 1) progressCalories = 1;
                let progress_cs_normal_calorie = progressCalories;

                if (screenType != hmSetting.screen_type.AOD) {

                  // normal_calorie_circle_scale_circle_scale
                  let level = Math.round(progress_cs_normal_calorie * 100);
                  if (normal_calorie_circle_scale) {
                    normal_calorie_circle_scale.setProperty(hmUI.prop.MORE, {                      
                      center_x: 233,
                      center_y: 233,
                      start_angle: 77,
                      end_angle: 13,
                      radius: 217,
                      line_width: 6,
                      corner_flag: 3,
                      color: 0xFFFFFFFF,
                      show_level: hmUI.show_level.ONLY_NORMAL,
                      level: level,
                    });
                  };
                };

            };

            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                console.log('resume_call()');
                scale_call();
                time_update(true, true);

                console.log('resume_call.js');
                // start resume_call.js

  loadSettings();
  autoToggleWeatherIcons();

  time_update2(true, true);
  //if (screenTypeJS == hmSetting.screen_type.WATCHFACE) {
   if (!normal_timerTimeUpdate2) {
    normal_timerTimeUpdate2 = timer.createTimer(0, 1000, (function (option) {
     let updateHour = timeSensor.minute == 0 && timeSensor.second < 2;
     let updateMinute = timeSensor.second < 2;
     time_update2(updateHour, updateMinute);
    })); // end timer 
   }; // end timer check
 // }; // end screenType


  if (screenTypeJS == hmSetting.screen_type.WATCHFACE) {
   //  updateTime();
   //  normal_temperature_current_text_font.setProperty(hmUI.prop.TEXT, weatherProvider.temperature + "°");
   //       normal_temperature_high_text_font.setProperty(hmUI.prop.TEXT, "Д:" + weatherProvider.temperatureMax + "°");
   //       normal_temperature_low_text_font.setProperty(hmUI.prop.TEXT, "Н:" + weatherProvider.temperatureMin + "°");
   // normal_widget_text_3.setProperty(hmUI.prop.VISIBLE, hmBle.connectStatus());

   chanceOfRainText.setProperty(hmUI.prop.TEXT, weatherProvider.chanceOfRain + '%');
   RainImg.setProperty(hmUI.prop.SRC, weatherProvider.chanceOfRain.replace('%', '') >= 50 ? 'images/Grafik/ic_activ/ic_rain_on.png' : 'images/Grafik/ic_activ/ic_rain_off.png');
   let Direction = weatherProvider.windDirection
   windSpeedText.setProperty(hmUI.prop.TEXT, getWindDescription(Direction, 0) + " " + weatherProvider.windSpeed + ' м/с');
   //       Line_arr[11][1] = weatherProvider.chanceOfRain + '%';
   //       Line_arr[11][4] = weatherProvider.chanceOfRain.replace('%', '') >= 50 ? 0xff0000 : 0x00ff00;
   //       Line_arr[12][1] = weatherProvider.temperatureFeels;
   //       Line_arr[13][1] = getWindDescription(Direction, 2) + " " + weatherProvider.windSpeed;


  }


  // app_update();


  //updateSleep();
update_app();
  updatePressere();
  //updateGrafik();
  click_Pogoda_off();
  setTimeout(() => {
   onDigitalCrown();
  }, 1000);
  setTimeout(() => {
   onKeyEvent();
  }, 1000);

  stopVibro();

                // end resume_call.js

              }),
              pause_call: (function () {
                console.log('pause_call()');

                console.log('pause_call.js');
                // start pause_call.js

vibrate.stop();
          hmApp.unregisterSpinEvent();
          offKeyEvent()
          normal_background_Pogoda.setProperty(hmUI.prop.VISIBLE, false);
          groupTap.setProperty(hmUI.prop.VISIBLE, false);
          groupVremya.setProperty(hmUI.prop.VISIBLE, true);
          groupPogoda.setProperty(hmUI.prop.VISIBLE, false);
/*          groupActiv.setProperty(hmUI.prop.VISIBLE, false);
          groupSleep.setProperty(hmUI.prop.VISIBLE, false);*/

                if (normal_timerTimeUpdate2) {
                  timer.stopTimer(normal_timerTimeUpdate2);
                  normal_timerTimeUpdate2 = undefined;
                }
                // end pause_call.js

              }),
            });

                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}