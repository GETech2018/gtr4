﻿    /*
     ** Watch_Face_Editor tool
     ** watchface js version v2.1.1
     ** Copyright © SashaCX75. All Rights Reserved
     */

    try {
     (() => {
      //start of ignored block
      const __$$app$$__ = __$$hmAppManager$$__.currentApp;

      function getApp() {
       return __$$app$$__.app;
      }

      function getCurrentPage() {
       return __$$app$$__.current && __$$app$$__.current.module;
      }
      const __$$module$$__ = __$$app$$__.current;
      const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
      const {
       px
      } = __$$app$$__.__globals__;
      const logger = Logger.getLogger('watchface_SashaCX75');
      //end of ignored block

      //dynamic modify start


      let normal_background_bg = ''
      let normal_image_img = ''
      let normal_analog_clock_pro_hour_pointer_img = ''
      let normal_analog_clock_pro_minute_pointer_img = ''
      let normal_analog_clock_pro_second_pointer_img = ''
      let normal_timerUpdateSec = undefined;
      let normal_stress_icon_img = ''
      let normal_digital_clock_img_time_second = ''
      let timeSensor = '';
      let normal_dow_text_font = ''
      let normal_DOW_Array = ['ПНД', 'ВТР', 'СРД', 'ЧТВ', 'ПТН', 'СБТ', 'ВСК'];
      let normal_day_month_font = ''
      let groupData = ''
      let groupStep = ''
      let normal_day_STEP_TEXT_FONT = ''
      let normal_day_STEP_unit = ''
	  
	  
         let centerX = 233; // Координата X центра круга
         let centerY = 233; // Координата Y центра круга
         let rectangleWidth = 60;
         let rectangleHeight = 46;
		 
		 function getRectangleCoordinates(diameter, time_now) {
         //let diameter = 402;
         let radius = diameter / 2;
         let angle = -90 * 3.14 / 180; // Начальный угол в радианах\градусах

         angle = angle + time_now * 3.14 / 180; // Увеличение угла 

         // Вычисляем координаты центра прямоугольника
         let centerXRectangle = centerX + (radius * Math.cos(angle));
         let centerYRectangle = centerY + (radius * Math.sin(angle));

         // Вычисляем координаты углов прямоугольника
         let x1 = centerXRectangle - (rectangleWidth / 2);
         let y1 = centerYRectangle - (rectangleHeight / 2);

         return {
          topLeft: {
           x: x1,
           y: y1
          }
         };
        };
	  
	  
	  

      //dynamic modify end

      __$$module$$__.module = DeviceRuntimeCore.WatchFace({
       init_view() {
        //dynamic modify start


        // FontName: PulpDisplay_Light.ttf; FontSize: 18
        hmUI.createWidget(hmUI.widget.TEXT, {
         x: 464,
         y: 464,
         w: 244,
         h: 26,
         text_size: 18,
         char_space: 0,
         line_space: 0,
         font: 'fonts/PulpDisplay_Light.ttf',
         color: 0xFF33DE9C,
         align_h: hmUI.align.CENTER_H,
         align_v: hmUI.align.CENTER_V,
         text_style: hmUI.text_style.ELLIPSIS,
         text: "0123456789 _-.,:;`'%°\\/",
         show_level: hmUI.show_level.ONLY_NORMAL,
        });

        hmUI.createWidget(hmUI.widget.TEXT, {
         x: 464,
         y: 464,
         w: 244,
         h: 26,
         text_size: 32,
         char_space: 0,
         line_space: 0,
         font: 'fonts/PulpDisplay_Light.ttf',
         color: 0xFF33DE9C,
         align_h: hmUI.align.CENTER_H,
         align_v: hmUI.align.CENTER_V,
         text_style: hmUI.text_style.ELLIPSIS,
         text: "0123456789 _-.,:;`'%°\\/",
         show_level: hmUI.show_level.ONLY_NORMAL,
        });
		   
        hmUI.createWidget(hmUI.widget.TEXT, {
         x: 464,
         y: 464,
         w: 300,
         h: 28,
         text_size: 20,
         char_space: 0,
         line_space: 0,
         font: 'fonts/PulpDisplay_ExtraBold.ttf',
         color: 0xFF33DE9C,
         align_h: hmUI.align.CENTER_H,
         align_v: hmUI.align.CENTER_V,
         text_style: hmUI.text_style.ELLIPSIS,
         text: "0123456789 _-.,:;`'%°\\/",
         show_level: hmUI.show_level.ONLY_NORMAL,
        });
		   


        console.log('Watch_Face.ScreenNormal');
        normal_background_bg = hmUI.createWidget(hmUI.widget.FILL_RECT, {
         x: 0,
         y: 0,
         w: 466,
         h: 466,
         color: '0xFF000000',
         show_level: hmUI.show_level.ONLY_NORMAL,
        });

        normal_image_img = hmUI.createWidget(hmUI.widget.IMG, {
         x: 0,
         y: 0,
         src: 'bg.png',
         show_level: hmUI.show_level.ONLY_NORMAL,
        });



        const deviceInfo = hmSetting.getDeviceInfo();
        if (!timeSensor) timeSensor = hmSensor.createSensor(hmSensor.id.TIME);
        timeSensor.addEventListener(timeSensor.event.MINUTEEND, function () {
         let updateHour = timeSensor.minute == 0;

         time_update(updateHour, true);
        });
		   
        groupData = hmUI.createWidget(hmUI.widget.GROUP, {
         x: 193,
         y: 352,
         w: 60,
         h: 46,
        }); // 	

        normal_day_month_font = groupData.createWidget(hmUI.widget.TEXT, {
         x: 0,
         y: -11,
         w: 60,
         h: 46,
          text: '--',
         text_size: 20,
         char_space: 0,
         line_space: 0,
         font: 'fonts/PulpDisplay_ExtraBold.ttf',
         color: 0xFF33DE9C,
         align_h: hmUI.align.CENTER_H,
         align_v: hmUI.align.CENTER_V,
         text_style: hmUI.text_style.ELLIPSIS,
         // unit_string: .,
         show_level: hmUI.show_level.ONLY_NORMAL,
        });

        normal_dow_text_font = groupData.createWidget(hmUI.widget.TEXT, {
         x: 0,
         y: 11,
         w: 60,
         h: 46,
         text_size: 20,
          text: '--',
         char_space: 0,
         line_space: 0,
         color: 0xFF33DE9C,
         align_h: hmUI.align.CENTER_H,
         align_v: hmUI.align.CENTER_V,
         text_style: hmUI.text_style.ELLIPSIS,
         // unit_string: ПНД, ВТР, СРД, ЧТВ, ПТН, СБТ, ВСК,
         show_level: hmUI.show_level.ONLY_NORMAL,
        });		
		   
        groupStep = hmUI.createWidget(hmUI.widget.GROUP, {
         x: 193,
         y: 352,
         w: 60,
         h: 46,
        }); // 	

        normal_day_STEP_TEXT_FONT = groupStep.createWidget(hmUI.widget.TEXT_FONT, {
         x: 0,
         y: -11,
         w: 60,
         h: 46,
         text_size: 20,
         char_space: 0,
         line_space: 0,
         font: 'fonts/PulpDisplay_ExtraBold.ttf',
         color: 0xFF33DE9C,
         align_h: hmUI.align.CENTER_H,
         align_v: hmUI.align.CENTER_V,
         text_style: hmUI.text_style.ELLIPSIS,
         type: hmUI.data_type.STEP,
         show_level: hmUI.show_level.ONLY_NORMAL,
        });

        normal_day_STEP_unit = groupStep.createWidget(hmUI.widget.TEXT, {
         x: 0,
         y: 11,
         w: 60,
         h: 46,
         text_size: 20,
         text: 'Шаги',
         char_space: 0,
         line_space: 0,
         color: 0xFF33DE9C,
         align_h: hmUI.align.CENTER_H,
         align_v: hmUI.align.CENTER_V,
         text_style: hmUI.text_style.ELLIPSIS,
         // unit_string: ПНД, ВТР, СРД, ЧТВ, ПТН, СБТ, ВСК,
         show_level: hmUI.show_level.ONLY_NORMAL,
        });
		   
		   
		   



        normal_analog_clock_pro_hour_pointer_img = hmUI.createWidget(hmUI.widget.IMG, {
         x: 0,
         y: 0,
         w: deviceInfo.width,
         h: deviceInfo.height,
         pos_x: 233 - 233,
         pos_y: 233 - 233,
         center_x: 233,
         center_y: 233,
         src: 'str_H_0.png',
         angle: 0,
         show_level: hmUI.show_level.ONLY_NORMAL,
        });



        normal_analog_clock_pro_minute_pointer_img = hmUI.createWidget(hmUI.widget.IMG, {
         x: 0,
         y: 0,
         w: deviceInfo.width,
         h: deviceInfo.height,
         pos_x: 233 - 233,
         pos_y: 233 - 233,
         center_x: 233,
         center_y: 233,
         src: 'str_M_0.png',
         angle: 0,
         show_level: hmUI.show_level.ONLY_NORMAL,
        });



        normal_analog_clock_pro_second_pointer_img = hmUI.createWidget(hmUI.widget.IMG, {
         x: 0,
         y: 0,
         w: deviceInfo.width,
         h: deviceInfo.height,
         pos_x: 233 - 233,
         pos_y: 233 - 233,
         center_x: 233,
         center_y: 233,
         src: 'str_S_0.png',
         angle: 0,
         show_level: hmUI.show_level.ONLY_NORMAL,
        });

        let screenType = hmSetting.getScreenType();
		   
            normal_battery_circle_scale = hmUI.createWidget(hmUI.widget.ARC_PROGRESS, {
              center_x: 233,
              center_y: 233,
              start_angle: 0,
              end_angle: -360,
              radius: 36,
              line_width: 10,
              corner_flag: 3,
              color: 0xFF33DE9C,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            
            const battery = hmSensor.createSensor(hmSensor.id.BATTERY);
            battery.addEventListener(hmSensor.event.CHANGE, function() {
              scale_call();
            });

            normal_battery_current_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 203,
              y: 210,
              w: 60,
              h: 46,
              text_size: 18,
              char_space: 0,
              line_space: 0,
              font: 'fonts/PulpDisplay_Light.ttf',
              color: 0xFF33DE9C,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.CENTER_V,
              unit_type: 1,
              text_style: hmUI.text_style.ELLIPSIS,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });		   
		   
		   
		   
		   
        normal_stress_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
         x: 0,
         y: 0,
         src: 'cap.png',
         show_level: hmUI.show_level.ONLY_NORMAL,
        });

        groupSec = hmUI.createWidget(hmUI.widget.GROUP, {
         x: 0,
         y: 0,
         w: 60,
         h: 46,
        }); // 


        normal_time_second_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
         x: 0,
         y: 0,
         w: 60,
         h: 46,
         text_size: 18,
         char_space: 0,
         line_space: 0,
         font: 'fonts/PulpDisplay_Light.ttf',
         color: 0xFF33DE9C,
         align_h: hmUI.align.CENTER_H,
         align_v: hmUI.align.CENTER_V,
         text_style: hmUI.text_style.ELLIPSIS,
         padding: true,
         type: hmUI.data_type.SECOND,
         show_level: hmUI.show_level.ONLY_NORMAL,
        });


        normal_time_minute_text_font = groupSec.createWidget(hmUI.widget.TEXT_FONT, {
         x: 0,
         y: 0,
         w: 60,
         h: 46,
         text_size: 32,
         char_space: 0,
         line_space: 0,
         font: 'fonts/PulpDisplay_Light.ttf',
         color: 0x00000000,
         align_h: hmUI.align.CENTER_H,
         align_v: hmUI.align.CENTER_V,
         text_style: hmUI.text_style.ELLIPSIS,
         padding: true,
         type: hmUI.data_type.MINUTE,
         show_level: hmUI.show_level.ONLY_NORMAL,
        });
		   
        normal_time_minute_unit = groupSec.createWidget(hmUI.widget.TEXT, {
         x: 0,
         y: 0,
         w: 60,
         h: 46,
         text_size: 32,
         text: 'м',
         char_space: 0,
         line_space: 0,
        // font: 'fonts/PulpDisplay_Light.ttf',
         color: 0xFF33DE9C,
         align_h: hmUI.align.CENTER_H,
         align_v: hmUI.align.CENTER_V,
         text_style: hmUI.text_style.ELLIPSIS,
         padding: true,
        // type: hmUI.data_type.MINUTE,
         show_level: hmUI.show_level.ONLY_NORMAL,
        });
		   
		   

        normal_time_hour_text_font = groupSec.createWidget(hmUI.widget.TEXT_FONT, {
         x: 0,
         y: 0,
         w: 60,
         h: 46,
         text_size: 32,
         char_space: 0,
         line_space: 0,
         font: 'fonts/PulpDisplay_Light.ttf',
         color: 0x00000000,
         align_h: hmUI.align.CENTER_H,
         align_v: hmUI.align.CENTER_V,
         text_style: hmUI.text_style.ELLIPSIS,
         padding: true,
         type: hmUI.data_type.HOUR,
         show_level: hmUI.show_level.ONLY_NORMAL,
        });
		   
        normal_time_hour_unit = groupSec.createWidget(hmUI.widget.TEXT, {
         x: 0,
         y: 0,
         w: 60,
         h: 46,
         text_size: 32,
         text: 'ч',
         char_space: 0,
         line_space: 0,
         //font: 'fonts/PulpDisplay_Light.ttf',
         color: 0xFF33DE9C,
         align_h: hmUI.align.CENTER_H,
         align_v: hmUI.align.CENTER_V,
         text_style: hmUI.text_style.ELLIPSIS,
         padding: true,
        // type: hmUI.data_type.HOUR,
         show_level: hmUI.show_level.ONLY_NORMAL,
        });
		   
            function scale_call() {
              console.log('scale_call()');

                console.log('update scales BATTERY');
                
                let valueBattery = battery.current;
                let targetBattery = 100;
                let progressBattery = valueBattery/targetBattery;
                if (progressBattery > 1) progressBattery = 1;
                let progress_cs_normal_battery = progressBattery;

                if (screenType != hmSetting.screen_type.AOD) {

                  // normal_battery_circle_scale_circle_scale
                  let level = Math.round(progress_cs_normal_battery * 100);
                  if (normal_battery_circle_scale) {
                    normal_battery_circle_scale.setProperty(hmUI.prop.MORE, {                      
                      center_x: 233,
                      center_y: 233,
                      start_angle: 0,
                      end_angle: -360,
                      radius: 36,
                      line_width: 10,
                      corner_flag: 3,
                      color: 0xFF33DE9C,
                      show_level: hmUI.show_level.ONLY_NORMAL,
                      level: level,
                    });
                  };
                };

            };



        function time_update(updateHour = false, updateMinute = false) {
         //return { to{   pLeft: { x: x1, y: y1 }, bottomRight: { x: x2, y: y2 } };             console.log('time_update()');
         let hour = timeSensor.hour;
         let minute = timeSensor.minute;
         let second = timeSensor.second;
         let format_hour = timeSensor.format_hour;

         if (updateMinute) {
          let normal_hour = hour;
          let normal_fullAngle_hour = 360;
          if (normal_hour > 11) normal_hour -= 12;
          let normal_angle_hour = 0 + normal_fullAngle_hour * normal_hour / 12 + (normal_fullAngle_hour / 12) * minute / 60;
          if (normal_analog_clock_pro_hour_pointer_img) normal_analog_clock_pro_hour_pointer_img.setProperty(hmUI.prop.ANGLE, normal_angle_hour);

          let coords_hour = getRectangleCoordinates(148, normal_angle_hour);
          normal_time_hour_text_font.setProperty(hmUI.prop.MORE, {
           x: coords_hour.topLeft.x,
           y: coords_hour.topLeft.y,
           w: 60,
           h: 46,
           text_size: 32,
           char_space: 0,
           line_space: 0,
           font: 'fonts/PulpDisplay_Light.ttf',
           color: 0x00000000,
           align_h: hmUI.align.CENTER_H,
           align_v: hmUI.align.CENTER_V,
           text_style: hmUI.text_style.ELLIPSIS,
           padding: true,
           type: hmUI.data_type.HOUR,
           show_level: hmUI.show_level.ONLY_NORMAL,
          });


          let normal_fullAngle_minute = 360;
          let normal_angle_minute = 0 + normal_fullAngle_minute * minute / 60;
          if (normal_analog_clock_pro_minute_pointer_img) normal_analog_clock_pro_minute_pointer_img.setProperty(hmUI.prop.ANGLE, normal_angle_minute);

          let coords_minute = getRectangleCoordinates(284, normal_angle_minute);
          normal_time_minute_text_font.setProperty(hmUI.prop.MORE, {
           x: coords_minute.topLeft.x,
           y: coords_minute.topLeft.y,
           w: 60,
           h: 46,
           text_size: 32,
           char_space: 0,
           line_space: 0,
           font: 'fonts/PulpDisplay_Light.ttf',
           color: 0x00000000,
           align_h: hmUI.align.CENTER_H,
           align_v: hmUI.align.CENTER_V,
           text_style: hmUI.text_style.ELLIPSIS,
           padding: true,
           type: hmUI.data_type.MINUTE,
           show_level: hmUI.show_level.ONLY_NORMAL,
          });
			 
          let coords_minute_unit = getRectangleCoordinates(284, normal_angle_minute+6*4);
        normal_time_minute_unit.setProperty(hmUI.prop.MORE, {
           x: coords_minute_unit.topLeft.x,
           y: coords_minute_unit.topLeft.y,
         w: 60,
         h: 46,
         text_size: 32,
         text: 'м',
         char_space: 0,
         line_space: 0,
         //font: 'fonts/PulpDisplay_Light.ttf',
         color: 0xFF33DE9C,
         align_h: hmUI.align.CENTER_H,
         align_v: hmUI.align.CENTER_V,
         text_style: hmUI.text_style.ELLIPSIS,
         padding: true,
        // type: hmUI.data_type.MINUTE,
         show_level: hmUI.show_level.ONLY_NORMAL,
        });		
			 
          let coords_hour_unit = getRectangleCoordinates(148, normal_angle_hour+6*6);
        normal_time_hour_unit.setProperty(hmUI.prop.MORE, {
           x: coords_hour_unit.topLeft.x,
           y: coords_hour_unit.topLeft.y,
         w: 60,
         h: 46,
         text_size: 32,
         text: 'ч',
         char_space: 0,
         line_space: 0,
         //font: 'fonts/PulpDisplay_Light.ttf',
         color: 0xFF33DE9C,
         align_h: hmUI.align.CENTER_H,
         align_v: hmUI.align.CENTER_V,
         text_style: hmUI.text_style.ELLIPSIS,
         padding: true,
        // type: hmUI.data_type.MINUTE,
         show_level: hmUI.show_level.ONLY_NORMAL,
        });	
			 
          let normal_DOW_Str = normal_DOW_Array[timeSensor.week - 1];
          normal_dow_text_font.setProperty(hmUI.prop.TEXT, normal_DOW_Str);

          let normal_DayStr = timeSensor.day.toString();
          let normal_MonthStr = timeSensor.month.toString();
          let normal_DayMonthStr = '--';
          // const dateFormat = hmSetting.getDateFormat();
          normal_DayMonthStr = normal_DayStr + '.' + normal_MonthStr;
          normal_day_month_font.setProperty(hmUI.prop.TEXT, normal_DayMonthStr);			 
			 
          let coords_Data = getRectangleCoordinates(284, normal_angle_minute + 6 * 30);
          groupData.setProperty(hmUI.prop.MORE, {
           x: coords_Data.topLeft.x,
           y: coords_Data.topLeft.y,
           w: 60,
           h: 46,
          }); // 				 
			 
          let coords_Step = getRectangleCoordinates(148, normal_angle_hour + 6 * 30);
          groupStep.setProperty(hmUI.prop.MORE, {
           x: coords_Step.topLeft.x,
           y: coords_Step.topLeft.y,
           w: 60,
           h: 46,
          }); // 	
			 
         };


         let normal_fullAngle_second = 360;
         let normal_angle_second = -6 + normal_fullAngle_second * second / 60;
         if (normal_analog_clock_pro_second_pointer_img) normal_analog_clock_pro_second_pointer_img.setProperty(hmUI.prop.ANGLE, normal_angle_second);

         let coords_second = getRectangleCoordinates(402, normal_angle_second + 6);
         normal_time_second_text_font.setProperty(hmUI.prop.MORE, {
          x: coords_second.topLeft.x,
          y: coords_second.topLeft.y,
          w: 60,
          h: 46,
          text_size: 18,
          char_space: 0,
          line_space: 0,
          font: 'fonts/PulpDisplay_Light.ttf',
          color: 0xFF33DE9C,
          align_h: hmUI.align.CENTER_H,
          align_v: hmUI.align.CENTER_V,
          text_style: hmUI.text_style.ELLIPSIS,
          padding: true,
          type: hmUI.data_type.SECOND,
          show_level: hmUI.show_level.ONLY_NORMAL,
         });


        };

        //end of ignored block
        const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
         resume_call: (function () {
                scale_call();
			 
          console.log('resume_call()');
          time_update(true, true);
          if (screenType == hmSetting.screen_type.WATCHFACE) {
           if (!normal_timerUpdateSec) {
            let animDelay = timeSensor.utc % 1000;
            let animRepeat = 1000;
            normal_timerUpdateSec = timer.createTimer(animDelay, animRepeat, (function (option) {
             time_update(false, false);
            })); // end timer 
           }; // end timer check
          }; // end screenType


         }),
         pause_call: (function () {
          console.log('pause_call()');
          if (normal_timerUpdateSec) {
           timer.stopTimer(normal_timerUpdateSec);
           normal_timerUpdateSec = undefined;
          }

         }),
        });

        //dynamic modify end
       },
       onInit() {
        logger.log('index page.js on init invoke');
       },
       build() {
        this.init_view();
        logger.log('index page.js on ready invoke');
       },
       onDestroy() {
        logger.log('index page.js on destroy invoke');
       }
      });;
     })();
    } catch (e) {
     console.log('Mini Program Error', e);
     e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));;
    }
