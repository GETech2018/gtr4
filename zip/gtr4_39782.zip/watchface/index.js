﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (()=>{
        //dynamic modify start

        const lang = DeviceRuntimeCore.HmUtils.getLanguage()
        let normal_background_bg_img = ''
        let normal_system_disconnect_img = ''
        let normal_date_img_date_week_img = ''
        let normal_compass_direction_pointer_img = ''
        let normal_compass_text_img = ''
        let normal_step_pointer_progress_img_pointer = ''
        let normal_battery_pointer_progress_img_pointer = ''
        let normal_date_img_date_day = ''
        let normal_analog_clock_time_pointer_hour = ''
        let normal_analog_clock_time_pointer_minute = ''
        let normal_analog_clock_time_pointer_second = ''
        let idle_background_bg_img = ''
        let idle_system_disconnect_img = ''
        let idle_analog_clock_time_pointer_hour = ''
        let idle_analog_clock_time_pointer_minute = ''
        let normal_step_jumpable_img_click = ''
        let normal_pai_jumpable_img_click = ''
        let normal_battery_jumpable_img_click = ''
		
		let btn_zona1 = ''
        let zona1_num = 0
        let zona1_all = 1
		
		function click_zona1() {
		  zona1_num = (zona1_num + 1) % (zona1_all + 1);
          if (zona1_num == 0) {		
		    normal_date_img_date_week_img.setProperty(hmUI.prop.VISIBLE, true);
            normal_compass_direction_pointer_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_compass_text_img.setProperty(hmUI.prop.VISIBLE, false);
		    hmUI.showToast({
            });
          };
		  
		 if (zona1_num == 1) {
			normal_date_img_date_week_img.setProperty(hmUI.prop.VISIBLE, false);
            normal_compass_direction_pointer_img.setProperty(hmUI.prop.VISIBLE, true);
			normal_compass_text_img.setProperty(hmUI.prop.VISIBLE, true);
		    hmUI.showToast({
            });
          };
        }
		
		let batteryInfo_click = ''
		
		const battery = hmSensor.createSensor(hmSensor.id.BATTERY);
		const step = hmSensor.createSensor(hmSensor.id.STEP);
		
		let valueBattery = ''
        let valueStep = ''


        //dynamic modify end
        const e = __$$hmAppManager$$__.currentApp;
        const o = e.current
          , {px: i} = (new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(e,o)),
        e.__globals__)
          , n = Logger.getLogger("watchface6");
        o.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            console.log('Watch_Face.ScreenNormal');
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 466,
              h: 466,
              src: 'bg.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 270,
              y: 215,
              src: 'bt.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
			
			let dned=["week_0.png","week_1.png","week_2.png","week_3.png","week_4.png","week_5.png","week_6.png"]
			if(lang=='ru-RU'){
				dned=["weekru_0.png","weekru_1.png","weekru_2.png","weekru_3.png","weekru_4.png","weekru_5.png","weekru_6.png"]
			}
            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 125,
              y: 227,
              week_en: dned,
              week_tc: ["week_0.png","week_1.png","week_2.png","week_3.png","week_4.png","week_5.png","week_6.png"],
              week_sc: ["week_0.png","week_1.png","week_2.png","week_3.png","week_4.png","week_5.png","week_6.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            const deviceInfo = hmSetting.getDeviceInfo();
            
            // normal_compass_custom_pointer_img = hmUI.createWidget(hmUI.widget.CUSTOM_POINTER, {
              // src: 'compass.png',
              // center_x: 233,
              // center_y: 233,
              // x: 233,
              // y: 233,
              // start_angle: 0,
              // end_angle: 360,
              // type: hmUI.data_type.COMPASS,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });


            //start of ignored block
            normal_compass_direction_pointer_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: deviceInfo.width,
              h: deviceInfo.height,
              pos_x: 233 - 233,
              pos_y: 233 - 233,
              center_x: 233,
              center_y: 233,
              src: 'compass.png',
              angle: 0,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            //end of ignored block

            normal_compass_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 114,
              y: 220,
              font_array: ["wfs_date0_f0b1a48e_46db_48c9_9e78_f4832ca73bbe.png","wfs_date1_54d95b7b_7ded_4255_bad8_d700a8f21fcd.png","wfs_date2_f5824145_ef35_42e7_a5e8_e8a19209b2e7.png","wfs_date3_46268525_2f7c_499f_b077_28693690034f.png","wfs_date4_fc0b68a1_d49b_4dc9_b306_fb54962672f4.png","wfs_date5_f97502fa_b4d3_48d9_abd3_5af3c21fb835.png","wfs_date6_6772b55e_acc1_4da6_9a96_43aef7740be0.png","wfs_date7_28238967_6596_4b3d_8771_e54686c7a4a3.png","wfs_date8_74fe64f9_3761_47ab_9ad2_b1ab98582f13.png","wfs_date9_64941b95_0b5e_4fbb_95a7_0fb74b73af34.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              // type: hmUI.data_type.COMPASS,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_pointer_progress_img_pointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
              src: 'wfs_powerhand_786f6dc3_aa98_4b41_bd57_641c838d2fdd.png',
              center_x: 233,
              center_y: 330,
              x: 16,
              y: 57,
              start_angle: -31,
              end_angle: -331,
              invalid_visible: false,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_pointer_progress_img_pointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
              src: 'wfs_powerhand_786f6dc3_aa98_4b41_bd57_641c838d2fdd.png',
              center_x: 233,
              center_y: 134,
              x: 17,
              y: 57,
              start_angle: -149,
              end_angle: 151,
              invalid_visible: false,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 360,
              day_startY: 220,
              day_sc_array: ["wfs_date0_f0b1a48e_46db_48c9_9e78_f4832ca73bbe.png","wfs_date1_54d95b7b_7ded_4255_bad8_d700a8f21fcd.png","wfs_date2_f5824145_ef35_42e7_a5e8_e8a19209b2e7.png","wfs_date3_46268525_2f7c_499f_b077_28693690034f.png","wfs_date4_fc0b68a1_d49b_4dc9_b306_fb54962672f4.png","wfs_date5_f97502fa_b4d3_48d9_abd3_5af3c21fb835.png","wfs_date6_6772b55e_acc1_4da6_9a96_43aef7740be0.png","wfs_date7_28238967_6596_4b3d_8771_e54686c7a4a3.png","wfs_date8_74fe64f9_3761_47ab_9ad2_b1ab98582f13.png","wfs_date9_64941b95_0b5e_4fbb_95a7_0fb74b73af34.png"],
              day_tc_array: ["wfs_date0_f0b1a48e_46db_48c9_9e78_f4832ca73bbe.png","wfs_date1_54d95b7b_7ded_4255_bad8_d700a8f21fcd.png","wfs_date2_f5824145_ef35_42e7_a5e8_e8a19209b2e7.png","wfs_date3_46268525_2f7c_499f_b077_28693690034f.png","wfs_date4_fc0b68a1_d49b_4dc9_b306_fb54962672f4.png","wfs_date5_f97502fa_b4d3_48d9_abd3_5af3c21fb835.png","wfs_date6_6772b55e_acc1_4da6_9a96_43aef7740be0.png","wfs_date7_28238967_6596_4b3d_8771_e54686c7a4a3.png","wfs_date8_74fe64f9_3761_47ab_9ad2_b1ab98582f13.png","wfs_date9_64941b95_0b5e_4fbb_95a7_0fb74b73af34.png"],
              day_en_array: ["wfs_date0_f0b1a48e_46db_48c9_9e78_f4832ca73bbe.png","wfs_date1_54d95b7b_7ded_4255_bad8_d700a8f21fcd.png","wfs_date2_f5824145_ef35_42e7_a5e8_e8a19209b2e7.png","wfs_date3_46268525_2f7c_499f_b077_28693690034f.png","wfs_date4_fc0b68a1_d49b_4dc9_b306_fb54962672f4.png","wfs_date5_f97502fa_b4d3_48d9_abd3_5af3c21fb835.png","wfs_date6_6772b55e_acc1_4da6_9a96_43aef7740be0.png","wfs_date7_28238967_6596_4b3d_8771_e54686c7a4a3.png","wfs_date8_74fe64f9_3761_47ab_9ad2_b1ab98582f13.png","wfs_date9_64941b95_0b5e_4fbb_95a7_0fb74b73af34.png"],
              day_zero: 1,
              day_space: 0,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_hour = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              hour_path: 'wfs_hourhand_d9dde790_d68b_4727_9908_1629fc4e5b89.png',
              hour_centerX: 233,
              hour_centerY: 233,
              hour_posX: 25,
              hour_posY: 226,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_minute = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              minute_path: 'wfs_minutehand_00214745_b803_43aa_a9c0_30a67dcfc6e9.png',
              minute_centerX: 233,
              minute_centerY: 233,
              minute_posX: 23,
              minute_posY: 226,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_second = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              second_path: 'wfs_secondshand_01972e45_6617_4e74_8ceb_a49ced25ac85.png',
              second_centerX: 233,
              second_centerY: 233,
              second_posX: 19,
              second_posY: 225,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
			
			function get_values (){
              valueBattery = battery.current; 
              valueStep = step.current;
          
            }


            console.log('Watch_Face.ScreenAOD');
            idle_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 466,
              h: 466,
              src: 'aod.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 195,
              y: 136,
              src: 'bt.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_analog_clock_time_pointer_hour = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              hour_path: 'wfs_aodhourhand_5989601b_c1dc_4f84_99c2_f87c588dedca.png',
              hour_centerX: 233,
              hour_centerY: 233,
              hour_posX: 14,
              hour_posY: 226,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_analog_clock_time_pointer_minute = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              minute_path: 'wfs_aodminutehand_995276a0_5e79_4b11_ae74_d27a078324f3.png',
              minute_centerX: 233,
              minute_centerY: 233,
              minute_posX: 12,
              minute_posY: 213,
              show_level: hmUI.show_level.ONLY_AOD,
            });
            console.log('Watch_Face.Shortcuts');

            stepInfo_click = hmUI.createWidget(hmUI.widget.BUTTON, {
          x: 185,
          y: 296,
          w: 97,
          h: 68,
          text: '',
          normal_src: 'Empty.png',
          press_src: 'Empty.png',
          click_func: () => {
            get_values();
			hmUI.showToast({ text: 'Step is ' + valueStep + ''});
          },
		   longpress_func: () => {
             hmApp.startApp({url: 'activityAppScreen', native: true });
             },
          show_level: hmUI.show_level.ONLY_NORMAL,
        });

            btn_zona1 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 155,
              y: 203,
              text: '',
              w: 97,
              h: 58,
              normal_src: 'Empty.png',
              press_src: 'Empty.png',
              click_func: () => {
				click_zona1();
				click_Vibrate();
             },
			  longpress_func: () => {
             hmApp.startApp({ url: "ScheduleCalScreen", native: true });
             },
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            btn_zona1.setProperty(hmUI.prop.VISIBLE, true);
			normal_compass_direction_pointer_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_compass_text_img.setProperty(hmUI.prop.VISIBLE, false);

            batteryInfo_click = hmUI.createWidget(hmUI.widget.BUTTON, {
          x: 185,
          y: 121,
          w: 97,
          h: 68,
          text: '',
          normal_src: 'Empty.png',
          press_src: 'Empty.png',
          click_func: () => {
            get_values();
			hmUI.showToast({ text: 'Battery is ' + valueBattery + ' %' });
          },
		  longpress_func: () => {
             hmApp.startApp({url: 'Settings_batteryManagerScreen', native: true });
             },
          show_level: hmUI.show_level.ONLY_NORMAL,
        });

            let screenType = hmSetting.getScreenType();
            //start of ignored block
            console.log('compass_update()');
            if (screenType == hmSetting.screen_type.WATCHFACE){
              compass = hmSensor.createSensor(hmSensor.id.COMPASS);
              compass.start();

              if (compass.direction_angle && compass.direction  && compass.direction_angle != 'INVALID') { // initial data
                // Compass Pointer
                let compass_direction_angle = parseInt(compass.direction_angle);
                normal_compass_direction_pointer_img.setProperty(hmUI.prop.ANGLE, -compass_direction_angle);
                // Compass Number
                let normal_compass_direction_angle_text = compass_direction_angle.toString();
                normal_compass_text_img.setProperty(hmUI.prop.TEXT, normal_compass_direction_angle_text);

              } else { // error data
                normal_compass_direction_pointer_img.setProperty(hmUI.prop.ANGLE, 0);
                normal_compass_text_img.setProperty(hmUI.prop.TEXT, '-');

              }

              compass.addEventListener(hmSensor.event.CHANGE, function (compass_res) { // change values when changing direction

                if (compass_res.calibration_status) {
                  // Compass Pointer
                  let compass_direction_angle = parseInt(compass_res.direction_angle);
                  normal_compass_direction_pointer_img.setProperty(hmUI.prop.ANGLE, -compass_direction_angle);
                  // Compass Number
                  let normal_compass_direction_angle_text = compass_direction_angle.toString();
                  normal_compass_text_img.setProperty(hmUI.prop.TEXT, normal_compass_direction_angle_text);

                } else { // error data
                  normal_compass_direction_pointer_img.setProperty(hmUI.prop.ANGLE, 0);
                  normal_compass_text_img.setProperty(hmUI.prop.TEXT, '-');

                }

              }); // Listener end

            };
            //end of ignored block

            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                console.log('resume_call()');
                if (compass && screenType == hmSetting.screen_type.WATCHFACE) compass.start();

              }),
              pause_call: (function () {
                console.log('pause_call()');
                if (compass) compass.stop();

              }),
            });

                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}