﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        const logger = Logger.getLogger('watchface_SashaCX75');
        //end of ignored block

        //dynamic modify start

        
        console.log('user_functions.js');
        // start user_functions.js

let colornumber_background = 1
        let totalcolors_background = 10
        let namecolor_background = ''

        function click_Color() {
            if(colornumber_background>=totalcolors_background) {
            colornumber_background=1;
                }
            else {
                colornumber_background=colornumber_background+1;
            }
            if ( colornumber_background == 1) { namecolor_background = "W H I T E"}
			if ( colornumber_background == 2) { namecolor_background = "Y E L L O W"}
			if ( colornumber_background == 3) { namecolor_background = "P E A C H"}
			if ( colornumber_background == 4) { namecolor_background = "O R A N G E"}
			if ( colornumber_background == 5) { namecolor_background = "R E D"}
			if ( colornumber_background == 6) { namecolor_background = "P U R P L E"}
			if ( colornumber_background == 7) { namecolor_background = "G R E E N"}
			if ( colornumber_background == 8) { namecolor_background = "B L U E"}
			if ( colornumber_background == 9) { namecolor_background = "D A R K - B L U E"}
            if ( colornumber_background == 10) { namecolor_background = "G R E Y"}

			hmUI.showToast({text: namecolor_background });
            normal_background_bg_img.setProperty(hmUI.prop.SRC, "color_" + parseInt(colornumber_background) + ".png");
        }
        // end user_functions.js

        let normal_background_bg_img = ''
        let normal_rotate_animation_img_1 = '';
        let normal_rotate_animation_param_1 = null;
        let normal_rotate_animation_lastTime_1 = 0;
        let timer_anim_rotate_1;
        let normal_rotate_animation_count_1 = 0;
        let normal_rotate_animation_img_2 = '';
        let normal_rotate_animation_param_2 = null;
        let normal_rotate_animation_lastTime_2 = 0;
        let timer_anim_rotate_2;
        let normal_rotate_animation_count_2 = 0;
        let normal_image_img = ''
        let normal_system_dnd_img = ''
        let normal_system_disconnect_img = ''
        let normal_system_clock_img = ''
        let normal_city_name_text = ''
        let normal_temperature_current_text_img = ''
        let normal_weather_image_progress_img_level = ''
        let normal_battery_text_text_img = ''
        let normal_pai_pointer_progress_img_pointer = ''
        let normal_pai_weekly_text_img = ''
        let normal_heart_rate_TextRotate = new Array(3);
        let normal_heart_rate_TextRotate_ASCIIARRAY = new Array(10);
        let normal_heart_rate_TextRotate_img_width = 13;
        let normal_heart_rate_TextRotate_error_img_width = 1;
        let normal_calorie_TextRotate = new Array(4);
        let normal_calorie_TextRotate_ASCIIARRAY = new Array(10);
        let normal_calorie_TextRotate_img_width = 13;
        let normal_calorie_TextRotate_error_img_width = 1;
        let normal_step_pointer_progress_img_pointer = ''
        let normal_step_current_text_img = ''
        let normal_date_img_date_week_img = ''
        let normal_date_img_date_day = ''
        let normal_digital_clock_img_time = ''
        let normal_digital_clock_hour_separator_img = ''
        let normal_digital_clock_minute_separator_img = ''
        let normal_digital_clock_second_separator_img = ''
        let normal_analog_clock_pro_second_pointer_img = ''
        let normal_timerUpdateSec = undefined;
        let idle_background_bg_img = ''
        let idle_image_img = ''
        let idle_system_dnd_img = ''
        let idle_system_disconnect_img = ''
        let idle_system_clock_img = ''
        let idle_city_name_text = ''
        let idle_temperature_current_text_img = ''
        let idle_weather_image_progress_img_level = ''
        let idle_battery_text_text_img = ''
        let idle_pai_pointer_progress_img_pointer = ''
        let idle_pai_weekly_text_img = ''
        let idle_heart_rate_TextRotate = new Array(3);
        let idle_heart_rate_TextRotate_ASCIIARRAY = new Array(10);
        let idle_heart_rate_TextRotate_img_width = 13;
        let idle_heart_rate_TextRotate_error_img_width = 1;
        let idle_calorie_TextRotate = new Array(4);
        let idle_calorie_TextRotate_ASCIIARRAY = new Array(10);
        let idle_calorie_TextRotate_img_width = 13;
        let idle_calorie_TextRotate_error_img_width = 1;
        let idle_step_pointer_progress_img_pointer = ''
        let idle_step_current_text_img = ''
        let idle_date_img_date_week_img = ''
        let idle_date_img_date_day = ''
        let idle_digital_clock_img_time = ''
        let idle_digital_clock_hour_separator_img = ''
        let idle_digital_clock_minute_separator_img = ''
        let idle_digital_clock_second_separator_img = ''
        let idle_analog_clock_pro_second_pointer_img = ''
        let idle_timerUpdateSec = undefined;
        let Button_1 = ''
        let Button_2 = ''
        let Button_3 = ''
        let Button_4 = ''
        let Button_5 = ''
        let Button_6 = ''
        let timeSensor = ''


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            console.log('Watch_Face.ScreenNormal');
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 466,
              h: 466,
              src: 'background.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_rotate_animation_img_1 = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 467,
              h: 467,
              pos_x: 0,
              pos_y: 0,
              center_x: 233,
              center_y: 233,
              angle: 0,
              src: 'animation/anim_0.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_rotate_animation_param_1 = {
              anim_steps: [{
                anim_rate: 'linear',
                anim_duration: 10000,
                anim_from: 0,
                anim_to: 360,
                anim_key: "angle",
              }],
              anim_fps: 15,
              anim_auto_start: 1,
              anim_repeat: 1,
              anim_auto_destroy: 1,
            };

            let now = hmSensor.createSensor(hmSensor.id.TIME);

            function anim_rotate_1_complete_call() {
              normal_rotate_animation_img_1.setProperty(hmUI.prop.ANIM, normal_rotate_animation_param_1);
              normal_rotate_animation_lastTime_1 = now.utc;
              normal_rotate_animation_count_1 = normal_rotate_animation_count_1 - 1;
              if(normal_rotate_animation_count_1 < -1) normal_rotate_animation_count_1 = - 1;
              if(normal_rotate_animation_count_1 == 0) stop_anim_rotate_1();
            }; // end animation callback function
            
            function stop_anim_rotate_1() {
              if (timer_anim_rotate_1) {
                timer.stopTimer(timer_anim_rotate_1);
                timer_anim_rotate_1 = undefined;
              };
            }; // end stop_anim_rotate function

            // normal_rotate_anime_1 = hmUI.createWidget(hmUI.widget.Rotate_Animation, {
              // start_angle: 0,
              // end_angle: 360,
              // pos_x: 233,
              // pos_y: 233,
              // center_x: 233,
              // center_y: 233,
              // src: 'anim_0.png',
              // anim_fps: 15,
              // anim_duration: 10000,
              // repeat_count: 0,
              // anim_two_sides: False,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_rotate_animation_img_2 = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 467,
              h: 467,
              pos_x: 0,
              pos_y: 0,
              center_x: 233,
              center_y: 233,
              angle: 360,
              src: 'animation/site_0.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_rotate_animation_param_2 = {
              anim_steps: [{
                anim_rate: 'linear',
                anim_duration: 20000,
                anim_from: 360,
                anim_to: 0,
                anim_key: "angle",
              }],
              anim_fps: 15,
              anim_auto_start: 1,
              anim_repeat: 1,
              anim_auto_destroy: 1,
            };

            function anim_rotate_2_complete_call() {
              normal_rotate_animation_img_2.setProperty(hmUI.prop.ANIM, normal_rotate_animation_param_2);
              normal_rotate_animation_lastTime_2 = now.utc;
              normal_rotate_animation_count_2 = normal_rotate_animation_count_2 - 1;
              if(normal_rotate_animation_count_2 < -1) normal_rotate_animation_count_2 = - 1;
              if(normal_rotate_animation_count_2 == 0) stop_anim_rotate_2();
            }; // end animation callback function
            
            function stop_anim_rotate_2() {
              if (timer_anim_rotate_2) {
                timer.stopTimer(timer_anim_rotate_2);
                timer_anim_rotate_2 = undefined;
              };
            }; // end stop_anim_rotate function

            // normal_rotate_anime_2 = hmUI.createWidget(hmUI.widget.Rotate_Animation, {
              // start_angle: 360,
              // end_angle: 0,
              // pos_x: 233,
              // pos_y: 233,
              // center_x: 233,
              // center_y: 233,
              // src: 'site_0.png',
              // anim_fps: 15,
              // anim_duration: 20000,
              // repeat_count: 0,
              // anim_two_sides: False,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_image_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'image.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_dnd_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 344,
              y: 31,
              src: 'dnd.png',
              type: hmUI.system_status.DISTURB,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 53,
              y: 45,
              src: 'bt.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 349,
              y: 396,
              src: 'alarm.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
              const weatherSensor = hmSensor.createSensor(hmSensor.id.WEATHER);

            normal_city_name_text = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 31,
              y: 228,
              w: 126,
              h: 29,
              text_size: 17,
              char_space: 0,
              line_space: 0,
              color: 0xFFC0C0C0,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 67,
              y: 258,
              font_array: ["act_0.png","act_1.png","act_2.png","act_3.png","act_4.png","act_5.png","act_6.png","act_7.png","act_8.png","act_9.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'pointer_3.png',
              unit_tc: 'pointer_3.png',
              unit_en: 'pointer_3.png',
              negative_image: 'pointer_2.png',
              invalid_image: 'dot.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 60,
              y: 174,
              image_array: ["weather_1.png","weather_2.png","weather_3.png","weather_4.png","weather_5.png","weather_6.png","weather_7.png","weather_8.png","weather_9.png","weather_10.png","weather_11.png","weather_12.png","weather_13.png","weather_14.png","weather_15.png","weather_16.png","weather_17.png","weather_18.png","weather_19.png","weather_20.png","weather_21.png","weather_22.png","weather_23.png","weather_24.png","weather_25.png","weather_26.png","weather_27.png","weather_28.png","weather_29.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 383,
              y: 324,
              font_array: ["act_0.png","act_1.png","act_2.png","act_3.png","act_4.png","act_5.png","act_6.png","act_7.png","act_8.png","act_9.png"],
              padding: false,
              h_space: 1,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_pai_pointer_progress_img_pointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
              src: 'pointer_5.png',
              center_x: 232,
              center_y: 371,
              x: 19,
              y: 77,
              start_angle: 301,
              end_angle: 59,
              invalid_visible: false,
              cover_path: 'image_pai.png',
              cover_x: 199,
              cover_y: 338,
              type: hmUI.data_type.PAI_WEEKLY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_pai_weekly_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 214,
              y: 305,
              font_array: ["act_0.png","act_1.png","act_2.png","act_3.png","act_4.png","act_5.png","act_6.png","act_7.png","act_8.png","act_9.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.PAI_WEEKLY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_heart_rate_text_rotate_img = hmUI.createWidget(hmUI.widget.Text_Rotate, {
              // x: 125,
              // y: 337,
              // font_array: ["act1_0.png","act1_1.png","act1_2.png","act1_3.png","act1_4.png","act1_5.png","act1_6.png","act1_7.png","act1_8.png","act1_9.png"],
              // zero: false,
              // unit_in_alignment: false,
              // h_space: 1,
              // angle: 45,
              // invalid_image: 'dot.png',
              // align_h: hmUI.align.CENTER_H,
              // type: hmUI.data_type.HEART,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_heart_rate_TextRotate_ASCIIARRAY[0] = 'act1_0.png';  // set of images with numbers
            normal_heart_rate_TextRotate_ASCIIARRAY[1] = 'act1_1.png';  // set of images with numbers
            normal_heart_rate_TextRotate_ASCIIARRAY[2] = 'act1_2.png';  // set of images with numbers
            normal_heart_rate_TextRotate_ASCIIARRAY[3] = 'act1_3.png';  // set of images with numbers
            normal_heart_rate_TextRotate_ASCIIARRAY[4] = 'act1_4.png';  // set of images with numbers
            normal_heart_rate_TextRotate_ASCIIARRAY[5] = 'act1_5.png';  // set of images with numbers
            normal_heart_rate_TextRotate_ASCIIARRAY[6] = 'act1_6.png';  // set of images with numbers
            normal_heart_rate_TextRotate_ASCIIARRAY[7] = 'act1_7.png';  // set of images with numbers
            normal_heart_rate_TextRotate_ASCIIARRAY[8] = 'act1_8.png';  // set of images with numbers
            normal_heart_rate_TextRotate_ASCIIARRAY[9] = 'act1_9.png';  // set of images with numbers

            //start of ignored block
            for (let i = 0; i < 3; i++) {
              normal_heart_rate_TextRotate[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 466,
                h: 466,
                center_x: 125,
                center_y: 337,
                pos_x: 125,
                pos_y: 337,
                angle: 45,
                src: 'act1_0.png',
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
              normal_heart_rate_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
            };
            //end of ignored block
            
            const heart_rate = hmSensor.createSensor(hmSensor.id.HEART);
            heart_rate.addEventListener(hmSensor.event.CHANGE, function() {
              text_update();
            });

            // normal_calorie_text_rotate_img = hmUI.createWidget(hmUI.widget.Text_Rotate, {
              // x: 109,
              // y: 110,
              // font_array: ["act1_0.png","act1_1.png","act1_2.png","act1_3.png","act1_4.png","act1_5.png","act1_6.png","act1_7.png","act1_8.png","act1_9.png"],
              // zero: false,
              // unit_in_alignment: false,
              // h_space: 0,
              // angle: -45,
              // invalid_image: 'dot.png',
              // align_h: hmUI.align.CENTER_H,
              // type: hmUI.data_type.CAL,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_calorie_TextRotate_ASCIIARRAY[0] = 'act1_0.png';  // set of images with numbers
            normal_calorie_TextRotate_ASCIIARRAY[1] = 'act1_1.png';  // set of images with numbers
            normal_calorie_TextRotate_ASCIIARRAY[2] = 'act1_2.png';  // set of images with numbers
            normal_calorie_TextRotate_ASCIIARRAY[3] = 'act1_3.png';  // set of images with numbers
            normal_calorie_TextRotate_ASCIIARRAY[4] = 'act1_4.png';  // set of images with numbers
            normal_calorie_TextRotate_ASCIIARRAY[5] = 'act1_5.png';  // set of images with numbers
            normal_calorie_TextRotate_ASCIIARRAY[6] = 'act1_6.png';  // set of images with numbers
            normal_calorie_TextRotate_ASCIIARRAY[7] = 'act1_7.png';  // set of images with numbers
            normal_calorie_TextRotate_ASCIIARRAY[8] = 'act1_8.png';  // set of images with numbers
            normal_calorie_TextRotate_ASCIIARRAY[9] = 'act1_9.png';  // set of images with numbers

            //start of ignored block
            for (let i = 0; i < 4; i++) {
              normal_calorie_TextRotate[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 466,
                h: 466,
                center_x: 109,
                center_y: 110,
                pos_x: 109,
                pos_y: 110,
                angle: -45,
                src: 'act1_0.png',
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
              normal_calorie_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
            };
            //end of ignored block
            
            const calorie = hmSensor.createSensor(hmSensor.id.CALORIE);
            calorie.addEventListener(hmSensor.event.CHANGE, function() {
              text_update();
            });

            normal_step_pointer_progress_img_pointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
              src: 'pointer_4.png',
              center_x: 232,
              center_y: 89,
              x: 18,
              y: 77,
              start_angle: -121,
              end_angle: 118,
              invalid_visible: false,
              cover_path: 'image_step.png',
              cover_x: 199,
              cover_y: 56,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 199,
              y: 127,
              font_array: ["act_0.png","act_1.png","act_2.png","act_3.png","act_4.png","act_5.png","act_6.png","act_7.png","act_8.png","act_9.png"],
              padding: false,
              h_space: 1,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 361,
              y: 150,
              week_en: ["day_1.png","day_2.png","day_3.png","day_4.png","day_5.png","day_6.png","day_7.png"],
              week_tc: ["day_1.png","day_2.png","day_3.png","day_4.png","day_5.png","day_6.png","day_7.png"],
              week_sc: ["day_1.png","day_2.png","day_3.png","day_4.png","day_5.png","day_6.png","day_7.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 387,
              day_startY: 119,
              day_sc_array: ["act_0.png","act_1.png","act_2.png","act_3.png","act_4.png","act_5.png","act_6.png","act_7.png","act_8.png","act_9.png"],
              day_tc_array: ["act_0.png","act_1.png","act_2.png","act_3.png","act_4.png","act_5.png","act_6.png","act_7.png","act_8.png","act_9.png"],
              day_en_array: ["act_0.png","act_1.png","act_2.png","act_3.png","act_4.png","act_5.png","act_6.png","act_7.png","act_8.png","act_9.png"],
              day_zero: 0,
              day_space: 1,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 196,
              hour_startY: 199,
              hour_array: ["time_0.png","time_1.png","time_2.png","time_3.png","time_4.png","time_5.png","time_6.png","time_7.png","time_8.png","time_9.png"],
              hour_zero: 1,
              hour_space: 6,
              hour_angle: 0,
              hour_align: hmUI.align.LEFT,

              minute_startX: 288,
              minute_startY: 199,
              minute_array: ["time_0.png","time_1.png","time_2.png","time_3.png","time_4.png","time_5.png","time_6.png","time_7.png","time_8.png","time_9.png"],
              minute_zero: 1,
              minute_space: 6,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              second_startX: 381,
              second_startY: 199,
              second_array: ["sec_0.png","sec_1.png","sec_2.png","sec_3.png","sec_4.png","sec_5.png","sec_6.png","sec_7.png","sec_8.png","sec_9.png"],
              second_zero: 1,
              second_space: 6,
              second_angle: 0,
              second_follow: 0,
              second_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_hour_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 272,
              y: 190,
              src: 'pointer_0.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_minute_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 366,
              y: 190,
              src: 'pointer_0.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_second_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 181,
              y: 231,
              src: 'image_time.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            const deviceInfo = hmSetting.getDeviceInfo();
            if (!timeSensor) timeSensor = hmSensor.createSensor(hmSensor.id.TIME);
            // normal_analog_clock_pro_second_pointer_img = hmUI.createWidget(hmUI.widget.TIME_POINTER_PRO, {
              // src: 'second.png',
              // center_x: 93,
              // center_y: 232,
              // x: 82,
              // y: 82,
              // start_angle: 0,
              // end_angle: 360,
              // type: hmUI.data_type.second,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });


            normal_analog_clock_pro_second_pointer_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: deviceInfo.width,
              h: deviceInfo.height,
              pos_x: 93 - 82,
              pos_y: 232 - 82,
              center_x: 93,
              center_y: 232,
              src: 'second.png',
              angle: 0,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            let screenType = hmSetting.getScreenType();
            console.log('user_script.js');
            // start user_script.js
let currentLanguage = 0;
let availableLanguages = [
    'en',
    'cs',
    'gr',
    'pl',
];
let currentFolder = availableLanguages[currentLanguage];

function getImagePath(filename) {
    return currentFolder + '/' + filename + '.png';
}

function generateDayArray(prefix) {
    let days = [];
    for (let i = 1; i <= 7; i++) {
        days.push(getImagePath(prefix + i));
    }
    return days;
}

function generateWeekWidget(x, y, prefix, showLevel) {
    let dayArray = generateDayArray(prefix)
    return hmUI.createWidget(hmUI.widget.IMG_WEEK, {
        x: x,
        y: y,
        week_en: dayArray,
        week_tc: dayArray,
        week_sc: dayArray,
        show_level: showLevel,
    });
}

function click_ChangeLanguage() {
    currentLanguage++;
    if (currentLanguage >= availableLanguages.length) {
        currentLanguage = 0;
    }
    currentFolder = availableLanguages[currentLanguage];

    normal_image_img.setProperty(hmUI.prop.SRC, getImagePath('image'));
    idle_image_img.setProperty(hmUI.prop.SRC, getImagePath('image'));

    normal_system_disconnect_img.setProperty(hmUI.prop.SRC, getImagePath('bt'));
    idle_system_disconnect_img.setProperty(hmUI.prop.SRC, getImagePath('bt'));

    normal_system_dnd_img.setProperty(hmUI.prop.SRC, getImagePath('dnd'));
    idle_system_dnd_img.setProperty(hmUI.prop.SRC, getImagePath('dnd'));

    normal_system_clock_img.setProperty(hmUI.prop.SRC, getImagePath('alarm'));
    idle_system_clock_img.setProperty(hmUI.prop.SRC, getImagePath('alarm'));

    let dayX = 361;
    let dayY = 150;
    hmUI.deleteWidget(normal_date_img_date_week_img);
    hmUI.deleteWidget(idle_date_img_date_week_img);
    normal_date_img_date_week_img = generateWeekWidget(dayX, dayY, 'day_', hmUI.show_level.ONLY_NORMAL);
    idle_date_img_date_week_img = generateWeekWidget(dayX, dayY, 'day_', hmUI.show_level.ONLY_AOD);

    hmUI.showToast({
        text: currentFolder
    });
}

            // end user_script.js


            console.log('Watch_Face.ScreenAOD');
            idle_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 466,
              h: 466,
              src: 'background.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_image_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'image.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_system_dnd_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 344,
              y: 31,
              src: 'dnd.png',
              type: hmUI.system_status.DISTURB,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 53,
              y: 45,
              src: 'bt.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 349,
              y: 396,
              src: 'alarm.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_city_name_text = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 31,
              y: 234,
              w: 126,
              h: 29,
              text_size: 17,
              char_space: 0,
              line_space: 0,
              color: 0xFFC0C0C0,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 67,
              y: 262,
              font_array: ["act_0.png","act_1.png","act_2.png","act_3.png","act_4.png","act_5.png","act_6.png","act_7.png","act_8.png","act_9.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'pointer_3.png',
              unit_tc: 'pointer_3.png',
              unit_en: 'pointer_3.png',
              negative_image: 'pointer_2.png',
              invalid_image: 'dot.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 60,
              y: 174,
              image_array: ["weather_1.png","weather_2.png","weather_3.png","weather_4.png","weather_5.png","weather_6.png","weather_7.png","weather_8.png","weather_9.png","weather_10.png","weather_11.png","weather_12.png","weather_13.png","weather_14.png","weather_15.png","weather_16.png","weather_17.png","weather_18.png","weather_19.png","weather_20.png","weather_21.png","weather_22.png","weather_23.png","weather_24.png","weather_25.png","weather_26.png","weather_27.png","weather_28.png","weather_29.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 383,
              y: 324,
              font_array: ["act_0.png","act_1.png","act_2.png","act_3.png","act_4.png","act_5.png","act_6.png","act_7.png","act_8.png","act_9.png"],
              padding: false,
              h_space: 1,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_pai_pointer_progress_img_pointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
              src: 'pointer_5.png',
              center_x: 232,
              center_y: 371,
              x: 19,
              y: 77,
              start_angle: 301,
              end_angle: 59,
              invalid_visible: false,
              cover_path: 'image_pai.png',
              cover_x: 199,
              cover_y: 338,
              type: hmUI.data_type.PAI_WEEKLY,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_pai_weekly_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 214,
              y: 305,
              font_array: ["act_0.png","act_1.png","act_2.png","act_3.png","act_4.png","act_5.png","act_6.png","act_7.png","act_8.png","act_9.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.PAI_WEEKLY,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            // idle_heart_rate_text_rotate_img = hmUI.createWidget(hmUI.widget.Text_Rotate, {
              // x: 125,
              // y: 337,
              // font_array: ["act1_0.png","act1_1.png","act1_2.png","act1_3.png","act1_4.png","act1_5.png","act1_6.png","act1_7.png","act1_8.png","act1_9.png"],
              // zero: false,
              // unit_in_alignment: false,
              // h_space: 1,
              // angle: 45,
              // invalid_image: 'dot.png',
              // align_h: hmUI.align.CENTER_H,
              // type: hmUI.data_type.HEART,
              // show_level: hmUI.show_level.ONLY_AOD,
            // });

            idle_heart_rate_TextRotate_ASCIIARRAY[0] = 'act1_0.png';  // set of images with numbers
            idle_heart_rate_TextRotate_ASCIIARRAY[1] = 'act1_1.png';  // set of images with numbers
            idle_heart_rate_TextRotate_ASCIIARRAY[2] = 'act1_2.png';  // set of images with numbers
            idle_heart_rate_TextRotate_ASCIIARRAY[3] = 'act1_3.png';  // set of images with numbers
            idle_heart_rate_TextRotate_ASCIIARRAY[4] = 'act1_4.png';  // set of images with numbers
            idle_heart_rate_TextRotate_ASCIIARRAY[5] = 'act1_5.png';  // set of images with numbers
            idle_heart_rate_TextRotate_ASCIIARRAY[6] = 'act1_6.png';  // set of images with numbers
            idle_heart_rate_TextRotate_ASCIIARRAY[7] = 'act1_7.png';  // set of images with numbers
            idle_heart_rate_TextRotate_ASCIIARRAY[8] = 'act1_8.png';  // set of images with numbers
            idle_heart_rate_TextRotate_ASCIIARRAY[9] = 'act1_9.png';  // set of images with numbers

            //start of ignored block
            for (let i = 0; i < 3; i++) {
              idle_heart_rate_TextRotate[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 466,
                h: 466,
                center_x: 125,
                center_y: 337,
                pos_x: 125,
                pos_y: 337,
                angle: 45,
                src: 'act1_0.png',
                show_level: hmUI.show_level.ONLY_AOD,
              });
              idle_heart_rate_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
            };
            //end of ignored block

            // idle_calorie_text_rotate_img = hmUI.createWidget(hmUI.widget.Text_Rotate, {
              // x: 109,
              // y: 110,
              // font_array: ["act1_0.png","act1_1.png","act1_2.png","act1_3.png","act1_4.png","act1_5.png","act1_6.png","act1_7.png","act1_8.png","act1_9.png"],
              // zero: false,
              // unit_in_alignment: false,
              // h_space: 0,
              // angle: -45,
              // invalid_image: 'dot.png',
              // align_h: hmUI.align.CENTER_H,
              // type: hmUI.data_type.CAL,
              // show_level: hmUI.show_level.ONLY_AOD,
            // });

            idle_calorie_TextRotate_ASCIIARRAY[0] = 'act1_0.png';  // set of images with numbers
            idle_calorie_TextRotate_ASCIIARRAY[1] = 'act1_1.png';  // set of images with numbers
            idle_calorie_TextRotate_ASCIIARRAY[2] = 'act1_2.png';  // set of images with numbers
            idle_calorie_TextRotate_ASCIIARRAY[3] = 'act1_3.png';  // set of images with numbers
            idle_calorie_TextRotate_ASCIIARRAY[4] = 'act1_4.png';  // set of images with numbers
            idle_calorie_TextRotate_ASCIIARRAY[5] = 'act1_5.png';  // set of images with numbers
            idle_calorie_TextRotate_ASCIIARRAY[6] = 'act1_6.png';  // set of images with numbers
            idle_calorie_TextRotate_ASCIIARRAY[7] = 'act1_7.png';  // set of images with numbers
            idle_calorie_TextRotate_ASCIIARRAY[8] = 'act1_8.png';  // set of images with numbers
            idle_calorie_TextRotate_ASCIIARRAY[9] = 'act1_9.png';  // set of images with numbers

            //start of ignored block
            for (let i = 0; i < 4; i++) {
              idle_calorie_TextRotate[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 466,
                h: 466,
                center_x: 109,
                center_y: 110,
                pos_x: 109,
                pos_y: 110,
                angle: -45,
                src: 'act1_0.png',
                show_level: hmUI.show_level.ONLY_AOD,
              });
              idle_calorie_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
            };
            //end of ignored block

            idle_step_pointer_progress_img_pointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
              src: 'pointer_4.png',
              center_x: 232,
              center_y: 89,
              x: 18,
              y: 77,
              start_angle: -121,
              end_angle: 118,
              invalid_visible: false,
              cover_path: 'image_step.png',
              cover_x: 199,
              cover_y: 56,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 199,
              y: 127,
              font_array: ["act_0.png","act_1.png","act_2.png","act_3.png","act_4.png","act_5.png","act_6.png","act_7.png","act_8.png","act_9.png"],
              padding: false,
              h_space: 1,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 361,
              y: 150,
              week_en: ["day_1.png","day_2.png","day_3.png","day_4.png","day_5.png","day_6.png","day_7.png"],
              week_tc: ["day_1.png","day_2.png","day_3.png","day_4.png","day_5.png","day_6.png","day_7.png"],
              week_sc: ["day_1.png","day_2.png","day_3.png","day_4.png","day_5.png","day_6.png","day_7.png"],
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 387,
              day_startY: 119,
              day_sc_array: ["act_0.png","act_1.png","act_2.png","act_3.png","act_4.png","act_5.png","act_6.png","act_7.png","act_8.png","act_9.png"],
              day_tc_array: ["act_0.png","act_1.png","act_2.png","act_3.png","act_4.png","act_5.png","act_6.png","act_7.png","act_8.png","act_9.png"],
              day_en_array: ["act_0.png","act_1.png","act_2.png","act_3.png","act_4.png","act_5.png","act_6.png","act_7.png","act_8.png","act_9.png"],
              day_zero: 0,
              day_space: 1,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 196,
              hour_startY: 199,
              hour_array: ["time_0.png","time_1.png","time_2.png","time_3.png","time_4.png","time_5.png","time_6.png","time_7.png","time_8.png","time_9.png"],
              hour_zero: 1,
              hour_space: 6,
              hour_angle: 0,
              hour_align: hmUI.align.LEFT,

              minute_startX: 288,
              minute_startY: 199,
              minute_array: ["time_0.png","time_1.png","time_2.png","time_3.png","time_4.png","time_5.png","time_6.png","time_7.png","time_8.png","time_9.png"],
              minute_zero: 1,
              minute_space: 6,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              second_startX: 381,
              second_startY: 199,
              second_array: ["sec_0.png","sec_1.png","sec_2.png","sec_3.png","sec_4.png","sec_5.png","sec_6.png","sec_7.png","sec_8.png","sec_9.png"],
              second_zero: 1,
              second_space: 6,
              second_angle: 0,
              second_follow: 0,
              second_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_hour_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 272,
              y: 190,
              src: 'pointer_0.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_minute_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 366,
              y: 190,
              src: 'pointer_0.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_second_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 181,
              y: 231,
              src: 'image_time.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            // idle_analog_clock_pro_second_pointer_img = hmUI.createWidget(hmUI.widget.TIME_POINTER_PRO, {
              // src: 'second.png',
              // center_x: 93,
              // center_y: 232,
              // x: 82,
              // y: 82,
              // start_angle: 0,
              // end_angle: 360,
              // type: hmUI.data_type.second,
              // show_level: hmUI.show_level.ONLY_AOD,
            // });


            idle_analog_clock_pro_second_pointer_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: deviceInfo.width,
              h: deviceInfo.height,
              pos_x: 93 - 82,
              pos_y: 232 - 82,
              center_x: 93,
              center_y: 232,
              src: 'second.png',
              angle: 0,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            console.log('Watch_Face.Buttons');
            Button_1 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 284,
              y: 419,
              w: 39,
              h: 39,
              text: '',
              color: 0xFFFF8C00,
              text_size: 24,
              press_src: 'dot.png',
              normal_src: 'dot.png',
              click_func: (button_widget) => {
                click_ChangeLanguage();
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_2 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 352,
              y: 94,
              w: 97,
              h: 97,
              text: '',
              color: 0xFFFF8C00,
              text_size: 24,
              press_src: 'dot.png',
              normal_src: 'dot.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'ScheduleCalScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_3 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 341,
              y: 383,
              w: 49,
              h: 49,
              text: '',
              color: 0xFFFF8C00,
              text_size: 24,
              press_src: 'dot.png',
              normal_src: 'dot.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'AlarmInfoScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_4 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 156,
              y: 290,
              w: 155,
              h: 117,
              text: '',
              color: 0xFFFF8C00,
              text_size: 24,
              press_src: 'dot.png',
              normal_src: 'dot.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'PAI_app_Screen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_5 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 156,
              y: 11,
              w: 155,
              h: 155,
              text: '',
              color: 0xFFFF8C00,
              text_size: 24,
              press_src: 'dot.png',
              normal_src: 'dot.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'activityAppScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_6 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 19,
              y: 316,
              w: 122,
              h: 155,
              text: '',
              color: 0xFFFF8C00,
              text_size: 24,
              press_src: 'dot.png',
              normal_src: 'dot.png',
              click_func: (button_widget) => {
                click_Color();
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            function time_update(updateHour = false, updateMinute = false) {
              console.log('time_update()');
              let hour = timeSensor.hour;
              let minute = timeSensor.minute;
              let second = timeSensor.second;

              let normal_fullAngle_second = 360;
              let normal_angle_second = 0 + normal_fullAngle_second*second/60;
              if (normal_analog_clock_pro_second_pointer_img) normal_analog_clock_pro_second_pointer_img.setProperty(hmUI.prop.ANGLE, normal_angle_second);

              let idle_fullAngle_second = 360;
              let idle_angle_second = 0 + idle_fullAngle_second*second/60;
              if (idle_analog_clock_pro_second_pointer_img) idle_analog_clock_pro_second_pointer_img.setProperty(hmUI.prop.ANGLE, idle_angle_second);

            };

            function text_update() {
              console.log('text_update()');

              console.log('update text rotate heart_rate_HEART');
              let valueHeartRate = heart_rate.last;
              let normal_heart_rate_rotate_string = parseInt(valueHeartRate).toString();

              if (screenType != hmSetting.screen_type.AOD) {
                for (var i = 1; i < 3; i++) {  // hide all symbols
                  normal_heart_rate_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                if (valueHeartRate != null && valueHeartRate != undefined && isFinite(valueHeartRate) && normal_heart_rate_rotate_string.length > 0 && normal_heart_rate_rotate_string.length < 6) {  // display data if it was possible to get it
                  let img_offset = 0;
                  // alignment = CENTER_H
                  let normal_heart_rate_TextRotate_posOffset = normal_heart_rate_TextRotate_img_width * normal_heart_rate_rotate_string.length;
                  normal_heart_rate_TextRotate_posOffset = normal_heart_rate_TextRotate_posOffset + 1 * (normal_heart_rate_rotate_string.length - 1);
                  img_offset -= normal_heart_rate_TextRotate_posOffset/2;
                  // alignment end
                  
                  let index = 0;
                  for (let char of normal_heart_rate_rotate_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 3) break;
                    if (charCode >= 0 && charCode < 10) { 
                      normal_heart_rate_TextRotate[index].setProperty(hmUI.prop.POS_X, 125 + img_offset);
                      normal_heart_rate_TextRotate[index].setProperty(hmUI.prop.SRC, normal_heart_rate_TextRotate_ASCIIARRAY[charCode]);
                      normal_heart_rate_TextRotate[index].setProperty(hmUI.prop.VISIBLE, true);
                      img_offset += normal_heart_rate_TextRotate_img_width + 1;
                      index++;
                    };  // end if digit
                  };  // end char of string
                }  // end isFinite
                else {
                  normal_heart_rate_TextRotate[0].setProperty(hmUI.prop.POS_X, 125 - normal_heart_rate_TextRotate_error_img_width / 2);
                  normal_heart_rate_TextRotate[0].setProperty(hmUI.prop.SRC, 'dot.png');
                  normal_heart_rate_TextRotate[0].setProperty(hmUI.prop.VISIBLE, true);
                };  // end else isFinite

              };

              console.log('update text rotate calorie_CALORIE');
              let valueCalories = calorie.current;
              let normal_calorie_rotate_string = parseInt(valueCalories).toString();

              if (screenType != hmSetting.screen_type.AOD) {
                for (var i = 1; i < 4; i++) {  // hide all symbols
                  normal_calorie_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                if (valueCalories != null && valueCalories != undefined && isFinite(valueCalories) && normal_calorie_rotate_string.length > 0 && normal_calorie_rotate_string.length < 6) {  // display data if it was possible to get it
                  let img_offset = 0;
                  // alignment = CENTER_H
                  let normal_calorie_TextRotate_posOffset = normal_calorie_TextRotate_img_width * normal_calorie_rotate_string.length;
                  img_offset -= normal_calorie_TextRotate_posOffset/2;
                  // alignment end
                  
                  let index = 0;
                  for (let char of normal_calorie_rotate_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 4) break;
                    if (charCode >= 0 && charCode < 10) { 
                      normal_calorie_TextRotate[index].setProperty(hmUI.prop.POS_X, 109 + img_offset);
                      normal_calorie_TextRotate[index].setProperty(hmUI.prop.SRC, normal_calorie_TextRotate_ASCIIARRAY[charCode]);
                      normal_calorie_TextRotate[index].setProperty(hmUI.prop.VISIBLE, true);
                      img_offset += normal_calorie_TextRotate_img_width;
                      index++;
                    };  // end if digit
                  };  // end char of string
                }  // end isFinite
                else {
                  normal_calorie_TextRotate[0].setProperty(hmUI.prop.POS_X, 109 - normal_calorie_TextRotate_error_img_width / 2);
                  normal_calorie_TextRotate[0].setProperty(hmUI.prop.SRC, 'dot.png');
                  normal_calorie_TextRotate[0].setProperty(hmUI.prop.VISIBLE, true);
                };  // end else isFinite

              };

              console.log('update text rotate heart_rate_HEART');
              let idle_heart_rate_rotate_string = parseInt(valueHeartRate).toString();

              if (screenType == hmSetting.screen_type.AOD) {
                for (var i = 1; i < 3; i++) {  // hide all symbols
                  idle_heart_rate_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                if (valueHeartRate != null && valueHeartRate != undefined && isFinite(valueHeartRate) && idle_heart_rate_rotate_string.length > 0 && idle_heart_rate_rotate_string.length < 6) {  // display data if it was possible to get it
                  let img_offset = 0;
                  // alignment = CENTER_H
                  let idle_heart_rate_TextRotate_posOffset = idle_heart_rate_TextRotate_img_width * idle_heart_rate_rotate_string.length;
                  idle_heart_rate_TextRotate_posOffset = idle_heart_rate_TextRotate_posOffset + 1 * (idle_heart_rate_rotate_string.length - 1);
                  img_offset -= idle_heart_rate_TextRotate_posOffset/2;
                  // alignment end
                  
                  let index = 0;
                  for (let char of idle_heart_rate_rotate_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 3) break;
                    if (charCode >= 0 && charCode < 10) { 
                      idle_heart_rate_TextRotate[index].setProperty(hmUI.prop.POS_X, 125 + img_offset);
                      idle_heart_rate_TextRotate[index].setProperty(hmUI.prop.SRC, idle_heart_rate_TextRotate_ASCIIARRAY[charCode]);
                      idle_heart_rate_TextRotate[index].setProperty(hmUI.prop.VISIBLE, true);
                      img_offset += idle_heart_rate_TextRotate_img_width + 1;
                      index++;
                    };  // end if digit
                  };  // end char of string
                }  // end isFinite
                else {
                  idle_heart_rate_TextRotate[0].setProperty(hmUI.prop.POS_X, 125 - idle_heart_rate_TextRotate_error_img_width / 2);
                  idle_heart_rate_TextRotate[0].setProperty(hmUI.prop.SRC, 'dot.png');
                  idle_heart_rate_TextRotate[0].setProperty(hmUI.prop.VISIBLE, true);
                };  // end else isFinite

              };

              console.log('update text rotate calorie_CALORIE');
              let idle_calorie_rotate_string = parseInt(valueCalories).toString();

              if (screenType == hmSetting.screen_type.AOD) {
                for (var i = 1; i < 4; i++) {  // hide all symbols
                  idle_calorie_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                if (valueCalories != null && valueCalories != undefined && isFinite(valueCalories) && idle_calorie_rotate_string.length > 0 && idle_calorie_rotate_string.length < 6) {  // display data if it was possible to get it
                  let img_offset = 0;
                  // alignment = CENTER_H
                  let idle_calorie_TextRotate_posOffset = idle_calorie_TextRotate_img_width * idle_calorie_rotate_string.length;
                  img_offset -= idle_calorie_TextRotate_posOffset/2;
                  // alignment end
                  
                  let index = 0;
                  for (let char of idle_calorie_rotate_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 4) break;
                    if (charCode >= 0 && charCode < 10) { 
                      idle_calorie_TextRotate[index].setProperty(hmUI.prop.POS_X, 109 + img_offset);
                      idle_calorie_TextRotate[index].setProperty(hmUI.prop.SRC, idle_calorie_TextRotate_ASCIIARRAY[charCode]);
                      idle_calorie_TextRotate[index].setProperty(hmUI.prop.VISIBLE, true);
                      img_offset += idle_calorie_TextRotate_img_width;
                      index++;
                    };  // end if digit
                  };  // end char of string
                }  // end isFinite
                else {
                  idle_calorie_TextRotate[0].setProperty(hmUI.prop.POS_X, 109 - idle_calorie_TextRotate_error_img_width / 2);
                  idle_calorie_TextRotate[0].setProperty(hmUI.prop.SRC, 'dot.png');
                  idle_calorie_TextRotate[0].setProperty(hmUI.prop.VISIBLE, true);
                };  // end else isFinite

              };

            };

            function scale_call() {
              console.log('scale_call()');

              console.log('Weather city name');
              let weatherData = weatherSensor.getForecastWeather();
              normal_city_name_text.setProperty(hmUI.prop.TEXT, weatherData.cityName);

              console.log('Weather city name');
              idle_city_name_text.setProperty(hmUI.prop.TEXT, weatherData.cityName);

            };

            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                console.log('resume_call()');
                scale_call();
                time_update(true, true);
                text_update();

                let nawAnimationTime = now.utc;;
                
                let delay_anim_rotate_1 = 0;
                let repeat_anim_rotate_1 = 10000;
                delay_anim_rotate_1 = repeat_anim_rotate_1 - (nawAnimationTime - normal_rotate_animation_lastTime_1);
                if(delay_anim_rotate_1 < 0) delay_anim_rotate_1 = 0; 
                if((nawAnimationTime - normal_rotate_animation_lastTime_1) > repeat_anim_rotate_1) {
                  normal_rotate_animation_count_1 = 0;
                  timer_anim_rotate_1_mirror = false;
                };

                if (!timer_anim_rotate_1) {
                  timer_anim_rotate_1 = timer.createTimer(delay_anim_rotate_1, repeat_anim_rotate_1, (function (option) {
                    anim_rotate_1_complete_call()
                  })); // end timer create
                };
                
                let delay_anim_rotate_2 = 0;
                let repeat_anim_rotate_2 = 20000;
                delay_anim_rotate_2 = repeat_anim_rotate_2 - (nawAnimationTime - normal_rotate_animation_lastTime_2);
                if(delay_anim_rotate_2 < 0) delay_anim_rotate_2 = 0; 
                if((nawAnimationTime - normal_rotate_animation_lastTime_2) > repeat_anim_rotate_2) {
                  normal_rotate_animation_count_2 = 0;
                  timer_anim_rotate_2_mirror = false;
                };

                if (!timer_anim_rotate_2) {
                  timer_anim_rotate_2 = timer.createTimer(delay_anim_rotate_2, repeat_anim_rotate_2, (function (option) {
                    anim_rotate_2_complete_call()
                  })); // end timer create
                };
                if (screenType == hmSetting.screen_type.WATCHFACE) {
                  if (!normal_timerUpdateSec) {
                    let animDelay = timeSensor.utc % 1000;
                    let animRepeat = 1000;
                    normal_timerUpdateSec = timer.createTimer(animDelay, animRepeat, (function (option) {
                      time_update(false, false);
                    }));  // end timer 
                  };  // end timer check
                };  // end screenType

                if (screenType == hmSetting.screen_type.AOD) {
                  if (!idle_timerUpdateSec) {
                    let animDelay = timeSensor.utc % 1000;
                    let animRepeat = 1000;
                    idle_timerUpdateSec = timer.createTimer(animDelay, animRepeat, (function (option) {
                      time_update(false, false);
                    }));  // end timer 
                  };  // end timer check
                };  // end screenType


              }),
              pause_call: (function () {
                console.log('pause_call()');
                stop_anim_rotate_1();
                stop_anim_rotate_2();
                if (normal_timerUpdateSec) {
                  timer.stopTimer(normal_timerUpdateSec);
                  normal_timerUpdateSec = undefined;
                }
                if (idle_timerUpdateSec) {
                  timer.stopTimer(idle_timerUpdateSec);
                  idle_timerUpdateSec = undefined;
                }

              }),
            });

                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}