﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        //const logger = Logger.getLogger('watchface_SashaCX75');
        const logger = DeviceRuntimeCore.HmLogger.getLogger('watchface_SashaCX75')
        //end of ignored block

        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_battery_text_text_img = ''
        let normal_step_current_text_img = ''
        let normal_widget_text_1 = ''
        let normal_widget_text_2 = ''
        let normal_widget_text_3 = ''
        let normal_digital_clock_img_time = ''
        let normal_system_disconnect_img = ''
        let normal_system_clock_img = ''
        let normal_date_img_date_week_img = ''
        let normal_date_img_date_day = ''
        let normal_analog_clock_time_pointer_hour = ''
        let normal_analog_clock_time_pointer_minute = ''
        let idle_background_bg_img = ''
        let idle_digital_clock_img_time = ''
        let Button_1 = ''
        let Button_2 = ''
        let Button_3 = ''
        let Button_4 = ''
        let Button_5 = ''
        let Button_6 = ''


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            console.log('Watch_Face.ScreenNormal');
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 466,
              h: 466,
              src: 'Bg.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 192,
              y: 250,
              font_array: ["A100_004.png","A100_005.png","A100_006.png","A100_007.png","A100_008.png","A100_009.png","A100_010.png","A100_011.png","A100_012.png","A100_013.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 169,
              y: 312,
              font_array: ["A100_004.png","A100_005.png","A100_006.png","A100_007.png","A100_008.png","A100_009.png","A100_010.png","A100_011.png","A100_012.png","A100_013.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_widget_text_1 = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 179,
              y: 277,
              w: 103,
              h: 39,
              text_size: 25,
              char_space: 0,
              color: 0xFF6F6FFF,
              line_space: 0,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.CENTER_H,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_widget_text_2 = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 180,
              y: 328,
              w: 103,
              h: 39,
              text_size: 25,
              char_space: 0,
              color: 0xFFC0C0C0,
              line_space: 0,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.CENTER_H,
              text: 'Шаги',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_widget_text_3 = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 188,
              y: 268,
              w: 103,
              h: 39,
              text_size: 23,
              char_space: 0,
              color: 0xFFC0C0C0,
              line_space: 0,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.LEFT,
              text: 'Батарея',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 82,
              hour_startY: 202,
              hour_array: ["A100_019.png","A100_020.png","A100_021.png","A100_022.png","A100_023.png","A100_024.png","A100_025.png","A100_026.png","A100_027.png","A100_028.png"],
              hour_zero: 1,
              hour_space: 2,
              hour_angle: 0,
              hour_align: hmUI.align.CENTER_H,

              minute_startX: 287,
              minute_startY: 202,
              minute_array: ["A100_019.png","A100_020.png","A100_021.png","A100_022.png","A100_023.png","A100_024.png","A100_025.png","A100_026.png","A100_027.png","A100_028.png"],
              minute_zero: 1,
              minute_space: 1,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.CENTER_H,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 281,
              y: 265,
              src: 'btoff.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 117,
              y: 268,
              src: 'alon.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 117,
              y: 129,
              week_en: ["d1.png","d2.png","d3.png","d4.png","d5.png","d6.png","d7.png"],
              week_tc: ["d1.png","d2.png","d3.png","d4.png","d5.png","d6.png","d7.png"],
              week_sc: ["d1.png","d2.png","d3.png","d4.png","d5.png","d6.png","d7.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 205,
              day_startY: 103,
              day_sc_array: ["A100_004.png","A100_005.png","A100_006.png","A100_007.png","A100_008.png","A100_009.png","A100_010.png","A100_011.png","A100_012.png","A100_013.png"],
              day_tc_array: ["A100_004.png","A100_005.png","A100_006.png","A100_007.png","A100_008.png","A100_009.png","A100_010.png","A100_011.png","A100_012.png","A100_013.png"],
              day_en_array: ["A100_004.png","A100_005.png","A100_006.png","A100_007.png","A100_008.png","A100_009.png","A100_010.png","A100_011.png","A100_012.png","A100_013.png"],
              day_zero: 1,
              day_space: 3,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_hour = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              hour_path: 'A100_029.png',
              hour_centerX: 233,
              hour_centerY: 235,
              hour_posX: 15,
              hour_posY: 140,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_minute = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              minute_path: 'A100_030.png',
              minute_centerX: 233,
              minute_centerY: 235,
              minute_posX: 17,
              minute_posY: 206,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            console.log('Watch_Face.ScreenAOD');
            idle_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 466,
              h: 466,
              src: 'A100_003.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 82,
              hour_startY: 202,
              hour_array: ["A100_019.png","A100_020.png","A100_021.png","A100_022.png","A100_023.png","A100_024.png","A100_025.png","A100_026.png","A100_027.png","A100_028.png"],
              hour_zero: 1,
              hour_space: 2,
              hour_angle: 0,
              hour_align: hmUI.align.CENTER_H,

              minute_startX: 287,
              minute_startY: 202,
              minute_array: ["A100_019.png","A100_020.png","A100_021.png","A100_022.png","A100_023.png","A100_024.png","A100_025.png","A100_026.png","A100_027.png","A100_028.png"],
              minute_zero: 1,
              minute_space: 1,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.CENTER_H,

              show_level: hmUI.show_level.ONLY_AOD,
            });

            console.log('Watch_Face.Buttons');
            Button_1 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 182,
              y: 99,
              w: 100,
              h: 40,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({ appid: 1057409, url: 'page/index' });
              }, // end func
              longpress_func: (button_widget) => {
                hmApp.startApp({url: 'ScheduleCalScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_2 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 178,
              y: 313,
              w: 100,
              h: 40,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'activityAppScreen', native: true });
              }, // end func
              longpress_func: (button_widget) => {
                hmApp.startApp({url: 'SportListScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_3 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 178,
              y: 258,
              w: 100,
              h: 40,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'Settings_batteryManagerScreen', native: true });
              }, // end func
              longpress_func: (button_widget) => {
                hmApp.startApp({url: 'FindPhoneScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_4 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 182,
              y: 38,
              w: 100,
              h: 47,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({ appid: 1051195, url: 'page/index', params: { from_wf: true} });
              }, // end func
              longpress_func: (button_widget) => {
                hmApp.startApp({url: 'WeatherScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_5 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 78,
              y: 203,
              w: 100,
              h: 50,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'AlarmInfoScreen', native: true });
              }, // end func
              longpress_func: (button_widget) => {
                hmApp.startApp({url: 'Sleep_HomeScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_6 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 282,
              y: 203,
              w: 100,
              h: 50,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'CountdownAppScreen', native: true });
              }, // end func
              longpress_func: (button_widget) => {
                hmApp.startApp({url: 'StopWatchScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button


                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}