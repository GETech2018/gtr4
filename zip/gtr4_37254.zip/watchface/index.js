﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        const logger = Logger.getLogger('watchface_SashaCX75');
        //end of ignored block

        //dynamic modify start

        
        console.log('user_functions.js');
        // start user_functions.js
		let bg_list = [
            'bezel_1.png',
            'bezel_2.png',
            'bezel_3.png',
            //'bezel_4.png',
			//'bezel_5.png',
			//'bezel_6.png',
			//'bezel_7.png',
        ];
		let zr_list = [
            'zr_1.png',
            'zr_2.png',
            'zr_3.png',
            //'bezel_4.png',
			//'bezel_5.png',
			//'bezel_6.png',
			//'bezel_7.png',
        ];
        let mask_list = [
            'mask_1.png',
            'mask_5.png',
            'mask_4.png',
            //'bezel_4.png',
			//'bezel_5.png',
			//'bezel_6.png',
			//'bezel_7.png',
        ];
        let crownSensitivity = 70;		// уровень чувствительности колесика
        let bg_index = 0;
		let degreeSum = 0;

        function onDigitalCrown() {
            hmApp.registerSpinEvent(function (key, degree) {
                    if (key === hmApp.key.HOME) {
                        degreeSum += degree;
                        if (Math.abs(degreeSum) > crownSensitivity){
                            let step = degreeSum < 0 ? -1 : 1;
                            bg_index += step;
                            bg_index = bg_index < 0 ? bg_list.length + bg_index : bg_index % bg_list.length;
                            degreeSum = 0;
                            
                            normal_background_bg_img.setProperty(hmUI.prop.SRC, bg_list[bg_index]);
							normal_battery_icon_img.setProperty(hmUI.prop.SRC, zr_list[bg_index]);
                            normal_image_img.setProperty(hmUI.prop.SRC, mask_list[bg_index]);
							hmUI.showToast({text: "<Фон> " + parseInt(bg_index+1) });
                        }
                    }
                }
            ) // crown
        }
        // end user_functions.js

        let normal_background_bg_img = ''
        let normal_battery_circle_scale = ''
        let normal_battery_icon_img = ''
        let normal_battery_TextCircle = new Array(3);
        let normal_battery_TextCircle_ASCIIARRAY = new Array(10);
        let normal_battery_TextCircle_img_width = 10;
        let normal_battery_TextCircle_img_height = 28;
        let normal_battery_TextCircle_unit = null;
        let normal_battery_TextCircle_unit_width = 16;
        let normal_battery_image_progress_img_level = ''
        let normal_date_img_date_month_img = ''
        let normal_image_img = ''
        let normal_wind_icon_img = ''
        let normal_wind_direction_image_progress_img_level = ''
        let normal_wind_text_text_img = ''
        let normal_system_disconnect_img = ''
        let normal_system_clock_img = ''
        let normal_heart_rate_icon_img = ''
        let normal_heart_rate_circle_scale = ''
        let normal_heart_rate_text_text_img = ''
        let normal_step_icon_img = ''
        let normal_step_circle_scale = ''
        let normal_step_current_text_img = ''
        let normal_calorie_icon_img = ''
        let normal_calorie_circle_scale = ''
        let normal_calorie_current_text_img = ''
        let normal_distance_TextCircle = new Array(5);
        let normal_distance_TextCircle_ASCIIARRAY = new Array(10);
        let normal_distance_TextCircle_img_width = 10;
        let normal_distance_TextCircle_img_height = 28;
        let normal_distance_TextCircle_dot_width = 6;
        let normal_distance_icon_img = ''
        let normal_pai_icon_img = ''
        let normal_day_TextCircle = new Array(2);
        let normal_day_TextCircle_ASCIIARRAY = new Array(10);
        let normal_day_TextCircle_img_width = 10;
        let normal_day_TextCircle_img_height = 28;
        let normal_timerTextUpdate = undefined;
        let normal_week_pointer_progress_date_pointer = ''
        let normal_high_TextCircle = new Array(4);
        let normal_high_TextCircle_ASCIIARRAY = new Array(10);
        let normal_high_TextCircle_img_width = 10;
        let normal_high_TextCircle_img_height = 28;
        let normal_high_TextCircle_unit = null;
        let normal_high_TextCircle_unit_width = 10;
        let normal_high_TextCircle_dot_width = 10;
        let normal_high_TextCircle_error_img_width = 10;
        let normal_low_TextCircle = new Array(4);
        let normal_low_TextCircle_ASCIIARRAY = new Array(10);
        let normal_low_TextCircle_img_width = 10;
        let normal_low_TextCircle_img_height = 28;
        let normal_low_TextCircle_unit = null;
        let normal_low_TextCircle_unit_width = 10;
        let normal_low_TextCircle_dot_width = 10;
        let normal_low_TextCircle_error_img_width = 10;
        let normal_temperature_current_text_img = ''
        let normal_weather_image_progress_img_level = ''
        let normal_analog_clock_time_pointer_hour = ''
        let normal_analog_clock_time_pointer_minute = ''
        let normal_analog_clock_time_pointer_second = ''
        let idle_background_bg_img = ''
        let idle_analog_clock_time_pointer_hour = ''
        let idle_analog_clock_time_pointer_minute = ''
        let normal_temperature_jumpable_img_click = ''
        let normal_spo2_jumpable_img_click = ''
        let normal_heart_jumpable_img_click = ''
        let normal_step_jumpable_img_click = ''
        let Button_1 = ''
        let Button_2 = ''
        let Button_3 = ''


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            console.log('Watch_Face.ScreenNormal');
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 466,
              h: 466,
              src: 'bezel_1.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_battery_circle_scale = hmUI.createWidget(hmUI.widget.Circle_Scale, {
              // center_x: 233,
              // center_y: 233,
              // start_angle: 89,
              // end_angle: -1,
              // radius: 158,
              // line_width: 27,
              // line_cap: Flat,
              // color: 0xFF00D200,
              // mirror: False,
              // inversion: False,
              // type: hmUI.data_type.BATTERY,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            let screenType = hmSetting.getScreenType();
            normal_battery_circle_scale = hmUI.createWidget(hmUI.widget.ARC_PROGRESS, {
              center_x: 233,
              center_y: 233,
              start_angle: 89,
              end_angle: -1,
              radius: 145,
              line_width: 27,
              corner_flag: 3,
              color: 0xFF00D200,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            
            const battery = hmSensor.createSensor(hmSensor.id.BATTERY);
            battery.addEventListener(hmSensor.event.CHANGE, function() {
              text_update();
              scale_call();
            });

            normal_battery_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'zr_1.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_battery_text_circle_img = hmUI.createWidget(hmUI.widget.Text_Circle, {
              // circle_center_X: 233,
              // circle_center_Y: 233,
              // font_array: ["num_1.png","num_2.png","num_3.png","num_4.png","num_5.png","num_6.png","num_7.png","num_8.png","num_9.png","num_10.png"],
              // radius: 171,
              // angle: 46,
              // char_space_angle: 0,
              // unit: 'num_12.png',
              // zero: false,
              // reverse_direction: false,
              // unit_in_alignment: true,
              // vertical_alignment: BOTTOM,
              // horizontal_alignment: CENTER_H,
              // type: hmUI.data_type.BATTERY,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_battery_TextCircle_ASCIIARRAY[0] = 'num_1.png';  // set of images with numbers
            normal_battery_TextCircle_ASCIIARRAY[1] = 'num_2.png';  // set of images with numbers
            normal_battery_TextCircle_ASCIIARRAY[2] = 'num_3.png';  // set of images with numbers
            normal_battery_TextCircle_ASCIIARRAY[3] = 'num_4.png';  // set of images with numbers
            normal_battery_TextCircle_ASCIIARRAY[4] = 'num_5.png';  // set of images with numbers
            normal_battery_TextCircle_ASCIIARRAY[5] = 'num_6.png';  // set of images with numbers
            normal_battery_TextCircle_ASCIIARRAY[6] = 'num_7.png';  // set of images with numbers
            normal_battery_TextCircle_ASCIIARRAY[7] = 'num_8.png';  // set of images with numbers
            normal_battery_TextCircle_ASCIIARRAY[8] = 'num_9.png';  // set of images with numbers
            normal_battery_TextCircle_ASCIIARRAY[9] = 'num_10.png';  // set of images with numbers

            //start of ignored block
            for (let i = 0; i < 3; i++) {
              normal_battery_TextCircle[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 466,
                h: 466,
                center_x: 233,
                center_y: 233,
                pos_x: 233 - normal_battery_TextCircle_img_width / 2,
                pos_y: 233 - 199,
                src: 'num_1.png',
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
              normal_battery_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
            };

            normal_battery_TextCircle_unit = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 466,
              h: 466,
              center_x: 233,
              center_y: 233,
              pos_x: 233 - normal_battery_TextCircle_unit_width / 2,
              pos_y: 233 - 199,
              src: 'num_12.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            normal_battery_TextCircle_unit.setProperty(hmUI.prop.VISIBLE, false);
            //end of ignored block
            
            function toDegree (radian) {
              return radian * (180 / Math.PI);
            };

            normal_battery_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 2,
              y: -1,
              image_array: ["dicon_2.png"],
              image_length: 1,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_month_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 0,
              month_startY: 0,
              month_sc_array: ["mes_1.png","mes_2.png","mes_3.png","mes_4.png","mes_5.png","mes_6.png","mes_7.png","mes_8.png","mes_9.png","mes_10.png","mes_11.png","mes_12.png"],
              month_tc_array: ["mes_1.png","mes_2.png","mes_3.png","mes_4.png","mes_5.png","mes_6.png","mes_7.png","mes_8.png","mes_9.png","mes_10.png","mes_11.png","mes_12.png"],
              month_en_array: ["mes_1.png","mes_2.png","mes_3.png","mes_4.png","mes_5.png","mes_6.png","mes_7.png","mes_8.png","mes_9.png","mes_10.png","mes_11.png","mes_12.png"],
              month_is_character: true ,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_image_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'mask_1.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_wind_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 283,
              y: 216,
              src: 'wind.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_wind_direction_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 282,
              y: 160,
              image_array: ["wind_txt_1.png","wind_txt_2.png","wind_txt_3.png","wind_txt_4.png","wind_txt_5.png","wind_txt_6.png","wind_txt_7.png","zr_1.png"],
              image_length: 8,
              type: hmUI.data_type.WIND_DIRECTION,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_wind_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 321,
              y: 217,
              font_array: ["num_1.png","num_2.png","num_3.png","num_4.png","num_5.png","num_6.png","num_7.png","num_8.png","num_9.png","num_10.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WIND,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 317,
              y: 369,
              src: '067.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 120,
              y: 369,
              src: '0064.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 36,
              y: 237,
              src: 'podl_2.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_heart_circle_scale = hmUI.createWidget(hmUI.widget.Circle_Scale, {
              // center_x: 108,
              // center_y: 310,
              // start_angle: -90,
              // end_angle: 90,
              // radius: 45,
              // line_width: 8,
              // line_cap: Flat,
              // color: 0xFFEA5559,
              // mirror: False,
              // inversion: False,
              // type: hmUI.data_type.HEART,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_heart_rate_circle_scale = hmUI.createWidget(hmUI.widget.ARC_PROGRESS, {
              center_x: 108,
              center_y: 310,
              start_angle: -90,
              end_angle: 90,
              radius: 41,
              line_width: 8,
              corner_flag: 3,
              color: 0xFFEA5559,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            
            const heart_rate = hmSensor.createSensor(hmSensor.id.HEART);
            heart_rate.addEventListener(hmSensor.event.CHANGE, function() {
              scale_call();
            });

            normal_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 93,
              y: 311,
              font_array: ["num_1.png","num_2.png","num_3.png","num_4.png","num_5.png","num_6.png","num_7.png","num_8.png","num_9.png","num_10.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 138,
              y: 260,
              src: 'podl_1.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_step_circle_scale = hmUI.createWidget(hmUI.widget.Circle_Scale, {
              // center_x: 232,
              // center_y: 354,
              // start_angle: -90,
              // end_angle: 90,
              // radius: 66,
              // line_width: 10,
              // line_cap: Flat,
              // color: 0xFF00D936,
              // mirror: False,
              // inversion: False,
              // type: hmUI.data_type.STEP,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_step_circle_scale = hmUI.createWidget(hmUI.widget.ARC_PROGRESS, {
              center_x: 232,
              center_y: 354,
              start_angle: -90,
              end_angle: 90,
              radius: 61,
              line_width: 10,
              corner_flag: 3,
              color: 0xFF00D936,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            
            const step = hmSensor.createSensor(hmSensor.id.STEP);
            step.addEventListener(hmSensor.event.CHANGE, function() {
              scale_call();
            });

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 210,
              y: 359,
              font_array: ["num_1.png","num_2.png","num_3.png","num_4.png","num_5.png","num_6.png","num_7.png","num_8.png","num_9.png","num_10.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_calorie_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 287,
              y: 237,
              src: 'podl_2.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_cal_circle_scale = hmUI.createWidget(hmUI.widget.Circle_Scale, {
              // center_x: 358,
              // center_y: 310,
              // start_angle: 90,
              // end_angle: -90,
              // radius: 45,
              // line_width: 8,
              // line_cap: Flat,
              // color: 0xFFFF8040,
              // mirror: False,
              // inversion: False,
              // type: hmUI.data_type.CAL,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_calorie_circle_scale = hmUI.createWidget(hmUI.widget.ARC_PROGRESS, {
              center_x: 358,
              center_y: 310,
              start_angle: 90,
              end_angle: -90,
              radius: 41,
              line_width: 8,
              corner_flag: 3,
              color: 0xFFFF8040,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            
            const calorie = hmSensor.createSensor(hmSensor.id.CALORIE);
            calorie.addEventListener(hmSensor.event.CHANGE, function() {
              scale_call();
            });

            normal_calorie_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 341,
              y: 311,
              font_array: ["num_1.png","num_2.png","num_3.png","num_4.png","num_5.png","num_6.png","num_7.png","num_8.png","num_9.png","num_10.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_distance_text_circle_img = hmUI.createWidget(hmUI.widget.Text_Circle, {
              // circle_center_X: 233,
              // circle_center_Y: 233,
              // font_array: ["num_1.png","num_2.png","num_3.png","num_4.png","num_5.png","num_6.png","num_7.png","num_8.png","num_9.png","num_10.png"],
              // radius: 173,
              // angle: 81,
              // char_space_angle: 0,
              // dot_image: 'num_11.png',
              // zero: false,
              // reverse_direction: false,
              // unit_in_alignment: true,
              // vertical_alignment: BOTTOM,
              // horizontal_alignment: CENTER_H,
              // type: hmUI.data_type.DISTANCE,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_distance_TextCircle_ASCIIARRAY[0] = 'num_1.png';  // set of images with numbers
            normal_distance_TextCircle_ASCIIARRAY[1] = 'num_2.png';  // set of images with numbers
            normal_distance_TextCircle_ASCIIARRAY[2] = 'num_3.png';  // set of images with numbers
            normal_distance_TextCircle_ASCIIARRAY[3] = 'num_4.png';  // set of images with numbers
            normal_distance_TextCircle_ASCIIARRAY[4] = 'num_5.png';  // set of images with numbers
            normal_distance_TextCircle_ASCIIARRAY[5] = 'num_6.png';  // set of images with numbers
            normal_distance_TextCircle_ASCIIARRAY[6] = 'num_7.png';  // set of images with numbers
            normal_distance_TextCircle_ASCIIARRAY[7] = 'num_8.png';  // set of images with numbers
            normal_distance_TextCircle_ASCIIARRAY[8] = 'num_9.png';  // set of images with numbers
            normal_distance_TextCircle_ASCIIARRAY[9] = 'num_10.png';  // set of images with numbers

            //start of ignored block
            for (let i = 0; i < 5; i++) {
              normal_distance_TextCircle[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 466,
                h: 466,
                center_x: 233,
                center_y: 233,
                pos_x: 233 - normal_distance_TextCircle_img_width / 2,
                pos_y: 233 - 201,
                src: 'num_1.png',
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
              normal_distance_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
            };
            //end of ignored block
            
            const distance = hmSensor.createSensor(hmSensor.id.DISTANCE);
            distance.addEventListener(hmSensor.event.CHANGE, function() {
              text_update();
            });

            normal_distance_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 2,
              y: -1,
              src: 'dicon_1.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_pai_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'mask_3.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_day_text_circle_img = hmUI.createWidget(hmUI.widget.Text_Circle, {
              // circle_center_X: 233,
              // circle_center_Y: 233,
              // font_array: ["num_1.png","num_2.png","num_3.png","num_4.png","num_5.png","num_6.png","num_7.png","num_8.png","num_9.png","num_10.png"],
              // radius: 145,
              // angle: -75,
              // char_space_angle: 0,
              // zero: false,
              // reverse_direction: false,
              // unit_in_alignment: true,
              // vertical_alignment: CENTER_V,
              // horizontal_alignment: CENTER_H,
              // type: hmUI.data_type.DAY,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_day_TextCircle_ASCIIARRAY[0] = 'num_1.png';  // set of images with numbers
            normal_day_TextCircle_ASCIIARRAY[1] = 'num_2.png';  // set of images with numbers
            normal_day_TextCircle_ASCIIARRAY[2] = 'num_3.png';  // set of images with numbers
            normal_day_TextCircle_ASCIIARRAY[3] = 'num_4.png';  // set of images with numbers
            normal_day_TextCircle_ASCIIARRAY[4] = 'num_5.png';  // set of images with numbers
            normal_day_TextCircle_ASCIIARRAY[5] = 'num_6.png';  // set of images with numbers
            normal_day_TextCircle_ASCIIARRAY[6] = 'num_7.png';  // set of images with numbers
            normal_day_TextCircle_ASCIIARRAY[7] = 'num_8.png';  // set of images with numbers
            normal_day_TextCircle_ASCIIARRAY[8] = 'num_9.png';  // set of images with numbers
            normal_day_TextCircle_ASCIIARRAY[9] = 'num_10.png';  // set of images with numbers

            //start of ignored block
            for (let i = 0; i < 2; i++) {
              normal_day_TextCircle[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 466,
                h: 466,
                center_x: 233,
                center_y: 233,
                pos_x: 233 - normal_day_TextCircle_img_width / 2,
                pos_y: 233 - 159,
                src: 'num_1.png',
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
              normal_day_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
            };
            //end of ignored block
            
            const timeNaw = hmSensor.createSensor(hmSensor.id.TIME);

            normal_week_pointer_progress_date_pointer = hmUI.createWidget(hmUI.widget.DATE_POINTER, {
              src: 'date_p.png',
              center_x: 233,
              center_y: 233,
              posX: 233,
              posY: 233,
              start_angle: -97,
              end_angle: -24,
              type: hmUI.date.WEEK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_high_text_circle_img = hmUI.createWidget(hmUI.widget.Text_Circle, {
              // circle_center_X: 233,
              // circle_center_Y: 233,
              // font_array: ["num_1.png","num_2.png","num_3.png","num_4.png","num_5.png","num_6.png","num_7.png","num_8.png","num_9.png","num_10.png"],
              // radius: 171,
              // angle: 14,
              // char_space_angle: 0,
              // unit: 'num_15.png',
              // dot_image: 'num_13.png',
              // error_image: 'num_13.png',
              // zero: false,
              // reverse_direction: false,
              // unit_in_alignment: true,
              // vertical_alignment: BOTTOM,
              // horizontal_alignment: LEFT,
              // type: hmUI.data_type.WEATHER_HIGH,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_high_TextCircle_ASCIIARRAY[0] = 'num_1.png';  // set of images with numbers
            normal_high_TextCircle_ASCIIARRAY[1] = 'num_2.png';  // set of images with numbers
            normal_high_TextCircle_ASCIIARRAY[2] = 'num_3.png';  // set of images with numbers
            normal_high_TextCircle_ASCIIARRAY[3] = 'num_4.png';  // set of images with numbers
            normal_high_TextCircle_ASCIIARRAY[4] = 'num_5.png';  // set of images with numbers
            normal_high_TextCircle_ASCIIARRAY[5] = 'num_6.png';  // set of images with numbers
            normal_high_TextCircle_ASCIIARRAY[6] = 'num_7.png';  // set of images with numbers
            normal_high_TextCircle_ASCIIARRAY[7] = 'num_8.png';  // set of images with numbers
            normal_high_TextCircle_ASCIIARRAY[8] = 'num_9.png';  // set of images with numbers
            normal_high_TextCircle_ASCIIARRAY[9] = 'num_10.png';  // set of images with numbers

            //start of ignored block
            for (let i = 0; i < 4; i++) {
              normal_high_TextCircle[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 466,
                h: 466,
                center_x: 233,
                center_y: 233,
                pos_x: 233 - normal_high_TextCircle_img_width / 2,
                pos_y: 233 - 199,
                src: 'num_1.png',
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
              normal_high_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
            };

            normal_high_TextCircle_unit = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 466,
              h: 466,
              center_x: 233,
              center_y: 233,
              pos_x: 233 - normal_high_TextCircle_unit_width / 2,
              pos_y: 233 - 199,
              src: 'num_15.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            normal_high_TextCircle_unit.setProperty(hmUI.prop.VISIBLE, false);
            //end of ignored block
            const weatherSensor = hmSensor.createSensor(hmSensor.id.WEATHER);

            // normal_low_text_circle_img = hmUI.createWidget(hmUI.widget.Text_Circle, {
              // circle_center_X: 233,
              // circle_center_Y: 233,
              // font_array: ["num_1.png","num_2.png","num_3.png","num_4.png","num_5.png","num_6.png","num_7.png","num_8.png","num_9.png","num_10.png"],
              // radius: 171,
              // angle: 11,
              // char_space_angle: 0,
              // unit: 'num_14.png',
              // dot_image: 'num_13.png',
              // error_image: 'num_13.png',
              // zero: false,
              // reverse_direction: false,
              // unit_in_alignment: true,
              // vertical_alignment: BOTTOM,
              // horizontal_alignment: RIGHT,
              // type: hmUI.data_type.WEATHER_LOW,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_low_TextCircle_ASCIIARRAY[0] = 'num_1.png';  // set of images with numbers
            normal_low_TextCircle_ASCIIARRAY[1] = 'num_2.png';  // set of images with numbers
            normal_low_TextCircle_ASCIIARRAY[2] = 'num_3.png';  // set of images with numbers
            normal_low_TextCircle_ASCIIARRAY[3] = 'num_4.png';  // set of images with numbers
            normal_low_TextCircle_ASCIIARRAY[4] = 'num_5.png';  // set of images with numbers
            normal_low_TextCircle_ASCIIARRAY[5] = 'num_6.png';  // set of images with numbers
            normal_low_TextCircle_ASCIIARRAY[6] = 'num_7.png';  // set of images with numbers
            normal_low_TextCircle_ASCIIARRAY[7] = 'num_8.png';  // set of images with numbers
            normal_low_TextCircle_ASCIIARRAY[8] = 'num_9.png';  // set of images with numbers
            normal_low_TextCircle_ASCIIARRAY[9] = 'num_10.png';  // set of images with numbers

            //start of ignored block
            for (let i = 0; i < 4; i++) {
              normal_low_TextCircle[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 466,
                h: 466,
                center_x: 233,
                center_y: 233,
                pos_x: 233 - normal_low_TextCircle_img_width / 2,
                pos_y: 233 - 199,
                src: 'num_1.png',
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
              normal_low_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
            };

            normal_low_TextCircle_unit = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 466,
              h: 466,
              center_x: 233,
              center_y: 233,
              pos_x: 233 - normal_low_TextCircle_unit_width / 2,
              pos_y: 233 - 199,
              src: 'num_14.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            normal_low_TextCircle_unit.setProperty(hmUI.prop.VISIBLE, false);
            //end of ignored block

            normal_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 186,
              y: 38,
              font_array: ["num_1.png","num_2.png","num_3.png","num_4.png","num_5.png","num_6.png","num_7.png","num_8.png","num_9.png","num_10.png"],
              padding: false,
              h_space: 0,
              angle: -9,
              unit_sc: 'num_15.png',
              unit_tc: 'num_15.png',
              unit_en: 'num_15.png',
              negative_image: 'num_13.png',
              invalid_image: 'num_13.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 215,
              y: 117,
              image_array: ["weather_icon_01w.png","weather_icon_02w.png","weather_icon_03w.png","weather_icon_04w.png","weather_icon_05w.png","weather_icon_06w.png","weather_icon_07w.png","weather_icon_08w.png","weather_icon_09w.png","weather_icon_10w.png","weather_icon_11w.png","weather_icon_12w.png","weather_icon_13w.png","weather_icon_14w.png","weather_icon_15w.png","weather_icon_16w.png","weather_icon_17w.png","weather_icon_18w.png","weather_icon_19w.png","weather_icon_20w.png","weather_icon_21w.png","weather_icon_22w.png","weather_icon_23w.png","weather_icon_24w.png","weather_icon_25w.png","weather_icon_26w.png","weather_icon_27w.png","weather_icon_28w.png","weather_icon_29w.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_hour = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              hour_path: 'hour_1.png',
              hour_centerX: 233,
              hour_centerY: 233,
              hour_posX: 28,
              hour_posY: 233,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_minute = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              minute_path: 'min_1.png',
              minute_centerX: 233,
              minute_centerY: 233,
              minute_posX: 28,
              minute_posY: 233,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_second = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              second_path: 'sec_1.png',
              second_centerX: 233,
              second_centerY: 233,
              second_posX: 28,
              second_posY: 233,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            console.log('Watch_Face.ScreenAOD');
            idle_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 466,
              h: 466,
              src: 'aod_1.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_analog_clock_time_pointer_hour = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              hour_path: 'hour_aod_1.png',
              hour_centerX: 233,
              hour_centerY: 233,
              hour_posX: 28,
              hour_posY: 233,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_analog_clock_time_pointer_minute = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              minute_path: 'min_1.png',
              minute_centerX: 233,
              minute_centerY: 233,
              minute_posX: 28,
              minute_posY: 233,
              minute_cover_path: 'min_ppp.png',
              minute_cover_x: 205,
              minute_cover_y: 0,
              show_level: hmUI.show_level.ONLY_AOD,
            });
            console.log('Watch_Face.Shortcuts');

            normal_temperature_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 184,
              y: 40,
              w: 97,
              h: 97,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_spo2_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 311,
              y: 265,
              w: 97,
              h: 97,
              type: hmUI.data_type.SPO2,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 60,
              y: 263,
              w: 97,
              h: 97,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 183,
              y: 305,
              w: 97,
              h: 97,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            console.log('Watch_Face.Buttons');
            Button_1 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 61,
              y: 117,
              w: 97,
              h: 83,
              text: '',
              color: 0xFFFF8C00,
              text_size: 24,
              press_src: 'empty.png',
              normal_src: 'empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'ScheduleCalScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_2 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 292,
              y: 52,
              w: 97,
              h: 83,
              text: '',
              color: 0xFFFF8C00,
              text_size: 24,
              press_src: 'empty.png',
              normal_src: 'empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'LowBatteryScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_3 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 268,
              y: 147,
              w: 62,
              h: 62,
              text: '',
              color: 0xFFFF8C00,
              text_size: 24,
              press_src: 'empty.png',
              normal_src: 'empty.png',
              longpress_func: (button_widget) => {
                hmApp.startApp({url: 'CompassScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            function text_update() {
              console.log('text_update()');

              console.log('update text circle battery_BATTERY');
              let valueBattery = battery.current;
              let normal_battery_circle_string = parseInt(valueBattery).toString();

              if (screenType != hmSetting.screen_type.AOD) {
                for (var i = 1; i < 3; i++) {  // hide all symbols
                  normal_battery_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                normal_battery_TextCircle_unit.setProperty(hmUI.prop.VISIBLE, false);
                let char_Angle = 46;
                if (valueBattery != null && valueBattery != undefined && isFinite(valueBattery) && normal_battery_circle_string.length > 0 && normal_battery_circle_string.length < 6) {  // display data if it was possible to get it
                  let normal_battery_TextCircle_img_angle = 0;
                  let normal_battery_TextCircle_dot_img_angle = 0;
                  let normal_battery_TextCircle_unit_angle = 0;
                  normal_battery_TextCircle_img_angle = toDegree(Math.atan2(normal_battery_TextCircle_img_width/2, 171));
                  normal_battery_TextCircle_unit_angle = toDegree(Math.atan2(normal_battery_TextCircle_unit_width/2, 171));
                  // alignment = CENTER_H
                  let normal_battery_TextCircle_angleOffset = normal_battery_TextCircle_img_angle * (normal_battery_circle_string.length - 1);
                  normal_battery_TextCircle_angleOffset = normal_battery_TextCircle_angleOffset + (normal_battery_TextCircle_img_angle + normal_battery_TextCircle_unit_angle + 0) / 2;
                  char_Angle -= normal_battery_TextCircle_angleOffset;
                  // alignment end
                  
                  let firstSymbol = true;
                  let index = 0;
                  for (let char of normal_battery_circle_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 3) break;
                    if (charCode >= 0 && charCode < 10) { 
                      if (!firstSymbol) char_Angle += normal_battery_TextCircle_img_angle;
                      firstSymbol = false;
                      normal_battery_TextCircle[index].setProperty(hmUI.prop.ANGLE, char_Angle);
                      normal_battery_TextCircle[index].setProperty(hmUI.prop.POS_X, 233 - normal_battery_TextCircle_img_width / 2);
                      normal_battery_TextCircle[index].setProperty(hmUI.prop.SRC, normal_battery_TextCircle_ASCIIARRAY[charCode]);
                      normal_battery_TextCircle[index].setProperty(hmUI.prop.VISIBLE, true);
                      char_Angle += normal_battery_TextCircle_img_angle;
                      index++;
                    };  // end if digit
                  };  // end char of string
                  char_Angle += normal_battery_TextCircle_unit_angle;
                  normal_battery_TextCircle_unit.setProperty(hmUI.prop.ANGLE, char_Angle);
                  normal_battery_TextCircle_unit.setProperty(hmUI.prop.VISIBLE, true);
                }  // end isFinite

              };

              console.log('update text circle DISTANCE');
              let distanceCurrent = distance.current;
              let normal_distance_circle_string = (distanceCurrent / 1000).toFixed(2);

              if (screenType != hmSetting.screen_type.AOD) {
                for (var i = 1; i < 5; i++) {  // hide all symbols
                  normal_distance_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                let char_Angle = 81;
                if (distanceCurrent != null && distanceCurrent != undefined && isFinite(distanceCurrent) && normal_distance_circle_string.length > 0 && normal_distance_circle_string.length < 6) {  // display data if it was possible to get it
                  let normal_distance_TextCircle_img_angle = 0;
                  let normal_distance_TextCircle_dot_img_angle = 0;
                  normal_distance_TextCircle_img_angle = toDegree(Math.atan2(normal_distance_TextCircle_img_width/2, 173));
                  normal_distance_TextCircle_dot_img_angle = toDegree(Math.atan2(normal_distance_TextCircle_dot_width/2, 173));
                  // alignment = CENTER_H
                  let normal_distance_TextCircle_angleOffset = normal_distance_TextCircle_img_angle * (normal_distance_circle_string.length - 1);
                  normal_distance_TextCircle_angleOffset = normal_distance_TextCircle_angleOffset - normal_distance_TextCircle_img_angle + normal_distance_TextCircle_dot_img_angle;
                  char_Angle -= normal_distance_TextCircle_angleOffset;
                  // alignment end
                  
                  let firstSymbol = true;
                  let index = 0;
                  for (let char of normal_distance_circle_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 5) break;
                    if (charCode >= 0 && charCode < 10) { 
                      if (!firstSymbol) char_Angle += normal_distance_TextCircle_img_angle;
                      firstSymbol = false;
                      normal_distance_TextCircle[index].setProperty(hmUI.prop.ANGLE, char_Angle);
                      normal_distance_TextCircle[index].setProperty(hmUI.prop.POS_X, 233 - normal_distance_TextCircle_img_width / 2);
                      normal_distance_TextCircle[index].setProperty(hmUI.prop.SRC, normal_distance_TextCircle_ASCIIARRAY[charCode]);
                      normal_distance_TextCircle[index].setProperty(hmUI.prop.VISIBLE, true);
                      char_Angle += normal_distance_TextCircle_img_angle;
                      index++;
                    }  // end if digit
                    else { 
                      if (!firstSymbol) char_Angle += normal_distance_TextCircle_dot_img_angle; 
                      firstSymbol = false;
                      normal_distance_TextCircle[index].setProperty(hmUI.prop.ANGLE, char_Angle);
                      normal_distance_TextCircle[index].setProperty(hmUI.prop.POS_X, 233 - normal_distance_TextCircle_dot_width / 2);
                      normal_distance_TextCircle[index].setProperty(hmUI.prop.SRC, 'num_11.png');
                      normal_distance_TextCircle[index].setProperty(hmUI.prop.VISIBLE, true);
                      char_Angle += normal_distance_TextCircle_dot_img_angle;
                      index++;
                    };  // end if dot point 
                  };  // end char of string
                }  // end isFinite

              };

              console.log('update text circle day_TIME');
              let valueDay = timeNaw.day;
              let normal_day_circle_string = parseInt(valueDay).toString();

              if (screenType != hmSetting.screen_type.AOD) {
                for (var i = 1; i < 2; i++) {  // hide all symbols
                  normal_day_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                let char_Angle = -75;
                if (valueDay != null && valueDay != undefined && isFinite(valueDay) && normal_day_circle_string.length > 0 && normal_day_circle_string.length < 6) {  // display data if it was possible to get it
                  let normal_day_TextCircle_img_angle = 0;
                  let normal_day_TextCircle_dot_img_angle = 0;
                  normal_day_TextCircle_img_angle = toDegree(Math.atan2(normal_day_TextCircle_img_width/2, 145));
                  // alignment = CENTER_H
                  let normal_day_TextCircle_angleOffset = normal_day_TextCircle_img_angle * (normal_day_circle_string.length - 1);
                  char_Angle -= normal_day_TextCircle_angleOffset;
                  // alignment end
                  
                  let firstSymbol = true;
                  let index = 0;
                  for (let char of normal_day_circle_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 2) break;
                    if (charCode >= 0 && charCode < 10) { 
                      if (!firstSymbol) char_Angle += normal_day_TextCircle_img_angle;
                      firstSymbol = false;
                      normal_day_TextCircle[index].setProperty(hmUI.prop.ANGLE, char_Angle);
                      normal_day_TextCircle[index].setProperty(hmUI.prop.POS_X, 233 - normal_day_TextCircle_img_width / 2);
                      normal_day_TextCircle[index].setProperty(hmUI.prop.SRC, normal_day_TextCircle_ASCIIARRAY[charCode]);
                      normal_day_TextCircle[index].setProperty(hmUI.prop.VISIBLE, true);
                      char_Angle += normal_day_TextCircle_img_angle;
                      index++;
                    };  // end if digit
                  };  // end char of string
                }  // end isFinite

              };
              let weatherData = weatherSensor.getForecastWeather();
              let forecastData = weatherData.forecastData;
              let high_temp = -100;
              if (forecastData.count > 0) {
                high_temp = forecastData.data[0].high;
              }; // end forecastData;

              console.log('update text circle high_forecastData');
              let temperatureHigh = undefined;
              let normal_high_circle_string = undefined;
              if (high_temp > -100) {
                temperatureHigh = 0;
                normal_high_circle_string = String(high_temp)
              };

              if (screenType != hmSetting.screen_type.AOD) {
                for (var i = 1; i < 4; i++) {  // hide all symbols
                  normal_high_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                normal_high_TextCircle_unit.setProperty(hmUI.prop.VISIBLE, false);
                let char_Angle = 14;
                if (temperatureHigh != null && temperatureHigh != undefined && isFinite(temperatureHigh) && normal_high_circle_string.length > 0 && normal_high_circle_string.length < 6) {  // display data if it was possible to get it
                  let normal_high_TextCircle_img_angle = 0;
                  let normal_high_TextCircle_dot_img_angle = 0;
                  let normal_high_TextCircle_unit_angle = 0;
                  normal_high_TextCircle_img_angle = toDegree(Math.atan2(normal_high_TextCircle_img_width/2, 171));
                  normal_high_TextCircle_dot_img_angle = toDegree(Math.atan2(normal_high_TextCircle_dot_width/2, 171));
                  normal_high_TextCircle_unit_angle = toDegree(Math.atan2(normal_high_TextCircle_unit_width/2, 171));
                  
                  let firstSymbol = true;
                  let index = 0;
                  for (let char of normal_high_circle_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 4) break;
                    if (charCode >= 0 && charCode < 10) { 
                      if (!firstSymbol) char_Angle += normal_high_TextCircle_img_angle;
                      firstSymbol = false;
                      normal_high_TextCircle[index].setProperty(hmUI.prop.ANGLE, char_Angle);
                      normal_high_TextCircle[index].setProperty(hmUI.prop.POS_X, 233 - normal_high_TextCircle_img_width / 2);
                      normal_high_TextCircle[index].setProperty(hmUI.prop.SRC, normal_high_TextCircle_ASCIIARRAY[charCode]);
                      normal_high_TextCircle[index].setProperty(hmUI.prop.VISIBLE, true);
                      char_Angle += normal_high_TextCircle_img_angle;
                      index++;
                    }  // end if digit
                    else { 
                      if (!firstSymbol) char_Angle += normal_high_TextCircle_dot_img_angle; 
                      firstSymbol = false;
                      normal_high_TextCircle[index].setProperty(hmUI.prop.ANGLE, char_Angle);
                      normal_high_TextCircle[index].setProperty(hmUI.prop.POS_X, 233 - normal_high_TextCircle_dot_width / 2);
                      normal_high_TextCircle[index].setProperty(hmUI.prop.SRC, 'num_13.png');
                      normal_high_TextCircle[index].setProperty(hmUI.prop.VISIBLE, true);
                      char_Angle += normal_high_TextCircle_dot_img_angle;
                      index++;
                    };  // end if dot point 
                  };  // end char of string
                  char_Angle += normal_high_TextCircle_unit_angle;
                  normal_high_TextCircle_unit.setProperty(hmUI.prop.ANGLE, char_Angle);
                  normal_high_TextCircle_unit.setProperty(hmUI.prop.VISIBLE, true);
                }  // end isFinite
                else {
                  normal_high_TextCircle[0].setProperty(hmUI.prop.ANGLE, char_Angle);
                  normal_high_TextCircle[0].setProperty(hmUI.prop.POS_X, 233 - normal_high_TextCircle_error_img_width / 2);
                  normal_high_TextCircle[0].setProperty(hmUI.prop.SRC, 'num_13.png');
                  normal_high_TextCircle[0].setProperty(hmUI.prop.VISIBLE, true);
                };  // end else isFinite

              };
              let low_temp = -100;
              if (forecastData.count > 0) {
                low_temp = forecastData.data[0].low;
              }; // end forecastData;

              console.log('update text circle low_forecastData');
              let temperatureLow = undefined;
              let normal_low_circle_string = undefined;
              if (low_temp > -100) {
                temperatureLow = 0;
                normal_low_circle_string = String(low_temp)
              };

              if (screenType != hmSetting.screen_type.AOD) {
                for (var i = 1; i < 4; i++) {  // hide all symbols
                  normal_low_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                normal_low_TextCircle_unit.setProperty(hmUI.prop.VISIBLE, false);
                let char_Angle = 11;
                if (temperatureLow != null && temperatureLow != undefined && isFinite(temperatureLow) && normal_low_circle_string.length > 0 && normal_low_circle_string.length < 6) {  // display data if it was possible to get it
                  let normal_low_TextCircle_img_angle = 0;
                  let normal_low_TextCircle_dot_img_angle = 0;
                  let normal_low_TextCircle_unit_angle = 0;
                  normal_low_TextCircle_img_angle = toDegree(Math.atan2(normal_low_TextCircle_img_width/2, 171));
                  normal_low_TextCircle_dot_img_angle = toDegree(Math.atan2(normal_low_TextCircle_dot_width/2, 171));
                  normal_low_TextCircle_unit_angle = toDegree(Math.atan2(normal_low_TextCircle_unit_width/2, 171));
                  // alignment = RIGHT
                  let normal_low_TextCircle_angleOffset = normal_low_TextCircle_img_angle * (normal_low_circle_string.length - 1);
                  normal_low_TextCircle_angleOffset = normal_low_TextCircle_angleOffset + (normal_low_TextCircle_img_angle + normal_low_TextCircle_unit_angle + 0) / 2;
                  char_Angle -= 2 * normal_low_TextCircle_angleOffset;
                  // alignment end
                  
                  let firstSymbol = true;
                  let index = 0;
                  for (let char of normal_low_circle_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 4) break;
                    if (charCode >= 0 && charCode < 10) { 
                      if (!firstSymbol) char_Angle += normal_low_TextCircle_img_angle;
                      firstSymbol = false;
                      normal_low_TextCircle[index].setProperty(hmUI.prop.ANGLE, char_Angle);
                      normal_low_TextCircle[index].setProperty(hmUI.prop.POS_X, 233 - normal_low_TextCircle_img_width / 2);
                      normal_low_TextCircle[index].setProperty(hmUI.prop.SRC, normal_low_TextCircle_ASCIIARRAY[charCode]);
                      normal_low_TextCircle[index].setProperty(hmUI.prop.VISIBLE, true);
                      char_Angle += normal_low_TextCircle_img_angle;
                      index++;
                    }  // end if digit
                    else { 
                      if (!firstSymbol) char_Angle += normal_low_TextCircle_dot_img_angle; 
                      firstSymbol = false;
                      normal_low_TextCircle[index].setProperty(hmUI.prop.ANGLE, char_Angle);
                      normal_low_TextCircle[index].setProperty(hmUI.prop.POS_X, 233 - normal_low_TextCircle_dot_width / 2);
                      normal_low_TextCircle[index].setProperty(hmUI.prop.SRC, 'num_13.png');
                      normal_low_TextCircle[index].setProperty(hmUI.prop.VISIBLE, true);
                      char_Angle += normal_low_TextCircle_dot_img_angle;
                      index++;
                    };  // end if dot point 
                  };  // end char of string
                  char_Angle += normal_low_TextCircle_unit_angle;
                  normal_low_TextCircle_unit.setProperty(hmUI.prop.ANGLE, char_Angle);
                  normal_low_TextCircle_unit.setProperty(hmUI.prop.VISIBLE, true);
                }  // end isFinite
                else {
                  normal_low_TextCircle[0].setProperty(hmUI.prop.ANGLE, char_Angle);
                  normal_low_TextCircle[0].setProperty(hmUI.prop.POS_X, 233 - normal_low_TextCircle_error_img_width / 2);
                  normal_low_TextCircle[0].setProperty(hmUI.prop.SRC, 'num_13.png');
                  normal_low_TextCircle[0].setProperty(hmUI.prop.VISIBLE, true);
                };  // end else isFinite

              };

            };

            function scale_call() {
              console.log('scale_call()');

                console.log('update scales BATTERY');
                
                let valueBattery = battery.current;
                let targetBattery = 100;
                let progressBattery = valueBattery/targetBattery;
                if (progressBattery > 1) progressBattery = 1;
                let progress_cs_normal_battery = progressBattery;

                if (screenType != hmSetting.screen_type.AOD) {

                  // normal_battery_circle_scale_circle_scale
                  let level = Math.round(progress_cs_normal_battery * 100);
                  if (normal_battery_circle_scale) {
                    normal_battery_circle_scale.setProperty(hmUI.prop.MORE, {                      
                      center_x: 233,
                      center_y: 233,
                      start_angle: 89,
                      end_angle: -1,
                      radius: 145,
                      line_width: 27,
                      corner_flag: 3,
                      color: 0xFF00D200,
                      show_level: hmUI.show_level.ONLY_NORMAL,
                      level: level,
                    });
                  };
                };

                console.log('update scales HEART');
                
                let valueHeartRate = heart_rate.last;
                let targetHeartRate = 179;
                let progressHeartRate = (valueHeartRate - 71)/(targetHeartRate - 71);
                if (progressHeartRate < 0) progressHeartRate = 0;
                if (progressHeartRate > 1) progressHeartRate = 1;
                let progress_cs_normal_heart_rate = progressHeartRate;

                if (screenType != hmSetting.screen_type.AOD) {

                  // normal_heart_rate_circle_scale_circle_scale
                  let level = Math.round(progress_cs_normal_heart_rate * 100);
                  if (normal_heart_rate_circle_scale) {
                    normal_heart_rate_circle_scale.setProperty(hmUI.prop.MORE, {                      
                      center_x: 108,
                      center_y: 310,
                      start_angle: -90,
                      end_angle: 90,
                      radius: 41,
                      line_width: 8,
                      corner_flag: 3,
                      color: 0xFFEA5559,
                      show_level: hmUI.show_level.ONLY_NORMAL,
                      level: level,
                    });
                  };
                };

                console.log('update scales STEP');
                
                let valueStep = step.current;
                let targetStep = step.target;
                let progressStep = valueStep/targetStep;
                if (progressStep > 1) progressStep = 1;
                let progress_cs_normal_step = progressStep;

                if (screenType != hmSetting.screen_type.AOD) {

                  // normal_step_circle_scale_circle_scale
                  let level = Math.round(progress_cs_normal_step * 100);
                  if (normal_step_circle_scale) {
                    normal_step_circle_scale.setProperty(hmUI.prop.MORE, {                      
                      center_x: 232,
                      center_y: 354,
                      start_angle: -90,
                      end_angle: 90,
                      radius: 61,
                      line_width: 10,
                      corner_flag: 3,
                      color: 0xFF00D936,
                      show_level: hmUI.show_level.ONLY_NORMAL,
                      level: level,
                    });
                  };
                };

                console.log('update scales CALORIE');
                
                let valueCalories = calorie.current;
                let targetCalories = calorie.target;
                let progressCalories = valueCalories/targetCalories;
                if (progressCalories > 1) progressCalories = 1;
                let progress_cs_normal_calorie = progressCalories;

                if (screenType != hmSetting.screen_type.AOD) {

                  // normal_calorie_circle_scale_circle_scale
                  let level = Math.round(progress_cs_normal_calorie * 100);
                  if (normal_calorie_circle_scale) {
                    normal_calorie_circle_scale.setProperty(hmUI.prop.MORE, {                      
                      center_x: 358,
                      center_y: 310,
                      start_angle: 90,
                      end_angle: -90,
                      radius: 41,
                      line_width: 8,
                      corner_flag: 3,
                      color: 0xFFFF8040,
                      show_level: hmUI.show_level.ONLY_NORMAL,
                      level: level,
                    });
                  };
                };

            };

            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                console.log('resume_call()');
                scale_call();
                text_update();
                if (screenType == hmSetting.screen_type.WATCHFACE) {
                  if (!normal_timerTextUpdate) {
                    normal_timerTextUpdate = timer.createTimer(0, 1000, (function (option) {
                      text_update();
                    }));  // end timer 
                  };  // end timer check
                };  // end screenType


                console.log('resume_call.js');
                // start resume_call.js
               // if (!isAOD) snowfall.start();
                
                setTimeout(() => {
                    onDigitalCrown();
                }, 350);
                
                // end resume_call.js

              }),
              pause_call: (function () {
                console.log('pause_call()');
                if (normal_timerTextUpdate) {
                  timer.stopTimer(normal_timerTextUpdate);
                  normal_timerTextUpdate = undefined;
                }

              }),
            });

                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}