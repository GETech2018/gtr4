﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.0.1
    ** Copyright © CashaCX75. All Rights Reserved
    */

    try {
    (()=>{
        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_system_lock_img = ''
        let normal_system_dnd_img = ''
        let normal_system_disconnect_img = ''
        let normal_system_clock_img = ''
        let normal_date_img_date_week_img = ''
        let normal_date_img_date_month = ''
        let normal_date_img_date_day = ''
        let normal_battery_image_progress_img_level = ''
        let normal_digital_clock_img_time = ''
        let idle_background_bg = ''
        let idle_system_lock_img = ''
        let idle_system_dnd_img = ''
        let idle_system_disconnect_img = ''
        let idle_system_clock_img = ''
        let idle_date_img_date_day = ''
        let idle_digital_clock_img_time = ''


        //dynamic modify end
        const e = __$$hmAppManager$$__.currentApp;
        const o = e.current
          , {px: i} = (new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(e,o)),
        e.__globals__)
          , n = Logger.getLogger("watchface6");
        o.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 466,
              h: 466,
              src: 'GTR_Max_Digital_Bckg_V1.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_lock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 185,
              y: 341,
              src: 'Locked_Black.png',
              type: hmUI.system_status.LOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_dnd_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 330,
              y: 343,
              src: 'DND_Black.png',
              type: hmUI.system_status.DISTURB,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 115,
              y: 341,
              src: 'BlueT_Black.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 255,
              y: 342,
              src: 'Alarm_Black.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 276,
              y: 69,
              week_en: ["WD_D_C_0.png","WD_D_C_1.png","WD_D_C_2.png","WD_D_C_3.png","WD_D_C_4.png","WD_D_C_5.png","WD_D_C_6.png"],
              week_tc: ["WD_D_C_0.png","WD_D_C_1.png","WD_D_C_2.png","WD_D_C_3.png","WD_D_C_4.png","WD_D_C_5.png","WD_D_C_6.png"],
              week_sc: ["WD_D_C_0.png","WD_D_C_1.png","WD_D_C_2.png","WD_D_C_3.png","WD_D_C_4.png","WD_D_C_5.png","WD_D_C_6.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_month = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 313,
              month_startY: 112,
              month_sc_array: ["DMD_S_B_0.png","DMD_S_B_1.png","DMD_S_B_2.png","DMD_S_B_3.png","DMD_S_B_4.png","DMD_S_B_5.png","DMD_S_B_6.png","DMD_S_B_7.png","DMD_S_B_8.png","DMD_S_B_9.png"],
              month_tc_array: ["DMD_S_B_0.png","DMD_S_B_1.png","DMD_S_B_2.png","DMD_S_B_3.png","DMD_S_B_4.png","DMD_S_B_5.png","DMD_S_B_6.png","DMD_S_B_7.png","DMD_S_B_8.png","DMD_S_B_9.png"],
              month_en_array: ["DMD_S_B_0.png","DMD_S_B_1.png","DMD_S_B_2.png","DMD_S_B_3.png","DMD_S_B_4.png","DMD_S_B_5.png","DMD_S_B_6.png","DMD_S_B_7.png","DMD_S_B_8.png","DMD_S_B_9.png"],
              month_zero: 1,
              month_space: 6,
              month_align: hmUI.align.LEFT,
              month_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 179,
              day_startY: 106,
              day_sc_array: ["DMD_M_B_0.png","DMD_M_B_1.png","DMD_M_B_2.png","DMD_M_B_3.png","DMD_M_B_4.png","DMD_M_B_5.png","DMD_M_B_6.png","DMD_M_B_7.png","DMD_M_B_8.png","DMD_M_B_9.png"],
              day_tc_array: ["DMD_M_B_0.png","DMD_M_B_1.png","DMD_M_B_2.png","DMD_M_B_3.png","DMD_M_B_4.png","DMD_M_B_5.png","DMD_M_B_6.png","DMD_M_B_7.png","DMD_M_B_8.png","DMD_M_B_9.png"],
              day_en_array: ["DMD_M_B_0.png","DMD_M_B_1.png","DMD_M_B_2.png","DMD_M_B_3.png","DMD_M_B_4.png","DMD_M_B_5.png","DMD_M_B_6.png","DMD_M_B_7.png","DMD_M_B_8.png","DMD_M_B_9.png"],
              day_zero: 1,
              day_space: 11,
              day_align: hmUI.align.LEFT,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 99,
              y: 376,
              image_array: ["Batt_21_D_0.png","Batt_21_D_1.png","Batt_21_D_2.png","Batt_21_D_3.png","Batt_21_D_4.png","Batt_21_D_5.png","Batt_21_D_6.png","Batt_21_D_7.png","Batt_21_D_8.png","Batt_21_D_9.png","Batt_21_D_10.png","Batt_21_D_11.png","Batt_21_D_12.png","Batt_21_D_13.png","Batt_21_D_14.png","Batt_21_D_15.png","Batt_21_D_16.png","Batt_21_D_17.png","Batt_21_D_18.png","Batt_21_D_19.png","Batt_21_D_20.png","Batt_21_D_21.png"],
              image_length: 22,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 57,
              hour_startY: 216,
              hour_array: ["DMD_B_B_0.png","DMD_B_B_1.png","DMD_B_B_2.png","DMD_B_B_3.png","DMD_B_B_4.png","DMD_B_B_5.png","DMD_B_B_6.png","DMD_B_B_7.png","DMD_B_B_8.png","DMD_B_B_9.png"],
              hour_zero: 1,
              hour_space: 21,
              hour_align: hmUI.align.LEFT,

              minute_startX: 254,
              minute_startY: 215,
              minute_array: ["DMD_B_B_0.png","DMD_B_B_1.png","DMD_B_B_2.png","DMD_B_B_3.png","DMD_B_B_4.png","DMD_B_B_5.png","DMD_B_B_6.png","DMD_B_B_7.png","DMD_B_B_8.png","DMD_B_B_9.png"],
              minute_zero: 1,
              minute_space: 21,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              second_startX: 62,
              second_startY: 121,
              second_array: ["DMD_M_B_0.png","DMD_M_B_1.png","DMD_M_B_2.png","DMD_M_B_3.png","DMD_M_B_4.png","DMD_M_B_5.png","DMD_M_B_6.png","DMD_M_B_7.png","DMD_M_B_8.png","DMD_M_B_9.png"],
              second_zero: 1,
              second_space: 10,
              second_follow: 0,
              second_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            idle_background_bg = hmUI.createWidget(hmUI.widget.FILL_RECT, {
              x: 0,
              y: 0,
              w: 466,
              h: 466,
              color: '0xFF000000',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_system_lock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 185,
              y: 341,
              src: 'Locked_White.png',
              type: hmUI.system_status.LOCK,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_system_dnd_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 330,
              y: 343,
              src: 'DND_White.png',
              type: hmUI.system_status.DISTURB,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 115,
              y: 341,
              src: 'BlueT_White.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 255,
              y: 342,
              src: 'Alarm_white.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 178,
              day_startY: 106,
              day_sc_array: ["DMD_M_W_0.png","DMD_M_W_1.png","DMD_M_W_2.png","DMD_M_W_3.png","DMD_M_W_4.png","DMD_M_W_5.png","DMD_M_W_6.png","DMD_M_W_7.png","DMD_M_W_8.png","DMD_M_W_9.png"],
              day_tc_array: ["DMD_M_W_0.png","DMD_M_W_1.png","DMD_M_W_2.png","DMD_M_W_3.png","DMD_M_W_4.png","DMD_M_W_5.png","DMD_M_W_6.png","DMD_M_W_7.png","DMD_M_W_8.png","DMD_M_W_9.png"],
              day_en_array: ["DMD_M_W_0.png","DMD_M_W_1.png","DMD_M_W_2.png","DMD_M_W_3.png","DMD_M_W_4.png","DMD_M_W_5.png","DMD_M_W_6.png","DMD_M_W_7.png","DMD_M_W_8.png","DMD_M_W_9.png"],
              day_zero: 1,
              day_space: 12,
              day_align: hmUI.align.LEFT,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 57,
              hour_startY: 216,
              hour_array: ["DMD_B_W_0.png","DMD_B_W_1.png","DMD_B_W_2.png","DMD_B_W_3.png","DMD_B_W_4.png","DMD_B_W_5.png","DMD_B_W_6.png","DMD_B_W_7.png","DMD_B_W_8.png","DMD_B_W_9.png"],
              hour_zero: 1,
              hour_space: 21,
              hour_align: hmUI.align.LEFT,

              minute_startX: 254,
              minute_startY: 215,
              minute_array: ["DMD_B_W_0.png","DMD_B_W_1.png","DMD_B_W_2.png","DMD_B_W_3.png","DMD_B_W_4.png","DMD_B_W_5.png","DMD_B_W_6.png","DMD_B_W_7.png","DMD_B_W_8.png","DMD_B_W_9.png"],
              minute_zero: 1,
              minute_space: 21,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_AOD,
            });


                //dynamic modify end
            },
            onInit() {
                n.log("index page.js on init invoke")
            },
            build() {
                this.init_view(),
                n.log("index page.js on ready invoke")
            },
            onDestroy() {
                n.log("index page.js on destroy invoke")
            }
        })
    }
    )()
} catch (e) {
    console.log("Mini Program Error", e),
    e && e.stack && e.stack.split(/\n/).forEach((e=>console.log("error stack", e)))
}
