/*
** Facemaker bundle tool v0.0.3
* *huamiOS watchface js version v2.0.1
* *Copyright © Huami. All Rights Reserved
*/


try {
	(() => {
		var __$$app$$__ = __$$hmAppManager$$__.currentApp;
		var __$$module$$__ = __$$app$$__.current;

		//drink is a name,can modify
		var h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__), 'drink');

		'use strict';

		//dynamic modify start
		let normal_img0 = '';
		let normal_img1 = '';
		let normal_img2 = '';
		let normal_img3 = '';
		let normal_img4 = '';
		let normal_img5 = '';
		let normal_img6 = '';
		let normal_img7 = '';
		let normal_weather_imageset9 = '';
		let normal_temperature_current_imagecombo10 = '';
		let timeInterval;
		let normal_hour_high_imageset12 = '';
		let normal_hour_high_imageset12_array = ['0050.png','0051.png','0052.png'];
		let normal_hour_low_imageset13 = '';
		let normal_hour_low_imageset13_array = ['0053.png','0054.png','0055.png','0056.png','0057.png','0058.png','0059.png','0060.png','0061.png','0062.png'];
		let normal_minute_high_imageset14 = '';
		let normal_minute_high_imageset14_array = ['0063.png','0064.png','0065.png','0066.png','0067.png','0068.png'];
		let normal_minute_low_imageset15 = '';
		let normal_minute_low_imageset15_array = ['0069.png','0070.png','0071.png','0072.png','0073.png','0074.png','0075.png','0076.png','0077.png','0078.png'];
		let normal_second_low_imageset16 = '';
		let normal_second_low_imageset16_array = ['0079.png','0080.png','0079.png','0080.png','0079.png','0080.png','0079.png','0080.png','0079.png','0080.png'];
		let normal_date_imagecombo18 = '';
		let normal_img19 = '';
		let normal_month_imagecombo20 = '';
		let normal_airpressure_imagecombo22 = '';
		let normal_img23 = '';
		let normal_humidity_imagecombo25 = '';
		let normal_img26 = '';
		let normal_wind_imagecombo28 = '';
		let normal_img29 = '';
		let normal_steps_imagecombo31 = '';
		let normal_img32 = '';
		let normal_distance_imagecombo34 = '';
		let normal_img35 = '';
		let normal_heart_current_imagecombo37 = '';
		let normal_img38 = '';
		let normal_calories_imagecombo40 = '';
		let normal_img41 = '';
		let normal_blood_oxygen_imagecombo43 = '';
		let normal_img44 = '';
		let normal_battery_imagecombo46 = '';
		let normal_img47 = '';
		let normal_alarm_status49 = '';
		let normal_bt_status50 = '';
		let normal_lock_status51 = '';
		let normal_week_imageset53 = '';
		let normal_week_imageset55 = '';
		let normal_week_imageset57 = '';
		let normal_week_imageset59 = '';
		let normal_week_imageset61 = '';
		let normal_week_imageset63 = '';
		let idle_hour_high_imageset67 = '';
		let idle_hour_high_imageset67_array = ['0210.png','0211.png','0212.png'];
		let idle_hour_low_imageset68 = '';
		let idle_hour_low_imageset68_array = ['0210.png','0211.png','0212.png','0213.png','0214.png','0215.png','0216.png','0217.png','0218.png','0219.png'];
		let idle_minute_high_imageset69 = '';
		let idle_minute_high_imageset69_array = ['0210.png','0211.png','0212.png','0213.png','0214.png','0215.png'];
		let idle_minute_low_imageset70 = '';
		let idle_minute_low_imageset70_array = ['0210.png','0211.png','0212.png','0213.png','0214.png','0215.png','0216.png','0217.png','0218.png','0219.png'];
		let idle_second_low_imageset71 = '';
		let idle_second_low_imageset71_array = ['0220.png','0221.png','0220.png','0221.png','0220.png','0221.png','0220.png','0221.png','0220.png','0221.png'];
		let container_1697718234604 = '';
		let container_1697718234604_customs = [
			{
				label: 'Data',
				widgets: [
					'normal_week_imageset53',
				]
			},
			{
				label: 'Data',
				widgets: [
					'normal_week_imageset55',
				]
			},
			{
				label: 'Date',
				widgets: [
					'normal_week_imageset57',
				]
			},
			{
				label: 'Date',
				widgets: [
					'normal_week_imageset59',
				]
			},
			{
				label: 'Data',
				widgets: [
					'normal_week_imageset61',
				]
			},
			{
				label: 'Data',
				widgets: [
					'normal_week_imageset63',
				]
			},
		];
		let container_1697718234604_selected = 0;
		//dynamic modify end

		//not required
		const logger = DeviceRuntimeCore.HmLogger.getLogger("yeguang");

		__$$module$$__.module = DeviceRuntimeCore.WatchFace({
			init_view() {

				const timeSensor = hmSensor.createSensor(hmSensor.id.TIME);
				const vibrateSensor = hmSensor.createSensor(hmSensor.id.VIBRATE);
				let screenType = hmSetting.getScreenType();

				normal_img0 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 0,
					y: 0,
					w: 466,
					h: 466,
					src: '0002.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img1 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 0,
					y: 0,
					w: 466,
					h: 466,
					src: '0003.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img2 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 0,
					y: 0,
					w: 466,
					h: 466,
					src: '0004.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img3 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 212,
					y: 233,
					w: 6,
					h: 118,
					src: '0005.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img4 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 248,
					y: 233,
					w: 6,
					h: 118,
					src: '0005.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img5 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 218,
					y: 240,
					w: 29,
					h: 30,
					src: '0006.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img6 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 218,
					y: 277,
					w: 30,
					h: 30,
					src: '0007.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img7 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 221,
					y: 315,
					w: 25,
					h: 30,
					src: '0008.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_weather_imageset9 = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
					x: 177,
					y: 355,
					image_array: ["0009.png","0010.png","0011.png","0012.png","0013.png","0014.png","0015.png","0016.png","0017.png","0018.png","0019.png","0020.png","0021.png","0022.png","0023.png","0024.png","0025.png","0026.png","0027.png","0028.png","0029.png","0030.png","0031.png","0032.png","0033.png","0034.png","0035.png","0036.png","0037.png"],
					image_length: 29,
					type: hmUI.data_type.WEATHER_CURRENT,
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_temperature_current_imagecombo10 = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
					x: 288,
					y: 402,
					font_array: ["0038.png","0039.png","0040.png","0041.png","0042.png","0043.png","0044.png","0045.png","0046.png","0047.png"],
					padding: false,
					h_space: -4,
					unit_sc: ["0049.png"],
					unit_tc: ["0049.png"],
					unit_en: ["0049.png"],
					negative_image: ["0048.png"],
					invalid_image: ["0048.png"],
					align_h: hmUI.align.CENTER_H,
					type: hmUI.data_type.WEATHER_CURRENT,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_hour_high_imageset12 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 35,
					y: 120,
					w: 35,
					h: 120,
					src: '0052.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				})

				normal_hour_low_imageset13 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 124,
					y: 120,
					w: 124,
					h: 120,
					src: '0062.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				})

				normal_minute_high_imageset14 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 255,
					y: 120,
					w: 255,
					h: 120,
					src: '0068.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				})

				normal_minute_low_imageset15 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 344,
					y: 120,
					w: 344,
					h: 120,
					src: '0078.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				})

				normal_second_low_imageset16 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 223,
					y: 147,
					w: 223,
					h: 147,
					src: '0080.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				})

				normal_date_imagecombo18 = hmUI.createWidget(hmUI.widget.IMG_DATE, {
					day_startX: 139,
					day_startY: 8,
					day_sc_array: ["0081.png","0082.png","0083.png","0084.png","0085.png","0086.png","0087.png","0088.png","0089.png","0090.png"],
					day_tc_array: ["0081.png","0082.png","0083.png","0084.png","0085.png","0086.png","0087.png","0088.png","0089.png","0090.png"],
					day_en_array: ["0081.png","0082.png","0083.png","0084.png","0085.png","0086.png","0087.png","0088.png","0089.png","0090.png"],
					day_zero: true,
					day_space: -8,
					day_align: hmUI.align.CENTER_H,
					day_is_character: false,
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img19 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 223,
					y: 22,
					w: 19,
					h: 41,
					src: '0091.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_month_imagecombo20 = hmUI.createWidget(hmUI.widget.IMG_DATE, {
					month_startX: 247,
					month_startY: 8,
					month_sc_array: ["0081.png","0082.png","0083.png","0084.png","0085.png","0086.png","0087.png","0088.png","0089.png","0090.png"],
					month_tc_array: ["0081.png","0082.png","0083.png","0084.png","0085.png","0086.png","0087.png","0088.png","0089.png","0090.png"],
					month_en_array: ["0081.png","0082.png","0083.png","0084.png","0085.png","0086.png","0087.png","0088.png","0089.png","0090.png"],
					month_zero: true,
					month_space: -8,
					month_align: hmUI.align.CENTER_H,
					month_is_character: false,
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_airpressure_imagecombo22 = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
					x: 288,
					y: 360,
					font_array: ["0092.png","0093.png","0094.png","0095.png","0096.png","0097.png","0098.png","0099.png","0100.png","0101.png"],
					padding: false,
					h_space: -4,
					align_h: hmUI.align.CENTER_H,
					type: hmUI.data_type.ALTIMETER,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img23 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 387,
					y: 364,
					w: 25,
					h: 25,
					src: '0102.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_humidity_imagecombo25 = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
					x: 88,
					y: 360,
					font_array: ["0103.png","0104.png","0105.png","0106.png","0107.png","0108.png","0109.png","0110.png","0111.png","0112.png"],
					padding: false,
					h_space: -4,
					align_h: hmUI.align.CENTER_H,
					type: hmUI.data_type.HUMIDITY,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img26 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 60,
					y: 365,
					w: 16,
					h: 20,
					src: '0113.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_wind_imagecombo28 = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
					x: 111,
					y: 402,
					font_array: ["0038.png","0039.png","0040.png","0041.png","0042.png","0043.png","0044.png","0045.png","0046.png","0047.png"],
					padding: false,
					h_space: -4,
					align_h: hmUI.align.CENTER_H,
					type: hmUI.data_type.WIND,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img29 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 93,
					y: 405,
					w: 23,
					h: 23,
					src: '0114.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_steps_imagecombo31 = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
					x: 69,
					y: 236,
					font_array: ["0115.png","0116.png","0117.png","0118.png","0119.png","0120.png","0121.png","0122.png","0123.png","0124.png"],
					padding: false,
					h_space: -6,
					align_h: hmUI.align.CENTER_H,
					type: hmUI.data_type.STEP,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img32 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 19,
					y: 241,
					w: 28,
					h: 30,
					src: '0125.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_distance_imagecombo34 = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
					x: 278,
					y: 236,
					font_array: ["0126.png","0127.png","0128.png","0129.png","0130.png","0131.png","0132.png","0133.png","0134.png","0135.png"],
					padding: false,
					h_space: -6,
					dot_image: '0136.png',
					align_h: hmUI.align.CENTER_H,
					type: hmUI.data_type.DISTANCE,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img35 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 416,
					y: 241,
					w: 28,
					h: 28,
					src: '0137.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_heart_current_imagecombo37 = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
					x: 101,
					y: 277,
					font_array: ["0138.png","0139.png","0140.png","0141.png","0142.png","0143.png","0144.png","0145.png","0146.png","0147.png"],
					padding: false,
					h_space: -6,
					invalid_image: '0148.png',
					align_h: hmUI.align.CENTER_H,
					type: hmUI.data_type.HEART,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img38 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 24,
					y: 277,
					w: 40,
					h: 35,
					src: '0149.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_calories_imagecombo40 = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
					x: 287,
					y: 277,
					font_array: ["0150.png","0151.png","0152.png","0153.png","0154.png","0155.png","0156.png","0157.png","0158.png","0159.png"],
					padding: false,
					h_space: -6,
					align_h: hmUI.align.CENTER_H,
					type: hmUI.data_type.CAL,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img41 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 407,
					y: 279,
					w: 28,
					h: 28,
					src: '0160.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_blood_oxygen_imagecombo43 = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
					x: 102,
					y: 313,
					font_array: ["0138.png","0139.png","0140.png","0141.png","0142.png","0143.png","0144.png","0145.png","0146.png","0147.png"],
					padding: false,
					h_space: -6,
					align_h: hmUI.align.CENTER_H,
					type: hmUI.data_type.SPO2,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img44 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 44,
					y: 318,
					w: 26,
					h: 26,
					src: '0161.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_battery_imagecombo46 = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
					x: 281,
					y: 313,
					font_array: ["0150.png","0151.png","0152.png","0153.png","0154.png","0155.png","0156.png","0157.png","0158.png","0159.png"],
					padding: false,
					h_space: -6,
					unit_sc: '0162.png',
					unit_tc: '0162.png',
					unit_en: '0162.png',
					align_h: hmUI.align.CENTER_H,
					type: hmUI.data_type.BATTERY,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img47 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 395,
					y: 317,
					w: 30,
					h: 30,
					src: '0163.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_alarm_status49 = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
					x: 218,
					y: 240,
					w: 29,
					h: 30,
					type: hmUI.system_status.CLOCK,
					src: '0164.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_bt_status50 = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
					x: 218,
					y: 277,
					w: 30,
					h: 30,
					type: hmUI.system_status.DISCONNECT,
					src: '0165.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_lock_status51 = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
					x: 221,
					y: 315,
					w: 25,
					h: 30,
					type: hmUI.system_status.LOCK,
					src: '0166.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_week_imageset53 = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
					x: 117,
					y: 76,
					week_en: ["0167.png","0168.png","0169.png","0170.png","0171.png","0172.png","0173.png"],
					week_tc: ["0167.png","0168.png","0169.png","0170.png","0171.png","0172.png","0173.png"],
					week_sc: ["0167.png","0168.png","0169.png","0170.png","0171.png","0172.png","0173.png"],
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_week_imageset55 = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
					x: 117,
					y: 76,
					week_en: ["0174.png","0175.png","0176.png","0177.png","0178.png","0179.png","0180.png"],
					week_tc: ["0174.png","0175.png","0176.png","0177.png","0178.png","0179.png","0180.png"],
					week_sc: ["0174.png","0175.png","0176.png","0177.png","0178.png","0179.png","0180.png"],
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_week_imageset55.setProperty(hmUI.prop.VISIBLE, false);

				normal_week_imageset57 = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
					x: 117,
					y: 76,
					week_en: ["0181.png","0182.png","0183.png","0184.png","0185.png","0186.png","0187.png"],
					week_tc: ["0181.png","0182.png","0183.png","0184.png","0185.png","0186.png","0187.png"],
					week_sc: ["0181.png","0182.png","0183.png","0184.png","0185.png","0186.png","0187.png"],
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_week_imageset57.setProperty(hmUI.prop.VISIBLE, false);

				normal_week_imageset59 = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
					x: 117,
					y: 76,
					week_en: ["0188.png","0189.png","0190.png","0191.png","0192.png","0193.png","0194.png"],
					week_tc: ["0188.png","0189.png","0190.png","0191.png","0192.png","0193.png","0194.png"],
					week_sc: ["0188.png","0189.png","0190.png","0191.png","0192.png","0193.png","0194.png"],
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_week_imageset59.setProperty(hmUI.prop.VISIBLE, false);

				normal_week_imageset61 = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
					x: 117,
					y: 76,
					week_en: ["0195.png","0196.png","0197.png","0198.png","0199.png","0200.png","0201.png"],
					week_tc: ["0195.png","0196.png","0197.png","0198.png","0199.png","0200.png","0201.png"],
					week_sc: ["0195.png","0196.png","0197.png","0198.png","0199.png","0200.png","0201.png"],
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_week_imageset61.setProperty(hmUI.prop.VISIBLE, false);

				normal_week_imageset63 = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
					x: 117,
					y: 76,
					week_en: ["0202.png","0203.png","0204.png","0205.png","0206.png","0207.png","0208.png"],
					week_tc: ["0202.png","0203.png","0204.png","0205.png","0206.png","0207.png","0208.png"],
					week_sc: ["0202.png","0203.png","0204.png","0205.png","0206.png","0207.png","0208.png"],
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_week_imageset63.setProperty(hmUI.prop.VISIBLE, false);

				idle_hour_high_imageset67 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 24,
					y: 134,
					w: 24,
					h: 134,
					src: '0212.png',
					enable: false,
					show_level: hmUI.show_level.ONAL_AOD,
				})

				idle_hour_low_imageset68 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 117,
					y: 134,
					w: 117,
					h: 134,
					src: '0219.png',
					enable: false,
					show_level: hmUI.show_level.ONAL_AOD,
				})

				idle_minute_high_imageset69 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 244,
					y: 134,
					w: 244,
					h: 134,
					src: '0215.png',
					enable: false,
					show_level: hmUI.show_level.ONAL_AOD,
				})

				idle_minute_low_imageset70 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 337,
					y: 134,
					w: 337,
					h: 134,
					src: '0219.png',
					enable: false,
					show_level: hmUI.show_level.ONAL_AOD,
				})

				idle_second_low_imageset71 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 224,
					y: 207,
					w: 224,
					h: 207,
					src: '0221.png',
					enable: false,
					show_level: hmUI.show_level.ONAL_AOD,
				})

				container_1697718234604 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 103,
					y: 70,
					w: 260,
					h: 50,
					src: '0209.png',
					show_level: hmUI.show_level.ONLY_NORMAL
				});

				container_1697718234604.addEventListener(hmUI.event.CLICK_DOWN, (info) => {
					container_1697718234604_selected = (container_1697718234604_selected+1 > container_1697718234604_customs.length-1) ? 0 : container_1697718234604_selected+1;
					for (let w = 0; w < container_1697718234604_customs.length; w++) {
						for (let z of container_1697718234604_customs[w].widgets) {
							eval(z).setProperty(hmUI.prop.VISIBLE, ((w == container_1697718234604_selected) ? true : false));
						}
					}
					hmUI.showToast({
						text: container_1697718234604_customs[container_1697718234604_selected].label.toString() + ' Włączony'
					});
					vibrateSensor.stop();
					vibrateSensor.scene = 25;
					vibrateSensor.start();
				});

				function updateTime() {
					normal_hour_high_imageset12.setProperty(hmUI.prop.MORE, {
						src: normal_hour_high_imageset12_array[(timeSensor.format_hour.toString().length == 2 ? timeSensor.format_hour.toString().charAt(0) : 0)]
					})
					normal_hour_low_imageset13.setProperty(hmUI.prop.MORE, {
						src: normal_hour_low_imageset13_array[(timeSensor.format_hour.toString().length == 2 ? timeSensor.format_hour.toString().charAt(1) : timeSensor.format_hour.toString().charAt(0))]
					})
					normal_minute_high_imageset14.setProperty(hmUI.prop.MORE, {
						src: normal_minute_high_imageset14_array[(timeSensor.minute.toString().length == 2 ? timeSensor.minute.toString().charAt(0) : 0)]
					})
					normal_minute_low_imageset15.setProperty(hmUI.prop.MORE, {
						src: normal_minute_low_imageset15_array[(timeSensor.minute.toString().length == 2 ? timeSensor.minute.toString().charAt(1) : timeSensor.minute.toString().charAt(0))]
					})
					normal_second_low_imageset16.setProperty(hmUI.prop.MORE, {
						src: normal_second_low_imageset16_array[(timeSensor.second.toString().length == 2 ? timeSensor.second.toString().charAt(1) : timeSensor.second.toString().charAt(0))]
					})
					idle_hour_high_imageset67.setProperty(hmUI.prop.MORE, {
						src: idle_hour_high_imageset67_array[(timeSensor.format_hour.toString().length == 2 ? timeSensor.format_hour.toString().charAt(0) : 0)]
					})
					idle_hour_low_imageset68.setProperty(hmUI.prop.MORE, {
						src: idle_hour_low_imageset68_array[(timeSensor.format_hour.toString().length == 2 ? timeSensor.format_hour.toString().charAt(1) : timeSensor.format_hour.toString().charAt(0))]
					})
					idle_minute_high_imageset69.setProperty(hmUI.prop.MORE, {
						src: idle_minute_high_imageset69_array[(timeSensor.minute.toString().length == 2 ? timeSensor.minute.toString().charAt(0) : 0)]
					})
					idle_minute_low_imageset70.setProperty(hmUI.prop.MORE, {
						src: idle_minute_low_imageset70_array[(timeSensor.minute.toString().length == 2 ? timeSensor.minute.toString().charAt(1) : timeSensor.minute.toString().charAt(0))]
					})
					idle_second_low_imageset71.setProperty(hmUI.prop.MORE, {
						src: idle_second_low_imageset71_array[(timeSensor.second.toString().length == 2 ? timeSensor.second.toString().charAt(1) : timeSensor.second.toString().charAt(0))]
					})
				}

				timeSensor.addEventListener(hmSensor.event.CHANGE, function() {
					updateTime();
				});

				const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
					resume_call: (function () {
						updateTime();
						timeInterval = setInterval(updateTime, 1000);
					}),
					pause_call: (function () {
						clearInterval(timeInterval);
					}),
				})
			},

		onInit() {
			console.log('index page.js on init invoke')
			this.init_view()
		},
		onReady() {
			console.log('index page.js on ready invoke')
		},
		onShow() {
			console.log('index page.js on show invoke')
		},
		onHide() {
			console.log('index page.js on hide invoke')
		},
		onDestroy() {
			console.log('index page.js on destroy invoke')
		},
	});	})()
} catch (e) {
	console.log(e)
}