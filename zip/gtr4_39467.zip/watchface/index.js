﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        const logger = Logger.getLogger('watchface_SashaCX75');
        //end of ignored block

        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_system_disconnect_img = ''
        let normal_moon_pointer_progress_img_pointer = ''
        let normal_sun_pointer_progress_img_pointer = ''
        let normal_analog_clock_time_pointer_hour = ''
        let normal_analog_clock_time_pointer_minute = ''
        let normal_analog_clock_time_pointer_second = ''
        let idle_background_bg_img = ''
        let idle_system_disconnect_img = ''
        let idle_moon_pointer_progress_img_pointer = ''
        let idle_sun_pointer_progress_img_pointer = ''
        let idle_analog_clock_time_pointer_hour = ''
        let idle_analog_clock_time_pointer_minute = ''
        let normal_spo2_jumpable_img_click = ''
		
		let btn_bezel = ''
        let bezel_num = 1
        let bezel_all = 7
     
        function click_Bezel() {
            if(bezel_num>=bezel_all) {bezel_num=1;}
            else { bezel_num=bezel_num+1;}
            hmUI.showToast({text: "<Color> " + parseInt(bezel_num) });
            normal_background_bg_img.setProperty(hmUI.prop.SRC, "bg_" + parseInt(bezel_num) + ".png");
        }


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            console.log('Watch_Face.ScreenNormal');
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 466,
              h: 466,
              src: 'bg_1.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 216,
              y: 322,
              src: 'bt.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_moon_pointer_progress_img_pointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
              src: 'sunmoon_moon.png',
              center_x: 233,
              center_y: 233,
              x: 47,
              y: 162,
              start_angle: -103,
              end_angle: 103,
              invalid_visible: false,
              type: hmUI.data_type.MOON_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sun_pointer_progress_img_pointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
              src: 'sunmoon_sun.png',
              center_x: 233,
              center_y: 233,
              x: 47,
              y: 200,
              start_angle: -104,
              end_angle: 104,
              invalid_visible: false,
              type: hmUI.data_type.SUN_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_hour = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              hour_path: 'wfs_hourhand_0364d302_914e_4bcb_950d_5c47835bf3b3.png',
              hour_centerX: 233,
              hour_centerY: 233,
              hour_posX: 28,
              hour_posY: 226,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_minute = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              minute_path: 'wfs_minutehand_b279e6e2_1e07_4560_8bc4_b5ecfdd18079.png',
              minute_centerX: 233,
              minute_centerY: 233,
              minute_posX: 24,
              minute_posY: 225,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_second = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              second_path: 'wfs_secondshand_6497624f_2cf2_428e_9c81_a94dc3555f1a.png',
              second_centerX: 233,
              second_centerY: 233,
              second_posX: 22,
              second_posY: 232,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            console.log('Watch_Face.ScreenAOD');
            idle_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 466,
              h: 466,
              src: 'aod.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 216,
              y: 322,
              src: 'bt.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_moon_pointer_progress_img_pointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
              src: 'sunmoon_moon.png',
              center_x: 233,
              center_y: 233,
              x: 47,
              y: 162,
              start_angle: -103,
              end_angle: 103,
              invalid_visible: false,
              type: hmUI.data_type.MOON_CURRENT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_sun_pointer_progress_img_pointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
              src: 'sunmoon_sun.png',
              center_x: 233,
              center_y: 233,
              x: 47,
              y: 200,
              start_angle: -104,
              end_angle: 104,
              invalid_visible: false,
              type: hmUI.data_type.SUN_CURRENT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_analog_clock_time_pointer_hour = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              hour_path: 'hour_aod.png',
              hour_centerX: 233,
              hour_centerY: 233,
              hour_posX: 28,
              hour_posY: 226,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_analog_clock_time_pointer_minute = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              minute_path: 'minute_aod.png',
              minute_centerX: 233,
              minute_centerY: 233,
              minute_posX: 24,
              minute_posY: 225,
              show_level: hmUI.show_level.ONLY_AOD,
            });
            console.log('Watch_Face.Shortcuts');

            btn_bezel = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 197,
              y: 197,
              text: '',
              w: 73,
              h: 73,
              normal_src: 'Empty.png',
              press_src: 'Empty.png',
              click_func: () => {
                  click_Bezel();
              },
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            btn_bezel.setProperty(hmUI.prop.VISIBLE, true);


                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}