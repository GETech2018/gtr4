﻿
    /*
    ** Serif stats watchface - Amazfit GTR 4 (466 x 466)
    ** layout generated for the old-style package format
    */

    try {

      (() => {

        var __$$app$$__ = __$$hmAppManager$$__.currentApp;
        var __$$module$$__ = __$$app$$__.current;
        var h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__), 'drink');

        'use strict';

        //dynamic modify start

        let normal_background_bg_img = ''
        let normal_background_fill = ''
        let normal_icon0_img = ''
        let normal_label0_img = ''
        let normal_icon1_img = ''
        let normal_label1_img = ''
        let normal_icon2_img = ''
        let normal_label2_img = ''
        let normal_date_sep1_img = ''
        let normal_date_sep2_img = ''
        let normal_date_img_date_week_img = ''
        let normal_date_img_date_day = ''
        let normal_date_img_date_month_img = ''
        let normal_digital_clock_img_time = ''
        let normal_digital_clock_colon_img = ''
        let normal_heart_rate_text_text_img = ''
        let normal_calorie_text_text_img = ''
        let normal_step_text_text_img = ''
        let normal_battery_text_text_img = ''
        let normal_battery_image_progress_img_level = ''
        let normal_heart_rate_jumpable_img_click = ''
        let normal_calorie_jumpable_img_click = ''
        let normal_step_jumpable_img_click = ''
        let idle_background_bg_img = ''
        let idle_date_img_date_week_img = ''
        let idle_date_img_date_day = ''
        let idle_date_img_date_month_img = ''
        let idle_digital_clock_img_time = ''
        let idle_digital_clock_colon_img = ''
        let idle_battery_text_text_img = ''

        //dynamic modify end

        const logger = DeviceRuntimeCore.HmLogger.getLogger("serif_stats");

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({

          init_view() {

            //dynamic modify start

            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 466,
              h: 466,
              src: 'bg.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            try {
              normal_background_fill = hmUI.createWidget(hmUI.widget.FILL_RECT, {
                x: 0,
                y: 0,
                w: 466,
                h: 466,
                radius: 0,
                color: 0x1E2225,
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
            } catch (e) {}

            normal_icon0_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 59,
              y: 230,
              src: 'ic0.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_label0_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 65,
              y: 326,
              src: 'lb0.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_icon1_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 209,
              y: 232,
              src: 'ic1.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_label1_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 207,
              y: 326,
              src: 'lb1.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_icon2_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 346,
              y: 226,
              src: 'ic2.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_label2_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 347,
              y: 326,
              src: 'lb2.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_sep1_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 204,
              y: 52,
              src: 'sep.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_sep2_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 259,
              y: 52,
              src: 'sep.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 124,
              y: 56,
              week_en: ["wk0.png","wk1.png","wk2.png","wk3.png","wk4.png","wk5.png","wk6.png"],
              week_tc: ["wk0.png","wk1.png","wk2.png","wk3.png","wk4.png","wk5.png","wk6.png"],
              week_sc: ["wk0.png","wk1.png","wk2.png","wk3.png","wk4.png","wk5.png","wk6.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 215,
              day_startY: 56,
              day_sc_array: ["d0.png","d1.png","d2.png","d3.png","d4.png","d5.png","d6.png","d7.png","d8.png","d9.png"],
              day_tc_array: ["d0.png","d1.png","d2.png","d3.png","d4.png","d5.png","d6.png","d7.png","d8.png","d9.png"],
              day_en_array: ["d0.png","d1.png","d2.png","d3.png","d4.png","d5.png","d6.png","d7.png","d8.png","d9.png"],
              day_zero: 1,
              day_space: 0,
              day_align: hmUI.align.LEFT,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_month_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 270,
              month_startY: 56,
              month_sc_array: ["mo0.png","mo1.png","mo2.png","mo3.png","mo4.png","mo5.png","mo6.png","mo7.png","mo8.png","mo9.png","mo10.png","mo11.png"],
              month_tc_array: ["mo0.png","mo1.png","mo2.png","mo3.png","mo4.png","mo5.png","mo6.png","mo7.png","mo8.png","mo9.png","mo10.png","mo11.png"],
              month_en_array: ["mo0.png","mo1.png","mo2.png","mo3.png","mo4.png","mo5.png","mo6.png","mo7.png","mo8.png","mo9.png","mo10.png","mo11.png"],
              month_is_character: true,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 44,
              hour_startY: 100,
              hour_array: ["t0.png","t1.png","t2.png","t3.png","t4.png","t5.png","t6.png","t7.png","t8.png","t9.png"],
              hour_zero: 1,
              hour_space: 0,
              hour_align: hmUI.align.LEFT,
              
              minute_startX: 252,
              minute_startY: 100,
              minute_array: ["t0.png","t1.png","t2.png","t3.png","t4.png","t5.png","t6.png","t7.png","t8.png","t9.png"],
              minute_zero: 1,
              minute_space: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,
              
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_colon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 220,
              y: 100,
              src: 'colon.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 18,
              y: 291,
              w: 140,
              h: 27,
              font_array: ["v0.png","v1.png","v2.png","v3.png","v4.png","v5.png","v6.png","v7.png","v8.png","v9.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_calorie_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 163,
              y: 291,
              w: 140,
              h: 27,
              font_array: ["v0.png","v1.png","v2.png","v3.png","v4.png","v5.png","v6.png","v7.png","v8.png","v9.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 308,
              y: 291,
              w: 140,
              h: 27,
              font_array: ["v0.png","v1.png","v2.png","v3.png","v4.png","v5.png","v6.png","v7.png","v8.png","v9.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 181,
              y: 375,
              w: 104,
              h: 19,
              font_array: ["p0.png","p1.png","p2.png","p3.png","p4.png","p5.png","p6.png","p7.png","p8.png","p9.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'pct.png',
              unit_tc: 'pct.png',
              unit_en: 'pct.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 181,
              y: 400,
              image_array: ["b00.png","b01.png","b02.png","b03.png","b04.png","b05.png","b06.png","b07.png","b08.png","b09.png","b10.png","b11.png","b12.png","b13.png","b14.png","b15.png","b16.png","b17.png","b18.png","b19.png","b20.png"],
              image_length: 21,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 28,
              y: 224,
              w: 120,
              h: 126,
              src: 'dummy.png',
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_calorie_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 173,
              y: 224,
              w: 120,
              h: 126,
              src: 'dummy.png',
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 318,
              y: 224,
              w: 120,
              h: 126,
              src: 'dummy.png',
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            idle_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 466,
              h: 466,
              src: 'aod_bg.png',
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 124,
              y: 102,
              week_en: ["aod_wk0.png","aod_wk1.png","aod_wk2.png","aod_wk3.png","aod_wk4.png","aod_wk5.png","aod_wk6.png"],
              week_tc: ["aod_wk0.png","aod_wk1.png","aod_wk2.png","aod_wk3.png","aod_wk4.png","aod_wk5.png","aod_wk6.png"],
              week_sc: ["aod_wk0.png","aod_wk1.png","aod_wk2.png","aod_wk3.png","aod_wk4.png","aod_wk5.png","aod_wk6.png"],
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 215,
              day_startY: 102,
              day_sc_array: ["aod_d0.png","aod_d1.png","aod_d2.png","aod_d3.png","aod_d4.png","aod_d5.png","aod_d6.png","aod_d7.png","aod_d8.png","aod_d9.png"],
              day_tc_array: ["aod_d0.png","aod_d1.png","aod_d2.png","aod_d3.png","aod_d4.png","aod_d5.png","aod_d6.png","aod_d7.png","aod_d8.png","aod_d9.png"],
              day_en_array: ["aod_d0.png","aod_d1.png","aod_d2.png","aod_d3.png","aod_d4.png","aod_d5.png","aod_d6.png","aod_d7.png","aod_d8.png","aod_d9.png"],
              day_zero: 1,
              day_space: 0,
              day_align: hmUI.align.LEFT,
              day_is_character: false,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_date_img_date_month_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 270,
              month_startY: 102,
              month_sc_array: ["aod_mo0.png","aod_mo1.png","aod_mo2.png","aod_mo3.png","aod_mo4.png","aod_mo5.png","aod_mo6.png","aod_mo7.png","aod_mo8.png","aod_mo9.png","aod_mo10.png","aod_mo11.png"],
              month_tc_array: ["aod_mo0.png","aod_mo1.png","aod_mo2.png","aod_mo3.png","aod_mo4.png","aod_mo5.png","aod_mo6.png","aod_mo7.png","aod_mo8.png","aod_mo9.png","aod_mo10.png","aod_mo11.png"],
              month_en_array: ["aod_mo0.png","aod_mo1.png","aod_mo2.png","aod_mo3.png","aod_mo4.png","aod_mo5.png","aod_mo6.png","aod_mo7.png","aod_mo8.png","aod_mo9.png","aod_mo10.png","aod_mo11.png"],
              month_is_character: true,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 44,
              hour_startY: 146,
              hour_array: ["aod_t0.png","aod_t1.png","aod_t2.png","aod_t3.png","aod_t4.png","aod_t5.png","aod_t6.png","aod_t7.png","aod_t8.png","aod_t9.png"],
              hour_zero: 1,
              hour_space: 0,
              hour_align: hmUI.align.LEFT,
              
              minute_startX: 252,
              minute_startY: 146,
              minute_array: ["aod_t0.png","aod_t1.png","aod_t2.png","aod_t3.png","aod_t4.png","aod_t5.png","aod_t6.png","aod_t7.png","aod_t8.png","aod_t9.png"],
              minute_zero: 1,
              minute_space: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,
              
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_digital_clock_colon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 220,
              y: 146,
              src: 'aod_colon.png',
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 181,
              y: 282,
              w: 104,
              h: 19,
              font_array: ["aod_p0.png","aod_p1.png","aod_p2.png","aod_p3.png","aod_p4.png","aod_p5.png","aod_p6.png","aod_p7.png","aod_p8.png","aod_p9.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'aod_pct.png',
              unit_tc: 'aod_pct.png',
              unit_en: 'aod_pct.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            //dynamic modify end
          },

          onInit() {
            console.log('index page.js on init invoke')
            this.init_view()
          },

          onReady() {
            console.log('index page.js on ready invoke')
          },

          onShow() {
            console.log('index page.js on show invoke')
          },

          onHide() {
            console.log('index page.js on hide invoke')
          },

          onDestory() {
            console.log('index page.js on destory invoke')
          },
        });

      })()
    } catch (e) {
      console.log(e)
    }
