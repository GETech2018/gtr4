# Cartografia do Radar GTR 4

Modo: ferramenta integrada `image_gen`, geração nova, fundo opaco.
Original: `radar-map-master.png`; recurso preparado: `assets/466x466-amazfit-gtr-4/radar/cartography.png`.
Os anéis, números, aro, feixe, aviões e data são camadas independentes.

## Prompt utilizado

Use case: stylized-concept. Asset type: PRODUCTION FLAT WATCHFACE BACKGROUND TEXTURE, square, straight-on 2D, not a product photo or mockup. Create a refined aviation radar map backdrop for an Amazfit GTR4 green radar watch face. Dark near-black forest green / muted emerald cartography, elegant intricate accurate-looking fictional coastal city and estuary, narrow illuminated coastlines, rivers, islands, subdued road network and small city blocks, tiny topographic contour details. A calm uncluttered center and enough negative space for orange aircraft clock hands and date widgets added separately in code. Uniformly dark and restrained, sophisticated instrument visual, crisp delicate lines readable when reduced to 466x466. Fully square image filled edge-to-edge with the cartography; map not bounded by a circle. No writing, no numbers, no labels, no symbols, no aircraft, no hands, no sweeping beam, no circular rings, no bezel or rim, no clock tick marks, no buttons, no logos. Those exact geometric elements will be overlaid by software. Intentional premium finish, low-contrast green land, black waterways with fine muted green coast edges, no bright yellow, no orange. Output a square image.
