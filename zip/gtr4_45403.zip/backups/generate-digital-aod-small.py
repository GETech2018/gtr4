"""Code-native vintage radar AOD: seven-segment time, range rings, native date."""
from pathlib import Path
import math
from PIL import Image, ImageDraw, ImageFont

OUT=Path(__file__).resolve().parents[1]/'assets/466x466-amazfit-gtr-4/radar'
S=4
def pts(vertices): return [(round(x*S),round(y*S)) for x,y in vertices]
def rect(box): return tuple(round(v*S) for v in box)

# Fixed-width instrument digits: bold enough for readability, sparse enough for AOD.
segments={
 'a':[(8,3),(34,3),(38,6),(34,9),(8,9),(4,6)],
 'g':[(8,31),(34,31),(38,34),(34,37),(8,37),(4,34)],
 'd':[(8,59),(34,59),(38,62),(34,65),(8,65),(4,62)],
 'f':[(3,9),(6,6),(9,10),(9,28),(6,32),(3,29)],
 'b':[(33,10),(36,6),(39,9),(39,29),(36,32),(33,28)],
 'e':[(3,39),(6,36),(9,40),(9,57),(6,61),(3,58)],
 'c':[(33,40),(36,36),(39,39),(39,58),(36,61),(33,57)]}
codes=['ab cdef'.replace(' ',''),'bc','abged','abgcd','fgbc','afgcd','afgecd','abc','abcdefg','abfgcd']
for value,code in enumerate(codes):
    im=Image.new('RGBA',(42*S,68*S)); d=ImageDraw.Draw(im)
    for name in code: d.polygon(pts(segments[name]),fill='white')
    im.resize((42,68),Image.Resampling.LANCZOS).save(OUT/f'aod-time-{value}.png')

im=Image.new('RGB',(466*S,466*S),'black'); d=ImageDraw.Draw(im)
ring=(153,177,157); ink=(183,204,187)
for r in [86,128,166]: d.ellipse(rect((233-r,233-r,233+r,233+r)),outline=ring,width=S)
for i in range(36):
    a=math.radians(i*10); inner=158 if i%3==0 else 163
    d.line(pts([(233+inner*math.sin(a),233-inner*math.cos(a)),(233+170*math.sin(a),233-170*math.cos(a))]),fill=ring,width=S)
for angle in [0,90,180,270]:
    a=math.radians(angle)
    d.line(pts([(233+78*math.sin(a),233-78*math.cos(a)),(233+154*math.sin(a),233-154*math.cos(a))]),fill=ring,width=S)
# A dark instrument window makes the large digits immediately readable.
d.rectangle(rect((118,176,348,270)),fill='black')
for vertices in [[(126,191),(126,181),(141,181)],[(325,181),(340,181),(340,191)],
                 [(126,255),(126,265),(141,265)],[(325,265),(340,265),(340,255)]]:
    d.line(pts(vertices),fill=ink,width=S)
font=ImageFont.truetype('C:/Windows/Fonts/consola.ttf',14*S)
small=ImageFont.truetype('C:/Windows/Fonts/consola.ttf',11*S)
d.rectangle(rect((190,126,276,155)),fill='black')
d.text((233*S,141*S),'R A D A R',font=font,anchor='mm',fill=ink)
d.text((233*S,165*S),'S T B Y',font=small,anchor='mm',fill=ink)
# Fixed separator; firmware draws hour/minute digits beside it without flashing.
for cy in [210,236]: d.rectangle(rect((229,cy-2,233,cy+2)),fill='white')
d.rectangle(rect((176,278,290,314)),fill='black')
d.text((206*S,294*S),'DAY',font=small,anchor='mm',fill=ink)
im.resize((466,466),Image.Resampling.LANCZOS).save(OUT/'aod-digital-panel.png')
print('Generated vintage radar digital AOD panel and ten seven-segment digits.')
