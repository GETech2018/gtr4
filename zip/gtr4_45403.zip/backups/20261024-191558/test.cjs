// ESM import/lifecycle checks with mocked @zos modules; not a firmware emulator.
const assert = require('node:assert/strict')
const fs = require('node:fs')
const path = require('node:path')
const vm = require('node:vm')
if (!vm.SourceTextModule) {
  const result = require('node:child_process').spawnSync(process.execPath,
    ['--experimental-vm-modules', __filename], { stdio: 'inherit' })
  process.exit(result.status === null ? 1 : result.status)
}
const root = path.resolve(__dirname, '..')
const source = fs.readFileSync(path.join(root, 'watchface/index.js'), 'utf8')
async function run(withDelegate) {
  let face, now = 100000, screen = 1, mutations = 0, nextId = 0
  const widgets = [], timers = new Map()
  const time = { day: 31, month: 12, hour: 10, minute: 15, second: 0 }, battery = { current: 100 }
  const enums = Object.fromEntries(['IMG','IMG_POINTER','TEXT','TIME_POINTER'].map(k => [k,k]))
  if (withDelegate) enums.WIDGET_DELEGATE = 'WIDGET_DELEGATE'
  const ui = {
      widget: enums, show_level: { ONLY_NORMAL: 1, ONAL_AOD: 2 },
      align: { CENTER_H: 0, CENTER_V: 0 }, prop: { MORE: 'MORE', VISIBLE: 'VISIBLE', ANGLE: 'ANGLE' },
      createWidget(type, options) {
        assert.ok(type, 'Undefined widget type')
        for (const key of ['src','hour_path','minute_path']) {
          if (options[key]) assert.ok(fs.existsSync(path.join(root, 'assets/466x466-amazfit-gtr-4', options[key])))
        }
        const widget = { type, options: { ...options }, visible: true,
          setProperty(prop, value) {
            mutations++
            if (prop === 'MORE') Object.assign(this.options, value)
            else if (prop === 'VISIBLE') this.visible = value
            else if (prop === 'ANGLE') this.options.angle = value
            else throw Error('Unknown property')
          }
        }
        widgets.push(widget)
        return widget
      }
  }
  const context = vm.createContext({
    console: { log() {} }, Date: { now: () => now },
    WatchFace: definition => { face = definition },
    setInterval(callback, delay) { assert.equal(delay,50); timers.set(nextId, callback); return nextId++ },
    clearInterval(id) { assert.ok(timers.delete(id), 'Timer stopped twice or wrong ID') }
  })
  const dependencies = {
    '@zos/ui': { default: ui },
    '@zos/app': { getScene: () => screen, SCENE_WATCHFACE: 1 },
    '@zos/sensor': {
      Time: class {
        getDate() { return time.day } getMonth() { return time.month }
        getHours() { return time.hour } getMinutes() { return time.minute }
        getSeconds() { return time.second }
      },
      Battery: class { getCurrent() { return battery.current } }
    }
  }
  const module = new vm.SourceTextModule(source + '\nexport { echoStrength }', { context })
  await module.link(specifier => {
    const dependency = dependencies[specifier]
    assert.ok(dependency, 'Unexpected import: ' + specifier)
    return new vm.SyntheticModule(Object.keys(dependency), function () {
      for (const [key,value] of Object.entries(dependency)) this.setExport(key,value)
    }, { context })
  })
  await module.evaluate()
  const { echoStrength } = module.namespace
  assert.equal(echoStrength(359, 0), 0, 'Do not reveal marker ahead of beam')
  assert.equal(echoStrength(0, 0), 1)
  assert.ok(echoStrength(1, 359) > 0.9, 'Echo survives 360-degree wrap')
  assert.equal(echoStrength(180, 0), 0, 'User echo duration preserved')
  face.onInit(); face.build()
  assert.equal(timers.size, 1)
  assert.equal(face.dateText.options.text, '31')
  assert.equal(face.batteryText, undefined, 'User disabled battery text preserved')
  assert.ok(face.dateText.options.x > 233)
  assert.ok(widgets.some(w => w.options.src === 'radar/background2.png'), 'User background preserved')
  assert.ok(widgets.some(w => w.options.src === 'radar/map-overlay.png'))
  assert.equal(face.echoes.length, 4, 'Four animated miniature aircraft')
  now = 101500; face.tick()
  assert.equal(face.beam.options.angle, 90)
  assert.equal((face.handEchoes[1].widget.options.alpha > 0), true, 'Minute aircraft revealed at 3 oclock')
  const fade = [face.handEchoes[1].widget.options.alpha]
  for (let step = 0; step < 120; step++) {
    now += 50; face.tick()
    fade.push(face.handEchoes[1].widget.options.alpha)
  }
  assert.equal(fade[0], 255, 'Full brightness at beam crossing')
  assert.ok(fade[60] >= 173 && fade[60] <= 175, 'Hands keep more brightness at three seconds')
  assert.ok(fade.slice(1, -1).every((value, i) => value <= fade[i]), 'Aircraft progressively fades each frame')
  assert.ok(fade.at(-2) >= 39 && fade.at(-2) <= 45, 'Hands remain visible before next sweep with eight-second decay')
  assert.equal(fade.at(-1), 255, 'Next sweep reilluminates the aircraft')
  assert.ok(face.handEchoes.every(hand => hand.widget.visible), 'Aircraft fade uses image alpha, never binary visibility')
  now = 100700; face.tick()
  const mini = face.echoes[0].widget
  assert.equal(mini.options.alpha, 255, 'Mini aircraft bright at beam crossing')
  now += 2000; face.tick()
  assert.ok(mini.options.alpha >= 127 && mini.options.alpha <= 128, 'Mini half brightness at two seconds')
  now += 2000; face.tick()
  assert.equal(mini.options.alpha, 0, 'Mini gone after four seconds')
  assert.ok(face.handEchoes[1].widget.options.alpha > 0, 'Clock hand still visible after mini aircraft disappears')
  assert.deepEqual(face.echoes.map(e => e.widget.options.src).join(','), 'radar/mini-north.png,radar/mini-east.png,radar/mini-south.png,radar/mini-west.png')
  now += 1999; face.tick()
  assert.equal(mini.options.alpha, 0, 'Mini stays invisible until next sweep')
  now += 1; face.tick()
  assert.equal(mini.options.alpha, 255, 'Mini reilluminated by next sweep')
  for (const [index, echo] of face.echoes.entries()) {
    const crossing = Math.ceil(100000 + echo.angle / 360 * 6000) + 1
    now = crossing; face.tick()
    assert.equal(echo.widget.options.x, echo.originX, 'Starts at original x')
    assert.equal(echo.widget.options.y, echo.originY, 'Starts at original y')
    now = crossing + 2000; face.tick()
    const directions = [[0, -1], [1, 0], [0, 1], [-1, 0]]
    assert.equal(echo.widget.options.x, echo.originX + directions[index][0] * 3, 'Halfway travel follows heading x')
    assert.equal(echo.widget.options.y, echo.originY + directions[index][1] * 3, 'Halfway travel follows heading y')
    now = crossing + 4000; face.tick()
    assert.equal(echo.widget.options.alpha, 0)
    const stopped = [echo.widget.options.x, echo.widget.options.y].join(',')
    now = crossing + 5000; face.tick()
    assert.equal([echo.widget.options.x, echo.widget.options.y].join(','), stopped, 'Hidden aircraft does not keep moving')
    now = crossing + 6000; face.tick()
    assert.equal(echo.widget.options.x, echo.originX, 'New reveal resets path x')
    assert.equal(echo.widget.options.y, echo.originY, 'New reveal resets path y')
  }
  time.hour = 11; time.minute = 59; time.second = 59
  now = 112000; face.tick()
  assert.equal((face.handEchoes[0].widget.options.alpha > 0), true, 'Hour echo crosses north')
  assert.equal((face.handEchoes[1].widget.options.alpha > 0), true, 'Minute echo crosses north')
  assert.equal(face.beam.options.angle, 0, 'User six-second revolution preserved')
  time.day = 1; time.month = 1; battery.current = 0; face.tick()
  assert.equal(face.dateText.options.text, '01', 'Date rollover')
  battery.current = undefined; face.tick()
  assert.equal(face.batteryText, undefined)
  screen = 2; const before = mutations; now += 1000; face.tick()
  assert.equal(mutations, before, 'No drawing during AOD')
  const aod = widgets.filter(w => w.options.show_level === 2)
  assert.equal(aod.length, 1)
  assert.equal(aod[0].type, 'TIME_POINTER')
  assert.ok(!aod[0].options.second_path)
  if (withDelegate) {
    const delegate = widgets.find(w => w.type === 'WIDGET_DELEGATE')
    delegate.options.pause_call(); assert.equal(timers.size, 0)
    screen = 1; delegate.options.resume_call(); delegate.options.resume_call()
    assert.equal(timers.size, 1, 'Resume must not duplicate timers')
  }
  face.onDestroy(); assert.equal(timers.size, 0)
  const after = mutations; face.tick(); face.startRadar()
  assert.equal(mutations, after); assert.equal(timers.size, 0)
}
async function main() {
await run(true)
await run(false)
const config = JSON.parse(fs.readFileSync(path.join(root, 'app.json')))
const target = config.targets['466x466-amazfit-gtr-4']
assert.equal(config.app.appType, 'watchface')
assert.equal(config.runtime.apiVersion.compatible, '2.1.0')
assert.equal(target.designWidth, 466)
assert.deepEqual(target.platforms.map(p => p.deviceSource), [7930112,7930113,7864577])
assert.equal(target.module.watchface.path, 'watchface/index')
console.log('PASS: assets/config, sweep wrap/expiration, date rollover, battery boundaries, AOD draw guard, pause/resume, timer cleanup; with and without delegate.')
}
main().catch(error => { console.error(error); process.exitCode = 1 })


