# Radar GTR 4 — protótipo

Mostrador Zepp OS para Amazfit GTR 4, 466 × 466.

## Estado atual após edições locais do usuário

Esta seção substitui as durações e detalhes descritos nas notas históricas abaixo.
As alterações locais foram preservadas: fundo `background2.png`, varredura em
6 segundos, intervalo solicitado de 50 ms, números dinâmicos desativados,
texto de bateria desativado e data apenas com o dia.

Foi acrescentada `map-overlay.png`: cartografia esquemática decorativa, com
costa, ilhas, vias, rio e pistas. Não é uma região real nem usa GPS.
O arquivo de fundo do usuário permanece intacto. `tools/generate_map.py`
gera somente essa camada e `mini-aircraft.png`, sem regenerar os demais recursos.

Os quatro miniaviões são imagens separadas, sem rastro pontilhado, orientadas
para norte, leste, sul e oeste. Esmaecem em 4 segundos e ficam invisíveis até
a próxima passagem do feixe. Durante a aparição avançam lentamente 6 pixels
na direção do nariz (1,5 px/s). Ao reaparecer, reiniciam a trajetória; o intervalo
invisível oculta o retorno à origem. Os miniaviões foram reduzidos em 20%. Os ponteiros
têm decaimento de 8 segundos (reiluminados pela varredura a cada 6 segundos), com a mesma
curva suave, permanecendo visíveis por mais tempo. Hora em laranja e minuto
em amarelo, com haste contínua e opaca do centro até o avião.

Os números 12, 3, 6 e 9 embutidos no fundo receberam uma camada de escurecimento;
o arquivo original permanece intacto. `tools/generate_pointer_assets.py` gera
os ponteiros, miniaviões orientados e a camada de escurecimento. Execute-o
por último caso regenere também os recursos antigos com `generate_assets.py`.

## Configuração conferida em 24/10/2026

- `appType`: `watchface`; entrada: `watchface/index`.
- Target e pasta de recursos: `466x466-amazfit-gtr-4`; `designWidth`: 466.
- `deviceSource`: 7930112, 7930113 e 7864577, conforme a tabela oficial.
- O campo `platforms[].name` é uma descrição escolhida pelo desenvolvedor;
  não é preciso inventar ou adivinhar um codinome de plataforma.
- `appId` 29494, `app.js` e o `icon.png` original foram preservados.
- API mínima declarada 2.1, importação principal `import hmUI from '@zos/ui'`,
  sensores de `@zos/sensor`, cenas de `@zos/app` e `setInterval/clearInterval`.
  O pacote local “GTR 4 v2.1.0” informa Zepp OS 3.5/API 3.5;
  a versão do pacote do simulador não é a versão do sistema do relógio.

## O que está implementado

- Radar verde com anéis subdivididos, textura determinística, escala fina, índices luminosos, aro metálico e feixe texturizado até a borda circular. Centro metálico, aviões com halo e molduras laterais para bateria/data. A graduação circular da bateria é decorativa; o percentual central é o valor real.
- Varredura em 8 segundos, atualização solicitada a cada 100 ms (não é
  garantia de 10 FPS reais no dispositivo).
- Hora: avião maior, verde, mais próximo do centro. Minuto: avião menor,
  verde-claro, mais distante. No modo normal, imagens `IMG` giram conforme os sensores de hora; no AOD, `TIME_POINTER` controla a hora nativamente.
- Cada avião aparece ao ser alcançado pelo feixe e perde opacidade gradualmente
  com uma curva suave durante cerca de 3 s, até zero, sem corte abrupto. A duração dos números continua em 1,44 s.
  O efeito usa a propriedade alpha de IMG, sem alternar VISIBLE: setAlpha em TIME_POINTER não produziu o esmaecimento no emulador. O efeito é independente para cada avião. No AOD os ponteiros continuam visíveis.
- Números e ecos decorativos aparecem atrás do feixe por cerca de 1,44 s.
  Os números perdem brilho gradualmente; os quatro ecos somem ao expirar.
- Data DD/MM à direita (3h) e bateria à esquerda (9h), lidas dos sensores
  do relógio; não são valores fixos.
- AOD separado: aviões brancos, fundo preto, sem segundos nem radar.
- Temporizador encerrado em `onDestroy`; pausa/retomada pelo delegate
  quando disponível. Em outras telas, `tick` não altera os desenhos.

Os ecos não representam tráfego aéreo, localização ou dados de radar reais.

## Comandos na pasta do projeto

```powershell
node tools/test.cjs
zeus build -t 466x466-amazfit-gtr-4
zeus dev -t 466x466-amazfit-gtr-4
```

Use apenas uma instância de `zeus dev`. Pare-a com Ctrl+C antes de executar
`zeus build`; não faça as duas compilações ao mesmo tempo. Durante esta
sessão houve conflito em `dist` entre processos, incluindo erro `EEXIST`.
O build normal gerou um `.zab` quando executado separadamente.

As imagens podem ser regeneradas com Python e Pillow:

```powershell
python tools/generate_assets.py
```

## Validação e limites

- Build com Zeus 1.9.3/ZPM 3.4.2: JavaScript compilado por QJSC e imagens
  convertidas; pacote `.zab` gerado.
- Testes com módulos ESM simulados, sem fornecer os globais legados:
  resolução das importações, ciclo/expiração do feixe, virada de data,
  bateria zero/indisponível, pausa/retomada, proteção de AOD e limpeza
  de temporizador, incluindo firmware sem `WIDGET_DELEGATE`.
- Estes testes não substituem execução no firmware. Desempenho, consumo,
  transparência/rotação e transição AOD precisam de validação no GTR 4 real.
- A tela de diagnóstico “RADAR OK” com fundo verde foi confirmada pelo
  usuário no emulador. A tela preta foi diagnosticada com `createWidget`
  indisponível: a importação principal de `@zos/ui`, conforme o exemplo
  oficial de mostrador, resolveu o teste. O radar usa a mesma importação.
  O usuário confirmou que o radar completo apareceu no emulador e,
  após substituir IMG_POINTER por IMG com prop.ANGLE no feixe, confirmou
  que o feixe aparece e gira. A captura enviada mostra os dois aviões,
  marcadores, data e bateria. Validação no aparelho físico permanece pendente.
- O aviso `Slirp: Failed to send packet, ret: -1` aparece na lista de
  mensagens ignoradas pelo próprio simulador instalado. Isoladamente,
  ele não comprova falha de instalação nem erro no mostrador.
- O modo AOD deve ser econômico: a orientação oficial pede fundo preto,
  ponteiros brancos, ausência de segundos e no máximo 10% de pixels acesos.
  Não foi implementada varredura animada no AOD.
- A animação usa widgets nativos e uma imagem rotacionada, sem canvas web
  ou WebGL. O custo de redesenho de uma imagem de tela inteira deve ser
  medido no relógio antes de aumentar a frequência.
- Este é um protótipo de desenvolvimento, não uma submissão pronta à loja:
  o ícone original foi mantido e ainda faltam validação física e revisão
  completa dos requisitos de publicação/localização.

## Fontes oficiais

- Dispositivos: https://docs.zepp.com/docs/reference/related-resources/device-list/
- Manifesto: https://docs.zepp.com/docs/reference/app-json/
- Ponteiros: https://docs.zepp.com/docs/v2/watchface/api/hmUI/widget/TIME_POINTER/
- Opacidade: https://docs.zepp.com/docs/reference/device-app-api/newAPI/ui/setAlpha/
- Rotação: https://docs.zepp.com/docs/v2/watchface/api/hmUI/widget/IMG_POINTER/
- AOD: https://docs.zepp.com/docs/watchface/specification/
- Simulador: https://docs.zepp.com/docs/guides/tools/simulator/


