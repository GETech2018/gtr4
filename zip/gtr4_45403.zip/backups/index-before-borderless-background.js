import hmUI from '@zos/ui'
import { Time, Battery } from '@zos/sensor'
import { getScene, SCENE_WATCHFACE } from '@zos/app'

// Normal hands use IMG opacity; AOD uses firmware-managed digital time/date.
// All positions are for 466x466.
const CENTER = 233
const FRAME_MS = 50
const REVOLUTION_MS = 6000
const ECHO_DEGREES = 180
const HAND_ECHO_DEGREES = 480 // Eight-second decay; six-second sweep renews the glow.
const HANDS_ALWAYS_VISIBLE = true // Set false to restore the previous hand fade.
const MINI_ECHO_MS = 5000
const MINI_TRAVEL_PX = 20 // Visible travel over five seconds, along the aircraft's heading.

function echoStrength(sweepAngle, targetAngle, duration = ECHO_DEGREES) {
  const age = ((sweepAngle - targetAngle) % 360 + 360) % 360
  return age < duration ? 1 - age / duration : 0
}

function pad2(value) {
  return value < 10 ? '0' + value : '' + value
}

WatchFace({
  onInit() {
    this.frameTimer = null
    this.ready = false
    this.destroyed = false
    this.epoch = Date.now()
    this.lastInfo = ''
    this.echoes = []
    this.handEchoes = []
    this.timeSensor = new Time()
    this.batterySensor = new Battery()
  },

  build() {
    const normal = hmUI.show_level.ONLY_NORMAL
    const aod = hmUI.show_level.ONAL_AOD // Official API spelling.
    hmUI.createWidget(hmUI.widget.IMG, {
      x: 0, y: 0, src: 'radar/cartography.png', show_level: normal
    })
    hmUI.createWidget(hmUI.widget.IMG, {
      x: 0, y: 0, src: 'radar/radar-grid.png', show_level: normal
    })
    // Exact cardinal placement, 194px from center instead of baked-in edge labels.
    for (const label of [['12',233,39],['3',427,233],['6',233,427],['9',39,233]]) {
      hmUI.createWidget(hmUI.widget.TEXT, {
        x: label[1] - 21, y: label[2] - 16, w: 42, h: 32,
        text: label[0], text_size: 26, color: 0x497c53,
        align_h: hmUI.align.CENTER_H, align_v: hmUI.align.CENTER_V, show_level: normal
      })
    }
    this.beam = hmUI.createWidget(hmUI.widget.IMG, {
      src: 'radar/sweep.png', x: 0, y: 0, w: 466, h: 466,
      pos_x: 0, pos_y: 0,
      center_x: CENTER, center_y: CENTER, angle: 0, show_level: normal
    })
    /*for (let hour = 1; hour <= 12; hour++) {
      const angle = hour * 30 % 360
      const radians = angle * Math.PI / 180
      const widget = hmUI.createWidget(hmUI.widget.TEXT, {
        x: Math.round(CENTER + 197 * Math.sin(radians) - 23),
        y: Math.round(CENTER - 197 * Math.cos(radians) - 15),
        w: 46, h: 30, text: pad2(hour), text_size: 22,
        color: 0x8dffac, align_h: hmUI.align.CENTER_H,
        align_v: hmUI.align.CENTER_V, show_level: normal
      })
      widget.setProperty(hmUI.prop.VISIBLE, false)
      this.echoes.push({ widget: widget, angle: angle, visible: false, color: -1 })
    }*/
    // Decorative returns, not live aircraft or GPS data.
    const targets = [[42, 104], [133, 151], [218, 89], [292, 163]]
    for (let i = 0; i < targets.length; i++) {
      const angle = targets[i][0]
      const radians = angle * Math.PI / 180
      const originX = Math.round(CENTER + targets[i][1] * Math.sin(radians) - 24)
      const originY = Math.round(CENTER - targets[i][1] * Math.cos(radians) - 24)
      const directions = [[0, -1], [1, 0], [0, 1], [-1, 0]]
      const widget = hmUI.createWidget(hmUI.widget.IMG, {
        x: originX, y: originY,
        src: 'radar/mini-' + ['north', 'east', 'south', 'west'][i] + '.png', alpha: 0, show_level: normal
      })
      this.echoes.push({
        widget: widget, angle: angle, image: true, alpha: 0,
        originX: originX, originY: originY,
        dx: directions[i][0], dy: directions[i][1], x: originX, y: originY
      })
    }
    hmUI.createWidget(hmUI.widget.IMG, {
      x: 0, y: 0, src: 'radar/date-panel.png', show_level: normal
    })
    this.dateText = hmUI.createWidget(hmUI.widget.TEXT, {
      x: 323, y: 219, w: 62, h: 28, text: '', text_size: 20,
      color: 0x80ac79, align_h: hmUI.align.CENTER_H,
      align_v: hmUI.align.CENTER_V, show_level: normal
    })
    /*this.batteryText = hmUI.createWidget(hmUI.widget.TEXT, {
      x: 84, y: 232, w: 52, h: 23, text: '', text_size: 17,
      color: 0x80ac79, align_h: hmUI.align.CENTER_H,
      align_v: hmUI.align.CENTER_V, show_level: normal
    })*/
    this.createHands(normal, '')
    hmUI.createWidget(hmUI.widget.IMG, {
      x: CENTER - 16, y: CENTER - 16, src: 'radar/hub.png', show_level: normal
    })
    // Above numeral shading and sweep: the silver rim stays uniform at every angle.
    hmUI.createWidget(hmUI.widget.IMG, {
      x: 0, y: 0, src: 'radar/silver-bezel.png', show_level: normal
    })
    // Firmware-managed AOD time/date remain live while the JS radar is paused.
    hmUI.createWidget(hmUI.widget.IMG, {
      x: 0, y: 0, src: 'radar/aod-digital-panel.png', show_level: aod
    })
    const timeDigits = Array.from({ length: 10 }, (_, i) => 'radar/aod-time-' + i + '.png')
    this.aodTime = hmUI.createWidget(hmUI.widget.IMG_TIME, {
      hour_startX: 63, hour_startY: 169, hour_space: 4, hour_zero: 1,
      hour_align: hmUI.align.LEFT, hour_array: timeDigits,
      minute_startX: 247, minute_startY: 169, minute_space: 4, minute_zero: 1,
      minute_align: hmUI.align.LEFT, minute_array: timeDigits, minute_follow: 0,
      show_level: aod
    })
    const dateDigits = Array.from({ length: 10 }, (_, i) => 'radar/aod-digit-' + i + '.png')
    this.aodDate = hmUI.createWidget(hmUI.widget.IMG_DATE, {
      day_startX: 247, day_startY: 319, day_space: 1, day_zero: 1,
      day_align: hmUI.align.LEFT, day_follow: 0, day_is_character: false,
      day_en_array: dateDigits, day_sc_array: dateDigits, day_tc_array: dateDigits,
      show_level: aod
    })
    // Not present on every older firmware; tick also checks screen type.
    if (typeof hmUI.widget.WIDGET_DELEGATE !== 'undefined') {
      hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
        resume_call: () => this.startRadar(),
        pause_call: () => this.stopRadar()
      })
    }
    this.ready = true
    this.startRadar()
    console.log('[radar] ready: map + mini aircraft, sweep ' + REVOLUTION_MS + 'ms, mini decay ' + MINI_ECHO_MS + 'ms')
  },

  createHands(showLevel, suffix) {
    const hour = {
      hour_centerX: CENTER, hour_centerY: CENTER,
      hour_posX: 30, hour_posY: 145,
      hour_path: 'radar/hour' + suffix + '.png'
    }
    const minute = {
      minute_centerX: CENTER, minute_centerY: CENTER,
      minute_posX: 22, minute_posY: 203,
      minute_path: 'radar/minute' + suffix + '.png'
    }
    if (suffix) {
      hmUI.createWidget(hmUI.widget.TIME_POINTER, {
        ...hour, ...minute, show_level: showLevel
      })
      return
    }
    // IMG supports alpha directly. TIME_POINTER did not visibly fade on the emulator.
    this.handEchoes = [
      { src: hour.hour_path, pos_x: CENTER - 30, pos_y: CENTER - 145 },
      { src: minute.minute_path, pos_x: CENTER - 22, pos_y: CENTER - 203 }
    ].map(options => {
      const widget = hmUI.createWidget(hmUI.widget.IMG, {
        ...options, x: 0, y: 0, w: 466, h: 466,
        center_x: CENTER, center_y: CENTER, angle: 0,
        alpha: 0, show_level: showLevel
      })
      return { widget: widget, alpha: 0, angle: -1 }
    })
  },

  updateInfo() {
    const t = this.timeSensor
    const rawBattery = this.batterySensor.getCurrent()
    const battery = typeof rawBattery === 'number' && isFinite(rawBattery)
      ? Math.max(0, Math.min(100, Math.round(rawBattery))) + '%' : '--%'
    const date = pad2(t.getDate())
    const key = date + ':' + battery
    if (key !== this.lastInfo) {
      this.dateText.setProperty(hmUI.prop.MORE, { text: date })
      //this.batteryText.setProperty(hmUI.prop.MORE, { text: battery })
      this.lastInfo = key
    }
  },

  tick() {
    if (!this.ready || this.destroyed) return
    if (getScene() !== SCENE_WATCHFACE) return
    const elapsed = Math.max(0, Date.now() - this.epoch)
    const angle = (elapsed % REVOLUTION_MS) * 360 / REVOLUTION_MS
    this.beam.setProperty(hmUI.prop.ANGLE, angle)
    const minutes = this.timeSensor.getMinutes() + this.timeSensor.getSeconds() / 60
    const handAngles = [((this.timeSensor.getHours() % 12) + minutes / 60) * 30, minutes * 6]
    for (let i = 0; i < this.handEchoes.length; i++) {
      const hand = this.handEchoes[i]
      const strength = echoStrength(angle, handAngles[i], HAND_ECHO_DEGREES)
      // Same easing as mini aircraft; the longer duration keeps hands visible longer.
      const alpha = HANDS_ALWAYS_VISIBLE ? 255 : Math.round(255 * strength * strength * (3 - 2 * strength))
      if (alpha !== hand.alpha || handAngles[i] !== hand.angle) {
        hand.widget.setProperty(hmUI.prop.MORE, { alpha: alpha, angle: handAngles[i] })
        hand.alpha = alpha
        hand.angle = handAngles[i]
      }
    }
    for (let i = 0; i < this.echoes.length; i++) {
      const echo = this.echoes[i]
      if (echo.image) {
        const ageMs = ((angle - echo.angle + 360) % 360) / 360 * REVOLUTION_MS
        const remaining = Math.max(0, 1 - ageMs / MINI_ECHO_MS)
        const alpha = Math.round(255 * remaining * remaining * (3 - 2 * remaining))
        const distance = MINI_TRAVEL_PX * Math.min(1, ageMs / MINI_ECHO_MS)
        const x = echo.originX + Math.round(echo.dx * distance)
        const y = echo.originY + Math.round(echo.dy * distance)
        if (alpha !== echo.alpha || (alpha > 0 && (x !== echo.x || y !== echo.y))) {
          // Update position and opacity together; the hidden interval masks the reset.
          echo.widget.setProperty(hmUI.prop.MORE, { alpha: alpha, x: x, y: y })
          echo.alpha = alpha
          echo.x = x
          echo.y = y
        }
        continue
      }
      const strength = echoStrength(angle, echo.angle)
      const visible = strength > 0
      
      if (visible !== echo.visible) {
        echo.widget.setProperty(hmUI.prop.VISIBLE, visible)
        echo.visible = visible
      }
      if (visible && !echo.image) {
        const r = Math.round(30 + 111 * strength)
        const g = Math.round(72 + 183 * strength)
        const b = Math.round(40 + 132 * strength)
        const color = (r << 16) | (g << 8) | b
        if (echo.color !== color) {
          echo.widget.setProperty(hmUI.prop.MORE, { color: color })
          echo.color = color
        }
      }
    }
    this.updateInfo()
  },

  startRadar() {
    if (!this.ready || this.destroyed || this.frameTimer !== null) return
    this.tick()
    this.frameTimer = setInterval(() => this.tick(), FRAME_MS)
  },

  stopRadar() {
    if (this.frameTimer !== null) {
      clearInterval(this.frameTimer)
      this.frameTimer = null
    }
  },

  onDestroy() {
    this.destroyed = true
    this.stopRadar()
    this.ready = false
    this.echoes = []
    this.handEchoes = []
  }
})
