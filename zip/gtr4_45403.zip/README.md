# Radar GTR 4 — protótipo

Mostrador Zepp OS para Amazfit GTR 4, 466 × 466.

## Publicacao 1.2.4 (codigo 20)

appId 1132832 e autor Djalma Ribeiro preservados. O pacote declara 21 deviceSource
oficiais para GTR 4, Active 2 Round, T-Rex 3 Pro 44mm, Active 3 Premium e Cheetah 2 Pro.
Fonte e lista exata: tools/devices-466.json (verificada em 2026-10-26).
O nome interno do target e a pasta de assets foram preservados para evitar duplicacao.
A Zepp reconhece os dispositivos pelo deviceSource, nao pelo nome dessa pasta.
As APIs continuam com minimo 2.1.0; a arte continua 466x466.
Mapa colorido padrao e bateria percentual com moldura a esquerda.
GTR 4 Limited Edition e T-Rex Dual Solar aguardam identificadores oficiais confirmados.
A tabela oficial agrupa variantes Active 2 Round sem distinguir NFC por nome.
Compilacao de producao e testes locais aprovados; os novos modelos nao foram testados
no firmware ou no relogio fisico nesta atualizacao. A inclusao na loja depende do
reconhecimento do pacote e da revisao da Zepp.

## Estado anterior apos edicoes locais do usuario

Esta seção substitui as durações e detalhes descritos nas notas históricas abaixo.
Versão 1.2.1 (código 17): esmaecimento dos ponteiros em 3,5 segundos após a pausa
inicial de 0,5 segundo. Quatro fundos selecionáveis no modo de edição:
1. Verde atual.
2. Mapa verde com números e graduação azul-ciano.
3. Mapa, anéis, números e graduação azuis.
4. Mapa colorido inspirado em radar meteorológico, com marcações verdes.

`WATCHFACE_EDIT_BG` gerencia a escolha nativa e `module.watchface.editable = 1`
habilita a edição. No relógio: segure o mostrador, toque no lápis, toque no fundo
para trocar e confirme pelo botão lateral. O fundo verde permanece como padrão.
O AOD digital é independente desses fundos. A versão colorida é decorativa,
sem previsão do tempo, precipitação real, GPS ou tráfego aéreo ao vivo.
O seletor e a persistência da escolha precisam de validação no GTR 4 físico.

`tools/generate_backgrounds.py` prepara os quatro fundos e recursos do editor.
As novas cartografias azul e colorida foram geradas com a ferramenta integrada
de imagens e ficam em `art/`; prompts em `art/background-variants-prompts.md`.

Ponteiros a 60% de opacidade, voltando a 100% quando
o feixe passa. Mantêm 100% por 0,5 segundo e depois esmaecem suavemente até
60% em mais 3,5 segundos (4 segundos no total após a passagem do feixe).
Tráfego decorativo com travessias completas,
seis silhuetas e três tamanhos. `appId` 1132832, fornecido pelo usuário após cadastro
na loja Zepp. O ID anterior 29494 fica somente nos backups.
Números cardinais 14 px mais próximos da borda;
fundo sem aro prata, ocupando o círculo inteiro de raio 233 px.
Graduação periférica a 231 px, sem a faixa preta anterior. AOD preservado.
Miniaviões percorrem a tela ao longo de 72 segundos; miniatura do próprio mostrador em `icon.png` (314x314),
com capa `preview.png` (466x466), compostas dos recursos da face às 10:09.
Gere novamente com `tools/generate_thumbnail.py`. Ícone anterior em `backups/icon-before-face-thumbnail.png`.
AOD digital ampliado estilo radar antigo, com anéis,
graduação e legendas verdes; hora e data brancas. `module.watchface.lockscreen = 1`, habilitando o AOD
associado ao mostrador. Antes, os widgets de AOD existiam mas o pacote declarava
`lockscreen = 0`, impedindo o firmware de reconhecer esse suporte.
Instale a versão 1.2.1 no relógio físico e use o estilo AOD que segue o mostrador.
O novo appId representa uma identidade diferente da versão de testes anterior.
O AOD ocupa quase toda a tela: escala externa com raio de 229 px, algarismos
de 76x124 px e data de 20x38 px por dígito. Os segmentos da hora são preenchidos
em branco sólido, com anéis e legendas verdes no fundo preto.
Referência: https://github.com/zepp-health/zeppos-samples/blob/main/watchface/3.0/timer/app.json
Os fundos ativos agora são `radar/themes/*.png`, com mapas, anéis e números
compostos por tema. O verde usa a cartografia de `art/radar-map-master.png`.
O arquivo antigo `background2.png` foi preservado. Mantidos: varredura em
6 segundos, intervalo solicitado de 50 ms, números dinâmicos desativados,
texto de bateria desativado e data apenas com o dia.

Nova arte: cartografia fictícia costeira, gerada com a ferramenta integrada de imagens.
O prompt está em `art/generation-prompt.md`. Não é uma região real nem usa GPS.
`tools/generate_theme.py` prepara a imagem em 466x466 e cria uma camada geométrica
com cinco anéis de raios 44, 86, 132, 176 e 204 px. O anel de 204 px acrescenta
um estágio externo. Números 12/3/6/9 são textos separados a 208 px do centro,
mais próximos da borda. A moldura da data foi recuada para não cobrir o número 3.
As camadas antigas `map-overlay.png`, `instruments.png`, `numeral-dimmer.png`,
`cartography.png` e `radar-grid.png`
ficam preservadas, mas não são usadas nesta versão.

Quatro aeronaves atravessam o mostrador continuamente em rotas diferentes,
incluindo diagonais. Cada ciclo dura 72 segundos e começa/termina fora da tela.
A posição continua avançando enquanto o eco fica invisível, sem voltar à origem
a cada varredura. O feixe revela a aeronave na posição atual e o eco esmaece
durante 5 segundos. Há suavização extra na entrada e saída da borda.

Silhuetas: avião comercial, monomotor, cargueiro, caça, helicóptero e planador.
Tamanhos nominais: 20, 26 e 32 px. O modelo/tamanho muda somente no início de
uma nova travessia, fora da tela; a seleção usa também períodos de três horas
do horário local para variar durante o dia. Sem rastros pontilhados.
`watchface/traffic.js` contém a simulação; `tools/generate_traffic.py` gera os
18 sprites. `tools/snapshot_traffic.cjs` usa a mesma simulação nas miniaturas.
Os ponteiros
ficam sempre visíveis no modo normal, variando entre 60% e 100% de opacidade.
O AOD digital mantém os algarismos brancos sólidos. O efeito anterior de decaimento de 8 segundos
foi mantido no código: basta definir `HANDS_ALWAYS_VISIBLE = false` em `watchface/index.js`.
Uma cópia anterior completa está em `radar-gtr4-antes-ponteiros-fixos.zip`, nos arquivos
de entrega, e o código anterior também está na pasta local `backups/`.
Hora em laranja e minuto
em amarelo, com haste contínua e opaca do centro até o avião.

O aro `silver-bezel.png` foi removido da composição ativa. O arquivo e o gerador
`tools/generate_bezel.py` continuam preservados para eventual retorno.
O arquivo original permanece intacto. `tools/generate_pointer_assets.py` gera
os ponteiros, miniaviões orientados e a camada de escurecimento. Execute-o
por último caso regenere também os recursos antigos com `generate_assets.py`.

Execute `tools/generate_theme.py` após `generate_pointer_assets.py` para manter
os recursos anteriores de AOD analógico. O AOD ativo agora é digital: execute
`tools/generate_digital_aod.py` para gerar os recursos de radar antigo.
`IMG_TIME` controla hora/minuto com dez imagens de algarismos de sete segmentos;
`IMG_DATE` controla o dia nativamente, com dez imagens menores de dígitos.
Isso mantém a data atualizada mesmo com o temporizador de animação pausado.
Fundo preto, círculos e graduação discretos, legendas RADAR/STBY, hora grande e dia abaixo.
Sem feixe animado, segundos, mapa ou miniaviões no AOD. A opção AOD deve estar habilitada
nas configurações do relógio, com o estilo que segue o mostrador atual.
A versão anterior dos ponteiros de AOD está preservada em `backups/index-before-digital-aod.js`.
A troca de cenas e atualização nativa devem ser confirmadas no firmware real.

## Configuração conferida em 24/10/2026

- `appType`: `watchface`; entrada: `watchface/index`.
- Target e pasta de recursos: `466x466-amazfit-gtr-4`; `designWidth`: 466.
- `deviceSource`: 7930112, 7930113 e 7864577, conforme a tabela oficial.
- O campo `platforms[].name` é uma descrição escolhida pelo desenvolvedor;
  não é preciso inventar ou adivinhar um codinome de plataforma.
- `appId` atual: 1132832. O `app.js` original permanece preservado; o ícone
  foi substituído pela miniatura da própria face, com o original nos backups.
- API mínima declarada 2.1, importação principal `import hmUI from '@zos/ui'`,
  sensores de `@zos/sensor`, cenas de `@zos/app` e `setInterval/clearInterval`.
  O pacote local “GTR 4 v2.1.0” informa Zepp OS 3.5/API 3.5;
  a versão do pacote do simulador não é a versão do sistema do relógio.

## O que está implementado

- Radar verde com anéis subdivididos, textura determinística, escala fina, índices luminosos, aro metálico e feixe texturizado até a borda circular. Centro metálico, aviões com halo e molduras laterais para bateria/data. A graduação circular da bateria é decorativa; o percentual central é o valor real.
- Varredura em 8 segundos, atualização solicitada a cada 100 ms (não é
  garantia de 10 FPS reais no dispositivo).
- Hora: avião maior, verde, mais próximo do centro. Minuto: avião menor,
  verde-claro, mais distante. No modo normal, imagens `IMG` giram conforme os sensores de hora; no AOD, `TIME_POINTER` controla a hora nativamente.
- Cada avião aparece ao ser alcançado pelo feixe e perde opacidade gradualmente
  com uma curva suave durante cerca de 3 s, até zero, sem corte abrupto. A duração dos números continua em 1,44 s.
  O efeito usa a propriedade alpha de IMG, sem alternar VISIBLE: setAlpha em TIME_POINTER não produziu o esmaecimento no emulador. O efeito é independente para cada avião. No AOD os ponteiros continuam visíveis.
- Números e ecos decorativos aparecem atrás do feixe por cerca de 1,44 s.
  Os números perdem brilho gradualmente; os quatro ecos somem ao expirar.
- Data DD/MM à direita (3h) e bateria à esquerda (9h), lidas dos sensores
  do relógio; não são valores fixos.
- AOD separado: aviões brancos, fundo preto, sem segundos nem radar.
- Temporizador encerrado em `onDestroy`; pausa/retomada pelo delegate
  quando disponível. Em outras telas, `tick` não altera os desenhos.

Os ecos não representam tráfego aéreo, localização ou dados de radar reais.

## Comandos na pasta do projeto

```powershell
node tools/test.cjs
zeus build -t 466x466-amazfit-gtr-4
zeus dev -t 466x466-amazfit-gtr-4
```

Use apenas uma instância de `zeus dev`. Pare-a com Ctrl+C antes de executar
`zeus build`; não faça as duas compilações ao mesmo tempo. Durante esta
sessão houve conflito em `dist` entre processos, incluindo erro `EEXIST`.
O build normal gerou um `.zab` quando executado separadamente.

As imagens podem ser regeneradas com Python e Pillow:

```powershell
python tools/generate_assets.py
```

## Validação e limites

- Build com Zeus 1.9.3/ZPM 3.4.2: JavaScript compilado por QJSC e imagens
  convertidas; pacote `.zab` gerado.
- Testes com módulos ESM simulados, sem fornecer os globais legados:
  resolução das importações, ciclo/expiração do feixe, virada de data,
  bateria zero/indisponível, pausa/retomada, proteção de AOD e limpeza
  de temporizador, incluindo firmware sem `WIDGET_DELEGATE`.
- Estes testes não substituem execução no firmware. Desempenho, consumo,
  transparência/rotação e transição AOD precisam de validação no GTR 4 real.
- A tela de diagnóstico “RADAR OK” com fundo verde foi confirmada pelo
  usuário no emulador. A tela preta foi diagnosticada com `createWidget`
  indisponível: a importação principal de `@zos/ui`, conforme o exemplo
  oficial de mostrador, resolveu o teste. O radar usa a mesma importação.
  O usuário confirmou que o radar completo apareceu no emulador e,
  após substituir IMG_POINTER por IMG com prop.ANGLE no feixe, confirmou
  que o feixe aparece e gira. A captura enviada mostra os dois aviões,
  marcadores, data e bateria. Validação no aparelho físico permanece pendente.
- O aviso `Slirp: Failed to send packet, ret: -1` aparece na lista de
  mensagens ignoradas pelo próprio simulador instalado. Isoladamente,
  ele não comprova falha de instalação nem erro no mostrador.
- O modo AOD deve ser econômico: a orientação oficial pede fundo preto,
  ponteiros brancos, ausência de segundos e no máximo 10% de pixels acesos.
  Não foi implementada varredura animada no AOD.
- A animação usa widgets nativos e uma imagem rotacionada, sem canvas web
  ou WebGL. O custo de redesenho de uma imagem de tela inteira deve ser
  medido no relógio antes de aumentar a frequência.
- Este é um protótipo de desenvolvimento, não uma submissão pronta à loja:
  o ícone original foi mantido e ainda faltam validação física e revisão
  completa dos requisitos de publicação/localização.

## Fontes oficiais

- Dispositivos: https://docs.zepp.com/docs/reference/related-resources/device-list/
- Manifesto: https://docs.zepp.com/docs/reference/app-json/
- Ponteiros: https://docs.zepp.com/docs/v2/watchface/api/hmUI/widget/TIME_POINTER/
- Opacidade: https://docs.zepp.com/docs/reference/device-app-api/newAPI/ui/setAlpha/
- Rotação: https://docs.zepp.com/docs/v2/watchface/api/hmUI/widget/IMG_POINTER/
- AOD: https://docs.zepp.com/docs/watchface/specification/
- Simulador: https://docs.zepp.com/docs/guides/tools/simulator/


