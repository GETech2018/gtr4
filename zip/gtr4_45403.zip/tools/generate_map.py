"""Draw schematic cartography and mini aircraft; leave existing user assets intact."""
from pathlib import Path
import math
import random
from PIL import Image, ImageDraw, ImageFilter

OUT = Path(__file__).resolve().parents[1] / 'assets/466x466-amazfit-gtr-4/radar'
S = 3
def points(vertices):
    return [(round(x*S), round(y*S)) for x,y in vertices]

canvas = Image.new('RGBA', (466*S,466*S))
d = ImageDraw.Draw(canvas)
# Fictional coastal sector, inspired by an air traffic control map.
coast = [(57,53),(205,49),(202,79),(217,99),(208,117),(231,133),
         (222,155),(240,174),(234,195),(258,210),(251,229),(274,250),
         (269,272),(290,289),(281,313),(299,333),(290,354),(312,381),
         (302,417),(48,417)]
d.polygon(points(coast), fill=(18,57,33,96))
d.line(points(coast[1:-1]), fill=(64,139,91,160), width=S)
# Islands and inland lakes.
for polygon in [[(301,171),(316,153),(327,159),(325,178),(311,190)],
                [(325,219),(341,210),(352,222),(341,244),(327,240)],
                [(316,285),(334,276),(345,288),(334,308),(320,303)]]:
    d.polygon(points(polygon),fill=(20,62,38,100))
    d.line(points(polygon+[polygon[0]]),fill=(55,123,80,145),width=S)
for box in [(113,113,132,141),(165,278,181,309),(102,326,125,344)]:
    d.ellipse(tuple(v*S for v in box),fill=(2,20,12,145),outline=(40,89,62,120),width=S)
# Meandering river and branching roads.
d.line(points([(87,56),(101,87),(95,108),(119,144),(133,157),(128,183),
               (148,201),(177,207),(187,226),(221,236),(251,229)]),
       fill=(52,119,87,145),width=2*S)
roads = [ [(78,98),(134,160),(190,211),(230,275),(259,345),(281,396)],
          [(58,291),(126,256),(190,211),(204,152),(190,89)],
          [(63,170),(135,180),(190,211),(223,201),(249,207)],
          [(92,382),(126,310),(126,256),(96,209),(103,153)],
          [(80,334),(152,335),(230,275),(263,276)] ]
for road in roads:
    d.line(points(road),fill=(67,130,77,140),width=S)
# Fine street blocks around the schematic airport, with no tiny unreadable labels.
for i in range(8):
    x=133+i*9
    d.line(points([(x,174),(x+23,236)]),fill=(42,92,57,105),width=S)
for i in range(7):
    y=177+i*9
    d.line(points([(130,y),(212,y+12)]),fill=(42,92,57,105),width=S)
# Two runway strips and threshold marks.
for offset in [0,10]:
    d.line(points([(205+offset,232),(226+offset,264)]),fill=(87,152,102,170),width=2*S)
for x,y in [(134,160),(190,211),(230,275),(126,256)]:
    d.ellipse(((x-2)*S,(y-2)*S,(x+2)*S,(y+2)*S),outline=(85,155,102,170),width=S)
# Limit cartography to the inner dial; preserve the user's bezel and numerals.
mask = Image.new('L',canvas.size)
ImageDraw.Draw(mask).ellipse((59*S,59*S,407*S,407*S),fill=255)
from PIL import ImageChops
canvas.putalpha(ImageChops.multiply(canvas.getchannel('A'),mask))
canvas.resize((466,466),Image.Resampling.LANCZOS).save(OUT/'map-overlay.png')

mini = Image.new('RGBA',(48*S,72*S))
d=ImageDraw.Draw(mini)
outline=[(24,5),(26,10),(27,17),(39,25),(39,29),(27,25),
         (26,32),(31,36),(31,39),(24,36),(17,39),(17,36),
         (22,32),(21,25),(9,29),(9,25),(21,17),(22,10)]
d.polygon(points(outline),fill=(68,198,101,235))
d.line(points(outline+[outline[0]]),fill=(131,255,157,245),width=S)
for i in range(4):
    y=44+i*7
    d.ellipse((22*S,(y-2)*S,26*S,(y+2)*S),fill=(86,245,120,220-i*45))
mini=Image.alpha_composite(mini.filter(ImageFilter.GaussianBlur(1.5*S)),mini)
mini.resize((48,72),Image.Resampling.LANCZOS).save(OUT/'mini-aircraft.png')
print('Generated map-overlay.png and mini-aircraft.png; existing assets preserved.')
