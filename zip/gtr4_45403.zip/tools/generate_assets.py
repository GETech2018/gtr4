"""Deterministic geometric artwork; requires Pillow. Preserves the original icon."""
from pathlib import Path
import math
import random
from PIL import Image, ImageDraw, ImageFilter

ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / 'assets' / '466x466-amazfit-gtr-4' / 'radar'
OUT.mkdir(parents=True, exist_ok=True)
SCALE = 3

def save_drawing(name, size, draw_fn, background=(0, 0, 0, 0)):
    im = Image.new('RGBA', (size[0]*SCALE, size[1]*SCALE), background)
    draw_fn(ImageDraw.Draw(im))
    im = im.resize(size, Image.Resampling.LANCZOS)
    im.save(OUT / name)
    return im

def pt(x, y):
    return (round(x*SCALE), round(y*SCALE))

def aircraft_points(width, length):
    return [(0,0),(2,5),(3,20),(width/2,33),(width/2,38),
            (4,31),(3,47),(10,53),(10,57),(0,53),
            (-10,57),(-10,53),(-3,47),(-4,31),
            (-width/2,38),(-width/2,33),(-3,20),(-2,5)]

def background(d):
    c = 233
    rng = random.Random(42)
    for _ in range(16000):
        x, y = rng.randrange(466), rng.randrange(466)
        if math.hypot(x-c,y-c) < 223:
            green = rng.randrange(5, 25)
            d.point(pt(x,y), fill=(0,green,green//4,255))
    # Concentric range rings, alternating solid and dotted fine subdivisions.
    for radius in (32, 58, 88, 116, 146, 174, 202, 222):
        d.ellipse((*pt(c-radius, c-radius), *pt(c+radius, c+radius)),
                  outline=(16, 76, 31, 255), width=SCALE)
    for radius in (44,73,102,131,160,188,214):
        for angle in range(0,360,3):
            a = math.radians(angle)
            d.ellipse((*pt(c+radius*math.sin(a)-.4,c-radius*math.cos(a)-.4),
                       *pt(c+radius*math.sin(a)+.4,c-radius*math.cos(a)+.4)), fill=(18,81,30,255))
    for angle in range(0, 360, 15):
        a = math.radians(angle)
        d.line((pt(c, c), pt(c+224*math.sin(a), c-224*math.cos(a))),
               fill=(10, 36, 23, 255), width=SCALE)
    for offset in range(-175,176,8):
        d.line((pt(c+offset,c-2),pt(c+offset,c+2)),fill=(46,116,56,255),width=SCALE)
        d.line((pt(c-2,c+offset),pt(c+2,c+offset)),fill=(46,116,56,255),width=SCALE)
    for i in range(180):
        a = math.radians(i*2)
        inner = 211 if i % 15 == 0 else (216 if i % 3 == 0 else 220)
        d.line((pt(c+inner*math.sin(a), c-inner*math.cos(a)),
                pt(c+227*math.sin(a), c-227*math.cos(a))),
               fill=(92, 231, 114, 255) if i % 3 == 0 else (28, 96, 44, 255), width=SCALE)
    for i in range(12):
        a = math.radians(i*30)
        p = (pt(c+211*math.sin(a),c-211*math.cos(a)),pt(c+225*math.sin(a),c-225*math.cos(a)))
        d.line(p, fill=(12,55,22,255),width=10*SCALE)
        d.line(p, fill=(30,149,51,255),width=6*SCALE)
        d.line(p, fill=(137,255,153,255),width=3*SCALE)
    # Thin metal bezel with directional highlights.
    for radius in range(229,233):
        for degree in range(360):
            value = int(80 + 115 * (0.5+0.5*math.cos(math.radians(degree-310))))
            d.arc((*pt(c-radius,c-radius),*pt(c+radius,c+radius)),degree,degree+1,fill=(value,value,int(value*.94),255),width=SCALE)
    # Decorative miniature aircraft and fading dotted tracks, behind the live sweep.
    for x,y,angle in [(166,124,-32),(307,129,35),(132,301,218),(316,319,142)]:
        a = math.radians(angle)
        def transform(px,py):
            return pt(x+px*math.cos(a)-py*math.sin(a), y+px*math.sin(a)+py*math.cos(a))
        points = [(px*.34,(py-28)*.34) for px,py in aircraft_points(48,57)]
        d.polygon([transform(px,py) for px,py in points],fill=(47,151,62,255))
        for i in range(5):
            tx,ty = transform(0,15+i*7)
            radius = max(1,2-i*.2)*SCALE
            d.ellipse((tx-radius,ty-radius,tx+radius,ty+radius),fill=(35,130-i*21,44,255))

base = save_drawing('background.png', (466, 466), background, (0, 5, 2, 255))
light = Image.new('RGBA', base.size)
light.putdata([(45,255,77,150) if g>180 and g>r*1.2 else (0,0,0,0)
               for r,g,b,a in base.getdata()])
base = Image.alpha_composite(base, light.filter(ImageFilter.GaussianBlur(4)))
base.save(OUT / 'background.png')

# Polar alpha gradient: leading edge points north; tail extends anticlockwise.
beam = Image.new('RGBA', (466, 466))
pixels = beam.load()
for y in range(466):
    for x in range(466):
        dx, dy = x-233, y-233
        radius = math.hypot(dx, dy)
        if radius > 231:
            continue
        angle = math.degrees(math.atan2(dx, -dy)) % 360
        age = (-angle) % 360
        if age <= 65:
            strength = (1-age/65)**1.8
            grain = random.Random(y*466+x).uniform(.72,1)
            alpha = round(140*strength*min(1, radius/22)*grain)
            if age < 0.55:
                alpha = 210
            pixels[x, y] = (61, 255, 113, alpha)
beam.save(OUT / 'sweep.png')

def plane(name, size, width, length, pivot, color, aod=False):
    cx = size[0]/2
    nose = 7
    def draw(d):
        points = aircraft_points(width,length)
        factor = length/57
        polygon = [pt(cx+x, nose+y*factor) for x,y in points]
        if not aod:
            # Tapered luminous shaft connects the aircraft to the central hub.
            shaft = [pt(cx-4,pivot),pt(cx-2,nose+length*.65),pt(cx+2,nose+length*.65),pt(cx+4,pivot)]
            d.polygon(shaft,fill=(28,98,40,160))
            d.line(shaft+[shaft[0]],fill=(95,220,105,215),width=SCALE)
        d.polygon(polygon, fill=color if aod else (35,115,48,200))
        if not aod:
            d.line(polygon+[polygon[0]],fill=color,width=SCALE)
            d.line((pt(cx,nose+5),pt(cx,nose+length-8)), fill=(156,255,163,235),width=SCALE)
    im = save_drawing(name,size,draw)
    if not aod:
        glow = im.filter(ImageFilter.GaussianBlur(2.8))
        im = Image.alpha_composite(glow, im)
        im.save(OUT / name)
    return im

plane('hour.png', (60,150), 52, 64, 145, (106,255,120,255))
plane('minute.png', (44,208), 36, 48, 203, (172,255,221,255))
plane('hour-aod.png', (60,150), 52, 64, 145, (255,255,255,255),True)
plane('minute-aod.png', (44,208), 36, 48, 203, (255,255,255,255),True)

def echo(d):
    d.ellipse((*pt(1,1),*pt(13,13)),outline=(48,180,85,255),width=SCALE)
    d.ellipse((*pt(5,5),*pt(9,9)),fill=(145,255,170,255))
save_drawing('echo.png',(14,14),echo)
def hub(d):
    for r, color in [(15,(20,29,22,255)),(14,(133,143,130,255)),(12,(40,48,43,255)),(10,(199,205,193,255)),(8,(127,135,123,255)),(4,(21,26,23,255)),(2,(4,9,5,255))]:
        d.ellipse((*pt(16-r,16-r),*pt(16+r,16+r)),fill=color)
    d.arc((*pt(4,4),*pt(28,28)),195,300,fill=(245,255,241,255),width=SCALE)
save_drawing('hub.png',(32,32),hub)

def instruments(d):
    # Fixed frames; live sensor text is drawn by the watchface above them.
    for r,col in [(39,(111,138,108,255)),(37,(18,32,21,255)),(34,(41,73,44,255)),(32,(2,10,4,255))]:
        d.ellipse((*pt(110-r,233-r),*pt(110+r,233+r)),fill=col)
    for i in range(44):
        a=math.radians(40+i*6.4)
        d.line((pt(110+27*math.sin(a),233-27*math.cos(a)),pt(110+31*math.sin(a),233-31*math.cos(a))),fill=(87,175,91,255),width=SCALE)
    d.rectangle((*pt(100,219),*pt(118,228)),outline=(157,221,149,255),width=SCALE)
    d.rectangle((*pt(118,222),*pt(121,225)),fill=(157,221,149,255))
    for inset,col in [(0,(115,135,110,255)),(2,(197,212,184,255)),(3,(37,56,38,255)),(5,(4,14,6,255))]:
        d.rectangle((*pt(319+inset,213+inset),*pt(389-inset,253-inset)),fill=col)
panel = save_drawing('instruments.png',(466,466),instruments)
panel.putdata([(round(r*.7),round(g*.7),round(b*.7),round(a*.72)) for r,g,b,a in panel.getdata()])
panel.save(OUT/'instruments.png')
print(f'Generated 9 assets in {OUT}')
