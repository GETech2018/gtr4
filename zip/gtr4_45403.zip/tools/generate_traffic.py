"""Draw original geometric aircraft silhouettes in three sizes; reference-inspired."""
from pathlib import Path
from PIL import Image, ImageDraw, ImageFilter

OUT=Path(__file__).resolve().parents[1]/'assets/466x466-amazfit-gtr-4/radar'
S=4
airliner=[(0,-17),(2,-12),(3,-5),(14,3),(14,7),(3,3),(2,10),(7,14),(7,17),(0,14),(-7,17),(-7,14),(-2,10),(-3,3),(-14,7),(-14,3),(-3,-5),(-2,-12)]
fighter=[(0,-18),(3,-10),(4,-3),(15,11),(15,14),(4,10),(7,17),(2,15),(0,12),(-2,15),(-7,17),(-4,10),(-15,14),(-15,11),(-4,-3),(-3,-10)]
glider=[(0,-17),(1,-12),(2,-3),(17,0),(17,3),(2,1),(1,12),(6,14),(6,16),(0,15),(-6,16),(-6,14),(-1,12),(-2,1),(-17,3),(-17,0),(-2,-3),(-1,-12)]
cargo=[(0,-16),(3,-12),(4,-3),(16,2),(16,7),(4,4),(3,12),(9,15),(9,18),(0,15),(-9,18),(-9,15),(-3,12),(-4,4),(-16,7),(-16,2),(-4,-3),(-3,-12)]
prop=[(0,-14),(3,-10),(3,-2),(15,-2),(15,3),(3,3),(2,12),(8,13),(8,16),(0,15),(-8,16),(-8,13),(-2,12),(-3,3),(-15,3),(-15,-2),(-3,-2),(-3,-10)]
for kind in ['airliner','prop','cargo','fighter','helicopter','glider']:
    for name,size in [('small',20),('medium',26),('large',32)]:
        im=Image.new('RGBA',(48*S,48*S));d=ImageDraw.Draw(im)
        factor=size/36
        def p(x,y):return (round((24+x*factor)*S),round((24+y*factor)*S))
        def line(vertices,width=1):d.line([p(x,y) for x,y in vertices],fill=(126,238,147,245),width=max(1,round(width*S*factor)))
        if kind=='helicopter':
            d.ellipse((*p(-4,-11),*p(4,7)),fill=(64,177,87,240),outline=(126,238,147,245),width=S)
            line([(0,5),(0,17)],2)
            line([(-5,15),(5,15)],1.5)
            line([(-16,-4),(16,-4)],2)
            line([(0,-17),(0,10)],1.5)
            line([(-7,-7),(-7,7)],1)
            line([(7,-7),(7,7)],1)
        else:
            polygon={'airliner':airliner,'prop':prop,'cargo':cargo,'fighter':fighter,'glider':glider}[kind]
            d.polygon([p(x,y) for x,y in polygon],fill=(61,177,86,240))
            line(polygon+[polygon[0]])
            if kind=='prop': line([(-9,-14),(9,-14)],2)
            if kind=='cargo':
                for x in [-10,-6,6,10]:line([(x,-3),(x,5)],2)
            line([(0,-11),(0,10)])
        im=Image.alpha_composite(im.filter(ImageFilter.GaussianBlur(.65*S)),im)
        im.resize((48,48),Image.Resampling.LANCZOS).save(OUT/f'traffic-{kind}-{name}.png')
print('Generated 18 traffic sprites: six silhouettes, three sizes, no dotted trails.')
