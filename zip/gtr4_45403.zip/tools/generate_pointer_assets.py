"""Geometric amber aircraft hands, four oriented minis, and numeral shading.
Only creates the named resources; user background and instruments stay intact.
"""
from pathlib import Path
import math
from PIL import Image, ImageDraw, ImageFilter

OUT = Path(__file__).resolve().parents[1]/'assets/466x466-amazfit-gtr-4/radar'
S=4
def p(vertices): return [(round(x*S),round(y*S)) for x,y in vertices]
def save_glow(im,name,size):
    glow=im.filter(ImageFilter.GaussianBlur(1.2*S))
    im=Image.alpha_composite(glow,im)
    im.resize(size,Image.Resampling.LANCZOS).save(OUT/name)

for name,size,pivot,length,width,body,edge in [
    ('hour.png',(60,150),(30,145),66,48,(228,126,17,255),(255,200,61,255)),
    ('minute.png',(44,208),(22,203),51,34,(255,185,27,255),(255,237,116,255))]:
    im=Image.new('RGBA',(size[0]*S,size[1]*S))
    d=ImageDraw.Draw(im)
    cx,cy=pivot
    nose=6
    # Wide continuous shaft, fully opaque, from the hub into the aircraft body.
    shaft=[(cx-4.5,cy+2),(cx-2.5,nose+length*.55),
           (cx+2.5,nose+length*.55),(cx+4.5,cy+2)]
    d.polygon(p(shaft),fill=body)
    d.line(p(shaft+[shaft[0]]),fill=edge,width=S)
    shape=[(0,0),(1.8,5),(2.5,19),(width/2,32),(width/2,37),
           (3.4,30),(2.7,46),(9,52),(9,56),(0,52),
           (-9,56),(-9,52),(-2.7,46),(-3.4,30),
           (-width/2,37),(-width/2,32),(-2.5,19),(-1.8,5)]
    polygon=[(cx+x,nose+y*length/56) for x,y in shape]
    d.polygon(p(polygon),fill=body)
    d.line(p(polygon+[polygon[0]]),fill=edge,width=S)
    d.line(p([(cx,nose+4),(cx,cy-3)]),fill=(255,237,150,255),width=S)
    save_glow(im,name,size)

shape=[(0,-17),(2,-12),(3,-5),(14,3),(14,7),(3,3),
       (2,10),(7,14),(7,17),(0,14),(-7,17),(-7,14),
       (-2,10),(-3,3),(-14,7),(-14,3),(-3,-5),(-2,-12)]
for heading,name in [(0,'north'),(90,'east'),(180,'south'),(270,'west')]:
    a=math.radians(heading)
    polygon=[(24+.8*(x*math.cos(a)-y*math.sin(a)),24+.8*(x*math.sin(a)+y*math.cos(a))) for x,y in shape]
    im=Image.new('RGBA',(48*S,48*S)); d=ImageDraw.Draw(im)
    d.polygon(p(polygon),fill=(53,163,77,235))
    d.line(p(polygon+[polygon[0]]),fill=(111,224,135,245),width=S)
    save_glow(im,'mini-'+name+'.png',(48,48))

# A transparent native drawing overlays only the numeral areas, without editing
# the user-supplied background2.png (the four numerals are baked into that image).
im=Image.new('RGBA',(466*S,466*S)); d=ImageDraw.Draw(im)
for box in [(208,3,258,31),(433,215,465,251),(214,432,250,465),(2,215,34,251)]:
    d.rounded_rectangle(tuple(round(v*S) for v in box),radius=3*S,fill=(0,0,0,140))
im.resize((466,466),Image.Resampling.LANCZOS).save(OUT/'numeral-dimmer.png')
print('Generated amber pointer hands, four headings without trails, and numeral dimmer.')
