"""Code-native vintage radar AOD: seven-segment time, range rings, native date."""
from pathlib import Path
import math
from PIL import Image, ImageDraw, ImageFont

OUT=Path(__file__).resolve().parents[1]/'assets/466x466-amazfit-gtr-4/radar'
S=4
def pts(vertices): return [(round(x*S),round(y*S)) for x,y in vertices]
def rect(box): return tuple(round(v*S) for v in box)
def save_digit(im,name,size):
    im=im.resize(size,Image.Resampling.LANCZOS)
    # Remove nearly invisible antialias fringes to keep AOD pixel coverage low.
    im.putalpha(im.getchannel('A').point(lambda value: value if value>=32 else 0))
    im.save(OUT/name)

# Fixed-width instrument digits: bold enough for readability, sparse enough for AOD.
segments={
 'a':[(8,3),(34,3),(38,6),(34,9),(8,9),(4,6)],
 'g':[(8,31),(34,31),(38,34),(34,37),(8,37),(4,34)],
 'd':[(8,59),(34,59),(38,62),(34,65),(8,65),(4,62)],
 'f':[(3,9),(6,6),(9,10),(9,28),(6,32),(3,29)],
 'b':[(33,10),(36,6),(39,9),(39,29),(36,32),(33,28)],
 'e':[(3,39),(6,36),(9,40),(9,57),(6,61),(3,58)],
 'c':[(33,40),(36,36),(39,39),(39,58),(36,61),(33,57)]}
codes=['ab cdef'.replace(' ',''),'bc','abged','abgcd','fgbc','afgcd','afgecd','abc','abcdefg','abfgcd']
for value,code in enumerate(codes):
    im=Image.new('RGBA',(76*S,124*S)); d=ImageDraw.Draw(im)
    for name in code:
        polygon=[(round(x*76/42*S),round(y*124/68*S)) for x,y in segments[name]]
        d.polygon(polygon,fill='white')
    save_digit(im,f'aod-time-{value}.png',(76,124))

datefont=ImageFont.truetype('C:/Windows/Fonts/consola.ttf',30*S)
for value in range(10):
    im=Image.new('RGBA',(20*S,38*S)); d=ImageDraw.Draw(im)
    d.text((10*S,19*S),str(value),font=datefont,anchor='mm',fill='white')
    save_digit(im,f'aod-digit-{value}.png',(20,38))

im=Image.new('RGB',(466*S,466*S),'black'); d=ImageDraw.Draw(im)
ring=(36,180,72); ink=(88,220,116)
for r in [126,182,223]: d.ellipse(rect((233-r,233-r,233+r,233+r)),outline=ring,width=S)
for i in range(36):
    a=math.radians(i*10); inner=215 if i%3==0 else 222
    d.line(pts([(233+inner*math.sin(a),233-inner*math.cos(a)),(233+229*math.sin(a),233-229*math.cos(a))]),fill=ring,width=S)
for angle in [0,90,180,270]:
    a=math.radians(angle)
    d.line(pts([(233+118*math.sin(a),233-118*math.cos(a)),(233+212*math.sin(a),233-212*math.cos(a))]),fill=ring,width=S)
# A dark instrument window makes the large digits immediately readable.
d.rectangle(rect((49,157,417,307)),fill='black')
for vertices in [[(53,174),(53,158),(76,158)],[(390,158),(413,158),(413,174)],
                 [(53,290),(53,306),(76,306)],[(390,306),(413,306),(413,290)]]:
    d.line(pts(vertices),fill=ink,width=S)
font=ImageFont.truetype('C:/Windows/Fonts/consola.ttf',20*S)
small=ImageFont.truetype('C:/Windows/Fonts/consola.ttf',16*S)
d.rectangle(rect((163,89,303,117)),fill='black')
d.text((233*S,103*S),'R A D A R',font=font,anchor='mm',fill=ink)
d.text((233*S,135*S),'S T B Y',font=small,anchor='mm',fill=ink)
# Fixed separator; firmware draws hour/minute digits beside it without flashing.
for cy in [211,252]: d.rectangle(rect((230,cy-3,236,cy+3)),fill='white')
d.rectangle(rect((175,317,292,364)),fill='black')
d.text((207*S,340*S),'DAY',font=small,anchor='mm',fill=ink)
im=im.resize((466,466),Image.Resampling.LANCZOS)
im.putdata([pixel if max(pixel)>=32 else (0,0,0) for pixel in im.getdata()])
im.save(OUT/'aod-digital-panel.png')
print('Generated vintage radar digital AOD panel and ten seven-segment digits.')
