// ESM import/lifecycle checks with mocked @zos modules; not a firmware emulator.
const assert = require('node:assert/strict')
const fs = require('node:fs')
const path = require('node:path')
const vm = require('node:vm')
if (!vm.SourceTextModule) {
  const result = require('node:child_process').spawnSync(process.execPath,
    ['--experimental-vm-modules', __filename], { stdio: 'inherit' })
  process.exit(result.status === null ? 1 : result.status)
}
const root = path.resolve(__dirname, '..')
const source = fs.readFileSync(path.join(root, 'watchface/index.js'), 'utf8')
async function run(withDelegate, alwaysVisible = true, withEditor = true) {
  let face, now = 100000, screen = 1, mutations = 0, nextId = 0
  const widgets = [], timers = new Map()
  const time = { day: 31, month: 12, hour: 10, minute: 15, second: 0 }, battery = { current: 100 }
  const enums = Object.fromEntries(['IMG','IMG_POINTER','TEXT','TIME_POINTER','IMG_DATE','IMG_TIME'].map(k => [k,k]))
  if (withDelegate) enums.WIDGET_DELEGATE = 'WIDGET_DELEGATE'
  if (withEditor) enums.WATCHFACE_EDIT_BG = 'WATCHFACE_EDIT_BG'
  const ui = {
      widget: enums, show_level: { ONLY_NORMAL: 1, ONAL_AOD: 2, ONLY_EDIT: 4 },
      align: { CENTER_H: 0, CENTER_V: 0, LEFT: 1 }, prop: { MORE: 'MORE', VISIBLE: 'VISIBLE', ANGLE: 'ANGLE' },
      createWidget(type, options) {
        assert.ok(type, 'Undefined widget type')
        for (const key of ['src','hour_path','minute_path','fg','tips_bg']) {
          if (options[key]) assert.ok(fs.existsSync(path.join(root, 'assets/466x466-amazfit-gtr-4', options[key])))
        }
        if(options.bg_config) {
          assert.equal(options.bg_config.length,4)
          assert.equal(new Set(options.bg_config.map(item=>item.id)).size,4)
          for(const item of options.bg_config) for(const key of ['preview','path']) {
            assert.ok(fs.existsSync(path.join(root,'assets/466x466-amazfit-gtr-4',item[key])))
          }
        }
        for (const key of ['day_en_array','day_sc_array','day_tc_array','hour_array','minute_array']) {
          if (options[key]) {
            assert.equal(options[key].length, 10, 'Native date uses ten digits')
            for (const file of options[key]) assert.ok(fs.existsSync(path.join(root, 'assets/466x466-amazfit-gtr-4', file)))
          }
        }
        const widget = { type, options: { ...options }, visible: true,
          setProperty(prop, value) {
            mutations++
            if (prop === 'MORE') Object.assign(this.options, value)
            else if (prop === 'VISIBLE') this.visible = value
            else if (prop === 'ANGLE') this.options.angle = value
            else throw Error('Unknown property')
          }
        }
        widgets.push(widget)
        return widget
      }
  }
  const context = vm.createContext({
    console: { log() {} }, Date: { now: () => now },
    WatchFace: definition => { face = definition },
    setInterval(callback, delay) { assert.equal(delay,50); timers.set(nextId, callback); return nextId++ },
    clearInterval(id) { assert.ok(timers.delete(id), 'Timer stopped twice or wrong ID') }
  })
  const dependencies = {
    '@zos/ui': { default: ui },
    '@zos/app': { getScene: () => screen, SCENE_WATCHFACE: 1 },
    '@zos/sensor': {
      Time: class {
        getDate() { return time.day } getMonth() { return time.month }
        getHours() { return time.hour } getMinutes() { return time.minute }
        getSeconds() { return time.second }
      },
      Battery: class { getCurrent() { return battery.current } }
    }
  }
  const testedSource = alwaysVisible ? source : source.replace('const HANDS_ALWAYS_VISIBLE = true', 'const HANDS_ALWAYS_VISIBLE = false')
  const trafficModule = new vm.SourceTextModule(fs.readFileSync(path.join(root, 'watchface/traffic.js'), 'utf8'), { context })
  const module = new vm.SourceTextModule(testedSource + '\nexport { echoStrength }', { context })
  await module.link(specifier => {
    if (specifier === './traffic') return trafficModule
    const dependency = dependencies[specifier]
    assert.ok(dependency, 'Unexpected import: ' + specifier)
    return new vm.SyntheticModule(Object.keys(dependency), function () {
      for (const [key,value] of Object.entries(dependency)) this.setExport(key,value)
    }, { context })
  })
  await module.evaluate()
  const { echoStrength } = module.namespace
  const { trafficFrame, trafficAppearance, createTraffic, advanceTraffic } = trafficModule.namespace
  assert.equal(echoStrength(359, 0), 0, 'Do not reveal marker ahead of beam')
  assert.equal(echoStrength(0, 0), 1)
  assert.ok(echoStrength(1, 359) > 0.9, 'Echo survives 360-degree wrap')
  assert.equal(echoStrength(180, 0), 0, 'User echo duration preserved')
  face.onInit(); face.build()
  assert.equal(timers.size, 1)
  assert.equal(face.dateText.options.text, '31')
  assert.equal(face.batteryText.options.text, '100%')
  assert.ok(face.batteryText.options.x < 233)
  assert.ok(face.dateText.options.x > 233)
  if(withEditor) {
    assert.equal(face.backgroundEditor.type,'WATCHFACE_EDIT_BG')
    assert.equal(face.backgroundEditor.options.default_id,4,'Colorful map is default')
    assert.equal(face.backgroundEditor.options.show_level,5,'Background enabled for normal/edit scenes, excluded from AOD')
    assert.equal(face.backgroundEditor.options.count,4)
  } else assert.ok(widgets.some(w=>w.options.src==='radar/themes/weather.png'),'Missing native editor falls back to colorful map without crashing')
  assert.equal(face.traffic.length, 4, 'Four animated flight routes')
  now = 101500; face.tick()
  assert.equal(face.beam.options.angle, 90)
  assert.equal((face.handEchoes[1].widget.options.alpha > 0), true, 'Minute aircraft revealed at 3 oclock')
  const fade = [face.handEchoes[1].widget.options.alpha]
  for (let step = 0; step < 120; step++) {
    now += 50; face.tick()
    fade.push(face.handEchoes[1].widget.options.alpha)
  }
  assert.equal(fade[0], 255, 'Full brightness at beam crossing')
  if (alwaysVisible) {
    assert.ok(fade.every(alpha => alpha >= 153 && alpha <= 255), 'Hands stay between 60% and 100% brightness')
    assert.ok(fade.slice(0,11).every(alpha=>alpha===255), 'Hand holds full brightness for 0.5 seconds')
    assert.ok(fade[13]<255, 'Hand starts fading after the hold')
    assert.ok(fade[45] >= 203 && fade[45] <= 205, 'Hand halfway through fade at 2.25 seconds including hold')
    assert.equal(fade[80], 153, 'Hand settles at 60% after 0.5-second hold plus 3.5-second fade')
    assert.equal(fade.at(-2), 153, 'Hand stays at 60% until next pass')
    assert.equal(fade.at(-1), 255, 'Beam restores hand to 100%')
    assert.ok(fade.slice(1,-1).every((alpha,i) => alpha <= fade[i]), 'Glow decays smoothly after the beam')
  }
  else {
  assert.ok(fade[60] >= 173 && fade[60] <= 175, 'Hands keep more brightness at three seconds')
  assert.ok(fade.slice(1, -1).every((value, i) => value <= fade[i]), 'Aircraft progressively fades each frame')
  assert.ok(fade.at(-2) >= 39 && fade.at(-2) <= 45, 'Hands remain visible before next sweep with eight-second decay')
  assert.equal(fade.at(-1), 255, 'Next sweep reilluminates the aircraft')
  }
  assert.ok(face.handEchoes.every(hand => hand.widget.visible), 'Aircraft fade uses image alpha, never binary visibility')
  // Cross the entire dial in every heading, with no six-second position reset.
  for (let index = 0; index < 4; index++) {
    const start = -index * 18000
    const first = trafficFrame(start, index), last = trafficFrame(start + 71999, index)
    assert.ok(first.radius > 233 && last.radius > 233, 'Route endpoints lie outside circular display')
    assert.ok(Math.hypot(last.x-first.x,last.y-first.y) > 440, 'Route crosses the dial')
    const middle = trafficFrame(start + 36000,index), next = trafficFrame(start + 36050,index)
    assert.ok(Math.hypot(next.x-middle.x,next.y-middle.y) < 1, 'Motion remains gentle per frame')
  }
  const state = createTraffic(0)
  const middle = trafficFrame(36000,0)
  advanceTraffic(state,36000,middle.bearing,0)
  assert.equal(state.alpha,255,'Moving target revealed by beam')
  const initialX=state.x, initialY=state.y, originalSrc=state.src
  advanceTraffic(state,38500,trafficFrame(38500,0).bearing+150,3)
  assert.ok(state.alpha>=127 && state.alpha<=128,'Moving echo half brightness after 2.5s')
  assert.equal(state.src,originalSrc,'Day-period change does not morph aircraft in mid-flight')
  advanceTraffic(state,41000,trafficFrame(41000,0).bearing+200,3)
  assert.equal(state.alpha,0,'Moving echo fades after five seconds')
  assert.ok(Math.hypot(state.x-initialX,state.y-initialY)>30,'Aircraft advances while fading')
  const models=new Set(), sizes=new Set()
  for(let cycle=0;cycle<8;cycle++) for(let hour=0;hour<24;hour+=3) {
    const appearance=trafficAppearance(cycle,0,hour)
    models.add(appearance.type); sizes.add(appearance.size)
    assert.ok(fs.existsSync(path.join(root,'assets/466x466-amazfit-gtr-4',appearance.src)))
  }
  assert.equal(models.size,6); assert.equal(sizes.size,3)
  let visibleMoves=0, sourceChanges=0
  const stopAt=now+150000
  for(;now<stopAt;now+=50) {
    const before=face.traffic.map(t=>({src:t.state.src,alpha:t.state.alpha,x:t.state.x,y:t.state.y}))
    face.tick()
    face.traffic.forEach((track,index)=>{
      const prior=before[index], current=track.state
      if(current.alpha>0 && prior.alpha>0 && (current.x!==prior.x || current.y!==prior.y)) visibleMoves++
      if(prior.src && current.src!==prior.src) {
        sourceChanges++
        assert.equal(current.alpha,0,'Aircraft models change off-screen')
      }
    })
  }
  assert.ok(visibleMoves>100 && sourceChanges>0,'Live lifecycle advances traffic and refreshes aircraft')
  time.hour = 11; time.minute = 59; time.second = 59
  now = 112000; face.tick()
  assert.equal((face.handEchoes[0].widget.options.alpha > 0), true, 'Hour echo crosses north')
  assert.equal((face.handEchoes[1].widget.options.alpha > 0), true, 'Minute echo crosses north')
  assert.equal(face.beam.options.angle, 0, 'User six-second revolution preserved')
  time.day = 1; time.month = 1; battery.current = 0; face.tick()
  assert.equal(face.dateText.options.text, '01', 'Date rollover')
  battery.current = undefined; face.tick()
  assert.equal(face.batteryText.options.text, '--%')
  screen = 2; const before = mutations; now += 1000; face.tick()
  assert.equal(mutations, before, 'No drawing during AOD')
  const aod = widgets.filter(w => w.options.show_level === 2)
  assert.equal(aod.length, 3)
  assert.ok(!aod.some(w => w.type === 'TIME_POINTER'), 'AOD is digital instead of analog')
  assert.equal(face.aodTime.type, 'IMG_TIME', 'Firmware controls digital AOD time')
  assert.equal(face.aodTime.options.show_level, 2)
  assert.ok(!face.aodTime.options.second_array, 'No ticking seconds in AOD')
  assert.equal(face.aodDate.type, 'IMG_DATE', 'Firmware updates AOD date without JS animation')
  assert.equal(face.aodDate.options.show_level, 2)
  assert.equal(face.aodDate.options.day_zero, 1)
  if (withDelegate) {
    const delegate = widgets.find(w => w.type === 'WIDGET_DELEGATE')
    delegate.options.pause_call(); assert.equal(timers.size, 0)
    screen = 1; delegate.options.resume_call(); delegate.options.resume_call()
    assert.equal(timers.size, 1, 'Resume must not duplicate timers')
  }
  face.onDestroy(); assert.equal(timers.size, 0)
  const after = mutations; face.tick(); face.startRadar()
  assert.equal(mutations, after); assert.equal(timers.size, 0)
  for(const scene of [2,4]) {
    screen=scene; face.onInit(); face.build()
    assert.equal(timers.size,0,'Starting directly in AOD/editor does not start animation timer')
    face.onDestroy()
  }
}
async function main() {
await run(true)
await run(false)
await run(true, false)
await run(false, false)
await run(true, true, false)
const config = JSON.parse(fs.readFileSync(path.join(root, 'app.json')))
const target = config.targets['466x466-amazfit-gtr-4']
assert.equal(config.app.appType, 'watchface')
assert.equal(config.runtime.apiVersion.compatible, '2.1.0')
assert.equal(target.designWidth, 466)
const supportedDevices = JSON.parse(fs.readFileSync(path.join(root, 'tools/devices-466.json'), 'utf8'))
const expectedSources = supportedDevices.devices.flatMap(device => device.deviceSources)
assert.equal(new Set(expectedSources).size, 21, '21 unique official regional identifiers')
assert.deepEqual(target.platforms.map(p => p.deviceSource), expectedSources)
assert.equal(target.module.watchface.path, 'watchface/index')
assert.equal(target.module.watchface.lockscreen, 1, 'Package must declare AOD support, in addition to drawing AOD widgets')
assert.equal(target.module.watchface.editable,1,'Enable native edit entry point')
console.log('PASS: crossing routes, continuous movement, six models/three sizes, off-screen swaps, beam fade, assets/config, native AOD, pause/resume and timer cleanup.')
}
main().catch(error => { console.error(error); process.exitCode = 1 })


