"""Compose native editable backgrounds from generated maps and exact dial geometry."""
from pathlib import Path
import math
from PIL import Image, ImageDraw, ImageFont

ROOT=Path(__file__).resolve().parents[1]
OUT=ROOT/'assets/466x466-amazfit-gtr-4/radar/themes'
OUT.mkdir(parents=True,exist_ok=True)
S=4
CYAN=(74,204,226)
THEMES=[
 ('green','radar-map-master.png',(48,115,65),(60,135,75),(83,160,96),(73,124,83)),
 ('green-cyan','radar-map-master.png',(48,115,65),CYAN,CYAN,CYAN),
 ('blue','radar-map-blue-master.png',(37,117,184),CYAN,CYAN,CYAN),
 ('weather','radar-map-weather-master.png',(44,150,68),(66,220,96),(66,220,96),(95,225,119))]
def p(x,y):return (round(x*S),round(y*S))
font=ImageFont.truetype('C:/Windows/Fonts/consolab.ttf',26)
for slug,source,rings,minor,major,numbers in THEMES:
    face=Image.open(ROOT/'art'/source).convert('RGBA').resize((466,466),Image.Resampling.LANCZOS)
    overlay=Image.new('RGBA',(466*S,466*S),(0,0,0,255));d=ImageDraw.Draw(overlay)
    d.ellipse((*p(0,0),*p(466,466)),fill=(0,0,0,100))
    for r in [44,86,132,176,204]:d.ellipse((*p(233-r,233-r),*p(233+r,233+r)),outline=(*rings,190),width=S)
    for angle in [0,90,180,270]:
        a=math.radians(angle)
        axis=(40,92,53) if slug in ['green','green-cyan'] else rings
        d.line((p(233,233),p(233+203*math.sin(a),233-203*math.cos(a))),fill=(*axis,135),width=S)
    for i in range(120):
        a=math.radians(i*3);inner=219 if i%10==0 else 225 if i%2==0 else 228
        d.line((p(233+inner*math.sin(a),233-inner*math.cos(a)),p(233+231*math.sin(a),233-231*math.cos(a))),fill=(*minor,200),width=S)
    for i in range(12):
        a=math.radians(i*30)
        d.line((p(233+219*math.sin(a),233-219*math.cos(a)),p(233+230*math.sin(a),233-230*math.cos(a))),fill=(*major,230),width=3*S)
    face.alpha_composite(overlay.resize((466,466),Image.Resampling.LANCZOS))
    d=ImageDraw.Draw(face)
    for label,x,y in [('12',233,25),('3',441,233),('6',233,441),('9',25,233)]:d.text((x,y),label,font=font,fill=numbers,anchor='mm')
    face.convert('RGB').save(OUT/f'{slug}.png',optimize=True)
im=Image.new('RGBA',(466*S,466*S));d=ImageDraw.Draw(im)
d.ellipse((*p(8,8),*p(458,458)),outline=(125,224,239,240),width=2*S)
im.resize((466,466),Image.Resampling.LANCZOS).save(OUT/'editor-fg.png')
im=Image.new('RGBA',(180*S,28*S));d=ImageDraw.Draw(im)
d.rounded_rectangle((0,0,180*S-1,28*S-1),radius=8*S,fill=(0,0,0,230),outline=(125,224,239,230),width=S)
d.text((90*S,14*S),'BACKGROUND',font=ImageFont.truetype('C:/Windows/Fonts/consola.ttf',14*S),fill='white',anchor='mm')
im.resize((180,28),Image.Resampling.LANCZOS).save(OUT/'editor-tip.png')
print('Generated four 466x466 backgrounds and native editor resources.')
