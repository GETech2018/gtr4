"""Compose the actual face assets at 10:09 for the watchface selection thumbnail."""
from pathlib import Path
import math
import json
import subprocess
import argparse
from PIL import Image, ImageDraw, ImageFont

BASE=Path(__file__).resolve().parents[1]/'assets/466x466-amazfit-gtr-4'
ART=BASE/'radar'
angle=55
parser=argparse.ArgumentParser()
parser.add_argument('--theme',default='weather',choices=['green','green-cyan','blue','weather'])
parser.add_argument('--output')
args=parser.parse_args()
face=Image.open(ART/'themes'/f'{args.theme}.png').convert('RGBA')
face.alpha_composite(Image.open(ART/'sweep.png').rotate(-angle,resample=Image.Resampling.BICUBIC,center=(233,233)))
snapshot=subprocess.run(['node',str(Path(__file__).with_name('snapshot_traffic.cjs'))],capture_output=True,text=True,check=True)
for aircraft in json.loads(snapshot.stdout):
    if not aircraft['alpha']: continue
    mini=Image.open(BASE/aircraft['src']).convert('RGBA')
    mini=mini.rotate(-aircraft['angle'],resample=Image.Resampling.BICUBIC,center=(24,24))
    mini.putalpha(mini.getchannel('A').point(lambda value:round(value*aircraft['alpha']/255)))
    face.alpha_composite(mini,(aircraft['x'],aircraft['y']))
face.alpha_composite(Image.open(ART/'date-panel.png').convert('RGBA'))
face.alpha_composite(Image.open(ART/'battery-panel.png').convert('RGBA'))
ImageDraw.Draw(face).text((354,233),'24',font=ImageFont.truetype('C:/Windows/Fonts/consola.ttf',20),fill='#80ac79',anchor='mm')
ImageDraw.Draw(face).text((112,233),'78%',font=ImageFont.truetype('C:/Windows/Fonts/consola.ttf',20),fill='#80ac79',anchor='mm')
for kind,pivot,theta in [('hour',(30,145),304.5),('minute',(22,203),54)]:
    layer=Image.new('RGBA',(466,466))
    layer.alpha_composite(Image.open(ART/f'{kind}.png'),(233-pivot[0],233-pivot[1]))
    glow=max(0,1-max(0,((angle-theta)%360)-30)/210)
    opacity=(153+round(102*glow*glow*(3-2*glow)))/255
    layer.putalpha(layer.getchannel('A').point(lambda value:round(value*opacity)))
    face.alpha_composite(layer.rotate(-theta,resample=Image.Resampling.BICUBIC,center=(233,233)))
face.alpha_composite(Image.open(ART/'hub.png'),(217,217))
# Solid black corners match the physical circular screen and avoid white margins.
if args.output:
    face.convert('RGB').save(args.output,optimize=True)
    print(args.output)
else:
    if args.theme!='weather': raise ValueError('Alternative themes require --output')
    face.convert('RGB').save(BASE/'preview.png')
    face.convert('RGB').resize((314,314),Image.Resampling.LANCZOS).save(BASE/'icon.png')
    print('Face thumbnail: icon.png 314x314; cover: preview.png 466x466.')
