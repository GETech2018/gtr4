"""Draw a uniform silver bezel as a separate geometric overlay."""
from pathlib import Path
from PIL import Image, ImageDraw

out = Path(__file__).resolve().parents[1]/'assets/466x466-amazfit-gtr-4/radar'
scale=4
im=Image.new('RGBA',(466*scale,466*scale))
d=ImageDraw.Draw(im)
# Radial relief only: identical silver at every angle, with no dark sectors.
for radius,color in [(232.5,168),(231.8,207),(230.8,221),(229.8,199),(228.8,169)]:
    box=tuple(round(v*scale) for v in (233-radius,233-radius,233+radius,233+radius))
    d.ellipse(box,fill=(color,color,color,255))
radius=228
d.ellipse(tuple(round(v*scale) for v in (233-radius,233-radius,233+radius,233+radius)),fill=(0,0,0,0))
im.resize((466,466),Image.Resampling.LANCZOS).save(out/'silver-bezel.png')
print('Generated uniform silver-bezel.png')
