    /*
     ** Watch_Face_Editor tool
     ** watchface js version v2.1.1
     ** Copyright © SashaCX75. All Rights Reserved
     */

    try {
     (() => {
      //start of ignored block
      const __$$app$$__ = __$$hmAppManager$$__.currentApp;

      function getApp() {
       return __$$app$$__.app;
      }

      function getCurrentPage() {
       return __$$app$$__.current && __$$app$$__.current.module;
      }
      const __$$module$$__ = __$$app$$__.current;
      const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
      const {
       px
      } = __$$app$$__.__globals__;
      const logger = Logger.getLogger('watchface_SashaCX75');
      //end of ignored block

      //dynamic modify start


      console.log('user_functions.js');
      // start user_functions.js

      const {
       width: D_W,
       height: D_H
      } = hmSetting.getDeviceInfo();
      let groupVremya = ''
      let groupPogoda = ''
      let groupTap = ''
      let groupActiv = ''
      let canvas0 = ''
      let canvas = ''

      let groupSleep = ''


      let normal_background_bg = ''


      //  const wfv = 'v0.1' // версия циферблата (для сброса настроек)


      let lang = hmSetting.getLanguage() == 4 ? 0 : 1

      const timeSensor = hmSensor.createSensor(hmSensor.id.TIME);

      //const curTime = hmSensor.createSensor(hmSensor.id.TIME);
      const battery = hmSensor.createSensor(hmSensor.id.BATTERY);

      const step = hmSensor.createSensor(hmSensor.id.STEP);
      const heart = hmSensor.createSensor(hmSensor.id.HEART);
      const calorie = hmSensor.createSensor(hmSensor.id.CALORIE);

      const distance = hmSensor.createSensor(hmSensor.id.DISTANCE);
      const stand = hmSensor.createSensor(hmSensor.id.STAND)
      const pai = hmSensor.createSensor(hmSensor.id.PAI);
      const fatburn = hmSensor.createSensor(hmSensor.id.FAT_BURRING);
      const spo2 = hmSensor.createSensor(hmSensor.id.SPO2);
      const stress = hmSensor.createSensor(hmSensor.id.STRESS);


      let battText, battScale
      let dateText, dayNameText = [],
       dayTemp = [],
       dayWeatherIcon = []
      let dney = 4;
      let daysNum = 8
      let fix_day = 0;

      //-------------------------------- 
      //переменные для ргафика
      let weather_ic_array = []
      let weather_ic = []
      let DigDay = []
      let DigNight = []
      let yArrH = [];
      let arr_xH = [];
      let arr_yH = [];
      let arr_x = [];
      let arr_y = [];
      let arr_xL = [];
      let arr_yL = [];
      let yArrAll = [];
      let yArrL = [];
      let y_pogodaH = [];
      let y_pogodaL = [];
      let week_array = ["ПН", "ВТ", "СР", "ЧТ", "ПТ", "СБ", "ВС"];
      let week_text = []
      let data_text = []
      const ROOTPATH = "images/"
      var shag = 46;
      var x0 = 119 - 23 - 23;
      //let isDayIcons = false
      //-------------------------------- 

      let normal_time_hour_min_text_font, minText
      let curTempText, curWeatherIcon, curCityName, curHumText, curWindText, curWindPointer, normal_update_time_text_font
      let Temp_Now, Temp_Max, Temp_Min, Temp_Delta, Temp_Procent
      let T_N, T_V, T_Z, T_24, level_SUN_CURRENT_day, level_SUN_CURRENT_night


      const speedUnit = [
       [' м/с', ' m/s'], //0
      ]

      const pressUnit = [
       [' мм', ' mmHg'], //0
       [' ГПа', ' hPa'], //1
      ]

      const distUnit = [
       [' м', ' m'], //0
       ['', ' km'], //1
      ]

      //      const distUnit = [
      //       [' м', ' m'], //0
      //       [' км', ' km'], //1
      //      ]

      const windDirectionStr = [
       ['СЕВ', 'N'], // 0
       ['С-В', 'NE'], // 1
       ['ВОС', 'E'], // 2
       ['Ю-В', 'SE'], // 3
       ['ЮЖН', 'S'], // 4
       ['Ю-З', 'SW'], // 5
       ['ЗАП', 'W'], // 6
       ['С-З', 'NW'], // 7
      ];



      let normal_motion_animation_img_1 = '';
      let normal_motion_animation_paramX_1 = null;
      let normal_motion_animation_lastTime_1 = 0;
      let timer_anim_motion_1;
      let normal_motion_animation_count_1 = 0;
      let normal_motion_animation_img_2 = '';
      let normal_motion_animation_paramX_2 = null;
      let normal_motion_animation_lastTime_2 = 0;
      let timer_anim_motion_2;
      let normal_motion_animation_count_2 = 0;


      function anim_sun_moon() {
       if (isDayIcons) {
        // anim_sun()
       } else {
        anim_moon()

       }
      }

      function start_Anim() {
       //let ic_W_index = 1 //тест
       let ic_W_index = weatherData.weatherIcon

       off_Anim()

       if (!isDayIcons) anim_star()

       // 1 Ясно 
       if (ic_W_index == 1) {
        rainfall.hide(0); //спрятать
        snowfall.hide(0); //спрятать
        anim_sun_moon()

        if (isDayIcons) {
         anim_airbaloon();
         anim_sun_blick()
         mask12.setProperty(hmUI.prop.VISIBLE, false);
         sun.setProperty(hmUI.prop.VISIBLE, true);
         anim_sun_ani()
        }
       }

       // 2 Слабая облачность  
       if (ic_W_index == 2) {
        rainfall.hide(0); //спрятать
        snowfall.hide(0); //спрятать
       }
       // 3 Облачно 
       if (ic_W_index == 3) {
        rainfall.hide(0); //спрятать
        snowfall.hide(0); //спрятать
        normal_motion_animation_img_1.setProperty(hmUI.prop.VISIBLE, true);
        normal_motion_animation_img_2.setProperty(hmUI.prop.VISIBLE, true);
       }
       // 4 Пасмур  
       if (ic_W_index == 4) {
        rainfall.hide(0); //спрятать
        snowfall.hide(0); //спрятать
        normal_motion_animation_img_1.setProperty(hmUI.prop.VISIBLE, true);
        normal_motion_animation_img_2.setProperty(hmUI.prop.VISIBLE, true);
       }
       // 5 Слабый дождь
       if (ic_W_index == 5) {
        snowfall.hide(0); //спрятать
        rainfall.hide(1) //- опобразить
        rainfall.start() //- запустить   
        thunder_img.setProperty(hmUI.prop.VISIBLE, true);
       }
       // 6 Дождь
       if (ic_W_index == 6) {
        anim_sun_moon()
        snowfall.hide(0); //спрятать
        rainfall.hide(1) //- опобразить
        rainfall.start() //- запустить   
        normal_motion_animation_img_1.setProperty(hmUI.prop.VISIBLE, true);
        normal_motion_animation_img_2.setProperty(hmUI.prop.VISIBLE, true);
        thunder_img.setProperty(hmUI.prop.VISIBLE, true);
       }
       // 7 Ливень  
       if (ic_W_index == 7) {
        snowfall.hide(0); //спрятать
        rainfall.hide(1) //- опобразить
        rainfall.start() //- запустить   
        thunder_img.setProperty(hmUI.prop.VISIBLE, true);
       }
       // 8 Гроза
       if (ic_W_index == 8) {
        anim_sun_moon()
        anim_groza();
        snowfall.hide(0); //спрятать
        rainfall.hide(1) //- опобразить
        rainfall.start() //- запустить   
        normal_motion_animation_img_1.setProperty(hmUI.prop.VISIBLE, true);
        normal_motion_animation_img_2.setProperty(hmUI.prop.VISIBLE, true);
        thunder_img.setProperty(hmUI.prop.VISIBLE, true);
       }
       // 9 Слабый снег
       if (ic_W_index == 9) {
        anim_sun_moon()
        rainfall.hide(0); //спрятать
        snowfall.hide(1) //- опобразить
        snowfall.start() //- запустить
       }
       // 10 Снег
       if (ic_W_index == 10) {
        rainfall.hide(0); //спрятать
        snowfall.hide(1) //- опобразить
        snowfall.start() //- запустить
       }
       // 11 Снегопад
       if (ic_W_index == 11) {
        rainfall.hide(0); //спрятать
        snowfall.hide(1) //- опобразить
        snowfall.start() //- запустить
       }
       // 12 Дождь со сонегом
       if (ic_W_index == 12) {
        snowfall.hide(1) //- опобразить
        snowfall.start() //- запустить
        rainfall.hide(1) //- опобразить
        rainfall.start() //- запустить   
        wheather12_img.setProperty(hmUI.prop.VISIBLE, true);
        thunder_img.setProperty(hmUI.prop.VISIBLE, true);
       }
       // 13 Туман
       if (ic_W_index == 13) {
        rainfall.hide(0); //спрятать
        snowfall.hide(0); //спрятать
        anim_fog()
        anim_sun_moon()
       }
       // 14 Ветрено
       if (ic_W_index == 14) {
        rainfall.hide(0); //спрятать
        snowfall.hide(0); //спрятать
        anim_sun_moon()
        anim_wind()
       }
      };


      function off_Anim() {
       //       snowfall.hide(); // остановить снегопад
       //       image_cleard.setProperty(hmUI.prop.VISIBLE, false);
       mask12.setProperty(hmUI.prop.VISIBLE, true);
       fog_img.setProperty(hmUI.prop.VISIBLE, false);
       wind_img.setProperty(hmUI.prop.VISIBLE, false);
       klenr_img.setProperty(hmUI.prop.VISIBLE, false);
       kleng_img.setProperty(hmUI.prop.VISIBLE, false);
       klenk_img.setProperty(hmUI.prop.VISIBLE, false);
       moon_1.setProperty(hmUI.prop.VISIBLE, false);
       star_1.setProperty(hmUI.prop.VISIBLE, false);
       star_2.setProperty(hmUI.prop.VISIBLE, false);
       star_3.setProperty(hmUI.prop.VISIBLE, false);
       airbaloon_img.setProperty(hmUI.prop.VISIBLE, false);
       weather_1_0_bg_img.setProperty(hmUI.prop.VISIBLE, false);
       sun_blick.setProperty(hmUI.prop.VISIBLE, false);
       sun_ani_img.setProperty(hmUI.prop.VISIBLE, false);
       sun.setProperty(hmUI.prop.VISIBLE, false);
       normal_motion_animation_img_1.setProperty(hmUI.prop.VISIBLE, false);
       normal_motion_animation_img_2.setProperty(hmUI.prop.VISIBLE, false);
       stop_anim_motion_1();
       stop_anim_motion_2();
       thunder_img.setProperty(hmUI.prop.VISIBLE, false);
       thunder00_img.setProperty(hmUI.prop.VISIBLE, false);
       thunder01_img.setProperty(hmUI.prop.VISIBLE, false);
       thunder02_img.setProperty(hmUI.prop.VISIBLE, false);
       thunder03_img.setProperty(hmUI.prop.VISIBLE, false);
       wheather12_img.setProperty(hmUI.prop.VISIBLE, false);
       snowfall.hide(0); //спрятать
       snowfall.stop(); //остановить
       rainfall.hide(0); //спрятать
       rainfall.stop(); //остановить
      };

      function anim_sun_ani() {
       sun_ani_img.setProperty(hmUI.prop.VISIBLE, true);

       sun_ani_1 = {
        anim_rate: 'linear',
        anim_duration: 70000,
        anim_from: 0,
        anim_to: 360,
        anim_offset: 0,
        anim_prop: hmUI.prop.ANGLE,
       }

       sun_ani_img.setProperty(hmUI.prop.ANIM, {
        anim_auto_start: 1,
        anim_auto_destroy: 0,
        anim_steps: [sun_ani_1],
        anim_repeat: 0,
        anim_fps: 15,
       })
      };

      function anim_fog() {
       fog_img.setProperty(hmUI.prop.VISIBLE, true);

       X_1 = {
        anim_rate: 'linear',
        anim_duration: 2500,
        anim_from: 0,
        anim_to: 60,
        anim_offset: 0,
        anim_prop: hmUI.prop.X,
       }

       X_2 = {
        anim_rate: 'linear',
        anim_duration: 50000,
        anim_from: 60,
        anim_to: 0,
        anim_offset: 2500,
        anim_prop: hmUI.prop.X,
       }

       X_3 = {
        anim_rate: 'linear',
        anim_duration: 55000,
        anim_from: 0,
        anim_to: 0,
        anim_offset: 2500 + 50000,
        anim_prop: hmUI.prop.X,
       }

       fog_1 = {
        anim_rate: 'easeOutExpo',
        anim_duration: 3000,
        anim_from: 255,
        anim_to: 255,
        anim_offset: 10000,
        anim_prop: hmUI.prop.ALPHA,
       }

       fog_2 = {
        anim_rate: 'easeOutExpo',
        anim_duration: 6000,
        anim_from: 255,
        anim_to: 200,
        anim_offset: 10000 + 3000,
        anim_prop: hmUI.prop.ALPHA,
       }

       fog_3 = {
        anim_rate: 'easeOutExpo',
        anim_duration: 12000,
        anim_from: 200,
        anim_to: 255,
        anim_offset: 10000 + 3000 + 6000,
        anim_prop: hmUI.prop.ALPHA,
       }

       fog_img.setProperty(hmUI.prop.ANIM, {
        anim_auto_start: 1,
        anim_auto_destroy: 0,
        anim_steps: [X_1, X_2, X_3, fog_1, fog_2, fog_3],
        anim_repeat: 0,
        anim_fps: 25,
       })
      }


      function anim_wind() {
       wind_img.setProperty(hmUI.prop.VISIBLE, true);
       klenr_img.setProperty(hmUI.prop.VISIBLE, true);
       kleng_img.setProperty(hmUI.prop.VISIBLE, true);
       klenk_img.setProperty(hmUI.prop.VISIBLE, true);

       X_1 = {
        anim_rate: 'linear',
        anim_duration: 9000,
        anim_from: 0,
        anim_to: 313,
        anim_offset: 0,
        anim_prop: hmUI.prop.X,
       }

       gr00_1 = {
        anim_rate: 'easeOutExpo',
        anim_duration: 1600,
        anim_from: 0,
        anim_to: 200,
        anim_offset: 0,
        anim_prop: hmUI.prop.ALPHA,
       }
       gr00_2 = {
        anim_rate: 'easeOutExpo',
        anim_duration: 400,
        anim_from: 200,
        anim_to: 255,
        anim_offset: 1600,
        anim_prop: hmUI.prop.ALPHA,
       }
       gr00_3 = {
        anim_rate: 'easeOutExpo',
        anim_duration: 3300,
        anim_from: 255,
        anim_to: 255,
        anim_offset: 2000,
        anim_prop: hmUI.prop.ALPHA,
       }
       gr00_4 = {
        anim_rate: 'easeOutExpo',
        anim_duration: 1500,
        anim_from: 255,
        anim_to: 200,
        anim_offset: 5300,
        anim_prop: hmUI.prop.ALPHA,
       }
       gr00_5 = {
        anim_rate: 'easeOutExpo',
        anim_duration: 1600,
        anim_from: 0,
        anim_to: 0,
        anim_offset: 6800,
        anim_prop: hmUI.prop.ALPHA,
       }
       gr00_6 = {
        anim_rate: 'easeOutExpo',
        anim_duration: 600,
        anim_from: 0,
        anim_to: 0,
        anim_offset: 8400,
        anim_prop: hmUI.prop.ALPHA,
       }

       X_kr_1 = {
        anim_rate: 'linear',
        anim_duration: 5000,
        anim_from: 100,
        anim_to: 195,
        anim_offset: 0,
        anim_prop: hmUI.prop.X,
       }

       X_kr_2 = {
        anim_rate: 'linear',
        anim_duration: 2000,
        anim_from: 195,
        anim_to: 200,
        anim_offset: 5000 + 0,
        anim_prop: hmUI.prop.X,
       }

       let Y_kr_rd = randomInt(-20, 20)

       Y_kr_1 = {
        anim_rate: 'linear',
        anim_duration: 5000,
        anim_from: 229,
        anim_to: 229 - Y_kr_rd,
        anim_offset: 0,
        anim_prop: hmUI.prop.Y,
       }

       Y_kr_2 = {
        anim_rate: 'linear',
        anim_duration: 2000,
        anim_from: 229 - Y_kr_rd,
        anim_to: 229,
        anim_offset: 5000 + 0,
        anim_prop: hmUI.prop.Y,
       }

       angle_kr = {
        anim_rate: 'linear',
        anim_duration: 4800,
        anim_from: 0,
        anim_to: 360,
        anim_offset: 0,
        anim_prop: hmUI.prop.ANGLE,
       }

       kr_0 = {
        anim_rate: 'easeOutExpo',
        anim_duration: 0,
        anim_from: 0,
        anim_to: 0,
        anim_offset: 0,
        anim_prop: hmUI.prop.ALPHA,
       }

       kr_1 = {
        anim_rate: 'easeOutExpo',
        anim_duration: 600,
        anim_from: 0,
        anim_to: 200,
        anim_offset: 0,
        anim_prop: hmUI.prop.ALPHA,
       }
       kr_2 = {
        anim_rate: 'easeOutExpo',
        anim_duration: 400,
        anim_from: 200,
        anim_to: 255,
        anim_offset: 0 + 600,
        anim_prop: hmUI.prop.ALPHA,
       }
       kr_3 = {
        anim_rate: 'easeOutExpo',
        anim_duration: 3300,
        anim_from: 255,
        anim_to: 255,
        anim_offset: 0 + 600 + 400,
        anim_prop: hmUI.prop.ALPHA,
       }
       kr_4 = {
        anim_rate: 'easeOutExpo',
        anim_duration: 500,
        anim_from: 255,
        anim_to: 200,
        anim_offset: 0 + 600 + 400 + 3300,
        anim_prop: hmUI.prop.ALPHA,
       }
       kr_5 = {
        anim_rate: 'easeOutExpo',
        anim_duration: 200,
        anim_from: 0,
        anim_to: 0,
        anim_offset: 0 + 600 + 400 + 3300 + 500,
        anim_prop: hmUI.prop.ALPHA,
       }
       kr_6 = {
        anim_rate: 'easeOutExpo',
        anim_duration: 2000,
        anim_from: 0,
        anim_to: 0,
        anim_offset: 0 + 600 + 400 + 3300 + 500 + 200,
        anim_prop: hmUI.prop.ALPHA,
       }


       X_1_g = {
        anim_rate: 'linear',
        anim_duration: 9000,
        anim_from: 0,
        anim_to: 313,
        anim_offset: 2600,
        anim_prop: hmUI.prop.X,
       }

       gr00_1_g = {
        anim_rate: 'easeOutExpo',
        anim_duration: 1600,
        anim_from: 0,
        anim_to: 200,
        anim_offset: 2600,
        anim_prop: hmUI.prop.ALPHA,
       }
       gr00_2_g = {
        anim_rate: 'easeOutExpo',
        anim_duration: 400,
        anim_from: 200,
        anim_to: 255,
        anim_offset: 1600 + 2600,
        anim_prop: hmUI.prop.ALPHA,
       }
       gr00_3_g = {
        anim_rate: 'easeOutExpo',
        anim_duration: 3300,
        anim_from: 255,
        anim_to: 255,
        anim_offset: 2000 + 2600,
        anim_prop: hmUI.prop.ALPHA,
       }
       gr00_4_g = {
        anim_rate: 'easeOutExpo',
        anim_duration: 1500,
        anim_from: 255,
        anim_to: 200,
        anim_offset: 5300 + 2600,
        anim_prop: hmUI.prop.ALPHA,
       }
       gr00_5_g = {
        anim_rate: 'easeOutExpo',
        anim_duration: 1600,
        anim_from: 0,
        anim_to: 0,
        anim_offset: 6800 + 2600,
        anim_prop: hmUI.prop.ALPHA,
       }
       gr00_6_g = {
        anim_rate: 'easeOutExpo',
        anim_duration: 600,
        anim_from: 0,
        anim_to: 0,
        anim_offset: 8400 + 2600,
        anim_prop: hmUI.prop.ALPHA,
       }

       X_kr_1_g = {
        anim_rate: 'linear',
        anim_duration: 5000,
        anim_from: 100,
        anim_to: 195,
        anim_offset: 2600,
        anim_prop: hmUI.prop.X,
       }

       X_kr_2_g = {
        anim_rate: 'linear',
        anim_duration: 2000,
        anim_from: 195,
        anim_to: 200,
        anim_offset: 5000 + 2600,
        anim_prop: hmUI.prop.X,
       }

       let Y_kr_rd_g = randomInt(-18, 18)

       Y_kr_1_g = {
        anim_rate: 'linear',
        anim_duration: 5000,
        anim_from: 229,
        anim_to: 229 - Y_kr_rd_g,
        anim_offset: 2600,
        anim_prop: hmUI.prop.Y,
       }

       Y_kr_2_g = {
        anim_rate: 'linear',
        anim_duration: 2000,
        anim_from: 229 - Y_kr_rd_g,
        anim_to: 229,
        anim_offset: 5000 + 2600,
        anim_prop: hmUI.prop.Y,
       }

       angle_kr_g = {
        anim_rate: 'linear',
        anim_duration: 4800,
        anim_from: 0,
        anim_to: 360,
        anim_offset: 2600,
        anim_prop: hmUI.prop.ANGLE,
       }

       kr_0_g = {
        anim_rate: 'easeOutExpo',
        anim_duration: 2600,
        anim_from: 0,
        anim_to: 0,
        anim_offset: 0,
        anim_prop: hmUI.prop.ALPHA,
       }

       kr_1_g = {
        anim_rate: 'easeOutExpo',
        anim_duration: 600,
        anim_from: 0,
        anim_to: 200,
        anim_offset: 2600,
        anim_prop: hmUI.prop.ALPHA,
       }
       kr_2_g = {
        anim_rate: 'easeOutExpo',
        anim_duration: 400,
        anim_from: 200,
        anim_to: 255,
        anim_offset: 2600 + 600,
        anim_prop: hmUI.prop.ALPHA,
       }
       kr_3_g = {
        anim_rate: 'easeOutExpo',
        anim_duration: 3300,
        anim_from: 255,
        anim_to: 255,
        anim_offset: 2600 + 600 + 400,
        anim_prop: hmUI.prop.ALPHA,
       }
       kr_4_g = {
        anim_rate: 'easeOutExpo',
        anim_duration: 500,
        anim_from: 255,
        anim_to: 200,
        anim_offset: 2600 + 600 + 400 + 3300,
        anim_prop: hmUI.prop.ALPHA,
       }
       kr_5_g = {
        anim_rate: 'easeOutExpo',
        anim_duration: 200,
        anim_from: 0,
        anim_to: 0,
        anim_offset: 2600 + 600 + 400 + 3300 + 500,
        anim_prop: hmUI.prop.ALPHA,
       }
       kr_6_g = {
        anim_rate: 'easeOutExpo',
        anim_duration: 2000,
        anim_from: 0,
        anim_to: 0,
        anim_offset: 2600 + 600 + 400 + 3300 + 500 + 200,
        anim_prop: hmUI.prop.ALPHA,
       }


       X_1_k = {
        anim_rate: 'linear',
        anim_duration: 9000,
        anim_from: 0,
        anim_to: 313,
        anim_offset: 5600,
        anim_prop: hmUI.prop.X,
       }

       gr00_1_k = {
        anim_rate: 'easeOutExpo',
        anim_duration: 1600,
        anim_from: 0,
        anim_to: 200,
        anim_offset: 5600,
        anim_prop: hmUI.prop.ALPHA,
       }
       gr00_2_k = {
        anim_rate: 'easeOutExpo',
        anim_duration: 400,
        anim_from: 200,
        anim_to: 255,
        anim_offset: 1600 + 5600,
        anim_prop: hmUI.prop.ALPHA,
       }
       gr00_3_k = {
        anim_rate: 'easeOutExpo',
        anim_duration: 3300,
        anim_from: 255,
        anim_to: 255,
        anim_offset: 2000 + 5600,
        anim_prop: hmUI.prop.ALPHA,
       }
       gr00_4_k = {
        anim_rate: 'easeOutExpo',
        anim_duration: 1500,
        anim_from: 255,
        anim_to: 200,
        anim_offset: 5300 + 5600,
        anim_prop: hmUI.prop.ALPHA,
       }
       gr00_5_k = {
        anim_rate: 'easeOutExpo',
        anim_duration: 1600,
        anim_from: 0,
        anim_to: 0,
        anim_offset: 6800 + 5600,
        anim_prop: hmUI.prop.ALPHA,
       }
       gr00_6_k = {
        anim_rate: 'easeOutExpo',
        anim_duration: 600,
        anim_from: 0,
        anim_to: 0,
        anim_offset: 8400 + 5600,
        anim_prop: hmUI.prop.ALPHA,
       }

       X_kr_1_k = {
        anim_rate: 'linear',
        anim_duration: 5000,
        anim_from: 100,
        anim_to: 195,
        anim_offset: 5600,
        anim_prop: hmUI.prop.X,
       }

       X_kr_2_k = {
        anim_rate: 'linear',
        anim_duration: 2000,
        anim_from: 195,
        anim_to: 200,
        anim_offset: 5000 + 5600,
        anim_prop: hmUI.prop.X,
       }

       let Y_kr_rd_k = randomInt(0, 0)

       Y_kr_1_k = {
        anim_rate: 'linear',
        anim_duration: 5000,
        anim_from: 229,
        anim_to: 229 - Y_kr_rd_k,
        anim_offset: 5600,
        anim_prop: hmUI.prop.Y,
       }

       Y_kr_2_k = {
        anim_rate: 'linear',
        anim_duration: 2000,
        anim_from: 229 - Y_kr_rd_k,
        anim_to: 229,
        anim_offset: 5000 + 5600,
        anim_prop: hmUI.prop.Y,
       }

       angle_kr_k = {
        anim_rate: 'linear',
        anim_duration: 4800,
        anim_from: 0,
        anim_to: 360,
        anim_offset: 5600,
        anim_prop: hmUI.prop.ANGLE,
       }

       kr_0_k = {
        anim_rate: 'easeOutExpo',
        anim_duration: 5600,
        anim_from: 0,
        anim_to: 0,
        anim_offset: 0,
        anim_prop: hmUI.prop.ALPHA,
       }

       kr_1_k = {
        anim_rate: 'easeOutExpo',
        anim_duration: 600,
        anim_from: 0,
        anim_to: 200,
        anim_offset: 5600,
        anim_prop: hmUI.prop.ALPHA,
       }
       kr_2_k = {
        anim_rate: 'easeOutExpo',
        anim_duration: 400,
        anim_from: 200,
        anim_to: 255,
        anim_offset: 5600 + 600,
        anim_prop: hmUI.prop.ALPHA,
       }
       kr_3_k = {
        anim_rate: 'easeOutExpo',
        anim_duration: 3300,
        anim_from: 255,
        anim_to: 255,
        anim_offset: 5600 + 600 + 400,
        anim_prop: hmUI.prop.ALPHA,
       }
       kr_4_k = {
        anim_rate: 'easeOutExpo',
        anim_duration: 500,
        anim_from: 255,
        anim_to: 200,
        anim_offset: 5600 + 600 + 400 + 3300,
        anim_prop: hmUI.prop.ALPHA,
       }
       kr_5_k = {
        anim_rate: 'easeOutExpo',
        anim_duration: 200,
        anim_from: 0,
        anim_to: 0,
        anim_offset: 5600 + 600 + 400 + 3300 + 500,
        anim_prop: hmUI.prop.ALPHA,
       }
       kr_6_k = {
        anim_rate: 'easeOutExpo',
        anim_duration: 2000,
        anim_from: 0,
        anim_to: 0,
        anim_offset: 5600 + 600 + 400 + 3300 + 500 + 200,
        anim_prop: hmUI.prop.ALPHA,
       }


       klenr_img.setProperty(hmUI.prop.ANIM, {
        anim_auto_start: 1,
        anim_auto_destroy: 0,
        anim_steps: [X_1, gr00_1, gr00_2, gr00_3, gr00_4, gr00_5, gr00_6, X_kr_1, X_kr_2, Y_kr_1, Y_kr_2, angle_kr, kr_0, kr_1, kr_2, kr_3, kr_4, kr_5, kr_6],
        anim_repeat: 0,
        anim_fps: 25,
       })

       kleng_img.setProperty(hmUI.prop.ANIM, {
        anim_auto_start: 1,
        anim_auto_destroy: 0,
        anim_steps: [X_1_g, gr00_1_g, gr00_2_g, gr00_3_g, gr00_4_g, gr00_5_g, gr00_6_g, X_kr_1_g, X_kr_2_g, Y_kr_1_g, Y_kr_2_g, angle_kr_g, kr_0_g, kr_1_g, kr_2_g, kr_3_g, kr_4_g, kr_5_g, kr_6_g],
        anim_repeat: 0,
        anim_fps: 25,
       })

       klenk_img.setProperty(hmUI.prop.ANIM, {
        anim_auto_start: 1,
        anim_auto_destroy: 0,
        anim_steps: [X_1_k, gr00_1_k, gr00_2_k, gr00_3_k, gr00_4_k, gr00_5_k, gr00_6_k, X_kr_1_k, X_kr_2_k, Y_kr_1_k, Y_kr_2_k, angle_kr_k, kr_0_k, kr_1_k, kr_2_k, kr_3_k, kr_4_k, kr_5_k, kr_6_k],
        anim_repeat: 0,
        anim_fps: 25,
       })

       wind_img.setProperty(hmUI.prop.ANIM, {
        anim_auto_start: 1,
        anim_auto_destroy: 0,
        anim_steps: [X_1, gr00_1, gr00_2, gr00_3, gr00_4, gr00_5, gr00_6],
        anim_repeat: 0,
        anim_fps: 25,
       })

      };


      function anim_groza() {
       thunder00_img.setProperty(hmUI.prop.VISIBLE, true);
       thunder01_img.setProperty(hmUI.prop.VISIBLE, true);
       thunder02_img.setProperty(hmUI.prop.VISIBLE, true);
       thunder03_img.setProperty(hmUI.prop.VISIBLE, true);

       gr00_1 = {
        anim_rate: 'easeOutExpo',
        anim_duration: 0,
        anim_from: 0,
        anim_to: 0,
        anim_offset: 0,
        anim_prop: hmUI.prop.ALPHA,
       }
       gr00_2 = {
        anim_rate: 'easeOutExpo',
        anim_duration: 990,
        anim_from: 0,
        anim_to: 0,
        anim_offset: 0,
        anim_prop: hmUI.prop.ALPHA,
       }

       let second = timeSensor.second;

       let Le00 = timeSensor.second <= 50 ? 1 : 0
       let Ge00 = timeSensor.second >= 40 ? 1 : 0
       let Alpha00 = 255 - 255 * Le00 * Ge00

       gr00_3 = {
        anim_rate: 'easeOutExpo',
        anim_duration: 1000,
        anim_from: 0,
        anim_to: Alpha00,
        anim_offset: 990,
        anim_prop: hmUI.prop.ALPHA,
       }
       gr00_4 = {
        anim_rate: 'easeOutExpo',
        anim_duration: 1200,
        anim_from: Alpha00,
        anim_to: 0,
        anim_offset: 990 + 1000,
        anim_prop: hmUI.prop.ALPHA,
       }
       gr00_5 = {
        anim_rate: 'easeOutExpo',
        anim_duration: 1600,
        anim_from: 0,
        anim_to: 0,
        anim_offset: 990 + 1000 + 1200,
        anim_prop: hmUI.prop.ALPHA,
       }
       gr00_6 = {
        anim_rate: 'easeOutExpo',
        anim_duration: 5000,
        anim_from: 0,
        anim_to: 0,
        anim_offset: 990 + 1000 + 1200 + 1600,
        anim_prop: hmUI.prop.ALPHA,
       }


       //  ------------------------

       gr01_1 = {
        anim_rate: 'easeOutExpo',
        anim_duration: 0,
        anim_from: 0,
        anim_to: 0,
        anim_offset: 0,
        anim_prop: hmUI.prop.ALPHA,
       }
       gr01_2 = {
        anim_rate: 'easeOutExpo',
        anim_duration: 990,
        anim_from: 0,
        anim_to: 0,
        anim_offset: 0,
        anim_prop: hmUI.prop.ALPHA,
       }

       let Le01 = timeSensor.second <= 20 ? 1 : 0
       let Ge01 = timeSensor.second >= 30 ? 1 : 0
       let Alpha01 = 255 - 255 * Le01 * Ge01

       gr01_3 = {
        anim_rate: 'easeOutExpo',
        anim_duration: 1000,
        anim_from: 0,
        anim_to: Alpha01,
        anim_offset: 990,
        anim_prop: hmUI.prop.ALPHA,
       }
       gr01_4 = {
        anim_rate: 'easeOutExpo',
        anim_duration: 1200,
        anim_from: Alpha01,
        anim_to: 0,
        anim_offset: 990 + 1000,
        anim_prop: hmUI.prop.ALPHA,
       }
       gr01_5 = {
        anim_rate: 'easeOutExpo',
        anim_duration: 1600,
        anim_from: 0,
        anim_to: 0,
        anim_offset: 990 + 1000 + 1200,
        anim_prop: hmUI.prop.ALPHA,
       }
       gr01_6 = {
        anim_rate: 'easeOutExpo',
        anim_duration: 5000,
        anim_from: 0,
        anim_to: 0,
        anim_offset: 990 + 1000 + 1200 + 1600,
        anim_prop: hmUI.prop.ALPHA,
       }


       //  ------------------------
       gr02_1 = {
        anim_rate: 'easeOutExpo',
        anim_duration: 0,
        anim_from: 0,
        anim_to: 0,
        anim_offset: 0,
        anim_prop: hmUI.prop.ALPHA,
       }
       gr02_2 = {
        anim_rate: 'easeOutExpo',
        anim_duration: 1490,
        anim_from: 0,
        anim_to: 0,
        anim_offset: 0,
        anim_prop: hmUI.prop.ALPHA,
       }
       gr02_3 = {
        anim_rate: 'easeOutExpo',
        anim_duration: 1500,
        anim_from: 0,
        anim_to: Alpha01,
        anim_offset: 1490,
        anim_prop: hmUI.prop.ALPHA,
       }
       gr02_4 = {
        anim_rate: 'easeOutExpo',
        anim_duration: 1700,
        anim_from: Alpha01,
        anim_to: 0,
        anim_offset: 1490 + 1500,
        anim_prop: hmUI.prop.ALPHA,
       }
       gr02_5 = {
        anim_rate: 'easeOutExpo',
        anim_duration: 2300,
        anim_from: 0,
        anim_to: 0,
        anim_offset: 1490 + 1500 + 1700,
        anim_prop: hmUI.prop.ALPHA,
       }
       gr02_6 = {
        anim_rate: 'easeOutExpo',
        anim_duration: 2500,
        anim_from: 0,
        anim_to: 255 - randomInt(0, 10),
        anim_offset: 1490 + 1500 + 1700 + 2300,
        anim_prop: hmUI.prop.ALPHA,
       }
       gr02_7 = {
        anim_rate: 'easeOutExpo',
        anim_duration: 2700,
        anim_from: 255 - randomInt(0, 10),
        anim_to: 0,
        anim_offset: 1490 + 1500 + 1700 + 2300 + 2500,
        anim_prop: hmUI.prop.ALPHA,
       }
       gr02_8 = {
        anim_rate: 'easeOutExpo',
        anim_duration: 3000,
        anim_from: 0,
        anim_to: 0,
        anim_offset: 1490 + 1500 + 1700 + 2300 + 2500 + 2700,
        anim_prop: hmUI.prop.ALPHA,
       }
       gr02_9 = {
        anim_rate: 'easeOutExpo',
        anim_duration: 5000,
        anim_from: 0,
        anim_to: 0,
        anim_offset: 1490 + 1500 + 1700 + 2300 + 2500 + 2700 + 3000,
        anim_prop: hmUI.prop.ALPHA,
       }


       //  ------------------------

       gr03_1 = {
        anim_rate: 'easeOutExpo',
        anim_duration: 0,
        anim_from: 0,
        anim_to: 0,
        anim_offset: 0,
        anim_prop: hmUI.prop.ALPHA,
       }
       gr03_2 = {
        anim_rate: 'easeOutExpo',
        anim_duration: 1490,
        anim_from: 0,
        anim_to: 0,
        anim_offset: 0,
        anim_prop: hmUI.prop.ALPHA,
       }

       let Le03 = timeSensor.second <= 0 ? 1 : 0
       let Ge03 = timeSensor.second >= 10 ? 1 : 0
       let Alpha03 = 255 - 255 * Le03 * Ge03

       gr03_3 = {
        anim_rate: 'easeOutExpo',
        anim_duration: 1200,
        anim_from: 0,
        anim_to: Alpha03,
        anim_offset: 1490,
        anim_prop: hmUI.prop.ALPHA,
       }
       gr03_4 = {
        anim_rate: 'easeOutExpo',
        anim_duration: 1300,
        anim_from: Alpha03,
        anim_to: 0,
        anim_offset: 1490 + 1200,
        anim_prop: hmUI.prop.ALPHA,
       }
       gr03_5 = {
        anim_rate: 'easeOutExpo',
        anim_duration: 2300,
        anim_from: 0,
        anim_to: 0,
        anim_offset: 1490 + 1200 + 1300,
        anim_prop: hmUI.prop.ALPHA,
       }
       gr03_6 = {
        anim_rate: 'easeOutExpo',
        anim_duration: 1800,
        anim_from: 0,
        anim_to: 255 - randomInt(0, 10),
        anim_offset: 1490 + 1200 + 1300 + 2300,
        anim_prop: hmUI.prop.ALPHA,
       }
       gr03_7 = {
        anim_rate: 'easeOutExpo',
        anim_duration: 2000,
        anim_from: 255 - randomInt(0, 10),
        anim_to: 0,
        anim_offset: 1490 + 1200 + 1300 + 2300 + 1800,
        anim_prop: hmUI.prop.ALPHA,
       }
       gr03_8 = {
        anim_rate: 'easeOutExpo',
        anim_duration: 3000,
        anim_from: 0,
        anim_to: 0,
        anim_offset: 1490 + 1200 + 1300 + 2300 + 1800 + 2000,
        anim_prop: hmUI.prop.ALPHA,
       }
       gr03_9 = {
        anim_rate: 'easeOutExpo',
        anim_duration: 5000,
        anim_from: 0,
        anim_to: 0,
        anim_offset: 1490 + 1200 + 1300 + 2300 + 1800 + 2000 + 3000,
        anim_prop: hmUI.prop.ALPHA,
       }


       //  ------------------------


       thunder00_img.setProperty(hmUI.prop.ANIM, {
        anim_auto_start: 1,
        anim_auto_destroy: 0,
        anim_steps: [gr00_1, gr00_2, gr00_3, gr00_4, gr00_5, gr00_6],
        anim_repeat: 0,
        anim_fps: 25,
       })

       thunder01_img.setProperty(hmUI.prop.ANIM, {
        anim_auto_start: 1,
        anim_auto_destroy: 0,
        anim_steps: [gr01_1, gr01_2, gr01_3, gr01_4, gr01_5, gr01_6],
        anim_repeat: 0,
        anim_fps: 25,
       })

       thunder02_img.setProperty(hmUI.prop.ANIM, {
        anim_auto_start: 1,
        anim_auto_destroy: 0,
        anim_steps: [gr02_1, gr02_2, gr02_3, gr02_4, gr02_5, gr02_6, gr02_7, gr02_8, gr02_9],
        anim_repeat: 0,
        anim_fps: 25,
       })

       thunder03_img.setProperty(hmUI.prop.ANIM, {
        anim_auto_start: 1,
        anim_auto_destroy: 0,
        anim_steps: [gr03_1, gr03_2, gr03_3, gr03_4, gr03_5, gr03_6, gr03_7, gr03_8, gr03_9],
        anim_repeat: 0,
        anim_fps: 25,
       })
      };


      // -----------------блик солнца
      function anim_sun_blick() {
       sun_blick.setProperty(hmUI.prop.VISIBLE, true);

       //       anim_sun_blick_1 = {
       //        anim_rate: 'linear',
       //        anim_duration: 0,
       //        anim_from: 70,
       //        anim_to: 70,
       //        anim_offset: 0,
       //        anim_prop: hmUI.prop.ALPHA,
       //       }
       anim_sun_blick_2 = {
        anim_rate: 'linear',
        anim_duration: 3000,
        anim_from: 70,
        anim_to: 255,
        anim_offset: 0,
        anim_prop: hmUI.prop.ALPHA,
       }

       anim_sun_blick_3 = {
        anim_rate: 'linear',
        anim_duration: 0,
        anim_from: 255,
        anim_to: 255,
        anim_offset: 3000,
        anim_prop: hmUI.prop.ALPHA,
       }

       anim_sun_blick_4 = {
        anim_rate: 'linear',
        anim_duration: 3000,
        anim_from: 255,
        anim_to: 70,
        anim_offset: 3000,
        anim_prop: hmUI.prop.ALPHA,
       }

       sun_blick.setProperty(hmUI.prop.ANIM, {
        anim_auto_start: 1,
        anim_auto_destroy: 0,
        anim_steps: [ /*anim_sun_blick_1,*/ anim_sun_blick_2, anim_sun_blick_3, anim_sun_blick_4],
        anim_repeat: -1,
        anim_fps: 25
       })
      }


      //------------Воздушный шар анимация  
      function anim_airbaloon() {
       airbaloon_img.setProperty(hmUI.prop.VISIBLE, true);
       weather_1_0_bg_img.setProperty(hmUI.prop.VISIBLE, true);

       timer_anim = setInterval(() => {
        let startPoint = points[currentPointIndex];
        let endPoint = points[currentPointIndex + 1];

        if (endPoint) {
         if (startTime === null) {
          startTime = timeSensor.utc; // Устанавливаем время начала анимации
         }
         let elapsed = timeSensor.utc - startTime; // Вычисляем прошедшее время
         const progress = Math.min(elapsed / (duration * spid), 1); // Нормализуем прогресс от 0 до 1
         if (progress < 1) {
          // Линейная интерполяция
          let currentX = startPoint.x + (endPoint.x - startPoint.x) * progress;
          let currentY = startPoint.y + (endPoint.y - startPoint.y) * progress;
          airbaloon_img.setProperty(hmUI.prop.X, currentX);
          airbaloon_img.setProperty(hmUI.prop.Y, currentY);
         } else {
          currentPointIndex++;
          startTime = null; // Сбрасываем время
         }
        } //endPoint
        // }else{currentPointIndex=0}//endPoint
       }, 80); //timer_anim		  

      }


      //------------Звезды анимация 
      function anim_star() {
       star_1.setProperty(hmUI.prop.VISIBLE, true);
       star_2.setProperty(hmUI.prop.VISIBLE, true);
       star_3.setProperty(hmUI.prop.VISIBLE, true);


       //--------------1
       anim_star_1_X = {
        anim_rate: 'linear',
        anim_duration: 1500,
        anim_from: 134,
        anim_to: -372,
        anim_offset: 4500,
        anim_prop: hmUI.prop.X,
       }

       //--------------1
       anim_star_1_Y = {
        anim_rate: 'linear',
        anim_duration: 1500,
        anim_from: 124,
        anim_to: 382,
        anim_offset: 4500,
        anim_prop: hmUI.prop.Y,
       }

       //--------------2
       anim_star_2_X = {
        anim_rate: 'linear',
        anim_duration: 4000,
        anim_from: 267,
        anim_to: -372,
        anim_offset: 6900,
        anim_prop: hmUI.prop.X,
       }

       //--------------1
       anim_star_2_Y = {
        anim_rate: 'linear',
        anim_duration: 4000,
        anim_from: 124,
        anim_to: 382,
        anim_offset: 6900,
        anim_prop: hmUI.prop.Y,
       }

       //--------------3
       anim_star_3_X = {
        anim_rate: 'linear',
        anim_duration: 6500,
        anim_from: 467,
        anim_to: -372,
        anim_offset: 2500,
        anim_prop: hmUI.prop.X,
       }

       //--------------3
       anim_star_3_Y = {
        anim_rate: 'linear',
        anim_duration: 6500,
        anim_from: 124,
        anim_to: 382,
        anim_offset: 2500,
        anim_prop: hmUI.prop.Y,
       }


       star_1.setProperty(hmUI.prop.ANIM, {
        anim_auto_destroy: 0,
        anim_steps: [anim_star_1_X, anim_star_1_Y],
        anim_repeat: -1,
        anim_fps: 25,
        anim_complete_func: () => {
         star_1.setProperty(hmUI.prop.VISIBLE, false);
         star_2.setProperty(hmUI.prop.VISIBLE, true);
        },
       });


       star_2.setProperty(hmUI.prop.ANIM, {
        anim_auto_destroy: 0,
        anim_steps: [anim_star_2_X, anim_star_2_Y],
        anim_repeat: -1,
        anim_fps: 25,
        anim_complete_func: () => {
         star_2.setProperty(hmUI.prop.VISIBLE, false);
         star_3.setProperty(hmUI.prop.VISIBLE, true);
        },
       });


       star_3.setProperty(hmUI.prop.ANIM, {
        anim_auto_destroy: 0,
        anim_steps: [anim_star_3_X, anim_star_3_Y],
        anim_repeat: -1,
        anim_fps: 25,
        anim_complete_func: () => {
         star_3.setProperty(hmUI.prop.VISIBLE, false);
         star_1.setProperty(hmUI.prop.VISIBLE, true);
        },
       });
      }


      function anim_moon() {
       moon_1.setProperty(hmUI.prop.VISIBLE, true);

       anim_moon_1_X = {
        anim_rate: 'linear',
        anim_duration: 600000 / 1,
        anim_from: 333,
        anim_to: 267,
        anim_offset: 0,
        anim_prop: hmUI.prop.X,
       }

       anim_moon_1_Y = {
        anim_rate: 'linear',
        anim_duration: 600000 / 1,
        anim_from: 271,
        anim_to: 124,
        anim_offset: 0,
        anim_prop: hmUI.prop.Y,
       }

       anim_moon_2_X = {
        anim_rate: 'linear',
        anim_duration: 1400000 / 1,
        anim_from: 267,
        anim_to: 200,
        anim_offset: 600000 / 1,
        anim_prop: hmUI.prop.X,
       }

       anim_moon_2_Y = {
        anim_rate: 'linear',
        anim_duration: 1400000 / 1,
        anim_from: 124,
        anim_to: 124,
        anim_offset: 600000 / 1,
        anim_prop: hmUI.prop.Y,
       }

       anim_moon_3_X = {
        anim_rate: 'linear',
        anim_duration: 2200000 / 1,
        anim_from: 200,
        anim_to: 127,
        anim_offset: (600000 + 1400000) / 1,
        anim_prop: hmUI.prop.X,
       }

       anim_moon_3_Y = {
        anim_rate: 'linear',
        anim_duration: 2200000 / 1,
        anim_from: 124,
        anim_to: 141,
        anim_offset: (600000 + 1400000) / 1,
        anim_prop: hmUI.prop.Y,
       }

       anim_moon_4_X = {
        anim_rate: 'linear',
        anim_duration: 2900000 / 1,
        anim_from: 127,
        anim_to: 80,
        anim_offset: (600000 + 1400000 + 2200000) / 1,
        anim_prop: hmUI.prop.X,
       }

       anim_moon_4_Y = {
        anim_rate: 'linear',
        anim_duration: 2900000 / 1,
        anim_from: 141,
        anim_to: 164,
        anim_offset: (600000 + 1400000 + 2200000) / 1,
        anim_prop: hmUI.prop.Y,
       }

       anim_moon_5_X = {
        anim_rate: 'linear',
        anim_duration: 3600000 / 1,
        anim_from: 80,
        anim_to: 33,
        anim_offset: (600000 + 1400000 + 2200000 + 2900000) / 1,
        anim_prop: hmUI.prop.X,
       }

       anim_moon_5_Y = {
        anim_rate: 'linear',
        anim_duration: 3600000 / 1,
        anim_from: 164,
        anim_to: 271,
        anim_offset: (600000 + 1400000 + 2200000 + 2900000) / 1,
        anim_prop: hmUI.prop.Y,
       }


       moon_1.setProperty(hmUI.prop.ANIM, {
        anim_auto_destroy: 0,
        anim_steps: [anim_moon_1_X, anim_moon_1_Y, anim_moon_2_X, anim_moon_2_Y, anim_moon_3_X, anim_moon_3_Y, anim_moon_4_X, anim_moon_4_Y, anim_moon_5_X, anim_moon_5_Y],
        anim_repeat: -1,
        anim_fps: 25,
        anim_auto_start: 1,
       });


      };


      // ----------------------------


      let app_right_text_font = ''
      let app_right = 0;



      function updateActivity() {

       normal_battery_current_text_font.setProperty(hmUI.prop.TEXT, battery.current + '%');
       // normal_step_current_text_font.text = step.current.toString();
       let distanceCurrent = distance.current;
       let normal_distance_string = (distanceCurrent / 1000).toFixed(2);
       // normal_distance_current_text_font.text = normal_distance_string;

       step_text.setProperty(hmUI.prop.TEXT, 'Шагов: ' + step.current.toString() + '  Путь: ' + normal_distance_string + ' км');
       puls_text.setProperty(hmUI.prop.TEXT, 'Пульс: ' + heart.last.toString() + '    Ккал: ' + calorie.current.toString());



      }




      function updateSleep() {
       //   -----------  сон------------------
       sleepTotalTime = sleep.getTotalTime();
       sleepInfo = sleep.getBasicInfo();
       sleepStartTime = sleepInfo.startTime;
       if (sleepStartTime >= 24 * 60) {
        sleepStartTime -= 24 * 60
       }
       sleepEndTime = sleepInfo.endTime + 1;
       if (sleepEndTime >= 24 * 60) {
        sleepEndTime -= 24 * 60
       }
       //-----------  время пробуждений ------------------
       let wakeTime = 0;
       sleepStageArray = sleep.getSleepStageData();
       for (let i = 0; i < sleepStageArray.length; i++) {
        let data = sleepStageArray[i];
        if (data.model == modelData.WAKE_STAGE) {
         wakeTime += data.stop + 1 - data.start;
        }
       }
       sleepTotalTime -= wakeTime;
       //-------------------------------------------------
       sleep_time_txt.setProperty(hmUI.prop.TEXT, 'СПАЛИ ' + Math.floor(sleepTotalTime / 60).toString().padStart(2, "0") + ':' + (sleepTotalTime % 60).toString().padStart(2, "0"));
       sleep_start_time_txt.setProperty(hmUI.prop.TEXT, Math.floor(sleepStartTime / 60).toString().padStart(2, "0") + ':' + (sleepStartTime % 60).toString().padStart(2, "0"));
       sleep_end_time_txt.setProperty(hmUI.prop.TEXT, Math.floor(sleepEndTime / 60).toString().padStart(2, "0") + ':' + (sleepEndTime % 60).toString().padStart(2, "0"));
       wake_time_txt.setProperty(hmUI.prop.TEXT, 'ПРОСЫПАЛИСЬ ' + String(wakeTime) + ' мин.');
       sleep_score_txt.setProperty(hmUI.prop.TEXT, 'КАЧЕСТВО ' + String(sleepScore) + ' %');
       // -------------------------------------------------
      }

      /*        function getLangIndex() {
      			lang = hmSetting.getLanguage() == 4 ? 0 : 1
              }*/

      //------------- дата и день недели ------------------
      let lastDate = {
       date: 0,
       day: 0,
       month: 0
      }

      let day_num = [0, 31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31];
      let year = timeSensor.year;
      if (year % 4 == 0 && (year % 100 != 0 || year % 400 == 0)) { // Високосный год
       day_num[2] = 29
      } else {
       day_num[2] = 28
      }

      function updateDate() {
       let data_gr = timeSensor.day;

       if (timeSensor.week != lastDate.day) {
        lastDate.day = timeSensor.week;
        let curDayNum = timeSensor.week - 1;
        for (let i = 0; i < daysNum; i++) {
         /*         if (i < daysNum - dney) {
                   normal_forecast_date_week_font[i].setProperty(hmUI.prop.MORE, {
                    text: i == 0 ? normal_forecast_date_week_font_Array[curDayNum] : normal_forecast_date_week_font_Array_smol[curDayNum] + ' ' + data_gr,
                    color: curDayNum < 5 ? "0xFFFFFFFF" : "0xFFFF0000",
                   });
                  }*/
         let week2 = week_array[curDayNum];
         week_text[i].setProperty(hmUI.prop.MORE, {
          color: curDayNum < 5 ? "0xFFFFFFFF" : "0xFFFF0000",
          text: week2,
         });
         data_text[i].setProperty(hmUI.prop.MORE, {
          color: curDayNum < 5 ? "0xFFFFFFFF" : "0xFFFF0000",
          text: data_gr,
         });
         curDayNum = (curDayNum + 1) % 7;
         data_gr = (data_gr + 1)
         if (data_gr > day_num[timeSensor.month]) data_gr = 1
        } //daysNum - fix_day
       } //lastDate
      } //updateDate

      //      function getCurrentDayName() {
      //       return day_names[timeSensor.week - 1][lang];
      //      }

      let lastTime = {
       hour: 0,
       min: 0
      }

      function time_update() {
       let curHour = timeSensor.hour;
       let curMinute = timeSensor.minute;
       //  let second = timeSensor.second;
       //       if (curHour != lastTime.hour) {
       //        lastTime.hour = curHour;
       //        curHour = curHour.toString().padStart(2, '0');
       //        normal_time_hour_min_text_font.setProperty(hmUI.prop.TEXT, curHour + ':' + curMinute);
       //       }

       //       if (curMinute != lastTime.min) {
       //        lastTime.min = curMinute;
       //        curHour = curHour.toString().padStart(2, '0');
       //        curMinute = curMinute.toString().padStart(2, '0');
       //        normal_time_hour_min_text_font.text = curHour + ':' + curMinute;
       //       }


      };

      //------------- обновить все данные ------------------
      function updateAllInfo() {
       //			updateTime();
       time_update();
       //updateBattery();
       updateDate();
       updateActivity();
      }

      function getPressure(val, unit = 0) {
       if (!val) return '--';
       if (!unit) val *= 0.750064;
       return Math.round(val).toString();
      }

      // температура со знаком
      function tempWithSign(val) {
       val = parseFloat(val);
       if (!isFinite(val)) return '--' // если на входе не число - возвращаем прочерки

       //			val = Math.round(val);
       //			if (val > 0) val = '+' + val;
       //			val += '°';
       return val
      }

      function getWindDescription(angle) {
       let index = 0;
       if (angle >= 337.5 && angle < 22.5) index = 0;
       else if (angle >= 22.5 && angle < 67.5) index = 1;
       else if (angle >= 67.5 && angle < 112.5) index = 2;
       else if (angle >= 112.5 && angle < 157.5) index = 3;
       else if (angle >= 157.5 && angle < 202.5) index = 4;
       else if (angle >= 202.5 && angle < 247.5) index = 5;
       else if (angle >= 247.5 && angle < 292.5) index = 6;
       else if (angle >= 292.5 && angle < 337.5) index = 7;

       return windDirectionStr[index][lang];
      }

      // чтение погодных данных из файла
      const mini_app_id = 1065824;
      const file_name_weather = "weather.json";
      const file_name_forecast = "forecast.json";

      function arrayBufferToCyrillic(buffer) {
       let result = '';
       const bytes = new Uint8Array(buffer);

       let i = 0;
       while (i < bytes.length) {
        let byte1 = bytes[i++];

        // Обработка 1-байтовых символов (ASCII)
        if (byte1 < 0x80) {
         result += String.fromCharCode(byte1);
        }
        // Обработка 2-байтовых символов (UTF-8 кодировка для кириллицы)
        else if (byte1 >= 0xC0 && byte1 < 0xE0) {
         let byte2 = bytes[i++];
         let charCode = ((byte1 & 0x1F) << 6) | (byte2 & 0x3F);
         result += String.fromCharCode(charCode);
        }
        // Обработка 3-байтовых символов (например, для UTF-8)
        else if (byte1 >= 0xE0 && byte1 < 0xF0) {
         let byte2 = bytes[i++];
         let byte3 = bytes[i++];
         let charCode = ((byte1 & 0x0F) << 12) | ((byte2 & 0x3F) << 6) | (byte3 & 0x3F);
         result += String.fromCharCode(charCode);
        }
       }

       return result;
      }

      function read_weather_file(file_name) {
       let str_result = "";
       try {

        const [fs_stat, err] = hmFS.stat(file_name, {
         appid: mini_app_id,
        });
        if (err == 0) {
         //console.log("--->size_alt:", fs_stat.size);

         const fh = hmFS.open(file_name, hmFS.O_RDONLY, {
          appid: mini_app_id,
         });

         const len = fs_stat.size;
         let array_buffer = new ArrayBuffer(len);
         hmFS.read(fh, array_buffer, 0, len);
         hmFS.close(fh);
         str_result = arrayBufferToCyrillic(array_buffer);
         //console.log(`array_buffer = ${array_buffer}`);
         //console.log(`str_result = ${str_result}`);
         return str_result;
        } else {
         console.log("err:", err);
        }
       } catch (error) {
        console.log("error:", error);
        console.log("FAIL: No access to hmFS.");
       }
       return "";
      }

      // время последнего изменеия файла
      function getFileModTime(file_name) {
       try {
        const [fs_stat, err] = hmFS.stat(file_name, {
         appid: mini_app_id,
        });

        if (err == 0) {
         //console.log("--->file time: ", fs_stat.mtime);
         //hmUI.showToast({text: file_name + " time: " + fs_stat.mtime});
         return fs_stat.mtime
        } else {
         console.log("err:", err);
        }
       } catch (error) {
        console.log("error:", error);
        console.log("FAIL: No access to hmFS.");
       }
       return null
      }


      // обновление погоды
      function updateWeather(data) {
       console.log(`updateWeather()`);

       //  ic_W_index = 4
       let ic_W_index = weatherData.weatherIcon

       if (ic_W_index == 9 || ic_W_index == 5 || ic_W_index == 12) fallingSpeed = 0.65 //	скорость снегопада общая 
       if (ic_W_index == 10 || ic_W_index == 6) fallingSpeed = 1.65
       if (ic_W_index == 11 || ic_W_index == 7 || ic_W_index == 8) fallingSpeed = 2.65
       //       if (ic_W_index == 9 || ic_W_index == 10 || ic_W_index == 11) {
       //        snowSrc_ = 'snow_'
       //       }
       //       if (ic_W_index == 5 || ic_W_index == 6 || ic_W_index == 7 || ic_W_index == 8) {
       //        snowSrc_ = 'rain_'
       //       }


       //------осадки-----
       normal_osadki_text_font.text = data.chanceOfRain;
       //------давление-----
       let value_pressure = getPressure(weatherData.pressure)
       //  normal_altimeter_current_text_font.setProperty(hmUI.prop.TEXT, value_pressure);
       // normal_unit_right_text_font.setProperty(hmUI.prop.TEXT, 'мрс');
       //       let color_pressure = value_pressure < 760 ? 0xffff00 : value_pressure > 760 ? 0xff0000 : 0x00ff00;
       //       pressure_grafic.setProperty(hmUI.prop.TEXT, value_pressure);
       //       pressure_grafic.setProperty(hmUI.prop.COLOR, color_pressure);

       //------ветер напрвление текстом + значение-----
       //  normal_wind_current_text_font.setProperty(hmUI.prop.TEXT, getWindDescription(weatherData.windDirection) + ' ' + Math.round(data.windSpeed));


       //  normal_unit_left_text_font.setProperty(hmUI.prop.TEXT, 'м/с');
       // WIND_grafic.setProperty(hmUI.prop.TEXT, getWindDescription(weatherData.windDirection) + ' ' + data.windSpeed + ' м/с');
       // WIND_porivi_grafic.setProperty(hmUI.prop.TEXT, '(' + data.windGusts + ')');	

       //------видимость-----
       //vidimost_grafic.setProperty(hmUI.prop.TEXT, data.visibility);
       //vidimost_grafic_unit.setProperty(hmUI.prop.TEXT, data.visibility_unit);		  

       //------облачность-----
       //oblaka_grafic.setProperty(hmUI.prop.TEXT, weatherData.cloudiness);	
       //oblaka_grafic.setProperty(hmUI.prop.TEXT, data.cloudiness);		  

       //------световой день-----
       //svetovoi_den_grafic.setProperty(hmUI.prop.TEXT, weatherData.dayDuration);		  

       //------влажность-----
       //  normal_HUMIDITY_text_font.text = data.humidity;


       //------время обновления-----
       normal_update_time_text_font.setProperty(hmUI.prop.TEXT, data.weatherTime);

       //------время востода заката-----
       normal_zak_text_font.setProperty(hmUI.prop.TEXT, weatherData.sunsetTime);
       normal_vos_text_font.setProperty(hmUI.prop.TEXT, weatherData.sunriseTime);

       WeaterText.text = weatherData.weatherDescription;
       normal_city_name_text.text = weatherData.cityName;


       line_up_grafic.setProperty(hmUI.prop.TEXT, data.humidity + " | " + getWindDescription(weatherData.windDirection) + ' ' + data.windSpeed + '(' + data.windGusts + ')' + " м/с | " + value_pressure);
       line_down_grafic.setProperty(hmUI.prop.TEXT, data.visibility + " " + data.visibility_unit + " | " + weatherData.dayDuration + " | " + weatherData.cloudiness + "%");

       normal_day_text_font_1.text = normal_forecast_date_week_font_Array[timeSensor.week - 1];
       normal_day_text_font_2.text = timeSensor.day + ` ` + normal_Month_Array[timeSensor.month - 1];


       // normal_day_text_font.text = timeSensor.day + `   ` + normal_Month_Array[timeSensor.month - 1] + `   ` + weatherData.temperature + `°(` + weatherData.temperatureFeels + `°) `;

       temperature_now.text = weatherData.temperature + "°(" + weatherData.temperatureFeels + ')';


       normal_temp_text_font.setProperty(hmUI.prop.TEXT, weatherData.temperature + "С°");
       normal_weather_text_font.setProperty(hmUI.prop.TEXT, weatherData.weatherDescription);
       normal_city_name_text_0.setProperty(hmUI.prop.TEXT, weatherData.sunriseTime + "   " + weatherData.cityName + "   " + weatherData.sunsetTime);

       //		  curCityName.setProperty(hmUI.prop.TEXT, data.cityName);
       //		  curTempText.setProperty(hmUI.prop.TEXT, data.temperature);
       //		  curHumText.setProperty(hmUI.prop.TEXT, data.humidity);
       //		  curWindText.setProperty(hmUI.prop.TEXT, data.windSpeed + speedUnit[0][lang]);

       //		  curWindPointer.setProperty(hmUI.prop.ANGLE, data.windDirection);

       //  curWeatherIcon.setProperty(hmUI.prop.SRC, `w_${data.weatherIcon}.png`);
       isDayIcons = true;

       //curWeatherIcon.setProperty(hmUI.prop.SRC, weatherData.temperature > 0 ?  `weather_up/weather_${data.weatherIcon}_0.png` : `weather_down/weather_${data.weatherIcon}_0.png`);		  

      }

      // разница между датами в днях
      function getDaysBetweenDates(d0, d1) {
       let diff = new Date(+d1).setHours(12) - new Date(+d0).setHours(12); // устанавливаем время в каждой дате на 12
       return Math.round(diff / 8.64e7); // msPerDay = 8.64e7;
      }

      //		function checkWeatherPanel() {
      //			if (!weatherPanelVisible) return
      //			
      //			const now = Date.now();
      //			const dTime = 10 * 1000 * 2;
      //			
      //			if (now - lastTimeScreenOn > dTime) deleteWeatherPanel()
      //			else lastTimeScreenOn = now;
      //		}		 


      // обновление прогноза погоды по дням
      function updateForecast(data) {
       console.log(`updateForecast()`);
       let dayOffset = 0; // смещение дней для начала прогноза по дням
       // если прогноз был обновлен во ВТ, а сегодня СР, то dayOffset = 1
       // соотвественно для чтения данных будем использовать объект forecastJson.forecast[i + dayOffset]
       fix_day = dayOffset

       if (isFinite(data.weatherTime)) {
        dayOffset = getDaysBetweenDates(data.weatherTime, Date.now());
       }

       Temp_Now = weatherData.temperature
       Temp_Max = data.forecast[dayOffset].temperatureMax
       Temp_Min = data.forecast[dayOffset].temperatureMin
       Temp_Delta = Temp_Max - Temp_Min
       Temp_Procent = (Temp_Now - Temp_Min) / Temp_Delta * 100


       WEATHER_CURRENT_Activ.setProperty(hmUI.prop.MORE, {
        center_x: 175 + 116,
        center_y: 166,
        start_angle: -135,
        end_angle: 135,
        radius: 39,
        line_width: 10,
        corner_flag: 3,
        color: 0xFFFFFFFF,
        level: Temp_Procent > 100 ? 200 - Temp_Procent : Temp_Procent,
        // type: hmUI.data_type.WEATHER_CURRENT,
        show_level: hmUI.show_level.ONLY_NORMAL,
       });


       WEATHER_HIGH_LOW_Activ.setProperty(hmUI.prop.TEXT, data.forecast[dayOffset].temperatureMin + '/' + data.forecast[dayOffset].temperatureMax);
       temperatura_day_night.setProperty(hmUI.prop.TEXT, data.forecast[dayOffset].temperatureMax + '°/' + data.forecast[dayOffset].temperatureMin + '°');



       for (let i = 0; i < daysNum; i++) {
        const ind = i + dayOffset;


        /*        if (i < daysNum - dney) {
                 normal_forecast_high_low_text_font[i].setProperty(hmUI.prop.TEXT, i + fix_day < daysNum ? data.forecast[ind].temperatureMax + '/' + data.forecast[ind].temperatureMin : '--/--');
                 if (i != 0) dayWeatherIcon[i].setProperty(hmUI.prop.SRC, i + fix_day < daysNum ? `w_${data.forecast[ind].weatherIcon}.png` : `w_15.png`);
                }*/


        weather_ic[i].setProperty(hmUI.prop.SRC, i + fix_day < daysNum ? `images/Grafik/weather/${data.forecast[ind].weatherIcon}.png` : `images/Grafik/weather/15.png`);

        if (i + fix_day < daysNum) {
         yArrH[i] = data.forecast[ind].temperatureMax;
         if (i < daysNum - 1) yArrL[i] = data.forecast[ind].temperatureMin;
        }


       }


       tip()

      }


      let weatherData, forecastData
      let lastModTime = {
       weather: 0,
       forecast: 0,
      }

      function updateWeatherData() {
       if (lastModTime.weather != getFileModTime(file_name_weather)) {
        weatherData = getWeatherData(file_name_weather);
        updateWeather(weatherData);
       }

       if (lastModTime.forecast != getFileModTime(file_name_forecast)) {
        forecastData = getForecastData(file_name_forecast);
        updateForecast(forecastData);
       }

      }


      //	авто переключение иконок погоды на ночные
      const nightIcons = [1, 2]
      let isDayIcons = true;


      function isDayNow() {
       let curMins = timeSensor.hour * 60 + timeSensor.minute;
       let sunriseMins = weatherData.TodaySunriseHour * 60 + weatherData.TodaySunriseMinute;
       let sunsetMins = weatherData.TodaySunsetHour * 60 + weatherData.TodaySunsetMinute;

       let nowIsDay = (curMins >= sunriseMins) && (curMins < sunsetMins);

       return nowIsDay
      }


      function toggleWeatherIcons() {
       // if (nightIcons.includes(weatherData.weatherIcon)) {
       const nowIsDay = isDayNow();

       if (nowIsDay) {
        if (!isDayIcons) {
         isDayIcons = true;
        }
       } else {
        if (isDayIcons) {
         isDayIcons = false;
        }
       }

       let sun_now = isDayIcons == true ? 0 : 1;
       let temp_0 = weatherData.temperature > 0 ? 'weather_up' : 'weather_down';
       let wIcNum = weatherData.weatherIcon;

//              let sun_now = isDayIcons == false ? 0 : 1;
//              let temp_0 = 'weather_up';
//              let wIcNum = 1;


       curWeatherIcon.setProperty(hmUI.prop.SRC, temp_0 + '/weather_' + wIcNum + '_' + sun_now + '.png'),

        normal_vos_text_font.setProperty(hmUI.prop.VISIBLE, isDayIcons == false);
       normal_vos_icon_img.setProperty(hmUI.prop.VISIBLE, isDayIcons == false);
       normal_zak_text_font.setProperty(hmUI.prop.VISIBLE, isDayIcons == true);
       normal_zak_icon_img.setProperty(hmUI.prop.VISIBLE, isDayIcons == true);


       T_N = timeSensor.hour * 60 + timeSensor.minute
       T_V = weatherData.TodaySunriseHour * 60 + weatherData.TodaySunriseMinute
       T_Z = weatherData.TodaySunsetHour * 60 + weatherData.TodaySunsetMinute
       T_24 = T_Z - T_N
       level_SUN_CURRENT_day = (T_N - T_V) / (T_Z - T_V) * 100;
       level_SUN_CURRENT_night = T_24 < 0 ? (T_N - T_Z) / ((24 * 60 - T_Z) + T_V) * 100 : (24 * 60 - T_Z + T_N) / ((24 * 60 - T_Z) + T_V) * 100;

       SUN_CURRENT_Activ.setProperty(hmUI.prop.MORE, {
        center_x: 175 + 116 + 7,
        center_y: 166 + 116,
        start_angle: -135,
        end_angle: 135,
        radius: 39,
        line_width: 10,
        corner_flag: 3,
        color: isDayIcons ? 0xffef42 : 0x42ffeb,
        level: isDayIcons ? level_SUN_CURRENT_day : level_SUN_CURRENT_night,
        show_level: hmUI.show_level.ONLY_NORMAL,
       });



      }

      //------------------------------------------------------


      function getWeatherData(fileName) {
       console.log(`getWeatherData()`);

       let weather_str = read_weather_file(fileName);
       console.log(`weather_json = ${weather_str}`);
       let weatherJson = JSON.parse(weather_str);

       lastModTime.weather = getFileModTime(fileName);

       let data = {
        weatherIcon: 0,
        weatherDescription: lang == 0 ? 'Нет данных' : 'No data', // описание погоды
        temperature: '--',
        temperatureFeels: '--', // ощущается
        temperatureMax: '--',
        temperatureMin: '--',
        humidity: '--',
        pressure: '--',
        windSpeed: '--',
        windDirection: 0,
        windGusts: null,
        chanceOfRain: '--',
        cloudiness: '--',
        visibility: '--',
        visibility_unit: '--',
        cityName: '--',
        sunriseTime: '--', // восход
        sunsetTime: '--', // закат
        dayDuration: '--', // световой день
        weatherTime: '--:--', //время обновления
        TodaySunriseHour: '--',
        TodaySunriseMinute: '--',
        TodaySunsetHour: '--',
        TodaySunsetMinute: '--',
       }


       if (weatherJson != undefined && weatherJson != null) {
        if (weatherJson.city != undefined && weatherJson.city != null && weatherJson.city.length) {
         data.cityName = weatherJson.city;
         data.cityName = data.cityName.replace(data.cityName[0], data.cityName[0].toUpperCase());
        }

        if (weatherJson.weatherDescriptionExtended != undefined && weatherJson.weatherDescriptionExtended != null && weatherJson.weatherDescriptionExtended.length) {
         data.weatherDescription = weatherJson.weatherDescriptionExtended;
         data.weatherDescription = data.weatherDescription.replace(data.weatherDescription[0], data.weatherDescription[0].toUpperCase());
        }

        if (isFinite(weatherJson.weatherIcon)) {
         data.weatherIcon = parseInt(weatherJson.weatherIcon);
        }

        if (isFinite(weatherJson.temperature)) {
         data.temperature = tempWithSign(weatherJson.temperature);
         data.temperature = Math.round(data.temperature);
         if (isFinite(weatherJson.temperatureFeels)) {
          data.temperatureFeels = tempWithSign(weatherJson.temperatureFeels);
          data.temperatureFeels = Math.round(data.temperatureFeels);
         }

         if (isFinite(weatherJson.temperatureMax)) {
          data.temperatureMax = tempWithSign(weatherJson.temperatureMax);
          data.temperatureMax = Math.round(data.temperatureMax);
         }

         if (isFinite(weatherJson.temperatureMin)) {
          data.temperatureMin = tempWithSign(weatherJson.temperatureMin);
          data.temperatureMin = Math.round(data.temperatureMin);
         }
        }

        if (isFinite(weatherJson.humidity)) {
         data.humidity = weatherJson.humidity + '%';
        }

        if (isFinite(weatherJson.chanceOfRain)) {
         data.chanceOfRain = weatherJson.chanceOfRain + '%';
         normal_osadki_img.setProperty(hmUI.prop.SRC, weatherJson.chanceOfRain > 50 ? 'ic_osadki_on.png' : 'ic_osadki_off.png');

        }

        if (isFinite(weatherJson.windSpeed)) {
         data.windSpeed = parseFloat(weatherJson.windSpeed);
         data.windSpeed > 10 ? data.windSpeed = Math.round(data.windSpeed) : data.windSpeed = data.windSpeed.toFixed(1);
        }

        if (isFinite(weatherJson.windGusts)) {
         data.windGusts = parseFloat(weatherJson.windGusts);
         data.windGusts > 10 ? data.windGusts = Math.round(data.windGusts) : data.windGusts = data.windGusts.toFixed(1);
        }

        if (isFinite(weatherJson.windDirection)) {
         data.windDirection = parseFloat(weatherJson.windDirection);
        }

        if (isFinite(weatherJson.pressure)) {
         data.pressure = parseInt(weatherJson.pressure);
        }

        if (isFinite(weatherJson.visibility)) {
         data.visibility = String(parseInt(weatherJson.visibility));
         let unitIndex = 'М';
         if (data.visibility > 1000) {
          data.visibility = String(parseInt(data.visibility / 1000));
          unitIndex = 'КМ';
         }
         data.visibility_unit = unitIndex;
        }

        if (isFinite(weatherJson.cloudiness)) {
         // data.cloudiness = parseInt(weatherJson.cloudiness);
         data.cloudiness = String(weatherJson.cloudiness);
        }


        if (isFinite(weatherJson.sunriseTime)) {
         const time = new Date(weatherJson.sunriseTime);
         let hour = time.getHours().toString().padStart(2, "0");
         let min = time.getMinutes().toString().padStart(2, "0");
         data.TodaySunriseHour = time.getHours();
         data.TodaySunriseMinute = time.getMinutes();
         data.sunriseTime = hour + ':' + min;
        }

        if (isFinite(weatherJson.sunsetTime)) {
         const time = new Date(weatherJson.sunsetTime);
         let hour = time.getHours().toString().padStart(2, "0");
         let min = time.getMinutes().toString().padStart(2, "0");
         data.TodaySunsetHour = time.getHours();
         data.TodaySunsetMinute = time.getMinutes();
         data.sunsetTime = hour + ':' + min;
        }

        if (isFinite(weatherJson.sunriseTime) && isFinite(weatherJson.sunsetTime)) {
         const diff = weatherJson.sunsetTime - weatherJson.sunriseTime;
         let hour = parseInt(diff / (1000 * 60 * 60)).toString().padStart(2, "0");
         let min = parseInt((diff % (1000 * 60 * 60)) / (1000 * 60)).toString().padStart(2, "0");
         data.dayDuration = hour + ':' + min;
        }

        if (isFinite(weatherJson.weatherTime)) {
         const weatherTime = new Date(weatherJson.weatherTime);
         let hour = weatherTime.getHours().toString().padStart(2, "0");
         let min = weatherTime.getMinutes().toString().padStart(2, "0");
         data.weatherTime = hour + ':' + min;
        }
       }


       return data
      }


      function getForecastData(fileName) {
       console.log(`getForecastData()`);

       let weather_str = read_weather_file(fileName);
       console.log(`forecastJson = ${weather_str}`);
       let forecastJson = JSON.parse(weather_str);

       lastModTime.forecast = getFileModTime(fileName);

       let data = {
        cityName: null,
        weatherTime: null,
        forecast: []
       }

       if (forecastJson != undefined && forecastJson != null) {
        if (forecastJson.cityName != undefined && forecastJson.cityName != null && forecastJson.cityName.length) {
         data.cityName = forecastJson.cityName;
         data.cityName = data.cityName.replace(data.cityName[0], data.cityName[0].toUpperCase());
        }

        if (isFinite(forecastJson.weatherTime)) {
         data.weatherTime = parseInt(forecastJson.weatherTime);
        }

        for (let i = 0; i < daysNum + 2; i++) {
         // for (let i = 0; i < daysNum; i++) {
         let dayForecast = {
          weatherIcon: 0,
          temperatureMax: '--',
          temperatureMin: '--',
          humidity: '--',
          pressure: '--',
          windSpeed: '--',
          windDirection: 0,
         }

         if (forecastJson != undefined && forecastJson != null) {
          if (isFinite(forecastJson.forecast[i].weatherIcon)) {
           dayForecast.weatherIcon = parseInt(forecastJson.forecast[i].weatherIcon);
          }

          if (isFinite(forecastJson.forecast[i].temperatureMax)) {
           dayForecast.temperatureMax = tempWithSign(forecastJson.forecast[i].temperatureMax);
          }

          if (isFinite(forecastJson.forecast[i].temperatureMin)) {
           dayForecast.temperatureMin = tempWithSign(forecastJson.forecast[i].temperatureMin);
          }

          if (isFinite(forecastJson.forecast[i].humidity)) {
           dayForecast.humidity = parseInt(forecastJson.forecast[i].humidity);
          }

          if (isFinite(forecastJson.forecast[i].pressure)) {
           dayForecast.pressure = parseInt(forecastJson.forecast[i].pressure);
          }

          if (isFinite(forecastJson.forecast[i].windSpeed)) {
           dayForecast.windSpeed = Math.round(parseFloat(forecastJson.forecast[i].windSpeed));
          }

          if (isFinite(forecastJson.forecast[i].windDirection)) {
           dayForecast.windDirection = parseFloat(forecastJson.forecast[i].windDirection);
          }
         }

         data.forecast.push(dayForecast);

        }

       }
       return data
      }


      //-----------------------------------------------------


      let weatherPanel = null,
       shadowScreen = null
      let weatherPanelVisible = false
      let lastTimeScreenOn = null


      let sleep_time_txt = ''
      let sleep_start_time_txt = ''
      let sleep_end_time_txt = ''
      let sleep_score_txt = ''
      let wake_time_txt

      const sleep = hmSensor.createSensor(hmSensor.id.SLEEP);
      let sleepInfo = sleep.getBasicInfo();

      let sleepTotalTime = sleep.getTotalTime();
      let sleepStartTime = sleepInfo.startTime;
      let sleepEndTime = sleepInfo.endTime + 1;
      let sleepScore = sleepInfo.score;

      //-----------  время пробуждений ------------------		
      let sleepStageArray = sleep.getSleepStageData();
      const modelData = sleep.getSleepStageModel();
      //-------------------------------------------------		

      //sleep_time_txt.setProperty(hmUI.prop.TEXT, 'Время сна: ' + Math.floor(sleepTotalTime / 60).toString().padStart(2, "0") + ':' + (sleepTotalTime % 60).toString().padStart(2, "0"));


      function click_sleep() {
       groupVremya.setProperty(hmUI.prop.VISIBLE, false);
       groupSleep.setProperty(hmUI.prop.VISIBLE, true);
      }


      function click_exit_sleep() {
       groupVremya.setProperty(hmUI.prop.VISIBLE, true);
       groupSleep.setProperty(hmUI.prop.VISIBLE, false);
      }


      let pressure_grafic; // отображаем давление
      let WIND_pressure_changes; // отображаем изменение давления 


      function makeAOD() {
       // color = hmFS.SysProGetInt('NUMNUM_color');
       const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
        resume_call: (function () {
         stopVibro();
        }),
        pause_call: (function () {
         hmApp.unregisterSpinEvent();
         stopVibro();
        }),
       });


      }


      let Activ_color_alpha = ''
      let color_bg_Activ = [0xff0000, 0xff0000, 0xFCB61C, 0x068FF9, 0xFFB900, 0xffffff, 0xf8e36c, 0xb84cf6, 0xa3fd1f, 0xfd912f, 0x8cffff, 0xff00a2, 0x8a8a8a];

      let menu = 0
      let color_ic = 0
      let Activ_color = 0

      function click_Activ_color() {
       Activ_color = (Activ_color + 1) % 2
       ic_activ_color_off_img.setProperty(hmUI.prop.VISIBLE, Activ_color == 0);
       hmFS.SysProSetInt('wt_098967_Activ_color', Activ_color);
      }


      let Btn_set_ = []
      let Shag_Y = 66


      let menu_ARC_color = [
       [],
       [],
       [],
       [],
       [],
       [],
       [],
       [],
       /*  [],
                [],
                [],
                [],
                [],
                [],
                [],
                [],
                [],
                [],
                [],
*/
       []
      ]


      let Ar_Set = [
       ['ЯРКОСТЬ ПОГОДЫ', 5, `tap/i_tap_pusto.png`, 1, 'page/index'],
       // ['ЦВЕТ НЕДЕЛЯ', 8, `tap/i_tap_pusto.png`, 0, 'page/index'],
       //       ['ЦВЕТ МИНУТЫ', 8, `tap/i_tap_pusto.png`, 0, 'page/index'],
       //       ['ЦВЕТ ДАТА', 2, `tap/i_tap_pusto.png`, 0, 'page/index'],
       //       ['ЦВЕТ АКТИВНОСТЬ', 4, `tap/i_tap_pusto.png`, 0, 'page/index'],
       ['КОРОНКА ОТКЛЮЧЕНА', 0, `tap/i_tap_pusto.png`, 1, 'page/index'],
      ];

      let color_bg = [
       [0xff1a4e, 0xff501e, 0xf6d945, 0xffb100, 0xa5ff1f, 0x00c37a, 0x00d3f0, 0x3f7af2, 0xffffff, 0xadadad, 0xadadad],
       //  [0xff1a4e, 0xff501e, 0xf6d945, 0xffb100, 0xa5ff1f, 0x00c37a, 0x00d3f0, 0x3f7af2, 0xffffff, 0xadadad],
       //       [0xff1a4e, 0xff501e, 0xf6d945, 0xffb100, 0xa5ff1f, 0x00c37a, 0x00d3f0, 0x3f7af2, 0xffffff, 0xadadad],
       //       [0xff1a4e, 0xff501e, 0xf6d945, 0xffb100, 0xa5ff1f, 0x00c37a, 0x00d3f0, 0x3f7af2, 0xffffff, 0xadadad],
       //       [0xff1a4e, 0xff501e, 0xf6d945, 0xffb100, 0xa5ff1f, 0x00c37a, 0x00d3f0, 0x3f7af2, 0xffffff, 0xadadad],
       [0xff0000],
      ];


      let crownSensitivity = 70; // уровень чувствительности колесика
      let color = 0;
      let color_str = 0;
      let bridg = 127;
      let crown = 0


      function click_crown(index) {
       for (let i = 0; i < Ar_Set.length; i++) {
        if (index == i) crown = i
       };

       for (let i = 0; i < Ar_Set.length; i++) {
        Btn_set_[i].setProperty(hmUI.prop.MORE, {
         x: Ar_Set.length <= 5 ? 153 : i < Math.ceil(Ar_Set.length / 2) ? 70 : 233,
         y: Ar_Set.length <= 5 ? 70 + i * Shag_Y : i < Math.ceil(Ar_Set.length / 2) ? 70 + i * Shag_Y : 70 + i * Shag_Y - Shag_Y * Math.ceil(Ar_Set.length / 2),
         w: 160,
         h: 60,
         text: Ar_Set[i][0],
         char_space: 0,
         line_space: -35,
         color: 0xFFFFFFFF,
         text_size: 24,
         radius: 12,
         press_color: 0xFFFF0000,
         normal_color: i != crown ? 0x000000 : 0x800000,
         text_style: hmUI.text_style.WRAP,
         show_level: hmUI.show_level.ONLY_NORMAL,
        }); // end button                        

       };


       for (let j = 0; j < Ar_Set.length; j++) {
        for (let i = 0; i < color_bg[j].length; i++) {
         menu_ARC_color[j][i].setProperty(hmUI.prop.VISIBLE, false);
        };
       };
       for (let i = 0; i < color_bg[crown].length; i++) {
        menu_ARC_color[crown][i].setProperty(hmUI.prop.VISIBLE, Ar_Set[crown][3] == 0);
        menu_ARC_PROGRES.setProperty(hmUI.prop.MORE, {
         center_x: 233,
         center_y: 233,
         start_angle: 45 + 90 / color_bg[crown].length * Ar_Set[crown][1], // start_angle: 45 + 90 / array * gde,
         end_angle: 135 + 90 / color_bg[crown].length * Ar_Set[crown][1], //end_angle: 135 + 90 / array * gde,
         radius: 219,
         line_width: 16,
         corner_flag: 0,
         color: 0xFF0000, //0xFF007eff
         level: 100 / color_bg[crown].length, //level: pointer,
         show_level: hmUI.show_level.ONLY_NORMAL,
        });
        menu_ARC_PROGRES.setProperty(hmUI.prop.VISIBLE, true);
       };

       for (let i = 0; i < color_bg[crown].length; i++) {
        menu_ARC_color[0].setProperty(hmUI.prop.MORE, {
         center_x: 233,
         center_y: 233,
         start_angle: 45 + 90 / color_bg[crown].length * i,
         end_angle: 135 + 90 / color_bg[crown].length * i,
         radius: 219 - 16,
         line_width: 16,
         corner_flag: 0,
         color: color_bg[crown][i],
         level: 100 / color_bg[crown].length,
         show_level: hmUI.show_level.ONLY_NORMAL,
        });
       };
      }

      function click_Set_on() {
       set = 1
       groupVremya.setProperty(hmUI.prop.VISIBLE, false);
       g_Set.setProperty(hmUI.prop.VISIBLE, true);
       //все
       g_ACR_color.setProperty(hmUI.prop.VISIBLE, true);

       for (let j = 0; j < Ar_Set.length; j++) {
        for (let i = 0; i < color_bg[j].length; i++) {
         menu_ARC_color[j][i].setProperty(hmUI.prop.VISIBLE, false);
        };
       };

       for (let i = 0; i < color_bg[crown].length; i++) {
        //где цвет 
        menu_ARC_color[crown][i].setProperty(hmUI.prop.VISIBLE, Ar_Set[crown][3] == 0);
       };

      }

      function click_Set_off() {
       set = 0
       g_Set.setProperty(hmUI.prop.VISIBLE, false);
       groupVremya.setProperty(hmUI.prop.VISIBLE, true);
       g_ACR_color.setProperty(hmUI.prop.VISIBLE, false);
       for (let j = 0; j < Ar_Set.length; j++) {
        for (let i = 0; i < color_bg[j].length; i++) {
         menu_ARC_color[j][i].setProperty(hmUI.prop.VISIBLE, false);
        };
       };
       hmFS.SysProSetInt('wt_098967_crown', crown);
      }


      function crown_color(crown) {
       let step = degreeSum < 0 ? -1 : 1;
       Ar_Set[crown][1] += step;
       Ar_Set[crown][1] = Ar_Set[crown][1] < 0 ? color_bg[crown].length + Ar_Set[crown][1] : Ar_Set[crown][1] % color_bg[crown].length;
       degreeSum = 0;
       hmFS.SysProSetInt('wt_098967_color_' + crown, Ar_Set[crown][1]);
       if (set == 0) {
        g_ACR_color.setProperty(hmUI.prop.VISIBLE, true);
        if (Ar_Set[crown][3] == 0) {
         for (let i = 0; i < color_bg[crown].length; i++) {
          menu_ARC_color[crown][i].setProperty(hmUI.prop.VISIBLE, Ar_Set[crown][3] == 0);
         };
        }
        if (MenuCirkl_Timer) {
         timer.stopTimer(MenuCirkl_Timer)
        }
        MenuCirkl_Timer = timer.createTimer(1000, 1, (function (option) {
         if (Ar_Set[crown][3] == 0) {
          for (let i = 0; i < color_bg[crown].length; i++) {
           menu_ARC_color[crown][i].setProperty(hmUI.prop.VISIBLE, false);
          };
         }
         g_ACR_color.setProperty(hmUI.prop.VISIBLE, false);
         timer.stopTimer(MenuCirkl_Timer)
        })); // end timer
       } else {
        g_Set.setProperty(hmUI.prop.VISIBLE, false);
        if (MenuCirkl_Timer) {
         timer.stopTimer(MenuCirkl_Timer)
        }
        MenuCirkl_Timer = timer.createTimer(1000, 1, (function (option) {
         g_Set.setProperty(hmUI.prop.VISIBLE, true);
         timer.stopTimer(MenuCirkl_Timer)
        })); // end timer
       }
       menu_ARC_PROGRES.setProperty(hmUI.prop.MORE, {
        center_x: 233,
        center_y: 233,
        start_angle: 45 + 90 / color_bg[crown].length * Ar_Set[crown][1], // start_angle: 45 + 90 / array * gde,
        end_angle: 135 + 90 / color_bg[crown].length * Ar_Set[crown][1], //end_angle: 135 + 90 / array * gde,
        radius: 219,
        line_width: 16,
        corner_flag: 0,
        color: 0xFF0000, //0xFF007eff
        level: 100 / color_bg[crown].length, //level: pointer,
        show_level: hmUI.show_level.ONLY_NORMAL,
       });
      }

      let bridg_bg = [
       ['100%', 0],
       ['90%', 26],
       ['80%', 51],
       ['70%', 77],
       ['60%', 102],
       ['50%', 128],
       ['40%', 153],
       ['30%', 179],
       ['20%', 204],
       ['10%', 230],
       ['0%', 255],
      ];

      let set = 0;
      let degreeSum = 0;
      let MenuCirkl_Timer = null;


      function onDigitalCrown() {
       hmApp.registerSpinEvent(function (key, degree) {
        if (key === hmApp.key.HOME) {
         degreeSum += degree;
         if (Math.abs(degreeSum) > crownSensitivity) {


          if (Activ_color == 1 && menu == 1) {
           let step = degreeSum < 0 ? -1 : 1;
           color_ic += step;
           color_ic = color_ic < 0 ? color_bg_Activ.length + color_ic : color_ic % color_bg_Activ.length;
           degreeSum = 0;
           hmFS.SysProSetInt('wt_098967_color_ic', color_ic);

           Activ_color_alpha.setProperty(hmUI.prop.MORE, {
            center_x: 233,
            center_y: 233,
            radius: 233,
            color: color_bg_Activ[color_ic],
            alpha: color_ic == 0 ? 0 : 255,
            show_level: hmUI.show_level.ONLY_NORMAL,
           })
           vibro();
          }

          if (Activ_color == 0 && menu == 0 && crown == 0) {
           crown_color(crown)

           hmUI.showToast({
            text: bridg_bg[Ar_Set[crown][1]][0]
           });

           bridg_alpha.setProperty(hmUI.prop.MORE, {
            center_x: 233,
            center_y: 233,
            radius: 233,
            color: 0x000000,
            alpha: bridg_bg[Ar_Set[crown][1]][1],
            show_level: hmUI.show_level.ONLY_NORMAL,
           });

           // normal_background_bg.setProperty(hmUI.prop.COLOR, color_bg[crown][Ar_Set[crown][1]]);

           vibro();
          }


         }
        }
       }) // crown
      }


      const vibrate = hmSensor.createSensor(hmSensor.id.VIBRATE)
      let stopVibro_Timer = null;

      function vibro(scene = 25) {
       let stopDelay = 50;
       vibrate.stop();
       vibrate.scene = scene;
       if (scene < 23 || scene > 25) stopDelay = 1220;
       vibrate.start();
       stopVibro_Timer = timer.createTimer(stopDelay, 0, stopVibro, {});
      }

      function stopVibro() {
       vibrate.stop();
       timer.stopTimer(stopVibro_Timer);
      }

      function click_Pogoda_on() {
       normal_background_Pogoda.setProperty(hmUI.prop.VISIBLE, true);
       menu = 2
       groupVremya.setProperty(hmUI.prop.VISIBLE, false);
       groupPogoda.setProperty(hmUI.prop.VISIBLE, true);
      }

      function click_Pogoda_off() {
       normal_background_Pogoda.setProperty(hmUI.prop.VISIBLE, false);
       menu = 0
       groupVremya.setProperty(hmUI.prop.VISIBLE, true);
       groupPogoda.setProperty(hmUI.prop.VISIBLE, false);
      }

      function click_Activ_on() {
       menu = 1
       groupVremya.setProperty(hmUI.prop.VISIBLE, false);
       groupActiv.setProperty(hmUI.prop.VISIBLE, true);
      }

      function click_Activ_off() {
       menu = 0
       Activ_color = 0
       ic_activ_color_off_img.setProperty(hmUI.prop.VISIBLE, Activ_color == 0);
       groupVremya.setProperty(hmUI.prop.VISIBLE, true);
       groupActiv.setProperty(hmUI.prop.VISIBLE, false);
      }


      let apps = [
       ['Нет действия', '-', `tap/i_tap_pusto.png`, 0, 'page/index'],
       ['Таймер', 'CountdownAppScreen', `tap/i_tap_obrat_otchet.png`, 0, 'page/index'],
       ['Секундомер', 'StopWatchScreen', `tap/i_tap_secundomer.png`, 0, 'page/index'],
       ['Мировые часы', 'WorldClockScreen', `tap/i_tap_mirivie_chasi.png`, 0, 'page/index'],
       ['Восход/закат', 'TideScreen', `tap/i_tap_voshod_zakat.png`, 0, 'page/index'],
       ['Сон', 'Sleep_HomeScreen', `tap/i_tap_son.png`, 0, 'page/index'],
       ['Стресс', 'StressHomeScreen', `tap/i_tap_stress.png`, 0, 'page/index'],
       ['SP02 (Кислород)', 'spo_HomeScreen', `tap/i_tap_kislorod.png`, 0, 'page/index'],
       ['Дыхание', 'RespirationsettingScreen', `tap/i_tap_dihanie.png`, 0, 'page/index'],
       ['Измерение одним касанием', 'oneKeyAppScreen', `tap/i_tap_1_kosanie.png`, 0, 'page/index'],
       ['Женский календарь', 'menstrualAppScreen', `tap/i_tap_gensk_calendar.png`, 0, 'page/index'],
       ['Найти телефон', 'FindPhoneScreen', `tap/i_tap_naiti_telo.png`, 0, 'page/index'],
       ['Музыка', 'LocalMusicScreen', `tap/i_tap_musik.png`, 0, 'page/index'], //'PhoneMusicCtrlScreen'
       ['Компас', 'CompassScreen', `tap/i_tap_kompas.png`, 0, 'page/index'],
       ['Набрать номер', 'DialCallScreen', `tap/i_tap_nabor.png`, 0, 'page/index'],
       ['Телефон', 'PhoneHomeScreen', `tap/i_tap_telefon.png`, 0, 'page/index'],
       ['Диктофон', 'VoiceMemoScreen', `tap/i_tap_dictofon.png`, 0, 'page/index'],
       ['Расписание', 'ScheduleListScreen', `tap/i_tap_raspisanie.png`, 0, 'page/index'],
       ['Список дел', 'todoListScreen', `tap/i_tap_spisok_del.png`, 0, 'page/index'],
       ['Календарь', 'ScheduleCalScreen', `tap/i_tap_calendar.png`, 0, 'page/index'],
       ['Погода', 'WeatherScreen', `tap/i_tap_pogoda.png`, 0, 'page/index'],
       ['Настройка', 'Settings_homeScreen', `tap/i_tap_sitting.png`, 0, 'page/index'],
       ['Камера', 'HidcameraScreen', `tap/i_tap_camera.png`, 0, 'page/index'],
       ['Пульс', 'heart_app_Screen', `tap/i_tap_puls.png`, 0, 'page/index'],
       ['Будильник', 'AlarmInfoScreen', `tap/i_tap_budilnik.png`, 0, 'page/index'],
       ['PAI', 'PAI_app_Screen', `tap/i_tap_pai.png`, 0, 'page/index'],
       ['Тренировка', 'SportListScreen', `tap/i_tap_trenerovka.png`, 0, 'page/index'],
       ['AOD', 'Settings_standbyModelScreen', `tap/i_tap_aod.png`, 0, 'page/index'],
       ['Экономия заряда', 'LowBatteryScreen', `tap/i_tap_LowBattery.png`, 0, 'page/index'],
       ['Давление/Высота', 'BaroAltimeterScreen', `tap/i_tap_barometr.png`, 0, 'page/index'],
       ['Погода LeXxiR', '1051195', `tap/i_tap_LeXxiR.png`, 1, 'page/index'],
       ['Календарь Sasha', '1057409', `tap/i_tap_calen_Sasha.png`, 1, 'page/index'],
       ['Flow', '1038314', `tap/i_tap_flow.png`, 1, 'page/gtr/home/index.page'],
       ['Ночной режим', 'Settings_nsModeHomeScreen', `tap/i_tap_night_Mode_Screen.png`, 0, 'page/index'],
       ['Говорящие часы', '1066653', `tap/i_tap_talking_watch.png`, 1, 'page/index.page'],
       ['Перезагрузка', 'HmReStartScreen', `tap/i_tap_restart.png`, 0, 'page/index'],
      ];


      const tap_1_edit = hmUI.createWidget(hmUI.widget.WATCHFACE_EDIT_GROUP, {
       edit_id: 101,
       x: 171,
       y: 20,
       w: 124,
       h: 124,
       select_image: 'tap/edit_red_1.png',
       un_select_image: 'tap/edit_griin_1.png',
       default_type: 19,
       optional_types: [{
        type: 0,
        preview: apps[0][2],
        title_en: apps[0][0]
       }, {
        type: 1,
        preview: apps[1][2],
        title_en: apps[1][0]
       }, {
        type: 2,
        preview: apps[2][2],
        title_en: apps[2][0]
       }, {
        type: 3,
        preview: apps[3][2],
        title_en: apps[3][0]
       }, {
        type: 4,
        preview: apps[4][2],
        title_en: apps[4][0]
       }, {
        type: 5,
        preview: apps[5][2],
        title_en: apps[5][0]
       }, {
        type: 6,
        preview: apps[6][2],
        title_en: apps[6][0]
       }, {
        type: 7,
        preview: apps[7][2],
        title_en: apps[7][0]
       }, {
        type: 8,
        preview: apps[8][2],
        title_en: apps[8][0]
       }, {
        type: 9,
        preview: apps[9][2],
        title_en: apps[9][0]
       }, {
        type: 10,
        preview: apps[10][2],
        title_en: apps[10][0]
       }, {
        type: 11,
        preview: apps[11][2],
        title_en: apps[11][0]
       }, {
        type: 12,
        preview: apps[12][2],
        title_en: apps[12][0]
       }, {
        type: 13,
        preview: apps[13][2],
        title_en: apps[13][0]
       }, {
        type: 14,
        preview: apps[14][2],
        title_en: apps[14][0]
       }, {
        type: 15,
        preview: apps[15][2],
        title_en: apps[15][0]
       }, {
        type: 16,
        preview: apps[16][2],
        title_en: apps[16][0]
       }, {
        type: 17,
        preview: apps[17][2],
        title_en: apps[17][0]
       }, {
        type: 18,
        preview: apps[18][2],
        title_en: apps[18][0]
       }, {
        type: 19,
        preview: apps[19][2],
        title_en: apps[19][0]
       }, {
        type: 20,
        preview: apps[20][2],
        title_en: apps[20][0]
       }, {
        type: 21,
        preview: apps[21][2],
        title_en: apps[21][0]
       }, {
        type: 22,
        preview: apps[22][2],
        title_en: apps[22][0]
       }, {
        type: 23,
        preview: apps[23][2],
        title_en: apps[23][0]
       }, {
        type: 24,
        preview: apps[24][2],
        title_en: apps[24][0]
       }, {
        type: 25,
        preview: apps[25][2],
        title_en: apps[25][0]
       }, {
        type: 26,
        preview: apps[26][2],
        title_en: apps[26][0]
       }, {
        type: 27,
        preview: apps[27][2],
        title_en: apps[27][0]
       }, {
        type: 28,
        preview: apps[28][2],
        title_en: apps[28][0]
       }, {
        type: 29,
        preview: apps[29][2],
        title_en: apps[29][0]
       }, {
        type: 30,
        preview: apps[30][2],
        title_en: apps[30][0]
       }, {
        type: 31,
        preview: apps[31][2],
        title_en: apps[31][0]
       }, {
        type: 32,
        preview: apps[32][2],
        title_en: apps[32][0]
       }, {
        type: 33,
        preview: apps[33][2],
        title_en: apps[33][0]
       }, {
        type: 34,
        preview: apps[34][2],
        title_en: apps[34][0]
       }, {
        type: 35,
        preview: apps[35][2],
        title_en: apps[35][0]
       }, ],

       count: 36,
       tips_x: 135 - 171,
       tips_y: 150 - 20,
       tips_width: 195,
       tips_margin: 10,
       tips_BG: 'tap/tips_bg.png'
      })

      let tap_1_select = tap_1_edit.getProperty(hmUI.prop.CURRENT_TYPE)

      const tap_2_edit = hmUI.createWidget(hmUI.widget.WATCHFACE_EDIT_GROUP, {
       edit_id: 102,
       x: 301,
       y: 95,
       w: 124,
       h: 124,
       select_image: 'tap/edit_red_1.png',
       un_select_image: 'tap/edit_griin_1.png',
       default_type: 20,
       optional_types: [{
        type: 0,
        preview: apps[0][2],
        title_en: apps[0][0]
       }, {
        type: 1,
        preview: apps[1][2],
        title_en: apps[1][0]
       }, {
        type: 2,
        preview: apps[2][2],
        title_en: apps[2][0]
       }, {
        type: 3,
        preview: apps[3][2],
        title_en: apps[3][0]
       }, {
        type: 4,
        preview: apps[4][2],
        title_en: apps[4][0]
       }, {
        type: 5,
        preview: apps[5][2],
        title_en: apps[5][0]
       }, {
        type: 6,
        preview: apps[6][2],
        title_en: apps[6][0]
       }, {
        type: 7,
        preview: apps[7][2],
        title_en: apps[7][0]
       }, {
        type: 8,
        preview: apps[8][2],
        title_en: apps[8][0]
       }, {
        type: 9,
        preview: apps[9][2],
        title_en: apps[9][0]
       }, {
        type: 10,
        preview: apps[10][2],
        title_en: apps[10][0]
       }, {
        type: 11,
        preview: apps[11][2],
        title_en: apps[11][0]
       }, {
        type: 12,
        preview: apps[12][2],
        title_en: apps[12][0]
       }, {
        type: 13,
        preview: apps[13][2],
        title_en: apps[13][0]
       }, {
        type: 14,
        preview: apps[14][2],
        title_en: apps[14][0]
       }, {
        type: 15,
        preview: apps[15][2],
        title_en: apps[15][0]
       }, {
        type: 16,
        preview: apps[16][2],
        title_en: apps[16][0]
       }, {
        type: 17,
        preview: apps[17][2],
        title_en: apps[17][0]
       }, {
        type: 18,
        preview: apps[18][2],
        title_en: apps[18][0]
       }, {
        type: 19,
        preview: apps[19][2],
        title_en: apps[19][0]
       }, {
        type: 20,
        preview: apps[20][2],
        title_en: apps[20][0]
       }, {
        type: 21,
        preview: apps[21][2],
        title_en: apps[21][0]
       }, {
        type: 22,
        preview: apps[22][2],
        title_en: apps[22][0]
       }, {
        type: 23,
        preview: apps[23][2],
        title_en: apps[23][0]
       }, {
        type: 24,
        preview: apps[24][2],
        title_en: apps[24][0]
       }, {
        type: 25,
        preview: apps[25][2],
        title_en: apps[25][0]
       }, {
        type: 26,
        preview: apps[26][2],
        title_en: apps[26][0]
       }, {
        type: 27,
        preview: apps[27][2],
        title_en: apps[27][0]
       }, {
        type: 28,
        preview: apps[28][2],
        title_en: apps[28][0]
       }, {
        type: 29,
        preview: apps[29][2],
        title_en: apps[29][0]
       }, {
        type: 30,
        preview: apps[30][2],
        title_en: apps[30][0]
       }, {
        type: 31,
        preview: apps[31][2],
        title_en: apps[31][0]
       }, {
        type: 32,
        preview: apps[32][2],
        title_en: apps[32][0]
       }, {
        type: 33,
        preview: apps[33][2],
        title_en: apps[33][0]
       }, {
        type: 34,
        preview: apps[34][2],
        title_en: apps[34][0]
       }, {
        type: 35,
        preview: apps[35][2],
        title_en: apps[35][0]
       }, ],

       count: 36,

       tips_x: 266 - 301,
       tips_y: 225 - 95,
       tips_width: 195,
       tips_margin: 10,
       tips_BG: 'tap/tips_bg.png'
      })

      let tap_2_select = tap_2_edit.getProperty(hmUI.prop.CURRENT_TYPE)

      const tap_3_edit = hmUI.createWidget(hmUI.widget.WATCHFACE_EDIT_GROUP, {
       edit_id: 103,
       x: 301,
       y: 246,
       w: 124,
       h: 124,
       select_image: 'tap/edit_red_1.png',
       un_select_image: 'tap/edit_griin_1.png',
       default_type: 24,
       optional_types: [{
        type: 0,
        preview: apps[0][2],
        title_en: apps[0][0]
       }, {
        type: 1,
        preview: apps[1][2],
        title_en: apps[1][0]
       }, {
        type: 2,
        preview: apps[2][2],
        title_en: apps[2][0]
       }, {
        type: 3,
        preview: apps[3][2],
        title_en: apps[3][0]
       }, {
        type: 4,
        preview: apps[4][2],
        title_en: apps[4][0]
       }, {
        type: 5,
        preview: apps[5][2],
        title_en: apps[5][0]
       }, {
        type: 6,
        preview: apps[6][2],
        title_en: apps[6][0]
       }, {
        type: 7,
        preview: apps[7][2],
        title_en: apps[7][0]
       }, {
        type: 8,
        preview: apps[8][2],
        title_en: apps[8][0]
       }, {
        type: 9,
        preview: apps[9][2],
        title_en: apps[9][0]
       }, {
        type: 10,
        preview: apps[10][2],
        title_en: apps[10][0]
       }, {
        type: 11,
        preview: apps[11][2],
        title_en: apps[11][0]
       }, {
        type: 12,
        preview: apps[12][2],
        title_en: apps[12][0]
       }, {
        type: 13,
        preview: apps[13][2],
        title_en: apps[13][0]
       }, {
        type: 14,
        preview: apps[14][2],
        title_en: apps[14][0]
       }, {
        type: 15,
        preview: apps[15][2],
        title_en: apps[15][0]
       }, {
        type: 16,
        preview: apps[16][2],
        title_en: apps[16][0]
       }, {
        type: 17,
        preview: apps[17][2],
        title_en: apps[17][0]
       }, {
        type: 18,
        preview: apps[18][2],
        title_en: apps[18][0]
       }, {
        type: 19,
        preview: apps[19][2],
        title_en: apps[19][0]
       }, {
        type: 20,
        preview: apps[20][2],
        title_en: apps[20][0]
       }, {
        type: 21,
        preview: apps[21][2],
        title_en: apps[21][0]
       }, {
        type: 22,
        preview: apps[22][2],
        title_en: apps[22][0]
       }, {
        type: 23,
        preview: apps[23][2],
        title_en: apps[23][0]
       }, {
        type: 24,
        preview: apps[24][2],
        title_en: apps[24][0]
       }, {
        type: 25,
        preview: apps[25][2],
        title_en: apps[25][0]
       }, {
        type: 26,
        preview: apps[26][2],
        title_en: apps[26][0]
       }, {
        type: 27,
        preview: apps[27][2],
        title_en: apps[27][0]
       }, {
        type: 28,
        preview: apps[28][2],
        title_en: apps[28][0]
       }, {
        type: 29,
        preview: apps[29][2],
        title_en: apps[29][0]
       }, {
        type: 30,
        preview: apps[30][2],
        title_en: apps[30][0]
       }, {
        type: 31,
        preview: apps[31][2],
        title_en: apps[31][0]
       }, {
        type: 32,
        preview: apps[32][2],
        title_en: apps[32][0]
       }, {
        type: 33,
        preview: apps[33][2],
        title_en: apps[33][0]
       }, {
        type: 34,
        preview: apps[34][2],
        title_en: apps[34][0]
       }, {
        type: 35,
        preview: apps[35][2],
        title_en: apps[35][0]
       }, ],

       count: 36,
       tips_x: 266 - 301,
       tips_y: 184 - 246,
       tips_width: 195,
       tips_margin: 10,
       tips_BG: 'tap/tips_bg.png'
      })

      let tap_3_select = tap_3_edit.getProperty(hmUI.prop.CURRENT_TYPE)

      const tap_4_edit = hmUI.createWidget(hmUI.widget.WATCHFACE_EDIT_GROUP, {
       edit_id: 104,
       x: 171,
       y: 321,
       w: 124,
       h: 124,
       select_image: 'tap/edit_red_1.png',
       un_select_image: 'tap/edit_griin_1.png',
       default_type: 11,
       optional_types: [{
        type: 0,
        preview: apps[0][2],
        title_en: apps[0][0]
       }, {
        type: 1,
        preview: apps[1][2],
        title_en: apps[1][0]
       }, {
        type: 2,
        preview: apps[2][2],
        title_en: apps[2][0]
       }, {
        type: 3,
        preview: apps[3][2],
        title_en: apps[3][0]
       }, {
        type: 4,
        preview: apps[4][2],
        title_en: apps[4][0]
       }, {
        type: 5,
        preview: apps[5][2],
        title_en: apps[5][0]
       }, {
        type: 6,
        preview: apps[6][2],
        title_en: apps[6][0]
       }, {
        type: 7,
        preview: apps[7][2],
        title_en: apps[7][0]
       }, {
        type: 8,
        preview: apps[8][2],
        title_en: apps[8][0]
       }, {
        type: 9,
        preview: apps[9][2],
        title_en: apps[9][0]
       }, {
        type: 10,
        preview: apps[10][2],
        title_en: apps[10][0]
       }, {
        type: 11,
        preview: apps[11][2],
        title_en: apps[11][0]
       }, {
        type: 12,
        preview: apps[12][2],
        title_en: apps[12][0]
       }, {
        type: 13,
        preview: apps[13][2],
        title_en: apps[13][0]
       }, {
        type: 14,
        preview: apps[14][2],
        title_en: apps[14][0]
       }, {
        type: 15,
        preview: apps[15][2],
        title_en: apps[15][0]
       }, {
        type: 16,
        preview: apps[16][2],
        title_en: apps[16][0]
       }, {
        type: 17,
        preview: apps[17][2],
        title_en: apps[17][0]
       }, {
        type: 18,
        preview: apps[18][2],
        title_en: apps[18][0]
       }, {
        type: 19,
        preview: apps[19][2],
        title_en: apps[19][0]
       }, {
        type: 20,
        preview: apps[20][2],
        title_en: apps[20][0]
       }, {
        type: 21,
        preview: apps[21][2],
        title_en: apps[21][0]
       }, {
        type: 22,
        preview: apps[22][2],
        title_en: apps[22][0]
       }, {
        type: 23,
        preview: apps[23][2],
        title_en: apps[23][0]
       }, {
        type: 24,
        preview: apps[24][2],
        title_en: apps[24][0]
       }, {
        type: 25,
        preview: apps[25][2],
        title_en: apps[25][0]
       }, {
        type: 26,
        preview: apps[26][2],
        title_en: apps[26][0]
       }, {
        type: 27,
        preview: apps[27][2],
        title_en: apps[27][0]
       }, {
        type: 28,
        preview: apps[28][2],
        title_en: apps[28][0]
       }, {
        type: 29,
        preview: apps[29][2],
        title_en: apps[29][0]
       }, {
        type: 30,
        preview: apps[30][2],
        title_en: apps[30][0]
       }, {
        type: 31,
        preview: apps[31][2],
        title_en: apps[31][0]
       }, {
        type: 32,
        preview: apps[32][2],
        title_en: apps[32][0]
       }, {
        type: 33,
        preview: apps[33][2],
        title_en: apps[33][0]
       }, {
        type: 34,
        preview: apps[34][2],
        title_en: apps[34][0]
       }, {
        type: 35,
        preview: apps[35][2],
        title_en: apps[35][0]
       }, ],

       count: 36,
       tips_x: 135 - 171,
       tips_y: 257 - 321,
       tips_width: 195,
       tips_margin: 10,
       tips_BG: 'tap/tips_bg.png'
      })

      let tap_4_select = tap_4_edit.getProperty(hmUI.prop.CURRENT_TYPE)

      const tap_5_edit = hmUI.createWidget(hmUI.widget.WATCHFACE_EDIT_GROUP, {
       edit_id: 105,
       x: 40,
       y: 246,
       w: 124,
       h: 124,
       select_image: 'tap/edit_red_1.png',
       un_select_image: 'tap/edit_griin_1.png',
       default_type: 0,
       optional_types: [{
        type: 0,
        preview: apps[0][2],
        title_en: apps[0][0]
       }, {
        type: 1,
        preview: apps[1][2],
        title_en: apps[1][0]
       }, {
        type: 2,
        preview: apps[2][2],
        title_en: apps[2][0]
       }, {
        type: 3,
        preview: apps[3][2],
        title_en: apps[3][0]
       }, {
        type: 4,
        preview: apps[4][2],
        title_en: apps[4][0]
       }, {
        type: 5,
        preview: apps[5][2],
        title_en: apps[5][0]
       }, {
        type: 6,
        preview: apps[6][2],
        title_en: apps[6][0]
       }, {
        type: 7,
        preview: apps[7][2],
        title_en: apps[7][0]
       }, {
        type: 8,
        preview: apps[8][2],
        title_en: apps[8][0]
       }, {
        type: 9,
        preview: apps[9][2],
        title_en: apps[9][0]
       }, {
        type: 10,
        preview: apps[10][2],
        title_en: apps[10][0]
       }, {
        type: 11,
        preview: apps[11][2],
        title_en: apps[11][0]
       }, {
        type: 12,
        preview: apps[12][2],
        title_en: apps[12][0]
       }, {
        type: 13,
        preview: apps[13][2],
        title_en: apps[13][0]
       }, {
        type: 14,
        preview: apps[14][2],
        title_en: apps[14][0]
       }, {
        type: 15,
        preview: apps[15][2],
        title_en: apps[15][0]
       }, {
        type: 16,
        preview: apps[16][2],
        title_en: apps[16][0]
       }, {
        type: 17,
        preview: apps[17][2],
        title_en: apps[17][0]
       }, {
        type: 18,
        preview: apps[18][2],
        title_en: apps[18][0]
       }, {
        type: 19,
        preview: apps[19][2],
        title_en: apps[19][0]
       }, {
        type: 20,
        preview: apps[20][2],
        title_en: apps[20][0]
       }, {
        type: 21,
        preview: apps[21][2],
        title_en: apps[21][0]
       }, {
        type: 22,
        preview: apps[22][2],
        title_en: apps[22][0]
       }, {
        type: 23,
        preview: apps[23][2],
        title_en: apps[23][0]
       }, {
        type: 24,
        preview: apps[24][2],
        title_en: apps[24][0]
       }, {
        type: 25,
        preview: apps[25][2],
        title_en: apps[25][0]
       }, {
        type: 26,
        preview: apps[26][2],
        title_en: apps[26][0]
       }, {
        type: 27,
        preview: apps[27][2],
        title_en: apps[27][0]
       }, {
        type: 28,
        preview: apps[28][2],
        title_en: apps[28][0]
       }, {
        type: 29,
        preview: apps[29][2],
        title_en: apps[29][0]
       }, {
        type: 30,
        preview: apps[30][2],
        title_en: apps[30][0]
       }, {
        type: 31,
        preview: apps[31][2],
        title_en: apps[31][0]
       }, {
        type: 32,
        preview: apps[32][2],
        title_en: apps[32][0]
       }, {
        type: 33,
        preview: apps[33][2],
        title_en: apps[33][0]
       }, {
        type: 34,
        preview: apps[34][2],
        title_en: apps[34][0]
       }, {
        type: 35,
        preview: apps[35][2],
        title_en: apps[35][0]
       }, ],

       count: 36,
       tips_x: 5 - 40,
       tips_y: 184 - 246,
       tips_width: 195,
       tips_margin: 10,
       tips_BG: 'tap/tips_bg.png'
      })

      let tap_5_select = tap_5_edit.getProperty(hmUI.prop.CURRENT_TYPE)

      const tap_6_edit = hmUI.createWidget(hmUI.widget.WATCHFACE_EDIT_GROUP, {
       edit_id: 106,
       x: 40,
       y: 95,
       w: 124,
       h: 124,
       select_image: 'tap/edit_red_1.png',
       un_select_image: 'tap/edit_griin_1.png',
       default_type: 35,
       optional_types: [{
        type: 0,
        preview: apps[0][2],
        title_en: apps[0][0]
       }, {
        type: 1,
        preview: apps[1][2],
        title_en: apps[1][0]
       }, {
        type: 2,
        preview: apps[2][2],
        title_en: apps[2][0]
       }, {
        type: 3,
        preview: apps[3][2],
        title_en: apps[3][0]
       }, {
        type: 4,
        preview: apps[4][2],
        title_en: apps[4][0]
       }, {
        type: 5,
        preview: apps[5][2],
        title_en: apps[5][0]
       }, {
        type: 6,
        preview: apps[6][2],
        title_en: apps[6][0]
       }, {
        type: 7,
        preview: apps[7][2],
        title_en: apps[7][0]
       }, {
        type: 8,
        preview: apps[8][2],
        title_en: apps[8][0]
       }, {
        type: 9,
        preview: apps[9][2],
        title_en: apps[9][0]
       }, {
        type: 10,
        preview: apps[10][2],
        title_en: apps[10][0]
       }, {
        type: 11,
        preview: apps[11][2],
        title_en: apps[11][0]
       }, {
        type: 12,
        preview: apps[12][2],
        title_en: apps[12][0]
       }, {
        type: 13,
        preview: apps[13][2],
        title_en: apps[13][0]
       }, {
        type: 14,
        preview: apps[14][2],
        title_en: apps[14][0]
       }, {
        type: 15,
        preview: apps[15][2],
        title_en: apps[15][0]
       }, {
        type: 16,
        preview: apps[16][2],
        title_en: apps[16][0]
       }, {
        type: 17,
        preview: apps[17][2],
        title_en: apps[17][0]
       }, {
        type: 18,
        preview: apps[18][2],
        title_en: apps[18][0]
       }, {
        type: 19,
        preview: apps[19][2],
        title_en: apps[19][0]
       }, {
        type: 20,
        preview: apps[20][2],
        title_en: apps[20][0]
       }, {
        type: 21,
        preview: apps[21][2],
        title_en: apps[21][0]
       }, {
        type: 22,
        preview: apps[22][2],
        title_en: apps[22][0]
       }, {
        type: 23,
        preview: apps[23][2],
        title_en: apps[23][0]
       }, {
        type: 24,
        preview: apps[24][2],
        title_en: apps[24][0]
       }, {
        type: 25,
        preview: apps[25][2],
        title_en: apps[25][0]
       }, {
        type: 26,
        preview: apps[26][2],
        title_en: apps[26][0]
       }, {
        type: 27,
        preview: apps[27][2],
        title_en: apps[27][0]
       }, {
        type: 28,
        preview: apps[28][2],
        title_en: apps[28][0]
       }, {
        type: 29,
        preview: apps[29][2],
        title_en: apps[29][0]
       }, {
        type: 30,
        preview: apps[30][2],
        title_en: apps[30][0]
       }, {
        type: 31,
        preview: apps[31][2],
        title_en: apps[31][0]
       }, {
        type: 32,
        preview: apps[32][2],
        title_en: apps[32][0]
       }, {
        type: 33,
        preview: apps[33][2],
        title_en: apps[33][0]
       }, {
        type: 34,
        preview: apps[34][2],
        title_en: apps[34][0]
       }, {
        type: 35,
        preview: apps[35][2],
        title_en: apps[35][0]
       }, ],

       count: 36,
       tips_x: 5 - 40,
       tips_y: 225 - 95,

       tips_width: 195,
       tips_margin: 10,
       tips_BG: 'tap/tips_bg.png'
      })

      let tap_6_select = tap_6_edit.getProperty(hmUI.prop.CURRENT_TYPE)

      let btn_tap = ''
      let btn_click_tap_exit = ''

      let btn_Tap_zona_0 = ''
      let btn_Tap_zona_1 = ''
      let btn_Tap_zona_2 = ''
      let btn_Tap_zona_3 = ''
      let btn_Tap_zona_4 = ''
      let btn_Tap_zona_5 = ''

      function tap_zona_exit() {
       groupVremya.setProperty(hmUI.prop.VISIBLE, true);
       groupTap.setProperty(hmUI.prop.VISIBLE, false);
      }

      let tap_x_y = [
       [178, 26, 1],
       [308, 102, 1],
       [308, 253, 1],
       [178, 328, 0],
       [47, 253, 0],
       [47, 102, 0]
      ];

      function tap_run() {
       groupVremya.setProperty(hmUI.prop.VISIBLE, false);
       groupTap.setProperty(hmUI.prop.VISIBLE, true);
      }


      let tip_grafik = 0

      function click_tip_grafik() {
       tip_grafik = (tip_grafik + 1) % 2
       hmFS.SysProSetInt('wt_098967_tip_grafik', tip_grafik);
       ic_graf_img.setProperty(hmUI.prop.SRC, "images/Grafik/ic_graf_" + tip_grafik + ".png");
       click_Pogoda_off();
       normal_background_Pogoda.setProperty(hmUI.prop.VISIBLE, true);
       setTimeout(() => {
        click_Pogoda_on()
        tip()
       }, 150);
      }

      // let timeSensor = ''

      let normal_city_name_text_0 = ''


      //-------------------------------- 

      //массив иконок для графика       
      for (var i = 0; i <= 28; i++) {
       weather_ic_array.push(ROOTPATH + "Grafik/weather/" + i + ".png"); //0-28
      }


      //-------------------------------- 

      //обновление для   графика           
      function updateGrafik() {


       tip()

      }

      function tip() {

       canvas.clear({
        x: 0,
        y: 0,
        w: 466,
        h: 466
       })


       for (let i = 0; i < daysNum - 1; i++) {
        canvas.drawRect({
         x1: 94 + shag * [i],
         y1: 93,
         x2: 94 + shag * [i] + 1,
         y2: 351,
         color: 0xc0c0c0
        })
       }


       let maxH = Math.max(...yArrH)
       let maxL = Math.min(...yArrL)
       let delta = 120 / (maxL - maxH)

       let RedArray = [];
       let BlueArray = [];

       if (tip_grafik == 0) {
        for (let i = 0; i < daysNum - fix_day; i++) {
         arr_x[i] = x0 + shag * [i];
         arr_y[i] = yArrH[i] * delta + 162 - maxH * delta;
        }
        splain(daysNum - fix_day)

        for (let i = 0; i < daysNum - fix_day - 1; i++) {
         arr_x[i] = x0 + 23 + shag * [i];
         arr_y[i] = yArrL[i] * delta + 162 - maxH * delta;
        }
        splain(daysNum - fix_day - 1)
       }
       if (tip_grafik == 1) {
        let k = 0
        for (let i = 0; i < daysNum - fix_day; i++) {

         yArrAll[k] = yArrH[i]
         k = k + 1
         yArrAll[k] = yArrL[i]
         k = k + 1
        }


        for (let i = 0; i < yArrAll.length; i++) {
         arr_x[i] = x0 + shag / 2 * [i];
         arr_y[i] = yArrAll[i] * delta + 162 - maxH * delta;
        }
        splain(yArrAll.length - 1)
       }


       for (let i = 0; i < daysNum - fix_day; i++) {
        if (tip_grafik == 0) {
         canvas.drawCircle({
          center_x: x0 + shag * [i],
          center_y: yArrH[i] * delta + 162 - maxH * delta,
          radius: 5,
          color: 0xFF0000
         })
        }
        y_pogodaH[i] = (yArrH[i] * delta + 145 - maxH * delta) - 5;
        DigDay[i].setProperty(hmUI.prop.more, {
         x: x0 - 23 - 5 + i * 45 * 1.02,
         y: y_pogodaH[i] - 18, //120-7//120-7/- 38
         w: 50,
         h: 40,
         color: "0xFFffffff",
         text_size: 27,
         text: yArrH[i],
         text_style: hmUI.text_style.NONE,
         align_h: hmUI.align.CENTER_H,
         align_v: hmUI.align.CENTER_V,
         show_level: hmUI.show_level.ONLY_NORMAL
        });

        if (i < daysNum - fix_day - 1) {
         if (tip_grafik == 0) {
          canvas.drawCircle({
           center_x: x0 + 23 + shag * [i],
           center_y: yArrL[i] * delta + 162 - maxH * delta,
           radius: 5,
           color: 0x00eaff
          })
         }
         y_pogodaL[i] = (yArrL[i] * delta + 145 - maxH * delta) - 5;;
         DigNight[i].setProperty(hmUI.prop.more, {
          x: x0 - 23 - 5 + 23 + i * 45 * 1.02,
          y: y_pogodaL[i] + 19, //120-7 / - 1  
          w: 50,
          h: 40,
          color: "0xFFffffff",
          text_size: 27,
          text: yArrL[i],
          text_style: hmUI.text_style.NONE,
          align_h: hmUI.align.CENTER_H,
          align_v: hmUI.align.CENTER_V,
          show_level: hmUI.show_level.ONLY_NORMAL
         });
        } //daysNum - fix_day - 1
       }; //daysNum - fix_day   
      }


      function splain(n) {
       let arr_a = new Array(n).fill().map(() => new Array(1));
       let arr_b = new Array(n - 1).fill().map(() => new Array(1));
       let arr_c = new Array(n).fill().map(() => new Array(1));
       let arr_d = new Array(n - 1).fill().map(() => new Array(1));

       let arr_h = new Array(n - 1).fill().map(() => new Array(1));
       let arr_alpha = new Array(n).fill().map(() => new Array(1));
       let arr_l = new Array(n).fill().map(() => new Array(1));
       let arr_mu = new Array(n).fill().map(() => new Array(1));
       let arr_z = new Array(n).fill().map(() => new Array(1));

       for (var i = 0; i < n - 1; i++) {
        arr_h[i] = arr_x[i + 1] - arr_x[i];
       }

       for (var i = 1; i < n - 1; i++) {
        arr_alpha[i] = 3 * ((arr_y[i + 1] - arr_y[i]) / arr_h[i] - (arr_y[i] - arr_y[i - 1]) / arr_h[i - 1]);
       }

       arr_l[0] = 1;
       arr_mu[0] = 0;
       arr_z[0] = 0;

       for (var i = 1; i < n - 1; i++) {
        arr_l[i] = 2 * (arr_x[i + 1] - arr_x[i - 1]) - arr_h[i - 1] * arr_mu[i - 1];
        arr_mu[i] = arr_h[i] / arr_l[i];
        arr_z[i] = (arr_alpha[i] - arr_h[i - 1] * arr_z[i - 1]) / arr_l[i];
       }

       arr_l[n - 1] = 1;
       arr_z[n - 1] = 0;
       arr_c[n - 1] = 0;

       for (var j = n - 2; j >= 0; j--) {
        arr_c[j] = arr_z[j] - arr_mu[j] * arr_c[j + 1];
        arr_b[j] = (arr_y[j + 1] - arr_y[j]) / arr_h[j] - arr_h[j] * (arr_c[j + 1] + 2 * arr_c[j]) / 3;
        arr_d[j] = (arr_c[j + 1] - arr_c[j]) / (3 * arr_h[j]);
        arr_a[j] = arr_y[j];
       }

       for (var i = 0; i < n - 1; i++) {
        for (xi = arr_x[i]; xi < arr_x[i + 1] - 1; xi += 5) {
         yi = arr_a[i] + arr_b[i] * (xi - arr_x[i]) + arr_c[i] * Math.pow((xi - arr_x[i]), 2) + arr_d[i] * Math.pow((xi - arr_x[i]), 3);

         if (tip_grafik == 0) {
          canvas.drawImage({
           x: xi,
           y: yi,
           w: 5,
           h: 310 - yi,
           alpha: 127,
           image: n == daysNum - fix_day ? 'images/Grafik/line_day.png' : 'images/Grafik/line_night.png'
          })
         }

         canvas.drawLine({
          x1: xi,
          y1: yi,
          x2: xi + 5,
          y2: arr_a[i] + arr_b[i] * (xi + 5 - arr_x[i]) + arr_c[i] * Math.pow((xi + 5 - arr_x[i]), 2) + arr_d[i] * Math.pow((xi + 5 - arr_x[i]), 3),
          // color: n == dney ? 0xff0000 : 0x00eaff//0x009cff  yArrAll.length - 1
          color: n == daysNum - fix_day ? 0xff0000 : n == daysNum - fix_day - 1 ? 0x00eaff : 0x12a2fd //0x009cff
         })


        }
       }

      }
      // end user_functions.js


      // класс текст с обводкой
      class TextWithOutline {
       constructor(props) {
        this._x = props.x || 0;
        this._y = props.y || 0;
        this._widget = [];
        this._color = (props.color == null) ? 0xffffff : props.color;
        this._color_outline = (props.color_outline == null) ? 0x000000 : props.color_outline;
        this._offset = props.offset || 2;
        this._group = props.group || hmUI;

        for (let i = 0; i < 5; i++) {
         this._widget[i] = this._group.createWidget(hmUI.widget.TEXT, {
          x: this._x,
          y: this._y,
          w: props.w || 100,
          h: props.h || 40,
          text_size: props.text_size || 30,
          char_space: props.char_space || 0,
          line_space: props.line_space || 0,
          text: props.text,
          color: i > 3 ? this._color : this._color_outline,
          align_h: props.align_h || hmUI.align.CENTER_H,
          align_v: props.align_v || hmUI.align.CENTER_V,
          text_style: props.text_style || hmUI.text_style.NONE,
         });

         if (props.font) {
          this._widget[i].setProperty(hmUI.prop.MORE, {
           font: props.font
          });
         }
        }

        this._widget[0].setProperty(hmUI.prop.MORE, {
         x: this._x - this._offset,
         y: this._y + this._offset
        });
        this._widget[1].setProperty(hmUI.prop.MORE, {
         x: this._x + this._offset,
         y: this._y - this._offset
        });
        this._widget[2].setProperty(hmUI.prop.MORE, {
         x: this._x - this._offset,
         y: this._y - this._offset
        });
        this._widget[3].setProperty(hmUI.prop.MORE, {
         x: this._x + this._offset,
         y: this._y + this._offset
        });
       }

       hide() {
        this._widget.forEach(item => {
         item.setProperty(hmUI.prop.VISIBLE, false);
        });
       }

       show() {
        this._widget.forEach(item => {
         item.setProperty(hmUI.prop.VISIBLE, true);
        });
       }

       set visible(v) {
        if (v) this.show()
        else this.hide();
       }

       set x(v) {
        this._x = v;
        this._widget[4].setProperty(hmUI.prop.MORE, {
         x: this._x
        });
        this._widget[0].setProperty(hmUI.prop.MORE, {
         x: this._x - this._offset
        });
        this._widget[1].setProperty(hmUI.prop.MORE, {
         x: this._x + this._offset
        });
        this._widget[2].setProperty(hmUI.prop.MORE, {
         x: this._x - this._offset
        });
        this._widget[3].setProperty(hmUI.prop.MORE, {
         x: this._x + this._offset
        });
       }

       set y(v) {
        this._y = v;
        this._widget[4].setProperty(hmUI.prop.MORE, {
         y: this._y
        });
        this._widget[0].setProperty(hmUI.prop.MORE, {
         y: this._y + this._offset
        });
        this._widget[1].setProperty(hmUI.prop.MORE, {
         y: this._y - this._offset
        });
        this._widget[2].setProperty(hmUI.prop.MORE, {
         y: this._y - this._offset
        });
        this._widget[3].setProperty(hmUI.prop.MORE, {
         y: this._y + this._offset
        });
       }

       set text(txt) {
        this._widget.forEach(item => {
         item.setProperty(hmUI.prop.TEXT, txt);
        });
       }

       set color(v) {
        this._color = v;
        this._widget[4].setProperty(hmUI.prop.MORE, {
         color: this._color
        });
       }

       set color_outline(v) {
        this._color_outline = v;
        for (let i = 0; i < 4; i++) {
         this._widget[i].setProperty(hmUI.prop.MORE, {
          color: this._color_outline
         });
        }
       }
      }

      // ----------------------------

      //******************* дождь 2.0 *******************

      // настройки ---->
      const rainTypesNum = 9; // количество типов снежинок
      const rainSrc_ = 'rain_'; // префикс картинок со снежинками

      let fallingSpeed = 0.65; // 0.65 скорость снегопада общая
      const rainMaxSize = 20; // максимальный размер снежинок
      const rainMinSize = 16; // минимальный размер снежинок
      // <---- настройки

      let rainfall

      // функция случайное целое
      function randomInt(...args) {
       let min = 0;
       let max = args[0];
       if (args.length > 1) {
        min = args[0];
        max = args[1];
       }
       let rand = min + Math.random() * (max + 1 - min);
       return Math.floor(rand);
      }

      // класс капля
      class rainFlake {
       constructor() {
        this._size_rain = randomInt(rainMinSize, rainMaxSize);
        //this._size = rainMaxSize;

        this._dir_rain = 1;

        this._id_rain = hmUI.createWidget(hmUI.widget.IMG, {
         x: this._x_rain + 83,
         y: this._y_rain + 190,
         w: this._size_rain,
         h: this._size_rain,
         src: `${rainSrc_}${randomInt(rainTypesNum)}.png`,
         alpha: randomInt(140, 255),
         //angle: this._angle,
         center_x: this._size_rain / 2,
         center_y: this._size_rain / 2,
         auto_scale: true,
         auto_scale_obj_fit: true,
        });

        this.init();
       }

       init(ff_rain) {
        this._x_rain = randomInt(296 - this._size_rain);
        // this._y_rain = -this._size_rain;
        this._y_rain = ff_rain != 0 ? randomInt(190, 296 - this._size_rain) : -this._size_rain;
        this._waveX_rain = 0;
        // this._dX = Math.random() * 25;
        this._shiftX_rain = 0.03 + Math.random() / randomInt(5, 7);
        this._speed_rain = fallingSpeed * this._size_rain / randomInt(3, 7);
        // this._angle = 90 * randomInt(3);
        this._id_rain.setProperty(hmUI.prop.MORE, {
         x: this._x_rain + 83,
         y: this._y_rain
        });
       }


       move_rain() {
        this._waveX_rain += this._shiftX_rain;
        this._y_rain += this._speed_rain;
        // let newX_rain = parseInt(this._x_rain+83 + this._dX * Math.sin(this._waveX_rain));
        let newX_rain = parseInt(this._x_rain + 83 + Math.sin(this._waveX_rain));
        //let newX_rain = this._x_rain+81;
        if (!randomInt(30)) this._dir_rain = -this._dir_rain;
        // this._angle = (this._angle + this._dir_rain * randomInt(18)) % 360;

        this._id_rain.setProperty(hmUI.prop.MORE, {
         x: newX_rain,
         y: this._y_rain,
         // angle: this._angle,
         center_x: this._size_rain / 2,
         center_y: this._size_rain / 2,
        });


        if (this._y_rain > 296 - 2 * this._size_rain || newX_rain > 372) {
         this.init();
         this._id_rain.setProperty(hmUI.prop.MORE, {
          w: this._size_rain,
          h: this._size_rain,
          src: `${rainSrc_}${randomInt(rainTypesNum)}.png`,
          alpha: randomInt(140, 255),
          // angle: this._angle,
          center_x: this._size_rain / 2,
          center_y: this._size_rain / 2,
          auto_scale: true,
          auto_scale_obj_fit: true,
         });
        }
       }

      }


      // класс дождь
      class Rainfall {
       constructor(num_rain) {
        this._flakesNum_rain = num_rain
        this._moveTimer_rain = null
        this.rainFlake = []
        for (let i = 0; i < this._flakesNum_rain; i++) {
         this.rainFlake[i] = new rainFlake();
        }
       }

       start() {
        if (!this._moveTimer_rain) {
         this._moveTimer_rain = setInterval(() => {
          for (let i = 0; i < this._flakesNum_rain; i++) {
           this.rainFlake[i].move_rain();
          }
         }, 80);
        }
       }

       stop() {
        if (this._moveTimer_rain) clearInterval(this._moveTimer_rain);
        this._moveTimer_rain = null;
       }

       hide(ff_rain) {
        this.stop();
        for (let i = 0; i < this._flakesNum_rain; i++) {
         this.rainFlake[i].init(ff_rain);
        }
       }

      }


      //******************* дождь *******************		 


      //******************* снегопад 2.0 *******************

      // настройки ---->
      const snowTypesNum = 9; // количество типов снежинок
      const snowSrc_ = 'snow_'; // префикс картинок со снежинками

      //let fallingSpeed = 0.65; // 0.65 скорость снегопада общая
      const snowMaxSize = 20; // максимальный размер снежинок
      const snowMinSize = 5; // минимальный размер снежинок
      // <---- настройки

      let snowfall


      // класс снежинка
      class SnowFlake {
       constructor() {
        this._size = randomInt(snowMinSize, snowMaxSize);
        //this._size = snowMaxSize;

        this._dir = 1;

        this._id = hmUI.createWidget(hmUI.widget.IMG, {
         x: this._x + 83,
         y: this._y + 190,
         w: this._size,
         h: this._size,
         src: `${snowSrc_}${randomInt(snowTypesNum)}.png`,
         alpha: randomInt(140, 255),
         angle: this._angle,
         center_x: this._size / 2,
         center_y: this._size / 2,
         auto_scale: true,
         auto_scale_obj_fit: true,
        });

        this.init();
       }

       init(ff) {
        this._x = randomInt(296 - this._size);
        // this._y = -this._size;
        this._y = ff != 0 ? randomInt(190, 296 - this._size) : -this._size;
        this._waveX = 0;
        this._dX = Math.random() * 25;
        this._shiftX = 0.03 + Math.random() / randomInt(5, 7);
        this._speed = fallingSpeed * this._size / randomInt(3, 7);
        this._angle = 90 * randomInt(3);
        this._id.setProperty(hmUI.prop.MORE, {
         x: this._x + 83,
         y: this._y
        });
       }


       move() {
        this._waveX += this._shiftX;
        this._y += this._speed;
        let newX = parseInt(this._x + 83 + this._dX * Math.sin(this._waveX));
        //let newX = this._x+81;
        if (!randomInt(30)) this._dir = -this._dir;
        this._angle = (this._angle + this._dir * randomInt(18)) % 360;

        this._id.setProperty(hmUI.prop.MORE, {
         x: newX,
         y: this._y,
         angle: this._angle,
         center_x: this._size / 2,
         center_y: this._size / 2,
        });

        //if ((this._y > 190 - 2 * this._size && this._y < 296 - 2 * this._size) || (newX > 83 - 3 * this._dX && newX < 372 - 3 * this._dX)) {

        //if (this._y > DEVICE_HEIGHT - 2 * this._size || newX > DEVICE_WIDTH - 3 * this._dX) {	


        if (this._y > 296 - 2 * this._size || newX > 372 - 3 * this._dX) {
         // if (this._y < 296 - 2 * this._size ||  newX < 372 - 3 * this._dX) {
         this.init();
         this._id.setProperty(hmUI.prop.MORE, {
          w: this._size,
          h: this._size,
          src: `${snowSrc_}${randomInt(snowTypesNum)}.png`,
          alpha: randomInt(140, 255),
          angle: this._angle,
          center_x: this._size / 2,
          center_y: this._size / 2,
          auto_scale: true,
          auto_scale_obj_fit: true,
         });
        }
       }

      }


      // класс снегопад
      class Snowfall {
       constructor(num) {
        this._flakesNum = num
        this._moveTimer = null
        this.snowFlake = []
        for (let i = 0; i < this._flakesNum; i++) {
         this.snowFlake[i] = new SnowFlake();
        }
       }

       start() {
        if (!this._moveTimer) {
         this._moveTimer = setInterval(() => {
          for (let i = 0; i < this._flakesNum; i++) {
           this.snowFlake[i].move();
          }
         }, 80);
        }
       }

       stop() {
        if (this._moveTimer) clearInterval(this._moveTimer);
        this._moveTimer = null;
       }

       hide(ff) {
        this.stop();
        for (let i = 0; i < this._flakesNum; i++) {
         this.snowFlake[i].init(ff);
        }
       }

      }


      //******************* снегопад *******************


      function anim_motion_1_complete_call() {
       normal_motion_animation_img_1.setProperty(hmUI.prop.ANIM, normal_motion_animation_paramX_1);
       normal_motion_animation_lastTime_1 = timeSensor.utc;
       normal_motion_animation_count_1 = normal_motion_animation_count_1 - 1;
       if (normal_motion_animation_count_1 < -1) normal_motion_animation_count_1 = -1;
       if (normal_motion_animation_count_1 == 0) stop_anim_motion_1();
      }; // end animation callback function

      function stop_anim_motion_1() {
       if (timer_anim_motion_1) {
        timer.stopTimer(timer_anim_motion_1);
        timer_anim_motion_1 = undefined;
       };
      }; // end stop_anim_motion function


      function anim_motion_2_complete_call() {
       normal_motion_animation_img_2.setProperty(hmUI.prop.ANIM, normal_motion_animation_paramX_2);
       normal_motion_animation_lastTime_2 = timeSensor.utc;
       normal_motion_animation_count_2 = normal_motion_animation_count_2 - 1;
       if (normal_motion_animation_count_2 < -1) normal_motion_animation_count_2 = -1;
       if (normal_motion_animation_count_2 == 0) stop_anim_motion_2();
      }; // end animation callback function

      function stop_anim_motion_2() {
       if (timer_anim_motion_2) {
        timer.stopTimer(timer_anim_motion_2);
        timer_anim_motion_2 = undefined;
       };
      }; // end stop_anim_motion function


      // ----------------------------

      let normal_image_img = ''
      let normal_timerTimeUpdate = undefined;
      let normal_group_ForecastWeather = ''
      let normal_forecast_date_week_font = new Array(4);
      let normal_forecast_date_week_font_Array = ['Понедельник', 'Вторник', 'Среда', 'Четверг', 'Пяпница', 'Суббота', 'Воскресенье'];
      // let normal_forecast_date_week_font_Array = ['Пнд', 'Втр', 'Срд', 'Чтв', 'Птн', 'Сбт', 'Вск'];
      let normal_forecast_date_week_font_Array_smol = ['Пн', 'Вт', 'Ср', 'Чт', 'Пт', 'Сб', 'Вс'];
      let normal_forecast_high_low_text_font = new Array(4);
      let normal_forecast_image_array = ['w_0.png', 'w_1.png', 'w_2.png', 'w_3.png', 'w_4.png', 'w_5.png', 'w_6.png', 'w_7.png', 'w_8.png', 'w_9.png', 'w_10.png', 'w_11.png', 'w_12.png', 'w_13.png', 'w_14.png', 'w_15.png', 'w_16.png', 'w_17.png', 'w_18.png', 'w_19.png', 'w_20.png', 'w_21.png', 'w_22.png', 'w_23.png', 'w_24.png', 'w_25.png', 'w_26.png', 'w_27.png', 'w_28.png'];
      let normal_distance_current_text_font = ''
      let normal_step_linear_scale = ''
      let normal_step_current_text_font = ''
      let normal_battery_circle_scale = ''
      let normal_battery_current_text_font = ''
      let normal_month_name_font = ''
      let normal_Month_Array = ['Января', 'Февраля', 'Марта', 'Апреля', 'Мая', 'Июня', 'Июля', 'Августа', 'Сентября', 'Октября', 'Ноября', 'Декабря', ];
      let normal_day_text_font = ''
      let app_right_circle_scale = ''
      let normal_calorie_current_text_font = ''
      let normal_sun_low_text_font = ''
      let normal_wind_direction_image_progress_img_level = ''
      let normal_wind_current_text_font = ''
      let normal_altimeter_current_text_font = ''
      let normal_heart_rate_text_font = ''
      let normal_system_disconnect_img = ''


      let startX = 23;
      let startY = 232;
      let endX = 167;
      let endY = 124;
      let duration = 1800; // миллисекунды
      let spid = 10;

      let points = [{
        x: 23,
        y: 232
       }, //1
       {
        x: 167,
        y: 124
       }, //2
       {
        x: 167,
        y: 124
       }, //3
       {
        x: 233,
        y: 144
       }, //4
       {
        x: 300,
        y: 124
       }, //5
       {
        x: 300,
        y: 124
       }, //6
       {
        x: 373,
        y: 245
       }, //7
       {
        x: 373,
        y: 245
       }, //8
       {
        x: 373,
        y: 141
       }, //9
       {
        x: 373,
        y: 141
       }, //10
       {
        x: 300,
        y: 124
       }, //11
       {
        x: 233,
        y: 144
       }, //12
       {
        x: 167,
        y: 124
       }, //13
       {
        x: 167,
        y: 124
       }, //14
       {
        x: 23,
        y: 232
       }, //15
       {
        x: 23,
        y: 232
       } //16
      ];

      let durations = [1800, 2000, 6500, 6500, 2000, 10000, 4000, 8000, 2000, 7000, 6500, 7500, 4000, 16000, 4000]; // Длительности анимации для каждой пары точек	

      let currentPointIndex = 0;
      let startTime = null;


      //dynamic modify end

      __$$module$$__.module = DeviceRuntimeCore.WatchFace({
       init_view() {
        //dynamic modify start


        // FontName: Bebas11.ttf; FontSize: 27
        hmUI.createWidget(hmUI.widget.TEXT, {
         x: 464,
         y: 464,
         w: 291,
         h: 38,
         text_size: 27,
         char_space: 0,
         line_space: 0,
         font: 'fonts/Bebas11.ttf',
         color: 0xFFFFFFFF,
         align_h: hmUI.align.CENTER_H,
         align_v: hmUI.align.CENTER_V,
         text_style: hmUI.text_style.ELLIPSIS,
         text: "0123456789 _-.,:;`'%°\\/",
         show_level: hmUI.show_level.ONLY_NORMAL,
        });


        console.log('user_script_start.js');
        // start user_script_start.js



        hmUI.createWidget(hmUI.widget.TEXT, {
         x: 464,
         y: 464,
         w: 42,
         h: 42,
         text_size: 27,
         char_space: 0,
         line_space: 0,
         font: 'fonts/Bebas11.ttf',
         color: 0xFFFFFF00,
         align_h: hmUI.align.LEFT,
         align_v: hmUI.align.CENTER_V,
         text_style: hmUI.text_style.NONE,
         text: "0123456789 ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz АБВГДЕЁЖЗИЙКЛМНОПРСТУФХЦЧШЩЪЫЬЭЮЯабвгдеёжзийклмнопрстуфхцчшщъыьэюя  ҐЄІЇґєії _-.,:;`'%°\\/()",
         show_level: hmUI.show_level.ONLY_NORMAL,
        });


        hmUI.createWidget(hmUI.widget.TEXT, {
         x: 464,
         y: 464,
         w: 42,
         h: 42,
         text_size: 27,
         char_space: 0,
         line_space: 0,
         font: 'fonts/Oswald-Regular.ttf',
         color: 0xFFFFFF00,
         align_h: hmUI.align.LEFT,
         align_v: hmUI.align.CENTER_V,
         text_style: hmUI.text_style.NONE,
         text: "0123456789 ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz АБВГДЕЁЖЗИЙКЛМНОПРСТУФХЦЧШЩЪЫЬЭЮЯабвгдеёжзийклмнопрстуфхцчшщъыьэюя  ҐЄІЇґєії _-.,:;`'%°\\/()",
         show_level: hmUI.show_level.ONLY_NORMAL,
        });

        hmUI.createWidget(hmUI.widget.TEXT, {
         x: 464,
         y: 464,
         w: 42,
         h: 42,
         text_size: 33,
         char_space: 0,
         line_space: 0,
         font: 'fonts/Bebas11.ttf',
         color: 0xFFFFFF00,
         align_h: hmUI.align.LEFT,
         align_v: hmUI.align.CENTER_V,
         text_style: hmUI.text_style.NONE,
         text: "0123456789 ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz АБВГДЕЁЖЗИЙКЛМНОПРСТУФХЦЧШЩЪЫЬЭЮЯабвгдеёжзийклмнопрстуфхцчшщъыьэюя  ҐЄІЇґєії _-.,:;`'%°\\/",
         show_level: hmUI.show_level.ONLY_NORMAL,
        });
        hmUI.createWidget(hmUI.widget.TEXT, {
         x: 464,
         y: 464,
         w: 328,
         h: 48,
         text_size: 35,
         char_space: 0,
         line_space: 0,
         font: 'fonts/Bebas11.ttf',
         color: 0xFFFFFFFF,
         align_h: hmUI.align.CENTER_H,
         align_v: hmUI.align.CENTER_V,
         text_style: hmUI.text_style.ELLIPSIS,
         text: "0123456789 _-.,:;`'%°\\/↓↑=C|",
         show_level: hmUI.show_level.ONLY_NORMAL,
        });

        hmUI.createWidget(hmUI.widget.TEXT, {
         x: 464,
         y: 464,
         w: 42,
         h: 42,
         text_size: 30,
         char_space: 0,
         line_space: 0,
         font: 'fonts/Oswald-Regular.ttf',
         color: 0xFFFFFF00,
         align_h: hmUI.align.LEFT,
         align_v: hmUI.align.CENTER_V,
         text_style: hmUI.text_style.NONE,
         text: "0123456789 ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz АБВГДЕЁЖЗИЙКЛМНОПРСТУФХЦЧШЩЪЫЬЭЮЯабвгдеёжзийклмнопрстуфхцчшщъыьэюя  ҐЄІЇґєії _-.,:;`'%°\\/",
         show_level: hmUI.show_level.ONLY_NORMAL,
        });

        hmUI.createWidget(hmUI.widget.TEXT, {
         x: 464,
         y: 464,
         w: 42,
         h: 42,
         text_size: 27,
         char_space: 0,
         line_space: 0,
         font: 'fonts/Oswald-Light.ttf',
         color: 0xFFFFFF00,
         align_h: hmUI.align.LEFT,
         align_v: hmUI.align.CENTER_V,
         text_style: hmUI.text_style.NONE,
         text: "0123456789 ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz АБВГДЕЁЖЗИЙКЛМНОПРСТУФХЦЧШЩЪЫЬЭЮЯабвгдеёжзийклмнопрстуфхцчшщъыьэюя  ҐЄІЇґєії _-.,:;`'%°\\/",
         show_level: hmUI.show_level.ONLY_NORMAL,
        });

        hmUI.createWidget(hmUI.widget.TEXT, {
         x: 464,
         y: 464,
         w: 42,
         h: 42,
         text_size: 24,
         char_space: 0,
         line_space: 0,
         font: 'fonts/Oswald-Light.ttf',
         color: 0xFFFFFF00,
         align_h: hmUI.align.LEFT,
         align_v: hmUI.align.CENTER_V,
         text_style: hmUI.text_style.NONE,
         text: "0123456789 ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz АБВГДЕЁЖЗИЙКЛМНОПРСТУФХЦЧШЩЪЫЬЭЮЯабвгдеёжзийклмнопрстуфхцчшщъыьэюя  ҐЄІЇґєії _-.,:;`'%°\\/",
         show_level: hmUI.show_level.ONLY_NORMAL,
        });


        normal_background_bg = hmUI.createWidget(hmUI.widget.FILL_RECT, {
         x: 0,
         y: 0,
         w: 466,
         h: 466,
         color: 0x000000,
         // color: color_bg[0][Ar_Set[0][1]],
         show_level: hmUI.show_level.ONLY_NORMAL,
        });
        // end user_script_start.js

        console.log('Watch_Face.ScreenNormal');

        let screenType = hmSetting.getScreenType();
        bg_edit_img = hmUI.createWidget(hmUI.widget.IMG, {
         x: 0,
         y: 0,
         src: 'tap/bg_edit.png',
         show_level: hmUI.show_level.ONLY_EDIT,
        });


        //    -------------Луна
        moon_1 = hmUI.createWidget(hmUI.widget.IMG, {
         x: 333,
         y: 271,
         src: 'weathermini/moon_0_1.png',
         show_level: hmUI.show_level.ONLY_NORMAL,
        });
        moon_1.setProperty(hmUI.prop.VISIBLE, false);


        //    -------------Звезды
        star_1 = hmUI.createWidget(hmUI.widget.IMG, {
         x: 134,
         y: 124,
         src: 'weathermini/falling_star_0_1.png',
         show_level: hmUI.show_level.ONLY_NORMAL,
        });
        star_1.setProperty(hmUI.prop.VISIBLE, false);

        star_2 = hmUI.createWidget(hmUI.widget.IMG, {
         x: 267,
         y: 124,
         src: 'weathermini/falling_star_0_1.png',
         show_level: hmUI.show_level.ONLY_NORMAL,
        });
        star_2.setProperty(hmUI.prop.VISIBLE, false);

        star_3 = hmUI.createWidget(hmUI.widget.IMG, {
         x: 467,
         y: 124,
         src: 'weathermini/falling_star_0_1.png',
         show_level: hmUI.show_level.ONLY_NORMAL,
        });
        star_3.setProperty(hmUI.prop.VISIBLE, false);


        weather_1_0_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
         x: 4,
         y: 124,
         src: 'weather_up/weather_1_0_bg.png',
         show_level: hmUI.show_level.ONLY_NORMAL,
        });
        weather_1_0_bg_img.setProperty(hmUI.prop.VISIBLE, false);

        //-----------шар
        airbaloon_img = hmUI.createWidget(hmUI.widget.IMG, {
         x: startX,
         y: startY,
         src: 'weathermini/airbaloon_0_0.png',
         show_level: hmUI.show_level.ONLY_NORMAL,
        });
        airbaloon_img.setProperty(hmUI.prop.VISIBLE, false);


        //------------Облака
        normal_motion_animation_img_1 = hmUI.createWidget(hmUI.widget.IMG, {
         x: 0,
         y: 0,
         w: 465,
         h: 465,
         pos_x: 51,
         pos_y: 131,
         src: 'weathermini/cloudy_mini.png',
         show_level: hmUI.show_level.ONLY_NORMAL,
        });
        normal_motion_animation_img_1.setProperty(hmUI.prop.VISIBLE, false);

        normal_motion_animation_paramX_1 = {
         anim_steps: [{
          anim_rate: 'linear',
          anim_duration: 100000,
          anim_from: 51,
          anim_to: 531,
          anim_key: "pos_x",
         }],
         anim_fps: 15,
         anim_auto_start: 1,
         anim_repeat: 0,
         anim_auto_destroy: 1,
        };


        normal_motion_animation_img_2 = hmUI.createWidget(hmUI.widget.IMG, {
         x: 0,
         y: 0,
         w: 465,
         h: 465,
         pos_x: -429,
         pos_y: 131,
         src: 'weathermini/cloudy_mini.png',
         show_level: hmUI.show_level.ONLY_NORMAL,
        });
        normal_motion_animation_img_2.setProperty(hmUI.prop.VISIBLE, false);


        normal_motion_animation_paramX_2 = {
         anim_steps: [{
          anim_rate: 'linear',
          anim_duration: 100000,
          anim_from: -429,
          anim_to: 51,
          anim_key: "pos_x",
         }],
         anim_fps: 15,
         anim_auto_start: 1,
         anim_repeat: 0,
         anim_auto_destroy: 1,
        };

        //------------Облака--------------------


        //-----------маска
        mask12 = hmUI.createWidget(hmUI.widget.IMG, {
         x: -9,
         y: 122,
         src: 'weathermini/mask12.png',
         mask: true,
         show_level: hmUI.show_level.ONLY_NORMAL,
        });
        mask12.setProperty(hmUI.prop.VISIBLE, true);

        curWeatherIcon = hmUI.createWidget(hmUI.widget.IMG, {
         x: 4,
         y: 124,
         src: 'weather_up/weather_13_0.png',
         show_level: hmUI.show_level.ONLY_NORMAL,
        });


        //------------Солнце
        sun_blick = hmUI.createWidget(hmUI.widget.IMG, {
         x: 50,
         y: 99,
         src: 'weathermini/sun_ani_blick_0_0.png',
         show_level: hmUI.show_level.ONLY_NORMAL,
        });
        sun_blick.setProperty(hmUI.prop.VISIBLE, false);

        //        sun_ani = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
        //         second_path: 'weathermini/sun_ani_0_0.png',
        //         second_centerX: 107,
        //         second_centerY: 171,
        //         second_posX: 63,
        //         second_posY: 63,
        //         //         fresh_frequency: 20,
        //         //         fresh_freqency: 20,
        //         show_level: hmUI.show_level.ONLY_NORMAL,
        //        });

        sun_ani_img = hmUI.createWidget(hmUI.widget.IMG, {
         x: 44,
         y: 109, //139-60
         w: 125,
         h: 125, //139-60
         center_x: 125 / 2,
         center_y: 125 / 2,
         src: 'weathermini/sun_ani_0_0.png',
         //alpha: 0,
         show_level: hmUI.show_level.ONLY_NORMAL,
        });
        sun_ani_img.setProperty(hmUI.prop.VISIBLE, false);
		   
	   
		   

        sun = hmUI.createWidget(hmUI.widget.IMG, {
         x: 80,
         y: 144,
         src: 'weathermini/sun.png',
         show_level: hmUI.show_level.ONLY_NORMAL,
        });
        sun.setProperty(hmUI.prop.VISIBLE, false);


        snowfall = new Snowfall(25); // в скобках количество снежинок		   
        rainfall = new Rainfall(25); // в скобках количество снежинок		   


        wheather12_img = hmUI.createWidget(hmUI.widget.IMG, {
         x: 106,
         y: 282,
         src: 'weathermini/wheather12.png',
         show_level: hmUI.show_level.ONLY_NORMAL,
        });
        wheather12_img.setProperty(hmUI.prop.VISIBLE, false);


        thunder00_img = hmUI.createWidget(hmUI.widget.IMG, {
         x: 142,
         y: 156 - 45,
         src: 'weathermini/thunder_night_thunder00.png',
         show_level: hmUI.show_level.ONLY_NORMAL,
        });
        thunder00_img.setProperty(hmUI.prop.VISIBLE, false);

        thunder01_img = hmUI.createWidget(hmUI.widget.IMG, {
         x: 190,
         y: 149 - 36,
         src: 'weathermini/thunder_night_thunder01.png',
         show_level: hmUI.show_level.ONLY_NORMAL,
        });
        thunder01_img.setProperty(hmUI.prop.VISIBLE, false);

        thunder02_img = hmUI.createWidget(hmUI.widget.IMG, {
         x: 155,
         y: 169 - 32,
         src: 'weathermini/thunder_night_thunder02.png',
         show_level: hmUI.show_level.ONLY_NORMAL,
        });
        thunder02_img.setProperty(hmUI.prop.VISIBLE, false);

        thunder03_img = hmUI.createWidget(hmUI.widget.IMG, {
         x: 155,
         y: 159 - 35,
         src: 'weathermini/thunder_night_thunder03.png',
         show_level: hmUI.show_level.ONLY_NORMAL,
        });
        thunder03_img.setProperty(hmUI.prop.VISIBLE, false);


        thunder_img = hmUI.createWidget(hmUI.widget.IMG, {
         x: 49,
         y: 139 - 60 / 1.5, //139-60
         src: 'weathermini/thunder.png',
         show_level: hmUI.show_level.ONLY_NORMAL,
        });
        thunder_img.setProperty(hmUI.prop.VISIBLE, false);

        wind_img = hmUI.createWidget(hmUI.widget.IMG, {
         x: 0,
         y: 224, //139-60
         src: 'weathermini/wind.png',
         show_level: hmUI.show_level.ONLY_NORMAL,
        });
        wind_img.setProperty(hmUI.prop.VISIBLE, false);

        klenr_img = hmUI.createWidget(hmUI.widget.IMG, {
         x: 0,
         y: 231, //139-60
         w: 32,
         h: 40, //139-60
         center_x: 32 / 2,
         center_y: 25,
         src: 'weathermini/klenr.png',
         alpha: 0,
         show_level: hmUI.show_level.ONLY_NORMAL,
        });
        klenr_img.setProperty(hmUI.prop.VISIBLE, false);

        kleng_img = hmUI.createWidget(hmUI.widget.IMG, {
         x: 0,
         y: 219, //139-60
         w: 27,
         h: 29, //139-60
         center_x: 27 / 2,
         center_y: 20,
         src: 'weathermini/kleng.png',
         alpha: 0,
         show_level: hmUI.show_level.ONLY_NORMAL,
        });
        kleng_img.setProperty(hmUI.prop.VISIBLE, false);

        klenk_img = hmUI.createWidget(hmUI.widget.IMG, {
         x: 0,
         y: 239, //139-60
         w: 27,
         h: 29, //139-60
         center_x: 27 / 2,
         center_y: 20,
         src: 'weathermini/klenk.png',
         alpha: 0,
         show_level: hmUI.show_level.ONLY_NORMAL,
        });
        klenk_img.setProperty(hmUI.prop.VISIBLE, false);

        fog_img = hmUI.createWidget(hmUI.widget.IMG, {
         x: 60,
         y: 201,
         w: 331, //247
         h: 127,
         src: 'weathermini/fog.png',
         auto_scale: true,
         auto_scale_obj_fit: true,
         show_level: hmUI.show_level.ONLY_NORMAL,
        });
        fog_img.setProperty(hmUI.prop.VISIBLE, false);


        normal_image_img = hmUI.createWidget(hmUI.widget.IMG, {
         x: 346,
         y: 321 + 2,
         src: 'ic_update.png',
         show_level: hmUI.show_level.ONLY_NORMAL,
        });


        normal_image_img = hmUI.createWidget(hmUI.widget.IMG, {
         x: 11,
         y: 258 + 2,
         src: 'ic_alarm.png',
         show_level: hmUI.show_level.ONLY_NORMAL,
        });

        /*        normal_image_img = hmUI.createWidget(hmUI.widget.IMG, {
                 x: 216,
                 y: 430,
                 src: 'ic_puls.png',
                 show_level: hmUI.show_level.ONLY_NORMAL,
                });*/

        //        normal_image_img = hmUI.createWidget(hmUI.widget.IMG, {
        //         x: 19,
        //         y: 198,
        //         src: 'ic_vl.png',
        //         show_level: hmUI.show_level.ONLY_NORMAL,
        //        });


        //        normal_time_hour_min_text_font = new TextWithOutline({
        //         x: 0,
        //         y: 158,
        //         w: 466,
        //         h: 150,
        //         text: '00:00',
        //         text_size: 120,
        //         char_space: 0,
        //         line_space: 0,
        //         font: 'fonts/Magistral-Medium.ttf',
        //         color: 0xFFFFFFFF,
        //         align_h: hmUI.align.CENTER_H,
        //         align_v: hmUI.align.CENTER_V,
        //         text_style: hmUI.text_style.ELLIPSIS,
        //         // padding: true,
        //         show_level: hmUI.show_level.ONLY_NORMAL,
        //        });


        normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
         hour_startX: 92,
         hour_startY: 46,
         hour_array: ["Hour_0.png", "Hour_1.png", "Hour_2.png", "Hour_3.png", "Hour_4.png", "Hour_5.png", "Hour_6.png", "Hour_7.png", "Hour_8.png", "Hour_9.png"],
         hour_zero: 1,
         hour_space: 0,
         hour_angle: 0,
         hour_unit_sc: 'Hour_10.png',
         hour_unit_tc: 'Hour_10.png',
         hour_unit_en: 'Hour_10.png',
         hour_align: hmUI.align.LEFT,

         minute_startX: 0,
         minute_startY: 0,
         minute_array: ["Hour_0.png", "Hour_1.png", "Hour_2.png", "Hour_3.png", "Hour_4.png", "Hour_5.png", "Hour_6.png", "Hour_7.png", "Hour_8.png", "Hour_9.png"],
         minute_zero: 1,
         minute_space: 0,
         minute_angle: 0,
         minute_follow: 1,
         minute_align: hmUI.align.LEFT,

         show_level: hmUI.show_level.ONLY_NORMAL,
        });


        /*       normal_group_ForecastWeather = hmUI.createWidget(hmUI.widget.GROUP, {
                x: -60,
                y: 0,
                h: 0,
                w: 0,
                show_level: hmUI.show_level.ONLY_NORMAL,
               });


               //start of ignored block
               if (screenType == hmSetting.screen_type.WATCHFACE) {
                for (let i = 0; i < daysNum - dney; i++) {
                 if (i == 0) {
                  normal_forecast_date_week_font[i] = normal_group_ForecastWeather.createWidget(hmUI.widget.TEXT, {
                   x: 91 + i * 85,
                   y: 353 + 3,
                   w: 150,
                   h: 36,
                   text_size: 24,
                   char_space: 0,
                   line_space: 0,
                   color: 0xFFFFFFFF,
                   font: 'fonts/Magistral-Bold.ttf',
                   align_h: hmUI.align.CENTER_H,
                   align_v: hmUI.align.CENTER_V,
                   text_style: hmUI.text_style.ELLIPSIS,
                   // unit_string: ПНД, ВТР, СРД, ЧТВ, ПТН, СБТ, ВСК,
                   show_level: hmUI.show_level.ONLY_NORMAL,
                  });


                 } else {
                  normal_forecast_date_week_font[i] = normal_group_ForecastWeather.createWidget(hmUI.widget.TEXT, {
                   x: 91 + i * 85,
                   y: 353 + 5,
                   w: 150,
                   h: 36,
                   text_size: 24,
                   char_space: 0,
                   line_space: 0,
                   color: 0xFFFFFFFF,
                   // color_2: 0xFFFF0000,
                   align_h: hmUI.align.CENTER_H,
                   align_v: hmUI.align.CENTER_V,
                   text_style: hmUI.text_style.ELLIPSIS,
                   // unit_string: ПНД, ВТР, СРД, ЧТВ, ПТН, СБТ, ВСК,
                   show_level: hmUI.show_level.ONLY_NORMAL,
                  });
                 }


                };


               };


               //end of ignored block


               //start of ignored block
               if (screenType == hmSetting.screen_type.WATCHFACE) {
                for (let i = 0; i < daysNum - dney; i++) {
                 normal_forecast_high_low_text_font[i] = normal_group_ForecastWeather.createWidget(hmUI.widget.TEXT, {
                  x: 91 + i * 85,
                  y: 336,
                  w: 150,
                  h: 30,
                  text_size: 27,
                  char_space: 0,
                  line_space: 0,
                  font: 'fonts/Bebas11.ttf',
                  color: 0xFFFFFFFF,
                  align_h: hmUI.align.CENTER_H,
                  align_v: hmUI.align.CENTER_V,
                  text_style: hmUI.text_style.ELLIPSIS,
                  // unit_string: /,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                 });
                };

                //dayTemp.push({ high: normal_forecast_high_low_text_font});                
               };
               //end of ignored block


               //start of ignored block
               // if (screenType == hmSetting.screen_type.WATCHFACE) {
               for (let i = 0; i < daysNum - dney; i++) {
                if (i != 0) {
                 dayWeatherIcon[i] = normal_group_ForecastWeather.createWidget(hmUI.widget.IMG, {
                  x: 139 + i * 85,
                  y: 283,
                  src: 'w_15.png',
                  show_level: hmUI.show_level.ONLY_NORMAL,
                 });
                } else {
                 curWeatherIcon = normal_group_ForecastWeather.createWidget(hmUI.widget.IMG, {
                  x: 139 + 0 * 85,
                  y: 283,
                  src: 'w_15.png',
                  show_level: hmUI.show_level.ONLY_NORMAL,
                 });
                }
               };
               //  };
               //end of ignored block*/


        //        normal_distance_current_text_font = new TextWithOutline({
        //         x: 0,
        //         y: 106,
        //         w: 466,
        //         h: 30,
        //         text_size: 26,
        //         char_space: 0,
        //         line_space: 0,
        //         font: 'fonts/Magistral-Medium.ttf',
        //         color: 0xFFFFFFFF,
        //         align_h: hmUI.align.CENTER_H,
        //         align_v: hmUI.align.CENTER_V,
        //         text_style: hmUI.text_style.ELLIPSIS,
        //         type: hmUI.data_type.DISTANCE,
        //         show_level: hmUI.show_level.ONLY_NORMAL,
        //        });

        /*        if (screenType != hmSetting.screen_type.AOD) {
                 normal_step_linear_scale = hmUI.createWidget(hmUI.widget.FILL_RECT);
                };*/


        /*        const step = hmSensor.createSensor(hmSensor.id.STEP);
                step.addEventListener(hmSensor.event.CHANGE, function () {
                 scale_call();
                });*/

        /*        normal_step_current_text_font = new TextWithOutline({
                 x: 0,
                 y: 75,
                 w: 466,
                 h: 30,
                 text_size: 26,
                 char_space: 0,
                 line_space: 0,
                 font: 'fonts/Magistral-Medium.ttf',
                 color: 0xFFFFFFFF,
                 align_h: hmUI.align.CENTER_H,
                 align_v: hmUI.align.CENTER_V,
                 text_style: hmUI.text_style.ELLIPSIS,
                 type: hmUI.data_type.STEP,
                 show_level: hmUI.show_level.ONLY_NORMAL,
                });*/


        /*        normal_battery_circle_scale = hmUI.createWidget(hmUI.widget.ARC_PROGRESS, {
                 center_x: 141,
                 center_y: 135,
                 start_angle: 270,
                 end_angle: 360,
                 radius: 71,
                 line_width: 6,
                 corner_flag: 0,
                 color: 0xFFFFFFFF,
                 show_level: hmUI.show_level.ONLY_NORMAL,
                });


                const battery = hmSensor.createSensor(hmSensor.id.BATTERY);
                battery.addEventListener(hmSensor.event.CHANGE, function () {
                 scale_call();
                });*/

        normal_battery_current_text_font = hmUI.createWidget(hmUI.widget.TEXT, {
         x: 0,
         y: 3,
         w: 466,
         h: 40,
         text_size: 29,
         char_space: 0,
         line_space: 0,
         // font: 'fonts/Magistral-Medium.ttf',
         color: 0xFFFFFFFF,
         align_h: hmUI.align.CENTER_H,
         align_v: hmUI.align.CENTER_V,
         unit_type: 1,
         text_style: hmUI.text_style.ELLIPSIS,
         type: hmUI.data_type.BATTERY,
         show_level: hmUI.show_level.ONLY_NORMAL,
        });

        normal_day_text_font_1 = new TextWithOutline({
         x: 14,
         y: 179,
         w: 466,
         h: 50,
         text_size: 27,
         char_space: 0,
         line_space: 0,
         font: 'fonts/Oswald-Regular.ttf',
         color: 0xFFFFFFFF,
         align_h: hmUI.align.LEFT,
         align_v: hmUI.align.CENTER_V,
         text_style: hmUI.text_style.ELLIPSIS,
         // unit_string: ЯНВАРЯ, ФЕВРАЛЯ, МАРТА, АПРЕЛЯ, МАЯ, ИЮНЯ, ИЮЛЯ, АВГУСТА, СЕНТЯБРЯ, ОКТЯБРЯ, НОЯБРЯ, ДЕКАБРЯ,
         show_level: hmUI.show_level.ONLY_NORMAL,
        });

        normal_day_text_font_2 = new TextWithOutline({
         x: 14,
         y: 214,
         w: 466,
         h: 50,
         text_size: 27,
         char_space: 0,
         line_space: 0,
         font: 'fonts/Oswald-Regular.ttf',
         color: 0xFFFFFFFF,
         align_h: hmUI.align.LEFT,
         align_v: hmUI.align.CENTER_V,
         text_style: hmUI.text_style.ELLIPSIS,
         // unit_string: ЯНВАРЯ, ФЕВРАЛЯ, МАРТА, АПРЕЛЯ, МАЯ, ИЮНЯ, ИЮЛЯ, АВГУСТА, СЕНТЯБРЯ, ОКТЯБРЯ, НОЯБРЯ, ДЕКАБРЯ,
         show_level: hmUI.show_level.ONLY_NORMAL,
        });


        temperature_now = new TextWithOutline({
         x: 303,
         y: 181,
         w: 150,
         h: 50,
         text_size: 27,
         char_space: 0,
         line_space: 0,
         font: 'fonts/Oswald-Regular.ttf',
         color: 0xFFFFFFFF,
         align_h: hmUI.align.RIGHT,
         align_v: hmUI.align.CENTER_V,
         text_style: hmUI.text_style.ELLIPSIS,
         // unit_string: ЯНВАРЯ, ФЕВРАЛЯ, МАРТА, АПРЕЛЯ, МАЯ, ИЮНЯ, ИЮЛЯ, АВГУСТА, СЕНТЯБРЯ, ОКТЯБРЯ, НОЯБРЯ, ДЕКАБРЯ,
         show_level: hmUI.show_level.ONLY_NORMAL,
        });


        normal_city_name_text = new TextWithOutline({
         x: 33,
         y: 280,
         w: 280,
         h: 50,
         text_size: 24,
         text: '--',
         font: 'fonts/Oswald-Light.ttf',
         char_space: 0,
         line_space: 0,
         color: 0xFFFFFFFF,
         align_h: hmUI.align.LEFT,
         align_v: hmUI.align.CENTER_V,
         text_style: hmUI.text_style.NONE,
         show_level: hmUI.show_level.ONLY_NORMAL,
        });


        WeaterText = new TextWithOutline({
         x: 33,
         y: 308,
         w: 280,
         h: 50,
         char_space: 0,
         color: "0xFFffffff",
         text: '--',
         font: 'fonts/Oswald-Light.ttf',
         text_size: 24,
         text_style: hmUI.text_style.NONE,
         align_h: hmUI.align.LEFT,
         align_v: hmUI.align.CENTER_V,
         show_level: hmUI.show_level.ONLY_NORMAL
        });

        normal_ALARM_CLOCK_text_font1 = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
         x: 52 - 2,
         y: 247 - 2,
         w: 150,
         h: 50,
         text_size: 27,
         padding: true,
         char_space: 0,
         line_space: 0,
         font: 'fonts/Oswald-Regular.ttf',
         color: 0x000000,
         align_h: hmUI.align.LEFT,
         align_v: hmUI.align.CENTER_V,
         text_style: hmUI.text_style.ELLIPSIS,
         type: hmUI.data_type.ALARM_CLOCK,
         show_level: hmUI.show_level.ONLY_NORMAL,
        });

        normal_ALARM_CLOCK_text_font2 = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
         x: 52 + 2,
         y: 247 + 2,
         w: 150,
         h: 50,
         text_size: 27,
         padding: true,
         char_space: 0,
         line_space: 0,
         font: 'fonts/Oswald-Regular.ttf',
         color: 0x000000,
         align_h: hmUI.align.LEFT,
         align_v: hmUI.align.CENTER_V,
         text_style: hmUI.text_style.ELLIPSIS,
         type: hmUI.data_type.ALARM_CLOCK,
         show_level: hmUI.show_level.ONLY_NORMAL,
        });

        normal_ALARM_CLOCK_text_font3 = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
         x: 52 + 2,
         y: 247 - 2,
         w: 150,
         h: 50,
         text_size: 27,
         padding: true,
         char_space: 0,
         line_space: 0,
         font: 'fonts/Oswald-Regular.ttf',
         color: 0x000000,
         align_h: hmUI.align.LEFT,
         align_v: hmUI.align.CENTER_V,
         text_style: hmUI.text_style.ELLIPSIS,
         type: hmUI.data_type.ALARM_CLOCK,
         show_level: hmUI.show_level.ONLY_NORMAL,
        });

        normal_ALARM_CLOCK_text_font4 = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
         x: 52 - 2,
         y: 247 + 2,
         w: 150,
         h: 50,
         text_size: 27,
         padding: true,
         char_space: 0,
         line_space: 0,
         font: 'fonts/Oswald-Regular.ttf',
         color: 0x000000,
         align_h: hmUI.align.LEFT,
         align_v: hmUI.align.CENTER_V,
         text_style: hmUI.text_style.ELLIPSIS,
         type: hmUI.data_type.ALARM_CLOCK,
         show_level: hmUI.show_level.ONLY_NORMAL,
        });

        normal_ALARM_CLOCK_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
         x: 52,
         y: 247,
         w: 150,
         h: 50,
         text_size: 27,
         padding: true,
         char_space: 0,
         line_space: 0,
         font: 'fonts/Oswald-Regular.ttf',
         color: 0xFFFFFFFF,
         align_h: hmUI.align.LEFT,
         align_v: hmUI.align.CENTER_V,
         text_style: hmUI.text_style.ELLIPSIS,
         type: hmUI.data_type.ALARM_CLOCK,
         show_level: hmUI.show_level.ONLY_NORMAL,
        });

        normal_osadki_img = hmUI.createWidget(hmUI.widget.IMG, {
         x: 370,
         y: 226 + 1,
         src: 'ic_osadki_off.png',
         show_level: hmUI.show_level.ONLY_NORMAL,
        });

        normal_osadki_text_font = new TextWithOutline({
         x: 303,
         y: 219,
         w: 150,
         h: 50,
         // text: weatherData.chanceOfRain,
         text_size: 27,
         char_space: 0,
         line_space: 0,
         font: 'fonts/Oswald-Light.ttf',
         color: 0xFFFFFFFF,
         align_h: hmUI.align.RIGHT,
         align_v: hmUI.align.CENTER_V,
         unit_type: 1,
         text_style: hmUI.text_style.ELLIPSIS,
         // type: hmUI.data_type.HUMIDITY,
         show_level: hmUI.show_level.ONLY_NORMAL,
        });

        normal_update_time_text_font = hmUI.createWidget(hmUI.widget.TEXT, {
         x: 331,
         y: 308,
         w: 150,
         h: 50,
         text: '--/--',
         font: 'fonts/Oswald-Light.ttf',
         text_size: 24,
         char_space: 0,
         line_space: 0,
         color: 0xFF9A9A9A,
         align_h: hmUI.align.CENTER_H,
         align_v: hmUI.align.CENTER_V,
         text_style: hmUI.text_style.ELLIPSIS,
         show_level: hmUI.show_level.ONLY_NORMAL,
        });

        step_text = hmUI.createWidget(hmUI.widget.TEXT, {
         x: 0,
         y: 342,
         w: 466,
         h: 50,
         text: '--/--',
         font: 'fonts/Oswald-Regular.ttf',
         text_size: 30,
         char_space: 0,
         line_space: 0,
         color: 0xFFFFFFFF,
         align_h: hmUI.align.CENTER_H,
         align_v: hmUI.align.CENTER_V,
         text_style: hmUI.text_style.ELLIPSIS,
         show_level: hmUI.show_level.ONLY_NORMAL,
        });

        puls_text = hmUI.createWidget(hmUI.widget.TEXT, {
         x: 0,
         y: 372,
         w: 466,
         h: 50,
         text: '--/--',
         font: 'fonts/Oswald-Regular.ttf',
         text_size: 30,
         char_space: 0,
         line_space: 0,
         color: 0xFFFFFFFF,
         align_h: hmUI.align.CENTER_H,
         align_v: hmUI.align.CENTER_V,
         text_style: hmUI.text_style.ELLIPSIS,
         show_level: hmUI.show_level.ONLY_NORMAL,
        });

        temperatura_day_night = hmUI.createWidget(hmUI.widget.TEXT, {
         x: 0,
         y: 406,
         w: 466,
         h: 50,
         text: "--/--",
         text_size: 27,
         char_space: 0,
         line_space: 0,
         font: 'fonts/Oswald-Light.ttf',
         color: 0xFFFFFFFF,
         align_h: hmUI.align.CENTER_H,
         align_v: hmUI.align.CENTER_V,
         unit_type: 1,
         text_style: hmUI.text_style.ELLIPSIS,
         // type: hmUI.data_type.HUMIDITY,
         show_level: hmUI.show_level.ONLY_NORMAL,
        });


        //        normal_HUMIDITY_text_font = new TextWithOutline({
        //         x: -40,
        //         y: 236,
        //         w: 150,
        //         h: 30,
        //         // text: weatherData.chanceOfRain,
        //         text_size: 26,
        //         char_space: 0,
        //         line_space: 0,
        //         // font: 'fonts/Magistral-Medium.ttf',
        //         color: 0xFFFFFFFF,
        //         align_h: hmUI.align.CENTER_H,
        //         align_v: hmUI.align.CENTER_V,
        //         unit_type: 1,
        //         text_style: hmUI.text_style.ELLIPSIS,
        //         // type: hmUI.data_type.HUMIDITY,
        //         show_level: hmUI.show_level.ONLY_NORMAL,
        //        });

        //        app_text_left = new TextWithOutline({
        //         x: 48,
        //         y: 115,
        //         w: 150,
        //         h: 40,
        //         text: 'ЗАРЯД',
        //         //font: 'fonts/Bebas11.ttf',
        //         text_size: 16,
        //         char_space: 0,
        //         line_space: 0,
        //         color: 0xFFFFFF,
        //         align_h: hmUI.align.CENTER_H,
        //         align_v: hmUI.align.CENTER_V,
        //         //unit_type: 1,
        //         text_style: hmUI.text_style.ELLIPSIS,
        //         //type: hmUI.data_type.WIND,
        //         show_level: hmUI.show_level.ONLY_NORMAL,
        //        });

        //        app_text_right = new TextWithOutline({
        //         x: 268,
        //         y: 115,
        //         w: 150,
        //         h: 40,
        //         text: 'ККАЛ',
        //         //font: 'fonts/Bebas11.ttf',
        //         text_size: 16,
        //         char_space: 0,
        //         line_space: 0,
        //         color: 0xFFFFFF,
        //         align_h: hmUI.align.CENTER_H,
        //         align_v: hmUI.align.CENTER_V,
        //         //unit_type: 1,
        //         text_style: hmUI.text_style.ELLIPSIS,
        //         //type: hmUI.data_type.WIND,
        //         show_level: hmUI.show_level.ONLY_NORMAL,
        //        });


        hmUI.createWidget(hmUI.widget.IMG, {
         x: 379,
         y: 83,
         src: 'ic_bt.png',
         show_level: hmUI.show_level.ONLY_NORMAL,
        });

        normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
         x: 379,
         y: 83,
         src: 'stat_B_off.png',
         type: hmUI.system_status.DISCONNECT,
         show_level: hmUI.show_level.ONLY_NORMAL,
        });


        console.log('user_script_beforeShortcuts.js');
        // start user_script_beforeShortcuts.js


        groupVremya = hmUI.createWidget(hmUI.widget.GROUP, {
         x: 0,
         y: 0,
         w: D_W,
         h: D_H,
        }); // ы

        groupTap = hmUI.createWidget(hmUI.widget.GROUP, {
         x: 0,
         y: 0,
         w: D_W,
         h: D_H,
        });

        i_tap_bg_img = groupTap.createWidget(hmUI.widget.IMG, {
         x: 0,
         y: 0,
         w: D_W,
         h: D_H,
         src: 'tap/i_tap_bg.png',
         show_level: hmUI.show_level.ONLY_NORMAL,
        });


        Tap_zona_0 = groupTap.createWidget(hmUI.widget.IMG, {
         x: tap_x_y[0][0],
         y: tap_x_y[0][1],
         src: apps[tap_1_select][2], //'tap/i_tap_calendar.png',
         show_level: hmUI.show_level.ONLY_NORMAL,
        });

        Tap_zona_1 = groupTap.createWidget(hmUI.widget.IMG, {
         x: tap_x_y[1][0],
         y: tap_x_y[1][1],
         src: apps[tap_2_select][2],
         show_level: hmUI.show_level.ONLY_NORMAL,
        });

        Tap_zona_2 = groupTap.createWidget(hmUI.widget.IMG, {
         x: tap_x_y[2][0],
         y: tap_x_y[2][1],
         src: apps[tap_3_select][2],
         show_level: hmUI.show_level.ONLY_NORMAL,
        });

        Tap_zona_3 = groupTap.createWidget(hmUI.widget.IMG, {
         x: tap_x_y[3][0],
         y: tap_x_y[3][1],
         src: apps[tap_4_select][2],
         show_level: hmUI.show_level.ONLY_NORMAL,
        });

        Tap_zona_4 = groupTap.createWidget(hmUI.widget.IMG, {
         x: tap_x_y[4][0],
         y: tap_x_y[4][1],
         src: apps[tap_5_select][2],
         show_level: hmUI.show_level.ONLY_NORMAL,
        });

        Tap_zona_5 = groupTap.createWidget(hmUI.widget.IMG, {
         x: tap_x_y[5][0],
         y: tap_x_y[5][1],
         src: apps[tap_6_select][2],
         show_level: hmUI.show_level.ONLY_NORMAL,
        });


        btn_Tap_zona_0 = groupTap.createWidget(hmUI.widget.BUTTON, {
         x: tap_x_y[0][0],
         y: tap_x_y[0][1],
         text: '',
         w: 113,
         h: 113,
         normal_src: '0_Empty.png',
         press_src: '0_Empty.png',
         click_func: () => {
          vibro();
          hmApp.startApp({
           appid: apps[tap_1_select][3] == 0 ? '' : apps[tap_1_select][1],
           url: apps[tap_1_select][3] == 0 ? apps[tap_1_select][1] : apps[tap_1_select][4],
           native: apps[tap_1_select][3] == 0 ? true : '',
           params: apps[tap_1_select][3] == 0 ? '' : {
            from_wf: true,
           }
          });

         },
         show_level: hmUI.show_level.ONLY_NORMAL,
        });

        btn_Tap_zona_1 = groupTap.createWidget(hmUI.widget.BUTTON, {
         x: tap_x_y[1][0],
         y: tap_x_y[1][1],
         text: '',
         w: 113,
         h: 113,
         normal_src: '0_Empty.png',
         press_src: '0_Empty.png',
         click_func: () => {
          vibro();
          hmApp.startApp({
           appid: apps[tap_2_select][3] == 0 ? '' : apps[tap_2_select][1],
           url: apps[tap_2_select][3] == 0 ? apps[tap_2_select][1] : apps[tap_2_select][4],
           native: apps[tap_2_select][3] == 0 ? true : '',
           params: apps[tap_2_select][3] == 0 ? '' : {
            from_wf: true,
           }
          });
         },
         show_level: hmUI.show_level.ONLY_NORMAL,
        });

        btn_Tap_zona_2 = groupTap.createWidget(hmUI.widget.BUTTON, {
         x: tap_x_y[2][0],
         y: tap_x_y[2][1],
         text: '',
         w: 113,
         h: 113,
         normal_src: '0_Empty.png',
         press_src: '0_Empty.png',
         click_func: () => {
          vibro();
          hmApp.startApp({
           appid: apps[tap_3_select][3] == 0 ? '' : apps[tap_3_select][1],
           url: apps[tap_3_select][3] == 0 ? apps[tap_3_select][1] : apps[tap_3_select][4],
           native: apps[tap_3_select][3] == 0 ? true : '',
           params: apps[tap_3_select][3] == 0 ? '' : {
            from_wf: true,
           }
          });
         },
         show_level: hmUI.show_level.ONLY_NORMAL,
        });

        btn_Tap_zona_3 = groupTap.createWidget(hmUI.widget.BUTTON, {
         x: tap_x_y[3][0],
         y: tap_x_y[3][1],
         text: '',
         w: 113,
         h: 113,
         normal_src: '0_Empty.png',
         press_src: '0_Empty.png',
         click_func: () => {
          vibro();
          hmApp.startApp({
           appid: apps[tap_4_select][3] == 0 ? '' : apps[tap_4_select][1],
           url: apps[tap_4_select][3] == 0 ? apps[tap_4_select][1] : apps[tap_4_select][4],
           native: apps[tap_4_select][3] == 0 ? true : '',
           params: apps[tap_4_select][3] == 0 ? '' : {
            from_wf: true,
           }
          });
         },
         show_level: hmUI.show_level.ONLY_NORMAL,
        });

        btn_Tap_zona_4 = groupTap.createWidget(hmUI.widget.BUTTON, {
         x: tap_x_y[4][0],
         y: tap_x_y[4][1],
         text: '',
         w: 113,
         h: 113,
         normal_src: '0_Empty.png',
         press_src: '0_Empty.png',
         click_func: () => {
          vibro();
          hmApp.startApp({
           appid: apps[tap_5_select][3] == 0 ? '' : apps[tap_5_select][1],
           url: apps[tap_5_select][3] == 0 ? apps[tap_5_select][1] : apps[tap_5_select][4],
           native: apps[tap_5_select][3] == 0 ? true : '',
           params: apps[tap_5_select][3] == 0 ? '' : {
            from_wf: true,
           }
          });
         },
         show_level: hmUI.show_level.ONLY_NORMAL,
        });

        btn_Tap_zona_5 = groupTap.createWidget(hmUI.widget.BUTTON, {
         x: tap_x_y[5][0],
         y: tap_x_y[5][1],
         text: '',
         w: 113,
         h: 113,
         normal_src: '0_Empty.png',
         press_src: '0_Empty.png',
         click_func: () => {
          vibro();
          hmApp.startApp({
           appid: apps[tap_6_select][3] == 0 ? '' : apps[tap_6_select][1],
           url: apps[tap_6_select][3] == 0 ? apps[tap_6_select][1] : apps[tap_6_select][4],
           native: apps[tap_6_select][3] == 0 ? true : '',
           params: apps[tap_6_select][3] == 0 ? '' : {
            from_wf: true,
           }
          });
         },
         show_level: hmUI.show_level.ONLY_NORMAL,
        });


        btn_tap = groupVremya.createWidget(hmUI.widget.BUTTON, {
         x: 183,
         y: 0,
         text: '',
         w: 100,
         h: 100,
         normal_src: '0_Empty.png',
         press_src: '0_Empty.png',
         click_func: () => {
          vibro();
          tap_run();
         },
         show_level: hmUI.show_level.ONLY_NORMAL,
        });

        btn_str = groupVremya.createWidget(hmUI.widget.BUTTON, {
         x: 183, //x кнопки
         y: 183, //y кнопки
         text: '',
         w: 100, //ширина кнопки
         h: 100, //высота кнопки
         normal_src: '0_Empty.png',
         press_src: '0_Empty.png',
         click_func: () => {
          vibro();
          click_Pogoda_on();
         },
         //           longpress_func: () => {
         //            vibro();
         //			   blok_btn_on();
         //           },
         show_level: hmUI.show_level.ONLY_NORMAL,
        });

        btn_Activ = groupVremya.createWidget(hmUI.widget.BUTTON, {
         x: 183, //x кнопки
         y: 366, //y кнопки
         text: '',
         w: 100, //ширина кнопки
         h: 100, //высота кнопки
         normal_src: '0_Empty.png',
         press_src: '0_Empty.png',
         click_func: () => {
          vibro();
          click_Activ_on();
         },
         //           longpress_func: () => {
         //            vibro();
         //			   blok_btn_on();
         //           },
         show_level: hmUI.show_level.ONLY_NORMAL,
        });

        btn_sleep = groupVremya.createWidget(hmUI.widget.BUTTON, {
         x: 366, //x кнопки
         y: 183, //y кнопки
         text: '',
         w: 100, //ширина кнопки
         h: 100, //высота кнопки
         normal_src: '0_Empty.png',
         press_src: '0_Empty.png',
         click_func: () => {
          vibro();
          click_sleep();
         },
         //         longpress_func: () => {
         //          vibro();
         //          setTimeout(() => {
         //           //launchApp({ appId: mini_app_id, url: 'page/index' });
         //           hmApp.startApp({
         //            appid: mini_app_id,
         //            url: 'page/index'
         //           });
         //          }, 100);
         //         },
         show_level: hmUI.show_level.ONLY_NORMAL,
        });

        btn_weather_update = groupVremya.createWidget(hmUI.widget.BUTTON, {
         x: 390, //x кнопки
         y: 284, //y кнопки
         text: '',
         w: 66, //ширина кнопки
         h: 66, //высота кнопки
         normal_src: '0_Empty.png',
         press_src: '0_Empty.png',
         click_func: () => {
          vibro();
          setTimeout(() => {
           //launchApp({ appId: mini_app_id, url: 'page/index' });
           hmApp.startApp({
            appid: mini_app_id,
            url: 'page/index'
           });
          }, 100);
         },
         longpress_func: () => {
          vibro();
          setTimeout(() => {
           //launchApp({ appId: mini_app_id, url: 'page/index' });
           hmApp.startApp({
            appid: mini_app_id,
            url: 'page/index'
           });
          }, 100);
         },
         show_level: hmUI.show_level.ONLY_NORMAL,
        });


        btn_click_tap_exit = groupTap.createWidget(hmUI.widget.BUTTON, {
         x: 183,
         y: 183,
         text: '',
         w: 100,
         h: 100,
         normal_src: '0_Empty.png',
         press_src: '0_Empty.png',
         click_func: () => {
          vibro();
          tap_zona_exit();
         },
         show_level: hmUI.show_level.ONLY_NORMAL,
        });


        groupSleep = hmUI.createWidget(hmUI.widget.GROUP, {
         x: 0,
         y: 0,
         w: D_W,
         h: D_H,
        }); // ы


        normal_Sleep_bg = groupSleep.createWidget(hmUI.widget.FILL_RECT, {
         x: 72,
         y: 99,
         w: 322,
         h: 200,
         color: 0x000000,
         radius: 20,
         alpha: 178,
         show_level: hmUI.show_level.ONLY_NORMAL,
        });


        sleep_time_txt = groupSleep.createWidget(hmUI.widget.TEXT, {
         x: 0, // координата X
         y: 108, // координата Y
         w: 466, // ширина 	
         h: 40, // высота	
         text_size: 33, // размер текста
         text: '',
         font: 'fonts/Bebas11.ttf',
         color: 0xffffff, // цвет текста
         align_h: hmUI.align.CENTER_H,
         show_level: hmUI.show_level.ONLY_NORMAL,
        });

        groupSleep.createWidget(hmUI.widget.TEXT, {
         x: 103, // координата X
         y: 144, // координата Y
         w: 466, // ширина 	
         h: 40, // высота	
         text_size: 33, // размер текста
         text: 'ЗАСНУЛИ',
         font: 'fonts/Bebas11.ttf',
         color: 0x00ff00, // цвет текста
         align_h: hmUI.align.LEFT,
         show_level: hmUI.show_level.ONLY_NORMAL,
        });

        groupSleep.createWidget(hmUI.widget.TEXT, {
         x: -105, // координата X
         y: 144, // координата Y
         w: 466, // ширина 	
         h: 40, // высота	
         text_size: 33, // размер текста
         text: 'ПРОСНУЛИСЬ',
         font: 'fonts/Bebas11.ttf',
         color: 0xe779ff, // цвет текста
         align_h: hmUI.align.RIGHT,
         show_level: hmUI.show_level.ONLY_NORMAL,
        });


        sleep_start_time_txt = groupSleep.createWidget(hmUI.widget.TEXT, {
         x: 103,
         y: 181,
         w: 466, // ширина 	
         h: 40,
         text_size: 33,
         text: '',
         font: 'fonts/Bebas11.ttf',
         color: 0x00ff00,
         align_h: hmUI.align.LEFT,
         show_level: hmUI.show_level.ONLY_NORMAL,
        });


        sleep_end_time_txt = groupSleep.createWidget(hmUI.widget.TEXT, {
         x: -105, // координата X
         y: 181,
         w: 466, // ширина 	
         h: 40,
         text_size: 33,
         text: '',
         font: 'fonts/Bebas11.ttf',
         color: 0xe779ff,
         align_h: hmUI.align.RIGHT,
         show_level: hmUI.show_level.ONLY_NORMAL,
        });

        wake_time_txt = groupSleep.createWidget(hmUI.widget.TEXT, {
         x: 0,
         y: 217,
         w: 466,
         h: 40,
         text_size: 33,
         font: 'fonts/Bebas11.ttf',
         text: '',
         color: 0xff4949,
         align_h: hmUI.align.CENTER_H,
         show_level: hmUI.show_level.ONLY_NORMAL,
        });

        sleep_score_txt = groupSleep.createWidget(hmUI.widget.TEXT, {
         x: 0,
         y: 256,
         w: 466,
         h: 40,
         text_size: 33,
         font: 'fonts/Bebas11.ttf',
         text: '',
         color: 0xffffff,
         align_h: hmUI.align.CENTER_H,
         show_level: hmUI.show_level.ONLY_NORMAL,
        });


        btn_exit_sleep = groupSleep.createWidget(hmUI.widget.BUTTON, {
         x: 0, //x кнопки
         y: 0, //y кнопки
         text: '',
         w: 466, //ширина кнопки
         h: 466, //высота кнопки
         normal_src: '0_Empty.png',
         press_src: '0_Empty.png',
         click_func: () => {
          vibro();
          click_exit_sleep();
         },
         //           longpress_func: () => {
         //            vibro();
         //			   blok_btn_on();
         //           },
         show_level: hmUI.show_level.ONLY_NORMAL,
        });

        normal_background_Pogoda = hmUI.createWidget(hmUI.widget.FILL_RECT, {
         x: 0,
         y: 0,
         w: 466,
         h: 466,
         color: 0x000000,
         show_level: hmUI.show_level.ONLY_NORMAL,
        });

        normal_background_Pogoda.setProperty(hmUI.prop.VISIBLE, false);


        //---------------------------    погода
        groupPogoda = hmUI.createWidget(hmUI.widget.GROUP, {
         x: 0,
         y: 0,
         w: D_W,
         h: D_H,
         show_level: hmUI.show_level.ONLY_NORMAL,
        });


        canvas = groupPogoda.createWidget(hmUI.widget.CANVAS, {
         x: 0,
         y: 0,
         w: 466,
         h: 466,
         show_level: hmUI.show_level.ONLY_NORMAL,
        });

        canvas.setPaint({
         color: 0x00ff00,
         line_width: 4
        })


        normal_temp_text_font = groupPogoda.createWidget(hmUI.widget.TEXT, {
         x: 115,
         y: 47 + 5 + 6 + 2 - 29 - 29,
         w: 236,
         h: 32,
         text_size: 27,
         char_space: 0,
         line_space: 0,
         font: 'fonts/Bebas11.ttf',
         color: 0xFFFFFFFF,
         align_h: hmUI.align.CENTER_H,
         align_v: hmUI.align.CENTER_V,
         text_style: hmUI.text_style.NONE,
         show_level: hmUI.show_level.ONLY_NORMAL,
        })

        normal_weather_text_font = groupPogoda.createWidget(hmUI.widget.TEXT, {
         x: 115,
         y: 47 + 5 + 6 + 2 - 29,
         w: 236,
         h: 32,
         text_size: 27,
         char_space: 0,
         line_space: 0,
         font: 'fonts/Bebas11.ttf',
         color: 0xFFFFFFFF,
         align_h: hmUI.align.CENTER_H,
         align_v: hmUI.align.CENTER_V,
         text_style: hmUI.text_style.NONE,
         show_level: hmUI.show_level.ONLY_NORMAL,
        })

        normal_city_name_text_0 = groupPogoda.createWidget(hmUI.widget.TEXT, {
         x: 74,
         y: 47 + 5 + 6 + 2,
         w: 318,
         h: 32,
         text_size: 27,
         char_space: 0,
         line_space: 0,
         font: 'fonts/Bebas11.ttf',
         color: 0xFFFFFFFF,
         align_h: hmUI.align.CENTER_H,
         align_v: hmUI.align.CENTER_V,
         text_style: hmUI.text_style.NONE,
         show_level: hmUI.show_level.ONLY_NORMAL,
        });


        ic_graf_img = groupPogoda.createWidget(hmUI.widget.IMG, {
         x: 414,
         y: 212,
         src: 'images/Grafik/ic_graf_0.png',
         show_level: hmUI.show_level.ONLY_NORMAL,
        });

        ic_lexxir_img = groupPogoda.createWidget(hmUI.widget.IMG, {
         x: 10,
         y: 212,
         src: 'images/Grafik/ic_lexxir.png',
         show_level: hmUI.show_level.ONLY_NORMAL,
        });

        line_up_grafic = groupPogoda.createWidget(hmUI.widget.TEXT, {
         x: 0,
         y: 353 - 4,
         w: 466,
         h: 40,
         color: 0xffffff,
         font: 'fonts/Bebas11.ttf',
         text_size: 35,
         align_h: hmUI.align.CENTER_H,
         align_v: hmUI.align.CENTER_V,
         text_style: hmUI.text_style.NONE,
         text: "--",
        });

        line_down_grafic = groupPogoda.createWidget(hmUI.widget.TEXT, {
         x: 0,
         y: 399,
         w: 466,
         h: 40,
         color: 0xffffff,
         font: 'fonts/Bebas11.ttf',
         text_size: 35,
         align_h: hmUI.align.CENTER_H,
         align_v: hmUI.align.CENTER_V,
         text_style: hmUI.text_style.NONE,
         text: "--",
        });

        line_up_grafic_comment = groupPogoda.createWidget(hmUI.widget.TEXT, {
         x: 0,
         y: 374,
         w: 466,
         h: 40,
         text: 'ВЛАЖНОСТЬ | ВЕТЕР(ПОРЫВЫ) | ДАВЛЕНИЕ',
         //font: 'fonts/Bebas11.ttf',
         text_size: 15,
         char_space: 0,
         line_space: 0,
         color: 0xFF9A9A9A,
         align_h: hmUI.align.CENTER_H,
         align_v: hmUI.align.CENTER_V,
         //unit_type: 1,
         text_style: hmUI.text_style.ELLIPSIS,
         //type: hmUI.data_type.WIND,
         show_level: hmUI.show_level.ONLY_NORMAL,
        });

        line_down_grafic_comment = groupPogoda.createWidget(hmUI.widget.TEXT, {
         x: 0,
         y: 419 + 4,
         w: 466,
         h: 40,
         text: 'ВИД | СВЕТЛО | ТУЧИ',
         //font: 'fonts/Bebas11.ttf',
         text_size: 15,
         char_space: 0,
         line_space: 0,
         color: 0xFF9A9A9A,
         align_h: hmUI.align.CENTER_H,
         align_v: hmUI.align.CENTER_V,
         //unit_type: 1,
         text_style: hmUI.text_style.ELLIPSIS,
         //type: hmUI.data_type.WIND,
         show_level: hmUI.show_level.ONLY_NORMAL,
        });


        /*        WIND_grafic = groupPogoda.createWidget(hmUI.widget.TEXT, {
                 x: 157,
                 y: 353,
                 w: 150,
                 h: 40,
                 font: 'fonts/Bebas11.ttf',
                 text_size: 27,
                 char_space: 0,
                 line_space: 0,
                 color: 0xFFFFFFFF,
                 align_h: hmUI.align.CENTER_H,
                 align_v: hmUI.align.CENTER_V,
                 //unit_type: 1,
                 text_style: hmUI.text_style.ELLIPSIS,
                 //type: hmUI.data_type.WIND,
                 show_level: hmUI.show_level.ONLY_NORMAL,
                });
        		   
                WIND_porivi_grafic = groupPogoda.createWidget(hmUI.widget.TEXT, {
                 x: 157,
                 y: 378,
                 w: 150,
                 h: 40,
                 font: 'fonts/Bebas11.ttf',
                 text_size: 27,
                 char_space: 0,
                 line_space: 0,
                 color: 0xFF9A9A9A,
                 align_h: hmUI.align.CENTER_H,
                 align_v: hmUI.align.CENTER_V,
                 //unit_type: 1,
                 text_style: hmUI.text_style.ELLIPSIS,
                 //type: hmUI.data_type.WIND,
                 show_level: hmUI.show_level.ONLY_NORMAL,
                });
        		   
                vidimost_grafic = groupPogoda.createWidget(hmUI.widget.TEXT, {
                 x: 97,
                 y: 387,
                 w: 150,
                 h: 40,
                 font: 'fonts/Bebas11.ttf',
                 text_size: 27,
                 char_space: 0,
                 line_space: 0,
                 color: 0xFFFFFFFF,
                 align_h: hmUI.align.CENTER_H,
                 align_v: hmUI.align.CENTER_V,
                 //unit_type: 1,
                 text_style: hmUI.text_style.ELLIPSIS,
                 //type: hmUI.data_type.WIND,
                 show_level: hmUI.show_level.ONLY_NORMAL,
                });	
        		   
                vidimost_grafic_unit = groupPogoda.createWidget(hmUI.widget.TEXT, {
                 x: 80,
                 y: 410,
                 w: 150,
                 h: 40,
                // text: 'КМ',
                 //font: 'fonts/Bebas11.ttf',
                 text_size: 16,
                 char_space: 0,
                 line_space: 0,
                 color: 0xFF9A9A9A,
                 align_h: hmUI.align.CENTER_H,
                 align_v: hmUI.align.CENTER_V,
                 //unit_type: 1,
                 text_style: hmUI.text_style.ELLIPSIS,
                 //type: hmUI.data_type.WIND,
                 show_level: hmUI.show_level.ONLY_NORMAL,
                });	
        		   
                oblaka_grafic_unit = groupPogoda.createWidget(hmUI.widget.TEXT, {
                 x: 240,
                 y: 410,
                 w: 150,
                 h: 40,
                 text: '%',
                 //font: 'fonts/Bebas11.ttf',
                 text_size: 20,
                 char_space: 0,
                 line_space: 0,
                 color: 0xFF9A9A9A,
                 align_h: hmUI.align.CENTER_H,
                 align_v: hmUI.align.CENTER_V,
                 //unit_type: 1,
                 text_style: hmUI.text_style.ELLIPSIS,
                 //type: hmUI.data_type.WIND,
                 show_level: hmUI.show_level.ONLY_NORMAL,
                });	
        		   
        		   
                oblaka_grafic = groupPogoda.createWidget(hmUI.widget.TEXT, {
                 x: 223,
                 y: 387,
                 w: 150,
                 h: 40,
                 font: 'fonts/Bebas11.ttf',
                 text_size: 27,
                 char_space: 0,
                 line_space: 0,
                 color: 0xFFFFFFFF,
                 align_h: hmUI.align.CENTER_H,
                 align_v: hmUI.align.CENTER_V,
                 //unit_type: 1,
                 text_style: hmUI.text_style.ELLIPSIS,
                 //type: hmUI.data_type.WIND,
                 show_level: hmUI.show_level.ONLY_NORMAL,
                });	
        		
                pressure_grafic = groupPogoda.createWidget(hmUI.widget.TEXT, {
                 x: 260-5,
                 y: 356,
                 w: 150,
                 h: 40,
                 color: 0xffffff,
                 font: 'fonts/Bebas11.ttf',
                 text_size: 35,
                 align_h: hmUI.align.CENTER_H,
                 align_v: hmUI.align.CENTER_V,
                 text_style: hmUI.text_style.NONE,
                 text: "--",
                });		
        		   
                svetovoi_den_grafic = groupPogoda.createWidget(hmUI.widget.TEXT, {
                 x: 143,
                 y: 421,
                 w: 150,
                 h: 40,
                 font: 'fonts/Bebas11.ttf',
                 text_size: 27,
                 char_space: 0,
                 line_space: 0,
                 color: 0xFFFFFFFF,
                 align_h: hmUI.align.CENTER_H,
                 align_v: hmUI.align.CENTER_V,
                 //unit_type: 1,
                 text_style: hmUI.text_style.ELLIPSIS,
                 //type: hmUI.data_type.WIND,
                 show_level: hmUI.show_level.ONLY_NORMAL,
                });	*/


        /*       groupPogoda.createWidget(hmUI.widget.IMG, {
                 x: 356,
                 y: 364,
                 src: ROOTPATH + 'Grafik/ic_activ/ic_davlenie.png',
                 show_level: hmUI.show_level.ONLY_NORMAL,
                });
        		   
                groupPogoda.createWidget(hmUI.widget.IMG, {
                 x: 74,
                 y: 361,
                 src: ROOTPATH + 'Grafik/ic_activ/ic_vlagnost.png',
                 show_level: hmUI.show_level.ONLY_NORMAL,
                });
        		   
                groupPogoda.createWidget(hmUI.widget.IMG, {
                 x: 315,
                 y: 396,
                 src: ROOTPATH + 'Grafik/ic_activ/ic_oblaka.png',
                 show_level: hmUI.show_level.ONLY_NORMAL,
                });

        		 groupPogoda.createWidget(hmUI.widget.IMG, {
                 x: 253,
                 y: 429,
                 src: ROOTPATH + 'Grafik/ic_activ/ic_svetovoi_den.png',
                 show_level: hmUI.show_level.ONLY_NORMAL,
                });

        		 groupPogoda.createWidget(hmUI.widget.IMG, {
                 x: 112,
                 y: 396,
                 src: ROOTPATH + 'Grafik/ic_activ/ic_vidimost.png',
                 show_level: hmUI.show_level.ONLY_NORMAL,
                });*/

        groupPogoda.createWidget(hmUI.widget.IMG, {
         x: 420,
         y: 171,
         src: ROOTPATH + 'Grafik/ic_activ/ic_visota.png',
         show_level: hmUI.show_level.ONLY_NORMAL,
        });

        groupPogoda.createWidget(hmUI.widget.IMG, {
         x: 16,
         y: 171,
         src: ROOTPATH + 'Grafik/ic_activ/ic_uv.png',
         show_level: hmUI.show_level.ONLY_NORMAL,
        });


        groupPogoda.createWidget(hmUI.widget.TEXT_FONT, {
         x: -43,
         y: 265 + 5,
         w: 150,
         h: 30,
         text_size: 27,
         font: 'fonts/Bebas11.ttf',
         char_space: 0,
         line_space: 0,
         color: 0xFFFFFFFF,
         align_h: hmUI.align.CENTER_H,
         align_v: hmUI.align.CENTER_V,
         text_style: hmUI.text_style.ELLIPSIS,
         type: hmUI.data_type.UVI,
         show_level: hmUI.show_level.ONLY_NORMAL,
        });

        groupPogoda.createWidget(hmUI.widget.TEXT_FONT, {
         x: 359,
         y: 265 + 5,
         w: 150,
         h: 30,
         text_size: 27,
         font: 'fonts/Bebas11.ttf',
         char_space: 0,
         line_space: 0,
         color: 0xFFFFFFFF,
         align_h: hmUI.align.CENTER_H,
         align_v: hmUI.align.CENTER_V,
         text_style: hmUI.text_style.ELLIPSIS,
         type: hmUI.data_type.ALTITUDE,
         show_level: hmUI.show_level.ONLY_NORMAL,
        });


        //        groupPogoda.createWidget(hmUI.widget.TEXT_FONT, {
        //         x: 56,
        //         y: 356,
        //         w: 150,
        //         h: 40,
        //         text_size: 35,
        //         char_space: 0,
        //         line_space: 0,
        //         color: 0xFFFFFFFF,
        //         font: 'fonts/Bebas11.ttf',
        //         align_h: hmUI.align.CENTER_H,
        //         align_v: hmUI.align.CENTER_V,
        //         unit_type: 1,
        //         text_style: hmUI.text_style.ELLIPSIS,
        //         type: hmUI.data_type.HUMIDITY,
        //         show_level: hmUI.show_level.ONLY_NORMAL,
        //        });


        for (var i = 0; i < daysNum; i++) {
         week_text[i] = groupPogoda.createWidget(hmUI.widget.TEXT, {
          x: x0 - 3 - 23 + i * 46 * 1.0, //,107 + i * 45 * 1.02,
          y: 295 - 1 + 2, //- 21
          w: 50,
          h: 50,
          char_space: 0, //-1
          line_space: 0,
          color: "0xFFffffff",
          text: week_array[i],
          text_size: 22,
          text_style: hmUI.text_style.NONE,
          align_h: hmUI.align.CENTER_H,
          align_v: hmUI.align.CENTER_V,
          show_level: hmUI.show_level.ONLY_NORMAL
         });
         // hmUI.deleteWidget(data_text[i]);
         data_text[i] = groupPogoda.createWidget(hmUI.widget.TEXT, {
          x: x0 - 3 - 23 + i * 46 * 1.0, //,107 + i * 45 * 1.02,
          y: 295 - 1 + 2 + 20, //- 21
          w: 50,
          h: 50,
          char_space: 0, //-1
          line_space: 0,
          color: "0xFFffffff",
          text: 31,
          text_size: 22,
          text_style: hmUI.text_style.NONE,
          align_h: hmUI.align.CENTER_H,
          align_v: hmUI.align.CENTER_V,
          show_level: hmUI.show_level.ONLY_NORMAL
         });

         weather_ic[i] = groupPogoda.createWidget(hmUI.widget.IMG, {
          x: x0 - 23 + i * shag,
          y: 78 + 10, //- 10
          w: 40,
          h: 40,
          // src: weatherArray[i],
          shortcut: true,
          show_level: hmUI.show_level.ONLY_NORMAL,
         });

         DigDay[i] = groupPogoda.createWidget(hmUI.widget.TEXT);
         if (i < daysNum - 1) DigNight[i] = groupPogoda.createWidget(hmUI.widget.TEXT);
        }


        btn_Pogoda_off = groupPogoda.createWidget(hmUI.widget.BUTTON, {
         x: 183, //x кнопки
         y: 183, //y кнопки
         text: '',
         w: 100, //ширина кнопки
         h: 100, //высота кнопки
         normal_src: '0_Empty.png',
         press_src: 'press_100.png',
         click_func: () => {
          vibro(); //имя вызываемой функции
          click_Pogoda_off();
         },
         //           longpress_func: () => {
         //            vibro();
         //			   blok_btn_off();
         //           },
         show_level: hmUI.show_level.ONLY_NORMAL,
        });

        btn_tip_grafik = groupPogoda.createWidget(hmUI.widget.BUTTON, {
         x: 366, //x кнопки
         y: 183, //y кнопки
         text: '',
         w: 100, //ширина кнопки
         h: 100, //высота кнопки
         normal_src: '0_Empty.png',
         press_src: 'press_100.png',
         click_func: () => {
          vibro(); //имя вызываемой функции
          click_tip_grafik();
         },
         //           longpress_func: () => {
         //            vibro();
         //			   blok_btn_off();
         //           },
         show_level: hmUI.show_level.ONLY_NORMAL,
        });

        groupPogoda.createWidget(hmUI.widget.BUTTON, {
         x: 0,
         y: 183,
         w: 100,
         h: 100,
         text: '',
         normal_src: 'blank.png',
         press_src: 'blank.png',
         click_func: () => {
          hmApp.startApp({
           appid: 1051195,
           url: 'page/index',
           params: {
            from_wf: true,
           }

          });
         },
        });

        groupActiv = hmUI.createWidget(hmUI.widget.GROUP, {
         x: 0,
         y: 0,
         w: D_W,
         h: D_H,
        });


        groupActiv.createWidget(hmUI.widget.IMG, {
         x: 0,
         y: 0,
         w: 466,
         h: 466,
         src: 'images/Grafik/bg_activ.png',
         show_level: hmUI.show_level.ONLY_NORMAL,
        });

        Activ_color_alpha = groupActiv.createWidget(hmUI.widget.CIRCLE, {
         center_x: 233,
         center_y: 233,
         radius: 233,
         color: color_bg_Activ[color_ic],
         alpha: color_ic == 0 ? 0 : 255,
         show_level: hmUI.show_level.ONLY_NORMAL,
        });

        groupActiv.createWidget(hmUI.widget.IMG, {
         x: 0,
         y: 0,
         w: 466,
         h: 466,
         src: 'images/Grafik/bg_activ_mask.png',
         show_level: hmUI.show_level.ONLY_NORMAL,
        });

        WEATHER_HIGH_LOW_Activ = groupActiv.createWidget(hmUI.widget.TEXT, {
         x: 216,
         y: 192,
         w: 150,
         h: 40,
         text_size: 37,
         char_space: 0,
         line_space: 0,
         color: 0xFFFFFFFF,
         align_h: hmUI.align.CENTER_H,
         align_v: hmUI.align.CENTER_V,
         text_style: hmUI.text_style.ELLIPSIS,
         // type: hmUI.data_type.WEATHER_HIGH_LOW,
         show_level: hmUI.show_level.ONLY_NORMAL,
        });

        groupActiv.createWidget(hmUI.widget.TEXT_FONT, {
         x: 157,
         y: 359,
         w: 150,
         h: 40,
         text_size: 37,
         char_space: 0,
         line_space: 0,
         color: 0xFFFFFFFF,
         align_h: hmUI.align.CENTER_H,
         align_v: hmUI.align.CENTER_V,
         text_style: hmUI.text_style.ELLIPSIS,
         type: hmUI.data_type.DISTANCE,
         show_level: hmUI.show_level.ONLY_NORMAL,
        });

        groupActiv.createWidget(hmUI.widget.TEXT_FONT, {
         x: 260,
         y: 70,
         w: 150,
         h: 40,
         text_size: 37,
         char_space: 0,
         line_space: 0,
         color: 0xFFFFFFFF,
         align_h: hmUI.align.CENTER_H,
         align_v: hmUI.align.CENTER_V,
         text_style: hmUI.text_style.ELLIPSIS,
         type: hmUI.data_type.PAI_WEEKLY,
         show_level: hmUI.show_level.ONLY_NORMAL,
        });

        normal_vos_icon_img = groupActiv.createWidget(hmUI.widget.IMG, {
         x: 276,
         y: 254,
         src: 'images/Grafik/ic_activ/ic_vos.png',
         show_level: hmUI.show_level.ONLY_NORMAL,
        });

        normal_zak_icon_img = groupActiv.createWidget(hmUI.widget.IMG, {
         x: 276,
         y: 254,
         src: 'images/Grafik/ic_activ/ic_zak.png',
         show_level: hmUI.show_level.ONLY_NORMAL,
        });

        normal_zak_text_font = groupActiv.createWidget(hmUI.widget.TEXT, {
         x: 223,
         y: 308,
         w: 150,
         h: 40,
         text_size: 37,
         char_space: 0,
         line_space: 0,
         color: 0xFFFFFFFF,
         align_h: hmUI.align.CENTER_H,
         align_v: hmUI.align.CENTER_V,
         text_style: hmUI.text_style.ELLIPSIS,
         // type: hmUI.data_type.SUN_SET,
         show_level: hmUI.show_level.ONLY_NORMAL,
        });

        normal_vos_text_font = groupActiv.createWidget(hmUI.widget.TEXT, {
         x: 223,
         y: 308,
         w: 150,
         h: 40,
         text_size: 37,
         char_space: 0,
         line_space: 0,
         color: 0xFFFFFFFF,
         align_h: hmUI.align.CENTER_H,
         align_v: hmUI.align.CENTER_V,
         text_style: hmUI.text_style.ELLIPSIS,
         // type: hmUI.data_type.SUN_RISE,
         show_level: hmUI.show_level.ONLY_NORMAL,
        });


        groupActiv.createWidget(hmUI.widget.TEXT_FONT, {
         x: 157,
         y: 70,
         w: 150,
         h: 40,
         text_size: 37,
         char_space: 0,
         line_space: 0,
         color: 0xFFFFFFFF,
         padding: true,
         align_h: hmUI.align.CENTER_H,
         align_v: hmUI.align.CENTER_V,
         text_style: hmUI.text_style.ELLIPSIS,
         type: hmUI.data_type.ALARM_CLOCK,
         show_level: hmUI.show_level.ONLY_NORMAL,
        });

        groupActiv.createWidget(hmUI.widget.TEXT_FONT, {
         x: 51,
         y: 385,
         w: 150,
         h: 40,
         text_size: 37,
         char_space: 0,
         line_space: 0,
         color: 0xFFFFFFFF,
         align_h: hmUI.align.CENTER_H,
         align_v: hmUI.align.CENTER_V,
         text_style: hmUI.text_style.ELLIPSIS,
         type: hmUI.data_type.SPO2,
         show_level: hmUI.show_level.ONLY_NORMAL,
        });

        groupActiv.createWidget(hmUI.widget.TEXT_FONT, {
         x: 333,
         y: 308,
         w: 150,
         h: 40,
         text_size: 37,
         char_space: 0,
         line_space: 0,
         color: 0xFFFFFFFF,
         align_h: hmUI.align.CENTER_H,
         align_v: hmUI.align.CENTER_V,
         text_style: hmUI.text_style.ELLIPSIS,
         type: hmUI.data_type.STRESS,
         show_level: hmUI.show_level.ONLY_NORMAL,
        });

        groupActiv.createWidget(hmUI.widget.ARC_PROGRESS, {
         center_x: 407,
         center_y: 166,
         start_angle: -135,
         end_angle: 135,
         radius: 39,
         line_width: 10,
         corner_flag: 3,
         color: 0xFFFFFFFF,
         type: hmUI.data_type.STAND,

         show_level: hmUI.show_level.ONLY_NORMAL,
        });

        groupActiv.createWidget(hmUI.widget.TEXT_FONT, {
         x: 333,
         y: 192,
         w: 150,
         h: 40,
         text_size: 37,
         char_space: 0,
         line_space: 0,
         color: 0xFFFFFFFF,
         align_h: hmUI.align.CENTER_H,
         align_v: hmUI.align.CENTER_V,
         text_style: hmUI.text_style.ELLIPSIS,
         type: hmUI.data_type.STAND,
         show_level: hmUI.show_level.ONLY_NORMAL,
        });

        groupActiv.createWidget(hmUI.widget.ARC_PROGRESS, {
         center_x: 180,
         center_y: 280,
         start_angle: -135,
         end_angle: 135,
         radius: 39,
         line_width: 10,
         corner_flag: 3,
         color: 0xFFFFFFFF,
         type: hmUI.data_type.STEP,
         show_level: hmUI.show_level.ONLY_NORMAL,
        });

        groupActiv.createWidget(hmUI.widget.TEXT_FONT, {
         x: 260,
         y: 385,
         w: 150,
         h: 40,
         text_size: 37,
         char_space: 0,
         line_space: 0,
         //padding: true,
         color: 0xFFFFFFFF,
         align_h: hmUI.align.CENTER_H,
         align_v: hmUI.align.CENTER_V,
         text_style: hmUI.text_style.ELLIPSIS,
         type: hmUI.data_type.FLOOR,
         show_level: hmUI.show_level.ONLY_NORMAL,
        });

        groupActiv.createWidget(hmUI.widget.TEXT_FONT, {
         x: 99,
         y: 308,
         w: 150,
         h: 40,
         text_size: 37,
         char_space: 0,
         line_space: 0,
         color: 0xFFFFFFFF,
         align_h: hmUI.align.CENTER_H,
         align_v: hmUI.align.CENTER_V,
         text_style: hmUI.text_style.ELLIPSIS,
         type: hmUI.data_type.STEP,
         show_level: hmUI.show_level.ONLY_NORMAL,
        });

        WEATHER_CURRENT_Activ = groupActiv.createWidget(hmUI.widget.ARC_PROGRESS, {
         center_x: 175 + 116,
         center_y: 166,
         start_angle: -135,
         end_angle: 135,
         radius: 39,
         line_width: 10,
         corner_flag: 3,
         color: 0xFFFFFFFF,
         // type: hmUI.data_type.WEATHER_CURRENT,
         show_level: hmUI.show_level.ONLY_NORMAL,
        });

        groupActiv.createWidget(hmUI.widget.ARC_PROGRESS, {
         center_x: 175 + 116 + 116,
         center_y: 166 + 116,
         start_angle: -135,
         end_angle: 135,
         radius: 39,
         line_width: 10,
         corner_flag: 3,
         color: 0xFFFFFFFF,
         type: hmUI.data_type.STRESS,
         show_level: hmUI.show_level.ONLY_NORMAL,
        });

        SUN_CURRENT_Activ = groupActiv.createWidget(hmUI.widget.ARC_PROGRESS, {
         center_x: 175 + 116 + 7,
         center_y: 166 + 116,
         start_angle: -135,
         end_angle: 135,
         radius: 39,
         line_width: 10,
         corner_flag: 3,
         color: 0xFFFFFFFF,
         // type: hmUI.data_type.SUN_CURRENT,
         show_level: hmUI.show_level.ONLY_NORMAL,
        });

        groupActiv.createWidget(hmUI.widget.ARC_PROGRESS, {
         center_x: 175,
         center_y: 166,
         start_angle: -135,
         end_angle: 135,
         radius: 39,
         line_width: 10,
         corner_flag: 3,
         color: 0xFFFFFFFF,
         type: hmUI.data_type.HEART,
         show_level: hmUI.show_level.ONLY_NORMAL,
        });

        groupActiv.createWidget(hmUI.widget.TEXT_FONT, {
         x: 99,
         y: 192,
         w: 150,
         h: 40,
         text_size: 37,
         char_space: 0,
         line_space: 0,
         color: 0xFFFFFFFF,
         align_h: hmUI.align.CENTER_H,
         align_v: hmUI.align.CENTER_V,
         text_style: hmUI.text_style.ELLIPSIS,
         type: hmUI.data_type.HEART,
         show_level: hmUI.show_level.ONLY_NORMAL,
        });

        groupActiv.createWidget(hmUI.widget.ARC_PROGRESS, {
         center_x: 59,
         center_y: 282,
         start_angle: -135,
         end_angle: 135,
         radius: 39,
         line_width: 10,
         corner_flag: 3,
         color: 0xFFFFFFFF,
         type: hmUI.data_type.FAT_BURNING,
         show_level: hmUI.show_level.ONLY_NORMAL,
        });

        groupActiv.createWidget(hmUI.widget.TEXT_FONT, {
         x: -17,
         y: 308,
         w: 150,
         h: 40,
         text_size: 37,
         char_space: 0,
         line_space: 0,
         color: 0xFFFFFFFF,
         align_h: hmUI.align.CENTER_H,
         align_v: hmUI.align.CENTER_V,
         text_style: hmUI.text_style.ELLIPSIS,
         type: hmUI.data_type.FAT_BURNING,
         show_level: hmUI.show_level.ONLY_NORMAL,
        });

        groupActiv.createWidget(hmUI.widget.ARC_PROGRESS, {
         center_x: 59,
         center_y: 166,
         start_angle: -135,
         end_angle: 135,
         radius: 39,
         line_width: 10,
         corner_flag: 3,
         color: 0xFFFFFFFF,
         type: hmUI.data_type.CAL,
         show_level: hmUI.show_level.ONLY_NORMAL,
        });

        groupActiv.createWidget(hmUI.widget.TEXT_FONT, {
         x: 51,
         y: 70,
         w: 150,
         h: 40,
         text_size: 37,
         char_space: 0,
         line_space: 0,
         padding: true,
         color: 0xFFFFFFFF,
         align_h: hmUI.align.CENTER_H,
         align_v: hmUI.align.CENTER_V,
         text_style: hmUI.text_style.ELLIPSIS,
         type: hmUI.data_type.COUNT_DOWN,
         show_level: hmUI.show_level.ONLY_NORMAL,
        });

        groupActiv.createWidget(hmUI.widget.TEXT_FONT, {
         x: -17,
         y: 192,
         w: 150,
         h: 40,
         text_size: 37,
         char_space: 0,
         line_space: 0,
         color: 0xFFFFFFFF,
         align_h: hmUI.align.CENTER_H,
         align_v: hmUI.align.CENTER_V,
         text_style: hmUI.text_style.ELLIPSIS,
         type: hmUI.data_type.CAL,
         show_level: hmUI.show_level.ONLY_NORMAL,
        });

        ic_activ_color_off_img = groupActiv.createWidget(hmUI.widget.IMG, {
         x: 363,
         y: 346,
         src: 'images/Grafik/ic_activ_color_off.png',
         show_level: hmUI.show_level.ONLY_NORMAL,
        });
        ic_activ_color_off_img.setProperty(hmUI.prop.VISIBLE, Activ_color == 0);


        btn_Activ_off = groupActiv.createWidget(hmUI.widget.BUTTON, {
         x: 183, //x кнопки
         y: 183, //y кнопки
         text: '',
         w: 100, //ширина кнопки
         h: 100, //высота кнопки
         normal_src: '0_Empty.png',
         press_src: 'press_100.png',
         click_func: () => {
          vibro(); //имя вызываемой функции
          click_Activ_off();
         },
         show_level: hmUI.show_level.ONLY_NORMAL,
        });

        btn_Activ_color = groupActiv.createWidget(hmUI.widget.BUTTON, {
         x: 325, //x кнопки
         y: 303, //y кнопки
         text: '',
         w: 100, //ширина кнопки
         h: 100, //высота кнопки
         normal_src: '0_Empty.png',
         press_src: 'press_100.png',
         click_func: () => {
          vibro(); //имя вызываемой функции
          click_Activ_color();
         },
         show_level: hmUI.show_level.ONLY_NORMAL,
        });

        g_ACR_color = hmUI.createWidget(hmUI.widget.GROUP, {
         x: 0,
         y: 0,
         w: 466,
         h: 466,
        })

        //цвет	
        menu_ARC_PROGRES_bg = g_ACR_color.createWidget(hmUI.widget.ARC_PROGRESS, {
         center_x: 233,
         center_y: 233,
         start_angle: 60 - 15,
         end_angle: 120 + 15,
         radius: 219,
         line_width: 16,
         corner_flag: 0,
         color: 0xFF5b5b5b,
         level: 100,
         show_level: hmUI.show_level.ONLY_NORMAL,
        });

        menu_ARC_PROGRES = g_ACR_color.createWidget(hmUI.widget.ARC_PROGRESS, {
         center_x: 233,
         center_y: 233,
         start_angle: 45 + 90 / color_bg[0].length * (-Ar_Set[0][1] * 95), // start_angle: 45 + 90 / array * gde,
         end_angle: 135 + 90 / color_bg[0].length * (-Ar_Set[0][1] * 95), //end_angle: 135 + 90 / array * gde,
         radius: 219,
         line_width: 16,
         corner_flag: 0,
         color: 0xFF0000, //0xFF007eff
         level: 100 / color_bg[0].length, //level: pointer,
         show_level: hmUI.show_level.ONLY_NORMAL,
        });


        for (let j = 0; j < Ar_Set.length; j++) {
         for (let i = 0; i < color_bg[j].length; i++) {
          menu_ARC_color[j][i] = hmUI.createWidget(hmUI.widget.ARC_PROGRESS, {
           center_x: 233,
           center_y: 233,
           start_angle: 45 + 90 / color_bg[j].length * i,
           end_angle: 135 + 90 / color_bg[j].length * i,
           radius: 219 - 16,
           line_width: 16,
           corner_flag: 0,
           color: color_bg[j][i],
           level: 100 / color_bg[j].length,
           show_level: hmUI.show_level.ONLY_NORMAL,
          });
         };
        };


        for (let j = 0; j < Ar_Set.length; j++) {
         for (let i = 0; i < color_bg[j].length; i++) {
          menu_ARC_color[j][i].setProperty(hmUI.prop.VISIBLE, false);
         };
        };

        g_ACR_color.setProperty(hmUI.prop.VISIBLE, false);


        g_Set = hmUI.createWidget(hmUI.widget.GROUP, {
         x: 0,
         y: 0,
         w: 466,
         h: 466,
        })

        normal_background_Set = g_Set.createWidget(hmUI.widget.FILL_RECT, {
         x: 0,
         y: 0,
         w: 466,
         h: 466,
         color: 0x000000,
         // radius: 12,
         alpha: 153,
         show_level: hmUI.show_level.ONLY_NORMAL,
        });


        for (let i = 0; i < Ar_Set.length; i++) {
         Btn_set_[i] = g_Set.createWidget(hmUI.widget.BUTTON, {
          x: Ar_Set.length <= 5 ? 153 : i < Math.ceil(Ar_Set.length / 2) ? 70 : 233,
          y: Ar_Set.length <= 5 ? 70 + i * Shag_Y : i < Math.ceil(Ar_Set.length / 2) ? 70 + i * Shag_Y : 70 + i * Shag_Y - Shag_Y * Math.ceil(Ar_Set.length / 2),
          w: 160,
          h: 60,
          text: Ar_Set[i][0],
          char_space: 0,
          line_space: -35,
          color: 0xFFFFFFFF,
          text_size: 24,
          radius: 12,
          press_color: 0xFFFF0000,
          normal_color: i != crown ? 0x000000 : 0x800000,
          click_func: () => {
           vibro();
           click_crown(i);
           //crown == i

          },
          text_style: hmUI.text_style.WRAP,
          show_level: hmUI.show_level.ONLY_NORMAL,
         }); // end button
        };

        btn_Set_exit = g_Set.createWidget(hmUI.widget.BUTTON, {
         x: 203, //x кнопки
         y: 70 + Shag_Y * 5, //y кнопки
         w: 60,
         h: 60,
         text: "ОК",
         char_space: 0,
         line_space: -35,
         color: 0xFFFFFFFF,
         text_size: 24,
         radius: 12,
         press_color: 0xFFFF0000,
         normal_color: 0xFF000000,
         click_func: () => {
          vibro();
          click_Set_off();
         },
         text_style: hmUI.text_style.WRAP,
         show_level: hmUI.show_level.ONLY_NORMAL,
        });
        g_Set.setProperty(hmUI.prop.VISIBLE, false);

        /*        btn_app_right = groupVremya.createWidget(hmUI.widget.BUTTON, {
                 x: 293, //x кнопки
                 y: 62, //y кнопки
                 text: '',
                 w: 100, //ширина кнопки
                 h: 100, //высота кнопки
                 normal_src: '0_Empty.png',
                 press_src: '0_Empty.png',
                 click_func: () => {
                  vibro();
                  click_app_right();
                 },
                 //                    longpress_func: () => {
                 //                     vibro();
                 //         			   blok_btn_on();
                 //                    },
                 show_level: hmUI.show_level.ONLY_NORMAL,
                });*/


        btn_crown = groupVremya.createWidget(hmUI.widget.BUTTON, {
         x: 307, //x кнопки
         y: 61, //y кнопки
         text: '',
         w: 100, //ширина кнопки
         h: 100, //высота кнопки
         normal_src: '0_Empty.png',
         press_src: '0_Empty.png',
         click_func: () => {
          vibro();
          click_app_right();
         },
         longpress_func: () => {
          vibro();
          click_Set_on();
         },
         show_level: hmUI.show_level.ONLY_NORMAL,
        });


        groupVremya.setProperty(hmUI.prop.VISIBLE, true);
        groupTap.setProperty(hmUI.prop.VISIBLE, false);
        groupPogoda.setProperty(hmUI.prop.VISIBLE, false);
        groupActiv.setProperty(hmUI.prop.VISIBLE, false);
        groupSleep.setProperty(hmUI.prop.VISIBLE, false);


        // end user_script_beforeShortcuts.js

        //start of ignored block
        //end of ignored block

        //start of ignored block


        //end of ignored block
        //start of ignored block
        //end of ignored block
        function scale_call() {
         console.log('scale_call()');

         console.log('update scales STEP');

         let valueStep = step.current;
         let targetStep = step.target;
         let progressStep = valueStep / targetStep;
         if (progressStep > 1) progressStep = 1;
         let progress_ls_normal_step = progressStep;

         if (screenType != hmSetting.screen_type.AOD) {

          // normal_step_linear_scale
          // initial parameters
          let start_x_normal_step = 189;
          let start_y_normal_step = 60;
          let lenght_ls_normal_step = 89;
          let line_width_ls_normal_step = 7;
          let color_ls_normal_step = 0xFFFFFFFF;

          // calculated parameters
          let start_x_normal_step_draw = start_x_normal_step;
          let start_y_normal_step_draw = start_y_normal_step;
          lenght_ls_normal_step = lenght_ls_normal_step * progress_ls_normal_step;
          let lenght_ls_normal_step_draw = lenght_ls_normal_step;
          let line_width_ls_normal_step_draw = line_width_ls_normal_step;
          if (lenght_ls_normal_step < 0) {
           lenght_ls_normal_step_draw = -lenght_ls_normal_step;
           start_x_normal_step_draw = start_x_normal_step - lenght_ls_normal_step_draw;
          };

          normal_step_linear_scale.setProperty(hmUI.prop.MORE, {
           x: start_x_normal_step_draw,
           y: start_y_normal_step_draw,
           w: lenght_ls_normal_step_draw,
           h: line_width_ls_normal_step_draw,
           radius: 3,
           color: color_ls_normal_step,
          });
         };

         console.log('update scales BATTERY');

         let valueBattery = battery.current;
         let targetBattery = 100;
         let progressBattery = valueBattery / targetBattery;
         if (progressBattery > 1) progressBattery = 1;
         let progress_cs_normal_battery = progressBattery;

         if (screenType != hmSetting.screen_type.AOD) {

          // normal_battery_circle_scale_circle_scale
          let level = Math.round(progress_cs_normal_battery * 100);
          if (normal_battery_circle_scale) {
           normal_battery_circle_scale.setProperty(hmUI.prop.MORE, {
            center_x: 141,
            center_y: 135,
            start_angle: 270,
            end_angle: 360,
            radius: 71,
            line_width: 6,
            corner_flag: 0,
            color: 0xFFFFFFFF,
            show_level: hmUI.show_level.ONLY_NORMAL,
            level: level,
           });
          };
         };


        };

        timeSensor.addEventListener(timeSensor.event.MINUTEEND, function () {
         updateAllInfo();
        });

        calorie.addEventListener(hmSensor.event.CHANGE, function () {
         updateActivity();
        });

        heart.addEventListener(hmSensor.event.CHANGE, function () {
         updateActivity();
        });


        const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
         resume_call: (function () {


          const now = Date.now();
          updateWeatherData();
          updateAllInfo();
          toggleWeatherIcons();
          start_Anim()
          updateSleep();
          //  scale_call();
          stopVibro();
          click_Pogoda_off();
          setTimeout(() => {
           onDigitalCrown();
          }, 150);


          let nawAnimationTime = timeSensor.utc;;

          let delay_anim_motion_1 = 0;
          let repeat_anim_motion_1 = 100000;
          delay_anim_motion_1 = repeat_anim_motion_1 - (nawAnimationTime - normal_motion_animation_lastTime_1);
          if (delay_anim_motion_1 < 0) delay_anim_motion_1 = 0;
          if ((nawAnimationTime - normal_motion_animation_lastTime_1) > repeat_anim_motion_1) {
           normal_motion_animation_count_1 = 0;
           timer_anim_motion_1_mirror = false;
          };

          if (!timer_anim_motion_1 || ic_W_index == 3 || ic_W_index == 4 || ic_W_index == 6 || ic_W_index == 8) {
           timer_anim_motion_1 = timer.createTimer(delay_anim_motion_1, repeat_anim_motion_1, (function (option) {
            anim_motion_1_complete_call()
           })); // end timer create

          };

          let delay_anim_motion_2 = 0;
          let repeat_anim_motion_2 = 100000;
          delay_anim_motion_2 = repeat_anim_motion_2 - (nawAnimationTime - normal_motion_animation_lastTime_2);
          if (delay_anim_motion_2 < 0) delay_anim_motion_2 = 0;
          if ((nawAnimationTime - normal_motion_animation_lastTime_2) > repeat_anim_motion_2) {
           normal_motion_animation_count_2 = 0;
           timer_anim_motion_2_mirror = false;
          };

          if (!timer_anim_motion_2 || ic_W_index == 3 || ic_W_index == 4 || ic_W_index == 6 || ic_W_index == 8) {
           timer_anim_motion_2 = timer.createTimer(delay_anim_motion_2, repeat_anim_motion_2, (function (option) {
            anim_motion_2_complete_call()
           })); // end timer create
          };


         }),
         pause_call: (function () {
          stop_anim_motion_1();
          stop_anim_motion_2();
          snowfall.stop(); // остановить снегопад

          if (normal_timerTimeUpdate) {
           timer.stopTimer(normal_timerTimeUpdate);
           normal_timerTimeUpdate = undefined;
          }


          stopVibro();
          groupTap.setProperty(hmUI.prop.VISIBLE, false);
          hmApp.unregisterSpinEvent();
          groupVremya.setProperty(hmUI.prop.VISIBLE, true);
          groupPogoda.setProperty(hmUI.prop.VISIBLE, false);
          groupActiv.setProperty(hmUI.prop.VISIBLE, false);
          groupSleep.setProperty(hmUI.prop.VISIBLE, false);
          // end pause_call.js

         }),
        });

        //dynamic modify end
       },
       onInit() {
       },
       build() {
        this.init_view();

       },
       onDestroy() {}
      });;
     })();
    } catch (e) {
     console.log('Mini Program Error', e);
     e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));;
    }
