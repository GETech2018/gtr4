﻿    /*
     ** Watch_Face_Editor tool
     ** watchface js version v2.1.1
     ** Copyright © SashaCX75. All Rights Reserved
     */

    try {
        (() => {
            //start of ignored block
            const __$$app$$__ = __$$hmAppManager$$__.currentApp;

            function getApp() {
                return __$$app$$__.app;
            }

            function getCurrentPage() {
                return __$$app$$__.current && __$$app$$__.current.module;
            }
            const __$$module$$__ = __$$app$$__.current;
            const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
            const {
                px
            } = __$$app$$__.__globals__;
            const logger = Logger.getLogger('watchface_SashaCX75');
            //end of ignored block

            //dynamic modify start


            console.log('user_functions.js');
            // start user_functions.js

            const {
                width: D_W,
                height: D_H
            } = hmSetting.getDeviceInfo();
            let groupVremya = ''
            let groupPogoda = ''
            let groupTap = ''
            let groupActiv = ''
            let canvas0 = ''
            let canvas = ''

            let groupSleep = ''


            // const battery = hmSensor.createSensor(hmSensor.id.BATTERY)
            const weatherSensor = hmSensor.createSensor(hmSensor.id.WEATHER);
            const heart_rate = hmSensor.createSensor(hmSensor.id.HEART);

            let normal_background_bg = ''



            function loadSettings() {

                if (hmFS.SysProGetInt('CYBERNETIC_color_ic') === undefined) {
                    color_ic = 0;
                    hmFS.SysProSetInt('CYBERNETIC_color_ic', color_ic);
                } else {
                    color_ic = hmFS.SysProGetInt('CYBERNETIC_color_ic');
                }

                if (hmFS.SysProGetInt('CYBERNETIC_Activ_color') === undefined) {
                    Activ_color = 0;
                    hmFS.SysProSetInt('CYBERNETIC_Activ_color', Activ_color);
                } else {
                    Activ_color = hmFS.SysProGetInt('CYBERNETIC_Activ_color');
                }

                if (hmFS.SysProGetInt('CYBERNETIC_color') === undefined) {
                    Ar_Set[0][1] = 0;
                    hmFS.SysProSetInt('CYBERNETIC_color', Ar_Set[0][1]);
                } else {
                    Ar_Set[0][1] = hmFS.SysProGetInt('CYBERNETIC_color');
                }

                if (hmFS.SysProGetInt('CYBERNETIC_color2') === undefined) {
                    Ar_Set[1][1] = 0;
                    hmFS.SysProSetInt('CYBERNETIC_color2', Ar_Set[1][1]);
                } else {
                    Ar_Set[1][1] = hmFS.SysProGetInt('CYBERNETIC_color2');
                }


                if (hmFS.SysProGetInt('CYBERNETIC_tip_grafik') === undefined) {
                    tip_grafik = 0;
                    hmFS.SysProSetInt('CYBERNETIC_tip_grafik', tip_grafik);
                } else {
                    tip_grafik = hmFS.SysProGetInt('CYBERNETIC_tip_grafik');
                }

                if (hmFS.SysProGetInt('CYBERNETIC_crown') === undefined) {
                    crown = 0;
                    hmFS.SysProSetInt('CYBERNETIC_crown', crown);
                } else {
                    crown = hmFS.SysProGetInt('CYBERNETIC_crown');
                }

            }







            function anim_point() {
                point1_time_1 = {
                    anim_rate: 'easeOutExpo',
                    anim_duration: 1000,
                    anim_from: 0,
                    anim_to: 0,
                    anim_offset: 0,
                    anim_prop: hmUI.prop.ALPHA,
                }

                point1_time_2 = {
                    anim_rate: 'easeOutExpo', //'linear'
                    anim_duration: 1000,
                    anim_from: 0,
                    anim_to: 0,
                    anim_offset: 1000,
                    anim_prop: hmUI.prop.ALPHA,
                }

                point1_time_3 = {
                    anim_rate: 'easeOutExpo', //'linear'
                    anim_duration: 1000,
                    anim_from: 255,
                    anim_to: 255,
                    anim_offset: 1000,
                    anim_prop: hmUI.prop.ALPHA,
                }




                point2_time_1 = {
                    anim_rate: 'easeOutExpo',
                    anim_duration: 1000,
                    anim_from: 255,
                    anim_to: 255,
                    anim_offset: 0,
                    anim_prop: hmUI.prop.ALPHA,
                }

                point2_time_2 = {
                    anim_rate: 'easeOutExpo', //'linear'
                    anim_duration: 1000,
                    anim_from: 255,
                    anim_to: 255,
                    anim_offset: 1000,
                    anim_prop: hmUI.prop.ALPHA,
                }

                point2_time_3 = {
                    anim_rate: 'easeOutExpo', //'linear'
                    anim_duration: 1000,
                    anim_from: 0,
                    anim_to: 0,
                    anim_offset: 1000,
                    anim_prop: hmUI.prop.ALPHA,
                }


                normal_temperature_current_text_font.setProperty(hmUI.prop.ANIM, {
                    anim_auto_start: 1,
                    anim_auto_destroy: 0,
                    anim_steps: [point1_time_1, point1_time_2, point1_time_3],
                    anim_repeat: -1,
                    anim_fps: 25,
                })

                normal_heart_rate_text_font.setProperty(hmUI.prop.ANIM, {
                    anim_auto_start: 1,
                    anim_auto_destroy: 0,
                    anim_steps: [point2_time_1, point2_time_2, point2_time_3],
                    anim_repeat: -1,
                    anim_fps: 25,
                })


            };







            let sleep_time_txt = ''
            let sleep_start_time_txt = ''
            let sleep_end_time_txt = ''
            let sleep_score_txt = ''
            let wake_time_txt

            const sleep = hmSensor.createSensor(hmSensor.id.SLEEP);
            let sleepInfo = sleep.getBasicInfo();

            let sleepTotalTime = sleep.getTotalTime();
            let sleepStartTime = sleepInfo.startTime;
            let sleepEndTime = sleepInfo.endTime + 1;
            let sleepScore = sleepInfo.score;

            //-----------  время пробуждений ------------------		
            let sleepStageArray = sleep.getSleepStageData();
            const modelData = sleep.getSleepStageModel();
            //-------------------------------------------------		

            //sleep_time_txt.setProperty(hmUI.prop.TEXT, 'Время сна: ' + Math.floor(sleepTotalTime / 60).toString().padStart(2, "0") + ':' + (sleepTotalTime % 60).toString().padStart(2, "0"));


            function click_sleep() {
                groupVremya.setProperty(hmUI.prop.VISIBLE, false);
                groupSleep.setProperty(hmUI.prop.VISIBLE, true);
            }


            function click_exit_sleep() {
                groupVremya.setProperty(hmUI.prop.VISIBLE, true);
                groupSleep.setProperty(hmUI.prop.VISIBLE, false);
            }


            function read_pressure() {
                console.log("read_pressure()");
                const file_name_alt = "../../../baro_altim/pressure.dat";
                const [fs_stat, err] = hmFS.stat(file_name_alt);
                if (err == 0) {
                    let file_size = fs_stat.size;
                    const len = file_size / 4;
                    console.log(`size_alt: ${file_size}, lenght: ${len}`)
                    const fh = hmFS.open(file_name_alt, hmFS.O_RDONLY)

                    let array_buffer = new Float32Array(len);
                    hmFS.read(fh, array_buffer.buffer, 0, file_size);
                    hmFS.close(fh);
                    console.log(`value ${array_buffer[array_buffer.length -1]}`);
                    return array_buffer;
                } else {
                    console.log('err:', err)
                }
                return null;
            }

            function getPressureValue(pressure_array) {
                console.log("getPressureValue()");
                if (pressure_array == null || pressure_array == undefined || pressure_array.length == 0) return 0;
                let start_index = pressure_array.length - 1;
                let end_index = start_index - 30 * 3; // 3 часа
                if (end_index < 0) end_index = 0;
                for (let index = start_index; index >= end_index; index--) {
                    if (pressure_array[index] != 0) return parseInt(pressure_array[index] / 100);
                }
                return 0;
            }

            function changesPressure(pressure_array) {
                console.log("changesPressure()");
                if (pressure_array == null || pressure_array == undefined || pressure_array.length == 0) return 0;
                let start_index = pressure_array.length - 1;
                let end_index = start_index - 30 * 3; // 3 часа
                let value = pressure_array[start_index];
                let result = 0;
                if (end_index < 0) end_index = 0;
                for (let index = start_index; index >= end_index; index--) {
                    let element = pressure_array[index];
                    if (element != 0) {
                        if (Math.abs(value - element) > 10) { // учитываем только если разниза больше 0,1 hPa
                            value = value - element;
                            console.log(`element = ${element}`);
                            console.log(`pressere_changes = ${value}`);
                            return value;
                        }
                    }
                }
                return result;
            }

            function hPa_To_mmHg(hPa_value = 0) {
                let mmHg = Math.round(hPa_value * 0.750064);
                return mmHg;
            }
            //#endregion

            let text_pressere; // отображаем давление
            let text_pressere_changes; // отображаем изменение давления 


            function makeAOD() {
                // color = hmFS.SysProGetInt('NUMNUM_color');
                const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
                    resume_call: (function () {
                        stopVibro();
                    }),
                    pause_call: (function () {
                        hmApp.unregisterSpinEvent();
                        stopVibro();
                    }),
                });


            }


            let Activ_color_alpha = ''
            let color_bg_Activ = [0xff0000, 0xff0000, 0xFCB61C, 0x068FF9, 0xFFB900, 0xffffff, 0xf8e36c, 0xb84cf6, 0xa3fd1f, 0xfd912f, 0x8cffff, 0xff00a2, 0x8a8a8a];

            let menu = 0
            let color_ic = 0
            let Activ_color = 0

            function click_Activ_color() {
                Activ_color = (Activ_color + 1) % 2
                ic_activ_color_off_img.setProperty(hmUI.prop.VISIBLE, Activ_color == 0);
                hmFS.SysProSetInt('CYBERNETIC_Activ_color', Activ_color);
            }


            let Btn_set_ = []
            let Shag_Y = 66


            let menu_ARC_color = [
                [],
                [],
                [],
                [],
                [],
                [],
                [],
                [],
                /*  [],
                [],
                [],
                [],
                [],
                [],
                [],
                [],
                [],
                [],
                [],
*/
                []
            ]


            let Ar_Set = [
                ['ЦВЕТ ФОНА', 0, 0, 'page/index'],
                ['АНАЛОГ ЦИФРОВОЙ', 0, 1, 'page/index'],
                /*             ['ЯРКОСТЬ', 0, `tap/i_tap_pusto.png`, 0, 'page/index'],*/
                ['КОРОНКА ОТКЛЮЧЕНА', 0, 1, 'page/index'],
                /*   ['ПЯТЬ', 0, `tap/i_tap_pusto.png`, 0, 'page/index'],
               ['ШЕСТЬ', 0, `tap/i_tap_pusto.png`, 0, 'page/index'],
                     ['СЕМЬ', 0, `tap/i_tap_pusto.png`, 0, 'page/index'],
                      ['ВОСЕМЬ', 0, `tap/i_tap_pusto.png`, 0, 'page/index'],
                      ['ДЕВЯТЬ', 0, `tap/i_tap_pusto.png`, 0, 'page/index']
					  ,*/

            ];

            let color_bg = [
                [0xff0000, 0xff8000, 0xffff00, 0x00ff00, 0x00ffff, 0x0080ff, 0x8080ff, 0xff00ff, 0xffffff, 0x808080],
                [0xff9f36, 0xff1e4d, 0xb24ee1],
                [0xff0000, 0xff6600, 0xff6600, 0xff6600, 0x00ffff, 0x0080ff, 0x8080ff],
                /*             [0xff0000, 0xff8000, 0xffff00, 0x00ff00, 0x00ffff, 0x0080ff, 0x8080ff, 0xff00ff, 0xffffff, 0x808080],
                             [0xff0000, 0xff8000, 0xffff00, 0x00deff, 0x00deff, 0x00deff, 0x8080ff, 0xff00ff],
                             [0xff0000, 0xff8000, 0xffff00, 0x00ff00, 0x00ffff, 0x0080ff, 0x8080ff, 0xff00ff, 0xffffff, 0x808080],
                             [0xff0000, 0xff8000, 0xffff00, 0x00ff00, 0x00ffff, 0x0080ff, 0x8080ff, 0xff00ff, 0xffffff, 0x808080],
                             [0xea00ff, 0xff8000, 0xea00ff, 0xea00ff],
                             [0x00ff1e, 0xff8000, 0x00ff1e, 0x00ff1e, 0x00ffff, 0x0080ff, 0x8080ff, 0xff00ff, 0xffffff, 0x808080],*/
            ];


            let crownSensitivity = 70; // уровень чувствительности колесика
            let color = 0;
            let color_str = 0;
            let bridg = 127;
            let crown = 0


            function click_crown(index) {
                for (let i = 0; i < Ar_Set.length; i++) {
                    if (index == i) crown = i
                };

                for (let i = 0; i < Ar_Set.length; i++) {
                    Btn_set_[i].setProperty(hmUI.prop.MORE, {
                        x: Ar_Set.length <= 5 ? 153 : i < Math.ceil(Ar_Set.length / 2) ? 70 : D_W / 2,
                        y: Ar_Set.length <= 5 ? 70 + i * Shag_Y : i < Math.ceil(Ar_Set.length / 2) ? 70 + i * Shag_Y : 70 + i * Shag_Y - Shag_Y * Math.ceil(Ar_Set.length / 2),
                        w: 160,
                        h: 60,
                        text: Ar_Set[i][0],
                        char_space: 0,
                        line_space: -35,
                        color: 0xFFFFFFFF,
                        text_size: 24,
                        radius: 12,
                        press_color: 0xFFFF0000,
                        normal_color: i != crown ? 0x000000 : 0x800000,
                        text_style: hmUI.text_style.WRAP,
                        show_level: hmUI.show_level.ONLY_NORMAL,
                    }); // end button                        

                };


                for (let j = 0; j < Ar_Set.length; j++) {
                    for (let i = 0; i < color_bg[j].length; i++) {
                        menu_ARC_color[j][i].setProperty(hmUI.prop.VISIBLE, false);
                    };
                };
                for (let i = 0; i < color_bg[crown].length; i++) {
                    menu_ARC_color[crown][i].setProperty(hmUI.prop.VISIBLE, crown == 0);
                };

                for (let i = 0; i < color_bg[crown].length; i++) {
                    menu_ARC_color[0].setProperty(hmUI.prop.MORE, {
                        center_x: D_W / 2,
                        center_y: D_W / 2,
                        start_angle: 45 + 90 / color_bg[crown].length * i,
                        end_angle: 135 + 90 / color_bg[crown].length * i,
                        radius: 219 - 16,
                        line_width: 16,
                        corner_flag: 0,
                        color: color_bg[crown][i],
                        level: 100 / color_bg[crown].length,
                        show_level: hmUI.show_level.ONLY_NORMAL,
                    });
                };
            }

            function click_Set_on() {
                set = 1
                groupVremya.setProperty(hmUI.prop.VISIBLE, false);
                g_Set.setProperty(hmUI.prop.VISIBLE, true);
                g_ACR_color.setProperty(hmUI.prop.VISIBLE, true);

                for (let j = 0; j < Ar_Set.length; j++) {
                    for (let i = 0; i < color_bg[j].length; i++) {
                        menu_ARC_color[j][i].setProperty(hmUI.prop.VISIBLE, false);
                    };

                };

                for (let i = 0; i < color_bg[crown].length; i++) {
                    menu_ARC_color[crown][i].setProperty(hmUI.prop.VISIBLE, crown == 0);
                };
            }

            function click_Set_off() {
                set = 0
                g_Set.setProperty(hmUI.prop.VISIBLE, false);
                groupVremya.setProperty(hmUI.prop.VISIBLE, true);
                g_ACR_color.setProperty(hmUI.prop.VISIBLE, false);
                for (let j = 0; j < Ar_Set.length; j++) {
                    for (let i = 0; i < color_bg[j].length; i++) {
                        menu_ARC_color[j][i].setProperty(hmUI.prop.VISIBLE, false);
                    };
                };
                hmFS.SysProSetInt('CYBERNETIC_crown', crown);

            }

            let set = 0;
            let degreeSum = 0;
            let MenuCirkl_Timer = null;


            function onDigitalCrown() {
                hmApp.registerSpinEvent(function (key, degree) {
                        if (key === hmApp.key.HOME) {
                            degreeSum += degree;
                            if (Math.abs(degreeSum) > crownSensitivity) {


                                if (Activ_color == 1 && menu == 1) {
                                    let step = degreeSum < 0 ? -1 : 1;
                                    color_ic += step;
                                    color_ic = color_ic < 0 ? color_bg_Activ.length + color_ic : color_ic % color_bg_Activ.length;
                                    degreeSum = 0;
                                    hmFS.SysProSetInt('CYBERNETIC_color_ic', color_ic);

                                    Activ_color_alpha.setProperty(hmUI.prop.MORE, {
                                            center_x: D_W / 2,
                                            center_y: D_W / 2,
                                            radius: D_W / 2,
                                            color: color_bg_Activ[color_ic],
                                            alpha: color_ic == 0 ? 0 : 255,
                                            show_level: hmUI.show_level.ONLY_NORMAL,
                                        })
                                        // hmFS.SysProSetInt('OMG_218_color_ic', color_ic);
                                    vibro();
                                }

                                if (Activ_color == 0 && menu == 0 && crown == 0) {
                                    let step = degreeSum < 0 ? -1 : 1;
                                    Ar_Set[0][1] += step;
                                    Ar_Set[0][1] = Ar_Set[0][1] < 0 ? color_bg[0].length + Ar_Set[0][1] : Ar_Set[0][1] % color_bg[0].length;
                                    degreeSum = 0;
                                    hmFS.SysProSetInt('CYBERNETIC_color', Ar_Set[0][1]);


                                    if (set == 0) {
                                        g_ACR_color.setProperty(hmUI.prop.VISIBLE, crown == 0);
                                        for (let i = 0; i < color_bg[crown].length; i++) {
                                            menu_ARC_color[crown][i].setProperty(hmUI.prop.VISIBLE, crown == 0);
                                        };
                                        if (MenuCirkl_Timer) {
                                            timer.stopTimer(MenuCirkl_Timer)
                                        }
                                        MenuCirkl_Timer = timer.createTimer(1000, 1, (function (option) {

                                            for (let i = 0; i < color_bg[crown].length; i++) {
                                                menu_ARC_color[crown][i].setProperty(hmUI.prop.VISIBLE, false);
                                            };
                                            g_ACR_color.setProperty(hmUI.prop.VISIBLE, false);
                                            timer.stopTimer(MenuCirkl_Timer)
                                        })); // end timer
                                    } else {
                                        g_Set.setProperty(hmUI.prop.VISIBLE, false);
                                        if (MenuCirkl_Timer) {
                                            timer.stopTimer(MenuCirkl_Timer)
                                        }
                                        MenuCirkl_Timer = timer.createTimer(1000, 1, (function (option) {
                                            g_Set.setProperty(hmUI.prop.VISIBLE, true);
                                            timer.stopTimer(MenuCirkl_Timer)

                                        })); // end timer
                                    }

                                    menu_ARC_PROGRES.setProperty(hmUI.prop.MORE, {
                                        center_x: D_W / 2,
                                        center_y: D_W / 2,
                                        start_angle: 45 + 90 / color_bg[0].length * Ar_Set[0][1], // start_angle: 45 + 90 / array * gde,
                                        end_angle: 135 + 90 / color_bg[0].length * Ar_Set[0][1], //end_angle: 135 + 90 / array * gde,
                                        radius: 219,
                                        line_width: 16,
                                        corner_flag: 0,
                                        color: 0xFF0000, //0xFF007eff
                                        level: 100 / color_bg[0].length, //level: pointer,
                                        show_level: hmUI.show_level.ONLY_NORMAL,
                                    });

                                    normal_background_bg.setProperty(hmUI.prop.COLOR, color_bg[0][Ar_Set[0][1]]);
                                    vibro();
                                    normal_analog_clock_pro_second_pointer_img.setProperty(hmUI.prop.SRC, 'str_S_' + Ar_Set[0][1] + '.png');

                                    normal_bat_text_font.setProperty(hmUI.prop.COLOR, color_bg[0][Ar_Set[0][1]]);

                                    normal_battery_circle_scale.setProperty(hmUI.prop.MORE, {
                                        center_x: D_W / 2,
                                        center_y: D_W / 2,
                                        start_angle: -125,
                                        end_angle: -55,
                                        radius: 215,
                                        line_width: 36,
                                        corner_flag: 3,
                                        color: color_bg[0][Ar_Set[0][1]],
                                        type: hmUI.data_type.BATTERY,
                                        show_level: hmUI.show_level.ONLY_NORMAL,
                                    });


                                    normal_time_hour_text_font.setProperty(hmUI.prop.COLOR, color_bg[0][Ar_Set[0][1]]);

                                    normal_analog_clock_pro_hour_pointer_img.setProperty(hmUI.prop.SRC, 'str_H_up_' + Ar_Set[0][1] + '.png');
                                    normal_analog_clock_pro_hour_pointer_img_down.setProperty(hmUI.prop.SRC, 'str_H_down_' + Ar_Set[0][1] + '.png');


                                    normal_temperature_current_text_font.setProperty(hmUI.prop.MORE, {
                                        x: 158,
                                        y: 412,
                                        w: 150,
                                        h: 30,
                                        text_size: 20,
                                        char_space: 0,
                                        line_space: 0,
                                        font: 'fonts/conthrax_sb.ttf',
                                        color: color_bg[0][Ar_Set[0][1]],
                                        align_h: hmUI.align.CENTER_H,
                                        align_v: hmUI.align.CENTER_V,
                                        unit_type: 1,
                                        text_style: hmUI.text_style.ELLIPSIS,
                                        type: hmUI.data_type.WEATHER_CURRENT,
                                        show_level: hmUI.show_level.ONLY_NORMAL,
                                    });


                                }


                                if (Activ_color == 0 && menu == 0 && crown == 1) {
                                    let step = degreeSum < 0 ? -1 : 1;
                                    Ar_Set[1][1] += step;
                                    Ar_Set[1][1] = Ar_Set[1][1] < 0 ? color_bg[1].length + Ar_Set[1][1] : Ar_Set[1][1] % color_bg[1].length;
                                    degreeSum = 0;
                                    hmFS.SysProSetInt('CYBERNETIC_color2', Ar_Set[1][1]);


                                    if (set == 0) {
                                        g_ACR_color.setProperty(hmUI.prop.VISIBLE, crown == 2);
                                        if (MenuCirkl_Timer) {
                                            timer.stopTimer(MenuCirkl_Timer)
                                        }
                                        MenuCirkl_Timer = timer.createTimer(1000, 1, (function (option) {
                                            timer.stopTimer(MenuCirkl_Timer)
                                            g_ACR_color.setProperty(hmUI.prop.VISIBLE, false);
                                        })); // end timer
                                    } else {
                                        g_Set.setProperty(hmUI.prop.VISIBLE, false);
                                        if (MenuCirkl_Timer) {
                                            timer.stopTimer(MenuCirkl_Timer)
                                        }
                                        MenuCirkl_Timer = timer.createTimer(1000, 1, (function (option) {
                                            g_Set.setProperty(hmUI.prop.VISIBLE, true);
                                            timer.stopTimer(MenuCirkl_Timer)
                                        })); // end timer
                                    }

                                    menu_ARC_PROGRES.setProperty(hmUI.prop.MORE, {
                                        center_x: D_W / 2,
                                        center_y: D_W / 2,
                                        start_angle: 45 + 90 / color_bg[1].length * Ar_Set[1][1], // start_angle: 45 + 90 / array * gde,
                                        end_angle: 135 + 90 / color_bg[1].length * Ar_Set[1][1], //end_angle: 135 + 90 / array * gde,
                                        radius: 219,
                                        line_width: 16,
                                        corner_flag: 0,
                                        color: 0xFF0000, //0xFF007eff
                                        level: 100 / color_bg[1].length, //level: pointer,
                                        show_level: hmUI.show_level.ONLY_NORMAL,
                                    });



                                    //  стрелки
                                    normal_analog_clock_pro_hour_pointer_img.setProperty(hmUI.prop.VISIBLE, Ar_Set[1][1] == 0 || Ar_Set[1][1] == 1);
                                    normal_analog_clock_pro_minute_pointer_img.setProperty(hmUI.prop.VISIBLE, Ar_Set[1][1] == 0 || Ar_Set[1][1] == 1);

                                    //  сектор
                                    //normal_analog_clock_pro_hour_pointer_img_down.setProperty(hmUI.prop.VISIBLE, Ar_Set[1][1] == 1 );                                     
                                    //normal_analog_clock_time_pointer_minute.setProperty(hmUI.prop.VISIBLE, Ar_Set[1][1] == 1 );         

                                    //  цифры
                                    normal_spo2_icon_img.setProperty(hmUI.prop.VISIBLE, Ar_Set[1][1] == 2 || Ar_Set[1][1] == 1);
                                    normal_time_hour_text_font.setProperty(hmUI.prop.VISIBLE, Ar_Set[1][1] == 2 || Ar_Set[1][1] == 1);
                                    normal_time_minute_text_font.setProperty(hmUI.prop.VISIBLE, Ar_Set[1][1] == 2 || Ar_Set[1][1] == 1);



                                    vibro();
                                }


                                /*                                if (Activ_color == 0 && menu == 0  && crown == 1) {
                                                                    let step = degreeSum < 0 ? -1 : 1;
                                                                    color_str += step;
                                                                    color_str = color_str < 0 ? color_bg_2.length + color_str : color_str % color_bg_2.length;
                                                                    degreeSum = 0;
                                      //  hmFS.SysProSetInt('Spatia_color_str', color_str);  
                                                                    
                                                                    g_ACR_color_2.setProperty(hmUI.prop.VISIBLE, true);
                                                                    if (MenuCirkl_Timer) {
                                                                        timer.stopTimer(MenuCirkl_Timer)
                                                                    }
                                                                    MenuCirkl_Timer = timer.createTimer(1000, 1, (function (option) {
                                                                        g_ACR_color_2.setProperty(hmUI.prop.VISIBLE, false);
                                                                    })); // end timer 


                                                                    menu_ARC_PROGRES_2.setProperty(hmUI.prop.MORE, {
                                                                        center_x: D_W/2,
                                                                        center_y: D_W/2,
                                                                        start_angle: 45 + 90 / color_bg_2.length * color_str, // start_angle: 45 + 90 / array * gde,
                                                                        end_angle: 135 + 90 / color_bg_2.length * color_str, //end_angle: 135 + 90 / array * gde,
                                                                        radius: 219,
                                                                        line_width: 16,
                                                                        corner_flag: 0,
                                                                        color: 0xFF0000, //0xFF007eff
                                                                        level: 100 / color_bg_2.length, //level: pointer,
                                                                        show_level: hmUI.show_level.ONLY_NORMAL,
                                                                    });                                    

                                                 normal_analog_clock_pro_minute_pointer_img.setProperty(hmUI.prop.SRC,'str_M_'+color_str+'.png');      

                                                                    vibro();


                                                                } */


                                /*          if (Activ_color == 0 && menu == 0 && crown == 2) {
                                           let step = degreeSum < 0 ? -10 : 10;
                                           bridg += step;
                                           bridg = bridg < 0 ? 255 + bridg : bridg % 255;
                                           degreeSum = 0;

                                           if (set == 0) {
                                            g_ACR_color.setProperty(hmUI.prop.VISIBLE, crown == 2);
                                            if (MenuCirkl_Timer) {
                                             timer.stopTimer(MenuCirkl_Timer)
                                            }
                                            MenuCirkl_Timer = timer.createTimer(1000, 1, (function (option) {
                                             timer.stopTimer(MenuCirkl_Timer)
                                             g_ACR_color.setProperty(hmUI.prop.VISIBLE, false);
                                            })); // end timer
                                           } else {
                                            g_Set.setProperty(hmUI.prop.VISIBLE, false);
                                            if (MenuCirkl_Timer) {
                                             timer.stopTimer(MenuCirkl_Timer)
                                            }
                                            MenuCirkl_Timer = timer.createTimer(1000, 1, (function (option) {
                                             g_Set.setProperty(hmUI.prop.VISIBLE, true);
                                             timer.stopTimer(MenuCirkl_Timer)
                                            })); // end timer
                                           }

                                           menu_ARC_PROGRES.setProperty(hmUI.prop.MORE, {
                                            center_x: D_W/2,
                                            center_y: D_W/2,
                                            start_angle: 45 + 90 / 100 * ((100 - Math.floor(bridg * 100 / 255 / 5) * 5) - 10), // start_angle: 45 + 90 / array * gde,
                                            end_angle: 135 + 90 / 100 * ((100 - Math.floor(bridg * 100 / 255 / 5) * 5) - 10),
                                            radius: 219,
                                            line_width: 16,
                                            corner_flag: 0,
                                            color: 0xFF0000, //0xFF007eff
                                            level: 100 / 10, //level: pointer,
                                            show_level: hmUI.show_level.ONLY_NORMAL,
                                           });

                                           hmUI.showToast({
                                            text: 100 - Math.floor(bridg * 100 / 255 / 5) * 5 + "%"
                                           });

                                           normal_bridg_bg.setProperty(hmUI.prop.MORE, {
                                            x: 0,
                                            y: 0,
                                            w: D_W,
                                            h: D_H,
                                            color: 0x000000,
                                            alpha: bridg,
                                            show_level: hmUI.show_level.ONLY_NORMAL,
                                           });

                                           vibro();
                                          }*/


                                //  }
                            }
                        }
                    }) // crown
            }




            const vibrate = hmSensor.createSensor(hmSensor.id.VIBRATE)
            let stopVibro_Timer = null;

            function vibro(scene = 25) {
                let stopDelay = 50;
                vibrate.stop();
                vibrate.scene = scene;
                if (scene < 23 || scene > 25) stopDelay = 1220;
                vibrate.start();
                stopVibro_Timer = timer.createTimer(stopDelay, 0, stopVibro, {});
            }

            function stopVibro() {
                vibrate.stop();
                timer.stopTimer(stopVibro_Timer);
            }

            function click_Pogoda_on() {
                normal_background_Pogoda.setProperty(hmUI.prop.VISIBLE, true);
                menu = 2
                groupVremya.setProperty(hmUI.prop.VISIBLE, false);
                groupPogoda.setProperty(hmUI.prop.VISIBLE, true);
            }

            function click_Pogoda_off() {
                normal_background_Pogoda.setProperty(hmUI.prop.VISIBLE, false);
                menu = 0
                groupVremya.setProperty(hmUI.prop.VISIBLE, true);
                groupPogoda.setProperty(hmUI.prop.VISIBLE, false);
            }

            function click_Activ_on() {
                menu = 1
                groupVremya.setProperty(hmUI.prop.VISIBLE, false);
                groupActiv.setProperty(hmUI.prop.VISIBLE, true);
            }

            function click_Activ_off() {
                menu = 0
                Activ_color = 0
                ic_activ_color_off_img.setProperty(hmUI.prop.VISIBLE, Activ_color == 0);
                groupVremya.setProperty(hmUI.prop.VISIBLE, true);
                groupActiv.setProperty(hmUI.prop.VISIBLE, false);
            }


            let apps = [
                ['Нет действия', '-', `tap/i_tap_pusto.png`, 0, 'page/index'],
                ['Таймер', 'CountdownAppScreen', `tap/i_tap_obrat_otchet.png`, 0, 'page/index'],
                ['Секундомер', 'StopWatchScreen', `tap/i_tap_secundomer.png`, 0, 'page/index'],
                ['Мировые часы', 'WorldClockScreen', `tap/i_tap_mirivie_chasi.png`, 0, 'page/index'],
                ['Восход/закат', 'TideScreen', `tap/i_tap_voshod_zakat.png`, 0, 'page/index'],
                ['Сон', 'Sleep_HomeScreen', `tap/i_tap_son.png`, 0, 'page/index'],
                ['Стресс', 'StressHomeScreen', `tap/i_tap_stress.png`, 0, 'page/index'],
                ['SP02 (Кислород)', 'spo_HomeScreen', `tap/i_tap_kislorod.png`, 0, 'page/index'],
                ['Дыхание', 'RespirationsettingScreen', `tap/i_tap_dihanie.png`, 0, 'page/index'],
                ['Измерение одним касанием', 'oneKeyAppScreen', `tap/i_tap_1_kosanie.png`, 0, 'page/index'],
                ['Женский календарь', 'menstrualAppScreen', `tap/i_tap_gensk_calendar.png`, 0, 'page/index'],
                ['Найти телефон', 'FindPhoneScreen', `tap/i_tap_naiti_telo.png`, 0, 'page/index'],
                ['Музыка', 'LocalMusicScreen', `tap/i_tap_musik.png`, 0, 'page/index'], //'PhoneMusicCtrlScreen'
                ['Компас', 'CompassScreen', `tap/i_tap_kompas.png`, 0, 'page/index'],
                ['Набрать номер', 'DialCallScreen', `tap/i_tap_nabor.png`, 0, 'page/index'],
                ['Телефон', 'PhoneHomeScreen', `tap/i_tap_telefon.png`, 0, 'page/index'],
                ['Диктофон', 'VoiceMemoScreen', `tap/i_tap_dictofon.png`, 0, 'page/index'],
                ['Расписание', 'ScheduleListScreen', `tap/i_tap_raspisanie.png`, 0, 'page/index'],
                ['Список дел', 'todoListScreen', `tap/i_tap_spisok_del.png`, 0, 'page/index'],
                ['Календарь', 'ScheduleCalScreen', `tap/i_tap_calendar.png`, 0, 'page/index'],
                ['Погода', 'WeatherScreen', `tap/i_tap_pogoda.png`, 0, 'page/index'],
                ['Настройка', 'Settings_homeScreen', `tap/i_tap_sitting.png`, 0, 'page/index'],
                ['Камера', 'HidcameraScreen', `tap/i_tap_camera.png`, 0, 'page/index'],
                ['Пульс', 'heart_app_Screen', `tap/i_tap_puls.png`, 0, 'page/index'],
                ['Будильник', 'AlarmInfoScreen', `tap/i_tap_budilnik.png`, 0, 'page/index'],
                ['PAI', 'PAI_app_Screen', `tap/i_tap_pai.png`, 0, 'page/index'],
                ['Тренировка', 'SportListScreen', `tap/i_tap_trenerovka.png`, 0, 'page/index'],
                ['AOD', 'Settings_standbyModelScreen', `tap/i_tap_aod.png`, 0, 'page/index'],
                ['Экономия заряда', 'LowBatteryScreen', `tap/i_tap_LowBattery.png`, 0, 'page/index'],
                ['Давление/Высота', 'BaroAltimeterScreen', `tap/i_tap_barometr.png`, 0, 'page/index'],
                ['Погода LeXxiR', '1051195', `tap/i_tap_LeXxiR.png`, 1, 'page/index'],
                ['Календарь Sasha', '1057409', `tap/i_tap_calen_Sasha.png`, 1, 'page/index'],
                ['Flow', '1038314', `tap/i_tap_flow.png`, 1, 'page/gtr/home/index.page'],
                ['Ночной режим', 'Settings_nsModeHomeScreen', `tap/i_tap_night_Mode_Screen.png`, 0, 'page/index']
            ];


            const tap_1_edit = hmUI.createWidget(hmUI.widget.WATCHFACE_EDIT_GROUP, {
                edit_id: 101,
                x: 171,
                y: 20,
                w: 124,
                h: 124,
                select_image: 'tap/edit_red_1.png',
                un_select_image: 'tap/edit_griin_1.png',
                default_type: 19,
                optional_types: [{
                    type: 0,
                    preview: apps[0][2],
                    title_en: apps[0][0]
                }, {
                    type: 1,
                    preview: apps[1][2],
                    title_en: apps[1][0]
                }, {
                    type: 2,
                    preview: apps[2][2],
                    title_en: apps[2][0]
                }, {
                    type: 3,
                    preview: apps[3][2],
                    title_en: apps[3][0]
                }, {
                    type: 4,
                    preview: apps[4][2],
                    title_en: apps[4][0]
                }, {
                    type: 5,
                    preview: apps[5][2],
                    title_en: apps[5][0]
                }, {
                    type: 6,
                    preview: apps[6][2],
                    title_en: apps[6][0]
                }, {
                    type: 7,
                    preview: apps[7][2],
                    title_en: apps[7][0]
                }, {
                    type: 8,
                    preview: apps[8][2],
                    title_en: apps[8][0]
                }, {
                    type: 9,
                    preview: apps[9][2],
                    title_en: apps[9][0]
                }, {
                    type: 10,
                    preview: apps[10][2],
                    title_en: apps[10][0]
                }, {
                    type: 11,
                    preview: apps[11][2],
                    title_en: apps[11][0]
                }, {
                    type: 12,
                    preview: apps[12][2],
                    title_en: apps[12][0]
                }, {
                    type: 13,
                    preview: apps[13][2],
                    title_en: apps[13][0]
                }, {
                    type: 14,
                    preview: apps[14][2],
                    title_en: apps[14][0]
                }, {
                    type: 15,
                    preview: apps[15][2],
                    title_en: apps[15][0]
                }, {
                    type: 16,
                    preview: apps[16][2],
                    title_en: apps[16][0]
                }, {
                    type: 17,
                    preview: apps[17][2],
                    title_en: apps[17][0]
                }, {
                    type: 18,
                    preview: apps[18][2],
                    title_en: apps[18][0]
                }, {
                    type: 19,
                    preview: apps[19][2],
                    title_en: apps[19][0]
                }, {
                    type: 20,
                    preview: apps[20][2],
                    title_en: apps[20][0]
                }, {
                    type: 21,
                    preview: apps[21][2],
                    title_en: apps[21][0]
                }, {
                    type: 22,
                    preview: apps[22][2],
                    title_en: apps[22][0]
                }, {
                    type: 23,
                    preview: apps[23][2],
                    title_en: apps[23][0]
                }, {
                    type: 24,
                    preview: apps[24][2],
                    title_en: apps[24][0]
                }, {
                    type: 25,
                    preview: apps[25][2],
                    title_en: apps[25][0]
                }, {
                    type: 26,
                    preview: apps[26][2],
                    title_en: apps[26][0]
                }, {
                    type: 27,
                    preview: apps[27][2],
                    title_en: apps[27][0]
                }, {
                    type: 28,
                    preview: apps[28][2],
                    title_en: apps[28][0]
                }, {
                    type: 29,
                    preview: apps[29][2],
                    title_en: apps[29][0]
                }, {
                    type: 30,
                    preview: apps[30][2],
                    title_en: apps[30][0]
                }, {
                    type: 31,
                    preview: apps[31][2],
                    title_en: apps[31][0]
                }, {
                    type: 32,
                    preview: apps[32][2],
                    title_en: apps[32][0]
                }, {
                    type: 33,
                    preview: apps[33][2],
                    title_en: apps[33][0]
                }, ],

                count: 34,
                tips_x: 135 - 171,
                tips_y: 150 - 20,
                tips_width: 195,
                tips_margin: 10,
                tips_BG: 'tap/tips_bg.png'
            })

            let tap_1_select = tap_1_edit.getProperty(hmUI.prop.CURRENT_TYPE)

            const tap_2_edit = hmUI.createWidget(hmUI.widget.WATCHFACE_EDIT_GROUP, {
                edit_id: 102,
                x: 301,
                y: 95,
                w: 124,
                h: 124,
                select_image: 'tap/edit_red_1.png',
                un_select_image: 'tap/edit_griin_1.png',
                default_type: 20,
                optional_types: [{
                    type: 0,
                    preview: apps[0][2],
                    title_en: apps[0][0]
                }, {
                    type: 1,
                    preview: apps[1][2],
                    title_en: apps[1][0]
                }, {
                    type: 2,
                    preview: apps[2][2],
                    title_en: apps[2][0]
                }, {
                    type: 3,
                    preview: apps[3][2],
                    title_en: apps[3][0]
                }, {
                    type: 4,
                    preview: apps[4][2],
                    title_en: apps[4][0]
                }, {
                    type: 5,
                    preview: apps[5][2],
                    title_en: apps[5][0]
                }, {
                    type: 6,
                    preview: apps[6][2],
                    title_en: apps[6][0]
                }, {
                    type: 7,
                    preview: apps[7][2],
                    title_en: apps[7][0]
                }, {
                    type: 8,
                    preview: apps[8][2],
                    title_en: apps[8][0]
                }, {
                    type: 9,
                    preview: apps[9][2],
                    title_en: apps[9][0]
                }, {
                    type: 10,
                    preview: apps[10][2],
                    title_en: apps[10][0]
                }, {
                    type: 11,
                    preview: apps[11][2],
                    title_en: apps[11][0]
                }, {
                    type: 12,
                    preview: apps[12][2],
                    title_en: apps[12][0]
                }, {
                    type: 13,
                    preview: apps[13][2],
                    title_en: apps[13][0]
                }, {
                    type: 14,
                    preview: apps[14][2],
                    title_en: apps[14][0]
                }, {
                    type: 15,
                    preview: apps[15][2],
                    title_en: apps[15][0]
                }, {
                    type: 16,
                    preview: apps[16][2],
                    title_en: apps[16][0]
                }, {
                    type: 17,
                    preview: apps[17][2],
                    title_en: apps[17][0]
                }, {
                    type: 18,
                    preview: apps[18][2],
                    title_en: apps[18][0]
                }, {
                    type: 19,
                    preview: apps[19][2],
                    title_en: apps[19][0]
                }, {
                    type: 20,
                    preview: apps[20][2],
                    title_en: apps[20][0]
                }, {
                    type: 21,
                    preview: apps[21][2],
                    title_en: apps[21][0]
                }, {
                    type: 22,
                    preview: apps[22][2],
                    title_en: apps[22][0]
                }, {
                    type: 23,
                    preview: apps[23][2],
                    title_en: apps[23][0]
                }, {
                    type: 24,
                    preview: apps[24][2],
                    title_en: apps[24][0]
                }, {
                    type: 25,
                    preview: apps[25][2],
                    title_en: apps[25][0]
                }, {
                    type: 26,
                    preview: apps[26][2],
                    title_en: apps[26][0]
                }, {
                    type: 27,
                    preview: apps[27][2],
                    title_en: apps[27][0]
                }, {
                    type: 28,
                    preview: apps[28][2],
                    title_en: apps[28][0]
                }, {
                    type: 29,
                    preview: apps[29][2],
                    title_en: apps[29][0]
                }, {
                    type: 30,
                    preview: apps[30][2],
                    title_en: apps[30][0]
                }, {
                    type: 31,
                    preview: apps[31][2],
                    title_en: apps[31][0]
                }, {
                    type: 32,
                    preview: apps[32][2],
                    title_en: apps[32][0]
                }, {
                    type: 33,
                    preview: apps[33][2],
                    title_en: apps[33][0]
                }, ],
                count: 34,
                tips_x: 266 - 301,
                tips_y: 225 - 95,
                tips_width: 195,
                tips_margin: 10,
                tips_BG: 'tap/tips_bg.png'
            })


            let tap_2_select = tap_2_edit.getProperty(hmUI.prop.CURRENT_TYPE)


            const tap_3_edit = hmUI.createWidget(hmUI.widget.WATCHFACE_EDIT_GROUP, {
                edit_id: 103,
                x: 301,
                y: 246,
                w: 124,
                h: 124,
                select_image: 'tap/edit_red_1.png',
                un_select_image: 'tap/edit_griin_1.png',
                default_type: 24,
                optional_types: [{
                    type: 0,
                    preview: apps[0][2],
                    title_en: apps[0][0]
                }, {
                    type: 1,
                    preview: apps[1][2],
                    title_en: apps[1][0]
                }, {
                    type: 2,
                    preview: apps[2][2],
                    title_en: apps[2][0]
                }, {
                    type: 3,
                    preview: apps[3][2],
                    title_en: apps[3][0]
                }, {
                    type: 4,
                    preview: apps[4][2],
                    title_en: apps[4][0]
                }, {
                    type: 5,
                    preview: apps[5][2],
                    title_en: apps[5][0]
                }, {
                    type: 6,
                    preview: apps[6][2],
                    title_en: apps[6][0]
                }, {
                    type: 7,
                    preview: apps[7][2],
                    title_en: apps[7][0]
                }, {
                    type: 8,
                    preview: apps[8][2],
                    title_en: apps[8][0]
                }, {
                    type: 9,
                    preview: apps[9][2],
                    title_en: apps[9][0]
                }, {
                    type: 10,
                    preview: apps[10][2],
                    title_en: apps[10][0]
                }, {
                    type: 11,
                    preview: apps[11][2],
                    title_en: apps[11][0]
                }, {
                    type: 12,
                    preview: apps[12][2],
                    title_en: apps[12][0]
                }, {
                    type: 13,
                    preview: apps[13][2],
                    title_en: apps[13][0]
                }, {
                    type: 14,
                    preview: apps[14][2],
                    title_en: apps[14][0]
                }, {
                    type: 15,
                    preview: apps[15][2],
                    title_en: apps[15][0]
                }, {
                    type: 16,
                    preview: apps[16][2],
                    title_en: apps[16][0]
                }, {
                    type: 17,
                    preview: apps[17][2],
                    title_en: apps[17][0]
                }, {
                    type: 18,
                    preview: apps[18][2],
                    title_en: apps[18][0]
                }, {
                    type: 19,
                    preview: apps[19][2],
                    title_en: apps[19][0]
                }, {
                    type: 20,
                    preview: apps[20][2],
                    title_en: apps[20][0]
                }, {
                    type: 21,
                    preview: apps[21][2],
                    title_en: apps[21][0]
                }, {
                    type: 22,
                    preview: apps[22][2],
                    title_en: apps[22][0]
                }, {
                    type: 23,
                    preview: apps[23][2],
                    title_en: apps[23][0]
                }, {
                    type: 24,
                    preview: apps[24][2],
                    title_en: apps[24][0]
                }, {
                    type: 25,
                    preview: apps[25][2],
                    title_en: apps[25][0]
                }, {
                    type: 26,
                    preview: apps[26][2],
                    title_en: apps[26][0]
                }, {
                    type: 27,
                    preview: apps[27][2],
                    title_en: apps[27][0]
                }, {
                    type: 28,
                    preview: apps[28][2],
                    title_en: apps[28][0]
                }, {
                    type: 29,
                    preview: apps[29][2],
                    title_en: apps[29][0]
                }, {
                    type: 30,
                    preview: apps[30][2],
                    title_en: apps[30][0]
                }, {
                    type: 31,
                    preview: apps[31][2],
                    title_en: apps[31][0]
                }, {
                    type: 32,
                    preview: apps[32][2],
                    title_en: apps[32][0]
                }, {
                    type: 33,
                    preview: apps[33][2],
                    title_en: apps[33][0]
                }, ],
                count: 34,
                tips_x: 266 - 301,
                tips_y: 184 - 246,
                tips_width: 195,
                tips_margin: 10,
                tips_BG: 'tap/tips_bg.png'
            })

            let tap_3_select = tap_3_edit.getProperty(hmUI.prop.CURRENT_TYPE)

            const tap_4_edit = hmUI.createWidget(hmUI.widget.WATCHFACE_EDIT_GROUP, {
                edit_id: 104,
                x: 171,
                y: 321,
                w: 124,
                h: 124,
                select_image: 'tap/edit_red_1.png',
                un_select_image: 'tap/edit_griin_1.png',
                default_type: 11,
                optional_types: [{
                    type: 0,
                    preview: apps[0][2],
                    title_en: apps[0][0]
                }, {
                    type: 1,
                    preview: apps[1][2],
                    title_en: apps[1][0]
                }, {
                    type: 2,
                    preview: apps[2][2],
                    title_en: apps[2][0]
                }, {
                    type: 3,
                    preview: apps[3][2],
                    title_en: apps[3][0]
                }, {
                    type: 4,
                    preview: apps[4][2],
                    title_en: apps[4][0]
                }, {
                    type: 5,
                    preview: apps[5][2],
                    title_en: apps[5][0]
                }, {
                    type: 6,
                    preview: apps[6][2],
                    title_en: apps[6][0]
                }, {
                    type: 7,
                    preview: apps[7][2],
                    title_en: apps[7][0]
                }, {
                    type: 8,
                    preview: apps[8][2],
                    title_en: apps[8][0]
                }, {
                    type: 9,
                    preview: apps[9][2],
                    title_en: apps[9][0]
                }, {
                    type: 10,
                    preview: apps[10][2],
                    title_en: apps[10][0]
                }, {
                    type: 11,
                    preview: apps[11][2],
                    title_en: apps[11][0]
                }, {
                    type: 12,
                    preview: apps[12][2],
                    title_en: apps[12][0]
                }, {
                    type: 13,
                    preview: apps[13][2],
                    title_en: apps[13][0]
                }, {
                    type: 14,
                    preview: apps[14][2],
                    title_en: apps[14][0]
                }, {
                    type: 15,
                    preview: apps[15][2],
                    title_en: apps[15][0]
                }, {
                    type: 16,
                    preview: apps[16][2],
                    title_en: apps[16][0]
                }, {
                    type: 17,
                    preview: apps[17][2],
                    title_en: apps[17][0]
                }, {
                    type: 18,
                    preview: apps[18][2],
                    title_en: apps[18][0]
                }, {
                    type: 19,
                    preview: apps[19][2],
                    title_en: apps[19][0]
                }, {
                    type: 20,
                    preview: apps[20][2],
                    title_en: apps[20][0]
                }, {
                    type: 21,
                    preview: apps[21][2],
                    title_en: apps[21][0]
                }, {
                    type: 22,
                    preview: apps[22][2],
                    title_en: apps[22][0]
                }, {
                    type: 23,
                    preview: apps[23][2],
                    title_en: apps[23][0]
                }, {
                    type: 24,
                    preview: apps[24][2],
                    title_en: apps[24][0]
                }, {
                    type: 25,
                    preview: apps[25][2],
                    title_en: apps[25][0]
                }, {
                    type: 26,
                    preview: apps[26][2],
                    title_en: apps[26][0]
                }, {
                    type: 27,
                    preview: apps[27][2],
                    title_en: apps[27][0]
                }, {
                    type: 28,
                    preview: apps[28][2],
                    title_en: apps[28][0]
                }, {
                    type: 29,
                    preview: apps[29][2],
                    title_en: apps[29][0]
                }, {
                    type: 30,
                    preview: apps[30][2],
                    title_en: apps[30][0]
                }, {
                    type: 31,
                    preview: apps[31][2],
                    title_en: apps[31][0]
                }, {
                    type: 32,
                    preview: apps[32][2],
                    title_en: apps[32][0]
                }, {
                    type: 33,
                    preview: apps[33][2],
                    title_en: apps[33][0]
                }, ],
                count: 34,
                tips_x: 135 - 171,
                tips_y: 257 - 321,
                tips_width: 195,
                tips_margin: 10,
                tips_BG: 'tap/tips_bg.png'
            })

            let tap_4_select = tap_4_edit.getProperty(hmUI.prop.CURRENT_TYPE)

            const tap_5_edit = hmUI.createWidget(hmUI.widget.WATCHFACE_EDIT_GROUP, {
                edit_id: 105,
                x: 40,
                y: 246,
                w: 124,
                h: 124,
                select_image: 'tap/edit_red_1.png',
                un_select_image: 'tap/edit_griin_1.png',
                default_type: 0,
                optional_types: [{
                    type: 0,
                    preview: apps[0][2],
                    title_en: apps[0][0]
                }, {
                    type: 1,
                    preview: apps[1][2],
                    title_en: apps[1][0]
                }, {
                    type: 2,
                    preview: apps[2][2],
                    title_en: apps[2][0]
                }, {
                    type: 3,
                    preview: apps[3][2],
                    title_en: apps[3][0]
                }, {
                    type: 4,
                    preview: apps[4][2],
                    title_en: apps[4][0]
                }, {
                    type: 5,
                    preview: apps[5][2],
                    title_en: apps[5][0]
                }, {
                    type: 6,
                    preview: apps[6][2],
                    title_en: apps[6][0]
                }, {
                    type: 7,
                    preview: apps[7][2],
                    title_en: apps[7][0]
                }, {
                    type: 8,
                    preview: apps[8][2],
                    title_en: apps[8][0]
                }, {
                    type: 9,
                    preview: apps[9][2],
                    title_en: apps[9][0]
                }, {
                    type: 10,
                    preview: apps[10][2],
                    title_en: apps[10][0]
                }, {
                    type: 11,
                    preview: apps[11][2],
                    title_en: apps[11][0]
                }, {
                    type: 12,
                    preview: apps[12][2],
                    title_en: apps[12][0]
                }, {
                    type: 13,
                    preview: apps[13][2],
                    title_en: apps[13][0]
                }, {
                    type: 14,
                    preview: apps[14][2],
                    title_en: apps[14][0]
                }, {
                    type: 15,
                    preview: apps[15][2],
                    title_en: apps[15][0]
                }, {
                    type: 16,
                    preview: apps[16][2],
                    title_en: apps[16][0]
                }, {
                    type: 17,
                    preview: apps[17][2],
                    title_en: apps[17][0]
                }, {
                    type: 18,
                    preview: apps[18][2],
                    title_en: apps[18][0]
                }, {
                    type: 19,
                    preview: apps[19][2],
                    title_en: apps[19][0]
                }, {
                    type: 20,
                    preview: apps[20][2],
                    title_en: apps[20][0]
                }, {
                    type: 21,
                    preview: apps[21][2],
                    title_en: apps[21][0]
                }, {
                    type: 22,
                    preview: apps[22][2],
                    title_en: apps[22][0]
                }, {
                    type: 23,
                    preview: apps[23][2],
                    title_en: apps[23][0]
                }, {
                    type: 24,
                    preview: apps[24][2],
                    title_en: apps[24][0]
                }, {
                    type: 25,
                    preview: apps[25][2],
                    title_en: apps[25][0]
                }, {
                    type: 26,
                    preview: apps[26][2],
                    title_en: apps[26][0]
                }, {
                    type: 27,
                    preview: apps[27][2],
                    title_en: apps[27][0]
                }, {
                    type: 28,
                    preview: apps[28][2],
                    title_en: apps[28][0]
                }, {
                    type: 29,
                    preview: apps[29][2],
                    title_en: apps[29][0]
                }, {
                    type: 30,
                    preview: apps[30][2],
                    title_en: apps[30][0]
                }, {
                    type: 31,
                    preview: apps[31][2],
                    title_en: apps[31][0]
                }, {
                    type: 32,
                    preview: apps[32][2],
                    title_en: apps[32][0]
                }, {
                    type: 33,
                    preview: apps[33][2],
                    title_en: apps[33][0]
                }, ],
                count: 34,
                tips_x: 5 - 40,
                tips_y: 184 - 246,
                tips_width: 195,
                tips_margin: 10,
                tips_BG: 'tap/tips_bg.png'
            })

            let tap_5_select = tap_5_edit.getProperty(hmUI.prop.CURRENT_TYPE)

            const tap_6_edit = hmUI.createWidget(hmUI.widget.WATCHFACE_EDIT_GROUP, {
                edit_id: 106,
                x: 40,
                y: 95,
                w: 124,
                h: 124,
                select_image: 'tap/edit_red_1.png',
                un_select_image: 'tap/edit_griin_1.png',
                default_type: 0,
                optional_types: [{
                    type: 0,
                    preview: apps[0][2],
                    title_en: apps[0][0]
                }, {
                    type: 1,
                    preview: apps[1][2],
                    title_en: apps[1][0]
                }, {
                    type: 2,
                    preview: apps[2][2],
                    title_en: apps[2][0]
                }, {
                    type: 3,
                    preview: apps[3][2],
                    title_en: apps[3][0]
                }, {
                    type: 4,
                    preview: apps[4][2],
                    title_en: apps[4][0]
                }, {

                    type: 5,
                    preview: apps[5][2],
                    title_en: apps[5][0]
                }, {
                    type: 6,
                    preview: apps[6][2],
                    title_en: apps[6][0]
                }, {
                    type: 7,
                    preview: apps[7][2],
                    title_en: apps[7][0]
                }, {
                    type: 8,
                    preview: apps[8][2],
                    title_en: apps[8][0]
                }, {
                    type: 9,
                    preview: apps[9][2],
                    title_en: apps[9][0]
                }, {
                    type: 10,
                    preview: apps[10][2],
                    title_en: apps[10][0]
                }, {
                    type: 11,
                    preview: apps[11][2],
                    title_en: apps[11][0]
                }, {
                    type: 12,
                    preview: apps[12][2],
                    title_en: apps[12][0]
                }, {
                    type: 13,
                    preview: apps[13][2],
                    title_en: apps[13][0]
                }, {
                    type: 14,
                    preview: apps[14][2],
                    title_en: apps[14][0]
                }, {
                    type: 15,
                    preview: apps[15][2],
                    title_en: apps[15][0]
                }, {
                    type: 16,
                    preview: apps[16][2],
                    title_en: apps[16][0]
                }, {
                    type: 17,
                    preview: apps[17][2],
                    title_en: apps[17][0]
                }, {
                    type: 18,
                    preview: apps[18][2],
                    title_en: apps[18][0]
                }, {
                    type: 19,
                    preview: apps[19][2],
                    title_en: apps[19][0]
                }, {
                    type: 20,
                    preview: apps[20][2],
                    title_en: apps[20][0]
                }, {
                    type: 21,
                    preview: apps[21][2],
                    title_en: apps[21][0]
                }, {
                    type: 22,
                    preview: apps[22][2],
                    title_en: apps[22][0]
                }, {
                    type: 23,
                    preview: apps[23][2],
                    title_en: apps[23][0]
                }, {
                    type: 24,
                    preview: apps[24][2],
                    title_en: apps[24][0]
                }, {
                    type: 25,
                    preview: apps[25][2],
                    title_en: apps[25][0]
                }, {
                    type: 26,
                    preview: apps[26][2],
                    title_en: apps[26][0]
                }, {
                    type: 27,
                    preview: apps[27][2],
                    title_en: apps[27][0]
                }, {
                    type: 28,
                    preview: apps[28][2],
                    title_en: apps[28][0]
                }, {
                    type: 29,
                    preview: apps[29][2],
                    title_en: apps[29][0]
                }, {
                    type: 30,
                    preview: apps[30][2],
                    title_en: apps[30][0]
                }, {
                    type: 31,
                    preview: apps[31][2],
                    title_en: apps[31][0]
                }, {
                    type: 32,
                    preview: apps[32][2],
                    title_en: apps[32][0]
                }, {
                    type: 33,
                    preview: apps[33][2],
                    title_en: apps[33][0]
                }, ],
                count: 34,
                tips_x: 5 - 40,
                tips_y: 225 - 95,

                tips_width: 195,
                tips_margin: 10,
                tips_BG: 'tap/tips_bg.png'
            })

            let tap_6_select = tap_6_edit.getProperty(hmUI.prop.CURRENT_TYPE)


            let btn_tap = ''
            let btn_click_tap_exit = ''

            let btn_Tap_zona_0 = ''
            let btn_Tap_zona_1 = ''
            let btn_Tap_zona_2 = ''
            let btn_Tap_zona_3 = ''
            let btn_Tap_zona_4 = ''
            let btn_Tap_zona_5 = ''

            function tap_zona_exit() {
                groupVremya.setProperty(hmUI.prop.VISIBLE, true);
                groupTap.setProperty(hmUI.prop.VISIBLE, false);
            }

            let tap_x_y = [
                [178, 26, 1],
                [308, 102, 1],
                [308, 253, 1],
                [178, 328, 0],
                [47, 253, 0],
                [47, 102, 0]
            ];

            function tap_run() {
                groupVremya.setProperty(hmUI.prop.VISIBLE, false);
                groupTap.setProperty(hmUI.prop.VISIBLE, true);
            }


            //-------------------------------- 
            //переменные для ргафика
            let weather_ic_array = []
            let weather_ic = []
            let DigDay = []
            let DigNight = []
            let yArrH = [];
            let arr_xH = [];
            let arr_yH = [];
            let arr_x = [];
            let arr_y = [];
            let arr_xL = [];
            let arr_yL = [];
            let yArrAll = [];
            let yArrL = [];
            let y_pogodaH = [];
            let y_pogodaL = [];
            let week_array = ["ПН", "ВТ", "СР", "ЧТ", "ПТ", "СБ", "ВС"];
            let week_text = []
            let data_text = []
            const ROOTPATH = "images/"
            var shag = 46;
            var x0 = 119 - 23 - 23;
            let dney = 8;
            let isDayIcons = false

            let shotWeaterhNames = ["Облачно", "Местами дождь", "Местами снег", "Cолнечно", "Пасмурно", "Слабый дождь", "Слабый снег", "Умеренный дождь", "Умеренный снег", "Сильный снегопад", "Сильный дождь", "Песчаная буря", "Мокрый снег", "Туман", "Дымка", "Дождь с грозой", "Метель", "Пыльно", "Ливень", "Дождь с градом", "Сильный дождь с градом", "Сильный дождь ", "Песчаная буря", "Сильная песчаная буря ", "Сильный дождь", "Неизвестная погода", "Облачно ночью", "Дождливо ночью", "Ясно ночью"];

            //            let app_activ_left = []
            //            let app_activ_right = []
            //            let app_activ_txt_left = []
            //            let app_activ_txt_right = []
            //            let activ_arr_left = [
            //                ['PAI', hmUI.data_type.PAI_WEEKLY, false],
            //                ['КАЛОРИЙ', hmUI.data_type.CAL, false],
            //                ['ШАГОВ', hmUI.data_type.STEP, false],
            //                ['РАЗМИНКА', hmUI.data_type.STAND, false],
            //                ['БУДИЛЬНИК', hmUI.data_type.ALARM_CLOCK, true],
            //                ['ЭТАЖ', hmUI.data_type.FLOOR, false]
            //            ];
            //            let activ_arr_right = [
            //                ['ЖИР', hmUI.data_type.FAT_BURNING, false],
            //                ['ПУЛЬС', hmUI.data_type.HEART, false],
            //                ['КМ', hmUI.data_type.DISTANCE, false],
            //                ['КИСЛОРОД', hmUI.data_type.SPO2, false],
            //                ['ТАЙМЕР', hmUI.data_type.COUNT_DOWN, true],
            //                ['СТРЕСС', hmUI.data_type.STRESS, false]
            //            ];

            let tip_grafik = 0

            function click_tip_grafik() {
                tip_grafik = (tip_grafik + 1) % 2
                hmFS.SysProSetInt('CYBERNETIC_tip_grafik', tip_grafik);
                ic_graf_img.setProperty(hmUI.prop.SRC, "images/Grafik/ic_graf_" + tip_grafik + ".png");
                click_Pogoda_off();
                normal_background_Pogoda.setProperty(hmUI.prop.VISIBLE, true);
                setTimeout(() => {
                    click_Pogoda_on()
                    tip()
                }, 150);
            }

            // let timeSensor = ''

            let normal_city_name_text_0 = ''


            //-------------------------------- 

            //массив иконок для графика       
            for (var i = 0; i <= 28; i++) {
                weather_ic_array.push(ROOTPATH + "Grafik/weather/" + i + ".png"); //0-28
            }


            //обновление для   графика           
            function updateGrafik() {
                if (!timeSensor) timeSensor = hmSensor.createSensor(hmSensor.id.TIME);
                let day_num = [0, 31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31];
                let year = timeSensor.year;
                if (year % 4 == 0 && (year % 100 != 0 || year % 400 == 0)) { // Високосный год
                    day_num[2] = 29
                } else {
                    day_num[2] = 28
                }

                let current = weatherSensor.current;
                let curAirIconIndex = weatherSensor.curAirIconIndex;

                let temperature_current_temp = -100;
                if (weatherSensor.current != undefined && weatherSensor.current != 'undefined') {
                    temperature_current_temp = weatherSensor.current;
                }; // end currentWeather; 

                let weatherData = weatherSensor.getForecastWeather();
                let forecastData = weatherData.forecastData;


                let tideData = weatherData.tideData;
                let sunset_hour = -1;
                let sunset_minute = -1;
                if (tideData.count > 0) {
                    sunset_hour = tideData.data[0].sunset.hour;
                    sunset_minute = tideData.data[0].sunset.minute;
                }; // end tideData;

                let sunsetTime = undefined;
                let normal_sunset_circle_string = undefined;
                if (sunset_hour >= 0 && sunset_minute >= 0) {
                    sunsetTime = 0;
                    normal_sunset_circle_string = String(sunset_hour).padStart(2, '0') + ':' + String(sunset_minute).padStart(2, '0');
                };

                let sunrise_hour = -1;
                let sunrise_minute = -1;
                if (tideData.count > 0) {
                    sunrise_hour = tideData.data[0].sunrise.hour;
                    sunrise_minute = tideData.data[0].sunrise.minute;
                }; // end tideData;

                let sunriseTime = undefined;
                let normal_sunrise_circle_string = undefined;
                if (sunrise_hour >= 0 && sunrise_minute >= 0) {
                    sunriseTime = 0;
                    normal_sunrise_circle_string = String(sunrise_hour).padStart(2, '0') + ':' + String(sunrise_minute).padStart(2, '0');
                };


                normal_temp_text_font.setProperty(hmUI.prop.TEXT, temperature_current_temp + "°С");

                normal_weather_text_font.setProperty(hmUI.prop.TEXT, shotWeaterhNames[curAirIconIndex]);

                normal_city_name_text_0.setProperty(hmUI.prop.TEXT, normal_sunrise_circle_string + "   " + weatherData.cityName + "   " + normal_sunset_circle_string);


                if (forecastData.count == 0) {
                    for (let i = 0; i < dney; i++) {
                        var invalidPath = "--";
                        weather_ic[i].setProperty(hmUI.prop.SRC, ROOTPATH + "Grafik/weather/25.png");
                    }
                } else {
                    let weekDay = timeSensor.week - 1;
                    let data_gr = timeSensor.day;
                    let month_gr = timeSensor.month;

                    for (let i = 0; i < dney; i++) {

                        // let arr_y  = [252, 238, 252, 266, 238, 224, 308, 322];    

                        yArrH[i] = forecastData.data[i].high;

                        let element = forecastData.data[i];
                        let iconIndex = element.index;
                        weather_ic[i].setProperty(hmUI.prop.SRC, weather_ic_array[iconIndex]);
                        let week2 = week_array[weekDay];
                        week_text[i].setProperty(hmUI.prop.MORE, {
                            color: weekDay < 5 ? "0xFFFFFFFF" : "0xFFFF0000",
                            text: week2,
                        });
                        data_text[i].setProperty(hmUI.prop.MORE, {
                            color: weekDay < 5 ? "0xFFFFFFFF" : "0xFFFF0000",
                            text: data_gr,
                        });
                        weekDay = (weekDay + 1) % 7;
                        data_gr = (data_gr + 1)
                        if (data_gr > day_num[month_gr]) data_gr = 1
                        if (i < dney - 1) yArrL[i] = forecastData.data[i].low;

                    }
                }

                sunData = weatherData.tideData;
                if (sunData.count > 0) {
                    today = sunData.data[0];
                    sunriseMins = today.sunrise.hour * 60 + today.sunrise.minute;
                    sunsetMins = today.sunset.hour * 60 + today.sunset.minute;
                } else {
                    sunriseMins = sunriseMins_def;
                    sunsetMins = sunsetMins_def;
                }
                curMins = timeSensor.hour * 60 + timeSensor.minute;
                let isDayNow = (curMins >= sunriseMins) && (curMins < sunsetMins);

                if (isDayNow) {
                    if (!isDayIcons) {
                        isDayIcons = true;
                    }
                } else {
                    if (isDayIcons) {
                        isDayIcons = false;
                    }
                }


                normal_vos_text_font.setProperty(hmUI.prop.VISIBLE, isDayIcons == false);
                normal_vos_icon_img.setProperty(hmUI.prop.VISIBLE, isDayIcons == false);
                normal_zak_text_font.setProperty(hmUI.prop.VISIBLE, isDayIcons == true);
                normal_zak_icon_img.setProperty(hmUI.prop.VISIBLE, isDayIcons == true);


                shotWeaterhNames = isDayIcons == false ? ["Облачно ночью", "Местами дождь", "Местами снег", "Ясно ночью", "Пасмурно ночью", "Слабый дождь", "Слабый снег", "Умеренный дождь", "Умеренный снег", "Сильный снегопад", "Сильный дождь", "Песчаная буря", "Мокрый снег", "Туман", "Дымка", "Дождь с грозой", "Метель", "Пыльно", "Ливень", "Дождь с градом", "Сильный дождь с градом", "Сильный дождь ", "Песчаная буря", "Сильная песчаная буря", "Сильный дождь", "Неизвестная погода", "Облачно ночью", "Дождливо ночью", "Ясно ночью"] : ["Облачно", "Местами дождь", "Местами снег", "Cолнечно", "Пасмурно", "Слабый дождь", "Слабый снег", "Умеренный дождь", "Умеренный снег", "Сильный снегопад", "Сильный дождь", "Песчаная буря", "Мокрый снег", "Туман", "Дымка", "Дождь с грозой", "Метель", "Пыльно", "Ливень", "Дождь с градом", "Сильный дождь с градом", "Сильный дождь ", "Песчаная буря", "Сильная песчаная буря ", "Сильный дождь", "Неизвестная погода", "Облачно ночью", "Дождливо ночью", "Ясно ночью"];

                //  array_ic_weater = isDayIcons == false ?  ["Ъ", "Ы", "Э", "Ь", "Д", "Е", "Ж", "З", "И", "Й", "К", "Л", "М", "Н", "О", "П", "Р", "С", "У", "Ф", "Х", "Ц", "Ч", "Ш", "?", "Ъ", "Ы", "Ь"] : ["А", "Б", "В", "Г", "Д", "Е", "Ж", "З", "И", "Й", "К", "Л", "М", "Н", "О", "П", "Р", "С", "У", "Ф", "Х", "Ц", "Ч", "Ш", "?", "Ъ", "Ы", "Ь"];  

                tip()

            }

            function tip() {

                canvas.clear({
                    x: 0,
                    y: 0,
                    w: D_W,
                    h: D_H
                })


                for (let i = 0; i < dney - 1; i++) {
                    canvas.drawRect({
                        x1: 94 + shag * [i],
                        y1: 93,
                        x2: 94 + shag * [i] + 1,
                        y2: 351,
                        color: 0xc0c0c0
                    })
                }


                let maxH = Math.max(...yArrH)
                let maxL = Math.min(...yArrL)
                let delta = 120 / (maxL - maxH)

                let RedArray = [];
                let BlueArray = [];

                if (tip_grafik == 0) {
                    for (let i = 0; i < dney; i++) {
                        arr_x[i] = x0 + shag * [i];
                        arr_y[i] = yArrH[i] * delta + 162 - maxH * delta;
                    }
                    // let n = arr_x.length;
                    splain(dney)

                    for (let i = 0; i < dney - 1; i++) {
                        arr_x[i] = x0 + 23 + shag * [i];
                        arr_y[i] = yArrL[i] * delta + 162 - maxH * delta;
                    }
                    // n = dney - 1;
                    splain(dney - 1)
                }
                if (tip_grafik == 1) {
                    let k = 0
                    for (let i = 0; i < dney; i++) {

                        yArrAll[k] = yArrH[i]
                        k = k + 1
                        yArrAll[k] = yArrL[i]
                        k = k + 1
                    }


                    for (let i = 0; i < yArrAll.length; i++) {
                        arr_x[i] = x0 + shag / 2 * [i];
                        arr_y[i] = yArrAll[i] * delta + 162 - maxH * delta;
                    }
                    //n = yArrAll.length - 1;
                    splain(yArrAll.length - 1)
                }


                for (let i = 0; i < dney; i++) {
                    if (tip_grafik == 0) {
                        canvas.drawCircle({
                            center_x: x0 + shag * [i],
                            center_y: yArrH[i] * delta + 162 - maxH * delta,
                            radius: 5,
                            color: 0xFF0000
                        })
                    }
                    y_pogodaH[i] = (yArrH[i] * delta + 145 - maxH * delta) - 5;
                    DigDay[i].setProperty(hmUI.prop.more, {
                        x: x0 - 23 - 5 + i * 45 * 1.02,
                        y: y_pogodaH[i] - 18, //120-7//120-7/- 38
                        w: 50,
                        h: 40,
                        color: "0xFFffffff",
                        text_size: 27,
                        text: yArrH[i],
                        text_style: hmUI.text_style.NONE,
                        align_h: hmUI.align.CENTER_H,
                        align_v: hmUI.align.CENTER_V,
                        show_level: hmUI.show_level.ONLY_NORMAL
                    });

                    if (i < dney - 1) {
                        if (tip_grafik == 0) {
                            canvas.drawCircle({
                                center_x: x0 + 23 + shag * [i],
                                center_y: yArrL[i] * delta + 162 - maxH * delta,
                                radius: 5,
                                color: 0x00eaff
                            })
                        }
                        y_pogodaL[i] = (yArrL[i] * delta + 145 - maxH * delta) - 5;;
                        DigNight[i].setProperty(hmUI.prop.more, {
                            x: x0 - 23 - 5 + 23 + i * 45 * 1.02,
                            y: y_pogodaL[i] + 19, //120-7 / - 1  
                            w: 50,
                            h: 40,
                            color: "0xFFffffff",
                            text_size: 27,
                            text: yArrL[i],
                            text_style: hmUI.text_style.NONE,
                            align_h: hmUI.align.CENTER_H,
                            align_v: hmUI.align.CENTER_V,
                            show_level: hmUI.show_level.ONLY_NORMAL
                        });
                    } //dney - 1
                }; //dney   
            }


            function splain(n) {
                let arr_a = new Array(n).fill().map(() => new Array(1));
                let arr_b = new Array(n - 1).fill().map(() => new Array(1));
                let arr_c = new Array(n).fill().map(() => new Array(1));
                let arr_d = new Array(n - 1).fill().map(() => new Array(1));

                let arr_h = new Array(n - 1).fill().map(() => new Array(1));
                let arr_alpha = new Array(n).fill().map(() => new Array(1));
                let arr_l = new Array(n).fill().map(() => new Array(1));
                let arr_mu = new Array(n).fill().map(() => new Array(1));
                let arr_z = new Array(n).fill().map(() => new Array(1));

                for (var i = 0; i < n - 1; i++) {
                    arr_h[i] = arr_x[i + 1] - arr_x[i];
                }

                for (var i = 1; i < n - 1; i++) {
                    arr_alpha[i] = 3 * ((arr_y[i + 1] - arr_y[i]) / arr_h[i] - (arr_y[i] - arr_y[i - 1]) / arr_h[i - 1]);
                }

                arr_l[0] = 1;
                arr_mu[0] = 0;
                arr_z[0] = 0;

                for (var i = 1; i < n - 1; i++) {
                    arr_l[i] = 2 * (arr_x[i + 1] - arr_x[i - 1]) - arr_h[i - 1] * arr_mu[i - 1];
                    arr_mu[i] = arr_h[i] / arr_l[i];
                    arr_z[i] = (arr_alpha[i] - arr_h[i - 1] * arr_z[i - 1]) / arr_l[i];
                }

                arr_l[n - 1] = 1;
                arr_z[n - 1] = 0;
                arr_c[n - 1] = 0;

                for (var j = n - 2; j >= 0; j--) {
                    arr_c[j] = arr_z[j] - arr_mu[j] * arr_c[j + 1];
                    arr_b[j] = (arr_y[j + 1] - arr_y[j]) / arr_h[j] - arr_h[j] * (arr_c[j + 1] + 2 * arr_c[j]) / 3;
                    arr_d[j] = (arr_c[j + 1] - arr_c[j]) / (3 * arr_h[j]);
                    arr_a[j] = arr_y[j];
                }

                for (var i = 0; i < n - 1; i++) {
                    for (xi = arr_x[i]; xi < arr_x[i + 1] - 1; xi += 5) {
                        yi = arr_a[i] + arr_b[i] * (xi - arr_x[i]) + arr_c[i] * Math.pow((xi - arr_x[i]), 2) + arr_d[i] * Math.pow((xi - arr_x[i]), 3);

                        if (tip_grafik == 0) {
                            canvas.drawImage({
                                x: xi,
                                y: yi,
                                w: 5,
                                h: 310 - yi,
                                alpha: 127,
                                image: n == dney ? 'images/Grafik/line_day.png' : 'images/Grafik/line_night.png'
                            })
                        }

                        canvas.drawLine({
                            x1: xi,
                            y1: yi,
                            x2: xi + 5,
                            y2: arr_a[i] + arr_b[i] * (xi + 5 - arr_x[i]) + arr_c[i] * Math.pow((xi + 5 - arr_x[i]), 2) + arr_d[i] * Math.pow((xi + 5 - arr_x[i]), 3),
                            // color: n == dney ? 0xff0000 : 0x00eaff//0x009cff  yArrAll.length - 1
                            color: n == dney ? 0xff0000 : n == dney - 1 ? 0x00eaff : 0x12a2fd //0x009cff
                        })


                    }
                }

            }

            // end user_functions.js

            let normal_stand_icon_img = ''
            let normal_battery_circle_scale = ''
            let normal_step_circle_scale = ''
            let normal_analog_clock_time_pointer_minute = ''
                //let normal_analog_clock_time_pointer_hour = ''
            let normal_analog_clock_pro_hour_pointer_img = ''
            let normal_analog_clock_pro_hour_pointer_img_down = ''
            let normal_analog_clock_pro_hour_cover_pointer_img = ''
            let normal_analog_clock_pro_second_pointer_img = ''
            let normal_timerUpdateSecSmooth = undefined;
            let lastTime = 0;
            let normal_analog_clock_pro_minute_pointer_img = ''
            let normal_timerUpdateSec = undefined;
            let normal_stress_icon_img = ''
            let normal_date_img_date_week_img = ''
            let normal_day_text_font = ''
            let normal_weather_image_progress_img_level = ''
            let normal_temperature_current_text_font = ''
            let normal_heart_rate_text_font = ''
            let normal_spo2_icon_img = ''
            let normal_time_hour_text_font = ''
            let normal_timerTimeUpdate = undefined;
            let normal_time_minute_text_font = ''
            let timeSensor = ''


            //dynamic modify end

            __$$module$$__.module = DeviceRuntimeCore.WatchFace({
                init_view() {
                    //dynamic modify start
                    loadSettings()

                    // FontName: conthrax_sb.ttf; FontSize: 22
                    hmUI.createWidget(hmUI.widget.TEXT, {
                        x: 464,
                        y: 464,
                        w: 387,
                        h: 31,
                        text_size: 22,
                        char_space: 0,
                        line_space: 0,
                        font: 'fonts/conthrax_sb.ttf',
                        color: 0xFFFFFFFF,
                        align_h: hmUI.align.LEFT,
                        align_v: hmUI.align.CENTER_V,
                        text_style: hmUI.text_style.ELLIPSIS,
                        text: "0123456789 _-.,:;`'%°\\/",
                        show_level: hmUI.show_level.ONLY_NORMAL,
                    });

                    // FontName: conthrax_sb.ttf; FontSize: 20
                    hmUI.createWidget(hmUI.widget.TEXT, {
                        x: 464,
                        y: 464,
                        w: 349,
                        h: 27,
                        text_size: 20,
                        char_space: 0,
                        line_space: 0,
                        font: 'fonts/conthrax_sb.ttf',
                        color: 0xFFFF00FF,
                        align_h: hmUI.align.CENTER_H,
                        align_v: hmUI.align.CENTER_V,
                        text_style: hmUI.text_style.ELLIPSIS,
                        text: "0123456789 ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz АБВГДЕЁЖЗИЙКЛМНОПРСТУФХЦЧШЩЪЫЬЭЮЯабвгдеёжзийклмнопрстуфхцчшщъыьэюя  ҐЄІЇґєії _-.,:;`'%°\\/",
                        show_level: hmUI.show_level.ONLY_NORMAL,
                    });

                    // FontName: conthrax_sb.ttf; FontSize: 78
                    hmUI.createWidget(hmUI.widget.TEXT, {
                        x: 464,
                        y: 464,
                        w: 1370,
                        h: 110,
                        text_size: 78,
                        char_space: 0,
                        line_space: 0,
                        font: 'fonts/conthrax_sb.ttf',
                        color: 0xFFFF00FF,
                        align_h: hmUI.align.LEFT,
                        align_v: hmUI.align.CENTER_V,
                        text_style: hmUI.text_style.ELLIPSIS,
                        text: "0123456789 _-.,:;`'%°\\/",
                        show_level: hmUI.show_level.ONLY_NORMAL,
                    });

                    console.log('user_script_start.js');
                    // start user_script_start.js

                    hmUI.createWidget(hmUI.widget.TEXT, {
                        x: 464,
                        y: 464,
                        w: 42,
                        h: 42,
                        text_size: 27,
                        char_space: 0,
                        line_space: 0,
                        font: 'fonts/Bebas11.ttf',
                        color: 0xFFFFFF00,
                        align_h: hmUI.align.LEFT,
                        align_v: hmUI.align.CENTER_V,
                        text_style: hmUI.text_style.NONE,
                        text: "0123456789 ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz АБВГДЕЁЖЗИЙКЛМНОПРСТУФХЦЧШЩЪЫЬЭЮЯабвгдеёжзийклмнопрстуфхцчшщъыьэюя  ҐЄІЇґєії _-.,:;`'%°\\/",
                        show_level: hmUI.show_level.ONLY_NORMAL,
                    });

                    hmUI.createWidget(hmUI.widget.TEXT, {
                        x: 464,
                        y: 464,
                        w: 42,
                        h: 42,
                        text_size: 33,
                        char_space: 0,
                        line_space: 0,
                        font: 'fonts/Bebas11.ttf',
                        color: 0xFFFFFF00,
                        align_h: hmUI.align.LEFT,
                        align_v: hmUI.align.CENTER_V,
                        text_style: hmUI.text_style.NONE,
                        text: "0123456789 ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz АБВГДЕЁЖЗИЙКЛМНОПРСТУФХЦЧШЩЪЫЬЭЮЯабвгдеёжзийклмнопрстуфхцчшщъыьэюя  ҐЄІЇґєії _-.,:;`'%°\\/",
                        show_level: hmUI.show_level.ONLY_NORMAL,
                    });
                    hmUI.createWidget(hmUI.widget.TEXT, {
                        x: 464,
                        y: 464,
                        w: 328,
                        h: 48,
                        text_size: 35,
                        char_space: 0,
                        line_space: 0,
                        font: 'fonts/Bebas11.ttf',
                        color: 0xFFFFFFFF,
                        align_h: hmUI.align.CENTER_H,
                        align_v: hmUI.align.CENTER_V,
                        text_style: hmUI.text_style.ELLIPSIS,
                        text: "0123456789 _-.,:;`'%°\\/↓↑=C",
                        show_level: hmUI.show_level.ONLY_NORMAL,
                    });

                    normal_background_bg = hmUI.createWidget(hmUI.widget.FILL_RECT, {
                        x: 0,
                        y: 0,
                        w: D_W,
                        h: D_H,
                        color: color_bg[0][Ar_Set[0][1]],
                        show_level: hmUI.show_level.ONLY_NORMAL,
                    });
                    // end user_script_start.js

                    console.log('Watch_Face.ScreenNormal');

                    normal_stand_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
                        x: 0,
                        y: 0,
                        src: 'bg.png',
                        show_level: hmUI.show_level.ONLY_NORMAL,
                    });

                    // normal_battery_circle_scale = hmUI.createWidget(hmUI.widget.Circle_Scale, {
                    // center_x: D_W/2,
                    // center_y: D_W/2,
                    // start_angle: -125,
                    // end_angle: -55,
                    // radius: D_W/2,
                    // line_width: 36,
                    // line_cap: Flat,
                    // color: 0xFFFF00FC,
                    // mirror: False,
                    // inversion: False,
                    // type: hmUI.data_type.BATTERY,
                    // show_level: hmUI.show_level.ONLY_NORMAL,
                    // });

                    let screenType = hmSetting.getScreenType();
                    normal_battery_circle_scale = hmUI.createWidget(hmUI.widget.ARC_PROGRESS, {
                        center_x: D_W / 2,
                        center_y: D_W / 2,
                        start_angle: -125,
                        end_angle: -55,
                        radius: 215,
                        line_width: 36,
                        corner_flag: 3,
                        color: color_bg[0][Ar_Set[0][1]],
                        type: hmUI.data_type.BATTERY,
                        show_level: hmUI.show_level.ONLY_NORMAL,
                    });

                    const battery = hmSensor.createSensor(hmSensor.id.BATTERY);
                    battery.addEventListener(hmSensor.event.CHANGE, function () {
                        scale_call();
                    });

                    // normal_step_circle_scale = hmUI.createWidget(hmUI.widget.Circle_Scale, {
                    // center_x: D_W/2,
                    // center_y: D_W/2,
                    // start_angle: 125,
                    // end_angle: 55,
                    // radius: D_W/2,
                    // line_width: 36,
                    // line_cap: Flat,
                    // color: 0xFFFFFFFF,
                    // mirror: False,
                    // inversion: False,
                    // type: hmUI.data_type.STEP,
                    // show_level: hmUI.show_level.ONLY_NORMAL,
                    // });

                    normal_step_circle_scale = hmUI.createWidget(hmUI.widget.ARC_PROGRESS, {
                        center_x: D_W / 2,
                        center_y: D_W / 2,
                        start_angle: 125,
                        end_angle: 55,
                        radius: 215,
                        line_width: 36,
                        corner_flag: 3,
                        color: 0xFFFFFFFF,
                        show_level: hmUI.show_level.ONLY_NORMAL,
                    });

                    const step = hmSensor.createSensor(hmSensor.id.STEP);
                    step.addEventListener(hmSensor.event.CHANGE, function () {
                        scale_call();
                    });

                    normal_analog_clock_time_pointer_minute = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
                        minute_path: 'str_M_down.png',
                        minute_centerX: D_W / 2,
                        minute_centerY: D_W / 2,
                        minute_posX: 189,
                        minute_posY: 189,
                        show_level: hmUI.show_level.ONLY_NORMAL,
                    });

                    const deviceInfo = hmSetting.getDeviceInfo();
                    if (!timeSensor) timeSensor = hmSensor.createSensor(hmSensor.id.TIME);
                    timeSensor.addEventListener(timeSensor.event.MINUTEEND, function () {
                        let updateHour = timeSensor.minute == 0;

                        time_update(updateHour, true);
                    });



                    //                    normal_analog_clock_time_pointer_hour = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
                    //                        hour_path: 'str_H_down.png',
                    //                        hour_centerX: D_W/2,
                    //                        hour_centerY: D_W/2,
                    //                        hour_posX: 189,
                    //                        hour_posY: 189,
                    //                        hour_cover_path: 'cap.png',
                    //                        hour_cover_x: 0,
                    //                        hour_cover_y: 0,
                    //                        show_level: hmUI.show_level.ONLY_NORMAL,
                    //                    });

                    normal_analog_clock_pro_hour_pointer_img_down = hmUI.createWidget(hmUI.widget.IMG, {
                        x: 0,
                        y: 0,
                        w: deviceInfo.width,
                        h: deviceInfo.height,
                        pos_x: D_W / 2 - 183,
                        pos_y: D_W / 2 - 183,
                        center_x: D_W / 2,
                        center_y: D_W / 2,
                        src: 'str_H_down_' + Ar_Set[0][1] + '.png',
                        angle: 0,
                        show_level: hmUI.show_level.ONLY_NORMAL,
                    });





                    normal_analog_clock_pro_hour_pointer_img = hmUI.createWidget(hmUI.widget.IMG, {
                        x: 0,
                        y: 0,
                        w: deviceInfo.width,
                        h: deviceInfo.height,
                        pos_x: D_W / 2 - 14,
                        pos_y: D_W / 2 - 135,
                        center_x: D_W / 2,
                        center_y: D_W / 2,
                        src: 'str_H_up_' + Ar_Set[0][1] + '.png',
                        angle: 0,
                        show_level: hmUI.show_level.ONLY_NORMAL,
                    });





                    normal_analog_clock_pro_hour_cover_pointer_img = hmUI.createWidget(hmUI.widget.IMG, {
                        x: 0,
                        y: 0,
                        src: 'cap.png',
                        show_level: hmUI.show_level.ONLY_NORMAL,
                    });

                    // normal_analog_clock_pro_second_pointer_img = hmUI.createWidget(hmUI.widget.TIME_POINTER_PRO, {
                    // src: 'str_S_0.png',
                    // center_x: D_W/2,
                    // center_y: D_W/2,
                    // x: 183,
                    // y: 183,
                    // start_angle: 0,
                    // end_angle: 360,
                    // type: hmUI.data_type.second,
                    // show_level: hmUI.show_level.ONLY_NORMAL,
                    // });


                    normal_analog_clock_pro_second_pointer_img = hmUI.createWidget(hmUI.widget.IMG, {
                        x: 0,
                        y: 0,
                        w: deviceInfo.width,
                        h: deviceInfo.height,
                        pos_x: D_W / 2 - 183,
                        pos_y: D_W / 2 - 183,
                        center_x: D_W / 2,
                        center_y: D_W / 2,
                        src: 'str_S_' + Ar_Set[0][1] + '.png',
                        angle: 0,
                        show_level: hmUI.show_level.ONLY_NORMAL,
                    });

                    function startSecAnim(sec, animDuration) {
                        const secAnim = {
                            anim_steps: [{
                                anim_rate: 'linear',
                                anim_duration: animDuration,
                                anim_from: sec,
                                anim_to: sec + (360 * (animDuration * 6 / 1000)) / 360,
                                anim_key: 'angle',
                            }],
                            anim_fps: 15,
                            anim_auto_start: 1,
                            anim_repeat: 0,
                            anim_auto_destroy: 1,
                        }
                        normal_analog_clock_pro_second_pointer_img.setProperty(hmUI.prop.ANIM, secAnim);
                    }
                    // normal_analog_clock_pro_minute_pointer_img = hmUI.createWidget(hmUI.widget.TIME_POINTER_PRO, {
                    // src: 'str_M_up.png',
                    // center_x: D_W/2,
                    // center_y: D_W/2,
                    // x: 12,
                    // y: 190,
                    // start_angle: 0,
                    // end_angle: 360,
                    // type: hmUI.data_type.minute,
                    // show_level: hmUI.show_level.ONLY_NORMAL,
                    // });


                    normal_analog_clock_pro_minute_pointer_img = hmUI.createWidget(hmUI.widget.IMG, {
                        x: 0,
                        y: 0,
                        w: deviceInfo.width,
                        h: deviceInfo.height,
                        pos_x: D_W / 2 - 12,
                        pos_y: D_W / 2 - 190,
                        center_x: D_W / 2,
                        center_y: D_W / 2,
                        src: 'str_M_up.png',
                        angle: 0,
                        show_level: hmUI.show_level.ONLY_NORMAL,
                    });

                    // normal_analog_clock_pro_smooth_second = hmUI.createWidget(hmUI.widget.SMOOTH_SECOND, {
                    // type: 4,
                    // fps: 15,
                    // show_level: hmUI.show_level.ONLY_NORMAL,
                    // });


                    normal_stress_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
                        x: 0,
                        y: 0,
                        src: 'cap_up.png',
                        show_level: hmUI.show_level.ONLY_NORMAL,
                    });

                    normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
                        x: 127,
                        y: 5,
                        week_en: ["week_0.png", "week_1.png", "week_2.png", "week_3.png", "week_4.png", "week_5.png", "week_6.png"],
                        week_tc: ["week_0.png", "week_1.png", "week_2.png", "week_3.png", "week_4.png", "week_5.png", "week_6.png"],
                        week_sc: ["week_0.png", "week_1.png", "week_2.png", "week_3.png", "week_4.png", "week_5.png", "week_6.png"],
                        show_level: hmUI.show_level.ONLY_NORMAL,
                    });

                    timeSensor.addEventListener(timeSensor.event.DAYCHANGE, function () {
                        time_update(true);
                    });

                    normal_day_text_font = hmUI.createWidget(hmUI.widget.TEXT, {
                        x: 158,
                        y: 27,
                        w: 150,
                        h: 30,
                        text_size: 22,
                        char_space: 0,
                        line_space: 0,
                        font: 'fonts/conthrax_sb.ttf',
                        color: 0xFFFFFFFF,
                        align_h: hmUI.align.CENTER_H,
                        align_v: hmUI.align.CENTER_V,
                        text_style: hmUI.text_style.ELLIPSIS,
                        // padding: true,
                        show_level: hmUI.show_level.ONLY_NORMAL,
                    });

                    normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
                        x: 52,
                        y: 362,
                        image_array: ["w_0.png", "w_1.png", "w_2.png", "w_3.png", "w_4.png", "w_5.png", "w_6.png", "w_7.png", "w_8.png", "w_9.png", "w_10.png", "w_11.png", "w_12.png", "w_13.png", "w_14.png", "w_15.png", "w_16.png", "w_17.png", "w_18.png", "w_19.png", "w_20.png", "w_21.png", "w_22.png", "w_23.png", "w_24.png", "w_25.png", "w_26.png", "w_27.png", "w_28.png"],
                        image_length: 29,
                        type: hmUI.data_type.WEATHER_CURRENT,
                        show_level: hmUI.show_level.ONLY_NORMAL,
                    });

                    normal_temperature_current_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
                        x: 158,
                        y: 412,
                        w: 150,
                        h: 30,
                        text_size: 20,
                        char_space: 0,
                        line_space: 0,
                        font: 'fonts/conthrax_sb.ttf',
                        color: color_bg[0][Ar_Set[0][1]],
                        align_h: hmUI.align.CENTER_H,
                        align_v: hmUI.align.CENTER_V,
                        unit_type: 1,
                        text_style: hmUI.text_style.ELLIPSIS,
                        type: hmUI.data_type.WEATHER_CURRENT,
                        show_level: hmUI.show_level.ONLY_NORMAL,
                    });

                    normal_heart_rate_text_font = hmUI.createWidget(hmUI.widget.TEXT, {
                        x: 158,
                        y: 412,
                        w: 150,
                        h: 30,
                        text_size: 20,
                        char_space: 0,
                        line_space: 0,
                        font: 'fonts/conthrax_sb.ttf',
                        color: 0xFFFFFFFF,
                        align_h: hmUI.align.CENTER_H,
                        align_v: hmUI.align.CENTER_V,
                        text_style: hmUI.text_style.ELLIPSIS,
                        //type: hmUI.data_type.HEART,
                        show_level: hmUI.show_level.ONLY_NORMAL,
                    });

                    normal_spo2_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
                        x: 137,
                        y: 145,
                        src: 'bg_dig.png',
                        show_level: hmUI.show_level.ONLY_NORMAL,
                    });

                    normal_time_hour_text_font = hmUI.createWidget(hmUI.widget.TEXT, {
                        x: 158,
                        y: 158 - 7,
                        w: 150,
                        h: 100,
                        text_size: 78,
                        char_space: 0,
                        line_space: 0,
                        font: 'fonts/conthrax_sb.ttf',
                        color: color_bg[0][Ar_Set[0][1]],
                        align_h: hmUI.align.CENTER_H,
                        align_v: hmUI.align.CENTER_V,
                        text_style: hmUI.text_style.ELLIPSIS,
                        // padding: true,
                        show_level: hmUI.show_level.ONLY_NORMAL,
                    });

                    normal_time_minute_text_font = hmUI.createWidget(hmUI.widget.TEXT, {
                        x: 158,
                        y: 224 - 7,
                        w: 150,
                        h: 100,
                        text_size: 78,
                        char_space: 0,
                        line_space: 0,
                        font: 'fonts/conthrax_sb.ttf',
                        color: 0xFFFFFFFF,
                        align_h: hmUI.align.CENTER_H,
                        align_v: hmUI.align.CENTER_V,
                        text_style: hmUI.text_style.ELLIPSIS,
                        // padding: true,
                        show_level: hmUI.show_level.ONLY_NORMAL,
                    });


                    normal_bat_text_font = hmUI.createWidget(hmUI.widget.TEXT, {
                        x: 6,
                        y: 6,
                        w: (466 - 6 * 2),
                        h: (466 - 6 * 2),
                        text_size: 20,
                        //text: '99%',
                        char_space: 0,
                        line_space: 0,
                        font: 'fonts/conthrax_sb.ttf',
                        color: color_bg[0][Ar_Set[0][1]],
                        start_angle: -52,
                        end_angle: 0,
                        align_h: hmUI.align.LEFT,
                        //align_v: hmUI.align.CENTER_V,
                        text_style: hmUI.text_style.ELLIPSIS,
                        // unit_string: Пнд, Втр, Срд, Чтв, Птн, Сбт, Вск,
                        show_level: hmUI.show_level.ONLY_NORMAL,
                    });

                    normal_step_text_font = hmUI.createWidget(hmUI.widget.TEXT, {
                        x: 6,
                        y: 6,
                        w: (466 - 6 * 2),
                        h: (466 - 6 * 2),
                        text_size: 20,
                        //text: '99%',
                        char_space: 0,
                        line_space: 0,
                        font: 'fonts/conthrax_sb.ttf',
                        color: 0xffffff,
                        start_angle: 0,
                        end_angle: 52,
                        align_h: hmUI.align.RIGHT,
                        //align_v: hmUI.align.CENTER_V,
                        text_style: hmUI.text_style.ELLIPSIS,
                        // unit_string: Пнд, Втр, Срд, Чтв, Птн, Сбт, Вск,
                        show_level: hmUI.show_level.ONLY_NORMAL,
                    });






                    console.log('user_script_beforeShortcuts.js');
                    // start user_script_beforeShortcuts.js

                    bg_edit_img = hmUI.createWidget(hmUI.widget.IMG, {
                        x: 0,
                        y: 0,
                        src: 'tap/bg_edit.png',
                        show_level: hmUI.show_level.ONLY_EDIT,
                    });

                    groupVremya = hmUI.createWidget(hmUI.widget.GROUP, {
                        x: 0,
                        y: 0,
                        w: D_W,
                        h: D_H,
                    }); // ы

                    groupTap = hmUI.createWidget(hmUI.widget.GROUP, {
                        x: 0,
                        y: 0,
                        w: D_W,
                        h: D_H,
                    });

                    i_tap_bg_img = groupTap.createWidget(hmUI.widget.IMG, {
                        x: 0,
                        y: 0,
                        w: D_W,
                        h: D_H,
                        src: 'tap/i_tap_bg.png',
                        show_level: hmUI.show_level.ONLY_NORMAL,
                    });


                    Tap_zona_0 = groupTap.createWidget(hmUI.widget.IMG, {
                        x: tap_x_y[0][0],
                        y: tap_x_y[0][1],
                        src: apps[tap_1_select][2], //'tap/i_tap_calendar.png',
                        show_level: hmUI.show_level.ONLY_NORMAL,
                    });

                    Tap_zona_1 = groupTap.createWidget(hmUI.widget.IMG, {
                        x: tap_x_y[1][0],
                        y: tap_x_y[1][1],
                        src: apps[tap_2_select][2],
                        show_level: hmUI.show_level.ONLY_NORMAL,
                    });

                    Tap_zona_2 = groupTap.createWidget(hmUI.widget.IMG, {
                        x: tap_x_y[2][0],
                        y: tap_x_y[2][1],
                        src: apps[tap_3_select][2],
                        show_level: hmUI.show_level.ONLY_NORMAL,
                    });

                    Tap_zona_3 = groupTap.createWidget(hmUI.widget.IMG, {
                        x: tap_x_y[3][0],
                        y: tap_x_y[3][1],
                        src: apps[tap_4_select][2],
                        show_level: hmUI.show_level.ONLY_NORMAL,
                    });

                    Tap_zona_4 = groupTap.createWidget(hmUI.widget.IMG, {
                        x: tap_x_y[4][0],
                        y: tap_x_y[4][1],
                        src: apps[tap_5_select][2],
                        show_level: hmUI.show_level.ONLY_NORMAL,
                    });

                    Tap_zona_5 = groupTap.createWidget(hmUI.widget.IMG, {
                        x: tap_x_y[5][0],
                        y: tap_x_y[5][1],
                        src: apps[tap_6_select][2],
                        show_level: hmUI.show_level.ONLY_NORMAL,
                    });


                    btn_Tap_zona_0 = groupTap.createWidget(hmUI.widget.BUTTON, {
                        x: tap_x_y[0][0],
                        y: tap_x_y[0][1],
                        text: '',
                        w: 113,
                        h: 113,
                        normal_src: '0_Empty.png',
                        press_src: '0_Empty.png',
                        click_func: () => {
                            vibro();
                            hmApp.startApp({
                                appid: apps[tap_1_select][3] == 0 ? '' : apps[tap_1_select][1],
                                url: apps[tap_1_select][3] == 0 ? apps[tap_1_select][1] : apps[tap_1_select][4],
                                native: apps[tap_1_select][3] == 0 ? true : '',
                                params: apps[tap_1_select][3] == 0 ? '' : {
                                    from_wf: true,
                                }
                            });

                        },
                        show_level: hmUI.show_level.ONLY_NORMAL,
                    });

                    btn_Tap_zona_1 = groupTap.createWidget(hmUI.widget.BUTTON, {
                        x: tap_x_y[1][0],
                        y: tap_x_y[1][1],
                        text: '',
                        w: 113,
                        h: 113,
                        normal_src: '0_Empty.png',
                        press_src: '0_Empty.png',
                        click_func: () => {
                            vibro();
                            hmApp.startApp({
                                appid: apps[tap_2_select][3] == 0 ? '' : apps[tap_2_select][1],
                                url: apps[tap_2_select][3] == 0 ? apps[tap_2_select][1] : apps[tap_2_select][4],
                                native: apps[tap_2_select][3] == 0 ? true : '',
                                params: apps[tap_2_select][3] == 0 ? '' : {
                                    from_wf: true,
                                }
                            });
                        },
                        show_level: hmUI.show_level.ONLY_NORMAL,
                    });

                    btn_Tap_zona_2 = groupTap.createWidget(hmUI.widget.BUTTON, {
                        x: tap_x_y[2][0],
                        y: tap_x_y[2][1],
                        text: '',
                        w: 113,
                        h: 113,
                        normal_src: '0_Empty.png',
                        press_src: '0_Empty.png',
                        click_func: () => {
                            vibro();
                            hmApp.startApp({
                                appid: apps[tap_3_select][3] == 0 ? '' : apps[tap_3_select][1],
                                url: apps[tap_3_select][3] == 0 ? apps[tap_3_select][1] : apps[tap_3_select][4],
                                native: apps[tap_3_select][3] == 0 ? true : '',
                                params: apps[tap_3_select][3] == 0 ? '' : {
                                    from_wf: true,
                                }
                            });
                        },
                        show_level: hmUI.show_level.ONLY_NORMAL,
                    });

                    btn_Tap_zona_3 = groupTap.createWidget(hmUI.widget.BUTTON, {
                        x: tap_x_y[3][0],
                        y: tap_x_y[3][1],
                        text: '',
                        w: 113,
                        h: 113,
                        normal_src: '0_Empty.png',
                        press_src: '0_Empty.png',
                        click_func: () => {
                            vibro();
                            hmApp.startApp({
                                appid: apps[tap_4_select][3] == 0 ? '' : apps[tap_4_select][1],
                                url: apps[tap_4_select][3] == 0 ? apps[tap_4_select][1] : apps[tap_4_select][4],
                                native: apps[tap_4_select][3] == 0 ? true : '',
                                params: apps[tap_4_select][3] == 0 ? '' : {
                                    from_wf: true,
                                }
                            });
                        },
                        show_level: hmUI.show_level.ONLY_NORMAL,
                    });

                    btn_Tap_zona_4 = groupTap.createWidget(hmUI.widget.BUTTON, {
                        x: tap_x_y[4][0],
                        y: tap_x_y[4][1],
                        text: '',
                        w: 113,
                        h: 113,
                        normal_src: '0_Empty.png',
                        press_src: '0_Empty.png',
                        click_func: () => {
                            vibro();
                            hmApp.startApp({
                                appid: apps[tap_5_select][3] == 0 ? '' : apps[tap_5_select][1],
                                url: apps[tap_5_select][3] == 0 ? apps[tap_5_select][1] : apps[tap_5_select][4],
                                native: apps[tap_5_select][3] == 0 ? true : '',
                                params: apps[tap_5_select][3] == 0 ? '' : {
                                    from_wf: true,
                                }
                            });
                        },
                        show_level: hmUI.show_level.ONLY_NORMAL,
                    });

                    btn_Tap_zona_5 = groupTap.createWidget(hmUI.widget.BUTTON, {
                        x: tap_x_y[5][0],
                        y: tap_x_y[5][1],
                        text: '',
                        w: 113,
                        h: 113,
                        normal_src: '0_Empty.png',
                        press_src: '0_Empty.png',
                        click_func: () => {
                            vibro();
                            hmApp.startApp({
                                appid: apps[tap_6_select][3] == 0 ? '' : apps[tap_6_select][1],
                                url: apps[tap_6_select][3] == 0 ? apps[tap_6_select][1] : apps[tap_6_select][4],
                                native: apps[tap_6_select][3] == 0 ? true : '',
                                params: apps[tap_6_select][3] == 0 ? '' : {
                                    from_wf: true,
                                }
                            });
                        },
                        show_level: hmUI.show_level.ONLY_NORMAL,
                    });


                    btn_tap = groupVremya.createWidget(hmUI.widget.BUTTON, {
                        x: 183,
                        y: 0,
                        text: '',
                        w: 100,
                        h: 100,
                        normal_src: '0_Empty.png',
                        press_src: '0_Empty.png',
                        click_func: () => {
                            vibro();
                            tap_run();
                        },
                        show_level: hmUI.show_level.ONLY_NORMAL,
                    });

                    btn_str = groupVremya.createWidget(hmUI.widget.BUTTON, {
                        x: 183, //x кнопки
                        y: 183, //y кнопки
                        text: '',
                        w: 100, //ширина кнопки
                        h: 100, //высота кнопки
                        normal_src: '0_Empty.png',
                        press_src: '0_Empty.png',
                        click_func: () => {
                            vibro();
                            click_Pogoda_on();
                        },
                        //           longpress_func: () => {
                        //            vibro();
                        //			   blok_btn_on();
                        //           },
                        show_level: hmUI.show_level.ONLY_NORMAL,
                    });

                    btn_Activ = groupVremya.createWidget(hmUI.widget.BUTTON, {
                        x: 183, //x кнопки
                        y: 366, //y кнопки
                        text: '',
                        w: 100, //ширина кнопки
                        h: 100, //высота кнопки
                        normal_src: '0_Empty.png',
                        press_src: '0_Empty.png',
                        click_func: () => {
                            vibro();
                            click_Activ_on();
                        },
                        //           longpress_func: () => {
                        //            vibro();
                        //			   blok_btn_on();
                        //           },
                        show_level: hmUI.show_level.ONLY_NORMAL,
                    });

                    btn_sleep = groupVremya.createWidget(hmUI.widget.BUTTON, {
                        x: 366, //x кнопки
                        y: 183, //y кнопки
                        text: '',
                        w: 100, //ширина кнопки
                        h: 100, //высота кнопки
                        normal_src: '0_Empty.png',
                        press_src: '0_Empty.png',
                        click_func: () => {
                            vibro();
                            click_sleep();
                        },
                        //           longpress_func: () => {
                        //            vibro();
                        //			   blok_btn_on();
                        //           },
                        show_level: hmUI.show_level.ONLY_NORMAL,
                    });


                    btn_click_tap_exit = groupTap.createWidget(hmUI.widget.BUTTON, {
                        x: 183,
                        y: 183,
                        text: '',
                        w: 100,
                        h: 100,
                        normal_src: '0_Empty.png',
                        press_src: '0_Empty.png',
                        click_func: () => {
                            vibro();
                            tap_zona_exit();
                        },
                        show_level: hmUI.show_level.ONLY_NORMAL,
                    });


                    groupSleep = hmUI.createWidget(hmUI.widget.GROUP, {
                        x: 0,
                        y: 0,
                        w: D_W,
                        h: D_H,
                    }); // ы


                    normal_Sleep_bg = groupSleep.createWidget(hmUI.widget.FILL_RECT, {
                        x: 72,
                        y: 99,
                        w: 322,
                        h: 200,
                        color: 0x000000,
                        radius: 20,
                        alpha: 178,
                        show_level: hmUI.show_level.ONLY_NORMAL,
                    });


                    sleep_time_txt = groupSleep.createWidget(hmUI.widget.TEXT, {
                        x: 0, // координата X
                        y: 108, // координата Y
                        w: D_W, // ширина 	
                        h: 40, // высота	
                        text_size: 33, // размер текста
                        text: '',
                        font: 'fonts/Bebas11.ttf',
                        color: 0xffffff, // цвет текста
                        align_h: hmUI.align.CENTER_H,
                        show_level: hmUI.show_level.ONLY_NORMAL,
                    });

                    groupSleep.createWidget(hmUI.widget.TEXT, {
                        x: 103, // координата X
                        y: 144, // координата Y
                        w: D_W, // ширина 	
                        h: 40, // высота	
                        text_size: 33, // размер текста
                        text: 'ЗАСНУЛИ',
                        font: 'fonts/Bebas11.ttf',
                        color: 0x00ff00, // цвет текста
                        align_h: hmUI.align.LEFT,
                        show_level: hmUI.show_level.ONLY_NORMAL,
                    });

                    groupSleep.createWidget(hmUI.widget.TEXT, {
                        x: -105, // координата X
                        y: 144, // координата Y
                        w: D_W, // ширина 	
                        h: 40, // высота	
                        text_size: 33, // размер текста
                        text: 'ПРОСНУЛИСЬ',
                        font: 'fonts/Bebas11.ttf',
                        color: 0xe779ff, // цвет текста
                        align_h: hmUI.align.RIGHT,
                        show_level: hmUI.show_level.ONLY_NORMAL,
                    });


                    sleep_start_time_txt = groupSleep.createWidget(hmUI.widget.TEXT, {
                        x: 103,
                        y: 181,
                        w: D_W, // ширина 	
                        h: 40,
                        text_size: 33,
                        text: '',
                        font: 'fonts/Bebas11.ttf',
                        color: 0x00ff00,
                        align_h: hmUI.align.LEFT,
                        show_level: hmUI.show_level.ONLY_NORMAL,
                    });


                    sleep_end_time_txt = groupSleep.createWidget(hmUI.widget.TEXT, {
                        x: -105, // координата X
                        y: 181,
                        w: D_W, // ширина 	
                        h: 40,
                        text_size: 33,
                        text: '',
                        font: 'fonts/Bebas11.ttf',
                        color: 0xe779ff,
                        align_h: hmUI.align.RIGHT,
                        show_level: hmUI.show_level.ONLY_NORMAL,
                    });

                    wake_time_txt = groupSleep.createWidget(hmUI.widget.TEXT, {
                        x: 0,
                        y: 217,
                        w: D_W,
                        h: 40,
                        text_size: 33,
                        font: 'fonts/Bebas11.ttf',
                        text: '',
                        color: 0xff4949,
                        align_h: hmUI.align.CENTER_H,
                        show_level: hmUI.show_level.ONLY_NORMAL,
                    });

                    sleep_score_txt = groupSleep.createWidget(hmUI.widget.TEXT, {
                        x: 0,
                        y: 256,
                        w: D_W,
                        h: 40,
                        text_size: 33,
                        font: 'fonts/Bebas11.ttf',
                        text: '',
                        color: 0xffffff,
                        align_h: hmUI.align.CENTER_H,
                        show_level: hmUI.show_level.ONLY_NORMAL,
                    });


                    btn_exit_sleep = groupSleep.createWidget(hmUI.widget.BUTTON, {
                        x: 0, //x кнопки
                        y: 0, //y кнопки
                        text: '',
                        w: D_W, //ширина кнопки
                        h: D_H, //высота кнопки
                        normal_src: '0_Empty.png',
                        press_src: '0_Empty.png',
                        click_func: () => {
                            vibro();
                            click_exit_sleep();
                        },
                        //           longpress_func: () => {
                        //            vibro();
                        //			   blok_btn_on();
                        //           },
                        show_level: hmUI.show_level.ONLY_NORMAL,
                    });

                    normal_background_Pogoda = hmUI.createWidget(hmUI.widget.FILL_RECT, {
                        x: 0,
                        y: 0,
                        w: D_W,
                        h: D_H,
                        color: 0x000000,
                        show_level: hmUI.show_level.ONLY_NORMAL,
                    });

                    normal_background_Pogoda.setProperty(hmUI.prop.VISIBLE, false);


                    //---------------------------    погода
                    groupPogoda = hmUI.createWidget(hmUI.widget.GROUP, {
                        x: 0,
                        y: 0,
                        w: D_W,
                        h: D_H,
                        show_level: hmUI.show_level.ONLY_NORMAL,
                    });

                    //                   canvas0 = groupPogoda.createWidget(hmUI.widget.CANVAS, {
                    //                       x: 0,
                    //                       y: 0,
                    //                       w: 0,
                    //                       h: 0
                    //                   });


                    canvas = groupPogoda.createWidget(hmUI.widget.CANVAS, {
                        x: 0,
                        y: 0,
                        w: D_W,
                        h: D_H,
                        show_level: hmUI.show_level.ONLY_NORMAL,
                    });

                    canvas.setPaint({
                        color: 0x00ff00,
                        line_width: 4
                    })


                    normal_temp_text_font = groupPogoda.createWidget(hmUI.widget.TEXT, {
                        x: 115,
                        y: 47 + 5 + 6 + 2 - 29 - 29,
                        w: 236,
                        h: 32,
                        text_size: 27,
                        char_space: 0,
                        line_space: 0,
                        font: 'fonts/Bebas11.ttf',
                        color: 0xFFFFFFFF,
                        align_h: hmUI.align.CENTER_H,
                        align_v: hmUI.align.CENTER_V,
                        text_style: hmUI.text_style.NONE,
                        show_level: hmUI.show_level.ONLY_NORMAL,
                    })

                    normal_weather_text_font = groupPogoda.createWidget(hmUI.widget.TEXT, {
                        x: 115,
                        y: 47 + 5 + 6 + 2 - 29,
                        w: 236,
                        h: 32,
                        text_size: 27,
                        char_space: 0,
                        line_space: 0,
                        font: 'fonts/Bebas11.ttf',
                        color: 0xFFFFFFFF,
                        align_h: hmUI.align.CENTER_H,
                        align_v: hmUI.align.CENTER_V,
                        text_style: hmUI.text_style.NONE,
                        show_level: hmUI.show_level.ONLY_NORMAL,
                    })

                    normal_city_name_text_0 = groupPogoda.createWidget(hmUI.widget.TEXT, {
                        x: 74,
                        y: 47 + 5 + 6 + 2,
                        w: 318,
                        h: 32,
                        text_size: 27,
                        char_space: 0,
                        line_space: 0,
                        font: 'fonts/Bebas11.ttf',
                        color: 0xFFFFFFFF,
                        align_h: hmUI.align.CENTER_H,
                        align_v: hmUI.align.CENTER_V,
                        text_style: hmUI.text_style.NONE,
                        show_level: hmUI.show_level.ONLY_NORMAL,
                    });


                    ic_graf_img = groupPogoda.createWidget(hmUI.widget.IMG, {
                        x: 414,
                        y: 212,
                        src: 'images/Grafik/ic_graf_0.png',
                        show_level: hmUI.show_level.ONLY_NORMAL,
                    });

                    ic_lexxir_img = groupPogoda.createWidget(hmUI.widget.IMG, {
                        x: 10,
                        y: 212,
                        src: 'images/Grafik/ic_lexxir.png',
                        show_level: hmUI.show_level.ONLY_NORMAL,
                    });


                    groupPogoda.createWidget(hmUI.widget.IMG, {
                        x: 177,
                        y: 351,
                        src: ROOTPATH + 'Grafik/ic_activ/bg_wind.png',
                        show_level: hmUI.show_level.ONLY_NORMAL,
                    });

                    groupPogoda.createWidget(hmUI.widget.IMG_LEVEL, {
                        x: 175,
                        y: 351,
                        image_array: [ROOTPATH + "Grafik/ic_activ/wind_0.png", ROOTPATH + "Grafik/ic_activ/wind_1.png", ROOTPATH + "Grafik/ic_activ/wind_2.png", ROOTPATH + "Grafik/ic_activ/wind_3.png", ROOTPATH + "Grafik/ic_activ/wind_4.png", ROOTPATH + "Grafik/ic_activ/wind_5.png", ROOTPATH + "Grafik/ic_activ/wind_6.png", ROOTPATH + "Grafik/ic_activ/wind_7.png"],
                        image_length: 8,
                        type: hmUI.data_type.WIND_DIRECTION,
                        show_level: hmUI.show_level.ONLY_NORMAL,
                    });

                    groupPogoda.createWidget(hmUI.widget.TEXT_FONT, {
                        x: 0,
                        y: 370,
                        w: D_W,
                        h: 40,
                        text_size: 35,
                        char_space: 0,
                        line_space: 0,
                        color: 0xFFFFFFFF,
                        align_h: hmUI.align.CENTER_H,
                        align_v: hmUI.align.CENTER_V,
                        unit_type: 1,
                        text_style: hmUI.text_style.ELLIPSIS,
                        type: hmUI.data_type.WIND,
                        show_level: hmUI.show_level.ONLY_NORMAL,
                    });


                    groupPogoda.createWidget(hmUI.widget.IMG, {
                        x: 318,
                        y: 370,
                        src: ROOTPATH + 'Grafik/ic_activ/ic_davl_txt.png',
                        show_level: hmUI.show_level.ONLY_NORMAL,
                    });

                    groupPogoda.createWidget(hmUI.widget.IMG, {
                        x: 16,
                        y: 171,
                        src: ROOTPATH + 'Grafik/ic_activ/ic_uv.png',
                        show_level: hmUI.show_level.ONLY_NORMAL,
                    });

                    groupPogoda.createWidget(hmUI.widget.TEXT_FONT, {
                        x: -43,
                        y: 265 + 5,
                        w: 150,
                        h: 30,
                        text_size: 27,
                        font: 'fonts/Bebas11.ttf',
                        char_space: 0,
                        line_space: 0,
                        color: 0xFFFFFFFF,
                        align_h: hmUI.align.CENTER_H,
                        align_v: hmUI.align.CENTER_V,
                        text_style: hmUI.text_style.ELLIPSIS,
                        type: hmUI.data_type.UVI,
                        show_level: hmUI.show_level.ONLY_NORMAL,
                    });

                    groupPogoda.createWidget(hmUI.widget.IMG, {
                        x: 420,
                        y: 171,
                        src: ROOTPATH + 'Grafik/ic_activ/ic_visota.png',
                        show_level: hmUI.show_level.ONLY_NORMAL,
                    });

                    groupPogoda.createWidget(hmUI.widget.TEXT_FONT, {
                        x: 359,
                        y: 265 + 5,
                        w: 150,
                        h: 30,
                        text_size: 27,
                        font: 'fonts/Bebas11.ttf',
                        char_space: 0,
                        line_space: 0,
                        color: 0xFFFFFFFF,
                        align_h: hmUI.align.CENTER_H,
                        align_v: hmUI.align.CENTER_V,
                        text_style: hmUI.text_style.ELLIPSIS,
                        type: hmUI.data_type.ALTITUDE,
                        show_level: hmUI.show_level.ONLY_NORMAL,
                    });

                    text_pressere = groupPogoda.createWidget(hmUI.widget.TEXT, {
                        x: 271 - 14,
                        y: 353 + 5,
                        w: 150,
                        h: 40,
                        color: 0xffffff,
                        font: 'fonts/Bebas11.ttf',
                        text_size: 35,
                        align_h: hmUI.align.CENTER_H,
                        align_v: hmUI.align.CENTER_V,
                        text_style: hmUI.text_style.NONE,
                        text: "--",
                    });

                    groupPogoda.createWidget(hmUI.widget.IMG, {
                        x: 61,
                        y: 369,
                        src: ROOTPATH + 'Grafik/ic_activ/ic_vlag_txt.png',
                        show_level: hmUI.show_level.ONLY_NORMAL,
                    });

                    groupPogoda.createWidget(hmUI.widget.TEXT_FONT, {
                        x: 49 + 14,
                        y: 353 + 5,
                        w: 150,
                        h: 40,
                        text_size: 35,
                        char_space: 0,
                        line_space: 0,
                        color: 0xFFFFFFFF,
                        font: 'fonts/Bebas11.ttf',
                        align_h: hmUI.align.CENTER_H,
                        align_v: hmUI.align.CENTER_V,
                        unit_type: 1,
                        text_style: hmUI.text_style.ELLIPSIS,
                        type: hmUI.data_type.HUMIDITY,
                        show_level: hmUI.show_level.ONLY_NORMAL,
                    });


                    for (var i = 0; i < dney; i++) {
                        week_text[i] = groupPogoda.createWidget(hmUI.widget.TEXT, {
                            x: x0 - 3 - 23 + i * 46 * 1.0, //,107 + i * 45 * 1.02,
                            y: 295 - 1 + 2, //- 21
                            w: 50,
                            h: 50,
                            char_space: 0, //-1
                            line_space: 0,
                            color: "0xFFffffff",
                            text: week_array[i],
                            text_size: 22,
                            text_style: hmUI.text_style.NONE,
                            align_h: hmUI.align.CENTER_H,
                            align_v: hmUI.align.CENTER_V,
                            show_level: hmUI.show_level.ONLY_NORMAL
                        });
                        // hmUI.deleteWidget(data_text[i]);
                        data_text[i] = groupPogoda.createWidget(hmUI.widget.TEXT, {
                            x: x0 - 3 - 23 + i * 46 * 1.0, //,107 + i * 45 * 1.02,
                            y: 295 - 1 + 2 + 20, //- 21
                            w: 50,
                            h: 50,

                            char_space: 0, //-1
                            line_space: 0,
                            color: "0xFFffffff",
                            text: 31,
                            text_size: 22,
                            text_style: hmUI.text_style.NONE,
                            align_h: hmUI.align.CENTER_H,
                            align_v: hmUI.align.CENTER_V,
                            show_level: hmUI.show_level.ONLY_NORMAL
                        });

                        weather_ic[i] = groupPogoda.createWidget(hmUI.widget.IMG, {
                            x: x0 - 23 + i * shag,
                            y: 78 + 10, //- 10
                            w: 40,
                            h: 40,
                            // src: weatherArray[i],
                            shortcut: true,
                            show_level: hmUI.show_level.ONLY_NORMAL,
                        });

                        DigDay[i] = groupPogoda.createWidget(hmUI.widget.TEXT);
                        if (i < dney - 1) DigNight[i] = groupPogoda.createWidget(hmUI.widget.TEXT);

                    }


                    btn_Pogoda_off = groupPogoda.createWidget(hmUI.widget.BUTTON, {
                        x: 183, //x кнопки
                        y: 183, //y кнопки
                        text: '',
                        w: 100, //ширина кнопки
                        h: 100, //высота кнопки
                        normal_src: '0_Empty.png',
                        press_src: 'press_100.png',
                        click_func: () => {
                            vibro(); //имя вызываемой функции
                            click_Pogoda_off();
                        },
                        //           longpress_func: () => {
                        //            vibro();
                        //			   blok_btn_off();
                        //           },
                        show_level: hmUI.show_level.ONLY_NORMAL,
                    });

                    btn_tip_grafik = groupPogoda.createWidget(hmUI.widget.BUTTON, {
                        x: 366, //x кнопки
                        y: 183, //y кнопки
                        text: '',
                        w: 100, //ширина кнопки
                        h: 100, //высота кнопки
                        normal_src: '0_Empty.png',
                        press_src: 'press_100.png',
                        click_func: () => {
                            vibro(); //имя вызываемой функции
                            click_tip_grafik();
                        },
                        //           longpress_func: () => {
                        //            vibro();
                        //			   blok_btn_off();
                        //           },
                        show_level: hmUI.show_level.ONLY_NORMAL,
                    });

                    groupPogoda.createWidget(hmUI.widget.BUTTON, {
                        x: 0,
                        y: 183,
                        w: 100,
                        h: 100,
                        text: '',
                        normal_src: 'blank.png',
                        press_src: 'blank.png',
                        click_func: () => {
                            hmApp.startApp({
                                appid: 1051195,
                                url: 'page/index',
                                params: {
                                    from_wf: true,
                                }

                            });
                        },
                    });

                    groupActiv = hmUI.createWidget(hmUI.widget.GROUP, {
                        x: 0,
                        y: 0,
                        w: D_W,
                        h: D_H,
                    });


                    groupActiv.createWidget(hmUI.widget.IMG, {
                        x: 0,
                        y: 0,
                        w: D_W,
                        h: D_H,
                        src: 'images/Grafik/bg_activ.png',
                        show_level: hmUI.show_level.ONLY_NORMAL,
                    });

                    Activ_color_alpha = groupActiv.createWidget(hmUI.widget.CIRCLE, {
                        center_x: D_W / 2,
                        center_y: D_W / 2,
                        radius: D_W / 2,
                        color: color_bg_Activ[color_ic],
                        alpha: color_ic == 0 ? 0 : 255,
                        show_level: hmUI.show_level.ONLY_NORMAL,
                    });

                    groupActiv.createWidget(hmUI.widget.IMG, {
                        x: 0,
                        y: 0,
                        w: D_W,
                        h: D_H,
                        src: 'images/Grafik/bg_activ_mask.png',
                        show_level: hmUI.show_level.ONLY_NORMAL,
                    });

                    groupActiv.createWidget(hmUI.widget.TEXT_FONT, {
                        x: 216,
                        y: 192,
                        w: 150,
                        h: 40,
                        text_size: 37,
                        char_space: 0,
                        line_space: 0,
                        color: 0xFFFFFFFF,
                        align_h: hmUI.align.CENTER_H,
                        align_v: hmUI.align.CENTER_V,
                        text_style: hmUI.text_style.ELLIPSIS,
                        type: hmUI.data_type.WEATHER_HIGH_LOW,
                        show_level: hmUI.show_level.ONLY_NORMAL,
                    });

                    groupActiv.createWidget(hmUI.widget.TEXT_FONT, {
                        x: 157,
                        y: 359,
                        w: 150,
                        h: 40,
                        text_size: 37,
                        char_space: 0,
                        line_space: 0,
                        color: 0xFFFFFFFF,
                        align_h: hmUI.align.CENTER_H,
                        align_v: hmUI.align.CENTER_V,
                        text_style: hmUI.text_style.ELLIPSIS,
                        type: hmUI.data_type.DISTANCE,
                        show_level: hmUI.show_level.ONLY_NORMAL,
                    });

                    groupActiv.createWidget(hmUI.widget.TEXT_FONT, {
                        x: 260,
                        y: 70,
                        w: 150,
                        h: 40,
                        text_size: 37,
                        char_space: 0,
                        line_space: 0,
                        color: 0xFFFFFFFF,
                        align_h: hmUI.align.CENTER_H,
                        align_v: hmUI.align.CENTER_V,
                        text_style: hmUI.text_style.ELLIPSIS,
                        type: hmUI.data_type.PAI_WEEKLY,
                        show_level: hmUI.show_level.ONLY_NORMAL,
                    });

                    normal_vos_icon_img = groupActiv.createWidget(hmUI.widget.IMG, {
                        x: 276,
                        y: 254,
                        src: 'images/Grafik/ic_activ/ic_vos.png',
                        show_level: hmUI.show_level.ONLY_NORMAL,
                    });

                    normal_zak_icon_img = groupActiv.createWidget(hmUI.widget.IMG, {
                        x: 276,
                        y: 254,
                        src: 'images/Grafik/ic_activ/ic_zak.png',
                        show_level: hmUI.show_level.ONLY_NORMAL,
                    });

                    normal_zak_text_font = groupActiv.createWidget(hmUI.widget.TEXT_FONT, {
                        x: 223,
                        y: 308,
                        w: 150,
                        h: 40,
                        text_size: 37,
                        char_space: 0,
                        line_space: 0,
                        color: 0xFFFFFFFF,
                        align_h: hmUI.align.CENTER_H,
                        align_v: hmUI.align.CENTER_V,
                        text_style: hmUI.text_style.ELLIPSIS,
                        type: hmUI.data_type.SUN_SET,
                        show_level: hmUI.show_level.ONLY_NORMAL,
                    });

                    normal_vos_text_font = groupActiv.createWidget(hmUI.widget.TEXT_FONT, {
                        x: 223,
                        y: 308,
                        w: 150,
                        h: 40,
                        text_size: 37,
                        char_space: 0,
                        line_space: 0,
                        color: 0xFFFFFFFF,
                        align_h: hmUI.align.CENTER_H,
                        align_v: hmUI.align.CENTER_V,
                        text_style: hmUI.text_style.ELLIPSIS,
                        type: hmUI.data_type.SUN_RISE,
                        show_level: hmUI.show_level.ONLY_NORMAL,
                    });


                    groupActiv.createWidget(hmUI.widget.TEXT_FONT, {
                        x: 157,
                        y: 70,
                        w: 150,
                        h: 40,
                        text_size: 37,
                        char_space: 0,
                        line_space: 0,
                        color: 0xFFFFFFFF,
                        padding: true,
                        align_h: hmUI.align.CENTER_H,
                        align_v: hmUI.align.CENTER_V,
                        text_style: hmUI.text_style.ELLIPSIS,
                        type: hmUI.data_type.ALARM_CLOCK,
                        show_level: hmUI.show_level.ONLY_NORMAL,
                    });

                    groupActiv.createWidget(hmUI.widget.TEXT_FONT, {
                        x: 51,
                        y: 385,
                        w: 150,
                        h: 40,
                        text_size: 37,
                        char_space: 0,
                        line_space: 0,
                        color: 0xFFFFFFFF,
                        align_h: hmUI.align.CENTER_H,
                        align_v: hmUI.align.CENTER_V,
                        text_style: hmUI.text_style.ELLIPSIS,
                        type: hmUI.data_type.SPO2,
                        show_level: hmUI.show_level.ONLY_NORMAL,
                    });

                    groupActiv.createWidget(hmUI.widget.TEXT_FONT, {
                        x: 333,
                        y: 308,
                        w: 150,
                        h: 40,
                        text_size: 37,
                        char_space: 0,
                        line_space: 0,
                        color: 0xFFFFFFFF,
                        align_h: hmUI.align.CENTER_H,
                        align_v: hmUI.align.CENTER_V,
                        text_style: hmUI.text_style.ELLIPSIS,
                        type: hmUI.data_type.STRESS,
                        show_level: hmUI.show_level.ONLY_NORMAL,
                    });

                    groupActiv.createWidget(hmUI.widget.ARC_PROGRESS, {
                        center_x: 407,
                        center_y: 166,
                        start_angle: -135,
                        end_angle: 135,
                        radius: 39,
                        line_width: 10,
                        corner_flag: 3,
                        color: 0xFFFFFFFF,
                        type: hmUI.data_type.STAND,

                        show_level: hmUI.show_level.ONLY_NORMAL,
                    });

                    groupActiv.createWidget(hmUI.widget.TEXT_FONT, {
                        x: 333,
                        y: 192,
                        w: 150,
                        h: 40,
                        text_size: 37,
                        char_space: 0,
                        line_space: 0,
                        color: 0xFFFFFFFF,
                        align_h: hmUI.align.CENTER_H,
                        align_v: hmUI.align.CENTER_V,
                        text_style: hmUI.text_style.ELLIPSIS,
                        type: hmUI.data_type.STAND,
                        show_level: hmUI.show_level.ONLY_NORMAL,
                    });

                    groupActiv.createWidget(hmUI.widget.ARC_PROGRESS, {
                        center_x: 180,
                        center_y: 280,
                        start_angle: -135,
                        end_angle: 135,
                        radius: 39,
                        line_width: 10,
                        corner_flag: 3,
                        color: 0xFFFFFFFF,
                        type: hmUI.data_type.STEP,
                        show_level: hmUI.show_level.ONLY_NORMAL,
                    });

                    groupActiv.createWidget(hmUI.widget.TEXT_FONT, {
                        x: 260,
                        y: 385,
                        w: 150,
                        h: 40,
                        text_size: 37,
                        char_space: 0,
                        line_space: 0,
                        //padding: true,
                        color: 0xFFFFFFFF,
                        align_h: hmUI.align.CENTER_H,
                        align_v: hmUI.align.CENTER_V,
                        text_style: hmUI.text_style.ELLIPSIS,
                        type: hmUI.data_type.FLOOR,
                        show_level: hmUI.show_level.ONLY_NORMAL,
                    });

                    groupActiv.createWidget(hmUI.widget.TEXT_FONT, {
                        x: 99,
                        y: 308,
                        w: 150,
                        h: 40,
                        text_size: 37,
                        char_space: 0,
                        line_space: 0,
                        color: 0xFFFFFFFF,
                        align_h: hmUI.align.CENTER_H,
                        align_v: hmUI.align.CENTER_V,
                        text_style: hmUI.text_style.ELLIPSIS,
                        type: hmUI.data_type.STEP,
                        show_level: hmUI.show_level.ONLY_NORMAL,
                    });

                    groupActiv.createWidget(hmUI.widget.ARC_PROGRESS, {
                        center_x: 175 + 116,
                        center_y: 166,
                        start_angle: -135,
                        end_angle: 135,
                        radius: 39,
                        line_width: 10,
                        corner_flag: 3,
                        color: 0xFFFFFFFF,
                        type: hmUI.data_type.WEATHER_CURRENT,
                        show_level: hmUI.show_level.ONLY_NORMAL,
                    });

                    groupActiv.createWidget(hmUI.widget.ARC_PROGRESS, {
                        center_x: 175 + 116 + 116,
                        center_y: 166 + 116,
                        start_angle: -135,
                        end_angle: 135,
                        radius: 39,
                        line_width: 10,
                        corner_flag: 3,
                        color: 0xFFFFFFFF,
                        type: hmUI.data_type.STRESS,
                        show_level: hmUI.show_level.ONLY_NORMAL,
                    });

                    groupActiv.createWidget(hmUI.widget.ARC_PROGRESS, {
                        center_x: 175 + 116 + 7,
                        center_y: 166 + 116,
                        start_angle: -135,
                        end_angle: 135,
                        radius: 39,
                        line_width: 10,
                        corner_flag: 3,
                        color: 0xFFFFFFFF,
                        type: hmUI.data_type.SUN_CURRENT,
                        show_level: hmUI.show_level.ONLY_NORMAL,
                    });

                    groupActiv.createWidget(hmUI.widget.ARC_PROGRESS, {
                        center_x: 175,
                        center_y: 166,
                        start_angle: -135,
                        end_angle: 135,
                        radius: 39,
                        line_width: 10,
                        corner_flag: 3,
                        color: 0xFFFFFFFF,
                        type: hmUI.data_type.HEART,
                        show_level: hmUI.show_level.ONLY_NORMAL,
                    });

                    groupActiv.createWidget(hmUI.widget.TEXT_FONT, {
                        x: 99,
                        y: 192,
                        w: 150,
                        h: 40,
                        text_size: 37,
                        char_space: 0,
                        line_space: 0,
                        color: 0xFFFFFFFF,
                        align_h: hmUI.align.CENTER_H,
                        align_v: hmUI.align.CENTER_V,
                        text_style: hmUI.text_style.ELLIPSIS,
                        type: hmUI.data_type.HEART,
                        show_level: hmUI.show_level.ONLY_NORMAL,
                    });

                    groupActiv.createWidget(hmUI.widget.ARC_PROGRESS, {
                        center_x: 59,
                        center_y: 282,
                        start_angle: -135,
                        end_angle: 135,
                        radius: 39,
                        line_width: 10,
                        corner_flag: 3,
                        color: 0xFFFFFFFF,
                        type: hmUI.data_type.FAT_BURNING,
                        show_level: hmUI.show_level.ONLY_NORMAL,
                    });

                    groupActiv.createWidget(hmUI.widget.TEXT_FONT, {
                        x: -17,
                        y: 308,
                        w: 150,
                        h: 40,
                        text_size: 37,
                        char_space: 0,
                        line_space: 0,
                        color: 0xFFFFFFFF,
                        align_h: hmUI.align.CENTER_H,
                        align_v: hmUI.align.CENTER_V,
                        text_style: hmUI.text_style.ELLIPSIS,
                        type: hmUI.data_type.FAT_BURNING,
                        show_level: hmUI.show_level.ONLY_NORMAL,
                    });

                    groupActiv.createWidget(hmUI.widget.ARC_PROGRESS, {
                        center_x: 59,
                        center_y: 166,
                        start_angle: -135,
                        end_angle: 135,
                        radius: 39,
                        line_width: 10,
                        corner_flag: 3,
                        color: 0xFFFFFFFF,
                        type: hmUI.data_type.CAL,
                        show_level: hmUI.show_level.ONLY_NORMAL,
                    });

                    groupActiv.createWidget(hmUI.widget.TEXT_FONT, {
                        x: 51,
                        y: 70,
                        w: 150,
                        h: 40,
                        text_size: 37,
                        char_space: 0,
                        line_space: 0,
                        padding: true,
                        color: 0xFFFFFFFF,
                        align_h: hmUI.align.CENTER_H,
                        align_v: hmUI.align.CENTER_V,
                        text_style: hmUI.text_style.ELLIPSIS,
                        type: hmUI.data_type.COUNT_DOWN,
                        show_level: hmUI.show_level.ONLY_NORMAL,
                    });

                    groupActiv.createWidget(hmUI.widget.TEXT_FONT, {
                        x: -17,
                        y: 192,
                        w: 150,
                        h: 40,
                        text_size: 37,
                        char_space: 0,
                        line_space: 0,
                        color: 0xFFFFFFFF,
                        align_h: hmUI.align.CENTER_H,
                        align_v: hmUI.align.CENTER_V,
                        text_style: hmUI.text_style.ELLIPSIS,
                        type: hmUI.data_type.CAL,
                        show_level: hmUI.show_level.ONLY_NORMAL,
                    });

                    ic_activ_color_off_img = groupActiv.createWidget(hmUI.widget.IMG, {
                        x: 363,
                        y: 346,
                        src: 'images/Grafik/ic_activ_color_off.png',
                        show_level: hmUI.show_level.ONLY_NORMAL,
                    });
                    ic_activ_color_off_img.setProperty(hmUI.prop.VISIBLE, Activ_color == 0);


                    btn_Activ_off = groupActiv.createWidget(hmUI.widget.BUTTON, {
                        x: 183, //x кнопки
                        y: 183, //y кнопки
                        text: '',
                        w: 100, //ширина кнопки
                        h: 100, //высота кнопки
                        normal_src: '0_Empty.png',
                        press_src: 'press_100.png',
                        click_func: () => {
                            vibro(); //имя вызываемой функции
                            click_Activ_off();
                        },
                        show_level: hmUI.show_level.ONLY_NORMAL,
                    });

                    btn_Activ_color = groupActiv.createWidget(hmUI.widget.BUTTON, {
                        x: 325, //x кнопки
                        y: 303, //y кнопки
                        text: '',
                        w: 100, //ширина кнопки
                        h: 100, //высота кнопки
                        normal_src: '0_Empty.png',
                        press_src: 'press_100.png',
                        click_func: () => {
                            vibro(); //имя вызываемой функции
                            click_Activ_color();
                        },
                        show_level: hmUI.show_level.ONLY_NORMAL,
                    });

                    g_ACR_color = hmUI.createWidget(hmUI.widget.GROUP, {
                        x: 0,
                        y: 0,
                        w: D_W,
                        h: D_H,
                    })

                    //цвет	
                    menu_ARC_PROGRES_bg = g_ACR_color.createWidget(hmUI.widget.ARC_PROGRESS, {
                        center_x: D_W / 2,
                        center_y: D_W / 2,
                        start_angle: 60 - 15,
                        end_angle: 120 + 15,
                        radius: 219,
                        line_width: 16,
                        corner_flag: 0,
                        color: 0xFF5b5b5b,
                        level: 100,
                        show_level: hmUI.show_level.ONLY_NORMAL,
                    });

                    menu_ARC_PROGRES = g_ACR_color.createWidget(hmUI.widget.ARC_PROGRESS, {
                        center_x: D_W / 2,
                        center_y: D_W / 2,
                        start_angle: 45 + 90 / color_bg[0].length * (-Ar_Set[0][1] * 95), // start_angle: 45 + 90 / array * gde,
                        end_angle: 135 + 90 / color_bg[0].length * (-Ar_Set[0][1] * 95), //end_angle: 135 + 90 / array * gde,
                        radius: 219,
                        line_width: 16,
                        corner_flag: 0,
                        color: 0xFF0000, //0xFF007eff
                        level: 100 / color_bg[0].length, //level: pointer,
                        show_level: hmUI.show_level.ONLY_NORMAL,
                    });


                    for (let j = 0; j < Ar_Set.length; j++) {
                        for (let i = 0; i < color_bg[j].length; i++) {
                            menu_ARC_color[j][i] = hmUI.createWidget(hmUI.widget.ARC_PROGRESS, {
                                center_x: D_W / 2,
                                center_y: D_W / 2,
                                start_angle: 45 + 90 / color_bg[j].length * i,
                                end_angle: 135 + 90 / color_bg[j].length * i,
                                radius: 219 - 16,
                                line_width: 16,
                                corner_flag: 0,
                                color: color_bg[j][i],
                                level: 100 / color_bg[j].length,
                                show_level: hmUI.show_level.ONLY_NORMAL,
                            });
                        };
                    };


                    for (let j = 0; j < Ar_Set.length; j++) {
                        for (let i = 0; i < color_bg[j].length; i++) {
                            menu_ARC_color[j][i].setProperty(hmUI.prop.VISIBLE, false);
                        };
                    };

                    g_ACR_color.setProperty(hmUI.prop.VISIBLE, false);


                    g_Set = hmUI.createWidget(hmUI.widget.GROUP, {
                        x: 0,
                        y: 0,
                        w: D_W,
                        h: D_H,
                    })

                    normal_background_Set = g_Set.createWidget(hmUI.widget.FILL_RECT, {
                        x: 0,
                        y: 0,
                        w: D_W,
                        h: D_H,
                        color: 0x000000,
                        // radius: 12,
                        alpha: 153,
                        show_level: hmUI.show_level.ONLY_NORMAL,
                    });


                    for (let i = 0; i < Ar_Set.length; i++) {
                        Btn_set_[i] = g_Set.createWidget(hmUI.widget.BUTTON, {
                            x: Ar_Set.length <= 5 ? 153 : i < Math.ceil(Ar_Set.length / 2) ? 70 : D_W / 2,
                            y: Ar_Set.length <= 5 ? 70 + i * Shag_Y : i < Math.ceil(Ar_Set.length / 2) ? 70 + i * Shag_Y : 70 + i * Shag_Y - Shag_Y * Math.ceil(Ar_Set.length / 2),
                            w: 160,
                            h: 60,
                            text: Ar_Set[i][0],
                            char_space: 0,
                            line_space: -35,
                            color: 0xFFFFFFFF,
                            text_size: 24,
                            radius: 12,
                            press_color: 0xFFFF0000,
                            normal_color: i != crown ? 0x000000 : 0x800000,
                            click_func: () => {
                                vibro();
                                click_crown(i);
                                //crown == i

                            },
                            text_style: hmUI.text_style.WRAP,
                            show_level: hmUI.show_level.ONLY_NORMAL,
                        }); // end button
                    };

                    btn_Set_exit = g_Set.createWidget(hmUI.widget.BUTTON, {
                        x: 203, //x кнопки
                        y: 70 + Shag_Y * 5, //y кнопки
                        w: 60,
                        h: 60,
                        text: "ОК",
                        char_space: 0,
                        line_space: -35,
                        color: 0xFFFFFFFF,
                        text_size: 24,
                        radius: 12,
                        press_color: 0xFFFF0000,
                        normal_color: 0xFF000000,
                        click_func: () => {
                            vibro();
                            click_Set_off();
                        },
                        text_style: hmUI.text_style.WRAP,
                        show_level: hmUI.show_level.ONLY_NORMAL,
                    });
                    g_Set.setProperty(hmUI.prop.VISIBLE, false);


                    btn_crown = groupVremya.createWidget(hmUI.widget.BUTTON, {
                        x: 307, //x кнопки
                        y: 61, //y кнопки
                        text: '',
                        w: 100, //ширина кнопки
                        h: 100, //высота кнопки
                        normal_src: '0_Empty.png',
                        press_src: '0_Empty.png',
                        click_func: () => {
                            // vibro();
                            click_Set_on();
                        },
                        //           longpress_func: () => {
                        //            vibro();
                        //			   blok_btn_on();
                        //           },
                        show_level: hmUI.show_level.ONLY_NORMAL,
                    });


                    groupVremya.setProperty(hmUI.prop.VISIBLE, true);
                    groupTap.setProperty(hmUI.prop.VISIBLE, false);
                    groupPogoda.setProperty(hmUI.prop.VISIBLE, false);
                    groupActiv.setProperty(hmUI.prop.VISIBLE, false);
                    groupSleep.setProperty(hmUI.prop.VISIBLE, false);
                    // end user_script_beforeShortcuts.js

                    //start of ignored block
                    function time_update(updateHour = false, updateMinute = false) {
                        console.log('time_update()');
                        let hour = timeSensor.hour;
                        let minute = timeSensor.minute;
                        let second = timeSensor.second;
                        let format_hour = timeSensor.format_hour;

                        if (updateHour) {
                            let normal_hour = hour;
                            let normal_fullAngle_hour = 360;
                            if (normal_hour > 11) normal_hour -= 12;
                            let normal_angle_hour = 0 + normal_fullAngle_hour * normal_hour / 12 + (normal_fullAngle_hour / 12) * minute / 60;
                            if (normal_analog_clock_pro_hour_pointer_img) normal_analog_clock_pro_hour_pointer_img.setProperty(hmUI.prop.ANGLE, normal_angle_hour);

                            if (normal_analog_clock_pro_hour_pointer_img_down) normal_analog_clock_pro_hour_pointer_img_down.setProperty(hmUI.prop.ANGLE, normal_angle_hour);


                        };

                        if (updateMinute) {
                            let normal_fullAngle_minute = 360;
                            let normal_angle_minute = 0 + normal_fullAngle_minute * (minute + second / 60) / 60;
                            if (normal_analog_clock_pro_minute_pointer_img) normal_analog_clock_pro_minute_pointer_img.setProperty(hmUI.prop.ANGLE, normal_angle_minute);
                        };

                        console.log('day font');
                        if (updateHour) {
                            let normal_dayStr = timeSensor.day.toString();
                            normal_dayStr = normal_dayStr.padStart(2, '0');
                            normal_day_text_font.setProperty(hmUI.prop.TEXT, normal_dayStr);
                        };

                        console.log('hour font');
                        if (updateHour) {
                            let normal_hourStr = format_hour.toString();
                            normal_hourStr = normal_hourStr.padStart(2, '0');
                            normal_time_hour_text_font.setProperty(hmUI.prop.TEXT, normal_hourStr);
                        };

                        console.log('minute font');
                        if (updateMinute) {
                            let normal_minuteStr = minute.toString();
                            normal_minuteStr = normal_minuteStr.padStart(2, '0');
                            normal_time_minute_text_font.setProperty(hmUI.prop.TEXT, normal_minuteStr);
                        };

                    };

                    //end of ignored block
                    function scale_call() {

                        let valueHeart = heart_rate.last;

                        normal_heart_rate_text_font.setProperty(hmUI.prop.TEXT, "ЧСС " + valueHeart);


                        let valueBattery = battery.current;
                        let targetBattery = 100;
                        let progressBattery = valueBattery / targetBattery;
                        if (progressBattery > 1) progressBattery = 1;
                        let progress_cs_normal_battery = progressBattery;


                        normal_bat_text_font.setProperty(hmUI.prop.TEXT, valueBattery + "%");

                        //                        if (screenType != hmSetting.screen_type.AOD) {
                        //
                        //                            // normal_battery_circle_scale_circle_scale
                        //                            let level = Math.round(progress_cs_normal_battery * 100);
                        //                            if (normal_battery_circle_scale) {
                        //                                normal_battery_circle_scale.setProperty(hmUI.prop.MORE, {
                        //                                    center_x: D_W/2,
                        //                                    center_y: D_W/2,
                        //                                    start_angle: -125,
                        //                                    end_angle: -55,
                        //                                    radius: 215,
                        //                                    line_width: 36,
                        //                                    corner_flag: 3,
                        //                                    color: 0xFFFF00FC,
                        //                                    show_level: hmUI.show_level.ONLY_NORMAL,
                        //                                    level: level,
                        //                                });
                        //                            };
                        //                        };

                        console.log('update scales STEP');

                        let valueStep = step.current;
                        let targetStep = step.target;
                        let progressStep = valueStep / targetStep;
                        if (progressStep > 1) progressStep = 1;
                        let progress_cs_normal_step = progressStep;

                        let distStr = parseInt(step.current * 100 / step.target)
                        normal_step_text_font.setProperty(hmUI.prop.TEXT, distStr + '%');

                        if (screenType != hmSetting.screen_type.AOD) {

                            // normal_step_circle_scale_circle_scale
                            let level = Math.round(progress_cs_normal_step * 100);
                            if (normal_step_circle_scale) {
                                normal_step_circle_scale.setProperty(hmUI.prop.MORE, {
                                    center_x: D_W / 2,
                                    center_y: D_W / 2,
                                    start_angle: 125,
                                    end_angle: 55,
                                    radius: 215,
                                    line_width: 36,
                                    corner_flag: 3,
                                    color: 0xFFFFFFFF,
                                    show_level: hmUI.show_level.ONLY_NORMAL,
                                    level: level,
                                });
                            };
                        };

                    };

                    anim_point()


                    const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
                        resume_call: (function () {
                            console.log('resume_call()');
                            scale_call();
                            time_update(true, true);
                            let secAngle = 0 + (360 * 6) * (timeSensor.second + ((timeSensor.utc % 1000) / 1000)) / 360;
                            normal_analog_clock_pro_second_pointer_img.setProperty(hmUI.prop.ANGLE, secAngle);
                            if (screenType == hmSetting.screen_type.WATCHFACE) {
                                if (!normal_timerUpdateSecSmooth) {
                                    let duration = 0;
                                    let animDuration = 5000;
                                    if (timeSensor.second > 55) animDuration = 1000 * (60.1 - (timeSensor.second - (timeSensor.utc % 1000) / 1000));
                                    let diffTime = timeSensor.utc - lastTime;
                                    if (diffTime < animDuration) duration = animDuration - diffTime;
                                    normal_timerUpdateSecSmooth = timer.createTimer(duration, animDuration, (function (option) {
                                        lastTime = timeSensor.utc;
                                        secAngle = 0 + (360 * 6) * (timeSensor.second + ((timeSensor.utc % 1000) / 1000)) / 360;
                                        startSecAnim(secAngle, animDuration);
                                    })); // end timer 
                                }; // end timer check
                            }; // end screenType

                            if (screenType == hmSetting.screen_type.WATCHFACE) {
                                if (!normal_timerUpdateSec) {
                                    let animDelay = timeSensor.utc % 1000;
                                    let animRepeat = 1000;
                                    normal_timerUpdateSec = timer.createTimer(animDelay, animRepeat, (function (option) {
                                        time_update(false, true);
                                    })); // end timer 
                                }; // end timer check
                            }; // end screenType

                            if (screenType == hmSetting.screen_type.WATCHFACE) {
                                if (!normal_timerTimeUpdate) {
                                    normal_timerTimeUpdate = timer.createTimer(0, 1000, (function (option) {


                                        let updateHour = timeSensor.minute == 0 && timeSensor.second < 2;
                                        let updateMinute = timeSensor.second < 2;
                                        time_update(updateHour, updateMinute);
                                    })); // end timer 
                                }; // end timer check
                            }; // end screenType


                            console.log('resume_call.js');
                            // start resume_call.js

                            //-----------  сон------------------
                            sleepTotalTime = sleep.getTotalTime();
                            sleepInfo = sleep.getBasicInfo();
                            sleepStartTime = sleepInfo.startTime;
                            if (sleepStartTime >= 24 * 60) {
                                sleepStartTime -= 24 * 60
                            }

                            sleepEndTime = sleepInfo.endTime + 1;
                            if (sleepEndTime >= 24 * 60) {
                                sleepEndTime -= 24 * 60
                            }

                            //-----------  время пробуждений ------------------
                            let wakeTime = 0;
                            sleepStageArray = sleep.getSleepStageData();

                            for (let i = 0; i < sleepStageArray.length; i++) {
                                let data = sleepStageArray[i];
                                if (data.model == modelData.WAKE_STAGE) {
                                    wakeTime += data.stop + 1 - data.start;
                                }

                            }

                            sleepTotalTime -= wakeTime;
                            //-------------------------------------------------

                            sleep_time_txt.setProperty(hmUI.prop.TEXT, 'СПАЛИ ' + Math.floor(sleepTotalTime / 60).toString().padStart(2, "0") + ':' + (sleepTotalTime % 60).toString().padStart(2, "0"));
                            sleep_start_time_txt.setProperty(hmUI.prop.TEXT, Math.floor(sleepStartTime / 60).toString().padStart(2, "0") + ':' + (sleepStartTime % 60).toString().padStart(2, "0"));
                            sleep_end_time_txt.setProperty(hmUI.prop.TEXT, Math.floor(sleepEndTime / 60).toString().padStart(2, "0") + ':' + (sleepEndTime % 60).toString().padStart(2, "0"));
                            wake_time_txt.setProperty(hmUI.prop.TEXT, 'ПРОСЫПАЛИСЬ ' + String(wakeTime) + ' мин.');
                            sleep_score_txt.setProperty(hmUI.prop.TEXT, 'КАЧЕСТВО ' + String(sleepScore) + ' %');
                            //-------------------------------------------------


                            let pressure_array = read_pressure();
                            let value = getPressureValue(pressure_array);
                            value = hPa_To_mmHg(value); // если нужно перевести в мм.рт.ст.

                            let pressere_changes_str = "=";
                            //let color_pressere = 0x00ff00;
                            let color_pressere_0 = value < 760 ? 0xffff00 : value > 760 ? 0xff0000 : 0x00ff00;

                            let pressere_changes = changesPressure(pressure_array);
                            if (pressere_changes < 0) {
                                pressere_changes_str = "↓"; /*color_pressere = 0xffff00;*/
                            }
                            if (pressere_changes > 0) {
                                pressere_changes_str = "↑"; /*color_pressere = 0xff0000;*/
                            }
                            //text_pressere_changes.setProperty(hmUI.prop.TEXT, pressere_changes_str);

                            let value_str = value == 0 ? "--" : value + pressere_changes_str;
                            text_pressere.setProperty(hmUI.prop.TEXT, value_str);
                            text_pressere.setProperty(hmUI.prop.COLOR, color_pressere_0);



                            stopVibro();
                            updateGrafik();
                            click_Pogoda_off();
                            setTimeout(() => {
                                onDigitalCrown();
                            }, 150);
                            // end resume_call.js

                        }),
                        pause_call: (function () {
                            console.log('pause_call()');
                            if (normal_timerUpdateSecSmooth) {
                                timer.stopTimer(normal_timerUpdateSecSmooth);
                                normal_timerUpdateSecSmooth = undefined;
                            }
                            if (normal_timerUpdateSec) {
                                timer.stopTimer(normal_timerUpdateSec);
                                normal_timerUpdateSec = undefined;
                            }
                            if (normal_timerTimeUpdate) {
                                timer.stopTimer(normal_timerTimeUpdate);
                                normal_timerTimeUpdate = undefined;
                            }

                            console.log('pause_call.js');
                            // start pause_call.js

                            stopVibro();
                            groupTap.setProperty(hmUI.prop.VISIBLE, false);
                            hmApp.unregisterSpinEvent();
                            groupVremya.setProperty(hmUI.prop.VISIBLE, true);
                            groupPogoda.setProperty(hmUI.prop.VISIBLE, false);
                            groupActiv.setProperty(hmUI.prop.VISIBLE, false);
                            groupSleep.setProperty(hmUI.prop.VISIBLE, false);
                            // end pause_call.js

                        }),
                    });

                    //dynamic modify end
                },
                onInit() {
                    if (hmSetting.getScreenType() == hmSetting.screen_type.AOD) {
                        stopVibro();
                        loadSettings();
                    }
                },
                build() {
                    this.init_view();
                    logger.log('index page.js on ready invoke');
                },
                onDestroy() {
                    logger.log('index page.js on destroy invoke');
                }
            });;
        })();
    } catch (e) {
        console.log('Mini Program Error', e);
        e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));;
    }
