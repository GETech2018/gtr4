﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        const logger = Logger.getLogger('watchface_SashaCX75');
        //end of ignored block

        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_date_img_date_week_img = ''
        let normal_date_img_date_day = ''
        let normal_date_day_separator_img = ''
        let editableZone_1_pai_circle_scale = null;
        let editableZone_1_step_circle_scale = null;
        let editableZone_1_heart_rate_circle_scale = null;
        let editableZone_1_calorie_circle_scale = null;
        let editGroup_1  = ''
        let editableZone_2_heart_rate_circle_scale = null;
        let editableZone_2_pai_circle_scale = null;
        let editableZone_2_step_circle_scale = null;
        let editableZone_2_calorie_circle_scale = null;
        let editGroup_2  = ''
        let editableZone_3_step_circle_scale = null;
        let editableZone_3_heart_rate_circle_scale = null;
        let editableZone_3_pai_circle_scale = null;
        let editableZone_3_calorie_circle_scale = null;
        let editGroup_3  = ''
        let fg_mask = ''
        let editableTimePointers = ''
        let normal_pai_jumpable_img_click = ''
        let normal_heart_jumpable_img_click = ''
        let normal_step_jumpable_img_click = ''


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            console.log('Watch_Face.ScreenNormal');
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 466,
              h: 466,
              src: 'base2.png',
              show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_EDIT,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 306,
              y: 208,
              week_en: ["0035.png","0036.png","0037.png","0038.png","0039.png","0040.png","0041.png"],
              week_tc: ["0035.png","0036.png","0037.png","0038.png","0039.png","0040.png","0041.png"],
              week_sc: ["0035.png","0036.png","0037.png","0038.png","0039.png","0040.png","0041.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 328,
              day_startY: 240,
              day_sc_array: ["0025.png","0026.png","0027.png","0028.png","0029.png","0030.png","0031.png","0032.png","0033.png","0034.png"],
              day_tc_array: ["0025.png","0026.png","0027.png","0028.png","0029.png","0030.png","0031.png","0032.png","0033.png","0034.png"],
              day_en_array: ["0025.png","0026.png","0027.png","0028.png","0029.png","0030.png","0031.png","0032.png","0033.png","0034.png"],
              day_zero: 1,
              day_space: 0,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_day_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 328,
              y: 169,
              src: 'date.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            console.log('Watch_Face.Editable_Elements');

            let screenType = hmSetting.getScreenType();            
            const pai = hmSensor.createSensor(hmSensor.id.PAI);
            
            const step = hmSensor.createSensor(hmSensor.id.STEP);
            
            const heart_rate = hmSensor.createSensor(hmSensor.id.HEART);
            
            const calorie = hmSensor.createSensor(hmSensor.id.CALORIE);

            editGroup_1 = hmUI.createWidget(hmUI.widget.WATCHFACE_EDIT_GROUP, {
              edit_id: 10021,
              x: 174,
              y: 59,
              w: 120,
              h: 120,
              select_image: 'select.png',
              un_select_image: 'unselect.png',
              default_type: hmUI.edit_type.PAI,
              optional_types: [
                { type: hmUI.edit_type.PAI, preview: 'ez(1)_PAI.png' },
                { type: hmUI.edit_type.STEP, preview: 'ez(1)_STEP.png' },
                { type: hmUI.edit_type.HEART, preview: 'ez(1)_HEART.png' },
                { type: hmUI.edit_type.CAL, preview: 'ez(1)_CAL.png' },
                { type: hmUI.edit_type.WEATHER, preview: 'ez(1)_WEATHER.png' },
              ],
              count: 5,
              select_list: {
                title_font_size: 34,
                title_align_h: hmUI.align.CENTER_H,
                list_item_vspace: 8,
                list_tips_text_font_size: 32,
                list_tips_text_align_h: hmUI.align.LEFT
              },
              tips_BG: 'tips_info.png',
              tips_x: 1,
              tips_y: -48,
              tips_width: 120,
              tips_margin: 0,
            });

            const editType_1 = editGroup_1.getProperty(hmUI.prop.CURRENT_TYPE);

            switch (editType_1) {
              case hmUI.edit_type.STEP:
                // editableZone_1_step_circle_scale = hmUI.createWidget(hmUI.widget.Circle_Scale, {
                  // center_x: 234,
                  // center_y: 122,
                  // start_angle: 26,
                  // end_angle: 336,
                  // radius: 55,
                  // line_width: 6,
                  // line_cap: Rounded,
                  // color: 0xFFA2C2F7,
                  // mirror: False,
                  // inversion: False,
                  // type: hmUI.data_type.STEP,
                  // show_level: hmUI.show_level.ONLY_NORMAL,
                // });

                if (screenType == hmSetting.screen_type.WATCHFACE) {
                  editableZone_1_step_circle_scale = hmUI.createWidget(hmUI.widget.ARC_PROGRESS, {
                  center_x: 234,
                  center_y: 122,
                  start_angle: 26,
                  end_angle: 336,
                  radius: 52,
                  line_width: 6,
                  corner_flag: 0,
                  color: 0xFFA2C2F7,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                  });
                };
                step.addEventListener(hmSensor.event.CHANGE, function() {
                  scale_call();
                });

                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                  x: 190,
                  y: 112,
                  font_array: ["0025.png","0026.png","0027.png","0028.png","0029.png","0030.png","0031.png","0032.png","0033.png","0034.png"],
                  padding: false,
                  h_space: -1,
                  align_h: hmUI.align.CENTER_H,
                  type: hmUI.data_type.STEP,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });

                hmUI.createWidget(hmUI.widget.IMG, {
                  x: 216,
                  y: 60,
                  src: 'icon_steps.png',
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });
                break;

              case hmUI.edit_type.CAL:
                // editableZone_1_cal_circle_scale = hmUI.createWidget(hmUI.widget.Circle_Scale, {
                  // center_x: 234,
                  // center_y: 122,
                  // start_angle: 26,
                  // end_angle: 336,
                  // radius: 55,
                  // line_width: 6,
                  // line_cap: Rounded,
                  // color: 0xFFA2C2F7,
                  // mirror: False,
                  // inversion: False,
                  // type: hmUI.data_type.CAL,
                  // show_level: hmUI.show_level.ONLY_NORMAL,
                // });

                if (screenType == hmSetting.screen_type.WATCHFACE) {
                  editableZone_1_calorie_circle_scale = hmUI.createWidget(hmUI.widget.ARC_PROGRESS, {
                  center_x: 234,
                  center_y: 122,
                  start_angle: 26,
                  end_angle: 336,
                  radius: 52,
                  line_width: 6,
                  corner_flag: 0,
                  color: 0xFFA2C2F7,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                  });
                };
                calorie.addEventListener(hmSensor.event.CHANGE, function() {
                  scale_call();
                });

                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                  x: 198,
                  y: 112,
                  font_array: ["0025.png","0026.png","0027.png","0028.png","0029.png","0030.png","0031.png","0032.png","0033.png","0034.png"],
                  padding: false,
                  h_space: 0,
                  align_h: hmUI.align.CENTER_H,
                  type: hmUI.data_type.CAL,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });

                hmUI.createWidget(hmUI.widget.IMG, {
                  x: 219,
                  y: 56,
                  src: 'icon_cal.png',
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });
                break;

              case hmUI.edit_type.HEART:
                // editableZone_1_heart_circle_scale = hmUI.createWidget(hmUI.widget.Circle_Scale, {
                  // center_x: 234,
                  // center_y: 122,
                  // start_angle: 26,
                  // end_angle: 336,
                  // radius: 55,
                  // line_width: 6,
                  // line_cap: Rounded,
                  // color: 0xFFA2C2F7,
                  // mirror: False,
                  // inversion: False,
                  // type: hmUI.data_type.HEART,
                  // show_level: hmUI.show_level.ONLY_NORMAL,
                // });

                if (screenType == hmSetting.screen_type.WATCHFACE) {
                  editableZone_1_heart_rate_circle_scale = hmUI.createWidget(hmUI.widget.ARC_PROGRESS, {
                  center_x: 234,
                  center_y: 122,
                  start_angle: 26,
                  end_angle: 336,
                  radius: 52,
                  line_width: 6,
                  corner_flag: 0,
                  color: 0xFFA2C2F7,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                  });
                };
                heart_rate.addEventListener(hmSensor.event.LAST, function() {
                  scale_call();
                });

                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                  x: 207,
                  y: 112,
                  font_array: ["0025.png","0026.png","0027.png","0028.png","0029.png","0030.png","0031.png","0032.png","0033.png","0034.png"],
                  padding: false,
                  h_space: 0,
                  align_h: hmUI.align.CENTER_H,
                  type: hmUI.data_type.HEART,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });

                hmUI.createWidget(hmUI.widget.IMG, {
                  x: 219,
                  y: 62,
                  src: 'icon_pulse.png',
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });
                break;

              case hmUI.edit_type.PAI:
                // editableZone_1_pai_weekly_circle_scale = hmUI.createWidget(hmUI.widget.Circle_Scale, {
                  // center_x: 234,
                  // center_y: 122,
                  // start_angle: 26,
                  // end_angle: 336,
                  // radius: 55,
                  // line_width: 6,
                  // line_cap: Rounded,
                  // color: 0xFFA2C2F7,
                  // mirror: False,
                  // inversion: False,
                  // type: hmUI.data_type.PAI_WEEKLY,
                  // show_level: hmUI.show_level.ONLY_NORMAL,
                // });

                if (screenType == hmSetting.screen_type.WATCHFACE) {
                  editableZone_1_pai_circle_scale = hmUI.createWidget(hmUI.widget.ARC_PROGRESS, {
                    center_x: 234,
                    center_y: 122,
                    start_angle: 26,
                    end_angle: 336,
                    radius: 52,
                    line_width: 6,
                    corner_flag: 0,
                    color: 0xFFA2C2F7,
                    show_level: hmUI.show_level.ONLY_NORMAL,
                  });
                };
                pai.addEventListener(hmSensor.event.CHANGE, function() {
                  scale_call();
                });

                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                  x: 207,
                  y: 112,
                  font_array: ["0025.png","0026.png","0027.png","0028.png","0029.png","0030.png","0031.png","0032.png","0033.png","0034.png"],
                  padding: false,
                  h_space: 0,
                  align_h: hmUI.align.CENTER_H,
                  type: hmUI.data_type.PAI_WEEKLY,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });

                hmUI.createWidget(hmUI.widget.IMG, {
                  x: 216,
                  y: 60,
                  src: 'pai.png',
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });
                break;

              case hmUI.edit_type.WEATHER:
                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                  x: 205,
                  y: 111,
                  font_array: ["0025.png","0026.png","0027.png","0028.png","0029.png","0030.png","0031.png","0032.png","0033.png","0034.png"],
                  padding: false,
                  h_space: 0,
                  unit_sc: '0048.png',
                  unit_tc: '0048.png',
                  unit_en: '0048.png',
                  negative_image: 'minus.png',
                  invalid_image: 'minus.png',
                  align_h: hmUI.align.CENTER_H,
                  type: hmUI.data_type.WEATHER_CURRENT,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });

                hmUI.createWidget(hmUI.widget.IMG, {
              x: 216,
              y: 54,
              src: 'icon_weather.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
                });
                break;
            }; // end switch

            editGroup_2 = hmUI.createWidget(hmUI.widget.WATCHFACE_EDIT_GROUP, {
              edit_id: 10022,
              x: 63,
              y: 171,
              w: 120,
              h: 120,
              select_image: 'select.png',
              un_select_image: 'unselect.png',
              default_type: hmUI.edit_type.HEART,
              optional_types: [
                { type: hmUI.edit_type.HEART, preview: 'ez(1)_HEART.png' },
                { type: hmUI.edit_type.PAI, preview: 'ez(1)_PAI.png' },
                { type: hmUI.edit_type.STEP, preview: 'ez(1)_STEP.png' },
                { type: hmUI.edit_type.CAL, preview: 'ez(1)_CAL.png' },
                { type: hmUI.edit_type.WEATHER, preview: 'ez(1)_WEATHER.png' },
              ],
              count: 5,
              select_list: {
                title_font_size: 34,
                title_align_h: hmUI.align.CENTER_H,
                list_item_vspace: 8,
                list_tips_text_font_size: 32,
                list_tips_text_align_h: hmUI.align.LEFT
              },
              tips_BG: 'tips_info.png',
              tips_x: 3,
              tips_y: -41,
              tips_width: 120,
              tips_margin: 0,
            });

            const editType_2 = editGroup_2.getProperty(hmUI.prop.CURRENT_TYPE);

            switch (editType_2) {
              case hmUI.edit_type.STEP:
                // editableZone_2_step_circle_scale = hmUI.createWidget(hmUI.widget.Circle_Scale, {
                  // center_x: 123,
                  // center_y: 234,
                  // start_angle: 26,
                  // end_angle: 336,
                  // radius: 55,
                  // line_width: 6,
                  // line_cap: Rounded,
                  // color: 0xFFA2C2F7,
                  // mirror: False,
                  // inversion: False,
                  // type: hmUI.data_type.STEP,
                  // show_level: hmUI.show_level.ONLY_NORMAL,
                // });

                if (screenType == hmSetting.screen_type.WATCHFACE) {
                  editableZone_2_step_circle_scale = hmUI.createWidget(hmUI.widget.ARC_PROGRESS, {
                  center_x: 123,
                  center_y: 234,
                  start_angle: 26,
                  end_angle: 336,
                  radius: 52,
                  line_width: 6,
                  corner_flag: 0,
                  color: 0xFFA2C2F7,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                  });
                };

                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                  x: 80,
                  y: 222,
                  font_array: ["0025.png","0026.png","0027.png","0028.png","0029.png","0030.png","0031.png","0032.png","0033.png","0034.png"],
                  padding: false,
                  h_space: -1,
                  align_h: hmUI.align.CENTER_H,
                  type: hmUI.data_type.STEP,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });

                hmUI.createWidget(hmUI.widget.IMG, {
                  x: 107,
                  y: 171,
                  src: 'icon_steps.png',
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });
                break;

              case hmUI.edit_type.CAL:
                // editableZone_2_cal_circle_scale = hmUI.createWidget(hmUI.widget.Circle_Scale, {
                  // center_x: 123,
                  // center_y: 234,
                  // start_angle: 26,
                  // end_angle: 336,
                  // radius: 55,
                  // line_width: 6,
                  // line_cap: Rounded,
                  // color: 0xFFA2C2F7,
                  // mirror: False,
                  // inversion: False,
                  // type: hmUI.data_type.CAL,
                  // show_level: hmUI.show_level.ONLY_NORMAL,
                // });

                if (screenType == hmSetting.screen_type.WATCHFACE) {
                  editableZone_2_calorie_circle_scale = hmUI.createWidget(hmUI.widget.ARC_PROGRESS, {
                  center_x: 123,
                  center_y: 234,
                  start_angle: 26,
                  end_angle: 336,
                  radius: 52,
                  line_width: 6,
                  corner_flag: 0,
                  color: 0xFFA2C2F7,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                  });
                };

                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                  x: 87,
                  y: 222,
                  font_array: ["0025.png","0026.png","0027.png","0028.png","0029.png","0030.png","0031.png","0032.png","0033.png","0034.png"],
                  padding: false,
                  h_space: 0,
                  align_h: hmUI.align.CENTER_H,
                  type: hmUI.data_type.CAL,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });

                hmUI.createWidget(hmUI.widget.IMG, {
                  x: 108,
                  y: 167,
                  src: 'icon_cal.png',
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });
                break;

              case hmUI.edit_type.HEART:
                // editableZone_2_heart_circle_scale = hmUI.createWidget(hmUI.widget.Circle_Scale, {
                  // center_x: 123,
                  // center_y: 234,
                  // start_angle: 26,
                  // end_angle: 336,
                  // radius: 55,
                  // line_width: 6,
                  // line_cap: Rounded,
                  // color: 0xFFA2C2F7,
                  // mirror: False,
                  // inversion: False,
                  // type: hmUI.data_type.HEART,
                  // show_level: hmUI.show_level.ONLY_NORMAL,
                // });

                if (screenType == hmSetting.screen_type.WATCHFACE) {
                  editableZone_2_heart_rate_circle_scale = hmUI.createWidget(hmUI.widget.ARC_PROGRESS, {
                  center_x: 123,
                  center_y: 234,
                  start_angle: 26,
                  end_angle: 336,
                  radius: 52,
                  line_width: 6,
                  corner_flag: 0,
                  color: 0xFFA2C2F7,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                  });
                };

                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                  x: 95,
                  y: 222,
                  font_array: ["0025.png","0026.png","0027.png","0028.png","0029.png","0030.png","0031.png","0032.png","0033.png","0034.png"],
                  padding: false,
                  h_space: 0,
                  align_h: hmUI.align.CENTER_H,
                  type: hmUI.data_type.HEART,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });

                hmUI.createWidget(hmUI.widget.IMG, {
                  x: 108,
                  y: 173,
                  src: 'icon_pulse.png',
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });
                break;

              case hmUI.edit_type.PAI:
                // editableZone_2_pai_weekly_circle_scale = hmUI.createWidget(hmUI.widget.Circle_Scale, {
                  // center_x: 123,
                  // center_y: 234,
                  // start_angle: 26,
                  // end_angle: 336,
                  // radius: 55,
                  // line_width: 6,
                  // line_cap: Rounded,
                  // color: 0xFFA2C2F7,
                  // mirror: False,
                  // inversion: False,
                  // type: hmUI.data_type.PAI_WEEKLY,
                  // show_level: hmUI.show_level.ONLY_NORMAL,
                // });

                if (screenType == hmSetting.screen_type.WATCHFACE) {
                  editableZone_2_pai_circle_scale = hmUI.createWidget(hmUI.widget.ARC_PROGRESS, {
                    center_x: 123,
                    center_y: 234,
                    start_angle: 26,
                    end_angle: 336,
                    radius: 52,
                    line_width: 6,
                    corner_flag: 0,
                    color: 0xFFA2C2F7,
                    show_level: hmUI.show_level.ONLY_NORMAL,
                  });
                };

                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                  x: 95,
                  y: 222,
                  font_array: ["0025.png","0026.png","0027.png","0028.png","0029.png","0030.png","0031.png","0032.png","0033.png","0034.png"],
                  padding: false,
                  h_space: 0,
                  align_h: hmUI.align.CENTER_H,
                  type: hmUI.data_type.PAI_WEEKLY,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });

                hmUI.createWidget(hmUI.widget.IMG, {
                  x: 104,
                  y: 171,
                  src: 'pai.png',
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });
                break;

              case hmUI.edit_type.WEATHER:
                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                  x: 95,
                  y: 222,
                  font_array: ["0025.png","0026.png","0027.png","0028.png","0029.png","0030.png","0031.png","0032.png","0033.png","0034.png"],
                  padding: false,
                  h_space: 0,
                  unit_sc: '0048.png',
                  unit_tc: '0048.png',
                  unit_en: '0048.png',
                  negative_image: 'minus.png',
                  invalid_image: 'minus.png',
                  align_h: hmUI.align.CENTER_H,
                  type: hmUI.data_type.WEATHER_CURRENT,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });

                hmUI.createWidget(hmUI.widget.IMG, {
              x: 104,
              y: 166,
              src: 'icon_weather.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
                });
                break;
            }; // end switch

            editGroup_3 = hmUI.createWidget(hmUI.widget.WATCHFACE_EDIT_GROUP, {
              edit_id: 10023,
              x: 174,
              y: 282,
              w: 120,
              h: 120,
              select_image: 'select.png',
              un_select_image: 'unselect.png',
              default_type: hmUI.edit_type.STEP,
              optional_types: [
                { type: hmUI.edit_type.STEP, preview: 'ez(1)_STEP.png' },
                { type: hmUI.edit_type.HEART, preview: 'ez(1)_HEART.png' },
                { type: hmUI.edit_type.PAI, preview: 'ez(1)_PAI.png' },
                { type: hmUI.edit_type.CAL, preview: 'ez(1)_CAL.png' },
                { type: hmUI.edit_type.WEATHER, preview: 'ez(1)_WEATHER.png' },
              ],
              count: 5,
              select_list: {
                title_font_size: 34,
                title_align_h: hmUI.align.CENTER_H,
                list_item_vspace: 8,
                list_tips_text_font_size: 32,
                list_tips_text_align_h: hmUI.align.LEFT
              },
              tips_BG: 'tips_info.png',
              tips_x: 1,
              tips_y: -53,
              tips_width: 120,
              tips_margin: 0,
            });

            const editType_3 = editGroup_3.getProperty(hmUI.prop.CURRENT_TYPE);

            switch (editType_3) {
              case hmUI.edit_type.STEP:
                // editableZone_3_step_circle_scale = hmUI.createWidget(hmUI.widget.Circle_Scale, {
                  // center_x: 233,
                  // center_y: 345,
                  // start_angle: 26,
                  // end_angle: 336,
                  // radius: 55,
                  // line_width: 6,
                  // line_cap: Rounded,
                  // color: 0xFFA2C2F7,
                  // mirror: False,
                  // inversion: False,
                  // type: hmUI.data_type.STEP,
                  // show_level: hmUI.show_level.ONLY_NORMAL,
                // });

                if (screenType == hmSetting.screen_type.WATCHFACE) {
                  editableZone_3_step_circle_scale = hmUI.createWidget(hmUI.widget.ARC_PROGRESS, {
                  center_x: 233,
                  center_y: 345,
                  start_angle: 26,
                  end_angle: 336,
                  radius: 52,
                  line_width: 6,
                  corner_flag: 0,
                  color: 0xFFA2C2F7,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                  });
                };

                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                  x: 191,
                  y: 332,
                  font_array: ["0025.png","0026.png","0027.png","0028.png","0029.png","0030.png","0031.png","0032.png","0033.png","0034.png"],
                  padding: false,
                  h_space: -1,
                  align_h: hmUI.align.CENTER_H,
                  type: hmUI.data_type.STEP,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });

                hmUI.createWidget(hmUI.widget.IMG, {
                  x: 218,
                  y: 280,
                  src: 'icon_steps.png',
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });
                break;

              case hmUI.edit_type.CAL:
                // editableZone_3_cal_circle_scale = hmUI.createWidget(hmUI.widget.Circle_Scale, {
                  // center_x: 233,
                  // center_y: 345,
                  // start_angle: 26,
                  // end_angle: 336,
                  // radius: 55,
                  // line_width: 6,
                  // line_cap: Rounded,
                  // color: 0xFFA2C2F7,
                  // mirror: False,
                  // inversion: False,
                  // type: hmUI.data_type.CAL,
                  // show_level: hmUI.show_level.ONLY_NORMAL,
                // });

                if (screenType == hmSetting.screen_type.WATCHFACE) {
                  editableZone_3_calorie_circle_scale = hmUI.createWidget(hmUI.widget.ARC_PROGRESS, {
                  center_x: 233,
                  center_y: 345,
                  start_angle: 26,
                  end_angle: 336,
                  radius: 52,
                  line_width: 6,
                  corner_flag: 0,
                  color: 0xFFA2C2F7,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                  });
                };

                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                  x: 198,
                  y: 332,
                  font_array: ["0025.png","0026.png","0027.png","0028.png","0029.png","0030.png","0031.png","0032.png","0033.png","0034.png"],
                  padding: false,
                  h_space: 0,
                  align_h: hmUI.align.CENTER_H,
                  type: hmUI.data_type.CAL,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });

                hmUI.createWidget(hmUI.widget.IMG, {
                  x: 219,
                  y: 277,
                  src: 'icon_cal.png',
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });
                break;

              case hmUI.edit_type.HEART:
                // editableZone_3_heart_circle_scale = hmUI.createWidget(hmUI.widget.Circle_Scale, {
                  // center_x: 233,
                  // center_y: 345,
                  // start_angle: 26,
                  // end_angle: 336,
                  // radius: 55,
                  // line_width: 6,
                  // line_cap: Rounded,
                  // color: 0xFFA2C2F7,
                  // mirror: False,
                  // inversion: False,
                  // type: hmUI.data_type.HEART,
                  // show_level: hmUI.show_level.ONLY_NORMAL,
                // });

                if (screenType == hmSetting.screen_type.WATCHFACE) {
                  editableZone_3_heart_rate_circle_scale = hmUI.createWidget(hmUI.widget.ARC_PROGRESS, {
                  center_x: 233,
                  center_y: 345,
                  start_angle: 26,
                  end_angle: 336,
                  radius: 52,
                  line_width: 6,
                  corner_flag: 0,
                  color: 0xFFA2C2F7,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                  });
                };

                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                  x: 207,
                  y: 332,
                  font_array: ["0025.png","0026.png","0027.png","0028.png","0029.png","0030.png","0031.png","0032.png","0033.png","0034.png"],
                  padding: false,
                  h_space: 0,
                  align_h: hmUI.align.CENTER_H,
                  type: hmUI.data_type.HEART,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });

                hmUI.createWidget(hmUI.widget.IMG, {
                  x: 219,
                  y: 282,
                  src: 'icon_pulse.png',
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });
                break;

              case hmUI.edit_type.PAI:
                // editableZone_3_pai_weekly_circle_scale = hmUI.createWidget(hmUI.widget.Circle_Scale, {
                  // center_x: 233,
                  // center_y: 345,
                  // start_angle: 26,
                  // end_angle: 336,
                  // radius: 55,
                  // line_width: 6,
                  // line_cap: Rounded,
                  // color: 0xFFA2C2F7,
                  // mirror: False,
                  // inversion: False,
                  // type: hmUI.data_type.PAI_WEEKLY,
                  // show_level: hmUI.show_level.ONLY_NORMAL,
                // });

                if (screenType == hmSetting.screen_type.WATCHFACE) {
                  editableZone_3_pai_circle_scale = hmUI.createWidget(hmUI.widget.ARC_PROGRESS, {
                    center_x: 233,
                    center_y: 345,
                    start_angle: 26,
                    end_angle: 336,
                    radius: 52,
                    line_width: 6,
                    corner_flag: 0,
                    color: 0xFFA2C2F7,
                    show_level: hmUI.show_level.ONLY_NORMAL,
                  });
                };

                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                  x: 207,
                  y: 332,
                  font_array: ["0025.png","0026.png","0027.png","0028.png","0029.png","0030.png","0031.png","0032.png","0033.png","0034.png"],
                  padding: false,
                  h_space: 0,
                  align_h: hmUI.align.CENTER_H,
                  type: hmUI.data_type.PAI_WEEKLY,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });

                hmUI.createWidget(hmUI.widget.IMG, {
                  x: 216,
                  y: 280,
                  src: 'pai.png',
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });
                break;

              case hmUI.edit_type.WEATHER:
                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                  x: 204,
                  y: 332,
                  font_array: ["0025.png","0026.png","0027.png","0028.png","0029.png","0030.png","0031.png","0032.png","0033.png","0034.png"],
                  padding: false,
                  h_space: 0,
                  unit_sc: '0048.png',
                  unit_tc: '0048.png',
                  unit_en: '0048.png',
                  negative_image: 'minus.png',
                  invalid_image: 'minus.png',
                  align_h: hmUI.align.CENTER_H,
                  type: hmUI.data_type.WEATHER_CURRENT,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });

                hmUI.createWidget(hmUI.widget.IMG, {
              x: 217,
              y: 278,
              src: 'icon_weather.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
                });
                break;
            }; // end switch

            fg_mask = hmUI.createWidget(hmUI.widget.WATCHFACE_EDIT_FG_MASK, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: 'mask.png',
              show_level: hmUI.show_level.ONLY_EDIT,
            });
            console.log('Watch_Face.ElementEditablePointers');

            const pointerEdit = hmUI.createWidget(hmUI.widget.WATCHFACE_EDIT_POINTER, {
              edit_id: 1003,
              x: 0,
              y: 0,
              config: [
                {
                  id: 1,
                  second: {
                    centerX: 234,
                    centerY: 233,
                    posX: 22,
                    posY: 229,
                    path: 'hand_S.png',
                  },
                  hour: {
                    centerX: 233,
                    centerY: 233,
                    posX: 22,
                    posY: 229,
                    path: 'hand_H.png',
                  },
                  minute: {
                    centerX: 234,
                    centerY: 233,
                    posX: 22,
                    posY: 237,
                    path: 'hand_M.png',
                  },
                  preview: 'preview1.png',
                },
              ],
              count: 1,
              default_id: 1,
              fg: 'fg.png',
              tips_x: 0,
              tips_y: 0,
              tips_bg: '.png',
            });
            const screenTypeForETP = hmSetting.getScreenType();
            const aodModel = screenTypeForETP == hmSetting.screen_type.AOD;
            const pointerProp = pointerEdit.getProperty(hmUI.prop.CURRENT_CONFIG, !aodModel);
            editableTimePointers = hmUI.createWidget(hmUI.widget.TIME_POINTER, pointerProp);
            console.log('Watch_Face.Shortcuts');

            normal_pai_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 169,
              y: 55,
              w: 130,
              h: 132,
              type: hmUI.data_type.PAI_WEEKLY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 58,
              y: 165,
              w: 130,
              h: 132,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 169,
              y: 278,
              w: 130,
              h: 132,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            function scale_call() {
              console.log('scale_call()');

                console.log('update editable circle_scale PAI');
                
                let valuePAI = pai.totalpai;
                let targetPAI = 100;
                let progressPAI = valuePAI/targetPAI;
                if (progressPAI > 1) progressPAI = 1;
                let progress_cs_editableZone_1_pai = progressPAI;

                if (editableZone_1_pai_circle_scale) {

                  // editableZone_1_pai_circle_scale_circle_scale
                  let level = Math.round(progress_cs_editableZone_1_pai * 100);
                  if (editableZone_1_pai_circle_scale) {
                    editableZone_1_pai_circle_scale.setProperty(hmUI.prop.MORE, {                      
                      center_x: 234,
                      center_y: 122,
                      start_angle: 26,
                      end_angle: 336,
                      radius: 52,
                      line_width: 6,
                      corner_flag: 0,
                      color: 0xFFA2C2F7,
                      show_level: hmUI.show_level.ONLY_NORMAL,
                      level: level,
                    });
                  };
                };

                console.log('update editable circle_scale STEP');
                
                let valueStep = step.current;
                let targetStep = step.target;
                let progressStep = valueStep/targetStep;
                if (progressStep > 1) progressStep = 1;
                let progress_cs_editableZone_1_step = progressStep;

                if (editableZone_1_step_circle_scale) {

                  // editableZone_1_step_circle_scale_circle_scale
                  let level = Math.round(progress_cs_editableZone_1_step * 100);
                  if (editableZone_1_step_circle_scale) {
                    editableZone_1_step_circle_scale.setProperty(hmUI.prop.MORE, {                      
                      center_x: 234,
                      center_y: 122,
                      start_angle: 26,
                      end_angle: 336,
                      radius: 52,
                      line_width: 6,
                      corner_flag: 0,
                      color: 0xFFA2C2F7,
                      show_level: hmUI.show_level.ONLY_NORMAL,
                      level: level,
                    });
                  };
                };

                console.log('update editable circle_scale HEART');
                
                let valueHeartRate = heart_rate.last;
                let targetHeartRate = 179;
                let progressHeartRate = (valueHeartRate - 71)/(targetHeartRate - 71);
                if (progressHeartRate < 0) progressHeartRate = 0;
                if (progressHeartRate > 1) progressHeartRate = 1;
                let progress_cs_editableZone_1_heart_rate = progressHeartRate;

                if (editableZone_1_heart_rate_circle_scale) {

                  // editableZone_1_heart_rate_circle_scale_circle_scale
                  let level = Math.round(progress_cs_editableZone_1_heart_rate * 100);
                  if (editableZone_1_heart_rate_circle_scale) {
                    editableZone_1_heart_rate_circle_scale.setProperty(hmUI.prop.MORE, {                      
                      center_x: 234,
                      center_y: 122,
                      start_angle: 26,
                      end_angle: 336,
                      radius: 52,
                      line_width: 6,
                      corner_flag: 0,
                      color: 0xFFA2C2F7,
                      show_level: hmUI.show_level.ONLY_NORMAL,
                      level: level,
                    });
                  };
                };

                console.log('update editable circle_scale CALORIE');
                
                let valueCalories = calorie.current;
                let targetCalories = calorie.target;
                let progressCalories = valueCalories/targetCalories;
                if (progressCalories > 1) progressCalories = 1;
                let progress_cs_editableZone_1_calorie = progressCalories;

                if (editableZone_1_calorie_circle_scale) {

                  // editableZone_1_calorie_circle_scale_circle_scale
                  let level = Math.round(progress_cs_editableZone_1_calorie * 100);
                  if (editableZone_1_calorie_circle_scale) {
                    editableZone_1_calorie_circle_scale.setProperty(hmUI.prop.MORE, {                      
                      center_x: 234,
                      center_y: 122,
                      start_angle: 26,
                      end_angle: 336,
                      radius: 52,
                      line_width: 6,
                      corner_flag: 0,
                      color: 0xFFA2C2F7,
                      show_level: hmUI.show_level.ONLY_NORMAL,
                      level: level,
                    });
                  };
                };

                console.log('update editable circle_scale HEART');
                let progress_cs_editableZone_2_heart_rate = progressHeartRate;

                if (editableZone_2_heart_rate_circle_scale) {

                  // editableZone_2_heart_rate_circle_scale_circle_scale
                  let level = Math.round(progress_cs_editableZone_2_heart_rate * 100);
                  if (editableZone_2_heart_rate_circle_scale) {
                    editableZone_2_heart_rate_circle_scale.setProperty(hmUI.prop.MORE, {                      
                      center_x: 123,
                      center_y: 234,
                      start_angle: 26,
                      end_angle: 336,
                      radius: 52,
                      line_width: 6,
                      corner_flag: 0,
                      color: 0xFFA2C2F7,
                      show_level: hmUI.show_level.ONLY_NORMAL,
                      level: level,
                    });
                  };
                };

                console.log('update editable circle_scale PAI');
                let progress_cs_editableZone_2_pai = progressPAI;

                if (editableZone_2_pai_circle_scale) {

                  // editableZone_2_pai_circle_scale_circle_scale
                  let level = Math.round(progress_cs_editableZone_2_pai * 100);
                  if (editableZone_2_pai_circle_scale) {
                    editableZone_2_pai_circle_scale.setProperty(hmUI.prop.MORE, {                      
                      center_x: 123,
                      center_y: 234,
                      start_angle: 26,
                      end_angle: 336,
                      radius: 52,
                      line_width: 6,
                      corner_flag: 0,
                      color: 0xFFA2C2F7,
                      show_level: hmUI.show_level.ONLY_NORMAL,
                      level: level,
                    });
                  };
                };

                console.log('update editable circle_scale STEP');
                let progress_cs_editableZone_2_step = progressStep;

                if (editableZone_2_step_circle_scale) {

                  // editableZone_2_step_circle_scale_circle_scale
                  let level = Math.round(progress_cs_editableZone_2_step * 100);
                  if (editableZone_2_step_circle_scale) {
                    editableZone_2_step_circle_scale.setProperty(hmUI.prop.MORE, {                      
                      center_x: 123,
                      center_y: 234,
                      start_angle: 26,
                      end_angle: 336,
                      radius: 52,
                      line_width: 6,
                      corner_flag: 0,
                      color: 0xFFA2C2F7,
                      show_level: hmUI.show_level.ONLY_NORMAL,
                      level: level,
                    });
                  };
                };

                console.log('update editable circle_scale CALORIE');
                let progress_cs_editableZone_2_calorie = progressCalories;

                if (editableZone_2_calorie_circle_scale) {

                  // editableZone_2_calorie_circle_scale_circle_scale
                  let level = Math.round(progress_cs_editableZone_2_calorie * 100);
                  if (editableZone_2_calorie_circle_scale) {
                    editableZone_2_calorie_circle_scale.setProperty(hmUI.prop.MORE, {                      
                      center_x: 123,
                      center_y: 234,
                      start_angle: 26,
                      end_angle: 336,
                      radius: 52,
                      line_width: 6,
                      corner_flag: 0,
                      color: 0xFFA2C2F7,
                      show_level: hmUI.show_level.ONLY_NORMAL,
                      level: level,
                    });
                  };
                };

                console.log('update editable circle_scale STEP');
                let progress_cs_editableZone_3_step = progressStep;

                if (editableZone_3_step_circle_scale) {

                  // editableZone_3_step_circle_scale_circle_scale
                  let level = Math.round(progress_cs_editableZone_3_step * 100);
                  if (editableZone_3_step_circle_scale) {
                    editableZone_3_step_circle_scale.setProperty(hmUI.prop.MORE, {                      
                      center_x: 233,
                      center_y: 345,
                      start_angle: 26,
                      end_angle: 336,
                      radius: 52,
                      line_width: 6,
                      corner_flag: 0,
                      color: 0xFFA2C2F7,
                      show_level: hmUI.show_level.ONLY_NORMAL,
                      level: level,
                    });
                  };
                };

                console.log('update editable circle_scale HEART');
                let progress_cs_editableZone_3_heart_rate = progressHeartRate;

                if (editableZone_3_heart_rate_circle_scale) {

                  // editableZone_3_heart_rate_circle_scale_circle_scale
                  let level = Math.round(progress_cs_editableZone_3_heart_rate * 100);
                  if (editableZone_3_heart_rate_circle_scale) {
                    editableZone_3_heart_rate_circle_scale.setProperty(hmUI.prop.MORE, {                      
                      center_x: 233,
                      center_y: 345,
                      start_angle: 26,
                      end_angle: 336,
                      radius: 52,
                      line_width: 6,
                      corner_flag: 0,
                      color: 0xFFA2C2F7,
                      show_level: hmUI.show_level.ONLY_NORMAL,
                      level: level,
                    });
                  };
                };

                console.log('update editable circle_scale PAI');
                let progress_cs_editableZone_3_pai = progressPAI;

                if (editableZone_3_pai_circle_scale) {

                  // editableZone_3_pai_circle_scale_circle_scale
                  let level = Math.round(progress_cs_editableZone_3_pai * 100);
                  if (editableZone_3_pai_circle_scale) {
                    editableZone_3_pai_circle_scale.setProperty(hmUI.prop.MORE, {                      
                      center_x: 233,
                      center_y: 345,
                      start_angle: 26,
                      end_angle: 336,
                      radius: 52,
                      line_width: 6,
                      corner_flag: 0,
                      color: 0xFFA2C2F7,
                      show_level: hmUI.show_level.ONLY_NORMAL,
                      level: level,
                    });
                  };
                };

                console.log('update editable circle_scale CALORIE');
                let progress_cs_editableZone_3_calorie = progressCalories;

                if (editableZone_3_calorie_circle_scale) {

                  // editableZone_3_calorie_circle_scale_circle_scale
                  let level = Math.round(progress_cs_editableZone_3_calorie * 100);
                  if (editableZone_3_calorie_circle_scale) {
                    editableZone_3_calorie_circle_scale.setProperty(hmUI.prop.MORE, {                      
                      center_x: 233,
                      center_y: 345,
                      start_angle: 26,
                      end_angle: 336,
                      radius: 52,
                      line_width: 6,
                      corner_flag: 0,
                      color: 0xFFA2C2F7,
                      show_level: hmUI.show_level.ONLY_NORMAL,
                      level: level,
                    });
                  };
                };

            };

            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                console.log('resume_call()');
                scale_call();
              }),
              pause_call: (function () {
                console.log('pause_call()');
                if (heart_rate) heart_rate.removeEventListener(heart_rate.event.LAST, function () {});
                if (heart_rate) heart_rate.removeEventListener(heart_rate.event.LAST, function () {});
                if (heart_rate) heart_rate.removeEventListener(heart_rate.event.LAST, function () {});

              }),
            });

                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}