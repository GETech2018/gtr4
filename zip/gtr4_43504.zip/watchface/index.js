﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        //const logger = Logger.getLogger('watchface_SashaCX75');
        const logger = DeviceRuntimeCore.HmLogger.getLogger('watchface_SashaCX75')
        //end of ignored block

        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_calorie_icon_img = ''
        let normal_system_disconnect_img = ''
        let normal_alarm_clock_icon_img = ''
        let normal_alarm_clock_current_text_font = ''
        let normal_distance_current_text_font = ''
        let normal_heart_rate_text_font = ''
        let normal_heart_rate_image_progress_img_level = ''
        let normal_step_icon_img = ''
        let normal_step_current_text_font = ''
        let normal_battery_current_text_font = ''
        let normal_battery_image_progress_img_level = ''
        let normal_dow_text_font = ''
        let normal_DOW_Array = ['ПНД', 'ВТР', 'СРД', 'ЧТВ', 'ПТН', 'СУБ', 'ВСК'];
        let normal_day_text_font = ''
        let normal_weather_image_progress_img_level = ''
        let normal_temperature_max_min_text_font = ''
        let normal_temperature_current_text_font = ''
        let normal_analog_clock_time_pointer_hour = ''
        let normal_analog_clock_time_pointer_minute = ''
        let normal_analog_clock_time_pointer_second = ''
        let idle_image_img = ''
		let image_top_img = ''
        let idle_system_disconnect_img = ''
        let idle_alarm_clock_icon_img = ''
        let idle_alarm_clock_current_text_font = ''
        let idle_step_current_text_font = ''
        let idle_analog_clock_time_pointer_hour = ''
        let idle_analog_clock_time_pointer_minute = ''
        let Button_1 = ''
        let Button_2 = ''
        let Button_3 = ''
        let Button_4 = ''
        let Button_5 = ''
        let Button_6 = ''
        let Button_7 = ''
        let Button_8 = ''
        let Button_9 = ''
        let Button_10 = ''
        let Button_11 = ''
        let Button_Switch_BG = ''

        let backgroundIndex = 0;
        let backgroundList = ['bg_1.png', 'bg_2.png', 'bg_3.png', 'bg_4.png', 'bg_5.png', 'bg_6.png', 'bg_7.png', 'bg_8.png', 'bg_9.png', 'bg_10.png'];
        let backgroundToastList = ['Фон %s', 'Фон %s', 'Фон %s', 'Фон %s', 'Фон %s', 'Фон %s', 'Фон %s', 'Фон %s', 'Фон %s', 'Фон %s'];
        const watchfaceId = hmApp.packageInfo().watchfaceId;
        
        let degreeSum = 0;
        let crownSensitivity = 70;  // crown sensitivity level
        let timeSensor = '';
		
		// смена маски
        //let mask_img = ''
        let btn_mask = ''
        let mask_num = 1
        let mask_all = 10
     
        function click_mask() {
            if(mask_num>=mask_all) {mask_num=1;}
            else { mask_num=mask_num+1;}
            hmUI.showToast({text: "Маска " + parseInt(mask_num) });
            normal_image_img.setProperty(hmUI.prop.SRC, "mask_" + parseInt(mask_num) + ".png");
        }
		
		let bot_circle_btn = ''
        let bot_circle_state = 0

        function click_bot_circle_Switcher() {
		
		let bot_circle_state_total = 7;

          bot_circle_state = (bot_circle_state + 1) % bot_circle_state_total;

          switch (bot_circle_state) {

              case 0:
 
                  normal_analog_clock_time_pointer_hour.setProperty(hmUI.prop.MORE, {
                    hour_path: 'h_1.png',
                    hour_centerX: 323,
                    hour_centerY: 232,
                    hour_posX: 114,
                    hour_posY: 114,
                    show_level: hmUI.show_level.ONLY_NORMAL,
                  });
      
                  normal_analog_clock_time_pointer_minute.setProperty(hmUI.prop.MORE, {
                    minute_path: 'm_1.png',
                    minute_centerX: 323,
                    minute_centerY: 232,
                    minute_posX: 114,
                    minute_posY: 114,
                    show_level: hmUI.show_level.ONLY_NORMAL,
                  });
				  
				  normal_analog_clock_time_pointer_second.setProperty(hmUI.prop.MORE, {
                    second_path: 's_1.png',
                    second_centerX: 323,
                    second_centerY: 232,
                    second_posX: 114,
                    second_posY: 114,
                    show_level: hmUI.show_level.ONLY_NORMAL,
                  });
				  
      
                  bot_circle_state_txt = 'Стрелки 1';
                  break;

              case 1:

                normal_analog_clock_time_pointer_hour.setProperty(hmUI.prop.MORE, {
                  hour_path: 'h_2.png',
                  hour_centerX: 323,
                  hour_centerY: 232,
                  hour_posX: 114,
                  hour_posY: 114,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });
    
                normal_analog_clock_time_pointer_minute.setProperty(hmUI.prop.MORE, {
                  minute_path: 'm_2.png',
                  minute_centerX: 323,
                  minute_centerY: 232,
                  minute_posX: 114,
                  minute_posY: 114,
                 show_level: hmUI.show_level.ONLY_NORMAL,
                });
				
   
              bot_circle_state_txt = 'Стрелки 2';
                  break;
				  
				  case 2:
 
                  normal_analog_clock_time_pointer_hour.setProperty(hmUI.prop.MORE, {
                    hour_path: 'h_3.png',
                    hour_centerX: 323,
                    hour_centerY: 232,
                    hour_posX: 114,
                    hour_posY: 114,
                    show_level: hmUI.show_level.ONLY_NORMAL,
                  });
      
                  normal_analog_clock_time_pointer_minute.setProperty(hmUI.prop.MORE, {
                    minute_path: 'm_3.png',
                    minute_centerX: 323,
                    minute_centerY: 232,
                    minute_posX: 114,
                    minute_posY: 114,
                    show_level: hmUI.show_level.ONLY_NORMAL,
                  });
				  
      
                  bot_circle_state_txt = 'Стрелки 3';
                  break;

              case 3:

                normal_analog_clock_time_pointer_hour.setProperty(hmUI.prop.MORE, {
                  hour_path: 'h_4.png',
                  hour_centerX: 323,
                  hour_centerY: 232,
                  hour_posX: 114,
                  hour_posY: 114,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });
    
                normal_analog_clock_time_pointer_minute.setProperty(hmUI.prop.MORE, {
                  minute_path: 'm_4.png',
                  minute_centerX: 323,
                  minute_centerY: 232,
                  minute_posX: 114,
                  minute_posY: 114,
                 show_level: hmUI.show_level.ONLY_NORMAL,
                });
				
   
              bot_circle_state_txt = 'Стрелки 4';
                  break;
				  
				  case 4:

                normal_analog_clock_time_pointer_hour.setProperty(hmUI.prop.MORE, {
                  hour_path: 'h_5.png',
                  hour_centerX: 323,
                  hour_centerY: 232,
                  hour_posX: 114,
                  hour_posY: 114,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });
    
                normal_analog_clock_time_pointer_minute.setProperty(hmUI.prop.MORE, {
                  minute_path: 'm_5.png',
                  minute_centerX: 323,
                  minute_centerY: 232,
                  minute_posX: 114,
                  minute_posY: 114,
                 show_level: hmUI.show_level.ONLY_NORMAL,
                });
				
   
              bot_circle_state_txt = 'Стрелки 5';
                  break;
				  
				  case 5:
 
                  normal_analog_clock_time_pointer_hour.setProperty(hmUI.prop.MORE, {
                    hour_path: 'h_6.png',
                    hour_centerX: 323,
                    hour_centerY: 232,
                    hour_posX: 114,
                    hour_posY: 114,
                    show_level: hmUI.show_level.ONLY_NORMAL,
                  });
      
                  normal_analog_clock_time_pointer_minute.setProperty(hmUI.prop.MORE, {
                    minute_path: 'm_6.png',
                    minute_centerX: 323,
                    minute_centerY: 232,
                    minute_posX: 114,
                    minute_posY: 114,
                    show_level: hmUI.show_level.ONLY_NORMAL,
                  });
				  
      
                  bot_circle_state_txt = 'Стрелки 6';
                  break;

              case 6:

                normal_analog_clock_time_pointer_hour.setProperty(hmUI.prop.MORE, {
                  hour_path: 'h_7.png',
                  hour_centerX: 323,
                  hour_centerY: 232,
                  hour_posX: 114,
                  hour_posY: 114,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });
    
                normal_analog_clock_time_pointer_minute.setProperty(hmUI.prop.MORE, {
                  minute_path: 'm_7.png',
                  minute_centerX: 323,
                  minute_centerY: 232,
                  minute_posX: 114,
                  minute_posY: 114,
                 show_level: hmUI.show_level.ONLY_NORMAL,
                });
				
   
              bot_circle_state_txt = 'Стрелки 7';
                  break;
    
              default:
                  break;
          }

          hmUI.showToast({ text: bot_circle_state_txt });
      }
	  


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            // FontName: conthrax_sb.ttf; FontSize: 18
            hmUI.createWidget(hmUI.widget.TEXT, {
              x: 464,
              y: 464,
              w: 376,
              h: 25,
              text_size: 18,
              char_space: 2,
              line_space: 0,
              font: 'fonts/conthrax_sb.ttf',
              color: 0xFFFFFFFF,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              text: "0123456789 _-.,:;`'%°\\/",
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // FontName: CommerceBlackCondensedSsiBoldCondensed.ttf; FontSize: 24; Cache: full
            hmUI.createWidget(hmUI.widget.TEXT, {
              x: 464,
              y: 464,
              w: 28,
              h: 28,
              text_size: 24,
              char_space: 1,
              line_space: 0,
              font: 'fonts/CommerceBlackCondensedSsiBoldCondensed.ttf',
              color: 0xFFFFFFFF,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.NONE,
              text: "0123456789 ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz АБВГДЕЁЖЗИЙКЛМНОПРСТУФХЦЧШЩЪЫЬЭЮЯабвгдеёжзийклмнопрстуфхцчшщъыьэюя  ҐЄІЇґєії _-.,:;`'%°\\/",
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // FontName: CommerceBlackCondensedSsiBoldCondensed.ttf; FontSize: 35
            hmUI.createWidget(hmUI.widget.TEXT, {
              x: 464,
              y: 464,
              w: 459,
              h: 50,
              text_size: 35,
              char_space: 2,
              line_space: 0,
              font: 'fonts/CommerceBlackCondensedSsiBoldCondensed.ttf',
              color: 0xFFFFFFFF,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              text: "0123456789 _-.,:;`'%°\\/",
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // FontName: CommerceBlackCondensedSsiBoldCondensed.ttf; FontSize: 28
            hmUI.createWidget(hmUI.widget.TEXT, {
              x: 464,
              y: 464,
              w: 366,
              h: 40,
              text_size: 28,
              char_space: 2,
              line_space: 0,
              font: 'fonts/CommerceBlackCondensedSsiBoldCondensed.ttf',
              color: 0xFFFFFFFF,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              text: "0123456789 _-.,:;`'%°\\/",
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // FontName: conthrax_sb.ttf; FontSize: 22; Cache: full
            hmUI.createWidget(hmUI.widget.TEXT, {
              x: 464,
              y: 464,
              w: 26,
              h: 26,
              text_size: 22,
              char_space: 1,
              line_space: 0,
              font: 'fonts/conthrax_sb.ttf',
              color: 0xFFFFFFFF,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.NONE,
              text: "0123456789 ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz АБВГДЕЁЖЗИЙКЛМНОПРСТУФХЦЧШЩЪЫЬЭЮЯабвгдеёжзийклмнопрстуфхцчшщъыьэюя  ҐЄІЇґєії _-.,:;`'%°\\/",
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // FontName: conthrax_sb.ttf; FontSize: 30
            hmUI.createWidget(hmUI.widget.TEXT, {
              x: 464,
              y: 464,
              w: 524,
              h: 42,
              text_size: 30,
              char_space: 0,
              line_space: 0,
              font: 'fonts/conthrax_sb.ttf',
              color: 0xFFFFFFFF,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              text: "0123456789 _-.,:;`'%°\\/",
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // FontName: conthrax_sb.ttf; FontSize: 24
            hmUI.createWidget(hmUI.widget.TEXT, {
              x: 464,
              y: 464,
              w: 480,
              h: 34,
              text_size: 24,
              char_space: 2,
              line_space: 0,
              font: 'fonts/conthrax_sb.ttf',
              color: 0xFFFFFFFF,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              text: "0123456789 _-.,:;`'%°\\/",
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // FontName: conthrax_sb.ttf; FontSize: 26
            hmUI.createWidget(hmUI.widget.TEXT, {
              x: 464,
              y: 464,
              w: 519,
              h: 37,
              text_size: 26,
              char_space: 2,
              line_space: 0,
              font: 'fonts/conthrax_sb.ttf',
              color: 0xFFFFFFFF,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              text: "0123456789 _-.,:;`'%°\\/",
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            //#region onDigitalCrown
            console.log('onDigitalCrown()');
            function onDigitalCrown() {
              setTimeout(() => {
                hmApp.registerSpinEvent(function (key, degree) {
                  if (key === hmApp.key.HOME) {
                    degreeSum += degree;
                    if (Math.abs(degreeSum) > crownSensitivity){
                      let step = degreeSum < 0 ? -1 : 1;
                      degreeSum = 0;
                      
                      console.log('SwitchBackground use crown');
                      backgroundIndex += step;
                      backgroundIndex = backgroundIndex < 0 ? backgroundList.length + backgroundIndex : backgroundIndex % backgroundList.length;
                      hmFS.SysProSetInt(`backgroundIndex_${watchfaceId}`, backgroundIndex);
                      let toastText = backgroundToastList[backgroundIndex].replace('%s', `${backgroundIndex + 1}`);
                      if (toastText.length > 0) hmUI.showToast({text: toastText});
                      normal_background_bg_img.setProperty(hmUI.prop.SRC, backgroundList[backgroundIndex]);
                      vibro(28);
                    }
                  } // key
                }) // crown
              }, 250);
            }
            //#endregion

            //#region SwitchBackground
            console.log('SwitchBackground');
            function switchBackground() {
              backgroundIndex++;
              if (backgroundIndex >= backgroundList.length) backgroundIndex = 0;
              hmFS.SysProSetInt(`backgroundIndex_${watchfaceId}`, backgroundIndex);
              let toastText = backgroundToastList[backgroundIndex].replace('%s', `${backgroundIndex + 1}`);
              if (toastText.length > 0) hmUI.showToast({text: toastText});
              normal_background_bg_img.setProperty(hmUI.prop.SRC, backgroundList[backgroundIndex]);
              vibro(28);
            };
            //#endregion

            console.log('Watch_Face.ScreenNormal');
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 466,
              h: 466,
              src: 'bg_1.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
			
			normal_image_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'mask_1.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_calorie_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 219,
              y: 10,
              src: 'bt115.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 219,
              y: 10,
              src: 'bt115_(6).png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_alarm_clock_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 60,
              y: 322,
              src: 'icon_next_alarm_(5).png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_alarm_clock_current_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 45,
              y: 353,
              w: 150,
              h: 30,
              text_size: 18,
              char_space: 2,
              line_space: 0,
              font: 'fonts/conthrax_sb.ttf',
              color: 0xFFFFFFFF,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.CENTER_V,
              padding: true,
              text_style: hmUI.text_style.ELLIPSIS,
              type: hmUI.data_type.ALARM_CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_distance_current_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 89,
              y: 312,
              w: 150,
              h: 30,
              text_size: 24,
              char_space: 1,
              line_space: 0,
              font: 'fonts/CommerceBlackCondensedSsiBoldCondensed.ttf',
              color: 0xFFFFFFFF,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.CENTER_V,
              unit_type: 1,
              text_style: hmUI.text_style.ELLIPSIS,
              type: hmUI.data_type.DISTANCE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 62,
              y: 219,
              w: 150,
              h: 33,
              text_size: 35,
              char_space: 2,
              line_space: 0,
              font: 'fonts/CommerceBlackCondensedSsiBoldCondensed.ttf',
              color: 0xFFFFFFFF,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 57,
              y: 221,
              image_array: ["zone_1.png","zone_2.png","zone_3.png","zone_4.png","zone_5.png","zone_6.png"],
              image_length: 6,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 60,
              y: 269,
              src: 'icon_step.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 68,
              y: 269,
              w: 150,
              h: 33,
              text_size: 35,
              char_space: 1,
              line_space: 0,
              font: 'fonts/CommerceBlackCondensedSsiBoldCondensed.ttf',
              color: 0xFFFFFFFF,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_current_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 208,
              y: 370,
              w: 150,
              h: 30,
              text_size: 28,
              char_space: 2,
              line_space: 0,
              font: 'fonts/CommerceBlackCondensedSsiBoldCondensed.ttf',
              color: 0xFFFFFFFF,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.CENTER_V,
              unit_type: 1,
              text_style: hmUI.text_style.ELLIPSIS,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 25,
              y: 12,
              image_array: ["zbat_1.png","zbat_2.png","zbat_3.png","zbat_4.png","zbat_5.png","zbat_6.png","zbat_7.png","zbat_8.png","zbat_9.png","zbat_10.png","zbat_11.png","zbat_12.png"],
              image_length: 12,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            if (!timeSensor) timeSensor = hmSensor.createSensor(hmSensor.id.TIME);
            timeSensor.addEventListener(timeSensor.event.DAYCHANGE, function() {
              time_update(true);
            });

            normal_dow_text_font = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 284,
              y: 61,
              w: 150,
              h: 30,
              text_size: 22,
              char_space: 1,
              line_space: 0,
              font: 'fonts/conthrax_sb.ttf',
              color: 0xFFFFFFFF,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              // unit_string: ПНД, ВТР, СРД, ЧТВ, ПТН, СУБ, ВСК,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_day_text_font = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 200,
              y: 68,
              w: 150,
              h: 30,
              text_size: 30,
              char_space: 0,
              line_space: 0,
              font: 'fonts/conthrax_sb.ttf',
              color: 0xFFFFFFFF,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              // padding: true,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 58,
              y: 96,
              image_array: ["w_0.png","w_1.png","w_2.png","w_3.png","w_4.png","w_5.png","w_6.png","w_7.png","w_8.png","w_9.png","w_10.png","w_11.png","w_12.png","w_13.png","w_14.png","w_15.png","w_16.png","w_17.png","w_18.png","w_19.png","w_20.png","w_21.png","w_22.png","w_23.png","w_24.png","w_25.png","w_26.png","w_27.png","w_28.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_max_min_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 50,
              y: 172,
              w: 150,
              h: 30,
              text_size: 24,
              char_space: 2,
              line_space: 0,
              font: 'fonts/conthrax_sb.ttf',
              color: 0xFFFFFFFF,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.CENTER_V,
              unit_type: 1,
              text_style: hmUI.text_style.ELLIPSIS,
              type: hmUI.data_type.WEATHER_HIGH_LOW,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 87,
              y: 129,
              w: 150,
              h: 30,
              text_size: 26,
              char_space: 2,
              line_space: 0,
              font: 'fonts/conthrax_sb.ttf',
              color: 0xFFFFFFFF,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.CENTER_V,
              unit_type: 1,
              text_style: hmUI.text_style.ELLIPSIS,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_hour = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              hour_path: 'h_1.png',
              hour_centerX: 323,
              hour_centerY: 232,
              hour_posX: 114,
              hour_posY: 114,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_minute = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              minute_path: 'm_1.png',
              minute_centerX: 323,
              minute_centerY: 232,
              minute_posX: 114,
              minute_posY: 114,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_second = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              second_path: 's_1.png',
              second_centerX: 323,
              second_centerY: 232,
              second_posX: 114,
              second_posY: 114,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            console.log('Watch_Face.ScreenAOD');

            idle_image_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: -90,
              y: 0,
              src: 'mask_6.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 173,
              y: 81,
              src: '0229.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_alarm_clock_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 220,
              y: 9,
              src: 'icon_next_alarm_(5).png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_alarm_clock_current_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 158,
              y: 46,
              w: 150,
              h: 30,
              text_size: 22,
              char_space: 2,
              line_space: 0,
              font: 'fonts/conthrax_sb.ttf',
              color: 0xFFFFFFFF,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.CENTER_V,
              padding: true,
              text_style: hmUI.text_style.ELLIPSIS,
              type: hmUI.data_type.ALARM_CLOCK,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_step_current_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 158,
              y: 391,
              w: 150,
              h: 33,
              text_size: 35,
              char_space: 1,
              line_space: 0,
              font: 'fonts/CommerceBlackCondensedSsiBoldCondensed.ttf',
              color: 0xFFFFFFFF,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_analog_clock_time_pointer_hour = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              hour_path: 'h_1.png',
              hour_centerX: 233,
              hour_centerY: 233,
              hour_posX: 114,
              hour_posY: 114,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_analog_clock_time_pointer_minute = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              minute_path: 'm_1.png',
              minute_centerX: 233,
              minute_centerY: 233,
              minute_posX: 114,
              minute_posY: 114,
              show_level: hmUI.show_level.ONLY_AOD,
            });
            
            // disconnectAlert = hmUI.createWidget(hmUI.widget.DisconnectAlert, {
              // disconneсnt_vibrate_type: 9,
              // disconneсnt_toast_text: НЕТ СВЯЗИ,
              // conneсnt_vibrate_type: 9,
              // conneсnt_toast_text: ЕСТЬ КОНТАКТ,
            // });

            // vibration when connecting or disconnecting

            function checkConnection() {
              console.log('checkConnection()');
              hmBle.removeListener;
              hmBle.addListener(function (status) {
                if(!status) {
                  hmUI.showToast({text: "НЕТ СВЯЗИ"});
                  vibro(9);
                }
                if(status) {
                  hmUI.showToast({text: "ЕСТЬ КОНТАКТ"});
                  vibro(9);
                }
              });
            }

            // end vibration when connecting or disconnecting
            // vibrate function

            const vibrate = hmSensor.createSensor(hmSensor.id.VIBRATE);
            let timer_StopVibrate = null;


            function vibro(scene = 25) {
              let stopDelay = 50;
              stopVibro();
              vibrate.stop();
              vibrate.scene = scene;
              if(scene < 23 || scene > 25) stopDelay = 1300;
              vibrate.start();
              if (scene != 1) timer_StopVibrate = timer.createTimer(stopDelay, 3000, stopVibro, {});
            }

            function stopVibro(){
              vibrate.stop();
              if(timer_StopVibrate) timer.stopTimer(timer_StopVibrate);
            }

            // end vibrate function

            console.log('Watch_Face.Buttons');
            Button_1 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 32,
              y: 210,
              w: 150,
              h: 48,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'Empty.png',
              normal_src: 'Empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'heart_app_Screen', native: true });
              }, // end func
              longpress_func: (button_widget) => {
                hmApp.startApp({url: 'spo_HomeScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_2 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 32,
              y: 260,
              w: 150,
              h: 48,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'Empty.png',
              normal_src: 'Empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'activityAppScreen', native: true });
              }, // end func
              longpress_func: (button_widget) => {
                hmApp.startApp({url: 'SportListScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_3 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 119,
              y: 310,
              w: 81,
              h: 39,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'Empty.png',
              normal_src: 'Empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'activityWeekShowScreen', native: true });
              }, // end func
              longpress_func: (button_widget) => {
                hmApp.startApp({url: 'PAI_app_Screen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_4 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 36,
              y: 310,
              w: 81,
              h: 72,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'Empty.png',
              normal_src: 'Empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'AlarmInfoScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_5 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 237,
              y: 409,
              w: 114,
              h: 60,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'Empty.png',
              normal_src: 'Empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'MusicCommonScreen', native: true });
              }, // end func
              longpress_func: (button_widget) => {
                hmApp.startApp({url: 'LocalMusicScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_6 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 120,
              y: 409,
              w: 114,
              h: 60,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'Empty.png',
              normal_src: 'Empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'PhoneContactsScreen', native: true });
              }, // end func
              longpress_func: (button_widget) => {
                hmApp.startApp({url: 'PhoneHomeScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_7 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 210,
              y: 355,
              w: 141,
              h: 52,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'Empty.png',
              normal_src: 'Empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'LowBatteryScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_8 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 205,
              y: 54,
              w: 214,
              h: 56,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'Empty.png',
              normal_src: 'Empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'ScheduleCalScreen', native: true });
              }, // end func
              longpress_func: (button_widget) => {
                hmApp.startApp({url: 'todoListScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_9 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 25,
              y: 83,
              w: 177,
              h: 82,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'Empty.png',
              normal_src: 'Empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({ appid: 1051195, url: 'page/index', params: { from_wf: true} });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_10 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 25,
              y: 167,
              w: 177,
              h: 40,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'Empty.png',
              normal_src: 'Empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'WeatherScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_11 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 187,
              y: 0,
              w: 90,
              h: 51,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'Empty.png',
              normal_src: 'Empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'FindPhoneScreen', native: true });
              }, // end func
              longpress_func: (button_widget) => {
                hmApp.startApp({url: 'Settings_dndScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            console.log('Watch_Face.SwitchBackground');
            // Button_Switch_BG = hmUI.createWidget(hmUI.widget.SwitchBackground, {
              // x: 0,
              // y: 0,
              // w: 100,
              // h: 40,
              // text: '',
              // color: 0xFFFF8C00,
              // text_size: 25,
              // radius: 12,
              // press_color: 0xFFA0A0A0,
              // normal_color: 0xFF696969,
              // bg_list: bg_1|bg_2|bg_3|bg_4|bg_5|bg_6|bg_7|bg_8|bg_9|bg_10,
              // toast_list: Фон %s|Фон %s|Фон %s|Фон %s|Фон %s|Фон %s|Фон %s|Фон %s|Фон %s|Фон %s,
              // use_crown: True,
              // use_in_AOD: False,
              // vibro: True,
            // });

            Button_Switch_BG = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 0,
              y: 0,
              w: 100,
              h: 40,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              radius: 12,
              press_color: 0xFFA0A0A0,
              normal_color: 0xFF696969,
              click_func: (button_widget) => {
                switchBackground();
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            let screenType = hmSetting.getScreenType();
            //#region time_update
            function time_update(updateHour = false, updateMinute = false) {
              console.log('time_update()');
              let hour = timeSensor.hour;
              let minute = timeSensor.minute;
              let second = timeSensor.second;
              let format_hour = timeSensor.format_hour;

              console.log('day of week font');
              if (updateHour) {
                let normal_DOW_Str = normal_DOW_Array[timeSensor.week-1];
                normal_dow_text_font.setProperty(hmUI.prop.TEXT, normal_DOW_Str );
              };

              console.log('day font');
              if (updateHour) {
                let normal_dayStr = timeSensor.day.toString();
                normal_dayStr = normal_dayStr.padStart(2, '0');
                normal_day_text_font.setProperty(hmUI.prop.TEXT, normal_dayStr );
              };

            };

            //#endregion
            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                console.log('resume_call()');
                time_update(true, true);
                checkConnection();
                stopVibro();

                //SwitchBackground
                if (hmFS.SysProGetInt(`backgroundIndex_${watchfaceId}`) === undefined) {
                  backgroundIndex = 0;
                  hmFS.SysProSetInt(`backgroundIndex_${watchfaceId}`, backgroundIndex);
                } else {
                  backgroundIndex = hmFS.SysProGetInt(`backgroundIndex_${watchfaceId}`);
                };
                if (screenType == hmSetting.screen_type.WATCHFACE && normal_background_bg_img) normal_background_bg_img.setProperty(hmUI.prop.SRC, backgroundList[backgroundIndex]);
                onDigitalCrown();
              }),
              pause_call: (function () {
                console.log('pause_call()');
                stopVibro();

                hmApp.unregisterSpinEvent();
              }),
            });
			
			bot_circle_btn = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 260,
              y: 170,
              text: '',
              w: 124,
              h: 128,
              normal_src: 'Empty.png',
              press_src: 'Empty.png',
              click_func: () => {
                  click_bot_circle_Switcher();
				  vibro(0);
              },
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
              bot_circle_btn.setProperty(hmUI.prop.VISIBLE, true);
			  
			  btn_mask = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 420,
              y: 155,
              text: '',
              w: 90,
              h: 160,
              normal_src: 'empty.png',
              press_src: 'empty.png',
              click_func: () => {
                  click_mask();
				  vibro(0);
              },
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            btn_mask.setProperty(hmUI.prop.VISIBLE, true);

                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}