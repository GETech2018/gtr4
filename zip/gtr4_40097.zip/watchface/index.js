﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        const logger = Logger.getLogger('watchface_SashaCX75');
        //end of ignored block

        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_system_disconnect_img = ''
        let normal_frame_animation_1 = ''
        let normal_hour_TextCircle = new Array(2);
        let normal_hour_TextCircle_ASCIIARRAY = new Array(10);
        let normal_hour_TextCircle_img_width = 29;
        let normal_hour_TextCircle_img_height = 42;
        let normal_timerTextUpdate = undefined;
        let normal_minute_TextCircle = new Array(2);
        let normal_minute_TextCircle_ASCIIARRAY = new Array(10);
        let normal_minute_TextCircle_img_width = 29;
        let normal_minute_TextCircle_img_height = 42;
        let normal_analog_clock_time_pointer_hour = ''
        let normal_analog_clock_time_pointer_minute = ''
        let normal_analog_clock_time_pointer_second = ''
        let timeSensor = ''


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            console.log('Watch_Face.ScreenNormal');
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 466,
              h: 466,
              src: 'bg.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 0,
              y: 0,
              src: 'bt.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_frame_animation_1 = hmUI.createWidget(hmUI.widget.IMG_ANIM, {
              x: 160,
              y: 160,
              anim_path: "animation",
              anim_ext: "png",
              anim_prefix: "test_anim",
              anim_fps: 25,
              anim_size: 30,
              repeat_count: 0,
              anim_repeat: true,
              anim_status:hmUI.anim_status.START,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_hour_text_circle_img = hmUI.createWidget(hmUI.widget.Text_Circle, {
              // circle_center_X: 233,
              // circle_center_Y: 233,
              // font_array: ["h_1.png","h_2.png","h_3.png","h_4.png","h_5.png","h_6.png","h_7.png","h_8.png","h_9.png","h_10.png"],
              // radius: 155,
              // angle: -22,
              // char_space_angle: -1,
              // zero: true,
              // reverse_direction: false,
              // unit_in_alignment: true,
              // vertical_alignment: BOTTOM,
              // horizontal_alignment: LEFT,
              // type: hmUI.data_type.HOUR,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_hour_TextCircle_ASCIIARRAY[0] = 'h_1.png';  // set of images with numbers
            normal_hour_TextCircle_ASCIIARRAY[1] = 'h_2.png';  // set of images with numbers
            normal_hour_TextCircle_ASCIIARRAY[2] = 'h_3.png';  // set of images with numbers
            normal_hour_TextCircle_ASCIIARRAY[3] = 'h_4.png';  // set of images with numbers
            normal_hour_TextCircle_ASCIIARRAY[4] = 'h_5.png';  // set of images with numbers
            normal_hour_TextCircle_ASCIIARRAY[5] = 'h_6.png';  // set of images with numbers
            normal_hour_TextCircle_ASCIIARRAY[6] = 'h_7.png';  // set of images with numbers
            normal_hour_TextCircle_ASCIIARRAY[7] = 'h_8.png';  // set of images with numbers
            normal_hour_TextCircle_ASCIIARRAY[8] = 'h_9.png';  // set of images with numbers
            normal_hour_TextCircle_ASCIIARRAY[9] = 'h_10.png';  // set of images with numbers

            //start of ignored block
            for (let i = 0; i < 2; i++) {
              normal_hour_TextCircle[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 466,
                h: 466,
                center_x: 233,
                center_y: 233,
                pos_x: 233 - normal_hour_TextCircle_img_width / 2,
                pos_y: 233 - 197,
                src: 'h_1.png',
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
              normal_hour_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
            };
            //end of ignored block

            if (!timeSensor) timeSensor = hmSensor.createSensor(hmSensor.id.TIME);
            let screenType = hmSetting.getScreenType();            
            function toDegree (radian) {
              return radian * (180 / Math.PI);
            };

            // normal_minute_text_circle_img = hmUI.createWidget(hmUI.widget.Text_Circle, {
              // circle_center_X: 233,
              // circle_center_Y: 233,
              // font_array: ["h_1.png","h_2.png","h_3.png","h_4.png","h_5.png","h_6.png","h_7.png","h_8.png","h_9.png","h_10.png"],
              // radius: 155,
              // angle: 12,
              // char_space_angle: -1,
              // zero: true,
              // reverse_direction: false,
              // unit_in_alignment: true,
              // vertical_alignment: BOTTOM,
              // horizontal_alignment: LEFT,
              // type: hmUI.data_type.MINUTE,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_minute_TextCircle_ASCIIARRAY[0] = 'h_1.png';  // set of images with numbers
            normal_minute_TextCircle_ASCIIARRAY[1] = 'h_2.png';  // set of images with numbers
            normal_minute_TextCircle_ASCIIARRAY[2] = 'h_3.png';  // set of images with numbers
            normal_minute_TextCircle_ASCIIARRAY[3] = 'h_4.png';  // set of images with numbers
            normal_minute_TextCircle_ASCIIARRAY[4] = 'h_5.png';  // set of images with numbers
            normal_minute_TextCircle_ASCIIARRAY[5] = 'h_6.png';  // set of images with numbers
            normal_minute_TextCircle_ASCIIARRAY[6] = 'h_7.png';  // set of images with numbers
            normal_minute_TextCircle_ASCIIARRAY[7] = 'h_8.png';  // set of images with numbers
            normal_minute_TextCircle_ASCIIARRAY[8] = 'h_9.png';  // set of images with numbers
            normal_minute_TextCircle_ASCIIARRAY[9] = 'h_10.png';  // set of images with numbers

            //start of ignored block
            for (let i = 0; i < 2; i++) {
              normal_minute_TextCircle[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 466,
                h: 466,
                center_x: 233,
                center_y: 233,
                pos_x: 233 - normal_minute_TextCircle_img_width / 2,
                pos_y: 233 - 197,
                src: 'h_1.png',
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
              normal_minute_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
            };
            //end of ignored block

            normal_analog_clock_time_pointer_hour = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              hour_path: 'A100_003.png',
              hour_centerX: 233,
              hour_centerY: 233,
              hour_posX: 181,
              hour_posY: 218,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_minute = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              minute_path: 'A100_004.png',
              minute_centerX: 233,
              minute_centerY: 233,
              minute_posX: 181,
              minute_posY: 217,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_second = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              second_path: 'A100_002.png',
              second_centerX: 233,
              second_centerY: 233,
              second_posX: 181,
              second_posY: 181,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });



            //start of ignored block
            function text_update() {
              console.log('text_update()');

              console.log('update text circle hour_TIME');
              let valueHour = timeSensor.format_hour;
              let normal_hour_circle_string = parseInt(valueHour).toString();
              normal_hour_circle_string = normal_hour_circle_string.padStart(2, '0');

              if (screenType != hmSetting.screen_type.AOD) {
                for (var i = 1; i < 2; i++) {  // hide all symbols
                  normal_hour_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                let char_Angle = -22;
                if (valueHour != null && valueHour != undefined && isFinite(valueHour) && normal_hour_circle_string.length > 0 && normal_hour_circle_string.length <= 2) {  // display data if it was possible to get it
                  let normal_hour_TextCircle_img_angle = 0;
                  let normal_hour_TextCircle_dot_img_angle = 0;
                  normal_hour_TextCircle_img_angle = toDegree(Math.atan2(normal_hour_TextCircle_img_width/2, 155));
                  
                  let firstSymbol = true;
                  let index = 0;
                  for (let char of normal_hour_circle_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 2) break;
                    if (charCode >= 0 && charCode < 10) { 
                      if (!firstSymbol) char_Angle += normal_hour_TextCircle_img_angle;
                      firstSymbol = false;
                      normal_hour_TextCircle[index].setProperty(hmUI.prop.ANGLE, char_Angle);
                      normal_hour_TextCircle[index].setProperty(hmUI.prop.POS_X, 233 - normal_hour_TextCircle_img_width / 2);
                      normal_hour_TextCircle[index].setProperty(hmUI.prop.SRC, normal_hour_TextCircle_ASCIIARRAY[charCode]);
                      normal_hour_TextCircle[index].setProperty(hmUI.prop.VISIBLE, true);
                      char_Angle += normal_hour_TextCircle_img_angle + -1;
                      index++;
                    };  // end if digit
                  };  // end char of string
                }  // end isFinite

              };

              console.log('update text circle minute_TIME');
              let valueMinute = timeSensor.minute;
              let normal_minute_circle_string = parseInt(valueMinute).toString();
              normal_minute_circle_string = normal_minute_circle_string.padStart(2, '0');

              if (screenType != hmSetting.screen_type.AOD) {
                for (var i = 1; i < 2; i++) {  // hide all symbols
                  normal_minute_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                let char_Angle = 12;
                if (valueMinute != null && valueMinute != undefined && isFinite(valueMinute) && normal_minute_circle_string.length > 0 && normal_minute_circle_string.length <= 2) {  // display data if it was possible to get it
                  let normal_minute_TextCircle_img_angle = 0;
                  let normal_minute_TextCircle_dot_img_angle = 0;
                  normal_minute_TextCircle_img_angle = toDegree(Math.atan2(normal_minute_TextCircle_img_width/2, 155));
                  
                  let firstSymbol = true;
                  let index = 0;
                  for (let char of normal_minute_circle_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 2) break;
                    if (charCode >= 0 && charCode < 10) { 
                      if (!firstSymbol) char_Angle += normal_minute_TextCircle_img_angle;
                      firstSymbol = false;
                      normal_minute_TextCircle[index].setProperty(hmUI.prop.ANGLE, char_Angle);
                      normal_minute_TextCircle[index].setProperty(hmUI.prop.POS_X, 233 - normal_minute_TextCircle_img_width / 2);
                      normal_minute_TextCircle[index].setProperty(hmUI.prop.SRC, normal_minute_TextCircle_ASCIIARRAY[charCode]);
                      normal_minute_TextCircle[index].setProperty(hmUI.prop.VISIBLE, true);
                      char_Angle += normal_minute_TextCircle_img_angle + -1;
                      index++;
                    };  // end if digit
                  };  // end char of string
                }  // end isFinite

              };

            };

            //end of ignored block
            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                console.log('resume_call()');
                text_update();
                normal_frame_animation_1.setProperty(hmUI.prop.ANIM_STATUS,hmUI.anim_status.START);
                if (screenType == hmSetting.screen_type.WATCHFACE) {
                  if (!normal_timerTextUpdate) {
                    normal_timerTextUpdate = timer.createTimer(0, 1000, (function (option) {
                      text_update();
                    }));  // end timer 
                  };  // end timer check
                };  // end screenType


              }),
              pause_call: (function () {
                console.log('pause_call()');
                normal_frame_animation_1.setProperty(hmUI.prop.ANIM_STATUS,hmUI.anim_status.STOP);
                if (normal_timerTextUpdate) {
                  timer.stopTimer(normal_timerTextUpdate);
                  normal_timerTextUpdate = undefined;
                }

              }),
            });

                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}