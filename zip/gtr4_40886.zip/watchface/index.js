﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (()=>{
        //dynamic modify start

        const lang = DeviceRuntimeCore.HmUtils.getLanguage()
        let normal_background_bg_img = ''
        let normal_date_img_date_year = ''
        let normal_date_img_date_month = ''
        let normal_date_img_date_day = ''
        let normal_date_img_date_week_img = ''
        let normal_system_lock_img = ''
        let normal_system_disconnect_img = ''
        let normal_system_clock_img = ''
        let normal_wind_pointer_progress_img_pointer = ''
        let normal_wind_text_text_img = ''
        let normal_uvi_pointer_progress_img_pointer = ''
        let normal_uvi_text_text_img = ''
        let normal_weather_image_progress_img_level = ''
        let normal_temperature_max_min_text_img = ''
        let normal_temperature_current_text_img = ''
        let normal_humidity_icon_img = ''
        let normal_vo2max_pointer_progress_img_pointer = ''
        let normal_vo2max_text_text_img = ''
        let normal_fat_burning_icon_img = ''
        let normal_training_load_pointer_progress_img_pointer = ''
        let normal_training_load_current_text_img = ''
        let normal_pai_icon_img = ''
        let normal_pai_pointer_progress_img_pointer = ''
        let normal_pai_weekly_text_img = ''
        let normal_battery_icon_img = ''
        let normal_battery_pointer_progress_img_pointer = ''
        let normal_battery_text_text_img = ''
        let normal_battery_image_progress_img_level = ''
        let normal_stress_icon_img = ''
        let normal_stress_pointer_progress_img_pointer = ''
        let normal_stress_text_text_img = ''
        let normal_heart_rate_icon_img = ''
        let normal_heart_rate_pointer_progress_img_pointer = ''
        let normal_heart_rate_text_text_img = ''
        let normal_stand_icon_img = ''
        let normal_stand_pointer_progress_img_pointer = ''
        let normal_stand_target_text_img = ''
        let normal_stand_current_text_img = ''
        let normal_calorie_icon_img = ''
        let normal_calorie_pointer_progress_img_pointer = ''
        let normal_calorie_current_text_img = ''
        let normal_step_icon_img = ''
        let normal_step_pointer_progress_img_pointer = ''
        let normal_step_current_text_img = ''
        let normal_digital_clock_img_time = ''
        let idle_background_bg = ''
        let idle_system_disconnect_img = ''
        let idle_digital_clock_img_time = ''
        let normal_step_jumpable_img_click = ''
        let normal_heart_jumpable_img_click = ''
        let normal_pai_jumpable_img_click = ''
        let normal_temperature_jumpable_img_click = ''
        let Button_1 = ''
        let Button_2 = ''
		
		const { width: DEVICE_WIDTH, height: DEVICE_HEIGHT } = hmSetting.getDeviceInfo();
		
		let group1 = ''
		let group2 = ''
		let group3 = ''
		let group4 = ''
		let group5 = ''
		let group6 = ''
		let group7 = ''
		let group8 = ''
		let group9 = ''
		
		let btn_zona1 = ''
        let zona1_num = 0
        let zona1_all = 2
		
		function click_zona1() {
		  zona1_num = (zona1_num + 1) % (zona1_all + 1);
          if (zona1_num == 0) {		
		    group6.setProperty(hmUI.prop.VISIBLE, true);
			group5.setProperty(hmUI.prop.VISIBLE, false);
			group4.setProperty(hmUI.prop.VISIBLE, false);
		    hmUI.showToast({
            });
          };
		  
		 if (zona1_num == 1) {
			group6.setProperty(hmUI.prop.VISIBLE, false);
			group5.setProperty(hmUI.prop.VISIBLE, true);
			group4.setProperty(hmUI.prop.VISIBLE, false);
		    hmUI.showToast({
            });
          };
		  
		  if (zona1_num == 2) {
			group6.setProperty(hmUI.prop.VISIBLE, false);
			group5.setProperty(hmUI.prop.VISIBLE, false);
			group4.setProperty(hmUI.prop.VISIBLE, true);
		    hmUI.showToast({
            });
          };
        }
		
		let btn_zona2 = ''
        let zona2_num = 0
        let zona2_all = 2
		
		function click_zona2() {
		  zona2_num = (zona2_num + 1) % (zona2_all + 1);
          if (zona2_num == 0) {		
		    group9.setProperty(hmUI.prop.VISIBLE, true);
			group8.setProperty(hmUI.prop.VISIBLE, false);
			group7.setProperty(hmUI.prop.VISIBLE, false);
		    hmUI.showToast({
            });
          };
		  
		 if (zona2_num == 1) {
			group9.setProperty(hmUI.prop.VISIBLE, false);
			group8.setProperty(hmUI.prop.VISIBLE, true);
			group7.setProperty(hmUI.prop.VISIBLE, false);
		    hmUI.showToast({
            });
          };
		  
		  if (zona2_num == 2) {
			group9.setProperty(hmUI.prop.VISIBLE, false);
			group8.setProperty(hmUI.prop.VISIBLE, false);
			group7.setProperty(hmUI.prop.VISIBLE, true);
		    hmUI.showToast({
            });
          };
        }
		
		let btn_zona3 = ''
        let zona3_num = 0
        let zona3_all = 2
		
		function click_zona3() {
		  zona3_num = (zona3_num + 1) % (zona3_all + 1);
          if (zona3_num == 0) {		
		    group3.setProperty(hmUI.prop.VISIBLE, true);
			group2.setProperty(hmUI.prop.VISIBLE, false);
			group1.setProperty(hmUI.prop.VISIBLE, false);
		    hmUI.showToast({
            });
          };
		  
		 if (zona3_num == 1) {
			group3.setProperty(hmUI.prop.VISIBLE, false);
			group2.setProperty(hmUI.prop.VISIBLE, true);
			group1.setProperty(hmUI.prop.VISIBLE, false);
		    hmUI.showToast({
            });
          };
		  
		  if (zona3_num == 2) {
			group3.setProperty(hmUI.prop.VISIBLE, false);
			group2.setProperty(hmUI.prop.VISIBLE, false);
			group1.setProperty(hmUI.prop.VISIBLE, true);
		    hmUI.showToast({
            });
          };
        }


        //dynamic modify end
        const e = __$$hmAppManager$$__.currentApp;
        const o = e.current
          , {px: i} = (new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(e,o)),
        e.__globals__)
          , n = Logger.getLogger("watchface6");
        o.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            console.log('Watch_Face.ScreenNormal');
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 466,
              h: 466,
              src: 'bg.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_year = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              year_startX: 258,
              year_startY: 21,
              year_sc_array: ["font_0.png","font_1.png","font_2.png","font_3.png","font_4.png","font_5.png","font_6.png","font_7.png","font_8.png","font_9.png"],
              year_tc_array: ["font_0.png","font_1.png","font_2.png","font_3.png","font_4.png","font_5.png","font_6.png","font_7.png","font_8.png","font_9.png"],
              year_en_array: ["font_0.png","font_1.png","font_2.png","font_3.png","font_4.png","font_5.png","font_6.png","font_7.png","font_8.png","font_9.png"],
              year_zero: 0,
              year_space: 0,
              year_align: hmUI.align.CENTER_H,
              year_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_month = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 216,
              month_startY: 21,
              month_sc_array: ["font_0.png","font_1.png","font_2.png","font_3.png","font_4.png","font_5.png","font_6.png","font_7.png","font_8.png","font_9.png"],
              month_tc_array: ["font_0.png","font_1.png","font_2.png","font_3.png","font_4.png","font_5.png","font_6.png","font_7.png","font_8.png","font_9.png"],
              month_en_array: ["font_0.png","font_1.png","font_2.png","font_3.png","font_4.png","font_5.png","font_6.png","font_7.png","font_8.png","font_9.png"],
              month_zero: 1,
              month_space: 0,
              month_unit_sc: 'dot_1.png',
              month_unit_tc: 'dot_1.png',
              month_unit_en: 'dot_1.png',
              month_align: hmUI.align.CENTER_H,
              month_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 173,
              day_startY: 21,
              day_sc_array: ["font_0.png","font_1.png","font_2.png","font_3.png","font_4.png","font_5.png","font_6.png","font_7.png","font_8.png","font_9.png"],
              day_tc_array: ["font_0.png","font_1.png","font_2.png","font_3.png","font_4.png","font_5.png","font_6.png","font_7.png","font_8.png","font_9.png"],
              day_en_array: ["font_0.png","font_1.png","font_2.png","font_3.png","font_4.png","font_5.png","font_6.png","font_7.png","font_8.png","font_9.png"],
              day_zero: 1,
              day_space: 0,
              day_unit_sc: 'dot_1.png',
              day_unit_tc: 'dot_1.png',
              day_unit_en: 'dot_1.png',
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
			
			let dned=["week_1.png","week_2.png","week_3.png","week_4.png","week_5.png","week_6.png","week_7.png"]
			if(lang=='ru-RU'){
				dned=["weekru_1.png","weekru_2.png","weekru_3.png","weekru_4.png","weekru_5.png","weekru_6.png","weekru_7.png"]
			}
            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 136,
              y: 53,
              week_en: dned,
              week_tc: ["week_1.png","week_2.png","week_3.png","week_4.png","week_5.png","week_6.png","week_7.png"],
              week_sc: ["week_1.png","week_2.png","week_3.png","week_4.png","week_5.png","week_6.png","week_7.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_lock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 256,
              y: 430,
              src: 'lock.png',
              type: hmUI.system_status.LOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 220,
              y: 430,
              src: 'bt.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 184,
              y: 430,
              src: 'alarm.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_wind_pointer_progress_img_pointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
              src: 'wind.png',
              center_x: 233,
              center_y: 233,
              x: -216,
              y: 10,
              start_angle: 46,
              end_angle: -47,
              invalid_visible: false,
              type: hmUI.data_type.WIND,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_wind_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 348,
              y: 395,
              font_array: ["fonts_0.png","fonts_1.png","fonts_2.png","fonts_3.png","fonts_4.png","fonts_5.png","fonts_6.png","fonts_7.png","fonts_8.png","fonts_9.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WIND,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_uvi_pointer_progress_img_pointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
              src: 'uvi.png',
              center_x: 233,
              center_y: 233,
              x: 229,
              y: 11,
              start_angle: -46,
              end_angle: 46,
              invalid_visible: false,
              type: hmUI.data_type.UVI,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_uvi_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 97,
              y: 395,
              font_array: ["fonts_0.png","fonts_1.png","fonts_2.png","fonts_3.png","fonts_4.png","fonts_5.png","fonts_6.png","fonts_7.png","fonts_8.png","fonts_9.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.UVI,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 92,
              y: 293,
              image_array: ["w_1.png","w_2.png","w_3.png","w_4.png","w_5.png","w_6.png","w_7.png","w_8.png","w_9.png","w_10.png","w_11.png","w_12.png","w_13.png","w_14.png","w_15.png","w_16.png","w_17.png","w_18.png","w_19.png","w_20.png","w_21.png","w_22.png","w_23.png","w_24.png","w_25.png","w_26.png","w_27.png","w_28.png","w_29.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_max_min_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 279,
              y: 318,
              font_array: ["font_0.png","font_1.png","font_2.png","font_3.png","font_4.png","font_5.png","font_6.png","font_7.png","font_8.png","font_9.png"],
              padding: false,
              h_space: 0,
              negative_image: 'dot1.png',
              dot_image: 'dot_1.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_HIGH_LOW,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 170,
              y: 310,
              font_array: ["A100_116.png","A100_117.png","A100_118.png","A100_119.png","A100_120.png","A100_121.png","A100_122.png","A100_123.png","A100_124.png","A100_125.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'gradus.png',
              unit_tc: 'gradus.png',
              unit_en: 'gradus.png',
              negative_image: 'A100_126.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
			
			group1 = hmUI.createWidget(hmUI.widget.GROUP, {
	                  x: 0,
	                  y: 0,
	                  w: DEVICE_WIDTH,
	                  h: DEVICE_HEIGHT,
            });

            normal_humidity_icon_img = group1.createWidget(hmUI.widget.IMG, {
              x: 301,
              y: 165,
              src: 'A100_419.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_vo2max_pointer_progress_img_pointer = group1.createWidget(hmUI.widget.IMG_POINTER, {
              src: 'A100_233.png',
              center_x: 351,
              center_y: 214,
              x: 7,
              y: 51,
              start_angle: -135,
              end_angle: 135,
              invalid_visible: false,
              type: hmUI.data_type.VO2MAX,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_vo2max_text_text_img = group1.createWidget(hmUI.widget.TEXT_IMG, {
              x: 335,
              y: 201,
              font_array: ["font_0.png","font_1.png","font_2.png","font_3.png","font_4.png","font_5.png","font_6.png","font_7.png","font_8.png","font_9.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.VO2MAX,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
			
			group2 = hmUI.createWidget(hmUI.widget.GROUP, {
	                  x: 0,
	                  y: 0,
	                  w: DEVICE_WIDTH,
	                  h: DEVICE_HEIGHT,
            });

            normal_fat_burning_icon_img = group2.createWidget(hmUI.widget.IMG, {
              x: 301,
              y: 165,
              src: 'A100_421.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_training_load_pointer_progress_img_pointer = group2.createWidget(hmUI.widget.IMG_POINTER, {
              src: 'A100_233.png',
              center_x: 351,
              center_y: 214,
              x: 7,
              y: 51,
              start_angle: -135,
              end_angle: 135,
              invalid_visible: false,
              type: hmUI.data_type.TRAINING_LOAD,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_training_load_current_text_img = group2.createWidget(hmUI.widget.TEXT_IMG, {
              x: 330,
              y: 201,
              font_array: ["font_0.png","font_1.png","font_2.png","font_3.png","font_4.png","font_5.png","font_6.png","font_7.png","font_8.png","font_9.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.TRAINING_LOAD,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
			
			group3 = hmUI.createWidget(hmUI.widget.GROUP, {
	                  x: 0,
	                  y: 0,
	                  w: DEVICE_WIDTH,
	                  h: DEVICE_HEIGHT,
            });

            normal_pai_icon_img = group3.createWidget(hmUI.widget.IMG, {
              x: 301,
              y: 165,
              src: 'A100_418.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_pai_pointer_progress_img_pointer = group3.createWidget(hmUI.widget.IMG_POINTER, {
              src: 'A100_233.png',
              center_x: 351,
              center_y: 214,
              x: 7,
              y: 51,
              start_angle: -135,
              end_angle: 135,
              invalid_visible: false,
              type: hmUI.data_type.PAI_WEEKLY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_pai_weekly_text_img = group3.createWidget(hmUI.widget.TEXT_IMG, {
              x: 330,
              y: 201,
              font_array: ["font_0.png","font_1.png","font_2.png","font_3.png","font_4.png","font_5.png","font_6.png","font_7.png","font_8.png","font_9.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.PAI_WEEKLY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
			
			group4 = hmUI.createWidget(hmUI.widget.GROUP, {
	                  x: 0,
	                  y: 0,
	                  w: DEVICE_WIDTH,
	                  h: DEVICE_HEIGHT,
            });

            normal_battery_icon_img = group4.createWidget(hmUI.widget.IMG, {
              x: 68,
              y: 165,
              src: 'A100_410.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_pointer_progress_img_pointer = group4.createWidget(hmUI.widget.IMG_POINTER, {
              src: 'A100_233.png',
              center_x: 118,
              center_y: 214,
              x: 7,
              y: 51,
              start_angle: -135,
              end_angle: 135,
              invalid_visible: false,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_text_img = group4.createWidget(hmUI.widget.TEXT_IMG, {
              x: 90,
              y: 201,
              font_array: ["font_0.png","font_1.png","font_2.png","font_3.png","font_4.png","font_5.png","font_6.png","font_7.png","font_8.png","font_9.png"],
              padding: false,
              h_space: 0,
              unit_sc: '%.png',
              unit_tc: '%.png',
              unit_en: '%.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_image_progress_img_level = group4.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 108,
              y: 246,
              image_array: ["A100_465.png","A100_466.png","A100_467.png","A100_468.png","A100_469.png","A100_470.png","A100_471.png","A100_472.png","A100_473.png","A100_474.png","A100_475.png"],
              image_length: 11,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
			
			group5 = hmUI.createWidget(hmUI.widget.GROUP, {
	                  x: 0,
	                  y: 0,
	                  w: DEVICE_WIDTH,
	                  h: DEVICE_HEIGHT,
            });

            normal_stress_icon_img = group5.createWidget(hmUI.widget.IMG, {
              x: 68,
              y: 165,
              src: 'A100_030.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_stress_pointer_progress_img_pointer = group5.createWidget(hmUI.widget.IMG_POINTER, {
              src: 'A100_233.png',
              center_x: 118,
              center_y: 214,
              x: 7,
              y: 51,
              start_angle: -135,
              end_angle: 135,
              invalid_visible: false,
              type: hmUI.data_type.STRESS,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_stress_text_text_img = group5.createWidget(hmUI.widget.TEXT_IMG, {
              x: 97,
              y: 201,
              font_array: ["font_0.png","font_1.png","font_2.png","font_3.png","font_4.png","font_5.png","font_6.png","font_7.png","font_8.png","font_9.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STRESS,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
			
			group6 = hmUI.createWidget(hmUI.widget.GROUP, {
	                  x: 0,
	                  y: 0,
	                  w: DEVICE_WIDTH,
	                  h: DEVICE_HEIGHT,
            });

            normal_heart_rate_icon_img = group6.createWidget(hmUI.widget.IMG, {
              x: 68,
              y: 165,
              src: 'A100_445.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_pointer_progress_img_pointer = group6.createWidget(hmUI.widget.IMG_POINTER, {
              src: 'A100_233.png',
              center_x: 118,
              center_y: 214,
              x: 7,
              y: 51,
              start_angle: -135,
              end_angle: 135,
              invalid_visible: false,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_text_img = group6.createWidget(hmUI.widget.TEXT_IMG, {
              x: 96,
              y: 201,
              font_array: ["font_0.png","font_1.png","font_2.png","font_3.png","font_4.png","font_5.png","font_6.png","font_7.png","font_8.png","font_9.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
			
			group7 = hmUI.createWidget(hmUI.widget.GROUP, {
	                  x: 0,
	                  y: 0,
	                  w: DEVICE_WIDTH,
	                  h: DEVICE_HEIGHT,
            });

            normal_stand_icon_img = group7.createWidget(hmUI.widget.IMG, {
              x: 184,
              y: 165,
              src: 'stand.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_stand_pointer_progress_img_pointer = group7.createWidget(hmUI.widget.IMG_POINTER, {
              src: 'A100_233.png',
              center_x: 236,
              center_y: 214,
              x: 7,
              y: 51,
              start_angle: -135,
              end_angle: 135,
              invalid_visible: false,
              type: hmUI.data_type.STAND,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_stand_target_text_img = group7.createWidget(hmUI.widget.TEXT_IMG, {
              x: 242,
              y: 201,
              font_array: ["font_0.png","font_1.png","font_2.png","font_3.png","font_4.png","font_5.png","font_6.png","font_7.png","font_8.png","font_9.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STAND_TARGET,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_stand_current_text_img = group7.createWidget(hmUI.widget.TEXT_IMG, {
              x: 172,
              y: 201,
              font_array: ["font_0.png","font_1.png","font_2.png","font_3.png","font_4.png","font_5.png","font_6.png","font_7.png","font_8.png","font_9.png"],
              padding: true,
              h_space: 0,
              unit_sc: 'dot_1.png',
              unit_tc: 'dot_1.png',
              unit_en: 'dot_1.png',
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.STAND,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
			
			group8 = hmUI.createWidget(hmUI.widget.GROUP, {
	                  x: 0,
	                  y: 0,
	                  w: DEVICE_WIDTH,
	                  h: DEVICE_HEIGHT,
            });

            normal_calorie_icon_img = group8.createWidget(hmUI.widget.IMG, {
              x: 184,
              y: 165,
              src: 'cal.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_calorie_pointer_progress_img_pointer = group8.createWidget(hmUI.widget.IMG_POINTER, {
              src: 'A100_233.png',
              center_x: 236,
              center_y: 214,
              x: 7,
              y: 51,
              start_angle: -135,
              end_angle: 135,
              invalid_visible: false,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_calorie_current_text_img = group8.createWidget(hmUI.widget.TEXT_IMG, {
              x: 207,
              y: 201,
              font_array: ["font_0.png","font_1.png","font_2.png","font_3.png","font_4.png","font_5.png","font_6.png","font_7.png","font_8.png","font_9.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
			
			group9 = hmUI.createWidget(hmUI.widget.GROUP, {
	                  x: 0,
	                  y: 0,
	                  w: DEVICE_WIDTH,
	                  h: DEVICE_HEIGHT,
            });

            normal_step_icon_img = group9.createWidget(hmUI.widget.IMG, {
              x: 184,
              y: 165,
              src: 'step.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_pointer_progress_img_pointer = group9.createWidget(hmUI.widget.IMG_POINTER, {
              src: 'A100_233.png',
              center_x: 236,
              center_y: 214,
              x: 7,
              y: 51,
              start_angle: -135,
              end_angle: 135,
              invalid_visible: false,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_text_img = group9.createWidget(hmUI.widget.TEXT_IMG, {
              x: 201,
              y: 201,
              font_array: ["font_0.png","font_1.png","font_2.png","font_3.png","font_4.png","font_5.png","font_6.png","font_7.png","font_8.png","font_9.png"],
              padding: false,
              h_space: -1,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 81,
              hour_startY: 92,
              hour_array: ["time_0.png","time_1.png","time_2.png","time_3.png","time_4.png","time_5.png","time_6.png","time_7.png","time_8.png","time_9.png"],
              hour_zero: 1,
              hour_space: 10,
              hour_angle: 0,
              hour_unit_sc: 'colon.png',
              hour_unit_tc: 'colon.png',
              hour_unit_en: 'colon.png',
              hour_align: hmUI.align.LEFT,

              minute_startX: 250,
              minute_startY: 92,
              minute_array: ["time_0.png","time_1.png","time_2.png","time_3.png","time_4.png","time_5.png","time_6.png","time_7.png","time_8.png","time_9.png"],
              minute_zero: 1,
              minute_space: 10,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              second_startX: 221,
              second_startY: 109,
              second_array: ["fonts_0.png","fonts_1.png","fonts_2.png","fonts_3.png","fonts_4.png","fonts_5.png","fonts_6.png","fonts_7.png","fonts_8.png","fonts_9.png"],
              second_zero: 1,
              second_space: 0,
              second_angle: 0,
              second_follow: 0,
              second_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            console.log('Watch_Face.ScreenAOD');
            idle_background_bg = hmUI.createWidget(hmUI.widget.FILL_RECT, {
              x: 0,
              y: 0,
              w: 466,
              h: 466,
              color: '0xFF000000',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 220,
              y: 430,
              src: 'bt.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 81,
              hour_startY: 207,
              hour_array: ["time_0.png","time_1.png","time_2.png","time_3.png","time_4.png","time_5.png","time_6.png","time_7.png","time_8.png","time_9.png"],
              hour_zero: 1,
              hour_space: 10,
              hour_angle: 0,
              hour_unit_sc: 'colon.png',
              hour_unit_tc: 'colon.png',
              hour_unit_en: 'colon.png',
              hour_align: hmUI.align.LEFT,

              minute_startX: 250,
              minute_startY: 207,
              minute_array: ["time_0.png","time_1.png","time_2.png","time_3.png","time_4.png","time_5.png","time_6.png","time_7.png","time_8.png","time_9.png"],
              minute_zero: 1,
              minute_space: 10,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_AOD,
            });
            console.log('Watch_Face.Shortcuts');
			
			const vibrate = hmSensor.createSensor(hmSensor.id.VIBRATE);
            let timer_StopVibrate = null;


            function vibro(scene = 25) {
              let stopDelay = 50;
              stopVibro();
              vibrate.stop();
              vibrate.scene = scene;
              if (scene < 23 || scene > 25) stopDelay = 1300;
              vibrate.start();
              timer_StopVibrate = timer.createTimer(stopDelay, 3000, stopVibro, {});
            }

            function stopVibro() {
              vibrate.stop();
              if (timer_StopVibrate) timer.stopTimer(timer_StopVibrate);
            }

            btn_zona2 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 200,
              y: 180,
              text: '',
              w: 73,
              h: 73,
              normal_src: 'Empty.png',
              press_src: 'Empty.png',
              click_func: () => {
				click_zona2();
                vibro();
             },
			  longpress_func: () => {
             hmApp.startApp({ url: "activityAppScreen", native: true });
             },
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            btn_zona2.setProperty(hmUI.prop.VISIBLE, true);
			group8.setProperty(hmUI.prop.VISIBLE, false);
			group7.setProperty(hmUI.prop.VISIBLE, false);

            btn_zona1 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 83,
              y: 180,
              text: '',
              w: 73,
              h: 73,
              normal_src: 'Empty.png',
              press_src: 'Empty.png',
              click_func: () => {
				click_zona1();
                vibro();
             },
			  longpress_func: () => {
             hmApp.startApp({ url: "heart_app_Screen", native: true });
             },
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            btn_zona1.setProperty(hmUI.prop.VISIBLE, true);
			group5.setProperty(hmUI.prop.VISIBLE, false);
			group4.setProperty(hmUI.prop.VISIBLE, false);

            btn_zona3 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 316,
              y: 180,
              text: '',
              w: 73,
              h: 73,
              normal_src: 'Empty.png',
              press_src: 'Empty.png',
              click_func: () => {
				click_zona3();
                vibro();
             },
			  longpress_func: () => {
             hmApp.startApp({ url: "PAI_app_Screen", native: true });
             },
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            btn_zona3.setProperty(hmUI.prop.VISIBLE, true);
			group2.setProperty(hmUI.prop.VISIBLE, false);
			group1.setProperty(hmUI.prop.VISIBLE, false);

            normal_temperature_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 126,
              y: 296,
              w: 126,
              h: 73,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            console.log('Watch_Face.Buttons');
            Button_1 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 131,
              y: 379,
              w: 58,
              h: 58,
              text: '',
              color: 0xFFFF8C00,
              text_size: 24,
              press_src: 'Empty.png',
              normal_src: 'Empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'FindPhoneScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_2 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 275,
              y: 379,
              w: 58,
              h: 58,
              text: '',
              color: 0xFFFF8C00,
              text_size: 24,
              press_src: 'Empty.png',
              normal_src: 'Empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'ScheduleCalScreen', native: true });
              }, // end func
              longpress_func: (button_widget) => {
                hmApp.startApp({url: 'todoListScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button
			
			hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 204,
              y: 379,
              w: 58,
              h: 58,
              text: '',
              normal_src: 'Empty.png',
              press_src: 'Empty.png',
              click_func: () => {
                vibro();
                panel_visible = !panel_visible;
                gr_panels.setProperty(hmUI.prop.VISIBLE, panel_visible);
              },
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
			
			let gr_panels = hmUI.createWidget(hmUI.widget.GROUP, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
            });
            gr_panels.setProperty(hmUI.prop.VISIBLE, false);

            let gr_panels_fill = gr_panels.createWidget(hmUI.widget.FILL_RECT, {
              x: 70,
              y: 70,
              w: 480 - 140,
              h: 480 - 140,
              color: '0xAA211d1e',
              radius: 20,
              alpha: 220,
              show_level:

                hmUI.show_level.ONLY_NORMAL,
            });

            //кнопка 1
            gr_panels.createWidget(hmUI.widget.BUTTON, {
              x: 100,
              y: 100,
              w: 70,
              h: 70,
              text: '',
              normal_src: 'phone.png',
              press_src: 'phone.png',
              click_func: () => {
                vibro();
                hmApp.startApp({
                  appid: 1,
                  url: 'PhoneRecentCallScreen',
                  native: true
                });
                //запуск приложения 1

              },
              longpress_func: () => {
               hmApp.startApp({ url: "PhoneContactsScreen", native: true });
              },

              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            //кнопка 2
            gr_panels.createWidget(hmUI.widget.BUTTON, {
              x: 200,
              y: 100,
              w: 70,
              h: 70,
              text: '',
              normal_src: 'music.png',
              press_src: 'music.png',
              click_func: () => {
                vibro();
                hmApp.startApp({
                  appid: 1,
                  url: 'LocalMusicScreen',
                  native: true
                });
                //запуск приложения 2

              },
              longpress_func: () => {
               hmApp.startApp({ url: "MusicCommonScreen", native: true });

              },
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            //кнопка 3
            gr_panels.createWidget(hmUI.widget.BUTTON, {
              x: 300,
              y: 100,
              w: 70,
              h: 70,
              text: '',
              normal_src: 'voicememo.png',
              press_src: 'Empty.png',
              click_func: () => {
                vibro();
                hmApp.startApp({
                  appid: 1,
                  url: 'VoiceMemoScreen',
                  native: true
                });
                //запуск приложения 3

              },

              longpress_func: () => {

              },
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            gr_panels.createWidget(hmUI.widget.BUTTON, {
              x: 100,
              y: 200,
              w: 70,
              h: 70,
              text: '',
              normal_src: 'stopwatch.png',
              press_src: 'Empty.png',
              click_func: () => {
                vibro();
                hmApp.startApp({
                  appid: 1,
                  url: 'StopWatchScreen',
                  native: true
                });
                //запуск приложения 4

              },

              longpress_func: () => {

              },
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            gr_panels.createWidget(hmUI.widget.BUTTON, {
              x: 100,
              y: 300,
              w: 70,
              h: 70,
              text: '',
              normal_src: 'compass.png',
              press_src: 'compass.png',
              click_func: () => {
                vibro();
                hmApp.startApp({
                  appid: 1,
                  url: 'CompassScreen',
                  native: true
                });
                //запуск приложения 5

              },

              longpress_func: () => {
			hmApp.startApp({ url: "BaroAltimeterScreen", native: true });
              },
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            gr_panels.createWidget(hmUI.widget.BUTTON, {
              x: 200,
              y: 200,
              w: 70,
              h: 70,
              text: '',
              normal_src: 'countdown.png',
              press_src: 'Empty.png',
              click_func: () => {
                vibro();
                hmApp.startApp({
                  appid: 1,
                  url: 'CountdownAppScreen',
                  native: true
                });
                //запуск приложения 6

              },

              longpress_func: () => {

              },
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            gr_panels.createWidget(hmUI.widget.BUTTON, {
              x: 200,
              y: 300,
              w: 70,
              h: 70,
              text: '',
              normal_src: 'measurement.png',
              press_src: 'Empty.png',
              click_func: () => {
                vibro();
                hmApp.startApp({
                  appid: 1,
                  url: 'oneKeyAppScreen',
                  native: true
                });
                //запуск приложения 7

              },

              longpress_func: () => {

              },
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            gr_panels.createWidget(hmUI.widget.BUTTON, {
              x: 300,
              y: 300,
              w: 70,
              h: 70,
              text: '',
              normal_src: 'setting.png',
              press_src: 'setting.png',
              click_func: () => {
                vibro();
                hmApp.startApp({
                  appid: 1,
                  url: 'Settings_homeScreen',
                  native: true
                });
                //запуск приложения 8

              },

              longpress_func: () => {
               hmApp.startApp({url: 'HmReStartScreen', native: true });
              },
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            gr_panels.createWidget(hmUI.widget.BUTTON, {
              x: 300,
              y: 200,
              w: 70,
              h: 70,
              text: '',
              normal_src: 'sport.png',
              press_src: 'sport.png',
              click_func: () => {
                vibro();
                hmApp.startApp({
                  appid: 1,
                  url: 'SportListScreen',
                  native: true
                });
                //запуск приложения 9

              },

              longpress_func: () => {
               hmApp.startApp({ url: "SportRecordListScreen", native: true });
              },
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            
            let panel_visible = false;
            
            gr_panels.createWidget(hmUI.widget.BUTTON, {
              x: 365,
              y: 55,
              w: 50,
              h: 50,
              radius: 25,
              text: 'X',
              normal_color: 0x992255,
              press_color: 0xfeb4a8,
              click_func: () => {

                vibro(24);
                panel_visible = !panel_visible;
                gr_panels.setProperty(hmUI.prop.VISIBLE, panel_visible);
              },
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}