﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        const logger = Logger.getLogger('watchface_SashaCX75');
        //end of ignored block

        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_system_clock_img = ''
        let normal_date_img_date_week_img = ''
        let normal_heart_rate_text_text_img = ''
        let normal_distance_text_text_img = ''
        let normal_calorie_current_text_img = ''
        let normal_step_current_text_img = ''
        let normal_image_img = ''
        let normal_temperature_current_text_img = ''
        let normal_weather_image_progress_img_level = ''
        let normal_date_img_date_month_img = ''
        let normal_date_img_date_day = ''
        let normal_battery_image_progress_img_level = ''
        let normal_battery_text_text_img = ''
        let normal_digital_clock_img_time_AmPm = ''
        let normal_digital_clock_img_time = ''
        let normal_analog_clock_time_pointer_second = ''
        let idle_background_bg_img = ''
        let idle_system_clock_img = ''
        let idle_date_img_date_week_img = ''
        let idle_heart_rate_text_text_img = ''
        let idle_distance_text_text_img = ''
        let idle_calorie_current_text_img = ''
        let idle_step_current_text_img = ''
        let idle_image_img = ''
        let idle_temperature_current_text_img = ''
        let idle_weather_image_progress_img_level = ''
        let idle_date_img_date_month_img = ''
        let idle_date_img_date_day = ''
        let idle_battery_image_progress_img_level = ''
        let idle_battery_text_text_img = ''
        let idle_digital_clock_img_time_AmPm = ''
        let idle_digital_clock_img_time = ''
        let idle_analog_clock_time_pointer_second = ''


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            console.log('Watch_Face.ScreenNormal');
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 466,
              h: 466,
              src: '466_3.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 366,
              y: 160,
              src: '0075.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 233,
              y: 92,
              week_en: ["m0043.png","m0044.png","m0045.png","m0046.png","m0047.png","m0048.png","m0049.png"],
              week_tc: ["m0043.png","m0044.png","m0045.png","m0046.png","m0047.png","m0048.png","m0049.png"],
              week_sc: ["m0043.png","m0044.png","m0045.png","m0046.png","m0047.png","m0048.png","m0049.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 323,
              y: 111,
              font_array: ["WF0_Frame0047.png","WF0_Frame0048.png","WF0_Frame0049.png","WF0_Frame0050.png","WF0_Frame0051.png","WF0_Frame0052.png","WF0_Frame0053.png","WF0_Frame0054.png","WF0_Frame0055.png","WF0_Frame0056.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_distance_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 125,
              y: 343,
              font_array: ["WF0_Frame0047.png","WF0_Frame0048.png","WF0_Frame0049.png","WF0_Frame0050.png","WF0_Frame0051.png","WF0_Frame0052.png","WF0_Frame0053.png","WF0_Frame0054.png","WF0_Frame0055.png","WF0_Frame0056.png"],
              padding: false,
              h_space: 0,
              unit_sc: '0042.png',
              unit_tc: '0042.png',
              unit_en: '0042.png',
              dot_image: '0039.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.DISTANCE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_calorie_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 143,
              y: 380,
              font_array: ["WF0_Frame0047.png","WF0_Frame0048.png","WF0_Frame0049.png","WF0_Frame0050.png","WF0_Frame0051.png","WF0_Frame0052.png","WF0_Frame0053.png","WF0_Frame0054.png","WF0_Frame0055.png","WF0_Frame0056.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 114,
              y: 302,
              font_array: ["WF0_Frame0047.png","WF0_Frame0048.png","WF0_Frame0049.png","WF0_Frame0050.png","WF0_Frame0051.png","WF0_Frame0052.png","WF0_Frame0053.png","WF0_Frame0054.png","WF0_Frame0055.png","WF0_Frame0056.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_image_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 200,
              y: 185,
              src: 'wfs_points_113d9760_a00c_46d1_864c_9403f38f898e.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 281,
              y: 366,
              font_array: ["WF0_Frame0047.png","WF0_Frame0048.png","WF0_Frame0049.png","WF0_Frame0050.png","WF0_Frame0051.png","WF0_Frame0052.png","WF0_Frame0053.png","WF0_Frame0054.png","WF0_Frame0055.png","WF0_Frame0056.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'gp.png',
              unit_tc: 'gp.png',
              unit_en: 'gp.png',
              negative_image: 'gt.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 225,
              y: 356,
              image_array: ["weather_icon_01.png","weather_icon_02.png","weather_icon_03.png","weather_icon_04.png","weather_icon_05.png","weather_icon_06.png","weather_icon_07.png","weather_icon_08.png","weather_icon_09.png","weather_icon_10.png","weather_icon_11.png","weather_icon_12.png","weather_icon_13.png","weather_icon_14.png","weather_icon_15.png","weather_icon_16.png","weather_icon_17.png","weather_icon_18.png","weather_icon_19.png","weather_icon_20.png","weather_icon_21.png","weather_icon_22.png","weather_icon_23.png","weather_icon_24.png","weather_icon_25.png","weather_icon_26.png","weather_icon_27.png","weather_icon_28.png","weather_icon_29.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_month_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 232,
              month_startY: 117,
              month_sc_array: ["d0053.png","d0054.png","d0055.png","d0056.png","d0057.png","d0058.png","d0059.png","d0060.png","d0061.png","d0062.png","d0063.png","d0064.png"],
              month_tc_array: ["d0053.png","d0054.png","d0055.png","d0056.png","d0057.png","d0058.png","d0059.png","d0060.png","d0061.png","d0062.png","d0063.png","d0064.png"],
              month_en_array: ["d0053.png","d0054.png","d0055.png","d0056.png","d0057.png","d0058.png","d0059.png","d0060.png","d0061.png","d0062.png","d0063.png","d0064.png"],
              month_is_character: true ,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 166,
              day_startY: 92,
              day_sc_array: ["p0.png","p1.png","p2.png","p3.png","p4.png","p5.png","p6.png","p7.png","p8.png","p9.png"],
              day_tc_array: ["p0.png","p1.png","p2.png","p3.png","p4.png","p5.png","p6.png","p7.png","p8.png","p9.png"],
              day_en_array: ["p0.png","p1.png","p2.png","p3.png","p4.png","p5.png","p6.png","p7.png","p8.png","p9.png"],
              day_zero: 0,
              day_space: 0,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: -29,
              y: 209,
              image_array: ["b2.png","b3.png","b4.png","b5.png","b6.png","b7.png","b8.png","b9.png","b99.png","b999.png"],
              image_length: 10,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 343,
              y: 298,
              font_array: ["WF0_Frame0047.png","WF0_Frame0048.png","WF0_Frame0049.png","WF0_Frame0050.png","WF0_Frame0051.png","WF0_Frame0052.png","WF0_Frame0053.png","WF0_Frame0054.png","WF0_Frame0055.png","WF0_Frame0056.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time_AmPm = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              am_x: 26,
              am_y: -137,
              am_sc_path: 'wfs_am_9f6ace29_ffd9_42b0_9456_0089028c4694.png',
              am_en_path: 'wfs_am_9f6ace29_ffd9_42b0_9456_0089028c4694.png',
              pm_x: 26,
              pm_y: -158,
              pm_sc_path: 'wfs_pm_f06d9694_516b_478c_b114_e139e24dd530.png',
              pm_en_path: 'wfs_pm_f06d9694_516b_478c_b114_e139e24dd530.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 64,
              hour_startY: 167,
              hour_array: ["time_0.png","time_1.png","time_2.png","time_3.png","time_4.png","time_5.png","time_6.png","time_7.png","time_8.png","time_9.png"],
              hour_zero: 1,
              hour_space: 0,
              hour_angle: 0,
              hour_align: hmUI.align.LEFT,

              minute_startX: 218,
              minute_startY: 167,
              minute_array: ["time_0.png","time_1.png","time_2.png","time_3.png","time_4.png","time_5.png","time_6.png","time_7.png","time_8.png","time_9.png"],
              minute_zero: 1,
              minute_space: 0,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              second_startX: 354,
              second_startY: 201,
              second_array: ["p0.png","p1.png","p2.png","p3.png","p4.png","p5.png","p6.png","p7.png","p8.png","p9.png"],
              second_zero: 1,
              second_space: 0,
              second_angle: 0,
              second_follow: 0,
              second_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_second = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              second_path: 'days.png',
              second_centerX: 233,
              second_centerY: 233,
              second_posX: 49,
              second_posY: 215,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            console.log('Watch_Face.ScreenAOD');
            idle_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 466,
              h: 466,
              src: '466_3.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 366,
              y: 160,
              src: '0075.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 233,
              y: 92,
              week_en: ["m0043.png","m0044.png","m0045.png","m0046.png","m0047.png","m0048.png","m0049.png"],
              week_tc: ["m0043.png","m0044.png","m0045.png","m0046.png","m0047.png","m0048.png","m0049.png"],
              week_sc: ["m0043.png","m0044.png","m0045.png","m0046.png","m0047.png","m0048.png","m0049.png"],
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 323,
              y: 111,
              font_array: ["WF0_Frame0047.png","WF0_Frame0048.png","WF0_Frame0049.png","WF0_Frame0050.png","WF0_Frame0051.png","WF0_Frame0052.png","WF0_Frame0053.png","WF0_Frame0054.png","WF0_Frame0055.png","WF0_Frame0056.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_distance_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 125,
              y: 343,
              font_array: ["WF0_Frame0047.png","WF0_Frame0048.png","WF0_Frame0049.png","WF0_Frame0050.png","WF0_Frame0051.png","WF0_Frame0052.png","WF0_Frame0053.png","WF0_Frame0054.png","WF0_Frame0055.png","WF0_Frame0056.png"],
              padding: false,
              h_space: 0,
              unit_sc: '0042.png',
              unit_tc: '0042.png',
              unit_en: '0042.png',
              dot_image: '0039.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.DISTANCE,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_calorie_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 143,
              y: 380,
              font_array: ["WF0_Frame0047.png","WF0_Frame0048.png","WF0_Frame0049.png","WF0_Frame0050.png","WF0_Frame0051.png","WF0_Frame0052.png","WF0_Frame0053.png","WF0_Frame0054.png","WF0_Frame0055.png","WF0_Frame0056.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 114,
              y: 302,
              font_array: ["WF0_Frame0047.png","WF0_Frame0048.png","WF0_Frame0049.png","WF0_Frame0050.png","WF0_Frame0051.png","WF0_Frame0052.png","WF0_Frame0053.png","WF0_Frame0054.png","WF0_Frame0055.png","WF0_Frame0056.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_image_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 200,
              y: 185,
              src: 'wfs_points_113d9760_a00c_46d1_864c_9403f38f898e.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 281,
              y: 366,
              font_array: ["WF0_Frame0047.png","WF0_Frame0048.png","WF0_Frame0049.png","WF0_Frame0050.png","WF0_Frame0051.png","WF0_Frame0052.png","WF0_Frame0053.png","WF0_Frame0054.png","WF0_Frame0055.png","WF0_Frame0056.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'gp.png',
              unit_tc: 'gp.png',
              unit_en: 'gp.png',
              negative_image: 'gt.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 225,
              y: 356,
              image_array: ["weather_icon_01.png","weather_icon_02.png","weather_icon_03.png","weather_icon_04.png","weather_icon_05.png","weather_icon_06.png","weather_icon_07.png","weather_icon_08.png","weather_icon_09.png","weather_icon_10.png","weather_icon_11.png","weather_icon_12.png","weather_icon_13.png","weather_icon_14.png","weather_icon_15.png","weather_icon_16.png","weather_icon_17.png","weather_icon_18.png","weather_icon_19.png","weather_icon_20.png","weather_icon_21.png","weather_icon_22.png","weather_icon_23.png","weather_icon_24.png","weather_icon_25.png","weather_icon_26.png","weather_icon_27.png","weather_icon_28.png","weather_icon_29.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_month_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 232,
              month_startY: 117,
              month_sc_array: ["d0053.png","d0054.png","d0055.png","d0056.png","d0057.png","d0058.png","d0059.png","d0060.png","d0061.png","d0062.png","d0063.png","d0064.png"],
              month_tc_array: ["d0053.png","d0054.png","d0055.png","d0056.png","d0057.png","d0058.png","d0059.png","d0060.png","d0061.png","d0062.png","d0063.png","d0064.png"],
              month_en_array: ["d0053.png","d0054.png","d0055.png","d0056.png","d0057.png","d0058.png","d0059.png","d0060.png","d0061.png","d0062.png","d0063.png","d0064.png"],
              month_is_character: true ,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 166,
              day_startY: 92,
              day_sc_array: ["p0.png","p1.png","p2.png","p3.png","p4.png","p5.png","p6.png","p7.png","p8.png","p9.png"],
              day_tc_array: ["p0.png","p1.png","p2.png","p3.png","p4.png","p5.png","p6.png","p7.png","p8.png","p9.png"],
              day_en_array: ["p0.png","p1.png","p2.png","p3.png","p4.png","p5.png","p6.png","p7.png","p8.png","p9.png"],
              day_zero: 0,
              day_space: 0,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_battery_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: -29,
              y: 209,
              image_array: ["b2.png","b3.png","b4.png","b5.png","b6.png","b7.png","b8.png","b9.png","b99.png","b999.png"],
              image_length: 10,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 343,
              y: 298,
              font_array: ["WF0_Frame0047.png","WF0_Frame0048.png","WF0_Frame0049.png","WF0_Frame0050.png","WF0_Frame0051.png","WF0_Frame0052.png","WF0_Frame0053.png","WF0_Frame0054.png","WF0_Frame0055.png","WF0_Frame0056.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time_AmPm = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              am_x: 26,
              am_y: -137,
              am_sc_path: 'wfs_am_9f6ace29_ffd9_42b0_9456_0089028c4694.png',
              am_en_path: 'wfs_am_9f6ace29_ffd9_42b0_9456_0089028c4694.png',
              pm_x: 26,
              pm_y: -158,
              pm_sc_path: 'wfs_pm_f06d9694_516b_478c_b114_e139e24dd530.png',
              pm_en_path: 'wfs_pm_f06d9694_516b_478c_b114_e139e24dd530.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 64,
              hour_startY: 167,
              hour_array: ["time_0.png","time_1.png","time_2.png","time_3.png","time_4.png","time_5.png","time_6.png","time_7.png","time_8.png","time_9.png"],
              hour_zero: 1,
              hour_space: 0,
              hour_angle: 0,
              hour_align: hmUI.align.LEFT,

              minute_startX: 218,
              minute_startY: 167,
              minute_array: ["time_0.png","time_1.png","time_2.png","time_3.png","time_4.png","time_5.png","time_6.png","time_7.png","time_8.png","time_9.png"],
              minute_zero: 1,
              minute_space: 0,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              second_startX: 354,
              second_startY: 201,
              second_array: ["p0.png","p1.png","p2.png","p3.png","p4.png","p5.png","p6.png","p7.png","p8.png","p9.png"],
              second_zero: 1,
              second_space: 0,
              second_angle: 0,
              second_follow: 0,
              second_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_analog_clock_time_pointer_second = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              second_path: 'days.png',
              second_centerX: 233,
              second_centerY: 233,
              second_posX: 49,
              second_posY: 215,
              show_level: hmUI.show_level.ONLY_AOD,
            });


                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}