/* Relief-style instrument panel - GTR 4 */
try {
(() => {
    const __$$app$$__ = __$$hmAppManager$$__.currentApp;
    const __$$module$$__ = __$$app$$__.current;
    const logger = Logger.getLogger('relief_gtr4');
    const D = (p) => { const a = []; for (let i = 0; i < 10; i++) a.push(p + '_' + i + '.png'); return a; };
    const NORMAL = hmUI.show_level.ONLY_NORMAL;
    const AOD = hmUI.show_level.ONLY_AOD;
    const open = (url) => () => { try { hmApp.startApp({ url: url, native: true }); } catch (e) { logger.log('startApp ' + e); } };
    const num = (cx, y, w, h, pre, type, extra) => hmUI.createWidget(hmUI.widget.TEXT_IMG, Object.assign({
        x: cx - Math.floor(w / 2), y: y, w: w, h: h, font_array: D(pre), h_space: 2, align_h: hmUI.align.CENTER_H,
        type: hmUI.data_type[type], invalid_image: pre + '_dash.png', show_level: NORMAL }, extra || {}));

    __$$module$$__.module = DeviceRuntimeCore.WatchFace({
        init_view() {
            hmUI.createWidget(hmUI.widget.IMG, { x: 0, y: 0, w: 466, h: 466, src: 'bg_1.png', show_level: NORMAL });
            hmUI.createWidget(hmUI.widget.IMG, { x: 0, y: 0, w: 466, h: 466, src: 'bg.png', show_level: AOD });

            // time: white hour, orange minute, small seconds
            hmUI.createWidget(hmUI.widget.IMG_TIME, {
                hour_zero: 1, hour_startX: 150, hour_startY: 205, hour_array: D('hw'), hour_space: 0,
                minute_zero: 1, minute_startX: 254, minute_startY: 205, minute_array: D('mo'), minute_space: 0,
                second_zero: 1, second_startX: 356, second_startY: 268, second_array: D('sg'), second_space: 0,
                show_level: NORMAL });

            // altitude
            num(232, 81, 110, 26, 'vl', 'ALTIMETER');
            // weather
            hmUI.createWidget(hmUI.widget.IMG_LEVEL, { x: 95, y: 81, image_array: ['wx_partly.png','wx_rain.png','wx_snow.png','wx_sun.png','wx_cloud.png','wx_rain.png','wx_snow.png','wx_rain.png','wx_snow.png','wx_snow.png','wx_rain.png','wx_dust.png','wx_sleet.png','wx_fog.png','wx_fog.png','wx_thunder.png','wx_snow.png','wx_dust.png','wx_rain.png','wx_sleet.png','wx_thunder.png','wx_rain.png','wx_dust.png','wx_dust.png','wx_rain.png','wx_cloud.png','wx_mooncloud.png','wx_rain.png','wx_moon.png'], image_length: 29,
                type: hmUI.data_type.WEATHER, show_level: NORMAL });
            num(107, 114, 80, 26, 'vl', 'WEATHER_CURRENT', { negative_image: 'vl_minus.png' });
            // sunrise
            num(358, 114, 90, 26, 'vl', 'SUN_RISE', { dot_image: 'colon.png', h_space: 1 });

            // steps + heart rate
            num(103, 210, 80, 21, 'vm', 'STEP');
            hmUI.createWidget(hmUI.widget.IMG_LEVEL, { x: 70, y: 235, image_array: ['sb_0.png','sb_1.png','sb_2.png','sb_3.png','sb_4.png','sb_5.png','sb_6.png','sb_7.png','sb_8.png','sb_9.png','sb_10.png'], image_length: 11,
                type: hmUI.data_type.STEP, show_level: NORMAL });
            num(100, 261, 80, 21, 'vm', 'HEART');

            // date
            hmUI.createWidget(hmUI.widget.IMG_WEEK, { x: 384, y: 215, week_en: ['wd_0.png','wd_1.png','wd_2.png','wd_3.png','wd_4.png','wd_5.png','wd_6.png'], week_tc: ['wd_0.png','wd_1.png','wd_2.png','wd_3.png','wd_4.png','wd_5.png','wd_6.png'], week_sc: ['wd_0.png','wd_1.png','wd_2.png','wd_3.png','wd_4.png','wd_5.png','wd_6.png'], show_level: NORMAL });
            hmUI.createWidget(hmUI.widget.IMG_DATE, {
                month_startX: 384, month_startY: 278, month_en_array: ['mn_0.png','mn_1.png','mn_2.png','mn_3.png','mn_4.png','mn_5.png','mn_6.png','mn_7.png','mn_8.png','mn_9.png','mn_10.png','mn_11.png'], month_sc_array: ['mn_0.png','mn_1.png','mn_2.png','mn_3.png','mn_4.png','mn_5.png','mn_6.png','mn_7.png','mn_8.png','mn_9.png','mn_10.png','mn_11.png'], month_tc_array: ['mn_0.png','mn_1.png','mn_2.png','mn_3.png','mn_4.png','mn_5.png','mn_6.png','mn_7.png','mn_8.png','mn_9.png','mn_10.png','mn_11.png'],
                day_startX: 387, day_startY: 241, day_zero: 1, day_space: 0,
                day_en_array: D('dy'), day_sc_array: D('dy'), day_tc_array: D('dy'), show_level: NORMAL });

            // metric panels
            num(98, 363, 84, 21, 'vm', 'PAI_DAILY');
            num(185, 363, 66, 21, 'vm', 'SPO2');
            num(277, 363, 74, 21, 'vm', 'STRESS');
            num(370, 363, 84, 21, 'vm', 'STAND');

            // battery pill
            num(250, 413, 60, 17, 'vs', 'BATTERY', { unit_sc: 'vs_pct.png', unit_tc: 'vs_pct.png', unit_en: 'vs_pct.png', h_space: 1 });
            hmUI.createWidget(hmUI.widget.IMG_LEVEL, { x: 208, y: 435, image_array: ['bb_0.png','bb_1.png','bb_2.png','bb_3.png','bb_4.png','bb_5.png','bb_6.png','bb_7.png','bb_8.png','bb_9.png','bb_10.png'], image_length: 11,
                type: hmUI.data_type.BATTERY, show_level: NORMAL });

            // always-on
            hmUI.createWidget(hmUI.widget.IMG_TIME, {
                hour_zero: 1, hour_startX: 135, hour_startY: 202, hour_array: D('ad'), hour_space: 0,
                minute_zero: 1, minute_startX: 251, minute_startY: 202, minute_array: D('ad'), minute_space: 0,
                show_level: AOD });
            hmUI.createWidget(hmUI.widget.IMG, { x: 223, y: 202, src: 'ad_colon.png', show_level: AOD });

            // tap areas
            const tap = (x, y, w, h, url) => hmUI.createWidget(hmUI.widget.BUTTON, {
                x: x, y: y, w: w, h: h, text: '', normal_src: 'blank.png', press_src: 'blank.png',
                click_func: open(url), show_level: NORMAL });
            tap(40, 200, 120, 40, 'activityAppScreen');        // steps
            tap(40, 244, 120, 46, 'heart_app_Screen');         // heart rate
            tap(72, 68, 100, 100, 'WeatherScreen');            // weather
            tap(300, 68, 100, 100, 'WeatherScreen');           // sunrise
            tap(174, 408, 124, 34, 'Settings_batteryManagerScreen'); // battery
        },
        onInit() { logger.log('init'); },
        build() { this.init_view(); },
        onDestroy() { logger.log('destroy'); }
    });
})();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
}
