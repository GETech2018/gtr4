﻿
    /*
    ** Watch_Face_Editor tool
    ** watchface js version v1.0.1
    ** Copyright © CashaCX75. All Rights Reserved
    */

    try {

      (() => {

        var __$$app$$__ = __$$hmAppManager$$__.currentApp;
        var __$$module$$__ = __$$app$$__.current;
        //drink is a name,can modify
        var h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__), 'drink');

        'use strict';

        //dynamic modify start

        
        let editBg = ''
        let normal_battery_image_progress_img_level = ''
        let normal_moon_image_progress_img_level = ''
        let editableTimePointers = ''


        //dynamic modify end

        //not required
        const logger = DeviceRuntimeCore.HmLogger.getLogger("yeguang");

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({

          init_view() {

            //dynamic modify start
                    
            
            editBg = hmUI.createWidget(hmUI.widget.WATCHFACE_EDIT_BG, {
              edit_id: 1002,
              x: 0,
              y: 0,
              // w: 466,
              // h: 466,
              // AOD_show: False,
              bg_config: [
                { id: 1, preview: 'bg_edit_1_preview.png', path: 'WF_1.png' },
                { id: 2, preview: 'bg_edit_2_preview1.png', path: 'WF_2.png' },
                { id: 3, preview: 'bg_edit_3_preview.png', path: 'WF_3.png' },
                { id: 4, preview: 'bg_edit_4_preview.png', path: 'WF_4.png' },
              ],
              count: 4,
              default_id: 1,
              fg: '.png',
              tips_bg: 'shortcut_pointer.png',
              tips_x: 290,
              tips_y: 206,
              show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_EDIT,
            });

            normal_battery_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 77,
              y: 221,
              image_array: ["bat.b_01.png","bat.b_02.png","bat.b_03.png","bat.b_04.png","bat.b_05.png","bat.b_06.png","bat.b_07.png","bat.b_08.png","bat.b_09.png","bat.b_10.png"],
              image_length: 10,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_moon_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 344,
              y: 207,
              image_array: ["m01.png","m02.png","m03.png","m04.png","m05.png","m06.png","m07.png","m08.png","m09.png","m10.png","m11.png","m12.png","m13.png","m14.png","m15.png","m16.png","m17.png","m18.png","m19.png","m20.png","m21.png","m22.png","m23.png","m24.png","m25.png","m26.png","m27.png","m28.png","m29.png","m30.png"],
              image_length: 30,
              type: hmUI.data_type.MOON,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });



            const pointerEdit = hmUI.createWidget(hmUI.widget.WATCHFACE_EDIT_POINTER, {
              edit_id: 1003,
              x: 0,
              y: 0,
              config: [
                {
                  id: 1,
                  second: {
                    centerX: 233,
                    centerY: 233,
                    posX: 27,
                    posY: 231,
                    path: 'second8.png',
                  },
                  hour: {
                    centerX: 233,
                    centerY: 233,
                    posX: 233,
                    posY: 233,
                    path: 'hour15.png',
                  },
                  minute: {
                    centerX: 233,
                    centerY: 233,
                    posX: 233,
                    posY: 233,
                    path: 'minute15.png',
                  },
                  preview: 'pointer_edit_1_preview.png',
                },
                {
                  id: 2,
                  second: {
                    centerX: 233,
                    centerY: 233,
                    posX: 27,
                    posY: 231,
                    path: 'second8.png',
                  },
                  hour: {
                    centerX: 233,
                    centerY: 233,
                    posX: 233,
                    posY: 233,
                    path: 'hour9.png',
                  },
                  minute: {
                    centerX: 233,
                    centerY: 233,
                    posX: 233,
                    posY: 233,
                    path: 'minute9.png',
                  },
                  preview: 'pointer_edit_2_preview.png',
                },
                {
                  id: 3,
                  second: {
                    centerX: 233,
                    centerY: 233,
                    posX: 18,
                    posY: 232,
                    path: 'second25.png',
                  },
                  hour: {
                    centerX: 233,
                    centerY: 233,
                    posX: 233,
                    posY: 233,
                    path: 'hour20.png',
                  },
                  minute: {
                    centerX: 233,
                    centerY: 233,
                    posX: 233,
                    posY: 233,
                    path: 'minute20.png',
                  },
                  preview: 'pointer_edit_3_preview.png',
                },
                {
                  id: 4,
                  second: {
                    centerX: 233,
                    centerY: 233,
                    posX: 22,
                    posY: 214,
                    path: 'second4.png',
                  },
                  hour: {
                    centerX: 233,
                    centerY: 233,
                    posX: 37,
                    posY: 233,
                    path: 'hour11.png',
                  },
                  minute: {
                    centerX: 233,
                    centerY: 233,
                    posX: 37,
                    posY: 233,
                    path: 'minute11.png',
                  },
                  preview: 'pointer_edit_4_preview.png',
                },
                {
                  id: 5,
                  second: {
                    centerX: 233,
                    centerY: 233,
                    posX: 13,
                    posY: 219,
                    path: 'second16.png',
                  },
                  hour: {
                    centerX: 233,
                    centerY: 233,
                    posX: 233,
                    posY: 233,
                    path: 'S_h_b.png',
                  },
                  minute: {
                    centerX: 233,
                    centerY: 233,
                    posX: 233,
                    posY: 233,
                    path: 'S_m_b.png',
                  },
                  preview: 'pointer_edit_5_preview.png',
                },
              ],
              count: 5,
              default_id: 1,
              fg: '.png',
              tips_x: 124,
              tips_y: 212,
              tips_bg: 'shortcut_pointer.png',
            });
            const screenTypeForETP = hmSetting.getScreenType();
            const aodModel = screenTypeForETP == hmSetting.screen_type.AOD;
            const pointerProp = pointerEdit.getProperty(hmUI.prop.CURRENT_CONFIG, !aodModel);
            editableTimePointers = hmUI.createWidget(hmUI.widget.TIME_POINTER, pointerProp);


            //dynamic modify end
          },

          onInit() {
            console.log('index page.js on init invoke')

            this.init_view()

          },

          onReady() {
            console.log('index page.js on ready invoke')
          },

          onShow() {
            console.log('index page.js on show invoke')
          },

          onHide() {
            console.log('index page.js on hide invoke')
          },

          onDestory() {
            console.log('index page.js on destory invoke')
          },
        });

      })()
    } catch (e) {
      console.log(e)
    }
  