﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.0.1
    ** Copyright © CashaCX75. All Rights Reserved
    */

    try {
    (()=>{
        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_digital_clock_img_time = ''
        let idle_digital_clock_img_time = ''


        //dynamic modify end
        const e = __$$hmAppManager$$__.currentApp;
        const o = e.current
          , {px: i} = (new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(e,o)),
        e.__globals__)
          , n = Logger.getLogger("watchface6");
        o.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 466,
              h: 466,
              src: 'FondChamp.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 89,
              hour_startY: 20,
              hour_array: ["HH0.png","HH1.png","HH2.png","HH3.png","HH4.png","HH5.png","HH6.png","HH7.png","HH8.png","HH9.png"],
              hour_zero: 1,
              hour_space: -39,
              hour_align: hmUI.align.LEFT,

              minute_startX: 89,
              minute_startY: 236,
              minute_array: ["MH0.png","MH1.png","MH2.png","MH3.png","MH4.png","MH5.png","MH6.png","MH7.png","MH8.png","MH9.png"],
              minute_zero: 1,
              minute_space: -39,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });



            idle_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 89,
              hour_startY: 20,
              hour_array: ["HH0.png","HH1.png","HH2.png","HH3.png","HH4.png","HH5.png","HH6.png","HH7.png","HH8.png","HH9.png"],
              hour_zero: 1,
              hour_space: -39,
              hour_align: hmUI.align.LEFT,

              minute_startX: 89,
              minute_startY: 236,
              minute_array: ["MH0.png","MH1.png","MH2.png","MH3.png","MH4.png","MH5.png","MH6.png","MH7.png","MH8.png","MH9.png"],
              minute_zero: 1,
              minute_space: -39,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_AOD,
            });


                //dynamic modify end
            },
            onInit() {
                n.log("index page.js on init invoke")
            },
            build() {
                this.init_view(),
                n.log("index page.js on ready invoke")
            },
            onDestroy() {
                n.log("index page.js on destroy invoke")
            }
        })
    }
    )()
} catch (e) {
    console.log("Mini Program Error", e),
    e && e.stack && e.stack.split(/\n/).forEach((e=>console.log("error stack", e)))
}
