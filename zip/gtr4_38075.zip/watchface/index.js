﻿    /*
     ** Watch_Face_Editor tool
     ** watchface js version v2.1.1
     ** Copyright © SashaCX75. All Rights Reserved
     */
    // import { Barometer } from '@zos/sensor'

    try {
     (() => {

      const {
       beforeModuleCreate = () => {}, afterModuleCreate = () => {}
      } = DeviceRuntimeCore.LifeCycle
      beforeModuleCreate()

      const {
       beforePageCreate = () => {}, afterPageCreate = () => {}
      } = DeviceRuntimeCore.LifeCycle
      beforePageCreate()
      const __$$G$$__ = __$$hmAppManager$$__.currentApp.current.__globals__.__$$G$$__
       //end of ignored block

       ! function (context) {
        with(context) {

         const hmUI = __$$R$$__('@zos/ui');
         const hmSensor = __$$R$$__('@zos/sensor');
         const hmScene = __$$R$$__('@zos/app');
         const hmRouter = __$$R$$__('@zos/router');
         const hmDevice = __$$R$$__('@zos/device');
         const hmBle = __$$R$$__('@zos/ble');
         const hmStorage = __$$R$$__('@zos/storage');
         const hmInteraction = __$$R$$__('@zos/interaction');
         const gettext = console.log;
         const barometer = new hmSensor.Barometer();
         const altitude = barometer.getAltitude();
         let airPressure = barometer.getAirPressure() * 0.750064;
         const {
          width: DEVICE_WIDTH,
          height: DEVICE_HEIGHT
         } = hmDevice.getDeviceInfo();


         const timeSensor = new hmSensor.Time();
         const step = new hmSensor.Step();
         const heart = new hmSensor.HeartRate();
         const calorie = new hmSensor.Calorie();
         const battery = new hmSensor.Battery();
         const distance = new hmSensor.Distance();
         //let weatherData = weather.getForecast();

         const weather = new hmSensor.Weather();


         let groupVremya = ''

         let normal_background_bg_img = ''
         let normal_image_img = ''
         let normal_distance_icon_img = ''
         let normal_distance_text_text_img = ''
         let normal_distance_text_separator_img = ''
         let normal_step_circle_scale = ''
         let normal_step_current_text_img = ''
         let normal_step_icon_img = ''
         let normal_calorie_circle_scale = ''
         let normal_calorie_current_text_img = ''
         let normal_calorie_icon_img = ''
         let normal_heart_rate_circle_scale = ''
         let normal_heart_rate_text_text_img = ''
         let normal_heart_rate_icon_img = ''
         let normal_battery_circle_scale = ''
         let normal_battery_text_text_img = ''
         let normal_battery_text_separator_img = ''
         let normal_battery_icon_img = ''
         let normal_digital_clock_img_time = ''
         let normal_digital_clock_hour_separator_img = ''
         let normal_digital_clock_minute_separator_img = ''
         let normal_date_img_date_day = ''
         let normal_date_img_date_week_img = ''
         // let normal_temperature_icon_img = ''
         let normal_temperature_high_text_img = ''
         let normal_temperature_low_text_img = ''
         let normal_temperature_current_text_img = ''
         let normal_weather_image_progress_img_level = ''
         let normal_stress_icon_img = ''
         let normal_sun_icon_img = ''
         let normal_sun_pointer_progress_img_pointer = ''
         let normal_sun_low_text_img = ''
         let normal_sun_high_text_img = ''
         let normal_sun_image_progress_img_level = ''
         let normal_altimeter_icon_img = ''
         let normal_altimeter_pointer_progress_img_pointer = ''
         let normal_altitude_target_text_img = ''
         let normal_altimeter_text_text_img = ''
         let normal_stand_icon_img = ''
         let normal_system_lock_img = ''
         let normal_system_disconnect_img = ''
         let normal_system_clock_img = ''
         let normal_analog_clock_time_pointer_minute = ''
         let normal_analog_clock_time_pointer_hour = ''
         let idle_background_bg_img = ''
         let idle_image_img = ''
         let idle_distance_icon_img = ''
         let idle_distance_text_text_img = ''
         let idle_distance_text_separator_img = ''
         let idle_step_circle_scale = ''
         let idle_battery_circle_scale = ''
         let idle_battery_text_text_img = ''
         let idle_battery_icon_img = ''
         let idle_digital_clock_img_time = ''
         let idle_digital_clock_hour_separator_img = ''
         let idle_date_img_date_day = ''
         let idle_stress_icon_img = ''
         let idle_stand_icon_img = ''
         let idle_system_lock_img = ''
         let idle_system_disconnect_img = ''
         let idle_system_clock_img = ''
         let normal_time_second_text_font = ''
         let normal_time_hour_min_text_font = ''
         let idle_timerTimeUpdate = undefined;
         let normal_timerTimeUpdate = undefined;

         let normal_SUN_SET_img = ''
         let normal_SUN_RISE_img = ''
         let normal_SUN_SET_text_font = ''
         let normal_SUN_RISE_text_font = ''


         let btn_dig = ''
         let dig = 0

         function cl_dig() {
          dig = (dig + 1) % 4
          hmStorage.localStorage.setItem('rz134_dig', dig);
			 
			if (theme == 1) normal_stress_icon_img.setProperty(hmUI.prop.SRC, dig == 0 || dig == 2 ? '24_0.png':'24_3.png');	
			else if (theme == 2) normal_stress_icon_img.setProperty(hmUI.prop.SRC, dig == 0 || dig == 2 ? '24_2.png':'24_1.png');	
			else if (theme == 3) normal_stress_icon_img.setProperty(hmUI.prop.SRC, '0_Empty.png');	
			 
			 
normal_digital_clock_minute_separator_img.setProperty(hmUI.prop.VISIBLE, dig == 0 || dig == 1);
normal_time_hour_min_text_font.setProperty(hmUI.prop.VISIBLE, dig == 0 || dig == 1);	
normal_time_second_text_font.setProperty(hmUI.prop.VISIBLE, dig == 0 || dig == 1);

normal_date_img_date_week_img.setProperty(hmUI.prop.VISIBLE, dig == 0 || dig == 2);
normal_battery_text_separator_img.setProperty(hmUI.prop.VISIBLE, dig == 0 || dig == 2);
normal_date_img_date_day.setProperty(hmUI.prop.VISIBLE, dig == 0 || dig == 2);

         }

         let btn_theme = ''
         let theme = 0
         let txt_theme = ["Атоматически", "12-3-6-9", "24-15-18-21", "Пусто"];
			
         function cl_theme() {
          theme = (theme + 1) % 4
          hmStorage.localStorage.setItem('rz134_theme', theme);
		hmUI.showToast({text: txt_theme[theme]});	
			 
			if (theme == 1) normal_stress_icon_img.setProperty(hmUI.prop.SRC, dig == 0 || dig == 2 ? '24_0.png':'24_3.png');	
			else if (theme == 2) normal_stress_icon_img.setProperty(hmUI.prop.SRC, dig == 0 || dig == 2 ? '24_2.png':'24_1.png');	
			else if (theme == 3) normal_stress_icon_img.setProperty(hmUI.prop.SRC, '0_Empty.png');	
			

         }


         let zona_left_btn = 0
         let zona_left = 0

         function cl_zona_left() {
          zona_left = (zona_left + 1) % 4

          hmStorage.localStorage.setItem('rz134_zona_left', zona_left);
			 

          normal_step_circle_scale.setProperty(hmUI.prop.VISIBLE, zona_left == 0 || zona_left == 3);
          normal_step_current_text_img.setProperty(hmUI.prop.VISIBLE, zona_left == 0);
          normal_step_icon_img.setProperty(hmUI.prop.VISIBLE, zona_left == 0);

          normal_calorie_circle_scale.setProperty(hmUI.prop.VISIBLE, zona_left == 1);
          normal_calorie_current_text_img.setProperty(hmUI.prop.VISIBLE, zona_left == 1);
          normal_calorie_icon_img.setProperty(hmUI.prop.VISIBLE, zona_left == 1);

          normal_heart_rate_circle_scale.setProperty(hmUI.prop.VISIBLE, zona_left == 2);
          normal_heart_rate_text_text_img.setProperty(hmUI.prop.VISIBLE, zona_left == 2);
          normal_heart_rate_icon_img.setProperty(hmUI.prop.VISIBLE, zona_left == 2);

          normal_distance_text_text_img.setProperty(hmUI.prop.VISIBLE, zona_left == 3);
          normal_distance_text_separator_img.setProperty(hmUI.prop.VISIBLE, zona_left == 3);


         }

         let zona_right_btn = 0
         let zona_right = 0

         function cl_zona_right() {
          zona_right = (zona_right + 1) % 4

          hmStorage.localStorage.setItem('rz134_zona_right', zona_right);

          normal_battery_circle_scale.setProperty(hmUI.prop.VISIBLE, zona_right == 0);
          normal_battery_text_text_img.setProperty(hmUI.prop.VISIBLE, zona_right == 0);
          normal_battery_icon_img.setProperty(hmUI.prop.VISIBLE, zona_right == 0);

          normal_temperature_high_text_img.setProperty(hmUI.prop.VISIBLE, zona_right == 1);
          normal_temperature_low_text_img.setProperty(hmUI.prop.VISIBLE, zona_right == 1);
          normal_temperature_current_text_img.setProperty(hmUI.prop.VISIBLE, zona_right == 1);
          normal_weather_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, zona_right == 1);
          normal_WEATHER_pointer_progress_img_pointer.setProperty(hmUI.prop.VISIBLE, zona_right == 1);

          normal_sun_pointer_progress_img_pointer.setProperty(hmUI.prop.VISIBLE, zona_right == 2);

          normal_SUN_RISE_text_font.setProperty(hmUI.prop.VISIBLE, isDayIcons == false && zona_right == 2);
          normal_SUN_SET_img.setProperty(hmUI.prop.VISIBLE, isDayIcons == true && zona_right == 2); //true
          normal_SUN_SET_text_font.setProperty(hmUI.prop.VISIBLE, isDayIcons == true && zona_right == 2);
          normal_SUN_RISE_img.setProperty(hmUI.prop.VISIBLE, isDayIcons == false && zona_right == 2);


          normal_altimeter_icon_img.setProperty(hmUI.prop.VISIBLE, zona_right == 3);
          normal_altimeter_pointer_progress_img_pointer.setProperty(hmUI.prop.VISIBLE, zona_right == 3);
          normal_altitude_target_text_img.setProperty(hmUI.prop.VISIBLE, zona_right == 3);
          normal_altimeter_text_text_img.setProperty(hmUI.prop.VISIBLE, zona_right == 3);


         }


         let str_btn = 0
         let str = 0

         function call_change_str(handsnumberstr) {
          switch (handsnumberstr) {
           case 1:
            Hourstring = '0_Empty.png';
            Minutestring = '0_Empty.png';
            center = '0_Empty.png';
            break;

           default:
            Hourstring = 'str_H.png';
            Minutestring = 'str_M.png';
            center = 'stsr_center.png';
            break;
          }

          normal_analog_clock_time_pointer_minute.setProperty(hmUI.prop.MORE, {
           minute_path: Minutestring,
           minute_centerX: 233,
           minute_centerY: 233,
           minute_posX: 26,
           minute_posY: 215,
           show_level: hmUI.show_level.ONLY_NORMAL,
          });

          normal_analog_clock_time_pointer_hour.setProperty(hmUI.prop.MORE, {
           hour_path: Hourstring,
           hour_centerX: 233,
           hour_centerY: 233,
           hour_posX: 26,
           hour_posY: 145,
           hour_cover_path: center,
           hour_cover_x: 221,
           hour_cover_y: 221,
           show_level: hmUI.show_level.ONLY_NORMAL,
          });

         }


         //
         // let week = timeSensor.week;
         let week = timeSensor.getDay();
         // let month = timeSensor.month;
         let month = timeSensor.getDate();
         let day_num = [0, 31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31];
         // let year = timeSensor.year;
         let year = timeSensor.getFullYear();

         if (year % 4 == 0 && (year % 100 != 0 || year % 400 == 0)) { // Високосный год
          day_num[2] = 29
         } else {
          day_num[2] = 28
         }


         let blok_btn = 0

         function click_blok() {
          blok_btn = 1;
          block_on_IMG.setProperty(hmUI.prop.SRC, blok_btn ? 'block_on.png' : 'block_off.png');

          groupVremya.setProperty(hmUI.prop.VISIBLE, false);
          btn_raz_block.setProperty(hmUI.prop.VISIBLE, true);


          hmStorage.localStorage.setItem('rz134_blok_btn', blok_btn);
         }

         function click_zazblok() {
          blok_btn = 0
          block_on_IMG.setProperty(hmUI.prop.SRC, blok_btn ? 'block_on.png' : 'block_off.png');

          groupVremya.setProperty(hmUI.prop.VISIBLE, true);
          btn_raz_block.setProperty(hmUI.prop.VISIBLE, false);


          hmStorage.localStorage.setItem('rz134_blok_btn', blok_btn);
         }

         function loadSettings() {
          dig = hmStorage.localStorage.getItem('rz134_dig', 0);
          theme = hmStorage.localStorage.getItem('rz134_theme', 0);
          blok_btn = hmStorage.localStorage.getItem('rz134_blok_btn', 0);
          zona_left = hmStorage.localStorage.getItem('rz134_zona_left', 0);
          zona_right = hmStorage.localStorage.getItem('rz134_zona_right', 0);
          isDayIcons = hmStorage.localStorage.getItem('rz134_isDayIcons', true);
          //str = hmStorage.localStorage.getItem('rz134_str', 0);

         }

         function saveSettings() {
          hmStorage.localStorage.setItem('rz134_dig', 0);
          hmStorage.localStorage.setItem('rz134_theme', 0);
          hmStorage.localStorage.setItem('rz134_zona_left', 0);
          hmStorage.localStorage.setItem('rz134_blok_btn', 0);
          hmStorage.localStorage.setItem('rz134_zona_right', 0);
          hmStorage.localStorage.setItem('rz134_isDayIcons', true);
          hmStorage.localStorage.setItem('rz134_init', true);
          //hmStorage.localStorage.setItem('rz134_str', 0);  
         }


         let apps = [
          ['Нет действия', '-', `tap/i_tap_pusto.png`],
          ['Таймер', 'CountdownAppScreen', `tap/i_tap_obrat_otchet.png`],
          ['Секундомер', 'StopWatchScreen', `tap/i_tap_secundomer.png`],
          ['Мировые часы', 'WorldClockScreen', `tap/i_tap_mirivie_chasi.png`],
          ['Восход/закат', 'TideScreen', `tap/i_tap_voshod_zakat.png`],
          ['Сон', 'Sleep_HomeScreen', `tap/i_tap_son.png`],
          ['Стресс', 'StressHomeScreen', `tap/i_tap_stress.png`],
          ['SP02 (Кислород)', 'spo_HomeScreen', `tap/i_tap_kislorod.png`],
          ['Дыхание', 'RespirationsettingScreen', `tap/i_tap_dihanie.png`],
          ['Измерение одним касанием', 'oneKeyAppScreen', `tap/i_tap_1_kosanie.png`],
          ['Женский календарь', 'menstrualAppScreen', `tap/i_tap_gensk_calendar.png`],
          ['Найти телефон', 'FindPhoneScreen', `tap/i_tap_naiti_telo.png`],
          ['Музыка', 'PhoneMusicCtrlScreen', `tap/i_tap_musik.png`],
          ['Компас', 'CompassScreen', `tap/i_tap_kompas.png`],
          ['Набрать номер', 'DialCallScreen', `tap/i_tap_nabor.png`],
          ['Телефон', 'PhoneHomeScreen', `tap/i_tap_telefon.png`],
          ['Диктофон', 'VoiceMemoScreen', `tap/i_tap_dictofon.png`],
          ['Расписание', 'ScheduleListScreen', `tap/i_tap_raspisanie.png`],
          ['Список дел', 'todoListScreen', `tap/i_tap_spisok_del.png`],
          ['Календарь', 'ScheduleCalScreen', `tap/i_tap_calendar.png`],
          ['Погода', 'WeatherScreen', `tap/i_tap_pogoda.png`],
          ['Настройка', 'Settings_homeScreen', `tap/i_tap_sitting.png`],
          ['Камера', 'HidcameraScreen', `tap/i_tap_camera.png`],
          ['Пульс', 'heart_app_Screen', `tap/i_tap_puls.png`],
          ['Будильник', 'AlarmInfoScreen', `tap/i_tap_budilnik.png`],
          ['PAI', 'PAI_app_Screen', `tap/i_tap_pai.png`],
          ['Тренировка', 'SportListScreen', `tap/i_tap_trenerovka.png`],
          ['AOD', 'Settings_standbyModelScreen', `tap/i_tap_aod.png`],
          ['Экономия заряда', 'LowBatteryScreen', `tap/i_tap_LowBattery.png`],
          ['Давление/Высота', 'BaroAltimeterScreen', `tap/i_tap_barometr.png`]
         ];


         const tap_1_edit = hmUI.createWidget(hmUI.widget.WATCHFACE_EDIT_GROUP, {
          edit_id: 101,
          x: 171,
          y: 20,
          w: 124,
          h: 124,
          select_image: 'tap/edit_red_1.png',
          un_select_image: 'tap/edit_griin_1.png',
          default_type: 19,
          optional_types: [{
           type: 0,
           preview: apps[0][2],
           title_en: apps[0][0]
          }, {
           type: 1,
           preview: apps[1][2],
           title_en: apps[1][0]
          }, {
           type: 2,
           preview: apps[2][2],
           title_en: apps[2][0]
          }, {
           type: 3,
           preview: apps[3][2],
           title_en: apps[3][0]
          }, {
           type: 4,
           preview: apps[4][2],
           title_en: apps[4][0]
          }, {
           type: 5,
           preview: apps[5][2],
           title_en: apps[5][0]
          }, {
           type: 6,
           preview: apps[6][2],
           title_en: apps[6][0]
          }, {
           type: 7,
           preview: apps[7][2],
           title_en: apps[7][0]
          }, {
           type: 8,
           preview: apps[8][2],
           title_en: apps[8][0]
          }, {
           type: 9,
           preview: apps[9][2],
           title_en: apps[9][0]
          }, {
           type: 10,
           preview: apps[10][2],
           title_en: apps[10][0]
          }, {
           type: 11,
           preview: apps[11][2],
           title_en: apps[11][0]
          }, {
           type: 12,
           preview: apps[12][2],
           title_en: apps[12][0]
          }, {
           type: 13,
           preview: apps[13][2],
           title_en: apps[13][0]
          }, {
           type: 14,
           preview: apps[14][2],
           title_en: apps[14][0]
          }, {
           type: 15,
           preview: apps[15][2],
           title_en: apps[15][0]
          }, {
           type: 16,
           preview: apps[16][2],
           title_en: apps[16][0]
          }, {
           type: 17,
           preview: apps[17][2],
           title_en: apps[17][0]
          }, {
           type: 18,
           preview: apps[18][2],
           title_en: apps[18][0]
          }, {
           type: 19,
           preview: apps[19][2],
           title_en: apps[19][0]
          }, {
           type: 20,
           preview: apps[20][2],
           title_en: apps[20][0]
          }, {
           type: 21,
           preview: apps[21][2],
           title_en: apps[21][0]
          }, {
           type: 22,
           preview: apps[22][2],
           title_en: apps[22][0]
          }, {
           type: 23,
           preview: apps[23][2],
           title_en: apps[23][0]
          }, {
           type: 24,
           preview: apps[24][2],
           title_en: apps[24][0]
          }, {
           type: 25,
           preview: apps[25][2],
           title_en: apps[25][0]
          }, {
           type: 26,
           preview: apps[26][2],
           title_en: apps[26][0]
          }, {
           type: 27,
           preview: apps[27][2],
           title_en: apps[27][0]
          }, {
           type: 28,
           preview: apps[28][2],
           title_en: apps[28][0]
          }, {
           type: 29,
           preview: apps[29][2],
           title_en: apps[29][0]
          }, ],
          count: 30,
          tips_x: 135 - 171,
          tips_y: 150 - 20,
          tips_width: 195,
          tips_margin: 10,
          tips_BG: 'tap/tips_bg.png'
         })

         let tap_1_select = tap_1_edit.getProperty(hmUI.prop.CURRENT_TYPE)

         const tap_2_edit = hmUI.createWidget(hmUI.widget.WATCHFACE_EDIT_GROUP, {
          edit_id: 102,
          x: 301,
          y: 95,
          w: 124,
          h: 124,
          select_image: 'tap/edit_red_1.png',
          un_select_image: 'tap/edit_griin_1.png',
          default_type: 20,
          optional_types: [{
           type: 0,
           preview: apps[0][2],
           title_en: apps[0][0]
          }, {
           type: 1,
           preview: apps[1][2],
           title_en: apps[1][0]
          }, {
           type: 2,
           preview: apps[2][2],
           title_en: apps[2][0]
          }, {
           type: 3,
           preview: apps[3][2],
           title_en: apps[3][0]
          }, {
           type: 4,
           preview: apps[4][2],
           title_en: apps[4][0]
          }, {
           type: 5,
           preview: apps[5][2],
           title_en: apps[5][0]
          }, {
           type: 6,
           preview: apps[6][2],
           title_en: apps[6][0]
          }, {
           type: 7,
           preview: apps[7][2],
           title_en: apps[7][0]
          }, {
           type: 8,
           preview: apps[8][2],
           title_en: apps[8][0]
          }, {
           type: 9,
           preview: apps[9][2],
           title_en: apps[9][0]
          }, {
           type: 10,
           preview: apps[10][2],
           title_en: apps[10][0]
          }, {
           type: 11,
           preview: apps[11][2],
           title_en: apps[11][0]
          }, {
           type: 12,
           preview: apps[12][2],
           title_en: apps[12][0]
          }, {
           type: 13,
           preview: apps[13][2],
           title_en: apps[13][0]
          }, {
           type: 14,
           preview: apps[14][2],
           title_en: apps[14][0]
          }, {
           type: 15,
           preview: apps[15][2],
           title_en: apps[15][0]
          }, {
           type: 16,
           preview: apps[16][2],
           title_en: apps[16][0]
          }, {
           type: 17,
           preview: apps[17][2],
           title_en: apps[17][0]
          }, {
           type: 18,
           preview: apps[18][2],
           title_en: apps[18][0]
          }, {
           type: 19,
           preview: apps[19][2],
           title_en: apps[19][0]
          }, {
           type: 20,
           preview: apps[20][2],
           title_en: apps[20][0]
          }, {
           type: 21,
           preview: apps[21][2],
           title_en: apps[21][0]
          }, {
           type: 22,
           preview: apps[22][2],
           title_en: apps[22][0]
          }, {
           type: 23,
           preview: apps[23][2],
           title_en: apps[23][0]
          }, {
           type: 24,
           preview: apps[24][2],
           title_en: apps[24][0]
          }, {
           type: 25,
           preview: apps[25][2],
           title_en: apps[25][0]
          }, {
           type: 26,
           preview: apps[26][2],
           title_en: apps[26][0]
          }, {
           type: 27,
           preview: apps[27][2],
           title_en: apps[27][0]
          }, {
           type: 28,
           preview: apps[28][2],
           title_en: apps[28][0]
          }, {
           type: 29,
           preview: apps[29][2],
           title_en: apps[29][0]
          }, ],
          count: 30,
          tips_x: 266 - 301,
          tips_y: 225 - 95,
          tips_width: 195,
          tips_margin: 10,
          tips_BG: 'tap/tips_bg.png'
         })


         let tap_2_select = tap_2_edit.getProperty(hmUI.prop.CURRENT_TYPE)


         const tap_3_edit = hmUI.createWidget(hmUI.widget.WATCHFACE_EDIT_GROUP, {
          edit_id: 103,
          x: 301,
          y: 246,
          w: 124,
          h: 124,
          select_image: 'tap/edit_red_1.png',
          un_select_image: 'tap/edit_griin_1.png',
          default_type: 24,
          optional_types: [{
           type: 0,
           preview: apps[0][2],
           title_en: apps[0][0]
          }, {
           type: 1,
           preview: apps[1][2],
           title_en: apps[1][0]
          }, {
           type: 2,
           preview: apps[2][2],
           title_en: apps[2][0]
          }, {
           type: 3,
           preview: apps[3][2],
           title_en: apps[3][0]
          }, {
           type: 4,
           preview: apps[4][2],
           title_en: apps[4][0]
          }, {
           type: 5,
           preview: apps[5][2],
           title_en: apps[5][0]
          }, {
           type: 6,
           preview: apps[6][2],
           title_en: apps[6][0]
          }, {
           type: 7,
           preview: apps[7][2],
           title_en: apps[7][0]
          }, {
           type: 8,
           preview: apps[8][2],
           title_en: apps[8][0]
          }, {
           type: 9,
           preview: apps[9][2],
           title_en: apps[9][0]
          }, {
           type: 10,
           preview: apps[10][2],
           title_en: apps[10][0]
          }, {
           type: 11,
           preview: apps[11][2],
           title_en: apps[11][0]
          }, {
           type: 12,
           preview: apps[12][2],
           title_en: apps[12][0]
          }, {
           type: 13,
           preview: apps[13][2],
           title_en: apps[13][0]
          }, {
           type: 14,
           preview: apps[14][2],
           title_en: apps[14][0]
          }, {
           type: 15,
           preview: apps[15][2],
           title_en: apps[15][0]
          }, {
           type: 16,
           preview: apps[16][2],
           title_en: apps[16][0]
          }, {
           type: 17,
           preview: apps[17][2],
           title_en: apps[17][0]
          }, {
           type: 18,
           preview: apps[18][2],
           title_en: apps[18][0]
          }, {
           type: 19,
           preview: apps[19][2],
           title_en: apps[19][0]
          }, {
           type: 20,
           preview: apps[20][2],
           title_en: apps[20][0]
          }, {
           type: 21,
           preview: apps[21][2],
           title_en: apps[21][0]
          }, {
           type: 22,
           preview: apps[22][2],
           title_en: apps[22][0]
          }, {
           type: 23,
           preview: apps[23][2],
           title_en: apps[23][0]
          }, {
           type: 24,
           preview: apps[24][2],
           title_en: apps[24][0]
          }, {
           type: 25,
           preview: apps[25][2],
           title_en: apps[25][0]
          }, {
           type: 26,
           preview: apps[26][2],
           title_en: apps[26][0]
          }, {
           type: 27,
           preview: apps[27][2],
           title_en: apps[27][0]
          }, {
           type: 28,
           preview: apps[28][2],
           title_en: apps[28][0]
          }, {
           type: 29,
           preview: apps[29][2],
           title_en: apps[29][0]
          }, ],
          count: 30,
          tips_x: 266 - 301,
          tips_y: 184 - 246,
          tips_width: 195,
          tips_margin: 10,
          tips_BG: 'tap/tips_bg.png'
         })

         let tap_3_select = tap_3_edit.getProperty(hmUI.prop.CURRENT_TYPE)

         const tap_4_edit = hmUI.createWidget(hmUI.widget.WATCHFACE_EDIT_GROUP, {
          edit_id: 104,
          x: 171,
          y: 321,
          w: 124,
          h: 124,
          select_image: 'tap/edit_red_1.png',
          un_select_image: 'tap/edit_griin_1.png',
          default_type: 11,
          optional_types: [{
           type: 0,
           preview: apps[0][2],
           title_en: apps[0][0]
          }, {
           type: 1,
           preview: apps[1][2],
           title_en: apps[1][0]
          }, {
           type: 2,
           preview: apps[2][2],
           title_en: apps[2][0]
          }, {
           type: 3,
           preview: apps[3][2],
           title_en: apps[3][0]
          }, {
           type: 4,
           preview: apps[4][2],
           title_en: apps[4][0]
          }, {
           type: 5,
           preview: apps[5][2],
           title_en: apps[5][0]
          }, {
           type: 6,
           preview: apps[6][2],
           title_en: apps[6][0]
          }, {
           type: 7,
           preview: apps[7][2],
           title_en: apps[7][0]
          }, {
           type: 8,
           preview: apps[8][2],
           title_en: apps[8][0]
          }, {
           type: 9,
           preview: apps[9][2],
           title_en: apps[9][0]
          }, {
           type: 10,
           preview: apps[10][2],
           title_en: apps[10][0]
          }, {
           type: 11,
           preview: apps[11][2],
           title_en: apps[11][0]
          }, {
           type: 12,
           preview: apps[12][2],
           title_en: apps[12][0]
          }, {
           type: 13,
           preview: apps[13][2],
           title_en: apps[13][0]
          }, {
           type: 14,
           preview: apps[14][2],
           title_en: apps[14][0]
          }, {
           type: 15,
           preview: apps[15][2],
           title_en: apps[15][0]
          }, {
           type: 16,
           preview: apps[16][2],
           title_en: apps[16][0]
          }, {
           type: 17,
           preview: apps[17][2],
           title_en: apps[17][0]
          }, {
           type: 18,
           preview: apps[18][2],
           title_en: apps[18][0]
          }, {
           type: 19,
           preview: apps[19][2],
           title_en: apps[19][0]
          }, {
           type: 20,
           preview: apps[20][2],
           title_en: apps[20][0]
          }, {
           type: 21,
           preview: apps[21][2],
           title_en: apps[21][0]
          }, {
           type: 22,
           preview: apps[22][2],
           title_en: apps[22][0]
          }, {
           type: 23,
           preview: apps[23][2],
           title_en: apps[23][0]
          }, {
           type: 24,
           preview: apps[24][2],
           title_en: apps[24][0]
          }, {
           type: 25,
           preview: apps[25][2],
           title_en: apps[25][0]
          }, {
           type: 26,
           preview: apps[26][2],
           title_en: apps[26][0]
          }, {
           type: 27,
           preview: apps[27][2],
           title_en: apps[27][0]
          }, {
           type: 28,
           preview: apps[28][2],
           title_en: apps[28][0]
          }, {
           type: 29,
           preview: apps[29][2],
           title_en: apps[29][0]
          }, ],
          count: 30,
          tips_x: 135 - 171,
          tips_y: 257 - 321,
          tips_width: 195,
          tips_margin: 10,
          tips_BG: 'tap/tips_bg.png'
         })

         let tap_4_select = tap_4_edit.getProperty(hmUI.prop.CURRENT_TYPE)

         const tap_5_edit = hmUI.createWidget(hmUI.widget.WATCHFACE_EDIT_GROUP, {
          edit_id: 105,
          x: 40,
          y: 246,
          w: 124,
          h: 124,
          select_image: 'tap/edit_red_1.png',
          un_select_image: 'tap/edit_griin_1.png',
          default_type: 0,
          optional_types: [{
           type: 0,
           preview: apps[0][2],
           title_en: apps[0][0]
          }, {
           type: 1,
           preview: apps[1][2],
           title_en: apps[1][0]
          }, {
           type: 2,
           preview: apps[2][2],
           title_en: apps[2][0]
          }, {
           type: 3,
           preview: apps[3][2],
           title_en: apps[3][0]
          }, {
           type: 4,
           preview: apps[4][2],
           title_en: apps[4][0]
          }, {
           type: 5,
           preview: apps[5][2],
           title_en: apps[5][0]
          }, {
           type: 6,
           preview: apps[6][2],
           title_en: apps[6][0]
          }, {
           type: 7,
           preview: apps[7][2],
           title_en: apps[7][0]
          }, {
           type: 8,
           preview: apps[8][2],
           title_en: apps[8][0]
          }, {
           type: 9,
           preview: apps[9][2],
           title_en: apps[9][0]
          }, {
           type: 10,
           preview: apps[10][2],
           title_en: apps[10][0]
          }, {
           type: 11,
           preview: apps[11][2],
           title_en: apps[11][0]
          }, {
           type: 12,
           preview: apps[12][2],
           title_en: apps[12][0]
          }, {
           type: 13,
           preview: apps[13][2],
           title_en: apps[13][0]
          }, {
           type: 14,
           preview: apps[14][2],
           title_en: apps[14][0]
          }, {
           type: 15,
           preview: apps[15][2],
           title_en: apps[15][0]
          }, {
           type: 16,
           preview: apps[16][2],
           title_en: apps[16][0]
          }, {
           type: 17,
           preview: apps[17][2],
           title_en: apps[17][0]
          }, {
           type: 18,
           preview: apps[18][2],
           title_en: apps[18][0]
          }, {
           type: 19,
           preview: apps[19][2],
           title_en: apps[19][0]
          }, {
           type: 20,
           preview: apps[20][2],
           title_en: apps[20][0]
          }, {
           type: 21,
           preview: apps[21][2],
           title_en: apps[21][0]
          }, {
           type: 22,
           preview: apps[22][2],
           title_en: apps[22][0]
          }, {
           type: 23,
           preview: apps[23][2],
           title_en: apps[23][0]
          }, {
           type: 24,
           preview: apps[24][2],
           title_en: apps[24][0]
          }, {
           type: 25,
           preview: apps[25][2],
           title_en: apps[25][0]
          }, {
           type: 26,
           preview: apps[26][2],
           title_en: apps[26][0]
          }, {
           type: 27,
           preview: apps[27][2],
           title_en: apps[27][0]
          }, {
           type: 28,
           preview: apps[28][2],
           title_en: apps[28][0]
          }, {
           type: 29,
           preview: apps[29][2],
           title_en: apps[29][0]
          }, ],
          count: 30,
          tips_x: 5 - 40,
          tips_y: 184 - 246,
          tips_width: 195,
          tips_margin: 10,
          tips_BG: 'tap/tips_bg.png'
         })

         let tap_5_select = tap_5_edit.getProperty(hmUI.prop.CURRENT_TYPE)

         const tap_6_edit = hmUI.createWidget(hmUI.widget.WATCHFACE_EDIT_GROUP, {
          edit_id: 106,
          x: 40,
          y: 95,
          w: 124,
          h: 124,
          select_image: 'tap/edit_red_1.png',
          un_select_image: 'tap/edit_griin_1.png',
          default_type: 0,
          optional_types: [{
           type: 0,
           preview: apps[0][2],
           title_en: apps[0][0]
          }, {
           type: 1,
           preview: apps[1][2],
           title_en: apps[1][0]
          }, {
           type: 2,
           preview: apps[2][2],
           title_en: apps[2][0]
          }, {
           type: 3,
           preview: apps[3][2],
           title_en: apps[3][0]
          }, {
           type: 4,
           preview: apps[4][2],
           title_en: apps[4][0]
          }, {
           type: 5,
           preview: apps[5][2],
           title_en: apps[5][0]
          }, {
           type: 6,
           preview: apps[6][2],
           title_en: apps[6][0]
          }, {
           type: 7,
           preview: apps[7][2],
           title_en: apps[7][0]
          }, {
           type: 8,
           preview: apps[8][2],
           title_en: apps[8][0]
          }, {
           type: 9,
           preview: apps[9][2],
           title_en: apps[9][0]
          }, {
           type: 10,
           preview: apps[10][2],
           title_en: apps[10][0]
          }, {
           type: 11,
           preview: apps[11][2],
           title_en: apps[11][0]
          }, {
           type: 12,
           preview: apps[12][2],
           title_en: apps[12][0]
          }, {
           type: 13,
           preview: apps[13][2],
           title_en: apps[13][0]
          }, {
           type: 14,
           preview: apps[14][2],
           title_en: apps[14][0]
          }, {
           type: 15,
           preview: apps[15][2],
           title_en: apps[15][0]
          }, {
           type: 16,
           preview: apps[16][2],
           title_en: apps[16][0]
          }, {
           type: 17,
           preview: apps[17][2],
           title_en: apps[17][0]
          }, {
           type: 18,
           preview: apps[18][2],
           title_en: apps[18][0]
          }, {
           type: 19,
           preview: apps[19][2],
           title_en: apps[19][0]
          }, {
           type: 20,
           preview: apps[20][2],
           title_en: apps[20][0]
          }, {
           type: 21,
           preview: apps[21][2],
           title_en: apps[21][0]
          }, {
           type: 22,
           preview: apps[22][2],
           title_en: apps[22][0]
          }, {
           type: 23,
           preview: apps[23][2],
           title_en: apps[23][0]
          }, {
           type: 24,
           preview: apps[24][2],
           title_en: apps[24][0]
          }, {
           type: 25,
           preview: apps[25][2],
           title_en: apps[25][0]
          }, {
           type: 26,
           preview: apps[26][2],
           title_en: apps[26][0]
          }, {
           type: 27,
           preview: apps[27][2],
           title_en: apps[27][0]
          }, {
           type: 28,
           preview: apps[28][2],
           title_en: apps[28][0]
          }, {
           type: 29,
           preview: apps[29][2],
           title_en: apps[29][0]
          }, ],
          count: 30,
          tips_x: 5 - 40,
          tips_y: 225 - 95,

          tips_width: 195,
          tips_margin: 10,
          tips_BG: 'tap/tips_bg.png'
         })

         let tap_6_select = tap_6_edit.getProperty(hmUI.prop.CURRENT_TYPE)

         let btn_tap = ''
         let btn_click_tap_exit = ''

         let btn_Tap_zona_0 = ''
         let btn_Tap_zona_1 = ''
         let btn_Tap_zona_2 = ''
         let btn_Tap_zona_3 = ''
         let btn_Tap_zona_4 = ''
         let btn_Tap_zona_5 = ''


         let tap_x_y = [
          [178, 26, 1],
          [308, 102, 1],
          [308, 253, 1],
          [178, 328, 0],
          [47, 253, 0],
          [47, 102, 0]
         ];


         let vibrate = new hmSensor.Vibrator();
         let stopVibro_Timer = null;


         function vibro(mode = 25) {
          let stopDelay = 25;
          vibrate.stop();
          //vibrate.setMode(mode);
          vibrate.start(mode);
          if (stopVibro_Timer) clearTimeout(stopVibro_Timer);
          stopVibro_Timer = setTimeout(() => {
           stopVibro();
          }, stopDelay);
         }

         function stopVibro() {
          vibrate.stop();
          //timer.stopTimer(stopVibro_Timer);
          if (stopVibro_Timer) clearTimeout(stopVibro_Timer);
         }


         //переменные для ргафика
         let weatherArrayGrafik = [] //есть
         let weatherIconImgArrayGrafik = [] //есть
         let weatherTxtImgArray = []
         let weatherTxtImgArrayN = []
         let pointred = new Array(6);
         let pointblue = new Array(5);
         let linered = new Array(6);
         let lineblue = new Array(5);
         let yArrH = new Array(6);
         let yArrL = new Array(5);
         let y_pogodaH = new Array(6);
         let y_pogodaL = new Array(5);
         let week_weater = ["ПН", "ВТ", "СР", "ЧТ", "ПТ", "СБ", "ВС"];

         let week_weater_img = []
         let day_weater_img = []
         const ROOTPATH = "images/"

         //-------------------------------- 

         //массив иконок для графика       
         for (var i = 0; i <= 28; i++) {
          weatherArrayGrafik.push(ROOTPATH + "Grafik/weather/" + i + ".png"); //0-28

         }


         function updateGrafik() {

          //          const weather = new hmSensor.Weather();
          let weatherData = weather.getForecast();
          let forecastData = weatherData.forecastData;


          sunData = weatherData.tideData;
          if (sunData.count > 0) {
           today = sunData.data[0];
           sunriseMins = today.sunrise.hour * 60 + today.sunrise.minute;
           sunsetMins = today.sunset.hour * 60 + today.sunset.minute;
          } else {
           sunriseMins = sunriseMins_def;
           sunsetMins = sunsetMins_def;
          }
          curMins = timeSensor.getHours() * 60 + timeSensor.getMinutes();
          let isDayNow = (curMins >= sunriseMins) && (curMins < sunsetMins);

          if (isDayNow) {
           if (!isDayIcons) {
            isDayIcons = true;
           }
          } else {
           if (isDayIcons) {
            isDayIcons = false;
           }
          }

          normal_SUN_RISE_text_font.setProperty(hmUI.prop.VISIBLE, isDayIcons == false && zona_right == 2);
          normal_SUN_SET_img.setProperty(hmUI.prop.VISIBLE, isDayIcons == true && zona_right == 2); //true
          normal_SUN_SET_text_font.setProperty(hmUI.prop.VISIBLE, isDayIcons == true && zona_right == 2);
          normal_SUN_RISE_img.setProperty(hmUI.prop.VISIBLE, isDayIcons == false && zona_right == 2); //false



          hmStorage.localStorage.setItem('rz134_isDayIcons', isDayIcons);

          if (forecastData.count == 0) {
           for (let i = 0; i < 6; i++) {
            var invalidPath = "--";
            weatherIconImgArrayGrafik[i].setProperty(hmUI.prop.SRC, ROOTPATH + "Grafik/weather/25.png");
           }
          } else {
           let weekDay = timeSensor.getDay() - 1;
           let data_gr = timeSensor.getDate();
           let month_gr = timeSensor.getDate().month;

           for (let i = 0; i < 6; i++) {
            yArrH[i] = forecastData.data[i].high;
            let element = forecastData.data[i];
            let iconIndex = element.index;
            weatherIconImgArrayGrafik[i].setProperty(hmUI.prop.SRC, weatherArrayGrafik[iconIndex]);


            // let weekDay = timeSensor.getDay() - 1;
            //  for (let i = 0; i < 6; i++) {
            let week2 = week_weater[weekDay];
            week_weater_img[i].setProperty(hmUI.prop.MORE, {
             color: weekDay < 5 ? "0xFFFFFFFF" : "0xFFFF0000",
             text: week2,
            });
            day_weater_img[i].setProperty(hmUI.prop.MORE, {
             color: weekDay < 5 ? "0xFFFFFFFF" : "0xFFFF0000",
             text: data_gr,
            });
            weekDay = (weekDay + 1) % 7;
            data_gr = (data_gr + 1)
            if (data_gr > day_num[month_gr]) data_gr = 1
            // }						
           }


          }


          for (let i = 0; i < 5; i++) {
           yArrL[i] = forecastData.data[i].low;
          }
          let maxH = Math.max(...yArrH)
          let maxL = Math.min(...yArrL)
          var shag = 46;
          var x0 = 119;
          for (let i = 0; i < 6; i++) {
           pointred[i].setProperty(hmUI.prop.MORE, {
            x: 119 + shag * [i] - 5,
            y: (yArrH[i] * (120 / (maxL - maxH)) + 169 - 27 - maxH * (120 / (maxL - maxH))) - 5,
            w: 10,
            h: 10,
            start_angle: -90,
            end_angle: 270,
            color: 0xFFFF0000,
            line_width: 10,
           });
          };

          for (let i = 0; i < 5; i++) {
           yyyyy1 = (yArrH[i] * (120 / (maxL - maxH)) + 169 - 27 - maxH * (120 / (maxL - maxH))) - 5,
            yyyyy2 = (yArrH[i + 1] * (120 / (maxL - maxH)) + 169 - 27 - maxH * (120 / (maxL - maxH))) - 5,
            linered[i].setProperty(hmUI.prop.MORE, {
             x: 0,
             y: 0,
             w: 164 + shag * i,
             h: 466,
             pos_x: -31 + shag * i,
             pos_y: yyyyy1 + 2,
             center_x: 119 + shag * i,
             center_y: yyyyy1,
             angle: Math.atan((yyyyy2 - yyyyy1) / shag) * 180 / Math.PI,
             src: ROOTPATH + 'Grafik/line_red.png',
            });
          };
          for (let i = 0; i < 5; i++) {
           pointblue[i].setProperty(hmUI.prop.MORE, {
            x: 119 + 23 + shag * [i] - 5,
            y: (yArrL[i] * (120 / (maxL - maxH)) + 169 - 27 - maxH * (120 / (maxL - maxH))) - 5,
            w: 10,
            h: 10,
            start_angle: -90,
            end_angle: 270,
            color: 0xFF00eaff,
            line_width: 10,
           });
          };

          for (let i = 0; i < 4; i++) {
           yyyyy1 = (yArrL[i] * (120 / (maxL - maxH)) + 169 - 27 - maxH * (120 / (maxL - maxH))) - 5,
            yyyyy2 = (yArrL[i + 1] * (120 / (maxL - maxH)) + 169 - 27 - maxH * (120 / (maxL - maxH))) - 5,
            lineblue[i].setProperty(hmUI.prop.MORE, {
             x: 0,
             y: 0,
             w: 164 + shag * i + 23,
             h: 466,
             pos_x: -31 + shag * i + 23,
             pos_y: yyyyy1 + 2,
             center_x: 119 + shag * i + 23,
             center_y: yyyyy1,
             angle: Math.atan((yyyyy2 - yyyyy1) / shag) * 180 / Math.PI,
             src: ROOTPATH + 'Grafik/line_blue.png',
            });
          };

          for (let i = 0; i < 5; i++) {
           pointblue[i].setProperty(hmUI.prop.MORE, {
            x: 119 + 23 + shag * [i] - 5,
            y: (yArrL[i] * (120 / (maxL - maxH)) + 169 - 27 - maxH * (120 / (maxL - maxH))) - 5,
            w: 10,
            h: 10,
            start_angle: -90,
            end_angle: 270,
            color: 0xFF00eaff,
            line_width: 10,
           });
          };

          for (let i = 0; i < 6; i++) {
           y_pogodaH[i] = (yArrH[i] * (120 / (maxL - maxH)) + 169 - 24 - maxH * (120 / (maxL - maxH))) - 5;
           weatherTxtImgArray[i].setProperty(hmUI.prop.more, {
            x: 96 - 5 + i * 45 * 1.02,
            y: y_pogodaH[i] - 38, //120-7
            w: 50,
            h: 40,
            color: "0xFFffffff",
            text_size: 27,
            text: yArrH[i],
            text_style: hmUI.text_style.NONE,
            align_h: hmUI.align.CENTER_H,
            align_v: hmUI.align.CENTER_V,
            show_level: hmUI.show_level.ONLY_NORMAL
           });
          }

          for (let i = 0; i < 5; i++) {
           y_pogodaL[i] = (yArrL[i] * (120 / (maxL - maxH)) + 169 - 24 - maxH * (120 / (maxL - maxH))) - 5;;
           weatherTxtImgArrayN[i].setProperty(hmUI.prop.more, {
            x: 96 - 5 + 23 + i * 45 * 1.02,
            y: y_pogodaL[i] - 1, //120-7
            w: 50,
            h: 40,
            color: "0xFFffffff",
            text_size: 27,
            text: yArrL[i],
            text_style: hmUI.text_style.NONE,
            align_h: hmUI.align.CENTER_H,
            align_v: hmUI.align.CENTER_V,
            show_level: hmUI.show_level.ONLY_NORMAL
           });
          }
         }


         function makeAOD() {


          idle_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
           x: 0,
           y: 0,
           w: 466,
           h: 466,
           src: 'bg.png',
           show_level: hmUI.show_level.ONLY_AOD,
          });

          idle_image_img = hmUI.createWidget(hmUI.widget.IMG, {
           x: 249,
           y: 73,
           src: 'bg_progress.png',
           show_level: hmUI.show_level.ONLY_AOD,
          });

          idle_distance_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
           x: 82,
           y: 77,
           src: 'bg_progress.png',
           show_level: hmUI.show_level.ONLY_AOD,
          });

          idle_distance_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
           x: 114,
           y: 120,
           font_array: ["dig_a_0.png", "dig_a_1.png", "dig_a_2.png", "dig_a_3.png", "dig_a_4.png", "dig_a_5.png", "dig_a_6.png", "dig_a_7.png", "dig_a_8.png", "dig_a_9.png"],
           padding: false,
           h_space: 0,
           dot_image: 'dig_a_dot.png',
           align_h: hmUI.align.CENTER_H,
           type: hmUI.data_type.DISTANCE,
           show_level: hmUI.show_level.ONLY_AOD,
          });


          idle_step_circle_scale = hmUI.createWidget(hmUI.widget.ARC_PROGRESS, {
           center_x: 149,
           center_y: 144,
           start_angle: 0,
           end_angle: 360,
           radius: 61,
           line_width: 12,
           corner_flag: 3,
           color: 0xFF919191,
           src_bg: 'bg_progress.png',
           type: hmUI.data_type.STEP,
           show_level: hmUI.show_level.ONLY_AOD,
          });

          idle_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
           x: 114,
           y: 120,
           font_array: ["dig_a_0.png", "dig_a_1.png", "dig_a_2.png", "dig_a_3.png", "dig_a_4.png", "dig_a_5.png", "dig_a_6.png", "dig_a_7.png", "dig_a_8.png", "dig_a_9.png"],
           padding: false,
           h_space: 0,
           align_h: hmUI.align.CENTER_H,
           type: hmUI.data_type.STEP,
           show_level: hmUI.show_level.ONLY_AOD,
          });

          idle_step_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
           x: 78,
           y: 73,
           src: 'ic_step.png',
           show_level: hmUI.show_level.ONLY_AOD,
          });

          idle_calorie_circle_scale = hmUI.createWidget(hmUI.widget.ARC_PROGRESS, {
           center_x: 149,
           center_y: 144,
           start_angle: 0,
           end_angle: 360,
           radius: 61,
           line_width: 12,
           corner_flag: 3,
           color: 0xFF919191,
           src_bg: 'bg_progress.png',
           type: hmUI.data_type.CAL,
           show_level: hmUI.show_level.ONLY_AOD,
          });


          idle_calorie_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
           x: 121,
           y: 120,
           font_array: ["dig_a_0.png", "dig_a_1.png", "dig_a_2.png", "dig_a_3.png", "dig_a_4.png", "dig_a_5.png", "dig_a_6.png", "dig_a_7.png", "dig_a_8.png", "dig_a_9.png"],
           padding: false,
           h_space: 0,
           align_h: hmUI.align.CENTER_H,
           type: hmUI.data_type.CAL,
           show_level: hmUI.show_level.ONLY_AOD,
          });

          idle_calorie_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
           x: 78,
           y: 73,
           src: 'ic_ckal.png',
           show_level: hmUI.show_level.ONLY_AOD,
          });

          idle_heart_rate_circle_scale = hmUI.createWidget(hmUI.widget.ARC_PROGRESS, {
           center_x: 149,
           center_y: 144,
           start_angle: 0,
           end_angle: 360,
           radius: 61,
           line_width: 12,
           corner_flag: 3,
           color: 0xFF919191,
           src_bg: 'bg_progress.png',
           type: hmUI.data_type.HEART,
           show_level: hmUI.show_level.ONLY_AOD,
          });


          idle_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
           x: 128,
           y: 120,
           font_array: ["dig_a_0.png", "dig_a_1.png", "dig_a_2.png", "dig_a_3.png", "dig_a_4.png", "dig_a_5.png", "dig_a_6.png", "dig_a_7.png", "dig_a_8.png", "dig_a_9.png"],
           padding: false,
           h_space: 0,
           align_h: hmUI.align.CENTER_H,
           type: hmUI.data_type.HEART,
           show_level: hmUI.show_level.ONLY_AOD,
          });

          idle_heart_rate_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
           x: 78,
           y: 73,
           src: 'ic_puls.png',
           show_level: hmUI.show_level.ONLY_AOD,
          });


          idle_distance_text_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
           x: 78,
           y: 73,
           src: 'ic_dist.png',
           show_level: hmUI.show_level.ONLY_AOD,
          });

          idle_battery_circle_scale = hmUI.createWidget(hmUI.widget.ARC_PROGRESS, {
           center_x: 320,
           center_y: 144,
           start_angle: 0,
           end_angle: 360,
           radius: 61,
           line_width: 12,
           corner_flag: 3,
           color: 0xFF919191,
           src_bg: 'bg_progress.png',
           type: hmUI.data_type.BATTERY,
           show_level: hmUI.show_level.ONLY_AOD,
          });

          idle_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
           x: 288,
           y: 120,
           font_array: ["dig_a_0.png", "dig_a_1.png", "dig_a_2.png", "dig_a_3.png", "dig_a_4.png", "dig_a_5.png", "dig_a_6.png", "dig_a_7.png", "dig_a_8.png", "dig_a_9.png"],
           padding: false,
           h_space: 0,
           unit_sc: 'dig_a_pr.png',
           unit_tc: 'dig_a_pr.png',
           unit_en: 'dig_a_pr.png',
           align_h: hmUI.align.CENTER_H,
           type: hmUI.data_type.BATTERY,
           show_level: hmUI.show_level.ONLY_AOD,
          });

          idle_battery_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
           x: 249,
           y: 73,
           src: 'ic_bat.png',
           show_level: hmUI.show_level.ONLY_AOD,
          });


          idle_temperature_high_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
           x: 325,
           y: 181,
           font_array: ["dig_t_0.png", "dig_t_1.png", "dig_t_2.png", "dig_t_3.png", "dig_t_4.png", "dig_t_5.png", "dig_t_6.png", "dig_t_7.png", "dig_t_8.png", "dig_t_9.png"],
           padding: false,
           h_space: 0,
           unit_sc: 'dig_t_g.png',
           unit_tc: 'dig_t_g.png',
           unit_en: 'dig_t_g.png',
           negative_image: 'dig_t_m.png',
           invalid_image: 'dig_t_v.png',
           align_h: hmUI.align.RIGHT,
           type: hmUI.data_type.WEATHER_HIGH,
           show_level: hmUI.show_level.ONLY_AOD,
          });

          idle_temperature_low_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
           x: 272,
           y: 181,
           font_array: ["dig_t_0.png", "dig_t_1.png", "dig_t_2.png", "dig_t_3.png", "dig_t_4.png", "dig_t_5.png", "dig_t_6.png", "dig_t_7.png", "dig_t_8.png", "dig_t_9.png"],
           padding: false,
           h_space: 0,
           unit_sc: 'dig_t_g.png',
           unit_tc: 'dig_t_g.png',
           unit_en: 'dig_t_g.png',
           negative_image: 'dig_t_m.png',
           invalid_image: 'dig_t_v.png',
           align_h: hmUI.align.LEFT,
           type: hmUI.data_type.WEATHER_LOW,
           show_level: hmUI.show_level.ONLY_AOD,
          });

          idle_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
           x: 283,
           y: 136,
           font_array: ["dig_a_0.png", "dig_a_1.png", "dig_a_2.png", "dig_a_3.png", "dig_a_4.png", "dig_a_5.png", "dig_a_6.png", "dig_a_7.png", "dig_a_8.png", "dig_a_9.png"],
           padding: false,
           h_space: 0,
           unit_sc: 'dig_a_gC.png',
           unit_tc: 'dig_a_gC.png',
           unit_en: 'dig_a_gC.png',
           negative_image: 'dig_a_m.png',
           invalid_image: 'dig_a_v.png',
           align_h: hmUI.align.CENTER_H,
           type: hmUI.data_type.WEATHER_CURRENT,
           show_level: hmUI.show_level.ONLY_AOD,
          });

          idle_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
           x: 295,
           y: 87,
           image_array: ["w_0.png", "w_1.png", "w_2.png", "w_3.png", "w_4.png", "w_5.png", "w_6.png", "w_7.png", "w_8.png", "w_9.png", "w_10.png", "w_11.png", "w_12.png", "w_13.png", "w_14.png", "w_15.png", "w_16.png", "w_17.png", "w_18.png", "w_19.png", "w_20.png", "w_21.png", "w_22.png", "w_23.png", "w_24.png", "w_25.png", "w_26.png", "w_27.png", "w_28.png"],
           image_length: 29,
           type: hmUI.data_type.WEATHER_CURRENT,
           show_level: hmUI.show_level.ONLY_AOD,
          });

          idle_WEATHER_pointer_progress_img_pointer = hmUI.createWidget(hmUI.widget.ARC_PROGRESS, {
           center_x: 320,
           center_y: 144,
           radius: 61,
           start_angle: -120,
           end_angle: 120,
           color: 0xFF919191,
           line_width: 12,
           corner_flag: 3,
           src_bg: 'bg_progress_weater.png',
           type: hmUI.data_type.WEATHER_CURRENT,
           show_level: hmUI.show_level.ONLY_AOD
          });
			 
          idle_sun_pointer_progress_img_pointer = hmUI.createWidget(hmUI.widget.ARC_PROGRESS, {
           center_x: 320,
           center_y: 144,
           radius: 61,
           start_angle: -180,
           end_angle: 180,
           color: 0xFF919191,
           line_width: 12,
           corner_flag: 3,
           src_bg: 'bg_progress.png',
           type: hmUI.data_type.SUN_CURRENT,
           show_level: hmUI.show_level.ONLY_AOD
          });			 
			 
			 
          idle_SUN_SET_img = hmUI.createWidget(hmUI.widget.IMG, {
           x: 249,
           y: 73,
           src: "ic_zak.png",
           show_level: hmUI.show_level.ONLY_AOD,
          });

          idle_SUN_RISE_img = hmUI.createWidget(hmUI.widget.IMG, {
           x: 249,
           y: 73,
           src: "ic_vos.png",
           show_level: hmUI.show_level.ONLY_AOD,
          });

          idle_SUN_SET_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
           x: 244,
           y: 113,
           w: 150,
           h: 50,
           text_size: 45,
           char_space: 0,
           line_space: 0,
           font: 'fonts/steelfish_bd.ttf',
           color: 0xFFFFFFFF,
           align_h: hmUI.align.CENTER_H,
           align_v: hmUI.align.CENTER_V,
           text_style: hmUI.text_style.ELLIPSIS,
           type: hmUI.data_type.SUN_SET,
           show_level: hmUI.show_level.ONLY_AOD,
          });

          idle_SUN_RISE_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
           x: 244,
           y: 113,
           w: 150,
           h: 50,
           text_size: 45,
           char_space: 0,
           line_space: 0,
           font: 'fonts/steelfish_bd.ttf',
           color: 0xFFFFFFFF,
           align_h: hmUI.align.CENTER_H,
           align_v: hmUI.align.CENTER_V,
           text_style: hmUI.text_style.ELLIPSIS,
           type: hmUI.data_type.SUN_RISE,
           show_level: hmUI.show_level.ONLY_AOD,
          });			 
			 

          idle_altimeter_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
           x: 249,
           y: 73,
           src: 'ic_davlen.png',
           show_level: hmUI.show_level.ONLY_AOD,
          });

          idle_altimeter_pointer_progress_img_pointer = hmUI.createWidget(hmUI.widget.ARC_PROGRESS, {
           center_x: 320,
           center_y: 144,
           radius: 61,
           start_angle: -120,
           end_angle: 120,
           color: 0xFF919191,
           line_width: 12,
           corner_flag: 3,
           src_bg: 'bg_progress_weater.png',
           //  type: hmUI.data_type.ALTIMETER,
           show_level: hmUI.show_level.ONLY_AOD,
          });


          idle_altitude_target_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
           x: 299 - 49,
           y: 139,
           w: 142,
           h: 60,
           font_array: ["dig_a_0.png", "dig_a_1.png", "dig_a_2.png", "dig_a_3.png", "dig_a_4.png", "dig_a_5.png", "dig_a_6.png", "dig_a_7.png", "dig_a_8.png", "dig_a_9.png"],
           padding: false,
           h_space: 0,
           align_h: hmUI.align.CENTER_H,
           type: hmUI.data_type.ALTITUDE,
           show_level: hmUI.show_level.ONLY_AOD,
          });


          idle_altimeter_text_text_img = hmUI.createWidget(hmUI.widget.TEXT, {
           x: 244,
           y: 87,
           w: 150,
           h: 50,
           //text: parseInt(barometer.getAirPressure() * 0.750064).toString(),
           text_size: 45,
           char_space: 0,
           line_space: 0,
           font: 'fonts/steelfish_bd.ttf',
           color: 0xFFFFFFFF,
           align_h: hmUI.align.CENTER_H,
           align_v: hmUI.align.CENTER_V,
           text_style: hmUI.text_style.ELLIPSIS,
           //type: hmUI.data_type.SUN_SET,
           show_level: hmUI.show_level.ONLY_AOD,
          });


          idle_time_hour_min_text_font = hmUI.createWidget(hmUI.widget.TEXT, {
           x: 0,
           y: 204,
           w: 466,
           h: 200,
           text_size: 123,
           char_space: 0,
           line_space: 0,
           font: 'fonts/steelfish_bd.ttf',
           color: 0xFFFFFFFF,
           align_h: hmUI.align.CENTER_H,
           align_v: hmUI.align.TOP,
           text_style: hmUI.text_style.ELLIPSIS,
           show_level: hmUI.show_level.ONLY_AOD,
          });

          idle_digital_clock_hour_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
           x: 214,
           y: 232,
           src: 'H_dot.png',
           show_level: hmUI.show_level.ONLY_AOD,
          });

          idle_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
           day_startX: 299,
           day_startY: 352,
           day_sc_array: ["dig_a_0.png", "dig_a_1.png", "dig_a_2.png", "dig_a_3.png", "dig_a_4.png", "dig_a_5.png", "dig_a_6.png", "dig_a_7.png", "dig_a_8.png", "dig_a_9.png"],
           day_tc_array: ["dig_a_0.png", "dig_a_1.png", "dig_a_2.png", "dig_a_3.png", "dig_a_4.png", "dig_a_5.png", "dig_a_6.png", "dig_a_7.png", "dig_a_8.png", "dig_a_9.png"],
           day_en_array: ["dig_a_0.png", "dig_a_1.png", "dig_a_2.png", "dig_a_3.png", "dig_a_4.png", "dig_a_5.png", "dig_a_6.png", "dig_a_7.png", "dig_a_8.png", "dig_a_9.png"],
           day_zero: 1,
           day_space: 2,
           day_align: hmUI.align.CENTER_H,
           day_is_character: false,
           show_level: hmUI.show_level.ONLY_AOD,
          });

          idle_stress_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
           x: 0,
           y: 0,
           src: 'a_24.png',
           show_level: hmUI.show_level.ONLY_AOD,
          });

          idle_stand_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
           x: 0,
           y: 0,
           src: 'a_bezel.png',
           show_level: hmUI.show_level.ONLY_AOD,
          });

          idle_system_lock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
           x: 409,
           y: 258,
           src: blok_btn ? 'block_on.png' : 'block_off.png',
           type: hmUI.system_status.LOCK,
           show_level: hmUI.show_level.ONLY_AOD,
          });

          idle_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
           x: 31,
           y: 157,
           src: 'stat_B_off.png',
           type: hmUI.system_status.DISCONNECT,
           show_level: hmUI.show_level.ONLY_AOD,
          });

          idle_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
           x: 29,
           y: 251,
           src: 'stat_H_on.png',
           type: hmUI.system_status.CLOCK,
           show_level: hmUI.show_level.ONLY_AOD,
          });


          const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
           resume_call: (function () {
            stopVibro();

            idle_update_sec = setInterval(() => {
             let hour = timeSensor.getHours();
             let minute = timeSensor.getMinutes();
             // let second = timeSensor.getSeconds();

             idle_normal_HourMinStr = hour.toString().padStart(2, '0') + ':' + minute.toString().padStart(2, '0')
             idle_time_hour_min_text_font.setProperty(hmUI.prop.TEXT, idle_normal_HourMinStr);

             let idle_valuePressure = barometer.getAirPressure() * 0.750064;
             let idle_davlenie_txt = parseInt(idle_valuePressure).toString();
             idle_altimeter_text_text_img.setProperty(hmUI.prop.TEXT, idle_davlenie_txt);
             let idle_davlenie_str = idle_valuePressure * 100 / (800 - 720) - 900;
             idle_altimeter_pointer_progress_img_pointer.setProperty(hmUI.prop.LEVEL, idle_davlenie_str);
            }, 1000); // end timer	


           }),
           pause_call: (function () {
            clearInterval(idle_update_sec)
            stopVibro();
           }),
          });


          idle_step_circle_scale.setProperty(hmUI.prop.VISIBLE, zona_left == 0 || zona_left == 3);
          idle_step_current_text_img.setProperty(hmUI.prop.VISIBLE, zona_left == 0);
          idle_step_icon_img.setProperty(hmUI.prop.VISIBLE, zona_left == 0);

          idle_calorie_circle_scale.setProperty(hmUI.prop.VISIBLE, zona_left == 1);
          idle_calorie_current_text_img.setProperty(hmUI.prop.VISIBLE, zona_left == 1);
          idle_calorie_icon_img.setProperty(hmUI.prop.VISIBLE, zona_left == 1);

          idle_heart_rate_circle_scale.setProperty(hmUI.prop.VISIBLE, zona_left == 2);
          idle_heart_rate_text_text_img.setProperty(hmUI.prop.VISIBLE, zona_left == 2);
          idle_heart_rate_icon_img.setProperty(hmUI.prop.VISIBLE, zona_left == 2);

          idle_distance_text_text_img.setProperty(hmUI.prop.VISIBLE, zona_left == 3);
          idle_distance_text_separator_img.setProperty(hmUI.prop.VISIBLE, zona_left == 3);


          idle_battery_circle_scale.setProperty(hmUI.prop.VISIBLE, zona_right == 0);
          idle_battery_text_text_img.setProperty(hmUI.prop.VISIBLE, zona_right == 0);
          idle_battery_icon_img.setProperty(hmUI.prop.VISIBLE, zona_right == 0);

          idle_temperature_high_text_img.setProperty(hmUI.prop.VISIBLE, zona_right == 1);
          idle_temperature_low_text_img.setProperty(hmUI.prop.VISIBLE, zona_right == 1);
          idle_temperature_current_text_img.setProperty(hmUI.prop.VISIBLE, zona_right == 1);
          idle_weather_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, zona_right == 1);
          idle_WEATHER_pointer_progress_img_pointer.setProperty(hmUI.prop.VISIBLE, zona_right == 1);

          idle_sun_pointer_progress_img_pointer.setProperty(hmUI.prop.VISIBLE, zona_right == 2);

          idle_altimeter_icon_img.setProperty(hmUI.prop.VISIBLE, zona_right == 3);
          idle_altimeter_pointer_progress_img_pointer.setProperty(hmUI.prop.VISIBLE, zona_right == 3);
          idle_altitude_target_text_img.setProperty(hmUI.prop.VISIBLE, zona_right == 3);
          idle_altimeter_text_text_img.setProperty(hmUI.prop.VISIBLE, zona_right == 3);

          idle_SUN_RISE_text_font.setProperty(hmUI.prop.VISIBLE, isDayIcons == false && zona_right == 2);
          idle_SUN_SET_img.setProperty(hmUI.prop.VISIBLE, isDayIcons == true && zona_right == 2); //true
          idle_SUN_SET_text_font.setProperty(hmUI.prop.VISIBLE, isDayIcons == true && zona_right == 2);
          idle_SUN_RISE_img.setProperty(hmUI.prop.VISIBLE, isDayIcons == false && zona_right == 2); //false	
			 
			 
			 
			 

         }


         //dynamic modify end

         function init_view() {
          //dynamic modify start
          if (hmStorage.localStorage.getItem('rz134_init') != true) {
           saveSettings();
          }
          loadSettings();


          // FontName: steelfish_bd.ttf; FontSize: 47
          hmUI.createWidget(hmUI.widget.TEXT, {
           x: 464,
           y: 464,
           w: 367,
           h: 67,
           text_size: 47,
           char_space: 0,
           line_space: 0,
           font: 'fonts/steelfish_bd.ttf',
           color: 0xFFFFFFFF,
           align_h: hmUI.align.CENTER_H,
           align_v: hmUI.align.CENTER_V,
           text_style: hmUI.text_style.ELLIPSIS,
           text: "0123456789 _-.,:;`'%°\\/",
           show_level: hmUI.show_level.ONLY_NORMAL,
          });

          // FontName: steelfish_bd.ttf; FontSize: 123
          hmUI.createWidget(hmUI.widget.TEXT, {
           x: 464,
           y: 464,
           w: 963,
           h: 176,
           text_size: 123,
           char_space: 0,
           line_space: 0,
           font: 'fonts/steelfish_bd.ttf',
           color: 0xFFFFFFFF,
           align_h: hmUI.align.CENTER_H,
           align_v: hmUI.align.TOP,
           text_style: hmUI.text_style.ELLIPSIS,
           text: "0123456789 _-.,:;`'%°\\/",
           show_level: hmUI.show_level.ONLY_NORMAL,
          });


          // FontName: steelfish_bd.ttf; FontSize: 45
          hmUI.createWidget(hmUI.widget.TEXT, {
           x: 464,
           y: 464,
           w: 963,
           h: 176,
           text_size: 45,
           char_space: 0,
           line_space: 0,
           font: 'fonts/steelfish_bd.ttf',
           color: 0xFFFFFFFF,
           align_h: hmUI.align.CENTER_H,
           align_v: hmUI.align.TOP,
           text_style: hmUI.text_style.ELLIPSIS,
           text: "0123456789 _-.,:;`'%°\\/",
           show_level: hmUI.show_level.ONLY_NORMAL,
          });

          normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
           x: 0,
           y: 0,
           w: 466,
           h: 466,
           src: 'bg.png',
           show_level: hmUI.show_level.ONLY_NORMAL,
          });

          normal_distance_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
           x: 114,
           y: 120,
           font_array: ["dig_a_0.png", "dig_a_1.png", "dig_a_2.png", "dig_a_3.png", "dig_a_4.png", "dig_a_5.png", "dig_a_6.png", "dig_a_7.png", "dig_a_8.png", "dig_a_9.png"],
           padding: false,
           h_space: 0,
           dot_image: 'dig_a_dot.png',
           align_h: hmUI.align.CENTER_H,
           type: hmUI.data_type.DISTANCE,
           show_level: hmUI.show_level.ONLY_NORMAL,
          });


          //  let screenType = hmSetting.getScreenType();
          normal_step_circle_scale = hmUI.createWidget(hmUI.widget.ARC_PROGRESS, {
           center_x: 149,
           center_y: 144,
           start_angle: 0,
           end_angle: 360,
           radius: 61,
           line_width: 12,
           corner_flag: 3,
           color: 0xFF919191,
           src_bg: 'bg_progress.png',
           type: hmUI.data_type.STEP,
           show_level: hmUI.show_level.ONLY_NORMAL,
          });

          normal_distance_text_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
           x: 78,
           y: 73,
           src: 'ic_dist.png',
           show_level: hmUI.show_level.ONLY_NORMAL,
          });


          normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
           x: 114,
           y: 120,
           font_array: ["dig_a_0.png", "dig_a_1.png", "dig_a_2.png", "dig_a_3.png", "dig_a_4.png", "dig_a_5.png", "dig_a_6.png", "dig_a_7.png", "dig_a_8.png", "dig_a_9.png"],
           padding: false,
           h_space: 0,
           align_h: hmUI.align.CENTER_H,
           type: hmUI.data_type.STEP,
           show_level: hmUI.show_level.ONLY_NORMAL,
          });


          normal_step_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
           x: 78,
           y: 73,
           src: 'ic_step.png',
           show_level: hmUI.show_level.ONLY_NORMAL,
          });


          normal_calorie_circle_scale = hmUI.createWidget(hmUI.widget.ARC_PROGRESS, {
           center_x: 149,
           center_y: 144,
           start_angle: 0,
           end_angle: 360,
           radius: 61,
           line_width: 12,
           corner_flag: 3,
           color: 0xFF919191,
           src_bg: 'bg_progress.png',
           type: hmUI.data_type.CAL,
           show_level: hmUI.show_level.ONLY_NORMAL,
          });


          normal_calorie_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
           x: 121,
           y: 120,
           font_array: ["dig_a_0.png", "dig_a_1.png", "dig_a_2.png", "dig_a_3.png", "dig_a_4.png", "dig_a_5.png", "dig_a_6.png", "dig_a_7.png", "dig_a_8.png", "dig_a_9.png"],
           padding: false,
           h_space: 0,
           align_h: hmUI.align.CENTER_H,
           type: hmUI.data_type.CAL,
           show_level: hmUI.show_level.ONLY_NORMAL,
          });

          normal_calorie_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
           x: 78,
           y: 73,
           src: 'ic_ckal.png',
           show_level: hmUI.show_level.ONLY_NORMAL,
          });


          normal_heart_rate_circle_scale = hmUI.createWidget(hmUI.widget.ARC_PROGRESS, {
           center_x: 149,
           center_y: 144,
           start_angle: 0,
           end_angle: 360,
           radius: 61,
           line_width: 12,
           corner_flag: 3,
           color: 0xFF919191,
           src_bg: 'bg_progress.png',
           type: hmUI.data_type.HEART,
           show_level: hmUI.show_level.ONLY_NORMAL,
          });


          normal_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
           x: 128,
           y: 120,
           font_array: ["dig_a_0.png", "dig_a_1.png", "dig_a_2.png", "dig_a_3.png", "dig_a_4.png", "dig_a_5.png", "dig_a_6.png", "dig_a_7.png", "dig_a_8.png", "dig_a_9.png"],
           padding: false,
           h_space: 0,
           align_h: hmUI.align.CENTER_H,
           type: hmUI.data_type.HEART,
           show_level: hmUI.show_level.ONLY_NORMAL,
          });

          normal_heart_rate_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
           x: 78,
           y: 73,
           src: 'ic_puls.png',
           show_level: hmUI.show_level.ONLY_NORMAL,
          });


          normal_battery_circle_scale = hmUI.createWidget(hmUI.widget.ARC_PROGRESS, {
           center_x: 320,
           center_y: 144,
           start_angle: 0,
           end_angle: 360,
           radius: 61,
           line_width: 12,
           corner_flag: 3,
           color: 0xFF919191,
           src_bg: 'bg_progress.png',
           type: hmUI.data_type.BATTERY,
           show_level: hmUI.show_level.ONLY_NORMAL,
          });


          normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
           x: 288,
           y: 120,
           font_array: ["dig_a_0.png", "dig_a_1.png", "dig_a_2.png", "dig_a_3.png", "dig_a_4.png", "dig_a_5.png", "dig_a_6.png", "dig_a_7.png", "dig_a_8.png", "dig_a_9.png"],
           padding: false,
           h_space: 0,
           unit_sc: 'dig_a_pr.png',
           unit_tc: 'dig_a_pr.png',
           unit_en: 'dig_a_pr.png',
           align_h: hmUI.align.CENTER_H,
           type: hmUI.data_type.BATTERY,
           show_level: hmUI.show_level.ONLY_NORMAL,
          });

          normal_battery_text_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
           x: 150,
           y: 345,
           src: 'bg_week.png',
           show_level: hmUI.show_level.ONLY_NORMAL,
          });

          normal_battery_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
           x: 249,
           y: 73,
           src: 'ic_bat.png',
           show_level: hmUI.show_level.ONLY_NORMAL,
          });

          normal_digital_clock_minute_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
           x: 324,
           y: 251,
           src: 'bg_S.png',
           show_level: hmUI.show_level.ONLY_NORMAL,
          });

          //   if (!timeSensor) timeSensor = hmSensor.createSensor(hmSensor.id.TIME);
          normal_time_second_text_font = hmUI.createWidget(hmUI.widget.TEXT, {
           x: 273,
           y: 250,
           w: 150,
           h: 50,
           text_size: 47,
           char_space: 0,
           line_space: 0,
           font: 'fonts/steelfish_bd.ttf',
           color: 0xFFFFFFFF,
           align_h: hmUI.align.CENTER_H,
           align_v: hmUI.align.CENTER_V,
           text_style: hmUI.text_style.ELLIPSIS,
           // padding: true,
           show_level: hmUI.show_level.ONLY_NORMAL,
          });


          normal_time_hour_min_text_font = hmUI.createWidget(hmUI.widget.TEXT, {
           x: 0,
           y: 204,
           w: 466,
           h: 200,
           text_size: 123,
           char_space: 0,
           line_space: 0,
           font: 'fonts/steelfish_bd.ttf',
           color: 0xFFFFFFFF,
           align_h: hmUI.align.CENTER_H,
           align_v: hmUI.align.TOP,
           text_style: hmUI.text_style.ELLIPSIS,
           show_level: hmUI.show_level.ONLY_NORMAL,
          });

          normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
           hour_startX: 145,
           hour_startY: 232,
           hour_array: ["dig_a_p.png", "dig_a_p.png", "dig_a_p.png", "dig_a_p.png", "dig_a_p.png", "dig_a_p.png", "dig_a_p.png", "dig_a_p.png", "dig_a_p.png", "dig_a_p.png"],
           hour_zero: 1,
           hour_space: 0,
           hour_angle: 0,
           hour_align: hmUI.align.CENTER_H,

           minute_startX: 243,
           minute_startY: 232,
           minute_array: ["dig_a_p.png", "dig_a_p.png", "dig_a_p.png", "dig_a_p.png", "dig_a_p.png", "dig_a_p.png", "dig_a_p.png", "dig_a_p.png", "dig_a_p.png", "dig_a_p.png"],
           minute_zero: 1,
           minute_space: 0,
           minute_angle: 0,
           minute_follow: 0,
           minute_align: hmUI.align.CENTER_H,

           second_startX: 333,
           second_startY: 258,
           second_array: ["dig_a_p.png", "dig_a_p.png", "dig_a_p.png", "dig_a_p.png", "dig_a_p.png", "dig_a_p.png", "dig_a_p.png", "dig_a_p.png", "dig_a_p.png", "dig_a_p.png"],
           second_zero: 1,
           second_space: 2,
           second_angle: 0,
           second_follow: 0,
           second_align: hmUI.align.CENTER_H,

           show_level: hmUI.show_level.ONLY_NORMAL,
          });

          normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
           day_startX: 299,
           day_startY: 352,
           day_sc_array: ["dig_a_0.png", "dig_a_1.png", "dig_a_2.png", "dig_a_3.png", "dig_a_4.png", "dig_a_5.png", "dig_a_6.png", "dig_a_7.png", "dig_a_8.png", "dig_a_9.png"],
           day_tc_array: ["dig_a_0.png", "dig_a_1.png", "dig_a_2.png", "dig_a_3.png", "dig_a_4.png", "dig_a_5.png", "dig_a_6.png", "dig_a_7.png", "dig_a_8.png", "dig_a_9.png"],
           day_en_array: ["dig_a_0.png", "dig_a_1.png", "dig_a_2.png", "dig_a_3.png", "dig_a_4.png", "dig_a_5.png", "dig_a_6.png", "dig_a_7.png", "dig_a_8.png", "dig_a_9.png"],
           day_zero: 1,
           day_space: 2,
           day_align: hmUI.align.CENTER_H,
           day_is_character: false,
           show_level: hmUI.show_level.ONLY_NORMAL,
          });

          normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
           x: 145,
           y: 385,
           week_en: ["week_0.png", "week_1.png", "week_2.png", "week_3.png", "week_4.png", "week_5.png", "week_6.png"],
           week_tc: ["week_0.png", "week_1.png", "week_2.png", "week_3.png", "week_4.png", "week_5.png", "week_6.png"],
           week_sc: ["week_0.png", "week_1.png", "week_2.png", "week_3.png", "week_4.png", "week_5.png", "week_6.png"],
           show_level: hmUI.show_level.ONLY_NORMAL,
          });


          normal_temperature_high_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
           x: 325,
           y: 181,
           font_array: ["dig_t_0.png", "dig_t_1.png", "dig_t_2.png", "dig_t_3.png", "dig_t_4.png", "dig_t_5.png", "dig_t_6.png", "dig_t_7.png", "dig_t_8.png", "dig_t_9.png"],
           padding: false,
           h_space: 0,
           unit_sc: 'dig_t_g.png',
           unit_tc: 'dig_t_g.png',
           unit_en: 'dig_t_g.png',
           negative_image: 'dig_t_m.png',
           invalid_image: 'dig_t_v.png',
           align_h: hmUI.align.RIGHT,
           type: hmUI.data_type.WEATHER_HIGH,
           show_level: hmUI.show_level.ONLY_NORMAL,
          });

          normal_temperature_low_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
           x: 272,
           y: 181,
           font_array: ["dig_t_0.png", "dig_t_1.png", "dig_t_2.png", "dig_t_3.png", "dig_t_4.png", "dig_t_5.png", "dig_t_6.png", "dig_t_7.png", "dig_t_8.png", "dig_t_9.png"],
           padding: false,
           h_space: 0,
           unit_sc: 'dig_t_g.png',
           unit_tc: 'dig_t_g.png',
           unit_en: 'dig_t_g.png',
           negative_image: 'dig_t_m.png',
           invalid_image: 'dig_t_v.png',
           align_h: hmUI.align.LEFT,
           type: hmUI.data_type.WEATHER_LOW,
           show_level: hmUI.show_level.ONLY_NORMAL,
          });

          normal_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
           x: 283,
           y: 136,
           font_array: ["dig_a_0.png", "dig_a_1.png", "dig_a_2.png", "dig_a_3.png", "dig_a_4.png", "dig_a_5.png", "dig_a_6.png", "dig_a_7.png", "dig_a_8.png", "dig_a_9.png"],
           padding: false,
           h_space: 0,
           unit_sc: 'dig_a_gC.png',
           unit_tc: 'dig_a_gC.png',
           unit_en: 'dig_a_gC.png',
           negative_image: 'dig_a_m.png',
           invalid_image: 'dig_a_v.png',
           align_h: hmUI.align.CENTER_H,
           type: hmUI.data_type.WEATHER_CURRENT,
           show_level: hmUI.show_level.ONLY_NORMAL,
          });

          normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
           x: 295,
           y: 87,
           image_array: ["w_0.png", "w_1.png", "w_2.png", "w_3.png", "w_4.png", "w_5.png", "w_6.png", "w_7.png", "w_8.png", "w_9.png", "w_10.png", "w_11.png", "w_12.png", "w_13.png", "w_14.png", "w_15.png", "w_16.png", "w_17.png", "w_18.png", "w_19.png", "w_20.png", "w_21.png", "w_22.png", "w_23.png", "w_24.png", "w_25.png", "w_26.png", "w_27.png", "w_28.png"],
           image_length: 29,
           type: hmUI.data_type.WEATHER_CURRENT,
           show_level: hmUI.show_level.ONLY_NORMAL,
          });

          normal_stress_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
           x: 0,
           y: 0,
           src: '24_0.png',
           show_level: hmUI.show_level.ONLY_NORMAL,
          });


          normal_sun_pointer_progress_img_pointer = hmUI.createWidget(hmUI.widget.ARC_PROGRESS, {
           center_x: 320,
           center_y: 144,
           radius: 61,
           start_angle: -180,
           end_angle: 180,
           color: 0xFF919191,
           line_width: 12,
           corner_flag: 3,
           src_bg: 'bg_progress.png',
           type: hmUI.data_type.SUN_CURRENT,
           show_level: hmUI.show_level.ONLY_NORMAL
          });


          normal_WEATHER_pointer_progress_img_pointer = hmUI.createWidget(hmUI.widget.ARC_PROGRESS, {
           center_x: 320,
           center_y: 144,
           radius: 61,
           start_angle: -120,
           end_angle: 120,
           color: 0xFF919191,
           line_width: 12,
           corner_flag: 3,
           src_bg: 'bg_progress_weater.png',
           type: hmUI.data_type.WEATHER_CURRENT,
           show_level: hmUI.show_level.ONLY_NORMAL
          });


          normal_SUN_SET_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
           x: 244,
           y: 113,
           w: 150,
           h: 50,
           text_size: 45,
           char_space: 0,
           line_space: 0,
           font: 'fonts/steelfish_bd.ttf',
           color: 0xFFFFFFFF,
           align_h: hmUI.align.CENTER_H,
           align_v: hmUI.align.CENTER_V,
           text_style: hmUI.text_style.ELLIPSIS,
           type: hmUI.data_type.SUN_SET,
           show_level: hmUI.show_level.ONLY_NORMAL,
          });

          normal_SUN_RISE_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
           x: 244,
           y: 113,
           w: 150,
           h: 50,
           text_size: 45,
           char_space: 0,
           line_space: 0,
           font: 'fonts/steelfish_bd.ttf',
           color: 0xFFFFFFFF,
           align_h: hmUI.align.CENTER_H,
           align_v: hmUI.align.CENTER_V,
           text_style: hmUI.text_style.ELLIPSIS,
           type: hmUI.data_type.SUN_RISE,
           show_level: hmUI.show_level.ONLY_NORMAL,
          });


          normal_SUN_SET_img = hmUI.createWidget(hmUI.widget.IMG, {
           x: 249,
           y: 73,
           src: "ic_zak.png",
           show_level: hmUI.show_level.ONLY_NORMAL,
          });

          normal_SUN_RISE_img = hmUI.createWidget(hmUI.widget.IMG, {
           x: 249,
           y: 73,
           src: "ic_vos.png",
           show_level: hmUI.show_level.ONLY_NORMAL,
          });

          normal_altimeter_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
           x: 249,
           y: 73,
           src: 'ic_davlen.png',
           show_level: hmUI.show_level.ONLY_NORMAL,
          });

          normal_altimeter_pointer_progress_img_pointer = hmUI.createWidget(hmUI.widget.ARC_PROGRESS, {
           center_x: 320,
           center_y: 144,
           radius: 61,
           start_angle: -120,
           end_angle: 120,
           color: 0xFF919191,
           line_width: 12,
           corner_flag: 3,
           src_bg: 'bg_progress_weater.png',
           //  type: hmUI.data_type.ALTIMETER,
           show_level: hmUI.show_level.ONLY_NORMAL,
          });


          normal_altitude_target_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
           x: 299 - 49,
           y: 139,
           w: 142,
           h: 60,
           font_array: ["dig_a_0.png", "dig_a_1.png", "dig_a_2.png", "dig_a_3.png", "dig_a_4.png", "dig_a_5.png", "dig_a_6.png", "dig_a_7.png", "dig_a_8.png", "dig_a_9.png"],
           padding: false,
           h_space: 0,
           align_h: hmUI.align.CENTER_H,
           type: hmUI.data_type.ALTITUDE,
           show_level: hmUI.show_level.ONLY_NORMAL,
          });


          normal_altimeter_text_text_img = hmUI.createWidget(hmUI.widget.TEXT, {
           x: 244,
           y: 87,
           w: 150,
           h: 50,
           text: 45,
           text_size: 45,
           char_space: 0,
           line_space: 0,
           font: 'fonts/steelfish_bd.ttf',
           color: 0xFFFFFFFF,
           align_h: hmUI.align.CENTER_H,
           align_v: hmUI.align.CENTER_V,
           text_style: hmUI.text_style.ELLIPSIS,
           //type: hmUI.data_type.SUN_SET,
           show_level: hmUI.show_level.ONLY_NORMAL,
          });


          normal_stand_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
           x: 0,
           y: 0,
           src: 'bezel.png',
           show_level: hmUI.show_level.ONLY_NORMAL,
          });

          block_on_IMG = hmUI.createWidget(hmUI.widget.IMG, {
           x: 409,
           y: 258,
           src: blok_btn ? 'block_on.png' : 'block_off.png',
           show_level: hmUI.show_level.ONLY_NORMAL,
          });

          normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
           x: 31,
           y: 157,
           src: 'stat_B_off.png',
           type: hmUI.system_status.DISCONNECT,
           show_level: hmUI.show_level.ONLY_NORMAL,
          });

          normal_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
           x: 29,
           y: 251,
           src: 'stat_H_on.png',
           type: hmUI.system_status.CLOCK,
           show_level: hmUI.show_level.ONLY_NORMAL,
          });

          normal_analog_clock_time_pointer_minute = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
           minute_path: 'str_M.png',
           minute_centerX: 233,
           minute_centerY: 233,
           minute_posX: 26,
           minute_posY: 215,
           show_level: hmUI.show_level.ONLY_NORMAL,
          });

          normal_analog_clock_time_pointer_hour = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
           hour_path: 'str_H.png',
           hour_centerX: 233,
           hour_centerY: 233,
           hour_posX: 26,
           hour_posY: 145,
           hour_cover_path: 'stsr_center.png',
           hour_cover_x: 221,
           hour_cover_y: 221,
           show_level: hmUI.show_level.ONLY_NORMAL,
          });


			 

          function time_update() {
           let hour = timeSensor.getHours();
           let minute = timeSensor.getMinutes();
           let second = timeSensor.getSeconds();
           let normal_secondStr = second.toString();
			  
//			if (theme == 0) normal_stress_icon_img.setProperty(hmUI.prop.SRC, hour >= 12 ? '24_2.png' : '24_0.png');
			  
			  
          if (theme == 0) {
           if (dig == 0 || dig == 2) {
            normal_stress_icon_img.setProperty(hmUI.prop.SRC, hour >= 12 ? '24_2.png' : '24_0.png');
           } else {
            normal_stress_icon_img.setProperty(hmUI.prop.SRC, hour >= 12 ? '24_1.png' : '24_3.png');
           }
		  }			  
/*			  
			if (theme == 1) normal_stress_icon_img.setProperty(hmUI.prop.SRC, dig == 0 || dig == 2 ? '24_0.png':'24_3.png');	
			else if (theme == 2) normal_stress_icon_img.setProperty(hmUI.prop.SRC, dig == 0 || dig == 2 ? '24_2.png':'24_1.png');	
			else if (theme == 3) normal_stress_icon_img.setProperty(hmUI.prop.SRC, '0_Empty.png');	*/			  
			  
           normal_secondStr = normal_secondStr.padStart(2, '0');
           normal_time_second_text_font.setProperty(hmUI.prop.TEXT, normal_secondStr);
           normal_HourMinStr = hour.toString().padStart(2, '0') + ':' + minute.toString().padStart(2, '0')
           normal_time_hour_min_text_font.setProperty(hmUI.prop.TEXT, normal_HourMinStr);
          };

          bg_edit_img = hmUI.createWidget(hmUI.widget.IMG, {
           x: 0,
           y: 0,
           src: 'tap/bg_edit.png',
           show_level: hmUI.show_level.ONLY_EDIT,
          });

          const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
           resume_call: (function () {

            updateGrafik();
            stopVibro();
            //  time_update(true, true);
            let animRepeat = 1000;
            update_sec = setInterval(() => {
             time_update();

             let valuePressure = barometer.getAirPressure() * 0.750064;
             let davlenie_txt = parseInt(valuePressure).toString();
             normal_altimeter_text_text_img.setProperty(hmUI.prop.TEXT, davlenie_txt);
             let davlenie_str = valuePressure * 100 / (800 - 720) - 900;
             normal_altimeter_pointer_progress_img_pointer.setProperty(hmUI.prop.LEVEL, davlenie_str);

            }, animRepeat); // end timer

           }),
           pause_call: (function () {
            clearInterval(update_sec)
            stopVibro();
            groupVremya.setProperty(hmUI.prop.VISIBLE, true);
            groupPogoda.setProperty(hmUI.prop.VISIBLE, false);
            groupTap.setProperty(hmUI.prop.VISIBLE, false);


           }),
          });


          groupVremya = hmUI.createWidget(hmUI.widget.GROUP, {
           x: 0,
           y: 0,
           w: 466,
           h: 466,
          }); // 	


          groupTap = hmUI.createWidget(hmUI.widget.GROUP, {
           x: 0,
           y: 0,
           w: 466,
           h: 466,
          });

          groupTap.createWidget(hmUI.widget.IMG, {
           x: 0,
           y: 0,
           w: 466,
           h: 466,
           src: 'tap/i_tap_bg.png',
           show_level: hmUI.show_level.ONLY_NORMAL,
          });


          Tap_zona_0 = groupTap.createWidget(hmUI.widget.IMG, {
           x: tap_x_y[0][0],
           y: tap_x_y[0][1],
           src: apps[tap_1_select][2], //'tap/i_tap_calendar.png',
           show_level: hmUI.show_level.ONLY_NORMAL,
          });

          Tap_zona_1 = groupTap.createWidget(hmUI.widget.IMG, {
           x: tap_x_y[1][0],
           y: tap_x_y[1][1],
           src: apps[tap_2_select][2],
           show_level: hmUI.show_level.ONLY_NORMAL,
          });

          Tap_zona_2 = groupTap.createWidget(hmUI.widget.IMG, {
           x: tap_x_y[2][0],
           y: tap_x_y[2][1],
           src: apps[tap_3_select][2],
           show_level: hmUI.show_level.ONLY_NORMAL,
          });

          Tap_zona_3 = groupTap.createWidget(hmUI.widget.IMG, {
           x: tap_x_y[3][0],
           y: tap_x_y[3][1],
           src: apps[tap_4_select][2],
           show_level: hmUI.show_level.ONLY_NORMAL,
          });

          Tap_zona_4 = groupTap.createWidget(hmUI.widget.IMG, {
           x: tap_x_y[4][0],
           y: tap_x_y[4][1],
           src: apps[tap_5_select][2],
           show_level: hmUI.show_level.ONLY_NORMAL,
          });

          Tap_zona_5 = groupTap.createWidget(hmUI.widget.IMG, {
           x: tap_x_y[5][0],
           y: tap_x_y[5][1],
           src: apps[tap_6_select][2],
           show_level: hmUI.show_level.ONLY_NORMAL,
          });


          btn_Tap_zona_0 = groupTap.createWidget(hmUI.widget.BUTTON, {
           x: tap_x_y[0][0],
           y: tap_x_y[0][1],
           text: '',
           w: 113,
           h: 113,
           normal_src: '0_Empty.png',
           press_src: '0_Empty.png',
           click_func: () => {
            vibro();
            hmRouter.launchApp({
             url: apps[tap_1_select][1],
             native: true
            });
           },
           show_level: hmUI.show_level.ONLY_NORMAL,
          });


          btn_Tap_zona_1 = groupTap.createWidget(hmUI.widget.BUTTON, {
           x: tap_x_y[1][0],
           y: tap_x_y[1][1],
           text: '',
           w: 113,
           h: 113,
           normal_src: '0_Empty.png',
           press_src: '0_Empty.png',
           click_func: () => {
            vibro();
            hmRouter.launchApp({
             url: apps[tap_2_select][1],
             native: true
            });
           },
           show_level: hmUI.show_level.ONLY_NORMAL,
          });

          btn_Tap_zona_2 = groupTap.createWidget(hmUI.widget.BUTTON, {
           x: tap_x_y[2][0],
           y: tap_x_y[2][1],
           text: '',
           w: 113,
           h: 113,
           normal_src: '0_Empty.png',
           press_src: '0_Empty.png',
           click_func: () => {
            vibro();
            hmRouter.launchApp({
             url: apps[tap_3_select][1],
             native: true
            });
           },
           show_level: hmUI.show_level.ONLY_NORMAL,
          });

          btn_Tap_zona_3 = groupTap.createWidget(hmUI.widget.BUTTON, {
           x: tap_x_y[3][0],
           y: tap_x_y[3][1],
           text: '',
           w: 113,
           h: 113,
           normal_src: '0_Empty.png',
           press_src: '0_Empty.png',
           click_func: () => {
            vibro();
            hmRouter.launchApp({
             url: apps[tap_4_select][1],
             native: true
            });
           },
           show_level: hmUI.show_level.ONLY_NORMAL,
          });

          btn_Tap_zona_4 = groupTap.createWidget(hmUI.widget.BUTTON, {
           x: tap_x_y[4][0],
           y: tap_x_y[4][1],
           text: '',
           w: 113,
           h: 113,
           normal_src: '0_Empty.png',
           press_src: '0_Empty.png',
           click_func: () => {
            vibro();
            hmRouter.launchApp({
             url: apps[tap_5_select][1],
             native: true
            });
           },
           show_level: hmUI.show_level.ONLY_NORMAL,
          });

          btn_Tap_zona_5 = groupTap.createWidget(hmUI.widget.BUTTON, {
           x: tap_x_y[5][0],
           y: tap_x_y[5][1],
           text: '',
           w: 113,
           h: 113,
           normal_src: '0_Empty.png',
           press_src: '0_Empty.png',
           click_func: () => {
            vibro();
            hmRouter.launchApp({
             url: apps[tap_6_select][1],
             native: true
            });
           },
           show_level: hmUI.show_level.ONLY_NORMAL,
          });

          btn_click_tap_exit = groupTap.createWidget(hmUI.widget.BUTTON, {
           x: 183,
           y: 183,
           text: '',
           w: 100,
           h: 100,
           normal_src: '0_Empty.png',
           press_src: '0_Empty.png',
           click_func: () => {
            vibro();
            groupVremya.setProperty(hmUI.prop.VISIBLE, true);
            groupTap.setProperty(hmUI.prop.VISIBLE, false);

           },
           show_level: hmUI.show_level.ONLY_NORMAL,
          });


          btn_tap = groupVremya.createWidget(hmUI.widget.BUTTON, {
           x: 55,
           y: 324,
           text: '',
           w: 80,
           h: 80,
           normal_src: 'p.png',
           press_src: 'p.pngg',
           click_func: () => {
            vibro();
            groupVremya.setProperty(hmUI.prop.VISIBLE, false);
            groupTap.setProperty(hmUI.prop.VISIBLE, true);

           },
           show_level: hmUI.show_level.ONLY_NORMAL,
          });

          btn_grafic = groupVremya.createWidget(hmUI.widget.BUTTON, {
           x: 143,
           y: 373,
           text: '',
           w: 80,
           h: 80,
           normal_src: 'p.png',
           press_src: 'p.pngg',
           click_func: () => {
            vibro();
            groupVremya.setProperty(hmUI.prop.VISIBLE, false);
            groupPogoda.setProperty(hmUI.prop.VISIBLE, true);

           },
           show_level: hmUI.show_level.ONLY_NORMAL,
          });


          //---------------------------    погода
          groupPogoda = hmUI.createWidget(hmUI.widget.GROUP, {
           x: 0,
           y: 0 + 20,
           w: 466,
           h: 466,
          });

          // фон
          groupPogoda.createWidget(hmUI.widget.IMG, {
           x: 62,
           y: 71,
           w: 343,
           h: 323,
           src: ROOTPATH + 'Grafik/Grafik_bg.png',
           //alpha: 153,
           show_level: hmUI.show_level.ONLY_NORMAL,
          });


          for (var i = 0; i < 6; i++) {
           week_weater_img[i] = groupPogoda.createWidget(hmUI.widget.TEXT, {
            x: 93 + i * 46 * 1.0, //,107 + i * 45 * 1.02,
            y: 295 - 21 + 2,
            w: 50,
            h: 50,
            char_space: 0, //-1
            line_space: 0,
            color: "0xFFffffff",
            text: week_weater[i],
            text_size: 22,
            text_style: hmUI.text_style.NONE,
            align_h: hmUI.align.CENTER_H,
            align_v: hmUI.align.CENTER_V,
            show_level: hmUI.show_level.ONLY_NORMAL
           });

           hmUI.deleteWidget(day_weater_img[i]);

           day_weater_img[i] = groupPogoda.createWidget(hmUI.widget.TEXT, {
            x: 93 + i * 46 * 1.0, //,107 + i * 45 * 1.02,
            y: 295 - 21 + 2 + 20,
            w: 50,
            h: 50,
            char_space: 0, //-1
            line_space: 0,
            color: "0xFFffffff",
            text: 31,
            text_size: 22,
            text_style: hmUI.text_style.NONE,
            align_h: hmUI.align.CENTER_H,
            align_v: hmUI.align.CENTER_V,
            show_level: hmUI.show_level.ONLY_NORMAL
           });

           weatherIconImgArrayGrafik[i] = groupPogoda.createWidget(hmUI.widget.IMG, {
            x: 98 + i * 45 * 1.02,
            y: 78,
            w: 40,
            h: 40,
            // src: weatherArray[i],
            shortcut: true,
            show_level: hmUI.show_level.ONLY_NORMAL,
           });

          }

          for (var i = 0; i < 6; i++) {
           hmUI.deleteWidget(linered[i]);
           linered[i] = groupPogoda.createWidget(hmUI.widget.IMG);
           hmUI.deleteWidget(pointred[i]);
           pointred[i] = groupPogoda.createWidget(hmUI.widget.ARC);
           hmUI.deleteWidget(weatherTxtImgArray[i]);
           weatherTxtImgArray[i] = groupPogoda.createWidget(hmUI.widget.TEXT);
          }
          for (var i = 0; i < 5; i++) {
           hmUI.deleteWidget(lineblue[i]);
           lineblue[i] = groupPogoda.createWidget(hmUI.widget.IMG);
           hmUI.deleteWidget(pointblue[i]);
           pointblue[i] = groupPogoda.createWidget(hmUI.widget.ARC);
           hmUI.deleteWidget(weatherTxtImgArrayN[i]);
           weatherTxtImgArrayN[i] = groupPogoda.createWidget(hmUI.widget.TEXT);
          }


          btn_Pogoda_off = groupPogoda.createWidget(hmUI.widget.BUTTON, {
           x: 183, //x кнопки
           y: 183, //y кнопки
           text: '',
           w: 100, //ширина кнопки
           h: 100, //высота кнопки
           normal_src: '0_Empty.png',
           press_src: 'press_100.png',
           click_func: () => {
            vibro(); //имя вызываемой функции
            groupVremya.setProperty(hmUI.prop.VISIBLE, true);
            groupPogoda.setProperty(hmUI.prop.VISIBLE, false);

           },
           show_level: hmUI.show_level.ONLY_NORMAL,
          });


          zona_left_btn = groupVremya.createWidget(hmUI.widget.BUTTON, {
           x: 109,
           y: 104,
           text: '',
           w: 80,
           h: 80,
           normal_src: '0_Empty.png',
           press_src: '0_Empty.png',
           click_func: () => {
            vibro();
            cl_zona_left()
           },
           show_level: hmUI.show_level.ONLY_NORMAL,
          });


          zona_right_btn = groupVremya.createWidget(hmUI.widget.BUTTON, {
           x: 280,
           y: 104,
           text: '',
           w: 80,
           h: 80,
           normal_src: '0_Empty.png',
           press_src: '0_Empty.png',
           click_func: () => {
            vibro();
            cl_zona_right()
           },
           show_level: hmUI.show_level.ONLY_NORMAL,
          });

          str_btn = groupVremya.createWidget(hmUI.widget.BUTTON, {
           x: 193,
           y: 193,
           text: '',
           w: 80,
           h: 80,
           normal_src: '0_Empty.png',
           press_src: '0_Empty.png',
           click_func: () => {
            vibro();
            str = (str + 1) % 2
            // hmStorage.localStorage.setItem('rz134_str', str);
            call_change_str(str)
           },
           show_level: hmUI.show_level.ONLY_NORMAL,
          });

          btn_dig = groupVremya.createWidget(hmUI.widget.BUTTON, {
           x: 244,
           y: 373,
           text: '',
           w: 80,
           h: 80,
           normal_src: '0_Empty.png',
           press_src: '0_Empty.png',
           click_func: () => {
            vibro();
            cl_dig()
           },
           show_level: hmUI.show_level.ONLY_NORMAL,
          });

          btn_theme = groupVremya.createWidget(hmUI.widget.BUTTON, {
           x: 328,
           y: 324,
           text: '',
           w: 80,
           h: 80,
           normal_src: '0_Empty.png',
           press_src: '0_Empty.png',
           click_func: () => {
            vibro();
            cl_theme()
           },
           show_level: hmUI.show_level.ONLY_NORMAL,
          });


          btn_block = groupVremya.createWidget(hmUI.widget.BUTTON, {
           x: 373,
           y: 243,
           text: '',
           w: 80,
           h: 80,
           normal_src: '0_Empty.png',
           press_src: '0_Empty.png',
           click_func: () => {
            vibro();
            click_blok();
           },
           show_level: hmUI.show_level.ONLY_NORMAL,
          });

          btn_raz_block = hmUI.createWidget(hmUI.widget.BUTTON, {
           x: 373,
           y: 243,
           text: '',
           w: 80,
           h: 80,
           normal_src: '0_Empty.png',
           press_src: '0_Empty.png',
           longpress_func: () => {
            vibro();
            click_zazblok();
           },
           show_level: hmUI.show_level.ONLY_NORMAL,
          });
          btn_raz_block.setProperty(hmUI.prop.VISIBLE, false);


          normal_step_circle_scale.setProperty(hmUI.prop.VISIBLE, zona_left == 0 || zona_left == 3);
          normal_step_current_text_img.setProperty(hmUI.prop.VISIBLE, zona_left == 0);
          normal_step_icon_img.setProperty(hmUI.prop.VISIBLE, zona_left == 0);

          normal_calorie_circle_scale.setProperty(hmUI.prop.VISIBLE, zona_left == 1);
          normal_calorie_current_text_img.setProperty(hmUI.prop.VISIBLE, zona_left == 1);
          normal_calorie_icon_img.setProperty(hmUI.prop.VISIBLE, zona_left == 1);

          normal_heart_rate_circle_scale.setProperty(hmUI.prop.VISIBLE, zona_left == 2);
          normal_heart_rate_text_text_img.setProperty(hmUI.prop.VISIBLE, zona_left == 2);
          normal_heart_rate_icon_img.setProperty(hmUI.prop.VISIBLE, zona_left == 2);

          normal_distance_text_text_img.setProperty(hmUI.prop.VISIBLE, zona_left == 3);
          normal_distance_text_separator_img.setProperty(hmUI.prop.VISIBLE, zona_left == 3);


          normal_battery_circle_scale.setProperty(hmUI.prop.VISIBLE, zona_right == 0);
          normal_battery_text_text_img.setProperty(hmUI.prop.VISIBLE, zona_right == 0);
          normal_battery_icon_img.setProperty(hmUI.prop.VISIBLE, zona_right == 0);

          normal_temperature_high_text_img.setProperty(hmUI.prop.VISIBLE, zona_right == 1);
          normal_temperature_low_text_img.setProperty(hmUI.prop.VISIBLE, zona_right == 1);
          normal_temperature_current_text_img.setProperty(hmUI.prop.VISIBLE, zona_right == 1);
          normal_weather_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, zona_right == 1);
          normal_WEATHER_pointer_progress_img_pointer.setProperty(hmUI.prop.VISIBLE, zona_right == 1);

          normal_sun_pointer_progress_img_pointer.setProperty(hmUI.prop.VISIBLE, zona_right == 2);

          normal_altimeter_icon_img.setProperty(hmUI.prop.VISIBLE, zona_right == 3);
          normal_altimeter_pointer_progress_img_pointer.setProperty(hmUI.prop.VISIBLE, zona_right == 3);
          normal_altitude_target_text_img.setProperty(hmUI.prop.VISIBLE, zona_right == 3);
          normal_altimeter_text_text_img.setProperty(hmUI.prop.VISIBLE, zona_right == 3);


          groupVremya.setProperty(hmUI.prop.VISIBLE, true);
          groupTap.setProperty(hmUI.prop.VISIBLE, false);
          groupPogoda.setProperty(hmUI.prop.VISIBLE, false);


          //dynamic modify end
         }


         __$$module$$__.module = WatchFace({
          onInit() {
           if (hmScene.getScene() == hmScene.SCENE_AOD) loadSettings();
          },
          build() {
           if (hmScene.getScene() == hmScene.SCENE_AOD) {
            makeAOD();
           } else {
            init_view();
           }
          },
          onPause() {
           //if (hmSetting.getScreenType() == hmSetting.screen_type.AOD) hmUI.showToast({text: "АОД: Ставлюсь на паузу!"});
           //else hmUI.showToast({text: "Ставлюсь на паузу!"});
          },
          onResume() {
           //if (hmSetting.getScreenType() == hmSetting.screen_type.AOD) hmUI.showToast({text: "АОД: И снова здравствуйте!!!"});
           //else hmUI.showToast({text: "И снова здравствуйте!!!"});
          },
          onDestroy() {
           vibrate && vibrate.stop();
           offDigitalCrown();
          }
         });

        }
       }.bind(__$$G$$__)(__$$G$$__);


      afterPageCreate()
      afterModuleCreate()

     })()
    } catch (e) {

     console.log('Mini Program Error', e)
     e && e.stack && e.stack.split(/\n/).forEach(i => console.log("error stack", i))

     /* todo */
    }
