﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        //const logger = Logger.getLogger('watchface_SashaCX75');
        const logger = DeviceRuntimeCore.HmLogger.getLogger('watchface_SashaCX75')
        //end of ignored block

        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_distance_text_text_img = ''
        let normal_distance_text_separator_img = ''
        let normal_altitude_target_text_img = ''
        let normal_altitude_target_separator_img = ''
        let normal_sun_high_text_font = ''
        let normal_sun_low_text_font = ''
        let normal_moon_high_text_font = ''
        let normal_moon_low_text_font = ''
        let normal_moon_image_progress_img_level = ''
        let normal_wind_direction_image_progress_img_level = ''
        let normal_wind_text_text_img = ''
        let normal_wind_text_separator_img = ''
        let normal_system_disconnect_img = ''
        let normal_system_clock_img = ''
        let normal_date_img_date_year = ''
        let normal_date_img_date_day = ''
        let normal_date_img_date_month = ''
        let normal_heart_rate_text_text_img = ''
        let normal_battery_text_text_img = ''
        let normal_battery_text_separator_img = ''
        let normal_battery_image_progress_img_level = ''
        let normal_calorie_current_text_img = ''
        let normal_calorie_current_separator_img = ''
        let normal_calorie_image_progress_img_level = ''
        let normal_step_icon_img = ''
        let normal_step_current_text_img = ''
        let normal_step_image_progress_img_level = ''
        let normal_date_img_date_week_img = ''
        let normal_city_name_text = ''
        let normal_weather_image_progress_img_level = ''
        let normal_temperature_high_text_font = ''
        let normal_temperature_low_text_font = ''
        let normal_temperature_current_text_img = ''
        let normal_digital_clock_img_time_AmPm = ''
        let normal_digital_clock_img_time = ''
        let idle_system_disconnect_img = ''
        let idle_system_clock_img = ''
        let idle_date_img_date_year = ''
        let idle_date_img_date_day = ''
        let idle_date_img_date_month = ''
        let idle_battery_current_text_font = ''
        let idle_date_img_date_week_img = ''
        let idle_digital_clock_img_time_AmPm = ''
        let idle_digital_clock_img_time = ''
        let normal_step_jumpable_img_click = ''
        let normal_heart_jumpable_img_click = ''
        let normal_battery_jumpable_img_click = ''
        let normal_sunrise_jumpable_img_click = ''
        let normal_moon_jumpable_img_click = ''
        let normal_temperature_jumpable_img_click = ''
        let normal_alarm_jumpable_img_click = ''
        let normal_altitude_jumpable_img_click = ''
        let normal_fatBurning_jumpable_img_click = ''
        let Button_1 = ''
        let Button_2 = ''
        let Button_3 = ''
        let Button_4 = ''
        let Button_5 = ''
        let Button_6 = ''


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            console.log('Watch_Face.ScreenNormal');
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 466,
              h: 466,
              src: '0002.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_distance_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 59,
              y: 311,
              font_array: ["0157.png","0158.png","0159.png","0160.png","0161.png","0162.png","0163.png","0164.png","0165.png","0166.png"],
              padding: false,
              h_space: 0,
              dot_image: '0107.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.DISTANCE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_distance_text_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 24,
              y: 308,
              src: 'dist.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_altitude_target_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 57,
              y: 273,
              font_array: ["0157.png","0158.png","0159.png","0160.png","0161.png","0162.png","0163.png","0164.png","0165.png","0166.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.ALTITUDE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_altitude_target_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 10,
              y: 261,
              src: 'alt.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sun_high_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 46,
              y: 352,
              w: 150,
              h: 30,
              text_size: 20,
              char_space: 0,
              line_space: 0,
              color: 0xFFFFFFFF,
              align_h: hmUI.align.LEFT,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              type: hmUI.data_type.SUN_RISE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sun_low_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 138,
              y: 352,
              w: 150,
              h: 30,
              text_size: 20,
              char_space: 0,
              line_space: 0,
              color: 0xFFFFFFFF,
              align_h: hmUI.align.LEFT,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              type: hmUI.data_type.SUN_SET,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_moon_high_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 183,
              y: 352,
              w: 150,
              h: 30,
              text_size: 20,
              char_space: 0,
              line_space: 0,
              color: 0xFFFFFFFF,
              align_h: hmUI.align.RIGHT,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              type: hmUI.data_type.MOON_RISE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_moon_low_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 367,
              y: 352,
              w: 150,
              h: 30,
              text_size: 20,
              char_space: 0,
              line_space: 0,
              color: 0xFFFFFFFF,
              align_h: hmUI.align.LEFT,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              type: hmUI.data_type.MOON_SET,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_moon_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 335,
              y: 352,
              image_array: ["moon_01.png","moon_02.png","moon_03.png","moon_04.png","moon_05.png","moon_06.png","moon_07.png","moon_08.png","moon_09.png","moon_10.png","moon_11.png","moon_12.png","moon_13.png","moon_14.png","moon_15.png","moon_16.png","moon_17.png","moon_18.png","moon_19.png","moon_20.png","moon_21.png","moon_22.png","moon_23.png","moon_24.png","moon_25.png","moon_26.png","moon_27.png","moon_28.png","moon_29.png","moon_30.png"],
              image_length: 30,
              type: hmUI.data_type.MOON,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_wind_direction_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 84,
              y: 242,
              image_array: ["0088.png","0089.png","0090.png","0091.png","0092.png","0093.png","0094.png","0095.png"],
              image_length: 8,
              type: hmUI.data_type.WIND_DIRECTION,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_wind_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 36,
              y: 242,
              font_array: ["0157.png","0158.png","0159.png","0160.png","0161.png","0162.png","0163.png","0164.png","0165.png","0166.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WIND,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_wind_text_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 235,
              src: '0096.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 276,
              y: 246,
              src: '0224.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 424,
              y: 220,
              src: '0149.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_year = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              year_startX: 267,
              year_startY: 14,
              year_sc_array: ["0167.png","0168.png","0169.png","0170.png","0171.png","0172.png","0173.png","0174.png","0175.png","0176.png"],
              year_tc_array: ["0167.png","0168.png","0169.png","0170.png","0171.png","0172.png","0173.png","0174.png","0175.png","0176.png"],
              year_en_array: ["0167.png","0168.png","0169.png","0170.png","0171.png","0172.png","0173.png","0174.png","0175.png","0176.png"],
              year_zero: 0,
              year_space: 0,
              year_align: hmUI.align.CENTER_H,
              year_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 148,
              day_startY: 14,
              day_sc_array: ["0167.png","0168.png","0169.png","0170.png","0171.png","0172.png","0173.png","0174.png","0175.png","0176.png"],
              day_tc_array: ["0167.png","0168.png","0169.png","0170.png","0171.png","0172.png","0173.png","0174.png","0175.png","0176.png"],
              day_en_array: ["0167.png","0168.png","0169.png","0170.png","0171.png","0172.png","0173.png","0174.png","0175.png","0176.png"],
              day_zero: 1,
              day_space: 0,
              day_unit_sc: '0177.png',
              day_unit_tc: '0177.png',
              day_unit_en: '0177.png',
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_month = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 208,
              month_startY: 14,
              month_sc_array: ["0167.png","0168.png","0169.png","0170.png","0171.png","0172.png","0173.png","0174.png","0175.png","0176.png"],
              month_tc_array: ["0167.png","0168.png","0169.png","0170.png","0171.png","0172.png","0173.png","0174.png","0175.png","0176.png"],
              month_en_array: ["0167.png","0168.png","0169.png","0170.png","0171.png","0172.png","0173.png","0174.png","0175.png","0176.png"],
              month_zero: 1,
              month_space: 0,
              month_unit_sc: '0177.png',
              month_unit_tc: '0177.png',
              month_unit_en: '0177.png',
              month_align: hmUI.align.CENTER_H,
              month_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 201,
              y: 399,
              font_array: ["0016.png","0017.png","0018.png","0019.png","0020.png","0021.png","0022.png","0023.png","0024.png","0025.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 336,
              y: 230,
              font_array: ["0016.png","0017.png","0018.png","0019.png","0020.png","0021.png","0022.png","0023.png","0024.png","0025.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 301,
              y: 227,
              src: '0015.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 262,
              y: 233,
              image_array: ["0004.png","0005.png","0006.png","0007.png","0008.png","0009.png","0010.png","0011.png","0012.png","0013.png","0014.png"],
              image_length: 11,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_calorie_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 336,
              y: 201,
              font_array: ["0016.png","0017.png","0018.png","0019.png","0020.png","0021.png","0022.png","0023.png","0024.png","0025.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_calorie_current_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 306,
              y: 202,
              src: '0054.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_calorie_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 235,
              y: 206,
              image_array: ["0043.png","0044.png","0045.png","0046.png","0047.png","0048.png","0049.png","0050.png","0051.png","0052.png","0053.png"],
              image_length: 11,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 307,
              y: 173,
              src: '0066.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 336,
              y: 172,
              font_array: ["0016.png","0017.png","0018.png","0019.png","0020.png","0021.png","0022.png","0023.png","0024.png","0025.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 208,
              y: 178,
              image_array: ["0055.png","0056.png","0057.png","0058.png","0059.png","0060.png","0061.png","0062.png","0063.png","0064.png","0065.png"],
              image_length: 11,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 149,
              y: 42,
              week_en: ["36.png","37.png","38.png","39.png","40.png","41.png","42.png"],
              week_tc: ["36.png","37.png","38.png","39.png","40.png","41.png","42.png"],
              week_sc: ["36.png","37.png","38.png","39.png","40.png","41.png","42.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
              const weatherSensor = hmSensor.createSensor(hmSensor.id.WEATHER);

            normal_city_name_text = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 68,
              y: 67,
              w: 326,
              h: 30,
              text_size: 21,
              char_space: 0,
              line_space: 0,
              color: 0xFFC0C0C0,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 22,
              y: 162,
              image_array: ["0108.png","0109.png","0110.png","0111.png","0112.png","0113.png","0114.png","0115.png","0116.png","0117.png","0118.png","0119.png","0120.png","0121.png","0122.png","0123.png","0124.png","0125.png","0126.png","0127.png","0128.png","0129.png","0130.png","0131.png","0132.png","0133.png","0134.png","0135.png","0136.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_high_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 144,
              y: 204,
              w: 55,
              h: 30,
              text_size: 22,
              char_space: 0,
              line_space: 0,
              color: 0xFFFFB164,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.CENTER_V,
              unit_type: 1,
              text_style: hmUI.text_style.ELLIPSIS,
              type: hmUI.data_type.WEATHER_HIGH,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_low_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 97,
              y: 204,
              w: 55,
              h: 30,
              text_size: 22,
              char_space: 0,
              line_space: 0,
              color: 0xFF00FFFF,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.CENTER_V,
              unit_type: 1,
              text_style: hmUI.text_style.ELLIPSIS,
              type: hmUI.data_type.WEATHER_LOW,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 110,
              y: 173,
              font_array: ["0067.png","0068.png","0069.png","0070.png","0071.png","0072.png","0073.png","0074.png","0075.png","0076.png"],
              padding: false,
              h_space: 0,
              unit_sc: '0148.png',
              unit_tc: '0148.png',
              unit_en: '0148.png',
              imperial_unit_sc: '0148.png',
              imperial_unit_tc: '0148.png',
              imperial_unit_en: '0148.png',
              negative_image: '0147.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            const temperatureUnit = hmSetting.getTemperatureUnit();
            //start of ignored block
            if (temperatureUnit == 1) {
              normal_temperature_current_text_img.setProperty(hmUI.prop.MORE, {
                x: 110,
                y: 173,
                font_array: ["0067.png","0068.png","0069.png","0070.png","0071.png","0072.png","0073.png","0074.png","0075.png","0076.png"],
                padding: false,
                h_space: 0,
                unit_sc: '0148.png',
                unit_tc: '0148.png',
                unit_en: '0148.png',
                imperial_unit_sc: '0148.png',
                imperial_unit_tc: '0148.png',
                imperial_unit_en: '0148.png',
                negative_image: '0147.png',
                align_h: hmUI.align.CENTER_H,
                type: hmUI.data_type.WEATHER_CURRENT,
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
            };
            //end of ignored block

            normal_digital_clock_img_time_AmPm = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              am_x: 221,
              am_y: 168,
              am_sc_path: '0219.png',
              am_en_path: '0219.png',
              pm_x: 221,
              pm_y: 168,
              pm_sc_path: '0220.png',
              pm_en_path: '0220.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 46,
              hour_startY: 97,
              hour_array: ["0208.png","0209.png","0210.png","0211.png","0212.png","0213.png","0214.png","0215.png","0216.png","0217.png"],
              hour_zero: 1,
              hour_space: 0,
              hour_angle: 0,
              hour_unit_sc: '0218.png',
              hour_unit_tc: '0218.png',
              hour_unit_en: '0218.png',
              hour_align: hmUI.align.CENTER_H,

              minute_startX: 0,
              minute_startY: 0,
              minute_array: ["0208.png","0209.png","0210.png","0211.png","0212.png","0213.png","0214.png","0215.png","0216.png","0217.png"],
              minute_zero: 1,
              minute_space: 0,
              minute_angle: 0,
              minute_follow: 1,
              minute_unit_sc: '0218.png',
              minute_unit_tc: '0218.png',
              minute_unit_en: '0218.png',
              minute_align: hmUI.align.CENTER_H,

              second_startX: 0,
              second_startY: 0,
              second_array: ["0208.png","0209.png","0210.png","0211.png","0212.png","0213.png","0214.png","0215.png","0216.png","0217.png"],
              second_zero: 1,
              second_space: 0,
              second_angle: 0,
              second_follow: 1,
              second_align: hmUI.align.CENTER_H,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            console.log('Watch_Face.ScreenAOD');

            idle_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 219,
              y: 236,
              src: '0224.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 212,
              y: 187,
              src: '0149.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_year = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              year_startX: 267,
              year_startY: 14,
              year_sc_array: ["0167.png","0168.png","0169.png","0170.png","0171.png","0172.png","0173.png","0174.png","0175.png","0176.png"],
              year_tc_array: ["0167.png","0168.png","0169.png","0170.png","0171.png","0172.png","0173.png","0174.png","0175.png","0176.png"],
              year_en_array: ["0167.png","0168.png","0169.png","0170.png","0171.png","0172.png","0173.png","0174.png","0175.png","0176.png"],
              year_zero: 0,
              year_space: 0,
              year_align: hmUI.align.CENTER_H,
              year_is_character: false,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 148,
              day_startY: 14,
              day_sc_array: ["0167.png","0168.png","0169.png","0170.png","0171.png","0172.png","0173.png","0174.png","0175.png","0176.png"],
              day_tc_array: ["0167.png","0168.png","0169.png","0170.png","0171.png","0172.png","0173.png","0174.png","0175.png","0176.png"],
              day_en_array: ["0167.png","0168.png","0169.png","0170.png","0171.png","0172.png","0173.png","0174.png","0175.png","0176.png"],
              day_zero: 1,
              day_space: 0,
              day_unit_sc: '0177.png',
              day_unit_tc: '0177.png',
              day_unit_en: '0177.png',
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_month = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 208,
              month_startY: 14,
              month_sc_array: ["0167.png","0168.png","0169.png","0170.png","0171.png","0172.png","0173.png","0174.png","0175.png","0176.png"],
              month_tc_array: ["0167.png","0168.png","0169.png","0170.png","0171.png","0172.png","0173.png","0174.png","0175.png","0176.png"],
              month_en_array: ["0167.png","0168.png","0169.png","0170.png","0171.png","0172.png","0173.png","0174.png","0175.png","0176.png"],
              month_zero: 1,
              month_space: 0,
              month_unit_sc: '0177.png',
              month_unit_tc: '0177.png',
              month_unit_en: '0177.png',
              month_align: hmUI.align.CENTER_H,
              month_is_character: false,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_battery_current_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 163,
              y: 434,
              w: 150,
              h: 30,
              text_size: 30,
              char_space: 0,
              line_space: 0,
              color: 0xFFFFFFFF,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.CENTER_V,
              unit_type: 1,
              text_style: hmUI.text_style.ELLIPSIS,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 149,
              y: 42,
              week_en: ["36.png","37.png","38.png","39.png","40.png","41.png","42.png"],
              week_tc: ["36.png","37.png","38.png","39.png","40.png","41.png","42.png"],
              week_sc: ["36.png","37.png","38.png","39.png","40.png","41.png","42.png"],
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time_AmPm = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              am_x: 221,
              am_y: 168,
              am_sc_path: '0219.png',
              am_en_path: '0219.png',
              pm_x: 221,
              pm_y: 168,
              pm_sc_path: '0220.png',
              pm_en_path: '0220.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 113,
              hour_startY: 97,
              hour_array: ["0208.png","0209.png","0210.png","0211.png","0212.png","0213.png","0214.png","0215.png","0216.png","0217.png"],
              hour_zero: 1,
              hour_space: 0,
              hour_angle: 0,
              hour_unit_sc: '0218.png',
              hour_unit_tc: '0218.png',
              hour_unit_en: '0218.png',
              hour_align: hmUI.align.CENTER_H,

              minute_startX: 0,
              minute_startY: 0,
              minute_array: ["0208.png","0209.png","0210.png","0211.png","0212.png","0213.png","0214.png","0215.png","0216.png","0217.png"],
              minute_zero: 1,
              minute_space: 0,
              minute_angle: 0,
              minute_follow: 1,
              minute_align: hmUI.align.CENTER_H,

              show_level: hmUI.show_level.ONLY_AOD,
            });
            console.log('Watch_Face.Shortcuts');

            normal_step_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 311,
              y: 168,
              w: 148,
              h: 30,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 192,
              y: 354,
              w: 87,
              h: 70,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 296,
              y: 228,
              w: 114,
              h: 30,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sunrise_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 43,
              y: 351,
              w: 143,
              h: 30,
              type: hmUI.data_type.SUN_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_moon_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 282,
              y: 351,
              w: 137,
              h: 30,
              type: hmUI.data_type.MOON_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 13,
              y: 164,
              w: 180,
              h: 70,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_alarm_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 423,
              y: 213,
              w: 45,
              h: 53,
              type: hmUI.data_type.ALARM_CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_altitude_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 10,
              y: 273,
              w: 148,
              h: 30,
              type: hmUI.data_type.ALTITUDE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_fatBurning_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 312,
              y: 198,
              w: 106,
              h: 30,
              type: hmUI.data_type.FAT_BURNING,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            console.log('Watch_Face.Buttons');
            Button_1 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 144,
              y: 12,
              w: 172,
              h: 63,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '0221.png',
              normal_src: '0221.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'ScheduleCalScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_2 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 118,
              y: 403,
              w: 60,
              h: 60,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '0221.png',
              normal_src: '0221.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'PhoneHomeScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_3 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 289,
              y: 402,
              w: 60,
              h: 60,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '0221.png',
              normal_src: '0221.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'FindPhoneScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_4 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 203,
              y: 431,
              w: 60,
              h: 35,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '0221.png',
              normal_src: '0221.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'AppListScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_5 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 45,
              y: 92,
              w: 375,
              h: 68,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '0221.png',
              normal_src: '0221.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'WorldClockScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_6 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 400,
              y: 282,
              w: 55,
              h: 55,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '0223.png',
              normal_src: '0223.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'StopWatchScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            function scale_call() {
              console.log('scale_call()');

              console.log('Weather city name');
              let weatherData = weatherSensor.getForecastWeather();
              normal_city_name_text.setProperty(hmUI.prop.TEXT, weatherData.cityName);

            };

            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                console.log('resume_call()');
                scale_call();
              }),
            });

                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}