﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        const logger = Logger.getLogger('watchface_SashaCX75');
        //end of ignored block

        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_calorie_current_text_img = ''
        let normal_moon_image_progress_img_level = ''
        let normal_system_dnd_img = ''
        let normal_system_disconnect_img = ''
        let normal_system_clock_img = ''
        let normal_battery_text_text_img = ''
        let normal_battery_image_progress_img_level = ''
        let normal_battery_pointer_progress_img_pointer = ''
        let normal_heart_rate_text_text_img = ''
        let normal_heart_rate_image_progress_img_level = ''
        let normal_frame_animation_1 = ''
        let normal_distance_text_text_img = ''
        let normal_step_current_text_img = ''
        let normal_step_image_progress_img_level = ''
        let normal_step_pointer_progress_img_pointer = ''
        let normal_date_img_date_week_img = ''
        let normal_day_pointer_progress_date_pointer = ''
        let normal_analog_clock_pro_hour_pointer_img = ''
        let normal_analog_clock_pro_minute_pointer_img = ''
        let normal_timerUpdateSec = undefined;
        let normal_analog_clock_pro_second_pointer_img = ''
        let normal_timerUpdateSecSmooth = undefined;
        let idle_background_bg_img = ''
        let idle_analog_clock_time_pointer_minute = ''
        let idle_analog_clock_time_pointer_hour = ''
        let normal_stopwatch_jumpable_img_click = ''
        let normal_alarm_jumpable_img_click = ''
        let normal_temperature_jumpable_img_click = ''
        let normal_heart_jumpable_img_click = ''
        let normal_step_jumpable_img_click = ''
        let timeSensor = ''


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            console.log('Watch_Face.ScreenNormal');
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 466,
              h: 466,
              src: '0000.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_calorie_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 316,
              y: 271,
              font_array: ["0002.png","0003.png","0004.png","0005.png","0006.png","0007.png","0008.png","0009.png","0010.png","0011.png"],
              padding: false,
              h_space: -1,
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_moon_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 185,
              y: 299,
              image_array: ["mp_01.png","mp_02.png","mp_03.png","mp_04.png","mp_05.png","mp_06.png","mp_07.png","mp_08.png","mp_09.png","mp_10.png","mp_11.png","mp_12.png","mp_13.png","mp_14.png","mp_15.png","mp_16.png","mp_17.png","mp_18.png","mp_19.png","mp_20.png","mp_21.png","mp_22.png","mp_23.png","mp_24.png","mp_25.png","mp_26.png","mp_27.png","mp_28.png","mp_29.png","mp_30.png"],
              image_length: 30,
              type: hmUI.data_type.MOON,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_dnd_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 215,
              y: 148,
              src: '0016.png',
              type: hmUI.system_status.DISTURB,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 273,
              y: 413,
              src: '0021.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 171,
              y: 413,
              src: '0020.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 95,
              y: 200,
              font_array: ["0002.png","0003.png","0004.png","0005.png","0006.png","0007.png","0008.png","0009.png","0010.png","0011.png"],
              padding: false,
              h_space: 0,
              unit_sc: '0015.png',
              unit_tc: '0015.png',
              unit_en: '0015.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 110,
              y: 180,
              image_array: ["bt_00.png","bt_01.png","bt_02.png","bt_03.png","bt_04.png","bt_05.png","bt_06.png","bt_07.png","bt_08.png","bt_09.png","bt_10.png","bt_11.png","bt_12.png","bt_13.png","bt_14.png","bt_15.png","bt_16.png","bt_17.png","bt_18.png","bt_19.png","bt_20.png","bt_21.png","bt_22.png","bt_23.png","bt_24.png","bt_25.png","bt_26.png","bt_27.png","bt_28.png","bt_29.png","bt_30.png","bt_31.png","bt_32.png","bt_33.png","bt_34.png","bt_35.png","bt_36.png","bt_37.png","bt_38.png","bt_39.png","bt_40.png","bt_41.png","bt_42.png","bt_43.png","bt_44.png","bt_45.png","bt_46.png","bt_47.png","bt_48.png","bt_49.png","bt_50.png","bt_51.png","bt_52.png","bt_53.png","bt_54.png","bt_55.png","bt_56.png","bt_57.png","bt_58.png","bt_59.png","bt_60.png","bt_61.png","bt_62.png","bt_63.png","bt_64.png","bt_65.png","bt_66.png","bt_67.png","bt_68.png","bt_69.png","bt_70.png","bt_71.png","bt_72.png","bt_73.png","bt_74.png","bt_75.png","bt_76.png","bt_77.png","bt_78.png","bt_79.png","bt_80.png","bt_81.png","bt_82.png","bt_83.png","bt_84.png","bt_85.png","bt_86.png","bt_87.png","bt_88.png","bt_89.png","bt_90.png","bt_91.png","bt_92.png","bt_93.png","bt_94.png","bt_95.png","bt_96.png","bt_97.png","bt_98.png","bt_99.png"],
              image_length: 100,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_pointer_progress_img_pointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
              src: '0025.png',
              center_x: 118,
              center_y: 233,
              x: 11,
              y: 71,
              start_angle: -90,
              end_angle: 90,
              invalid_visible: false,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 97,
              y: 251,
              font_array: ["0002.png","0003.png","0004.png","0005.png","0006.png","0007.png","0008.png","0009.png","0010.png","0011.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 81,
              y: 253,
              image_array: ["hr_01.png","hr_02.png","hr_03.png","hr_04.png","hr_05.png","hr_06.png"],
              image_length: 6,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_frame_animation_1 = hmUI.createWidget(hmUI.widget.IMG_ANIM, {
              x: 81,
              y: 253,
              anim_path: "animation",
              anim_ext: "png",
              anim_prefix: "ani",
              anim_fps: 2,
              anim_size: 2,
              repeat_count: 0,
              anim_repeat: true,
              anim_status:hmUI.anim_status.START,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_distance_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 320,
              y: 251,
              font_array: ["0002.png","0003.png","0004.png","0005.png","0006.png","0007.png","0008.png","0009.png","0010.png","0011.png"],
              padding: false,
              h_space: 0,
              unit_sc: '0013.png',
              unit_tc: '0013.png',
              unit_en: '0013.png',
              imperial_unit_sc: '0014.png',
              imperial_unit_tc: '0014.png',
              imperial_unit_en: '0014.png',
              dot_image: '0012.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.DISTANCE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 311,
              y: 200,
              font_array: ["0002.png","0003.png","0004.png","0005.png","0006.png","0007.png","0008.png","0009.png","0010.png","0011.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 335,
              y: 176,
              image_array: ["st_00.png","st_01.png","st_02.png","st_03.png","st_04.png","st_05.png","st_06.png","st_07.png","st_08.png","st_09.png","st_10.png","st_11.png","st_12.png","st_13.png","st_14.png","st_15.png","st_16.png","st_17.png","st_18.png","st_19.png","st_20.png","st_21.png","st_22.png","st_23.png","st_24.png","st_25.png","st_26.png","st_27.png","st_28.png","st_29.png","st_30.png","st_31.png","st_32.png","st_33.png","st_34.png","st_35.png","st_36.png","st_37.png","st_38.png","st_39.png","st_40.png","st_41.png","st_42.png","st_43.png","st_44.png","st_45.png","st_46.png","st_47.png","st_48.png","st_49.png","st_50.png","st_51.png","st_52.png","st_53.png","st_54.png","st_55.png","st_56.png","st_57.png","st_58.png","st_59.png","st_60.png","st_61.png","st_62.png","st_63.png","st_64.png","st_65.png","st_66.png","st_67.png","st_68.png","st_69.png","st_70.png","st_71.png","st_72.png","st_73.png","st_74.png","st_75.png","st_76.png","st_77.png","st_78.png","st_79.png","st_80.png","st_81.png","st_82.png","st_83.png","st_84.png","st_85.png","st_86.png","st_87.png","st_88.png","st_89.png","st_90.png","st_91.png","st_92.png","st_93.png","st_94.png","st_95.png","st_96.png","st_97.png","st_98.png","st_99.png"],
              image_length: 100,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_pointer_progress_img_pointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
              src: '0025.png',
              center_x: 348,
              center_y: 233,
              x: 11,
              y: 71,
              start_angle: -90,
              end_angle: 90,
              invalid_visible: false,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 213,
              y: 366,
              week_en: ["wk-01.png","wk-02.png","wk-03.png","wk-04.png","wk-05.png","wk-06.png","wk-07.png"],
              week_tc: ["wk-01.png","wk-02.png","wk-03.png","wk-04.png","wk-05.png","wk-06.png","wk-07.png"],
              week_sc: ["wk-01.png","wk-02.png","wk-03.png","wk-04.png","wk-05.png","wk-06.png","wk-07.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_day_pointer_progress_date_pointer = hmUI.createWidget(hmUI.widget.DATE_POINTER, {
              src: '0026.png',
              center_x: 233,
              center_y: 348,
              posX: 11,
              posY: 64,
              start_angle: 0,
              end_angle: 360,
              type: hmUI.date.DAY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            const deviceInfo = hmSetting.getDeviceInfo();
            if (!timeSensor) timeSensor = hmSensor.createSensor(hmSensor.id.TIME);
            timeSensor.addEventListener(timeSensor.event.MINUTEEND, function() {
              let updateHour = timeSensor.minute == 0;

              time_update(updateHour, true);
            });

            // normal_analog_clock_pro_hour_pointer_img = hmUI.createWidget(hmUI.widget.TIME_POINTER_PRO, {
              // src: '0022.png',
              // center_x: 233,
              // center_y: 233,
              // x: 15,
              // y: 168,
              // start_angle: 0,
              // end_angle: 360,
              // type: hmUI.data_type.hour,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });


            normal_analog_clock_pro_hour_pointer_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: deviceInfo.width,
              h: deviceInfo.height,
              pos_x: 233 - 15,
              pos_y: 233 - 168,
              center_x: 233,
              center_y: 233,
              src: '0022.png',
              angle: 0,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            let screenType = hmSetting.getScreenType();
            // normal_analog_clock_pro_minute_pointer_img = hmUI.createWidget(hmUI.widget.TIME_POINTER_PRO, {
              // src: '0023.png',
              // center_x: 233,
              // center_y: 233,
              // x: 14,
              // y: 223,
              // start_angle: 0,
              // end_angle: 360,
              // type: hmUI.data_type.minute,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });


            normal_analog_clock_pro_minute_pointer_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: deviceInfo.width,
              h: deviceInfo.height,
              pos_x: 233 - 14,
              pos_y: 233 - 223,
              center_x: 233,
              center_y: 233,
              src: '0023.png',
              angle: 0,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_analog_clock_pro_second_pointer_img = hmUI.createWidget(hmUI.widget.TIME_POINTER_PRO, {
              // src: '0024.png',
              // center_x: 233,
              // center_y: 233,
              // x: 13,
              // y: 230,
              // start_angle: 0,
              // end_angle: 360,
              // type: hmUI.data_type.second,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });


            normal_analog_clock_pro_second_pointer_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: deviceInfo.width,
              h: deviceInfo.height,
              pos_x: 233 - 13,
              pos_y: 233 - 230,
              center_x: 233,
              center_y: 233,
              src: '0024.png',
              angle: 0,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_analog_clock_pro_smooth_second = hmUI.createWidget(hmUI.widget.SMOOTH_SECOND, {
              // type: 2,
              // fps: 6,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });



            console.log('Watch_Face.ScreenAOD');
            idle_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 466,
              h: 466,
              src: 'aod_01.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_analog_clock_time_pointer_minute = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              minute_path: 'aod_03.png',
              minute_centerX: 233,
              minute_centerY: 233,
              minute_posX: 14,
              minute_posY: 223,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_analog_clock_time_pointer_hour = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              hour_path: 'aod_02.png',
              hour_centerX: 233,
              hour_centerY: 233,
              hour_posX: 15,
              hour_posY: 168,
              show_level: hmUI.show_level.ONLY_AOD,
            });
            console.log('Watch_Face.Shortcuts');

            normal_stopwatch_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 183,
              y: 183,
              w: 100,
              h: 100,
              type: hmUI.data_type.STOP_WATCH,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_alarm_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 158,
              y: 399,
              w: 50,
              h: 50,
              type: hmUI.data_type.ALARM_CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 184,
              y: 296,
              w: 100,
              h: 100,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 58,
              y: 173,
              w: 120,
              h: 120,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 288,
              y: 173,
              w: 120,
              h: 120,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            //start of ignored block
            function time_update(updateHour = false, updateMinute = false) {
              console.log('time_update()');
              let hour = timeSensor.hour;
              let minute = timeSensor.minute;
              let second = timeSensor.second;
              let format_hour = timeSensor.format_hour;

              if (updateMinute) {
                let normal_hour = hour;
                let normal_fullAngle_hour = 360;
                if (normal_hour > 11) normal_hour -= 12;
                let normal_angle_hour = 0 + normal_fullAngle_hour*normal_hour/12 + (normal_fullAngle_hour/12)*minute/60;
                if (normal_analog_clock_pro_hour_pointer_img) normal_analog_clock_pro_hour_pointer_img.setProperty(hmUI.prop.ANGLE, normal_angle_hour);
              };

                let normal_fullAngle_minute = 360;
                let normal_angle_minute = 0 + normal_fullAngle_minute*(minute + second/60)/60;
                if (normal_analog_clock_pro_minute_pointer_img) normal_analog_clock_pro_minute_pointer_img.setProperty(hmUI.prop.ANGLE, normal_angle_minute);
              let normal_fullAngle_second = 360;
              let normal_angle_second = 0 + normal_fullAngle_second*(second + (timeSensor.utc % 1000)/1000)/60;
              if (normal_analog_clock_pro_second_pointer_img) normal_analog_clock_pro_second_pointer_img.setProperty(hmUI.prop.ANGLE, normal_angle_second);

            };

            //end of ignored block
            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                console.log('resume_call()');
                time_update(true, true);
                normal_frame_animation_1.setProperty(hmUI.prop.ANIM_STATUS,hmUI.anim_status.START);
                if (screenType == hmSetting.screen_type.WATCHFACE) {
                  if (!normal_timerUpdateSec) {
                    let animDelay = timeSensor.utc % 1000;
                    let animRepeat = 1000;
                    normal_timerUpdateSec = timer.createTimer(animDelay, animRepeat, (function (option) {
                      time_update(false, true);
                    }));  // end timer 
                  };  // end timer check
                };  // end screenType

                if (screenType == hmSetting.screen_type.WATCHFACE) {
                  if (!normal_timerUpdateSecSmooth) {
                    let animDelay = 0;
                    let animRepeat = 1000/6;
                    normal_timerUpdateSecSmooth = timer.createTimer(animDelay, animRepeat, (function (option) {
                      time_update(false, false);
                    }));  // end timer 
                  };  // end timer check
                };  // end screenType


              }),
              pause_call: (function () {
                console.log('pause_call()');
                normal_frame_animation_1.setProperty(hmUI.prop.ANIM_STATUS,hmUI.anim_status.STOP);
                if (normal_timerUpdateSec) {
                  timer.stopTimer(normal_timerUpdateSec);
                  normal_timerUpdateSec = undefined;
                }
                if (normal_timerUpdateSecSmooth) {
                  timer.stopTimer(normal_timerUpdateSecSmooth);
                  normal_timerUpdateSecSmooth = undefined;
                }

              }),
            });

                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}