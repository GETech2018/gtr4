﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        const logger = Logger.getLogger('watchface_SashaCX75');
        //end of ignored block

        //dynamic modify start

        
        let editBg = ''
        let normal_date_img_date_week_img = ''
        let normal_weather_image_progress_img_level = ''
        let normal_temperature_current_text_font = ''
        let normal_year_TextRotate = new Array(4);
        let normal_year_TextRotate_ASCIIARRAY = new Array(10);
        let normal_year_TextRotate_img_width = 14;
        let normal_timerTextUpdate = undefined;
        let normal_date_img_date_month_img = ''
        let normal_battery_linear_scale = ''
        let normal_battery_current_text_font = ''
        let normal_date_img_date_day = ''
        let normal_digital_clock_img_time = ''
        let idle_date_img_date_week_img = ''
        let idle_weather_image_progress_img_level = ''
        let idle_temperature_current_text_font = ''
        let idle_year_TextRotate = new Array(4);
        let idle_year_TextRotate_ASCIIARRAY = new Array(10);
        let idle_year_TextRotate_img_width = 14;
        let idle_timerTextUpdate = undefined;
        let idle_date_img_date_month_img = ''
        let idle_battery_linear_scale = ''
        let idle_battery_current_text_font = ''
        let idle_date_img_date_day = ''
        let idle_digital_clock_img_time = ''
        let timeSensor = ''


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            console.log('Watch_Face.ScreenNormal');
            editBg = hmUI.createWidget(hmUI.widget.WATCHFACE_EDIT_BG, {
              edit_id: 1002,
              x: 0,
              y: 0,
              // w: 466,
              // h: 466,
              // AOD_show: True,
              bg_config: [
                { id: 1, preview: 'bg_edit_1_preview.png', path: 'MASK.png' },
                { id: 2, preview: 'bg_edit_2_preview.png', path: 'mask2.png' },
                { id: 3, preview: 'bg_edit_3_preview.png', path: 'mask3.png' },
                { id: 4, preview: 'bg_edit_4_preview.png', path: 'mask4.png' },
                { id: 5, preview: 'bg_edit_5_preview.png', path: 'mask5.png' },
                { id: 6, preview: 'bg_edit_6_preview.png', path: 'mask6.png' },
                { id: 7, preview: 'bg_edit_7_preview.png', path: 'mask7.png' },
                { id: 8, preview: 'bg_edit_8_preview.png', path: 'mask8.png' },
                { id: 9, preview: 'bg_edit_9_preview.png', path: 'mask9.png' },
              ],
              count: 9,
              default_id: 1,
              fg: '.png',
              tips_bg: '.png',
              tips_x: 0,
              tips_y: 0,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 41,
              y: 112,
              week_en: ["m0043.png","m0044.png","m0045.png","m0046.png","m0047.png","m0048.png","m0049.png"],
              week_tc: ["m0043.png","m0044.png","m0045.png","m0046.png","m0047.png","m0048.png","m0049.png"],
              week_sc: ["m0043.png","m0044.png","m0045.png","m0046.png","m0047.png","m0048.png","m0049.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 369,
              y: 100,
              image_array: ["w_0.png","w_1.png","w_2.png","w_3.png","w_4.png","w_5.png","w_6.png","w_7.png","w_8.png","w_9.png","w_10.png","w_11.png","w_12.png","w_13.png","w_14.png","w_15.png","w_16.png","w_17.png","w_18.png","w_19.png","w_20.png","w_21.png","w_22.png","w_23.png","w_24.png","w_25.png","w_26.png","w_27.png","w_28.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 376,
              y: 156,
              w: 69,
              h: 34,
              text_size: 27,
              char_space: 0,
              line_space: 0,
              color: 0xFFFFFFFF,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.TOP,
              unit_type: 1,
              text_style: hmUI.text_style.ELLIPSIS,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_year_text_rotate_img = hmUI.createWidget(hmUI.widget.Text_Rotate, {
              // x: 67,
              // y: 181,
              // font_array: ["42.png","43.png","44.png","45.png","46.png","47.png","48.png","49.png","50.png","51.png"],
              // zero: true,
              // unit_in_alignment: false,
              // h_space: 2,
              // angle: -90,
              // align_h: hmUI.align.LEFT,
              // type: hmUI.data_type.YEAR,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_year_TextRotate_ASCIIARRAY[0] = '42.png';  // set of images with numbers
            normal_year_TextRotate_ASCIIARRAY[1] = '43.png';  // set of images with numbers
            normal_year_TextRotate_ASCIIARRAY[2] = '44.png';  // set of images with numbers
            normal_year_TextRotate_ASCIIARRAY[3] = '45.png';  // set of images with numbers
            normal_year_TextRotate_ASCIIARRAY[4] = '46.png';  // set of images with numbers
            normal_year_TextRotate_ASCIIARRAY[5] = '47.png';  // set of images with numbers
            normal_year_TextRotate_ASCIIARRAY[6] = '48.png';  // set of images with numbers
            normal_year_TextRotate_ASCIIARRAY[7] = '49.png';  // set of images with numbers
            normal_year_TextRotate_ASCIIARRAY[8] = '50.png';  // set of images with numbers
            normal_year_TextRotate_ASCIIARRAY[9] = '51.png';  // set of images with numbers

            //start of ignored block
            for (let i = 0; i < 4; i++) {
              normal_year_TextRotate[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 466,
                h: 466,
                center_x: 67,
                center_y: 181,
                pos_x: 67,
                pos_y: 181,
                angle: -90,
                src: '42.png',
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
              normal_year_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
            };
            //end of ignored block

            if (!timeSensor) timeSensor = hmSensor.createSensor(hmSensor.id.TIME);
            let screenType = hmSetting.getScreenType();
            normal_date_img_date_month_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 53,
              month_startY: 276,
              month_sc_array: ["m_1.png","m_2.png","m_3.png","m_4.png","m_5.png","m_6.png","m_7.png","m_8.png","m_9.png","m_10.png","m_11.png","m_12.png"],
              month_tc_array: ["m_1.png","m_2.png","m_3.png","m_4.png","m_5.png","m_6.png","m_7.png","m_8.png","m_9.png","m_10.png","m_11.png","m_12.png"],
              month_en_array: ["m_1.png","m_2.png","m_3.png","m_4.png","m_5.png","m_6.png","m_7.png","m_8.png","m_9.png","m_10.png","m_11.png","m_12.png"],
              month_is_character: true ,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            if (screenType != hmSetting.screen_type.AOD) {
              normal_battery_linear_scale = hmUI.createWidget(hmUI.widget.FILL_RECT);
            };

            // normal_battery_linear_scale = hmUI.createWidget(hmUI.widget.Linear_Scale, {
              // start_x: 391,
              // start_y: 288,
              // color: 0xFFC0C0C0,
              // lenght: 35,
              // line_width: 16,
              // line_cap: Flat,
              // vertical: False,
              // mirror: False,
              // inversion: False,
              // alpha: 255,
              // type: hmUI.data_type.BATTERY,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });
            
            const battery = hmSensor.createSensor(hmSensor.id.BATTERY);
            battery.addEventListener(hmSensor.event.CHANGE, function() {
              scale_call();
            });

            normal_battery_current_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 377,
              y: 311,
              w: 63,
              h: 39,
              text_size: 25,
              char_space: 0,
              line_space: 0,
              color: 0xFFFFFFFF,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.TOP,
              unit_type: 1,
              text_style: hmUI.text_style.ELLIPSIS,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 22,
              day_startY: 199,
              day_sc_array: ["wfs_0_482ad812_d31d_4a07_a060_3e7ca079aab6.png","wfs_1_2f77404e_f357_448a_af59_09531db154b7.png","wfs_2_97b8da55_b4e7_41e5_81b8_10e567e5bf96.png","wfs_3_68d4f059_c6c2_4bf4_ad22_0927fee014a7.png","wfs_4_8e67f4f7_7f54_4121_ad99_837e10ec3270.png","wfs_5_100e00cc_b781_4477_b3cc_5680f78d7921.png","wfs_6_0e501e10_2f0e_4017_b8d3_90f38a5848a4.png","wfs_7_14ef4679_7ed9_4413_bfe9_f8e6d2644f2c.png","wfs_8_125c738b_fcc2_4dd5_9da8_c7e1426202ad.png","wfs_9_a3baacf8_1c45_4c92_8e23_f47a03e7b559.png"],
              day_tc_array: ["wfs_0_482ad812_d31d_4a07_a060_3e7ca079aab6.png","wfs_1_2f77404e_f357_448a_af59_09531db154b7.png","wfs_2_97b8da55_b4e7_41e5_81b8_10e567e5bf96.png","wfs_3_68d4f059_c6c2_4bf4_ad22_0927fee014a7.png","wfs_4_8e67f4f7_7f54_4121_ad99_837e10ec3270.png","wfs_5_100e00cc_b781_4477_b3cc_5680f78d7921.png","wfs_6_0e501e10_2f0e_4017_b8d3_90f38a5848a4.png","wfs_7_14ef4679_7ed9_4413_bfe9_f8e6d2644f2c.png","wfs_8_125c738b_fcc2_4dd5_9da8_c7e1426202ad.png","wfs_9_a3baacf8_1c45_4c92_8e23_f47a03e7b559.png"],
              day_en_array: ["wfs_0_482ad812_d31d_4a07_a060_3e7ca079aab6.png","wfs_1_2f77404e_f357_448a_af59_09531db154b7.png","wfs_2_97b8da55_b4e7_41e5_81b8_10e567e5bf96.png","wfs_3_68d4f059_c6c2_4bf4_ad22_0927fee014a7.png","wfs_4_8e67f4f7_7f54_4121_ad99_837e10ec3270.png","wfs_5_100e00cc_b781_4477_b3cc_5680f78d7921.png","wfs_6_0e501e10_2f0e_4017_b8d3_90f38a5848a4.png","wfs_7_14ef4679_7ed9_4413_bfe9_f8e6d2644f2c.png","wfs_8_125c738b_fcc2_4dd5_9da8_c7e1426202ad.png","wfs_9_a3baacf8_1c45_4c92_8e23_f47a03e7b559.png"],
              day_zero: 1,
              day_space: 2,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 120,
              hour_startY: 30,
              hour_array: ["100.png","101.png","102.png","103.png","104.png","105.png","106.png","107.png","108.png","109.png"],
              hour_zero: 1,
              hour_space: 1,
              hour_angle: 0,
              hour_align: hmUI.align.CENTER_H,

              minute_startX: 120,
              minute_startY: 242,
              minute_array: ["100.png","101.png","102.png","103.png","104.png","105.png","106.png","107.png","108.png","109.png"],
              minute_zero: 1,
              minute_space: 1,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.CENTER_H,

              second_startX: 376,
              second_startY: 199,
              second_array: ["wfs_0_482ad812_d31d_4a07_a060_3e7ca079aab6.png","wfs_1_2f77404e_f357_448a_af59_09531db154b7.png","wfs_2_97b8da55_b4e7_41e5_81b8_10e567e5bf96.png","wfs_3_68d4f059_c6c2_4bf4_ad22_0927fee014a7.png","wfs_4_8e67f4f7_7f54_4121_ad99_837e10ec3270.png","wfs_5_100e00cc_b781_4477_b3cc_5680f78d7921.png","wfs_6_0e501e10_2f0e_4017_b8d3_90f38a5848a4.png","wfs_7_14ef4679_7ed9_4413_bfe9_f8e6d2644f2c.png","wfs_8_125c738b_fcc2_4dd5_9da8_c7e1426202ad.png","wfs_9_a3baacf8_1c45_4c92_8e23_f47a03e7b559.png"],
              second_zero: 1,
              second_space: 2,
              second_angle: 0,
              second_follow: 0,
              second_align: hmUI.align.CENTER_H,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            console.log('Watch_Face.ScreenAOD');

            idle_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 41,
              y: 112,
              week_en: ["m0043.png","m0044.png","m0045.png","m0046.png","m0047.png","m0048.png","m0049.png"],
              week_tc: ["m0043.png","m0044.png","m0045.png","m0046.png","m0047.png","m0048.png","m0049.png"],
              week_sc: ["m0043.png","m0044.png","m0045.png","m0046.png","m0047.png","m0048.png","m0049.png"],
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 369,
              y: 100,
              image_array: ["w_0.png","w_1.png","w_2.png","w_3.png","w_4.png","w_5.png","w_6.png","w_7.png","w_8.png","w_9.png","w_10.png","w_11.png","w_12.png","w_13.png","w_14.png","w_15.png","w_16.png","w_17.png","w_18.png","w_19.png","w_20.png","w_21.png","w_22.png","w_23.png","w_24.png","w_25.png","w_26.png","w_27.png","w_28.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_temperature_current_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 376,
              y: 156,
              w: 69,
              h: 34,
              text_size: 27,
              char_space: 0,
              line_space: 0,
              color: 0xFFFFFFFF,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.TOP,
              unit_type: 1,
              text_style: hmUI.text_style.ELLIPSIS,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            // idle_year_text_rotate_img = hmUI.createWidget(hmUI.widget.Text_Rotate, {
              // x: 67,
              // y: 181,
              // font_array: ["42.png","43.png","44.png","45.png","46.png","47.png","48.png","49.png","50.png","51.png"],
              // zero: true,
              // unit_in_alignment: false,
              // h_space: 2,
              // angle: -90,
              // align_h: hmUI.align.LEFT,
              // type: hmUI.data_type.YEAR,
              // show_level: hmUI.show_level.ONLY_AOD,
            // });

            idle_year_TextRotate_ASCIIARRAY[0] = '42.png';  // set of images with numbers
            idle_year_TextRotate_ASCIIARRAY[1] = '43.png';  // set of images with numbers
            idle_year_TextRotate_ASCIIARRAY[2] = '44.png';  // set of images with numbers
            idle_year_TextRotate_ASCIIARRAY[3] = '45.png';  // set of images with numbers
            idle_year_TextRotate_ASCIIARRAY[4] = '46.png';  // set of images with numbers
            idle_year_TextRotate_ASCIIARRAY[5] = '47.png';  // set of images with numbers
            idle_year_TextRotate_ASCIIARRAY[6] = '48.png';  // set of images with numbers
            idle_year_TextRotate_ASCIIARRAY[7] = '49.png';  // set of images with numbers
            idle_year_TextRotate_ASCIIARRAY[8] = '50.png';  // set of images with numbers
            idle_year_TextRotate_ASCIIARRAY[9] = '51.png';  // set of images with numbers

            //start of ignored block
            for (let i = 0; i < 4; i++) {
              idle_year_TextRotate[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 466,
                h: 466,
                center_x: 67,
                center_y: 181,
                pos_x: 67,
                pos_y: 181,
                angle: -90,
                src: '42.png',
                show_level: hmUI.show_level.ONLY_AOD,
              });
              idle_year_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
            };
            //end of ignored block

            idle_date_img_date_month_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 53,
              month_startY: 276,
              month_sc_array: ["m_1.png","m_2.png","m_3.png","m_4.png","m_5.png","m_6.png","m_7.png","m_8.png","m_9.png","m_10.png","m_11.png","m_12.png"],
              month_tc_array: ["m_1.png","m_2.png","m_3.png","m_4.png","m_5.png","m_6.png","m_7.png","m_8.png","m_9.png","m_10.png","m_11.png","m_12.png"],
              month_en_array: ["m_1.png","m_2.png","m_3.png","m_4.png","m_5.png","m_6.png","m_7.png","m_8.png","m_9.png","m_10.png","m_11.png","m_12.png"],
              month_is_character: true ,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            if (screenType == hmSetting.screen_type.AOD) {
              idle_battery_linear_scale = hmUI.createWidget(hmUI.widget.FILL_RECT);
            };

            // idle_battery_linear_scale = hmUI.createWidget(hmUI.widget.Linear_Scale, {
              // start_x: 391,
              // start_y: 288,
              // color: 0xFFC0C0C0,
              // lenght: 35,
              // line_width: 16,
              // line_cap: Flat,
              // vertical: False,
              // mirror: False,
              // inversion: False,
              // alpha: 255,
              // type: hmUI.data_type.BATTERY,
              // show_level: hmUI.show_level.ONLY_AOD,
            // });

            idle_battery_current_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 377,
              y: 311,
              w: 63,
              h: 39,
              text_size: 25,
              char_space: 0,
              line_space: 0,
              color: 0xFFFFFFFF,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.TOP,
              unit_type: 1,
              text_style: hmUI.text_style.ELLIPSIS,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 22,
              day_startY: 199,
              day_sc_array: ["wfs_0_482ad812_d31d_4a07_a060_3e7ca079aab6.png","wfs_1_2f77404e_f357_448a_af59_09531db154b7.png","wfs_2_97b8da55_b4e7_41e5_81b8_10e567e5bf96.png","wfs_3_68d4f059_c6c2_4bf4_ad22_0927fee014a7.png","wfs_4_8e67f4f7_7f54_4121_ad99_837e10ec3270.png","wfs_5_100e00cc_b781_4477_b3cc_5680f78d7921.png","wfs_6_0e501e10_2f0e_4017_b8d3_90f38a5848a4.png","wfs_7_14ef4679_7ed9_4413_bfe9_f8e6d2644f2c.png","wfs_8_125c738b_fcc2_4dd5_9da8_c7e1426202ad.png","wfs_9_a3baacf8_1c45_4c92_8e23_f47a03e7b559.png"],
              day_tc_array: ["wfs_0_482ad812_d31d_4a07_a060_3e7ca079aab6.png","wfs_1_2f77404e_f357_448a_af59_09531db154b7.png","wfs_2_97b8da55_b4e7_41e5_81b8_10e567e5bf96.png","wfs_3_68d4f059_c6c2_4bf4_ad22_0927fee014a7.png","wfs_4_8e67f4f7_7f54_4121_ad99_837e10ec3270.png","wfs_5_100e00cc_b781_4477_b3cc_5680f78d7921.png","wfs_6_0e501e10_2f0e_4017_b8d3_90f38a5848a4.png","wfs_7_14ef4679_7ed9_4413_bfe9_f8e6d2644f2c.png","wfs_8_125c738b_fcc2_4dd5_9da8_c7e1426202ad.png","wfs_9_a3baacf8_1c45_4c92_8e23_f47a03e7b559.png"],
              day_en_array: ["wfs_0_482ad812_d31d_4a07_a060_3e7ca079aab6.png","wfs_1_2f77404e_f357_448a_af59_09531db154b7.png","wfs_2_97b8da55_b4e7_41e5_81b8_10e567e5bf96.png","wfs_3_68d4f059_c6c2_4bf4_ad22_0927fee014a7.png","wfs_4_8e67f4f7_7f54_4121_ad99_837e10ec3270.png","wfs_5_100e00cc_b781_4477_b3cc_5680f78d7921.png","wfs_6_0e501e10_2f0e_4017_b8d3_90f38a5848a4.png","wfs_7_14ef4679_7ed9_4413_bfe9_f8e6d2644f2c.png","wfs_8_125c738b_fcc2_4dd5_9da8_c7e1426202ad.png","wfs_9_a3baacf8_1c45_4c92_8e23_f47a03e7b559.png"],
              day_zero: 1,
              day_space: 2,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 120,
              hour_startY: 30,
              hour_array: ["100.png","101.png","102.png","103.png","104.png","105.png","106.png","107.png","108.png","109.png"],
              hour_zero: 1,
              hour_space: 1,
              hour_angle: 0,
              hour_align: hmUI.align.CENTER_H,

              minute_startX: 120,
              minute_startY: 242,
              minute_array: ["100.png","101.png","102.png","103.png","104.png","105.png","106.png","107.png","108.png","109.png"],
              minute_zero: 1,
              minute_space: 1,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.CENTER_H,

              second_startX: 376,
              second_startY: 199,
              second_array: ["wfs_0_482ad812_d31d_4a07_a060_3e7ca079aab6.png","wfs_1_2f77404e_f357_448a_af59_09531db154b7.png","wfs_2_97b8da55_b4e7_41e5_81b8_10e567e5bf96.png","wfs_3_68d4f059_c6c2_4bf4_ad22_0927fee014a7.png","wfs_4_8e67f4f7_7f54_4121_ad99_837e10ec3270.png","wfs_5_100e00cc_b781_4477_b3cc_5680f78d7921.png","wfs_6_0e501e10_2f0e_4017_b8d3_90f38a5848a4.png","wfs_7_14ef4679_7ed9_4413_bfe9_f8e6d2644f2c.png","wfs_8_125c738b_fcc2_4dd5_9da8_c7e1426202ad.png","wfs_9_a3baacf8_1c45_4c92_8e23_f47a03e7b559.png"],
              second_zero: 1,
              second_space: 2,
              second_angle: 0,
              second_follow: 0,
              second_align: hmUI.align.CENTER_H,

              show_level: hmUI.show_level.ONLY_AOD,
            });

            //start of ignored block
            function text_update() {
              console.log('text_update()');

              console.log('update text rotate year_TIME');
              let valueYear = timeSensor.year;
              let normal_year_rotate_string = parseInt(valueYear).toString();

              if (screenType != hmSetting.screen_type.AOD) {
                for (var i = 1; i < 4; i++) {  // hide all symbols
                  normal_year_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                if (valueYear != null && valueYear != undefined && isFinite(valueYear) && normal_year_rotate_string.length > 0 && normal_year_rotate_string.length <= 4) {  // display data if it was possible to get it
                  let img_offset = 0;
                  
                  let index = 0;
                  for (let char of normal_year_rotate_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 4) break;
                    if (charCode >= 0 && charCode < 10) { 
                      normal_year_TextRotate[index].setProperty(hmUI.prop.POS_X, 67 + img_offset);
                      normal_year_TextRotate[index].setProperty(hmUI.prop.SRC, normal_year_TextRotate_ASCIIARRAY[charCode]);
                      normal_year_TextRotate[index].setProperty(hmUI.prop.VISIBLE, true);
                      img_offset += normal_year_TextRotate_img_width + 2;
                      index++;
                    };  // end if digit
                  };  // end char of string
                }  // end isFinite

              };

              console.log('update text rotate year_TIME');
              let idle_year_rotate_string = parseInt(valueYear).toString();

              if (screenType == hmSetting.screen_type.AOD) {
                for (var i = 1; i < 4; i++) {  // hide all symbols
                  idle_year_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                if (valueYear != null && valueYear != undefined && isFinite(valueYear) && idle_year_rotate_string.length > 0 && idle_year_rotate_string.length <= 4) {  // display data if it was possible to get it
                  let img_offset = 0;
                  
                  let index = 0;
                  for (let char of idle_year_rotate_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 4) break;
                    if (charCode >= 0 && charCode < 10) { 
                      idle_year_TextRotate[index].setProperty(hmUI.prop.POS_X, 67 + img_offset);
                      idle_year_TextRotate[index].setProperty(hmUI.prop.SRC, idle_year_TextRotate_ASCIIARRAY[charCode]);
                      idle_year_TextRotate[index].setProperty(hmUI.prop.VISIBLE, true);
                      img_offset += idle_year_TextRotate_img_width + 2;
                      index++;
                    };  // end if digit
                  };  // end char of string
                }  // end isFinite

              };

            };

            //end of ignored block
            function scale_call() {
              console.log('scale_call()');

                console.log('update scales BATTERY');
                
                let valueBattery = battery.current;
                let targetBattery = 100;
                let progressBattery = valueBattery/targetBattery;
                if (progressBattery > 1) progressBattery = 1;
                let progress_ls_normal_battery = progressBattery;

                if (screenType != hmSetting.screen_type.AOD) {

                  // normal_battery_linear_scale
                  // initial parameters
                  let start_x_normal_battery = 391;
                  let start_y_normal_battery = 288;
                  let lenght_ls_normal_battery = 35;
                  let line_width_ls_normal_battery = 16;
                  let color_ls_normal_battery = 0xFFC0C0C0;
                  
                  // calculated parameters
                  let start_x_normal_battery_draw = start_x_normal_battery;
                  let start_y_normal_battery_draw = start_y_normal_battery;
                  lenght_ls_normal_battery = lenght_ls_normal_battery * progress_ls_normal_battery;
                  let lenght_ls_normal_battery_draw = lenght_ls_normal_battery;
                  let line_width_ls_normal_battery_draw = line_width_ls_normal_battery;
                  if (lenght_ls_normal_battery < 0){
                    lenght_ls_normal_battery_draw = -lenght_ls_normal_battery;
                    start_x_normal_battery_draw = start_x_normal_battery - lenght_ls_normal_battery_draw;
                  };
                  
                  normal_battery_linear_scale.setProperty(hmUI.prop.MORE, {
                    x: start_x_normal_battery_draw,
                    y: start_y_normal_battery_draw,
                    w: lenght_ls_normal_battery_draw,
                    h: line_width_ls_normal_battery_draw,
                    color: color_ls_normal_battery,
                  });
                };

                console.log('update scales BATTERY');
                let progress_ls_idle_battery = progressBattery;

                if (screenType == hmSetting.screen_type.AOD) {

                  // idle_battery_linear_scale
                  // initial parameters
                  let start_x_idle_battery = 391;
                  let start_y_idle_battery = 288;
                  let lenght_ls_idle_battery = 35;
                  let line_width_ls_idle_battery = 16;
                  let color_ls_idle_battery = 0xFFC0C0C0;
                  
                  // calculated parameters
                  let start_x_idle_battery_draw = start_x_idle_battery;
                  let start_y_idle_battery_draw = start_y_idle_battery;
                  lenght_ls_idle_battery = lenght_ls_idle_battery * progress_ls_idle_battery;
                  let lenght_ls_idle_battery_draw = lenght_ls_idle_battery;
                  let line_width_ls_idle_battery_draw = line_width_ls_idle_battery;
                  if (lenght_ls_idle_battery < 0){
                    lenght_ls_idle_battery_draw = -lenght_ls_idle_battery;
                    start_x_idle_battery_draw = start_x_idle_battery - lenght_ls_idle_battery_draw;
                  };
                  
                  idle_battery_linear_scale.setProperty(hmUI.prop.MORE, {
                    x: start_x_idle_battery_draw,
                    y: start_y_idle_battery_draw,
                    w: lenght_ls_idle_battery_draw,
                    h: line_width_ls_idle_battery_draw,
                    color: color_ls_idle_battery,
                  });
                };

            };

            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                console.log('resume_call()');
                scale_call();
                text_update();
                if (screenType == hmSetting.screen_type.WATCHFACE) {
                  if (!normal_timerTextUpdate) {
                    normal_timerTextUpdate = timer.createTimer(0, 1000, (function (option) {
                      text_update();
                    }));  // end timer 
                  };  // end timer check
                };  // end screenType

                if (screenType == hmSetting.screen_type.AOD) {
                  if (!idle_timerTextUpdate) {
                    idle_timerTextUpdate = timer.createTimer(0, 1000, (function (option) {
                      text_update();
                    }));  // end timer 
                  };  // end timer check
                };  // end screenType


              }),
              pause_call: (function () {
                console.log('pause_call()');
                if (normal_timerTextUpdate) {
                  timer.stopTimer(normal_timerTextUpdate);
                  normal_timerTextUpdate = undefined;
                }
                if (idle_timerTextUpdate) {
                  timer.stopTimer(idle_timerTextUpdate);
                  idle_timerTextUpdate = undefined;
                }

              }),
            });

                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}