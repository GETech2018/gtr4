﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        //const logger = Logger.getLogger('watchface_SashaCX75');
        const logger = DeviceRuntimeCore.HmLogger.getLogger('watchface_SashaCX75')
        //end of ignored block

        //dynamic modify start

        
        console.log('user_functions.js');
        // start user_functions.js

/////////////////////////////////////////////////////////////////////////////////
// User functions
/////////////////////////////////////////////////////////////////////////////////

// Variables for scores
const appId = hmApp.packageInfo().appId;
let score1 = 0;
let score2 = 0;
let teamColor1Index = 0;   	// blue
let teamColor2Index = 1;	// red
let teamColors =     [0x0080FF,0xFF0000,0x00FF00,0xFFFF00,0xFF8000,0x0000FF,0XFF00FF,0x000000,0xFFFFFF,0x808080,0x804000];
let teamTextColors = [0xFFFFFF,0xFFFFFF,0x000000,0x000000,0xFFFFFF,0xFFFFFF,0xFFFFFF,0xFFFFFF,0x000000,0xFFFFFF,0xFFFFFF];


// Variables for timer
let sTimer = undefined;  // seconds
let flagTimer = false;
let secondValue = 0;
let minValue = 0;
let savedMilliSeconds = 0;

// Update team 1 color
function UpdateTeam1Color() {
	Button_6.setProperty(hmUI.prop.MORE, {
              x: 84,
              y: 76,
              w: 138,
              h: 80,	
		normal_color: teamColors[teamColor1Index],
		press_color: teamColors[teamColor1Index],
		color: teamTextColors[teamColor1Index],
	});
	console.log('teamColor1Index: ' + teamColor1Index);
}

// Set team 1 color
function Team1ColorChange() {
	if (teamColor1Index == teamColors.length-1) {
		teamColor1Index = 0;
	}
	else {
		teamColor1Index++;
	}
	hmFS.SysProSetInt(`teamColor1Index_${appId}`, teamColor1Index);	
	UpdateTeam1Color();	
}

// Update team 2 color
function UpdateTeam2Color() {
	Button_7.setProperty(hmUI.prop.MORE, {
              x: 247,
              y: 76,
              w: 138,
              h: 80,
		normal_color: teamColors[teamColor2Index],
		press_color: teamColors[teamColor2Index],
		color: teamTextColors[teamColor2Index],		
	})
}

// Set team 2 color
function Team2ColorChange() {
	if (teamColor2Index == teamColors.length-1) {
		teamColor2Index = 0;
	}
	else {
		teamColor2Index++;
	}
	hmFS.SysProSetInt(`teamColor2Index_${appId}`, teamColor2Index);	
	UpdateTeam2Color();	
}

// Update score 1
function UpdateScore1(){	
	let s;
	let t;
	t = "000" + score1.toString();
	s = t.substr(t.length - 3);
	Button_6.setProperty(hmUI.prop.MORE, {
              x: 84,
              y: 76,
              w: 138,
              h: 80,	
		text:s
	})	
	console.log('Update score1:' + score1.toString());
}

// Update score 2
function UpdateScore2(){	
	let s;
	let t;
	t = "000" + score2.toString();
	s = t.substr(t.length - 3);
	Button_7.setProperty(hmUI.prop.MORE, {
              x: 247,
              y: 76,
              w: 138,
              h: 80,
		text: s	
	})
	console.log('Update score2:' + score2.toString());
}

// Increase score 1
function Score1Inc() {
	if (score1 < 999) {
		score1++;
		hmFS.SysProSetInt(`score1_${appId}`, score1);
		UpdateScore1();
	}	
}

// Decrease score 1
function Score1Dec() {
	if (score1 > 0) {
		score1--;
		hmFS.SysProSetInt(`score1_${appId}`, score1);
		UpdateScore1();
	}	
}

// Increase score 2
function Score2Inc() {
	if (score2 < 999) {
		score2++;
		hmFS.SysProSetInt(`score2_${appId}`, score2);
		UpdateScore2();
	}		
}

// Decrease score 2
function Score2Dec() {
	if (score2 > 0) {
		score2--;
		hmFS.SysProSetInt(`score2_${appId}`, score2);
		UpdateScore2();
	}	
}

// Score reset
function ScoreReset() {
	score1 = 0;
	score2 = 0;
	hmFS.SysProSetInt(`score1_${appId}`, score1);
	hmFS.SysProSetInt(`score2_${appId}`, score2);
	UpdateScore1();
	UpdateScore2();
}

// Update seconds
function UpdateSeconds() {
	let s;
	let t;
	t = "00" + secondValue.toString();
	s = t.substr(t.length - 2);		
	normal_widget_text_3.setProperty(hmUI.prop.TEXT, s);
	//console.log('UpdateSeconds ' + secondValue.toString());
}

// Update minutes
function UpdateMinutes() {
	let s;
	let t;
	t = "000" + minValue.toString();
	s = t.substr(t.length - 3);		
	normal_widget_text_1.setProperty(hmUI.prop.TEXT, s);
}

// Increase seconds
 function setSeconds(t) {	 
    if (secondValue == 59) {
		secondValue = 0;
		setMinutes();
     }
	 else {
		secondValue++;
	}
	UpdateSeconds();
 }

// Increase minutes
function setMinutes(t) {
	if (minValue < 999) {
		minValue++;
	}
	else {
		minValue = 0;
	}
	UpdateMinutes();
}

// Timer Stop/Start
function TimerStopStart() {
	console.log('TimerStopStart');
	if (flagTimer) {
		timer.stopTimer(sTimer);
		hmFS.SysProSetInt(`seconds_${appId}`, secondValue);
		hmFS.SysProSetInt(`minutes_${appId}`, minValue);
		Button_8.setProperty(hmUI.prop.MORE, {
              x: 258,
              y: 330,
              w: 80,
              h: 80,					  
			press_src: 'play.png',
            normal_src: 'play.png'
		});
		Button_9.setProperty(hmUI.prop.VISIBLE, true);		
	}
	else {
		sTimer = timer.createTimer(1000, 1000, setSeconds, {});
		Button_8.setProperty(hmUI.prop.MORE, {
              x: 258,
              y: 330,
              w: 80,
              h: 80,				  
			press_src: 'pause.png',
            normal_src: 'pause.png'
		});
		Button_9.setProperty(hmUI.prop.VISIBLE, false);
	}
	flagTimer = !flagTimer;
}

// Timer reset
function TimerReset() {
	console.log('Timer reset');
	secondValue = 0;
	minValue = 0;
	UpdateSeconds();
	UpdateMinutes();
}

// Update elements
function UpdateElements(){	
	console.log('UpdateElements');
	
	//Retrieve score 1
	let sc1 = hmFS.SysProGetInt(`score1_${appId}`)
	if (sc1==undefined) {
	  score1 = 0;
	} 
	else {
	  score1 = sc1;
	}
	UpdateScore1();
	
	// Retrieve score 2
	let sc2 = hmFS.SysProGetInt(`score2_${appId}`)
	if (sc2==undefined) {
	  score2 = 0;
	} 
	else {
	  score2 = sc2;
	}	
	UpdateScore2();	

	// Retrieve team 1 color
	let ci1 = hmFS.SysProGetInt(`teamColor1Index_${appId}`)
	if (ci1==undefined) {
	  teamColor1Index = 0;
	} 
	else {
	  teamColor1Index = ci1;
	}	
	UpdateTeam1Color();	
	
	// Retrieve team 2 color
	let ci2 = hmFS.SysProGetInt(`teamColor2Index_${appId}`)
	if (ci2==undefined) {
	  teamColor2Index = 1;
	} 
	else {
	  teamColor2Index = ci2;
	}	
	UpdateTeam2Color();
	
	// Update seconds
	let sv = hmFS.SysProGetInt(`seconds_${appId}`);
	if (sv==undefined) {
		secondValue = 0;
	}
	else {
		secondValue = sv;
	}
	UpdateSeconds();

	// Update minutes
	let mv = hmFS.SysProGetInt(`minutes_${appId}`);
	if (mv==undefined) {
		minValue = 0;
	}
	else {
		minValue = mv;
	}	
	UpdateMinutes();	
	
	flagTimer = false;	
	
	if (minValue==0 && secondValue==0) {
		Button_9.setProperty(hmUI.prop.VISIBLE, false);
	}
	else {
		Button_9.setProperty(hmUI.prop.VISIBLE, true);
	}		
}

/////////////////////////////
// end user functions	
////////////////////////////

        // end user_functions.js

        let normal_background_bg_img = ''
        let normal_system_disconnect_img = ''
        let normal_battery_image_progress_img_progress = ''
        let normal_time_hour_min_sec_text_font = ''
        let normal_timerTimeUpdate = undefined;
        let normal_widget_text_1 = ''
        let normal_widget_text_2 = ''
        let normal_widget_text_3 = ''
        let normal_widget_text_4 = ''
        let idle_time_hour_min_sec_text_font = ''
        let idle_timerTimeUpdate = undefined;
        let Button_1 = ''
        let Button_2 = ''
        let Button_3 = ''
        let Button_4 = ''
        let Button_5 = ''
        let Button_6 = ''
        let Button_7 = ''
        let Button_8 = ''
        let Button_9 = ''
        let timeSensor = '';


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            console.log('Watch_Face.ScreenNormal');
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 466,
              h: 466,
              src: 'fond.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 401,
              y: 281,
              src: 'bt_off.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_image_progress_img_progress = hmUI.createWidget(hmUI.widget.IMG_PROGRESS, {
              x: [100,100,100,100,100],
              y: [405,405,405,405,405],
              image_array: ["Batt1.png","Batt2.png","Batt3.png","Batt4.png","Batt5.png"],
              image_length: 5,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            if (!timeSensor) timeSensor = hmSensor.createSensor(hmSensor.id.TIME);
            let screenType = hmSetting.getScreenType();
            normal_time_hour_min_sec_text_font = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 154,
              y: 11,
              w: 158,
              h: 50,
              text_size: 35,
              char_space: 0,
              color: 0xFFFFFFFF,
              line_space: 0,
              align_v: hmUI.align.BOTTOM,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.CENTER_H,
              // padding: true,
              // unit_end: 2,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_widget_text_1 = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 91,
              y: 247,
              w: 130,
              h: 90,
              text_size: 70,
              char_space: 0,
              color: 0xFFFFFFFF,
              line_space: 0,
              align_v: hmUI.align.BOTTOM,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.CENTER_H,
              text: '000',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_widget_text_2 = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 223,
              y: 247,
              w: 20,
              h: 90,
              text_size: 70,
              char_space: 0,
              color: 0xFFFFFFFF,
              line_space: 0,
              align_v: hmUI.align.BOTTOM,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.CENTER_H,
              text: ':',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_widget_text_3 = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 246,
              y: 247,
              w: 83,
              h: 90,
              text_size: 70,
              char_space: 0,
              color: 0xFFFF8C00,
              line_space: 0,
              align_v: hmUI.align.BOTTOM,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.CENTER_H,
              text: '00',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_widget_text_4 = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 223,
              y: 76,
              w: 22,
              h: 80,
              text_size: 60,
              char_space: 0,
              color: 0xFFFFFFFF,
              line_space: 0,
              align_v: hmUI.align.BOTTOM,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.CENTER_H,
              text: '-',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            console.log('Watch_Face.ScreenAOD');

            idle_time_hour_min_sec_text_font = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 128,
              y: 205,
              w: 209,
              h: 55,
              text_size: 45,
              char_space: 0,
              color: 0xFFFFFFFF,
              line_space: 0,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.CENTER_H,
              // padding: true,
              // unit_end: 2,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            console.log('Watch_Face.Buttons');
            Button_1 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 353,
              y: 164,
              w: 90,
              h: 80,
              text: '+',
              color: 0xFFFFFFFF,
              text_size: 40,
              radius: 12,
              press_color: 0xFFA0A0A0,
              normal_color: 0xFFA0A0A0,
              click_func: (button_widget) => {
                Score2Inc()
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_2 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 275,
              y: 164,
              w: 70,
              h: 80,
              text: '-',
              color: 0xFFFFFFFF,
              text_size: 40,
              radius: 12,
              press_color: 0xFFA0A0A0,
              normal_color: 0xFFA0A0A0,
              click_func: (button_widget) => {
                Score2Dec()
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_3 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 25,
              y: 164,
              w: 90,
              h: 80,
              text: '+',
              color: 0xFFFFFFFF,
              text_size: 40,
              radius: 12,
              press_color: 0xFFA0A0A0,
              normal_color: 0xFFA0A0A0,
              click_func: (button_widget) => {
                Score1Inc()
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_4 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 123,
              y: 164,
              w: 70,
              h: 80,
              text: '-',
              color: 0xFFFFFFFF,
              text_size: 40,
              radius: 12,
              press_color: 0xFFA0A0A0,
              normal_color: 0xFFA0A0A0,
              click_func: (button_widget) => {
                Score1Dec()
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_5 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 200,
              y: 164,
              w: 70,
              h: 80,
              text: '0 0',
              color: 0xFFFFFFFF,
              text_size: 25,
              radius: 12,
              press_color: 0xFFFFFFFF,
              normal_color: 0xFFA0A0A0,
              click_func: (button_widget) => {
                ScoreReset()
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_6 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 84,
              y: 76,
              w: 138,
              h: 80,
              text: '000',
              color: 0xFFFFFFFF,
              text_size: 60,
              radius: 12,
              press_color: 0xFF0080FF,
              normal_color: 0xFF0080FF,
              click_func: (button_widget) => {
                Team1ColorChange()
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_7 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 247,
              y: 76,
              w: 138,
              h: 80,
              text: '000',
              color: 0xFFFFFFFF,
              text_size: 60,
              radius: 12,
              press_color: 0xFFFF0000,
              normal_color: 0xFFFF0000,
              click_func: (button_widget) => {
                Team2ColorChange()
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_8 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 258,
              y: 330,
              w: 80,
              h: 80,
              text: '',
              color: 0xFF000000,
              text_size: 10,
              press_src: 'play.png',
              normal_src: 'play.png',
              // vibro: True,
              click_func: (button_widget) => {
                TimerStopStart()
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_9 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 128,
              y: 330,
              w: 80,
              h: 80,
              text: '',
              color: 0xFF000000,
              text_size: 35,
              press_src: 'reset.png',
              normal_src: 'reset.png',
              // vibro: True,
              click_func: (button_widget) => {
                TimerReset()
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            console.log('user_script_end.js');
            // start user_script_end.js

			UpdateElements();
            // end user_script_end.js

            //#region time_update
            function time_update(updateHour = false, updateMinute = false) {
              console.log('time_update()');
              let hour = timeSensor.hour;
              let minute = timeSensor.minute;
              let second = timeSensor.second;
              let format_hour = timeSensor.format_hour;

              console.log('hour:min:sec font');
              let normal_HourMinSecStr = format_hour.toString();
              normal_HourMinSecStr = normal_HourMinSecStr.padStart(2, '0');
              normal_HourMinSecStr = normal_HourMinSecStr + ':' + minute.toString().padStart(2, '0') + ':' + second.toString().padStart(2, '0');
              normal_time_hour_min_sec_text_font.setProperty(hmUI.prop.TEXT, normal_HourMinSecStr );
              console.log('hour:min:sec font');
              let idle_HourMinSecStr = format_hour.toString();
              idle_HourMinSecStr = idle_HourMinSecStr.padStart(2, '0');
              idle_HourMinSecStr = idle_HourMinSecStr + ':' + minute.toString().padStart(2, '0') + ':' + second.toString().padStart(2, '0');
              idle_time_hour_min_sec_text_font.setProperty(hmUI.prop.TEXT, idle_HourMinSecStr );
            };

            //#endregion
            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                console.log('resume_call()');
                time_update(true, true);
                if (screenType == hmSetting.screen_type.WATCHFACE) {
                  if (!normal_timerTimeUpdate) {
                    normal_timerTimeUpdate = timer.createTimer(0, 1000, (function (option) {
                      let updateHour = timeSensor.minute == 0 && timeSensor.second < 2;
                      let updateMinute = timeSensor.second < 2;
                      time_update(updateHour, updateMinute);
                    }));  // end timer 
                  };  // end timer check
                };  // end screenType

                if (screenType == hmSetting.screen_type.AOD) {
                  if (!idle_timerTimeUpdate) {
                    idle_timerTimeUpdate = timer.createTimer(0, 1000, (function (option) {
                      let updateHour = timeSensor.minute == 0 && timeSensor.second < 2;
                      let updateMinute = timeSensor.second < 2;
                      time_update(updateHour, updateMinute);
                    }));  // end timer 
                  };  // end timer check
                };  // end screenType


                console.log('resume_call.js');
                // start resume_call.js

				// ajust time spent since last page change
				if (screenType == hmSetting.screen_type.WATCHFACE) {
					if (flagTimer) {							
						let secondsSpent = Math.trunc((Date.now()  - savedMilliSeconds)/1000);						
						minValue = Math.trunc((minValue*60 + secondValue + secondsSpent) / 60)%1000;
						secondValue = (secondValue + secondsSpent)%60;										
						UpdateSeconds();
						UpdateMinutes();								
					}
				}
                // end resume_call.js

              }),
              pause_call: (function () {
                console.log('pause_call()');
                if (normal_timerTimeUpdate) {
                  timer.stopTimer(normal_timerTimeUpdate);
                  normal_timerTimeUpdate = undefined;
                }
                if (idle_timerTimeUpdate) {
                  timer.stopTimer(idle_timerTimeUpdate);
                  idle_timerTimeUpdate = undefined;
                }

                console.log('pause_call.js');
                // start pause_call.js

				// save current time
				savedMilliSeconds = Date.now();
                // end pause_call.js

              }),
            });

                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}