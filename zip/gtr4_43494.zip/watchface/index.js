﻿    /*
     ** Watch_Face_Editor tool
     ** watchface js version v2.1.1
     ** Copyright © SashaCX75. All Rights Reserved
     */

    try {
     (() => {
      //start of ignored block
      const __$$app$$__ = __$$hmAppManager$$__.currentApp;

      function getApp() {
       return __$$app$$__.app;
      }

      function getCurrentPage() {
       return __$$app$$__.current && __$$app$$__.current.module;
      }
      const __$$module$$__ = __$$app$$__.current;
      const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
      const {
       px
      } = __$$app$$__.__globals__;
      //const logger = Logger.getLogger('watchface_SashaCX75');
      const logger = DeviceRuntimeCore.HmLogger.getLogger('watchface_SashaCX75')
      //end of ignored block

      //dynamic modify start


      console.log('user_functions.js');
      // start user_functions.js

      let normal_weather_s_image_progress_img_level = '';
      let idle_weather_s_image_progress_img_level = '';
      let weather = hmSensor.createSensor(hmSensor.id.WEATHER);

      function loadSettings() {

       tap_centr = hmFS.SysProGetInt('RS_London_II_tap_centr') === undefined ? (hmFS.SysProSetInt('RS_London_II_tap_centr', 0), 0) : hmFS.SysProGetInt('RS_London_II_tap_centr');
       tap_up = hmFS.SysProGetInt('RS_London_II_tap_up') === undefined ? (hmFS.SysProSetInt('RS_London_II_tap_up', 0), 0) : hmFS.SysProGetInt('RS_London_II_tap_up');
       tap_dw = hmFS.SysProGetInt('RS_London_II_tap_dw') === undefined ? (hmFS.SysProSetInt('RS_LondonRS_London_II_tap_dw_II_tap_up', 0), 0) : hmFS.SysProGetInt('RS_London_II_tap_dw');

      }

      let tap_centr = 0;

      function clik_tap_centr() {
       tap_centr = (tap_centr + 1) % 2
       hmFS.SysProSetInt('RS_London_II_tap_centr', tap_centr);
		  
		  
        normal_temperature_low_text_font.setProperty(hmUI.prop.VISIBLE, (tap_up == 1 && tap_centr == 1) ? true : false);		               
        normal_temperature_high_text_font.setProperty(hmUI.prop.VISIBLE, (tap_up == 1 && tap_centr == 1) ? true : false);		               
       
        normal_battery_pointer_progress_img_pointer.setProperty(hmUI.prop.MORE, {
         src: tap_dw == 0 ? 'str_bat.png' : 'str_bat_1.png',
         center_x: (tap_dw == 1 || tap_centr == 0) ? 339 : 999,
         center_y: 233,
         x: 7,
         y: 26,
         start_angle: -150,
         end_angle: 150,
         invalid_visible: false,
         type: hmUI.data_type.BATTERY,
         show_level: hmUI.show_level.ONLY_NORMAL,
        });
        
         normal_heart_rate_pointer_progress_img_pointer.setProperty(hmUI.prop.MORE, {
         src: tap_dw == 0 ? 'str_bat.png' : 'str_bat_1.png',
         center_x:  (tap_dw == 1 || tap_centr == 0) ? 129 : -999,
         center_y: 233,
         x: 7,
         y: 26,
         start_angle: -150,
         end_angle: 150,
         invalid_visible: false,
         type: hmUI.data_type.HEART,
         show_level: hmUI.show_level.ONLY_NORMAL,
        });       
       
       
        norma_tap_alarm_icon_img.setProperty(hmUI.prop.VISIBLE, (tap_dw == 0 && tap_centr == 1) ? true : false);		   
        normal_tap_timer_icon_img.setProperty(hmUI.prop.VISIBLE, (tap_dw == 0 && tap_centr == 1) ? true : false);	
        
        Button_4.setProperty(hmUI.prop.VISIBLE, (tap_dw == 0 && tap_centr == 1) ? true : false);		            
        Button_5.setProperty(hmUI.prop.VISIBLE, (tap_dw == 0 && tap_centr == 1) ? true : false);	        	         
        	         	         	         
       
       normal_analog_clock_time_pointer_hour.setProperty(hmUI.prop.VISIBLE, tap_centr == 0 ? true : false);
       normal_analog_clock_time_pointer_minute.setProperty(hmUI.prop.VISIBLE, tap_centr == 0 ? true : false);
       normal_analog_clock_time_pointer_second.setProperty(hmUI.prop.VISIBLE, tap_centr == 0 ? true : false);
       idle_analog_clock_time_pointer_hour.setProperty(hmUI.prop.VISIBLE, tap_centr == 0 ? true : false);
       idle_analog_clock_time_pointer_minute.setProperty(hmUI.prop.VISIBLE, tap_centr == 0 ? true : false);
       //  idle_analog_clock_pro_second_pointer_img.setProperty(hmUI.prop.VISIBLE, tap_centr == 0 ? true : false);

       normal_stand_icon_img.setProperty(hmUI.prop.ALPHA, (tap_dw == 1 || tap_centr == 0) ? 255 : 128);
       vibro();
      }

      let tap_up = 0;

      function clik_tap_up() {
       tap_up = (tap_up + 1) % 2
       hmFS.SysProSetInt('RS_London_II_tap_up', tap_up);
		  
        normal_temperature_low_text_font.setProperty(hmUI.prop.VISIBLE, (tap_up == 1 && tap_centr == 1) ? true : false);		               
        normal_temperature_high_text_font.setProperty(hmUI.prop.VISIBLE, (tap_up == 1 && tap_centr == 1) ? true : false);		               
		  
		  
       normal_temperature_icon_img_A.setProperty(hmUI.prop.VISIBLE, (tap_dw == 1 && tap_up == 0) ? true : false);

       normal_weather_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, tap_up == 0 ? true : false);
       normal_weather_s_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, tap_up == 1 ? true : false);
       normal_temperature_icon_img.setProperty(hmUI.prop.VISIBLE, tap_up == 0 ? true : false);

       if (screenType == hmSetting.screen_type.AOD) {
        idle_weather_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, tap_up == 0 ? true : false);
        idle_temperature_icon_img.setProperty(hmUI.prop.VISIBLE, tap_up == 0 ? true : false);
        idle_temperature_icon_img_A.setProperty(hmUI.prop.VISIBLE, tap_up == 0 ? true : false);
       }


       vibro();
      }

      let tap_dw = 0;

      function clik_tap_dw() {
       tap_dw = (tap_dw + 1) % 2
       hmFS.SysProSetInt('RS_London_II_tap_dw', tap_dw);
		  
normal_temperature_low_text_font.setAlpha(tap_dw == 0 ? 255: 179);
normal_temperature_high_text_font.setAlpha(tap_dw == 0 ? 255: 179);	
		  
            normal_moon_image_progress_img_level.setAlpha(tap_dw == 0 ? 255: 179);

       normal_battery_circle_scale_bg.setProperty(hmUI.prop.COLOR, tap_dw == 0 ? 0x4d8f75 : 0x408080);
       normal_heart_rate_circle_scale_2_bg.setProperty(hmUI.prop.COLOR, tap_dw == 0 ? 0x4d8f75 : 0x408080);

        norma_tap_alarm_icon_img.setProperty(hmUI.prop.VISIBLE, (tap_dw == 0 && tap_centr == 1) ? true : false);		   
        normal_tap_timer_icon_img.setProperty(hmUI.prop.VISIBLE, (tap_dw == 0 && tap_centr == 1) ? true : false);	
        
        Button_4.setProperty(hmUI.prop.VISIBLE, (tap_dw == 0 && tap_centr == 1) ? true : false);		            
        Button_5.setProperty(hmUI.prop.VISIBLE, (tap_dw == 0 && tap_centr == 1) ? true : false);	        	         
        	         	         	         


       normal_battery_circle_scale.setProperty(hmUI.prop.MORE, {
        center_x: 338,
        center_y: 233,
        start_angle: -151,
        end_angle: 151,
        radius: 38,
        line_width: 50,
        corner_flag: 3,
        type: hmUI.data_type.BATTERY,
        color: tap_dw == 0 ? 0xFF80FFFF : 0xFF00FF9B,
        show_level: hmUI.show_level.ONLY_NORMAL,
       });

       normal_heart_rate_circle_scale_2.setProperty(hmUI.prop.MORE, {
        center_x: 129,
        center_y: 233,
        start_angle: -151,
        end_angle: 151,
        radius: 38,
        line_width: 50,
        corner_flag: 3,
        type: hmUI.data_type.HEART,
        color: tap_dw == 0 ? 0xFF80FFFF : 0xFF00FF9B,
        // mirror: False,
        show_level: hmUI.show_level.ONLY_NORMAL,
       });


       normal_stand_icon_img.setProperty(hmUI.prop.ALPHA, (tap_dw == 1 || tap_centr == 0) ? 255 : 128);


       normal_temperature_icon_img_A.setProperty(hmUI.prop.VISIBLE, (tap_dw == 1 && tap_up == 0) ? true : false);

       normal_system_disconnect_img_0.setProperty(hmUI.prop.VISIBLE, tap_dw == 0 ? true : false);
       normal_system_disconnect_img_1.setProperty(hmUI.prop.VISIBLE, tap_dw == 1 ? true : false);

       normal_SUN_CURRENT_PROGRESS.setProperty(hmUI.prop.SRC, tap_dw == 0 ? 'str_sun.png' : 'str_sun_1.png');


       normal_weather_s_image_progress_img_level.setProperty(hmUI.prop.MORE, {
        x: 321,
        y: 114,
        image_array: tap_dw == 0 ? ["ws_0.png", "ws_1.png", "ws_2.png", "ws_3.png", "ws_4.png", "ws_5.png", "ws_6.png", "ws_7.png", "ws_8.png", "ws_9.png", "ws_10.png", "ws_11.png", "ws_12.png", "ws_13.png", "ws_14.png", "ws_15.png", "ws_16.png", "ws_17.png", "ws_18.png", "ws_19.png", "ws_20.png", "ws_21.png", "ws_22.png", "ws_23.png", "ws_24.png", "ws_25.png", "ws_26.png", "ws_27.png", "ws_28.png"] : ["wsa_0.png", "wsa_1.png", "wsa_2.png", "wsa_3.png", "wsa_4.png", "wsa_5.png", "wsa_6.png", "wsa_7.png", "wsa_8.png", "wsa_9.png", "wsa_10.png", "wsa_11.png", "wsa_12.png", "wsa_13.png", "wsa_14.png", "wsa_15.png", "wsa_16.png", "wsa_17.png", "wsa_18.png", "wsa_19.png", "wsa_20.png", "wsa_21.png", "wsa_22.png", "wsa_23.png", "wsa_24.png", "wsa_25.png", "wsa_26.png", "wsa_27.png", "wsa_28.png"],
        image_length: 29,
        type: hmUI.data_type.WEATHER_CURRENT,
        show_level: hmUI.show_level.ONLY_NORMAL,
       });
       
       
        normal_battery_pointer_progress_img_pointer.setProperty(hmUI.prop.MORE, {
         src: tap_dw == 0 ? 'str_bat.png' : 'str_bat_1.png',
         center_x:  (tap_dw == 1 || tap_centr == 0) ? 339 : 999,
         center_y: 233,
         x: 7,
         y: 26,
         start_angle: -150,
         end_angle: 150,
         invalid_visible: false,
         type: hmUI.data_type.BATTERY,
         show_level: hmUI.show_level.ONLY_NORMAL,
        });
        
         normal_heart_rate_pointer_progress_img_pointer.setProperty(hmUI.prop.MORE, {
         src: tap_dw == 0 ? 'str_bat.png' : 'str_bat_1.png',
         center_x:  (tap_dw == 1 || tap_centr == 0) ? 129 : -999,
         center_y: 233,
         x: 7,
         y: 26,
         start_angle: -150,
         end_angle: 150,
         invalid_visible: false,
         type: hmUI.data_type.HEART,
         show_level: hmUI.show_level.ONLY_NORMAL,
        });       

       normal_analog_clock_time_pointer_hour.setProperty(hmUI.prop.MORE, {
        hour_path: tap_dw == 0 ? 'str_h.png' : 'str_h_1.png',
        hour_centerX: 233,
        hour_centerY: 233,
        hour_posX: 25,
        hour_posY: 127,
        show_level: hmUI.show_level.ONLY_NORMAL,
       });

       normal_analog_clock_time_pointer_minute.setProperty(hmUI.prop.MORE, {
        minute_path: tap_dw == 0 ? 'str_m.png' : 'str_m_1.png',
        minute_centerX: 233,
        minute_centerY: 233,
        minute_posX: 27,
        minute_posY: 217,
        show_level: hmUI.show_level.ONLY_NORMAL,
       });

       normal_stand_icon_img.setProperty(hmUI.prop.SRC, tap_dw == 0 ? 'bezel_0.png' : 'bezel_2.png');
       normal_image_img.setProperty(hmUI.prop.SRC, tap_dw == 0 ? 'bg_0.png' : 'bg_1.png');


       normal_time_hour_min_text_font.setProperty(hmUI.prop.COLOR, tap_dw == 0 ? 0xFFFFFFFF : 0xFF00FF9B);


       normal_time_second_text_font.setProperty(hmUI.prop.COLOR, tap_dw == 0 ? 0xFFFFFFFF : 0xFF00FF9B);

       normal_step_current_text_font.setProperty(hmUI.prop.MORE, {
        x: 0,
        y: 267,
        w: 466,
        h: 50,
        text_size: 31,
        char_space: 0,
        line_space: 0,
        font: 'fonts/Eurostile-Regular.ttf',
        color: tap_dw == 0 ? 0xFFFFFFFF : 0xFF00FF9B,
        align_h: hmUI.align.CENTER_H,
        align_v: hmUI.align.CENTER_V,
        text_style: hmUI.text_style.ELLIPSIS,
        type: hmUI.data_type.STEP,
        show_level: hmUI.show_level.ONLY_NORMAL,
       });

       normal_battery_current_text_font.setProperty(hmUI.prop.MORE, {
        x: 264,
        y: 260,
        w: 150,
        h: 30,
        text_size: 21,
        char_space: 0,
        line_space: 0,
        font: 'fonts/IBMPlexSansCondensed_Medium.ttf',
        color: tap_dw == 0 ? 0xFFFFFFFF : 0xFF00FF9B,
        align_h: hmUI.align.CENTER_H,
        align_v: hmUI.align.CENTER_V,
        text_style: hmUI.text_style.ELLIPSIS,
        type: hmUI.data_type.BATTERY,
        show_level: hmUI.show_level.ONLY_NORMAL,
       });

       normal_heart_rate_text_font.setProperty(hmUI.prop.MORE, {
        x: 55,
        y: 260,
        w: 150,
        h: 30,
        text_size: 21,
        char_space: 0,
        line_space: 0,
        font: 'fonts/IBMPlexSansCondensed_Medium.ttf',
        color: tap_dw == 0 ? 0xFFFFFFFF : 0xFF00FF9B,
        align_h: hmUI.align.CENTER_H,
        align_v: hmUI.align.CENTER_V,
        text_style: hmUI.text_style.ELLIPSIS,
        type: hmUI.data_type.HEART,
        show_level: hmUI.show_level.ONLY_NORMAL,
       });

       normal_dow_text_font.setProperty(hmUI.prop.COLOR, tap_dw == 0 ? 0xFFFFFFFF : 0xFF00FF9B);
       normal_day_text_font.setProperty(hmUI.prop.COLOR, tap_dw == 0 ? 0xFFFFFFFF : 0xFF00FF9B);

       normal_alarm_clock_current_text_font.setProperty(hmUI.prop.MORE, {
        x: 44,
        y: 314,
        w: 150,
        h: 30,
        text_size: 20,
        char_space: 0,
        line_space: 0,
        font: 'fonts/Eurostile-Regular.ttf',
        color: tap_dw == 0 ? 0xFFFFFFFF : 0xFF00FF9B,
        align_h: hmUI.align.CENTER_H,
        align_v: hmUI.align.CENTER_V,
        padding: true,
        text_style: hmUI.text_style.ELLIPSIS,
        type: hmUI.data_type.ALARM_CLOCK,
        show_level: hmUI.show_level.ONLY_NORMAL,
       });

       normal_city_name_text.setProperty(hmUI.prop.COLOR, tap_dw == 0 ? 0xFFFFFFFF : 0xFF00FF9B);

       normal_temperature_current_text_font.setProperty(hmUI.prop.MORE, {
        x: 123,
        y: 113,
        w: 150,
        h: 30,
        text_size: 25,
        char_space: 0,
        line_space: 0,
        color: tap_dw == 0 ? 0xFFFFFFFF : 0xFF00FF9B,
        align_h: hmUI.align.LEFT,
        align_v: hmUI.align.CENTER_V,
        text_style: hmUI.text_style.ELLIPSIS,
        type: hmUI.data_type.WEATHER_CURRENT,
        show_level: hmUI.show_level.ONLY_NORMAL,
       });

       normal_month_name_font.setProperty(hmUI.prop.COLOR, tap_dw == 0 ? 0xFFFFFFFF : 0xFF00FF9B);

       vibro();
      }
      const vibrate = hmSensor.createSensor(hmSensor.id.VIBRATE)
      let stopVibro_Timer = null;

      function vibro(scene = 25) {
       //let stopDelay = 50;
       vibrate.stop();
       vibrate.scene = scene;
       vibrate.start();
      }

      function stopVibro() {
       vibrate.stop();
       timer.stopTimer(stopVibro_Timer);
      }

      let weatherData = weather.getForecastWeather();
      let sunData = weatherData.tideData;
      let today = '';
      let sunriseMins = '';
      let sunsetMins = '';
      let sunriseMins_def = 8 * 60; // время восхода
      let sunsetMins_def = 20 * 60; // и заката по умолчанию
      let curMins = '';
      let normal_SUN_CURRENT_PROGRESS = '';
      let idle_SUN_CURRENT_PROGRESS = '';
      let isDayIcons = true;

      const screenType = hmSetting.getScreenType();

      function autoToggleWeatherIcons() {

       weatherData = weather.getForecastWeather();
       sunData = weatherData.tideData;
       if (sunData.count > 0) {
        today = sunData.data[0];
        sunriseMins = today.sunrise.hour * 60 + today.sunrise.minute;
        sunsetMins = today.sunset.hour * 60 + today.sunset.minute;
       } else {
        sunriseMins = sunriseMins_def;
        sunsetMins = sunsetMins_def;
       }

       curMins = timeSensor.hour * 60 + timeSensor.minute;
       let isDayNow = (curMins >= sunriseMins) && (curMins < sunsetMins);

       if (isDayNow) {
        if (!isDayIcons) {
         isDayIcons = true;
        }
       } else {
        if (isDayIcons) {
         isDayIcons = false;
        }

       }

//       normal_sun_low_text_font.setProperty(hmUI.prop.VISIBLE, isDayIcons);
//       normal_sun_high_text_font.setProperty(hmUI.prop.VISIBLE, !isDayIcons);


       let sunAngle;
       if (isDayNow) {
        // Расчет для дня
        sunAngle = 90 + 180 * (curMins - sunriseMins) / (sunsetMins - sunriseMins);
       } else {
        // Расчет для ночи
        const nightDuration = (24 * 60 - sunsetMins) + sunriseMins;
        let timeFromSunset;

        if (curMins >= sunsetMins) {
         // После заката до полуночи
         timeFromSunset = curMins - sunsetMins;
        } else {
         // После полуночи до восхода
         timeFromSunset = (24 * 60 - sunsetMins) + curMins;
        }
        sunAngle = 270 + 180 * (timeFromSunset / nightDuration);
       }

       normal_SUN_CURRENT_PROGRESS.setProperty(hmUI.prop.ANGLE, sunAngle);
       if (screenType == hmSetting.screen_type.AOD) {
        idle_SUN_CURRENT_PROGRESS.setProperty(hmUI.prop.ANGLE, sunAngle);
        idle_sun_low_text_font.setProperty(hmUI.prop.VISIBLE, isDayIcons);
        idle_sun_high_text_font.setProperty(hmUI.prop.VISIBLE, !isDayIcons);
       }; // end screenType
      }

      // end user_functions.js

      let normal_background_bg = ''
      let normal_sun_icon_img = ''
      let normal_sun_low_text_font = ''
      let normal_sun_high_text_font = ''
      let normal_image_img = ''
      let normal_time_hour_min_text_font = ''
      let normal_timerTimeUpdate = undefined;
      let normal_time_second_text_font = ''
      let normal_step_current_text_font = ''
      let normal_battery_pointer_progress_img_pointer = ''
      let normal_battery_current_text_font = ''
      // let normal_heart_rate_icon_img = ''
      let normal_heart_rate_pointer_progress_img_pointer = ''
      let normal_heart_rate_text_font = ''
      let normal_dow_text_font = ''
      let normal_DOW_Array = ['ПОНЕДЕЛЬНИК', 'ВТОРНИК', 'СРЕДА', 'ЧЕТВЕРГ', 'ПЯТНИЦА', 'СУББОТА', 'ВОСКРЕСЕНЬЕ'];
      let normal_day_text_font = ''
      let normal_alarm_clock_current_text_font = ''
      let normal_system_disconnect_img_0 = ''
      let normal_system_disconnect_img_1 = ''
      let normal_city_name_text = ''
        let normal_temperature_low_text_font = ''
        let normal_temperature_high_text_font = ''
        let normal_moon_image_progress_img_level = ''
      let normal_temperature_current_text_font = ''
      let normal_weather_image_progress_img_level = ''
      let normal_temperature_icon_img_A = ''
      let normal_temperature_icon_img = ''
      let normal_stand_icon_img = ''
      let normal_month_pointer_progress_date_pointer = ''
      let normal_month_name_font = ''
      let normal_Month_Array = ['ЯНВ', 'ФЕВ', 'МАР', 'АПР', 'МАЙ', 'ИЮН', 'ИЮЛ', 'АВГ', 'СЕН', 'ОКТ', 'НОЯ', 'ДЕК', ];
      let normal_analog_clock_time_pointer_hour = ''
      let normal_analog_clock_time_pointer_minute = ''
      let normal_analog_clock_time_pointer_second = ''
      let normal_timerUpdateSec = undefined;
      let idle_background_bg = ''
      let idle_sun_icon_img = ''
      let idle_sun_high_text_font = ''
      let idle_sun_low_text_font = ''
      let idle_image_img = ''
      let idle_time_hour_min_text_font = ''
      let idle_timerTimeUpdate = undefined;
      let idle_time_second_text_font = ''
      let idle_step_current_text_font = ''
      let idle_battery_pointer_progress_img_pointer = ''
      let idle_battery_current_text_font = ''
      let idle_heart_rate_pointer_progress_img_pointer = ''
      let idle_heart_rate_text_font = ''
      let idle_day_text_font = ''
      let idle_dow_text_font = ''
      let idle_DOW_Array = ['ПОНЕДЕЛЬНИК', 'ВТОРНИК', 'СРЕДА', 'ЧЕТВЕРГ', 'ПЯТНИЦА', 'СУББОТА', 'ВОСКРЕСЕНЬЕ'];
      let idle_month_pointer_progress_date_pointer = ''
      let idle_month_name_font = ''
      let idle_Month_Array = ['ЯНВ', 'ФЕВ', 'МАР', 'АПР', 'МАЙ', 'ИЮН', 'ИЮЛ', 'АВГ', 'СЕН', 'ОКТ', 'НОЯ', 'ДЕК', ];
      let idle_alarm_clock_current_text_font = ''
      let idle_system_disconnect_img = ''
      let idle_city_name_text = ''
      let idle_temperature_current_text_font = ''
      let idle_weather_image_progress_img_level = ''
      let idle_temperature_icon_img = ''
      let idle_temperature_icon_img_A = ''
      let idle_stand_icon_img = ''
      let idle_analog_clock_time_pointer_hour = ''
      let idle_analog_clock_time_pointer_minute = ''
      let idle_timerUpdateSec = undefined;
      let Button_1 = ''
      let Button_2 = ''
      let Button_3 = ''
      let Button_4 = ''	  
      let Button_5 = ''
	  let timeSensor = '';

      let normal_heart_rate_circle_scale_2 = ''
      let normal_battery_circle_scale = ''
      let normal_heart_rate_circle_scale_2_bg = ''
      let normal_battery_circle_scale_bg = ''
      let norma_tap_alarm_icon_img = ''
      let normal_tap_timer_icon_img = ''
	  
      let normal_ic_text_font_puls = ''
      let normal_ic_text_font_bat = ''
      let normal_ic_text_font_step = ''
	  
      let idle_ic_text_font_puls = ''
      let idle_ic_text_font_bat = ''
      let idle_ic_text_font_step = ''

      let idle_heart_rate_circle_scale_2 = ''
      let idle_battery_circle_scale = ''
      let idle_heart_rate_circle_scale_2_bg = ''
      let idle_battery_circle_scale_bg = ''
      //dynamic modify end
	  

      __$$module$$__.module = DeviceRuntimeCore.WatchFace({
       init_view() {
        //dynamic modify start


        // FontName: 3_Europext.ttf; FontSize: 14
        hmUI.createWidget(hmUI.widget.TEXT, {
         x: 464,
         y: 464,
         w: 268,
         h: 19,
         text_size: 14,
         char_space: 0,
         line_space: 0,
         font: 'fonts/3_Europext.ttf',
         color: 0xFFFFFFFF,
         align_h: hmUI.align.CENTER_H,
         align_v: hmUI.align.CENTER_V,
         text_style: hmUI.text_style.ELLIPSIS,
         text: "0123456789 _-.,:;`'%°\\/",
         show_level: hmUI.show_level.ONLY_NORMAL,
        });

        // FontName: Eurostile-Regular.ttf; FontSize: 64
        hmUI.createWidget(hmUI.widget.TEXT, {
         x: 464,
         y: 464,
         w: 960,
         h: 85,
         text_size: 64,
         char_space: 0,
         line_space: 0,
         font: 'fonts/Eurostile-Regular.ttf',
         color: 0xFFFFFFFF,
         align_h: hmUI.align.CENTER_H,
         align_v: hmUI.align.CENTER_V,
         text_style: hmUI.text_style.ELLIPSIS,
         text: "0123456789 _-.,:;`'%°\\/",
         show_level: hmUI.show_level.ONLY_NORMAL,
        });

        // FontName: Eurostile-Regular.ttf; FontSize: 22
        hmUI.createWidget(hmUI.widget.TEXT, {
         x: 464,
         y: 464,
         w: 336,
         h: 30,
         text_size: 22,
         char_space: 0,
         line_space: 0,
         font: 'fonts/Eurostile-Regular.ttf',
         color: 0xFFFFFFFF,
         align_h: hmUI.align.LEFT,
         align_v: hmUI.align.CENTER_V,
         text_style: hmUI.text_style.ELLIPSIS,
         text: "0123456789 _-.,:;`'%°\\/",
         show_level: hmUI.show_level.ONLY_NORMAL,
        });

        // FontName: Eurostile-Regular.ttf; FontSize: 31
        hmUI.createWidget(hmUI.widget.TEXT, {
         x: 464,
         y: 464,
         w: 469,
         h: 42,
         text_size: 31,
         char_space: 0,
         line_space: 0,
         font: 'fonts/Eurostile-Regular.ttf',
         color: 0xFFFFFFFF,
         align_h: hmUI.align.CENTER_H,
         align_v: hmUI.align.CENTER_V,
         text_style: hmUI.text_style.ELLIPSIS,
         text: "0123456789 _-.,:;`'%°\\/",
         show_level: hmUI.show_level.ONLY_NORMAL,
        });

        // FontName: IBMPlexSansCondensed_Medium.ttf; FontSize: 21
        hmUI.createWidget(hmUI.widget.TEXT, {
         x: 464,
         y: 464,
         w: 300,
         h: 34,
         text_size: 21,
         char_space: 0,
         line_space: 0,
         font: 'fonts/IBMPlexSansCondensed_Medium.ttf',
         color: 0xFFFFFFFF,
         align_h: hmUI.align.CENTER_H,
         align_v: hmUI.align.CENTER_V,
         text_style: hmUI.text_style.ELLIPSIS,
         text: "0123456789 _-.,:;`'%°\\/",
         show_level: hmUI.show_level.ONLY_NORMAL,
        });

        // FontName: 3_Europext.ttf; FontSize: 19; Cache: full
        hmUI.createWidget(hmUI.widget.TEXT, {
         x: 464,
         y: 464,
         w: 22,
         h: 22,
         text_size: 19,
         char_space: 0,
         line_space: 0,
         font: 'fonts/3_Europext.ttf',
         color: 0xFFFFFFFF,
         align_h: hmUI.align.CENTER_H,
         align_v: hmUI.align.CENTER_V,
         text_style: hmUI.text_style.NONE,
         text: "0123456789 ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz АБВГДЕЁЖЗИЙКЛМНОПРСТУФХЦЧШЩЪЫЬЭЮЯабвгдеёжзийклмнопрстуфхцчшщъыьэюя  ҐЄІЇґєії _-.,:;`'%°\\/",
         show_level: hmUI.show_level.ONLY_NORMAL,
        });

        // FontName: Eurostile-Regular.ttf; FontSize: 20
        hmUI.createWidget(hmUI.widget.TEXT, {
         x: 464,
         y: 464,
         w: 298,
         h: 25,
         text_size: 20,
         char_space: 0,
         line_space: 0,
         font: 'fonts/Eurostile-Regular.ttf',
         color: 0xFFFFFFFF,
         align_h: hmUI.align.CENTER_H,
         align_v: hmUI.align.CENTER_V,
         text_style: hmUI.text_style.ELLIPSIS,
         text: "0123456789 _-.,:;`'%°\\/",
         show_level: hmUI.show_level.ONLY_NORMAL,
        });

        // FontName: 3_Europext.ttf; FontSize: 13; Cache: full
        hmUI.createWidget(hmUI.widget.TEXT, {
         x: 464,
         y: 464,
         w: 15,
         h: 15,
         text_size: 13,
         char_space: 0,
         line_space: 0,
         font: 'fonts/3_Europext.ttf',
         color: 0xFFFFFFFF,
         align_h: hmUI.align.CENTER_H,
         align_v: hmUI.align.CENTER_V,
         text_style: hmUI.text_style.NONE,
         text: "0123456789 ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz АБВГДЕЁЖЗИЙКЛМНОПРСТУФХЦЧШЩЪЫЬЭЮЯабвгдеёжзийклмнопрстуфхцчшщъыьэюя  ҐЄІЇґєії _-.,:;`'%°\\/",
         show_level: hmUI.show_level.ONLY_NORMAL,
        });

        // FontName: 3_Europext.ttf; FontSize: 16; Cache: full
        hmUI.createWidget(hmUI.widget.TEXT, {
         x: 464,
         y: 464,
         w: 19,
         h: 19,
         text_size: 16,
         char_space: 0,
         line_space: 0,
         font: 'fonts/3_Europext.ttf',
         color: 0xFFFFFFFF,
         align_h: hmUI.align.RIGHT,
         align_v: hmUI.align.CENTER_V,
         text_style: hmUI.text_style.NONE,
         text: "0123456789 ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz АБВГДЕЁЖЗИЙКЛМНОПРСТУФХЦЧШЩЪЫЬЭЮЯабвгдеёжзийклмнопрстуфхцчшщъыьэюя  ҐЄІЇґєії _-.,:;`'%°\\/",
         show_level: hmUI.show_level.ONLY_NORMAL,
        });
		   
            // FontName: 3_Europext.ttf; FontSize: 10; Cache: full
            hmUI.createWidget(hmUI.widget.TEXT, {
              x: 464,
              y: 464,
              w: 12,
              h: 12,
              text_size: 10,
              char_space: 0,
              line_space: 0,
              font: 'fonts/3_Europext.ttf',
              color: 0xFFFFFFFF,
              align_h: hmUI.align.RIGHT,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.NONE,
              text: "0123456789 ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz АБВГДЕЁЖЗИЙКЛМНОПРСТУФХЦЧШЩЪЫЬЭЮЯабвгдеёжзийклмнопрстуфхцчшщъыьэюя  ҐЄІЇґєії _-.,:;`'%°\\/",
              show_level: hmUI.show_level.ONLY_NORMAL,
            });		
		   
            // FontName: 3_Europext.ttf; FontSize: 10; Cache: full
            hmUI.createWidget(hmUI.widget.TEXT, {
              x: 464,
              y: 464,
              w: 12,
              h: 12,
              text_size: 15,
              char_space: 0,
              line_space: 0,
              font: 'fonts/3_Europext.ttf',
              color: 0xFFFFFFFF,
              align_h: hmUI.align.RIGHT,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.NONE,
              text: "0123456789 ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz АБВГДЕЁЖЗИЙКЛМНОПРСТУФХЦЧШЩЪЫЬЭЮЯабвгдеёжзийклмнопрстуфхцчшщъыьэюя  ҐЄІЇґєії _-.,:;`'%°\\/",
              show_level: hmUI.show_level.ONLY_NORMAL,
            });		
		   
		   
		   
        console.log('user_script_start.js');
        // start user_script_start.js

        loadSettings();
        // end user_script_start.js

        console.log('Watch_Face.ScreenNormal');
        normal_background_bg = hmUI.createWidget(hmUI.widget.FILL_RECT, {
         x: 0,
         y: 0,
         w: 466,
         h: 466,
         color: '0xFF000000',
         show_level: hmUI.show_level.ONLY_NORMAL,
        });

        console.log('user_script.js');
        // start user_script.js
        normal_SUN_CURRENT_PROGRESS = hmUI.createWidget(hmUI.widget.IMG, {
         x: 0,
         y: 0,
         w: 466,
         h: 466,
         pos_x: 153,
         pos_y: 88,
         center_x: 233,
         center_y: 168,
         src: tap_dw == 0 ? 'str_sun.png' : 'str_sun_1.png',
         angle: 90,
         show_level: hmUI.show_level.ONLY_NORMAL,
        });


        // end user_script.js




        normal_battery_circle_scale_bg = hmUI.createWidget(hmUI.widget.CIRCLE, {
         center_x: 338,
         center_y: 233,
         radius: 64,
         color: tap_dw == 0 ? 0x4d8f75 : 0x408080,
         alpha: 255,
         show_level: hmUI.show_level.ONLY_NORMAL,
        });

        normal_heart_rate_circle_scale_2_bg = hmUI.createWidget(hmUI.widget.CIRCLE, {
         center_x: 129,
         center_y: 233,
         radius: 64,
         color: tap_dw == 0 ? 0x4d8f75 : 0x408080,
         alpha: 255,
         show_level: hmUI.show_level.ONLY_NORMAL,
        });


        normal_battery_circle_scale = hmUI.createWidget(hmUI.widget.ARC_PROGRESS, {
         center_x: 338,
         center_y: 233,
         start_angle: -151,
         end_angle: 151,
         radius: 38,
         line_width: 50,
         corner_flag: 3,
         type: hmUI.data_type.BATTERY,
         color: tap_dw == 0 ? 0xFF80FFFF : 0xFF00FF9B,
         show_level: hmUI.show_level.ONLY_NORMAL,
        });

        normal_heart_rate_circle_scale_2 = hmUI.createWidget(hmUI.widget.ARC_PROGRESS, {
         center_x: 129,
         center_y: 233,
         start_angle: -151,
         end_angle: 151,
         radius: 38,
         line_width: 50,
         corner_flag: 3,
         type: hmUI.data_type.HEART,
         color: tap_dw == 0 ? 0xFF80FFFF : 0xFF00FF9B,
         // mirror: False,
         show_level: hmUI.show_level.ONLY_NORMAL,
        });


        normal_image_img = hmUI.createWidget(hmUI.widget.IMG, {
         x: 0,
         y: 0,
         src: tap_dw == 0 ? 'bg_0.png' : 'bg_1.png',
         show_level: hmUI.show_level.ONLY_NORMAL,
        });
		   
            norma_tap_alarm_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 303,
              y: 198,
              src: 'ic_tap_alarm.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
		   
        norma_tap_alarm_icon_img.setProperty(hmUI.prop.VISIBLE, (tap_dw == 0 && tap_centr == 1) ? true : false);		   
		   
            normal_tap_timer_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 91,
              y: 198,
              src: 'ic_tap_timer.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            
        normal_tap_timer_icon_img.setProperty(hmUI.prop.VISIBLE, (tap_dw == 0 && tap_centr == 1) ? true : false);		               
            
		   
            normal_ic_text_font_puls = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 129-75,
              y: 244+2,
              w: 150,
              h: 30,
              text: 'ЧСС',
              text_size: 10,
              char_space: 0,
              line_space: 0,
              font: 'fonts/3_Europext.ttf',
              color: 0xb4b4b4,
         align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              // padding: true,
              // unit_string: ЯНВ, ФЕВ, МАР, АПР, МАЙ, ИЮН, ИЮЛ, АВГ, СЕН, ОКТ, НОЯ,ЧСС,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });	
		   
            normal_ic_text_font_bat = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 338-75,
              y: 244+2,
              w: 150,
              h: 30,
              text: '%',
              text_size: 10,
              char_space: 0,
              line_space: 0,
              font: 'fonts/3_Europext.ttf',
              color: 0xb4b4b4,
         align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              // padding: true,
              // unit_string: ЯНВ, ФЕВ, МАР, АПР, МАЙ, ИЮН, ИЮЛ, АВГ, СЕН, ОКТ, НОЯ,ЧСС,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });	
		   
            normal_ic_text_font_step = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 0,
              y: 248+7,
              w: 466,
              h: 30,
              text: 'ШАГИ',
              text_size: 15,
              char_space: 0,
              line_space: 0,
              font: 'fonts/3_Europext.ttf',
              color: 0xb4b4b4,
         align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              // padding: true,
              // unit_string: ЯНВ, ФЕВ, МАР, АПР, МАЙ, ИЮН, ИЮЛ, АВГ, СЕН, ОКТ, НОЯ,ЧСС,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });	
		   
		    
 /*       normal_sun_low_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
         x: 162,
         y: 161,
         w: 142,
         h: 30,
         text_size: 14,
         char_space: 0,
         line_space: 0,
         font: 'fonts/3_Europext.ttf',
         color: tap_dw == 0 ? 0xFFFFFFFF : 0xFF00FF9B,
         align_h: hmUI.align.CENTER_H,
         align_v: hmUI.align.CENTER_V,
         padding: true,
         unit_type: 1,
         text_style: hmUI.text_style.ELLIPSIS,
         type: hmUI.data_type.SUN_SET,
         show_level: hmUI.show_level.ONLY_NORMAL,
        });

        normal_sun_high_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
         x: 162,
         y: 161,
         w: 142,
         h: 30,
         text_size: 14,
         char_space: 0,
         line_space: 0,
         font: 'fonts/3_Europext.ttf',
         color: tap_dw == 0 ? 0xFFFFFFFF : 0xFF00FF9B,
         align_h: hmUI.align.CENTER_H,
         align_v: hmUI.align.CENTER_V,
         padding: true,
         unit_type: 1,
         text_style: hmUI.text_style.ELLIPSIS,
         type: hmUI.data_type.SUN_RISE,
         show_level: hmUI.show_level.ONLY_NORMAL,
        });		   */
		   

        if (!timeSensor) timeSensor = hmSensor.createSensor(hmSensor.id.TIME);
        let screenType = hmSetting.getScreenType();
        normal_time_hour_min_text_font = hmUI.createWidget(hmUI.widget.TEXT, {
         x: 3,
         y: 303,
         w: 466,
         h: 80,
         text_size: 64,
         char_space: 0,
         line_space: 0,
         font: 'fonts/Eurostile-Regular.ttf',
         color: tap_dw == 0 ? 0xFFFFFFFF : 0xFF00FF9B,
         align_h: hmUI.align.CENTER_H,
         align_v: hmUI.align.CENTER_V,
         text_style: hmUI.text_style.ELLIPSIS,
         // padding: true,
         show_level: hmUI.show_level.ONLY_NORMAL,
        });

        normal_time_second_text_font = hmUI.createWidget(hmUI.widget.TEXT, {
         x: 326,
         y: 337,
         w: 150,
         h: 30,
         text_size: 22,
         char_space: 0,
         line_space: 0,
         font: 'fonts/Eurostile-Regular.ttf',
         color: tap_dw == 0 ? 0xFFFFFFFF : 0xFF00FF9B,
         align_h: hmUI.align.LEFT,
         align_v: hmUI.align.CENTER_V,
         text_style: hmUI.text_style.ELLIPSIS,
         // padding: true,
         show_level: hmUI.show_level.ONLY_NORMAL,
        });


        normal_step_current_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
         x: 0,
         y: 267,
         w: 466,
         h: 50,
         text_size: 31,
         char_space: 0,
         line_space: 0,
         font: 'fonts/Eurostile-Regular.ttf',
         color: tap_dw == 0 ? 0xFFFFFFFF : 0xFF00FF9B,
         align_h: hmUI.align.CENTER_H,
         align_v: hmUI.align.CENTER_V,
         text_style: hmUI.text_style.ELLIPSIS,
         type: hmUI.data_type.STEP,
         show_level: hmUI.show_level.ONLY_NORMAL,
        });


        normal_battery_pointer_progress_img_pointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
         src: tap_dw == 0 ? 'str_bat.png' : 'str_bat_1.png',
         center_x:  (tap_dw == 1 || tap_centr == 0) ? 339 : 999,
         center_y: 233,
         x: 7,
         y: 26,
         start_angle: -150,
         end_angle: 150,
         invalid_visible: false,
         type: hmUI.data_type.BATTERY,
         show_level: hmUI.show_level.ONLY_NORMAL,
        });
        
         normal_heart_rate_pointer_progress_img_pointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
         src: tap_dw == 0 ? 'str_bat.png' : 'str_bat_1.png',
         center_x:  (tap_dw == 1 || tap_centr == 0) ? 129 : -999,
         center_y: 233,
         x: 7,
         y: 26,
         start_angle: -150,
         end_angle: 150,
         invalid_visible: false,
         type: hmUI.data_type.HEART,
         show_level: hmUI.show_level.ONLY_NORMAL,
        });
               

        normal_battery_current_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
         x: 264,
         y: 260,
         w: 150,
         h: 30,
         text_size: 21,
         char_space: 0,
         line_space: 0,
         font: 'fonts/IBMPlexSansCondensed_Medium.ttf',
         color: tap_dw == 0 ? 0xFFFFFFFF : 0xFF00FF9B,
         align_h: hmUI.align.CENTER_H,
         align_v: hmUI.align.CENTER_V,
         text_style: hmUI.text_style.ELLIPSIS,
         type: hmUI.data_type.BATTERY,
         show_level: hmUI.show_level.ONLY_NORMAL,
        });

        normal_heart_rate_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
         x: 55,
         y: 260,
         w: 150,
         h: 30,
         text_size: 21,
         char_space: 0,
         line_space: 0,
         font: 'fonts/IBMPlexSansCondensed_Medium.ttf',
         color: tap_dw == 0 ? 0xFFFFFFFF : 0xFF00FF9B,
         align_h: hmUI.align.CENTER_H,
         align_v: hmUI.align.CENTER_V,
         text_style: hmUI.text_style.ELLIPSIS,
         type: hmUI.data_type.HEART,
         show_level: hmUI.show_level.ONLY_NORMAL,
        });

        timeSensor.addEventListener(timeSensor.event.DAYCHANGE, function () {
         time_update(true);
        });

        normal_dow_text_font = hmUI.createWidget(hmUI.widget.TEXT, {
         x: 0,
         y: 363,
         w: 466,
         h: 30,
         text_size: 19,
         char_space: 0,
         line_space: 0,
         font: 'fonts/3_Europext.ttf',
         color: tap_dw == 0 ? 0xFFFFFFFF : 0xFF00FF9B,
         align_h: hmUI.align.CENTER_H,
         align_v: hmUI.align.CENTER_V,
         text_style: hmUI.text_style.ELLIPSIS,
         // padding: true,
         // unit_string: ПОНЕДЕЛЬНИК, ВТОРНИК, СРЕДА, ЧЕТВЕРГ, ПЯТНИЦА, СУББОТА, ВОСКРЕСЕНЬЕ,
         show_level: hmUI.show_level.ONLY_NORMAL,
        });

        normal_day_text_font = hmUI.createWidget(hmUI.widget.TEXT, {
         x: 0,
         y: 382,
         w: 466,
         h: 30,
         text_size: 19,
         char_space: 0,
         line_space: 0,
         font: 'fonts/3_Europext.ttf',
         color: tap_dw == 0 ? 0xFFFFFFFF : 0xFF00FF9B,
         align_h: hmUI.align.CENTER_H,
         align_v: hmUI.align.CENTER_V,
         text_style: hmUI.text_style.ELLIPSIS,
         // padding: true,
         // unit_string: ПОНЕДЕЛЬНИК, ВТОРНИК, СРЕДА, ЧЕТВЕРГ, ПЯТНИЦА, СУББОТА, ВОСКРЕСЕНЬЕ,
         show_level: hmUI.show_level.ONLY_NORMAL,
        });

        normal_alarm_clock_current_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
         x: 44,
         y: 314,
         w: 150,
         h: 30,
         text_size: 20,
         char_space: 0,
         line_space: 0,
         font: 'fonts/Eurostile-Regular.ttf',
         color: tap_dw == 0 ? 0xFFFFFFFF : 0xFF00FF9B,
         align_h: hmUI.align.CENTER_H,
         align_v: hmUI.align.CENTER_V,
         padding: true,
         text_style: hmUI.text_style.ELLIPSIS,
         type: hmUI.data_type.ALARM_CLOCK,
         show_level: hmUI.show_level.ONLY_NORMAL,
        });

        normal_system_disconnect_img_0 = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
         x: 319,
         y: 320,
         src: 'stat_B_off.png',
         type: hmUI.system_status.DISCONNECT,
         show_level: hmUI.show_level.ONLY_NORMAL,
        });

        normal_system_disconnect_img_1 = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
         x: 319,
         y: 320,
         src: 'stat_B_off_1.png',
         type: hmUI.system_status.DISCONNECT,
         show_level: hmUI.show_level.ONLY_NORMAL,
        });

        normal_system_disconnect_img_0.setProperty(hmUI.prop.VISIBLE, tap_dw == 0 ? true : false);
        normal_system_disconnect_img_1.setProperty(hmUI.prop.VISIBLE, tap_dw == 1 ? true : false);

        const weatherSensor = hmSensor.createSensor(hmSensor.id.WEATHER);

        normal_city_name_text = hmUI.createWidget(hmUI.widget.TEXT, {
         x: 162,
         y: 60,
         w: 142,
         h: 30,
         text_size: 13,
         char_space: 0,
         line_space: 0,
         font: 'fonts/3_Europext.ttf',
         color: tap_dw == 0 ? 0xFFFFFFFF : 0xFF00FF9B,
         align_h: hmUI.align.CENTER_H,
         align_v: hmUI.align.CENTER_V,
         text_style: hmUI.text_style.ELLIPSIS,
         // padding: true,
         // unit_type: 1,
         // unit_string: ПОНЕДЕЛЬНИК, ВТОРНИК, СРЕДА, ЧЕТВЕРГ, ПЯТНИЦА, СУББОТА, ВОСКРЕСЕНЬЕ,
         show_level: hmUI.show_level.ONLY_NORMAL,
        });
		   
            normal_temperature_low_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 0,
              y: 221+7,
              w: 466,
              h: 30,
              text_size: 25,
              char_space: 0,
              line_space: 0,
              color: 0xFFFFFFFF,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.CENTER_V,
              unit_type: 1,
         		//alpha: tap_centr == 0 ? 255:179,
              text_style: hmUI.text_style.ELLIPSIS,
              type: hmUI.data_type.WEATHER_LOW,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_high_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 0,
              y: 191+7,
              w: 466,
              h: 30,
              text_size: 25,
              char_space: 0,
              line_space: 0,
              color: 0xFFFFFFFF,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.CENTER_V,
              unit_type: 1,
         		//alpha: tap_centr == 0 ? 255:179,
				text_style: hmUI.text_style.ELLIPSIS,
              type: hmUI.data_type.WEATHER_HIGH,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
		   
normal_temperature_low_text_font.setAlpha(tap_dw == 0 ? 255: 179);
normal_temperature_high_text_font.setAlpha(tap_dw == 0 ? 255: 179);		   
		   
        normal_temperature_low_text_font.setProperty(hmUI.prop.VISIBLE, (tap_up == 1 && tap_centr == 1) ? true : false);		               
        normal_temperature_high_text_font.setProperty(hmUI.prop.VISIBLE, (tap_up == 1 && tap_centr == 1) ? true : false);		               
		   
            normal_moon_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 177,
              y: 164,
              image_array: ["moon_0.png","moon_1.png","moon_2.png","moon_3.png","moon_4.png","moon_5.png","moon_6.png","moon_7.png","moon_8.png","moon_9.png","moon_10.png","moon_11.png","moon_12.png","moon_13.png","moon_14.png","moon_15.png","moon_16.png","moon_17.png","moon_18.png","moon_19.png","moon_20.png","moon_21.png","moon_22.png","moon_23.png","moon_24.png","moon_25.png","moon_26.png","moon_27.png","moon_28.png","moon_29.png"],
				image_length: 30,
              type: hmUI.data_type.MOON,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });	
		   
            normal_moon_image_progress_img_level.setAlpha(tap_dw == 0 ? 255: 179);
		   
        normal_temperature_current_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
         x: 123,
         y: 113,
         w: 150,
         h: 30,
         text_size: 25,
         char_space: 0,
         line_space: 0,
         color: tap_dw == 0 ? 0xFFFFFFFF : 0xFF00FF9B,
         align_h: hmUI.align.LEFT,
         align_v: hmUI.align.CENTER_V,
         text_style: hmUI.text_style.ELLIPSIS,
         type: hmUI.data_type.WEATHER_CURRENT,
         show_level: hmUI.show_level.ONLY_NORMAL,
        });

        normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
         x: 72,
         y: 59,
         image_array: ["wb_0.png", "wb_1.png", "wb_2.png", "wb_3.png", "wb_4.png", "wb_5.png", "wb_6.png", "wb_7.png", "wb_8.png", "wb_9.png", "wb_10.png", "wb_11.png", "wb_12.png", "wb_13.png", "wb_14.png", "wb_15.png", "wb_16.png", "wb_17.png", "wb_18.png", "wb_19.png", "wb_20.png", "wb_21.png", "wb_22.png", "wb_23.png", "wb_24.png", "wb_25.png", "wb_26.png", "wb_27.png", "wb_28.png"],
         image_length: 29,
         type: hmUI.data_type.WEATHER_CURRENT,
         show_level: hmUI.show_level.ONLY_NORMAL,
        });

        normal_temperature_icon_img_A = hmUI.createWidget(hmUI.widget.IMG, {
         x: 72,
         y: 59,
         src: 'weather_cap_A.png',
         alpha: 128,
         show_level: hmUI.show_level.ONLY_NORMAL,
        });

        normal_temperature_icon_img_A.setProperty(hmUI.prop.VISIBLE, (tap_dw == 1 && tap_up == 0) ? true : false);


        normal_temperature_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
         x: 72,
         y: 59,
         src: 'weather_cap.png',
         show_level: hmUI.show_level.ONLY_NORMAL,
        });

        normal_stand_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
         x: 0,
         y: 0,
         src: tap_dw == 0 ? 'bezel_0.png' : 'bezel_2.png',
         show_level: hmUI.show_level.ONLY_NORMAL,
        });

        normal_month_pointer_progress_date_pointer = hmUI.createWidget(hmUI.widget.DATE_POINTER, {
         src: 'str_month.png',
         center_x: 233,
         center_y: 233,
         posX: 19,
         posY: 203,
         start_angle: -15,
         end_angle: 345,
         type: hmUI.date.MONTH,
         show_level: hmUI.show_level.ONLY_NORMAL,
        });

        normal_month_name_font = hmUI.createWidget(hmUI.widget.TEXT, {
         x: -3,
         y: 334,
         w: 150,
         h: 30,
         text_size: 16,
         char_space: 0,
         line_space: 0,
         font: 'fonts/3_Europext.ttf',
         color: tap_dw == 0 ? 0xFFFFFFFF : 0xFF00FF9B,
         align_h: hmUI.align.RIGHT,
         align_v: hmUI.align.CENTER_V,
         text_style: hmUI.text_style.ELLIPSIS,
         // padding: true,
         // unit_string: ЯНВ, ФЕВ, МАР, АПР, МАЙ, ИЮН, ИЮЛ, АВГ, СЕН, ОКТ, НОЯ, ДЕК,
         show_level: hmUI.show_level.ONLY_NORMAL,
        });
        

        
        

        const deviceInfo = hmSetting.getDeviceInfo();
        timeSensor.addEventListener(timeSensor.event.DAYCHANGE, function () {
         time_update(true);
        });

        normal_analog_clock_time_pointer_hour = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
         hour_path: tap_dw == 0 ? 'str_h.png' : 'str_h_1.png',
         hour_centerX: 233,
         hour_centerY: 233,
         hour_posX: 25,
         hour_posY: 127,
         show_level: hmUI.show_level.ONLY_NORMAL,
        });

        normal_analog_clock_time_pointer_minute = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
         minute_path: tap_dw == 0 ? 'str_m.png' : 'str_m_1.png',
         minute_centerX: 233,
         minute_centerY: 233,
         minute_posX: 27,
         minute_posY: 217,
         show_level: hmUI.show_level.ONLY_NORMAL,
        });

        normal_analog_clock_time_pointer_second = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
         second_path: 'str_s.png',
         second_centerX: 233,
         second_centerY: 233,
         second_posX: 21,
         second_posY: 225,
         fresh_frequency: 25,
         show_level: hmUI.show_level.ONLY_NORMAL,
        });


        console.log('Watch_Face.ScreenAOD');
        idle_background_bg = hmUI.createWidget(hmUI.widget.FILL_RECT, {
         x: 0,
         y: 0,
         w: 466,
         h: 466,
         color: '0xFF000000',
         show_level: hmUI.show_level.ONLY_AOD,
        });

        idle_SUN_CURRENT_PROGRESS = hmUI.createWidget(hmUI.widget.IMG, {
         x: 0,
         y: 0,
         w: 466,
         h: 466,
         pos_x: 153,
         pos_y: 88,
         center_x: 233,
         center_y: 168,
         src: 'str_sun_1.png',
         angle: 90,
         show_level: hmUI.show_level.ONLY_AOD,
        });


		   
        idle_battery_circle_scale_bg = hmUI.createWidget(hmUI.widget.CIRCLE, {
         center_x: 338,
         center_y: 233,
         radius: 64,
         color: 0x00804e,
         alpha: 255,
         show_level: hmUI.show_level.ONLY_AOD,
        });

        idle_heart_rate_circle_scale_2_bg = hmUI.createWidget(hmUI.widget.CIRCLE, {
         center_x: 129,
         center_y: 233,
         radius: 64,
         color: 0x00804e,
         alpha: 255,
         show_level: hmUI.show_level.ONLY_AOD,
        });


        idle_battery_circle_scale = hmUI.createWidget(hmUI.widget.ARC_PROGRESS, {
         center_x: 338,
         center_y: 233,
         start_angle: -151,
         end_angle: 151,
         radius: 38,
         line_width: 50,
         corner_flag: 3,
         type: hmUI.data_type.BATTERY,
         color: 0xFF00FF9B,
         show_level: hmUI.show_level.ONLY_AOD,
        });

        idle_heart_rate_circle_scale_2 = hmUI.createWidget(hmUI.widget.ARC_PROGRESS, {
         center_x: 129,
         center_y: 233,
         start_angle: -151,
         end_angle: 151,
         radius: 38,
         line_width: 50,
         corner_flag: 3,
         type: hmUI.data_type.HEART,
         color: 0xFF00FF9B,
         // mirror: False,
         show_level: hmUI.show_level.ONLY_AOD,
        });


        idle_image_img = hmUI.createWidget(hmUI.widget.IMG, {
         x: 0,
         y: 0,
         src: 'bg_1.png',
         show_level: hmUI.show_level.ONLY_AOD,
        });
		   
            idle_ic_text_font_puls = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 129-75,
              y: 244,
              w: 150,
              h: 30,
              text: 'ЧСС',
              text_size: 10,
              char_space: 0,
              line_space: 0,
              font: 'fonts/3_Europext.ttf',
              color: 0xFF00FF9B,
         align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              // padding: true,
              // unit_string: ЯНВ, ФЕВ, МАР, АПР, МАЙ, ИЮН, ИЮЛ, АВГ, СЕН, ОКТ, НОЯ,ЧСС,
              show_level: hmUI.show_level.ONLY_AOD,
            });	
		   
            idle_ic_text_font_bat = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 338-75,
              y: 244,
              w: 150,
              h: 30,
              text: '%',
              text_size: 10,
              char_space: 0,
              line_space: 0,
              font: 'fonts/3_Europext.ttf',
              color: 0xFF00FF9B,
         align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              // padding: true,
              // unit_string: ЯНВ, ФЕВ, МАР, АПР, МАЙ, ИЮН, ИЮЛ, АВГ, СЕН, ОКТ, НОЯ,ЧСС,
              show_level: hmUI.show_level.ONLY_AOD,
            });	
		   
            idle_ic_text_font_step = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 0,
              y: 248,
              w: 466,
              h: 30,
              text: 'ШАГИ',
              text_size: 15,
              char_space: 0,
              line_space: 0,
              font: 'fonts/3_Europext.ttf',
              color: 0xFF00FF9B,
         align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              // padding: true,
              // unit_string: ЯНВ, ФЕВ, МАР, АПР, МАЙ, ИЮН, ИЮЛ, АВГ, СЕН, ОКТ, НОЯ,ЧСС,
              show_level: hmUI.show_level.ONLY_AOD,
            });
		   
		   
        idle_sun_low_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
         x: 162,
         y: 161,
         w: 142,
         h: 30,
         text_size: 14,
         char_space: 0,
         line_space: 0,
         font: 'fonts/3_Europext.ttf',
         color: 0xFF00FF9B,
         align_h: hmUI.align.CENTER_H,
         align_v: hmUI.align.CENTER_V,
         padding: true,
         unit_type: 1,
         text_style: hmUI.text_style.ELLIPSIS,
         type: hmUI.data_type.SUN_SET,
         show_level: hmUI.show_level.ONLY_AOD,
        });

        idle_sun_high_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
         x: 162,
         y: 161,
         w: 142,
         h: 30,
         text_size: 14,
         char_space: 0,
         line_space: 0,
         font: 'fonts/3_Europext.ttf',
         color: 0xFF00FF9B,
         align_h: hmUI.align.CENTER_H,
         align_v: hmUI.align.CENTER_V,
         padding: true,
         unit_type: 1,
         text_style: hmUI.text_style.ELLIPSIS,
         type: hmUI.data_type.SUN_RISE,
         show_level: hmUI.show_level.ONLY_AOD,
        });
		   
		   

        idle_time_hour_min_text_font = hmUI.createWidget(hmUI.widget.TEXT, {
         x: 3,
         y: 303,
         w: 466,
         h: 80,
         text_size: 64,
         char_space: 0,
         line_space: 0,
         font: 'fonts/Eurostile-Regular.ttf',
         color: 0xFF00FF9B,
         align_h: hmUI.align.CENTER_H,
         align_v: hmUI.align.CENTER_V,
         text_style: hmUI.text_style.ELLIPSIS,
         // padding: true,
         show_level: hmUI.show_level.ONLY_AOD,
        });

        idle_time_second_text_font = hmUI.createWidget(hmUI.widget.TEXT, {
         x: 326,
         y: 337,
         w: 150,
         h: 30,
         text: '88',
         text_size: 22,
         char_space: 0,
         line_space: 0,
         font: 'fonts/Eurostile-Regular.ttf',
         color: 0xFF00FF9B,
         align_h: hmUI.align.LEFT,
         align_v: hmUI.align.CENTER_V,
         text_style: hmUI.text_style.ELLIPSIS,
         // padding: true,
         show_level: hmUI.show_level.ONLY_AOD,
        });

        idle_step_current_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
         x: 0,
         y: 267,
         w: 466,
         h: 50,
         text_size: 31,
         char_space: 0,
         line_space: 0,
         font: 'fonts/Eurostile-Regular.ttf',
         color: 0xFF00FF9B,
         align_h: hmUI.align.CENTER_H,
         align_v: hmUI.align.CENTER_V,
         text_style: hmUI.text_style.ELLIPSIS,
         type: hmUI.data_type.STEP,
         show_level: hmUI.show_level.ONLY_AOD,
        });

        idle_battery_pointer_progress_img_pointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
         src: 'str_bat_1.png',
         center_x: 339,
         center_y: 233,
         x: 7,
         y: 26,
         start_angle: -150,
         end_angle: 150,
         invalid_visible: false,
         type: hmUI.data_type.BATTERY,
         show_level: hmUI.show_level.ONLY_AOD,
        });

        idle_battery_current_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
         x: 264,
         y: 260,
         w: 150,
         h: 30,
         text_size: 21,
         char_space: 0,
         line_space: 0,
         font: 'fonts/IBMPlexSansCondensed_Medium.ttf',
         color: 0xFF00FF9B,
         align_h: hmUI.align.CENTER_H,
         align_v: hmUI.align.CENTER_V,
         text_style: hmUI.text_style.ELLIPSIS,
         type: hmUI.data_type.BATTERY,
         show_level: hmUI.show_level.ONLY_AOD,
        });

        idle_heart_rate_pointer_progress_img_pointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
         src: 'str_bat_1.png',
         center_x: 129,
         center_y: 233,
         x: 7,
         y: 26,
         start_angle: -150,
         end_angle: 150,
         invalid_visible: false,
         type: hmUI.data_type.HEART,
         show_level: hmUI.show_level.ONLY_AOD,
        });

        idle_heart_rate_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
         x: 55,
         y: 260,
         w: 150,
         h: 30,
         text_size: 21,
         char_space: 0,
         line_space: 0,
         font: 'fonts/IBMPlexSansCondensed_Medium.ttf',
         color: 0xFF00FF9B,
         align_h: hmUI.align.CENTER_H,
         align_v: hmUI.align.CENTER_V,
         text_style: hmUI.text_style.ELLIPSIS,
         type: hmUI.data_type.HEART,
         show_level: hmUI.show_level.ONLY_AOD,
        });

        idle_day_text_font = hmUI.createWidget(hmUI.widget.TEXT, {
         x: 0,
         y: 382,
         w: 466,
         h: 30,
         text_size: 19,
         char_space: 0,
         line_space: 0,
         font: 'fonts/3_Europext.ttf',
         color: 0xFF00FF9B,
         align_h: hmUI.align.CENTER_H,
         align_v: hmUI.align.CENTER_V,
         text_style: hmUI.text_style.ELLIPSIS,
         // padding: true,
         show_level: hmUI.show_level.ONLY_AOD,
        });

        idle_dow_text_font = hmUI.createWidget(hmUI.widget.TEXT, {
         x: 0,
         y: 363,
         w: 466,
         h: 30,
         text_size: 19,
         char_space: 0,
         line_space: 0,
         font: 'fonts/3_Europext.ttf',
         color: 0xFF00FF9B,
         align_h: hmUI.align.CENTER_H,
         align_v: hmUI.align.CENTER_V,
         text_style: hmUI.text_style.ELLIPSIS,
         // padding: true,
         // unit_string: ПОНЕДЕЛЬНИК, ВТОРНИК, СРЕДА, ЧЕТВЕРГ, ПЯТНИЦА, СУББОТА, ВОСКРЕСЕНЬЕ,
         show_level: hmUI.show_level.ONLY_AOD,
        });

        idle_month_pointer_progress_date_pointer = hmUI.createWidget(hmUI.widget.DATE_POINTER, {
         src: 'str_month_1.png',
         center_x: 233,
         center_y: 233,
         posX: 19,
         posY: 203,
         start_angle: -15,
         end_angle: 345,
         type: hmUI.date.MONTH,
         show_level: hmUI.show_level.ONLY_AOD,
        });

        idle_month_name_font = hmUI.createWidget(hmUI.widget.TEXT, {
         x: -3,
         y: 334,
         w: 150,
         h: 30,
         text_size: 16,
         char_space: 0,
         line_space: 0,
         font: 'fonts/3_Europext.ttf',
         color: 0xFF00FF9B,
         align_h: hmUI.align.RIGHT,
         align_v: hmUI.align.CENTER_V,
         text_style: hmUI.text_style.ELLIPSIS,
         // padding: true,
         // unit_string: ЯНВ, ФЕВ, МАР, АПР, МАЙ, ИЮН, ИЮЛ, АВГ, СЕН, ОКТ, НОЯ, ДЕК,
         show_level: hmUI.show_level.ONLY_AOD,
        });

        idle_alarm_clock_current_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
         x: 44,
         y: 314,
         w: 150,
         h: 30,
         text_size: 20,
         char_space: 0,
         line_space: 0,
         font: 'fonts/Eurostile-Regular.ttf',
         color: 0xFF00FF9B,
         align_h: hmUI.align.CENTER_H,
         align_v: hmUI.align.CENTER_V,
         padding: true,
         text_style: hmUI.text_style.ELLIPSIS,
         type: hmUI.data_type.ALARM_CLOCK,
         show_level: hmUI.show_level.ONLY_AOD,
        });

        idle_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
         x: 319,
         y: 320,
         src: 'stat_B_off_1.png',
         type: hmUI.system_status.DISCONNECT,
         show_level: hmUI.show_level.ONLY_AOD,
        });

        idle_city_name_text = hmUI.createWidget(hmUI.widget.TEXT, {
         x: 162,
         y: 60,
         w: 142,
         h: 30,
         text_size: 13,
         char_space: 0,
         line_space: 0,
         font: 'fonts/3_Europext.ttf',
         color: 0xFF00FF9B,
         align_h: hmUI.align.CENTER_H,
         align_v: hmUI.align.CENTER_V,
         text_style: hmUI.text_style.ELLIPSIS,
         // unit_type: 1,
         show_level: hmUI.show_level.ONLY_AOD,
        });

        idle_temperature_current_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
         x: 123,
         y: 113,
         w: 150,
         h: 30,
         text_size: 25,
         char_space: 0,
         line_space: 0,
         color: 0xFF00FF9B,
         align_h: hmUI.align.LEFT,
         align_v: hmUI.align.CENTER_V,
         text_style: hmUI.text_style.ELLIPSIS,
         type: hmUI.data_type.WEATHER_CURRENT,
         show_level: hmUI.show_level.ONLY_AOD,
        });

        idle_weather_s_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
         x: 321,
         y: 114,
         image_array: ["wsa_0.png", "wsa_1.png", "wsa_2.png", "wsa_3.png", "wsa_4.png", "wsa_5.png", "wsa_6.png", "wsa_7.png", "wsa_8.png", "wsa_9.png", "wsa_10.png", "wsa_11.png", "wsa_12.png", "wsa_13.png", "wsa_14.png", "wsa_15.png", "wsa_16.png", "wsa_17.png", "wsa_18.png", "wsa_19.png", "wsa_20.png", "wsa_21.png", "wsa_22.png", "wsa_23.png", "wsa_24.png", "wsa_25.png", "wsa_26.png", "wsa_27.png", "wsa_28.png"],
         image_length: 29,
         type: hmUI.data_type.WEATHER_CURRENT,
         show_level: hmUI.show_level.ONLY_AOD,
        });


        idle_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
         x: 72,
         y: 59,
         image_array: ["wb_0.png", "wb_1.png", "wb_2.png", "wb_3.png", "wb_4.png", "wb_5.png", "wb_6.png", "wb_7.png", "wb_8.png", "wb_9.png", "wb_10.png", "wb_11.png", "wb_12.png", "wb_13.png", "wb_14.png", "wb_15.png", "wb_16.png", "wb_17.png", "wb_18.png", "wb_19.png", "wb_20.png", "wb_21.png", "wb_22.png", "wb_23.png", "wb_24.png", "wb_25.png", "wb_26.png", "wb_27.png", "wb_28.png"],
         image_length: 29,
         type: hmUI.data_type.WEATHER_CURRENT,
         show_level: hmUI.show_level.ONLY_AOD,
        });

        idle_temperature_icon_img_A = hmUI.createWidget(hmUI.widget.IMG, {
         x: 72,
         y: 59,
         src: 'weather_cap_A.png',
         alpha: 128,
         show_level: hmUI.show_level.ONLY_AOD,
        });

        idle_temperature_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
         x: 72,
         y: 59,
         src: 'weather_cap.png',
         show_level: hmUI.show_level.ONLY_AOD,
        });

        idle_stand_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
         x: 0,
         y: 0,
         src: 'bezel_1.png',
         show_level: hmUI.show_level.ONLY_AOD,
        });

        idle_analog_clock_time_pointer_hour = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
         hour_path: 'str_h_1.png',
         hour_centerX: 233,
         hour_centerY: 233,
         hour_posX: 25,
         hour_posY: 127,
         show_level: hmUI.show_level.ONLY_AOD,
        });

        idle_analog_clock_time_pointer_minute = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
         minute_path: 'str_m_1.png',
         minute_centerX: 233,
         minute_centerY: 233,
         minute_posX: 27,
         minute_posY: 217,
         show_level: hmUI.show_level.ONLY_AOD,
        });
        
          normal_weather_s_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
         x: 321,
         y: 114,
         image_array: tap_dw == 0 ? ["ws_0.png", "ws_1.png", "ws_2.png", "ws_3.png", "ws_4.png", "ws_5.png", "ws_6.png", "ws_7.png", "ws_8.png", "ws_9.png", "ws_10.png", "ws_11.png", "ws_12.png", "ws_13.png", "ws_14.png", "ws_15.png", "ws_16.png", "ws_17.png", "ws_18.png", "ws_19.png", "ws_20.png", "ws_21.png", "ws_22.png", "ws_23.png", "ws_24.png", "ws_25.png", "ws_26.png", "ws_27.png", "ws_28.png"] : ["wsa_0.png", "wsa_1.png", "wsa_2.png", "wsa_3.png", "wsa_4.png", "wsa_5.png", "wsa_6.png", "wsa_7.png", "wsa_8.png", "wsa_9.png", "wsa_10.png", "wsa_11.png", "wsa_12.png", "wsa_13.png", "wsa_14.png", "wsa_15.png", "wsa_16.png", "wsa_17.png", "wsa_18.png", "wsa_19.png", "wsa_20.png", "wsa_21.png", "wsa_22.png", "wsa_23.png", "wsa_24.png", "wsa_25.png", "wsa_26.png", "wsa_27.png", "wsa_28.png"],
         image_length: 29,
         type: hmUI.data_type.WEATHER_CURRENT,
         show_level: hmUI.show_level.ONLY_NORMAL,
        });
      
        

        console.log('Watch_Face.Buttons');
        Button_1 = hmUI.createWidget(hmUI.widget.BUTTON, {
         x: 183,
         y: 183,
         w: 100,
         h: 100,
         text: '',
         color: 0xFFFF8C00,
         text_size: 25,
         press_src: '0.png',
         normal_src: '0.png',
         click_func: (button_widget) => {
          clik_tap_centr()
         }, // end func
         show_level: hmUI.show_level.ONLY_NORMAL,
        }); // end button

        Button_2 = hmUI.createWidget(hmUI.widget.BUTTON, {
         x: 183,
         y: 66,
         w: 100,
         h: 100,
         text: '',
         color: 0xFFFF8C00,
         text_size: 25,
         press_src: '0.png',
         normal_src: '0.png',
         click_func: (button_widget) => {
          clik_tap_up()
         }, // end func
         show_level: hmUI.show_level.ONLY_NORMAL,
        }); // end button

        Button_3 = hmUI.createWidget(hmUI.widget.BUTTON, {
         x: 183,
         y: 366,
         w: 100,
         h: 100,
         text: '',
         color: 0xFFFF8C00,
         text_size: 25,
         press_src: '0.png',
         normal_src: '0.png',
         click_func: (button_widget) => {
          clik_tap_dw()
         }, // end func
         show_level: hmUI.show_level.ONLY_NORMAL,
        }); // end button
        console.log('user_script_end.js');
        // start user_script_end.js
        
        
             Button_4 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 303,
              y: 198,
              w: 71,
              h: 71,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '0.png',
              normal_src: '0.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'AlarmInfoScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_5 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 91,
              y: 198,
              w: 71,
              h: 71,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '0.png',
              normal_src: '0.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'CountdownAppScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button		       
                
        Button_4.setProperty(hmUI.prop.VISIBLE, (tap_dw == 0 && tap_centr == 1) ? true : false);		            
        Button_5.setProperty(hmUI.prop.VISIBLE, (tap_dw == 0 && tap_centr == 1) ? true : false);		         


        normal_analog_clock_time_pointer_hour.setProperty(hmUI.prop.VISIBLE, tap_centr == 0 ? true : false);
        normal_analog_clock_time_pointer_minute.setProperty(hmUI.prop.VISIBLE, tap_centr == 0 ? true : false);
        normal_analog_clock_time_pointer_second.setProperty(hmUI.prop.VISIBLE, tap_centr == 0 ? true : false);
        normal_weather_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, tap_up == 0 ? true : false);
        normal_temperature_icon_img.setProperty(hmUI.prop.VISIBLE, tap_up == 0 ? true : false);
        normal_weather_s_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, tap_up == 1 ? true : false);
        normal_stand_icon_img.setProperty(hmUI.prop.ALPHA, (tap_dw == 1 || tap_centr == 0) ? 255 : 128);
        idle_analog_clock_time_pointer_hour.setProperty(hmUI.prop.VISIBLE, tap_centr == 0 ? true : false);
        idle_analog_clock_time_pointer_minute.setProperty(hmUI.prop.VISIBLE, tap_centr == 0 ? true : false);

        if (screenType == hmSetting.screen_type.AOD) {
         idle_weather_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, tap_up == 0 ? true : false);
         idle_temperature_icon_img.setProperty(hmUI.prop.VISIBLE, tap_up == 0 ? true : false);
         idle_temperature_icon_img_A.setProperty(hmUI.prop.VISIBLE, tap_up == 0 ? true : false);
        }

        // idle_analog_clock_pro_second_pointer_img.setProperty(hmUI.prop.VISIBLE, tap_centr == 0 ? true : false);


        // end user_script_end.js

        //#region time_update
        function time_update(updateHour = false, updateMinute = false) {
         console.log('time_update()');
         let hour = timeSensor.hour;
         let minute = timeSensor.minute;
         let second = timeSensor.second;
         let format_hour = timeSensor.format_hour;

         console.log('hour:min font');
         if (updateMinute) {
          let normal_HourMinStr = format_hour.toString();
          normal_HourMinStr = normal_HourMinStr.padStart(2, '0');
          normal_HourMinStr = normal_HourMinStr + ':' + minute.toString().padStart(2, '0')
          if (!timeSensor.is24Hour) {
           if (hour > 11) normal_HourMinStr = 'pm ' + normal_HourMinStr
           else normal_HourMinStr = 'am ' + normal_HourMinStr
          };
          normal_time_hour_min_text_font.setProperty(hmUI.prop.TEXT, normal_HourMinStr);
         };

         console.log('second font');
         let normal_secondStr = second.toString();
         normal_secondStr = normal_secondStr.padStart(2, '0');
         normal_time_second_text_font.setProperty(hmUI.prop.TEXT, normal_secondStr);
         console.log('day of week font');
         if (updateHour) {
          let normal_DOW_Str = normal_DOW_Array[timeSensor.week - 1];
          normal_dow_text_font.setProperty(hmUI.prop.TEXT, normal_DOW_Str);
         };

         console.log('day font');
         if (updateHour) {
          let normal_dayStr = timeSensor.day.toString();
          normal_dayStr = normal_dayStr.padStart(2, '0');
          normal_day_text_font.setProperty(hmUI.prop.TEXT, normal_dayStr);
         };

         console.log('month font');
         if (updateHour) {
          let normal_Month_Str = normal_Month_Array[timeSensor.month - 1];
          normal_month_name_font.setProperty(hmUI.prop.TEXT, normal_Month_Str);
         };

         console.log('hour:min font');
         if (updateMinute) {
          let idle_HourMinStr = format_hour.toString();
          idle_HourMinStr = idle_HourMinStr.padStart(2, '0');
          idle_HourMinStr = idle_HourMinStr + ':' + minute.toString().padStart(2, '0')
          if (!timeSensor.is24Hour) {
           if (hour > 11) idle_HourMinStr = 'pm ' + idle_HourMinStr
           else idle_HourMinStr = 'am ' + idle_HourMinStr
          };
          idle_time_hour_min_text_font.setProperty(hmUI.prop.TEXT, idle_HourMinStr);
         };

         console.log('day font');
         if (updateHour) {
          let idle_dayStr = timeSensor.day.toString();
          idle_dayStr = idle_dayStr.padStart(2, '0');
          idle_day_text_font.setProperty(hmUI.prop.TEXT, idle_dayStr);
         };

         console.log('day of week font');
         if (updateHour) {
          let idle_DOW_Str = idle_DOW_Array[timeSensor.week - 1];
          idle_dow_text_font.setProperty(hmUI.prop.TEXT, idle_DOW_Str);
         };

         console.log('month font');
         if (updateHour) {
          let idle_Month_Str = idle_Month_Array[timeSensor.month - 1];
          idle_month_name_font.setProperty(hmUI.prop.TEXT, idle_Month_Str);
         };

        };

        //#endregion
        function scale_call() {
         console.log('scale_call()');

         console.log('Weather city name');
         let weatherData = weatherSensor.getForecastWeather();
         let normal_cityNameStr = weatherData.cityName;
         normal_cityNameStr = normal_cityNameStr.toUpperCase();
         normal_city_name_text.setProperty(hmUI.prop.TEXT, normal_cityNameStr);

         console.log('Weather city name');
         let idle_cityNameStr = weatherData.cityName;
         idle_cityNameStr = idle_cityNameStr.toUpperCase();
         idle_city_name_text.setProperty(hmUI.prop.TEXT, idle_cityNameStr);

        };

        const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
         resume_call: (function () {
          console.log('resume_call()');
          scale_call();
          time_update(true, true);
          if (screenType == hmSetting.screen_type.WATCHFACE) {
           if (!normal_timerTimeUpdate) {
            normal_timerTimeUpdate = timer.createTimer(0, 1000, (function (option) {
             let updateHour = timeSensor.minute == 0 && timeSensor.second < 2;
             let updateMinute = timeSensor.second < 2;
             time_update(updateHour, updateMinute);
            })); // end timer 
           }; // end timer check
          }; // end screenType

          if (screenType == hmSetting.screen_type.AOD) {
           if (!idle_timerTimeUpdate) {
            idle_timerTimeUpdate = timer.createTimer(0, 1000, (function (option) {
             let updateHour = timeSensor.minute == 0 && timeSensor.second < 2;
             let updateMinute = timeSensor.second < 2;
             time_update(updateHour, updateMinute);
            })); // end timer 
           }; // end timer check
          }; // end screenType


          console.log('resume_call.js');
          // start resume_call.js

          loadSettings();
          autoToggleWeatherIcons();
          stopVibro();
          // end resume_call.js

         }),
         pause_call: (function () {
          console.log('pause_call()');
          if (normal_timerTimeUpdate) {
           timer.stopTimer(normal_timerTimeUpdate);
           normal_timerTimeUpdate = undefined;
          }
          if (normal_timerUpdateSec) {
           timer.stopTimer(normal_timerUpdateSec);
           normal_timerUpdateSec = undefined;
          }
          if (idle_timerTimeUpdate) {
           timer.stopTimer(idle_timerTimeUpdate);
           idle_timerTimeUpdate = undefined;
          }
          if (idle_timerUpdateSec) {
           timer.stopTimer(idle_timerUpdateSec);
           idle_timerUpdateSec = undefined;
          }

          console.log('pause_call.js');
          // start pause_call.js

          vibrate.stop();
          // end pause_call.js

         }),
        });

        //dynamic modify end
       },
       onInit() {
        logger.log('index page.js on init invoke');
       },
       build() {
        this.init_view();
        logger.log('index page.js on ready invoke');
       },
       onDestroy() {
        logger.log('index page.js on destroy invoke');
       }
      });;
     })();
    } catch (e) {
     console.log('Mini Program Error', e);
     e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));;
    }
