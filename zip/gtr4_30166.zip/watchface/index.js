﻿
    /*
    ** Watch_Face_Editor tool
    ** watchface js version v1.0.1
    ** Copyright © CashaCX75. All Rights Reserved
    */

    try {

      (() => {

        var __$$app$$__ = __$$hmAppManager$$__.currentApp;
        var __$$module$$__ = __$$app$$__.current;
        //drink is a name,can modify
        var h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__), 'drink');

        'use strict';

        //dynamic modify start

        
        let editBg = ''
        let normal_date_img_date_day = ''
        let idle_date_img_date_day = ''
        let editGroup_1  = ''
        let editGroup_2  = ''
        let editGroup_3  = ''
        let mask = ''
        let fg_mask = ''
        let editableTimePointers = ''


        //dynamic modify end

        //not required
        const logger = DeviceRuntimeCore.HmLogger.getLogger("yeguang");

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({

          init_view() {

            //dynamic modify start
                    
            
            editBg = hmUI.createWidget(hmUI.widget.WATCHFACE_EDIT_BG, {
              edit_id: 1002,
              x: 0,
              y: 0,
              // w: 466,
              // h: 466,
              // AOD_show: True,
              bg_config: [
                { id: 1, preview: 'p_0001.png', path: 'b_0001.png' },
                { id: 2, preview: 'p_0002.png', path: 'b_0002.png' },
                { id: 3, preview: 'p_0003.png', path: 'b_0003.png' },
                { id: 4, preview: 'p_0007.png', path: 'b_0004.png' },
              ],
              count: 4,
              default_id: 1,
              fg: '.png',
              tips_bg: 'faq.png',
              tips_x: 108,
              tips_y: 96,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: -26,
              day_startY: 303,
              day_sc_array: ["n_0001.png","n_0002.png","n_0003.png","n_0004.png","n_0005.png","n_0006.png","n_0007.png","n_0008.png","n_0009.png","n_0010.png"],
              day_tc_array: ["n_0001.png","n_0002.png","n_0003.png","n_0004.png","n_0005.png","n_0006.png","n_0007.png","n_0008.png","n_0009.png","n_0010.png"],
              day_en_array: ["n_0001.png","n_0002.png","n_0003.png","n_0004.png","n_0005.png","n_0006.png","n_0007.png","n_0008.png","n_0009.png","n_0010.png"],
              day_zero: 1,
              day_space: -14,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });



            idle_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: -26,
              day_startY: 303,
              day_sc_array: ["n_0001.png","n_0002.png","n_0003.png","n_0004.png","n_0005.png","n_0006.png","n_0007.png","n_0008.png","n_0009.png","n_0010.png"],
              day_tc_array: ["n_0001.png","n_0002.png","n_0003.png","n_0004.png","n_0005.png","n_0006.png","n_0007.png","n_0008.png","n_0009.png","n_0010.png"],
              day_en_array: ["n_0001.png","n_0002.png","n_0003.png","n_0004.png","n_0005.png","n_0006.png","n_0007.png","n_0008.png","n_0009.png","n_0010.png"],
              day_zero: 1,
              day_space: -14,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            editGroup_1 = hmUI.createWidget(hmUI.widget.WATCHFACE_EDIT_GROUP, {
              edit_id: 10021,
              x: 91,
              y: 177,
              w: 111,
              h: 111,
              select_image: 'c_0002.png',
              un_select_image: 'c_0003.png',
              default_type: hmUI.edit_type.BATTERY,
              optional_types: [
                { type: hmUI.edit_type.BATTERY, preview: 'x_0001.png' },
                { type: hmUI.edit_type.HEART, preview: 'x_0002.png' },
                { type: hmUI.edit_type.STAND, preview: 'x_0005.png' },
                { type: hmUI.edit_type.CAL, preview: 'x_0003.png' },
                { type: hmUI.edit_type.STEP, preview: 'x_0004.png' },
                { type: hmUI.edit_type.WEATHER, preview: 'x_0006.png' },
                { type: hmUI.edit_type.SPO2, preview: 'x_0007.png' },
                { type: hmUI.edit_type.PAI, preview: 'x_0008.png' },
                { type: hmUI.edit_type.ALTIMETER, preview: 'x_0009.png' },
              ],
              count: 9,
              tips_BG: 'faq.png',
              tips_x: 13,
              tips_y: -78,
              tips_width: 261,
              tips_margin: 0,
            });

            const editType_1 = editGroup_1.getProperty(hmUI.prop.CURRENT_TYPE);

            switch (editType_1) {
              case hmUI.edit_type.BATTERY:
                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                  x: 127,
                  y: 196,
                  font_array: ["o_0001.png","o_0002.png","o_0003.png","o_0004.png","o_0005.png","o_0006.png","o_0007.png","o_0008.png","o_0009.png","o_0010.png"],
                  padding: false,
                  h_space: -2,
                  align_h: hmUI.align.CENTER_H,
                  type: hmUI.data_type.BATTERY,
                  show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_AOD,
                });

                hmUI.createWidget(hmUI.widget.IMG, {
                  x: 91,
                  y: 177,
                  src: 'z_0001.png',
                  show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_AOD,
                });

                hmUI.createWidget(hmUI.widget.IMG_POINTER, {
                  src: 'u_0001.png',
                  center_x: 146,
                  center_y: 233,
                  x: 10,
                  y: 45,
                  start_angle: -135,
                  end_angle: 135,
                  type: hmUI.data_type.BATTERY,
                  show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_AOD,
                });
                break;

              case hmUI.edit_type.STEP:
                hmUI.createWidget(hmUI.widget.IMG, {
                  x: 91,
                  y: 177,
                  src: 'z_0004.png',
                  show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_AOD,
                });

                hmUI.createWidget(hmUI.widget.IMG_POINTER, {
                  src: 'u_0001.png',
                  center_x: 146,
                  center_y: 233,
                  x: 10,
                  y: 45,
                  start_angle: -135,
                  end_angle: 135,
                  type: hmUI.data_type.STEP,
                  show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_AOD,
                });
                break;

              case hmUI.edit_type.CAL:
                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                  x: 122,
                  y: 196,
                  font_array: ["o_0001.png","o_0002.png","o_0003.png","o_0004.png","o_0005.png","o_0006.png","o_0007.png","o_0008.png","o_0009.png","o_0010.png"],
                  padding: false,
                  h_space: -2,
                  align_h: hmUI.align.CENTER_H,
                  type: hmUI.data_type.CAL,
                  show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_AOD,
                });

                hmUI.createWidget(hmUI.widget.IMG, {
                  x: 91,
                  y: 177,
                  src: 'z_0003.png',
                  show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_AOD,
                });

                hmUI.createWidget(hmUI.widget.IMG_POINTER, {
                  src: 'u_0001.png',
                  center_x: 146,
                  center_y: 233,
                  x: 10,
                  y: 45,
                  start_angle: -135,
                  end_angle: 135,
                  type: hmUI.data_type.CAL,
                  show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_AOD,
                });
                break;

              case hmUI.edit_type.HEART:
                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                  x: 127,
                  y: 196,
                  font_array: ["o_0001.png","o_0002.png","o_0003.png","o_0004.png","o_0005.png","o_0006.png","o_0007.png","o_0008.png","o_0009.png","o_0010.png"],
                  padding: false,
                  h_space: -2,
                  align_h: hmUI.align.CENTER_H,
                  type: hmUI.data_type.HEART,
                  show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_AOD,
                });

                hmUI.createWidget(hmUI.widget.IMG, {
                  x: 91,
                  y: 177,
                  src: 'z_0002.png',
                  show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_AOD,
                });

                hmUI.createWidget(hmUI.widget.IMG_POINTER, {
                  src: 'u_0001.png',
                  center_x: 146,
                  center_y: 233,
                  x: 10,
                  y: 45,
                  start_angle: -135,
                  end_angle: 135,
                  type: hmUI.data_type.HEART,
                  show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_AOD,
                });
                break;

              case hmUI.edit_type.PAI:
                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                  x: 127,
                  y: 196,
                  font_array: ["o_0001.png","o_0002.png","o_0003.png","o_0004.png","o_0005.png","o_0006.png","o_0007.png","o_0008.png","o_0009.png","o_0010.png"],
                  padding: false,
                  h_space: 0,
                  align_h: hmUI.align.CENTER_H,
                  type: hmUI.data_type.PAI_WEEKLY,
                  show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_AOD,
                });

                hmUI.createWidget(hmUI.widget.IMG, {
                  x: 91,
                  y: 177,
                  src: 'z_0008.png',
                  show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_AOD,
                });

                hmUI.createWidget(hmUI.widget.IMG_POINTER, {
              src: 'u_0001.png',
              center_x: 146,
              center_y: 233,
              x: 10,
              y: 45,
              start_angle: -135,
              end_angle: 135,
              type: hmUI.data_type.PAI_WEEKLY,
              show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_AOD,
                });
                break;

              case hmUI.edit_type.STAND:
                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                  x: 115,
                  y: 196,
                  font_array: ["o_0001.png","o_0002.png","o_0003.png","o_0004.png","o_0005.png","o_0006.png","o_0007.png","o_0008.png","o_0009.png","o_0010.png"],
                  padding: false,
                  h_space: -2,
                  align_h: hmUI.align.CENTER_H,
                  type: hmUI.data_type.STAND,
                  show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_AOD,
                });

                editableZone_1_stand_current_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
                  x: 91,
                  y: 177,
                  src: 'z_0005.png',
                  show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_AOD,
                });

                hmUI.createWidget(hmUI.widget.IMG_POINTER, {
              src: 'u_0001.png',
              center_x: 146,
              center_y: 233,
              x: 10,
              y: 45,
              start_angle: -135,
              end_angle: 135,
              type: hmUI.data_type.STAND,
              show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_AOD,
                });
                break;

              case hmUI.edit_type.SPO2:
                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                  x: 133,
                  y: 220,
                  font_array: ["o_0001.png","o_0002.png","o_0003.png","o_0004.png","o_0005.png","o_0006.png","o_0007.png","o_0008.png","o_0009.png","o_0010.png"],
                  padding: false,
                  h_space: -2,
                  align_h: hmUI.align.LEFT,
                  type: hmUI.data_type.SPO2,
                  show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_AOD,
                });

                hmUI.createWidget(hmUI.widget.IMG, {
                  x: 91,
                  y: 177,
                  src: 'z_0007.png',
                  show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_AOD,
                });
                break;

              case hmUI.edit_type.WEATHER:
                hmUI.createWidget(hmUI.widget.IMG, {
                  x: 91,
                  y: 177,
                  src: 'z_0006.png',
                  show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_AOD,
                });

                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                  x: 126,
                  y: 206,
                  font_array: ["o_0001.png","o_0002.png","o_0003.png","o_0004.png","o_0005.png","o_0006.png","o_0007.png","o_0008.png","o_0009.png","o_0010.png"],
                  padding: false,
                  h_space: -2,
                  unit_sc: 'o_0012.png',
                  unit_tc: 'o_0012.png',
                  unit_en: 'o_0012.png',
                  negative_image: 'o_0011.png',
                  invalid_image: 'o_0013.png',
                  align_h: hmUI.align.CENTER_H,
                  type: hmUI.data_type.WEATHER_CURRENT,
                  show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_AOD,
                });

                hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
                  x: 129,
                  y: 235,
                  image_array: ["w_0001.png","w_0002.png","w_0003.png","w_0004.png","w_0005.png","w_0006.png","w_0007.png","w_0008.png","w_0009.png","w_0010.png","w_0011.png","w_0012.png","w_0013.png","w_0014.png","w_0015.png","w_0016.png","w_0017.png","w_0018.png","w_0019.png","w_0020.png","w_0021.png","w_0022.png","w_0023.png","w_0024.png","w_0025.png","w_0026.png","w_0027.png","w_0028.png","w_0029.png"],
                  image_length: 29,
                  type: hmUI.data_type.WEATHER_CURRENT,
                  show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_AOD,
                });
                break;

              case hmUI.edit_type.ALTIMETER:
                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                  x: 122,
                  y: 196,
                  font_array: ["o_0001.png","o_0002.png","o_0003.png","o_0004.png","o_0005.png","o_0006.png","o_0007.png","o_0008.png","o_0009.png","o_0010.png"],
                  padding: false,
                  h_space: -2,
                  align_h: hmUI.align.LEFT,
                  type: hmUI.data_type.ALTIMETER,
                  show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_AOD,
                });

                hmUI.createWidget(hmUI.widget.IMG, {
                  x: 91,
                  y: 177,
                  src: 'z_0009.png',
                  show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_AOD,
                });

                hmUI.createWidget(hmUI.widget.IMG_POINTER, {
                  src: 'u_0001.png',
                  center_x: 146,
                  center_y: 233,
                  x: 10,
                  y: 45,
                  start_angle: -135,
                  end_angle: 135,
                  type: hmUI.data_type.ALTIMETER,
                  show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_AOD,
                });
                break;
            }; // end switch

            editGroup_2 = hmUI.createWidget(hmUI.widget.WATCHFACE_EDIT_GROUP, {
              edit_id: 10022,
              x: 178,
              y: 259,
              w: 111,
              h: 111,
              select_image: 'c_0002.png',
              un_select_image: 'c_0003.png',
              default_type: hmUI.edit_type.CAL,
              optional_types: [
                { type: hmUI.edit_type.CAL, preview: 'x_0003.png' },
                { type: hmUI.edit_type.BATTERY, preview: 'x_0001.png' },
                { type: hmUI.edit_type.HEART, preview: 'x_0002.png' },
                { type: hmUI.edit_type.STEP, preview: 'x_0004.png' },
                { type: hmUI.edit_type.STAND, preview: 'x_0005.png' },
                { type: hmUI.edit_type.WEATHER, preview: 'x_0006.png' },
                { type: hmUI.edit_type.SPO2, preview: 'x_0007.png' },
                { type: hmUI.edit_type.PAI, preview: 'x_0008.png' },
                { type: hmUI.edit_type.ALTIMETER, preview: 'x_0009.png' },
              ],
              count: 9,
              tips_BG: 'faq.png',
              tips_x: -74,
              tips_y: -160,
              tips_width: 261,
              tips_margin: 0,
            });

            const editType_2 = editGroup_2.getProperty(hmUI.prop.CURRENT_TYPE);

            switch (editType_2) {
              case hmUI.edit_type.BATTERY:
                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                  x: 215,
                  y: 278,
                  font_array: ["o_0001.png","o_0002.png","o_0003.png","o_0004.png","o_0005.png","o_0006.png","o_0007.png","o_0008.png","o_0009.png","o_0010.png"],
                  padding: false,
                  h_space: -2,
                  align_h: hmUI.align.CENTER_H,
                  type: hmUI.data_type.BATTERY,
                  show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_AOD,
                });

                hmUI.createWidget(hmUI.widget.IMG, {
                  x: 178,
                  y: 259,
                  src: 'z_0001.png',
                  show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_AOD,
                });

                hmUI.createWidget(hmUI.widget.IMG_POINTER, {
                  src: 'u_0001.png',
                  center_x: 233,
                  center_y: 315,
                  x: 10,
                  y: 45,
                  start_angle: -135,
                  end_angle: 135,
                  type: hmUI.data_type.BATTERY,
                  show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_AOD,
                });
                break;

              case hmUI.edit_type.STEP:
                hmUI.createWidget(hmUI.widget.IMG_POINTER, {
                  src: 'u_0001.png',
                  center_x: 233,
                  center_y: 315,
                  x: 10,
                  y: 45,
                  start_angle: -135,
                  end_angle: 135,
                  scale_sc: 'z_0004.png',
                  scale_tc: 'z_0004.png',
                  scale_en: 'z_0004.png',
                  scale_x: 178,
                  scale_y: 259,
                  type: hmUI.data_type.STEP,
                  show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_AOD,
                });
                break;

              case hmUI.edit_type.CAL:
                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                  x: 208,
                  y: 278,
                  font_array: ["o_0001.png","o_0002.png","o_0003.png","o_0004.png","o_0005.png","o_0006.png","o_0007.png","o_0008.png","o_0009.png","o_0010.png"],
                  padding: false,
                  h_space: -2,
                  align_h: hmUI.align.CENTER_H,
                  type: hmUI.data_type.CAL,
                  show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_AOD,
                });

                hmUI.createWidget(hmUI.widget.IMG, {
                  x: 178,
                  y: 259,
                  src: 'z_0003.png',
                  show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_AOD,
                });

                hmUI.createWidget(hmUI.widget.IMG_POINTER, {
                  src: 'u_0001.png',
                  center_x: 233,
                  center_y: 315,
                  x: 10,
                  y: 45,
                  start_angle: -135,
                  end_angle: 135,
                  type: hmUI.data_type.CAL,
                  show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_AOD,
                });
                break;

              case hmUI.edit_type.HEART:
                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                  x: 215,
                  y: 278,
                  font_array: ["o_0001.png","o_0002.png","o_0003.png","o_0004.png","o_0005.png","o_0006.png","o_0007.png","o_0008.png","o_0009.png","o_0010.png"],
                  padding: false,
                  h_space: -2,
                  align_h: hmUI.align.CENTER_H,
                  type: hmUI.data_type.HEART,
                  show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_AOD,
                });

                hmUI.createWidget(hmUI.widget.IMG, {
                  x: 178,
                  y: 259,
                  src: 'z_0002.png',
                  show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_AOD,
                });

                hmUI.createWidget(hmUI.widget.IMG_POINTER, {
                  src: 'u_0001.png',
                  center_x: 233,
                  center_y: 315,
                  x: 10,
                  y: 45,
                  start_angle: -135,
                  end_angle: 135,
                  type: hmUI.data_type.HEART,
                  show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_AOD,
                });
                break;

              case hmUI.edit_type.PAI:
                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                  x: 215,
                  y: 278,
                  font_array: ["o_0001.png","o_0002.png","o_0003.png","o_0004.png","o_0005.png","o_0006.png","o_0007.png","o_0008.png","o_0009.png","o_0010.png"],
                  padding: false,
                  h_space: -2,
                  align_h: hmUI.align.CENTER_H,
                  type: hmUI.data_type.PAI_WEEKLY,
                  show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_AOD,
                });

                hmUI.createWidget(hmUI.widget.IMG, {
                  x: 178,
                  y: 259,
                  src: 'z_0008.png',
                  show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_AOD,
                });

                hmUI.createWidget(hmUI.widget.IMG_POINTER, {
              src: 'u_0001.png',
              center_x: 233,
              center_y: 315,
              x: 10,
              y: 45,
              start_angle: -135,
              end_angle: 135,
              type: hmUI.data_type.PAI_WEEKLY,
              show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_AOD,
                });
                break;

              case hmUI.edit_type.STAND:
                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                  x: 203,
                  y: 278,
                  font_array: ["o_0001.png","o_0002.png","o_0003.png","o_0004.png","o_0005.png","o_0006.png","o_0007.png","o_0008.png","o_0009.png","o_0010.png"],
                  padding: false,
                  h_space: -2,
                  align_h: hmUI.align.CENTER_H,
                  type: hmUI.data_type.STAND,
                  show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_AOD,
                });

                editableZone_2_stand_current_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
                  x: 178,
                  y: 259,
                  src: 'z_0005.png',
                  show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_AOD,
                });

                hmUI.createWidget(hmUI.widget.IMG_POINTER, {
              src: 'u_0001.png',
              center_x: 233,
              center_y: 315,
              x: 10,
              y: 45,
              start_angle: -135,
              end_angle: 135,
              type: hmUI.data_type.STAND,
              show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_AOD,
                });
                break;

              case hmUI.edit_type.SPO2:
                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                  x: 214,
                  y: 301,
                  font_array: ["o_0001.png","o_0002.png","o_0003.png","o_0004.png","o_0005.png","o_0006.png","o_0007.png","o_0008.png","o_0009.png","o_0010.png"],
                  padding: false,
                  h_space: -2,
                  align_h: hmUI.align.CENTER_H,
                  type: hmUI.data_type.SPO2,
                  show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_AOD,
                });

                hmUI.createWidget(hmUI.widget.IMG, {
                  x: 178,
                  y: 259,
                  src: 'z_0007.png',
                  show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_AOD,
                });
                break;

              case hmUI.edit_type.WEATHER:
                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                  x: 209,
                  y: 286,
                  font_array: ["o_0001.png","o_0002.png","o_0003.png","o_0004.png","o_0005.png","o_0006.png","o_0007.png","o_0008.png","o_0009.png","o_0010.png"],
                  padding: false,
                  h_space: -2,
                  unit_sc: 'o_0012.png',
                  unit_tc: 'o_0012.png',
                  unit_en: 'o_0012.png',
                  negative_image: 'o_0011.png',
                  invalid_image: 'o_0013.png',
                  align_h: hmUI.align.CENTER_H,
                  type: hmUI.data_type.WEATHER_CURRENT,
                  show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_AOD,
                });

                hmUI.createWidget(hmUI.widget.IMG, {
              x: 178,
              y: 259,
              src: 'z_0006.png',
              show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_AOD,
                });

                hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
                  x: 216,
                  y: 317,
                  image_array: ["w_0001.png","w_0002.png","w_0003.png","w_0004.png","w_0005.png","w_0006.png","w_0007.png","w_0008.png","w_0009.png","w_0010.png","w_0011.png","w_0012.png","w_0013.png","w_0014.png","w_0015.png","w_0016.png","w_0017.png","w_0018.png","w_0019.png","w_0020.png","w_0021.png","w_0022.png","w_0023.png","w_0024.png","w_0025.png","w_0026.png","w_0027.png","w_0028.png","w_0029.png"],
                  image_length: 29,
                  type: hmUI.data_type.WEATHER_CURRENT,
                  show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_AOD,
                });
                break;

              case hmUI.edit_type.ALTIMETER:
                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                  x: 209,
                  y: 278,
                  font_array: ["o_0001.png","o_0002.png","o_0003.png","o_0004.png","o_0005.png","o_0006.png","o_0007.png","o_0008.png","o_0009.png","o_0010.png"],
                  padding: false,
                  h_space: -2,
                  align_h: hmUI.align.CENTER_H,
                  type: hmUI.data_type.ALTIMETER,
                  show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_AOD,
                });

                hmUI.createWidget(hmUI.widget.IMG, {
                  x: 178,
                  y: 259,
                  src: 'z_0009.png',
                  show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_AOD,
                });

                hmUI.createWidget(hmUI.widget.IMG_POINTER, {
                  src: 'u_0001.png',
                  center_x: 233,
                  center_y: 315,
                  x: 10,
                  y: 45,
                  start_angle: -135,
                  end_angle: 135,
                  type: hmUI.data_type.ALTIMETER,
                  show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_AOD,
                });
                break;
            }; // end switch

            editGroup_3 = hmUI.createWidget(hmUI.widget.WATCHFACE_EDIT_GROUP, {
              edit_id: 10023,
              x: 264,
              y: 177,
              w: 111,
              h: 111,
              select_image: 'c_0002.png',
              un_select_image: 'c_0003.png',
              default_type: hmUI.edit_type.HEART,
              optional_types: [
                { type: hmUI.edit_type.HEART, preview: 'x_0002.png' },
                { type: hmUI.edit_type.CAL, preview: 'x_0003.png' },
                { type: hmUI.edit_type.BATTERY, preview: 'x_0001.png' },
                { type: hmUI.edit_type.STEP, preview: 'x_0004.png' },
                { type: hmUI.edit_type.STAND, preview: 'x_0005.png' },
                { type: hmUI.edit_type.WEATHER, preview: 'x_0006.png' },
                { type: hmUI.edit_type.SPO2, preview: 'x_0007.png' },
                { type: hmUI.edit_type.PAI, preview: 'x_0008.png' },
                { type: hmUI.edit_type.ALTIMETER, preview: 'x_0009.png' },
              ],
              count: 9,
              tips_BG: 'faq.png',
              tips_x: -160,
              tips_y: -78,
              tips_width: 261,
              tips_margin: 0,
            });

            const editType_3 = editGroup_3.getProperty(hmUI.prop.CURRENT_TYPE);

            switch (editType_3) {
              case hmUI.edit_type.BATTERY:
                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                  x: 301,
                  y: 196,
                  font_array: ["o_0001.png","o_0002.png","o_0003.png","o_0004.png","o_0005.png","o_0006.png","o_0007.png","o_0008.png","o_0009.png","o_0010.png"],
                  padding: false,
                  h_space: -2,
                  align_h: hmUI.align.CENTER_H,
                  type: hmUI.data_type.BATTERY,
                  show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_AOD,
                });

                hmUI.createWidget(hmUI.widget.IMG, {
                  x: 264,
                  y: 177,
                  src: 'z_0001.png',
                  show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_AOD,
                });

                hmUI.createWidget(hmUI.widget.IMG_POINTER, {
                  src: 'u_0001.png',
                  center_x: 318,
                  center_y: 233,
                  x: 10,
                  y: 45,
                  start_angle: -135,
                  end_angle: 135,
                  type: hmUI.data_type.BATTERY,
                  show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_AOD,
                });
                break;

              case hmUI.edit_type.STEP:
                hmUI.createWidget(hmUI.widget.IMG_POINTER, {
                  src: 'u_0001.png',
                  center_x: 318,
                  center_y: 233,
                  x: 10,
                  y: 45,
                  start_angle: -135,
                  end_angle: 135,
                  scale_sc: 'z_0004.png',
                  scale_tc: 'z_0004.png',
                  scale_en: 'z_0004.png',
                  scale_x: 264,
                  scale_y: 177,
                  type: hmUI.data_type.STEP,
                  show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_AOD,
                });
                break;

              case hmUI.edit_type.CAL:
                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                  x: 301,
                  y: 196,
                  font_array: ["o_0001.png","o_0002.png","o_0003.png","o_0004.png","o_0005.png","o_0006.png","o_0007.png","o_0008.png","o_0009.png","o_0010.png"],
                  padding: false,
                  h_space: -2,
                  align_h: hmUI.align.LEFT,
                  type: hmUI.data_type.CAL,
                  show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_AOD,
                });

                hmUI.createWidget(hmUI.widget.IMG, {
                  x: 264,
                  y: 177,
                  src: 'z_0003.png',
                  show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_AOD,
                });

                hmUI.createWidget(hmUI.widget.IMG_POINTER, {
                  src: 'u_0001.png',
                  center_x: 318,
                  center_y: 233,
                  x: 10,
                  y: 45,
                  start_angle: -135,
                  end_angle: 135,
                  type: hmUI.data_type.CAL,
                  show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_AOD,
                });
                break;

              case hmUI.edit_type.HEART:
                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                  x: 301,
                  y: 196,
                  font_array: ["o_0001.png","o_0002.png","o_0003.png","o_0004.png","o_0005.png","o_0006.png","o_0007.png","o_0008.png","o_0009.png","o_0010.png"],
                  padding: false,
                  h_space: -2,
                  align_h: hmUI.align.CENTER_H,
                  type: hmUI.data_type.HEART,
                  show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_AOD,
                });

                hmUI.createWidget(hmUI.widget.IMG, {
                  x: 264,
                  y: 177,
                  src: 'z_0002.png',
                  show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_AOD,
                });

                hmUI.createWidget(hmUI.widget.IMG_POINTER, {
                  src: 'u_0001.png',
                  center_x: 318,
                  center_y: 233,
                  x: 10,
                  y: 45,
                  start_angle: -135,
                  end_angle: 135,
                  type: hmUI.data_type.HEART,
                  show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_AOD,
                });
                break;

              case hmUI.edit_type.PAI:
                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                  x: 301,
                  y: 196,
                  font_array: ["o_0001.png","o_0002.png","o_0003.png","o_0004.png","o_0005.png","o_0006.png","o_0007.png","o_0008.png","o_0009.png","o_0010.png"],
                  padding: false,
                  h_space: -2,
                  align_h: hmUI.align.CENTER_H,
                  type: hmUI.data_type.PAI_WEEKLY,
                  show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_AOD,
                });

                hmUI.createWidget(hmUI.widget.IMG, {
                  x: 264,
                  y: 177,
                  src: 'z_0008.png',
                  show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_AOD,
                });

                hmUI.createWidget(hmUI.widget.IMG_POINTER, {
              src: 'u_0001.png',
              center_x: 318,
              center_y: 233,
              x: 10,
              y: 45,
              start_angle: -135,
              end_angle: 135,
              type: hmUI.data_type.PAI_WEEKLY,
              show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_AOD,
                });
                break;

              case hmUI.edit_type.STAND:
                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                  x: 290,
                  y: 196,
                  font_array: ["o_0001.png","o_0002.png","o_0003.png","o_0004.png","o_0005.png","o_0006.png","o_0007.png","o_0008.png","o_0009.png","o_0010.png"],
                  padding: false,
                  h_space: -2,
                  align_h: hmUI.align.CENTER_H,
                  type: hmUI.data_type.STAND,
                  show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_AOD,
                });

                editableZone_3_stand_current_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
                  x: 264,
                  y: 177,
                  src: 'z_0005.png',
                  show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_AOD,
                });
                break;

              case hmUI.edit_type.SPO2:
                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                  x: 301,
                  y: 220,
                  font_array: ["o_0001.png","o_0002.png","o_0003.png","o_0004.png","o_0005.png","o_0006.png","o_0007.png","o_0008.png","o_0009.png","o_0010.png"],
                  padding: false,
                  h_space: -2,
                  align_h: hmUI.align.CENTER_H,
                  type: hmUI.data_type.SPO2,
                  show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_AOD,
                });

                hmUI.createWidget(hmUI.widget.IMG, {
                  x: 264,
                  y: 177,
                  src: 'z_0007.png',
                  show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_AOD,
                });
                break;

              case hmUI.edit_type.WEATHER:
                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                  x: 297,
                  y: 205,
                  font_array: ["o_0001.png","o_0002.png","o_0003.png","o_0004.png","o_0005.png","o_0006.png","o_0007.png","o_0008.png","o_0009.png","o_0010.png"],
                  padding: false,
                  h_space: -2,
                  unit_sc: 'o_0012.png',
                  unit_tc: 'o_0012.png',
                  unit_en: 'o_0012.png',
                  negative_image: 'o_0011.png',
                  invalid_image: 'o_0013.png',
                  align_h: hmUI.align.CENTER_H,
                  type: hmUI.data_type.WEATHER_CURRENT,
                  show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_AOD,
                });

                hmUI.createWidget(hmUI.widget.IMG, {
              x: 264,
              y: 177,
              src: 'z_0006.png',
              show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_AOD,
                });

                hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
                  x: 302,
                  y: 235,
                  image_array: ["w_0001.png","w_0002.png","w_0003.png","w_0004.png","w_0005.png","w_0006.png","w_0007.png","w_0008.png","w_0009.png","w_0010.png","w_0011.png","w_0012.png","w_0013.png","w_0014.png","w_0015.png","w_0016.png","w_0017.png","w_0018.png","w_0019.png","w_0020.png","w_0021.png","w_0022.png","w_0023.png","w_0024.png","w_0025.png","w_0026.png","w_0027.png","w_0028.png","w_0029.png"],
                  image_length: 29,
                  type: hmUI.data_type.WEATHER_CURRENT,
                  show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_AOD,
                });
                break;

              case hmUI.edit_type.ALTIMETER:
                hmUI.createWidget(hmUI.widget.IMG_POINTER, {
                  src: 'u_0001.png',
                  center_x: 318,
                  center_y: 233,
                  x: 10,
                  y: 45,
                  start_angle: -135,
                  end_angle: 135,
                  type: hmUI.data_type.ALTIMETER,
                  show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_AOD,
                });

                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                  x: 290,
                  y: 196,
                  font_array: ["o_0001.png","o_0002.png","o_0003.png","o_0004.png","o_0005.png","o_0006.png","o_0007.png","o_0008.png","o_0009.png","o_0010.png"],
                  padding: false,
                  h_space: 0,
                  align_h: hmUI.align.CENTER_H,
                  type: hmUI.data_type.ALTIMETER,
                  show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_AOD,
                });

                hmUI.createWidget(hmUI.widget.IMG, {
                  x: 264,
                  y: 177,
                  src: 'z_0009.png',
                  show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_AOD,
                });
                break;
            }; // end switch

            mask = hmUI.createWidget(hmUI.widget.WATCHFACE_EDIT_MASK, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: 'c_0004.png',
              show_level: hmUI.show_level.ONLY_EDIT,
            });

            fg_mask = hmUI.createWidget(hmUI.widget.WATCHFACE_EDIT_FG_MASK, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: 'c_0005.png',
              show_level: hmUI.show_level.ONLY_EDIT,
            });

            const pointerEdit = hmUI.createWidget(hmUI.widget.WATCHFACE_EDIT_POINTER, {
              edit_id: 1003,
              x: 0,
              y: 0,
              config: [
                {
                  id: 1,
                  second: {
                    centerX: 233,
                    centerY: 233,
                    posX: 32,
                    posY: 186,
                    path: 's_0001.png',
                  },
                  hour: {
                    centerX: 233,
                    centerY: 233,
                    posX: 27,
                    posY: 109,
                    path: 'h_0001.png',
                  },
                  minute: {
                    centerX: 233,
                    centerY: 233,
                    posX: 24,
                    posY: 170,
                    path: 'm_0001.png',
                  },
                  preview: 'p_0004.png',
                },
                {
                  id: 2,
                  second: {
                    centerX: 233,
                    centerY: 233,
                    posX: 32,
                    posY: 186,
                    path: 's_0002.png',
                  },
                  hour: {
                    centerX: 233,
                    centerY: 233,
                    posX: 27,
                    posY: 109,
                    path: 'h_0002.png',
                  },
                  minute: {
                    centerX: 233,
                    centerY: 233,
                    posX: 24,
                    posY: 170,
                    path: 'm_0002.png',
                  },
                  preview: 'p_0005.png',
                },
                {
                  id: 3,
                  second: {
                    centerX: 233,
                    centerY: 233,
                    posX: 32,
                    posY: 186,
                    path: 's_0003.png',
                  },
                  hour: {
                    centerX: 233,
                    centerY: 233,
                    posX: 27,
                    posY: 109,
                    path: 'h_0003.png',
                  },
                  minute: {
                    centerX: 233,
                    centerY: 233,
                    posX: 24,
                    posY: 170,
                    path: 'm_0003.png',
                  },
                  preview: 'p_0006.png',
                },
              ],
              count: 3,
              default_id: 1,
              fg: 'c_0001.png',
              tips_x: 108,
              tips_y: 300,
              tips_bg: 'faq.png',
            });
            const pointerProp = pointerEdit.getProperty(hmUI.prop.CURRENT_CONFIG, true);
            editableTimePointers = hmUI.createWidget(hmUI.widget.TIME_POINTER, pointerProp);


            //dynamic modify end
          },

          onInit() {
            console.log('index page.js on init invoke')

            this.init_view()

          },

          onReady() {
            console.log('index page.js on ready invoke')
          },

          onShow() {
            console.log('index page.js on show invoke')
          },

          onHide() {
            console.log('index page.js on hide invoke')
          },

          onDestory() {
            console.log('index page.js on destory invoke')
          },
        });

      })()
    } catch (e) {
      console.log(e)
    }
  