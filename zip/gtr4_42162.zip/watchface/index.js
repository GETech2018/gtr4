﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        const logger = Logger.getLogger('watchface_SashaCX75');
        //end of ignored block

        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_system_disconnect_img = ''
        let normal_system_clock_img = ''
        let normal_date_img_date_week_img = ''
        let normal_date_img_date_year = ''
        let normal_date_img_date_month = ''
        let normal_date_img_date_day = ''
        let normal_digital_clock_img_time = ''
        let normal_analog_clock_time_pointer_second = ''
        let normal_step_jumpable_img_click = ''
        let normal_heart_jumpable_img_click = ''
        let normal_battery_jumpable_img_click = ''
        let normal_temperature_jumpable_img_click = ''
        let normal_altimeter_jumpable_img_click = ''
        let normal_stress_jumpable_img_click = ''
        let normal_stopwatch_jumpable_img_click = ''
        let normal_alarm_jumpable_img_click = ''
        let normal_fatBurning_jumpable_img_click = ''


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            console.log('Watch_Face.ScreenNormal');
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 466,
              h: 466,
              src: 'future.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 177,
              y: 287,
              src: 'blue.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 252,
              y: 285,
              src: 'bud.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 145,
              y: 189,
              week_en: ["day_01.png","day_02.png","day_03.png","day_04.png","day_05.png","day_06.png","day_07.png"],
              week_tc: ["day_01.png","day_02.png","day_03.png","day_04.png","day_05.png","day_06.png","day_07.png"],
              week_sc: ["day_01.png","day_02.png","day_03.png","day_04.png","day_05.png","day_06.png","day_07.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_year = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              year_startX: 271,
              year_startY: 160,
              year_sc_array: ["date_00.png","date_01.png","date_02.png","date_03.png","date_04.png","date_05.png","date_06.png","date_07.png","date_08.png","date_09.png"],
              year_tc_array: ["date_00.png","date_01.png","date_02.png","date_03.png","date_04.png","date_05.png","date_06.png","date_07.png","date_08.png","date_09.png"],
              year_en_array: ["date_00.png","date_01.png","date_02.png","date_03.png","date_04.png","date_05.png","date_06.png","date_07.png","date_08.png","date_09.png"],
              year_zero: 0,
              year_space: 3,
              year_align: hmUI.align.LEFT,
              year_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_month = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 209,
              month_startY: 160,
              month_sc_array: ["date_00.png","date_01.png","date_02.png","date_03.png","date_04.png","date_05.png","date_06.png","date_07.png","date_08.png","date_09.png"],
              month_tc_array: ["date_00.png","date_01.png","date_02.png","date_03.png","date_04.png","date_05.png","date_06.png","date_07.png","date_08.png","date_09.png"],
              month_en_array: ["date_00.png","date_01.png","date_02.png","date_03.png","date_04.png","date_05.png","date_06.png","date_07.png","date_08.png","date_09.png"],
              month_zero: 1,
              month_space: 3,
              month_align: hmUI.align.CENTER_H,
              month_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 149,
              day_startY: 160,
              day_sc_array: ["date_00.png","date_01.png","date_02.png","date_03.png","date_04.png","date_05.png","date_06.png","date_07.png","date_08.png","date_09.png"],
              day_tc_array: ["date_00.png","date_01.png","date_02.png","date_03.png","date_04.png","date_05.png","date_06.png","date_07.png","date_08.png","date_09.png"],
              day_en_array: ["date_00.png","date_01.png","date_02.png","date_03.png","date_04.png","date_05.png","date_06.png","date_07.png","date_08.png","date_09.png"],
              day_zero: 1,
              day_space: 3,
              day_align: hmUI.align.RIGHT,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 129,
              hour_startY: 237,
              hour_array: ["t_00.png","t_01.png","t_02.png","t_03.png","t_04.png","t_05.png","t_06.png","t_07.png","t_08.png","t_09.png"],
              hour_zero: 1,
              hour_space: 8,
              hour_angle: 0,
              hour_align: hmUI.align.RIGHT,

              minute_startX: 247,
              minute_startY: 237,
              minute_array: ["t_00.png","t_01.png","t_02.png","t_03.png","t_04.png","t_05.png","t_06.png","t_07.png","t_08.png","t_09.png"],
              minute_zero: 1,
              minute_space: 8,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_second = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              second_path: 'sec.png',
              second_centerX: 233,
              second_centerY: 233,
              second_posX: 3,
              second_posY: 130,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            console.log('Watch_Face.Shortcuts');

            normal_step_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 202,
              y: 24,
              w: 65,
              h: 65,
              src: 'empty.png',
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 278,
              y: 38,
              w: 65,
              h: 65,
              src: 'empty.png',
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 28,
              y: 234,
              w: 65,
              h: 65,
              src: 'empty.png',
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 59,
              y: 305,
              w: 65,
              h: 65,
              src: 'empty.png',
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_altimeter_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 123,
              y: 356,
              w: 65,
              h: 65,
              src: 'empty.png',
              type: hmUI.data_type.ALTIMETER,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_stress_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 64,
              y: 84,
              w: 65,
              h: 65,
              src: 'empty.png',
              type: hmUI.data_type.STRESS,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_stopwatch_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 275,
              y: 359,
              w: 65,
              h: 65,
              src: 'empty.png',
              type: hmUI.data_type.STOP_WATCH,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_alarm_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 29,
              y: 157,
              w: 65,
              h: 65,
              src: 'empty.png',
              type: hmUI.data_type.ALARM_CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_fatBurning_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 128,
              y: 38,
              w: 65,
              h: 65,
              src: 'empty.png',
              type: hmUI.data_type.FAT_BURNING,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}