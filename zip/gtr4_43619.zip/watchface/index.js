﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        //const logger = Logger.getLogger('watchface_SashaCX75');
        const logger = DeviceRuntimeCore.HmLogger.getLogger('watchface_SashaCX75')
        //end of ignored block

        //dynamic modify start

        
        console.log('user_functions.js');
        // start user_functions.js

      let normal_SUN_CURRENT_PROGRESS = '';
      let normal_weather_text_font = '';
      let normal_hour_text_font = '';
      let normal_min_text_font = '';
      let normal_temp_text_font = '';
      let normal_press_text_font = '';
      let normal_second_pointer = '';
      let normal_readiness_icon_img = '';


      let weather = hmSensor.createSensor(hmSensor.id.WEATHER);
   const baro = hmSensor.createSensor(hmSensor.id.BARO);
    const pressureValue = baro.pressure;
   // const altitudeValue = baro.altitude;      

      let weatherData = weather.getForecastWeather();
      let sunData = weatherData.tideData;
      let today = '';
      let sunriseMins = '';
      let sunsetMins = '';
      let sunriseMins_def = 8 * 60; // время восхода
      let sunsetMins_def = 20 * 60; // и заката по умолчанию
      let curMins = '';
      let idle_SUN_CURRENT_PROGRESS = '';
      let isDayIcons = true;

      const screenType = hmSetting.getScreenType();

      function autoToggleWeatherIcons() {
        if (!timeSensor) timeSensor = hmSensor.createSensor(hmSensor.id.TIME);
		  

       weatherData = weather.getForecastWeather();
       sunData = weatherData.tideData;
       if (sunData.count > 0) {
        today = sunData.data[0];
        sunriseMins = today.sunrise.hour * 60 + today.sunrise.minute;
        sunsetMins = today.sunset.hour * 60 + today.sunset.minute;
       } else {
        sunriseMins = sunriseMins_def;
        sunsetMins = sunsetMins_def;
       }

       curMins = timeSensor.hour * 60 + timeSensor.minute;
       let isDayNow = (curMins >= sunriseMins) && (curMins < sunsetMins);

       if (isDayNow) {
        if (!isDayIcons) {
         isDayIcons = true;
        }
       } else {
        if (isDayIcons) {
         isDayIcons = false;
        }

       }

//       normal_sun_low_text_font.setProperty(hmUI.prop.VISIBLE, isDayIcons);
//       normal_sun_high_text_font.setProperty(hmUI.prop.VISIBLE, !isDayIcons);


       let sunAngle;
       if (isDayNow) {
        // Расчет для дня
        sunAngle = 90 + 180 * (curMins - sunriseMins) / (sunsetMins - sunriseMins);
       } else {
        // Расчет для ночи
        const nightDuration = (24 * 60 - sunsetMins) + sunriseMins;
        let timeFromSunset;

        if (curMins >= sunsetMins) {
         // После заката до полуночи
         timeFromSunset = curMins - sunsetMins;
        } else {
         // После полуночи до восхода
         timeFromSunset = (24 * 60 - sunsetMins) + curMins;
        }
        sunAngle = 270 + 180 * (timeFromSunset / nightDuration);
       }
		  
       shotWeaterhNames = isDayIcons == false ? ["Облачно ночью", "Местами дождь", "Местами снег", "Ясно ночью", "Пасмурно ночью", "Слабый дождь", "Слабый снег", "Умеренный дождь", "Умеренный снег", "Сильный снегопад", "Сильный дождь", "Песчаная буря", "Мокрый снег", "Туман", "Дымка", "Дождь с грозой", "Метель", "Пыльно", "Ливень", "Дождь с градом", "Сильный дождь с градом", "Сильный дождь ", "Песчаная буря", "Сильная песчаная буря", "Сильный дождь", "Неизвестная погода", "Облачно ночью", "Дождливо ночью", "Ясно ночью"] : ["Облачно", "Местами дождь", "Местами снег", "Cолнечно", "Пасмурно", "Слабый дождь", "Слабый снег", "Умеренный дождь", "Умеренный снег", "Сильный снегопад", "Сильный дождь", "Песчаная буря", "Мокрый снег", "Туман", "Дымка", "Дождь с грозой", "Метель", "Пыльно", "Ливень", "Дождь с градом", "Сильный дождь с градом", "Сильный дождь ", "Песчаная буря", "Сильная песчаная буря ", "Сильный дождь", "Неизвестная погода", "Облачно ночью", "Дождливо ночью", "Ясно ночью"];		  
		  
       let curAirIconIndex = weather.curAirIconIndex;

       normal_SUN_CURRENT_PROGRESS.setProperty(hmUI.prop.ANGLE, sunAngle);
       normal_weather_text_font.setProperty(hmUI.prop.TEXT, shotWeaterhNames[curAirIconIndex].toUpperCase());
		  
/*       if (screenType == hmSetting.screen_type.AOD) {
        idle_SUN_CURRENT_PROGRESS.setProperty(hmUI.prop.ANGLE, sunAngle);
        idle_sun_low_text_font.setProperty(hmUI.prop.VISIBLE, isDayIcons);
        idle_sun_high_text_font.setProperty(hmUI.prop.VISIBLE, !isDayIcons);
       }; // end screenType*/
      }
      
            const vibrate = hmSensor.createSensor(hmSensor.id.VIBRATE);
            let timer_StopVibrate = null;


            function vibro(scene = 25) {
              let stopDelay = 50;
              stopVibro();
              vibrate.stop();
              vibrate.scene = scene;
              if(scene < 23 || scene > 25) stopDelay = 1300;
              vibrate.start();
              timer_StopVibrate = timer.createTimer(stopDelay, 3000, stopVibro, {});
            }

            function stopVibro(){
              vibrate.stop();
              if(timer_StopVibrate) timer.stopTimer(timer_StopVibrate);
            }      
        // end user_functions.js

        let normal_stand_icon_img = ''
        let normal_fat_burning_icon_img = ''
        let normal_system_disconnect_img = ''
        let normal_system_clock_img = ''
        let normal_month_name_font = ''
        let normal_Month_Array = ['ЯНВ', 'ФЕВ', 'МАР', 'АПР', 'МАЙ', 'ИЮН', 'ИЮЛ', 'АВГ', 'СЕН', 'ОКТ', 'НОЯ', 'ДЕК', ];
        let normal_dow_text_font = ''
        let normal_DOW_Array = ['ПНД', 'ВТР', 'СРД', 'ЧТВ', 'ПТН', 'СБТ', 'ВСК'];
        let normal_image_img = ''
        let normal_calorie_current_text_font = ''
        let normal_calorie_circle_scale = ''
        let normal_calorie_icon_img = ''
        let normal_calorie_pointer_progress_img_pointer = ''
        let normal_heart_rate_circle_scale_2 = ''
        let normal_heart_rate_icon_img = ''
        let normal_heart_rate_pointer_progress_img_pointer = ''
        let normal_heart_rate_text_font = ''
        let normal_battery_circle_scale = ''
        let normal_battery_icon_img = ''
        let normal_battery_pointer_progress_img_pointer = ''
        let normal_battery_current_text_font = ''
        let normal_step_circle_scale = ''
        let normal_step_icon_img = ''
        let normal_step_current_text_font = ''
        let normal_step_pointer_progress_img_pointer = ''
        let normal_distance_current_text_font = ''
        let normal_city_name_text = ''
        let normal_second_circle_scale = ''
        let normal_timerUpdateSec = undefined;
        let normal_stress_icon_img = ''
        let normal_day_pointer_progress_date_pointer = ''
        let normal_analog_clock_time_pointer_hour = ''
        let normal_analog_clock_time_pointer_minute = ''
        let Button_1 = ''
        let Button_2 = ''
        let Button_3 = ''
        let Button_4 = ''
        let timeSensor = '';


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            // FontName: Oswald-Medium.ttf; FontSize: 21; Cache: full
            hmUI.createWidget(hmUI.widget.TEXT, {
              x: 464,
              y: 464,
              w: 25,
              h: 25,
              text_size: 21,
              char_space: 0,
              line_space: 0,
              font: 'fonts/Oswald-Medium.ttf',
              color: 0xFF000000,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.NONE,
              text: "0123456789 ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz АБВГДЕЁЖЗИЙКЛМНОПРСТУФХЦЧШЩЪЫЬЭЮЯабвгдеёжзийклмнопрстуфхцчшщъыьэюя  ҐЄІЇґєії _-.,:;`'%°\\/",
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // FontName: SentinelPro-Medium.ttf; FontSize: 20
            hmUI.createWidget(hmUI.widget.TEXT, {
              x: 464,
              y: 464,
              w: 261,
              h: 28,
              text_size: 20,
              char_space: 0,
              line_space: 0,
              font: 'fonts/SentinelPro-Medium.ttf',
              color: 0xFF000000,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              text: "0123456789 _-.,:;`'%°\\/",
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // FontName: Oswald-Medium.ttf; FontSize: 15; Cache: full
            hmUI.createWidget(hmUI.widget.TEXT, {
              x: 464,
              y: 464,
              w: 18,
              h: 18,
              text_size: 15,
              char_space: 0,
              line_space: 0,
              font: 'fonts/Oswald-Medium.ttf',
              color: 0xFF000000,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.NONE,
              text: "0123456789 ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz АБВГДЕЁЖЗИЙКЛМНОПРСТУФХЦЧШЩЪЫЬЭЮЯабвгдеёжзийклмнопрстуфхцчшщъыьэюя  ҐЄІЇґєії _-.,:;`'%°\\/",
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            console.log('user_script_start.js');
            // start user_script_start.js

        hmUI.createWidget(hmUI.widget.TEXT, {
            x: 464,
            y: 464,
            w: 22,
            h: 40,
            text_size: 17,
            char_space: 0,
            line_space: 0,
            font: 'fonts/Oswald-Medium.ttf',
            color: 0xFFFFFFFF,
            align_h: hmUI.align.CENTER_H,
            align_v: hmUI.align.CENTER_V,
            text_style: hmUI.text_style.NONE,
            text: "0123456789 ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz АБВГДЕЁЖЗИЙКЛМНОПРСТУФХЦЧШЩЪЫЬЭЮЯабвгдеёжзийклмнопрстуфхцчшщъыьэюя  ҐЄІЇґєії _-.,:;`'%°\\/",
            show_level: hmUI.show_level.ONLY_NORMAL,
        });
        
            hmUI.createWidget(hmUI.widget.TEXT, {
              x: 464,
              y: 464,
              w: 261,
              h: 28,
              text_size: 36,
              char_space: 0,
              line_space: 0,
              font: 'fonts/SentinelPro-Medium.ttf',
              color: 0xFF000000,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              text: "0123456789 _-.,:;`'%°\\/",
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
        

        normal_SUN_CURRENT_PROGRESS = hmUI.createWidget(hmUI.widget.IMG, {
            x: 0,
            y: 0,
            w: 466,
            h: 466,
            pos_x: 174,
            pos_y: 298,
            center_x: 233,
            center_y: 356,
            src: 'str_sun.png',
            angle: 90,
            show_level: hmUI.show_level.ONLY_NORMAL,
        });
        
           hmUI.createWidget(hmUI.widget.FILL_RECT, {
              x: 0,
              y: 0,
              w: 466,
              h: 233,
              color: '0xFFE9E9E9',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });        
            // end user_script_start.js

            console.log('Watch_Face.ScreenNormal');

            normal_stand_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 338,
              y: 344,
              src: 'stat_bg_on.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_fat_burning_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 107,
              y: 344,
              src: 'stat_bg_on.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 107,
              y: 344,
              src: 'stat_B_off.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 338,
              y: 344,
              src: 'stat_H_on.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            if (!timeSensor) timeSensor = hmSensor.createSensor(hmSensor.id.TIME);
            timeSensor.addEventListener(timeSensor.event.DAYCHANGE, function() {
              time_update(true);
            });

            normal_month_name_font = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 186,
              y: 105,
              w: 150,
              h: 40,
              text_size: 21,
              char_space: 0,
              line_space: 0,
              font: 'fonts/Oswald-Medium.ttf',
              color: 0xFF000000,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              // unit_string: ЯНВ, ФЕВ, МАР, АПР, МАЙ, ИЮН, ИЮЛ, АВГ, СЕН, ОКТ, НОЯ, ДЕК,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_dow_text_font = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 131,
              y: 105,
              w: 150,
              h: 40,
              text_size: 21,
              char_space: 0,
              line_space: 0,
              font: 'fonts/Oswald-Medium.ttf',
              color: 0xFF000000,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              // unit_string: ПНД, ВТР, СРД, ЧТВ, ПТН, СБТ, ВСК,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_image_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'bg.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_calorie_current_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 137,
              y: 338,
              w: 128,
              h: 30,
              text_size: 20,
              char_space: 0,
              line_space: 0,
              font: 'fonts/SentinelPro-Medium.ttf',
              color: 0xFF000000,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_cal_circle_scale = hmUI.createWidget(hmUI.widget.Circle_Scale, {
              // center_x: 233,
              // center_y: 355,
              // start_angle: 108,
              // end_angle: 255,
              // radius: 55,
              // line_width: 6,
              // line_cap: Flat,
              // color: 0xFFD68F57,
              // mirror: False,
              // inversion: False,
              // alpha: 255,
              // type: hmUI.data_type.CAL,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            let screenType = hmSetting.getScreenType();
            normal_calorie_circle_scale = hmUI.createWidget(hmUI.widget.ARC_PROGRESS, {
              center_x: 233,
              center_y: 355,
              start_angle: 108,
              end_angle: 255,
              radius: 52,
              line_width: 6,
              corner_flag: 3,
              color: 0xFFD68F57,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            
            const calorie = hmSensor.createSensor(hmSensor.id.CALORIE);
            calorie.addEventListener(hmSensor.event.CHANGE, function() {
              scale_call();
            });

            normal_calorie_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 176,
              y: 353,
              src: 'cap_midl.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_calorie_pointer_progress_img_pointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
              src: 'str_cal.png',
              center_x: 233,
              center_y: 355,
              x: 19,
              y: 46,
              start_angle: 108,
              end_angle: 252,
              invalid_visible: false,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_circle_scale_2 = hmUI.createWidget(hmUI.widget.ARC_PROGRESS, {
              center_x: 349,
              center_y: 258,
              start_angle: 198,
              end_angle: 342,
              radius: 59,
              line_width: 8,
              corner_flag: 3,
              type: hmUI.data_type.HEART,
              color: 0xFFD68F57,
              // mirror: False,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 285,
              y: 196,
              src: 'cap_right_left.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_pointer_progress_img_pointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
              src: 'str_bat_s.png',
              center_x: 349,
              center_y: 258,
              x: 20,
              y: 32,
              start_angle: 198,
              end_angle: 342,
              invalid_visible: false,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 286,
              y: 296,
              w: 128,
              h: 30,
              text_size: 20,
              char_space: 0,
              line_space: 0,
              font: 'fonts/SentinelPro-Medium.ttf',
              color: 0xFF000000,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_battery_circle_scale = hmUI.createWidget(hmUI.widget.Circle_Scale, {
              // center_x: 349,
              // center_y: 258,
              // start_angle: 162,
              // end_angle: 18,
              // radius: 63,
              // line_width: 8,
              // line_cap: Flat,
              // color: 0xFFD68F57,
              // mirror: False,
              // inversion: False,
              // alpha: 255,
              // type: hmUI.data_type.BATTERY,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_battery_circle_scale = hmUI.createWidget(hmUI.widget.ARC_PROGRESS, {
              center_x: 349,
              center_y: 258,
              start_angle: 162,
              end_angle: 18,
              radius: 59,
              line_width: 8,
              corner_flag: 3,
              color: 0xFFD68F57,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            
            const battery = hmSensor.createSensor(hmSensor.id.BATTERY);
            battery.addEventListener(hmSensor.event.CHANGE, function() {
              scale_call();
            });

            normal_battery_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 363,
              y: 196,
              src: 'cap_right_right.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_pointer_progress_img_pointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
              src: 'str_bat.png',
              center_x: 349,
              center_y: 258,
              x: 21,
              y: 62,
              start_angle: 162,
              end_angle: 18,
              invalid_visible: false,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_current_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 286,
              y: 186,
              w: 128,
              h: 30,
              text_size: 20,
              char_space: 0,
              line_space: 0,
              font: 'fonts/SentinelPro-Medium.ttf',
              color: 0xFF000000,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_step_circle_scale = hmUI.createWidget(hmUI.widget.Circle_Scale, {
              // center_x: 118,
              // center_y: 258,
              // start_angle: -145,
              // end_angle: 145,
              // radius: 63,
              // line_width: 8,
              // line_cap: Flat,
              // color: 0xFFD68F57,
              // mirror: False,
              // inversion: False,
              // alpha: 255,
              // type: hmUI.data_type.STEP,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_step_circle_scale = hmUI.createWidget(hmUI.widget.ARC_PROGRESS, {
              center_x: 118,
              center_y: 258,
              start_angle: -145,
              end_angle: 145,
              radius: 59,
              line_width: 8,
              corner_flag: 3,
              color: 0xFFD68F57,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            
            const step = hmSensor.createSensor(hmSensor.id.STEP);
            step.addEventListener(hmSensor.event.CHANGE, function() {
              scale_call();
            });

            normal_step_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 54,
              y: 194,
              src: 'cap_left.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 54,
              y: 289,
              w: 128,
              h: 30,
              text_size: 20,
              char_space: 0,
              line_space: 0,
              font: 'fonts/SentinelPro-Medium.ttf',
              color: 0xFF000000,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_pointer_progress_img_pointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
              src: 'str_bat.png',
              center_x: 118,
              center_y: 258,
              x: 21,
              y: 62,
              start_angle: -145,
              end_angle: 145,
              invalid_visible: false,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_distance_current_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 54,
              y: 272,
              w: 128,
              h: 30,
              text_size: 20,
              char_space: 0,
              line_space: 0,
              font: 'fonts/SentinelPro-Medium.ttf',
              color: 0xFF000000,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              type: hmUI.data_type.DISTANCE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
              const weatherSensor = hmSensor.createSensor(hmSensor.id.WEATHER);

            normal_city_name_text = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 97,
              y: 168,
              w: 272,
              h: 30,
              text_size: 15,
              char_space: 0,
              line_space: 0,
              font: 'fonts/Oswald-Medium.ttf',
              color: 0xFF000000,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              // unit_type: 1,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            console.log('user_script.js');
            // start user_script.js
normal_weather_text_font = hmUI.createWidget(hmUI.widget.TEXT, {
    x: 122,
    y: 145,
    w: 223,
    h: 40,
    text_size: 17,
    char_space: 0,
    line_space: 0,
    font: 'fonts/Oswald-Medium.ttf',
    color: 0x000000,
    align_h: hmUI.align.CENTER_H,
    align_v: hmUI.align.CENTER_V,
    text_style: hmUI.text_style.NONE,
    show_level: hmUI.show_level.ONLY_NORMAL,
})

            normal_hour_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
             x: 46,
             y: 46,
             w: (466 - 46 * 2),
             h: (466 - 46 * 2),
             start_angle: -30,
             end_angle: -2,
             //mode: 1,
             text_size: 36,
             char_space: -2,
             line_space: 0,
           // text: '00',
              font: 'fonts/SentinelPro-Medium.ttf',
              color: 0x000000,
             align_h: hmUI.align.CENTER_H,
             align_v: hmUI.align.CENTER_V,
             unit_type: 1,
             text_style: hmUI.text_style.ELLIPSIS,
              padding: true,
             type: hmUI.data_type.HOUR,
             show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_min_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
             x: 46,
             y: 46,
             w: (466 - 46 * 2),
             h: (466 - 46 * 2),
             start_angle: 2,
             end_angle: 30,
             //mode: 1,
             text_size: 36,
             char_space: -2,
             line_space: 0,
            //text: '00',
              font: 'fonts/SentinelPro-Medium.ttf',
              color: 0x000000,
             align_h: hmUI.align.CENTER_H,
             align_v: hmUI.align.CENTER_V,
             unit_type: 1,
             text_style: hmUI.text_style.ELLIPSIS,
                           padding: true,
 type: hmUI.data_type.MINUTE,
             show_level: hmUI.show_level.ONLY_NORMAL,
            });
            
            normal_temp_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
             x: 46,
             y: 46,
             w: (466 - 46 * 2),
             h: (466 - 46 * 2),
             start_angle: 30,
             end_angle: 60,
             //mode: 1,
             text_size: 36,
             char_space: -2,
             line_space: 0,
           // text: '00',
              font: 'fonts/SentinelPro-Medium.ttf',
              color: 0x000000,
             align_h: hmUI.align.CENTER_H,
             align_v: hmUI.align.CENTER_V,
             unit_type: 1,
             text_style: hmUI.text_style.ELLIPSIS,
                           padding: true,
              unit_type: 1,
              type: hmUI.data_type.WEATHER_CURRENT,
             show_level: hmUI.show_level.ONLY_NORMAL,
            });            
            
            normal_press_text_font = hmUI.createWidget(hmUI.widget.TEXT, {
             x: 46,
             y: 46,
             w: (466 - 46 * 2),
             h: (466 - 46 * 2),
             start_angle: -60,
             end_angle: -30,
             //mode: 1,
             text_size: 36,
             char_space: -2,
             line_space: 0,
  text:  Math.round(pressureValue * 0.750064).toString(),
  font: 'fonts/SentinelPro-Medium.ttf',
              color: 0x000000,
             align_h: hmUI.align.CENTER_H,
             align_v: hmUI.align.CENTER_V,
             unit_type: 1,
             text_style: hmUI.text_style.ELLIPSIS,
                           padding: true,
// type: hmUI.data_type.MINUTE,
             show_level: hmUI.show_level.ONLY_NORMAL,
            }); 
            // end user_script.js

            // normal_second_circle_scale = hmUI.createWidget(hmUI.widget.Circle_Scale, {
              // center_x: 233,
              // center_y: 233,
              // start_angle: 0,
              // end_angle: 360,
              // radius: 223,
              // line_width: 18,
              // line_cap: Flat,
              // color: 0xFFD68F57,
              // mirror: False,
              // inversion: False,
              // alpha: 255,
              // type: hmUI.data_type.SECOND,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });


            normal_second_circle_scale = hmUI.createWidget(hmUI.widget.ARC_PROGRESS, {
              center_x: 233,
              center_y: 233,
              start_angle: 0,
              end_angle: 360,
              radius: 214,
              line_width: 18,
              corner_flag: 3,
              color: 0xFFD68F57,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_time_circle_options = hmUI.createWidget(hmUI.widget.TIME_CIRCLE_OPTIONS, {
              // smooth: false,
              // format24h: false,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });


            normal_stress_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'cap.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_day_pointer_progress_date_pointer = hmUI.createWidget(hmUI.widget.DATE_POINTER, {
              src: 'str_data.png',
              center_x: 233,
              center_y: 357,
              posX: 20,
              posY: 72,
              start_angle: 0,
              end_angle: 360,
              type: hmUI.date.DAY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_hour = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              hour_path: 'str_H.png',
              hour_centerX: 233,
              hour_centerY: 233,
              hour_posX: 26,
              hour_posY: 131,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_minute = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              minute_path: 'str_M.png',
              minute_centerX: 233,
              minute_centerY: 233,
              minute_posX: 23,
              minute_posY: 197,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });



            console.log('user_script_beforeShortcuts.js');
            // start user_script_beforeShortcuts.js

            normal_second_pointer = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 467,
              h: 467,
              pos_x: 210,
              pos_y: -1,
              center_x: 233,
              center_y: 233,
              angle: 0,
              src: 'str_S.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
				
            normal_readiness_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'glass.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
				
            // end user_script_beforeShortcuts.js

            console.log('Watch_Face.Buttons');
            Button_1 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 68,
              y: 207,
              w: 100,
              h: 100,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '0.png',
              normal_src: '0.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'AlarmInfoScreen', native: true });
vibro(28);
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_2 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 300,
              y: 207,
              w: 100,
              h: 100,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '0.png',
              normal_src: '0.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'CountdownAppScreen', native: true });
vibro(28);
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_3 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 183,
              y: 75,
              w: 100,
              h: 100,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '0.png',
              normal_src: '0.png',
              click_func: (button_widget) => {
                 hmApp.startApp({ appid: 1057409, url: 'page/index', params: { from_wf: true} });
vibro(28);
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_4 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 294,
              y: 75,
              w: 100,
              h: 100,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '0.png',
              normal_src: '0.png',
              click_func: (button_widget) => {
                hmApp.startApp({ appid: 1051195, url: 'page/index', params: { from_wf: true} });
vibro(28);
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            //#region time_update
            function time_update(updateHour = false, updateMinute = false) {
              console.log('time_update()');
              let hour = timeSensor.hour;
              let minute = timeSensor.minute;
              let second = timeSensor.second;
              let format_hour = timeSensor.format_hour;
              
 let pressureValue = baro.pressure;
let ptess_val = Math.round(pressureValue * 0.750064).toString();              
				
 normal_press_text_font.setProperty(hmUI.prop.TEXT, ptess_val);
				

              console.log('month font');
              if (updateHour) {
                let normal_Month_Str = normal_Month_Array[timeSensor.month-1];
                normal_month_name_font.setProperty(hmUI.prop.TEXT, normal_Month_Str );
              };

              console.log('day of week font');
              if (updateHour) {
                let normal_DOW_Str = normal_DOW_Array[timeSensor.week-1];
                normal_dow_text_font.setProperty(hmUI.prop.TEXT, normal_DOW_Str );
              };

              // Second Circle
              let normal_secondCircleProgress = 360 * second/60;
              
            normal_second_circle_scale.setProperty(hmUI.prop.MORE, {
              center_x: 233,
              center_y: 233,
              start_angle: 0,
              end_angle: normal_secondCircleProgress,
              radius: 214,
              line_width: 18,
              corner_flag: 3,
              color: 0xFFD68F57,
              level: 100,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });              
              
             // if (normal_second_circle_scale) normal_second_circle_scale.setProperty(hmUI.prop.LEVEL, normal_secondCircleProgress );
              normal_second_pointer.setProperty(hmUI.prop.ANGLE, normal_secondCircleProgress );
              

            };

            //#endregion
            function scale_call() {
              console.log('scale_call()');

                console.log('update scales CALORIE');
                
                let valueCalories = calorie.current;
                let targetCalories = calorie.target;
                let progressCalories = valueCalories/targetCalories;
                if (progressCalories > 1) progressCalories = 1;
                let progress_cs_normal_calorie = progressCalories;

                if (screenType != hmSetting.screen_type.AOD) {

                  // normal_calorie_circle_scale_circle_scale
                  let level = Math.round(progress_cs_normal_calorie * 100);
                  if (normal_calorie_circle_scale) {
                    normal_calorie_circle_scale.setProperty(hmUI.prop.MORE, {                      
                      center_x: 233,
                      center_y: 355,
                      start_angle: 108,
                      end_angle: 255,
                      radius: 52,
                      line_width: 6,
                      corner_flag: 3,
                      color: 0xFFD68F57,
                      show_level: hmUI.show_level.ONLY_NORMAL,
                      level: level,
                    });
                  };
                };

                console.log('update scales BATTERY');
                
                let valueBattery = battery.current;
                let targetBattery = 100;
                let progressBattery = valueBattery/targetBattery;
                if (progressBattery > 1) progressBattery = 1;
                let progress_cs_normal_battery = progressBattery;

                if (screenType != hmSetting.screen_type.AOD) {

                  // normal_battery_circle_scale_circle_scale
                  let level = Math.round(progress_cs_normal_battery * 100);
                  if (normal_battery_circle_scale) {
                    normal_battery_circle_scale.setProperty(hmUI.prop.MORE, {                      
                      center_x: 349,
                      center_y: 258,
                      start_angle: 162,
                      end_angle: 18,
                      radius: 59,
                      line_width: 8,
                      corner_flag: 3,
                      color: 0xFFD68F57,
                      show_level: hmUI.show_level.ONLY_NORMAL,
                      level: level,
                    });
                  };
                };

                console.log('update scales STEP');
                
                let valueStep = step.current;
                let targetStep = step.target;
                let progressStep = valueStep/targetStep;
                if (progressStep > 1) progressStep = 1;
                let progress_cs_normal_step = progressStep;

                if (screenType != hmSetting.screen_type.AOD) {

                  // normal_step_circle_scale_circle_scale
                  let level = Math.round(progress_cs_normal_step * 100);
                  if (normal_step_circle_scale) {
                    normal_step_circle_scale.setProperty(hmUI.prop.MORE, {                      
                      center_x: 118,
                      center_y: 258,
                      start_angle: -145,
                      end_angle: 145,
                      radius: 59,
                      line_width: 8,
                      corner_flag: 3,
                      color: 0xFFD68F57,
                      show_level: hmUI.show_level.ONLY_NORMAL,
                      level: level,
                    });
                  };
                };

              console.log('Weather city name');
              let weatherData = weatherSensor.getForecastWeather();
              let normal_cityNameStr = weatherData.cityName;
              normal_cityNameStr = normal_cityNameStr.toUpperCase();
              normal_city_name_text.setProperty(hmUI.prop.TEXT, normal_cityNameStr);

            };

            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                console.log('resume_call()');
                scale_call();
                time_update(true, true);
                if (screenType == hmSetting.screen_type.WATCHFACE) {
                  if (!normal_timerUpdateSec) {
                    let animDelay = timeSensor.utc % 1000;
                    let animRepeat = 1000;
                    normal_timerUpdateSec = timer.createTimer(animDelay, animRepeat, (function (option) {
                      time_update(false, false);
                    }));  // end timer 
                  };  // end timer check
                };  // end screenType


                console.log('resume_call.js');
                // start resume_call.js

          autoToggleWeatherIcons();


                // end resume_call.js

              }),
              pause_call: (function () {
                console.log('pause_call()');
                if (normal_timerUpdateSec) {
                  timer.stopTimer(normal_timerUpdateSec);
                  normal_timerUpdateSec = undefined;
                }

              }),
            });

                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}