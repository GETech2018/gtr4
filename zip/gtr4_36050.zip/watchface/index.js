﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        const logger = Logger.getLogger('watchface_SashaCX75');
        //end of ignored block

        //dynamic modify start

        
        let normal_day_TextCircle = new Array(2);
        let normal_day_TextCircle_ASCIIARRAY = new Array(10);
        let normal_day_TextCircle_img_width = 15;
        let normal_day_TextCircle_img_height = 26;
        let normal_timerTextUpdate = undefined;
        let normal_week_pointer_progress_date_pointer = ''
        let normal_pai_icon_img = ''
        let normal_battery_pointer_progress_img_pointer = ''
        let normal_step_pointer_progress_img_pointer = ''
        let normal_month_pointer_progress_date_pointer = ''
        let normal_analog_clock_time_pointer_second = ''
        let normal_analog_clock_time_pointer_hour = ''
        let normal_analog_clock_time_pointer_minute = ''
        let normal_system_disconnect_img = ''
        let idle_background_bg_img = ''
        let idle_analog_clock_time_pointer_hour = ''
        let idle_analog_clock_time_pointer_minute = ''
        let idle_system_disconnect_img = ''


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                

            // normal_day_text_circle_img = hmUI.createWidget(hmUI.widget.Text_Circle, {
              // circle_center_X: 233,
              // circle_center_Y: 233,
              // font_array: ["font_0.png","font_1.png","font_2.png","font_3.png","font_4.png","font_5.png","font_6.png","font_7.png","font_8.png","font_9.png"],
              // radius: 170,
              // angle: 135,
              // char_space_angle: 0,
              // zero: true,
              // reverse_direction: true,
              // unit_in_alignment: true,
              // vertical_alignment: BOTTOM,
              // horizontal_alignment: CENTER_H,
              // type: hmUI.data_type.DAY,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_day_TextCircle_ASCIIARRAY[0] = 'font_0.png';  // set of images with numbers
            normal_day_TextCircle_ASCIIARRAY[1] = 'font_1.png';  // set of images with numbers
            normal_day_TextCircle_ASCIIARRAY[2] = 'font_2.png';  // set of images with numbers
            normal_day_TextCircle_ASCIIARRAY[3] = 'font_3.png';  // set of images with numbers
            normal_day_TextCircle_ASCIIARRAY[4] = 'font_4.png';  // set of images with numbers
            normal_day_TextCircle_ASCIIARRAY[5] = 'font_5.png';  // set of images with numbers
            normal_day_TextCircle_ASCIIARRAY[6] = 'font_6.png';  // set of images with numbers
            normal_day_TextCircle_ASCIIARRAY[7] = 'font_7.png';  // set of images with numbers
            normal_day_TextCircle_ASCIIARRAY[8] = 'font_8.png';  // set of images with numbers
            normal_day_TextCircle_ASCIIARRAY[9] = 'font_9.png';  // set of images with numbers

            //start of ignored block
            for (let i = 0; i < 2; i++) {
              normal_day_TextCircle[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 466,
                h: 466,
                center_x: 233,
                center_y: 233,
                pos_x: 233 - normal_day_TextCircle_img_width / 2,
                pos_y: 233 + 144,
                src: 'font_0.png',
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
              normal_day_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
            };
            //end of ignored block
            
            const timeNaw = hmSensor.createSensor(hmSensor.id.TIME);

            let screenType = hmSetting.getScreenType();            
            function toDegree (radian) {
              return radian * (180 / Math.PI);
            };

            normal_week_pointer_progress_date_pointer = hmUI.createWidget(hmUI.widget.DATE_POINTER, {
              src: 'days.png',
              center_x: 176,
              center_y: 289,
              posX: 100,
              posY: 100,
              start_angle: 0,
              end_angle: 360,
              type: hmUI.date.WEEK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_pai_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'bg.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_pointer_progress_img_pointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
              src: 'point1.png',
              center_x: 135,
              center_y: 233,
              x: 34,
              y: 52,
              start_angle: 0,
              end_angle: 360,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_pointer_progress_img_pointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
              src: 'point1.png',
              center_x: 330,
              center_y: 233,
              x: 34,
              y: 52,
              start_angle: 0,
              end_angle: 360,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_month_pointer_progress_date_pointer = hmUI.createWidget(hmUI.widget.DATE_POINTER, {
              src: 'sec.png',
              center_x: 233,
              center_y: 333,
              posX: 34,
              posY: 52,
              start_angle: 0,
              end_angle: 360,
              type: hmUI.date.MONTH,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_second = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              second_path: 'sec.png',
              second_centerX: 233,
              second_centerY: 130,
              second_posX: 34,
              second_posY: 52,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_hour = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              hour_path: 'hours.png',
              hour_centerX: 233,
              hour_centerY: 233,
              hour_posX: 36,
              hour_posY: 232,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_minute = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              minute_path: 'minutes.png',
              minute_centerX: 233,
              minute_centerY: 233,
              minute_posX: 36,
              minute_posY: 232,
              minute_cover_path: 'indidot.png',
              minute_cover_x: 0,
              minute_cover_y: 0,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 218,
              y: 218,
              src: 'BT3.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            idle_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 466,
              h: 466,
              src: 'aod.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_analog_clock_time_pointer_hour = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              hour_path: 'hours.png',
              hour_centerX: 233,
              hour_centerY: 233,
              hour_posX: 36,
              hour_posY: 232,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_analog_clock_time_pointer_minute = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              minute_path: 'minutes.png',
              minute_centerX: 233,
              minute_centerY: 233,
              minute_posX: 36,
              minute_posY: 232,
              minute_cover_path: 'indidot.png',
              minute_cover_x: 0,
              minute_cover_y: 0,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 218,
              y: 218,
              src: 'BT3.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            function text_update() {

              console.log('update text circle day_TIME');
              let valueDay = timeNaw.day;
              let normal_day_circle_string = parseInt(valueDay).toString();
              normal_day_circle_string = normal_day_circle_string.padStart(2, '0');

              if (screenType != hmSetting.screen_type.AOD) {
                for (var i = 1; i < 2; i++) {  // hide all symbols
                  normal_day_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                let char_Angle = 315;
                if (valueDay != null && valueDay != undefined && isFinite(valueDay) && normal_day_circle_string.length > 0 && normal_day_circle_string.length < 6) {  // display data if it was possible to get it
                  let normal_day_TextCircle_img_angle = 0;
                  let normal_day_TextCircle_dot_img_angle = 0;
                  normal_day_TextCircle_img_angle = toDegree(Math.atan2(normal_day_TextCircle_img_width/2, 170));
                  // alignment = CENTER_H
                  let normal_day_TextCircle_angleOffset = normal_day_TextCircle_img_angle * (normal_day_circle_string.length - 1);
                  normal_day_TextCircle_angleOffset = -normal_day_TextCircle_angleOffset;
                  char_Angle -= normal_day_TextCircle_angleOffset;
                  // alignment end
                  
                  let firstSymbol = true;
                  let index = 0;
                  for (let char of normal_day_circle_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 2) break;
                    if (charCode >= 0 && charCode < 10) { 
                      if (!firstSymbol) char_Angle -= normal_day_TextCircle_img_angle;
                      firstSymbol = false;
                      normal_day_TextCircle[index].setProperty(hmUI.prop.ANGLE, char_Angle);
                      normal_day_TextCircle[index].setProperty(hmUI.prop.POS_X, 233 - normal_day_TextCircle_img_width / 2);
                      normal_day_TextCircle[index].setProperty(hmUI.prop.SRC, normal_day_TextCircle_ASCIIARRAY[charCode]);
                      normal_day_TextCircle[index].setProperty(hmUI.prop.VISIBLE, true);
                      char_Angle -= normal_day_TextCircle_img_angle;
                      index++;
                    };  // end if digit
                  };  // end char of string
                }  // end isFinite

              };

            };

            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                text_update();
                if (screenType == hmSetting.screen_type.WATCHFACE) {
                  if (!normal_timerTextUpdate) {
                    normal_timerTextUpdate = timer.createTimer(0, 1000, (function (option) {
                      text_update();
                    }));  // end timer 
                  };  // end timer check
                };  // end screenType


              }),
              pause_call: (function () {
                if (normal_timerTextUpdate) {
                  timer.stopTimer(normal_timerTextUpdate);
                  normal_timerTextUpdate = undefined;
                }

              }),
            });

                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}