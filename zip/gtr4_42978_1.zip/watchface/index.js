﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        //const logger = Logger.getLogger('watchface_SashaCX75');
        const logger = DeviceRuntimeCore.HmLogger.getLogger('watchface_SashaCX75')
        //end of ignored block

        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_image_img = ''
        let normal_system_disconnect_img = ''
        let normal_system_clock_img = ''
        let normal_altimeter_text_text_img = ''
        let normal_altimeter_text_separator_img = ''
        let normal_sun_high_text_img = ''
        let normal_sun_low_text_img = ''
        let normal_moon_image_progress_img_level = ''
        let normal_date_img_date_month_img = ''
        let normal_date_img_date_day = ''
        let normal_date_img_date_week_img = ''
        let normal_weather_image_progress_img_level = ''
        let normal_temperature_high_text_img = ''
        let normal_temperature_low_text_img = ''
        let normal_temperature_current_text_img = ''
        let normal_battery_linear_scale = ''
        let normal_battery_text_text_img = ''
        let normal_heart_rate_text_text_img = ''
        let normal_step_circle_scale = ''
        let normal_step_target_text_img = ''
        let normal_step_current_text_img = ''
        let normal_digital_clock_img_time_AmPm = ''
        let normal_digital_clock_img_time = ''
        let idle_background_bg = ''
        let idle_image_img = ''
        let idle_battery_linear_scale = ''
        let idle_digital_clock_img_time_AmPm = ''
        let idle_digital_clock_img_time = ''
        let Button_1 = ''
        let Button_2 = ''
        let Button_3 = ''
        let Button_4 = ''
        let Button_5 = ''
        let Button_6 = ''

let colornumber_main = 1
        let totalcolors_main = 30
        let namecolor_main = ''

        function click_Color() {
            if(colornumber_main>=totalcolors_main) {
            colornumber_main=1;
                }
            else {
                colornumber_main=colornumber_main+1;
            }
	
            normal_background_bg_img.setProperty(hmUI.prop.SRC, "bg" + parseInt(colornumber_main) + ".png");			
        }
        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            console.log('Watch_Face.ScreenNormal');
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 466,
              h: 466,
              src: 'bg4.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_image_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'maskapl.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 19,
              y: 216,
              src: 'icon_nobt.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 19,
              y: 250,
              src: 'icon_alarmon.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_altimeter_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 170,
              y: 17,
              font_array: ["temp_00.png","temp_01.png","temp_02.png","temp_03.png","temp_04.png","temp_05.png","temp_06.png","temp_07.png","temp_08.png","temp_09.png"],
              padding: false,
              h_space: -5,
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.ALTIMETER,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_altimeter_text_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 237,
              y: 17,
              src: 'tmp_hpa.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sun_high_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 129,
              y: 48,
              font_array: ["temp_00.png","temp_01.png","temp_02.png","temp_03.png","temp_04.png","temp_05.png","temp_06.png","temp_07.png","temp_08.png","temp_09.png"],
              padding: false,
              h_space: -5,
              dot_image: 'temp_dots.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.SUN_RISE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sun_low_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 260,
              y: 48,
              font_array: ["temp_00.png","temp_01.png","temp_02.png","temp_03.png","temp_04.png","temp_05.png","temp_06.png","temp_07.png","temp_08.png","temp_09.png"],
              padding: false,
              h_space: -5,
              dot_image: 'temp_dots.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.SUN_SET,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_moon_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 413,
              y: 304,
              image_array: ["Moon_01.png","Moon_02.png","Moon_03.png","Moon_04.png","Moon_05.png","Moon_06.png","Moon_07.png","Moon_08.png","Moon_09.png","Moon_10.png","Moon_11.png","Moon_12.png","Moon_13.png","Moon_14.png","Moon_15.png","Moon_16.png","Moon_17.png","Moon_18.png","Moon_19.png","Moon_20.png","Moon_21.png","Moon_22.png","Moon_23.png","Moon_24.png","Moon_25.png","Moon_26.png","Moon_27.png","Moon_28.png","Moon_29.png","Moon_30.png"],
              image_length: 30,
              type: hmUI.data_type.MOON,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_month_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 280,
              month_startY: 98,
              month_sc_array: ["mies-00.png","mies-01.png","mies-02.png","mies-03.png","mies-04.png","mies-05.png","mies-06.png","mies-07.png","mies-08.png","mies-09.png","mies-10.png","mies-11.png"],
              month_tc_array: ["mies-00.png","mies-01.png","mies-02.png","mies-03.png","mies-04.png","mies-05.png","mies-06.png","mies-07.png","mies-08.png","mies-09.png","mies-10.png","mies-11.png"],
              month_en_array: ["mies-00.png","mies-01.png","mies-02.png","mies-03.png","mies-04.png","mies-05.png","mies-06.png","mies-07.png","mies-08.png","mies-09.png","mies-10.png","mies-11.png"],
              month_is_character: true ,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 198,
              day_startY: 98,
              day_sc_array: ["digday_00.png","digday_11.png","digday_22.png","digday_33.png","digday_44.png","digday_55.png","digday_66.png","digday_77.png","digday_88.png","digday_99.png"],
              day_tc_array: ["digday_00.png","digday_11.png","digday_22.png","digday_33.png","digday_44.png","digday_55.png","digday_66.png","digday_77.png","digday_88.png","digday_99.png"],
              day_en_array: ["digday_00.png","digday_11.png","digday_22.png","digday_33.png","digday_44.png","digday_55.png","digday_66.png","digday_77.png","digday_88.png","digday_99.png"],
              day_zero: 1,
              day_space: -3,
              day_align: hmUI.align.LEFT,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 81,
              y: 100,
              week_en: ["dni-00.png","dni-01.png","dni-02.png","dni-03.png","dni-04.png","dni-05.png","dni-06.png"],
              week_tc: ["dni-00.png","dni-01.png","dni-02.png","dni-03.png","dni-04.png","dni-05.png","dni-06.png"],
              week_sc: ["dni-00.png","dni-01.png","dni-02.png","dni-03.png","dni-04.png","dni-05.png","dni-06.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 388,
              y: 132,
              image_array: ["0052.png","0053.png","0054.png","0055.png","0056.png","0057.png","0058.png","0059.png","0060.png","0061.png","0062.png","0063.png","0064.png","0065.png","0066.png","0067.png","0068.png","0069.png","0070.png","0071.png","0072.png","0073.png","0074.png","0075.png","0076.png","0077.png","0078.png","0079.png","0080.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_high_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 92,
              y: 158,
              font_array: ["temp_00.png","temp_01.png","temp_02.png","temp_03.png","temp_04.png","temp_05.png","temp_06.png","temp_07.png","temp_08.png","temp_09.png"],
              padding: false,
              h_space: -5,
              unit_sc: 'temp_deg.png',
              unit_tc: 'temp_deg.png',
              unit_en: 'temp_deg.png',
              imperial_unit_sc: 'temp_deg.png',
              imperial_unit_tc: 'temp_deg.png',
              imperial_unit_en: 'temp_deg.png',
              negative_image: 'temp_dash.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_HIGH,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            const temperatureUnit = hmSetting.getTemperatureUnit();
            //start of ignored block
            if (temperatureUnit == 1) {
              normal_temperature_high_text_img.setProperty(hmUI.prop.MORE, {
                x: 92,
                y: 158,
                font_array: ["temp_00.png","temp_01.png","temp_02.png","temp_03.png","temp_04.png","temp_05.png","temp_06.png","temp_07.png","temp_08.png","temp_09.png"],
                padding: false,
                h_space: -5,
                unit_sc: 'temp_deg.png',
                unit_tc: 'temp_deg.png',
                unit_en: 'temp_deg.png',
                imperial_unit_sc: 'temp_deg.png',
                imperial_unit_tc: 'temp_deg.png',
                imperial_unit_en: 'temp_deg.png',
                negative_image: 'temp_dash.png',
                align_h: hmUI.align.CENTER_H,
                type: hmUI.data_type.WEATHER_HIGH,
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
            };
            //end of ignored block

            normal_temperature_low_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 197,
              y: 158,
              font_array: ["temp_00.png","temp_01.png","temp_02.png","temp_03.png","temp_04.png","temp_05.png","temp_06.png","temp_07.png","temp_08.png","temp_09.png"],
              padding: false,
              h_space: -5,
              unit_sc: 'temp_deg.png',
              unit_tc: 'temp_deg.png',
              unit_en: 'temp_deg.png',
              imperial_unit_sc: 'temp_deg.png',
              imperial_unit_tc: 'temp_deg.png',
              imperial_unit_en: 'temp_deg.png',
              negative_image: 'temp_dash.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_LOW,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            //start of ignored block
            if (temperatureUnit == 1) {
              normal_temperature_low_text_img.setProperty(hmUI.prop.MORE, {
                x: 197,
                y: 158,
                font_array: ["temp_00.png","temp_01.png","temp_02.png","temp_03.png","temp_04.png","temp_05.png","temp_06.png","temp_07.png","temp_08.png","temp_09.png"],
                padding: false,
                h_space: -5,
                unit_sc: 'temp_deg.png',
                unit_tc: 'temp_deg.png',
                unit_en: 'temp_deg.png',
                imperial_unit_sc: 'temp_deg.png',
                imperial_unit_tc: 'temp_deg.png',
                imperial_unit_en: 'temp_deg.png',
                negative_image: 'temp_dash.png',
                align_h: hmUI.align.CENTER_H,
                type: hmUI.data_type.WEATHER_LOW,
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
            };
            //end of ignored block

            normal_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 305,
              y: 158,
              font_array: ["temp_00.png","temp_01.png","temp_02.png","temp_03.png","temp_04.png","temp_05.png","temp_06.png","temp_07.png","temp_08.png","temp_09.png"],
              padding: false,
              h_space: -5,
              unit_sc: 'temp_deg.png',
              unit_tc: 'temp_deg.png',
              unit_en: 'temp_deg.png',
              imperial_unit_sc: 'temp_deg.png',
              imperial_unit_tc: 'temp_deg.png',
              imperial_unit_en: 'temp_deg.png',
              negative_image: 'temp_dash.png',
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            //start of ignored block
            if (temperatureUnit == 1) {
              normal_temperature_current_text_img.setProperty(hmUI.prop.MORE, {
                x: 305,
                y: 158,
                font_array: ["temp_00.png","temp_01.png","temp_02.png","temp_03.png","temp_04.png","temp_05.png","temp_06.png","temp_07.png","temp_08.png","temp_09.png"],
                padding: false,
                h_space: -5,
                unit_sc: 'temp_deg.png',
                unit_tc: 'temp_deg.png',
                unit_en: 'temp_deg.png',
                imperial_unit_sc: 'temp_deg.png',
                imperial_unit_tc: 'temp_deg.png',
                imperial_unit_en: 'temp_deg.png',
                negative_image: 'temp_dash.png',
                align_h: hmUI.align.RIGHT,
                type: hmUI.data_type.WEATHER_CURRENT,
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
            };
            //end of ignored block

            let screenType = hmSetting.getScreenType();
            if (screenType != hmSetting.screen_type.AOD) {
              normal_battery_linear_scale = hmUI.createWidget(hmUI.widget.FILL_RECT);
            };

            // normal_battery_linear_scale = hmUI.createWidget(hmUI.widget.Linear_Scale, {
              // start_x: 190,
              // start_y: 449,
              // color: 0xFF0A0A0A,
              // lenght: 83,
              // line_width: 12,
              // line_cap: Rounded,
              // vertical: False,
              // mirror: False,
              // inversion: True,
              // alpha: 255,
              // type: hmUI.data_type.BATTERY,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });
            
            const battery = hmSensor.createSensor(hmSensor.id.BATTERY);
            battery.addEventListener(hmSensor.event.CHANGE, function() {
              scale_call();
            });

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 205,
              y: 427,
              font_array: ["small_00.png","small_11.png","small_22.png","small_33.png","small_44.png","small_55.png","small_66.png","small_77.png","small_88.png","small_99.png"],
              padding: false,
              h_space: -3,
              unit_sc: 'small_proc.png',
              unit_tc: 'small_proc.png',
              unit_en: 'small_proc.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 203,
              y: 385,
              font_array: ["other_00.png","other_11.png","other_22.png","other_33.png","other_44.png","other_55.png","other_66.png","other_77.png","other_88.png","other_99.png"],
              padding: false,
              h_space: -4,
              unit_sc: 'other_BPM0.png',
              unit_tc: 'other_BPM0.png',
              unit_en: 'other_BPM0.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_step_circle_scale = hmUI.createWidget(hmUI.widget.Circle_Scale, {
              // center_x: 135,
              // center_y: 359,
              // start_angle: -180,
              // end_angle: 180,
              // radius: 59,
              // line_width: 11,
              // line_cap: Rounded,
              // color: 0xFF090909,
              // mirror: False,
              // inversion: True,
              // alpha: 255,
              // type: hmUI.data_type.STEP,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_step_circle_scale = hmUI.createWidget(hmUI.widget.ARC_PROGRESS, {
              center_x: 135,
              center_y: 359,
              start_angle: 180,
              end_angle: -180,
              radius: 54,
              line_width: 11,
              corner_flag: 0,
              color: 0xFF090909,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            
            const step = hmSensor.createSensor(hmSensor.id.STEP);
            step.addEventListener(hmSensor.event.CHANGE, function() {
              scale_call();
            });

            normal_step_target_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 85,
              y: 350,
              font_array: ["small_00.png","small_11.png","small_22.png","small_33.png","small_44.png","small_55.png","small_66.png","small_77.png","small_88.png","small_99.png"],
              padding: false,
              h_space: -5,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STEP_TARGET,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 202,
              y: 317,
              font_array: ["steps_00.png","steps_11.png","steps_22.png","steps_33.png","steps_44.png","steps_55.png","steps_66.png","steps_77.png","steps_88.png","steps_99.png"],
              padding: false,
              h_space: -2,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time_AmPm = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              am_x: 406,
              am_y: 206,
              am_sc_path: 'numbig_am.png',
              am_en_path: 'numbig_am.png',
              pm_x: 406,
              pm_y: 206,
              pm_sc_path: 'numbig_pm.png',
              pm_en_path: 'numbig_pm.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 47,
              hour_startY: 188,
              hour_array: ["numbig_00.png","numbig_01.png","numbig_02.png","numbig_03.png","numbig_04.png","numbig_05.png","numbig_06.png","numbig_07.png","numbig_08.png","numbig_09.png"],
              hour_zero: 1,
              hour_space: 0,
              hour_angle: 0,
              hour_unit_sc: 'numbig_dots.png',
              hour_unit_tc: 'numbig_dots.png',
              hour_unit_en: 'numbig_dots.png',
              hour_align: hmUI.align.CENTER_H,

              minute_startX: 241,
              minute_startY: 188,
              minute_array: ["numbig_00.png","numbig_01.png","numbig_02.png","numbig_03.png","numbig_04.png","numbig_05.png","numbig_06.png","numbig_07.png","numbig_08.png","numbig_09.png"],
              minute_zero: 1,
              minute_space: 0,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              second_startX: 401,
              second_startY: 239,
              second_array: ["numbigadd_00.png","numbigadd_01.png","numbigadd_02.png","numbigadd_03.png","numbigadd_04.png","numbigadd_05.png","numbigadd_06.png","numbigadd_07.png","numbigadd_08.png","numbigadd_09.png"],
              second_zero: 1,
              second_space: -10,
              second_angle: 0,
              second_follow: 0,
              second_align: hmUI.align.RIGHT,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            console.log('Watch_Face.ScreenAOD');
            idle_background_bg = hmUI.createWidget(hmUI.widget.FILL_RECT, {
              x: 0,
              y: 0,
              w: 466,
              h: 466,
              color: '0xFF6E6E6E',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_image_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'aodbg.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            if (screenType == hmSetting.screen_type.AOD) {
              idle_battery_linear_scale = hmUI.createWidget(hmUI.widget.FILL_RECT);
            };

            // idle_battery_linear_scale = hmUI.createWidget(hmUI.widget.Linear_Scale, {
              // start_x: 190,
              // start_y: 449,
              // color: 0xFF000000,
              // lenght: 81,
              // line_width: 11,
              // line_cap: Flat,
              // vertical: False,
              // mirror: False,
              // inversion: True,
              // alpha: 255,
              // type: hmUI.data_type.BATTERY,
              // show_level: hmUI.show_level.ONLY_AOD,
            // });

            idle_digital_clock_img_time_AmPm = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              am_x: 406,
              am_y: 206,
              am_sc_path: 'numbig_am.png',
              am_en_path: 'numbig_am.png',
              pm_x: 406,
              pm_y: 206,
              pm_sc_path: 'numbig_pm.png',
              pm_en_path: 'numbig_pm.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 47,
              hour_startY: 187,
              hour_array: ["numbig_00.png","numbig_01.png","numbig_02.png","numbig_03.png","numbig_04.png","numbig_05.png","numbig_06.png","numbig_07.png","numbig_08.png","numbig_09.png"],
              hour_zero: 1,
              hour_space: 0,
              hour_angle: 0,
              hour_unit_sc: 'numbig_dots.png',
              hour_unit_tc: 'numbig_dots.png',
              hour_unit_en: 'numbig_dots.png',
              hour_align: hmUI.align.CENTER_H,

              minute_startX: 241,
              minute_startY: 187,
              minute_array: ["numbig_00.png","numbig_01.png","numbig_02.png","numbig_03.png","numbig_04.png","numbig_05.png","numbig_06.png","numbig_07.png","numbig_08.png","numbig_09.png"],
              minute_zero: 1,
              minute_space: 0,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_AOD,
            });
            
            // disconnectAlert = hmUI.createWidget(hmUI.widget.DisconnectAlert, {
              // disconneсnt_vibrate_type: 25,
              // disconneсnt_toast_text: DISCONNECTED,
              // conneсnt_vibrate_type: 25,
              // conneсnt_toast_text: CONNECTED,
            // });

            // vibration when connecting or disconnecting

            function checkConnection() {
              console.log('checkConnection()');
              hmBle.removeListener;
              hmBle.addListener(function (status) {
                if(!status) {
                  hmUI.showToast({text: "DISCONNECTED"});
                  vibro(25);
                }
                if(status) {
                  hmUI.showToast({text: "CONNECTED"});
                  vibro(25);
                }
              });
            }

            // end vibration when connecting or disconnecting
            // vibrate function

            const vibrate = hmSensor.createSensor(hmSensor.id.VIBRATE);
            let timer_StopVibrate = null;


            function vibro(scene = 25) {
              let stopDelay = 50;
              stopVibro();
              vibrate.stop();
              vibrate.scene = scene;
              if(scene < 23 || scene > 25) stopDelay = 1300;
              vibrate.start();
              if (scene != 1) timer_StopVibrate = timer.createTimer(stopDelay, 3000, stopVibro, {});
            }

            function stopVibro(){
              vibrate.stop();
              if(timer_StopVibrate) timer.stopTimer(timer_StopVibrate);
            }

            // end vibrate function

            console.log('Watch_Face.Buttons');
            Button_1 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 208,
              y: 321,
              w: 146,
              h: 39,
              text: '',
              color: 0xFFFF8C00,
              text_size: 24,
              press_src: '_WFbyTRK88PL.png',
              normal_src: '_WFbyTRK88PL.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'activityAppScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_2 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 208,
              y: 381,
              w: 146,
              h: 39,
              text: '',
              color: 0xFFFF8C00,
              text_size: 24,
              press_src: '_WFbyTRK88PL.png',
              normal_src: '_WFbyTRK88PL.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'heart_app_Screen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_3 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 204,
              y: 100,
              w: 163,
              h: 39,
              text: '',
              color: 0xFFFF8C00,
              text_size: 24,
              press_src: '_WFbyTRK88PL.png',
              normal_src: '_WFbyTRK88PL.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'ScheduleCalScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_4 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 389,
              y: 130,
              w: 49,
              h: 49,
              text: '',
              color: 0xFFFF8C00,
              text_size: 24,
              press_src: '_WFbyTRK88PL.png',
              normal_src: '_WFbyTRK88PL.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'WeatherScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_5 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 29,
              y: 307,
              w: 39,
              h: 43,
              text: '',
              color: 0xFFFF8C00,
              text_size: 24,
              press_src: '_WFbyTRK88PL.png',
              normal_src: '_WFbyTRK88PL.png',
              click_func: (button_widget) => {
                click_Color();
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_6 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 138,
              y: 45,
              w: 194,
              h: 39,
              text: '',
              color: 0xFFFF8C00,
              text_size: 24,
              press_src: '_WFbyTRK88PL.png',
              normal_src: '_WFbyTRK88PL.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'TideScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            function scale_call() {
              console.log('scale_call()');

                console.log('update scales BATTERY');
                
                let valueBattery = battery.current;
                let targetBattery = 100;
                let progressBattery = valueBattery/targetBattery;
                if (progressBattery > 1) progressBattery = 1;
                let progress_ls_normal_battery = 1 - progressBattery;

                if (screenType != hmSetting.screen_type.AOD) {

                  // normal_battery_linear_scale
                  // initial parameters
                  let start_x_normal_battery = 273;
                  let start_y_normal_battery = 449;
                  let lenght_ls_normal_battery = -83;
                  let line_width_ls_normal_battery = 12;
                  let color_ls_normal_battery = 0xFF0A0A0A;
                  
                  // calculated parameters
                  let start_x_normal_battery_draw = start_x_normal_battery;
                  let start_y_normal_battery_draw = start_y_normal_battery;
                  lenght_ls_normal_battery = lenght_ls_normal_battery * progress_ls_normal_battery;
                  let lenght_ls_normal_battery_draw = lenght_ls_normal_battery;
                  let line_width_ls_normal_battery_draw = line_width_ls_normal_battery;
                  if (lenght_ls_normal_battery < 0){
                    lenght_ls_normal_battery_draw = -lenght_ls_normal_battery;
                    start_x_normal_battery_draw = start_x_normal_battery - lenght_ls_normal_battery_draw;
                  };
                  
                  normal_battery_linear_scale.setProperty(hmUI.prop.MORE, {
                    x: start_x_normal_battery_draw,
                    y: start_y_normal_battery_draw,
                    w: lenght_ls_normal_battery_draw,
                    h: line_width_ls_normal_battery_draw,
                    radius: 6,
                    color: color_ls_normal_battery,
                  });
                };

                console.log('update scales STEP');
                
                let valueStep = step.current;
                let targetStep = step.target;
                let progressStep = valueStep/targetStep;
                if (progressStep > 1) progressStep = 1;
                let progress_cs_normal_step = 1 - progressStep;

                if (screenType != hmSetting.screen_type.AOD) {

                  // normal_step_circle_scale_circle_scale
                  let level = Math.round(progress_cs_normal_step * 100);
                  if (normal_step_circle_scale) {
                    normal_step_circle_scale.setProperty(hmUI.prop.MORE, {                      
                      center_x: 135,
                      center_y: 359,
                      start_angle: 180,
                      end_angle: -180,
                      radius: 54,
                      line_width: 11,
                      corner_flag: 0,
                      color: 0xFF090909,
                      show_level: hmUI.show_level.ONLY_NORMAL,
                      level: level,
                    });
                  };
                };

                console.log('update scales BATTERY');
                let progress_ls_idle_battery = 1 - progressBattery;

                if (screenType == hmSetting.screen_type.AOD) {

                  // idle_battery_linear_scale
                  // initial parameters
                  let start_x_idle_battery = 271;
                  let start_y_idle_battery = 449;
                  let lenght_ls_idle_battery = -81;
                  let line_width_ls_idle_battery = 11;
                  let color_ls_idle_battery = 0xFF000000;
                  
                  // calculated parameters
                  let start_x_idle_battery_draw = start_x_idle_battery;
                  let start_y_idle_battery_draw = start_y_idle_battery;
                  lenght_ls_idle_battery = lenght_ls_idle_battery * progress_ls_idle_battery;
                  let lenght_ls_idle_battery_draw = lenght_ls_idle_battery;
                  let line_width_ls_idle_battery_draw = line_width_ls_idle_battery;
                  if (lenght_ls_idle_battery < 0){
                    lenght_ls_idle_battery_draw = -lenght_ls_idle_battery;
                    start_x_idle_battery_draw = start_x_idle_battery - lenght_ls_idle_battery_draw;
                  };
                  
                  idle_battery_linear_scale.setProperty(hmUI.prop.MORE, {
                    x: start_x_idle_battery_draw,
                    y: start_y_idle_battery_draw,
                    w: lenght_ls_idle_battery_draw,
                    h: line_width_ls_idle_battery_draw,
                    color: color_ls_idle_battery,
                  });
                };

            };

            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                console.log('resume_call()');
                scale_call();
                checkConnection();
                stopVibro();

              }),
              pause_call: (function () {
                console.log('pause_call()');
                stopVibro();

              }),
            });

                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}