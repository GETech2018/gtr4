﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        const logger = Logger.getLogger('watchface_SashaCX75');
        //end of ignored block

        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_battery_pointer_progress_img_pointer = ''
        let normal_battery_TextCircle = new Array(3);
        let normal_battery_TextCircle_ASCIIARRAY = new Array(10);
        let normal_battery_TextCircle_img_width = 14;
        let normal_battery_TextCircle_img_height = 20;
        let normal_battery_TextCircle_unit = null;
        let normal_battery_TextCircle_unit_width = 37;
        let normal_battery_TextCircle_error_img_width = 1;
        let normal_pai_total_TextCircle = new Array(3);
        let normal_pai_total_TextCircle_ASCIIARRAY = new Array(10);
        let normal_pai_total_TextCircle_img_width = 14;
        let normal_pai_total_TextCircle_img_height = 20;
        let normal_temperature_current_text_img = ''
        let normal_weather_image_progress_img_level = ''
        let normal_heart_rate_TextCircle = new Array(3);
        let normal_heart_rate_TextCircle_ASCIIARRAY = new Array(10);
        let normal_heart_rate_TextCircle_img_width = 14;
        let normal_heart_rate_TextCircle_img_height = 20;
        let normal_heart_rate_TextCircle_error_img_width = 1;
        let normal_calorie_TextCircle = new Array(4);
        let normal_calorie_TextCircle_ASCIIARRAY = new Array(10);
        let normal_calorie_TextCircle_img_width = 14;
        let normal_calorie_TextCircle_img_height = 20;
        let normal_calorie_TextCircle_error_img_width = 1;
        let normal_distance_TextCircle = new Array(5);
        let normal_distance_TextCircle_ASCIIARRAY = new Array(10);
        let normal_distance_TextCircle_img_width = 14;
        let normal_distance_TextCircle_img_height = 20;
        let normal_distance_TextCircle_unit = null;
        let normal_distance_TextCircle_unit_width = 37;
        let normal_distance_TextCircle_dot_width = 9;
        let normal_distance_TextCircle_error_img_width = 1;
        let normal_step_TextCircle = new Array(5);
        let normal_step_TextCircle_ASCIIARRAY = new Array(10);
        let normal_step_TextCircle_img_width = 14;
        let normal_step_TextCircle_img_height = 20;
        let normal_step_TextCircle_error_img_width = 1;
        let normal_rotate_animation_img_1 = '';
        let normal_rotate_animation_param_1 = null;
        let normal_rotate_animation_lastTime_1 = 0;
        let timer_anim_rotate_1;
        let timer_anim_rotate_1_mirror = false;
        let normal_rotate_animation_param_1_mirror = null;
        let normal_rotate_animation_count_1 = 0;
        let normal_date_img_date_week_img = ''
        let normal_year_TextCircle = new Array(4);
        let normal_year_TextCircle_ASCIIARRAY = new Array(10);
        let normal_year_TextCircle_img_width = 10;
        let normal_year_TextCircle_img_height = 13;
        let normal_year_TextCircle_error_img_width = 1;
        let normal_timerTextUpdate = undefined;
        let normal_date_img_date_month_img = ''
        let normal_day_TextCircle = new Array(2);
        let normal_day_TextCircle_ASCIIARRAY = new Array(10);
        let normal_day_TextCircle_img_width = 10;
        let normal_day_TextCircle_img_height = 13;
        let normal_day_TextCircle_unit = null;
        let normal_day_TextCircle_unit_width = 4;
        let normal_day_TextCircle_error_img_width = 1;
        let normal_digital_clock_img_time_AmPm = ''
        let normal_digital_clock_img_time = ''
        let normal_analog_clock_time_pointer_hour = ''
        let normal_analog_clock_time_pointer_minute = ''
        let normal_analog_clock_time_pointer_second = ''
        let idle_background_bg_img = ''
        let idle_image_img = ''
        let idle_battery_pointer_progress_img_pointer = ''
        let idle_battery_TextCircle = new Array(3);
        let idle_battery_TextCircle_ASCIIARRAY = new Array(10);
        let idle_battery_TextCircle_img_width = 14;
        let idle_battery_TextCircle_img_height = 20;
        let idle_battery_TextCircle_unit = null;
        let idle_battery_TextCircle_unit_width = 37;
        let idle_battery_TextCircle_error_img_width = 1;
        let idle_pai_total_TextCircle = new Array(3);
        let idle_pai_total_TextCircle_ASCIIARRAY = new Array(10);
        let idle_pai_total_TextCircle_img_width = 14;
        let idle_pai_total_TextCircle_img_height = 20;
        let idle_temperature_current_text_img = ''
        let idle_weather_image_progress_img_level = ''
        let idle_heart_rate_TextCircle = new Array(3);
        let idle_heart_rate_TextCircle_ASCIIARRAY = new Array(10);
        let idle_heart_rate_TextCircle_img_width = 14;
        let idle_heart_rate_TextCircle_img_height = 20;
        let idle_heart_rate_TextCircle_error_img_width = 1;
        let idle_calorie_TextCircle = new Array(4);
        let idle_calorie_TextCircle_ASCIIARRAY = new Array(10);
        let idle_calorie_TextCircle_img_width = 14;
        let idle_calorie_TextCircle_img_height = 20;
        let idle_calorie_TextCircle_error_img_width = 1;
        let idle_distance_TextCircle = new Array(5);
        let idle_distance_TextCircle_ASCIIARRAY = new Array(10);
        let idle_distance_TextCircle_img_width = 14;
        let idle_distance_TextCircle_img_height = 20;
        let idle_distance_TextCircle_unit = null;
        let idle_distance_TextCircle_unit_width = 37;
        let idle_distance_TextCircle_dot_width = 9;
        let idle_distance_TextCircle_error_img_width = 1;
        let idle_step_TextCircle = new Array(5);
        let idle_step_TextCircle_ASCIIARRAY = new Array(10);
        let idle_step_TextCircle_img_width = 14;
        let idle_step_TextCircle_img_height = 20;
        let idle_step_TextCircle_error_img_width = 1;
        let idle_date_img_date_week_img = ''
        let idle_year_TextCircle = new Array(4);
        let idle_year_TextCircle_ASCIIARRAY = new Array(10);
        let idle_year_TextCircle_img_width = 10;
        let idle_year_TextCircle_img_height = 13;
        let idle_year_TextCircle_error_img_width = 1;
        let idle_timerTextUpdate = undefined;
        let idle_date_img_date_month_img = ''
        let idle_day_TextCircle = new Array(2);
        let idle_day_TextCircle_ASCIIARRAY = new Array(10);
        let idle_day_TextCircle_img_width = 10;
        let idle_day_TextCircle_img_height = 13;
        let idle_day_TextCircle_unit = null;
        let idle_day_TextCircle_unit_width = 4;
        let idle_day_TextCircle_error_img_width = 1;
        let idle_digital_clock_img_time_AmPm = ''
        let idle_digital_clock_img_time = ''
        let Button_1 = ''
        let Button_2 = ''
        let Button_3 = ''
        let Button_4 = ''
        let Button_5 = ''
        let Button_6 = ''
        let Button_7 = ''
        let Button_8 = ''
        let timeSensor = ''


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            console.log('Watch_Face.ScreenNormal');
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 466,
              h: 466,
              src: 'bg.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_pointer_progress_img_pointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
              src: 'pointer_0.png',
              center_x: 233,
              center_y: 233,
              x: 7,
              y: 159,
              start_angle: -135,
              end_angle: 135,
              invalid_visible: false,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_battery_text_circle_img = hmUI.createWidget(hmUI.widget.Text_Circle, {
              // circle_center_X: 233,
              // circle_center_Y: 233,
              // font_array: ["act_0.png","act_1.png","act_2.png","act_3.png","act_4.png","act_5.png","act_6.png","act_7.png","act_8.png","act_9.png"],
              // radius: 195,
              // angle: 132,
              // char_space_angle: 1,
              // unit: 'percent.png',
              // error_image: 'dot.png',
              // zero: false,
              // reverse_direction: true,
              // unit_in_alignment: true,
              // vertical_alignment: BOTTOM,
              // horizontal_alignment: CENTER_H,
              // type: hmUI.data_type.BATTERY,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_battery_TextCircle_ASCIIARRAY[0] = 'act_0.png';  // set of images with numbers
            normal_battery_TextCircle_ASCIIARRAY[1] = 'act_1.png';  // set of images with numbers
            normal_battery_TextCircle_ASCIIARRAY[2] = 'act_2.png';  // set of images with numbers
            normal_battery_TextCircle_ASCIIARRAY[3] = 'act_3.png';  // set of images with numbers
            normal_battery_TextCircle_ASCIIARRAY[4] = 'act_4.png';  // set of images with numbers
            normal_battery_TextCircle_ASCIIARRAY[5] = 'act_5.png';  // set of images with numbers
            normal_battery_TextCircle_ASCIIARRAY[6] = 'act_6.png';  // set of images with numbers
            normal_battery_TextCircle_ASCIIARRAY[7] = 'act_7.png';  // set of images with numbers
            normal_battery_TextCircle_ASCIIARRAY[8] = 'act_8.png';  // set of images with numbers
            normal_battery_TextCircle_ASCIIARRAY[9] = 'act_9.png';  // set of images with numbers

            //start of ignored block
            for (let i = 0; i < 3; i++) {
              normal_battery_TextCircle[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 466,
                h: 466,
                center_x: 233,
                center_y: 233,
                pos_x: 233 - normal_battery_TextCircle_img_width / 2,
                pos_y: 233 + 175,
                src: 'act_0.png',
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
              normal_battery_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
            };

            normal_battery_TextCircle_unit = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 466,
              h: 466,
              center_x: 233,
              center_y: 233,
              pos_x: 233 - normal_battery_TextCircle_unit_width / 2,
              pos_y: 233 + 175,
              src: 'percent.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            normal_battery_TextCircle_unit.setProperty(hmUI.prop.VISIBLE, false);
            //end of ignored block
            
            const battery = hmSensor.createSensor(hmSensor.id.BATTERY);
            battery.addEventListener(hmSensor.event.CHANGE, function() {
              text_update();
            });
            
            function toDegree (radian) {
              return radian * (180 / Math.PI);
            };

            // normal_pai_total_text_circle_img = hmUI.createWidget(hmUI.widget.Text_Circle, {
              // circle_center_X: 233,
              // circle_center_Y: 233,
              // font_array: ["act_0.png","act_1.png","act_2.png","act_3.png","act_4.png","act_5.png","act_6.png","act_7.png","act_8.png","act_9.png"],
              // radius: 197,
              // angle: -132,
              // char_space_angle: 1,
              // zero: false,
              // reverse_direction: true,
              // unit_in_alignment: true,
              // vertical_alignment: BOTTOM,
              // horizontal_alignment: CENTER_H,
              // type: hmUI.data_type.PAI_WEEKLY,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_pai_total_TextCircle_ASCIIARRAY[0] = 'act_0.png';  // set of images with numbers
            normal_pai_total_TextCircle_ASCIIARRAY[1] = 'act_1.png';  // set of images with numbers
            normal_pai_total_TextCircle_ASCIIARRAY[2] = 'act_2.png';  // set of images with numbers
            normal_pai_total_TextCircle_ASCIIARRAY[3] = 'act_3.png';  // set of images with numbers
            normal_pai_total_TextCircle_ASCIIARRAY[4] = 'act_4.png';  // set of images with numbers
            normal_pai_total_TextCircle_ASCIIARRAY[5] = 'act_5.png';  // set of images with numbers
            normal_pai_total_TextCircle_ASCIIARRAY[6] = 'act_6.png';  // set of images with numbers
            normal_pai_total_TextCircle_ASCIIARRAY[7] = 'act_7.png';  // set of images with numbers
            normal_pai_total_TextCircle_ASCIIARRAY[8] = 'act_8.png';  // set of images with numbers
            normal_pai_total_TextCircle_ASCIIARRAY[9] = 'act_9.png';  // set of images with numbers

            //start of ignored block
            for (let i = 0; i < 3; i++) {
              normal_pai_total_TextCircle[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 466,
                h: 466,
                center_x: 233,
                center_y: 233,
                pos_x: 233 - normal_pai_total_TextCircle_img_width / 2,
                pos_y: 233 + 177,
                src: 'act_0.png',
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
              normal_pai_total_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
            };
            //end of ignored block
            
            const pai = hmSensor.createSensor(hmSensor.id.PAI);
            pai.addEventListener(hmSensor.event.CHANGE, function() {
              text_update();
            });

            normal_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 255,
              y: 188,
              font_array: ["act_0.png","act_1.png","act_2.png","act_3.png","act_4.png","act_5.png","act_6.png","act_7.png","act_8.png","act_9.png"],
              padding: false,
              h_space: 1,
              unit_sc: 'pointer_3.png',
              unit_tc: 'pointer_3.png',
              unit_en: 'pointer_3.png',
              negative_image: 'pointer_2.png',
              invalid_image: 'dot.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 155,
              y: 179,
              image_array: ["weather_1.png","weather_2.png","weather_3.png","weather_4.png","weather_5.png","weather_6.png","weather_7.png","weather_8.png","weather_9.png","weather_10.png","weather_11.png","weather_12.png","weather_13.png","weather_14.png","weather_15.png","weather_16.png","weather_17.png","weather_18.png","weather_19.png","weather_20.png","weather_21.png","weather_22.png","weather_23.png","weather_24.png","weather_25.png","weather_26.png","weather_27.png","weather_28.png","weather_29.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_heart_rate_text_circle_img = hmUI.createWidget(hmUI.widget.Text_Circle, {
              // circle_center_X: 233,
              // circle_center_Y: 233,
              // font_array: ["act_0.png","act_1.png","act_2.png","act_3.png","act_4.png","act_5.png","act_6.png","act_7.png","act_8.png","act_9.png"],
              // radius: 175,
              // angle: 89,
              // char_space_angle: 1,
              // error_image: 'dot.png',
              // zero: false,
              // reverse_direction: false,
              // unit_in_alignment: true,
              // vertical_alignment: BOTTOM,
              // horizontal_alignment: CENTER_H,
              // type: hmUI.data_type.HEART,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_heart_rate_TextCircle_ASCIIARRAY[0] = 'act_0.png';  // set of images with numbers
            normal_heart_rate_TextCircle_ASCIIARRAY[1] = 'act_1.png';  // set of images with numbers
            normal_heart_rate_TextCircle_ASCIIARRAY[2] = 'act_2.png';  // set of images with numbers
            normal_heart_rate_TextCircle_ASCIIARRAY[3] = 'act_3.png';  // set of images with numbers
            normal_heart_rate_TextCircle_ASCIIARRAY[4] = 'act_4.png';  // set of images with numbers
            normal_heart_rate_TextCircle_ASCIIARRAY[5] = 'act_5.png';  // set of images with numbers
            normal_heart_rate_TextCircle_ASCIIARRAY[6] = 'act_6.png';  // set of images with numbers
            normal_heart_rate_TextCircle_ASCIIARRAY[7] = 'act_7.png';  // set of images with numbers
            normal_heart_rate_TextCircle_ASCIIARRAY[8] = 'act_8.png';  // set of images with numbers
            normal_heart_rate_TextCircle_ASCIIARRAY[9] = 'act_9.png';  // set of images with numbers

            //start of ignored block
            for (let i = 0; i < 3; i++) {
              normal_heart_rate_TextCircle[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 466,
                h: 466,
                center_x: 233,
                center_y: 233,
                pos_x: 233 - normal_heart_rate_TextCircle_img_width / 2,
                pos_y: 233 - 195,
                src: 'act_0.png',
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
              normal_heart_rate_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
            };
            //end of ignored block
            
            const heart_rate = hmSensor.createSensor(hmSensor.id.HEART);
            heart_rate.addEventListener(hmSensor.event.CHANGE, function() {
              text_update();
            });

            // normal_calorie_text_circle_img = hmUI.createWidget(hmUI.widget.Text_Circle, {
              // circle_center_X: 233,
              // circle_center_Y: 233,
              // font_array: ["act_0.png","act_1.png","act_2.png","act_3.png","act_4.png","act_5.png","act_6.png","act_7.png","act_8.png","act_9.png"],
              // radius: 175,
              // angle: 32,
              // char_space_angle: 1,
              // error_image: 'dot.png',
              // zero: false,
              // reverse_direction: false,
              // unit_in_alignment: true,
              // vertical_alignment: BOTTOM,
              // horizontal_alignment: CENTER_H,
              // type: hmUI.data_type.CAL,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_calorie_TextCircle_ASCIIARRAY[0] = 'act_0.png';  // set of images with numbers
            normal_calorie_TextCircle_ASCIIARRAY[1] = 'act_1.png';  // set of images with numbers
            normal_calorie_TextCircle_ASCIIARRAY[2] = 'act_2.png';  // set of images with numbers
            normal_calorie_TextCircle_ASCIIARRAY[3] = 'act_3.png';  // set of images with numbers
            normal_calorie_TextCircle_ASCIIARRAY[4] = 'act_4.png';  // set of images with numbers
            normal_calorie_TextCircle_ASCIIARRAY[5] = 'act_5.png';  // set of images with numbers
            normal_calorie_TextCircle_ASCIIARRAY[6] = 'act_6.png';  // set of images with numbers
            normal_calorie_TextCircle_ASCIIARRAY[7] = 'act_7.png';  // set of images with numbers
            normal_calorie_TextCircle_ASCIIARRAY[8] = 'act_8.png';  // set of images with numbers
            normal_calorie_TextCircle_ASCIIARRAY[9] = 'act_9.png';  // set of images with numbers

            //start of ignored block
            for (let i = 0; i < 4; i++) {
              normal_calorie_TextCircle[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 466,
                h: 466,
                center_x: 233,
                center_y: 233,
                pos_x: 233 - normal_calorie_TextCircle_img_width / 2,
                pos_y: 233 - 195,
                src: 'act_0.png',
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
              normal_calorie_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
            };
            //end of ignored block
            
            const calorie = hmSensor.createSensor(hmSensor.id.CALORIE);
            calorie.addEventListener(hmSensor.event.CHANGE, function() {
              text_update();
            });

            // normal_distance_text_circle_img = hmUI.createWidget(hmUI.widget.Text_Circle, {
              // circle_center_X: 233,
              // circle_center_Y: 233,
              // font_array: ["act_0.png","act_1.png","act_2.png","act_3.png","act_4.png","act_5.png","act_6.png","act_7.png","act_8.png","act_9.png"],
              // radius: 175,
              // angle: -27,
              // char_space_angle: 1,
              // unit: 'km.png',
              // imperial_unit: 'ml.png',
              // dot_image: 'pointer_5.png',
              // error_image: 'dot.png',
              // zero: false,
              // reverse_direction: false,
              // unit_in_alignment: true,
              // vertical_alignment: BOTTOM,
              // horizontal_alignment: CENTER_H,
              // type: hmUI.data_type.DISTANCE,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_distance_TextCircle_ASCIIARRAY[0] = 'act_0.png';  // set of images with numbers
            normal_distance_TextCircle_ASCIIARRAY[1] = 'act_1.png';  // set of images with numbers
            normal_distance_TextCircle_ASCIIARRAY[2] = 'act_2.png';  // set of images with numbers
            normal_distance_TextCircle_ASCIIARRAY[3] = 'act_3.png';  // set of images with numbers
            normal_distance_TextCircle_ASCIIARRAY[4] = 'act_4.png';  // set of images with numbers
            normal_distance_TextCircle_ASCIIARRAY[5] = 'act_5.png';  // set of images with numbers
            normal_distance_TextCircle_ASCIIARRAY[6] = 'act_6.png';  // set of images with numbers
            normal_distance_TextCircle_ASCIIARRAY[7] = 'act_7.png';  // set of images with numbers
            normal_distance_TextCircle_ASCIIARRAY[8] = 'act_8.png';  // set of images with numbers
            normal_distance_TextCircle_ASCIIARRAY[9] = 'act_9.png';  // set of images with numbers

            //start of ignored block
            for (let i = 0; i < 5; i++) {
              normal_distance_TextCircle[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 466,
                h: 466,
                center_x: 233,
                center_y: 233,
                pos_x: 233 - normal_distance_TextCircle_img_width / 2,
                pos_y: 233 - 195,
                src: 'act_0.png',
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
              normal_distance_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
            };

            normal_distance_TextCircle_unit = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 466,
              h: 466,
              center_x: 233,
              center_y: 233,
              pos_x: 233 - normal_distance_TextCircle_unit_width / 2,
              pos_y: 233 - 195,
              src: 'km.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            normal_distance_TextCircle_unit.setProperty(hmUI.prop.VISIBLE, false);

            const mileageUnit = hmSetting.getMileageUnit();
            if (mileageUnit == 1) {
              normal_distance_TextCircle_unit.setProperty(hmUI.prop.SRC, 'ml.png');
            };
            //end of ignored block
            
            const distance = hmSensor.createSensor(hmSensor.id.DISTANCE);
            distance.addEventListener(hmSensor.event.CHANGE, function() {
              text_update();
            });

            // normal_step_text_circle_img = hmUI.createWidget(hmUI.widget.Text_Circle, {
              // circle_center_X: 233,
              // circle_center_Y: 233,
              // font_array: ["act_0.png","act_1.png","act_2.png","act_3.png","act_4.png","act_5.png","act_6.png","act_7.png","act_8.png","act_9.png"],
              // radius: 175,
              // angle: -89,
              // char_space_angle: 1,
              // error_image: 'dot.png',
              // zero: false,
              // reverse_direction: false,
              // unit_in_alignment: true,
              // vertical_alignment: BOTTOM,
              // horizontal_alignment: CENTER_H,
              // type: hmUI.data_type.STEP,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_step_TextCircle_ASCIIARRAY[0] = 'act_0.png';  // set of images with numbers
            normal_step_TextCircle_ASCIIARRAY[1] = 'act_1.png';  // set of images with numbers
            normal_step_TextCircle_ASCIIARRAY[2] = 'act_2.png';  // set of images with numbers
            normal_step_TextCircle_ASCIIARRAY[3] = 'act_3.png';  // set of images with numbers
            normal_step_TextCircle_ASCIIARRAY[4] = 'act_4.png';  // set of images with numbers
            normal_step_TextCircle_ASCIIARRAY[5] = 'act_5.png';  // set of images with numbers
            normal_step_TextCircle_ASCIIARRAY[6] = 'act_6.png';  // set of images with numbers
            normal_step_TextCircle_ASCIIARRAY[7] = 'act_7.png';  // set of images with numbers
            normal_step_TextCircle_ASCIIARRAY[8] = 'act_8.png';  // set of images with numbers
            normal_step_TextCircle_ASCIIARRAY[9] = 'act_9.png';  // set of images with numbers

            //start of ignored block
            for (let i = 0; i < 5; i++) {
              normal_step_TextCircle[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 466,
                h: 466,
                center_x: 233,
                center_y: 233,
                pos_x: 233 - normal_step_TextCircle_img_width / 2,
                pos_y: 233 - 195,
                src: 'act_0.png',
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
              normal_step_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
            };
            //end of ignored block
            
            const step = hmSensor.createSensor(hmSensor.id.STEP);
            step.addEventListener(hmSensor.event.CHANGE, function() {
              text_update();
            });

            normal_rotate_animation_img_1 = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 467,
              h: 467,
              pos_x: 205,
              pos_y: 329,
              center_x: 232,
              center_y: 360,
              angle: -8,
              src: 'animation/anim_0.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_rotate_animation_param_1 = {
              anim_steps: [{
                anim_rate: 'linear',
                anim_duration: 200,
                anim_from: -8,
                anim_to: 8,
                anim_key: "angle",
              }],
              anim_fps: 30,
              anim_auto_start: 1,
              anim_repeat: 1,
              anim_auto_destroy: 1,
            };

            let now = hmSensor.createSensor(hmSensor.id.TIME);

            normal_rotate_animation_param_1_mirror = {
              anim_steps: [{
                anim_rate: 'linear',
                anim_duration: 200,
                anim_from: 8,
                anim_to: -8,
                anim_key: "angle",
              }],
              anim_fps: 30,
              anim_auto_start: 1,
              anim_repeat: 1,
              anim_auto_destroy: 1,
            };

            function anim_rotate_1_mirror() {
              normal_rotate_animation_img_1.setProperty(hmUI.prop.ANIM, normal_rotate_animation_param_1_mirror);
              normal_rotate_animation_lastTime_1 = now.utc;
              normal_rotate_animation_count_1 = normal_rotate_animation_count_1 - 1;
              if(normal_rotate_animation_count_1 < -1) normal_rotate_animation_count_1 = - 1;
              if(normal_rotate_animation_count_1 == 0) stop_anim_rotate_1();

            }; // end animation_mirror callback function

            function anim_rotate_1_complete_call() {
              normal_rotate_animation_img_1.setProperty(hmUI.prop.ANIM, normal_rotate_animation_param_1);
              normal_rotate_animation_lastTime_1 = now.utc;
            }; // end animation callback function
            
            function stop_anim_rotate_1() {
              if (timer_anim_rotate_1) {
                timer.stopTimer(timer_anim_rotate_1);
                timer_anim_rotate_1 = undefined;
              };
            }; // end stop_anim_rotate function

            // normal_rotate_anime_1 = hmUI.createWidget(hmUI.widget.Rotate_Animation, {
              // start_angle: -8,
              // end_angle: 8,
              // pos_x: 27,
              // pos_y: 31,
              // center_x: 232,
              // center_y: 360,
              // src: 'anim_0.png',
              // anim_fps: 30,
              // anim_duration: 200,
              // repeat_count: 0,
              // anim_two_sides: True,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 380,
              y: 280,
              week_en: ["day_1.png","day_2.png","day_3.png","day_4.png","day_5.png","day_6.png","day_7.png"],
              week_tc: ["day_1.png","day_2.png","day_3.png","day_4.png","day_5.png","day_6.png","day_7.png"],
              week_sc: ["day_1.png","day_2.png","day_3.png","day_4.png","day_5.png","day_6.png","day_7.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_year_text_circle_img = hmUI.createWidget(hmUI.widget.Text_Circle, {
              // circle_center_X: 233,
              // circle_center_Y: 233,
              // font_array: ["font_date_0.png","font_date_1.png","font_date_2.png","font_date_3.png","font_date_4.png","font_date_5.png","font_date_6.png","font_date_7.png","font_date_8.png","font_date_9.png"],
              // radius: 213,
              // angle: 79,
              // char_space_angle: 0,
              // error_image: 'dot.png',
              // zero: true,
              // reverse_direction: false,
              // unit_in_alignment: true,
              // vertical_alignment: BOTTOM,
              // horizontal_alignment: CENTER_H,
              // type: hmUI.data_type.YEAR,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_year_TextCircle_ASCIIARRAY[0] = 'font_date_0.png';  // set of images with numbers
            normal_year_TextCircle_ASCIIARRAY[1] = 'font_date_1.png';  // set of images with numbers
            normal_year_TextCircle_ASCIIARRAY[2] = 'font_date_2.png';  // set of images with numbers
            normal_year_TextCircle_ASCIIARRAY[3] = 'font_date_3.png';  // set of images with numbers
            normal_year_TextCircle_ASCIIARRAY[4] = 'font_date_4.png';  // set of images with numbers
            normal_year_TextCircle_ASCIIARRAY[5] = 'font_date_5.png';  // set of images with numbers
            normal_year_TextCircle_ASCIIARRAY[6] = 'font_date_6.png';  // set of images with numbers
            normal_year_TextCircle_ASCIIARRAY[7] = 'font_date_7.png';  // set of images with numbers
            normal_year_TextCircle_ASCIIARRAY[8] = 'font_date_8.png';  // set of images with numbers
            normal_year_TextCircle_ASCIIARRAY[9] = 'font_date_9.png';  // set of images with numbers

            //start of ignored block
            for (let i = 0; i < 4; i++) {
              normal_year_TextCircle[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 466,
                h: 466,
                center_x: 233,
                center_y: 233,
                pos_x: 233 - normal_year_TextCircle_img_width / 2,
                pos_y: 233 - 226,
                src: 'font_date_0.png',
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
              normal_year_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
            };
            //end of ignored block

            if (!timeSensor) timeSensor = hmSensor.createSensor(hmSensor.id.TIME);
            let screenType = hmSetting.getScreenType();
            normal_date_img_date_month_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 391,
              month_startY: 84,
              month_sc_array: ["month_1.png","month_2.png","month_3.png","month_4.png","month_5.png","month_6.png","month_7.png","month_8.png","month_9.png","month_10.png","month_11.png","month_12.png"],
              month_tc_array: ["month_1.png","month_2.png","month_3.png","month_4.png","month_5.png","month_6.png","month_7.png","month_8.png","month_9.png","month_10.png","month_11.png","month_12.png"],
              month_en_array: ["month_1.png","month_2.png","month_3.png","month_4.png","month_5.png","month_6.png","month_7.png","month_8.png","month_9.png","month_10.png","month_11.png","month_12.png"],
              month_is_character: true ,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_day_text_circle_img = hmUI.createWidget(hmUI.widget.Text_Circle, {
              // circle_center_X: 233,
              // circle_center_Y: 233,
              // font_array: ["font_date_0.png","font_date_1.png","font_date_2.png","font_date_3.png","font_date_4.png","font_date_5.png","font_date_6.png","font_date_7.png","font_date_8.png","font_date_9.png"],
              // radius: 214,
              // angle: 45,
              // char_space_angle: 0,
              // unit: 'pointer_1.png',
              // error_image: 'dot.png',
              // zero: false,
              // reverse_direction: false,
              // unit_in_alignment: true,
              // vertical_alignment: BOTTOM,
              // horizontal_alignment: CENTER_H,
              // type: hmUI.data_type.DAY,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_day_TextCircle_ASCIIARRAY[0] = 'font_date_0.png';  // set of images with numbers
            normal_day_TextCircle_ASCIIARRAY[1] = 'font_date_1.png';  // set of images with numbers
            normal_day_TextCircle_ASCIIARRAY[2] = 'font_date_2.png';  // set of images with numbers
            normal_day_TextCircle_ASCIIARRAY[3] = 'font_date_3.png';  // set of images with numbers
            normal_day_TextCircle_ASCIIARRAY[4] = 'font_date_4.png';  // set of images with numbers
            normal_day_TextCircle_ASCIIARRAY[5] = 'font_date_5.png';  // set of images with numbers
            normal_day_TextCircle_ASCIIARRAY[6] = 'font_date_6.png';  // set of images with numbers
            normal_day_TextCircle_ASCIIARRAY[7] = 'font_date_7.png';  // set of images with numbers
            normal_day_TextCircle_ASCIIARRAY[8] = 'font_date_8.png';  // set of images with numbers
            normal_day_TextCircle_ASCIIARRAY[9] = 'font_date_9.png';  // set of images with numbers

            //start of ignored block
            for (let i = 0; i < 2; i++) {
              normal_day_TextCircle[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 466,
                h: 466,
                center_x: 233,
                center_y: 233,
                pos_x: 233 - normal_day_TextCircle_img_width / 2,
                pos_y: 233 - 227,
                src: 'font_date_0.png',
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
              normal_day_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
            };

            normal_day_TextCircle_unit = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 466,
              h: 466,
              center_x: 233,
              center_y: 233,
              pos_x: 233 - normal_day_TextCircle_unit_width / 2,
              pos_y: 233 - 227,
              src: 'pointer_1.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            normal_day_TextCircle_unit.setProperty(hmUI.prop.VISIBLE, false);
            //end of ignored block

            normal_digital_clock_img_time_AmPm = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              am_x: 280,
              am_y: 412,
              am_sc_path: 'am.png',
              am_en_path: 'am.png',
              pm_x: 280,
              pm_y: 412,
              pm_sc_path: 'pm.png',
              pm_en_path: 'pm.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 150,
              hour_startY: 414,
              hour_array: ["time_0.png","time_1.png","time_2.png","time_3.png","time_4.png","time_5.png","time_6.png","time_7.png","time_8.png","time_9.png"],
              hour_zero: 1,
              hour_space: 3,
              hour_angle: 0,
              hour_unit_sc: 'pointer_4.png',
              hour_unit_tc: 'pointer_4.png',
              hour_unit_en: 'pointer_4.png',
              hour_align: hmUI.align.LEFT,

              minute_startX: 216,
              minute_startY: 414,
              minute_array: ["time_0.png","time_1.png","time_2.png","time_3.png","time_4.png","time_5.png","time_6.png","time_7.png","time_8.png","time_9.png"],
              minute_zero: 1,
              minute_space: 3,
              minute_angle: 0,
              minute_follow: 0,
              minute_unit_sc: 'pointer_4.png',
              minute_unit_tc: 'pointer_4.png',
              minute_unit_en: 'pointer_4.png',
              minute_align: hmUI.align.LEFT,

              second_startX: 284,
              second_startY: 423,
              second_array: ["act_0.png","act_1.png","act_2.png","act_3.png","act_4.png","act_5.png","act_6.png","act_7.png","act_8.png","act_9.png"],
              second_zero: 1,
              second_space: 4,
              second_angle: 0,
              second_follow: 0,
              second_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_hour = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              hour_path: 'hour.png',
              hour_centerX: 233,
              hour_centerY: 233,
              hour_posX: 24,
              hour_posY: 165,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_minute = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              minute_path: 'minute.png',
              minute_centerX: 233,
              minute_centerY: 233,
              minute_posX: 16,
              minute_posY: 228,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_second = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              second_path: 'second.png',
              second_centerX: 233,
              second_centerY: 233,
              second_posX: 12,
              second_posY: 228,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            console.log('Watch_Face.ScreenAOD');
            idle_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 466,
              h: 466,
              src: 'aod.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_image_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 204,
              y: 328,
              src: 'anim_0.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_battery_pointer_progress_img_pointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
              src: 'pointer_0.png',
              center_x: 233,
              center_y: 233,
              x: 7,
              y: 159,
              start_angle: -135,
              end_angle: 135,
              invalid_visible: false,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            // idle_battery_text_circle_img = hmUI.createWidget(hmUI.widget.Text_Circle, {
              // circle_center_X: 233,
              // circle_center_Y: 233,
              // font_array: ["act_0.png","act_1.png","act_2.png","act_3.png","act_4.png","act_5.png","act_6.png","act_7.png","act_8.png","act_9.png"],
              // radius: 195,
              // angle: 132,
              // char_space_angle: 1,
              // unit: 'percent.png',
              // error_image: 'dot.png',
              // zero: false,
              // reverse_direction: true,
              // unit_in_alignment: true,
              // vertical_alignment: BOTTOM,
              // horizontal_alignment: CENTER_H,
              // type: hmUI.data_type.BATTERY,
              // show_level: hmUI.show_level.ONLY_AOD,
            // });

            idle_battery_TextCircle_ASCIIARRAY[0] = 'act_0.png';  // set of images with numbers
            idle_battery_TextCircle_ASCIIARRAY[1] = 'act_1.png';  // set of images with numbers
            idle_battery_TextCircle_ASCIIARRAY[2] = 'act_2.png';  // set of images with numbers
            idle_battery_TextCircle_ASCIIARRAY[3] = 'act_3.png';  // set of images with numbers
            idle_battery_TextCircle_ASCIIARRAY[4] = 'act_4.png';  // set of images with numbers
            idle_battery_TextCircle_ASCIIARRAY[5] = 'act_5.png';  // set of images with numbers
            idle_battery_TextCircle_ASCIIARRAY[6] = 'act_6.png';  // set of images with numbers
            idle_battery_TextCircle_ASCIIARRAY[7] = 'act_7.png';  // set of images with numbers
            idle_battery_TextCircle_ASCIIARRAY[8] = 'act_8.png';  // set of images with numbers
            idle_battery_TextCircle_ASCIIARRAY[9] = 'act_9.png';  // set of images with numbers

            //start of ignored block
            for (let i = 0; i < 3; i++) {
              idle_battery_TextCircle[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 466,
                h: 466,
                center_x: 233,
                center_y: 233,
                pos_x: 233 - idle_battery_TextCircle_img_width / 2,
                pos_y: 233 + 175,
                src: 'act_0.png',
                show_level: hmUI.show_level.ONLY_AOD,
              });
              idle_battery_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
            };

            idle_battery_TextCircle_unit = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 466,
              h: 466,
              center_x: 233,
              center_y: 233,
              pos_x: 233 - idle_battery_TextCircle_unit_width / 2,
              pos_y: 233 + 175,
              src: 'percent.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });
            idle_battery_TextCircle_unit.setProperty(hmUI.prop.VISIBLE, false);
            //end of ignored block

            // idle_pai_total_text_circle_img = hmUI.createWidget(hmUI.widget.Text_Circle, {
              // circle_center_X: 233,
              // circle_center_Y: 233,
              // font_array: ["act_0.png","act_1.png","act_2.png","act_3.png","act_4.png","act_5.png","act_6.png","act_7.png","act_8.png","act_9.png"],
              // radius: 197,
              // angle: -132,
              // char_space_angle: 1,
              // zero: false,
              // reverse_direction: true,
              // unit_in_alignment: true,
              // vertical_alignment: BOTTOM,
              // horizontal_alignment: CENTER_H,
              // type: hmUI.data_type.PAI_WEEKLY,
              // show_level: hmUI.show_level.ONLY_AOD,
            // });

            idle_pai_total_TextCircle_ASCIIARRAY[0] = 'act_0.png';  // set of images with numbers
            idle_pai_total_TextCircle_ASCIIARRAY[1] = 'act_1.png';  // set of images with numbers
            idle_pai_total_TextCircle_ASCIIARRAY[2] = 'act_2.png';  // set of images with numbers
            idle_pai_total_TextCircle_ASCIIARRAY[3] = 'act_3.png';  // set of images with numbers
            idle_pai_total_TextCircle_ASCIIARRAY[4] = 'act_4.png';  // set of images with numbers
            idle_pai_total_TextCircle_ASCIIARRAY[5] = 'act_5.png';  // set of images with numbers
            idle_pai_total_TextCircle_ASCIIARRAY[6] = 'act_6.png';  // set of images with numbers
            idle_pai_total_TextCircle_ASCIIARRAY[7] = 'act_7.png';  // set of images with numbers
            idle_pai_total_TextCircle_ASCIIARRAY[8] = 'act_8.png';  // set of images with numbers
            idle_pai_total_TextCircle_ASCIIARRAY[9] = 'act_9.png';  // set of images with numbers

            //start of ignored block
            for (let i = 0; i < 3; i++) {
              idle_pai_total_TextCircle[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 466,
                h: 466,
                center_x: 233,
                center_y: 233,
                pos_x: 233 - idle_pai_total_TextCircle_img_width / 2,
                pos_y: 233 + 177,
                src: 'act_0.png',
                show_level: hmUI.show_level.ONLY_AOD,
              });
              idle_pai_total_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
            };
            //end of ignored block

            idle_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 255,
              y: 188,
              font_array: ["act_0.png","act_1.png","act_2.png","act_3.png","act_4.png","act_5.png","act_6.png","act_7.png","act_8.png","act_9.png"],
              padding: false,
              h_space: 1,
              unit_sc: 'pointer_3.png',
              unit_tc: 'pointer_3.png',
              unit_en: 'pointer_3.png',
              negative_image: 'pointer_2.png',
              invalid_image: 'dot.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 155,
              y: 179,
              image_array: ["weather_1.png","weather_2.png","weather_3.png","weather_4.png","weather_5.png","weather_6.png","weather_7.png","weather_8.png","weather_9.png","weather_10.png","weather_11.png","weather_12.png","weather_13.png","weather_14.png","weather_15.png","weather_16.png","weather_17.png","weather_18.png","weather_19.png","weather_20.png","weather_21.png","weather_22.png","weather_23.png","weather_24.png","weather_25.png","weather_26.png","weather_27.png","weather_28.png","weather_29.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            // idle_heart_rate_text_circle_img = hmUI.createWidget(hmUI.widget.Text_Circle, {
              // circle_center_X: 233,
              // circle_center_Y: 233,
              // font_array: ["act_0.png","act_1.png","act_2.png","act_3.png","act_4.png","act_5.png","act_6.png","act_7.png","act_8.png","act_9.png"],
              // radius: 175,
              // angle: 89,
              // char_space_angle: 1,
              // error_image: 'dot.png',
              // zero: false,
              // reverse_direction: false,
              // unit_in_alignment: true,
              // vertical_alignment: BOTTOM,
              // horizontal_alignment: CENTER_H,
              // type: hmUI.data_type.HEART,
              // show_level: hmUI.show_level.ONLY_AOD,
            // });

            idle_heart_rate_TextCircle_ASCIIARRAY[0] = 'act_0.png';  // set of images with numbers
            idle_heart_rate_TextCircle_ASCIIARRAY[1] = 'act_1.png';  // set of images with numbers
            idle_heart_rate_TextCircle_ASCIIARRAY[2] = 'act_2.png';  // set of images with numbers
            idle_heart_rate_TextCircle_ASCIIARRAY[3] = 'act_3.png';  // set of images with numbers
            idle_heart_rate_TextCircle_ASCIIARRAY[4] = 'act_4.png';  // set of images with numbers
            idle_heart_rate_TextCircle_ASCIIARRAY[5] = 'act_5.png';  // set of images with numbers
            idle_heart_rate_TextCircle_ASCIIARRAY[6] = 'act_6.png';  // set of images with numbers
            idle_heart_rate_TextCircle_ASCIIARRAY[7] = 'act_7.png';  // set of images with numbers
            idle_heart_rate_TextCircle_ASCIIARRAY[8] = 'act_8.png';  // set of images with numbers
            idle_heart_rate_TextCircle_ASCIIARRAY[9] = 'act_9.png';  // set of images with numbers

            //start of ignored block
            for (let i = 0; i < 3; i++) {
              idle_heart_rate_TextCircle[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 466,
                h: 466,
                center_x: 233,
                center_y: 233,
                pos_x: 233 - idle_heart_rate_TextCircle_img_width / 2,
                pos_y: 233 - 195,
                src: 'act_0.png',
                show_level: hmUI.show_level.ONLY_AOD,
              });
              idle_heart_rate_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
            };
            //end of ignored block

            // idle_calorie_text_circle_img = hmUI.createWidget(hmUI.widget.Text_Circle, {
              // circle_center_X: 233,
              // circle_center_Y: 233,
              // font_array: ["act_0.png","act_1.png","act_2.png","act_3.png","act_4.png","act_5.png","act_6.png","act_7.png","act_8.png","act_9.png"],
              // radius: 175,
              // angle: 32,
              // char_space_angle: 1,
              // error_image: 'dot.png',
              // zero: false,
              // reverse_direction: false,
              // unit_in_alignment: true,
              // vertical_alignment: BOTTOM,
              // horizontal_alignment: CENTER_H,
              // type: hmUI.data_type.CAL,
              // show_level: hmUI.show_level.ONLY_AOD,
            // });

            idle_calorie_TextCircle_ASCIIARRAY[0] = 'act_0.png';  // set of images with numbers
            idle_calorie_TextCircle_ASCIIARRAY[1] = 'act_1.png';  // set of images with numbers
            idle_calorie_TextCircle_ASCIIARRAY[2] = 'act_2.png';  // set of images with numbers
            idle_calorie_TextCircle_ASCIIARRAY[3] = 'act_3.png';  // set of images with numbers
            idle_calorie_TextCircle_ASCIIARRAY[4] = 'act_4.png';  // set of images with numbers
            idle_calorie_TextCircle_ASCIIARRAY[5] = 'act_5.png';  // set of images with numbers
            idle_calorie_TextCircle_ASCIIARRAY[6] = 'act_6.png';  // set of images with numbers
            idle_calorie_TextCircle_ASCIIARRAY[7] = 'act_7.png';  // set of images with numbers
            idle_calorie_TextCircle_ASCIIARRAY[8] = 'act_8.png';  // set of images with numbers
            idle_calorie_TextCircle_ASCIIARRAY[9] = 'act_9.png';  // set of images with numbers

            //start of ignored block
            for (let i = 0; i < 4; i++) {
              idle_calorie_TextCircle[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 466,
                h: 466,
                center_x: 233,
                center_y: 233,
                pos_x: 233 - idle_calorie_TextCircle_img_width / 2,
                pos_y: 233 - 195,
                src: 'act_0.png',
                show_level: hmUI.show_level.ONLY_AOD,
              });
              idle_calorie_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
            };
            //end of ignored block

            // idle_distance_text_circle_img = hmUI.createWidget(hmUI.widget.Text_Circle, {
              // circle_center_X: 233,
              // circle_center_Y: 233,
              // font_array: ["act_0.png","act_1.png","act_2.png","act_3.png","act_4.png","act_5.png","act_6.png","act_7.png","act_8.png","act_9.png"],
              // radius: 175,
              // angle: -27,
              // char_space_angle: 1,
              // unit: 'km.png',
              // imperial_unit: 'ml.png',
              // dot_image: 'pointer_5.png',
              // error_image: 'dot.png',
              // zero: false,
              // reverse_direction: false,
              // unit_in_alignment: true,
              // vertical_alignment: BOTTOM,
              // horizontal_alignment: CENTER_H,
              // type: hmUI.data_type.DISTANCE,
              // show_level: hmUI.show_level.ONLY_AOD,
            // });

            idle_distance_TextCircle_ASCIIARRAY[0] = 'act_0.png';  // set of images with numbers
            idle_distance_TextCircle_ASCIIARRAY[1] = 'act_1.png';  // set of images with numbers
            idle_distance_TextCircle_ASCIIARRAY[2] = 'act_2.png';  // set of images with numbers
            idle_distance_TextCircle_ASCIIARRAY[3] = 'act_3.png';  // set of images with numbers
            idle_distance_TextCircle_ASCIIARRAY[4] = 'act_4.png';  // set of images with numbers
            idle_distance_TextCircle_ASCIIARRAY[5] = 'act_5.png';  // set of images with numbers
            idle_distance_TextCircle_ASCIIARRAY[6] = 'act_6.png';  // set of images with numbers
            idle_distance_TextCircle_ASCIIARRAY[7] = 'act_7.png';  // set of images with numbers
            idle_distance_TextCircle_ASCIIARRAY[8] = 'act_8.png';  // set of images with numbers
            idle_distance_TextCircle_ASCIIARRAY[9] = 'act_9.png';  // set of images with numbers

            //start of ignored block
            for (let i = 0; i < 5; i++) {
              idle_distance_TextCircle[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 466,
                h: 466,
                center_x: 233,
                center_y: 233,
                pos_x: 233 - idle_distance_TextCircle_img_width / 2,
                pos_y: 233 - 195,
                src: 'act_0.png',
                show_level: hmUI.show_level.ONLY_AOD,
              });
              idle_distance_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
            };

            idle_distance_TextCircle_unit = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 466,
              h: 466,
              center_x: 233,
              center_y: 233,
              pos_x: 233 - idle_distance_TextCircle_unit_width / 2,
              pos_y: 233 - 195,
              src: 'km.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });
            idle_distance_TextCircle_unit.setProperty(hmUI.prop.VISIBLE, false);

            if (mileageUnit == 1) {
              idle_distance_TextCircle_unit.setProperty(hmUI.prop.SRC, 'ml.png');
            };
            //end of ignored block

            // idle_step_text_circle_img = hmUI.createWidget(hmUI.widget.Text_Circle, {
              // circle_center_X: 233,
              // circle_center_Y: 233,
              // font_array: ["act_0.png","act_1.png","act_2.png","act_3.png","act_4.png","act_5.png","act_6.png","act_7.png","act_8.png","act_9.png"],
              // radius: 175,
              // angle: -89,
              // char_space_angle: 1,
              // error_image: 'dot.png',
              // zero: false,
              // reverse_direction: false,
              // unit_in_alignment: true,
              // vertical_alignment: BOTTOM,
              // horizontal_alignment: CENTER_H,
              // type: hmUI.data_type.STEP,
              // show_level: hmUI.show_level.ONLY_AOD,
            // });

            idle_step_TextCircle_ASCIIARRAY[0] = 'act_0.png';  // set of images with numbers
            idle_step_TextCircle_ASCIIARRAY[1] = 'act_1.png';  // set of images with numbers
            idle_step_TextCircle_ASCIIARRAY[2] = 'act_2.png';  // set of images with numbers
            idle_step_TextCircle_ASCIIARRAY[3] = 'act_3.png';  // set of images with numbers
            idle_step_TextCircle_ASCIIARRAY[4] = 'act_4.png';  // set of images with numbers
            idle_step_TextCircle_ASCIIARRAY[5] = 'act_5.png';  // set of images with numbers
            idle_step_TextCircle_ASCIIARRAY[6] = 'act_6.png';  // set of images with numbers
            idle_step_TextCircle_ASCIIARRAY[7] = 'act_7.png';  // set of images with numbers
            idle_step_TextCircle_ASCIIARRAY[8] = 'act_8.png';  // set of images with numbers
            idle_step_TextCircle_ASCIIARRAY[9] = 'act_9.png';  // set of images with numbers

            //start of ignored block
            for (let i = 0; i < 5; i++) {
              idle_step_TextCircle[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 466,
                h: 466,
                center_x: 233,
                center_y: 233,
                pos_x: 233 - idle_step_TextCircle_img_width / 2,
                pos_y: 233 - 195,
                src: 'act_0.png',
                show_level: hmUI.show_level.ONLY_AOD,
              });
              idle_step_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
            };
            //end of ignored block

            idle_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 380,
              y: 280,
              week_en: ["day_1.png","day_2.png","day_3.png","day_4.png","day_5.png","day_6.png","day_7.png"],
              week_tc: ["day_1.png","day_2.png","day_3.png","day_4.png","day_5.png","day_6.png","day_7.png"],
              week_sc: ["day_1.png","day_2.png","day_3.png","day_4.png","day_5.png","day_6.png","day_7.png"],
              show_level: hmUI.show_level.ONLY_AOD,
            });

            // idle_year_text_circle_img = hmUI.createWidget(hmUI.widget.Text_Circle, {
              // circle_center_X: 233,
              // circle_center_Y: 233,
              // font_array: ["font_date_0.png","font_date_1.png","font_date_2.png","font_date_3.png","font_date_4.png","font_date_5.png","font_date_6.png","font_date_7.png","font_date_8.png","font_date_9.png"],
              // radius: 213,
              // angle: 79,
              // char_space_angle: 0,
              // error_image: 'dot.png',
              // zero: true,
              // reverse_direction: false,
              // unit_in_alignment: true,
              // vertical_alignment: BOTTOM,
              // horizontal_alignment: CENTER_H,
              // type: hmUI.data_type.YEAR,
              // show_level: hmUI.show_level.ONLY_AOD,
            // });

            idle_year_TextCircle_ASCIIARRAY[0] = 'font_date_0.png';  // set of images with numbers
            idle_year_TextCircle_ASCIIARRAY[1] = 'font_date_1.png';  // set of images with numbers
            idle_year_TextCircle_ASCIIARRAY[2] = 'font_date_2.png';  // set of images with numbers
            idle_year_TextCircle_ASCIIARRAY[3] = 'font_date_3.png';  // set of images with numbers
            idle_year_TextCircle_ASCIIARRAY[4] = 'font_date_4.png';  // set of images with numbers
            idle_year_TextCircle_ASCIIARRAY[5] = 'font_date_5.png';  // set of images with numbers
            idle_year_TextCircle_ASCIIARRAY[6] = 'font_date_6.png';  // set of images with numbers
            idle_year_TextCircle_ASCIIARRAY[7] = 'font_date_7.png';  // set of images with numbers
            idle_year_TextCircle_ASCIIARRAY[8] = 'font_date_8.png';  // set of images with numbers
            idle_year_TextCircle_ASCIIARRAY[9] = 'font_date_9.png';  // set of images with numbers

            //start of ignored block
            for (let i = 0; i < 4; i++) {
              idle_year_TextCircle[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 466,
                h: 466,
                center_x: 233,
                center_y: 233,
                pos_x: 233 - idle_year_TextCircle_img_width / 2,
                pos_y: 233 - 226,
                src: 'font_date_0.png',
                show_level: hmUI.show_level.ONLY_AOD,
              });
              idle_year_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
            };
            //end of ignored block

            idle_date_img_date_month_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 391,
              month_startY: 84,
              month_sc_array: ["month_1.png","month_2.png","month_3.png","month_4.png","month_5.png","month_6.png","month_7.png","month_8.png","month_9.png","month_10.png","month_11.png","month_12.png"],
              month_tc_array: ["month_1.png","month_2.png","month_3.png","month_4.png","month_5.png","month_6.png","month_7.png","month_8.png","month_9.png","month_10.png","month_11.png","month_12.png"],
              month_en_array: ["month_1.png","month_2.png","month_3.png","month_4.png","month_5.png","month_6.png","month_7.png","month_8.png","month_9.png","month_10.png","month_11.png","month_12.png"],
              month_is_character: true ,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            // idle_day_text_circle_img = hmUI.createWidget(hmUI.widget.Text_Circle, {
              // circle_center_X: 233,
              // circle_center_Y: 233,
              // font_array: ["font_date_0.png","font_date_1.png","font_date_2.png","font_date_3.png","font_date_4.png","font_date_5.png","font_date_6.png","font_date_7.png","font_date_8.png","font_date_9.png"],
              // radius: 214,
              // angle: 45,
              // char_space_angle: 0,
              // unit: 'pointer_1.png',
              // error_image: 'dot.png',
              // zero: false,
              // reverse_direction: false,
              // unit_in_alignment: true,
              // vertical_alignment: BOTTOM,
              // horizontal_alignment: CENTER_H,
              // type: hmUI.data_type.DAY,
              // show_level: hmUI.show_level.ONLY_AOD,
            // });

            idle_day_TextCircle_ASCIIARRAY[0] = 'font_date_0.png';  // set of images with numbers
            idle_day_TextCircle_ASCIIARRAY[1] = 'font_date_1.png';  // set of images with numbers
            idle_day_TextCircle_ASCIIARRAY[2] = 'font_date_2.png';  // set of images with numbers
            idle_day_TextCircle_ASCIIARRAY[3] = 'font_date_3.png';  // set of images with numbers
            idle_day_TextCircle_ASCIIARRAY[4] = 'font_date_4.png';  // set of images with numbers
            idle_day_TextCircle_ASCIIARRAY[5] = 'font_date_5.png';  // set of images with numbers
            idle_day_TextCircle_ASCIIARRAY[6] = 'font_date_6.png';  // set of images with numbers
            idle_day_TextCircle_ASCIIARRAY[7] = 'font_date_7.png';  // set of images with numbers
            idle_day_TextCircle_ASCIIARRAY[8] = 'font_date_8.png';  // set of images with numbers
            idle_day_TextCircle_ASCIIARRAY[9] = 'font_date_9.png';  // set of images with numbers

            //start of ignored block
            for (let i = 0; i < 2; i++) {
              idle_day_TextCircle[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 466,
                h: 466,
                center_x: 233,
                center_y: 233,
                pos_x: 233 - idle_day_TextCircle_img_width / 2,
                pos_y: 233 - 227,
                src: 'font_date_0.png',
                show_level: hmUI.show_level.ONLY_AOD,
              });
              idle_day_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
            };

            idle_day_TextCircle_unit = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 466,
              h: 466,
              center_x: 233,
              center_y: 233,
              pos_x: 233 - idle_day_TextCircle_unit_width / 2,
              pos_y: 233 - 227,
              src: 'pointer_1.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });
            idle_day_TextCircle_unit.setProperty(hmUI.prop.VISIBLE, false);
            //end of ignored block

            idle_digital_clock_img_time_AmPm = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              am_x: 280,
              am_y: 412,
              am_sc_path: 'am.png',
              am_en_path: 'am.png',
              pm_x: 280,
              pm_y: 412,
              pm_sc_path: 'pm.png',
              pm_en_path: 'pm.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 150,
              hour_startY: 414,
              hour_array: ["time_0.png","time_1.png","time_2.png","time_3.png","time_4.png","time_5.png","time_6.png","time_7.png","time_8.png","time_9.png"],
              hour_zero: 1,
              hour_space: 3,
              hour_angle: 0,
              hour_unit_sc: 'pointer_4.png',
              hour_unit_tc: 'pointer_4.png',
              hour_unit_en: 'pointer_4.png',
              hour_align: hmUI.align.LEFT,

              minute_startX: 216,
              minute_startY: 414,
              minute_array: ["time_0.png","time_1.png","time_2.png","time_3.png","time_4.png","time_5.png","time_6.png","time_7.png","time_8.png","time_9.png"],
              minute_zero: 1,
              minute_space: 3,
              minute_angle: 0,
              minute_follow: 0,
              minute_unit_sc: 'pointer_4.png',
              minute_unit_tc: 'pointer_4.png',
              minute_unit_en: 'pointer_4.png',
              minute_align: hmUI.align.LEFT,

              second_startX: 284,
              second_startY: 423,
              second_array: ["act_0.png","act_1.png","act_2.png","act_3.png","act_4.png","act_5.png","act_6.png","act_7.png","act_8.png","act_9.png"],
              second_zero: 1,
              second_space: 4,
              second_angle: 0,
              second_follow: 0,
              second_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_AOD,
            });
            
            // disconnectAlert = hmUI.createWidget(hmUI.widget.DisconnectAlert, {
              // disconneсnt_vibrate_type: 25,
              // disconneсnt_toast_text: Bluetooth has been disconnected!,
              // conneсnt_vibrate_type: 25,
              // conneсnt_toast_text: Bluetooth has been reconnected!,
            // });

            // vibration when connecting or disconnecting

            function checkConnection() {
              console.log('checkConnection()');
              hmBle.removeListener;
              hmBle.addListener(function (status) {
                if(!status) {
                  hmUI.showToast({text: "Bluetooth has been disconnected!"});
                  vibro(25);
                }
                if(status) {
                  hmUI.showToast({text: "Bluetooth has been reconnected!"});
                  vibro(25);
                }
              });
            }

            // end vibration when connecting or disconnecting
            // vibrate function

            const vibrate = hmSensor.createSensor(hmSensor.id.VIBRATE);
            let timer_StopVibrate = null;


            function vibro(scene = 25) {
              let stopDelay = 50;
              stopVibro();
              vibrate.stop();
              vibrate.scene = scene;
              if(scene < 23 || scene > 25) stopDelay = 1300;
              vibrate.start();
              if (scene != 1) timer_StopVibrate = timer.createTimer(stopDelay, 3000, stopVibro, {});
            }

            function stopVibro(){
              vibrate.stop();
              if(timer_StopVibrate) timer.stopTimer(timer_StopVibrate);
            }

            // end vibrate function

            console.log('Watch_Face.Buttons');
            Button_1 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 388,
              y: 289,
              w: 29,
              h: 29,
              text: '',
              color: 0xFFFF8C00,
              text_size: 24,
              press_src: 'dot.png',
              normal_src: 'dot.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'PhoneMusicCtrlScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_2 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 217,
              y: 404,
              w: 57,
              h: 50,
              text: '',
              color: 0xFFFF8C00,
              text_size: 24,
              press_src: 'dot.png',
              normal_src: 'dot.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'Sleep_HomeScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_3 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 150,
              y: 404,
              w: 57,
              h: 50,
              text: '',
              color: 0xFFFF8C00,
              text_size: 24,
              press_src: 'dot.png',
              normal_src: 'dot.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'AlarmInfoScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_4 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 327,
              y: 327,
              w: 76,
              h: 73,
              text: '',
              color: 0xFFFF8C00,
              text_size: 24,
              press_src: 'dot.png',
              normal_src: 'dot.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'LowBatteryScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_5 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 248,
              y: 5,
              w: 79,
              h: 44,
              text: '',
              color: 0xFFFF8C00,
              text_size: 24,
              press_src: 'dot.png',
              normal_src: 'dot.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'StressHomeScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_6 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 139,
              y: 5,
              w: 79,
              h: 44,
              text: '',
              color: 0xFFFF8C00,
              text_size: 24,
              press_src: 'dot.png',
              normal_src: 'dot.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'spo_HomeScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_7 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 2,
              y: 57,
              w: 79,
              h: 160,
              text: '',
              color: 0xFFFF8C00,
              text_size: 24,
              press_src: 'dot.png',
              normal_src: 'dot.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'ScheduleCalScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_8 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 2,
              y: 268,
              w: 92,
              h: 160,
              text: '',
              color: 0xFFFF8C00,
              text_size: 24,
              press_src: 'dot.png',
              normal_src: 'dot.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'SportListScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            function text_update() {
              console.log('text_update()');

              console.log('update text circle battery_BATTERY');
              let valueBattery = battery.current;
              let normal_battery_circle_string = parseInt(valueBattery).toString();

              if (screenType != hmSetting.screen_type.AOD) {
                for (var i = 1; i < 3; i++) {  // hide all symbols
                  normal_battery_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                normal_battery_TextCircle_unit.setProperty(hmUI.prop.VISIBLE, false);
                let char_Angle = 312;
                if (valueBattery != null && valueBattery != undefined && isFinite(valueBattery) && normal_battery_circle_string.length > 0 && normal_battery_circle_string.length < 6) {  // display data if it was possible to get it
                  let normal_battery_TextCircle_img_angle = 0;
                  let normal_battery_TextCircle_dot_img_angle = 0;
                  let normal_battery_TextCircle_unit_angle = 0;
                  normal_battery_TextCircle_img_angle = toDegree(Math.atan2(normal_battery_TextCircle_img_width/2, 195));
                  normal_battery_TextCircle_unit_angle = toDegree(Math.atan2(normal_battery_TextCircle_unit_width/2, 195));
                  // alignment = CENTER_H
                  let normal_battery_TextCircle_angleOffset = normal_battery_TextCircle_img_angle * (normal_battery_circle_string.length - 1);
                  normal_battery_TextCircle_angleOffset = normal_battery_TextCircle_angleOffset + 1 * (normal_battery_circle_string.length - 1) / 2;
                  normal_battery_TextCircle_angleOffset = normal_battery_TextCircle_angleOffset + (normal_battery_TextCircle_img_angle + normal_battery_TextCircle_unit_angle + 1) / 2;
                  normal_battery_TextCircle_angleOffset = -normal_battery_TextCircle_angleOffset;
                  char_Angle -= normal_battery_TextCircle_angleOffset;
                  // alignment end
                  
                  let firstSymbol = true;
                  let index = 0;
                  for (let char of normal_battery_circle_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 3) break;
                    if (charCode >= 0 && charCode < 10) { 
                      if (!firstSymbol) char_Angle -= normal_battery_TextCircle_img_angle;
                      firstSymbol = false;
                      normal_battery_TextCircle[index].setProperty(hmUI.prop.ANGLE, char_Angle);
                      normal_battery_TextCircle[index].setProperty(hmUI.prop.POS_X, 233 - normal_battery_TextCircle_img_width / 2);
                      normal_battery_TextCircle[index].setProperty(hmUI.prop.SRC, normal_battery_TextCircle_ASCIIARRAY[charCode]);
                      normal_battery_TextCircle[index].setProperty(hmUI.prop.VISIBLE, true);
                      char_Angle -= normal_battery_TextCircle_img_angle + 1;
                      index++;
                    };  // end if digit
                  };  // end char of string
                  char_Angle -= normal_battery_TextCircle_unit_angle;
                  normal_battery_TextCircle_unit.setProperty(hmUI.prop.ANGLE, char_Angle);
                  normal_battery_TextCircle_unit.setProperty(hmUI.prop.VISIBLE, true);
                }  // end isFinite
                else {
                  normal_battery_TextCircle[0].setProperty(hmUI.prop.ANGLE, char_Angle);
                  normal_battery_TextCircle[0].setProperty(hmUI.prop.POS_X, 233 - normal_battery_TextCircle_error_img_width / 2);
                  normal_battery_TextCircle[0].setProperty(hmUI.prop.SRC, 'dot.png');
                  normal_battery_TextCircle[0].setProperty(hmUI.prop.VISIBLE, true);
                };  // end else isFinite

              };

              console.log('update text circle pai_total_PAI');
              let totalPAI = pai.totalpai;
              let normal_pai_total_circle_string = parseInt(totalPAI).toString();

              if (screenType != hmSetting.screen_type.AOD) {
                for (var i = 1; i < 3; i++) {  // hide all symbols
                  normal_pai_total_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                let char_Angle = 48;
                if (totalPAI != null && totalPAI != undefined && isFinite(totalPAI) && normal_pai_total_circle_string.length > 0 && normal_pai_total_circle_string.length < 6) {  // display data if it was possible to get it
                  let normal_pai_total_TextCircle_img_angle = 0;
                  let normal_pai_total_TextCircle_dot_img_angle = 0;
                  normal_pai_total_TextCircle_img_angle = toDegree(Math.atan2(normal_pai_total_TextCircle_img_width/2, 197));
                  // alignment = CENTER_H
                  let normal_pai_total_TextCircle_angleOffset = normal_pai_total_TextCircle_img_angle * (normal_pai_total_circle_string.length - 1);
                  normal_pai_total_TextCircle_angleOffset = normal_pai_total_TextCircle_angleOffset + 1 * (normal_pai_total_circle_string.length - 1) / 2;
                  normal_pai_total_TextCircle_angleOffset = -normal_pai_total_TextCircle_angleOffset;
                  char_Angle -= normal_pai_total_TextCircle_angleOffset;
                  // alignment end
                  
                  let firstSymbol = true;
                  let index = 0;
                  for (let char of normal_pai_total_circle_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 3) break;
                    if (charCode >= 0 && charCode < 10) { 
                      if (!firstSymbol) char_Angle -= normal_pai_total_TextCircle_img_angle;
                      firstSymbol = false;
                      normal_pai_total_TextCircle[index].setProperty(hmUI.prop.ANGLE, char_Angle);
                      normal_pai_total_TextCircle[index].setProperty(hmUI.prop.POS_X, 233 - normal_pai_total_TextCircle_img_width / 2);
                      normal_pai_total_TextCircle[index].setProperty(hmUI.prop.SRC, normal_pai_total_TextCircle_ASCIIARRAY[charCode]);
                      normal_pai_total_TextCircle[index].setProperty(hmUI.prop.VISIBLE, true);
                      char_Angle -= normal_pai_total_TextCircle_img_angle + 1;
                      index++;
                    };  // end if digit
                  };  // end char of string
                }  // end isFinite

              };

              console.log('update text circle heart_rate_HEART');
              let valueHeartRate = heart_rate.last;
              let normal_heart_rate_circle_string = parseInt(valueHeartRate).toString();

              if (screenType != hmSetting.screen_type.AOD) {
                for (var i = 1; i < 3; i++) {  // hide all symbols
                  normal_heart_rate_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                let char_Angle = 89;
                if (valueHeartRate != null && valueHeartRate != undefined && isFinite(valueHeartRate) && normal_heart_rate_circle_string.length > 0 && normal_heart_rate_circle_string.length < 6) {  // display data if it was possible to get it
                  let normal_heart_rate_TextCircle_img_angle = 0;
                  let normal_heart_rate_TextCircle_dot_img_angle = 0;
                  normal_heart_rate_TextCircle_img_angle = toDegree(Math.atan2(normal_heart_rate_TextCircle_img_width/2, 175));
                  // alignment = CENTER_H
                  let normal_heart_rate_TextCircle_angleOffset = normal_heart_rate_TextCircle_img_angle * (normal_heart_rate_circle_string.length - 1);
                  normal_heart_rate_TextCircle_angleOffset = normal_heart_rate_TextCircle_angleOffset + 1 * (normal_heart_rate_circle_string.length - 1) / 2;
                  char_Angle -= normal_heart_rate_TextCircle_angleOffset;
                  // alignment end
                  
                  let firstSymbol = true;
                  let index = 0;
                  for (let char of normal_heart_rate_circle_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 3) break;
                    if (charCode >= 0 && charCode < 10) { 
                      if (!firstSymbol) char_Angle += normal_heart_rate_TextCircle_img_angle;
                      firstSymbol = false;
                      normal_heart_rate_TextCircle[index].setProperty(hmUI.prop.ANGLE, char_Angle);
                      normal_heart_rate_TextCircle[index].setProperty(hmUI.prop.POS_X, 233 - normal_heart_rate_TextCircle_img_width / 2);
                      normal_heart_rate_TextCircle[index].setProperty(hmUI.prop.SRC, normal_heart_rate_TextCircle_ASCIIARRAY[charCode]);
                      normal_heart_rate_TextCircle[index].setProperty(hmUI.prop.VISIBLE, true);
                      char_Angle += normal_heart_rate_TextCircle_img_angle + 1;
                      index++;
                    };  // end if digit
                  };  // end char of string
                }  // end isFinite
                else {
                  normal_heart_rate_TextCircle[0].setProperty(hmUI.prop.ANGLE, char_Angle);
                  normal_heart_rate_TextCircle[0].setProperty(hmUI.prop.POS_X, 233 - normal_heart_rate_TextCircle_error_img_width / 2);
                  normal_heart_rate_TextCircle[0].setProperty(hmUI.prop.SRC, 'dot.png');
                  normal_heart_rate_TextCircle[0].setProperty(hmUI.prop.VISIBLE, true);
                };  // end else isFinite

              };

              console.log('update text circle calorie_CALORIE');
              let valueCalories = calorie.current;
              let normal_calorie_circle_string = parseInt(valueCalories).toString();

              if (screenType != hmSetting.screen_type.AOD) {
                for (var i = 1; i < 4; i++) {  // hide all symbols
                  normal_calorie_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                let char_Angle = 32;
                if (valueCalories != null && valueCalories != undefined && isFinite(valueCalories) && normal_calorie_circle_string.length > 0 && normal_calorie_circle_string.length < 6) {  // display data if it was possible to get it
                  let normal_calorie_TextCircle_img_angle = 0;
                  let normal_calorie_TextCircle_dot_img_angle = 0;
                  normal_calorie_TextCircle_img_angle = toDegree(Math.atan2(normal_calorie_TextCircle_img_width/2, 175));
                  // alignment = CENTER_H
                  let normal_calorie_TextCircle_angleOffset = normal_calorie_TextCircle_img_angle * (normal_calorie_circle_string.length - 1);
                  normal_calorie_TextCircle_angleOffset = normal_calorie_TextCircle_angleOffset + 1 * (normal_calorie_circle_string.length - 1) / 2;
                  char_Angle -= normal_calorie_TextCircle_angleOffset;
                  // alignment end
                  
                  let firstSymbol = true;
                  let index = 0;
                  for (let char of normal_calorie_circle_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 4) break;
                    if (charCode >= 0 && charCode < 10) { 
                      if (!firstSymbol) char_Angle += normal_calorie_TextCircle_img_angle;
                      firstSymbol = false;
                      normal_calorie_TextCircle[index].setProperty(hmUI.prop.ANGLE, char_Angle);
                      normal_calorie_TextCircle[index].setProperty(hmUI.prop.POS_X, 233 - normal_calorie_TextCircle_img_width / 2);
                      normal_calorie_TextCircle[index].setProperty(hmUI.prop.SRC, normal_calorie_TextCircle_ASCIIARRAY[charCode]);
                      normal_calorie_TextCircle[index].setProperty(hmUI.prop.VISIBLE, true);
                      char_Angle += normal_calorie_TextCircle_img_angle + 1;
                      index++;
                    };  // end if digit
                  };  // end char of string
                }  // end isFinite
                else {
                  normal_calorie_TextCircle[0].setProperty(hmUI.prop.ANGLE, char_Angle);
                  normal_calorie_TextCircle[0].setProperty(hmUI.prop.POS_X, 233 - normal_calorie_TextCircle_error_img_width / 2);
                  normal_calorie_TextCircle[0].setProperty(hmUI.prop.SRC, 'dot.png');
                  normal_calorie_TextCircle[0].setProperty(hmUI.prop.VISIBLE, true);
                };  // end else isFinite

              };

              console.log('update text circle DISTANCE');
              let distanceCurrent = distance.current;
              let normal_distance_circle_string = (distanceCurrent / 1000).toFixed(2);

              if (screenType != hmSetting.screen_type.AOD) {
                for (var i = 1; i < 5; i++) {  // hide all symbols
                  normal_distance_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                normal_distance_TextCircle_unit.setProperty(hmUI.prop.VISIBLE, false);
                let char_Angle = -27;
                if (distanceCurrent != null && distanceCurrent != undefined && isFinite(distanceCurrent) && normal_distance_circle_string.length > 0 && normal_distance_circle_string.length < 6) {  // display data if it was possible to get it
                  let normal_distance_TextCircle_img_angle = 0;
                  let normal_distance_TextCircle_dot_img_angle = 0;
                  let normal_distance_TextCircle_unit_angle = 0;
                  normal_distance_TextCircle_img_angle = toDegree(Math.atan2(normal_distance_TextCircle_img_width/2, 175));
                  normal_distance_TextCircle_dot_img_angle = toDegree(Math.atan2(normal_distance_TextCircle_dot_width/2, 175));
                  normal_distance_TextCircle_unit_angle = toDegree(Math.atan2(normal_distance_TextCircle_unit_width/2, 175));
                  // alignment = CENTER_H
                  let normal_distance_TextCircle_angleOffset = normal_distance_TextCircle_img_angle * (normal_distance_circle_string.length - 1);
                  normal_distance_TextCircle_angleOffset = normal_distance_TextCircle_angleOffset - normal_distance_TextCircle_img_angle + normal_distance_TextCircle_dot_img_angle;
                  normal_distance_TextCircle_angleOffset = normal_distance_TextCircle_angleOffset + 1 * (normal_distance_circle_string.length - 1) / 2;
                  normal_distance_TextCircle_angleOffset = normal_distance_TextCircle_angleOffset + (normal_distance_TextCircle_img_angle + normal_distance_TextCircle_unit_angle + 1) / 2;
                  char_Angle -= normal_distance_TextCircle_angleOffset;
                  // alignment end
                  
                  let firstSymbol = true;
                  let index = 0;
                  for (let char of normal_distance_circle_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 5) break;
                    if (charCode >= 0 && charCode < 10) { 
                      if (!firstSymbol) char_Angle += normal_distance_TextCircle_img_angle;
                      firstSymbol = false;
                      normal_distance_TextCircle[index].setProperty(hmUI.prop.ANGLE, char_Angle);
                      normal_distance_TextCircle[index].setProperty(hmUI.prop.POS_X, 233 - normal_distance_TextCircle_img_width / 2);
                      normal_distance_TextCircle[index].setProperty(hmUI.prop.SRC, normal_distance_TextCircle_ASCIIARRAY[charCode]);
                      normal_distance_TextCircle[index].setProperty(hmUI.prop.VISIBLE, true);
                      char_Angle += normal_distance_TextCircle_img_angle + 1;
                      index++;
                    }  // end if digit
                    else { 
                      if (!firstSymbol) char_Angle += normal_distance_TextCircle_dot_img_angle; 
                      firstSymbol = false;
                      normal_distance_TextCircle[index].setProperty(hmUI.prop.ANGLE, char_Angle);
                      normal_distance_TextCircle[index].setProperty(hmUI.prop.POS_X, 233 - normal_distance_TextCircle_dot_width / 2);
                      normal_distance_TextCircle[index].setProperty(hmUI.prop.SRC, 'pointer_5.png');
                      normal_distance_TextCircle[index].setProperty(hmUI.prop.VISIBLE, true);
                      char_Angle += normal_distance_TextCircle_dot_img_angle + 1;
                      index++;
                    };  // end if dot point 
                  };  // end char of string
                  char_Angle += normal_distance_TextCircle_unit_angle;
                  normal_distance_TextCircle_unit.setProperty(hmUI.prop.ANGLE, char_Angle);
                  normal_distance_TextCircle_unit.setProperty(hmUI.prop.VISIBLE, true);
                }  // end isFinite
                else {
                  normal_distance_TextCircle[0].setProperty(hmUI.prop.ANGLE, char_Angle);
                  normal_distance_TextCircle[0].setProperty(hmUI.prop.POS_X, 233 - normal_distance_TextCircle_error_img_width / 2);
                  normal_distance_TextCircle[0].setProperty(hmUI.prop.SRC, 'dot.png');
                  normal_distance_TextCircle[0].setProperty(hmUI.prop.VISIBLE, true);
                };  // end else isFinite

              };

              console.log('update text circle step_STEP');
              let valueStep = step.current;
              let normal_step_circle_string = parseInt(valueStep).toString();

              if (screenType != hmSetting.screen_type.AOD) {
                for (var i = 1; i < 5; i++) {  // hide all symbols
                  normal_step_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                let char_Angle = -89;
                if (valueStep != null && valueStep != undefined && isFinite(valueStep) && normal_step_circle_string.length > 0 && normal_step_circle_string.length < 6) {  // display data if it was possible to get it
                  let normal_step_TextCircle_img_angle = 0;
                  let normal_step_TextCircle_dot_img_angle = 0;
                  normal_step_TextCircle_img_angle = toDegree(Math.atan2(normal_step_TextCircle_img_width/2, 175));
                  // alignment = CENTER_H
                  let normal_step_TextCircle_angleOffset = normal_step_TextCircle_img_angle * (normal_step_circle_string.length - 1);
                  normal_step_TextCircle_angleOffset = normal_step_TextCircle_angleOffset + 1 * (normal_step_circle_string.length - 1) / 2;
                  char_Angle -= normal_step_TextCircle_angleOffset;
                  // alignment end
                  
                  let firstSymbol = true;
                  let index = 0;
                  for (let char of normal_step_circle_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 5) break;
                    if (charCode >= 0 && charCode < 10) { 
                      if (!firstSymbol) char_Angle += normal_step_TextCircle_img_angle;
                      firstSymbol = false;
                      normal_step_TextCircle[index].setProperty(hmUI.prop.ANGLE, char_Angle);
                      normal_step_TextCircle[index].setProperty(hmUI.prop.POS_X, 233 - normal_step_TextCircle_img_width / 2);
                      normal_step_TextCircle[index].setProperty(hmUI.prop.SRC, normal_step_TextCircle_ASCIIARRAY[charCode]);
                      normal_step_TextCircle[index].setProperty(hmUI.prop.VISIBLE, true);
                      char_Angle += normal_step_TextCircle_img_angle + 1;
                      index++;
                    };  // end if digit
                  };  // end char of string
                }  // end isFinite
                else {
                  normal_step_TextCircle[0].setProperty(hmUI.prop.ANGLE, char_Angle);
                  normal_step_TextCircle[0].setProperty(hmUI.prop.POS_X, 233 - normal_step_TextCircle_error_img_width / 2);
                  normal_step_TextCircle[0].setProperty(hmUI.prop.SRC, 'dot.png');
                  normal_step_TextCircle[0].setProperty(hmUI.prop.VISIBLE, true);
                };  // end else isFinite

              };

              console.log('update text circle year_TIME');
              let valueYear = timeSensor.year;
              let normal_year_circle_string = parseInt(valueYear).toString();

              if (screenType != hmSetting.screen_type.AOD) {
                for (var i = 1; i < 4; i++) {  // hide all symbols
                  normal_year_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                let char_Angle = 79;
                if (valueYear != null && valueYear != undefined && isFinite(valueYear) && normal_year_circle_string.length > 0 && normal_year_circle_string.length < 6) {  // display data if it was possible to get it
                  let normal_year_TextCircle_img_angle = 0;
                  let normal_year_TextCircle_dot_img_angle = 0;
                  normal_year_TextCircle_img_angle = toDegree(Math.atan2(normal_year_TextCircle_img_width/2, 213));
                  // alignment = CENTER_H
                  let normal_year_TextCircle_angleOffset = normal_year_TextCircle_img_angle * (normal_year_circle_string.length - 1);
                  char_Angle -= normal_year_TextCircle_angleOffset;
                  // alignment end
                  
                  let firstSymbol = true;
                  let index = 0;
                  for (let char of normal_year_circle_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 4) break;
                    if (charCode >= 0 && charCode < 10) { 
                      if (!firstSymbol) char_Angle += normal_year_TextCircle_img_angle;
                      firstSymbol = false;
                      normal_year_TextCircle[index].setProperty(hmUI.prop.ANGLE, char_Angle);
                      normal_year_TextCircle[index].setProperty(hmUI.prop.POS_X, 233 - normal_year_TextCircle_img_width / 2);
                      normal_year_TextCircle[index].setProperty(hmUI.prop.SRC, normal_year_TextCircle_ASCIIARRAY[charCode]);
                      normal_year_TextCircle[index].setProperty(hmUI.prop.VISIBLE, true);
                      char_Angle += normal_year_TextCircle_img_angle;
                      index++;
                    };  // end if digit
                  };  // end char of string
                }  // end isFinite
                else {
                  normal_year_TextCircle[0].setProperty(hmUI.prop.ANGLE, char_Angle);
                  normal_year_TextCircle[0].setProperty(hmUI.prop.POS_X, 233 - normal_year_TextCircle_error_img_width / 2);
                  normal_year_TextCircle[0].setProperty(hmUI.prop.SRC, 'dot.png');
                  normal_year_TextCircle[0].setProperty(hmUI.prop.VISIBLE, true);
                };  // end else isFinite

              };

              console.log('update text circle day_TIME');
              let valueDay = timeSensor.day;
              let normal_day_circle_string = parseInt(valueDay).toString();

              if (screenType != hmSetting.screen_type.AOD) {
                for (var i = 1; i < 2; i++) {  // hide all symbols
                  normal_day_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                normal_day_TextCircle_unit.setProperty(hmUI.prop.VISIBLE, false);
                let char_Angle = 45;
                if (valueDay != null && valueDay != undefined && isFinite(valueDay) && normal_day_circle_string.length > 0 && normal_day_circle_string.length < 6) {  // display data if it was possible to get it
                  let normal_day_TextCircle_img_angle = 0;
                  let normal_day_TextCircle_dot_img_angle = 0;
                  let normal_day_TextCircle_unit_angle = 0;
                  normal_day_TextCircle_img_angle = toDegree(Math.atan2(normal_day_TextCircle_img_width/2, 214));
                  normal_day_TextCircle_unit_angle = toDegree(Math.atan2(normal_day_TextCircle_unit_width/2, 214));
                  // alignment = CENTER_H
                  let normal_day_TextCircle_angleOffset = normal_day_TextCircle_img_angle * (normal_day_circle_string.length - 1);
                  normal_day_TextCircle_angleOffset = normal_day_TextCircle_angleOffset + (normal_day_TextCircle_img_angle + normal_day_TextCircle_unit_angle + 0) / 2;
                  char_Angle -= normal_day_TextCircle_angleOffset;
                  // alignment end
                  
                  let firstSymbol = true;
                  let index = 0;
                  for (let char of normal_day_circle_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 2) break;
                    if (charCode >= 0 && charCode < 10) { 
                      if (!firstSymbol) char_Angle += normal_day_TextCircle_img_angle;
                      firstSymbol = false;
                      normal_day_TextCircle[index].setProperty(hmUI.prop.ANGLE, char_Angle);
                      normal_day_TextCircle[index].setProperty(hmUI.prop.POS_X, 233 - normal_day_TextCircle_img_width / 2);
                      normal_day_TextCircle[index].setProperty(hmUI.prop.SRC, normal_day_TextCircle_ASCIIARRAY[charCode]);
                      normal_day_TextCircle[index].setProperty(hmUI.prop.VISIBLE, true);
                      char_Angle += normal_day_TextCircle_img_angle;
                      index++;
                    };  // end if digit
                  };  // end char of string
                  char_Angle += normal_day_TextCircle_unit_angle;
                  normal_day_TextCircle_unit.setProperty(hmUI.prop.ANGLE, char_Angle);
                  normal_day_TextCircle_unit.setProperty(hmUI.prop.VISIBLE, true);
                }  // end isFinite
                else {
                  normal_day_TextCircle[0].setProperty(hmUI.prop.ANGLE, char_Angle);
                  normal_day_TextCircle[0].setProperty(hmUI.prop.POS_X, 233 - normal_day_TextCircle_error_img_width / 2);
                  normal_day_TextCircle[0].setProperty(hmUI.prop.SRC, 'dot.png');
                  normal_day_TextCircle[0].setProperty(hmUI.prop.VISIBLE, true);
                };  // end else isFinite

              };

              console.log('update text circle battery_BATTERY');
              let idle_battery_circle_string = parseInt(valueBattery).toString();

              if (screenType == hmSetting.screen_type.AOD) {
                for (var i = 1; i < 3; i++) {  // hide all symbols
                  idle_battery_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                idle_battery_TextCircle_unit.setProperty(hmUI.prop.VISIBLE, false);
                let char_Angle = 312;
                if (valueBattery != null && valueBattery != undefined && isFinite(valueBattery) && idle_battery_circle_string.length > 0 && idle_battery_circle_string.length < 6) {  // display data if it was possible to get it
                  let idle_battery_TextCircle_img_angle = 0;
                  let idle_battery_TextCircle_dot_img_angle = 0;
                  let idle_battery_TextCircle_unit_angle = 0;
                  idle_battery_TextCircle_img_angle = toDegree(Math.atan2(idle_battery_TextCircle_img_width/2, 195));
                  idle_battery_TextCircle_unit_angle = toDegree(Math.atan2(idle_battery_TextCircle_unit_width/2, 195));
                  // alignment = CENTER_H
                  let idle_battery_TextCircle_angleOffset = idle_battery_TextCircle_img_angle * (idle_battery_circle_string.length - 1);
                  idle_battery_TextCircle_angleOffset = idle_battery_TextCircle_angleOffset + 1 * (idle_battery_circle_string.length - 1) / 2;
                  idle_battery_TextCircle_angleOffset = idle_battery_TextCircle_angleOffset + (idle_battery_TextCircle_img_angle + idle_battery_TextCircle_unit_angle + 1) / 2;
                  idle_battery_TextCircle_angleOffset = -idle_battery_TextCircle_angleOffset;
                  char_Angle -= idle_battery_TextCircle_angleOffset;
                  // alignment end
                  
                  let firstSymbol = true;
                  let index = 0;
                  for (let char of idle_battery_circle_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 3) break;
                    if (charCode >= 0 && charCode < 10) { 
                      if (!firstSymbol) char_Angle -= idle_battery_TextCircle_img_angle;
                      firstSymbol = false;
                      idle_battery_TextCircle[index].setProperty(hmUI.prop.ANGLE, char_Angle);
                      idle_battery_TextCircle[index].setProperty(hmUI.prop.POS_X, 233 - idle_battery_TextCircle_img_width / 2);
                      idle_battery_TextCircle[index].setProperty(hmUI.prop.SRC, idle_battery_TextCircle_ASCIIARRAY[charCode]);
                      idle_battery_TextCircle[index].setProperty(hmUI.prop.VISIBLE, true);
                      char_Angle -= idle_battery_TextCircle_img_angle + 1;
                      index++;
                    };  // end if digit
                  };  // end char of string
                  char_Angle -= idle_battery_TextCircle_unit_angle;
                  idle_battery_TextCircle_unit.setProperty(hmUI.prop.ANGLE, char_Angle);
                  idle_battery_TextCircle_unit.setProperty(hmUI.prop.VISIBLE, true);
                }  // end isFinite
                else {
                  idle_battery_TextCircle[0].setProperty(hmUI.prop.ANGLE, char_Angle);
                  idle_battery_TextCircle[0].setProperty(hmUI.prop.POS_X, 233 - idle_battery_TextCircle_error_img_width / 2);
                  idle_battery_TextCircle[0].setProperty(hmUI.prop.SRC, 'dot.png');
                  idle_battery_TextCircle[0].setProperty(hmUI.prop.VISIBLE, true);
                };  // end else isFinite

              };

              console.log('update text circle pai_total_PAI');
              let idle_pai_total_circle_string = parseInt(totalPAI).toString();

              if (screenType == hmSetting.screen_type.AOD) {
                for (var i = 1; i < 3; i++) {  // hide all symbols
                  idle_pai_total_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                let char_Angle = 48;
                if (totalPAI != null && totalPAI != undefined && isFinite(totalPAI) && idle_pai_total_circle_string.length > 0 && idle_pai_total_circle_string.length < 6) {  // display data if it was possible to get it
                  let idle_pai_total_TextCircle_img_angle = 0;
                  let idle_pai_total_TextCircle_dot_img_angle = 0;
                  idle_pai_total_TextCircle_img_angle = toDegree(Math.atan2(idle_pai_total_TextCircle_img_width/2, 197));
                  // alignment = CENTER_H
                  let idle_pai_total_TextCircle_angleOffset = idle_pai_total_TextCircle_img_angle * (idle_pai_total_circle_string.length - 1);
                  idle_pai_total_TextCircle_angleOffset = idle_pai_total_TextCircle_angleOffset + 1 * (idle_pai_total_circle_string.length - 1) / 2;
                  idle_pai_total_TextCircle_angleOffset = -idle_pai_total_TextCircle_angleOffset;
                  char_Angle -= idle_pai_total_TextCircle_angleOffset;
                  // alignment end
                  
                  let firstSymbol = true;
                  let index = 0;
                  for (let char of idle_pai_total_circle_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 3) break;
                    if (charCode >= 0 && charCode < 10) { 
                      if (!firstSymbol) char_Angle -= idle_pai_total_TextCircle_img_angle;
                      firstSymbol = false;
                      idle_pai_total_TextCircle[index].setProperty(hmUI.prop.ANGLE, char_Angle);
                      idle_pai_total_TextCircle[index].setProperty(hmUI.prop.POS_X, 233 - idle_pai_total_TextCircle_img_width / 2);
                      idle_pai_total_TextCircle[index].setProperty(hmUI.prop.SRC, idle_pai_total_TextCircle_ASCIIARRAY[charCode]);
                      idle_pai_total_TextCircle[index].setProperty(hmUI.prop.VISIBLE, true);
                      char_Angle -= idle_pai_total_TextCircle_img_angle + 1;
                      index++;
                    };  // end if digit
                  };  // end char of string
                }  // end isFinite

              };

              console.log('update text circle heart_rate_HEART');
              let idle_heart_rate_circle_string = parseInt(valueHeartRate).toString();

              if (screenType == hmSetting.screen_type.AOD) {
                for (var i = 1; i < 3; i++) {  // hide all symbols
                  idle_heart_rate_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                let char_Angle = 89;
                if (valueHeartRate != null && valueHeartRate != undefined && isFinite(valueHeartRate) && idle_heart_rate_circle_string.length > 0 && idle_heart_rate_circle_string.length < 6) {  // display data if it was possible to get it
                  let idle_heart_rate_TextCircle_img_angle = 0;
                  let idle_heart_rate_TextCircle_dot_img_angle = 0;
                  idle_heart_rate_TextCircle_img_angle = toDegree(Math.atan2(idle_heart_rate_TextCircle_img_width/2, 175));
                  // alignment = CENTER_H
                  let idle_heart_rate_TextCircle_angleOffset = idle_heart_rate_TextCircle_img_angle * (idle_heart_rate_circle_string.length - 1);
                  idle_heart_rate_TextCircle_angleOffset = idle_heart_rate_TextCircle_angleOffset + 1 * (idle_heart_rate_circle_string.length - 1) / 2;
                  char_Angle -= idle_heart_rate_TextCircle_angleOffset;
                  // alignment end
                  
                  let firstSymbol = true;
                  let index = 0;
                  for (let char of idle_heart_rate_circle_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 3) break;
                    if (charCode >= 0 && charCode < 10) { 
                      if (!firstSymbol) char_Angle += idle_heart_rate_TextCircle_img_angle;
                      firstSymbol = false;
                      idle_heart_rate_TextCircle[index].setProperty(hmUI.prop.ANGLE, char_Angle);
                      idle_heart_rate_TextCircle[index].setProperty(hmUI.prop.POS_X, 233 - idle_heart_rate_TextCircle_img_width / 2);
                      idle_heart_rate_TextCircle[index].setProperty(hmUI.prop.SRC, idle_heart_rate_TextCircle_ASCIIARRAY[charCode]);
                      idle_heart_rate_TextCircle[index].setProperty(hmUI.prop.VISIBLE, true);
                      char_Angle += idle_heart_rate_TextCircle_img_angle + 1;
                      index++;
                    };  // end if digit
                  };  // end char of string
                }  // end isFinite
                else {
                  idle_heart_rate_TextCircle[0].setProperty(hmUI.prop.ANGLE, char_Angle);
                  idle_heart_rate_TextCircle[0].setProperty(hmUI.prop.POS_X, 233 - idle_heart_rate_TextCircle_error_img_width / 2);
                  idle_heart_rate_TextCircle[0].setProperty(hmUI.prop.SRC, 'dot.png');
                  idle_heart_rate_TextCircle[0].setProperty(hmUI.prop.VISIBLE, true);
                };  // end else isFinite

              };

              console.log('update text circle calorie_CALORIE');
              let idle_calorie_circle_string = parseInt(valueCalories).toString();

              if (screenType == hmSetting.screen_type.AOD) {
                for (var i = 1; i < 4; i++) {  // hide all symbols
                  idle_calorie_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                let char_Angle = 32;
                if (valueCalories != null && valueCalories != undefined && isFinite(valueCalories) && idle_calorie_circle_string.length > 0 && idle_calorie_circle_string.length < 6) {  // display data if it was possible to get it
                  let idle_calorie_TextCircle_img_angle = 0;
                  let idle_calorie_TextCircle_dot_img_angle = 0;
                  idle_calorie_TextCircle_img_angle = toDegree(Math.atan2(idle_calorie_TextCircle_img_width/2, 175));
                  // alignment = CENTER_H
                  let idle_calorie_TextCircle_angleOffset = idle_calorie_TextCircle_img_angle * (idle_calorie_circle_string.length - 1);
                  idle_calorie_TextCircle_angleOffset = idle_calorie_TextCircle_angleOffset + 1 * (idle_calorie_circle_string.length - 1) / 2;
                  char_Angle -= idle_calorie_TextCircle_angleOffset;
                  // alignment end
                  
                  let firstSymbol = true;
                  let index = 0;
                  for (let char of idle_calorie_circle_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 4) break;
                    if (charCode >= 0 && charCode < 10) { 
                      if (!firstSymbol) char_Angle += idle_calorie_TextCircle_img_angle;
                      firstSymbol = false;
                      idle_calorie_TextCircle[index].setProperty(hmUI.prop.ANGLE, char_Angle);
                      idle_calorie_TextCircle[index].setProperty(hmUI.prop.POS_X, 233 - idle_calorie_TextCircle_img_width / 2);
                      idle_calorie_TextCircle[index].setProperty(hmUI.prop.SRC, idle_calorie_TextCircle_ASCIIARRAY[charCode]);
                      idle_calorie_TextCircle[index].setProperty(hmUI.prop.VISIBLE, true);
                      char_Angle += idle_calorie_TextCircle_img_angle + 1;
                      index++;
                    };  // end if digit
                  };  // end char of string
                }  // end isFinite
                else {
                  idle_calorie_TextCircle[0].setProperty(hmUI.prop.ANGLE, char_Angle);
                  idle_calorie_TextCircle[0].setProperty(hmUI.prop.POS_X, 233 - idle_calorie_TextCircle_error_img_width / 2);
                  idle_calorie_TextCircle[0].setProperty(hmUI.prop.SRC, 'dot.png');
                  idle_calorie_TextCircle[0].setProperty(hmUI.prop.VISIBLE, true);
                };  // end else isFinite

              };

              console.log('update text circle DISTANCE');
              let idle_distance_circle_string = (distanceCurrent / 1000).toFixed(2);

              if (screenType == hmSetting.screen_type.AOD) {
                for (var i = 1; i < 5; i++) {  // hide all symbols
                  idle_distance_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                idle_distance_TextCircle_unit.setProperty(hmUI.prop.VISIBLE, false);
                let char_Angle = -27;
                if (distanceCurrent != null && distanceCurrent != undefined && isFinite(distanceCurrent) && idle_distance_circle_string.length > 0 && idle_distance_circle_string.length < 6) {  // display data if it was possible to get it
                  let idle_distance_TextCircle_img_angle = 0;
                  let idle_distance_TextCircle_dot_img_angle = 0;
                  let idle_distance_TextCircle_unit_angle = 0;
                  idle_distance_TextCircle_img_angle = toDegree(Math.atan2(idle_distance_TextCircle_img_width/2, 175));
                  idle_distance_TextCircle_dot_img_angle = toDegree(Math.atan2(idle_distance_TextCircle_dot_width/2, 175));
                  idle_distance_TextCircle_unit_angle = toDegree(Math.atan2(idle_distance_TextCircle_unit_width/2, 175));
                  // alignment = CENTER_H
                  let idle_distance_TextCircle_angleOffset = idle_distance_TextCircle_img_angle * (idle_distance_circle_string.length - 1);
                  idle_distance_TextCircle_angleOffset = idle_distance_TextCircle_angleOffset - idle_distance_TextCircle_img_angle + idle_distance_TextCircle_dot_img_angle;
                  idle_distance_TextCircle_angleOffset = idle_distance_TextCircle_angleOffset + 1 * (idle_distance_circle_string.length - 1) / 2;
                  idle_distance_TextCircle_angleOffset = idle_distance_TextCircle_angleOffset + (idle_distance_TextCircle_img_angle + idle_distance_TextCircle_unit_angle + 1) / 2;
                  char_Angle -= idle_distance_TextCircle_angleOffset;
                  // alignment end
                  
                  let firstSymbol = true;
                  let index = 0;
                  for (let char of idle_distance_circle_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 5) break;
                    if (charCode >= 0 && charCode < 10) { 
                      if (!firstSymbol) char_Angle += idle_distance_TextCircle_img_angle;
                      firstSymbol = false;
                      idle_distance_TextCircle[index].setProperty(hmUI.prop.ANGLE, char_Angle);
                      idle_distance_TextCircle[index].setProperty(hmUI.prop.POS_X, 233 - idle_distance_TextCircle_img_width / 2);
                      idle_distance_TextCircle[index].setProperty(hmUI.prop.SRC, idle_distance_TextCircle_ASCIIARRAY[charCode]);
                      idle_distance_TextCircle[index].setProperty(hmUI.prop.VISIBLE, true);
                      char_Angle += idle_distance_TextCircle_img_angle + 1;
                      index++;
                    }  // end if digit
                    else { 
                      if (!firstSymbol) char_Angle += idle_distance_TextCircle_dot_img_angle; 
                      firstSymbol = false;
                      idle_distance_TextCircle[index].setProperty(hmUI.prop.ANGLE, char_Angle);
                      idle_distance_TextCircle[index].setProperty(hmUI.prop.POS_X, 233 - idle_distance_TextCircle_dot_width / 2);
                      idle_distance_TextCircle[index].setProperty(hmUI.prop.SRC, 'pointer_5.png');
                      idle_distance_TextCircle[index].setProperty(hmUI.prop.VISIBLE, true);
                      char_Angle += idle_distance_TextCircle_dot_img_angle + 1;
                      index++;
                    };  // end if dot point 
                  };  // end char of string
                  char_Angle += idle_distance_TextCircle_unit_angle;
                  idle_distance_TextCircle_unit.setProperty(hmUI.prop.ANGLE, char_Angle);
                  idle_distance_TextCircle_unit.setProperty(hmUI.prop.VISIBLE, true);
                }  // end isFinite
                else {
                  idle_distance_TextCircle[0].setProperty(hmUI.prop.ANGLE, char_Angle);
                  idle_distance_TextCircle[0].setProperty(hmUI.prop.POS_X, 233 - idle_distance_TextCircle_error_img_width / 2);
                  idle_distance_TextCircle[0].setProperty(hmUI.prop.SRC, 'dot.png');
                  idle_distance_TextCircle[0].setProperty(hmUI.prop.VISIBLE, true);
                };  // end else isFinite

              };

              console.log('update text circle step_STEP');
              let idle_step_circle_string = parseInt(valueStep).toString();

              if (screenType == hmSetting.screen_type.AOD) {
                for (var i = 1; i < 5; i++) {  // hide all symbols
                  idle_step_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                let char_Angle = -89;
                if (valueStep != null && valueStep != undefined && isFinite(valueStep) && idle_step_circle_string.length > 0 && idle_step_circle_string.length < 6) {  // display data if it was possible to get it
                  let idle_step_TextCircle_img_angle = 0;
                  let idle_step_TextCircle_dot_img_angle = 0;
                  idle_step_TextCircle_img_angle = toDegree(Math.atan2(idle_step_TextCircle_img_width/2, 175));
                  // alignment = CENTER_H
                  let idle_step_TextCircle_angleOffset = idle_step_TextCircle_img_angle * (idle_step_circle_string.length - 1);
                  idle_step_TextCircle_angleOffset = idle_step_TextCircle_angleOffset + 1 * (idle_step_circle_string.length - 1) / 2;
                  char_Angle -= idle_step_TextCircle_angleOffset;
                  // alignment end
                  
                  let firstSymbol = true;
                  let index = 0;
                  for (let char of idle_step_circle_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 5) break;
                    if (charCode >= 0 && charCode < 10) { 
                      if (!firstSymbol) char_Angle += idle_step_TextCircle_img_angle;
                      firstSymbol = false;
                      idle_step_TextCircle[index].setProperty(hmUI.prop.ANGLE, char_Angle);
                      idle_step_TextCircle[index].setProperty(hmUI.prop.POS_X, 233 - idle_step_TextCircle_img_width / 2);
                      idle_step_TextCircle[index].setProperty(hmUI.prop.SRC, idle_step_TextCircle_ASCIIARRAY[charCode]);
                      idle_step_TextCircle[index].setProperty(hmUI.prop.VISIBLE, true);
                      char_Angle += idle_step_TextCircle_img_angle + 1;
                      index++;
                    };  // end if digit
                  };  // end char of string
                }  // end isFinite
                else {
                  idle_step_TextCircle[0].setProperty(hmUI.prop.ANGLE, char_Angle);
                  idle_step_TextCircle[0].setProperty(hmUI.prop.POS_X, 233 - idle_step_TextCircle_error_img_width / 2);
                  idle_step_TextCircle[0].setProperty(hmUI.prop.SRC, 'dot.png');
                  idle_step_TextCircle[0].setProperty(hmUI.prop.VISIBLE, true);
                };  // end else isFinite

              };

              console.log('update text circle year_TIME');
              let idle_year_circle_string = parseInt(valueYear).toString();

              if (screenType == hmSetting.screen_type.AOD) {
                for (var i = 1; i < 4; i++) {  // hide all symbols
                  idle_year_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                let char_Angle = 79;
                if (valueYear != null && valueYear != undefined && isFinite(valueYear) && idle_year_circle_string.length > 0 && idle_year_circle_string.length < 6) {  // display data if it was possible to get it
                  let idle_year_TextCircle_img_angle = 0;
                  let idle_year_TextCircle_dot_img_angle = 0;
                  idle_year_TextCircle_img_angle = toDegree(Math.atan2(idle_year_TextCircle_img_width/2, 213));
                  // alignment = CENTER_H
                  let idle_year_TextCircle_angleOffset = idle_year_TextCircle_img_angle * (idle_year_circle_string.length - 1);
                  char_Angle -= idle_year_TextCircle_angleOffset;
                  // alignment end
                  
                  let firstSymbol = true;
                  let index = 0;
                  for (let char of idle_year_circle_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 4) break;
                    if (charCode >= 0 && charCode < 10) { 
                      if (!firstSymbol) char_Angle += idle_year_TextCircle_img_angle;
                      firstSymbol = false;
                      idle_year_TextCircle[index].setProperty(hmUI.prop.ANGLE, char_Angle);
                      idle_year_TextCircle[index].setProperty(hmUI.prop.POS_X, 233 - idle_year_TextCircle_img_width / 2);
                      idle_year_TextCircle[index].setProperty(hmUI.prop.SRC, idle_year_TextCircle_ASCIIARRAY[charCode]);
                      idle_year_TextCircle[index].setProperty(hmUI.prop.VISIBLE, true);
                      char_Angle += idle_year_TextCircle_img_angle;
                      index++;
                    };  // end if digit
                  };  // end char of string
                }  // end isFinite
                else {
                  idle_year_TextCircle[0].setProperty(hmUI.prop.ANGLE, char_Angle);
                  idle_year_TextCircle[0].setProperty(hmUI.prop.POS_X, 233 - idle_year_TextCircle_error_img_width / 2);
                  idle_year_TextCircle[0].setProperty(hmUI.prop.SRC, 'dot.png');
                  idle_year_TextCircle[0].setProperty(hmUI.prop.VISIBLE, true);
                };  // end else isFinite

              };

              console.log('update text circle day_TIME');
              let idle_day_circle_string = parseInt(valueDay).toString();

              if (screenType == hmSetting.screen_type.AOD) {
                for (var i = 1; i < 2; i++) {  // hide all symbols
                  idle_day_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                idle_day_TextCircle_unit.setProperty(hmUI.prop.VISIBLE, false);
                let char_Angle = 45;
                if (valueDay != null && valueDay != undefined && isFinite(valueDay) && idle_day_circle_string.length > 0 && idle_day_circle_string.length < 6) {  // display data if it was possible to get it
                  let idle_day_TextCircle_img_angle = 0;
                  let idle_day_TextCircle_dot_img_angle = 0;
                  let idle_day_TextCircle_unit_angle = 0;
                  idle_day_TextCircle_img_angle = toDegree(Math.atan2(idle_day_TextCircle_img_width/2, 214));
                  idle_day_TextCircle_unit_angle = toDegree(Math.atan2(idle_day_TextCircle_unit_width/2, 214));
                  // alignment = CENTER_H
                  let idle_day_TextCircle_angleOffset = idle_day_TextCircle_img_angle * (idle_day_circle_string.length - 1);
                  idle_day_TextCircle_angleOffset = idle_day_TextCircle_angleOffset + (idle_day_TextCircle_img_angle + idle_day_TextCircle_unit_angle + 0) / 2;
                  char_Angle -= idle_day_TextCircle_angleOffset;
                  // alignment end
                  
                  let firstSymbol = true;
                  let index = 0;
                  for (let char of idle_day_circle_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 2) break;
                    if (charCode >= 0 && charCode < 10) { 
                      if (!firstSymbol) char_Angle += idle_day_TextCircle_img_angle;
                      firstSymbol = false;
                      idle_day_TextCircle[index].setProperty(hmUI.prop.ANGLE, char_Angle);
                      idle_day_TextCircle[index].setProperty(hmUI.prop.POS_X, 233 - idle_day_TextCircle_img_width / 2);
                      idle_day_TextCircle[index].setProperty(hmUI.prop.SRC, idle_day_TextCircle_ASCIIARRAY[charCode]);
                      idle_day_TextCircle[index].setProperty(hmUI.prop.VISIBLE, true);
                      char_Angle += idle_day_TextCircle_img_angle;
                      index++;
                    };  // end if digit
                  };  // end char of string
                  char_Angle += idle_day_TextCircle_unit_angle;
                  idle_day_TextCircle_unit.setProperty(hmUI.prop.ANGLE, char_Angle);
                  idle_day_TextCircle_unit.setProperty(hmUI.prop.VISIBLE, true);
                }  // end isFinite
                else {
                  idle_day_TextCircle[0].setProperty(hmUI.prop.ANGLE, char_Angle);
                  idle_day_TextCircle[0].setProperty(hmUI.prop.POS_X, 233 - idle_day_TextCircle_error_img_width / 2);
                  idle_day_TextCircle[0].setProperty(hmUI.prop.SRC, 'dot.png');
                  idle_day_TextCircle[0].setProperty(hmUI.prop.VISIBLE, true);
                };  // end else isFinite

              };

            };

            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                console.log('resume_call()');
                text_update();

                let nawAnimationTime = now.utc;;
                
                let delay_anim_rotate_1 = 0;
                let repeat_anim_rotate_1 = 200;
                delay_anim_rotate_1 = repeat_anim_rotate_1 - (nawAnimationTime - normal_rotate_animation_lastTime_1);
                if(delay_anim_rotate_1 < 0) delay_anim_rotate_1 = 0; 
                if((nawAnimationTime - normal_rotate_animation_lastTime_1) > repeat_anim_rotate_1*2) {
                  normal_rotate_animation_count_1 = 0;
                  timer_anim_rotate_1_mirror = false;
                };

                if (!timer_anim_rotate_1) {
                  timer_anim_rotate_1 = timer.createTimer(delay_anim_rotate_1, repeat_anim_rotate_1, (function (option) {
                    if(timer_anim_rotate_1_mirror) {
                      anim_rotate_1_mirror()
                    } else {
                      anim_rotate_1_complete_call()
                    };
                    timer_anim_rotate_1_mirror = !timer_anim_rotate_1_mirror;
                  })); // end timer create
                };
                if (screenType == hmSetting.screen_type.WATCHFACE) {
                  if (!normal_timerTextUpdate) {
                    normal_timerTextUpdate = timer.createTimer(0, 1000, (function (option) {
                      text_update();
                    }));  // end timer 
                  };  // end timer check
                };  // end screenType

                if (screenType == hmSetting.screen_type.AOD) {
                  if (!idle_timerTextUpdate) {
                    idle_timerTextUpdate = timer.createTimer(0, 1000, (function (option) {
                      text_update();
                    }));  // end timer 
                  };  // end timer check
                };  // end screenType

                checkConnection();
                stopVibro();

              }),
              pause_call: (function () {
                console.log('pause_call()');
                stop_anim_rotate_1();
                if (normal_timerTextUpdate) {
                  timer.stopTimer(normal_timerTextUpdate);
                  normal_timerTextUpdate = undefined;
                }
                if (idle_timerTextUpdate) {
                  timer.stopTimer(idle_timerTextUpdate);
                  idle_timerTextUpdate = undefined;
                }
                stopVibro();

              }),
            });

                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}