/*
** Facemaker bundle tool v0.0.3
* *huamiOS watchface js version v2.0.1
* *Copyright © Huami. All Rights Reserved
*/


try {
	(() => {
		var __$$app$$__ = __$$hmAppManager$$__.currentApp;
		var __$$module$$__ = __$$app$$__.current;

		//drink is a name,can modify
		var h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__), 'drink');

		'use strict';

		//dynamic modify start
		let normal_img0 = '';
		let normal_img1 = '';
		let normal_img2 = '';
		let normal_img3 = '';
		let normal_img4 = '';
		let normal_img5 = '';
		let normal_img6 = '';
		let normal_img7 = '';
		let normal_img8 = '';
		let normal_img9 = '';
		let normal_img10 = '';
		let normal_img11 = '';
		let normal_img12 = '';
		let normal_date_imagecombo14 = '';
		let chronoInterval;
		let chronoIsRunning = false;
		let chronoStart = 0;
		let chronoStoppedAt = 0;
		let normal_chrono_seconds_rotary = '';
		let normal_chrono_seconds_rotary_start_angle = 0;
		let normal_chrono_seconds_rotary_end_angle = 360;
		let normal_chrono_minutes_rotary = '';
		let normal_chrono_minutes_rotary_start_angle = 0;
		let normal_chrono_minutes_rotary_end_angle = 720;
		let normal_chrono_start_stop = '';
		let normal_chrono_start_stop_array = ['0026.png','0026.png'];
		let normal_chrono_reset = '';
		let normal_chrono_reset_array = ['0026.png','0027.png'];
		let normal_battery_rotary17 = '';
		let normal_hour_rotary19 = '';
		let normal_minute_rotary20 = '';
		let normal_second_rotary21 = '';
		let idle_img24 = '';
		let idle_img25 = '';
		let idle_hour_rotary27 = '';
		let idle_minute_rotary28 = '';
		let idle_img29 = '';
		//dynamic modify end

		//not required
		const logger = DeviceRuntimeCore.HmLogger.getLogger("yeguang");

		__$$module$$__.module = DeviceRuntimeCore.WatchFace({
			init_view() {

				const timeSensor = hmSensor.createSensor(hmSensor.id.TIME);
				const vibrateSensor = hmSensor.createSensor(hmSensor.id.VIBRATE);
				let screenType = hmSetting.getScreenType();

				normal_img0 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 0,
					y: 0,
					w: 466,
					h: 466,
					src: '0002.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img1 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 217,
					y: 360,
					w: 33,
					h: 18,
					src: '0003.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img2 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 178,
					y: 276,
					w: 109,
					h: 109,
					src: '0004.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img3 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 86,
					y: 187,
					w: 100,
					h: 100,
					src: '0005.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img4 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 75,
					y: 176,
					w: 120,
					h: 120,
					src: '0006.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img5 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 74,
					y: 173,
					w: 127,
					h: 127,
					src: '0007.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img6 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 87,
					y: 187,
					w: 97,
					h: 97,
					src: '0008.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img7 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 85,
					y: 186,
					w: 100,
					h: 100,
					src: '0009.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img8 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 162,
					y: 69,
					w: 142,
					h: 142,
					src: '0010.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img9 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 137,
					y: 44,
					w: 191,
					h: 191,
					src: '0011.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img10 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 23,
					y: 28,
					w: 416,
					h: 415,
					src: '0012.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img11 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 210,
					y: 117,
					w: 46,
					h: 46,
					src: '0013.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img12 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 210,
					y: 308,
					w: 46,
					h: 46,
					src: '0013.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_date_imagecombo14 = hmUI.createWidget(hmUI.widget.IMG_DATE, {
					day_startX: 350,
					day_startY: 223,
					day_sc_array: ["0014.png","0015.png","0016.png","0017.png","0018.png","0019.png","0020.png","0021.png","0022.png","0023.png"],
					day_tc_array: ["0014.png","0015.png","0016.png","0017.png","0018.png","0019.png","0020.png","0021.png","0022.png","0023.png"],
					day_en_array: ["0014.png","0015.png","0016.png","0017.png","0018.png","0019.png","0020.png","0021.png","0022.png","0023.png"],
					day_zero: true,
					day_space: 0,
					day_align: hmUI.align.LEFT,
					day_is_character: false,
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_chrono_seconds_rotary = hmUI.createWidget(hmUI.widget.IMG, {
					x: 0,
					y: 0,
					w: 466,
					h: 466,
					center_x: 136,
					center_y: 236,
					pos_x: 126,
					pos_y: 186,
					src: '0024.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_chrono_minutes_rotary = hmUI.createWidget(hmUI.widget.IMG, {
					x: 0,
					y: 0,
					w: 466,
					h: 466,
					center_x: 233,
					center_y: 140,
					pos_x: 221,
					pos_y: 80,
					src: '0025.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_chrono_start_stop = hmUI.createWidget(hmUI.widget.IMG, {
					x: 83,
					y: 186,
					w: 100,
					h: 100,
					src: '0026.png',
					show_level: hmUI.show_level.ONLY_NORMAL
				});

				normal_chrono_start_stop.addEventListener(hmUI.event.CLICK_DOWN, (info) => {
					if (!chronoIsRunning) {
						chronoInterval = setInterval(updateChrono, 1);
						chronoIsRunning = true;
						chronoStart = chronoStart == 0 ? timeSensor.utc : chronoStart + (timeSensor.utc-chronoStoppedAt);
					} else {
						clearInterval(chronoInterval);
						chronoIsRunning = false;
						chronoStoppedAt = timeSensor.utc;
					}
					normal_chrono_start_stop.setProperty(hmUI.prop.MORE, {
						src: normal_chrono_start_stop_array[Number(chronoIsRunning)]
					})
					normal_chrono_reset.setProperty(hmUI.prop.MORE, {
						src: normal_chrono_reset_array[Number(chronoIsRunning)],
						enable: !chronoIsRunning
					})
					vibrateSensor.stop();
					vibrateSensor.scene = 25;
					vibrateSensor.start();
				});

				normal_chrono_reset = hmUI.createWidget(hmUI.widget.IMG, {
					x: 290,
					y: 183,
					w: 100,
					h: 100,
					src: '0027.png',
					show_level: hmUI.show_level.ONLY_NORMAL
				});

				normal_chrono_reset.addEventListener(hmUI.event.CLICK_DOWN, (info) => {
					chronoStart = 0;
					if (typeof normal_chrono_hours != 'undefined') {
						for (let i=0; i < normal_chrono_hours.length; i++) {
							normal_chrono_hours[i].setProperty(hmUI.prop.MORE, {
								src: normal_chrono_hours_array[0]
							})
						}
					}
					if (typeof normal_chrono_minutes != 'undefined') {
						for (let i=0; i < normal_chrono_minutes.length; i++) {
							normal_chrono_minutes[i].setProperty(hmUI.prop.MORE, {
								src: normal_chrono_minutes_array[0]
							})
						}
					}
					if (typeof normal_chrono_seconds != 'undefined') {
						for (let i=0; i < normal_chrono_seconds.length; i++) {
							normal_chrono_seconds[i].setProperty(hmUI.prop.MORE, {
								src: normal_chrono_seconds_array[0]
							})
						}
					}
					if (typeof normal_chrono_milliseconds != 'undefined') {
						for (let i=0; i < normal_chrono_milliseconds.length; i++) {
							normal_chrono_milliseconds[i].setProperty(hmUI.prop.MORE, {
								src: normal_chrono_milliseconds_array[0]
							})
						}
					}
					if (typeof normal_chrono_hours_rotary != 'undefined') {
						normal_chrono_hours_rotary.setProperty(hmUI.prop.MORE, {
							angle: normal_chrono_hours_rotary_start_angle
						})
					}

					if (typeof normal_chrono_minutes_rotary != 'undefined') {
						normal_chrono_minutes_rotary.setProperty(hmUI.prop.MORE, {
							angle: normal_chrono_minutes_rotary_start_angle
						})
					}

					if (typeof normal_chrono_seconds_rotary != 'undefined') {
						normal_chrono_seconds_rotary.setProperty(hmUI.prop.MORE, {
							angle: normal_chrono_seconds_rotary_start_angle
						})
					}

					vibrateSensor.stop();
					vibrateSensor.scene = 25;
					vibrateSensor.start();
				});

				normal_battery_rotary17 = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
					src: '0028.png',
					center_x: 233,
					center_y: 331,
					x: 12,
					y: 59,
					start_angle: -150,
					end_angle: 150,
					type: hmUI.data_type.BATTERY,
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_hour_rotary19 = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
					hour_path: '0029.png',
					hour_centerX: 233,
					hour_centerY: 233,
					hour_posX: 19,
					hour_posY: 133,
					hour_start_angle: 0,
					hour_end_angle: 360,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_minute_rotary20 = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
					minute_path: '0030.png',
					minute_centerX: 233,
					minute_centerY: 233,
					minute_posX: 14,
					minute_posY: 206,
					minute_start_angle: 0,
					minute_end_angle: 360,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_second_rotary21 = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
					second_path: '0031.png',
					second_centerX: 233,
					second_centerY: 233,
					second_posX: 11,
					second_posY: 215,
					second_start_angle: 0,
					second_end_angle: 360,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				idle_img24 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 0,
					y: 0,
					w: 466,
					h: 466,
					src: '0032.png',
					enable: false,
					show_level: hmUI.show_level.ONAL_AOD,
				});

				idle_img25 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 211,
					y: 100,
					w: 45,
					h: 47,
					src: '0033.png',
					enable: false,
					show_level: hmUI.show_level.ONAL_AOD,
				});

				idle_hour_rotary27 = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
					hour_path: '0034.png',
					hour_centerX: 233,
					hour_centerY: 233,
					hour_posX: 19,
					hour_posY: 133,
					hour_start_angle: 0,
					hour_end_angle: 360,
					show_level: hmUI.show_level.ONAL_AOD,
				});

				idle_minute_rotary28 = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
					minute_path: '0035.png',
					minute_centerX: 233,
					minute_centerY: 233,
					minute_posX: 14,
					minute_posY: 206,
					minute_start_angle: 0,
					minute_end_angle: 360,
					show_level: hmUI.show_level.ONAL_AOD,
				});

				idle_img29 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 220,
					y: 218,
					w: 26,
					h: 29,
					src: '0036.png',
					enable: false,
					show_level: hmUI.show_level.ONAL_AOD,
				});

				function updateChrono() {
					let curTime = timeSensor.utc;
					let curDiff = curTime-chronoStart;
					let curMilli = curDiff.toString().substr(curDiff.toString().length - 3).padStart(3, '0');
					let curSeconds = Math.floor((curDiff)/1000).toString().padStart(2, '0');
					let curMinutes = Math.floor(curSeconds/60).toString().padStart(2, '0');
					let curHours = Math.floor(curMinutes/60).toString().padStart(2, '0');
					if (typeof normal_chrono_hours != 'undefined' && normal_chrono_hours.length > 0) {
						for (let i=0; i < normal_chrono_hours.length; i++) {
							normal_chrono_hours[i].setProperty(hmUI.prop.MORE, {
								src: normal_chrono_hours_array[curHours.charAt(i)]
							})
						}
					}

					if (typeof normal_chrono_minutes != 'undefined' && normal_chrono_minutes.length > 0) {
						for (let i=0; i < normal_chrono_minutes.length; i++) {
							normal_chrono_minutes[i].setProperty(hmUI.prop.MORE, {
								src: normal_chrono_minutes_array[curMinutes.charAt(i)]
							})
						}
					}

					if (typeof normal_chrono_seconds != 'undefined' && normal_chrono_seconds.length > 0) {
						for (let i=0; i < normal_chrono_seconds.length; i++) {
							normal_chrono_seconds[i].setProperty(hmUI.prop.MORE, {
								src: normal_chrono_seconds_array[curSeconds.charAt(i)]
							})
						}
					}

					if (typeof normal_chrono_milliseconds != 'undefined' && normal_chrono_milliseconds.length > 0) {
						for (let i=0; i < normal_chrono_milliseconds.length; i++) {
							normal_chrono_milliseconds[i].setProperty(hmUI.prop.MORE, {
								src: normal_chrono_milliseconds_array[curMilli.charAt(i)]
							})
						}
					}

					if (typeof normal_chrono_hours_rotary != 'undefined') {
						let hsa = normal_chrono_hours_rotary_start_angle;
						let hea = normal_chrono_hours_rotary_end_angle;
						let hcw = hea > hsa;
						let hd = hcw ? hea - hsa : hsa - hea;
						let hfac = hd / 360;
						normal_chrono_hours_rotary.setProperty(hmUI.prop.MORE, {
							angle: (hcw ? (hsa + (parseInt(curHours) * (6 * hfac))) : (hsa - (parseInt(curHours) * (6 * hfac))))
						})
					}

					if (typeof normal_chrono_minutes_rotary != 'undefined') {
						let msa = normal_chrono_minutes_rotary_start_angle;
						let mea = normal_chrono_minutes_rotary_end_angle;
						let mcw = mea > msa;
						let md = mcw ? mea - msa : msa - mea;
						let mfac = md / 360;
						normal_chrono_minutes_rotary.setProperty(hmUI.prop.MORE, {
							angle: (mcw ? (msa + (parseInt(curMinutes) * (6 * mfac))) : (msa - (parseInt(curMinutes) * (6 * mfac))))
						})
					}

					if (typeof normal_chrono_seconds_rotary != 'undefined') {
						let ssa = normal_chrono_seconds_rotary_start_angle;
						let sea = normal_chrono_seconds_rotary_end_angle;
						let scw = sea > ssa;
						let sd = scw ? sea - ssa : ssa - sea;
						let sfac = sd / 360;
						normal_chrono_seconds_rotary.setProperty(hmUI.prop.MORE, {
							angle: (scw ? (ssa + ((parseInt(curSeconds) + (parseInt(curMilli) / 1000)) * (6 * sfac))) : (ssa - ((parseInt(curSeconds) + (parseInt(curMilli) / 1000)) * (6 * sfac))))
						})
					}

				}

				const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
					resume_call: (function () {
						if (chronoIsRunning) {
							chronoInterval = setInterval(updateChrono, 50);
						}
					}),
					pause_call: (function () {
						clearInterval(chronoInterval);
					}),
				})
			},

		onInit() {
			console.log('index page.js on init invoke')
			this.init_view()
		},
		onReady() {
			console.log('index page.js on ready invoke')
		},
		onShow() {
			console.log('index page.js on show invoke')
		},
		onHide() {
			console.log('index page.js on hide invoke')
		},
		onDestroy() {
			console.log('index page.js on destroy invoke')
		},
	});	})()
} catch (e) {
	console.log(e)
}