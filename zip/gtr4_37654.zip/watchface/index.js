﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        const logger = Logger.getLogger('watchface_SashaCX75');
        //end of ignored block

        //dynamic modify start

        
        console.log('user_functions.js');
        // start user_functions.js
		let colornumber_bezel = 1
        let totalcolors_bezel = 16
        let namecolor_bezel = ''
		
		function click_Bezel() {
            if(colornumber_bezel>=totalcolors_bezel) {
            colornumber_bezel=1;
                }
            else {
                colornumber_bezel=colornumber_bezel+1;
            }
			if ( colornumber_bezel == 1) { namecolor_bezel = "BEZEL 1/16"}
			if ( colornumber_bezel == 2) { namecolor_bezel = "BEZEL 2/16"}
			if ( colornumber_bezel == 3) { namecolor_bezel = "BEZEL 3/16"}
			if ( colornumber_bezel == 4) { namecolor_bezel = "BEZEL 4/16"}
			if ( colornumber_bezel == 5) { namecolor_bezel = "BEZEL 5/16"}
			if ( colornumber_bezel == 6) { namecolor_bezel = "BEZEL 6/16"}
			if ( colornumber_bezel == 7) { namecolor_bezel = "BEZEL 7/16"}
			if ( colornumber_bezel == 8) { namecolor_bezel = "BEZEL 8/16"}
			if ( colornumber_bezel == 9) { namecolor_bezel = "BEZEL 9/16"}
			if ( colornumber_bezel == 10) { namecolor_bezel = "BEZEL 10/16"}
			if ( colornumber_bezel == 11) { namecolor_bezel = "BEZEL 11/16"}
			if ( colornumber_bezel == 12) { namecolor_bezel = "BEZEL 12/16"}
			if ( colornumber_bezel == 13) { namecolor_bezel = "BEZEL 13/16"}
			if ( colornumber_bezel == 14) { namecolor_bezel = "BEZEL 14/16"}
			if ( colornumber_bezel == 15) { namecolor_bezel = "BEZEL 15/16"}
			if ( colornumber_bezel == 16) { namecolor_bezel = "BEZEL 16/16"}

			hmUI.showToast({text: namecolor_bezel });
            normal_stress_icon_img.setProperty(hmUI.prop.SRC, "bezel" + parseInt(colornumber_bezel) + ".png");
        }
		
		let colornumber_main = 1
        let totalcolors_main = 7
        let namecolor_main = ''
		
		function click_Color() {
            if(colornumber_main>=totalcolors_main) {
            colornumber_main=1;
                }
            else {
                colornumber_main=colornumber_main+1;
            }
			if ( colornumber_main == 1) { namecolor_main = "COLOR 1/7"}
			if ( colornumber_main == 2) { namecolor_main = "COLOR 2/7"}
			if ( colornumber_main == 3) { namecolor_main = "COLOR 3/7"}
			if ( colornumber_main == 4) { namecolor_main = "COLOR 4/7"}
			if ( colornumber_main == 5) { namecolor_main = "COLOR 5/7"}
			if ( colornumber_main == 6) { namecolor_main = "COLOR 6/7"}
			if ( colornumber_main == 7) { namecolor_main = "COLOR 7/7"}

			hmUI.showToast({text: namecolor_main });
            normal_image_img.setProperty(hmUI.prop.SRC, "main" + parseInt(colornumber_main) + ".png");
        }
		
		let btn_element_1 = ''
        let elementnumber_1 = 1
        let total_elemente = 2

        function click_Light() {
            if(elementnumber_1==total_elemente) {
            elementnumber_1=1;
                UpdateElementeOne();
                }
            else {
                elementnumber_1=elementnumber_1+1;
                if(elementnumber_1==2) {
                  UpdateElementeTwo();
                }

            }
            if(elementnumber_1==1) hmUI.showToast({text: 'LIGHT OFF'});
            if(elementnumber_1==2) hmUI.showToast({text: 'LIGHT ON'});
		}
		
        function UpdateElementeOne(){
                normal_stand_icon_img.setProperty(hmUI.prop.VISIBLE, false);
        }

        function UpdateElementeTwo(){
				normal_stand_icon_img.setProperty(hmUI.prop.VISIBLE, true);
        }
        // end user_functions.js

        let normal_background_bg_img = ''
        let normal_temperature_current_text_img = ''
        let normal_month_TextCircle = new Array(2);
        let normal_month_TextCircle_ASCIIARRAY = new Array(10);
        let normal_month_TextCircle_img_width = 16;
        let normal_month_TextCircle_img_height = 21;
        let normal_timerTextUpdate = undefined;
        let normal_day_TextCircle = new Array(2);
        let normal_day_TextCircle_ASCIIARRAY = new Array(10);
        let normal_day_TextCircle_img_width = 16;
        let normal_day_TextCircle_img_height = 21;
        let normal_calorie_pointer_progress_img_pointer = ''
        let normal_calorie_current_text_img = ''
        let normal_week_pointer_progress_date_pointer = ''
        let normal_heart_rate_pointer_progress_img_pointer = ''
        let normal_heart_rate_icon_img = ''
        let normal_heart_rate_TextCircle = new Array(3);
        let normal_heart_rate_TextCircle_ASCIIARRAY = new Array(10);
        let normal_heart_rate_TextCircle_img_width = 11;
        let normal_heart_rate_TextCircle_img_height = 16;
        let normal_heart_rate_image_progress_img_level = ''
        let normal_battery_pointer_progress_img_pointer = ''
        let normal_battery_icon_img = ''
        let normal_battery_TextCircle = new Array(3);
        let normal_battery_TextCircle_ASCIIARRAY = new Array(10);
        let normal_battery_TextCircle_img_width = 11;
        let normal_battery_TextCircle_img_height = 16;
        let normal_battery_TextCircle_unit = null;
        let normal_battery_TextCircle_unit_width = 11;
        let normal_battery_image_progress_img_level = ''
        let normal_digital_clock_img_time = ''
        let normal_stand_icon_img = ''
        let normal_step_pointer_progress_img_pointer = ''
        let normal_step_current_text_img = ''
        let normal_image_img = ''
        let normal_analog_clock_pro_hour_pointer_img = ''
        let normal_analog_clock_pro_minute_pointer_img = ''
        let normal_stress_icon_img = ''
        let idle_background_bg_img = ''
        let idle_temperature_current_text_img = ''
        let idle_month_TextCircle = new Array(2);
        let idle_month_TextCircle_ASCIIARRAY = new Array(10);
        let idle_month_TextCircle_img_width = 16;
        let idle_month_TextCircle_img_height = 21;
        let idle_timerTextUpdate = undefined;
        let idle_day_TextCircle = new Array(2);
        let idle_day_TextCircle_ASCIIARRAY = new Array(10);
        let idle_day_TextCircle_img_width = 16;
        let idle_day_TextCircle_img_height = 21;
        let idle_calorie_pointer_progress_img_pointer = ''
        let idle_calorie_current_text_img = ''
        let idle_week_pointer_progress_date_pointer = ''
        let idle_heart_rate_pointer_progress_img_pointer = ''
        let idle_heart_rate_icon_img = ''
        let idle_heart_rate_TextCircle = new Array(3);
        let idle_heart_rate_TextCircle_ASCIIARRAY = new Array(10);
        let idle_heart_rate_TextCircle_img_width = 11;
        let idle_heart_rate_TextCircle_img_height = 16;
        let idle_heart_rate_image_progress_img_level = ''
        let idle_battery_pointer_progress_img_pointer = ''
        let idle_battery_icon_img = ''
        let idle_battery_TextCircle = new Array(3);
        let idle_battery_TextCircle_ASCIIARRAY = new Array(10);
        let idle_battery_TextCircle_img_width = 11;
        let idle_battery_TextCircle_img_height = 16;
        let idle_battery_TextCircle_unit = null;
        let idle_battery_TextCircle_unit_width = 11;
        let idle_battery_image_progress_img_level = ''
        let idle_digital_clock_img_time = ''
        let idle_stand_icon_img = ''
        let idle_step_pointer_progress_img_pointer = ''
        let idle_step_current_text_img = ''
        let idle_image_img = ''
        let idle_analog_clock_pro_hour_pointer_img = ''
        let idle_analog_clock_pro_minute_pointer_img = ''
        let Button_1 = ''
        let Button_2 = ''
        let Button_3 = ''
        let Button_4 = ''
        let Button_5 = ''
        let Button_6 = ''
        let Button_7 = ''
        let Button_8 = ''
        let Button_9 = ''
        let Button_10 = ''
        let Button_11 = ''
        let Button_12 = ''
        let Button_13 = ''
        let timeSensor = ''


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            console.log('Watch_Face.ScreenNormal');
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 466,
              h: 466,
              src: 'bg.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 40,
              y: 250,
              font_array: ["num_00.png","num_01.png","num_02.png","num_03.png","num_04.png","num_05.png","num_06.png","num_07.png","num_08.png","num_09.png"],
              padding: false,
              h_space: -3,
              unit_sc: 'num_11.png',
              unit_tc: 'num_11.png',
              unit_en: 'num_11.png',
              negative_image: 'num_10.png',
              invalid_image: 'num_12.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_month_text_circle_img = hmUI.createWidget(hmUI.widget.Text_Circle, {
              // circle_center_X: 233,
              // circle_center_Y: 233,
              // font_array: ["num_00.png","num_01.png","num_02.png","num_03.png","num_04.png","num_05.png","num_06.png","num_07.png","num_08.png","num_09.png"],
              // radius: 170,
              // angle: 43,
              // char_space_angle: -1,
              // zero: false,
              // reverse_direction: false,
              // unit_in_alignment: true,
              // vertical_alignment: CENTER_V,
              // horizontal_alignment: CENTER_H,
              // type: hmUI.data_type.MONTH,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_month_TextCircle_ASCIIARRAY[0] = 'num_00.png';  // set of images with numbers
            normal_month_TextCircle_ASCIIARRAY[1] = 'num_01.png';  // set of images with numbers
            normal_month_TextCircle_ASCIIARRAY[2] = 'num_02.png';  // set of images with numbers
            normal_month_TextCircle_ASCIIARRAY[3] = 'num_03.png';  // set of images with numbers
            normal_month_TextCircle_ASCIIARRAY[4] = 'num_04.png';  // set of images with numbers
            normal_month_TextCircle_ASCIIARRAY[5] = 'num_05.png';  // set of images with numbers
            normal_month_TextCircle_ASCIIARRAY[6] = 'num_06.png';  // set of images with numbers
            normal_month_TextCircle_ASCIIARRAY[7] = 'num_07.png';  // set of images with numbers
            normal_month_TextCircle_ASCIIARRAY[8] = 'num_08.png';  // set of images with numbers
            normal_month_TextCircle_ASCIIARRAY[9] = 'num_09.png';  // set of images with numbers

            //start of ignored block
            for (let i = 0; i < 2; i++) {
              normal_month_TextCircle[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 466,
                h: 466,
                center_x: 233,
                center_y: 233,
                pos_x: 233 - normal_month_TextCircle_img_width / 2,
                pos_y: 233 - 180,
                src: 'num_00.png',
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
              normal_month_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
            };
            //end of ignored block
            
            const timeNaw = hmSensor.createSensor(hmSensor.id.TIME);

            let screenType = hmSetting.getScreenType();            
            function toDegree (radian) {
              return radian * (180 / Math.PI);
            };

            // normal_day_text_circle_img = hmUI.createWidget(hmUI.widget.Text_Circle, {
              // circle_center_X: 233,
              // circle_center_Y: 233,
              // font_array: ["num_00.png","num_01.png","num_02.png","num_03.png","num_04.png","num_05.png","num_06.png","num_07.png","num_08.png","num_09.png"],
              // radius: 170,
              // angle: -42,
              // char_space_angle: -1,
              // zero: false,
              // reverse_direction: false,
              // unit_in_alignment: true,
              // vertical_alignment: CENTER_V,
              // horizontal_alignment: CENTER_H,
              // type: hmUI.data_type.DAY,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_day_TextCircle_ASCIIARRAY[0] = 'num_00.png';  // set of images with numbers
            normal_day_TextCircle_ASCIIARRAY[1] = 'num_01.png';  // set of images with numbers
            normal_day_TextCircle_ASCIIARRAY[2] = 'num_02.png';  // set of images with numbers
            normal_day_TextCircle_ASCIIARRAY[3] = 'num_03.png';  // set of images with numbers
            normal_day_TextCircle_ASCIIARRAY[4] = 'num_04.png';  // set of images with numbers
            normal_day_TextCircle_ASCIIARRAY[5] = 'num_05.png';  // set of images with numbers
            normal_day_TextCircle_ASCIIARRAY[6] = 'num_06.png';  // set of images with numbers
            normal_day_TextCircle_ASCIIARRAY[7] = 'num_07.png';  // set of images with numbers
            normal_day_TextCircle_ASCIIARRAY[8] = 'num_08.png';  // set of images with numbers
            normal_day_TextCircle_ASCIIARRAY[9] = 'num_09.png';  // set of images with numbers

            //start of ignored block
            for (let i = 0; i < 2; i++) {
              normal_day_TextCircle[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 466,
                h: 466,
                center_x: 233,
                center_y: 233,
                pos_x: 233 - normal_day_TextCircle_img_width / 2,
                pos_y: 233 - 180,
                src: 'num_00.png',
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
              normal_day_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
            };
            //end of ignored block

            normal_calorie_pointer_progress_img_pointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
              src: 'hand_point.png',
              center_x: 361,
              center_y: 191,
              x: 7,
              y: 51,
              start_angle: 34,
              end_angle: 112,
              invalid_visible: false,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_calorie_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 374,
              y: 250,
              font_array: ["num_00.png","num_01.png","num_02.png","num_03.png","num_04.png","num_05.png","num_06.png","num_07.png","num_08.png","num_09.png"],
              padding: false,
              h_space: -3,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_week_pointer_progress_date_pointer = hmUI.createWidget(hmUI.widget.DATE_POINTER, {
              src: 'hand_point.png',
              center_x: 234,
              center_y: 233,
              posX: 7,
              posY: 169,
              start_angle: -33,
              end_angle: 25,
              type: hmUI.date.WEEK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_pointer_progress_img_pointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
              src: 'hand_point.png',
              center_x: 340,
              center_y: 312,
              x: 7,
              y: 51,
              start_angle: 170,
              end_angle: 90,
              invalid_visible: false,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'hr_top.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_heart_rate_text_circle_img = hmUI.createWidget(hmUI.widget.Text_Circle, {
              // circle_center_X: 233,
              // circle_center_Y: 233,
              // font_array: ["small_00.png","small_01.png","small_02.png","small_03.png","small_04.png","small_05.png","small_06.png","small_07.png","small_08.png","small_09.png"],
              // radius: 128,
              // angle: 134,
              // char_space_angle: 1,
              // zero: false,
              // reverse_direction: true,
              // unit_in_alignment: true,
              // vertical_alignment: CENTER_V,
              // horizontal_alignment: CENTER_H,
              // type: hmUI.data_type.HEART,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_heart_rate_TextCircle_ASCIIARRAY[0] = 'small_00.png';  // set of images with numbers
            normal_heart_rate_TextCircle_ASCIIARRAY[1] = 'small_01.png';  // set of images with numbers
            normal_heart_rate_TextCircle_ASCIIARRAY[2] = 'small_02.png';  // set of images with numbers
            normal_heart_rate_TextCircle_ASCIIARRAY[3] = 'small_03.png';  // set of images with numbers
            normal_heart_rate_TextCircle_ASCIIARRAY[4] = 'small_04.png';  // set of images with numbers
            normal_heart_rate_TextCircle_ASCIIARRAY[5] = 'small_05.png';  // set of images with numbers
            normal_heart_rate_TextCircle_ASCIIARRAY[6] = 'small_06.png';  // set of images with numbers
            normal_heart_rate_TextCircle_ASCIIARRAY[7] = 'small_07.png';  // set of images with numbers
            normal_heart_rate_TextCircle_ASCIIARRAY[8] = 'small_08.png';  // set of images with numbers
            normal_heart_rate_TextCircle_ASCIIARRAY[9] = 'small_09.png';  // set of images with numbers

            //start of ignored block
            for (let i = 0; i < 3; i++) {
              normal_heart_rate_TextCircle[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 466,
                h: 466,
                center_x: 233,
                center_y: 233,
                pos_x: 233 - normal_heart_rate_TextCircle_img_width / 2,
                pos_y: 233 + 120,
                src: 'small_00.png',
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
              normal_heart_rate_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
            };
            //end of ignored block
            
            const heart_rate = hmSensor.createSensor(hmSensor.id.HEART);
            heart_rate.addEventListener(hmSensor.event.CHANGE, function() {
              text_update();
            });

            normal_heart_rate_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 0,
              y: 0,
              image_array: ["hr_01.png","hr_02.png","hr_03.png","hr_04.png","hr_05.png","hr_06.png"],
              image_length: 6,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_pointer_progress_img_pointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
              src: 'hand_point.png',
              center_x: 124,
              center_y: 312,
              x: 7,
              y: 50,
              start_angle: -170,
              end_angle: -90,
              invalid_visible: false,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'batt_top.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_battery_text_circle_img = hmUI.createWidget(hmUI.widget.Text_Circle, {
              // circle_center_X: 233,
              // circle_center_Y: 233,
              // font_array: ["small_00.png","small_01.png","small_02.png","small_03.png","small_04.png","small_05.png","small_06.png","small_07.png","small_08.png","small_09.png"],
              // radius: 128,
              // angle: -134,
              // char_space_angle: 0,
              // unit: 'small_10.png',
              // zero: false,
              // reverse_direction: true,
              // unit_in_alignment: true,
              // vertical_alignment: CENTER_V,
              // horizontal_alignment: CENTER_H,
              // type: hmUI.data_type.BATTERY,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_battery_TextCircle_ASCIIARRAY[0] = 'small_00.png';  // set of images with numbers
            normal_battery_TextCircle_ASCIIARRAY[1] = 'small_01.png';  // set of images with numbers
            normal_battery_TextCircle_ASCIIARRAY[2] = 'small_02.png';  // set of images with numbers
            normal_battery_TextCircle_ASCIIARRAY[3] = 'small_03.png';  // set of images with numbers
            normal_battery_TextCircle_ASCIIARRAY[4] = 'small_04.png';  // set of images with numbers
            normal_battery_TextCircle_ASCIIARRAY[5] = 'small_05.png';  // set of images with numbers
            normal_battery_TextCircle_ASCIIARRAY[6] = 'small_06.png';  // set of images with numbers
            normal_battery_TextCircle_ASCIIARRAY[7] = 'small_07.png';  // set of images with numbers
            normal_battery_TextCircle_ASCIIARRAY[8] = 'small_08.png';  // set of images with numbers
            normal_battery_TextCircle_ASCIIARRAY[9] = 'small_09.png';  // set of images with numbers

            //start of ignored block
            for (let i = 0; i < 3; i++) {
              normal_battery_TextCircle[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 466,
                h: 466,
                center_x: 233,
                center_y: 233,
                pos_x: 233 - normal_battery_TextCircle_img_width / 2,
                pos_y: 233 + 120,
                src: 'small_00.png',
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
              normal_battery_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
            };

            normal_battery_TextCircle_unit = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 466,
              h: 466,
              center_x: 233,
              center_y: 233,
              pos_x: 233 - normal_battery_TextCircle_unit_width / 2,
              pos_y: 233 + 120,
              src: 'small_10.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            normal_battery_TextCircle_unit.setProperty(hmUI.prop.VISIBLE, false);
            //end of ignored block
            
            const battery = hmSensor.createSensor(hmSensor.id.BATTERY);
            battery.addEventListener(hmSensor.event.CHANGE, function() {
              text_update();
            });

            normal_battery_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 0,
              y: 0,
              image_array: ["batt_01.png","batt_02.png","batt_03.png","batt_04.png","batt_05.png","batt_06.png","batt_07.png","batt_08.png"],
              image_length: 8,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 178,
              hour_startY: 280,
              hour_array: ["time_00.png","time_01.png","time_02.png","time_03.png","time_04.png","time_05.png","time_06.png","time_07.png","time_08.png","time_09.png"],
              hour_zero: 1,
              hour_space: 0,
              hour_angle: 0,
              hour_unit_sc: 'time_10.png',
              hour_unit_tc: 'time_10.png',
              hour_unit_en: 'time_10.png',
              hour_align: hmUI.align.CENTER_H,

              minute_startX: 0,
              minute_startY: 0,
              minute_array: ["time_00.png","time_01.png","time_02.png","time_03.png","time_04.png","time_05.png","time_06.png","time_07.png","time_08.png","time_09.png"],
              minute_zero: 1,
              minute_space: 0,
              minute_angle: 0,
              minute_follow: 1,
              minute_align: hmUI.align.LEFT,

              second_startX: 222,
              second_startY: 200,
              second_array: ["sec_00.png","sec_01.png","sec_02.png","sec_03.png","sec_04.png","sec_05.png","sec_06.png","sec_07.png","sec_08.png","sec_09.png"],
              second_zero: 1,
              second_space: 1,
              second_angle: 0,
              second_follow: 0,
              second_align: hmUI.align.CENTER_H,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_stand_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'light.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_pointer_progress_img_pointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
              src: 'hand_point.png',
              center_x: 104,
              center_y: 190,
              x: 7,
              y: 51,
              start_angle: -112,
              end_angle: -34,
              invalid_visible: false,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 179,
              y: 379,
              font_array: ["num_00.png","num_01.png","num_02.png","num_03.png","num_04.png","num_05.png","num_06.png","num_07.png","num_08.png","num_09.png"],
              padding: true,
              h_space: 6,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_image_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'main1.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            const deviceInfo = hmSetting.getDeviceInfo();
            if (!timeSensor) timeSensor = hmSensor.createSensor(hmSensor.id.TIME);
            timeSensor.addEventListener(timeSensor.event.MINUTEEND, function() {
              time_update(true, true);
            });

            // normal_analog_clock_pro_hour_pointer_img = hmUI.createWidget(hmUI.widget.TIME_POINTER_PRO, {
              // src: 'hand_hour.png',
              // center_x: 233,
              // center_y: 233,
              // x: 233,
              // y: 233,
              // start_angle: -120,
              // end_angle: 120,
              // type: hmUI.data_type.hour,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });


            normal_analog_clock_pro_hour_pointer_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: deviceInfo.width,
              h: deviceInfo.height,
              pos_x: 233 - 233,
              pos_y: 233 - 233,
              center_x: 233,
              center_y: 233,
              src: 'hand_hour.png',
              angle: 0,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_analog_clock_pro_minute_pointer_img = hmUI.createWidget(hmUI.widget.TIME_POINTER_PRO, {
              // src: 'hand_min.png',
              // center_x: 233,
              // center_y: 233,
              // x: 233,
              // y: 233,
              // start_angle: -120,
              // end_angle: 120,
              // type: hmUI.data_type.minute,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });


            normal_analog_clock_pro_minute_pointer_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: deviceInfo.width,
              h: deviceInfo.height,
              pos_x: 233 - 233,
              pos_y: 233 - 233,
              center_x: 233,
              center_y: 233,
              src: 'hand_min.png',
              angle: 0,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_stress_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'bezel1.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            console.log('Watch_Face.ScreenAOD');
            idle_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 466,
              h: 466,
              src: 'bg.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 40,
              y: 250,
              font_array: ["num_00.png","num_01.png","num_02.png","num_03.png","num_04.png","num_05.png","num_06.png","num_07.png","num_08.png","num_09.png"],
              padding: false,
              h_space: -3,
              unit_sc: 'num_11.png',
              unit_tc: 'num_11.png',
              unit_en: 'num_11.png',
              negative_image: 'num_10.png',
              invalid_image: 'num_12.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            // idle_month_text_circle_img = hmUI.createWidget(hmUI.widget.Text_Circle, {
              // circle_center_X: 233,
              // circle_center_Y: 233,
              // font_array: ["num_00.png","num_01.png","num_02.png","num_03.png","num_04.png","num_05.png","num_06.png","num_07.png","num_08.png","num_09.png"],
              // radius: 170,
              // angle: 43,
              // char_space_angle: -1,
              // zero: false,
              // reverse_direction: false,
              // unit_in_alignment: true,
              // vertical_alignment: CENTER_V,
              // horizontal_alignment: CENTER_H,
              // type: hmUI.data_type.MONTH,
              // show_level: hmUI.show_level.ONLY_AOD,
            // });

            idle_month_TextCircle_ASCIIARRAY[0] = 'num_00.png';  // set of images with numbers
            idle_month_TextCircle_ASCIIARRAY[1] = 'num_01.png';  // set of images with numbers
            idle_month_TextCircle_ASCIIARRAY[2] = 'num_02.png';  // set of images with numbers
            idle_month_TextCircle_ASCIIARRAY[3] = 'num_03.png';  // set of images with numbers
            idle_month_TextCircle_ASCIIARRAY[4] = 'num_04.png';  // set of images with numbers
            idle_month_TextCircle_ASCIIARRAY[5] = 'num_05.png';  // set of images with numbers
            idle_month_TextCircle_ASCIIARRAY[6] = 'num_06.png';  // set of images with numbers
            idle_month_TextCircle_ASCIIARRAY[7] = 'num_07.png';  // set of images with numbers
            idle_month_TextCircle_ASCIIARRAY[8] = 'num_08.png';  // set of images with numbers
            idle_month_TextCircle_ASCIIARRAY[9] = 'num_09.png';  // set of images with numbers

            //start of ignored block
            for (let i = 0; i < 2; i++) {
              idle_month_TextCircle[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 466,
                h: 466,
                center_x: 233,
                center_y: 233,
                pos_x: 233 - idle_month_TextCircle_img_width / 2,
                pos_y: 233 - 180,
                src: 'num_00.png',
                show_level: hmUI.show_level.ONLY_AOD,
              });
              idle_month_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
            };
            //end of ignored block

            // idle_day_text_circle_img = hmUI.createWidget(hmUI.widget.Text_Circle, {
              // circle_center_X: 233,
              // circle_center_Y: 233,
              // font_array: ["num_00.png","num_01.png","num_02.png","num_03.png","num_04.png","num_05.png","num_06.png","num_07.png","num_08.png","num_09.png"],
              // radius: 170,
              // angle: -42,
              // char_space_angle: -1,
              // zero: false,
              // reverse_direction: false,
              // unit_in_alignment: true,
              // vertical_alignment: CENTER_V,
              // horizontal_alignment: CENTER_H,
              // type: hmUI.data_type.DAY,
              // show_level: hmUI.show_level.ONLY_AOD,
            // });

            idle_day_TextCircle_ASCIIARRAY[0] = 'num_00.png';  // set of images with numbers
            idle_day_TextCircle_ASCIIARRAY[1] = 'num_01.png';  // set of images with numbers
            idle_day_TextCircle_ASCIIARRAY[2] = 'num_02.png';  // set of images with numbers
            idle_day_TextCircle_ASCIIARRAY[3] = 'num_03.png';  // set of images with numbers
            idle_day_TextCircle_ASCIIARRAY[4] = 'num_04.png';  // set of images with numbers
            idle_day_TextCircle_ASCIIARRAY[5] = 'num_05.png';  // set of images with numbers
            idle_day_TextCircle_ASCIIARRAY[6] = 'num_06.png';  // set of images with numbers
            idle_day_TextCircle_ASCIIARRAY[7] = 'num_07.png';  // set of images with numbers
            idle_day_TextCircle_ASCIIARRAY[8] = 'num_08.png';  // set of images with numbers
            idle_day_TextCircle_ASCIIARRAY[9] = 'num_09.png';  // set of images with numbers

            //start of ignored block
            for (let i = 0; i < 2; i++) {
              idle_day_TextCircle[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 466,
                h: 466,
                center_x: 233,
                center_y: 233,
                pos_x: 233 - idle_day_TextCircle_img_width / 2,
                pos_y: 233 - 180,
                src: 'num_00.png',
                show_level: hmUI.show_level.ONLY_AOD,
              });
              idle_day_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
            };
            //end of ignored block

            idle_calorie_pointer_progress_img_pointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
              src: 'hand_point.png',
              center_x: 361,
              center_y: 191,
              x: 7,
              y: 51,
              start_angle: 34,
              end_angle: 112,
              invalid_visible: false,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_calorie_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 374,
              y: 250,
              font_array: ["num_00.png","num_01.png","num_02.png","num_03.png","num_04.png","num_05.png","num_06.png","num_07.png","num_08.png","num_09.png"],
              padding: false,
              h_space: -3,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_week_pointer_progress_date_pointer = hmUI.createWidget(hmUI.widget.DATE_POINTER, {
              src: 'hand_point.png',
              center_x: 234,
              center_y: 233,
              posX: 7,
              posY: 169,
              start_angle: -33,
              end_angle: 25,
              type: hmUI.date.WEEK,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_heart_rate_pointer_progress_img_pointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
              src: 'hand_point.png',
              center_x: 340,
              center_y: 312,
              x: 7,
              y: 51,
              start_angle: 170,
              end_angle: 90,
              invalid_visible: false,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_heart_rate_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'hr_top.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            // idle_heart_rate_text_circle_img = hmUI.createWidget(hmUI.widget.Text_Circle, {
              // circle_center_X: 233,
              // circle_center_Y: 233,
              // font_array: ["small_00.png","small_01.png","small_02.png","small_03.png","small_04.png","small_05.png","small_06.png","small_07.png","small_08.png","small_09.png"],
              // radius: 128,
              // angle: 134,
              // char_space_angle: 1,
              // zero: false,
              // reverse_direction: true,
              // unit_in_alignment: true,
              // vertical_alignment: CENTER_V,
              // horizontal_alignment: CENTER_H,
              // type: hmUI.data_type.HEART,
              // show_level: hmUI.show_level.ONLY_AOD,
            // });

            idle_heart_rate_TextCircle_ASCIIARRAY[0] = 'small_00.png';  // set of images with numbers
            idle_heart_rate_TextCircle_ASCIIARRAY[1] = 'small_01.png';  // set of images with numbers
            idle_heart_rate_TextCircle_ASCIIARRAY[2] = 'small_02.png';  // set of images with numbers
            idle_heart_rate_TextCircle_ASCIIARRAY[3] = 'small_03.png';  // set of images with numbers
            idle_heart_rate_TextCircle_ASCIIARRAY[4] = 'small_04.png';  // set of images with numbers
            idle_heart_rate_TextCircle_ASCIIARRAY[5] = 'small_05.png';  // set of images with numbers
            idle_heart_rate_TextCircle_ASCIIARRAY[6] = 'small_06.png';  // set of images with numbers
            idle_heart_rate_TextCircle_ASCIIARRAY[7] = 'small_07.png';  // set of images with numbers
            idle_heart_rate_TextCircle_ASCIIARRAY[8] = 'small_08.png';  // set of images with numbers
            idle_heart_rate_TextCircle_ASCIIARRAY[9] = 'small_09.png';  // set of images with numbers

            //start of ignored block
            for (let i = 0; i < 3; i++) {
              idle_heart_rate_TextCircle[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 466,
                h: 466,
                center_x: 233,
                center_y: 233,
                pos_x: 233 - idle_heart_rate_TextCircle_img_width / 2,
                pos_y: 233 + 120,
                src: 'small_00.png',
                show_level: hmUI.show_level.ONLY_AOD,
              });
              idle_heart_rate_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
            };
            //end of ignored block

            idle_heart_rate_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 0,
              y: 0,
              image_array: ["hr_01.png","hr_02.png","hr_03.png","hr_04.png","hr_05.png","hr_06.png"],
              image_length: 6,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_battery_pointer_progress_img_pointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
              src: 'hand_point.png',
              center_x: 124,
              center_y: 312,
              x: 7,
              y: 50,
              start_angle: -170,
              end_angle: -90,
              invalid_visible: false,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_battery_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'batt_top.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            // idle_battery_text_circle_img = hmUI.createWidget(hmUI.widget.Text_Circle, {
              // circle_center_X: 233,
              // circle_center_Y: 233,
              // font_array: ["small_00.png","small_01.png","small_02.png","small_03.png","small_04.png","small_05.png","small_06.png","small_07.png","small_08.png","small_09.png"],
              // radius: 128,
              // angle: -134,
              // char_space_angle: 0,
              // unit: 'small_10.png',
              // zero: false,
              // reverse_direction: true,
              // unit_in_alignment: true,
              // vertical_alignment: CENTER_V,
              // horizontal_alignment: CENTER_H,
              // type: hmUI.data_type.BATTERY,
              // show_level: hmUI.show_level.ONLY_AOD,
            // });

            idle_battery_TextCircle_ASCIIARRAY[0] = 'small_00.png';  // set of images with numbers
            idle_battery_TextCircle_ASCIIARRAY[1] = 'small_01.png';  // set of images with numbers
            idle_battery_TextCircle_ASCIIARRAY[2] = 'small_02.png';  // set of images with numbers
            idle_battery_TextCircle_ASCIIARRAY[3] = 'small_03.png';  // set of images with numbers
            idle_battery_TextCircle_ASCIIARRAY[4] = 'small_04.png';  // set of images with numbers
            idle_battery_TextCircle_ASCIIARRAY[5] = 'small_05.png';  // set of images with numbers
            idle_battery_TextCircle_ASCIIARRAY[6] = 'small_06.png';  // set of images with numbers
            idle_battery_TextCircle_ASCIIARRAY[7] = 'small_07.png';  // set of images with numbers
            idle_battery_TextCircle_ASCIIARRAY[8] = 'small_08.png';  // set of images with numbers
            idle_battery_TextCircle_ASCIIARRAY[9] = 'small_09.png';  // set of images with numbers

            //start of ignored block
            for (let i = 0; i < 3; i++) {
              idle_battery_TextCircle[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 466,
                h: 466,
                center_x: 233,
                center_y: 233,
                pos_x: 233 - idle_battery_TextCircle_img_width / 2,
                pos_y: 233 + 120,
                src: 'small_00.png',
                show_level: hmUI.show_level.ONLY_AOD,
              });
              idle_battery_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
            };

            idle_battery_TextCircle_unit = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 466,
              h: 466,
              center_x: 233,
              center_y: 233,
              pos_x: 233 - idle_battery_TextCircle_unit_width / 2,
              pos_y: 233 + 120,
              src: 'small_10.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });
            idle_battery_TextCircle_unit.setProperty(hmUI.prop.VISIBLE, false);
            //end of ignored block

            idle_battery_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 0,
              y: 0,
              image_array: ["batt_01.png","batt_02.png","batt_03.png","batt_04.png","batt_05.png","batt_06.png","batt_07.png","batt_08.png"],
              image_length: 8,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 178,
              hour_startY: 280,
              hour_array: ["time_00.png","time_01.png","time_02.png","time_03.png","time_04.png","time_05.png","time_06.png","time_07.png","time_08.png","time_09.png"],
              hour_zero: 1,
              hour_space: 0,
              hour_angle: 0,
              hour_unit_sc: 'time_10.png',
              hour_unit_tc: 'time_10.png',
              hour_unit_en: 'time_10.png',
              hour_align: hmUI.align.CENTER_H,

              minute_startX: 0,
              minute_startY: 0,
              minute_array: ["time_00.png","time_01.png","time_02.png","time_03.png","time_04.png","time_05.png","time_06.png","time_07.png","time_08.png","time_09.png"],
              minute_zero: 1,
              minute_space: 0,
              minute_angle: 0,
              minute_follow: 1,
              minute_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_stand_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'light.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_step_pointer_progress_img_pointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
              src: 'hand_point.png',
              center_x: 104,
              center_y: 190,
              x: 7,
              y: 51,
              start_angle: -112,
              end_angle: -34,
              invalid_visible: false,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 179,
              y: 379,
              font_array: ["num_00.png","num_01.png","num_02.png","num_03.png","num_04.png","num_05.png","num_06.png","num_07.png","num_08.png","num_09.png"],
              padding: true,
              h_space: 6,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_image_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'aod_main.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            // idle_analog_clock_pro_hour_pointer_img = hmUI.createWidget(hmUI.widget.TIME_POINTER_PRO, {
              // src: 'hand_hour.png',
              // center_x: 233,
              // center_y: 233,
              // x: 233,
              // y: 233,
              // start_angle: -120,
              // end_angle: 120,
              // type: hmUI.data_type.hour,
              // show_level: hmUI.show_level.ONLY_AOD,
            // });


            idle_analog_clock_pro_hour_pointer_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: deviceInfo.width,
              h: deviceInfo.height,
              pos_x: 233 - 233,
              pos_y: 233 - 233,
              center_x: 233,
              center_y: 233,
              src: 'hand_hour.png',
              angle: 0,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            // idle_analog_clock_pro_minute_pointer_img = hmUI.createWidget(hmUI.widget.TIME_POINTER_PRO, {
              // src: 'hand_min.png',
              // center_x: 233,
              // center_y: 233,
              // x: 233,
              // y: 233,
              // start_angle: -120,
              // end_angle: 120,
              // type: hmUI.data_type.minute,
              // show_level: hmUI.show_level.ONLY_AOD,
            // });


            idle_analog_clock_pro_minute_pointer_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: deviceInfo.width,
              h: deviceInfo.height,
              pos_x: 233 - 233,
              pos_y: 233 - 233,
              center_x: 233,
              center_y: 233,
              src: 'hand_min.png',
              angle: 0,
              show_level: hmUI.show_level.ONLY_AOD,
            });
            
            // disconnectAlert = hmUI.createWidget(hmUI.widget.DisconnectAlert, {
              // disconneсnt_vibrate_type: 9,
              // disconneсnt_toast_text: Bluetooth OFF,
              // conneсnt_vibrate_type: 0,
              // conneсnt_toast_text: Bluetooth ON,
            // });

            // vibration when connecting or disconnecting

            function checkConnection() {
              console.log('checkConnection()');
              hmBle.removeListener;
              hmBle.addListener(function (status) {
                if(!status) {
                  hmUI.showToast({text: "Bluetooth OFF"});
                  vibro(9);
                }
                if(status) {
                  hmUI.showToast({text: "Bluetooth ON"});
                  vibro(0);
                }
              });
            }

            // end vibration when connecting or disconnecting
            // vibrate function

            const vibrate = hmSensor.createSensor(hmSensor.id.VIBRATE);
            let timer_StopVibrate = null;


            function vibro(scene = 25) {
              let stopDelay = 50;
              stopVibro();
              vibrate.stop();
              vibrate.scene = scene;
              if(scene < 23 || scene > 25) stopDelay = 1300;
              vibrate.start();
              if (scene != 1) timer_StopVibrate = timer.createTimer(stopDelay, 3000, stopVibro, {});
            }

            function stopVibro(){
              vibrate.stop();
              if(timer_StopVibrate) timer.stopTimer(timer_StopVibrate);
            }

            // end vibrate function

            console.log('Watch_Face.Buttons');
            Button_1 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 158,
              y: 48,
              w: 150,
              h: 45,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'batt_top.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'ScheduleCalScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_2 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 158,
              y: 374,
              w: 150,
              h: 45,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'batt_top.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'activityAppScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_3 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 66,
              y: 300,
              w: 80,
              h: 80,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'batt_top.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'PowerSaveHintScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_4 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 322,
              y: 300,
              w: 80,
              h: 80,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'batt_top.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'heart_app_Screen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_5 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 239,
              y: 276,
              w: 50,
              h: 45,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'batt_top.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'StopWatchScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_6 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 176,
              y: 276,
              w: 50,
              h: 45,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'batt_top.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'CountdownAppScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_7 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 380,
              y: 239,
              w: 45,
              h: 45,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'batt_top.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'SportStatusScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_8 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 375,
              y: 137,
              w: 50,
              h: 80,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'batt_top.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'SportListScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_9 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 41,
              y: 137,
              w: 50,
              h: 80,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'batt_top.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'SportScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_10 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 41,
              y: 238,
              w: 45,
              h: 45,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'batt_top.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'WeatherScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_11 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 264,
              y: 328,
              w: 45,
              h: 45,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'batt_top.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                click_Bezel();
				vibro(25);
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_12 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 158,
              y: 328,
              w: 45,
              h: 45,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'batt_top.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                click_Color();
				vibro(25);
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_13 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 210,
              y: 210,
              w: 45,
              h: 45,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'batt_top.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                click_Light();
				vibro(25);
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            console.log('user_script_end.js');
            // start user_script_end.js
			let cc = 0
			if (cc ==0 ){
			  normal_stand_icon_img.setProperty(hmUI.prop.VISIBLE, false);
			cc = 1;
			}
            // end user_script_end.js

            function time_update(updateHour = false, updateMinute = false) {
              console.log('time_update()');
              let hour = timeSensor.hour;
              let minute = timeSensor.minute;
              let second = timeSensor.second;

              if (updateHour) {
                let normal_hour = hour;
                let normal_fullAngle_hour = 240;
                if (normal_hour > 11) normal_hour -= 12;
                let normal_angle_hour = -120 + normal_fullAngle_hour*normal_hour/12 + (normal_fullAngle_hour/12)*minute/60;
                if (normal_analog_clock_pro_hour_pointer_img) normal_analog_clock_pro_hour_pointer_img.setProperty(hmUI.prop.ANGLE, normal_angle_hour);
              };

              if (updateMinute) {
                let normal_fullAngle_minute = 240;
                let normal_angle_minute = -120 + normal_fullAngle_minute*minute/60;
                if (normal_analog_clock_pro_minute_pointer_img) normal_analog_clock_pro_minute_pointer_img.setProperty(hmUI.prop.ANGLE, normal_angle_minute);
              };

              if (updateHour) {
                let idle_hour = hour;
                let idle_fullAngle_hour = 240;
                if (idle_hour > 11) idle_hour -= 12;
                let idle_angle_hour = -120 + idle_fullAngle_hour*idle_hour/12 + (idle_fullAngle_hour/12)*minute/60;
                if (idle_analog_clock_pro_hour_pointer_img) idle_analog_clock_pro_hour_pointer_img.setProperty(hmUI.prop.ANGLE, idle_angle_hour);
              };

              if (updateMinute) {
                let idle_fullAngle_minute = 240;
                let idle_angle_minute = -120 + idle_fullAngle_minute*minute/60;
                if (idle_analog_clock_pro_minute_pointer_img) idle_analog_clock_pro_minute_pointer_img.setProperty(hmUI.prop.ANGLE, idle_angle_minute);
              };

            };

            function text_update() {
              console.log('text_update()');

              console.log('update text circle month_TIME');
              let valueMonth = timeNaw.month;
              let normal_month_circle_string = parseInt(valueMonth).toString();

              if (screenType != hmSetting.screen_type.AOD) {
                for (var i = 1; i < 2; i++) {  // hide all symbols
                  normal_month_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                let char_Angle = 43;
                if (valueMonth != null && valueMonth != undefined && isFinite(valueMonth) && normal_month_circle_string.length > 0 && normal_month_circle_string.length < 6) {  // display data if it was possible to get it
                  let normal_month_TextCircle_img_angle = 0;
                  let normal_month_TextCircle_dot_img_angle = 0;
                  normal_month_TextCircle_img_angle = toDegree(Math.atan2(normal_month_TextCircle_img_width/2, 170));
                  // alignment = CENTER_H
                  let normal_month_TextCircle_angleOffset = normal_month_TextCircle_img_angle * (normal_month_circle_string.length - 1);
                  normal_month_TextCircle_angleOffset = normal_month_TextCircle_angleOffset + -1 * (normal_month_circle_string.length - 1) / 2;
                  char_Angle -= normal_month_TextCircle_angleOffset;
                  // alignment end
                  
                  let firstSymbol = true;
                  let index = 0;
                  for (let char of normal_month_circle_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 2) break;
                    if (charCode >= 0 && charCode < 10) { 
                      if (!firstSymbol) char_Angle += normal_month_TextCircle_img_angle;
                      firstSymbol = false;
                      normal_month_TextCircle[index].setProperty(hmUI.prop.ANGLE, char_Angle);
                      normal_month_TextCircle[index].setProperty(hmUI.prop.POS_X, 233 - normal_month_TextCircle_img_width / 2);
                      normal_month_TextCircle[index].setProperty(hmUI.prop.SRC, normal_month_TextCircle_ASCIIARRAY[charCode]);
                      normal_month_TextCircle[index].setProperty(hmUI.prop.VISIBLE, true);
                      char_Angle += normal_month_TextCircle_img_angle + -1;
                      index++;
                    };  // end if digit
                  };  // end char of string
                }  // end isFinite

              };

              console.log('update text circle day_TIME');
              let valueDay = timeNaw.day;
              let normal_day_circle_string = parseInt(valueDay).toString();

              if (screenType != hmSetting.screen_type.AOD) {
                for (var i = 1; i < 2; i++) {  // hide all symbols
                  normal_day_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                let char_Angle = -42;
                if (valueDay != null && valueDay != undefined && isFinite(valueDay) && normal_day_circle_string.length > 0 && normal_day_circle_string.length < 6) {  // display data if it was possible to get it
                  let normal_day_TextCircle_img_angle = 0;
                  let normal_day_TextCircle_dot_img_angle = 0;
                  normal_day_TextCircle_img_angle = toDegree(Math.atan2(normal_day_TextCircle_img_width/2, 170));
                  // alignment = CENTER_H
                  let normal_day_TextCircle_angleOffset = normal_day_TextCircle_img_angle * (normal_day_circle_string.length - 1);
                  normal_day_TextCircle_angleOffset = normal_day_TextCircle_angleOffset + -1 * (normal_day_circle_string.length - 1) / 2;
                  char_Angle -= normal_day_TextCircle_angleOffset;
                  // alignment end
                  
                  let firstSymbol = true;
                  let index = 0;
                  for (let char of normal_day_circle_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 2) break;
                    if (charCode >= 0 && charCode < 10) { 
                      if (!firstSymbol) char_Angle += normal_day_TextCircle_img_angle;
                      firstSymbol = false;
                      normal_day_TextCircle[index].setProperty(hmUI.prop.ANGLE, char_Angle);
                      normal_day_TextCircle[index].setProperty(hmUI.prop.POS_X, 233 - normal_day_TextCircle_img_width / 2);
                      normal_day_TextCircle[index].setProperty(hmUI.prop.SRC, normal_day_TextCircle_ASCIIARRAY[charCode]);
                      normal_day_TextCircle[index].setProperty(hmUI.prop.VISIBLE, true);
                      char_Angle += normal_day_TextCircle_img_angle + -1;
                      index++;
                    };  // end if digit
                  };  // end char of string
                }  // end isFinite

              };

              console.log('update text circle heart_rate_HEART');
              let valueHeartRate = heart_rate.last;
              let normal_heart_rate_circle_string = parseInt(valueHeartRate).toString();

              if (screenType != hmSetting.screen_type.AOD) {
                for (var i = 1; i < 3; i++) {  // hide all symbols
                  normal_heart_rate_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                let char_Angle = 314;
                if (valueHeartRate != null && valueHeartRate != undefined && isFinite(valueHeartRate) && normal_heart_rate_circle_string.length > 0 && normal_heart_rate_circle_string.length < 6) {  // display data if it was possible to get it
                  let normal_heart_rate_TextCircle_img_angle = 0;
                  let normal_heart_rate_TextCircle_dot_img_angle = 0;
                  normal_heart_rate_TextCircle_img_angle = toDegree(Math.atan2(normal_heart_rate_TextCircle_img_width/2, 128));
                  // alignment = CENTER_H
                  let normal_heart_rate_TextCircle_angleOffset = normal_heart_rate_TextCircle_img_angle * (normal_heart_rate_circle_string.length - 1);
                  normal_heart_rate_TextCircle_angleOffset = normal_heart_rate_TextCircle_angleOffset + 1 * (normal_heart_rate_circle_string.length - 1) / 2;
                  normal_heart_rate_TextCircle_angleOffset = -normal_heart_rate_TextCircle_angleOffset;
                  char_Angle -= normal_heart_rate_TextCircle_angleOffset;
                  // alignment end
                  
                  let firstSymbol = true;
                  let index = 0;
                  for (let char of normal_heart_rate_circle_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 3) break;
                    if (charCode >= 0 && charCode < 10) { 
                      if (!firstSymbol) char_Angle -= normal_heart_rate_TextCircle_img_angle;
                      firstSymbol = false;
                      normal_heart_rate_TextCircle[index].setProperty(hmUI.prop.ANGLE, char_Angle);
                      normal_heart_rate_TextCircle[index].setProperty(hmUI.prop.POS_X, 233 - normal_heart_rate_TextCircle_img_width / 2);
                      normal_heart_rate_TextCircle[index].setProperty(hmUI.prop.SRC, normal_heart_rate_TextCircle_ASCIIARRAY[charCode]);
                      normal_heart_rate_TextCircle[index].setProperty(hmUI.prop.VISIBLE, true);
                      char_Angle -= normal_heart_rate_TextCircle_img_angle + 1;
                      index++;
                    };  // end if digit
                  };  // end char of string
                }  // end isFinite

              };

              console.log('update text circle battery_BATTERY');
              let valueBattery = battery.current;
              let normal_battery_circle_string = parseInt(valueBattery).toString();

              if (screenType != hmSetting.screen_type.AOD) {
                for (var i = 1; i < 3; i++) {  // hide all symbols
                  normal_battery_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                normal_battery_TextCircle_unit.setProperty(hmUI.prop.VISIBLE, false);
                let char_Angle = 46;
                if (valueBattery != null && valueBattery != undefined && isFinite(valueBattery) && normal_battery_circle_string.length > 0 && normal_battery_circle_string.length < 6) {  // display data if it was possible to get it
                  let normal_battery_TextCircle_img_angle = 0;
                  let normal_battery_TextCircle_dot_img_angle = 0;
                  let normal_battery_TextCircle_unit_angle = 0;
                  normal_battery_TextCircle_img_angle = toDegree(Math.atan2(normal_battery_TextCircle_img_width/2, 128));
                  normal_battery_TextCircle_unit_angle = toDegree(Math.atan2(normal_battery_TextCircle_unit_width/2, 128));
                  // alignment = CENTER_H
                  let normal_battery_TextCircle_angleOffset = normal_battery_TextCircle_img_angle * (normal_battery_circle_string.length - 1);
                  normal_battery_TextCircle_angleOffset = normal_battery_TextCircle_angleOffset + (normal_battery_TextCircle_img_angle + normal_battery_TextCircle_unit_angle + 0) / 2;
                  normal_battery_TextCircle_angleOffset = -normal_battery_TextCircle_angleOffset;
                  char_Angle -= normal_battery_TextCircle_angleOffset;
                  // alignment end
                  
                  let firstSymbol = true;
                  let index = 0;
                  for (let char of normal_battery_circle_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 3) break;
                    if (charCode >= 0 && charCode < 10) { 
                      if (!firstSymbol) char_Angle -= normal_battery_TextCircle_img_angle;
                      firstSymbol = false;
                      normal_battery_TextCircle[index].setProperty(hmUI.prop.ANGLE, char_Angle);
                      normal_battery_TextCircle[index].setProperty(hmUI.prop.POS_X, 233 - normal_battery_TextCircle_img_width / 2);
                      normal_battery_TextCircle[index].setProperty(hmUI.prop.SRC, normal_battery_TextCircle_ASCIIARRAY[charCode]);
                      normal_battery_TextCircle[index].setProperty(hmUI.prop.VISIBLE, true);
                      char_Angle -= normal_battery_TextCircle_img_angle;
                      index++;
                    };  // end if digit
                  };  // end char of string
                  char_Angle -= normal_battery_TextCircle_unit_angle;
                  normal_battery_TextCircle_unit.setProperty(hmUI.prop.ANGLE, char_Angle);
                  normal_battery_TextCircle_unit.setProperty(hmUI.prop.VISIBLE, true);
                }  // end isFinite

              };

              console.log('update text circle month_TIME');
              let idle_month_circle_string = parseInt(valueMonth).toString();

              if (screenType == hmSetting.screen_type.AOD) {
                for (var i = 1; i < 2; i++) {  // hide all symbols
                  idle_month_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                let char_Angle = 43;
                if (valueMonth != null && valueMonth != undefined && isFinite(valueMonth) && idle_month_circle_string.length > 0 && idle_month_circle_string.length < 6) {  // display data if it was possible to get it
                  let idle_month_TextCircle_img_angle = 0;
                  let idle_month_TextCircle_dot_img_angle = 0;
                  idle_month_TextCircle_img_angle = toDegree(Math.atan2(idle_month_TextCircle_img_width/2, 170));
                  // alignment = CENTER_H
                  let idle_month_TextCircle_angleOffset = idle_month_TextCircle_img_angle * (idle_month_circle_string.length - 1);
                  idle_month_TextCircle_angleOffset = idle_month_TextCircle_angleOffset + -1 * (idle_month_circle_string.length - 1) / 2;
                  char_Angle -= idle_month_TextCircle_angleOffset;
                  // alignment end
                  
                  let firstSymbol = true;
                  let index = 0;
                  for (let char of idle_month_circle_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 2) break;
                    if (charCode >= 0 && charCode < 10) { 
                      if (!firstSymbol) char_Angle += idle_month_TextCircle_img_angle;
                      firstSymbol = false;
                      idle_month_TextCircle[index].setProperty(hmUI.prop.ANGLE, char_Angle);
                      idle_month_TextCircle[index].setProperty(hmUI.prop.POS_X, 233 - idle_month_TextCircle_img_width / 2);
                      idle_month_TextCircle[index].setProperty(hmUI.prop.SRC, idle_month_TextCircle_ASCIIARRAY[charCode]);
                      idle_month_TextCircle[index].setProperty(hmUI.prop.VISIBLE, true);
                      char_Angle += idle_month_TextCircle_img_angle + -1;
                      index++;
                    };  // end if digit
                  };  // end char of string
                }  // end isFinite

              };

              console.log('update text circle day_TIME');
              let idle_day_circle_string = parseInt(valueDay).toString();

              if (screenType == hmSetting.screen_type.AOD) {
                for (var i = 1; i < 2; i++) {  // hide all symbols
                  idle_day_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                let char_Angle = -42;
                if (valueDay != null && valueDay != undefined && isFinite(valueDay) && idle_day_circle_string.length > 0 && idle_day_circle_string.length < 6) {  // display data if it was possible to get it
                  let idle_day_TextCircle_img_angle = 0;
                  let idle_day_TextCircle_dot_img_angle = 0;
                  idle_day_TextCircle_img_angle = toDegree(Math.atan2(idle_day_TextCircle_img_width/2, 170));
                  // alignment = CENTER_H
                  let idle_day_TextCircle_angleOffset = idle_day_TextCircle_img_angle * (idle_day_circle_string.length - 1);
                  idle_day_TextCircle_angleOffset = idle_day_TextCircle_angleOffset + -1 * (idle_day_circle_string.length - 1) / 2;
                  char_Angle -= idle_day_TextCircle_angleOffset;
                  // alignment end
                  
                  let firstSymbol = true;
                  let index = 0;
                  for (let char of idle_day_circle_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 2) break;
                    if (charCode >= 0 && charCode < 10) { 
                      if (!firstSymbol) char_Angle += idle_day_TextCircle_img_angle;
                      firstSymbol = false;
                      idle_day_TextCircle[index].setProperty(hmUI.prop.ANGLE, char_Angle);
                      idle_day_TextCircle[index].setProperty(hmUI.prop.POS_X, 233 - idle_day_TextCircle_img_width / 2);
                      idle_day_TextCircle[index].setProperty(hmUI.prop.SRC, idle_day_TextCircle_ASCIIARRAY[charCode]);
                      idle_day_TextCircle[index].setProperty(hmUI.prop.VISIBLE, true);
                      char_Angle += idle_day_TextCircle_img_angle + -1;
                      index++;
                    };  // end if digit
                  };  // end char of string
                }  // end isFinite

              };

              console.log('update text circle heart_rate_HEART');
              let idle_heart_rate_circle_string = parseInt(valueHeartRate).toString();

              if (screenType == hmSetting.screen_type.AOD) {
                for (var i = 1; i < 3; i++) {  // hide all symbols
                  idle_heart_rate_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                let char_Angle = 314;
                if (valueHeartRate != null && valueHeartRate != undefined && isFinite(valueHeartRate) && idle_heart_rate_circle_string.length > 0 && idle_heart_rate_circle_string.length < 6) {  // display data if it was possible to get it
                  let idle_heart_rate_TextCircle_img_angle = 0;
                  let idle_heart_rate_TextCircle_dot_img_angle = 0;
                  idle_heart_rate_TextCircle_img_angle = toDegree(Math.atan2(idle_heart_rate_TextCircle_img_width/2, 128));
                  // alignment = CENTER_H
                  let idle_heart_rate_TextCircle_angleOffset = idle_heart_rate_TextCircle_img_angle * (idle_heart_rate_circle_string.length - 1);
                  idle_heart_rate_TextCircle_angleOffset = idle_heart_rate_TextCircle_angleOffset + 1 * (idle_heart_rate_circle_string.length - 1) / 2;
                  idle_heart_rate_TextCircle_angleOffset = -idle_heart_rate_TextCircle_angleOffset;
                  char_Angle -= idle_heart_rate_TextCircle_angleOffset;
                  // alignment end
                  
                  let firstSymbol = true;
                  let index = 0;
                  for (let char of idle_heart_rate_circle_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 3) break;
                    if (charCode >= 0 && charCode < 10) { 
                      if (!firstSymbol) char_Angle -= idle_heart_rate_TextCircle_img_angle;
                      firstSymbol = false;
                      idle_heart_rate_TextCircle[index].setProperty(hmUI.prop.ANGLE, char_Angle);
                      idle_heart_rate_TextCircle[index].setProperty(hmUI.prop.POS_X, 233 - idle_heart_rate_TextCircle_img_width / 2);
                      idle_heart_rate_TextCircle[index].setProperty(hmUI.prop.SRC, idle_heart_rate_TextCircle_ASCIIARRAY[charCode]);
                      idle_heart_rate_TextCircle[index].setProperty(hmUI.prop.VISIBLE, true);
                      char_Angle -= idle_heart_rate_TextCircle_img_angle + 1;
                      index++;
                    };  // end if digit
                  };  // end char of string
                }  // end isFinite

              };

              console.log('update text circle battery_BATTERY');
              let idle_battery_circle_string = parseInt(valueBattery).toString();

              if (screenType == hmSetting.screen_type.AOD) {
                for (var i = 1; i < 3; i++) {  // hide all symbols
                  idle_battery_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                idle_battery_TextCircle_unit.setProperty(hmUI.prop.VISIBLE, false);
                let char_Angle = 46;
                if (valueBattery != null && valueBattery != undefined && isFinite(valueBattery) && idle_battery_circle_string.length > 0 && idle_battery_circle_string.length < 6) {  // display data if it was possible to get it
                  let idle_battery_TextCircle_img_angle = 0;
                  let idle_battery_TextCircle_dot_img_angle = 0;
                  let idle_battery_TextCircle_unit_angle = 0;
                  idle_battery_TextCircle_img_angle = toDegree(Math.atan2(idle_battery_TextCircle_img_width/2, 128));
                  idle_battery_TextCircle_unit_angle = toDegree(Math.atan2(idle_battery_TextCircle_unit_width/2, 128));
                  // alignment = CENTER_H
                  let idle_battery_TextCircle_angleOffset = idle_battery_TextCircle_img_angle * (idle_battery_circle_string.length - 1);
                  idle_battery_TextCircle_angleOffset = idle_battery_TextCircle_angleOffset + (idle_battery_TextCircle_img_angle + idle_battery_TextCircle_unit_angle + 0) / 2;
                  idle_battery_TextCircle_angleOffset = -idle_battery_TextCircle_angleOffset;
                  char_Angle -= idle_battery_TextCircle_angleOffset;
                  // alignment end
                  
                  let firstSymbol = true;
                  let index = 0;
                  for (let char of idle_battery_circle_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 3) break;
                    if (charCode >= 0 && charCode < 10) { 
                      if (!firstSymbol) char_Angle -= idle_battery_TextCircle_img_angle;
                      firstSymbol = false;
                      idle_battery_TextCircle[index].setProperty(hmUI.prop.ANGLE, char_Angle);
                      idle_battery_TextCircle[index].setProperty(hmUI.prop.POS_X, 233 - idle_battery_TextCircle_img_width / 2);
                      idle_battery_TextCircle[index].setProperty(hmUI.prop.SRC, idle_battery_TextCircle_ASCIIARRAY[charCode]);
                      idle_battery_TextCircle[index].setProperty(hmUI.prop.VISIBLE, true);
                      char_Angle -= idle_battery_TextCircle_img_angle;
                      index++;
                    };  // end if digit
                  };  // end char of string
                  char_Angle -= idle_battery_TextCircle_unit_angle;
                  idle_battery_TextCircle_unit.setProperty(hmUI.prop.ANGLE, char_Angle);
                  idle_battery_TextCircle_unit.setProperty(hmUI.prop.VISIBLE, true);
                }  // end isFinite

              };

            };

            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                console.log('resume_call()');
                time_update(true, true);
                text_update();
                if (screenType == hmSetting.screen_type.WATCHFACE) {
                  if (!normal_timerTextUpdate) {
                    normal_timerTextUpdate = timer.createTimer(0, 1000, (function (option) {
                      text_update();
                    }));  // end timer 
                  };  // end timer check
                };  // end screenType

                if (screenType == hmSetting.screen_type.AOD) {
                  if (!idle_timerTextUpdate) {
                    idle_timerTextUpdate = timer.createTimer(0, 1000, (function (option) {
                      text_update();
                    }));  // end timer 
                  };  // end timer check
                };  // end screenType

                checkConnection();
                stopVibro();

              }),
              pause_call: (function () {
                console.log('pause_call()');
                if (normal_timerTextUpdate) {
                  timer.stopTimer(normal_timerTextUpdate);
                  normal_timerTextUpdate = undefined;
                }
                if (idle_timerTextUpdate) {
                  timer.stopTimer(idle_timerTextUpdate);
                  idle_timerTextUpdate = undefined;
                }
                stopVibro();

              }),
            });

                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}