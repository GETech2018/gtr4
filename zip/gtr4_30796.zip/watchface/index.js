﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.0.1
    ** Copyright © CashaCX75. All Rights Reserved
    */

    try {
    (()=>{
        //dynamic modify start

        
        let normal_background_bg = ''
        let normal_pai_weekly_text_img = ''
        let normal_pai_day_text_img = ''
        let normal_stress_icon_img = ''
        let normal_stress_image_progress_img_level = ''
        let normal_heart_rate_text_text_img = ''
        let normal_system_lock_img = ''
        let normal_system_dnd_img = ''
        let normal_system_disconnect_img = ''
        let normal_system_clock_img = ''
        let normal_date_img_date_week_img = ''
        let normal_date_img_date_year = ''
        let normal_date_img_date_month = ''
        let normal_date_img_date_day = ''
        let normal_moon_image_progress_img_level = ''
        let normal_city_name_text = ''
        let normal_temperature_high_text_img = ''
        let normal_temperature_low_text_img = ''
        let normal_temperature_current_text_img = ''
        let normal_weather_image_progress_img_level = ''
        let normal_distance_text_text_img = ''
        let normal_calorie_current_text_img = ''
        let normal_step_current_text_img = ''
        let normal_battery_text_text_img = ''
        let normal_battery_image_progress_img_level = ''
        let normal_sun_current_text_img = ''
        let normal_digital_clock_img_time_AmPm = ''
        let normal_digital_clock_img_time = ''
        let normal_stopwatch_jumpable_img_click = ''
        let normal_countdown_jumpable_img_click = ''
        let normal_sleep_jumpable_img_click = ''
        let normal_alarm_jumpable_img_click = ''
        let normal_sunrise_jumpable_img_click = ''
        let normal_temperature_jumpable_img_click = ''
        let normal_stress_jumpable_img_click = ''
        let normal_pai_jumpable_img_click = ''
        let normal_heart_jumpable_img_click = ''
        let normal_step_jumpable_img_click = ''
	let img = ''  // block name with image

        let prefix_img = 'Image_'  // prefix image (name without sequence number)
        let img_index = 1  // image number
        let img_count = 10  // number of images


        //dynamic modify end
        const e = __$$hmAppManager$$__.currentApp;
        const o = e.current
          , {px: i} = (new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(e,o)),
        e.__globals__)
          , n = Logger.getLogger("watchface6");
        o.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
            img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 466,
              h: 466,
              src: prefix_img + parseInt(img_index) + '.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
   

            normal_pai_weekly_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 156,
              y: 81,
              font_array: ["z_0000.png","z_0001.png","z_0002.png","z_0003.png","z_0004.png","z_0005.png","z_0006.png","z_0007.png","z_0008.png","z_0009.png"],
              padding: false,
              h_space: -2,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.PAI_WEEKLY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_pai_day_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 106,
              y: 81,
              font_array: ["z_0000.png","z_0001.png","z_0002.png","z_0003.png","z_0004.png","z_0005.png","z_0006.png","z_0007.png","z_0008.png","z_0009.png"],
              padding: false,
              h_space: -2,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.PAI_DAILY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_stress_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 221,
              y: 69,
              src: 'Stress.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_stress_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 221,
              y: 69,
              image_array: ["Stress_0000.png","Stress_0001.png","Stress_0002.png","Stress_0003.png","Stress_0004.png","Stress_0005.png","Stress_0006.png","Stress_0007.png","Stress_0008.png","Stress_0009.png"],
              image_length: 10,
              type: hmUI.data_type.STRESS,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 175,
              y: 264,
              font_array: ["Puls_0000.png","Puls_0001.png","Puls_0002.png","Puls_0003.png","Puls_0004.png","Puls_0005.png","Puls_0006.png","Puls_0007.png","Puls_0008.png","Puls_0009.png"],
              padding: false,
              h_space: -2,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_lock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 268,
              y: 6,
              src: 'Schloss.png',
              type: hmUI.system_status.LOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_dnd_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 177,
              y: 6,
              src: 'DND.png',
              type: hmUI.system_status.DISTURB,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 203,
              y: 2,
              src: 'Bluetooth.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 235,
              y: 4,
              src: 'Wecker.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 176,
              y: 216,
              week_en: ["Tag_0000.png","Tag_0001.png","Tag_0002.png","Tag_0003.png","Tag_0004.png","Tag_0005.png","Tag_0006.png"],
              week_tc: ["Tag_0000.png","Tag_0001.png","Tag_0002.png","Tag_0003.png","Tag_0004.png","Tag_0005.png","Tag_0006.png"],
              week_sc: ["Tag_0000.png","Tag_0001.png","Tag_0002.png","Tag_0003.png","Tag_0004.png","Tag_0005.png","Tag_0006.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_year = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              year_startX: 101,
              year_startY: 219,
              year_sc_array: ["z_0000.png","z_0001.png","z_0002.png","z_0003.png","z_0004.png","z_0005.png","z_0006.png","z_0007.png","z_0008.png","z_0009.png"],
              year_tc_array: ["z_0000.png","z_0001.png","z_0002.png","z_0003.png","z_0004.png","z_0005.png","z_0006.png","z_0007.png","z_0008.png","z_0009.png"],
              year_en_array: ["z_0000.png","z_0001.png","z_0002.png","z_0003.png","z_0004.png","z_0005.png","z_0006.png","z_0007.png","z_0008.png","z_0009.png"],
              year_zero: 1,
              year_space: -2,
              year_align: hmUI.align.LEFT,
              year_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_month = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 63,
              month_startY: 219,
              month_sc_array: ["z_0000.png","z_0001.png","z_0002.png","z_0003.png","z_0004.png","z_0005.png","z_0006.png","z_0007.png","z_0008.png","z_0009.png"],
              month_tc_array: ["z_0000.png","z_0001.png","z_0002.png","z_0003.png","z_0004.png","z_0005.png","z_0006.png","z_0007.png","z_0008.png","z_0009.png"],
              month_en_array: ["z_0000.png","z_0001.png","z_0002.png","z_0003.png","z_0004.png","z_0005.png","z_0006.png","z_0007.png","z_0008.png","z_0009.png"],
              month_zero: 1,
              month_space: -2,
              month_unit_sc: 'z_Punkt.png',
              month_unit_tc: 'z_Punkt.png',
              month_unit_en: 'z_Punkt.png',
              month_align: hmUI.align.LEFT,
              month_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 25,
              day_startY: 219,
              day_sc_array: ["z_0000.png","z_0001.png","z_0002.png","z_0003.png","z_0004.png","z_0005.png","z_0006.png","z_0007.png","z_0008.png","z_0009.png"],
              day_tc_array: ["z_0000.png","z_0001.png","z_0002.png","z_0003.png","z_0004.png","z_0005.png","z_0006.png","z_0007.png","z_0008.png","z_0009.png"],
              day_en_array: ["z_0000.png","z_0001.png","z_0002.png","z_0003.png","z_0004.png","z_0005.png","z_0006.png","z_0007.png","z_0008.png","z_0009.png"],
              day_zero: 1,
              day_space: -2,
              day_unit_sc: 'z_Punkt.png',
              day_unit_tc: 'z_Punkt.png',
              day_unit_en: 'z_Punkt.png',
              day_align: hmUI.align.LEFT,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_moon_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 255,
              y: 157,
              image_array: ["moon_30_01.png","moon_30_02.png","moon_30_03.png","moon_30_04.png","moon_30_05.png","moon_30_06.png","moon_30_07.png","moon_30_08.png","moon_30_09.png","moon_30_10.png","moon_30_11.png","moon_30_12.png","moon_30_13.png","moon_30_14.png","moon_30_15.png","moon_30_16.png","moon_30_17.png","moon_30_18.png","moon_30_19.png","moon_30_20.png","moon_30_21.png","moon_30_22.png","moon_30_23.png","moon_30_24.png","moon_30_25.png","moon_30_26.png","moon_30_27.png","moon_30_28.png","moon_30_29.png","moon_30_30.png"],
              image_length: 30,
              type: hmUI.data_type.MOON,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_city_name_text = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 248,
              y: 294,
              w: 200,
              h: 30,
              text_size: 18,
              char_space: 0,
              line_space: 0,
              color: 0xFFFFFFFF,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_high_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 389,
              y: 280,
              font_array: ["z_0000.png","z_0001.png","z_0002.png","z_0003.png","z_0004.png","z_0005.png","z_0006.png","z_0007.png","z_0008.png","z_0009.png"],
              padding: false,
              h_space: -2,
              unit_sc: 'z_Grad.png',
              unit_tc: 'z_Grad.png',
              unit_en: 'z_Grad.png',
              negative_image: 'z_Minus.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_HIGH,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_low_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 332,
              y: 280,
              font_array: ["z_0000.png","z_0001.png","z_0002.png","z_0003.png","z_0004.png","z_0005.png","z_0006.png","z_0007.png","z_0008.png","z_0009.png"],
              padding: false,
              h_space: -2,
              unit_sc: 'z_Grad.png',
              unit_tc: 'z_Grad.png',
              unit_en: 'z_Grad.png',
              negative_image: 'z_Minus.png',
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.WEATHER_LOW,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 227,
              y: 244,
              font_array: ["Zeit_0000.png","Zeit_0001.png","Zeit_0002.png","Zeit_0003.png","Zeit_0004.png","Zeit_0005.png","Zeit_0006.png","Zeit_0007.png","Zeit_0008.png","Zeit_0009.png"],
              padding: false,
              h_space: -2,
              unit_sc: 'Zeit_Grad.png',
              unit_tc: 'Zeit_Grad.png',
              unit_en: 'Zeit_Grad.png',
              negative_image: 'Zeit_Minus.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 350,
              y: 186,
              image_array: ["0124.png","0125.png","0126.png","0127.png","0128.png","0129.png","0130.png","0131.png","0132.png","0133.png","0134.png","0135.png","0136.png","0137.png","0138.png","0139.png","0140.png","0141.png","0142.png","0143.png","0144.png","0145.png","0146.png","0147.png","0148.png","0149.png","0150.png","0151.png","0152.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_distance_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 279,
              y: 372,
              font_array: ["z_0000.png","z_0001.png","z_0002.png","z_0003.png","z_0004.png","z_0005.png","z_0006.png","z_0007.png","z_0008.png","z_0009.png"],
              padding: false,
              h_space: -2,
              dot_image: 'z_Punkt.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.DISTANCE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_calorie_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 206,
              y: 372,
              font_array: ["z_0000.png","z_0001.png","z_0002.png","z_0003.png","z_0004.png","z_0005.png","z_0006.png","z_0007.png","z_0008.png","z_0009.png"],
              padding: false,
              h_space: -2,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 116,
              y: 372,
              font_array: ["z_0000.png","z_0001.png","z_0002.png","z_0003.png","z_0004.png","z_0005.png","z_0006.png","z_0007.png","z_0008.png","z_0009.png"],
              padding: false,
              h_space: -2,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 50,
              y: 266,
              font_array: ["z_0000.png","z_0001.png","z_0002.png","z_0003.png","z_0004.png","z_0005.png","z_0006.png","z_0007.png","z_0008.png","z_0009.png"],
              padding: false,
              h_space: -2,
              unit_sc: 'z_Prozent.png',
              unit_tc: 'z_Prozent.png',
              unit_en: 'z_Prozent.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 26,
              y: 298,
              image_array: ["Batt_0001.png","Batt_0002.png","Batt_0003.png","Batt_0004.png","Batt_0005.png","Batt_0006.png","Batt_0007.png","Batt_0008.png","Batt_0009.png","Batt_0010.png"],
              image_length: 10,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sun_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 286,
              y: 81,
              font_array: ["z_0000.png","z_0001.png","z_0002.png","z_0003.png","z_0004.png","z_0005.png","z_0006.png","z_0007.png","z_0008.png","z_0009.png"],
              padding: false,
              h_space: -2,
              dot_image: 'z_Doppelpunkt.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.SUN_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time_AmPm = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              am_x: 190,
              am_y: 189,
              am_sc_path: 'AM.png',
              am_en_path: 'AM.png',
              pm_x: 193,
              pm_y: 189,
              pm_sc_path: 'PM.png',
              pm_en_path: 'PM.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 20,
              hour_startY: 150,
              hour_array: ["Zeit_0000.png","Zeit_0001.png","Zeit_0002.png","Zeit_0003.png","Zeit_0004.png","Zeit_0005.png","Zeit_0006.png","Zeit_0007.png","Zeit_0008.png","Zeit_0009.png"],
              hour_zero: 1,
              hour_space: -2,
              hour_unit_sc: 'Zeit_Doppelpunkt.png',
              hour_unit_tc: 'Zeit_Doppelpunkt.png',
              hour_unit_en: 'Zeit_Doppelpunkt.png',
              hour_align: hmUI.align.LEFT,

              minute_startX: 0,
              minute_startY: 0,
              minute_array: ["Zeit_0000.png","Zeit_0001.png","Zeit_0002.png","Zeit_0003.png","Zeit_0004.png","Zeit_0005.png","Zeit_0006.png","Zeit_0007.png","Zeit_0008.png","Zeit_0009.png"],
              minute_zero: 1,
              minute_space: -2,
              minute_follow: 1,
              minute_align: hmUI.align.LEFT,

              second_startX: 193,
              second_startY: 155,
              second_array: ["z_0000.png","z_0001.png","z_0002.png","z_0003.png","z_0004.png","z_0005.png","z_0006.png","z_0007.png","z_0008.png","z_0009.png"],
              second_zero: 1,
              second_space: -2,
              second_follow: 0,
              second_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });



            normal_stopwatch_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 112,
              y: 146,
              w: 84,
              h: 66,
              src: 'leer.png',
              type: hmUI.data_type.STOP_WATCH,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_countdown_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 18,
              y: 146,
              w: 83,
              h: 66,
              src: 'leer.png',
              type: hmUI.data_type.COUNT_DOWN,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sleep_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 240,
              y: 151,
              w: 86,
              h: 77,
              src: 'leer.png',
              type: hmUI.data_type.SLEEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_alarm_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 17,
              y: 212,
              w: 214,
              h: 36,
              src: 'leer.png',
              type: hmUI.data_type.ALARM_CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sunrise_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 274,
              y: 38,
              w: 91,
              h: 100,
              src: 'leer.png',
              type: hmUI.data_type.SUN_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 240,
              y: 243,
              w: 210,
              h: 78,
              src: 'leer.png',
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_stress_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 207,
              y: 38,
              w: 61,
              h: 100,
              src: 'leer.png',
              type: hmUI.data_type.STRESS,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_pai_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 97,
              y: 38,
              w: 110,
              h: 100,
              src: 'leer.png',
              type: hmUI.data_type.PAI_WEEKLY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 125,
              y: 253,
              w: 107,
              h: 68,
              src: 'leer.png',
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 100,
              y: 330,
              w: 100,
              h: 100,
              src: 'leer.png',
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // Button to switch images. This block should be after all blocks with display elements.
            hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 15,  // x coordinate of the button
              y: 254,  // y coordinate of the button
              text: '',
              w: 100,  // button width
              h: 67,  // button height
              normal_src: 'leer.png',  // transparent image
              press_src: 'leer.png',  // transparent image
              show_level: hmUI.show_level.ONLY_NORMAL,
              click_func: () => {
                img_index++;
                if(img_index > img_count) img_index = 1;
                hmUI.showToast({text: 'Hintergrund ' + parseInt(img_index) });  // Remove if you do not want to display a message with the number of the selected image
                img.setProperty(hmUI.prop.SRC, prefix_img + parseInt(img_index) + '.png');
              }
            });

            function scale_call() {

              console.log('Wearther city name');
              const weatherSensor = hmSensor.createSensor(hmSensor.id.WEATHER);
              const weatherData = weatherSensor.getForecastWeather();
              normal_city_name_text.setProperty(hmUI.prop.TEXT, weatherData.cityName);

            };

            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                scale_call();
              }),
            });

                //dynamic modify end
            },
            onInit() {
                n.log("index page.js on init invoke")
            },
            build() {
                this.init_view(),
                n.log("index page.js on ready invoke")
            },
            onDestroy() {
                n.log("index page.js on destroy invoke")
            }
        })
    }
    )()
} catch (e) {
    console.log("Mini Program Error", e),
    e && e.stack && e.stack.split(/\n/).forEach((e=>console.log("error stack", e)))
}
