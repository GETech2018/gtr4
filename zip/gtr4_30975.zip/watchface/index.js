﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.0.1
    ** Copyright © CashaCX75. All Rights Reserved
    */

    try {
    (()=>{
        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_stress_text_text_img = ''
        let normal_step_current_text_img = ''
        let normal_heart_rate_text_text_img = ''
        let normal_uvi_text_text_img = ''
        let normal_humidity_text_text_img = ''
        let normal_date_img_date_week_img = ''
        let normal_system_lock_img = ''
        let normal_system_dnd_img = ''
        let normal_system_disconnect_img = ''
        let normal_system_clock_img = ''
        let normal_temperature_current_text_img = ''
        let normal_date_img_date_month = ''
        let normal_date_img_date_day = ''
        let normal_battery_text_text_img = ''
        let normal_battery_image_progress_img_level = ''
        let normal_digital_clock_img_time = ''
        let idle_background_bg = ''
        let idle_date_img_date_week_img = ''
        let idle_system_lock_img = ''
        let idle_system_dnd_img = ''
        let idle_system_disconnect_img = ''
        let idle_system_clock_img = ''
        let idle_date_img_date_month = ''
        let idle_date_img_date_day = ''
        let idle_battery_text_text_img = ''
        let idle_battery_image_progress_img_level = ''
        let idle_digital_clock_img_time = ''


        //dynamic modify end
        const e = __$$hmAppManager$$__.currentApp;
        const o = e.current
          , {px: i} = (new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(e,o)),
        e.__globals__)
          , n = Logger.getLogger("watchface6");
        o.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 466,
              h: 466,
              src: 'GTR4_SplitFace_V2.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_stress_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 82,
              y: 344,
              font_array: ["CN_Small_Black_0.png","CN_Small_Black_1.png","CN_Small_Black_2.png","CN_Small_Black_3.png","CN_Small_Black_4.png","CN_Small_Black_5.png","CN_Small_Black_6.png","CN_Small_Black_7.png","CN_Small_Black_8.png","CN_Small_Black_9.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.STRESS,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 50,
              y: 283,
              font_array: ["CN_Small_Black_0.png","CN_Small_Black_1.png","CN_Small_Black_2.png","CN_Small_Black_3.png","CN_Small_Black_4.png","CN_Small_Black_5.png","CN_Small_Black_6.png","CN_Small_Black_7.png","CN_Small_Black_8.png","CN_Small_Black_9.png"],
              padding: false,
              h_space: 2,
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 77,
              y: 313,
              font_array: ["CN_Small_Black_0.png","CN_Small_Black_1.png","CN_Small_Black_2.png","CN_Small_Black_3.png","CN_Small_Black_4.png","CN_Small_Black_5.png","CN_Small_Black_6.png","CN_Small_Black_7.png","CN_Small_Black_8.png","CN_Small_Black_9.png"],
              padding: false,
              h_space: 2,
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_uvi_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 360,
              y: 154,
              font_array: ["CN_Small_White_0.png","CN_Small_White_1.png","CN_Small_White_2.png","CN_Small_White_3.png","CN_Small_White_4.png","CN_Small_White_5.png","CN_Small_White_6.png","CN_Small_White_7.png","CN_Small_White_8.png","CN_Small_White_9.png"],
              padding: false,
              h_space: 2,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.UVI,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_humidity_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 346,
              y: 180,
              font_array: ["CN_Small_White_0.png","CN_Small_White_1.png","CN_Small_White_2.png","CN_Small_White_3.png","CN_Small_White_4.png","CN_Small_White_5.png","CN_Small_White_6.png","CN_Small_White_7.png","CN_Small_White_8.png","CN_Small_White_9.png"],
              padding: false,
              h_space: 2,
              unit_sc: 'CN_Small_White_Perc.png',
              unit_tc: 'CN_Small_White_Perc.png',
              unit_en: 'CN_Small_White_Perc.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.HUMIDITY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 140,
              y: 73,
              week_en: ["WD_0.png","WD_1.png","WD_2.png","WD_3.png","WD_4.png","WD_5.png","WD_6.png"],
              week_tc: ["WD_0.png","WD_1.png","WD_2.png","WD_3.png","WD_4.png","WD_5.png","WD_6.png"],
              week_sc: ["WD_0.png","WD_1.png","WD_2.png","WD_3.png","WD_4.png","WD_5.png","WD_6.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_lock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 363,
              y: 238,
              src: 'Locked_Black.png',
              type: hmUI.system_status.LOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_dnd_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 259,
              y: 240,
              src: 'DND_Black.png',
              type: hmUI.system_status.DISTURB,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 212,
              y: 240,
              src: 'BlueT_Black.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 309,
              y: 240,
              src: 'Alarm_Black.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 205,
              y: 153,
              font_array: ["CN_Med_White_0.png","CN_Med_White_1.png","CN_Med_White_2.png","CN_Med_White_3.png","CN_Med_White_4.png","CN_Med_White_5.png","CN_Med_White_6.png","CN_Med_White_7.png","CN_Med_White_8.png","CN_Med_White_9.png"],
              padding: false,
              h_space: 6,
              unit_sc: 'CN_Med_White_Deg_Deg.png',
              unit_tc: 'CN_Med_White_Deg_Deg.png',
              unit_en: 'CN_Med_White_Deg_Deg.png',
              negative_image: 'CN_Med_White_Minus.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_month = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 266,
              month_startY: 68,
              month_sc_array: ["CN_Med_White_0.png","CN_Med_White_1.png","CN_Med_White_2.png","CN_Med_White_3.png","CN_Med_White_4.png","CN_Med_White_5.png","CN_Med_White_6.png","CN_Med_White_7.png","CN_Med_White_8.png","CN_Med_White_9.png"],
              month_tc_array: ["CN_Med_White_0.png","CN_Med_White_1.png","CN_Med_White_2.png","CN_Med_White_3.png","CN_Med_White_4.png","CN_Med_White_5.png","CN_Med_White_6.png","CN_Med_White_7.png","CN_Med_White_8.png","CN_Med_White_9.png"],
              month_en_array: ["CN_Med_White_0.png","CN_Med_White_1.png","CN_Med_White_2.png","CN_Med_White_3.png","CN_Med_White_4.png","CN_Med_White_5.png","CN_Med_White_6.png","CN_Med_White_7.png","CN_Med_White_8.png","CN_Med_White_9.png"],
              month_zero: 1,
              month_space: 5,
              month_align: hmUI.align.LEFT,
              month_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 181,
              day_startY: 68,
              day_sc_array: ["CN_Med_White_0.png","CN_Med_White_1.png","CN_Med_White_2.png","CN_Med_White_3.png","CN_Med_White_4.png","CN_Med_White_5.png","CN_Med_White_6.png","CN_Med_White_7.png","CN_Med_White_8.png","CN_Med_White_9.png"],
              day_tc_array: ["CN_Med_White_0.png","CN_Med_White_1.png","CN_Med_White_2.png","CN_Med_White_3.png","CN_Med_White_4.png","CN_Med_White_5.png","CN_Med_White_6.png","CN_Med_White_7.png","CN_Med_White_8.png","CN_Med_White_9.png"],
              day_en_array: ["CN_Med_White_0.png","CN_Med_White_1.png","CN_Med_White_2.png","CN_Med_White_3.png","CN_Med_White_4.png","CN_Med_White_5.png","CN_Med_White_6.png","CN_Med_White_7.png","CN_Med_White_8.png","CN_Med_White_9.png"],
              day_zero: 1,
              day_space: 5,
              day_unit_sc: 'CN_Med_White_Dot.png',
              day_unit_tc: 'CN_Med_White_Dot.png',
              day_unit_en: 'CN_Med_White_Dot.png',
              day_align: hmUI.align.LEFT,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 102,
              y: 182,
              font_array: ["CN_Small_White_0.png","CN_Small_White_1.png","CN_Small_White_2.png","CN_Small_White_3.png","CN_Small_White_4.png","CN_Small_White_5.png","CN_Small_White_6.png","CN_Small_White_7.png","CN_Small_White_8.png","CN_Small_White_9.png"],
              padding: false,
              h_space: 2,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 61,
              y: 131,
              image_array: ["Batt_LB_Cir_1.png","Batt_LB_Cir_2.png","Batt_LB_Cir_3.png","Batt_LB_Cir_4.png","Batt_LB_Cir_5.png","Batt_LB_Cir_6.png","Batt_LB_Cir_7.png","Batt_LB_Cir_8.png","Batt_LB_Cir_9.png","Batt_LB_Cir_10.png","Batt_LB_Cir_11.png","Batt_LB_Cir_12.png"],
              image_length: 12,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 176,
              hour_startY: 290,
              hour_array: ["CN_Big_Black_0.png","CN_Big_Black_1.png","CN_Big_Black_2.png","CN_Big_Black_3.png","CN_Big_Black_4.png","CN_Big_Black_5.png","CN_Big_Black_6.png","CN_Big_Black_7.png","CN_Big_Black_8.png","CN_Big_Black_9.png"],
              hour_zero: 1,
              hour_space: 5,
              hour_unit_sc: 'CN_Big_Black_DDot.png',
              hour_unit_tc: 'CN_Big_Black_DDot.png',
              hour_unit_en: 'CN_Big_Black_DDot.png',
              hour_align: hmUI.align.CENTER_H,

              minute_startX: 0,
              minute_startY: 0,
              minute_array: ["CN_Big_Black_0.png","CN_Big_Black_1.png","CN_Big_Black_2.png","CN_Big_Black_3.png","CN_Big_Black_4.png","CN_Big_Black_5.png","CN_Big_Black_6.png","CN_Big_Black_7.png","CN_Big_Black_8.png","CN_Big_Black_9.png"],
              minute_zero: 1,
              minute_space: 5,
              minute_follow: 1,
              minute_align: hmUI.align.LEFT,

              second_startX: 211,
              second_startY: 382,
              second_array: ["CN_Med_Black_0.png","CN_Med_Black_1.png","CN_Med_Black_2.png","CN_Med_Black_3.png","CN_Med_Black_4.png","CN_Med_Black_5.png","CN_Med_Black_6.png","CN_Med_Black_7.png","CN_Med_Black_8.png","CN_Med_Black_9.png"],
              second_zero: 1,
              second_space: 0,
              second_follow: 0,
              second_align: hmUI.align.CENTER_H,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            idle_background_bg = hmUI.createWidget(hmUI.widget.FILL_RECT, {
              x: 0,
              y: 0,
              w: 466,
              h: 466,
              color: '0xFF000000',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 140,
              y: 73,
              week_en: ["WD_0.png","WD_1.png","WD_2.png","WD_3.png","WD_4.png","WD_5.png","WD_6.png"],
              week_tc: ["WD_0.png","WD_1.png","WD_2.png","WD_3.png","WD_4.png","WD_5.png","WD_6.png"],
              week_sc: ["WD_0.png","WD_1.png","WD_2.png","WD_3.png","WD_4.png","WD_5.png","WD_6.png"],
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_system_lock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 363,
              y: 238,
              src: 'Locked_White.png',
              type: hmUI.system_status.LOCK,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_system_dnd_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 259,
              y: 240,
              src: 'DND_White.png',
              type: hmUI.system_status.DISTURB,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 212,
              y: 240,
              src: 'BlueT_White.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 309,
              y: 240,
              src: 'Alarm_white.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_month = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 266,
              month_startY: 68,
              month_sc_array: ["CN_Med_White_0.png","CN_Med_White_1.png","CN_Med_White_2.png","CN_Med_White_3.png","CN_Med_White_4.png","CN_Med_White_5.png","CN_Med_White_6.png","CN_Med_White_7.png","CN_Med_White_8.png","CN_Med_White_9.png"],
              month_tc_array: ["CN_Med_White_0.png","CN_Med_White_1.png","CN_Med_White_2.png","CN_Med_White_3.png","CN_Med_White_4.png","CN_Med_White_5.png","CN_Med_White_6.png","CN_Med_White_7.png","CN_Med_White_8.png","CN_Med_White_9.png"],
              month_en_array: ["CN_Med_White_0.png","CN_Med_White_1.png","CN_Med_White_2.png","CN_Med_White_3.png","CN_Med_White_4.png","CN_Med_White_5.png","CN_Med_White_6.png","CN_Med_White_7.png","CN_Med_White_8.png","CN_Med_White_9.png"],
              month_zero: 1,
              month_space: 5,
              month_align: hmUI.align.LEFT,
              month_is_character: false,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 181,
              day_startY: 68,
              day_sc_array: ["CN_Med_White_0.png","CN_Med_White_1.png","CN_Med_White_2.png","CN_Med_White_3.png","CN_Med_White_4.png","CN_Med_White_5.png","CN_Med_White_6.png","CN_Med_White_7.png","CN_Med_White_8.png","CN_Med_White_9.png"],
              day_tc_array: ["CN_Med_White_0.png","CN_Med_White_1.png","CN_Med_White_2.png","CN_Med_White_3.png","CN_Med_White_4.png","CN_Med_White_5.png","CN_Med_White_6.png","CN_Med_White_7.png","CN_Med_White_8.png","CN_Med_White_9.png"],
              day_en_array: ["CN_Med_White_0.png","CN_Med_White_1.png","CN_Med_White_2.png","CN_Med_White_3.png","CN_Med_White_4.png","CN_Med_White_5.png","CN_Med_White_6.png","CN_Med_White_7.png","CN_Med_White_8.png","CN_Med_White_9.png"],
              day_zero: 1,
              day_space: 5,
              day_unit_sc: 'CN_Med_White_Dot.png',
              day_unit_tc: 'CN_Med_White_Dot.png',
              day_unit_en: 'CN_Med_White_Dot.png',
              day_align: hmUI.align.LEFT,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 102,
              y: 182,
              font_array: ["CN_Small_White_0.png","CN_Small_White_1.png","CN_Small_White_2.png","CN_Small_White_3.png","CN_Small_White_4.png","CN_Small_White_5.png","CN_Small_White_6.png","CN_Small_White_7.png","CN_Small_White_8.png","CN_Small_White_9.png"],
              padding: false,
              h_space: 2,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_battery_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 61,
              y: 131,
              image_array: ["Batt_LB_Cir_1.png","Batt_LB_Cir_2.png","Batt_LB_Cir_3.png","Batt_LB_Cir_4.png","Batt_LB_Cir_5.png","Batt_LB_Cir_6.png","Batt_LB_Cir_7.png","Batt_LB_Cir_8.png","Batt_LB_Cir_9.png","Batt_LB_Cir_10.png","Batt_LB_Cir_11.png","Batt_LB_Cir_12.png"],
              image_length: 12,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 176,
              hour_startY: 290,
              hour_array: ["CN_Big_White_0.png","CN_Big_White_1.png","CN_Big_White_2.png","CN_Big_White_3.png","CN_Big_White_4.png","CN_Big_White_5.png","CN_Big_White_6.png","CN_Big_White_7.png","CN_Big_White_8.png","CN_Big_White_9.png"],
              hour_zero: 1,
              hour_space: 5,
              hour_unit_sc: 'CN_Big_White_DDot.png',
              hour_unit_tc: 'CN_Big_White_DDot.png',
              hour_unit_en: 'CN_Big_White_DDot.png',
              hour_align: hmUI.align.CENTER_H,

              minute_startX: 0,
              minute_startY: 0,
              minute_array: ["CN_Big_White_0.png","CN_Big_White_1.png","CN_Big_White_2.png","CN_Big_White_3.png","CN_Big_White_4.png","CN_Big_White_5.png","CN_Big_White_6.png","CN_Big_White_7.png","CN_Big_White_8.png","CN_Big_White_9.png"],
              minute_zero: 1,
              minute_space: 5,
              minute_follow: 1,
              minute_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_AOD,
            });
            
            // disconnectAlert = hmUI.createWidget(hmUI.widget.DisconnectAlert, {
              // disconneсnt_vibrate_type: 9,
              // conneсnt_vibrate_type: 9,
            // });

            // vibration when connecting or disconnecting

            function checkConnection() {
              hmBle.removeListener;
              hmBle.addListener(function (status) {
                if(!status) {
                  vibro(9);
                }
                if(status) {
                  vibro(9);
                }
              });
            }

            // end vibration when connecting or disconnecting
            // vibrate function

            const vibrate = hmSensor.createSensor(hmSensor.id.VIBRATE);
            let timer_StopVibrate = null;


            function vibro(scene = 25) {
              let stopDelay = 50;
              stopVibro();
              vibrate.scene = scene;
              if(scene < 23 || scene > 25) stopDelay = 1300;
              vibrate.start();
              timer_StopVibrate = timer.createTimer(stopDelay, 3000, stopVibro, {});
            }

            function stopVibro(){
              vibrate.stop();
              if(timer_StopVibrate) timer.stopTimer(timer_StopVibrate);
            }

            // end vibrate function

            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                checkConnection();
                stopVibro();

              }),
              pause_call: (function () {
                stopVibro();

              }),
            });

                //dynamic modify end
            },
            onInit() {
                n.log("index page.js on init invoke")
            },
            build() {
                this.init_view(),
                n.log("index page.js on ready invoke")
            },
            onDestroy() {
                n.log("index page.js on destroy invoke")
            }
        })
    }
    )()
} catch (e) {
    console.log("Mini Program Error", e),
    e && e.stack && e.stack.split(/\n/).forEach((e=>console.log("error stack", e)))
}
