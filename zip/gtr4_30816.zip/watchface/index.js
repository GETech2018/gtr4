/*
** Facemaker bundle tool v0.0.2
* *huamiOS watchface js version v2.0.1
* *Copyright © Huami. All Rights Reserved
*/


try {
	(() => {
		var __$$app$$__ = __$$hmAppManager$$__.currentApp;
		var __$$module$$__ = __$$app$$__.current;

		//drink is a name,can modify
		var h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__), 'drink');

		'use strict';

		//dynamic modify start
		let normal_background_bg_img0 = '';
		let normal_background_bg_img1 = '';
		let normal_background_bg_img2 = '';
		let normal_digital_clock_img_hour_high4 = '';
		let normal_digital_clock_img_hour_high4_array = ['0005.png','0006.png','0007.png'];
		let normal_digital_clock_img_hour_low5 = '';
		let normal_digital_clock_img_hour_low5_array = ['0008.png','0009.png','0010.png','0011.png','0012.png','0013.png','0014.png','0015.png','0016.png','0017.png'];
		let normal_digital_clock_img_minute_high6 = '';
		let normal_digital_clock_img_minute_high6_array = ['0018.png','0019.png','0020.png','0021.png','0022.png','0023.png'];
		let normal_digital_clock_img_minute_low7 = '';
		let normal_digital_clock_img_minute_low7_array = ['0024.png','0025.png','0026.png','0027.png','0028.png','0029.png','0030.png','0031.png','0032.png','0033.png'];
		let normal_background_bg_img8 = '';
		let normal_date_img_date_week_img10 = '';
		let normal_date_current_date_monthday11 = '';
		let normal_date_current_date_month12 = '';
		let normal_background_bg_img13 = '';
		let normal_date_current_date_year14 = '';
		let normal_background_bg_img15 = '';
		let normal_weather_image_progress_img_level17 = '';
		let normal_temperature_current_text_img18 = '';
		let normal_background_bg_img19 = '';
		let normal_wind_current_text_img21 = '';
		let normal_background_bg_img22 = '';
		let normal_blood_oxygen_text_img24 = '';
		let normal_background_bg_img25 = '';
		let normal_heart_current_text_img27 = '';
		let normal_background_bg_img28 = '';
		let normal_calories_current_text_img30 = '';
		let normal_background_bg_img31 = '';
		let normal_battery_current_text_img33 = '';
		let normal_background_bg_img34 = '';
		let normal_step_current_text_img36 = '';
		let normal_background_bg_img37 = '';
		let normal_distance_current_text_img39 = '';
		let normal_background_bg_img40 = '';
		let normal_alarm_status42 = '';
		//dynamic modify end

		//not required
		const logger = DeviceRuntimeCore.HmLogger.getLogger("yeguang");

		__$$module$$__.module = DeviceRuntimeCore.WatchFace({
			init_view() {

				let screenType = hmSetting.getScreenType();

				normal_background_bg_img0 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 234,
					y: 237,
					w: 202,
					h: 180,
					src: '0002.png',
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_background_bg_img1 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 30,
					y: 237,
					w: 202,
					h: 180,
					src: '0003.png',
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_background_bg_img2 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 42,
					y: 90,
					w: 382,
					h: 3,
					src: '0004.png',
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				const timeSensor = hmSensor.createSensor(hmSensor.id.TIME);
				timeSensor.addEventListener(hmSensor.event.CHANGE, function() {
					updateImageCombos();
				});

				normal_digital_clock_img_hour_high4 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 41,
					y: 98,
					w: 41,
					h: 98,
					src: '0007.png',
					show_level: hmUI.show_level.ONLY_NORMAL,
				})

				normal_digital_clock_img_hour_low5 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 131,
					y: 98,
					w: 131,
					h: 98,
					src: '0017.png',
					show_level: hmUI.show_level.ONLY_NORMAL,
				})

				normal_digital_clock_img_minute_high6 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 244,
					y: 98,
					w: 244,
					h: 98,
					src: '0023.png',
					show_level: hmUI.show_level.ONLY_NORMAL,
				})

				normal_digital_clock_img_minute_low7 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 335,
					y: 98,
					w: 335,
					h: 98,
					src: '0033.png',
					show_level: hmUI.show_level.ONLY_NORMAL,
				})

				normal_background_bg_img8 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 220,
					y: 120,
					w: 27,
					h: 92,
					src: '0034.png',
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_date_img_date_week_img10 = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
					x: 195,
					y: 0,
					week_en: ["0035.png","0036.png","0037.png","0038.png","0039.png","0040.png","0041.png"],
					week_tc: ["0035.png","0036.png","0037.png","0038.png","0039.png","0040.png","0041.png"],
					week_sc: ["0035.png","0036.png","0037.png","0038.png","0039.png","0040.png","0041.png"],
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_date_current_date_monthday11 = hmUI.createWidget(hmUI.widget.IMG_DATE, {
					day_startX: 93,
					day_startY: 47,
					day_sc_array: ["0042.png","0043.png","0044.png","0045.png","0046.png","0047.png","0048.png","0049.png","0050.png","0051.png"],
					day_tc_array: ["0042.png","0043.png","0044.png","0045.png","0046.png","0047.png","0048.png","0049.png","0050.png","0051.png"],
					day_en_array: ["0042.png","0043.png","0044.png","0045.png","0046.png","0047.png","0048.png","0049.png","0050.png","0051.png"],
					day_zero: true,
					day_space: -3,
					day_align: hmUI.align.CENTER_H,
					day_is_character: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_date_current_date_month12 = hmUI.createWidget(hmUI.widget.IMG_DATE, {
					month_startX: 173,
					month_startY: 47,
					month_sc_array: ["0052.png","0053.png","0054.png","0055.png","0056.png","0057.png","0058.png","0059.png","0060.png","0061.png"],
					month_tc_array: ["0052.png","0053.png","0054.png","0055.png","0056.png","0057.png","0058.png","0059.png","0060.png","0061.png"],
					month_en_array: ["0052.png","0053.png","0054.png","0055.png","0056.png","0057.png","0058.png","0059.png","0060.png","0061.png"],
					month_zero: true,
					month_space: -3,
					month_align: hmUI.align.CENTER_H,
					month_is_character: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_background_bg_img13 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 155,
					y: 43,
					w: 15,
					h: 32,
					src: '0062.png',
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_date_current_date_year14 = hmUI.createWidget(hmUI.widget.IMG_DATE, {
					year_startX: 255,
					year_startY: 47,
					year_sc_array: ["0063.png","0064.png","0065.png","0066.png","0067.png","0068.png","0069.png","0070.png","0071.png","0072.png"],
					year_tc_array: ["0063.png","0064.png","0065.png","0066.png","0067.png","0068.png","0069.png","0070.png","0071.png","0072.png"],
					year_en_array: ["0063.png","0064.png","0065.png","0066.png","0067.png","0068.png","0069.png","0070.png","0071.png","0072.png"],
					year_zero: true,
					year_space: -3,
					year_align: hmUI.align.CENTER_H,
					year_is_character: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_background_bg_img15 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 236,
					y: 43,
					w: 15,
					h: 32,
					src: '0062.png',
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_weather_image_progress_img_level17 = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
					x: 170,
					y: 229,
					image_array: ["0073.png","0074.png","0075.png","0076.png","0077.png","0078.png","0079.png","0080.png","0081.png","0082.png","0083.png","0084.png","0085.png","0086.png","0087.png","0088.png","0089.png","0090.png","0091.png","0092.png","0093.png","0094.png","0095.png","0096.png","0097.png","0098.png","0099.png","0100.png","0101.png"],
					image_length: 29,
					type: hmUI.data_type.WEATHER_CURRENT,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_temperature_current_text_img18 = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
					x: 326,
					y: 246,
					font_array: ["0102.png","0103.png","0104.png","0105.png","0106.png","0107.png","0108.png","0109.png","0110.png","0111.png"],
					padding: false,
					h_space: -2,
					unit_sc: ["0113.png"],
					unit_tc: ["0113.png"],
					unit_en: ["0113.png"],
					negative_image: ["0112.png"],
					invalid_image: ["0114.png"],
					align_h: hmUI.align.CENTER_H,
					type: hmUI.data_type.WEATHER_CURRENT,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_background_bg_img19 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 403,
					y: 242,
					w: 21,
					h: 35,
					src: '0115.png',
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_wind_current_text_img21 = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
					x: 86,
					y: 246,
					font_array: ["0116.png","0117.png","0118.png","0119.png","0120.png","0121.png","0122.png","0123.png","0124.png","0125.png"],
					padding: false,
					h_space: -2,
					align_h: hmUI.align.CENTER_H,
					type: hmUI.data_type.WIND,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_background_bg_img22 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 36,
					y: 246,
					w: 32,
					h: 30,
					src: '0126.png',
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_blood_oxygen_text_img24 = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
					x: 106,
					y: 292,
					font_array: ["0127.png","0128.png","0129.png","0130.png","0131.png","0132.png","0133.png","0134.png","0135.png","0136.png"],
					padding: false,
					h_space: -2,
					align_h: hmUI.align.CENTER_H,
					type: hmUI.data_type.SPO2,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_background_bg_img25 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 51,
					y: 287,
					w: 33,
					h: 35,
					src: '0137.png',
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_heart_current_text_img27 = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
					x: 309,
					y: 292,
					font_array: ["0116.png","0117.png","0118.png","0119.png","0120.png","0121.png","0122.png","0123.png","0124.png","0125.png"],
					padding: false,
					h_space: -2,
					invalid_image: '0138.png',
					align_h: hmUI.align.CENTER_H,
					type: hmUI.data_type.HEART,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_background_bg_img28 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 378,
					y: 289,
					w: 36,
					h: 30,
					src: '0139.png',
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_calories_current_text_img30 = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
					x: 278,
					y: 337,
					font_array: ["0102.png","0103.png","0104.png","0105.png","0106.png","0107.png","0108.png","0109.png","0110.png","0111.png"],
					padding: false,
					h_space: -2,
					align_h: hmUI.align.CENTER_H,
					type: hmUI.data_type.CAL,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_background_bg_img31 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 369,
					y: 333,
					w: 25,
					h: 30,
					src: '0140.png',
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_battery_current_text_img33 = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
					x: 114,
					y: 337,
					font_array: ["0141.png","0142.png","0143.png","0144.png","0145.png","0146.png","0147.png","0148.png","0149.png","0150.png"],
					padding: false,
					h_space: -2,
					unit_sc: '0151.png',
					unit_tc: '0151.png',
					unit_en: '0151.png',
					align_h: hmUI.align.CENTER_H,
					type: hmUI.data_type.BATTERY,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_background_bg_img34 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 72,
					y: 335,
					w: 25,
					h: 30,
					src: '0152.png',
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_step_current_text_img36 = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
					x: 122,
					y: 383,
					font_array: ["0153.png","0154.png","0155.png","0156.png","0157.png","0158.png","0159.png","0160.png","0161.png","0162.png"],
					padding: false,
					h_space: -2,
					align_h: hmUI.align.CENTER_H,
					type: hmUI.data_type.STEP,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_background_bg_img37 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 86,
					y: 379,
					w: 23,
					h: 30,
					src: '0163.png',
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_distance_current_text_img39 = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
					x: 259,
					y: 383,
					font_array: ["0164.png","0165.png","0166.png","0167.png","0168.png","0169.png","0170.png","0171.png","0172.png","0173.png"],
					padding: false,
					h_space: -2,
					dot_image: '0174.png',
					align_h: hmUI.align.CENTER_H,
					type: hmUI.data_type.DISTANCE,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_background_bg_img40 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 355,
					y: 382,
					w: 28,
					h: 27,
					src: '0175.png',
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_alarm_status42 = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
					x: 211,
					y: 421,
					w: 44,
					h: 46,
					type: hmUI.system_status.CLOCK,
					src: '0176.png',
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				function updateImageCombos() {
					normal_digital_clock_img_hour_high4.setProperty(hmUI.prop.MORE, {
						src: normal_digital_clock_img_hour_high4_array[(timeSensor.hour.toString().length == 2 ? timeSensor.hour.toString().charAt(0) : 0)]
					})
					normal_digital_clock_img_hour_low5.setProperty(hmUI.prop.MORE, {
						src: normal_digital_clock_img_hour_low5_array[(timeSensor.hour.toString().length == 2 ? timeSensor.hour.toString().charAt(1) : timeSensor.hour.toString().charAt(0))]
					})
					normal_digital_clock_img_minute_high6.setProperty(hmUI.prop.MORE, {
						src: normal_digital_clock_img_minute_high6_array[(timeSensor.minute.toString().length == 2 ? timeSensor.minute.toString().charAt(0) : 0)]
					})
					normal_digital_clock_img_minute_low7.setProperty(hmUI.prop.MORE, {
						src: normal_digital_clock_img_minute_low7_array[(timeSensor.minute.toString().length == 2 ? timeSensor.minute.toString().charAt(1) : timeSensor.minute.toString().charAt(0))]
					})
				};

				const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
					resume_call: (function () {
						updateImageCombos();

					}),
					pause_call: (function () {
					}),
				})
			},

		onInit() {
			console.log('index page.js on init invoke')
			this.init_view()
		},
		onReady() {
			console.log('index page.js on ready invoke')
		},
		onShow() {
			console.log('index page.js on show invoke')
		},
		onHide() {
			console.log('index page.js on hide invoke')
		},
		onDestroy() {
			console.log('index page.js on destroy invoke')
		},
	});	})()
} catch (e) {
	console.log(e)
}