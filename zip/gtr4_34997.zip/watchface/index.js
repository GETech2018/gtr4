﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        const logger = Logger.getLogger('watchface_SashaCX75');
        //end of ignored block

        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_system_disconnect_img = ''
        let normal_system_clock_img = ''
        let normal_battery_image_progress_img_level = ''
        let normal_date_img_date_week_img = ''
        let normal_date_img_date_month = ''
        let normal_date_img_date_day = ''
        let normal_heart_rate_text_text_img = ''
        let normal_altitude_current_text_img = ''
        let normal_temperature_current_text_img = ''
        let normal_weather_image_progress_img_level = ''
        let normal_aqi_current_text_img = ''
        let normal_altimeter_text_text_img = ''
        let normal_calorie_current_text_img = ''
        let normal_step_current_text_img = ''
        let normal_step_image_progress_img_level = ''
        let normal_digital_clock_img_time = ''
        let idle_background_bg_img = ''
        let idle_system_disconnect_img = ''
        let idle_system_clock_img = ''
        let idle_battery_image_progress_img_level = ''
        let idle_date_img_date_week_img = ''
        let idle_date_img_date_month = ''
        let idle_date_img_date_day = ''
        let idle_heart_rate_text_text_img = ''
        let idle_altitude_current_text_img = ''
        let idle_temperature_current_text_img = ''
        let idle_weather_image_progress_img_level = ''
        let idle_aqi_current_text_img = ''
        let idle_altimeter_text_text_img = ''
        let idle_calorie_current_text_img = ''
        let idle_step_current_text_img = ''
        let idle_step_image_progress_img_level = ''
        let idle_digital_clock_img_time = ''
        let normal_stopwatch_jumpable_img_click = ''
        let normal_altimeter_jumpable_img_click = ''
        let normal_temperature_jumpable_img_click = ''
        let normal_calendar_img_click = ''
        let normal_heart_jumpable_img_click = ''
        let normal_step_jumpable_img_click = ''
		
		let heart = hmSensor.createSensor(hmSensor.id.HEART);
        let heartArr = ''

        function HeartUpdate() {
          heartArr = heart.today
          min_heart_txt.setProperty(hmUI.prop.TEXT, Math.min(...heartArr).toString())
          max_heart_txt.setProperty(hmUI.prop.TEXT, Math.max(...heartArr).toString())
        }

        heart.addEventListener(hmSensor.event.CHANGE, function () {
          HeartUpdate()
        })


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 466,
              h: 466,
              src: 'bg.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 15,
              y: 221,
              src: 'bluetooth_(10).png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 429,
              y: 222,
              src: 'free-icon-notification-bell-3541850.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 138,
              y: 367,
              image_array: ["batt_0.png","batt_1.png","batt_2.png","batt_3.png","batt_4.png","batt_5.png","batt_6.png","batt_7.png","batt_8.png","batt_9.png"],
              image_length: 10,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 78,
              y: 207,
              week_en: ["day_1.png","day_2.png","day_3.png","day_4.png","day_5.png","day_6.png","day_7.png"],
              week_tc: ["day_1.png","day_2.png","day_3.png","day_4.png","day_5.png","day_6.png","day_7.png"],
              week_sc: ["day_1.png","day_2.png","day_3.png","day_4.png","day_5.png","day_6.png","day_7.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_month = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 109,
              month_startY: 238,
              month_sc_array: ["nm_0.png","nm_1.png","nm_2.png","nm_3.png","nm_4.png","nm_5.png","nm_6.png","nm_7.png","nm_8.png","nm_9.png"],
              month_tc_array: ["nm_0.png","nm_1.png","nm_2.png","nm_3.png","nm_4.png","nm_5.png","nm_6.png","nm_7.png","nm_8.png","nm_9.png"],
              month_en_array: ["nm_0.png","nm_1.png","nm_2.png","nm_3.png","nm_4.png","nm_5.png","nm_6.png","nm_7.png","nm_8.png","nm_9.png"],
              month_zero: 1,
              month_space: 2,
              month_align: hmUI.align.CENTER_H,
              month_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 63,
              day_startY: 238,
              day_sc_array: ["nm_0.png","nm_1.png","nm_2.png","nm_3.png","nm_4.png","nm_5.png","nm_6.png","nm_7.png","nm_8.png","nm_9.png"],
              day_tc_array: ["nm_0.png","nm_1.png","nm_2.png","nm_3.png","nm_4.png","nm_5.png","nm_6.png","nm_7.png","nm_8.png","nm_9.png"],
              day_en_array: ["nm_0.png","nm_1.png","nm_2.png","nm_3.png","nm_4.png","nm_5.png","nm_6.png","nm_7.png","nm_8.png","nm_9.png"],
              day_zero: 1,
              day_space: 2,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
			
			min_heart_txt = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 130,
              y: 80,
              w: 50,
              h: 50,
              text_size: 22,
              text: '',
              color: 0x0000ff,
              align_h: hmUI.align.RIGHT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            max_heart_txt = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 273,
              y: 80,
              w: 50,
              h: 50,
              text_size: 22,
              text: '',
              color: 0xff0000,
              align_h: hmUI.align.CENTR,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 208,
              y: 84,
              font_array: ["nm_0.png","nm_1.png","nm_2.png","nm_3.png","nm_4.png","nm_5.png","nm_6.png","nm_7.png","nm_8.png","nm_9.png"],
              padding: false,
              h_space: 2,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_altitude_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 180,
              y: 125,
              font_array: ["ft_0.png","ft_1.png","ft_2.png","ft_3.png","ft_4.png","ft_5.png","ft_6.png","ft_7.png","ft_8.png","ft_9.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.ALTITUDE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 245,
              y: 155,
              font_array: ["ft_0.png","ft_1.png","ft_2.png","ft_3.png","ft_4.png","ft_5.png","ft_6.png","ft_7.png","ft_8.png","ft_9.png"],
              padding: false,
              h_space: 2,
              negative_image: 'minus.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 95,
              y: 135,
              image_array: ["weather_0.png","weather_1.png","weather_2.png","weather_3.png","weather_4.png","weather_5.png","weather_6.png","weather_7.png","weather_8.png","weather_9.png","weather_10.png","weather_11.png","weather_12.png","weather_13.png","weather_14.png","weather_15.png","weather_16.png","weather_17.png","weather_18.png","weather_19.png","weather_20.png","weather_21.png","weather_22.png","weather_23.png","weather_24.png","weather_25.png","weather_26.png","weather_27.png","weather_28.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_aqi_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 343,
              y: 140,
              font_array: ["ft_0.png","ft_1.png","ft_2.png","ft_3.png","ft_4.png","ft_5.png","ft_6.png","ft_7.png","ft_8.png","ft_9.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.AQI,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_altimeter_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 250,
              y: 125,
              font_array: ["ft_0.png","ft_1.png","ft_2.png","ft_3.png","ft_4.png","ft_5.png","ft_6.png","ft_7.png","ft_8.png","ft_9.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.ALTIMETER,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_calorie_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 335,
              y: 190,
              font_array: ["nm_0.png","nm_1.png","nm_2.png","nm_3.png","nm_4.png","nm_5.png","nm_6.png","nm_7.png","nm_8.png","nm_9.png"],
              padding: false,
              h_space: 2,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 333,
              y: 260,
              font_array: ["ft_0.png","ft_1.png","ft_2.png","ft_3.png","ft_4.png","ft_5.png","ft_6.png","ft_7.png","ft_8.png","ft_9.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 161,
              y: 222,
              image_array: ["pwr_1.png","pwr_2.png","pwr_3.png","pwr_4.png","pwr_5.png","pwr_6.png","pwr_7.png","pwr_8.png","pwr_9.png"],
              image_length: 9,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 107,
              hour_startY: 281,
              hour_array: ["h0.png","h1.png","h2.png","h3.png","h4.png","h5.png","h6.png","h7.png","h8.png","h9.png"],
              hour_zero: 1,
              hour_space: 4,
              hour_angle: 0,
              hour_align: hmUI.align.LEFT,

              minute_startX: 207,
              minute_startY: 281,
              minute_array: ["h0.png","h1.png","h2.png","h3.png","h4.png","h5.png","h6.png","h7.png","h8.png","h9.png"],
              minute_zero: 1,
              minute_space: 5,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              second_startX: 298,
              second_startY: 313,
              second_array: ["s0.png","s1.png","s2.png","s3.png","s4.png","s5.png","s6.png","s7.png","s8.png","s9.png"],
              second_zero: 1,
              second_space: 3,
              second_angle: 0,
              second_follow: 0,
              second_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            idle_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 466,
              h: 466,
              src: 'aod.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 15,
              y: 221,
              src: 'bluetooth_(10).png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 429,
              y: 222,
              src: 'free-icon-notification-bell-3541850.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_battery_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 138,
              y: 367,
              image_array: ["batt_0.png","batt_1.png","batt_2.png","batt_3.png","batt_4.png","batt_5.png","batt_6.png","batt_7.png","batt_8.png","batt_9.png"],
              image_length: 10,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 78,
              y: 207,
              week_en: ["day_1.png","day_2.png","day_3.png","day_4.png","day_5.png","day_6.png","day_7.png"],
              week_tc: ["day_1.png","day_2.png","day_3.png","day_4.png","day_5.png","day_6.png","day_7.png"],
              week_sc: ["day_1.png","day_2.png","day_3.png","day_4.png","day_5.png","day_6.png","day_7.png"],
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_month = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 109,
              month_startY: 238,
              month_sc_array: ["nm_0.png","nm_1.png","nm_2.png","nm_3.png","nm_4.png","nm_5.png","nm_6.png","nm_7.png","nm_8.png","nm_9.png"],
              month_tc_array: ["nm_0.png","nm_1.png","nm_2.png","nm_3.png","nm_4.png","nm_5.png","nm_6.png","nm_7.png","nm_8.png","nm_9.png"],
              month_en_array: ["nm_0.png","nm_1.png","nm_2.png","nm_3.png","nm_4.png","nm_5.png","nm_6.png","nm_7.png","nm_8.png","nm_9.png"],
              month_zero: 1,
              month_space: 2,
              month_align: hmUI.align.CENTER_H,
              month_is_character: false,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 63,
              day_startY: 238,
              day_sc_array: ["nm_0.png","nm_1.png","nm_2.png","nm_3.png","nm_4.png","nm_5.png","nm_6.png","nm_7.png","nm_8.png","nm_9.png"],
              day_tc_array: ["nm_0.png","nm_1.png","nm_2.png","nm_3.png","nm_4.png","nm_5.png","nm_6.png","nm_7.png","nm_8.png","nm_9.png"],
              day_en_array: ["nm_0.png","nm_1.png","nm_2.png","nm_3.png","nm_4.png","nm_5.png","nm_6.png","nm_7.png","nm_8.png","nm_9.png"],
              day_zero: 1,
              day_space: 2,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 210,
              y: 84,
              font_array: ["nm_0.png","nm_1.png","nm_2.png","nm_3.png","nm_4.png","nm_5.png","nm_6.png","nm_7.png","nm_8.png","nm_9.png"],
              padding: false,
              h_space: 2,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_AOD,
            });
			
			min_heart_txt = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 130,
              y: 80,
              w: 50,
              h: 50,
              text_size: 22,
              text: '',
              color: 0x0000ff,
              align_h: hmUI.align.RIGHT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            max_heart_txt = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 273,
              y: 80,
              w: 50,
              h: 50,
              text_size: 22,
              text: '',
              color: 0xff0000,
              align_h: hmUI.align.CENTR,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_altitude_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 180,
              y: 125,
              font_array: ["ft_0.png","ft_1.png","ft_2.png","ft_3.png","ft_4.png","ft_5.png","ft_6.png","ft_7.png","ft_8.png","ft_9.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.ALTITUDE,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 245,
              y: 155,
              font_array: ["ft_0.png","ft_1.png","ft_2.png","ft_3.png","ft_4.png","ft_5.png","ft_6.png","ft_7.png","ft_8.png","ft_9.png"],
              padding: false,
              h_space: 2,
              negative_image: 'minus.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 95,
              y: 135,
              image_array: ["weather_0.png","weather_1.png","weather_2.png","weather_3.png","weather_4.png","weather_5.png","weather_6.png","weather_7.png","weather_8.png","weather_9.png","weather_10.png","weather_11.png","weather_12.png","weather_13.png","weather_14.png","weather_15.png","weather_16.png","weather_17.png","weather_18.png","weather_19.png","weather_20.png","weather_21.png","weather_22.png","weather_23.png","weather_24.png","weather_25.png","weather_26.png","weather_27.png","weather_28.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_aqi_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 343,
              y: 140,
              font_array: ["ft_0.png","ft_1.png","ft_2.png","ft_3.png","ft_4.png","ft_5.png","ft_6.png","ft_7.png","ft_8.png","ft_9.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.AQI,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_altimeter_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 250,
              y: 125,
              font_array: ["ft_0.png","ft_1.png","ft_2.png","ft_3.png","ft_4.png","ft_5.png","ft_6.png","ft_7.png","ft_8.png","ft_9.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.ALTIMETER,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_calorie_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 335,
              y: 190,
              font_array: ["nm_0.png","nm_1.png","nm_2.png","nm_3.png","nm_4.png","nm_5.png","nm_6.png","nm_7.png","nm_8.png","nm_9.png"],
              padding: false,
              h_space: 2,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 333,
              y: 260,
              font_array: ["ft_0.png","ft_1.png","ft_2.png","ft_3.png","ft_4.png","ft_5.png","ft_6.png","ft_7.png","ft_8.png","ft_9.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_step_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 161,
              y: 222,
              image_array: ["pwr_1.png","pwr_2.png","pwr_3.png","pwr_4.png","pwr_5.png","pwr_6.png","pwr_7.png","pwr_8.png","pwr_9.png"],
              image_length: 9,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 107,
              hour_startY: 281,
              hour_array: ["h0.png","h1.png","h2.png","h3.png","h4.png","h5.png","h6.png","h7.png","h8.png","h9.png"],
              hour_zero: 1,
              hour_space: 4,
              hour_angle: 0,
              hour_align: hmUI.align.LEFT,

              minute_startX: 207,
              minute_startY: 281,
              minute_array: ["h0.png","h1.png","h2.png","h3.png","h4.png","h5.png","h6.png","h7.png","h8.png","h9.png"],
              minute_zero: 1,
              minute_space: 5,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              second_startX: 298,
              second_startY: 313,
              second_array: ["s0.png","s1.png","s2.png","s3.png","s4.png","s5.png","s6.png","s7.png","s8.png","s9.png"],
              second_zero: 1,
              second_space: 3,
              second_angle: 0,
              second_follow: 0,
              second_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_AOD,
            });
            
            // disconnectAlert = hmUI.createWidget(hmUI.widget.DisconnectAlert, {
              // disconneсnt_vibrate_type: 9,
              // disconneсnt_toast_text: Signal LOST,
              // conneсnt_vibrate_type: 0,
              // conneсnt_toast_text: Signal FIND,
            // });

            // vibration when connecting or disconnecting

            function checkConnection() {
              hmBle.removeListener;
              hmBle.addListener(function (status) {
                if(!status) {
                  hmUI.showToast({text: "Signal LOST"});
                  vibro(9);
                }
                if(status) {
                  hmUI.showToast({text: "Signal FIND"});
                  vibro(0);
                }
              });
            }

            // end vibration when connecting or disconnecting
            // vibrate function

            const vibrate = hmSensor.createSensor(hmSensor.id.VIBRATE);
            let timer_StopVibrate = null;


            function vibro(scene = 25) {
              let stopDelay = 50;
              stopVibro();
              vibrate.stop();
              vibrate.scene = scene;
              if(scene < 23 || scene > 25) stopDelay = 1300;
              vibrate.start();
              timer_StopVibrate = timer.createTimer(stopDelay, 3000, stopVibro, {});
            }

            function stopVibro(){
              vibrate.stop();
              if(timer_StopVibrate) timer.stopTimer(timer_StopVibrate);
            }

            // end vibrate function

            normal_stopwatch_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 300,
              y: 305,
              w: 50,
              h: 50,
              src: 'Empty.png',
              type: hmUI.data_type.STOP_WATCH,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_altimeter_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 308,
              y: 110,
              w: 60,
              h: 60,
              src: 'Empty.png',
              type: hmUI.data_type.ALTIMETER,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 90,
              y: 135,
              w: 60,
              h: 60,
              src: 'Empty.png',
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_calendar_img_click = hmUI.createWidget(hmUI.widget.IMG, {
              x: 65,
              y: 205,
              w: 80,
              h: 60,
              src: 'Empty.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            normal_calendar_img_click.addEventListener(hmUI.event.CLICK_DOWN, function (info) {
              hmApp.startApp({
                appid: 1,
                url: 'ScheduleCalScreen',
                native: true
              })
            });

            normal_heart_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 180,
              y: 60,
              w: 100,
              h: 50,
              src: 'Empty.png',
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 315,
              y: 241,
              w: 80,
              h: 50,
              src: 'Empty.png',
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                HeartUpdate()
				checkConnection();
                stopVibro();

              }),
              pause_call: (function () {
                stopVibro();

              }),
            });

                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}