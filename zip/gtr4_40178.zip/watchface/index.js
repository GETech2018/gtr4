﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        const logger = Logger.getLogger('watchface_SashaCX75');
        //end of ignored block

        //dynamic modify start

        
        let editBg = ''
        let normal_step_circle_scale = ''
        let normal_fat_burning_circle_scale = ''
        let normal_stand_circle_scale = ''
        let normal_dow_text_font = ''
        let normal_DOW_Array = ['MON', 'TUE', 'WED', 'THU', 'FRI', 'SAT', 'SUN'];
        let normal_day_text_font = ''
        let normal_temperature_high_text_font = ''
        let normal_temperature_low_text_font = ''
        let normal_temperature_current_text_font = ''
        let normal_moon_image_progress_img_level = ''
        let idle_step_circle_scale = ''
        let idle_fat_burning_circle_scale = ''
        let idle_stand_circle_scale = ''
        let idle_dow_text_font = ''
        let idle_DOW_Array = ['MON', 'TUE', 'WED', 'THU', 'FRI', 'SAT', 'SUN'];
        let idle_day_text_font = ''
        let idle_temperature_high_text_font = ''
        let idle_temperature_low_text_font = ''
        let idle_temperature_current_text_font = ''
        let idle_moon_image_progress_img_level = ''
        let idle_image_img = ''
        let editableTimePointers = ''
        let normal_cal_jumpable_img_click = ''
        let normal_sunrise_jumpable_img_click = ''
        let normal_temperature_jumpable_img_click = ''
        let Button_1 = ''
        let timeSensor = ''


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            // FontName: SF-Compact-Rounded-Medium-min.ttf; FontSize: 24; Cache: full
            hmUI.createWidget(hmUI.widget.TEXT, {
              x: 464,
              y: 464,
              w: 28,
              h: 28,
              text_size: 24,
              char_space: 0,
              line_space: 0,
              font: 'fonts/SF-Compact-Rounded-Medium-min.ttf',
              color: 0xFFFF3240,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.NONE,
              text: "0123456789 ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz АБВГДЕЁЖЗИЙКЛМНОПРСТУФХЦЧШЩЪЫЬЭЮЯабвгдеёжзийклмнопрстуфхцчшщъыьэюя  ҐЄІЇґєії _-.,:;`'%°\\/",
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // FontName: SF-Compact-Rounded-Medium-min.ttf; FontSize: 48
            hmUI.createWidget(hmUI.widget.TEXT, {
              x: 464,
              y: 464,
              w: 630,
              h: 70,
              text_size: 48,
              char_space: 0,
              line_space: 0,
              font: 'fonts/SF-Compact-Rounded-Medium-min.ttf',
              color: 0xFFFFFFFF,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              text: "0123456789 _-.,:;`'%°\\/",
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // FontName: SF-Compact-Rounded-Medium-min.ttf; FontSize: 20
            hmUI.createWidget(hmUI.widget.TEXT, {
              x: 464,
              y: 464,
              w: 254,
              h: 28,
              text_size: 20,
              char_space: 0,
              line_space: 0,
              font: 'fonts/SF-Compact-Rounded-Medium-min.ttf',
              color: 0xFFFF0000,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              text: "0123456789 _-.,:;`'%°\\/",
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // FontName: SF-Compact-Rounded-Medium-min.ttf; FontSize: 44
            hmUI.createWidget(hmUI.widget.TEXT, {
              x: 464,
              y: 464,
              w: 544,
              h: 64,
              text_size: 44,
              char_space: -1,
              line_space: 0,
              font: 'fonts/SF-Compact-Rounded-Medium-min.ttf',
              color: 0xFFFFFFFF,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              text: "0123456789 _-.,:;`'%°\\/",
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            console.log('Watch_Face.ScreenNormal');
            editBg = hmUI.createWidget(hmUI.widget.WATCHFACE_EDIT_BG, {
              edit_id: 1002,
              x: 0,
              y: 0,
              // w: 466,
              // h: 466,
              // AOD_show: True,
              bg_config: [
                { id: 1, preview: 'bg_pre0.png', path: 'bg0.png' },
                { id: 2, preview: 'bg_pre1.png', path: 'bg1.png' },
                { id: 3, preview: 'bg_pre2.png', path: 'bg2.png' },
                { id: 4, preview: 'bg_pre3.png', path: 'bg3.png' },
                { id: 5, preview: 'bg_pre4.png', path: 'bg4.png' },
                { id: 6, preview: 'bg_pre5.png', path: 'bg5.png' },
              ],
              count: 6,
              default_id: 1,
              fg: '.png',
              tips_bg: 'tooltip.png',
              tips_x: 170,
              tips_y: 313,
            });

            // normal_step_circle_scale = hmUI.createWidget(hmUI.widget.Circle_Scale, {
              // center_x: 136,
              // center_y: 232,
              // start_angle: 0,
              // end_angle: 370,
              // radius: 54,
              // line_width: 9,
              // line_cap: Rounded,
              // color: 0xFFFF1353,
              // mirror: False,
              // inversion: False,
              // type: hmUI.data_type.STEP,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            let screenType = hmSetting.getScreenType();
            normal_step_circle_scale = hmUI.createWidget(hmUI.widget.ARC_PROGRESS, {
              center_x: 136,
              center_y: 232,
              start_angle: 0,
              end_angle: 370,
              radius: 50,
              line_width: 9,
              corner_flag: 0,
              color: 0xFFFF1353,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            
            const step = hmSensor.createSensor(hmSensor.id.STEP);
            step.addEventListener(hmSensor.event.CHANGE, function() {
              scale_call();
            });

            // normal_fat_burning_circle_scale = hmUI.createWidget(hmUI.widget.Circle_Scale, {
              // center_x: 136,
              // center_y: 232,
              // start_angle: 0,
              // end_angle: 370,
              // radius: 39,
              // line_width: 9,
              // line_cap: Rounded,
              // color: 0xFF9DFD00,
              // mirror: False,
              // inversion: False,
              // type: hmUI.data_type.FAT_BURNING,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_fat_burning_circle_scale = hmUI.createWidget(hmUI.widget.ARC_PROGRESS, {
              center_x: 136,
              center_y: 232,
              start_angle: 0,
              end_angle: 370,
              radius: 35,
              line_width: 9,
              corner_flag: 0,
              color: 0xFF9DFD00,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            
            const fat_burning = hmSensor.createSensor(hmSensor.id.FAT_BURRING);
            fat_burning.addEventListener(hmSensor.event.CHANGE, function() {
              scale_call();
            });

            // normal_stand_circle_scale = hmUI.createWidget(hmUI.widget.Circle_Scale, {
              // center_x: 136,
              // center_y: 232,
              // start_angle: 0,
              // end_angle: 370,
              // radius: 24,
              // line_width: 9,
              // line_cap: Rounded,
              // color: 0xFF5AC8FA,
              // mirror: False,
              // inversion: False,
              // type: hmUI.data_type.STAND,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_stand_circle_scale = hmUI.createWidget(hmUI.widget.ARC_PROGRESS, {
              center_x: 136,
              center_y: 232,
              start_angle: 0,
              end_angle: 370,
              radius: 20,
              line_width: 9,
              corner_flag: 0,
              color: 0xFF5AC8FA,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            
            const stand = hmSensor.createSensor(hmSensor.id.STAND);
            stand.addEventListener(hmSensor.event.CHANGE, function() {
              scale_call();
            });

            if (!timeSensor) timeSensor = hmSensor.createSensor(hmSensor.id.TIME);
            timeSensor.addEventListener(timeSensor.event.DAYCHANGE, function() {
              time_update(true);
            });

            normal_dow_text_font = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 203,
              y: 97,
              w: 60,
              h: 34,
              text_size: 24,
              char_space: 0,
              line_space: 0,
              font: 'fonts/SF-Compact-Rounded-Medium-min.ttf',
              color: 0xFFFF3240,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              // unit_string: MON, TUE, WED, THU, FRI, SAT, SUN,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_day_text_font = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 203,
              y: 117,
              w: 60,
              h: 60,
              text_size: 48,
              char_space: 0,
              line_space: 0,
              font: 'fonts/SF-Compact-Rounded-Medium-min.ttf',
              color: 0xFFFFFFFF,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_high_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 334,
              y: 264,
              w: 50,
              h: 30,
              text_size: 20,
              char_space: 0,
              line_space: 0,
              font: 'fonts/SF-Compact-Rounded-Medium-min.ttf',
              color: 0xFFFF0000,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.CENTER_V,
              unit_type: 1,
              text_style: hmUI.text_style.ELLIPSIS,
              type: hmUI.data_type.WEATHER_HIGH,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_low_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 277,
              y: 264,
              w: 50,
              h: 30,
              text_size: 20,
              char_space: 0,
              line_space: 0,
              font: 'fonts/SF-Compact-Rounded-Medium-min.ttf',
              color: 0xFF00FF00,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.CENTER_V,
              unit_type: 1,
              text_style: hmUI.text_style.ELLIPSIS,
              type: hmUI.data_type.WEATHER_LOW,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 293,
              y: 208,
              w: 80,
              h: 50,
              text_size: 44,
              char_space: -1,
              line_space: 0,
              font: 'fonts/SF-Compact-Rounded-Medium-min.ttf',
              color: 0xFFFFFFFF,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.CENTER_V,
              unit_type: 1,
              text_style: hmUI.text_style.ELLIPSIS,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_moon_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 163,
              y: 262,
              image_array: ["31.png","32.png","33.png","34.png","35.png","36.png","37.png","38.png","39.png","40.png","41.png","42.png","43.png","44.png","45.png","46.png","47.png","48.png","49.png","50.png","51.png","52.png","53.png","54.png","55.png","56.png","57.png","58.png","59.png","60.png"],
              image_length: 30,
              shortcut: true,
              type: hmUI.data_type.MOON,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            console.log('Watch_Face.ScreenAOD');

            // idle_step_circle_scale = hmUI.createWidget(hmUI.widget.Circle_Scale, {
              // center_x: 136,
              // center_y: 232,
              // start_angle: 0,
              // end_angle: 370,
              // radius: 54,
              // line_width: 9,
              // line_cap: Rounded,
              // color: 0xFFFF1353,
              // mirror: False,
              // inversion: False,
              // type: hmUI.data_type.STEP,
              // show_level: hmUI.show_level.ONLY_AOD,
            // });

            idle_step_circle_scale = hmUI.createWidget(hmUI.widget.ARC_PROGRESS, {
              center_x: 136,
              center_y: 232,
              start_angle: 0,
              end_angle: 370,
              radius: 50,
              line_width: 9,
              corner_flag: 0,
              color: 0xFFFF1353,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            // idle_fat_burning_circle_scale = hmUI.createWidget(hmUI.widget.Circle_Scale, {
              // center_x: 136,
              // center_y: 232,
              // start_angle: 0,
              // end_angle: 370,
              // radius: 39,
              // line_width: 9,
              // line_cap: Rounded,
              // color: 0xFF9DFD00,
              // mirror: False,
              // inversion: False,
              // type: hmUI.data_type.FAT_BURNING,
              // show_level: hmUI.show_level.ONLY_AOD,
            // });

            idle_fat_burning_circle_scale = hmUI.createWidget(hmUI.widget.ARC_PROGRESS, {
              center_x: 136,
              center_y: 232,
              start_angle: 0,
              end_angle: 370,
              radius: 35,
              line_width: 9,
              corner_flag: 0,
              color: 0xFF9DFD00,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            // idle_stand_circle_scale = hmUI.createWidget(hmUI.widget.Circle_Scale, {
              // center_x: 136,
              // center_y: 232,
              // start_angle: 0,
              // end_angle: 370,
              // radius: 24,
              // line_width: 9,
              // line_cap: Rounded,
              // color: 0xFF5AC8FA,
              // mirror: False,
              // inversion: False,
              // type: hmUI.data_type.STAND,
              // show_level: hmUI.show_level.ONLY_AOD,
            // });

            idle_stand_circle_scale = hmUI.createWidget(hmUI.widget.ARC_PROGRESS, {
              center_x: 136,
              center_y: 232,
              start_angle: 0,
              end_angle: 370,
              radius: 20,
              line_width: 9,
              corner_flag: 0,
              color: 0xFF5AC8FA,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_dow_text_font = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 203,
              y: 97,
              w: 60,
              h: 34,
              text_size: 24,
              char_space: 0,
              line_space: 0,
              font: 'fonts/SF-Compact-Rounded-Medium-min.ttf',
              color: 0xFFFF3240,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              // unit_string: MON, TUE, WED, THU, FRI, SAT, SUN,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_day_text_font = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 203,
              y: 117,
              w: 60,
              h: 60,
              text_size: 48,
              char_space: 0,
              line_space: 0,
              font: 'fonts/SF-Compact-Rounded-Medium-min.ttf',
              color: 0xFFFFFFFF,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_temperature_high_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 334,
              y: 264,
              w: 50,
              h: 30,
              text_size: 20,
              char_space: 0,
              line_space: 0,
              font: 'fonts/SF-Compact-Rounded-Medium-min.ttf',
              color: 0xFFFF0000,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              type: hmUI.data_type.WEATHER_HIGH,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_temperature_low_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 277,
              y: 264,
              w: 50,
              h: 30,
              text_size: 20,
              char_space: 0,
              line_space: 0,
              font: 'fonts/SF-Compact-Rounded-Medium-min.ttf',
              color: 0xFF00FF00,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              type: hmUI.data_type.WEATHER_LOW,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_temperature_current_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 297,
              y: 208,
              w: 70,
              h: 50,
              text_size: 44,
              char_space: -1,
              line_space: 0,
              font: 'fonts/SF-Compact-Rounded-Medium-min.ttf',
              color: 0xFFFFFFFF,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.CENTER_V,
              unit_type: 1,
              text_style: hmUI.text_style.ELLIPSIS,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_moon_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 163,
              y: 262,
              image_array: ["31.png","32.png","33.png","34.png","35.png","36.png","37.png","38.png","39.png","40.png","41.png","42.png","43.png","44.png","45.png","46.png","47.png","48.png","49.png","50.png","51.png","52.png","53.png","54.png","55.png","56.png","57.png","58.png","59.png","60.png"],
              image_length: 30,
              shortcut: true,
              type: hmUI.data_type.MOON,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_image_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'black50.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });
            console.log('Watch_Face.ElementEditablePointers');

            const pointerEdit = hmUI.createWidget(hmUI.widget.WATCHFACE_EDIT_POINTER, {
              edit_id: 1003,
              x: 0,
              y: 0,
              config: [
                {
                  id: 1,
                  second: {
                    centerX: 233,
                    centerY: 233,
                    posX: 30,
                    posY: 233,
                    path: 'hand.sec.png',
                  },
                  hour: {
                    centerX: 233,
                    centerY: 233,
                    posX: 30,
                    posY: 233,
                    path: 'hand.hour.W.png',
                  },
                  minute: {
                    centerX: 233,
                    centerY: 233,
                    posX: 30,
                    posY: 233,
                    path: 'hand.min.W.png',
                  },
                  preview: 'pointer_edit_1_preview.png',
                },
                {
                  id: 2,
                  second: {
                    centerX: 233,
                    centerY: 233,
                    posX: 30,
                    posY: 233,
                    path: 'hand.sec.png',
                  },
                  hour: {
                    centerX: 233,
                    centerY: 233,
                    posX: 30,
                    posY: 233,
                    path: 'hand.hour.B.png',
                  },
                  minute: {
                    centerX: 233,
                    centerY: 233,
                    posX: 30,
                    posY: 233,
                    path: 'hand.min.B.png',
                  },
                  preview: 'pointer_edit_2_preview.png',
                },
              ],
              count: 2,
              default_id: 1,
              fg: '3.png',
              tips_x: 170,
              tips_y: 395,
              tips_bg: 'tooltip.png',
            });
            const screenTypeForETP = hmSetting.getScreenType();
            const aodModel = screenTypeForETP == hmSetting.screen_type.AOD;
            const pointerProp = pointerEdit.getProperty(hmUI.prop.CURRENT_CONFIG, !aodModel);
            editableTimePointers = hmUI.createWidget(hmUI.widget.TIME_POINTER, pointerProp);
            console.log('Watch_Face.Shortcuts');

            normal_cal_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 83,
              y: 183,
              w: 100,
              h: 100,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sunrise_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 193,
              y: 293,
              w: 80,
              h: 80,
              type: hmUI.data_type.SUN_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 287,
              y: 178,
              w: 90,
              h: 110,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            console.log('Watch_Face.Buttons');
            Button_1 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 193,
              y: 97,
              w: 80,
              h: 80,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '2.png',
              normal_src: '2.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            //start of ignored block
            function time_update(updateHour = false, updateMinute = false) {
              console.log('time_update()');
              let hour = timeSensor.hour;
              let minute = timeSensor.minute;
              let second = timeSensor.second;
              let format_hour = timeSensor.format_hour;

              console.log('day of week font');
              if (updateHour) {
                let normal_DOW_Str = normal_DOW_Array[timeSensor.week-1];
                normal_dow_text_font.setProperty(hmUI.prop.TEXT, normal_DOW_Str );
              };

              console.log('day font');
              if (updateHour) {
                let normal_dayStr = timeSensor.day.toString();
                normal_day_text_font.setProperty(hmUI.prop.TEXT, normal_dayStr );
              };

              console.log('day of week font');
              if (updateHour) {
                let idle_DOW_Str = idle_DOW_Array[timeSensor.week-1];
                idle_dow_text_font.setProperty(hmUI.prop.TEXT, idle_DOW_Str );
              };

              console.log('day font');
              if (updateHour) {
                let idle_dayStr = timeSensor.day.toString();
                idle_day_text_font.setProperty(hmUI.prop.TEXT, idle_dayStr );
              };

            };

            //end of ignored block
            function scale_call() {
              console.log('scale_call()');

                console.log('update scales STEP');
                
                let valueStep = step.current;
                let targetStep = step.target;
                let progressStep = valueStep/targetStep;
                if (progressStep > 1) progressStep = 1;
                let progress_cs_normal_step = progressStep;

                if (screenType != hmSetting.screen_type.AOD) {

                  // normal_step_circle_scale_circle_scale
                  let level = Math.round(progress_cs_normal_step * 100);
                  if (normal_step_circle_scale) {
                    normal_step_circle_scale.setProperty(hmUI.prop.MORE, {                      
                      center_x: 136,
                      center_y: 232,
                      start_angle: 0,
                      end_angle: 370,
                      radius: 50,
                      line_width: 9,
                      corner_flag: 0,
                      color: 0xFFFF1353,
                      show_level: hmUI.show_level.ONLY_NORMAL,
                      level: level,
                    });
                  };
                };

                console.log('update scales FAT_BURNING');
                
                let valueFatBurning = fat_burning.current;
                let targetFatBurning = fat_burning.target;
                let progressFatBurning = valueFatBurning/targetFatBurning;
                if (progressFatBurning > 1) progressFatBurning = 1;
                let progress_cs_normal_fat_burning = progressFatBurning;

                if (screenType != hmSetting.screen_type.AOD) {

                  // normal_fat_burning_circle_scale_circle_scale
                  let level = Math.round(progress_cs_normal_fat_burning * 100);
                  if (normal_fat_burning_circle_scale) {
                    normal_fat_burning_circle_scale.setProperty(hmUI.prop.MORE, {                      
                      center_x: 136,
                      center_y: 232,
                      start_angle: 0,
                      end_angle: 370,
                      radius: 35,
                      line_width: 9,
                      corner_flag: 0,
                      color: 0xFF9DFD00,
                      show_level: hmUI.show_level.ONLY_NORMAL,
                      level: level,
                    });
                  };
                };

                console.log('update scales STAND');
                
                let valueStand = stand.current;
                let targetStand = stand.target;
                let progressStand = valueStand/targetStand;
                if (progressStand > 1) progressStand = 1;
                let progress_cs_normal_stand = progressStand;

                if (screenType != hmSetting.screen_type.AOD) {

                  // normal_stand_circle_scale_circle_scale
                  let level = Math.round(progress_cs_normal_stand * 100);
                  if (normal_stand_circle_scale) {
                    normal_stand_circle_scale.setProperty(hmUI.prop.MORE, {                      
                      center_x: 136,
                      center_y: 232,
                      start_angle: 0,
                      end_angle: 370,
                      radius: 20,
                      line_width: 9,
                      corner_flag: 0,
                      color: 0xFF5AC8FA,
                      show_level: hmUI.show_level.ONLY_NORMAL,
                      level: level,
                    });
                  };
                };

                console.log('update scales STEP');
                let progress_cs_idle_step = progressStep;

                if (screenType == hmSetting.screen_type.AOD) {

                  // idle_step_circle_scale_circle_scale
                  let level = Math.round(progress_cs_idle_step * 100);
                  if (idle_step_circle_scale) {
                    idle_step_circle_scale.setProperty(hmUI.prop.MORE, {                      
                      center_x: 136,
                      center_y: 232,
                      start_angle: 0,
                      end_angle: 370,
                      radius: 50,
                      line_width: 9,
                      corner_flag: 0,
                      color: 0xFFFF1353,
                      show_level: hmUI.show_level.ONLY_AOD,
                      level: level,
                    });
                  };
                };

                console.log('update scales FAT_BURNING');
                let progress_cs_idle_fat_burning = progressFatBurning;

                if (screenType == hmSetting.screen_type.AOD) {

                  // idle_fat_burning_circle_scale_circle_scale
                  let level = Math.round(progress_cs_idle_fat_burning * 100);
                  if (idle_fat_burning_circle_scale) {
                    idle_fat_burning_circle_scale.setProperty(hmUI.prop.MORE, {                      
                      center_x: 136,
                      center_y: 232,
                      start_angle: 0,
                      end_angle: 370,
                      radius: 35,
                      line_width: 9,
                      corner_flag: 0,
                      color: 0xFF9DFD00,
                      show_level: hmUI.show_level.ONLY_AOD,
                      level: level,
                    });
                  };
                };

                console.log('update scales STAND');
                let progress_cs_idle_stand = progressStand;

                if (screenType == hmSetting.screen_type.AOD) {

                  // idle_stand_circle_scale_circle_scale
                  let level = Math.round(progress_cs_idle_stand * 100);
                  if (idle_stand_circle_scale) {
                    idle_stand_circle_scale.setProperty(hmUI.prop.MORE, {                      
                      center_x: 136,
                      center_y: 232,
                      start_angle: 0,
                      end_angle: 370,
                      radius: 20,
                      line_width: 9,
                      corner_flag: 0,
                      color: 0xFF5AC8FA,
                      show_level: hmUI.show_level.ONLY_AOD,
                      level: level,
                    });
                  };
                };

            };

            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                console.log('resume_call()');
                scale_call();
                time_update(true, true);
              }),
            });

                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}