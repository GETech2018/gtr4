﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        const logger = Logger.getLogger('watchface_SashaCX75');
        //end of ignored block

        //dynamic modify start

        
        console.log('user_functions.js');
        // start user_functions.js

function endDemo (options) {
    hmUI.createWidget(hmUI.widget.IMG, {
        x: 0,
        y: 0,
        w: 480,
        h: 480,
        src: 'bg_demo.png',
        show_level: hmUI.show_level.ONLY_NORMAL,
    });
  }

const demoPeriod = 10 * 1000;
timer.createTimer(
    demoPeriod,
    demoPeriod,
    endDemo,
    {}
)

        // end user_functions.js

        let normal_background_bg_img = ''
        let normal_rotate_animation_img_1 = '';
        let normal_rotate_animation_param_1 = null;
        let normal_rotate_animation_lastTime_1 = 0;
        let timer_anim_rotate_1;
        let normal_rotate_animation_count_1 = 0;
        let normal_rotate_animation_img_2 = '';
        let normal_rotate_animation_param_2 = null;
        let normal_rotate_animation_lastTime_2 = 0;
        let timer_anim_rotate_2;
        let normal_rotate_animation_count_2 = 0;
        let normal_rotate_animation_img_3 = '';
        let normal_rotate_animation_param_3 = null;
        let normal_rotate_animation_lastTime_3 = 0;
        let timer_anim_rotate_3;
        let normal_rotate_animation_count_3 = 0;
        let normal_rotate_animation_img_4 = '';
        let normal_rotate_animation_param_4 = null;
        let normal_rotate_animation_lastTime_4 = 0;
        let timer_anim_rotate_4;
        let normal_rotate_animation_count_4 = 0;
        let normal_rotate_animation_img_5 = '';
        let normal_rotate_animation_param_5 = null;
        let normal_rotate_animation_lastTime_5 = 0;
        let timer_anim_rotate_5;
        let normal_rotate_animation_count_5 = 0;
        let normal_rotate_animation_img_6 = '';
        let normal_rotate_animation_param_6 = null;
        let normal_rotate_animation_lastTime_6 = 0;
        let timer_anim_rotate_6;
        let timer_anim_rotate_6_mirror = false;
        let normal_rotate_animation_param_6_mirror = null;
        let normal_rotate_animation_count_6 = 0;
        let normal_rotate_animation_img_7 = '';
        let normal_rotate_animation_param_7 = null;
        let normal_rotate_animation_lastTime_7 = 0;
        let timer_anim_rotate_7;
        let normal_rotate_animation_count_7 = 0;
        let normal_rotate_animation_img_8 = '';
        let normal_rotate_animation_param_8 = null;
        let normal_rotate_animation_lastTime_8 = 0;
        let timer_anim_rotate_8;
        let normal_rotate_animation_count_8 = 0;
        let normal_rotate_animation_img_9 = '';
        let normal_rotate_animation_param_9 = null;
        let normal_rotate_animation_lastTime_9 = 0;
        let timer_anim_rotate_9;
        let normal_rotate_animation_count_9 = 0;
        let normal_rotate_animation_img_10 = '';
        let normal_rotate_animation_param_10 = null;
        let normal_rotate_animation_lastTime_10 = 0;
        let timer_anim_rotate_10;
        let normal_rotate_animation_count_10 = 0;
        let normal_rotate_animation_img_11 = '';
        let normal_rotate_animation_param_11 = null;
        let normal_rotate_animation_lastTime_11 = 0;
        let timer_anim_rotate_11;
        let normal_rotate_animation_count_11 = 0;
        let normal_rotate_animation_img_12 = '';
        let normal_rotate_animation_param_12 = null;
        let normal_rotate_animation_lastTime_12 = 0;
        let timer_anim_rotate_12;
        let normal_rotate_animation_count_12 = 0;
        let normal_rotate_animation_img_13 = '';
        let normal_rotate_animation_param_13 = null;
        let normal_rotate_animation_lastTime_13 = 0;
        let timer_anim_rotate_13;
        let normal_rotate_animation_count_13 = 0;
        let normal_rotate_animation_img_14 = '';
        let normal_rotate_animation_param_14 = null;
        let normal_rotate_animation_lastTime_14 = 0;
        let timer_anim_rotate_14;
        let normal_rotate_animation_count_14 = 0;
        let normal_rotate_animation_img_15 = '';
        let normal_rotate_animation_param_15 = null;
        let normal_rotate_animation_lastTime_15 = 0;
        let timer_anim_rotate_15;
        let normal_rotate_animation_count_15 = 0;
        let normal_image_img = ''
        let normal_date_img_date_day = ''
        let normal_date_img_date_month_img = ''
        let normal_date_img_date_week_img = ''
        let normal_date_img_date_year = ''
        let normal_calorie_current_text_img = ''
        let normal_heart_rate_text_text_img = ''
        let normal_distance_text_text_img = ''
        let normal_step_current_text_img = ''
        let normal_battery_icon_img = ''
        let normal_battery_text_text_img = ''
        let normal_battery_text_separator_img = ''
        let normal_battery_image_progress_img_level = ''
        let normal_digital_clock_img_time = ''
        let normal_analog_clock_time_pointer_hour = ''
        let normal_analog_clock_time_pointer_minute = ''
        let normal_analog_clock_time_pointer_second = ''
        let idle_background_bg_img = ''
        let idle_date_img_date_day = ''
        let idle_date_img_date_month_img = ''
        let idle_date_img_date_week_img = ''
        let idle_date_img_date_year = ''
        let idle_calorie_current_text_img = ''
        let idle_heart_rate_text_text_img = ''
        let idle_distance_text_text_img = ''
        let idle_step_current_text_img = ''
        let idle_battery_icon_img = ''
        let idle_battery_text_text_img = ''
        let idle_battery_text_separator_img = ''
        let idle_battery_image_progress_img_level = ''
        let idle_digital_clock_img_time = ''
        let idle_analog_clock_time_pointer_hour = ''
        let idle_analog_clock_time_pointer_minute = ''
        let idle_analog_clock_time_pointer_second = ''
        let Button_1 = ''
        let Button_2 = ''
        let Button_3 = ''
        let Button_4 = ''
        let Button_5 = ''
        let Button_6 = ''
        let Button_7 = ''
        let Button_8 = ''
        let Button_9 = ''
        let Button_10 = ''
        let Button_11 = ''
        let Button_12 = ''


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            console.log('Watch_Face.ScreenNormal');
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 466,
              h: 466,
              src: 'background.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_rotate_animation_img_1 = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 467,
              h: 467,
              pos_x: 292,
              pos_y: 63,
              center_x: 306,
              center_y: 77,
              angle: 0,
              src: 'animation/ring1_0.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_rotate_animation_param_1 = {
              anim_steps: [{
                anim_rate: 'linear',
                anim_duration: 10000,
                anim_from: 0,
                anim_to: 360,
                anim_key: "angle",
              }],
              anim_fps: 15,
              anim_auto_start: 1,
              anim_repeat: 1,
              anim_auto_destroy: 1,
            };

            let now = hmSensor.createSensor(hmSensor.id.TIME);

            function anim_rotate_1_complete_call() {
              normal_rotate_animation_img_1.setProperty(hmUI.prop.ANIM, normal_rotate_animation_param_1);
              normal_rotate_animation_lastTime_1 = now.utc;
              normal_rotate_animation_count_1 = normal_rotate_animation_count_1 - 1;
              if(normal_rotate_animation_count_1 < -1) normal_rotate_animation_count_1 = - 1;
              if(normal_rotate_animation_count_1 == 0) stop_anim_rotate_1();
            }; // end animation callback function
            
            function stop_anim_rotate_1() {
              if (timer_anim_rotate_1) {
                timer.stopTimer(timer_anim_rotate_1);
                timer_anim_rotate_1 = undefined;
              };
            }; // end stop_anim_rotate function

            // normal_rotate_anime_1 = hmUI.createWidget(hmUI.widget.Rotate_Animation, {
              // start_angle: 0,
              // end_angle: 360,
              // pos_x: 14,
              // pos_y: 14,
              // center_x: 306,
              // center_y: 77,
              // src: 'ring1_0.png',
              // anim_fps: 15,
              // anim_duration: 10000,
              // repeat_count: 0,
              // anim_two_sides: False,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_rotate_animation_img_2 = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 467,
              h: 467,
              pos_x: 310,
              pos_y: 77,
              center_x: 328,
              center_y: 95,
              angle: 360,
              src: 'animation/ring2_0.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_rotate_animation_param_2 = {
              anim_steps: [{
                anim_rate: 'linear',
                anim_duration: 10000,
                anim_from: 360,
                anim_to: 0,
                anim_key: "angle",
              }],
              anim_fps: 15,
              anim_auto_start: 1,
              anim_repeat: 1,
              anim_auto_destroy: 1,
            };

            function anim_rotate_2_complete_call() {
              normal_rotate_animation_img_2.setProperty(hmUI.prop.ANIM, normal_rotate_animation_param_2);
              normal_rotate_animation_lastTime_2 = now.utc;
              normal_rotate_animation_count_2 = normal_rotate_animation_count_2 - 1;
              if(normal_rotate_animation_count_2 < -1) normal_rotate_animation_count_2 = - 1;
              if(normal_rotate_animation_count_2 == 0) stop_anim_rotate_2();
            }; // end animation callback function
            
            function stop_anim_rotate_2() {
              if (timer_anim_rotate_2) {
                timer.stopTimer(timer_anim_rotate_2);
                timer_anim_rotate_2 = undefined;
              };
            }; // end stop_anim_rotate function

            // normal_rotate_anime_2 = hmUI.createWidget(hmUI.widget.Rotate_Animation, {
              // start_angle: 360,
              // end_angle: 0,
              // pos_x: 18,
              // pos_y: 18,
              // center_x: 328,
              // center_y: 95,
              // src: 'ring2_0.png',
              // anim_fps: 15,
              // anim_duration: 10000,
              // repeat_count: 0,
              // anim_two_sides: False,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_rotate_animation_img_3 = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 467,
              h: 467,
              pos_x: 310,
              pos_y: 106,
              center_x: 343,
              center_y: 138,
              angle: 0,
              src: 'animation/ring3_0.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_rotate_animation_param_3 = {
              anim_steps: [{
                anim_rate: 'linear',
                anim_duration: 13000,
                anim_from: 0,
                anim_to: 360,
                anim_key: "angle",
              }],
              anim_fps: 15,
              anim_auto_start: 1,
              anim_repeat: 1,
              anim_auto_destroy: 1,
            };

            function anim_rotate_3_complete_call() {
              normal_rotate_animation_img_3.setProperty(hmUI.prop.ANIM, normal_rotate_animation_param_3);
              normal_rotate_animation_lastTime_3 = now.utc;
              normal_rotate_animation_count_3 = normal_rotate_animation_count_3 - 1;
              if(normal_rotate_animation_count_3 < -1) normal_rotate_animation_count_3 = - 1;
              if(normal_rotate_animation_count_3 == 0) stop_anim_rotate_3();
            }; // end animation callback function
            
            function stop_anim_rotate_3() {
              if (timer_anim_rotate_3) {
                timer.stopTimer(timer_anim_rotate_3);
                timer_anim_rotate_3 = undefined;
              };
            }; // end stop_anim_rotate function

            // normal_rotate_anime_3 = hmUI.createWidget(hmUI.widget.Rotate_Animation, {
              // start_angle: 0,
              // end_angle: 360,
              // pos_x: 33,
              // pos_y: 32,
              // center_x: 343,
              // center_y: 138,
              // src: 'ring3_0.png',
              // anim_fps: 15,
              // anim_duration: 13000,
              // repeat_count: 0,
              // anim_two_sides: False,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_rotate_animation_img_4 = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 467,
              h: 467,
              pos_x: 352,
              pos_y: 153,
              center_x: 375,
              center_y: 176,
              angle: 360,
              src: 'animation/ring4_0.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_rotate_animation_param_4 = {
              anim_steps: [{
                anim_rate: 'linear',
                anim_duration: 13000,
                anim_from: 360,
                anim_to: 0,
                anim_key: "angle",
              }],
              anim_fps: 15,
              anim_auto_start: 1,
              anim_repeat: 1,
              anim_auto_destroy: 1,
            };

            function anim_rotate_4_complete_call() {
              normal_rotate_animation_img_4.setProperty(hmUI.prop.ANIM, normal_rotate_animation_param_4);
              normal_rotate_animation_lastTime_4 = now.utc;
              normal_rotate_animation_count_4 = normal_rotate_animation_count_4 - 1;
              if(normal_rotate_animation_count_4 < -1) normal_rotate_animation_count_4 = - 1;
              if(normal_rotate_animation_count_4 == 0) stop_anim_rotate_4();
            }; // end animation callback function
            
            function stop_anim_rotate_4() {
              if (timer_anim_rotate_4) {
                timer.stopTimer(timer_anim_rotate_4);
                timer_anim_rotate_4 = undefined;
              };
            }; // end stop_anim_rotate function

            // normal_rotate_anime_4 = hmUI.createWidget(hmUI.widget.Rotate_Animation, {
              // start_angle: 360,
              // end_angle: 0,
              // pos_x: 23,
              // pos_y: 23,
              // center_x: 375,
              // center_y: 176,
              // src: 'ring4_0.png',
              // anim_fps: 15,
              // anim_duration: 13000,
              // repeat_count: 0,
              // anim_two_sides: False,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_rotate_animation_img_5 = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 467,
              h: 467,
              pos_x: 182,
              pos_y: 103,
              center_x: 232,
              center_y: 153,
              angle: 0,
              src: 'animation/ring5_0.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_rotate_animation_param_5 = {
              anim_steps: [{
                anim_rate: 'linear',
                anim_duration: 13000,
                anim_from: 0,
                anim_to: 360,
                anim_key: "angle",
              }],
              anim_fps: 15,
              anim_auto_start: 1,
              anim_repeat: 1,
              anim_auto_destroy: 1,
            };

            function anim_rotate_5_complete_call() {
              normal_rotate_animation_img_5.setProperty(hmUI.prop.ANIM, normal_rotate_animation_param_5);
              normal_rotate_animation_lastTime_5 = now.utc;
              normal_rotate_animation_count_5 = normal_rotate_animation_count_5 - 1;
              if(normal_rotate_animation_count_5 < -1) normal_rotate_animation_count_5 = - 1;
              if(normal_rotate_animation_count_5 == 0) stop_anim_rotate_5();
            }; // end animation callback function
            
            function stop_anim_rotate_5() {
              if (timer_anim_rotate_5) {
                timer.stopTimer(timer_anim_rotate_5);
                timer_anim_rotate_5 = undefined;
              };
            }; // end stop_anim_rotate function

            // normal_rotate_anime_5 = hmUI.createWidget(hmUI.widget.Rotate_Animation, {
              // start_angle: 0,
              // end_angle: 360,
              // pos_x: 50,
              // pos_y: 50,
              // center_x: 232,
              // center_y: 153,
              // src: 'ring5_0.png',
              // anim_fps: 15,
              // anim_duration: 13000,
              // repeat_count: 0,
              // anim_two_sides: False,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_rotate_animation_img_6 = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 467,
              h: 467,
              pos_x: 195,
              pos_y: 116,
              center_x: 232,
              center_y: 153,
              angle: 0,
              src: 'animation/ring14_0.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_rotate_animation_param_6 = {
              anim_steps: [{
                anim_rate: 'linear',
                anim_duration: 1000,
                anim_from: 0,
                anim_to: 360,
                anim_key: "angle",
              }],
              anim_fps: 15,
              anim_auto_start: 1,
              anim_repeat: 1,
              anim_auto_destroy: 1,
            };

            normal_rotate_animation_param_6_mirror = {
              anim_steps: [{
                anim_rate: 'linear',
                anim_duration: 1000,
                anim_from: 360,
                anim_to: 0,
                anim_key: "angle",
              }],
              anim_fps: 15,
              anim_auto_start: 1,
              anim_repeat: 1,
              anim_auto_destroy: 1,
            };

            function anim_rotate_6_mirror() {
              normal_rotate_animation_img_6.setProperty(hmUI.prop.ANIM, normal_rotate_animation_param_6_mirror);
              normal_rotate_animation_lastTime_6 = now.utc;
              normal_rotate_animation_count_6 = normal_rotate_animation_count_6 - 1;
              if(normal_rotate_animation_count_6 < -1) normal_rotate_animation_count_6 = - 1;
              if(normal_rotate_animation_count_6 == 0) stop_anim_rotate_6();

            }; // end animation_mirror callback function

            function anim_rotate_6_complete_call() {
              normal_rotate_animation_img_6.setProperty(hmUI.prop.ANIM, normal_rotate_animation_param_6);
              normal_rotate_animation_lastTime_6 = now.utc;
            }; // end animation callback function
            
            function stop_anim_rotate_6() {
              if (timer_anim_rotate_6) {
                timer.stopTimer(timer_anim_rotate_6);
                timer_anim_rotate_6 = undefined;
              };
            }; // end stop_anim_rotate function

            // normal_rotate_anime_6 = hmUI.createWidget(hmUI.widget.Rotate_Animation, {
              // start_angle: 0,
              // end_angle: 360,
              // pos_x: 37,
              // pos_y: 37,
              // center_x: 232,
              // center_y: 153,
              // src: 'ring14_0.png',
              // anim_fps: 15,
              // anim_duration: 1000,
              // repeat_count: 0,
              // anim_two_sides: True,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_rotate_animation_img_7 = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 467,
              h: 467,
              pos_x: 109,
              pos_y: 70,
              center_x: 154,
              center_y: 114,
              angle: 360,
              src: 'animation/ring6_0.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_rotate_animation_param_7 = {
              anim_steps: [{
                anim_rate: 'linear',
                anim_duration: 13000,
                anim_from: 360,
                anim_to: 0,
                anim_key: "angle",
              }],
              anim_fps: 15,
              anim_auto_start: 1,
              anim_repeat: 1,
              anim_auto_destroy: 1,
            };

            function anim_rotate_7_complete_call() {
              normal_rotate_animation_img_7.setProperty(hmUI.prop.ANIM, normal_rotate_animation_param_7);
              normal_rotate_animation_lastTime_7 = now.utc;
              normal_rotate_animation_count_7 = normal_rotate_animation_count_7 - 1;
              if(normal_rotate_animation_count_7 < -1) normal_rotate_animation_count_7 = - 1;
              if(normal_rotate_animation_count_7 == 0) stop_anim_rotate_7();
            }; // end animation callback function
            
            function stop_anim_rotate_7() {
              if (timer_anim_rotate_7) {
                timer.stopTimer(timer_anim_rotate_7);
                timer_anim_rotate_7 = undefined;
              };
            }; // end stop_anim_rotate function

            // normal_rotate_anime_7 = hmUI.createWidget(hmUI.widget.Rotate_Animation, {
              // start_angle: 360,
              // end_angle: 0,
              // pos_x: 45,
              // pos_y: 44,
              // center_x: 154,
              // center_y: 114,
              // src: 'ring6_0.png',
              // anim_fps: 15,
              // anim_duration: 13000,
              // repeat_count: 0,
              // anim_two_sides: False,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_rotate_animation_img_8 = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 467,
              h: 467,
              pos_x: 362,
              pos_y: 206,
              center_x: 380,
              center_y: 224,
              angle: 0,
              src: 'animation/ring7_0.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_rotate_animation_param_8 = {
              anim_steps: [{
                anim_rate: 'linear',
                anim_duration: 6000,
                anim_from: 0,
                anim_to: 360,
                anim_key: "angle",
              }],
              anim_fps: 15,
              anim_auto_start: 1,
              anim_repeat: 1,
              anim_auto_destroy: 1,
            };

            function anim_rotate_8_complete_call() {
              normal_rotate_animation_img_8.setProperty(hmUI.prop.ANIM, normal_rotate_animation_param_8);
              normal_rotate_animation_lastTime_8 = now.utc;
              normal_rotate_animation_count_8 = normal_rotate_animation_count_8 - 1;
              if(normal_rotate_animation_count_8 < -1) normal_rotate_animation_count_8 = - 1;
              if(normal_rotate_animation_count_8 == 0) stop_anim_rotate_8();
            }; // end animation callback function
            
            function stop_anim_rotate_8() {
              if (timer_anim_rotate_8) {
                timer.stopTimer(timer_anim_rotate_8);
                timer_anim_rotate_8 = undefined;
              };
            }; // end stop_anim_rotate function

            // normal_rotate_anime_8 = hmUI.createWidget(hmUI.widget.Rotate_Animation, {
              // start_angle: 0,
              // end_angle: 360,
              // pos_x: 18,
              // pos_y: 18,
              // center_x: 380,
              // center_y: 224,
              // src: 'ring7_0.png',
              // anim_fps: 15,
              // anim_duration: 6000,
              // repeat_count: 0,
              // anim_two_sides: False,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_rotate_animation_img_9 = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 467,
              h: 467,
              pos_x: 393,
              pos_y: 209,
              center_x: 416,
              center_y: 232,
              angle: 0,
              src: 'animation/ring8_0.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_rotate_animation_param_9 = {
              anim_steps: [{
                anim_rate: 'linear',
                anim_duration: 8000,
                anim_from: 0,
                anim_to: 360,
                anim_key: "angle",
              }],
              anim_fps: 15,
              anim_auto_start: 1,
              anim_repeat: 1,
              anim_auto_destroy: 1,
            };

            function anim_rotate_9_complete_call() {
              normal_rotate_animation_img_9.setProperty(hmUI.prop.ANIM, normal_rotate_animation_param_9);
              normal_rotate_animation_lastTime_9 = now.utc;
              normal_rotate_animation_count_9 = normal_rotate_animation_count_9 - 1;
              if(normal_rotate_animation_count_9 < -1) normal_rotate_animation_count_9 = - 1;
              if(normal_rotate_animation_count_9 == 0) stop_anim_rotate_9();
            }; // end animation callback function
            
            function stop_anim_rotate_9() {
              if (timer_anim_rotate_9) {
                timer.stopTimer(timer_anim_rotate_9);
                timer_anim_rotate_9 = undefined;
              };
            }; // end stop_anim_rotate function

            // normal_rotate_anime_9 = hmUI.createWidget(hmUI.widget.Rotate_Animation, {
              // start_angle: 0,
              // end_angle: 360,
              // pos_x: 23,
              // pos_y: 23,
              // center_x: 416,
              // center_y: 232,
              // src: 'ring8_0.png',
              // anim_fps: 15,
              // anim_duration: 8000,
              // repeat_count: 0,
              // anim_two_sides: False,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_rotate_animation_img_10 = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 467,
              h: 467,
              pos_x: 313,
              pos_y: 226,
              center_x: 348,
              center_y: 260,
              angle: 360,
              src: 'animation/ring9_0.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_rotate_animation_param_10 = {
              anim_steps: [{
                anim_rate: 'linear',
                anim_duration: 10000,
                anim_from: 360,
                anim_to: 0,
                anim_key: "angle",
              }],
              anim_fps: 15,
              anim_auto_start: 1,
              anim_repeat: 1,
              anim_auto_destroy: 1,
            };

            function anim_rotate_10_complete_call() {
              normal_rotate_animation_img_10.setProperty(hmUI.prop.ANIM, normal_rotate_animation_param_10);
              normal_rotate_animation_lastTime_10 = now.utc;
              normal_rotate_animation_count_10 = normal_rotate_animation_count_10 - 1;
              if(normal_rotate_animation_count_10 < -1) normal_rotate_animation_count_10 = - 1;
              if(normal_rotate_animation_count_10 == 0) stop_anim_rotate_10();
            }; // end animation callback function
            
            function stop_anim_rotate_10() {
              if (timer_anim_rotate_10) {
                timer.stopTimer(timer_anim_rotate_10);
                timer_anim_rotate_10 = undefined;
              };
            }; // end stop_anim_rotate function

            // normal_rotate_anime_10 = hmUI.createWidget(hmUI.widget.Rotate_Animation, {
              // start_angle: 360,
              // end_angle: 0,
              // pos_x: 35,
              // pos_y: 34,
              // center_x: 348,
              // center_y: 260,
              // src: 'ring9_0.png',
              // anim_fps: 15,
              // anim_duration: 10000,
              // repeat_count: 0,
              // anim_two_sides: False,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_rotate_animation_img_11 = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 467,
              h: 467,
              pos_x: 260,
              pos_y: 266,
              center_x: 299,
              center_y: 304,
              angle: 0,
              src: 'animation/ring10_0.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_rotate_animation_param_11 = {
              anim_steps: [{
                anim_rate: 'linear',
                anim_duration: 9000,
                anim_from: 0,
                anim_to: 360,
                anim_key: "angle",
              }],
              anim_fps: 15,
              anim_auto_start: 1,
              anim_repeat: 1,
              anim_auto_destroy: 1,
            };

            function anim_rotate_11_complete_call() {
              normal_rotate_animation_img_11.setProperty(hmUI.prop.ANIM, normal_rotate_animation_param_11);
              normal_rotate_animation_lastTime_11 = now.utc;
              normal_rotate_animation_count_11 = normal_rotate_animation_count_11 - 1;
              if(normal_rotate_animation_count_11 < -1) normal_rotate_animation_count_11 = - 1;
              if(normal_rotate_animation_count_11 == 0) stop_anim_rotate_11();
            }; // end animation callback function
            
            function stop_anim_rotate_11() {
              if (timer_anim_rotate_11) {
                timer.stopTimer(timer_anim_rotate_11);
                timer_anim_rotate_11 = undefined;
              };
            }; // end stop_anim_rotate function

            // normal_rotate_anime_11 = hmUI.createWidget(hmUI.widget.Rotate_Animation, {
              // start_angle: 0,
              // end_angle: 360,
              // pos_x: 39,
              // pos_y: 38,
              // center_x: 299,
              // center_y: 304,
              // src: 'ring10_0.png',
              // anim_fps: 15,
              // anim_duration: 9000,
              // repeat_count: 0,
              // anim_two_sides: False,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_rotate_animation_img_12 = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 467,
              h: 467,
              pos_x: 207,
              pos_y: 299,
              center_x: 242,
              center_y: 333,
              angle: 360,
              src: 'animation/ring11_0.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_rotate_animation_param_12 = {
              anim_steps: [{
                anim_rate: 'linear',
                anim_duration: 8000,
                anim_from: 360,
                anim_to: 0,
                anim_key: "angle",
              }],
              anim_fps: 15,
              anim_auto_start: 1,
              anim_repeat: 1,
              anim_auto_destroy: 1,
            };

            function anim_rotate_12_complete_call() {
              normal_rotate_animation_img_12.setProperty(hmUI.prop.ANIM, normal_rotate_animation_param_12);
              normal_rotate_animation_lastTime_12 = now.utc;
              normal_rotate_animation_count_12 = normal_rotate_animation_count_12 - 1;
              if(normal_rotate_animation_count_12 < -1) normal_rotate_animation_count_12 = - 1;
              if(normal_rotate_animation_count_12 == 0) stop_anim_rotate_12();
            }; // end animation callback function
            
            function stop_anim_rotate_12() {
              if (timer_anim_rotate_12) {
                timer.stopTimer(timer_anim_rotate_12);
                timer_anim_rotate_12 = undefined;
              };
            }; // end stop_anim_rotate function

            // normal_rotate_anime_12 = hmUI.createWidget(hmUI.widget.Rotate_Animation, {
              // start_angle: 360,
              // end_angle: 0,
              // pos_x: 35,
              // pos_y: 34,
              // center_x: 242,
              // center_y: 333,
              // src: 'ring11_0.png',
              // anim_fps: 15,
              // anim_duration: 8000,
              // repeat_count: 0,
              // anim_two_sides: False,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_rotate_animation_img_13 = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 467,
              h: 467,
              pos_x: 0,
              pos_y: 0,
              center_x: 233,
              center_y: 233,
              angle: 0,
              src: 'animation/second_0.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_rotate_animation_param_13 = {
              anim_steps: [{
                anim_rate: 'linear',
                anim_duration: 1000,
                anim_from: 0,
                anim_to: 360,
                anim_key: "angle",
              }],
              anim_fps: 15,
              anim_auto_start: 1,
              anim_repeat: 1,
              anim_auto_destroy: 1,
            };

            function anim_rotate_13_complete_call() {
              normal_rotate_animation_img_13.setProperty(hmUI.prop.ANIM, normal_rotate_animation_param_13);
              normal_rotate_animation_lastTime_13 = now.utc;
              normal_rotate_animation_count_13 = normal_rotate_animation_count_13 - 1;
              if(normal_rotate_animation_count_13 < -1) normal_rotate_animation_count_13 = - 1;
              if(normal_rotate_animation_count_13 == 0) stop_anim_rotate_13();
            }; // end animation callback function
            
            function stop_anim_rotate_13() {
              if (timer_anim_rotate_13) {
                timer.stopTimer(timer_anim_rotate_13);
                timer_anim_rotate_13 = undefined;
              };
            }; // end stop_anim_rotate function

            // normal_rotate_anime_13 = hmUI.createWidget(hmUI.widget.Rotate_Animation, {
              // start_angle: 0,
              // end_angle: 360,
              // pos_x: 233,
              // pos_y: 233,
              // center_x: 233,
              // center_y: 233,
              // src: 'second_0.png',
              // anim_fps: 15,
              // anim_duration: 1000,
              // repeat_count: 0,
              // anim_two_sides: False,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_rotate_animation_img_14 = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 467,
              h: 467,
              pos_x: 123,
              pos_y: 321,
              center_x: 144,
              center_y: 342,
              angle: 360,
              src: 'animation/ring12_0.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_rotate_animation_param_14 = {
              anim_steps: [{
                anim_rate: 'linear',
                anim_duration: 16000,
                anim_from: 360,
                anim_to: 0,
                anim_key: "angle",
              }],
              anim_fps: 15,
              anim_auto_start: 1,
              anim_repeat: 1,
              anim_auto_destroy: 1,
            };

            function anim_rotate_14_complete_call() {
              normal_rotate_animation_img_14.setProperty(hmUI.prop.ANIM, normal_rotate_animation_param_14);
              normal_rotate_animation_lastTime_14 = now.utc;
              normal_rotate_animation_count_14 = normal_rotate_animation_count_14 - 1;
              if(normal_rotate_animation_count_14 < -1) normal_rotate_animation_count_14 = - 1;
              if(normal_rotate_animation_count_14 == 0) stop_anim_rotate_14();
            }; // end animation callback function
            
            function stop_anim_rotate_14() {
              if (timer_anim_rotate_14) {
                timer.stopTimer(timer_anim_rotate_14);
                timer_anim_rotate_14 = undefined;
              };
            }; // end stop_anim_rotate function

            // normal_rotate_anime_14 = hmUI.createWidget(hmUI.widget.Rotate_Animation, {
              // start_angle: 360,
              // end_angle: 0,
              // pos_x: 21,
              // pos_y: 21,
              // center_x: 144,
              // center_y: 342,
              // src: 'ring12_0.png',
              // anim_fps: 15,
              // anim_duration: 16000,
              // repeat_count: 0,
              // anim_two_sides: False,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_rotate_animation_img_15 = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 467,
              h: 467,
              pos_x: 67,
              pos_y: 195,
              center_x: 117,
              center_y: 245,
              angle: 0,
              src: 'animation/ring13_0.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_rotate_animation_param_15 = {
              anim_steps: [{
                anim_rate: 'linear',
                anim_duration: 16000,
                anim_from: 0,
                anim_to: 360,
                anim_key: "angle",
              }],
              anim_fps: 15,
              anim_auto_start: 1,
              anim_repeat: 1,
              anim_auto_destroy: 1,
            };

            function anim_rotate_15_complete_call() {
              normal_rotate_animation_img_15.setProperty(hmUI.prop.ANIM, normal_rotate_animation_param_15);
              normal_rotate_animation_lastTime_15 = now.utc;
              normal_rotate_animation_count_15 = normal_rotate_animation_count_15 - 1;
              if(normal_rotate_animation_count_15 < -1) normal_rotate_animation_count_15 = - 1;
              if(normal_rotate_animation_count_15 == 0) stop_anim_rotate_15();
            }; // end animation callback function
            
            function stop_anim_rotate_15() {
              if (timer_anim_rotate_15) {
                timer.stopTimer(timer_anim_rotate_15);
                timer_anim_rotate_15 = undefined;
              };
            }; // end stop_anim_rotate function

            // normal_rotate_anime_15 = hmUI.createWidget(hmUI.widget.Rotate_Animation, {
              // start_angle: 0,
              // end_angle: 360,
              // pos_x: 50,
              // pos_y: 50,
              // center_x: 117,
              // center_y: 245,
              // src: 'ring13_0.png',
              // anim_fps: 15,
              // anim_duration: 16000,
              // repeat_count: 0,
              // anim_two_sides: False,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_image_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'image.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 218,
              day_startY: 354,
              day_sc_array: ["act_0.png","act_1.png","act_2.png","act_3.png","act_4.png","act_5.png","act_6.png","act_7.png","act_8.png","act_9.png"],
              day_tc_array: ["act_0.png","act_1.png","act_2.png","act_3.png","act_4.png","act_5.png","act_6.png","act_7.png","act_8.png","act_9.png"],
              day_en_array: ["act_0.png","act_1.png","act_2.png","act_3.png","act_4.png","act_5.png","act_6.png","act_7.png","act_8.png","act_9.png"],
              day_zero: 0,
              day_space: 0,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_month_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 198,
              month_startY: 316,
              month_sc_array: ["month_1.png","month_2.png","month_3.png","month_4.png","month_5.png","month_6.png","month_7.png","month_8.png","month_9.png","month_10.png","month_11.png","month_12.png"],
              month_tc_array: ["month_1.png","month_2.png","month_3.png","month_4.png","month_5.png","month_6.png","month_7.png","month_8.png","month_9.png","month_10.png","month_11.png","month_12.png"],
              month_en_array: ["month_1.png","month_2.png","month_3.png","month_4.png","month_5.png","month_6.png","month_7.png","month_8.png","month_9.png","month_10.png","month_11.png","month_12.png"],
              month_is_character: true ,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 198,
              y: 65,
              week_en: ["day_1.png","day_2.png","day_3.png","day_4.png","day_5.png","day_6.png","day_7.png"],
              week_tc: ["day_1.png","day_2.png","day_3.png","day_4.png","day_5.png","day_6.png","day_7.png"],
              week_sc: ["day_1.png","day_2.png","day_3.png","day_4.png","day_5.png","day_6.png","day_7.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_year = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              year_startX: 203,
              year_startY: 286,
              year_sc_array: ["act_0.png","act_1.png","act_2.png","act_3.png","act_4.png","act_5.png","act_6.png","act_7.png","act_8.png","act_9.png"],
              year_tc_array: ["act_0.png","act_1.png","act_2.png","act_3.png","act_4.png","act_5.png","act_6.png","act_7.png","act_8.png","act_9.png"],
              year_en_array: ["act_0.png","act_1.png","act_2.png","act_3.png","act_4.png","act_5.png","act_6.png","act_7.png","act_8.png","act_9.png"],
              year_zero: 1,
              year_space: 0,
              year_align: hmUI.align.CENTER_H,
              year_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_calorie_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 104,
              y: 248,
              font_array: ["act_0.png","act_1.png","act_2.png","act_3.png","act_4.png","act_5.png","act_6.png","act_7.png","act_8.png","act_9.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 120,
              y: 306,
              font_array: ["act_0.png","act_1.png","act_2.png","act_3.png","act_4.png","act_5.png","act_6.png","act_7.png","act_8.png","act_9.png"],
              padding: false,
              h_space: 0,
              invalid_image: 'dot.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_distance_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 294,
              y: 306,
              font_array: ["act_0.png","act_1.png","act_2.png","act_3.png","act_4.png","act_5.png","act_6.png","act_7.png","act_8.png","act_9.png"],
              padding: false,
              h_space: -1,
              unit_sc: 'dot.png',
              unit_tc: 'dot.png',
              unit_en: 'dot.png',
              imperial_unit_sc: 'dot.png',
              imperial_unit_tc: 'dot.png',
              imperial_unit_en: 'dot.png',
              dot_image: 'pointer_0.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.DISTANCE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 297,
              y: 248,
              font_array: ["act_0.png","act_1.png","act_2.png","act_3.png","act_4.png","act_5.png","act_6.png","act_7.png","act_8.png","act_9.png"],
              padding: false,
              h_space: -1,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'icon_bat.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 205,
              y: 158,
              font_array: ["act_0.png","act_1.png","act_2.png","act_3.png","act_4.png","act_5.png","act_6.png","act_7.png","act_8.png","act_9.png"],
              padding: false,
              h_space: -1,
              unit_sc: 'percent.png',
              unit_tc: 'percent.png',
              unit_en: 'percent.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 217,
              y: 184,
              src: 'icon_bat.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 220,
              y: 187,
              image_array: ["img_bat_1.png","img_bat_2.png","img_bat_3.png","img_bat_4.png","img_bat_5.png","img_bat_6.png","img_bat_7.png","img_bat_8.png","img_bat_9.png","img_bat_10.png"],
              image_length: 10,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 183,
              hour_startY: 403,
              hour_array: ["act_0.png","act_1.png","act_2.png","act_3.png","act_4.png","act_5.png","act_6.png","act_7.png","act_8.png","act_9.png"],
              hour_zero: 1,
              hour_space: 0,
              hour_angle: 0,
              hour_unit_sc: 'pointer_1.png',
              hour_unit_tc: 'pointer_1.png',
              hour_unit_en: 'pointer_1.png',
              hour_align: hmUI.align.LEFT,

              minute_startX: 218,
              minute_startY: 403,
              minute_array: ["act_0.png","act_1.png","act_2.png","act_3.png","act_4.png","act_5.png","act_6.png","act_7.png","act_8.png","act_9.png"],
              minute_zero: 1,
              minute_space: 0,
              minute_angle: 0,
              minute_follow: 0,
              minute_unit_sc: 'pointer_1.png',
              minute_unit_tc: 'pointer_1.png',
              minute_unit_en: 'pointer_1.png',
              minute_align: hmUI.align.LEFT,

              second_startX: 254,
              second_startY: 403,
              second_array: ["act_0.png","act_1.png","act_2.png","act_3.png","act_4.png","act_5.png","act_6.png","act_7.png","act_8.png","act_9.png"],
              second_zero: 1,
              second_space: 0,
              second_angle: 0,
              second_follow: 0,
              second_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_hour = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              hour_path: 'hour.png',
              hour_centerX: 233,
              hour_centerY: 233,
              hour_posX: 8,
              hour_posY: 142,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_minute = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              minute_path: 'minute.png',
              minute_centerX: 233,
              minute_centerY: 233,
              minute_posX: 7,
              minute_posY: 205,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_second = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              second_path: 'second.png',
              second_centerX: 233,
              second_centerY: 233,
              second_posX: 16,
              second_posY: 222,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            console.log('Watch_Face.ScreenAOD');
            idle_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 466,
              h: 466,
              src: 'aod.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 218,
              day_startY: 354,
              day_sc_array: ["act_0.png","act_1.png","act_2.png","act_3.png","act_4.png","act_5.png","act_6.png","act_7.png","act_8.png","act_9.png"],
              day_tc_array: ["act_0.png","act_1.png","act_2.png","act_3.png","act_4.png","act_5.png","act_6.png","act_7.png","act_8.png","act_9.png"],
              day_en_array: ["act_0.png","act_1.png","act_2.png","act_3.png","act_4.png","act_5.png","act_6.png","act_7.png","act_8.png","act_9.png"],
              day_zero: 0,
              day_space: 0,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_month_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 198,
              month_startY: 316,
              month_sc_array: ["month_1.png","month_2.png","month_3.png","month_4.png","month_5.png","month_6.png","month_7.png","month_8.png","month_9.png","month_10.png","month_11.png","month_12.png"],
              month_tc_array: ["month_1.png","month_2.png","month_3.png","month_4.png","month_5.png","month_6.png","month_7.png","month_8.png","month_9.png","month_10.png","month_11.png","month_12.png"],
              month_en_array: ["month_1.png","month_2.png","month_3.png","month_4.png","month_5.png","month_6.png","month_7.png","month_8.png","month_9.png","month_10.png","month_11.png","month_12.png"],
              month_is_character: true ,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 198,
              y: 65,
              week_en: ["day_1.png","day_2.png","day_3.png","day_4.png","day_5.png","day_6.png","day_7.png"],
              week_tc: ["day_1.png","day_2.png","day_3.png","day_4.png","day_5.png","day_6.png","day_7.png"],
              week_sc: ["day_1.png","day_2.png","day_3.png","day_4.png","day_5.png","day_6.png","day_7.png"],
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_year = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              year_startX: 203,
              year_startY: 286,
              year_sc_array: ["act_0.png","act_1.png","act_2.png","act_3.png","act_4.png","act_5.png","act_6.png","act_7.png","act_8.png","act_9.png"],
              year_tc_array: ["act_0.png","act_1.png","act_2.png","act_3.png","act_4.png","act_5.png","act_6.png","act_7.png","act_8.png","act_9.png"],
              year_en_array: ["act_0.png","act_1.png","act_2.png","act_3.png","act_4.png","act_5.png","act_6.png","act_7.png","act_8.png","act_9.png"],
              year_zero: 1,
              year_space: 0,
              year_align: hmUI.align.CENTER_H,
              year_is_character: false,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_calorie_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 104,
              y: 248,
              font_array: ["act_0.png","act_1.png","act_2.png","act_3.png","act_4.png","act_5.png","act_6.png","act_7.png","act_8.png","act_9.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 120,
              y: 306,
              font_array: ["act_0.png","act_1.png","act_2.png","act_3.png","act_4.png","act_5.png","act_6.png","act_7.png","act_8.png","act_9.png"],
              padding: false,
              h_space: 0,
              invalid_image: 'dot.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_distance_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 294,
              y: 306,
              font_array: ["act_0.png","act_1.png","act_2.png","act_3.png","act_4.png","act_5.png","act_6.png","act_7.png","act_8.png","act_9.png"],
              padding: false,
              h_space: -1,
              unit_sc: 'dot.png',
              unit_tc: 'dot.png',
              unit_en: 'dot.png',
              imperial_unit_sc: 'dot.png',
              imperial_unit_tc: 'dot.png',
              imperial_unit_en: 'dot.png',
              dot_image: 'pointer_0.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.DISTANCE,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 297,
              y: 248,
              font_array: ["act_0.png","act_1.png","act_2.png","act_3.png","act_4.png","act_5.png","act_6.png","act_7.png","act_8.png","act_9.png"],
              padding: false,
              h_space: -1,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_battery_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'icon_bat.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 205,
              y: 158,
              font_array: ["act_0.png","act_1.png","act_2.png","act_3.png","act_4.png","act_5.png","act_6.png","act_7.png","act_8.png","act_9.png"],
              padding: false,
              h_space: -1,
              unit_sc: 'percent.png',
              unit_tc: 'percent.png',
              unit_en: 'percent.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_battery_text_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 217,
              y: 184,
              src: 'icon_bat.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_battery_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 220,
              y: 187,
              image_array: ["img_bat_1.png","img_bat_2.png","img_bat_3.png","img_bat_4.png","img_bat_5.png","img_bat_6.png","img_bat_7.png","img_bat_8.png","img_bat_9.png","img_bat_10.png"],
              image_length: 10,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 183,
              hour_startY: 403,
              hour_array: ["act_0.png","act_1.png","act_2.png","act_3.png","act_4.png","act_5.png","act_6.png","act_7.png","act_8.png","act_9.png"],
              hour_zero: 1,
              hour_space: 0,
              hour_angle: 0,
              hour_unit_sc: 'pointer_1.png',
              hour_unit_tc: 'pointer_1.png',
              hour_unit_en: 'pointer_1.png',
              hour_align: hmUI.align.LEFT,

              minute_startX: 218,
              minute_startY: 403,
              minute_array: ["act_0.png","act_1.png","act_2.png","act_3.png","act_4.png","act_5.png","act_6.png","act_7.png","act_8.png","act_9.png"],
              minute_zero: 1,
              minute_space: 0,
              minute_angle: 0,
              minute_follow: 0,
              minute_unit_sc: 'pointer_1.png',
              minute_unit_tc: 'pointer_1.png',
              minute_unit_en: 'pointer_1.png',
              minute_align: hmUI.align.LEFT,

              second_startX: 254,
              second_startY: 403,
              second_array: ["act_0.png","act_1.png","act_2.png","act_3.png","act_4.png","act_5.png","act_6.png","act_7.png","act_8.png","act_9.png"],
              second_zero: 1,
              second_space: 0,
              second_angle: 0,
              second_follow: 0,
              second_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_analog_clock_time_pointer_hour = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              hour_path: 'hour_1.png',
              hour_centerX: 233,
              hour_centerY: 233,
              hour_posX: 8,
              hour_posY: 142,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_analog_clock_time_pointer_minute = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              minute_path: 'minute_1.png',
              minute_centerX: 233,
              minute_centerY: 233,
              minute_posX: 7,
              minute_posY: 205,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_analog_clock_time_pointer_second = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              second_path: 'second.png',
              second_centerX: 233,
              second_centerY: 233,
              second_posX: 16,
              second_posY: 222,
              show_level: hmUI.show_level.ONLY_AOD,
            });
            
            // disconnectAlert = hmUI.createWidget(hmUI.widget.DisconnectAlert, {
              // disconneсnt_vibrate_type: 25,
              // disconneсnt_toast_text: The bluetooth device has been disconnected!,
              // conneсnt_vibrate_type: 25,
              // conneсnt_toast_text: The Bluetooth device has been reconnected.,
            // });

            // vibration when connecting or disconnecting

            function checkConnection() {
              console.log('checkConnection()');
              hmBle.removeListener;
              hmBle.addListener(function (status) {
                if(!status) {
                  hmUI.showToast({text: "The bluetooth device has been disconnected!"});
                  vibro(25);
                }
                if(status) {
                  hmUI.showToast({text: "The Bluetooth device has been reconnected."});
                  vibro(25);
                }
              });
            }

            // end vibration when connecting or disconnecting
            // vibrate function

            const vibrate = hmSensor.createSensor(hmSensor.id.VIBRATE);
            let timer_StopVibrate = null;


            function vibro(scene = 25) {
              let stopDelay = 50;
              stopVibro();
              vibrate.stop();
              vibrate.scene = scene;
              if(scene < 23 || scene > 25) stopDelay = 1300;
              vibrate.start();
              if (scene != 1) timer_StopVibrate = timer.createTimer(stopDelay, 3000, stopVibro, {});
            }

            function stopVibro(){
              vibrate.stop();
              if(timer_StopVibrate) timer.stopTimer(timer_StopVibrate);
            }

            // end vibrate function

            console.log('Watch_Face.Buttons');
            Button_1 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 0,
              y: 152,
              w: 97,
              h: 55,
              text: '',
              color: 0xFFFF8C00,
              text_size: 24,
              press_src: 'pai_2.png',
              normal_src: 'pai_1.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'PAI_app_Screen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_2 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 47,
              y: 67,
              w: 97,
              h: 55,
              text: '',
              color: 0xFFFF8C00,
              text_size: 24,
              press_src: 'spo_2.png',
              normal_src: 'spo_1.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'spo_HomeScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_3 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 324,
              y: 67,
              w: 97,
              h: 55,
              text: '',
              color: 0xFFFF8C00,
              text_size: 24,
              press_src: 'stress_2.png',
              normal_src: 'stress_1.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'StressHomeScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_4 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 370,
              y: 154,
              w: 97,
              h: 55,
              text: '',
              color: 0xFFFF8C00,
              text_size: 24,
              press_src: 'music_2.png',
              normal_src: 'music_1.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'PhoneMusicCtrlScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_5 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 370,
              y: 255,
              w: 97,
              h: 55,
              text: '',
              color: 0xFFFF8C00,
              text_size: 24,
              press_src: 'sleep_2.png',
              normal_src: 'sleep_1.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'Sleep_HomeScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_6 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 315,
              y: 343,
              w: 97,
              h: 63,
              text: '',
              color: 0xFFFF8C00,
              text_size: 24,
              press_src: 'barometer_2.png',
              normal_src: 'barometer_1.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'BaroAltimeterScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_7 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 53,
              y: 341,
              w: 97,
              h: 63,
              text: '',
              color: 0xFFFF8C00,
              text_size: 24,
              press_src: 'weather_2.png',
              normal_src: 'weather_1.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'WeatherScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_8 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: -1,
              y: 251,
              w: 97,
              h: 63,
              text: '',
              color: 0xFFFF8C00,
              text_size: 24,
              press_src: 'alarm_2.png',
              normal_src: 'alarm_1.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'AlarmInfoScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_9 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 190,
              y: 144,
              w: 83,
              h: 63,
              text: '',
              color: 0xFFFF8C00,
              text_size: 24,
              press_src: 'dot.png',
              normal_src: 'dot.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'LowBatteryScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_10 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 190,
              y: 58,
              w: 83,
              h: 63,
              text: '',
              color: 0xFFFF8C00,
              text_size: 24,
              press_src: 'dot.png',
              normal_src: 'dot.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'ScheduleCalScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_11 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 287,
              y: 235,
              w: 79,
              h: 63,
              text: '',
              color: 0xFFFF8C00,
              text_size: 24,
              press_src: 'dot.png',
              normal_src: 'dot.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'activityAppScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_12 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 99,
              y: 262,
              w: 79,
              h: 63,
              text: '',
              color: 0xFFFF8C00,
              text_size: 24,
              press_src: 'dot.png',
              normal_src: 'dot.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'heart_app_Screen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                console.log('resume_call()');

                let nawAnimationTime = now.utc;;
                
                let delay_anim_rotate_1 = 0;
                let repeat_anim_rotate_1 = 10000;
                delay_anim_rotate_1 = repeat_anim_rotate_1 - (nawAnimationTime - normal_rotate_animation_lastTime_1);
                if(delay_anim_rotate_1 < 0) delay_anim_rotate_1 = 0; 
                if((nawAnimationTime - normal_rotate_animation_lastTime_1) > repeat_anim_rotate_1) {
                  normal_rotate_animation_count_1 = 0;
                  timer_anim_rotate_1_mirror = false;
                };

                if (!timer_anim_rotate_1) {
                  timer_anim_rotate_1 = timer.createTimer(delay_anim_rotate_1, repeat_anim_rotate_1, (function (option) {
                    anim_rotate_1_complete_call()
                  })); // end timer create
                };
                
                let delay_anim_rotate_2 = 0;
                let repeat_anim_rotate_2 = 10000;
                delay_anim_rotate_2 = repeat_anim_rotate_2 - (nawAnimationTime - normal_rotate_animation_lastTime_2);
                if(delay_anim_rotate_2 < 0) delay_anim_rotate_2 = 0; 
                if((nawAnimationTime - normal_rotate_animation_lastTime_2) > repeat_anim_rotate_2) {
                  normal_rotate_animation_count_2 = 0;
                  timer_anim_rotate_2_mirror = false;
                };

                if (!timer_anim_rotate_2) {
                  timer_anim_rotate_2 = timer.createTimer(delay_anim_rotate_2, repeat_anim_rotate_2, (function (option) {
                    anim_rotate_2_complete_call()
                  })); // end timer create
                };
                
                let delay_anim_rotate_3 = 0;
                let repeat_anim_rotate_3 = 13000;
                delay_anim_rotate_3 = repeat_anim_rotate_3 - (nawAnimationTime - normal_rotate_animation_lastTime_3);
                if(delay_anim_rotate_3 < 0) delay_anim_rotate_3 = 0; 
                if((nawAnimationTime - normal_rotate_animation_lastTime_3) > repeat_anim_rotate_3) {
                  normal_rotate_animation_count_3 = 0;
                  timer_anim_rotate_3_mirror = false;
                };

                if (!timer_anim_rotate_3) {
                  timer_anim_rotate_3 = timer.createTimer(delay_anim_rotate_3, repeat_anim_rotate_3, (function (option) {
                    anim_rotate_3_complete_call()
                  })); // end timer create
                };
                
                let delay_anim_rotate_4 = 0;
                let repeat_anim_rotate_4 = 13000;
                delay_anim_rotate_4 = repeat_anim_rotate_4 - (nawAnimationTime - normal_rotate_animation_lastTime_4);
                if(delay_anim_rotate_4 < 0) delay_anim_rotate_4 = 0; 
                if((nawAnimationTime - normal_rotate_animation_lastTime_4) > repeat_anim_rotate_4) {
                  normal_rotate_animation_count_4 = 0;
                  timer_anim_rotate_4_mirror = false;
                };

                if (!timer_anim_rotate_4) {
                  timer_anim_rotate_4 = timer.createTimer(delay_anim_rotate_4, repeat_anim_rotate_4, (function (option) {
                    anim_rotate_4_complete_call()
                  })); // end timer create
                };
                
                let delay_anim_rotate_5 = 0;
                let repeat_anim_rotate_5 = 13000;
                delay_anim_rotate_5 = repeat_anim_rotate_5 - (nawAnimationTime - normal_rotate_animation_lastTime_5);
                if(delay_anim_rotate_5 < 0) delay_anim_rotate_5 = 0; 
                if((nawAnimationTime - normal_rotate_animation_lastTime_5) > repeat_anim_rotate_5) {
                  normal_rotate_animation_count_5 = 0;
                  timer_anim_rotate_5_mirror = false;
                };

                if (!timer_anim_rotate_5) {
                  timer_anim_rotate_5 = timer.createTimer(delay_anim_rotate_5, repeat_anim_rotate_5, (function (option) {
                    anim_rotate_5_complete_call()
                  })); // end timer create
                };
                
                let delay_anim_rotate_6 = 0;
                let repeat_anim_rotate_6 = 1000;
                delay_anim_rotate_6 = repeat_anim_rotate_6 - (nawAnimationTime - normal_rotate_animation_lastTime_6);
                if(delay_anim_rotate_6 < 0) delay_anim_rotate_6 = 0; 
                if((nawAnimationTime - normal_rotate_animation_lastTime_6) > repeat_anim_rotate_6*2) {
                  normal_rotate_animation_count_6 = 0;
                  timer_anim_rotate_6_mirror = false;
                };

                if (!timer_anim_rotate_6) {
                  timer_anim_rotate_6 = timer.createTimer(delay_anim_rotate_6, repeat_anim_rotate_6, (function (option) {
                    if(timer_anim_rotate_6_mirror) {
                      anim_rotate_6_mirror()
                    } else {
                      anim_rotate_6_complete_call()
                    };
                    timer_anim_rotate_6_mirror = !timer_anim_rotate_6_mirror;
                  })); // end timer create
                };
                
                let delay_anim_rotate_7 = 0;
                let repeat_anim_rotate_7 = 13000;
                delay_anim_rotate_7 = repeat_anim_rotate_7 - (nawAnimationTime - normal_rotate_animation_lastTime_7);
                if(delay_anim_rotate_7 < 0) delay_anim_rotate_7 = 0; 
                if((nawAnimationTime - normal_rotate_animation_lastTime_7) > repeat_anim_rotate_7) {
                  normal_rotate_animation_count_7 = 0;
                  timer_anim_rotate_7_mirror = false;
                };

                if (!timer_anim_rotate_7) {
                  timer_anim_rotate_7 = timer.createTimer(delay_anim_rotate_7, repeat_anim_rotate_7, (function (option) {
                    anim_rotate_7_complete_call()
                  })); // end timer create
                };
                
                let delay_anim_rotate_8 = 0;
                let repeat_anim_rotate_8 = 6000;
                delay_anim_rotate_8 = repeat_anim_rotate_8 - (nawAnimationTime - normal_rotate_animation_lastTime_8);
                if(delay_anim_rotate_8 < 0) delay_anim_rotate_8 = 0; 
                if((nawAnimationTime - normal_rotate_animation_lastTime_8) > repeat_anim_rotate_8) {
                  normal_rotate_animation_count_8 = 0;
                  timer_anim_rotate_8_mirror = false;
                };

                if (!timer_anim_rotate_8) {
                  timer_anim_rotate_8 = timer.createTimer(delay_anim_rotate_8, repeat_anim_rotate_8, (function (option) {
                    anim_rotate_8_complete_call()
                  })); // end timer create
                };
                
                let delay_anim_rotate_9 = 0;
                let repeat_anim_rotate_9 = 8000;
                delay_anim_rotate_9 = repeat_anim_rotate_9 - (nawAnimationTime - normal_rotate_animation_lastTime_9);
                if(delay_anim_rotate_9 < 0) delay_anim_rotate_9 = 0; 
                if((nawAnimationTime - normal_rotate_animation_lastTime_9) > repeat_anim_rotate_9) {
                  normal_rotate_animation_count_9 = 0;
                  timer_anim_rotate_9_mirror = false;
                };

                if (!timer_anim_rotate_9) {
                  timer_anim_rotate_9 = timer.createTimer(delay_anim_rotate_9, repeat_anim_rotate_9, (function (option) {
                    anim_rotate_9_complete_call()
                  })); // end timer create
                };
                
                let delay_anim_rotate_10 = 0;
                let repeat_anim_rotate_10 = 10000;
                delay_anim_rotate_10 = repeat_anim_rotate_10 - (nawAnimationTime - normal_rotate_animation_lastTime_10);
                if(delay_anim_rotate_10 < 0) delay_anim_rotate_10 = 0; 
                if((nawAnimationTime - normal_rotate_animation_lastTime_10) > repeat_anim_rotate_10) {
                  normal_rotate_animation_count_10 = 0;
                  timer_anim_rotate_10_mirror = false;
                };

                if (!timer_anim_rotate_10) {
                  timer_anim_rotate_10 = timer.createTimer(delay_anim_rotate_10, repeat_anim_rotate_10, (function (option) {
                    anim_rotate_10_complete_call()
                  })); // end timer create
                };
                
                let delay_anim_rotate_11 = 0;
                let repeat_anim_rotate_11 = 9000;
                delay_anim_rotate_11 = repeat_anim_rotate_11 - (nawAnimationTime - normal_rotate_animation_lastTime_11);
                if(delay_anim_rotate_11 < 0) delay_anim_rotate_11 = 0; 
                if((nawAnimationTime - normal_rotate_animation_lastTime_11) > repeat_anim_rotate_11) {
                  normal_rotate_animation_count_11 = 0;
                  timer_anim_rotate_11_mirror = false;
                };

                if (!timer_anim_rotate_11) {
                  timer_anim_rotate_11 = timer.createTimer(delay_anim_rotate_11, repeat_anim_rotate_11, (function (option) {
                    anim_rotate_11_complete_call()
                  })); // end timer create
                };
                
                let delay_anim_rotate_12 = 0;
                let repeat_anim_rotate_12 = 8000;
                delay_anim_rotate_12 = repeat_anim_rotate_12 - (nawAnimationTime - normal_rotate_animation_lastTime_12);
                if(delay_anim_rotate_12 < 0) delay_anim_rotate_12 = 0; 
                if((nawAnimationTime - normal_rotate_animation_lastTime_12) > repeat_anim_rotate_12) {
                  normal_rotate_animation_count_12 = 0;
                  timer_anim_rotate_12_mirror = false;
                };

                if (!timer_anim_rotate_12) {
                  timer_anim_rotate_12 = timer.createTimer(delay_anim_rotate_12, repeat_anim_rotate_12, (function (option) {
                    anim_rotate_12_complete_call()
                  })); // end timer create
                };
                
                let delay_anim_rotate_13 = 0;
                let repeat_anim_rotate_13 = 1000;
                delay_anim_rotate_13 = repeat_anim_rotate_13 - (nawAnimationTime - normal_rotate_animation_lastTime_13);
                if(delay_anim_rotate_13 < 0) delay_anim_rotate_13 = 0; 
                if((nawAnimationTime - normal_rotate_animation_lastTime_13) > repeat_anim_rotate_13) {
                  normal_rotate_animation_count_13 = 0;
                  timer_anim_rotate_13_mirror = false;
                };

                if (!timer_anim_rotate_13) {
                  timer_anim_rotate_13 = timer.createTimer(delay_anim_rotate_13, repeat_anim_rotate_13, (function (option) {
                    anim_rotate_13_complete_call()
                  })); // end timer create
                };
                
                let delay_anim_rotate_14 = 0;
                let repeat_anim_rotate_14 = 16000;
                delay_anim_rotate_14 = repeat_anim_rotate_14 - (nawAnimationTime - normal_rotate_animation_lastTime_14);
                if(delay_anim_rotate_14 < 0) delay_anim_rotate_14 = 0; 
                if((nawAnimationTime - normal_rotate_animation_lastTime_14) > repeat_anim_rotate_14) {
                  normal_rotate_animation_count_14 = 0;
                  timer_anim_rotate_14_mirror = false;
                };

                if (!timer_anim_rotate_14) {
                  timer_anim_rotate_14 = timer.createTimer(delay_anim_rotate_14, repeat_anim_rotate_14, (function (option) {
                    anim_rotate_14_complete_call()
                  })); // end timer create
                };
                
                let delay_anim_rotate_15 = 0;
                let repeat_anim_rotate_15 = 16000;
                delay_anim_rotate_15 = repeat_anim_rotate_15 - (nawAnimationTime - normal_rotate_animation_lastTime_15);
                if(delay_anim_rotate_15 < 0) delay_anim_rotate_15 = 0; 
                if((nawAnimationTime - normal_rotate_animation_lastTime_15) > repeat_anim_rotate_15) {
                  normal_rotate_animation_count_15 = 0;
                  timer_anim_rotate_15_mirror = false;
                };

                if (!timer_anim_rotate_15) {
                  timer_anim_rotate_15 = timer.createTimer(delay_anim_rotate_15, repeat_anim_rotate_15, (function (option) {
                    anim_rotate_15_complete_call()
                  })); // end timer create
                };
                checkConnection();
                stopVibro();

              }),
              pause_call: (function () {
                console.log('pause_call()');
                stop_anim_rotate_1();
                stop_anim_rotate_2();
                stop_anim_rotate_3();
                stop_anim_rotate_4();
                stop_anim_rotate_5();
                stop_anim_rotate_6();
                stop_anim_rotate_7();
                stop_anim_rotate_8();
                stop_anim_rotate_9();
                stop_anim_rotate_10();
                stop_anim_rotate_11();
                stop_anim_rotate_12();
                stop_anim_rotate_13();
                stop_anim_rotate_14();
                stop_anim_rotate_15();
                stopVibro();

              }),
            });

                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}