﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        const logger = Logger.getLogger('watchface_SashaCX75');
        //end of ignored block

        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_compass_icon_img = ''
        let normal_compass_direction_pointer_img = ''
        let normal_date_img_date_week_img = ''
        let normal_date_img_date_day = ''
        let normal_battery_icon_img = ''
        let normal_battery_circle_scale = ''
        let normal_battery_pointer_progress_img_pointer = ''
        let normal_battery_text_text_img = ''
        let normal_sun_icon_img = ''
        let normal_sun_current_text_img = ''
        let normal_sun_pointer_progress_img_pointer = ''
        let normal_temperature_icon_img = ''
        let normal_temperature_max_min_text_img = ''
        let normal_temperature_current_text_img = ''
        let normal_weather_pointer_progress_img_pointer = ''
        let normal_distance_icon_img = ''
        let normal_distance_text_text_img = ''
        let normal_spo2_icon_img = ''
		let normal_spo2_pointer_progress_img_pointer = ''
        let normal_spo2_text_text_img = ''
        let normal_stress_icon_img = ''
        let normal_stress_text_text_img = ''
        let normal_stress_image_progress_img_level = ''
        let normal_heart_rate_icon_img = ''
        let normal_heart_rate_text_text_img = ''
        let normal_heart_rate_image_progress_img_level = ''
        let normal_fat_burning_icon_img = ''
        let normal_fat_burning_circle_scale = ''
        let normal_fat_burning_pointer_progress_img_pointer = ''
        let normal_fat_burning_current_text_img = ''
        let normal_stand_icon_img = ''
        let normal_stand_circle_scale = ''
        let normal_stand_pointer_progress_img_pointer = ''
        let normal_stand_target_text_img = ''
        let normal_stand_current_text_img = ''
        let normal_calorie_icon_img = ''
        let normal_calorie_current_text_img = ''
        let normal_calorie_circle_scale = ''
        let normal_calorie_pointer_progress_img_pointer = ''
        let normal_step_icon_img = ''
        let normal_step_current_text_img = ''
        let normal_step_circle_scale = ''
        let normal_step_pointer_progress_img_pointer = ''
        let normal_analog_clock_time_pointer_hour = ''
        let normal_analog_clock_time_pointer_minute = ''
        let normal_analog_clock_time_pointer_second = ''
        let idle_background_bg_img = ''
        let idle_analog_clock_time_pointer_hour = ''
        let idle_analog_clock_time_pointer_minute = ''
		
		let btn_bezel = ''
        let bezel_num = 1
        let bezel_all = 8
     
        function click_Bezel() {
            if(bezel_num>=bezel_all) {bezel_num=1;}
            else { bezel_num=bezel_num+1;}
            hmUI.showToast({text: "<Color> " + parseInt(bezel_num) });
            normal_background_bg_img.setProperty(hmUI.prop.SRC, "bg_" + parseInt(bezel_num) + ".png");
            
			}
		
        let delay_Timer = null;
        let clicks = 0;
        let clicksDelay = 400;       
		

          function checkClicks() {

            switch(clicks) {
              case 1:
                click_Bezel();
             break;
              case 2:
                click_bot_circle_Switcher();
             break;
              default:
             break;
           }
            
           timer.stopTimer(delay_Timer);
           clicks = 0;

          }
            
        
      
              function getClick() {		
      
            clicks++;
            if(delay_Timer) timer.stopTimer(delay_Timer);
            delay_Timer = timer.createTimer(clicksDelay, 0, checkClicks, {});
      
              }
		
		let bot_circle_btn = ''
        let bot_circle_state = 0 
        let bot_circle_state_txt = ''

        function click_bot_circle_Switcher() {

          let bot_circle_state_total = 7;

          bot_circle_state = (bot_circle_state + 1) % bot_circle_state_total;

          switch (bot_circle_state) {

              case 0:
 
                  normal_analog_clock_time_pointer_hour.setProperty(hmUI.prop.MORE, {
                    hour_path: 'h_0.png',
                    hour_centerX: 233,
                    hour_centerY: 233,
                    hour_posX: 12,
                    hour_posY: 138,
                    show_level: hmUI.show_level.ONLY_NORMAL,
                  });
      
                  normal_analog_clock_time_pointer_minute.setProperty(hmUI.prop.MORE, {
                    minute_path: 'm_0.png',
                    minute_centerX: 233,
                    minute_centerY: 233,
                    minute_posX: 12,
                    minute_posY: 212,
                    show_level: hmUI.show_level.ONLY_NORMAL,
                  });
      
                  bot_circle_state_txt = 'Hands 1';
                  break;

              case 1:

                normal_analog_clock_time_pointer_hour.setProperty(hmUI.prop.MORE, {
                  hour_path: 'h_1.png',
                  hour_centerX: 233,
                  hour_centerY: 233,
                  hour_posX: 12,
                  hour_posY: 138,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });
    
                normal_analog_clock_time_pointer_minute.setProperty(hmUI.prop.MORE, {
                  minute_path: 'm_1.png',
                  minute_centerX: 233,
                  minute_centerY: 233,
                  minute_posX: 12,
                  minute_posY: 212,
                 show_level: hmUI.show_level.ONLY_NORMAL,
                });
   
              bot_circle_state_txt = 'Hands 2';
                  break;

              case 2:

                    normal_analog_clock_time_pointer_hour.setProperty(hmUI.prop.MORE, {
                      hour_path: 'h_2.png',
                      hour_centerX: 233,
                      hour_centerY: 233,
                      hour_posX: 12,
                      hour_posY: 138,
                      show_level: hmUI.show_level.ONLY_NORMAL,
                    });
        
                    normal_analog_clock_time_pointer_minute.setProperty(hmUI.prop.MORE, {
                      minute_path: 'm_2.png',
                      minute_centerX: 233,
                      minute_centerY: 233,
                      minute_posX: 12,
                      minute_posY: 212,
                      show_level: hmUI.show_level.ONLY_NORMAL,
                    });
       
                  bot_circle_state_txt = 'Hands 3';
              break;
			  
			  case 3:

                    normal_analog_clock_time_pointer_hour.setProperty(hmUI.prop.MORE, {
                      hour_path: 'h_3.png',
                      hour_centerX: 233,
                      hour_centerY: 233,
                      hour_posX: 12,
                      hour_posY: 138,
                      show_level: hmUI.show_level.ONLY_NORMAL,
                    });
        
                    normal_analog_clock_time_pointer_minute.setProperty(hmUI.prop.MORE, {
                      minute_path: 'm_3.png',
                      minute_centerX: 233,
                      minute_centerY: 233,
                      minute_posX: 12,
                      minute_posY: 212,
                      show_level: hmUI.show_level.ONLY_NORMAL,
                    });
       
                  bot_circle_state_txt = 'Hands 4';
              break;
			  
			  case 4:

                    normal_analog_clock_time_pointer_hour.setProperty(hmUI.prop.MORE, {
                      hour_path: 'h_4.png',
                      hour_centerX: 233,
                      hour_centerY: 233,
                      hour_posX: 12,
                      hour_posY: 138,
                      show_level: hmUI.show_level.ONLY_NORMAL,
                    });
        
                    normal_analog_clock_time_pointer_minute.setProperty(hmUI.prop.MORE, {
                      minute_path: 'm_4.png',
                      minute_centerX: 233,
                      minute_centerY: 233,
                      minute_posX: 12,
                      minute_posY: 212,
                      show_level: hmUI.show_level.ONLY_NORMAL,
                    });
       
                  bot_circle_state_txt = 'Hands 5';
              break;
			  
			  case 5:

                    normal_analog_clock_time_pointer_hour.setProperty(hmUI.prop.MORE, {
                      hour_path: 'h_5.png',
                      hour_centerX: 233,
                      hour_centerY: 233,
                      hour_posX: 12,
                      hour_posY: 138,
                      show_level: hmUI.show_level.ONLY_NORMAL,
                    });
        
                    normal_analog_clock_time_pointer_minute.setProperty(hmUI.prop.MORE, {
                      minute_path: 'm_5.png',
                      minute_centerX: 233,
                      minute_centerY: 233,
                      minute_posX: 12,
                      minute_posY: 212,
                      show_level: hmUI.show_level.ONLY_NORMAL,
                    });
       
                  bot_circle_state_txt = 'Hands 6';
              break;
			  
			  case 6:

                    normal_analog_clock_time_pointer_hour.setProperty(hmUI.prop.MORE, {
                      hour_path: 'h_6.png',
                      hour_centerX: 233,
                      hour_centerY: 233,
                      hour_posX: 12,
                      hour_posY: 138,
                      show_level: hmUI.show_level.ONLY_NORMAL,
                    });
        
                    normal_analog_clock_time_pointer_minute.setProperty(hmUI.prop.MORE, {
                      minute_path: 'm_6.png',
                      minute_centerX: 233,
                      minute_centerY: 233,
                      minute_posX: 12,
                      minute_posY: 212,
                      show_level: hmUI.show_level.ONLY_NORMAL,
                    });
       
                  bot_circle_state_txt = 'Hands 7';
              break;
			  
			  case 7:

                    normal_analog_clock_time_pointer_hour.setProperty(hmUI.prop.MORE, {
                      hour_path: 'h_7.png',
                      hour_centerX: 233,
                      hour_centerY: 233,
                      hour_posX: 12,
                      hour_posY: 138,
                      show_level: hmUI.show_level.ONLY_NORMAL,
                    });
        
                    normal_analog_clock_time_pointer_minute.setProperty(hmUI.prop.MORE, {
                      minute_path: 'm_7.png',
                      minute_centerX: 233,
                      minute_centerY: 233,
                      minute_posX: 12,
                      minute_posY: 212,
                      show_level: hmUI.show_level.ONLY_NORMAL,
                    });
       
                  bot_circle_state_txt = 'Hands 8';
              break;
    
              default:
                  break;
          }

          hmUI.showToast({ text: bot_circle_state_txt });
      }		
			   
		let btn_zona1 = ''
        let zona1_num = 0
        let zona1_all = 3
		
		function click_zona1() {
		  zona1_num = (zona1_num + 1) % (zona1_all + 1);
          if (zona1_num == 0) {		
		    normal_step_current_text_img.setProperty(hmUI.prop.VISIBLE, true);
            normal_step_icon_img.setProperty(hmUI.prop.VISIBLE, true);
			normal_step_circle_scale.setProperty(hmUI.prop.VISIBLE, true);
			normal_step_pointer_progress_img_pointer.setProperty(hmUI.prop.VISIBLE, true);
			normal_calorie_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_calorie_icon_img.setProperty(hmUI.prop.VISIBLE, false);
            normal_calorie_circle_scale.setProperty(hmUI.prop.VISIBLE, false);
            normal_calorie_pointer_progress_img_pointer.setProperty(hmUI.prop.VISIBLE, false);
			normal_stand_icon_img.setProperty(hmUI.prop.VISIBLE, false); 
            normal_stand_circle_scale.setProperty(hmUI.prop.VISIBLE, false);
            normal_stand_pointer_progress_img_pointer.setProperty(hmUI.prop.VISIBLE, false);
			normal_stand_target_text_img.setProperty(hmUI.prop.VISIBLE, false);
            normal_stand_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
            normal_fat_burning_icon_img.setProperty(hmUI.prop.VISIBLE, false);
            normal_fat_burning_circle_scale.setProperty(hmUI.prop.VISIBLE, false);
			normal_fat_burning_pointer_progress_img_pointer.setProperty(hmUI.prop.VISIBLE, false);
			normal_fat_burning_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
		    hmUI.showToast({
            });
          };
		  
		 if (zona1_num == 1) {
			normal_step_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
            normal_step_icon_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_step_circle_scale.setProperty(hmUI.prop.VISIBLE, false);
			normal_step_pointer_progress_img_pointer.setProperty(hmUI.prop.VISIBLE, false);
			normal_calorie_current_text_img.setProperty(hmUI.prop.VISIBLE, true);
			normal_calorie_icon_img.setProperty(hmUI.prop.VISIBLE, true);
            normal_calorie_circle_scale.setProperty(hmUI.prop.VISIBLE, true);
            normal_calorie_pointer_progress_img_pointer.setProperty(hmUI.prop.VISIBLE, true);
			normal_stand_icon_img.setProperty(hmUI.prop.VISIBLE, false); 
            normal_stand_circle_scale.setProperty(hmUI.prop.VISIBLE, false);
            normal_stand_pointer_progress_img_pointer.setProperty(hmUI.prop.VISIBLE, false);
			normal_stand_target_text_img.setProperty(hmUI.prop.VISIBLE, false);
            normal_stand_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
            normal_fat_burning_icon_img.setProperty(hmUI.prop.VISIBLE, false);
            normal_fat_burning_circle_scale.setProperty(hmUI.prop.VISIBLE, false);
			normal_fat_burning_pointer_progress_img_pointer.setProperty(hmUI.prop.VISIBLE, false);
			normal_fat_burning_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
		    hmUI.showToast({
            });
          };
		  
		  if (zona1_num == 2) {
			normal_step_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
            normal_step_icon_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_step_circle_scale.setProperty(hmUI.prop.VISIBLE, false);
			normal_step_pointer_progress_img_pointer.setProperty(hmUI.prop.VISIBLE, false);
			normal_calorie_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_calorie_icon_img.setProperty(hmUI.prop.VISIBLE, false);
            normal_calorie_circle_scale.setProperty(hmUI.prop.VISIBLE, false);
            normal_calorie_pointer_progress_img_pointer.setProperty(hmUI.prop.VISIBLE, false);
			normal_stand_icon_img.setProperty(hmUI.prop.VISIBLE, true); 
            normal_stand_circle_scale.setProperty(hmUI.prop.VISIBLE, true);
            normal_stand_pointer_progress_img_pointer.setProperty(hmUI.prop.VISIBLE, true);
			normal_stand_target_text_img.setProperty(hmUI.prop.VISIBLE, true);
            normal_stand_current_text_img.setProperty(hmUI.prop.VISIBLE, true);
            normal_fat_burning_icon_img.setProperty(hmUI.prop.VISIBLE, false);
            normal_fat_burning_circle_scale.setProperty(hmUI.prop.VISIBLE, false);
			normal_fat_burning_pointer_progress_img_pointer.setProperty(hmUI.prop.VISIBLE, false);
			normal_fat_burning_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
		    hmUI.showToast({
            });
          };
		  
		  if (zona1_num == 3) {
			normal_step_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
            normal_step_icon_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_step_circle_scale.setProperty(hmUI.prop.VISIBLE, false);
			normal_step_pointer_progress_img_pointer.setProperty(hmUI.prop.VISIBLE, false);
			normal_calorie_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_calorie_icon_img.setProperty(hmUI.prop.VISIBLE, false);
            normal_calorie_circle_scale.setProperty(hmUI.prop.VISIBLE, false);
            normal_calorie_pointer_progress_img_pointer.setProperty(hmUI.prop.VISIBLE, false);
			normal_stand_icon_img.setProperty(hmUI.prop.VISIBLE, false); 
            normal_stand_circle_scale.setProperty(hmUI.prop.VISIBLE, false);
            normal_stand_pointer_progress_img_pointer.setProperty(hmUI.prop.VISIBLE, false);
			normal_stand_target_text_img.setProperty(hmUI.prop.VISIBLE, false);
            normal_stand_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
            normal_fat_burning_icon_img.setProperty(hmUI.prop.VISIBLE, true);
            normal_fat_burning_circle_scale.setProperty(hmUI.prop.VISIBLE, true);
			normal_fat_burning_pointer_progress_img_pointer.setProperty(hmUI.prop.VISIBLE, true);
			normal_fat_burning_current_text_img.setProperty(hmUI.prop.VISIBLE, true);
		    hmUI.showToast({
            });
          };
        }
		
		let btn_zona2 = ''
        let zona2_num = 0
        let zona2_all = 3
		
		function click_zona2() {
		  zona2_num = (zona2_num + 1) % (zona2_all + 1);
          if (zona2_num == 0) {		
		    normal_heart_rate_icon_img.setProperty(hmUI.prop.VISIBLE, true); 
            normal_heart_rate_text_text_img.setProperty(hmUI.prop.VISIBLE, true);
            normal_heart_rate_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, true);
			normal_stress_icon_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_stress_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_stress_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, false);
			normal_spo2_icon_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_spo2_pointer_progress_img_pointer.setProperty(hmUI.prop.VISIBLE, false);
			normal_spo2_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_distance_icon_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_distance_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
		    hmUI.showToast({
            });
          };
		  
		 if (zona2_num == 1) {
			normal_heart_rate_icon_img.setProperty(hmUI.prop.VISIBLE, false); 
            normal_heart_rate_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
            normal_heart_rate_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, false);
			normal_stress_icon_img.setProperty(hmUI.prop.VISIBLE, true);
			normal_stress_text_text_img.setProperty(hmUI.prop.VISIBLE, true);
			normal_stress_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, true);
			normal_spo2_icon_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_spo2_pointer_progress_img_pointer.setProperty(hmUI.prop.VISIBLE, false);
			normal_spo2_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_distance_icon_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_distance_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
		    hmUI.showToast({
            });
          };
		  
		  if (zona2_num == 2) {
			normal_heart_rate_icon_img.setProperty(hmUI.prop.VISIBLE, false); 
            normal_heart_rate_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
            normal_heart_rate_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, false);
			normal_stress_icon_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_stress_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_stress_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, false);
			normal_spo2_icon_img.setProperty(hmUI.prop.VISIBLE, true);
			normal_spo2_pointer_progress_img_pointer.setProperty(hmUI.prop.VISIBLE, true);
			normal_spo2_text_text_img.setProperty(hmUI.prop.VISIBLE, true);
			normal_distance_icon_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_distance_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
		    hmUI.showToast({
            });
          };
		  
		  if (zona2_num == 3) {
			normal_heart_rate_icon_img.setProperty(hmUI.prop.VISIBLE, false); 
            normal_heart_rate_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
            normal_heart_rate_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, false);
			normal_stress_icon_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_stress_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_stress_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, false);
			normal_spo2_icon_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_spo2_pointer_progress_img_pointer.setProperty(hmUI.prop.VISIBLE, false);
			normal_spo2_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_distance_icon_img.setProperty(hmUI.prop.VISIBLE, true);
			normal_distance_text_text_img.setProperty(hmUI.prop.VISIBLE, true);
		    hmUI.showToast({
            });
          };
        }
		
		let longPress_Timer = null;
	    let longPressDelay = 900;   // задержка на долгое нажатие в мс
		
		function getLongPress2() {
		    if(longPress_Timer) timer.stopTimer(longPress_Timer);
			
			let url;

			switch(zona2_num) {
			   case 0:
					url = 'heart_app_Screen';
				break;
			   case 1:
					url = 'StressHomeScreen';
				break;
			   case 2:
					url = 'spo_HomeScreen';
				break;
			   case 3:
					url = 'activityWeekShowScreen';
				break;
			   default:
				break;
			}
			hmApp.startApp({ url: url, native: true });
			
	    }


		function getLongPress3() {
		    if(longPress_Timer) timer.stopTimer(longPress_Timer);
			
			let url;

			switch(zona3_num) {
			   case 1:
					url = 'WeatherScreen';
				break;
			   case 2:
					url = 'TideScreen';
				break;
			   case 3:
					url = 'Settings_batteryManagerScreen';
				break;
			   case 4:
					url = 'ScheduleCalScreen';
				break;
			   case 5:
					url = 'CompassScreen';
				break;
			   default:
				break;
			}
			hmApp.startApp({ url: url, native: true });
			
	    }
		
		let btn_zona3 = ''
        let zona3_num = 0
        let zona3_all = 5
		
		function click_zona3() {
		  zona3_num = (zona3_num + 1) % (zona3_all + 1);
          if (zona3_num == 0) {		
		    normal_temperature_icon_img.setProperty(hmUI.prop.VISIBLE, false);
            normal_temperature_max_min_text_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_temperature_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_weather_pointer_progress_img_pointer.setProperty(hmUI.prop.VISIBLE, false);
			normal_sun_icon_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_sun_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_sun_pointer_progress_img_pointer.setProperty(hmUI.prop.VISIBLE, false);
			normal_battery_icon_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_battery_circle_scale.setProperty(hmUI.prop.VISIBLE, false);
            normal_battery_pointer_progress_img_pointer.setProperty(hmUI.prop.VISIBLE, false);
            normal_battery_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_date_img_date_week_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_date_img_date_day.setProperty(hmUI.prop.VISIBLE, false);
			normal_compass_icon_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_compass_direction_pointer_img.setProperty(hmUI.prop.VISIBLE, false);
		    hmUI.showToast({
            });
          };
		  
		 if (zona3_num == 1) {
			normal_temperature_icon_img.setProperty(hmUI.prop.VISIBLE, true);
            normal_temperature_max_min_text_img.setProperty(hmUI.prop.VISIBLE, true);
			normal_temperature_current_text_img.setProperty(hmUI.prop.VISIBLE, true);
			normal_weather_pointer_progress_img_pointer.setProperty(hmUI.prop.VISIBLE, true);
			normal_sun_icon_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_sun_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_sun_pointer_progress_img_pointer.setProperty(hmUI.prop.VISIBLE, false);
			normal_battery_icon_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_battery_circle_scale.setProperty(hmUI.prop.VISIBLE, false);
            normal_battery_pointer_progress_img_pointer.setProperty(hmUI.prop.VISIBLE, false);
            normal_battery_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_date_img_date_week_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_date_img_date_day.setProperty(hmUI.prop.VISIBLE, false);
			normal_compass_icon_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_compass_direction_pointer_img.setProperty(hmUI.prop.VISIBLE, false);
		    hmUI.showToast({
            });
          };
		  
		  if (zona3_num == 2) {
			normal_temperature_icon_img.setProperty(hmUI.prop.VISIBLE, false);
            normal_temperature_max_min_text_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_temperature_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_weather_pointer_progress_img_pointer.setProperty(hmUI.prop.VISIBLE, false);
			normal_sun_icon_img.setProperty(hmUI.prop.VISIBLE, true);
			normal_sun_current_text_img.setProperty(hmUI.prop.VISIBLE, true);
			normal_sun_pointer_progress_img_pointer.setProperty(hmUI.prop.VISIBLE, true);
			normal_battery_icon_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_battery_circle_scale.setProperty(hmUI.prop.VISIBLE, false);
            normal_battery_pointer_progress_img_pointer.setProperty(hmUI.prop.VISIBLE, false);
            normal_battery_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_date_img_date_week_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_date_img_date_day.setProperty(hmUI.prop.VISIBLE, false);
			normal_compass_icon_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_compass_direction_pointer_img.setProperty(hmUI.prop.VISIBLE, false);
		    hmUI.showToast({
            });
          };
		  
		  if (zona3_num == 3) {
			normal_temperature_icon_img.setProperty(hmUI.prop.VISIBLE, false);
            normal_temperature_max_min_text_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_temperature_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_weather_pointer_progress_img_pointer.setProperty(hmUI.prop.VISIBLE, false);
			normal_sun_icon_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_sun_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_sun_pointer_progress_img_pointer.setProperty(hmUI.prop.VISIBLE, false);
			normal_battery_icon_img.setProperty(hmUI.prop.VISIBLE, true);
			normal_battery_circle_scale.setProperty(hmUI.prop.VISIBLE, true);
            normal_battery_pointer_progress_img_pointer.setProperty(hmUI.prop.VISIBLE, true);
            normal_battery_text_text_img.setProperty(hmUI.prop.VISIBLE, true);
			normal_date_img_date_week_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_date_img_date_day.setProperty(hmUI.prop.VISIBLE, false);
			normal_compass_icon_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_compass_direction_pointer_img.setProperty(hmUI.prop.VISIBLE, false);
		    hmUI.showToast({
            });
          };
		  
		  if (zona3_num == 4) {
			normal_temperature_icon_img.setProperty(hmUI.prop.VISIBLE, false);
            normal_temperature_max_min_text_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_temperature_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_weather_pointer_progress_img_pointer.setProperty(hmUI.prop.VISIBLE, false);
			normal_sun_icon_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_sun_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_sun_pointer_progress_img_pointer.setProperty(hmUI.prop.VISIBLE, false);
			normal_battery_icon_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_battery_circle_scale.setProperty(hmUI.prop.VISIBLE, false);
            normal_battery_pointer_progress_img_pointer.setProperty(hmUI.prop.VISIBLE, false);
            normal_battery_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_date_img_date_week_img.setProperty(hmUI.prop.VISIBLE, true);
			normal_date_img_date_day.setProperty(hmUI.prop.VISIBLE, true);
			normal_compass_icon_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_compass_direction_pointer_img.setProperty(hmUI.prop.VISIBLE, false);
		    hmUI.showToast({
            });
          };
		  
		  if (zona3_num == 5) {
			normal_temperature_icon_img.setProperty(hmUI.prop.VISIBLE, false);
            normal_temperature_max_min_text_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_temperature_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_weather_pointer_progress_img_pointer.setProperty(hmUI.prop.VISIBLE, false);
			normal_sun_icon_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_sun_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_sun_pointer_progress_img_pointer.setProperty(hmUI.prop.VISIBLE, false);
			normal_battery_icon_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_battery_circle_scale.setProperty(hmUI.prop.VISIBLE, false);
            normal_battery_pointer_progress_img_pointer.setProperty(hmUI.prop.VISIBLE, false);
            normal_battery_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_date_img_date_week_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_date_img_date_day.setProperty(hmUI.prop.VISIBLE, false);
			normal_compass_icon_img.setProperty(hmUI.prop.VISIBLE, true);
			normal_compass_direction_pointer_img.setProperty(hmUI.prop.VISIBLE, true);
		    hmUI.showToast({
            });
          };
        }


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            console.log('Watch_Face.ScreenNormal');
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 466,
              h: 466,
              src: 'bg_1.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_compass_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 157,
              y: 308,
              src: 'comp.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            const deviceInfo = hmSetting.getDeviceInfo();
            
            // normal_compass_custom_pointer_img = hmUI.createWidget(hmUI.widget.CUSTOM_POINTER, {
              // src: 'A100_213.png',
              // center_x: 232,
              // center_y: 382,
              // x: 29,
              // y: 29,
              // start_angle: 0,
              // end_angle: 360,
              // type: hmUI.data_type.COMPASS,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });


            //start of ignored block
            normal_compass_direction_pointer_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: deviceInfo.width,
              h: deviceInfo.height,
              pos_x: 232 - 29,
              pos_y: 382 - 29,
              center_x: 232,
              center_y: 382,
              src: 'A100_213.png',
              angle: 0,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            //end of ignored block

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 157,
              y: 308,
              week_en: ["week_1.png","week_2.png","week_3.png","week_4.png","week_5.png","week_6.png","week_7.png"],
              week_tc: ["week_1.png","week_2.png","week_3.png","week_4.png","week_5.png","week_6.png","week_7.png"],
              week_sc: ["week_1.png","week_2.png","week_3.png","week_4.png","week_5.png","week_6.png","week_7.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 219,
              day_startY: 368,
              day_sc_array: ["nm_0.png","nm_1.png","nm_2.png","nm_3.png","nm_4.png","nm_5.png","nm_6.png","nm_7.png","nm_8.png","nm_9.png"],
              day_tc_array: ["nm_0.png","nm_1.png","nm_2.png","nm_3.png","nm_4.png","nm_5.png","nm_6.png","nm_7.png","nm_8.png","nm_9.png"],
              day_en_array: ["nm_0.png","nm_1.png","nm_2.png","nm_3.png","nm_4.png","nm_5.png","nm_6.png","nm_7.png","nm_8.png","nm_9.png"],
              day_zero: 1,
              day_space: -1,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 157,
              y: 308,
              src: 'pwr.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_battery_circle_scale = hmUI.createWidget(hmUI.widget.Circle_Scale, {
              // center_x: 231,
              // center_y: 382,
              // start_angle: -138,
              // end_angle: 138,
              // radius: 57,
              // line_width: 3,
              // line_cap: Rounded,
              // color: 0xFF00FF00,
              // mirror: False,
              // inversion: False,
              // type: hmUI.data_type.BATTERY,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            let screenType = hmSetting.getScreenType();
            normal_battery_circle_scale = hmUI.createWidget(hmUI.widget.ARC_PROGRESS, {
              center_x: 231,
              center_y: 382,
              start_angle: -138,
              end_angle: 138,
              radius: 56,
              line_width: 3,
              corner_flag: 0,
              color: 0xFF00FF00,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            
            const battery = hmSensor.createSensor(hmSensor.id.BATTERY);
            battery.addEventListener(hmSensor.event.CHANGE, function() {
              scale_call();
            });

            normal_battery_pointer_progress_img_pointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
              src: 'A100_004.png',
              center_x: 231,
              center_y: 382,
              x: 6,
              y: 56,
              start_angle: -138,
              end_angle: 138,
              invalid_visible: false,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 207,
              y: 396,
              font_array: ["nm_0.png","nm_1.png","nm_2.png","nm_3.png","nm_4.png","nm_5.png","nm_6.png","nm_7.png","nm_8.png","nm_9.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'unit1.png',
              unit_tc: 'unit1.png',
              unit_en: 'unit1.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sun_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 157,
              y: 308,
              src: 'sun.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sun_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 198,
              y: 377,
              font_array: ["nm_0.png","nm_1.png","nm_2.png","nm_3.png","nm_4.png","nm_5.png","nm_6.png","nm_7.png","nm_8.png","nm_9.png"],
              padding: false,
              h_space: 0,
              dot_image: 'dots.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.SUN_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sun_pointer_progress_img_pointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
              src: 'suns.png',
              center_x: 232,
              center_y: 382,
              x: 8,
              y: 74,
              start_angle: -89,
              end_angle: 89,
              invalid_visible: false,
              type: hmUI.data_type.SUN_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 157,
              y: 308,
              src: 'weather.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_max_min_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 185,
              y: 368,
              font_array: ["nm_0.png","nm_1.png","nm_2.png","nm_3.png","nm_4.png","nm_5.png","nm_6.png","nm_7.png","nm_8.png","nm_9.png"],
              padding: false,
              h_space: 0,
              negative_image: 'fuhao1.png',
              dot_image: 'un.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_HIGH_LOW,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 208,
              y: 398,
              font_array: ["n_0.png","n_1.png","n_2.png","n_3.png","n_4.png","n_5.png","n_6.png","n_7.png","n_8.png","n_9.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'unit_0.png',
              unit_tc: 'unit_0.png',
              unit_en: 'unit_0.png',
              negative_image: 'fuhao.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_weather_pointer_progress_img_pointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
              src: '52.png',
              center_x: 231,
              center_y: 383,
              x: 23,
              y: 62,
              start_angle: -122,
              end_angle: 122,
              invalid_visible: false,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_distance_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 308,
              y: 158,
              src: 'temp.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_distance_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 350,
              y: 249,
              font_array: ["nm_0.png","nm_1.png","nm_2.png","nm_3.png","nm_4.png","nm_5.png","nm_6.png","nm_7.png","nm_8.png","nm_9.png"],
              padding: false,
              h_space: 0,
              dot_image: 'dot.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.DISTANCE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_spo2_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 308,
              y: 158,
              src: 'spo2.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
			
			normal_spo2_pointer_progress_img_pointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
              src: 'A100_004.png',
              center_x: 382,
              center_y: 234,
              x: 6,
              y: 56,
              start_angle: -138,
              end_angle: 138,
              invalid_visible: false,
              type: hmUI.data_type.SPO2,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_spo2_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 357,
              y: 249,
              font_array: ["nm_0.png","nm_1.png","nm_2.png","nm_3.png","nm_4.png","nm_5.png","nm_6.png","nm_7.png","nm_8.png","nm_9.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'unit1.png',
              unit_tc: 'unit1.png',
              unit_en: 'unit1.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.SPO2,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_stress_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 308,
              y: 158,
              src: 'stress.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_stress_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 362,
              y: 249,
              font_array: ["nm_0.png","nm_1.png","nm_2.png","nm_3.png","nm_4.png","nm_5.png","nm_6.png","nm_7.png","nm_8.png","nm_9.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STRESS,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_stress_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 308,
              y: 156,
              image_array: ["hr_1.png","hr_2.png","hr_3.png","hr_4.png","hr_5.png","hr_6.png"],
              image_length: 6,
              type: hmUI.data_type.STRESS,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 308,
              y: 158,
              src: 'bpm.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 363,
              y: 249,
              font_array: ["nm_0.png","nm_1.png","nm_2.png","nm_3.png","nm_4.png","nm_5.png","nm_6.png","nm_7.png","nm_8.png","nm_9.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 308,
              y: 156,
              image_array: ["hr_1.png","hr_2.png","hr_3.png","hr_4.png","hr_5.png","hr_6.png"],
              image_length: 6,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_fat_burning_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 10,
              y: 158,
              src: 'fat.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_fat_burning_circle_scale = hmUI.createWidget(hmUI.widget.Circle_Scale, {
              // center_x: 83,
              // center_y: 232,
              // start_angle: -138,
              // end_angle: 138,
              // radius: 57,
              // line_width: 3,
              // line_cap: Rounded,
              // color: 0xFF80FF80,
              // mirror: False,
              // inversion: False,
              // type: hmUI.data_type.FAT_BURNING,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_fat_burning_circle_scale = hmUI.createWidget(hmUI.widget.ARC_PROGRESS, {
              center_x: 83,
              center_y: 232,
              start_angle: -138,
              end_angle: 138,
              radius: 56,
              line_width: 3,
              corner_flag: 0,
              color: 0xFF80FF80,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            
            const fat_burning = hmSensor.createSensor(hmSensor.id.FAT_BURRING);
            fat_burning.addEventListener(hmSensor.event.CHANGE, function() {
              scale_call();
            });

            normal_fat_burning_pointer_progress_img_pointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
              src: 'A100_004.png',
              center_x: 83,
              center_y: 232,
              x: 6,
              y: 56,
              start_angle: -138,
              end_angle: 138,
              invalid_visible: false,
              type: hmUI.data_type.FAT_BURNING,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_fat_burning_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 63,
              y: 249,
              font_array: ["nm_0.png","nm_1.png","nm_2.png","nm_3.png","nm_4.png","nm_5.png","nm_6.png","nm_7.png","nm_8.png","nm_9.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.FAT_BURNING,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_stand_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 10,
              y: 158,
              src: 'stand.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_stand_circle_scale = hmUI.createWidget(hmUI.widget.Circle_Scale, {
              // center_x: 83,
              // center_y: 232,
              // start_angle: -138,
              // end_angle: 138,
              // radius: 57,
              // line_width: 3,
              // line_cap: Rounded,
              // color: 0xFF00DDDD,
              // mirror: False,
              // inversion: False,
              // type: hmUI.data_type.STAND,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_stand_circle_scale = hmUI.createWidget(hmUI.widget.ARC_PROGRESS, {
              center_x: 83,
              center_y: 232,
              start_angle: -138,
              end_angle: 138,
              radius: 56,
              line_width: 3,
              corner_flag: 0,
              color: 0xFF00DDDD,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            
            const stand = hmSensor.createSensor(hmSensor.id.STAND);
            stand.addEventListener(hmSensor.event.CHANGE, function() {
              scale_call();
            });

            normal_stand_pointer_progress_img_pointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
              src: 'A100_004.png',
              center_x: 83,
              center_y: 232,
              x: 6,
              y: 56,
              start_angle: -138,
              end_angle: 138,
              invalid_visible: false,
              type: hmUI.data_type.STAND,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_stand_target_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 89,
              y: 249,
              font_array: ["nm_0.png","nm_1.png","nm_2.png","nm_3.png","nm_4.png","nm_5.png","nm_6.png","nm_7.png","nm_8.png","nm_9.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STAND_TARGET,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_stand_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 21,
              y: 249,
              font_array: ["nm_0.png","nm_1.png","nm_2.png","nm_3.png","nm_4.png","nm_5.png","nm_6.png","nm_7.png","nm_8.png","nm_9.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'un.png',
              unit_tc: 'un.png',
              unit_en: 'un.png',
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.STAND,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_calorie_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 10,
              y: 158,
              src: 'cal.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_calorie_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 55,
              y: 249,
              font_array: ["nm_0.png","nm_1.png","nm_2.png","nm_3.png","nm_4.png","nm_5.png","nm_6.png","nm_7.png","nm_8.png","nm_9.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_cal_circle_scale = hmUI.createWidget(hmUI.widget.Circle_Scale, {
              // center_x: 83,
              // center_y: 232,
              // start_angle: -138,
              // end_angle: 138,
              // radius: 57,
              // line_width: 3,
              // line_cap: Rounded,
              // color: 0xFFFF8C00,
              // mirror: False,
              // inversion: False,
              // type: hmUI.data_type.CAL,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_calorie_circle_scale = hmUI.createWidget(hmUI.widget.ARC_PROGRESS, {
              center_x: 83,
              center_y: 232,
              start_angle: -138,
              end_angle: 138,
              radius: 56,
              line_width: 3,
              corner_flag: 0,
              color: 0xFFFF8C00,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            
            const calorie = hmSensor.createSensor(hmSensor.id.CALORIE);
            calorie.addEventListener(hmSensor.event.CHANGE, function() {
              scale_call();
            });

            normal_calorie_pointer_progress_img_pointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
              src: 'A100_004.png',
              center_x: 83,
              center_y: 232,
              x: 6,
              y: 56,
              start_angle: -138,
              end_angle: 138,
              invalid_visible: false,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 10,
              y: 158,
              src: 'step.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 50,
              y: 249,
              font_array: ["nm_0.png","nm_1.png","nm_2.png","nm_3.png","nm_4.png","nm_5.png","nm_6.png","nm_7.png","nm_8.png","nm_9.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_step_circle_scale = hmUI.createWidget(hmUI.widget.Circle_Scale, {
              // center_x: 83,
              // center_y: 232,
              // start_angle: -138,
              // end_angle: 138,
              // radius: 57,
              // line_width: 3,
              // line_cap: Rounded,
              // color: 0xFF0000FF,
              // mirror: False,
              // inversion: False,
              // type: hmUI.data_type.STEP,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_step_circle_scale = hmUI.createWidget(hmUI.widget.ARC_PROGRESS, {
              center_x: 83,
              center_y: 232,
              start_angle: -138,
              end_angle: 138,
              radius: 56,
              line_width: 3,
              corner_flag: 0,
              color: 0xFF0000FF,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            
            const step = hmSensor.createSensor(hmSensor.id.STEP);
            step.addEventListener(hmSensor.event.CHANGE, function() {
              scale_call();
            });

            normal_step_pointer_progress_img_pointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
              src: 'A100_004.png',
              center_x: 83,
              center_y: 232,
              x: 6,
              y: 56,
              start_angle: -138,
              end_angle: 138,
              invalid_visible: false,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_hour = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              hour_path: 'h_0.png',
              hour_centerX: 233,
              hour_centerY: 233,
              hour_posX: 12,
              hour_posY: 138,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_minute = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              minute_path: 'm_0.png',
              minute_centerX: 233,
              minute_centerY: 233,
              minute_posX: 12,
              minute_posY: 212,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_second = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              second_path: 'A100_008.png',
              second_centerX: 233,
              second_centerY: 233,
              second_posX: 12,
              second_posY: 208,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            console.log('Watch_Face.ScreenAOD');
            idle_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 466,
              h: 466,
              src: 'aod.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_analog_clock_time_pointer_hour = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              hour_path: 'h_0.png',
              hour_centerX: 233,
              hour_centerY: 233,
              hour_posX: 12,
              hour_posY: 138,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_analog_clock_time_pointer_minute = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              minute_path: 'm_0.png',
              minute_centerX: 233,
              minute_centerY: 233,
              minute_posX: 12,
              minute_posY: 212,
              show_level: hmUI.show_level.ONLY_AOD,
            });
			
			btn_zona1 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 39,
              y: 184,
              text: '',
              w: 97,
              h: 97,
              normal_src: 'Empty.png',
              press_src: 'Empty.png',
              click_func: () => {
				click_zona1();
				click_Vibrate();
             },
			  longpress_func: () => {
             hmApp.startApp({ url: "activityAppScreen", native: true });
             },
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            btn_zona1.setProperty(hmUI.prop.VISIBLE, true);
			normal_calorie_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_calorie_icon_img.setProperty(hmUI.prop.VISIBLE, false);
            normal_calorie_circle_scale.setProperty(hmUI.prop.VISIBLE, false);
            normal_calorie_pointer_progress_img_pointer.setProperty(hmUI.prop.VISIBLE, false);
			normal_stand_icon_img.setProperty(hmUI.prop.VISIBLE, false); 
            normal_stand_circle_scale.setProperty(hmUI.prop.VISIBLE, false);
            normal_stand_pointer_progress_img_pointer.setProperty(hmUI.prop.VISIBLE, false);
			normal_stand_target_text_img.setProperty(hmUI.prop.VISIBLE, false);
            normal_stand_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
            normal_fat_burning_icon_img.setProperty(hmUI.prop.VISIBLE, false);
            normal_fat_burning_circle_scale.setProperty(hmUI.prop.VISIBLE, false);
			normal_fat_burning_pointer_progress_img_pointer.setProperty(hmUI.prop.VISIBLE, false);
			normal_fat_burning_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
			
			btn_zona2 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 335,
              y: 184,
              text: '',
              w: 97,
              h: 97,
              normal_src: 'Empty.png',
              press_src: 'Empty.png',
              click_func: () => {
				click_zona2();
				click_Vibrate();
             },
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            btn_zona2.setProperty(hmUI.prop.VISIBLE, true);
			normal_stress_icon_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_stress_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_stress_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, false);
			normal_spo2_icon_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_spo2_pointer_progress_img_pointer.setProperty(hmUI.prop.VISIBLE, false);
			normal_spo2_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_distance_icon_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_distance_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
			
			btn_zona2.addEventListener(hmUI.event.CLICK_DOWN, function () {
					if(longPress_Timer) timer.stopTimer(longPress_Timer);
					longPress_Timer = timer.createTimer(longPressDelay, 0, getLongPress2, {});
			});
			btn_zona2.addEventListener(hmUI.event.CLICK_UP, function () {
					if(longPress_Timer) timer.stopTimer(longPress_Timer);
			});
			
			btn_zona3 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 184,
              y: 340,
              text: '',
              w: 97,
              h: 97,
              normal_src: 'Empty.png',
              press_src: 'Empty.png',
              click_func: () => {
				click_zona3();
				click_Vibrate();
             },
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            btn_zona3.setProperty(hmUI.prop.VISIBLE, true);
			normal_temperature_icon_img.setProperty(hmUI.prop.VISIBLE, false);
            normal_temperature_max_min_text_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_temperature_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_weather_pointer_progress_img_pointer.setProperty(hmUI.prop.VISIBLE, false);
			normal_sun_icon_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_sun_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_sun_pointer_progress_img_pointer.setProperty(hmUI.prop.VISIBLE, false);
			normal_battery_icon_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_battery_circle_scale.setProperty(hmUI.prop.VISIBLE, false);
            normal_battery_pointer_progress_img_pointer.setProperty(hmUI.prop.VISIBLE, false);
            normal_battery_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_date_img_date_week_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_date_img_date_day.setProperty(hmUI.prop.VISIBLE, false);
			normal_compass_icon_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_compass_direction_pointer_img.setProperty(hmUI.prop.VISIBLE, false);
			
			btn_zona3.addEventListener(hmUI.event.CLICK_DOWN, function () {
					if(longPress_Timer) timer.stopTimer(longPress_Timer);
					longPress_Timer = timer.createTimer(longPressDelay, 0, getLongPress3, {});
			});
			btn_zona3.addEventListener(hmUI.event.CLICK_UP, function () {
					if(longPress_Timer) timer.stopTimer(longPress_Timer);
			});
			
			bot_circle_btn = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 197,
              y: 197,
              text: '',
              w: 73,
              h: 73,
              normal_src: 'Empty.png',
              press_src: 'Empty.png',
              click_func: () => {
                  getClick();
              },
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
              bot_circle_btn.setProperty(hmUI.prop.VISIBLE, true);

            //start of ignored block
            console.log('compass_update()');
            if (screenType == hmSetting.screen_type.WATCHFACE){
              compass = hmSensor.createSensor(hmSensor.id.COMPASS);
              compass.start();

              if (compass.direction_angle && compass.direction  && compass.direction_angle != 'INVALID') { // initial data
                // Compass Pointer
                let compass_direction_angle = parseInt(compass.direction_angle);
                normal_compass_direction_pointer_img.setProperty(hmUI.prop.ANGLE, -compass_direction_angle);

              } else { // error data
                normal_compass_direction_pointer_img.setProperty(hmUI.prop.ANGLE, 0);

              }

              compass.addEventListener(hmSensor.event.CHANGE, function (compass_res) { // change values when changing direction

                if (compass_res.calibration_status) {
                  // Compass Pointer
                  let compass_direction_angle = parseInt(compass_res.direction_angle);
                  normal_compass_direction_pointer_img.setProperty(hmUI.prop.ANGLE, -compass_direction_angle);

                } else { // error data
                  normal_compass_direction_pointer_img.setProperty(hmUI.prop.ANGLE, 0);

                }

              }); // Listener end

            };
            //end of ignored block

            function scale_call() {
              console.log('scale_call()');

                console.log('update scales BATTERY');
                
                let valueBattery = battery.current;
                let targetBattery = 100;
                let progressBattery = valueBattery/targetBattery;
                if (progressBattery > 1) progressBattery = 1;
                let progress_cs_normal_battery = progressBattery;

                if (screenType != hmSetting.screen_type.AOD) {

                  // normal_battery_circle_scale_circle_scale
                  let level = Math.round(progress_cs_normal_battery * 100);
                  if (normal_battery_circle_scale) {
                    normal_battery_circle_scale.setProperty(hmUI.prop.MORE, {                      
                      center_x: 231,
                      center_y: 382,
                      start_angle: -138,
                      end_angle: 138,
                      radius: 56,
                      line_width: 3,
                      corner_flag: 0,
                      color: 0xFF00FF00,
                      show_level: hmUI.show_level.ONLY_NORMAL,
                      level: level,
                    });
                  };
                };

                console.log('update scales FAT_BURNING');
                
                let valueFatBurning = fat_burning.current;
                let targetFatBurning = fat_burning.target;
                let progressFatBurning = valueFatBurning/targetFatBurning;
                if (progressFatBurning > 1) progressFatBurning = 1;
                let progress_cs_normal_fat_burning = progressFatBurning;

                if (screenType != hmSetting.screen_type.AOD) {

                  // normal_fat_burning_circle_scale_circle_scale
                  let level = Math.round(progress_cs_normal_fat_burning * 100);
                  if (normal_fat_burning_circle_scale) {
                    normal_fat_burning_circle_scale.setProperty(hmUI.prop.MORE, {                      
                      center_x: 83,
                      center_y: 232,
                      start_angle: -138,
                      end_angle: 138,
                      radius: 56,
                      line_width: 3,
                      corner_flag: 0,
                      color: 0xFF80FF80,
                      show_level: hmUI.show_level.ONLY_NORMAL,
                      level: level,
                    });
                  };
                };

                console.log('update scales STAND');
                
                let valueStand = stand.current;
                let targetStand = stand.target;
                let progressStand = valueStand/targetStand;
                if (progressStand > 1) progressStand = 1;
                let progress_cs_normal_stand = progressStand;

                if (screenType != hmSetting.screen_type.AOD) {

                  // normal_stand_circle_scale_circle_scale
                  let level = Math.round(progress_cs_normal_stand * 100);
                  if (normal_stand_circle_scale) {
                    normal_stand_circle_scale.setProperty(hmUI.prop.MORE, {                      
                      center_x: 83,
                      center_y: 232,
                      start_angle: -138,
                      end_angle: 138,
                      radius: 56,
                      line_width: 3,
                      corner_flag: 0,
                      color: 0xFF00DDDD,
                      show_level: hmUI.show_level.ONLY_NORMAL,
                      level: level,
                    });
                  };
                };

                console.log('update scales CALORIE');
                
                let valueCalories = calorie.current;
                let targetCalories = calorie.target;
                let progressCalories = valueCalories/targetCalories;
                if (progressCalories > 1) progressCalories = 1;
                let progress_cs_normal_calorie = progressCalories;

                if (screenType != hmSetting.screen_type.AOD) {

                  // normal_calorie_circle_scale_circle_scale
                  let level = Math.round(progress_cs_normal_calorie * 100);
                  if (normal_calorie_circle_scale) {
                    normal_calorie_circle_scale.setProperty(hmUI.prop.MORE, {                      
                      center_x: 83,
                      center_y: 232,
                      start_angle: -138,
                      end_angle: 138,
                      radius: 56,
                      line_width: 3,
                      corner_flag: 0,
                      color: 0xFFFF8C00,
                      show_level: hmUI.show_level.ONLY_NORMAL,
                      level: level,
                    });
                  };
                };

                console.log('update scales STEP');
                
                let valueStep = step.current;
                let targetStep = step.target;
                let progressStep = valueStep/targetStep;
                if (progressStep > 1) progressStep = 1;
                let progress_cs_normal_step = progressStep;

                if (screenType != hmSetting.screen_type.AOD) {

                  // normal_step_circle_scale_circle_scale
                  let level = Math.round(progress_cs_normal_step * 100);
                  if (normal_step_circle_scale) {
                    normal_step_circle_scale.setProperty(hmUI.prop.MORE, {                      
                      center_x: 83,
                      center_y: 232,
                      start_angle: -138,
                      end_angle: 138,
                      radius: 56,
                      line_width: 3,
                      corner_flag: 0,
                      color: 0xFF0000FF,
                      show_level: hmUI.show_level.ONLY_NORMAL,
                      level: level,
                    });
                  };
                };

            };

            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                console.log('resume_call()');
                scale_call();
                if (compass && screenType == hmSetting.screen_type.WATCHFACE) compass.start();

              }),
              pause_call: (function () {
                console.log('pause_call()');
                if (compass) compass.stop();

              }),
            });

                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}