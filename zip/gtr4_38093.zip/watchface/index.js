﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        const logger = Logger.getLogger('watchface_SashaCX75');
        //end of ignored block

        //dynamic modify start

        
        console.log('user_functions.js');
        // start user_functions.js

let color2number_main = 1
        let totalcolor2s_main = 9
        let namecolor2_main = ''
		
		function click_COLOR() {
            if(color2number_main>=totalcolor2s_main) {
            color2number_main=1;
                }
            else {
                color2number_main=color2number_main+1;
            }
			if ( color2number_main == 1) { namecolor2_main = "RED STYLE"}
			if ( color2number_main == 2) { namecolor2_main = "CYAN STYLE"}
			if ( color2number_main == 3) { namecolor2_main = "ORANGE STYLE"}
			if ( color2number_main == 4) { namecolor2_main = "GREEN STYLE"}
			if ( color2number_main == 5) { namecolor2_main = "FUCHSIA STYLE"}
			if ( color2number_main == 6) { namecolor2_main = "YELLOW STYLE"}
			if ( color2number_main == 7) { namecolor2_main = "BLUE STYLE"}
			if ( color2number_main == 8) { namecolor2_main = "LIME STYLE"}
			if ( color2number_main == 9) { namecolor2_main = "PURPLE STYLE"}

			hmUI.showToast({text: namecolor2_main });
            normal_background_bg_img.setProperty(hmUI.prop.SRC, "bg" + parseInt(color2number_main) + ".png");
        }
		
		let elementnumber_1 = 1
        let total_elemente_1 = 2

        function click_TOP() {
            if(elementnumber_1==total_elemente_1) {
            elementnumber_1=1;
                UpdateElemente_1One();
                }
            else {
                elementnumber_1=elementnumber_1+1;
                if(elementnumber_1==2) {
                  UpdateElemente_1Two();
                }
            }
            if(elementnumber_1==1) hmUI.showToast({text: 'Cover TOP OFF'});
            if(elementnumber_1==2) hmUI.showToast({text: 'Cover TOP ON'});
        }

        // Cover OFF
        function UpdateElemente_1One(){
				normal_stress_icon_img.setProperty(hmUI.prop.VISIBLE, false);
        }

        //Cover ON
        function UpdateElemente_1Two(){
				normal_stress_icon_img.setProperty(hmUI.prop.VISIBLE, true);
        }
		
		let elementnumber_2 = 1
        let total_elemente_2 = 2

        function click_MID() {
            if(elementnumber_2==total_elemente_2) {
            elementnumber_2=1;
                UpdateElemente_2One();
                }
            else {
                elementnumber_2=elementnumber_2+1;
                if(elementnumber_2==2) {
                  UpdateElemente_2Two();
                }
            }
            if(elementnumber_2==1) hmUI.showToast({text: 'Cover MID OFF'});
            if(elementnumber_2==2) hmUI.showToast({text: 'Cover MID ON'});
        }

        // Cover OFF
        function UpdateElemente_2One(){
				normal_stand_icon_img.setProperty(hmUI.prop.VISIBLE, false);
        }

        //Cover ON
        function UpdateElemente_2Two(){
				normal_stand_icon_img.setProperty(hmUI.prop.VISIBLE, true);
        }
		
		let elementnumber_3 = 1
        let total_elemente_3 = 2

        function click_BOT() {
            if(elementnumber_3==total_elemente_3) {
            elementnumber_3=1;
                UpdateElemente_3One();
                }
            else {
                elementnumber_3=elementnumber_3+1;
                if(elementnumber_3==2) {
                  UpdateElemente_3Two();
                }
            }
            if(elementnumber_3==1) hmUI.showToast({text: 'Cover BOT OFF'});
            if(elementnumber_3==2) hmUI.showToast({text: 'Cover BOT ON'});
        }

        // Cover OFF
        function UpdateElemente_3One(){
				normal_fat_burning_icon_img.setProperty(hmUI.prop.VISIBLE, false);
        }

        //Cover ON
        function UpdateElemente_3Two(){
				normal_fat_burning_icon_img.setProperty(hmUI.prop.VISIBLE, true);
        }
        // end user_functions.js

        let normal_background_bg_img = ''
        let normal_fat_burning_icon_img = ''
        let normal_stand_icon_img = ''
        let normal_stress_icon_img = ''
        let normal_distance_text_text_img = ''
        let normal_heart_rate_text_text_img = ''
        let normal_calorie_current_text_img = ''
        let normal_step_current_text_img = ''
        let normal_date_img_date_month_img = ''
        let normal_date_img_date_day = ''
        let normal_date_img_date_week_img = ''
        let normal_temperature_current_text_img = ''
        let normal_weather_image_progress_img_level = ''
        let normal_moon_image_progress_img_level = ''
        let normal_sun_current_text_img = ''
        let normal_battery_image_progress_img_level = ''
        let normal_battery_icon_img = ''
        let normal_battery_TextCircle = new Array(3);
        let normal_battery_TextCircle_ASCIIARRAY = new Array(10);
        let normal_battery_TextCircle_img_width = 17;
        let normal_battery_TextCircle_img_height = 26;
        let normal_battery_TextCircle_unit = null;
        let normal_battery_TextCircle_unit_width = 20;
        let normal_battery_TextCircle_error_img_width = 26;
        let normal_image_img = ''
        let normal_system_disconnect_img = ''
        let normal_system_clock_img = ''
        let normal_digital_clock_img_time_AmPm = ''
        let normal_digital_clock_img_time = ''
        let idle_background_bg_img = ''
        let idle_fat_burning_icon_img = ''
        let idle_stand_icon_img = ''
        let idle_stress_icon_img = ''
        let idle_distance_text_text_img = ''
        let idle_heart_rate_text_text_img = ''
        let idle_calorie_current_text_img = ''
        let idle_step_current_text_img = ''
        let idle_date_img_date_month_img = ''
        let idle_date_img_date_day = ''
        let idle_date_img_date_week_img = ''
        let idle_temperature_current_text_img = ''
        let idle_weather_image_progress_img_level = ''
        let idle_moon_image_progress_img_level = ''
        let idle_sun_current_text_img = ''
        let idle_battery_image_progress_img_level = ''
        let idle_battery_icon_img = ''
        let idle_battery_TextCircle = new Array(3);
        let idle_battery_TextCircle_ASCIIARRAY = new Array(10);
        let idle_battery_TextCircle_img_width = 17;
        let idle_battery_TextCircle_img_height = 26;
        let idle_battery_TextCircle_unit = null;
        let idle_battery_TextCircle_unit_width = 20;
        let idle_battery_TextCircle_error_img_width = 26;
        let idle_image_img = ''
        let idle_system_disconnect_img = ''
        let idle_system_clock_img = ''
        let idle_digital_clock_img_time_AmPm = ''
        let idle_digital_clock_img_time = ''
        let Button_1 = ''
        let Button_2 = ''
        let Button_3 = ''
        let Button_4 = ''
        let Button_5 = ''
        let Button_6 = ''
        let Button_7 = ''
        let Button_8 = ''
        let Button_9 = ''
        let Button_10 = ''
        let Button_11 = ''
        let Button_12 = ''
        let Button_13 = ''
        let Button_14 = ''
        let Button_15 = ''
        let Button_16 = ''
        let Button_17 = ''


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            console.log('Watch_Face.ScreenNormal');
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 466,
              h: 466,
              src: 'bg1.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_fat_burning_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'cover_bot.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_stand_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'cover_mid.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_stress_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'cover_top.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_distance_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 179,
              y: 402,
              font_array: ["num_00.png","num_01.png","num_02.png","num_03.png","num_04.png","num_05.png","num_06.png","num_07.png","num_08.png","num_09.png"],
              padding: true,
              h_space: 0,
              unit_sc: 'num_km.png',
              unit_tc: 'num_km.png',
              unit_en: 'num_km.png',
              imperial_unit_sc: 'num_mil.png',
              imperial_unit_tc: 'num_mil.png',
              imperial_unit_en: 'num_mil.png',
              dot_image: 'num_14.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.DISTANCE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 322,
              y: 321,
              font_array: ["num_00.png","num_01.png","num_02.png","num_03.png","num_04.png","num_05.png","num_06.png","num_07.png","num_08.png","num_09.png"],
              padding: false,
              h_space: 2,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_calorie_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 81,
              y: 321,
              font_array: ["num_00.png","num_01.png","num_02.png","num_03.png","num_04.png","num_05.png","num_06.png","num_07.png","num_08.png","num_09.png"],
              padding: false,
              h_space: 2,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 157,
              y: 317,
              font_array: ["big_00.png","big_01.png","big_02.png","big_03.png","big_04.png","big_05.png","big_06.png","big_07.png","big_08.png","big_09.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_month_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 328,
              month_startY: 150,
              month_sc_array: ["month_01.png","month_02.png","month_03.png","month_04.png","month_05.png","month_06.png","month_07.png","month_08.png","month_09.png","month_10.png","month_11.png","month_12.png"],
              month_tc_array: ["month_01.png","month_02.png","month_03.png","month_04.png","month_05.png","month_06.png","month_07.png","month_08.png","month_09.png","month_10.png","month_11.png","month_12.png"],
              month_en_array: ["month_01.png","month_02.png","month_03.png","month_04.png","month_05.png","month_06.png","month_07.png","month_08.png","month_09.png","month_10.png","month_11.png","month_12.png"],
              month_is_character: true ,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 203,
              day_startY: 95,
              day_sc_array: ["big_00.png","big_01.png","big_02.png","big_03.png","big_04.png","big_05.png","big_06.png","big_07.png","big_08.png","big_09.png"],
              day_tc_array: ["big_00.png","big_01.png","big_02.png","big_03.png","big_04.png","big_05.png","big_06.png","big_07.png","big_08.png","big_09.png"],
              day_en_array: ["big_00.png","big_01.png","big_02.png","big_03.png","big_04.png","big_05.png","big_06.png","big_07.png","big_08.png","big_09.png"],
              day_zero: 0,
              day_space: 0,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 0,
              y: 0,
              week_en: ["wd1.png","wd2.png","wd3.png","wd4.png","wd5.png","wd6.png","wd7.png"],
              week_tc: ["wd1.png","wd2.png","wd3.png","wd4.png","wd5.png","wd6.png","wd7.png"],
              week_sc: ["wd1.png","wd2.png","wd3.png","wd4.png","wd5.png","wd6.png","wd7.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 345,
              y: 106,
              font_array: ["num_00.png","num_01.png","num_02.png","num_03.png","num_04.png","num_05.png","num_06.png","num_07.png","num_08.png","num_09.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'num_11.png',
              unit_tc: 'num_11.png',
              unit_en: 'num_11.png',
              negative_image: 'num_10.png',
              invalid_image: 'num_12.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 287,
              y: 91,
              image_array: ["weatherl_00.png","weatherl_01.png","weatherl_02.png","weatherl_03.png","weatherl_04.png","weatherl_05.png","weatherl_06.png","weatherl_07.png","weatherl_08.png","weatherl_09.png","weatherl_10.png","weatherl_11.png","weatherl_12.png","weatherl_13.png","weatherl_14.png","weatherl_15.png","weatherl_16.png","weatherl_17.png","weatherl_18.png","weatherl_19.png","weatherl_20.png","weatherl_21.png","weatherl_22.png","weatherl_23.png","weatherl_24.png","weatherl_25.png","weatherl_26.png","weatherl_27.png","weatherl_28.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_moon_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 136,
              y: 92,
              image_array: ["Moon_01.png","Moon_02.png","Moon_03.png","Moon_04.png","Moon_05.png","Moon_06.png","Moon_07.png","Moon_08.png","Moon_09.png","Moon_10.png","Moon_11.png","Moon_12.png","Moon_13.png","Moon_14.png","Moon_15.png","Moon_16.png","Moon_17.png","Moon_18.png","Moon_19.png","Moon_20.png","Moon_21.png","Moon_22.png","Moon_23.png","Moon_24.png","Moon_25.png","Moon_26.png","Moon_27.png","Moon_28.png","Moon_29.png","Moon_30.png"],
              image_length: 30,
              type: hmUI.data_type.MOON,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sun_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 52,
              y: 106,
              font_array: ["num_00.png","num_01.png","num_02.png","num_03.png","num_04.png","num_05.png","num_06.png","num_07.png","num_08.png","num_09.png"],
              padding: false,
              h_space: 0,
              invalid_image: 'num_12.png',
              dot_image: 'num_15.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.SUN_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 0,
              y: 0,
              image_array: ["batt_01.png","batt_02.png","batt_03.png","batt_04.png","batt_05.png","batt_06.png","batt_07.png","batt_08.png","batt_09.png","batt_10.png"],
              image_length: 10,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'batt_bck.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_battery_text_circle_img = hmUI.createWidget(hmUI.widget.Text_Circle, {
              // circle_center_X: 233,
              // circle_center_Y: 233,
              // font_array: ["num_00.png","num_01.png","num_02.png","num_03.png","num_04.png","num_05.png","num_06.png","num_07.png","num_08.png","num_09.png"],
              // radius: 211,
              // angle: 1,
              // char_space_angle: 0,
              // unit: 'num_13.png',
              // error_image: 'num_12.png',
              // zero: false,
              // reverse_direction: false,
              // unit_in_alignment: true,
              // vertical_alignment: CENTER_V,
              // horizontal_alignment: CENTER_H,
              // type: hmUI.data_type.BATTERY,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_battery_TextCircle_ASCIIARRAY[0] = 'num_00.png';  // set of images with numbers
            normal_battery_TextCircle_ASCIIARRAY[1] = 'num_01.png';  // set of images with numbers
            normal_battery_TextCircle_ASCIIARRAY[2] = 'num_02.png';  // set of images with numbers
            normal_battery_TextCircle_ASCIIARRAY[3] = 'num_03.png';  // set of images with numbers
            normal_battery_TextCircle_ASCIIARRAY[4] = 'num_04.png';  // set of images with numbers
            normal_battery_TextCircle_ASCIIARRAY[5] = 'num_05.png';  // set of images with numbers
            normal_battery_TextCircle_ASCIIARRAY[6] = 'num_06.png';  // set of images with numbers
            normal_battery_TextCircle_ASCIIARRAY[7] = 'num_07.png';  // set of images with numbers
            normal_battery_TextCircle_ASCIIARRAY[8] = 'num_08.png';  // set of images with numbers
            normal_battery_TextCircle_ASCIIARRAY[9] = 'num_09.png';  // set of images with numbers

            //start of ignored block
            for (let i = 0; i < 3; i++) {
              normal_battery_TextCircle[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 466,
                h: 466,
                center_x: 233,
                center_y: 233,
                pos_x: 233 - normal_battery_TextCircle_img_width / 2,
                pos_y: 233 - 224,
                src: 'num_00.png',
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
              normal_battery_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
            };

            normal_battery_TextCircle_unit = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 466,
              h: 466,
              center_x: 233,
              center_y: 233,
              pos_x: 233 - normal_battery_TextCircle_unit_width / 2,
              pos_y: 233 - 224,
              src: 'num_13.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            normal_battery_TextCircle_unit.setProperty(hmUI.prop.VISIBLE, false);
            //end of ignored block
            
            const battery = hmSensor.createSensor(hmSensor.id.BATTERY);
            battery.addEventListener(hmSensor.event.CHANGE, function() {
              text_update();
            });
            
            function toDegree (radian) {
              return radian * (180 / Math.PI);
            };

            normal_image_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'main.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 339,
              y: 382,
              src: 'st_bt.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 107,
              y: 382,
              src: 'st_al.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time_AmPm = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              am_x: 0,
              am_y: 0,
              am_sc_path: 'time_am.png',
              am_en_path: 'time_am.png',
              pm_x: 0,
              pm_y: 0,
              pm_sc_path: 'time_pm.png',
              pm_en_path: 'time_pm.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 31,
              hour_startY: 201,
              hour_array: ["time_00.png","time_01.png","time_02.png","time_03.png","time_04.png","time_05.png","time_06.png","time_07.png","time_08.png","time_09.png"],
              hour_zero: 1,
              hour_space: 8,
              hour_angle: 0,
              hour_align: hmUI.align.LEFT,

              minute_startX: 179,
              minute_startY: 201,
              minute_array: ["time_00.png","time_01.png","time_02.png","time_03.png","time_04.png","time_05.png","time_06.png","time_07.png","time_08.png","time_09.png"],
              minute_zero: 1,
              minute_space: 8,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              second_startX: 322,
              second_startY: 201,
              second_array: ["sec_00.png","sec_01.png","sec_02.png","sec_03.png","sec_04.png","sec_05.png","sec_06.png","sec_07.png","sec_08.png","sec_09.png"],
              second_zero: 1,
              second_space: 8,
              second_angle: 0,
              second_follow: 0,
              second_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            console.log('Watch_Face.ScreenAOD');
            idle_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 466,
              h: 466,
              src: 'bg1.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_fat_burning_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'cover_bot.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_stand_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'cover_mid.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_stress_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'cover_top.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_distance_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 179,
              y: 402,
              font_array: ["num_00.png","num_01.png","num_02.png","num_03.png","num_04.png","num_05.png","num_06.png","num_07.png","num_08.png","num_09.png"],
              padding: true,
              h_space: 0,
              unit_sc: 'num_km.png',
              unit_tc: 'num_km.png',
              unit_en: 'num_km.png',
              imperial_unit_sc: 'num_mil.png',
              imperial_unit_tc: 'num_mil.png',
              imperial_unit_en: 'num_mil.png',
              dot_image: 'num_14.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.DISTANCE,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 322,
              y: 321,
              font_array: ["num_00.png","num_01.png","num_02.png","num_03.png","num_04.png","num_05.png","num_06.png","num_07.png","num_08.png","num_09.png"],
              padding: false,
              h_space: 2,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_calorie_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 81,
              y: 321,
              font_array: ["num_00.png","num_01.png","num_02.png","num_03.png","num_04.png","num_05.png","num_06.png","num_07.png","num_08.png","num_09.png"],
              padding: false,
              h_space: 2,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 157,
              y: 317,
              font_array: ["big_00.png","big_01.png","big_02.png","big_03.png","big_04.png","big_05.png","big_06.png","big_07.png","big_08.png","big_09.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_month_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 328,
              month_startY: 150,
              month_sc_array: ["month_01.png","month_02.png","month_03.png","month_04.png","month_05.png","month_06.png","month_07.png","month_08.png","month_09.png","month_10.png","month_11.png","month_12.png"],
              month_tc_array: ["month_01.png","month_02.png","month_03.png","month_04.png","month_05.png","month_06.png","month_07.png","month_08.png","month_09.png","month_10.png","month_11.png","month_12.png"],
              month_en_array: ["month_01.png","month_02.png","month_03.png","month_04.png","month_05.png","month_06.png","month_07.png","month_08.png","month_09.png","month_10.png","month_11.png","month_12.png"],
              month_is_character: true ,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 203,
              day_startY: 95,
              day_sc_array: ["big_00.png","big_01.png","big_02.png","big_03.png","big_04.png","big_05.png","big_06.png","big_07.png","big_08.png","big_09.png"],
              day_tc_array: ["big_00.png","big_01.png","big_02.png","big_03.png","big_04.png","big_05.png","big_06.png","big_07.png","big_08.png","big_09.png"],
              day_en_array: ["big_00.png","big_01.png","big_02.png","big_03.png","big_04.png","big_05.png","big_06.png","big_07.png","big_08.png","big_09.png"],
              day_zero: 0,
              day_space: 0,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 0,
              y: 0,
              week_en: ["wd1.png","wd2.png","wd3.png","wd4.png","wd5.png","wd6.png","wd7.png"],
              week_tc: ["wd1.png","wd2.png","wd3.png","wd4.png","wd5.png","wd6.png","wd7.png"],
              week_sc: ["wd1.png","wd2.png","wd3.png","wd4.png","wd5.png","wd6.png","wd7.png"],
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 345,
              y: 106,
              font_array: ["num_00.png","num_01.png","num_02.png","num_03.png","num_04.png","num_05.png","num_06.png","num_07.png","num_08.png","num_09.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'num_11.png',
              unit_tc: 'num_11.png',
              unit_en: 'num_11.png',
              negative_image: 'num_10.png',
              invalid_image: 'num_12.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 287,
              y: 91,
              image_array: ["weatherl_00.png","weatherl_01.png","weatherl_02.png","weatherl_03.png","weatherl_04.png","weatherl_05.png","weatherl_06.png","weatherl_07.png","weatherl_08.png","weatherl_09.png","weatherl_10.png","weatherl_11.png","weatherl_12.png","weatherl_13.png","weatherl_14.png","weatherl_15.png","weatherl_16.png","weatherl_17.png","weatherl_18.png","weatherl_19.png","weatherl_20.png","weatherl_21.png","weatherl_22.png","weatherl_23.png","weatherl_24.png","weatherl_25.png","weatherl_26.png","weatherl_27.png","weatherl_28.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_moon_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 136,
              y: 92,
              image_array: ["Moon_01.png","Moon_02.png","Moon_03.png","Moon_04.png","Moon_05.png","Moon_06.png","Moon_07.png","Moon_08.png","Moon_09.png","Moon_10.png","Moon_11.png","Moon_12.png","Moon_13.png","Moon_14.png","Moon_15.png","Moon_16.png","Moon_17.png","Moon_18.png","Moon_19.png","Moon_20.png","Moon_21.png","Moon_22.png","Moon_23.png","Moon_24.png","Moon_25.png","Moon_26.png","Moon_27.png","Moon_28.png","Moon_29.png","Moon_30.png"],
              image_length: 30,
              type: hmUI.data_type.MOON,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_sun_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 52,
              y: 106,
              font_array: ["num_00.png","num_01.png","num_02.png","num_03.png","num_04.png","num_05.png","num_06.png","num_07.png","num_08.png","num_09.png"],
              padding: false,
              h_space: 0,
              invalid_image: 'num_12.png',
              dot_image: 'num_15.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.SUN_CURRENT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_battery_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 0,
              y: 0,
              image_array: ["batt_01.png","batt_02.png","batt_03.png","batt_04.png","batt_05.png","batt_06.png","batt_07.png","batt_08.png","batt_09.png","batt_10.png"],
              image_length: 10,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_battery_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'batt_bck.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            // idle_battery_text_circle_img = hmUI.createWidget(hmUI.widget.Text_Circle, {
              // circle_center_X: 233,
              // circle_center_Y: 233,
              // font_array: ["num_00.png","num_01.png","num_02.png","num_03.png","num_04.png","num_05.png","num_06.png","num_07.png","num_08.png","num_09.png"],
              // radius: 211,
              // angle: 1,
              // char_space_angle: 0,
              // unit: 'num_13.png',
              // error_image: 'num_12.png',
              // zero: false,
              // reverse_direction: false,
              // unit_in_alignment: true,
              // vertical_alignment: CENTER_V,
              // horizontal_alignment: CENTER_H,
              // type: hmUI.data_type.BATTERY,
              // show_level: hmUI.show_level.ONLY_AOD,
            // });

            idle_battery_TextCircle_ASCIIARRAY[0] = 'num_00.png';  // set of images with numbers
            idle_battery_TextCircle_ASCIIARRAY[1] = 'num_01.png';  // set of images with numbers
            idle_battery_TextCircle_ASCIIARRAY[2] = 'num_02.png';  // set of images with numbers
            idle_battery_TextCircle_ASCIIARRAY[3] = 'num_03.png';  // set of images with numbers
            idle_battery_TextCircle_ASCIIARRAY[4] = 'num_04.png';  // set of images with numbers
            idle_battery_TextCircle_ASCIIARRAY[5] = 'num_05.png';  // set of images with numbers
            idle_battery_TextCircle_ASCIIARRAY[6] = 'num_06.png';  // set of images with numbers
            idle_battery_TextCircle_ASCIIARRAY[7] = 'num_07.png';  // set of images with numbers
            idle_battery_TextCircle_ASCIIARRAY[8] = 'num_08.png';  // set of images with numbers
            idle_battery_TextCircle_ASCIIARRAY[9] = 'num_09.png';  // set of images with numbers

            //start of ignored block
            for (let i = 0; i < 3; i++) {
              idle_battery_TextCircle[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 466,
                h: 466,
                center_x: 233,
                center_y: 233,
                pos_x: 233 - idle_battery_TextCircle_img_width / 2,
                pos_y: 233 - 224,
                src: 'num_00.png',
                show_level: hmUI.show_level.ONLY_AOD,
              });
              idle_battery_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
            };

            idle_battery_TextCircle_unit = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 466,
              h: 466,
              center_x: 233,
              center_y: 233,
              pos_x: 233 - idle_battery_TextCircle_unit_width / 2,
              pos_y: 233 - 224,
              src: 'num_13.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });
            idle_battery_TextCircle_unit.setProperty(hmUI.prop.VISIBLE, false);
            //end of ignored block

            idle_image_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'main.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 339,
              y: 382,
              src: 'st_bt.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 107,
              y: 382,
              src: 'st_al.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time_AmPm = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              am_x: 0,
              am_y: 0,
              am_sc_path: 'time_am.png',
              am_en_path: 'time_am.png',
              pm_x: 0,
              pm_y: 0,
              pm_sc_path: 'time_pm.png',
              pm_en_path: 'time_pm.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 31,
              hour_startY: 201,
              hour_array: ["time_00.png","time_01.png","time_02.png","time_03.png","time_04.png","time_05.png","time_06.png","time_07.png","time_08.png","time_09.png"],
              hour_zero: 1,
              hour_space: 8,
              hour_angle: 0,
              hour_align: hmUI.align.LEFT,

              minute_startX: 179,
              minute_startY: 201,
              minute_array: ["time_00.png","time_01.png","time_02.png","time_03.png","time_04.png","time_05.png","time_06.png","time_07.png","time_08.png","time_09.png"],
              minute_zero: 1,
              minute_space: 8,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              second_startX: 322,
              second_startY: 201,
              second_array: ["sec_00.png","sec_01.png","sec_02.png","sec_03.png","sec_04.png","sec_05.png","sec_06.png","sec_07.png","sec_08.png","sec_09.png"],
              second_zero: 1,
              second_space: 8,
              second_angle: 0,
              second_follow: 0,
              second_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_AOD,
            });
            
            // disconnectAlert = hmUI.createWidget(hmUI.widget.DisconnectAlert, {
              // disconneсnt_vibrate_type: 9,
              // disconneсnt_toast_text: Bluetooth OFF,
              // conneсnt_vibrate_type: 0,
              // conneсnt_toast_text: Bluetooth ON,
            // });

            // vibration when connecting or disconnecting

            function checkConnection() {
              console.log('checkConnection()');
              hmBle.removeListener;
              hmBle.addListener(function (status) {
                if(!status) {
                  hmUI.showToast({text: "Bluetooth OFF"});
                  vibro(9);
                }
                if(status) {
                  hmUI.showToast({text: "Bluetooth ON"});
                  vibro(0);
                }
              });
            }

            // end vibration when connecting or disconnecting
            // vibrate function

            const vibrate = hmSensor.createSensor(hmSensor.id.VIBRATE);
            let timer_StopVibrate = null;


            function vibro(scene = 25) {
              let stopDelay = 50;
              stopVibro();
              vibrate.stop();
              vibrate.scene = scene;
              if(scene < 23 || scene > 25) stopDelay = 1300;
              vibrate.start();
              if (scene != 1) timer_StopVibrate = timer.createTimer(stopDelay, 3000, stopVibro, {});
            }

            function stopVibro(){
              vibrate.stop();
              if(timer_StopVibrate) timer.stopTimer(timer_StopVibrate);
            }

            // end vibrate function

            console.log('Watch_Face.Buttons');
            Button_1 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 332,
              y: 209,
              w: 87,
              h: 58,
              text: '',
              color: 0xFFFF8C00,
              text_size: 24,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'StopWatchScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_2 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 189,
              y: 209,
              w: 87,
              h: 58,
              text: '',
              color: 0xFFFF8C00,
              text_size: 24,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'CountdownAppScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_3 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 42,
              y: 209,
              w: 87,
              h: 58,
              text: '',
              color: 0xFFFF8C00,
              text_size: 24,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'TomatoMainScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_4 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 160,
              y: 316,
              w: 146,
              h: 68,
              text: '',
              color: 0xFFFF8C00,
              text_size: 24,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'activityAppScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_5 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 97,
              y: 379,
              w: 39,
              h: 39,
              text: '',
              color: 0xFFFF8C00,
              text_size: 24,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'AlarmInfoScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_6 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 330,
              y: 379,
              w: 39,
              h: 39,
              text: '',
              color: 0xFFFF8C00,
              text_size: 24,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'FindPhoneScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_7 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 320,
              y: 320,
              w: 58,
              h: 58,
              text: '',
              color: 0xFFFF8C00,
              text_size: 24,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'heart_app_Screen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_8 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 87,
              y: 320,
              w: 58,
              h: 58,
              text: '',
              color: 0xFFFF8C00,
              text_size: 24,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'PAI_app_Screen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_9 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 184,
              y: 403,
              w: 97,
              h: 49,
              text: '',
              color: 0xFFFF8C00,
              text_size: 24,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'SportStatusScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_10 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 330,
              y: 92,
              w: 97,
              h: 49,
              text: '',
              color: 0xFFFF8C00,
              text_size: 24,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'WeatherScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_11 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 184,
              y: 92,
              w: 97,
              h: 49,
              text: '',
              color: 0xFFFF8C00,
              text_size: 24,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'ScheduleCalScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_12 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 39,
              y: 92,
              w: 97,
              h: 49,
              text: '',
              color: 0xFFFF8C00,
              text_size: 24,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'TideScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_13 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 184,
              y: 0,
              w: 97,
              h: 49,
              text: '',
              color: 0xFFFF8C00,
              text_size: 24,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'PowerSaveHintScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_14 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 398,
              y: 146,
              w: 39,
              h: 39,
              text: '',
              color: 0xFFFF8C00,
              text_size: 24,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                click_TOP();
                				vibro(25);
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_15 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 34,
              y: 306,
              w: 39,
              h: 39,
              text: '',
              color: 0xFFFF8C00,
              text_size: 24,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                click_COLOR();
                				vibro(25);
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_16 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 393,
              y: 306,
              w: 39,
              h: 39,
              text: '',
              color: 0xFFFF8C00,
              text_size: 24,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                click_BOT();
                				vibro(25);
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_17 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 427,
              y: 218,
              w: 39,
              h: 39,
              text: '',
              color: 0xFFFF8C00,
              text_size: 24,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                click_MID();
                				vibro(25);
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            console.log('user_script_end.js');
            // start user_script_end.js

let cc = 0
			if (cc ==0 ){
			  normal_stress_icon_img.setProperty(hmUI.prop.VISIBLE, false);
              normal_stand_icon_img.setProperty(hmUI.prop.VISIBLE, false);
			  normal_fat_burning_icon_img.setProperty(hmUI.prop.VISIBLE, false);
			cc = 1;
			}
            // end user_script_end.js

            let screenType = hmSetting.getScreenType();
            function text_update() {
              console.log('text_update()');

              console.log('update text circle battery_BATTERY');
              let valueBattery = battery.current;
              let normal_battery_circle_string = parseInt(valueBattery).toString();

              if (screenType != hmSetting.screen_type.AOD) {
                for (var i = 1; i < 3; i++) {  // hide all symbols
                  normal_battery_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                normal_battery_TextCircle_unit.setProperty(hmUI.prop.VISIBLE, false);
                let char_Angle = 1;
                if (valueBattery != null && valueBattery != undefined && isFinite(valueBattery) && normal_battery_circle_string.length > 0 && normal_battery_circle_string.length < 6) {  // display data if it was possible to get it
                  let normal_battery_TextCircle_img_angle = 0;
                  let normal_battery_TextCircle_dot_img_angle = 0;
                  let normal_battery_TextCircle_unit_angle = 0;
                  normal_battery_TextCircle_img_angle = toDegree(Math.atan2(normal_battery_TextCircle_img_width/2, 211));
                  normal_battery_TextCircle_unit_angle = toDegree(Math.atan2(normal_battery_TextCircle_unit_width/2, 211));
                  // alignment = CENTER_H
                  let normal_battery_TextCircle_angleOffset = normal_battery_TextCircle_img_angle * (normal_battery_circle_string.length - 1);
                  normal_battery_TextCircle_angleOffset = normal_battery_TextCircle_angleOffset + (normal_battery_TextCircle_img_angle + normal_battery_TextCircle_unit_angle + 0) / 2;
                  char_Angle -= normal_battery_TextCircle_angleOffset;
                  // alignment end
                  
                  let firstSymbol = true;
                  let index = 0;
                  for (let char of normal_battery_circle_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 3) break;
                    if (charCode >= 0 && charCode < 10) { 
                      if (!firstSymbol) char_Angle += normal_battery_TextCircle_img_angle;
                      firstSymbol = false;
                      normal_battery_TextCircle[index].setProperty(hmUI.prop.ANGLE, char_Angle);
                      normal_battery_TextCircle[index].setProperty(hmUI.prop.POS_X, 233 - normal_battery_TextCircle_img_width / 2);
                      normal_battery_TextCircle[index].setProperty(hmUI.prop.SRC, normal_battery_TextCircle_ASCIIARRAY[charCode]);
                      normal_battery_TextCircle[index].setProperty(hmUI.prop.VISIBLE, true);
                      char_Angle += normal_battery_TextCircle_img_angle;
                      index++;
                    };  // end if digit
                  };  // end char of string
                  char_Angle += normal_battery_TextCircle_unit_angle;
                  normal_battery_TextCircle_unit.setProperty(hmUI.prop.ANGLE, char_Angle);
                  normal_battery_TextCircle_unit.setProperty(hmUI.prop.VISIBLE, true);
                }  // end isFinite
                else {
                  normal_battery_TextCircle[0].setProperty(hmUI.prop.ANGLE, char_Angle);
                  normal_battery_TextCircle[0].setProperty(hmUI.prop.POS_X, 233 - normal_battery_TextCircle_error_img_width / 2);
                  normal_battery_TextCircle[0].setProperty(hmUI.prop.SRC, 'num_12.png');
                  normal_battery_TextCircle[0].setProperty(hmUI.prop.VISIBLE, true);
                };  // end else isFinite

              };

              console.log('update text circle battery_BATTERY');
              let idle_battery_circle_string = parseInt(valueBattery).toString();

              if (screenType == hmSetting.screen_type.AOD) {
                for (var i = 1; i < 3; i++) {  // hide all symbols
                  idle_battery_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                idle_battery_TextCircle_unit.setProperty(hmUI.prop.VISIBLE, false);
                let char_Angle = 1;
                if (valueBattery != null && valueBattery != undefined && isFinite(valueBattery) && idle_battery_circle_string.length > 0 && idle_battery_circle_string.length < 6) {  // display data if it was possible to get it
                  let idle_battery_TextCircle_img_angle = 0;
                  let idle_battery_TextCircle_dot_img_angle = 0;
                  let idle_battery_TextCircle_unit_angle = 0;
                  idle_battery_TextCircle_img_angle = toDegree(Math.atan2(idle_battery_TextCircle_img_width/2, 211));
                  idle_battery_TextCircle_unit_angle = toDegree(Math.atan2(idle_battery_TextCircle_unit_width/2, 211));
                  // alignment = CENTER_H
                  let idle_battery_TextCircle_angleOffset = idle_battery_TextCircle_img_angle * (idle_battery_circle_string.length - 1);
                  idle_battery_TextCircle_angleOffset = idle_battery_TextCircle_angleOffset + (idle_battery_TextCircle_img_angle + idle_battery_TextCircle_unit_angle + 0) / 2;
                  char_Angle -= idle_battery_TextCircle_angleOffset;
                  // alignment end
                  
                  let firstSymbol = true;
                  let index = 0;
                  for (let char of idle_battery_circle_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 3) break;
                    if (charCode >= 0 && charCode < 10) { 
                      if (!firstSymbol) char_Angle += idle_battery_TextCircle_img_angle;
                      firstSymbol = false;
                      idle_battery_TextCircle[index].setProperty(hmUI.prop.ANGLE, char_Angle);
                      idle_battery_TextCircle[index].setProperty(hmUI.prop.POS_X, 233 - idle_battery_TextCircle_img_width / 2);
                      idle_battery_TextCircle[index].setProperty(hmUI.prop.SRC, idle_battery_TextCircle_ASCIIARRAY[charCode]);
                      idle_battery_TextCircle[index].setProperty(hmUI.prop.VISIBLE, true);
                      char_Angle += idle_battery_TextCircle_img_angle;
                      index++;
                    };  // end if digit
                  };  // end char of string
                  char_Angle += idle_battery_TextCircle_unit_angle;
                  idle_battery_TextCircle_unit.setProperty(hmUI.prop.ANGLE, char_Angle);
                  idle_battery_TextCircle_unit.setProperty(hmUI.prop.VISIBLE, true);
                }  // end isFinite
                else {
                  idle_battery_TextCircle[0].setProperty(hmUI.prop.ANGLE, char_Angle);
                  idle_battery_TextCircle[0].setProperty(hmUI.prop.POS_X, 233 - idle_battery_TextCircle_error_img_width / 2);
                  idle_battery_TextCircle[0].setProperty(hmUI.prop.SRC, 'num_12.png');
                  idle_battery_TextCircle[0].setProperty(hmUI.prop.VISIBLE, true);
                };  // end else isFinite

              };

            };

            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                console.log('resume_call()');
                text_update();
                checkConnection();
                stopVibro();

              }),
              pause_call: (function () {
                console.log('pause_call()');
                stopVibro();

              }),
            });

                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}