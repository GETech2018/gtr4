﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        const logger = Logger.getLogger('watchface_SashaCX75');
        //end of ignored block

        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_battery_icon_img = ''
        let normal_battery_circle_scale = ''
        let normal_battery_TextCircle = new Array(5);
        let normal_battery_TextCircle_ASCIIARRAY = new Array(10);
        let normal_battery_TextCircle_img_width = 15;
        let normal_battery_TextCircle_img_height = 26;
        let normal_step_icon_img = ''
        let normal_step_circle_scale = ''
        let normal_step_target_TextCircle = new Array(5);
        let normal_step_target_TextCircle_ASCIIARRAY = new Array(10);
        let normal_step_target_TextCircle_img_width = 15;
        let normal_step_target_TextCircle_img_height = 26;
        let normal_analog_clock_time_pointer_hour = ''
        let normal_analog_clock_time_pointer_minute = ''
        let normal_analog_clock_time_pointer_second = ''
        let normal_system_disconnect_img = ''
        let idle_background_bg = ''
        let idle_battery_icon_img = ''
        let idle_battery_circle_scale = ''
        let idle_battery_TextCircle = new Array(5);
        let idle_battery_TextCircle_ASCIIARRAY = new Array(10);
        let idle_battery_TextCircle_img_width = 15;
        let idle_battery_TextCircle_img_height = 26;
        let idle_step_icon_img = ''
        let idle_step_circle_scale = ''
        let idle_step_target_TextCircle = new Array(5);
        let idle_step_target_TextCircle_ASCIIARRAY = new Array(10);
        let idle_step_target_TextCircle_img_width = 15;
        let idle_step_target_TextCircle_img_height = 26;
        let idle_analog_clock_time_pointer_hour = ''
        let idle_analog_clock_time_pointer_minute = ''
        let idle_analog_clock_time_pointer_second = ''
        let idle_system_disconnect_img = ''


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 466,
              h: 466,
              src: 'bg.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 422,
              y: 260,
              src: 'pwr (2).png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_battery_circle_scale = hmUI.createWidget(hmUI.widget.Circle_Scale, {
              // center_x: 233,
              // center_y: 233,
              // start_angle: 22,
              // end_angle: 98,
              // radius: 226,
              // line_width: 15,
              // line_cap: Rounded,
              // color: 0xFF00DB37,
              // mirror: False,
              // inversion: False,
              // type: hmUI.data_type.BATTERY,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            let screenType = hmSetting.getScreenType();
            normal_battery_circle_scale = hmUI.createWidget(hmUI.widget.ARC_PROGRESS, {
              center_x: 233,
              center_y: 233,
              start_angle: 22,
              end_angle: 98,
              radius: 219,
              line_width: 15,
              corner_flag: 0,
              color: 0xFF00DB37,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            
            const battery = hmSensor.createSensor(hmSensor.id.BATTERY);
            battery.addEventListener(hmSensor.event.CHANGE, function() {
              text_update();
              scale_call();
            });

            // normal_battery_text_circle_img = hmUI.createWidget(hmUI.widget.Text_Circle, {
              // circle_center_X: 233,
              // circle_center_Y: 233,
              // font_array: ["font_0.png","font_1.png","font_2.png","font_3.png","font_4.png","font_5.png","font_6.png","font_7.png","font_8.png","font_9.png"],
              // radius: 178,
              // angle: 59,
              // char_space_angle: 0,
              // zero: false,
              // reverse_direction: false,
              // unit_in_alignment: true,
              // vertical_alignment: BOTTOM,
              // horizontal_alignment: CENTER_H,
              // type: hmUI.data_type.BATTERY,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_battery_TextCircle_ASCIIARRAY[0] = 'font_0.png';  // set of images with numbers
            normal_battery_TextCircle_ASCIIARRAY[1] = 'font_1.png';  // set of images with numbers
            normal_battery_TextCircle_ASCIIARRAY[2] = 'font_2.png';  // set of images with numbers
            normal_battery_TextCircle_ASCIIARRAY[3] = 'font_3.png';  // set of images with numbers
            normal_battery_TextCircle_ASCIIARRAY[4] = 'font_4.png';  // set of images with numbers
            normal_battery_TextCircle_ASCIIARRAY[5] = 'font_5.png';  // set of images with numbers
            normal_battery_TextCircle_ASCIIARRAY[6] = 'font_6.png';  // set of images with numbers
            normal_battery_TextCircle_ASCIIARRAY[7] = 'font_7.png';  // set of images with numbers
            normal_battery_TextCircle_ASCIIARRAY[8] = 'font_8.png';  // set of images with numbers
            normal_battery_TextCircle_ASCIIARRAY[9] = 'font_9.png';  // set of images with numbers

            //start of ignored block
            for (let i = 0; i < 5; i++) {
              normal_battery_TextCircle[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 466,
                h: 466,
                center_x: 233,
                center_y: 233,
                pos_x: 233 - normal_battery_TextCircle_img_width / 2,
                pos_y: 233 - 204,
                src: 'font_0.png',
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
              normal_battery_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
            };
            //end of ignored block
            
            function toDegree (radian) {
              return radian * (180 / Math.PI);
            };

            normal_step_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 5,
              y: 175,
              src: 'st.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_step_circle_scale = hmUI.createWidget(hmUI.widget.Circle_Scale, {
              // center_x: 233,
              // center_y: 233,
              // start_angle: 200,
              // end_angle: 276,
              // radius: 226,
              // line_width: 15,
              // line_cap: Rounded,
              // color: 0xFFCC0000,
              // mirror: False,
              // inversion: False,
              // type: hmUI.data_type.STEP,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_step_circle_scale = hmUI.createWidget(hmUI.widget.ARC_PROGRESS, {
              center_x: 233,
              center_y: 233,
              start_angle: 200,
              end_angle: 276,
              radius: 219,
              line_width: 15,
              corner_flag: 0,
              color: 0xFFCC0000,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            
            const step = hmSensor.createSensor(hmSensor.id.STEP);
            step.addEventListener(hmSensor.event.CHANGE, function() {
              text_update();
              scale_call();
            });

            // normal_step_target_text_circle_img = hmUI.createWidget(hmUI.widget.Text_Circle, {
              // circle_center_X: 233,
              // circle_center_Y: 233,
              // font_array: ["font_0.png","font_1.png","font_2.png","font_3.png","font_4.png","font_5.png","font_6.png","font_7.png","font_8.png","font_9.png"],
              // radius: 205,
              // angle: -121,
              // char_space_angle: 0,
              // zero: false,
              // reverse_direction: true,
              // unit_in_alignment: true,
              // vertical_alignment: BOTTOM,
              // horizontal_alignment: CENTER_H,
              // type: hmUI.data_type.STEP_TARGET,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_step_target_TextCircle_ASCIIARRAY[0] = 'font_0.png';  // set of images with numbers
            normal_step_target_TextCircle_ASCIIARRAY[1] = 'font_1.png';  // set of images with numbers
            normal_step_target_TextCircle_ASCIIARRAY[2] = 'font_2.png';  // set of images with numbers
            normal_step_target_TextCircle_ASCIIARRAY[3] = 'font_3.png';  // set of images with numbers
            normal_step_target_TextCircle_ASCIIARRAY[4] = 'font_4.png';  // set of images with numbers
            normal_step_target_TextCircle_ASCIIARRAY[5] = 'font_5.png';  // set of images with numbers
            normal_step_target_TextCircle_ASCIIARRAY[6] = 'font_6.png';  // set of images with numbers
            normal_step_target_TextCircle_ASCIIARRAY[7] = 'font_7.png';  // set of images with numbers
            normal_step_target_TextCircle_ASCIIARRAY[8] = 'font_8.png';  // set of images with numbers
            normal_step_target_TextCircle_ASCIIARRAY[9] = 'font_9.png';  // set of images with numbers

            //start of ignored block
            for (let i = 0; i < 5; i++) {
              normal_step_target_TextCircle[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 466,
                h: 466,
                center_x: 233,
                center_y: 233,
                pos_x: 233 - normal_step_target_TextCircle_img_width / 2,
                pos_y: 233 + 179,
                src: 'font_0.png',
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
              normal_step_target_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
            };
            //end of ignored block

            normal_analog_clock_time_pointer_hour = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              hour_path: 'h14.png',
              hour_centerX: 233,
              hour_centerY: 233,
              hour_posX: 10,
              hour_posY: 134,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_minute = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              minute_path: 'm14.png',
              minute_centerX: 233,
              minute_centerY: 233,
              minute_posX: 14,
              minute_posY: 202,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_second = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              second_path: 's14.png',
              second_centerX: 233,
              second_centerY: 233,
              second_posX: 10,
              second_posY: 203,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 219,
              y: 219,
              src: 'BT3.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            idle_background_bg = hmUI.createWidget(hmUI.widget.FILL_RECT, {
              x: 0,
              y: 0,
              w: 466,
              h: 466,
              color: '0xFF000000',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_battery_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 422,
              y: 260,
              src: 'pwr (2).png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            // idle_battery_circle_scale = hmUI.createWidget(hmUI.widget.Circle_Scale, {
              // center_x: 233,
              // center_y: 233,
              // start_angle: 22,
              // end_angle: 98,
              // radius: 226,
              // line_width: 15,
              // line_cap: Rounded,
              // color: 0xFF00DB37,
              // mirror: False,
              // inversion: False,
              // type: hmUI.data_type.BATTERY,
              // show_level: hmUI.show_level.ONLY_AOD,
            // });

            idle_battery_circle_scale = hmUI.createWidget(hmUI.widget.ARC_PROGRESS, {
              center_x: 233,
              center_y: 233,
              start_angle: 22,
              end_angle: 98,
              radius: 219,
              line_width: 15,
              corner_flag: 0,
              color: 0xFF00DB37,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            // idle_battery_text_circle_img = hmUI.createWidget(hmUI.widget.Text_Circle, {
              // circle_center_X: 233,
              // circle_center_Y: 233,
              // font_array: ["font_0.png","font_1.png","font_2.png","font_3.png","font_4.png","font_5.png","font_6.png","font_7.png","font_8.png","font_9.png"],
              // radius: 178,
              // angle: 59,
              // char_space_angle: 0,
              // zero: false,
              // reverse_direction: false,
              // unit_in_alignment: true,
              // vertical_alignment: BOTTOM,
              // horizontal_alignment: CENTER_H,
              // type: hmUI.data_type.BATTERY,
              // show_level: hmUI.show_level.ONLY_AOD,
            // });

            idle_battery_TextCircle_ASCIIARRAY[0] = 'font_0.png';  // set of images with numbers
            idle_battery_TextCircle_ASCIIARRAY[1] = 'font_1.png';  // set of images with numbers
            idle_battery_TextCircle_ASCIIARRAY[2] = 'font_2.png';  // set of images with numbers
            idle_battery_TextCircle_ASCIIARRAY[3] = 'font_3.png';  // set of images with numbers
            idle_battery_TextCircle_ASCIIARRAY[4] = 'font_4.png';  // set of images with numbers
            idle_battery_TextCircle_ASCIIARRAY[5] = 'font_5.png';  // set of images with numbers
            idle_battery_TextCircle_ASCIIARRAY[6] = 'font_6.png';  // set of images with numbers
            idle_battery_TextCircle_ASCIIARRAY[7] = 'font_7.png';  // set of images with numbers
            idle_battery_TextCircle_ASCIIARRAY[8] = 'font_8.png';  // set of images with numbers
            idle_battery_TextCircle_ASCIIARRAY[9] = 'font_9.png';  // set of images with numbers

            //start of ignored block
            for (let i = 0; i < 5; i++) {
              idle_battery_TextCircle[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 466,
                h: 466,
                center_x: 233,
                center_y: 233,
                pos_x: 233 - idle_battery_TextCircle_img_width / 2,
                pos_y: 233 - 204,
                src: 'font_0.png',
                show_level: hmUI.show_level.ONLY_AOD,
              });
              idle_battery_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
            };
            //end of ignored block

            idle_step_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 5,
              y: 175,
              src: 'st.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            // idle_step_circle_scale = hmUI.createWidget(hmUI.widget.Circle_Scale, {
              // center_x: 233,
              // center_y: 233,
              // start_angle: 200,
              // end_angle: 276,
              // radius: 226,
              // line_width: 15,
              // line_cap: Rounded,
              // color: 0xFFCC0000,
              // mirror: False,
              // inversion: False,
              // type: hmUI.data_type.STEP,
              // show_level: hmUI.show_level.ONLY_AOD,
            // });

            idle_step_circle_scale = hmUI.createWidget(hmUI.widget.ARC_PROGRESS, {
              center_x: 233,
              center_y: 233,
              start_angle: 200,
              end_angle: 276,
              radius: 219,
              line_width: 15,
              corner_flag: 0,
              color: 0xFFCC0000,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            // idle_step_target_text_circle_img = hmUI.createWidget(hmUI.widget.Text_Circle, {
              // circle_center_X: 233,
              // circle_center_Y: 233,
              // font_array: ["font_0.png","font_1.png","font_2.png","font_3.png","font_4.png","font_5.png","font_6.png","font_7.png","font_8.png","font_9.png"],
              // radius: 205,
              // angle: -121,
              // char_space_angle: 0,
              // zero: false,
              // reverse_direction: true,
              // unit_in_alignment: true,
              // vertical_alignment: BOTTOM,
              // horizontal_alignment: CENTER_H,
              // type: hmUI.data_type.STEP_TARGET,
              // show_level: hmUI.show_level.ONLY_AOD,
            // });

            idle_step_target_TextCircle_ASCIIARRAY[0] = 'font_0.png';  // set of images with numbers
            idle_step_target_TextCircle_ASCIIARRAY[1] = 'font_1.png';  // set of images with numbers
            idle_step_target_TextCircle_ASCIIARRAY[2] = 'font_2.png';  // set of images with numbers
            idle_step_target_TextCircle_ASCIIARRAY[3] = 'font_3.png';  // set of images with numbers
            idle_step_target_TextCircle_ASCIIARRAY[4] = 'font_4.png';  // set of images with numbers
            idle_step_target_TextCircle_ASCIIARRAY[5] = 'font_5.png';  // set of images with numbers
            idle_step_target_TextCircle_ASCIIARRAY[6] = 'font_6.png';  // set of images with numbers
            idle_step_target_TextCircle_ASCIIARRAY[7] = 'font_7.png';  // set of images with numbers
            idle_step_target_TextCircle_ASCIIARRAY[8] = 'font_8.png';  // set of images with numbers
            idle_step_target_TextCircle_ASCIIARRAY[9] = 'font_9.png';  // set of images with numbers

            //start of ignored block
            for (let i = 0; i < 5; i++) {
              idle_step_target_TextCircle[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 466,
                h: 466,
                center_x: 233,
                center_y: 233,
                pos_x: 233 - idle_step_target_TextCircle_img_width / 2,
                pos_y: 233 + 179,
                src: 'font_0.png',
                show_level: hmUI.show_level.ONLY_AOD,
              });
              idle_step_target_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
            };
            //end of ignored block

            idle_analog_clock_time_pointer_hour = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              hour_path: 'h14.png',
              hour_centerX: 233,
              hour_centerY: 233,
              hour_posX: 10,
              hour_posY: 134,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_analog_clock_time_pointer_minute = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              minute_path: 'm14.png',
              minute_centerX: 233,
              minute_centerY: 233,
              minute_posX: 14,
              minute_posY: 202,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_analog_clock_time_pointer_second = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              second_path: 's14.png',
              second_centerX: 233,
              second_centerY: 233,
              second_posX: 10,
              second_posY: 203,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 219,
              y: 219,
              src: 'BT3.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            function text_update() {

              console.log('update text circle BATTERY');
              let valueBattery = battery.current;
              let normal_battery_circle_string = parseInt(valueBattery).toString();

              if (screenType != hmSetting.screen_type.AOD) {
                for (var i = 1; i < 5; i++) {  // hide all symbols
                  normal_battery_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                let char_Angle = 59;
                if (valueBattery != null && valueBattery != undefined && isFinite(valueBattery) && normal_battery_circle_string.length > 0 && normal_battery_circle_string.length < 6) {  // display data if it was possible to get it
                  let normal_battery_TextCircle_img_angle = 0;
                  let normal_battery_TextCircle_dot_img_angle = 0;
                  normal_battery_TextCircle_img_angle = toDegree(Math.atan2(normal_battery_TextCircle_img_width/2, 178));
                  // alignment = CENTER_H
                  let normal_battery_TextCircle_angleOffset = normal_battery_TextCircle_img_angle * (normal_battery_circle_string.length - 1);
                  char_Angle -= normal_battery_TextCircle_angleOffset;
                  // alignment end
                  
                  let firstSymbol = true;
                  let index = 0;
                  for (let char of normal_battery_circle_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 5) break;
                    if (charCode >= 0 && charCode < 10) { 
                      if (!firstSymbol) char_Angle += normal_battery_TextCircle_img_angle;
                      firstSymbol = false;
                      normal_battery_TextCircle[index].setProperty(hmUI.prop.ANGLE, char_Angle);
                      normal_battery_TextCircle[index].setProperty(hmUI.prop.POS_X, 233 - normal_battery_TextCircle_img_width / 2);
                      normal_battery_TextCircle[index].setProperty(hmUI.prop.SRC, normal_battery_TextCircle_ASCIIARRAY[charCode]);
                      normal_battery_TextCircle[index].setProperty(hmUI.prop.VISIBLE, true);
                      char_Angle += normal_battery_TextCircle_img_angle;
                      index++;
                    };  // end if digit
                  };  // end char of string
                }  // end isFinite

              };

              console.log('update text circle STEP');
              let targetStep = step.target;
              let normal_step_target_circle_string = parseInt(targetStep).toString();

              if (screenType != hmSetting.screen_type.AOD) {
                for (var i = 1; i < 5; i++) {  // hide all symbols
                  normal_step_target_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                let char_Angle = 59;
                if (targetStep != null && targetStep != undefined && isFinite(targetStep) && normal_step_target_circle_string.length > 0 && normal_step_target_circle_string.length < 6) {  // display data if it was possible to get it
                  let normal_step_target_TextCircle_img_angle = 0;
                  let normal_step_target_TextCircle_dot_img_angle = 0;
                  normal_step_target_TextCircle_img_angle = toDegree(Math.atan2(normal_step_target_TextCircle_img_width/2, 205));
                  // alignment = CENTER_H
                  let normal_step_target_TextCircle_angleOffset = normal_step_target_TextCircle_img_angle * (normal_step_target_circle_string.length - 1);
                  normal_step_target_TextCircle_angleOffset = -normal_step_target_TextCircle_angleOffset;
                  char_Angle -= normal_step_target_TextCircle_angleOffset;
                  // alignment end
                  
                  let firstSymbol = true;
                  let index = 0;
                  for (let char of normal_step_target_circle_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 5) break;
                    if (charCode >= 0 && charCode < 10) { 
                      if (!firstSymbol) char_Angle -= normal_step_target_TextCircle_img_angle;
                      firstSymbol = false;
                      normal_step_target_TextCircle[index].setProperty(hmUI.prop.ANGLE, char_Angle);
                      normal_step_target_TextCircle[index].setProperty(hmUI.prop.POS_X, 233 - normal_step_target_TextCircle_img_width / 2);
                      normal_step_target_TextCircle[index].setProperty(hmUI.prop.SRC, normal_step_target_TextCircle_ASCIIARRAY[charCode]);
                      normal_step_target_TextCircle[index].setProperty(hmUI.prop.VISIBLE, true);
                      char_Angle -= normal_step_target_TextCircle_img_angle;
                      index++;
                    };  // end if digit
                  };  // end char of string
                }  // end isFinite

              };

              console.log('update text circle BATTERY');
              let idle_battery_circle_string = parseInt(valueBattery).toString();

              if (screenType == hmSetting.screen_type.AOD) {
                for (var i = 1; i < 5; i++) {  // hide all symbols
                  idle_battery_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                let char_Angle = 59;
                if (valueBattery != null && valueBattery != undefined && isFinite(valueBattery) && idle_battery_circle_string.length > 0 && idle_battery_circle_string.length < 6) {  // display data if it was possible to get it
                  let idle_battery_TextCircle_img_angle = 0;
                  let idle_battery_TextCircle_dot_img_angle = 0;
                  idle_battery_TextCircle_img_angle = toDegree(Math.atan2(idle_battery_TextCircle_img_width/2, 178));
                  // alignment = CENTER_H
                  let idle_battery_TextCircle_angleOffset = idle_battery_TextCircle_img_angle * (idle_battery_circle_string.length - 1);
                  char_Angle -= idle_battery_TextCircle_angleOffset;
                  // alignment end
                  
                  let firstSymbol = true;
                  let index = 0;
                  for (let char of idle_battery_circle_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 5) break;
                    if (charCode >= 0 && charCode < 10) { 
                      if (!firstSymbol) char_Angle += idle_battery_TextCircle_img_angle;
                      firstSymbol = false;
                      idle_battery_TextCircle[index].setProperty(hmUI.prop.ANGLE, char_Angle);
                      idle_battery_TextCircle[index].setProperty(hmUI.prop.POS_X, 233 - idle_battery_TextCircle_img_width / 2);
                      idle_battery_TextCircle[index].setProperty(hmUI.prop.SRC, idle_battery_TextCircle_ASCIIARRAY[charCode]);
                      idle_battery_TextCircle[index].setProperty(hmUI.prop.VISIBLE, true);
                      char_Angle += idle_battery_TextCircle_img_angle;
                      index++;
                    };  // end if digit
                  };  // end char of string
                }  // end isFinite

              };

              console.log('update text circle STEP');
              let idle_step_target_circle_string = parseInt(targetStep).toString();

              if (screenType == hmSetting.screen_type.AOD) {
                for (var i = 1; i < 5; i++) {  // hide all symbols
                  idle_step_target_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                let char_Angle = 59;
                if (targetStep != null && targetStep != undefined && isFinite(targetStep) && idle_step_target_circle_string.length > 0 && idle_step_target_circle_string.length < 6) {  // display data if it was possible to get it
                  let idle_step_target_TextCircle_img_angle = 0;
                  let idle_step_target_TextCircle_dot_img_angle = 0;
                  idle_step_target_TextCircle_img_angle = toDegree(Math.atan2(idle_step_target_TextCircle_img_width/2, 205));
                  // alignment = CENTER_H
                  let idle_step_target_TextCircle_angleOffset = idle_step_target_TextCircle_img_angle * (idle_step_target_circle_string.length - 1);
                  idle_step_target_TextCircle_angleOffset = -idle_step_target_TextCircle_angleOffset;
                  char_Angle -= idle_step_target_TextCircle_angleOffset;
                  // alignment end
                  
                  let firstSymbol = true;
                  let index = 0;
                  for (let char of idle_step_target_circle_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 5) break;
                    if (charCode >= 0 && charCode < 10) { 
                      if (!firstSymbol) char_Angle -= idle_step_target_TextCircle_img_angle;
                      firstSymbol = false;
                      idle_step_target_TextCircle[index].setProperty(hmUI.prop.ANGLE, char_Angle);
                      idle_step_target_TextCircle[index].setProperty(hmUI.prop.POS_X, 233 - idle_step_target_TextCircle_img_width / 2);
                      idle_step_target_TextCircle[index].setProperty(hmUI.prop.SRC, idle_step_target_TextCircle_ASCIIARRAY[charCode]);
                      idle_step_target_TextCircle[index].setProperty(hmUI.prop.VISIBLE, true);
                      char_Angle -= idle_step_target_TextCircle_img_angle;
                      index++;
                    };  // end if digit
                  };  // end char of string
                }  // end isFinite

              };

            };

            function scale_call() {

                console.log('update scales BATTERY');
                
                let valueBattery = battery.current;
                let targetBattery = 100;
                let progressBattery = valueBattery/targetBattery;
                if (progressBattery > 1) progressBattery = 1;
                let progress_cs_normal_battery = progressBattery;

                if (screenType != hmSetting.screen_type.AOD) {

                  // normal_battery_circle_scale_circle_scale
                  let level = Math.round(progress_cs_normal_battery * 100);
                  if (normal_battery_circle_scale) {
                    normal_battery_circle_scale.setProperty(hmUI.prop.MORE, {                      
                      center_x: 233,
                      center_y: 233,
                      start_angle: 22,
                      end_angle: 98,
                      radius: 219,
                      line_width: 15,
                      corner_flag: 0,
                      color: 0xFF00DB37,
                      show_level: hmUI.show_level.ONLY_NORMAL,
                      level: level,
                    });
                  };
                };

                console.log('update scales STEP');
                
                let valueStep = step.current;
                let targetStep = step.target;
                let progressStep = valueStep/targetStep;
                if (progressStep > 1) progressStep = 1;
                let progress_cs_normal_step = progressStep;

                if (screenType != hmSetting.screen_type.AOD) {

                  // normal_step_circle_scale_circle_scale
                  let level = Math.round(progress_cs_normal_step * 100);
                  if (normal_step_circle_scale) {
                    normal_step_circle_scale.setProperty(hmUI.prop.MORE, {                      
                      center_x: 233,
                      center_y: 233,
                      start_angle: 200,
                      end_angle: 276,
                      radius: 219,
                      line_width: 15,
                      corner_flag: 0,
                      color: 0xFFCC0000,
                      show_level: hmUI.show_level.ONLY_NORMAL,
                      level: level,
                    });
                  };
                };

                console.log('update scales BATTERY');
                let progress_cs_idle_battery = progressBattery;

                if (screenType == hmSetting.screen_type.AOD) {

                  // idle_battery_circle_scale_circle_scale
                  let level = Math.round(progress_cs_idle_battery * 100);
                  if (idle_battery_circle_scale) {
                    idle_battery_circle_scale.setProperty(hmUI.prop.MORE, {                      
                      center_x: 233,
                      center_y: 233,
                      start_angle: 22,
                      end_angle: 98,
                      radius: 219,
                      line_width: 15,
                      corner_flag: 0,
                      color: 0xFF00DB37,
                      show_level: hmUI.show_level.ONLY_AOD,
                      level: level,
                    });
                  };
                };

                console.log('update scales STEP');
                let progress_cs_idle_step = progressStep;

                if (screenType == hmSetting.screen_type.AOD) {

                  // idle_step_circle_scale_circle_scale
                  let level = Math.round(progress_cs_idle_step * 100);
                  if (idle_step_circle_scale) {
                    idle_step_circle_scale.setProperty(hmUI.prop.MORE, {                      
                      center_x: 233,
                      center_y: 233,
                      start_angle: 200,
                      end_angle: 276,
                      radius: 219,
                      line_width: 15,
                      corner_flag: 0,
                      color: 0xFFCC0000,
                      show_level: hmUI.show_level.ONLY_AOD,
                      level: level,
                    });
                  };
                };

            };

            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                scale_call();
                text_update();
              }),
            });

                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}