﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.0.1
    ** Copyright © CashaCX75. All Rights Reserved
    */

    try {
    (()=>{
        //dynamic modify start

        
        let normal_background_bg = ''
        let normal_weather_image_progress_img_level = ''
        let normal_temperature_current_text_img = ''
        let normal_humidity_pointer_progress_img_pointer = ''
        let normal_heart_rate_text_text_img = ''
        let normal_battery_text_text_img = ''
        let normal_step_current_text_img = ''
        let normal_calorie_current_text_img = ''
        let normal_date_img_date_week_img = ''
        let normal_uvi_text_text_img = ''
        let normal_pai_weekly_text_img = ''
        let normal_date_img_date_day = ''
        let normal_date_img_date_month = ''
        let normal_date_img_date_year = ''
        let normal_digital_clock_img_time = ''
        let normal_system_disconnect_img = ''
        let normal_system_dnd_img = ''
        let normal_system_lock_img = ''
        let normal_system_clock_img = ''
        let idle_background_bg_img = ''
        let idle_digital_clock_img_time = ''


        //dynamic modify end
        const e = __$$hmAppManager$$__.currentApp;
        const o = e.current
          , {px: i} = (new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(e,o)),
        e.__globals__)
          , n = Logger.getLogger("watchface6");
        o.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            normal_background_bg = hmUI.createWidget(hmUI.widget.FILL_RECT, {
              x: 0,
              y: 0,
              w: 452,
              h: 452,
              color: '0xFF000000',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 212,
              y: 58,
              image_array: ["3.png","4.png","5.png","6.png","7.png","8.png","9.png","10.png","11.png","12.png","13.png","14.png","15.png","16.png","17.png","18.png","19.png","20.png","21.png","22.png","23.png","24.png","25.png","26.png","27.png","28.png","29.png","30.png","31.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 207,
              y: 108,
              font_array: ["32.png","33.png","34.png","35.png","36.png","37.png","38.png","39.png","40.png","41.png"],
              padding: false,
              h_space: 0,
              unit_sc: '44.png',
              unit_tc: '44.png',
              unit_en: '44.png',
              negative_image: '43.png',
              invalid_image: '42.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_humidity_pointer_progress_img_pointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
              src: '45.png',
              center_x: 233,
              center_y: 98,
              x: 19,
              y: 63,
              start_angle: -160,
              end_angle: 160,
              type: hmUI.data_type.HUMIDITY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 90,
              y: 115,
              font_array: ["32.png","33.png","34.png","35.png","36.png","37.png","38.png","39.png","40.png","41.png"],
              padding: false,
              h_space: 0,
              invalid_image: '46.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 323,
              y: 115,
              font_array: ["32.png","33.png","34.png","35.png","36.png","37.png","38.png","39.png","40.png","41.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 73,
              y: 334,
              font_array: ["32.png","33.png","34.png","35.png","36.png","37.png","38.png","39.png","40.png","41.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_calorie_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 315,
              y: 333,
              font_array: ["32.png","33.png","34.png","35.png","36.png","37.png","38.png","39.png","40.png","41.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 105,
              y: 149,
              week_en: ["47.png","48.png","49.png","50.png","51.png","52.png","53.png"],
              week_tc: ["47.png","48.png","49.png","50.png","51.png","52.png","53.png"],
              week_sc: ["47.png","48.png","49.png","50.png","51.png","52.png","53.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_uvi_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 54,
              y: 240,
              font_array: ["54.png","55.png","56.png","57.png","58.png","59.png","60.png","61.png","62.png","63.png"],
              padding: false,
              h_space: 0,
              invalid_image: '64.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.UVI,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_pai_weekly_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 381,
              y: 240,
              font_array: ["54.png","55.png","56.png","57.png","58.png","59.png","60.png","61.png","62.png","63.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.PAI_WEEKLY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 223,
              day_startY: 291,
              day_sc_array: ["54.png","55.png","56.png","57.png","58.png","59.png","60.png","61.png","62.png","63.png"],
              day_tc_array: ["54.png","55.png","56.png","57.png","58.png","59.png","60.png","61.png","62.png","63.png"],
              day_en_array: ["54.png","55.png","56.png","57.png","58.png","59.png","60.png","61.png","62.png","63.png"],
              day_zero: 1,
              day_space: 0,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_month = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 190,
              month_startY: 291,
              month_sc_array: ["54.png","55.png","56.png","57.png","58.png","59.png","60.png","61.png","62.png","63.png"],
              month_tc_array: ["54.png","55.png","56.png","57.png","58.png","59.png","60.png","61.png","62.png","63.png"],
              month_en_array: ["54.png","55.png","56.png","57.png","58.png","59.png","60.png","61.png","62.png","63.png"],
              month_zero: 1,
              month_space: 0,
              month_align: hmUI.align.CENTER_H,
              month_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_year = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              year_startX: 135,
              year_startY: 291,
              year_sc_array: ["54.png","55.png","56.png","57.png","58.png","59.png","60.png","61.png","62.png","63.png"],
              year_tc_array: ["54.png","55.png","56.png","57.png","58.png","59.png","60.png","61.png","62.png","63.png"],
              year_en_array: ["54.png","55.png","56.png","57.png","58.png","59.png","60.png","61.png","62.png","63.png"],
              year_zero: 1,
              year_space: 0,
              year_align: hmUI.align.CENTER_H,
              year_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 117,
              hour_startY: 202,
              hour_array: ["95.png","96.png","97.png","98.png","99.png","100.png","101.png","102.png","103.png","104.png"],
              hour_zero: 1,
              hour_space: 4,
              hour_align: hmUI.align.CENTER_H,

              minute_startX: 246,
              minute_startY: 202,
              minute_array: ["105.png","106.png","107.png","108.png","109.png","110.png","111.png","112.png","113.png","114.png"],
              minute_zero: 1,
              minute_space: 4,
              minute_follow: 0,
              minute_align: hmUI.align.CENTER_H,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 423,
              y: 114,
              src: '115.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_dnd_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 0,
              y: 114,
              src: '116.png',
              type: hmUI.system_status.DISTURB,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_lock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 0,
              y: 233,
              src: '117.png',
              type: hmUI.system_status.LOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 423,
              y: 233,
              src: '118.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            idle_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 466,
              h: 466,
              src: '119.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 114,
              hour_startY: 202,
              hour_array: ["95.png","96.png","97.png","98.png","99.png","100.png","101.png","102.png","103.png","104.png"],
              hour_zero: 1,
              hour_space: 4,
              hour_align: hmUI.align.CENTER_H,

              minute_startX: 260,
              minute_startY: 197,
              minute_array: ["105.png","106.png","107.png","108.png","109.png","110.png","111.png","112.png","113.png","114.png"],
              minute_zero: 1,
              minute_space: 4,
              minute_follow: 0,
              minute_align: hmUI.align.CENTER_H,

              show_level: hmUI.show_level.ONLY_AOD,
            });


                //dynamic modify end
            },
            onInit() {
                n.log("index page.js on init invoke")
            },
            build() {
                this.init_view(),
                n.log("index page.js on ready invoke")
            },
            onDestroy() {
                n.log("index page.js on destroy invoke")
            }
        })
    }
    )()
} catch (e) {
    console.log("Mini Program Error", e),
    e && e.stack && e.stack.split(/\n/).forEach((e=>console.log("error stack", e)))
}
