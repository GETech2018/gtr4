﻿
    /*
    ** Watch_Face_Editor tool
    ** watchface js version v1.0.1
    ** Copyright © CashaCX75. All Rights Reserved
    */

    try {

      (() => {

        var __$$app$$__ = __$$hmAppManager$$__.currentApp;
        var __$$module$$__ = __$$app$$__.current;
        //drink is a name,can modify
        var h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__), 'drink');

        'use strict';

        //dynamic modify start

        
        let normal_background_bg = ''
        let normal_digital_clock_img_time = ''
        let normal_frame_animation_1 = ''
        let idle_background_bg = ''
        let idle_digital_clock_img_time = ''
        let idle_stress_icon_img = ''
        let idle_calorie_icon_img = ''


        //dynamic modify end

        //not required
        const logger = DeviceRuntimeCore.HmLogger.getLogger("yeguang");

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({

          init_view() {

            //dynamic modify start
                    
            
            normal_background_bg = hmUI.createWidget(hmUI.widget.FILL_RECT, {
              x: 0,
              y: 0,
              w: 466,
              h: 466,
              color: '0xFF000000',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: -121,
              hour_startY: -95,
              hour_array: ["green_layer_Hr_0001.png","green_layer_Hr_0002.png","green_layer_Hr_0003.png","green_layer_Hr_0004.png","green_layer_Hr_0005.png","green_layer_Hr_0006.png","green_layer_Hr_0007.png","green_layer_Hr_0008.png","green_layer_Hr_0009.png","green_layer_Hr_0010.png"],
              hour_zero: 1,
              hour_space: -213,
              hour_align: hmUI.align.LEFT,

              minute_startX: 126,
              minute_startY: -95,
              minute_array: ["blue_layer_Min_0001.png","blue_layer_Min_0002.png","blue_layer_Min_0003.png","blue_layer_Min_0004.png","blue_layer_Min_0005.png","blue_layer_Min_0006.png","blue_layer_Min_0007.png","blue_layer_Min_0008.png","blue_layer_Min_0009.png","blue_layer_Min_0010.png"],
              minute_zero: 1,
              minute_space: -218,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_frame_animation_1 = hmUI.createWidget(hmUI.widget.IMG_ANIM, {
              x: 149,
              y: 135,
              anim_path: "animation",
              anim_ext: "png",
              anim_prefix: "Picture",
              anim_fps: 2,
              anim_size: 10,
              repeat_count: 0,
              anim_repeat: true,
              anim_status:hmUI.anim_status.START,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            idle_background_bg = hmUI.createWidget(hmUI.widget.FILL_RECT, {
              x: 0,
              y: 0,
              w: 466,
              h: 466,
              color: '0xFF000000',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: -118,
              hour_startY: -95,
              hour_array: ["green_layer_Hr_0001.png","green_layer_Hr_0002.png","green_layer_Hr_0003.png","green_layer_Hr_0004.png","green_layer_Hr_0005.png","green_layer_Hr_0006.png","green_layer_Hr_0007.png","green_layer_Hr_0008.png","green_layer_Hr_0009.png","green_layer_Hr_0010.png"],
              hour_zero: 1,
              hour_space: -205,
              hour_align: hmUI.align.LEFT,

              minute_startX: 120,
              minute_startY: -95,
              minute_array: ["blue_layer_Min_0001.png","blue_layer_Min_0002.png","blue_layer_Min_0003.png","blue_layer_Min_0004.png","blue_layer_Min_0005.png","blue_layer_Min_0006.png","blue_layer_Min_0007.png","blue_layer_Min_0008.png","blue_layer_Min_0009.png","blue_layer_Min_0010.png"],
              minute_zero: 1,
              minute_space: -203,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_stress_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 207,
              y: 446,
              src: 'Picturelogo237.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_calorie_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'AOB Overlay - 2.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                normal_frame_animation_1.setProperty(hmUI.prop.ANIM_STATUS,hmUI.anim_status.START);

              }),
              pause_call: (function () {
                normal_frame_animation_1.setProperty(hmUI.prop.ANIM_STATUS,hmUI.anim_status.STOP);

              }),
            });

            //dynamic modify end
          },

          onInit() {
            console.log('index page.js on init invoke')

            this.init_view()

          },

          onReady() {
            console.log('index page.js on ready invoke')
          },

          onShow() {
            console.log('index page.js on show invoke')
          },

          onHide() {
            console.log('index page.js on hide invoke')
          },

          onDestory() {
            console.log('index page.js on destory invoke')
          },
        });

      })()
    } catch (e) {
      console.log(e)
    }
  