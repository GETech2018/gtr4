    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        const logger = Logger.getLogger('watchface_SashaCX75');
        //end of ignored block

        //dynamic modify start

        
        let normal_background_bg = ''
        let normal_image_img = ''
        let normal_system_disconnect_img = ''
        let normal_system_clock_img = ''
        let normal_battery_text_text_img = ''
        let normal_sun_high_text_img = ''
        let normal_sun_low_text_img = ''
        let normal_temperature_high_text_img = ''
        let normal_temperature_high_separator_img = ''
        let normal_temperature_low_text_img = ''
        let normal_temperature_low_separator_img = ''
        let normal_temperature_current_text_img = ''
        let normal_weather_image_progress_img_level = ''
        let normal_date_img_date_week_img = ''
        let normal_date_img_date_month_img = ''
        let normal_date_img_date_day = ''
        let normal_heart_rate_text_text_img = ''
        let normal_digital_clock_img_time = ''
        let normal_digital_clock_img_time_AmPm = ''
        let normal_step_icon_img = ''
        let normal_step_current_text_img = ''
        let idle_background_bg = ''
        let idle_system_disconnect_img = ''
        let idle_system_clock_img = ''
        let idle_battery_text_text_img = ''
        let idle_date_img_date_week_img = ''
        let idle_date_img_date_month_img = ''
        let idle_date_img_date_day = ''
        let idle_digital_clock_img_time = ''
        let idle_digital_clock_img_time_AmPm = ''
        let normal_stopwatch_jumpable_img_click = ''
        let normal_countdown_jumpable_img_click = ''
        let normal_sunrise_jumpable_img_click = ''
        let normal_altimeter_jumpable_img_click = ''
        let normal_temperature_jumpable_img_click = ''
        let normal_heart_jumpable_img_click = ''
        let normal_step_jumpable_img_click = ''
        let normal_sleep_jumpable_img_click = ''
        let normal_alarm_jumpable_img_click = ''
        
        const curTime = hmSensor.createSensor(hmSensor.id.TIME);

        let btn_color = ''
        let colornumber = 0
        let totalcolors = 8
        
        //let minute_arraym =  ["dtn_y_1.png","dtn_y_2.png","dtn_y_3.png","dtn_y_4.png","dtn_y_5.png","dtn_y_6.png","dtn_y_7.png","dtn_y_8.png","dtn_y_9.png","dtn_y_10.png"]
			
		 function call_change_Hands() {

        colornumber = (colornumber + 1) % (totalcolors);

        switch (colornumber) {
          case 0:
            normal_digital_clock_img_time.setProperty(hmUI.prop.MORE, {

              minute_startX: 301,
              minute_startY: 165,
              minute_array: ["dtn_1.png","dtn_2.png","dtn_3.png","dtn_4.png","dtn_5.png","dtn_6.png","dtn_7.png","dtn_8.png","dtn_9.png","dtn_10.png"],
              minute_zero: 1,
              minute_space: 5,
              minute_follow: 0,
              minute_align: hmUI.align.CENTER_H,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            bot_circle_state_txt = 'Color 1';
            break;
          case 1:
            normal_digital_clock_img_time.setProperty(hmUI.prop.MORE, {

              minute_startX: 301,
              minute_startY: 165,
              minute_array: ["dtn_y_1.png","dtn_y_2.png","dtn_y_3.png","dtn_y_4.png","dtn_y_5.png","dtn_y_6.png","dtn_y_7.png","dtn_y_8.png","dtn_y_9.png","dtn_y_10.png"],
              minute_zero: 1,
              minute_space: 5,
              minute_follow: 0,
              minute_align: hmUI.align.CENTER_H,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            bot_circle_state_txt = 'Color 2';
            break;
            case 2:
              normal_digital_clock_img_time.setProperty(hmUI.prop.MORE, {
  
                minute_startX: 301,
                minute_startY: 165,
                minute_array: ["dtn_b_1.png","dtn_b_2.png","dtn_b_3.png","dtn_b_4.png","dtn_b_5.png","dtn_b_6.png","dtn_b_7.png","dtn_b_8.png","dtn_b_9.png","dtn_b_10.png"],
                minute_zero: 1,
                minute_space: 5,
                minute_follow: 0,
                minute_align: hmUI.align.CENTER_H,
  
 
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
     
               bot_circle_state_txt = 'Color 3';
              break;

              case 3:
                normal_digital_clock_img_time.setProperty(hmUI.prop.MORE, {

                  minute_startX: 301,
                  minute_startY: 165,
                  minute_array: ["dtn_o_1.png","dtn_o_2.png","dtn_o_3.png","dtn_o_4.png","dtn_o_5.png","dtn_o_6.png","dtn_o_7.png","dtn_o_8.png","dtn_o_9.png","dtn_o_10.png"],
                  minute_zero: 1,
                  minute_space: 5,
                  minute_follow: 0,
                  minute_align: hmUI.align.CENTER_H,
    
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });
    
                  bot_circle_state_txt = 'Color 4';
                  break;
							
              case 4:
                normal_digital_clock_img_time.setProperty(hmUI.prop.MORE, {

                  minute_startX: 301,
                  minute_startY: 165,
                  minute_array: ["dtn_c_1.png","dtn_c_2.png","dtn_c_3.png","dtn_c_4.png","dtn_c_5.png","dtn_c_6.png","dtn_c_7.png","dtn_c_8.png","dtn_c_9.png","dtn_c_10.png"],
                  minute_zero: 1,
                  minute_space: 5,
                  minute_follow: 0,
                  minute_align: hmUI.align.CENTER_H,
    
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });
    
                  bot_circle_state_txt = 'Color 5';
                  break;
							
              case 5:
                normal_digital_clock_img_time.setProperty(hmUI.prop.MORE, {

                  minute_startX: 301,
                  minute_startY: 165,
                  minute_array: ["dtn_r_1.png","dtn_r_2.png","dtn_r_3.png","dtn_r_4.png","dtn_r_5.png","dtn_r_6.png","dtn_r_7.png","dtn_r_8.png","dtn_r_9.png","dtn_r_10.png"],
                  minute_zero: 1,
                  minute_space: 5,
                  minute_follow: 0,
                  minute_align: hmUI.align.CENTER_H,
    
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });
    
                  bot_circle_state_txt = 'Color 6';
				break;
							
              case 6:
                normal_digital_clock_img_time.setProperty(hmUI.prop.MORE, {

                  minute_startX: 301,
                  minute_startY: 165,
                  minute_array: ["dtn_p_1.png","dtn_p_2.png","dtn_p_3.png","dtn_p_4.png","dtn_p_5.png","dtn_p_6.png","dtn_p_7.png","dtn_p_8.png","dtn_p_9.png","dtn_p_10.png"],
                  minute_zero: 1,
                  minute_space: 5,
                  minute_follow: 0,
                  minute_align: hmUI.align.CENTER_H,
    
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });
    
                  bot_circle_state_txt = 'Color 7';
				break;
							
              case 7:
                normal_digital_clock_img_time.setProperty(hmUI.prop.MORE, {

                  minute_startX: 301,
                  minute_startY: 165,
                  minute_array: ["dtn_g_1.png","dtn_g_2.png","dtn_g_3.png","dtn_g_4.png","dtn_g_5.png","dtn_g_6.png","dtn_g_7.png","dtn_g_8.png","dtn_g_9.png","dtn_g_10.png"],
                  minute_zero: 1,
                  minute_space: 5,
                  minute_follow: 0,
                  minute_align: hmUI.align.CENTER_H,
    
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });
    
                  bot_circle_state_txt = 'Color 8';
				
                    break;
				
              default:
            break;
          }
          
          hmUI.showToast({ text: bot_circle_state_txt });
        }	

   function call_change_Hours() {

          colornumber = (colornumber + 1) % (totalcolors);
  
          switch (colornumber) {
            case 0:
              normal_digital_clock_img_time.setProperty(hmUI.prop.MORE, {
                hour_startX: 21,
                hour_startY: 165,
                hour_array: ["dtn_1.png","dtn_2.png","dtn_3.png","dtn_4.png","dtn_5.png","dtn_6.png","dtn_7.png","dtn_8.png","dtn_9.png","dtn_10.png"],
                hour_zero: 1,
                hour_space: 5,
                hour_align: hmUI.align.CENTER_H,
  
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
           
              bot_circle_state_txt = 'Color 1';
              break;
              case 1:
                normal_digital_clock_img_time.setProperty(hmUI.prop.MORE, {
                  hour_startX: 21,
                  hour_startY: 165,
                  hour_array: ["dtn_y_1.png","dtn_y_2.png","dtn_y_3.png","dtn_y_4.png","dtn_y_5.png","dtn_y_6.png","dtn_y_7.png","dtn_y_8.png","dtn_y_9.png","dtn_y_10.png"],
                  hour_zero: 1,
                  hour_space: 5,
                  hour_align: hmUI.align.CENTER_H,

                  show_level: hmUI.show_level.ONLY_NORMAL,
                });
       
                bot_circle_state_txt = 'Color 2';
                break;
              case 2:
                normal_digital_clock_img_time.setProperty(hmUI.prop.MORE, {
                  hour_startX: 21,
                  hour_startY: 165,
                  hour_array: ["dtn_b_1.png","dtn_b_2.png","dtn_b_3.png","dtn_b_4.png","dtn_b_5.png","dtn_b_6.png","dtn_b_7.png","dtn_b_8.png","dtn_b_9.png","dtn_b_10.png"],
                  hour_zero: 1,
                  hour_space: 5,
                  hour_align: hmUI.align.CENTER_H,
    
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });
    
                bot_circle_state_txt = 'Color 3';
                break;
              case 3:
                  normal_digital_clock_img_time.setProperty(hmUI.prop.MORE, {
                    hour_startX: 21,
                    hour_startY: 165,
                    hour_array: ["dtn_o_1.png","dtn_o_2.png","dtn_o_3.png","dtn_o_4.png","dtn_o_5.png","dtn_o_6.png","dtn_o_7.png","dtn_o_8.png","dtn_o_9.png","dtn_o_10.png"],
                    hour_zero: 1,
                    hour_space: 5,
                    hour_align: hmUI.align.CENTER_H,
      
                    show_level: hmUI.show_level.ONLY_NORMAL,
                  });
      
                bot_circle_state_txt = 'Color 4';
				break;
              case 4:
                  normal_digital_clock_img_time.setProperty(hmUI.prop.MORE, {
                    hour_startX: 21,
                    hour_startY: 165,
                    hour_array: ["dtn_c_1.png","dtn_c_2.png","dtn_c_3.png","dtn_c_4.png","dtn_c_5.png","dtn_c_6.png","dtn_c_7.png","dtn_c_8.png","dtn_c_9.png","dtn_c_10.png"],
                    hour_zero: 1,
                    hour_space: 5,
                    hour_align: hmUI.align.CENTER_H,
      
                    show_level: hmUI.show_level.ONLY_NORMAL,
                  });
      
                  bot_circle_state_txt = 'Color 5';
				break;				  				
              case 5:
                  normal_digital_clock_img_time.setProperty(hmUI.prop.MORE, {
                    hour_startX: 21,
                    hour_startY: 165,
                    hour_array: ["dtn_r_1.png","dtn_r_2.png","dtn_r_3.png","dtn_r_4.png","dtn_r_5.png","dtn_r_6.png","dtn_r_7.png","dtn_r_8.png","dtn_r_9.png","dtn_r_10.png"],
                    hour_zero: 1,
                    hour_space: 5,
                    hour_follow: 0,
                    hour_align: hmUI.align.CENTER_H,
    
                   show_level: hmUI.show_level.ONLY_NORMAL,
                 }); 
				  
                  bot_circle_state_txt = 'Color 6';
				break;							
              case 6:
                 normal_digital_clock_img_time.setProperty(hmUI.prop.MORE, {
                   hour_startX: 21,
                   hour_startY: 165,
                   hour_array: ["dtn_p_1.png","dtn_p_2.png","dtn_p_3.png","dtn_p_4.png","dtn_p_5.png","dtn_r_p6.png","dtn_p_7.png","dtn_p_8.png","dtn_p_9.png","dtn_p_10.png"],
                   hour_zero: 1,
                   hour_space: 5,
                   hour_follow: 0,
                   hour_align: hmUI.align.CENTER_H,
    
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });
    
                  bot_circle_state_txt = 'Color 7';
				break;
							
              case 7:
                 normal_digital_clock_img_time.setProperty(hmUI.prop.MORE, {
                   hour_startX: 21,
                   hour_startY: 165,
                   hour_array: ["dtn_g_1.png","dtn_g_2.png","dtn_g_3.png","dtn_g_4.png","dtn_g_5.png","dtn_g_6.png","dtn_g_7.png","dtn_g_8.png","dtn_g_9.png","dtn_g_10.png"],
                   hour_zero: 1,
                   hour_space: 5,
                   hour_follow: 0,
                   hour_align: hmUI.align.CENTER_H,
    
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });
    
                  bot_circle_state_txt = 'Color 8';
				  
                    break;
  
                default:
              break;
            }
            
            hmUI.showToast({ text: bot_circle_state_txt });
          }

          let delay_Timer = null;
          let clicks = 0;
          let clicksDelay = 400;       // задержка между кликами в мс 
  
        //--------------------- обработка множественных кликов (тапов) 1, 2, 3, ...  ---------------------	
   
        function checkClicks() {
  
          switch(clicks) {
            case 1:
              call_change_Hands();
           break;
            case 2:
              call_change_Hours(); // функции на двойной клик
           break;
          //  case 3:
          //    click_bot_ssmoth_Switcher() ;// функции на тройной клик
          // break;
           // case 4:
             // функции на 4-ной клик
           //break;
            default:
           break;
         }
          
         timer.stopTimer(delay_Timer);
         clicks = 0;
  
        }
		
		    function getClick() {		
    
          clicks++;
          if(delay_Timer) timer.stopTimer(delay_Timer);
          delay_Timer = timer.createTimer(clicksDelay, 0, checkClicks, {});
    
       }
        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            normal_background_bg = hmUI.createWidget(hmUI.widget.FILL_RECT, {
              x: 0,
              y: 0,
              w: 466,
              h: 466,
              color: '0xFF000000',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_image_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: '0001.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 188,
              y: 16,
              src: '0041.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 345,
              y: 306,
              src: '0028.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 55,
              y: 335,
              font_array: ["0065.png","0066.png","0067.png","0068.png","0069.png","0070.png","0071.png","0072.png","0073.png","0074.png"],
              padding: false,
              h_space: -1,
              unit_sc: '0027.png',
              unit_tc: '0027.png',
              unit_en: '0027.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sun_high_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 52,
              y: 86,
              font_array: ["0002.png","0003.png","0004.png","0005.png","0006.png","0007.png","0008.png","0009.png","0010.png","0011.png"],
              padding: false,
              h_space: 0,
              dot_image: '0040.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.SUN_RISE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sun_low_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 306,
              y: 86,
              font_array: ["0002.png","0003.png","0004.png","0005.png","0006.png","0007.png","0008.png","0009.png","0010.png","0011.png"],
              padding: false,
              h_space: 0,
              dot_image: '0040.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.SUN_SET,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_high_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 364,
              y: 129,
              font_array: ["0002.png","0003.png","0004.png","0005.png","0006.png","0007.png","0008.png","0009.png","0010.png","0011.png"],
              padding: false,
              h_space: 0,
              unit_sc: '0051.png',
              unit_tc: '0051.png',
              unit_en: '0051.png',
              negative_image: '0012.png',
              invalid_image: '0052.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_HIGH,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_high_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 318,
              y: 127,
              src: '0024.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_low_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 89,
              y: 129,
              font_array: ["0002.png","0003.png","0004.png","0005.png","0006.png","0007.png","0008.png","0009.png","0010.png","0011.png"],
              padding: false,
              h_space: 0,
              unit_sc: '0051.png',
              unit_tc: '0051.png',
              unit_en: '0051.png',
              negative_image: '0012.png',
              invalid_image: '0052.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_LOW,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_low_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 47,
              y: 127,
              src: '0023.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 193,
              y: 124,
              font_array: ["0065.png","0066.png","0067.png","0068.png","0069.png","0070.png","0071.png","0072.png","0073.png","0074.png"],
              padding: false,
              h_space: 0,
              unit_sc: '0051.png',
              unit_tc: '0051.png',
              unit_en: '0051.png',
              negative_image: '0042.png',
              invalid_image: '0052.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 201,
              y: 51,
              image_array: ["0077.png","0078.png","0079.png","0080.png","0081.png","0082.png","0083.png","0084.png","0085.png","0086.png","0087.png","0088.png","0089.png","0090.png","0091.png","0092.png","0093.png","0094.png","0095.png","0096.png","0097.png","0098.png","0099.png","0100.png","0101.png","0102.png","0103.png","0104.png","0105.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 196,
              y: 179,
              week_en: ["0043.png","0044.png","0045.png","0046.png","0047.png","0048.png","0049.png"],
              week_tc: ["0043.png","0044.png","0045.png","0046.png","0047.png","0048.png","0049.png"],
              week_sc: ["0043.png","0044.png","0045.png","0046.png","0047.png","0048.png","0049.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_month_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 195,
              month_startY: 269,
              month_sc_array: ["0053.png","0054.png","0055.png","0056.png","0057.png","0058.png","0059.png","0060.png","0061.png","0062.png","0063.png","0064.png"],
              month_tc_array: ["0053.png","0054.png","0055.png","0056.png","0057.png","0058.png","0059.png","0060.png","0061.png","0062.png","0063.png","0064.png"],
              month_en_array: ["0053.png","0054.png","0055.png","0056.png","0057.png","0058.png","0059.png","0060.png","0061.png","0062.png","0063.png","0064.png"],
              month_is_character: true ,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 196,
              day_startY: 218,
              day_sc_array: ["0013.png","0014.png","0015.png","0016.png","0017.png","0018.png","0019.png","0020.png","0021.png","0022.png"],
              day_tc_array: ["0013.png","0014.png","0015.png","0016.png","0017.png","0018.png","0019.png","0020.png","0021.png","0022.png"],
              day_en_array: ["0013.png","0014.png","0015.png","0016.png","0017.png","0018.png","0019.png","0020.png","0021.png","0022.png"],
              day_zero: 0,
              day_space: 2,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 192,
              y: 354,
              font_array: ["0065.png","0066.png","0067.png","0068.png","0069.png","0070.png","0071.png","0072.png","0073.png","0074.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 21,
              hour_startY: 165,
              hour_array: ["dtn_1.png","dtn_2.png","dtn_3.png","dtn_4.png","dtn_5.png","dtn_6.png","dtn_7.png","dtn_8.png","dtn_9.png","dtn_10.png"],
              hour_zero: 1,
              hour_space: 5,
              hour_angle: 0,
              hour_align: hmUI.align.CENTER_H,

              minute_startX: 301,
              minute_startY: 165,
              minute_array: ["dtn_1.png","dtn_2.png","dtn_3.png","dtn_4.png","dtn_5.png","dtn_6.png","dtn_7.png","dtn_8.png","dtn_9.png","dtn_10.png"],
              minute_zero: 1,
              minute_space: 5,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.CENTER_H,

              second_startX: 338,
              second_startY: 335,
              second_array: ["0013.png","0014.png","0015.png","0016.png","0017.png","0018.png","0019.png","0020.png","0021.png","0022.png"],
              second_zero: 1,
              second_space: 0,
              second_angle: 0,
              second_follow: 0,
              second_align: hmUI.align.CENTER_H,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time_AmPm = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              am_x: 358,
              am_y: 372,
              am_sc_path: '0025.png',
              am_en_path: '0025.png',
              pm_x: 358,
              pm_y: 372,
              pm_sc_path: '0026.png',
              pm_en_path: '0026.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 3,
              y: 153,
              src: '0050.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 166,
              y: 423,
              font_array: ["0065.png","0066.png","0067.png","0068.png","0069.png","0070.png","0071.png","0072.png","0073.png","0074.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            idle_background_bg = hmUI.createWidget(hmUI.widget.FILL_RECT, {
              x: 0,
              y: 0,
              w: 466,
              h: 466,
              color: '0xFF000000',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 188,
              y: 38,
              src: '0041.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 359,
              y: 287,
              src: '0028.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 194,
              y: 406,
              font_array: ["0065.png","0066.png","0067.png","0068.png","0069.png","0070.png","0071.png","0072.png","0073.png","0074.png"],
              padding: false,
              h_space: -1,
              unit_sc: '0027.png',
              unit_tc: '0027.png',
              unit_en: '0027.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 61,
              y: 195,
              week_en: ["0043.png","0044.png","0045.png","0046.png","0047.png","0048.png","0049.png"],
              week_tc: ["0043.png","0044.png","0045.png","0046.png","0047.png","0048.png","0049.png"],
              week_sc: ["0043.png","0044.png","0045.png","0046.png","0047.png","0048.png","0049.png"],
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_month_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 60,
              month_startY: 259,
              month_sc_array: ["0053.png","0054.png","0055.png","0056.png","0057.png","0058.png","0059.png","0060.png","0061.png","0062.png","0063.png","0064.png"],
              month_tc_array: ["0053.png","0054.png","0055.png","0056.png","0057.png","0058.png","0059.png","0060.png","0061.png","0062.png","0063.png","0064.png"],
              month_en_array: ["0053.png","0054.png","0055.png","0056.png","0057.png","0058.png","0059.png","0060.png","0061.png","0062.png","0063.png","0064.png"],
              month_is_character: true ,
              show_level: hmUI.show_level.ONLY_AOD,
            });
				
             btn_color = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 182, //x кнопки
              y: 175, //y кнопки
              text: '',
              w: 100, //ширина кнопки
              h: 100, //высота кнопки
              normal_src: '0_Empty.png',
              press_src: '0_Empty.png',
              click_func: () => {
                getClick();    //имя вызываемой функции
                vibro(2);
              },
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            btn_color.setProperty(hmUI.prop.VISIBLE, true);
				
            idle_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 71,
              day_startY: 225,
              day_sc_array: ["0065.png","0066.png","0067.png","0068.png","0069.png","0070.png","0071.png","0072.png","0073.png","0074.png"],
              day_tc_array: ["0065.png","0066.png","0067.png","0068.png","0069.png","0070.png","0071.png","0072.png","0073.png","0074.png"],
              day_en_array: ["0065.png","0066.png","0067.png","0068.png","0069.png","0070.png","0071.png","0072.png","0073.png","0074.png"],
              day_zero: 1,
              day_space: 2,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 191,
              hour_startY: 190,
              hour_array: ["3.png","4.png","5.png","6.png","7.png","8.png","9.png","10.png","11.png","12.png"],
              hour_zero: 1,
              hour_space: 5,
              hour_angle: 0,
              hour_unit_sc: '2.png',
              hour_unit_tc: '2.png',
              hour_unit_en: '2.png',
              hour_align: hmUI.align.CENTER_H,

              minute_startX: 290,
              minute_startY: 165,
              minute_array: ["3.png","4.png","5.png","6.png","7.png","8.png","9.png","10.png","11.png","12.png"],
              minute_zero: 1,
              minute_space: 5,
              minute_angle: 0,
              minute_follow: 1,
              minute_align: hmUI.align.CENTER_H,

              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time_AmPm = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              am_x: 226,
              am_y: 288,
              am_sc_path: '0025.png',
              am_en_path: '0025.png',
              pm_x: 226,
              pm_y: 288,
              pm_sc_path: '0026.png',
              pm_en_path: '0026.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });
            
            // disconnectAlert = hmUI.createWidget(hmUI.widget.DisconnectAlert, {
              // disconneсnt_vibrate_type: 0,
              // disconneсnt_toast_text: Disconnected,
              // conneсnt_vibrate_type: 0,
              // conneсnt_toast_text: Connected,
            // });

            // vibration when connecting or disconnecting

            function checkConnection() {
              hmBle.removeListener;
              hmBle.addListener(function (status) {
                if(!status) {
                  hmUI.showToast({text: "Disconnected"});
                  vibro(0);
                }
                if(status) {
                  hmUI.showToast({text: "Connected"});
                  vibro(0);
                }
              });
            }

            // end vibration when connecting or disconnecting
            // vibrate function

            const vibrate = hmSensor.createSensor(hmSensor.id.VIBRATE);
            let timer_StopVibrate = null;


            function vibro(scene = 25) {
              let stopDelay = 50;
              stopVibro();
              vibrate.stop();
              vibrate.scene = scene;
              if(scene < 23 || scene > 25) stopDelay = 1300;
              vibrate.start();
              timer_StopVibrate = timer.createTimer(stopDelay, 3000, stopVibro, {});
            }

            function stopVibro(){
              vibrate.stop();
              if(timer_StopVibrate) timer.stopTimer(timer_StopVibrate);
            }

            // end vibrate function

            normal_stopwatch_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 0,
              y: 165,
              w: 158,
              h: 155,
              type: hmUI.data_type.STOP_WATCH,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_countdown_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 312,
              y: 165,
              w: 147,
              h: 155,
              type: hmUI.data_type.COUNT_DOWN,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sunrise_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 32,
              y: 41,
              w: 119,
              h: 119,
              type: hmUI.data_type.SUN_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_altimeter_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 315,
              y: 40,
              w: 119,
              h: 119,
              type: hmUI.data_type.ALTIMETER,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 163,
              y: 59,
              w: 143,
              h: 100,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 165,
              y: 295,
              w: 137,
              h: 85,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 162,
              y: 387,
              w: 141,
              h: 96,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sleep_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 44,
              y: 329,
              w: 100,
              h: 100,
              type: hmUI.data_type.SLEEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_alarm_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 326,
              y: 330,
              w: 100,
              h: 100,
              type: hmUI.data_type.ALARM_CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                checkConnection();
                stopVibro();

              }),
              pause_call: (function () {
                stopVibro();

              }),
            });

                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}