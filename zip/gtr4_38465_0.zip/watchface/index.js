﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        const logger = Logger.getLogger('watchface_SashaCX75');
        //end of ignored block

        //dynamic modify start

        
        let editBg = ''
        let normal_image_img = ''
        let normal_frame_animation_1 = ''
        let normal_digital_clock_img_time = ''
        let normal_system_lock_img = ''
        let normal_system_disconnect_img = ''
        let normal_system_clock_img = ''
        let normal_analog_clock_time_pointer_second = ''
        let normal_battery_text_text_img = ''
        let normal_heart_rate_text_text_img = ''
        let normal_step_current_text_img = ''
        let normal_distance_text_text_img = ''
        let normal_temperature_current_text_img = ''
        let normal_weather_image_progress_img_level = ''
        let normal_date_img_date_week_img = ''
        let normal_date_img_date_month_img = ''
        let normal_date_img_date_day = ''
        let idle_background_bg = ''
        let idle_image_img = ''
        let idle_digital_clock_img_time = ''
        let idle_system_lock_img = ''
        let idle_system_disconnect_img = ''
        let idle_system_clock_img = ''
        let idle_analog_clock_time_pointer_second = ''
        let idle_battery_text_text_img = ''
        let idle_heart_rate_text_text_img = ''
        let idle_step_current_text_img = ''
        let idle_distance_text_text_img = ''
        let idle_temperature_current_text_img = ''
        let idle_weather_image_progress_img_level = ''
        let idle_date_img_date_week_img = ''
        let idle_date_img_date_month_img = ''
        let idle_date_img_date_day = ''
        let image_top_img = ''
        let Button_1 = ''
        let Button_2 = ''
        let Button_3 = ''
        let Button_4 = ''
        let Button_5 = ''
        let Button_6 = ''
        let Button_7 = ''
        let Button_8 = ''


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            console.log('Watch_Face.ScreenNormal');
            editBg = hmUI.createWidget(hmUI.widget.WATCHFACE_EDIT_BG, {
              edit_id: 1002,
              x: 0,
              y: 0,
              // w: 466,
              // h: 466,
              // AOD_show: False,
              bg_config: [
                { id: 1, preview: 'bg_edit_1_preview.png', path: 'bg_0.png' },
                { id: 2, preview: 'bg_edit_2_preview.png', path: 'bg_1.png' },
                { id: 3, preview: 'bg_edit_3_preview.png', path: 'bg_2.png' },
                { id: 4, preview: 'bg_edit_4_preview.png', path: 'bg_3.png' },
                { id: 5, preview: 'bg_edit_5_preview.png', path: 'bg_4.png' },
                { id: 6, preview: 'bg_edit_6_preview.png', path: 'bg_5.png' },
                { id: 7, preview: 'bg_edit_7_preview.png', path: 'bg_6.png' },
              ],
              count: 7,
              default_id: 1,
              fg: '.png',
              tips_bg: 'option.png',
              tips_x: 326,
              tips_y: 214,
              show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_EDIT,
            });

            normal_image_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'image_bg.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_frame_animation_1 = hmUI.createWidget(hmUI.widget.IMG_ANIM, {
              x: 181,
              y: 88,
              anim_path: "animation",
              anim_ext: "png",
              anim_prefix: "anim",
              anim_fps: 10,
              anim_size: 30,
              repeat_count: 0,
              anim_repeat: true,
              anim_status:hmUI.anim_status.START,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 47,
              hour_startY: 161,
              hour_array: ["time_0.png","time_1.png","time_2.png","time_3.png","time_4.png","time_5.png","time_6.png","time_7.png","time_8.png","time_9.png"],
              hour_zero: 1,
              hour_space: 0,
              hour_angle: 0,
              hour_unit_sc: 'pointer_0.png',
              hour_unit_tc: 'pointer_0.png',
              hour_unit_en: 'pointer_0.png',
              hour_align: hmUI.align.LEFT,

              minute_startX: 179,
              minute_startY: 161,
              minute_array: ["time_0.png","time_1.png","time_2.png","time_3.png","time_4.png","time_5.png","time_6.png","time_7.png","time_8.png","time_9.png"],
              minute_zero: 1,
              minute_space: 0,
              minute_angle: 0,
              minute_follow: 0,
              minute_unit_sc: 'pointer_0.png',
              minute_unit_tc: 'pointer_0.png',
              minute_unit_en: 'pointer_0.png',
              minute_align: hmUI.align.LEFT,

              second_startX: 311,
              second_startY: 161,
              second_array: ["time_0.png","time_1.png","time_2.png","time_3.png","time_4.png","time_5.png","time_6.png","time_7.png","time_8.png","time_9.png"],
              second_zero: 1,
              second_space: 0,
              second_angle: 0,
              second_follow: 0,
              second_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_lock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 181,
              y: 309,
              src: 'lock.png',
              type: hmUI.system_status.LOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 181,
              y: 337,
              src: 'bt_off.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 179,
              y: 364,
              src: 'alarm.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_second = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              second_path: 'second.png',
              second_centerX: 233,
              second_centerY: 233,
              second_posX: 212,
              second_posY: 212,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 105,
              y: 90,
              font_array: ["act_0.png","act_1.png","act_2.png","act_3.png","act_4.png","act_5.png","act_6.png","act_7.png","act_8.png","act_9.png"],
              padding: false,
              h_space: 1,
              unit_sc: 'percent.png',
              unit_tc: 'percent.png',
              unit_en: 'percent.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 299,
              y: 90,
              font_array: ["act_0.png","act_1.png","act_2.png","act_3.png","act_4.png","act_5.png","act_6.png","act_7.png","act_8.png","act_9.png"],
              padding: false,
              h_space: 1,
              invalid_image: 'dot_0.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 85,
              y: 344,
              font_array: ["act_0.png","act_1.png","act_2.png","act_3.png","act_4.png","act_5.png","act_6.png","act_7.png","act_8.png","act_9.png"],
              padding: false,
              h_space: 2,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_distance_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 293,
              y: 344,
              font_array: ["act_0.png","act_1.png","act_2.png","act_3.png","act_4.png","act_5.png","act_6.png","act_7.png","act_8.png","act_9.png"],
              padding: false,
              h_space: 2,
              unit_sc: 'km.png',
              unit_tc: 'km.png',
              unit_en: 'km.png',
              imperial_unit_sc: 'ml.png',
              imperial_unit_tc: 'ml.png',
              imperial_unit_en: 'ml.png',
              dot_image: 'pointer_1.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.DISTANCE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 213,
              y: 37,
              font_array: ["small_0.png","small_1.png","small_2.png","small_3.png","small_4.png","small_5.png","small_6.png","small_7.png","small_8.png","small_9.png"],
              padding: false,
              h_space: 1,
              unit_sc: 'pointer_3.png',
              unit_tc: 'pointer_3.png',
              unit_en: 'pointer_3.png',
              negative_image: 'pointer_2.png',
              invalid_image: 'dot_1.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 115,
              y: 58,
              image_array: ["weather_1.png","weather_2.png","weather_3.png","weather_4.png","weather_5.png","weather_6.png","weather_7.png","weather_8.png","weather_9.png","weather_10.png","weather_11.png","weather_12.png","weather_13.png","weather_14.png","weather_15.png","weather_16.png","weather_17.png","weather_18.png","weather_19.png","weather_20.png","weather_21.png","weather_22.png","weather_23.png","weather_24.png","weather_25.png","weather_26.png","weather_27.png","weather_28.png","weather_29.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 167,
              y: 125,
              week_en: ["day_1.png","day_2.png","day_3.png","day_4.png","day_5.png","day_6.png","day_7.png"],
              week_tc: ["day_1.png","day_2.png","day_3.png","day_4.png","day_5.png","day_6.png","day_7.png"],
              week_sc: ["day_1.png","day_2.png","day_3.png","day_4.png","day_5.png","day_6.png","day_7.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_month_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 253,
              month_startY: 125,
              month_sc_array: ["month_1.png","month_2.png","month_3.png","month_4.png","month_5.png","month_6.png","month_7.png","month_8.png","month_9.png","month_10.png","month_11.png","month_12.png"],
              month_tc_array: ["month_1.png","month_2.png","month_3.png","month_4.png","month_5.png","month_6.png","month_7.png","month_8.png","month_9.png","month_10.png","month_11.png","month_12.png"],
              month_en_array: ["month_1.png","month_2.png","month_3.png","month_4.png","month_5.png","month_6.png","month_7.png","month_8.png","month_9.png","month_10.png","month_11.png","month_12.png"],
              month_is_character: true ,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 222,
              day_startY: 132,
              day_sc_array: ["small_0.png","small_1.png","small_2.png","small_3.png","small_4.png","small_5.png","small_6.png","small_7.png","small_8.png","small_9.png"],
              day_tc_array: ["small_0.png","small_1.png","small_2.png","small_3.png","small_4.png","small_5.png","small_6.png","small_7.png","small_8.png","small_9.png"],
              day_en_array: ["small_0.png","small_1.png","small_2.png","small_3.png","small_4.png","small_5.png","small_6.png","small_7.png","small_8.png","small_9.png"],
              day_zero: 0,
              day_space: 1,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            console.log('Watch_Face.ScreenAOD');
            idle_background_bg = hmUI.createWidget(hmUI.widget.FILL_RECT, {
              x: 0,
              y: 0,
              w: 466,
              h: 466,
              color: '0xFFFFFFFF',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_image_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'image_bg.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 47,
              hour_startY: 161,
              hour_array: ["time_0.png","time_1.png","time_2.png","time_3.png","time_4.png","time_5.png","time_6.png","time_7.png","time_8.png","time_9.png"],
              hour_zero: 1,
              hour_space: 0,
              hour_angle: 0,
              hour_unit_sc: 'pointer_0.png',
              hour_unit_tc: 'pointer_0.png',
              hour_unit_en: 'pointer_0.png',
              hour_align: hmUI.align.LEFT,

              minute_startX: 179,
              minute_startY: 161,
              minute_array: ["time_0.png","time_1.png","time_2.png","time_3.png","time_4.png","time_5.png","time_6.png","time_7.png","time_8.png","time_9.png"],
              minute_zero: 1,
              minute_space: 0,
              minute_angle: 0,
              minute_follow: 0,
              minute_unit_sc: 'pointer_0.png',
              minute_unit_tc: 'pointer_0.png',
              minute_unit_en: 'pointer_0.png',
              minute_align: hmUI.align.LEFT,

              second_startX: 311,
              second_startY: 161,
              second_array: ["time_0.png","time_1.png","time_2.png","time_3.png","time_4.png","time_5.png","time_6.png","time_7.png","time_8.png","time_9.png"],
              second_zero: 1,
              second_space: 0,
              second_angle: 0,
              second_follow: 0,
              second_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_system_lock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 181,
              y: 309,
              src: 'lock.png',
              type: hmUI.system_status.LOCK,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 181,
              y: 337,
              src: 'bt_off.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 179,
              y: 364,
              src: 'alarm.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_analog_clock_time_pointer_second = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              second_path: 'second.png',
              second_centerX: 233,
              second_centerY: 233,
              second_posX: 212,
              second_posY: 212,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 105,
              y: 90,
              font_array: ["act_0.png","act_1.png","act_2.png","act_3.png","act_4.png","act_5.png","act_6.png","act_7.png","act_8.png","act_9.png"],
              padding: false,
              h_space: 1,
              unit_sc: 'percent.png',
              unit_tc: 'percent.png',
              unit_en: 'percent.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 299,
              y: 90,
              font_array: ["act_0.png","act_1.png","act_2.png","act_3.png","act_4.png","act_5.png","act_6.png","act_7.png","act_8.png","act_9.png"],
              padding: false,
              h_space: 1,
              invalid_image: 'dot_0.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 85,
              y: 344,
              font_array: ["act_0.png","act_1.png","act_2.png","act_3.png","act_4.png","act_5.png","act_6.png","act_7.png","act_8.png","act_9.png"],
              padding: false,
              h_space: 2,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_distance_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 293,
              y: 344,
              font_array: ["act_0.png","act_1.png","act_2.png","act_3.png","act_4.png","act_5.png","act_6.png","act_7.png","act_8.png","act_9.png"],
              padding: false,
              h_space: 2,
              unit_sc: 'km.png',
              unit_tc: 'km.png',
              unit_en: 'km.png',
              imperial_unit_sc: 'ml.png',
              imperial_unit_tc: 'ml.png',
              imperial_unit_en: 'ml.png',
              dot_image: 'pointer_1.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.DISTANCE,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 213,
              y: 37,
              font_array: ["small_0.png","small_1.png","small_2.png","small_3.png","small_4.png","small_5.png","small_6.png","small_7.png","small_8.png","small_9.png"],
              padding: false,
              h_space: 1,
              unit_sc: 'pointer_3.png',
              unit_tc: 'pointer_3.png',
              unit_en: 'pointer_3.png',
              negative_image: 'pointer_2.png',
              invalid_image: 'dot_1.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 115,
              y: 58,
              image_array: ["weather_1.png","weather_2.png","weather_3.png","weather_4.png","weather_5.png","weather_6.png","weather_7.png","weather_8.png","weather_9.png","weather_10.png","weather_11.png","weather_12.png","weather_13.png","weather_14.png","weather_15.png","weather_16.png","weather_17.png","weather_18.png","weather_19.png","weather_20.png","weather_21.png","weather_22.png","weather_23.png","weather_24.png","weather_25.png","weather_26.png","weather_27.png","weather_28.png","weather_29.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 167,
              y: 125,
              week_en: ["day_1.png","day_2.png","day_3.png","day_4.png","day_5.png","day_6.png","day_7.png"],
              week_tc: ["day_1.png","day_2.png","day_3.png","day_4.png","day_5.png","day_6.png","day_7.png"],
              week_sc: ["day_1.png","day_2.png","day_3.png","day_4.png","day_5.png","day_6.png","day_7.png"],
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_month_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 253,
              month_startY: 125,
              month_sc_array: ["month_1.png","month_2.png","month_3.png","month_4.png","month_5.png","month_6.png","month_7.png","month_8.png","month_9.png","month_10.png","month_11.png","month_12.png"],
              month_tc_array: ["month_1.png","month_2.png","month_3.png","month_4.png","month_5.png","month_6.png","month_7.png","month_8.png","month_9.png","month_10.png","month_11.png","month_12.png"],
              month_en_array: ["month_1.png","month_2.png","month_3.png","month_4.png","month_5.png","month_6.png","month_7.png","month_8.png","month_9.png","month_10.png","month_11.png","month_12.png"],
              month_is_character: true ,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 222,
              day_startY: 132,
              day_sc_array: ["small_0.png","small_1.png","small_2.png","small_3.png","small_4.png","small_5.png","small_6.png","small_7.png","small_8.png","small_9.png"],
              day_tc_array: ["small_0.png","small_1.png","small_2.png","small_3.png","small_4.png","small_5.png","small_6.png","small_7.png","small_8.png","small_9.png"],
              day_en_array: ["small_0.png","small_1.png","small_2.png","small_3.png","small_4.png","small_5.png","small_6.png","small_7.png","small_8.png","small_9.png"],
              day_zero: 0,
              day_space: 1,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            image_top_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'images_0.png',
              show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_AOD,
            });

            console.log('Watch_Face.Buttons');
            Button_1 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 175,
              y: 398,
              w: 113,
              h: 41,
              text: '',
              color: 0xFFFF8C00,
              text_size: 24,
              press_src: 'dot_0.png',
              normal_src: 'dot_0.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'SportListScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_2 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 179,
              y: 28,
              w: 113,
              h: 68,
              text: '',
              color: 0xFFFF8C00,
              text_size: 24,
              press_src: 'dot_0.png',
              normal_src: 'dot_0.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'WeatherScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_3 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 179,
              y: 360,
              w: 97,
              h: 29,
              text: '',
              color: 0xFFFF8C00,
              text_size: 24,
              press_src: 'dot_0.png',
              normal_src: 'dot_0.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'AlarmInfoScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_4 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 301,
              y: 310,
              w: 81,
              h: 79,
              text: '',
              color: 0xFFFF8C00,
              text_size: 24,
              press_src: 'dot_0.png',
              normal_src: 'dot_0.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'spo_HomeScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_5 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 88,
              y: 310,
              w: 81,
              h: 79,
              text: '',
              color: 0xFFFF8C00,
              text_size: 24,
              press_src: 'dot_0.png',
              normal_src: 'dot_0.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'activityAppScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_6 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 88,
              y: 89,
              w: 81,
              h: 66,
              text: '',
              color: 0xFFFF8C00,
              text_size: 24,
              press_src: 'dot_0.png',
              normal_src: 'dot_0.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'LowBatteryScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_7 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 302,
              y: 89,
              w: 81,
              h: 66,
              text: '',
              color: 0xFFFF8C00,
              text_size: 24,
              press_src: 'dot_0.png',
              normal_src: 'dot_0.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'heart_app_Screen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_8 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 183,
              y: 123,
              w: 106,
              h: 32,
              text: '',
              color: 0xFFFF8C00,
              text_size: 24,
              press_src: 'dot_0.png',
              normal_src: 'dot_0.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'ScheduleCalScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                console.log('resume_call()');
                normal_frame_animation_1.setProperty(hmUI.prop.ANIM_STATUS,hmUI.anim_status.START);

              }),
              pause_call: (function () {
                console.log('pause_call()');
                normal_frame_animation_1.setProperty(hmUI.prop.ANIM_STATUS,hmUI.anim_status.STOP);

              }),
            });

                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}