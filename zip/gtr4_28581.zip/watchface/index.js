﻿
    /*
    ** Watch_Face_Editor tool
    ** watchface js version v1.0.1
    ** Copyright © CashaCX75. All Rights Reserved
    */

    try {

      (() => {

        var __$$app$$__ = __$$hmAppManager$$__.currentApp;
        var __$$module$$__ = __$$app$$__.current;
        //drink is a name,can modify
        var h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__), 'drink');

        'use strict';

        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_temperature_current_text_img = ''
        let normal_temperature_current_separator_img = ''
        let normal_heart_rate_text_text_img = ''
        let normal_heart_rate_text_separator_img = ''
        let normal_step_current_text_img = ''
        let normal_step_current_separator_img = ''
        let normal_date_img_date_month_img = ''
        let normal_date_img_date_day = ''
        let normal_date_day_separator_img = ''
        let normal_date_img_date_week_img = ''
        let normal_battery_icon_img = ''
        let normal_battery_text_text_img = ''
        let normal_battery_text_separator_img = ''
        let normal_digital_clock_img_time = ''
        let normal_digital_clock_minute_separator_img = ''
        let idle_background_bg_img = ''
        let idle_date_img_date_month_img = ''
        let idle_date_img_date_day = ''
        let idle_date_day_separator_img = ''
        let idle_date_img_date_week_img = ''
        let idle_battery_icon_img = ''
        let idle_battery_text_text_img = ''
        let idle_battery_text_separator_img = ''
        let idle_digital_clock_img_time = ''
        let idle_digital_clock_minute_separator_img = ''


        //dynamic modify end

        //not required
        const logger = DeviceRuntimeCore.HmLogger.getLogger("yeguang");

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({

          init_view() {

            //dynamic modify start
                    
            
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 466,
              h: 466,
              src: 'bck-0001.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 247,
              y: 37,
              font_array: ["dig-0000.png","dig-0001.png","dig-0002.png","dig-0003.png","dig-0004.png","dig-0005.png","dig-0006.png","dig-0007.png","dig-0008.png","dig-0009.png"],
              padding: false,
              h_space: 6,
              unit_sc: 'gradi.png',
              unit_tc: 'gradi.png',
              unit_en: 'gradi.png',
              negative_image: 'meno.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 100,
              y: 37,
              src: 'temperature.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 238,
              y: 396,
              font_array: ["dig-0000.png","dig-0001.png","dig-0002.png","dig-0003.png","dig-0004.png","dig-0005.png","dig-0006.png","dig-0007.png","dig-0008.png","dig-0009.png"],
              padding: true,
              h_space: 6,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 125,
              y: 394,
              src: 'Heart.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 236,
              y: 355,
              font_array: ["dig-0000.png","dig-0001.png","dig-0002.png","dig-0003.png","dig-0004.png","dig-0005.png","dig-0006.png","dig-0007.png","dig-0008.png","dig-0009.png"],
              padding: true,
              h_space: 6,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 125,
              y: 354,
              src: 'Step.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_month_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 284,
              month_startY: 298,
              month_sc_array: ["mon-0001.png","mon-0002.png","mon-0003.png","mon-0004.png","mon-0005.png","mon-0006.png","mon-0007.png","mon-0008.png","mon-0009.png","mon-0010.png","mon-0011.png","mon-0012.png"],
              month_tc_array: ["mon-0001.png","mon-0002.png","mon-0003.png","mon-0004.png","mon-0005.png","mon-0006.png","mon-0007.png","mon-0008.png","mon-0009.png","mon-0010.png","mon-0011.png","mon-0012.png"],
              month_en_array: ["mon-0001.png","mon-0002.png","mon-0003.png","mon-0004.png","mon-0005.png","mon-0006.png","mon-0007.png","mon-0008.png","mon-0009.png","mon-0010.png","mon-0011.png","mon-0012.png"],
              month_is_character: true ,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 230,
              day_startY: 298,
              day_sc_array: ["dig-0000.png","dig-0001.png","dig-0002.png","dig-0003.png","dig-0004.png","dig-0005.png","dig-0006.png","dig-0007.png","dig-0008.png","dig-0009.png"],
              day_tc_array: ["dig-0000.png","dig-0001.png","dig-0002.png","dig-0003.png","dig-0004.png","dig-0005.png","dig-0006.png","dig-0007.png","dig-0008.png","dig-0009.png"],
              day_en_array: ["dig-0000.png","dig-0001.png","dig-0002.png","dig-0003.png","dig-0004.png","dig-0005.png","dig-0006.png","dig-0007.png","dig-0008.png","dig-0009.png"],
              day_zero: 1,
              day_space: 4,
              day_align: hmUI.align.LEFT,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_day_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 205,
              y: 305,
              src: 'dig-virgola.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 46,
              y: 298,
              week_en: ["day-0001.png","day-0002.png","day-0003.png","day-0004.png","day-0005.png","day-0006.png","day-0007.png"],
              week_tc: ["day-0001.png","day-0002.png","day-0003.png","day-0004.png","day-0005.png","day-0006.png","day-0007.png"],
              week_sc: ["day-0001.png","day-0002.png","day-0003.png","day-0004.png","day-0005.png","day-0006.png","day-0007.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 126,
              y: 87,
              src: 'power.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 252,
              y: 88,
              font_array: ["dig-0000.png","dig-0001.png","dig-0002.png","dig-0003.png","dig-0004.png","dig-0005.png","dig-0006.png","dig-0007.png","dig-0008.png","dig-0009.png"],
              padding: true,
              h_space: 4,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 331,
              y: 88,
              src: 'dig-per.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 36,
              hour_startY: 158,
              hour_array: ["num-0100.png","num-0101.png","num-0102.png","num-0103.png","num-0104.png","num-0105.png","num-0106.png","num-0107.png","num-0108.png","num-0109.png"],
              hour_zero: 1,
              hour_space: 19,
              hour_align: hmUI.align.CENTER_H,

              minute_startX: 281,
              minute_startY: 158,
              minute_array: ["num-0100.png","num-0101.png","num-0102.png","num-0103.png","num-0104.png","num-0105.png","num-0106.png","num-0107.png","num-0108.png","num-0109.png"],
              minute_zero: 1,
              minute_space: 20,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_minute_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 211,
              y: 158,
              src: 'sec-0101.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            idle_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 466,
              h: 466,
              src: 'bck-0001.png',
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_date_img_date_month_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 284,
              month_startY: 298,
              month_sc_array: ["mon-0001.png","mon-0002.png","mon-0003.png","mon-0004.png","mon-0005.png","mon-0006.png","mon-0007.png","mon-0008.png","mon-0009.png","mon-0010.png","mon-0011.png","mon-0012.png"],
              month_tc_array: ["mon-0001.png","mon-0002.png","mon-0003.png","mon-0004.png","mon-0005.png","mon-0006.png","mon-0007.png","mon-0008.png","mon-0009.png","mon-0010.png","mon-0011.png","mon-0012.png"],
              month_en_array: ["mon-0001.png","mon-0002.png","mon-0003.png","mon-0004.png","mon-0005.png","mon-0006.png","mon-0007.png","mon-0008.png","mon-0009.png","mon-0010.png","mon-0011.png","mon-0012.png"],
              month_is_character: true ,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 230,
              day_startY: 298,
              day_sc_array: ["dig-0000.png","dig-0001.png","dig-0002.png","dig-0003.png","dig-0004.png","dig-0005.png","dig-0006.png","dig-0007.png","dig-0008.png","dig-0009.png"],
              day_tc_array: ["dig-0000.png","dig-0001.png","dig-0002.png","dig-0003.png","dig-0004.png","dig-0005.png","dig-0006.png","dig-0007.png","dig-0008.png","dig-0009.png"],
              day_en_array: ["dig-0000.png","dig-0001.png","dig-0002.png","dig-0003.png","dig-0004.png","dig-0005.png","dig-0006.png","dig-0007.png","dig-0008.png","dig-0009.png"],
              day_zero: 1,
              day_space: 4,
              day_align: hmUI.align.LEFT,
              day_is_character: false,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_date_day_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 205,
              y: 305,
              src: 'dig-virgola.png',
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 46,
              y: 298,
              week_en: ["day-0001.png","day-0002.png","day-0003.png","day-0004.png","day-0005.png","day-0006.png","day-0007.png"],
              week_tc: ["day-0001.png","day-0002.png","day-0003.png","day-0004.png","day-0005.png","day-0006.png","day-0007.png"],
              week_sc: ["day-0001.png","day-0002.png","day-0003.png","day-0004.png","day-0005.png","day-0006.png","day-0007.png"],
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_battery_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 126,
              y: 87,
              src: 'power.png',
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 252,
              y: 88,
              font_array: ["dig-0000.png","dig-0001.png","dig-0002.png","dig-0003.png","dig-0004.png","dig-0005.png","dig-0006.png","dig-0007.png","dig-0008.png","dig-0009.png"],
              padding: true,
              h_space: 4,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_battery_text_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 331,
              y: 88,
              src: 'dig-per.png',
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 36,
              hour_startY: 158,
              hour_array: ["num-0100.png","num-0101.png","num-0102.png","num-0103.png","num-0104.png","num-0105.png","num-0106.png","num-0107.png","num-0108.png","num-0109.png"],
              hour_zero: 1,
              hour_space: 19,
              hour_align: hmUI.align.CENTER_H,

              minute_startX: 281,
              minute_startY: 158,
              minute_array: ["num-0100.png","num-0101.png","num-0102.png","num-0103.png","num-0104.png","num-0105.png","num-0106.png","num-0107.png","num-0108.png","num-0109.png"],
              minute_zero: 1,
              minute_space: 20,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_digital_clock_minute_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 211,
              y: 158,
              src: 'sec-0101.png',
              show_level: hmUI.show_level.ONAL_AOD,
            });


            //dynamic modify end
          },

          onInit() {
            console.log('index page.js on init invoke')

            this.init_view()

          },

          onReady() {
            console.log('index page.js on ready invoke')
          },

          onShow() {
            console.log('index page.js on show invoke')
          },

          onHide() {
            console.log('index page.js on hide invoke')
          },

          onDestory() {
            console.log('index page.js on destory invoke')
          },
        });

      })()
    } catch (e) {
      console.log(e)
    }
  