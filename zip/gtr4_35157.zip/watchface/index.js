﻿/*
** Watch_Face_Editor tool
** watchface js version v2.1.1
** Copyright © SashaCX75. All Rights Reserved
*/

try {
  (() => {
    //start of ignored block
    const __$$app$$__ = __$$hmAppManager$$__.currentApp;
    function getApp() {
      return __$$app$$__.app;
    }
    function getCurrentPage() {
      return __$$app$$__.current && __$$app$$__.current.module;
    }
    const __$$module$$__ = __$$app$$__.current;
    const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
    const { px } = __$$app$$__.__globals__;
    const logger = Logger.getLogger('watchface_SashaCX75');
    //end of ignored block

    //dynamic modify start


    let normal_background_bg_img = ''
    let normal_temperature_current_text_img = ''
    let normal_weather_image_progress_img_level = ''
    let normal_step_current_text_img = ''
    let normal_heart_rate_text_text_img = ''
    let normal_battery_text_text_img = ''
    let normal_date_img_date_day = ''
    let normal_date_img_date_week_img = ''
    let normal_date_img_date_month_img = ''
    let normal_digital_clock_img_time = ''
    let normal_digital_clock_hour_separator_img = ''
    let idle_background_bg_img = ''
    let idle_temperature_current_text_img = ''
    let idle_weather_image_progress_img_level = ''
    let idle_step_current_text_img = ''
    let idle_heart_rate_text_text_img = ''
    let idle_battery_text_text_img = ''
    let idle_date_img_date_day = ''
    let idle_date_img_date_week_img = ''
    let idle_date_img_date_month_img = ''
    let idle_pai_icon_img = ''
    let idle_digital_clock_img_time = ''
    let idle_digital_clock_hour_separator_img = ''
    let image_top_img = ''


    //dynamic modify end

    __$$module$$__.module = DeviceRuntimeCore.WatchFace({
      init_view() {
        //dynamic modify start


        normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
          x: 0,
          y: 0,
          w: 466,
          h: 466,
          src: 'bg.png',
          show_level: hmUI.show_level.ONLY_NORMAL,
        });

        normal_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
          x: 229,
          y: 296,
          font_array: ["dig26w_0.png", "dig26w_1.png", "dig26w_2.png", "dig26w_3.png", "dig26w_4.png", "dig26w_5.png", "dig26w_6.png", "dig26w_7.png", "dig26w_8.png", "dig26w_9.png"],
          padding: false,
          h_space: -1,
          unit_sc: 'dig26w_degr.png',
          unit_tc: 'dig26w_degr.png',
          unit_en: 'dig26w_degr.png',
          negative_image: 'dig26w_minus.png',
          align_h: hmUI.align.CENTER_H,
          type: hmUI.data_type.WEATHER_CURRENT,
          show_level: hmUI.show_level.ONLY_NORMAL,
        });

        normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
          x: 191,
          y: 286,
          image_array: ["w_1.png", "w_2.png", "w_3.png", "w_4.png", "w_5.png", "w_6.png", "w_7.png", "w_8.png", "w_9.png", "w_10.png", "w_11.png", "w_12.png", "w_13.png", "w_14.png", "w_15.png", "w_16.png", "w_17.png", "w_18.png", "w_19.png", "w_20.png", "w_21.png", "w_22.png", "w_23.png", "w_24.png", "w_25.png", "w_26.png", "w_27.png", "w_28.png", "w_29.png"],
          image_length: 29,
          type: hmUI.data_type.WEATHER_CURRENT,
          show_level: hmUI.show_level.ONLY_NORMAL,
        });

        normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
          x: 50,
          y: 296,
          font_array: ["dig26w_0.png", "dig26w_1.png", "dig26w_2.png", "dig26w_3.png", "dig26w_4.png", "dig26w_5.png", "dig26w_6.png", "dig26w_7.png", "dig26w_8.png", "dig26w_9.png"],
          padding: false,
          h_space: 0,
          align_h: hmUI.align.CENTER_H,
          type: hmUI.data_type.STEP,
          show_level: hmUI.show_level.ONLY_NORMAL,
        });

        normal_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
          x: 50,
          y: 146,
          font_array: ["dig26w_0.png", "dig26w_1.png", "dig26w_2.png", "dig26w_3.png", "dig26w_4.png", "dig26w_5.png", "dig26w_6.png", "dig26w_7.png", "dig26w_8.png", "dig26w_9.png"],
          padding: false,
          h_space: 0,
          align_h: hmUI.align.CENTER_H,
          type: hmUI.data_type.HEART,
          show_level: hmUI.show_level.ONLY_NORMAL,
        });

        normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
          x: 374,
          y: 146,
          font_array: ["dig26w_0.png", "dig26w_1.png", "dig26w_2.png", "dig26w_3.png", "dig26w_4.png", "dig26w_5.png", "dig26w_6.png", "dig26w_7.png", "dig26w_8.png", "dig26w_9.png"],
          padding: false,
          h_space: 1,
          align_h: hmUI.align.CENTER_H,
          type: hmUI.data_type.BATTERY,
          show_level: hmUI.show_level.ONLY_NORMAL,
        });

        normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
          day_startX: 196,
          day_startY: 132,
          day_sc_array: ["dig44w_0.png", "dig44w_1.png", "dig44w_2.png", "dig44w_3.png", "dig44w_4.png", "dig44w_5.png", "dig44w_6.png", "dig44w_7.png", "dig44w_8.png", "dig44w_9.png"],
          day_tc_array: ["dig44w_0.png", "dig44w_1.png", "dig44w_2.png", "dig44w_3.png", "dig44w_4.png", "dig44w_5.png", "dig44w_6.png", "dig44w_7.png", "dig44w_8.png", "dig44w_9.png"],
          day_en_array: ["dig44w_0.png", "dig44w_1.png", "dig44w_2.png", "dig44w_3.png", "dig44w_4.png", "dig44w_5.png", "dig44w_6.png", "dig44w_7.png", "dig44w_8.png", "dig44w_9.png"],
          day_zero: 1,
          day_space: -1,
          day_align: hmUI.align.CENTER_H,
          day_is_character: false,
          show_level: hmUI.show_level.ONLY_NORMAL,
        });

        normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
          x: 269,
          y: 146,
          week_en: ["week_1.png", "week_2.png", "week_3.png", "week_4.png", "week_5.png", "week_6.png", "week_7.png"],
          week_tc: ["week_1.png", "week_2.png", "week_3.png", "week_4.png", "week_5.png", "week_6.png", "week_7.png"],
          week_sc: ["week_1.png", "week_2.png", "week_3.png", "week_4.png", "week_5.png", "week_6.png", "week_7.png"],
          show_level: hmUI.show_level.ONLY_NORMAL,
        });

        normal_date_img_date_month_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
          month_startX: 119,
          month_startY: 146,
          month_sc_array: ["mon_1.png", "mon_2.png", "mon_3.png", "mon_4.png", "mon_5.png", "mon_6.png", "mon_7.png", "mon_8.png", "mon_9.png", "mon_10.png", "mon_11.png", "mon_12.png"],
          month_tc_array: ["mon_1.png", "mon_2.png", "mon_3.png", "mon_4.png", "mon_5.png", "mon_6.png", "mon_7.png", "mon_8.png", "mon_9.png", "mon_10.png", "mon_11.png", "mon_12.png"],
          month_en_array: ["mon_1.png", "mon_2.png", "mon_3.png", "mon_4.png", "mon_5.png", "mon_6.png", "mon_7.png", "mon_8.png", "mon_9.png", "mon_10.png", "mon_11.png", "mon_12.png"],
          month_is_character: true,
          show_level: hmUI.show_level.ONLY_NORMAL,
        });

        normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
          hour_startX: 13,
          hour_startY: 182,
          hour_array: ["dig130w_0.png", "dig130w_1.png", "dig130w_2.png", "dig130w_3.png", "dig130w_4.png", "dig130w_5.png", "dig130w_6.png", "dig130w_7.png", "dig130w_8.png", "dig130w_9.png"],
          hour_zero: 1,
          hour_space: -3,
          hour_angle: 0,
          hour_align: hmUI.align.CENTER_H,

          minute_startX: 251,
          minute_startY: 182,
          minute_array: ["dig130y_0.png", "dig130y_1.png", "dig130y_2.png", "dig130y_3.png", "dig130y_4.png", "dig130y_5.png", "dig130y_6.png", "dig130y_7.png", "dig130y_8.png", "dig130y_9.png"],
          minute_zero: 1,
          minute_space: -3,
          minute_angle: 0,
          minute_follow: 0,
          minute_align: hmUI.align.CENTER_H,

          second_startX: 387,
          second_startY: 296,
          second_array: ["dig26w_0.png", "dig26w_1.png", "dig26w_2.png", "dig26w_3.png", "dig26w_4.png", "dig26w_5.png", "dig26w_6.png", "dig26w_7.png", "dig26w_8.png", "dig26w_9.png"],
          second_zero: 1,
          second_space: 0,
          second_angle: 0,
          second_follow: 0,
          second_align: hmUI.align.CENTER_H,

          show_level: hmUI.show_level.ONLY_NORMAL,
        });

        normal_digital_clock_hour_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
          x: 220,
          y: 182,
          src: 'dig130w_dots.png',
          show_level: hmUI.show_level.ONLY_NORMAL,
        });


        idle_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
          x: 0,
          y: 0,
          w: 466,
          h: 466,
          src: 'bg.png',
          show_level: hmUI.show_level.ONLY_AOD,
        });

        idle_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
          x: 229,
          y: 296,
          font_array: ["dig26w_0.png", "dig26w_1.png", "dig26w_2.png", "dig26w_3.png", "dig26w_4.png", "dig26w_5.png", "dig26w_6.png", "dig26w_7.png", "dig26w_8.png", "dig26w_9.png"],
          padding: false,
          h_space: -1,
          unit_sc: 'dig26w_degr.png',
          unit_tc: 'dig26w_degr.png',
          unit_en: 'dig26w_degr.png',
          negative_image: 'dig26w_minus.png',
          align_h: hmUI.align.CENTER_H,
          type: hmUI.data_type.WEATHER_CURRENT,
          show_level: hmUI.show_level.ONLY_AOD,
        });

        idle_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
          x: 191,
          y: 286,
          image_array: ["w_1.png", "w_2.png", "w_3.png", "w_4.png", "w_5.png", "w_6.png", "w_7.png", "w_8.png", "w_9.png", "w_10.png", "w_11.png", "w_12.png", "w_13.png", "w_14.png", "w_15.png", "w_16.png", "w_17.png", "w_18.png", "w_19.png", "w_20.png", "w_21.png", "w_22.png", "w_23.png", "w_24.png", "w_25.png", "w_26.png", "w_27.png", "w_28.png", "w_29.png"],
          image_length: 29,
          type: hmUI.data_type.WEATHER_CURRENT,
          show_level: hmUI.show_level.ONLY_AOD,
        });

        idle_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
          x: 50,
          y: 296,
          font_array: ["dig26w_0.png", "dig26w_1.png", "dig26w_2.png", "dig26w_3.png", "dig26w_4.png", "dig26w_5.png", "dig26w_6.png", "dig26w_7.png", "dig26w_8.png", "dig26w_9.png"],
          padding: false,
          h_space: 0,
          align_h: hmUI.align.CENTER_H,
          type: hmUI.data_type.STEP,
          show_level: hmUI.show_level.ONLY_AOD,
        });

        idle_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
          x: 50,
          y: 146,
          font_array: ["dig26w_0.png", "dig26w_1.png", "dig26w_2.png", "dig26w_3.png", "dig26w_4.png", "dig26w_5.png", "dig26w_6.png", "dig26w_7.png", "dig26w_8.png", "dig26w_9.png"],
          padding: false,
          h_space: 0,
          align_h: hmUI.align.CENTER_H,
          type: hmUI.data_type.HEART,
          show_level: hmUI.show_level.ONLY_AOD,
        });

        idle_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
          x: 374,
          y: 146,
          font_array: ["dig26w_0.png", "dig26w_1.png", "dig26w_2.png", "dig26w_3.png", "dig26w_4.png", "dig26w_5.png", "dig26w_6.png", "dig26w_7.png", "dig26w_8.png", "dig26w_9.png"],
          padding: false,
          h_space: 1,
          align_h: hmUI.align.CENTER_H,
          type: hmUI.data_type.BATTERY,
          show_level: hmUI.show_level.ONLY_AOD,
        });

        idle_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
          day_startX: 196,
          day_startY: 132,
          day_sc_array: ["dig44w_0.png", "dig44w_1.png", "dig44w_2.png", "dig44w_3.png", "dig44w_4.png", "dig44w_5.png", "dig44w_6.png", "dig44w_7.png", "dig44w_8.png", "dig44w_9.png"],
          day_tc_array: ["dig44w_0.png", "dig44w_1.png", "dig44w_2.png", "dig44w_3.png", "dig44w_4.png", "dig44w_5.png", "dig44w_6.png", "dig44w_7.png", "dig44w_8.png", "dig44w_9.png"],
          day_en_array: ["dig44w_0.png", "dig44w_1.png", "dig44w_2.png", "dig44w_3.png", "dig44w_4.png", "dig44w_5.png", "dig44w_6.png", "dig44w_7.png", "dig44w_8.png", "dig44w_9.png"],
          day_zero: 1,
          day_space: -1,
          day_align: hmUI.align.CENTER_H,
          day_is_character: false,
          show_level: hmUI.show_level.ONLY_AOD,
        });

        idle_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
          x: 269,
          y: 146,
          week_en: ["week_1.png", "week_2.png", "week_3.png", "week_4.png", "week_5.png", "week_6.png", "week_7.png"],
          week_tc: ["week_1.png", "week_2.png", "week_3.png", "week_4.png", "week_5.png", "week_6.png", "week_7.png"],
          week_sc: ["week_1.png", "week_2.png", "week_3.png", "week_4.png", "week_5.png", "week_6.png", "week_7.png"],
          show_level: hmUI.show_level.ONLY_AOD,
        });

        idle_date_img_date_month_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
          month_startX: 119,
          month_startY: 146,
          month_sc_array: ["mon_1.png", "mon_2.png", "mon_3.png", "mon_4.png", "mon_5.png", "mon_6.png", "mon_7.png", "mon_8.png", "mon_9.png", "mon_10.png", "mon_11.png", "mon_12.png"],
          month_tc_array: ["mon_1.png", "mon_2.png", "mon_3.png", "mon_4.png", "mon_5.png", "mon_6.png", "mon_7.png", "mon_8.png", "mon_9.png", "mon_10.png", "mon_11.png", "mon_12.png"],
          month_en_array: ["mon_1.png", "mon_2.png", "mon_3.png", "mon_4.png", "mon_5.png", "mon_6.png", "mon_7.png", "mon_8.png", "mon_9.png", "mon_10.png", "mon_11.png", "mon_12.png"],
          month_is_character: true,
          show_level: hmUI.show_level.ONLY_AOD,
        });

        idle_pai_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
          x: 0,
          y: 0,
          src: 'mask.png',
          alpha: 150,
          show_level: hmUI.show_level.ONLY_AOD,
        });

        idle_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
          hour_startX: 13,
          hour_startY: 182,
          hour_array: ["dig130w_0.png", "dig130w_1.png", "dig130w_2.png", "dig130w_3.png", "dig130w_4.png", "dig130w_5.png", "dig130w_6.png", "dig130w_7.png", "dig130w_8.png", "dig130w_9.png"],
          hour_zero: 1,
          hour_space: -3,
          hour_angle: 0,
          hour_align: hmUI.align.CENTER_H,

          minute_startX: 251,
          minute_startY: 182,
          minute_array: ["dig130y_0.png", "dig130y_1.png", "dig130y_2.png", "dig130y_3.png", "dig130y_4.png", "dig130y_5.png", "dig130y_6.png", "dig130y_7.png", "dig130y_8.png", "dig130y_9.png"],
          minute_zero: 1,
          minute_space: -3,
          minute_angle: 0,
          minute_follow: 0,
          minute_align: hmUI.align.CENTER_H,

          show_level: hmUI.show_level.ONLY_AOD,
        });

        idle_digital_clock_hour_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
          x: 220,
          y: 182,
          src: 'dig130w_dots.png',
          show_level: hmUI.show_level.ONLY_AOD,
        });

        image_top_img = hmUI.createWidget(hmUI.widget.IMG, {
          x: 0,
          y: 0,
          src: 'fg.png',
          show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_AOD,
        });


        //dynamic modify end
      },
      onInit() {
        logger.log('index page.js on init invoke');
      },
      build() {
        this.init_view();
        logger.log('index page.js on ready invoke');
      },
      onDestroy() {
        logger.log('index page.js on destroy invoke');
      }
    });
    ;
  })();
} catch (e) {
  console.log('Mini Program Error', e);
  e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
  ;
}