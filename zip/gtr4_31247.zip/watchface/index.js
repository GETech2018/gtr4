﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.0.1
    ** Copyright © CashaCX75. All Rights Reserved
    */

    try {
    (()=>{
        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_battery_text_text_img = ''
        let normal_battery_image_progress_img_level = ''
        let normal_step_current_text_img = ''
        let normal_sun_high_text_img = ''
        let normal_sun_low_text_img = ''
        let normal_date_img_date_month = ''
        let normal_date_img_date_day = ''
        let normal_uvi_text_text_img = ''
        let normal_humidity_text_text_img = ''
        let normal_temperature_high_text_img = ''
        let normal_temperature_low_text_img = ''
        let normal_temperature_current_text_img = ''
        let normal_weather_image_progress_img_level = ''
        let normal_digital_clock_img_time = ''
        let idle_background_bg_img = ''
        let idle_date_img_date_month = ''
        let idle_date_img_date_day = ''
        let idle_digital_clock_img_time = ''


        //dynamic modify end
        const e = __$$hmAppManager$$__.currentApp;
        const o = e.current
          , {px: i} = (new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(e,o)),
        e.__globals__)
          , n = Logger.getLogger("watchface6");
        o.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 466,
              h: 466,
              src: 'GTR4_Split_Planes_Bckg.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 202,
              y: 427,
              font_array: ["SP_XS_W_0.png","SP_XS_W_1.png","SP_XS_W_2.png","SP_XS_W_3.png","SP_XS_W_4.png","SP_XS_W_5.png","SP_XS_W_6.png","SP_XS_W_7.png","SP_XS_W_8.png","SP_XS_W_9.png"],
              padding: false,
              h_space: 3,
              unit_sc: 'SP_XS_W_Perc.png',
              unit_tc: 'SP_XS_W_Perc.png',
              unit_en: 'SP_XS_W_Perc.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 275,
              y: 246,
              image_array: ["Batt_Red_0.png","Batt_Red_1.png","Batt_Red_2.png","Batt_Red_3.png","Batt_Red_4.png","Batt_Red_5.png","Batt_Red_6.png","Batt_Red_7.png","Batt_Red_8.png","Batt_Red_9.png","Batt_Red_10.png"],
              image_length: 11,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 118,
              y: 345,
              font_array: ["SP_M_B_0.png","SP_M_B_1.png","SP_M_B_2.png","SP_M_B_3.png","SP_M_B_4.png","SP_M_B_5.png","SP_M_B_6.png","SP_M_B_7.png","SP_M_B_8.png","SP_M_B_9.png"],
              padding: false,
              h_space: 6,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sun_high_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 215,
              y: 251,
              font_array: ["SP_XS_B_0.png","SP_XS_B_1.png","SP_XS_B_2.png","SP_XS_B_3.png","SP_XS_B_4.png","SP_XS_B_5.png","SP_XS_B_6.png","SP_XS_B_7.png","SP_XS_B_8.png","SP_XS_B_9.png"],
              padding: false,
              h_space: 3,
              dot_image: 'SP_XS_B_DDot.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.SUN_RISE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sun_low_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 215,
              y: 287,
              font_array: ["SP_XS_B_0.png","SP_XS_B_1.png","SP_XS_B_2.png","SP_XS_B_3.png","SP_XS_B_4.png","SP_XS_B_5.png","SP_XS_B_6.png","SP_XS_B_7.png","SP_XS_B_8.png","SP_XS_B_9.png"],
              padding: false,
              h_space: 3,
              dot_image: 'SP_XS_B_DDot.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.SUN_SET,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_month = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 26,
              month_startY: 249,
              month_sc_array: ["SP_M_B_0.png","SP_M_B_1.png","SP_M_B_2.png","SP_M_B_3.png","SP_M_B_4.png","SP_M_B_5.png","SP_M_B_6.png","SP_M_B_7.png","SP_M_B_8.png","SP_M_B_9.png"],
              month_tc_array: ["SP_M_B_0.png","SP_M_B_1.png","SP_M_B_2.png","SP_M_B_3.png","SP_M_B_4.png","SP_M_B_5.png","SP_M_B_6.png","SP_M_B_7.png","SP_M_B_8.png","SP_M_B_9.png"],
              month_en_array: ["SP_M_B_0.png","SP_M_B_1.png","SP_M_B_2.png","SP_M_B_3.png","SP_M_B_4.png","SP_M_B_5.png","SP_M_B_6.png","SP_M_B_7.png","SP_M_B_8.png","SP_M_B_9.png"],
              month_zero: 1,
              month_space: 5,
              month_align: hmUI.align.LEFT,
              month_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 26,
              day_startY: 190,
              day_sc_array: ["SP_M_B_0.png","SP_M_B_1.png","SP_M_B_2.png","SP_M_B_3.png","SP_M_B_4.png","SP_M_B_5.png","SP_M_B_6.png","SP_M_B_7.png","SP_M_B_8.png","SP_M_B_9.png"],
              day_tc_array: ["SP_M_B_0.png","SP_M_B_1.png","SP_M_B_2.png","SP_M_B_3.png","SP_M_B_4.png","SP_M_B_5.png","SP_M_B_6.png","SP_M_B_7.png","SP_M_B_8.png","SP_M_B_9.png"],
              day_en_array: ["SP_M_B_0.png","SP_M_B_1.png","SP_M_B_2.png","SP_M_B_3.png","SP_M_B_4.png","SP_M_B_5.png","SP_M_B_6.png","SP_M_B_7.png","SP_M_B_8.png","SP_M_B_9.png"],
              day_zero: 1,
              day_space: 5,
              day_align: hmUI.align.LEFT,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_uvi_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 270,
              y: 36,
              font_array: ["SP_XS_B_0.png","SP_XS_B_1.png","SP_XS_B_2.png","SP_XS_B_3.png","SP_XS_B_4.png","SP_XS_B_5.png","SP_XS_B_6.png","SP_XS_B_7.png","SP_XS_B_8.png","SP_XS_B_9.png"],
              padding: false,
              h_space: 3,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.UVI,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_humidity_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 227,
              y: 71,
              font_array: ["SP_XS_B_0.png","SP_XS_B_1.png","SP_XS_B_2.png","SP_XS_B_3.png","SP_XS_B_4.png","SP_XS_B_5.png","SP_XS_B_6.png","SP_XS_B_7.png","SP_XS_B_8.png","SP_XS_B_9.png"],
              padding: false,
              h_space: 3,
              unit_sc: 'SP_XS_B_Perc.png',
              unit_tc: 'SP_XS_B_Perc.png',
              unit_en: 'SP_XS_B_Perc.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.HUMIDITY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_high_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 330,
              y: 71,
              font_array: ["SP_XS_B_0.png","SP_XS_B_1.png","SP_XS_B_2.png","SP_XS_B_3.png","SP_XS_B_4.png","SP_XS_B_5.png","SP_XS_B_6.png","SP_XS_B_7.png","SP_XS_B_8.png","SP_XS_B_9.png"],
              padding: false,
              h_space: 3,
              unit_sc: 'SP_XS_B_Deg.png',
              unit_tc: 'SP_XS_B_Deg.png',
              unit_en: 'SP_XS_B_Deg.png',
              negative_image: 'SP_XS_B_Minus.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.WEATHER_HIGH,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_low_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 330,
              y: 118,
              font_array: ["SP_XS_B_0.png","SP_XS_B_1.png","SP_XS_B_2.png","SP_XS_B_3.png","SP_XS_B_4.png","SP_XS_B_5.png","SP_XS_B_6.png","SP_XS_B_7.png","SP_XS_B_8.png","SP_XS_B_9.png"],
              padding: false,
              h_space: 2,
              unit_sc: 'SP_XS_B_Deg.png',
              unit_tc: 'SP_XS_B_Deg.png',
              unit_en: 'SP_XS_B_Deg.png',
              negative_image: 'SP_XS_B_Minus.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.WEATHER_LOW,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 188,
              y: 110,
              font_array: ["SP_M_B_0.png","SP_M_B_1.png","SP_M_B_2.png","SP_M_B_3.png","SP_M_B_4.png","SP_M_B_5.png","SP_M_B_6.png","SP_M_B_7.png","SP_M_B_8.png","SP_M_B_9.png"],
              padding: false,
              h_space: 6,
              unit_sc: 'SP_M_B_Deg.png',
              unit_tc: 'SP_M_B_Deg.png',
              unit_en: 'SP_M_B_Deg.png',
              negative_image: 'SP_M_B_Minus.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 66,
              y: 57,
              image_array: ["WI_R_B_0.png","WI_R_B_1.png","WI_R_B_2.png","WI_R_B_3.png","WI_R_B_4.png","WI_R_B_5.png","WI_R_B_6.png","WI_R_B_7.png","WI_R_B_8.png","WI_R_B_9.png","WI_R_B_10.png","WI_R_B_11.png","WI_R_B_12.png","WI_R_B_13.png","WI_R_B_14.png","WI_R_B_15.png","WI_R_B_16.png","WI_R_B_17.png","WI_R_B_18.png","WI_R_B_19.png","WI_R_B_20.png","WI_R_B_21.png","WI_R_B_22.png","WI_R_B_23.png","WI_R_B_24.png","WI_R_B_25.png","WI_R_B_26.png","WI_R_B_27.png","WI_R_B_28.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 150,
              hour_startY: 177,
              hour_array: ["SP_B_B_0.png","SP_B_B_1.png","SP_B_B_2.png","SP_B_B_3.png","SP_B_B_4.png","SP_B_B_5.png","SP_B_B_6.png","SP_B_B_7.png","SP_B_B_8.png","SP_B_B_9.png"],
              hour_zero: 1,
              hour_space: 7,
              hour_unit_sc: 'SP_B_B_DDot.png',
              hour_unit_tc: 'SP_B_B_DDot.png',
              hour_unit_en: 'SP_B_B_DDot.png',
              hour_align: hmUI.align.LEFT,

              minute_startX: 0,
              minute_startY: 0,
              minute_array: ["SP_B_B_0.png","SP_B_B_1.png","SP_B_B_2.png","SP_B_B_3.png","SP_B_B_4.png","SP_B_B_5.png","SP_B_B_6.png","SP_B_B_7.png","SP_B_B_8.png","SP_B_B_9.png"],
              minute_zero: 1,
              minute_space: 7,
              minute_follow: 1,
              minute_align: hmUI.align.LEFT,

              second_startX: 384,
              second_startY: 188,
              second_array: ["SP_M_B_0.png","SP_M_B_1.png","SP_M_B_2.png","SP_M_B_3.png","SP_M_B_4.png","SP_M_B_5.png","SP_M_B_6.png","SP_M_B_7.png","SP_M_B_8.png","SP_M_B_9.png"],
              second_zero: 1,
              second_space: 5,
              second_follow: 0,
              second_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            idle_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 466,
              h: 466,
              src: 'GTR4_Split_Planes_Bckg_AOD.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_month = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 26,
              month_startY: 249,
              month_sc_array: ["SP_M_W_0.png","SP_M_W_1.png","SP_M_W_2.png","SP_M_W_3.png","SP_M_W_4.png","SP_M_W_5.png","SP_M_W_6.png","SP_M_W_7.png","SP_M_W_8.png","SP_M_W_9.png"],
              month_tc_array: ["SP_M_W_0.png","SP_M_W_1.png","SP_M_W_2.png","SP_M_W_3.png","SP_M_W_4.png","SP_M_W_5.png","SP_M_W_6.png","SP_M_W_7.png","SP_M_W_8.png","SP_M_W_9.png"],
              month_en_array: ["SP_M_W_0.png","SP_M_W_1.png","SP_M_W_2.png","SP_M_W_3.png","SP_M_W_4.png","SP_M_W_5.png","SP_M_W_6.png","SP_M_W_7.png","SP_M_W_8.png","SP_M_W_9.png"],
              month_zero: 1,
              month_space: 5,
              month_align: hmUI.align.LEFT,
              month_is_character: false,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 26,
              day_startY: 190,
              day_sc_array: ["SP_M_W_0.png","SP_M_W_1.png","SP_M_W_2.png","SP_M_W_3.png","SP_M_W_4.png","SP_M_W_5.png","SP_M_W_6.png","SP_M_W_7.png","SP_M_W_8.png","SP_M_W_9.png"],
              day_tc_array: ["SP_M_W_0.png","SP_M_W_1.png","SP_M_W_2.png","SP_M_W_3.png","SP_M_W_4.png","SP_M_W_5.png","SP_M_W_6.png","SP_M_W_7.png","SP_M_W_8.png","SP_M_W_9.png"],
              day_en_array: ["SP_M_W_0.png","SP_M_W_1.png","SP_M_W_2.png","SP_M_W_3.png","SP_M_W_4.png","SP_M_W_5.png","SP_M_W_6.png","SP_M_W_7.png","SP_M_W_8.png","SP_M_W_9.png"],
              day_zero: 1,
              day_space: 5,
              day_align: hmUI.align.LEFT,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 150,
              hour_startY: 177,
              hour_array: ["SP_B_W_0.png","SP_B_W_1.png","SP_B_W_2.png","SP_B_W_3.png","SP_B_W_4.png","SP_B_W_5.png","SP_B_W_6.png","SP_B_W_7.png","SP_B_W_8.png","SP_B_W_9.png"],
              hour_zero: 1,
              hour_space: 7,
              hour_unit_sc: 'SP_B_W_DDot.png',
              hour_unit_tc: 'SP_B_W_DDot.png',
              hour_unit_en: 'SP_B_W_DDot.png',
              hour_align: hmUI.align.LEFT,

              minute_startX: 0,
              minute_startY: 0,
              minute_array: ["SP_B_W_0.png","SP_B_W_1.png","SP_B_W_2.png","SP_B_W_3.png","SP_B_W_4.png","SP_B_W_5.png","SP_B_W_6.png","SP_B_W_7.png","SP_B_W_8.png","SP_B_W_9.png"],
              minute_zero: 1,
              minute_space: 7,
              minute_follow: 1,
              minute_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_AOD,
            });


                //dynamic modify end
            },
            onInit() {
                n.log("index page.js on init invoke")
            },
            build() {
                this.init_view(),
                n.log("index page.js on ready invoke")
            },
            onDestroy() {
                n.log("index page.js on destroy invoke")
            }
        })
    }
    )()
} catch (e) {
    console.log("Mini Program Error", e),
    e && e.stack && e.stack.split(/\n/).forEach((e=>console.log("error stack", e)))
}
