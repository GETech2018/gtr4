﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        //const logger = Logger.getLogger('watchface_SashaCX75');
        const logger = DeviceRuntimeCore.HmLogger.getLogger('watchface_SashaCX75')
        //end of ignored block

        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_weather_image_progress_img_level = ''
        let normal_temperature_current_text_img = ''
        let normal_battery_linear_scale = ''
        let normal_battery_text_text_img = ''
        let normal_battery_text_separator_img = ''
        let normal_calorie_current_text_img = ''
        let normal_distance_TextRotate = new Array(5);
        let normal_distance_TextRotate_ASCIIARRAY = new Array(10);
        let normal_distance_TextRotate_img_width = 1;
        let normal_distance_TextRotate_unit = null;
        let normal_distance_TextRotate_unit_width = 52;
        let normal_distance_TextRotate_dot_width = 1;
        let normal_distance_TextRotate_error_img_width = 1;
        let normal_distance_text_text_img = ''
        let normal_heart_rate_text_text_img = ''
        let normal_step_current_text_img = ''
        let normal_date_img_date_day = ''
        let normal_date_img_date_week_img = ''
        let normal_digital_clock_img_time_minute = ''
        let normal_digital_clock_img_time_hour = ''
        let normal_digital_clock_hour_separator_img = ''
        let idle_background_bg_img = ''
        let idle_weather_image_progress_img_level = ''
        let idle_temperature_current_text_img = ''
        let idle_battery_linear_scale = ''
        let idle_battery_text_text_img = ''
        let idle_battery_text_separator_img = ''
        let idle_calorie_current_text_img = ''
        let idle_distance_TextRotate = new Array(5);
        let idle_distance_TextRotate_ASCIIARRAY = new Array(10);
        let idle_distance_TextRotate_img_width = 1;
        let idle_distance_TextRotate_unit = null;
        let idle_distance_TextRotate_unit_width = 52;
        let idle_distance_TextRotate_dot_width = 1;
        let idle_distance_TextRotate_error_img_width = 1;
        let idle_distance_text_text_img = ''
        let idle_heart_rate_text_text_img = ''
        let idle_step_current_text_img = ''
        let idle_date_img_date_day = ''
        let idle_date_img_date_week_img = ''
        let idle_digital_clock_img_time_minute = ''
        let idle_digital_clock_img_time_hour = ''
        let idle_digital_clock_hour_separator_img = ''


        let tap_battery = ''
        let tap_weather = ''
        let tap_steps = ''
        let tap_heart = ''
        let tap_calories = ''
        let tap_date = ''
        let tap_theme = '';
        let themeBattColor = 0xFF856C55;  // battery bar fill, follows the colour theme
        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            const themeGroups = [];
            const themeImgs = [];
            console.log('Watch_Face.ScreenNormal');
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 466,
              h: 466,
              src: 'Bg1.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            themeImgs.push({w: normal_background_bg_img, base: () => 'Bg1'});

            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 208,
              y: 47,
              image_array: ["Weather_icon_01.png","Weather_icon_02.png","Weather_icon_03.png","Weather_icon_04.png","Weather_icon_05.png","Weather_icon_06.png","Weather_icon_07.png","Weather_icon_08.png","Weather_icon_09.png","Weather_icon_10.png","Weather_icon_11.png","Weather_icon_12.png","Weather_icon_13.png","Weather_icon_14.png","Weather_icon_15.png","Weather_icon_16.png","Weather_icon_17.png","Weather_icon_18.png","Weather_icon_19.png","Weather_icon_20.png","Weather_icon_21.png","Weather_icon_22.png","Weather_icon_23.png","Weather_icon_24.png","Weather_icon_25.png","Weather_icon_26.png","Weather_icon_27.png","Weather_icon_28.png","Weather_icon_29.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            const normal_weather_image_progress_img_level_t1 = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 208,
              y: 47,
              image_array: ["Weather_icon_01_a.png","Weather_icon_02_a.png","Weather_icon_03_a.png","Weather_icon_04_a.png","Weather_icon_05_a.png","Weather_icon_06_a.png","Weather_icon_07_a.png","Weather_icon_08_a.png","Weather_icon_09_a.png","Weather_icon_10_a.png","Weather_icon_11_a.png","Weather_icon_12_a.png","Weather_icon_13_a.png","Weather_icon_14_a.png","Weather_icon_15_a.png","Weather_icon_16_a.png","Weather_icon_17_a.png","Weather_icon_18_a.png","Weather_icon_19_a.png","Weather_icon_20_a.png","Weather_icon_21_a.png","Weather_icon_22_a.png","Weather_icon_23_a.png","Weather_icon_24_a.png","Weather_icon_25_a.png","Weather_icon_26_a.png","Weather_icon_27_a.png","Weather_icon_28_a.png","Weather_icon_29_a.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            const normal_weather_image_progress_img_level_t2 = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 208,
              y: 47,
              image_array: ["Weather_icon_01_b.png","Weather_icon_02_b.png","Weather_icon_03_b.png","Weather_icon_04_b.png","Weather_icon_05_b.png","Weather_icon_06_b.png","Weather_icon_07_b.png","Weather_icon_08_b.png","Weather_icon_09_b.png","Weather_icon_10_b.png","Weather_icon_11_b.png","Weather_icon_12_b.png","Weather_icon_13_b.png","Weather_icon_14_b.png","Weather_icon_15_b.png","Weather_icon_16_b.png","Weather_icon_17_b.png","Weather_icon_18_b.png","Weather_icon_19_b.png","Weather_icon_20_b.png","Weather_icon_21_b.png","Weather_icon_22_b.png","Weather_icon_23_b.png","Weather_icon_24_b.png","Weather_icon_25_b.png","Weather_icon_26_b.png","Weather_icon_27_b.png","Weather_icon_28_b.png","Weather_icon_29_b.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            const normal_weather_image_progress_img_level_t3 = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 208,
              y: 47,
              image_array: ["Weather_icon_01_c.png","Weather_icon_02_c.png","Weather_icon_03_c.png","Weather_icon_04_c.png","Weather_icon_05_c.png","Weather_icon_06_c.png","Weather_icon_07_c.png","Weather_icon_08_c.png","Weather_icon_09_c.png","Weather_icon_10_c.png","Weather_icon_11_c.png","Weather_icon_12_c.png","Weather_icon_13_c.png","Weather_icon_14_c.png","Weather_icon_15_c.png","Weather_icon_16_c.png","Weather_icon_17_c.png","Weather_icon_18_c.png","Weather_icon_19_c.png","Weather_icon_20_c.png","Weather_icon_21_c.png","Weather_icon_22_c.png","Weather_icon_23_c.png","Weather_icon_24_c.png","Weather_icon_25_c.png","Weather_icon_26_c.png","Weather_icon_27_c.png","Weather_icon_28_c.png","Weather_icon_29_c.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            const normal_weather_image_progress_img_level_t4 = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 208,
              y: 47,
              image_array: ["Weather_icon_01_d.png","Weather_icon_02_d.png","Weather_icon_03_d.png","Weather_icon_04_d.png","Weather_icon_05_d.png","Weather_icon_06_d.png","Weather_icon_07_d.png","Weather_icon_08_d.png","Weather_icon_09_d.png","Weather_icon_10_d.png","Weather_icon_11_d.png","Weather_icon_12_d.png","Weather_icon_13_d.png","Weather_icon_14_d.png","Weather_icon_15_d.png","Weather_icon_16_d.png","Weather_icon_17_d.png","Weather_icon_18_d.png","Weather_icon_19_d.png","Weather_icon_20_d.png","Weather_icon_21_d.png","Weather_icon_22_d.png","Weather_icon_23_d.png","Weather_icon_24_d.png","Weather_icon_25_d.png","Weather_icon_26_d.png","Weather_icon_27_d.png","Weather_icon_28_d.png","Weather_icon_29_d.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            const normal_weather_image_progress_img_level_t5 = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 208,
              y: 47,
              image_array: ["Weather_icon_01_e.png","Weather_icon_02_e.png","Weather_icon_03_e.png","Weather_icon_04_e.png","Weather_icon_05_e.png","Weather_icon_06_e.png","Weather_icon_07_e.png","Weather_icon_08_e.png","Weather_icon_09_e.png","Weather_icon_10_e.png","Weather_icon_11_e.png","Weather_icon_12_e.png","Weather_icon_13_e.png","Weather_icon_14_e.png","Weather_icon_15_e.png","Weather_icon_16_e.png","Weather_icon_17_e.png","Weather_icon_18_e.png","Weather_icon_19_e.png","Weather_icon_20_e.png","Weather_icon_21_e.png","Weather_icon_22_e.png","Weather_icon_23_e.png","Weather_icon_24_e.png","Weather_icon_25_e.png","Weather_icon_26_e.png","Weather_icon_27_e.png","Weather_icon_28_e.png","Weather_icon_29_e.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            const normal_weather_image_progress_img_level_t6 = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 208,
              y: 47,
              image_array: ["Weather_icon_01_f.png","Weather_icon_02_f.png","Weather_icon_03_f.png","Weather_icon_04_f.png","Weather_icon_05_f.png","Weather_icon_06_f.png","Weather_icon_07_f.png","Weather_icon_08_f.png","Weather_icon_09_f.png","Weather_icon_10_f.png","Weather_icon_11_f.png","Weather_icon_12_f.png","Weather_icon_13_f.png","Weather_icon_14_f.png","Weather_icon_15_f.png","Weather_icon_16_f.png","Weather_icon_17_f.png","Weather_icon_18_f.png","Weather_icon_19_f.png","Weather_icon_20_f.png","Weather_icon_21_f.png","Weather_icon_22_f.png","Weather_icon_23_f.png","Weather_icon_24_f.png","Weather_icon_25_f.png","Weather_icon_26_f.png","Weather_icon_27_f.png","Weather_icon_28_f.png","Weather_icon_29_f.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            const normal_weather_image_progress_img_level_t7 = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 208,
              y: 47,
              image_array: ["Weather_icon_01_g.png","Weather_icon_02_g.png","Weather_icon_03_g.png","Weather_icon_04_g.png","Weather_icon_05_g.png","Weather_icon_06_g.png","Weather_icon_07_g.png","Weather_icon_08_g.png","Weather_icon_09_g.png","Weather_icon_10_g.png","Weather_icon_11_g.png","Weather_icon_12_g.png","Weather_icon_13_g.png","Weather_icon_14_g.png","Weather_icon_15_g.png","Weather_icon_16_g.png","Weather_icon_17_g.png","Weather_icon_18_g.png","Weather_icon_19_g.png","Weather_icon_20_g.png","Weather_icon_21_g.png","Weather_icon_22_g.png","Weather_icon_23_g.png","Weather_icon_24_g.png","Weather_icon_25_g.png","Weather_icon_26_g.png","Weather_icon_27_g.png","Weather_icon_28_g.png","Weather_icon_29_g.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            themeGroups.push([normal_weather_image_progress_img_level, normal_weather_image_progress_img_level_t1, normal_weather_image_progress_img_level_t2, normal_weather_image_progress_img_level_t3, normal_weather_image_progress_img_level_t4, normal_weather_image_progress_img_level_t5, normal_weather_image_progress_img_level_t6, normal_weather_image_progress_img_level_t7]);

            normal_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 194,
              y: 115,
              font_array: ["Act_0.png","Act_1.png","Act_2.png","Act_3.png","Act_4.png","Act_5.png","Act_6.png","Act_7.png","Act_8.png","Act_9.png"],
              padding: false,
              h_space: 1,
              unit_sc: 'Temp_unit.png',
              unit_tc: 'Temp_unit.png',
              unit_en: 'Temp_unit.png',
              imperial_unit_sc: 'Temp_unit.png',
              imperial_unit_tc: 'Temp_unit.png',
              imperial_unit_en: 'Temp_unit.png',
              negative_image: 'Temp_Error.png',
              invalid_image: 'Temp_Error.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            const temperatureUnit = hmSetting.getTemperatureUnit();
            //#region temperatureUnit
            if (temperatureUnit == 1) {
              normal_temperature_current_text_img.setProperty(hmUI.prop.MORE, {
                x: 194,
                y: 115,
                font_array: ["Act_0.png","Act_1.png","Act_2.png","Act_3.png","Act_4.png","Act_5.png","Act_6.png","Act_7.png","Act_8.png","Act_9.png"],
                padding: false,
                h_space: 1,
                unit_sc: 'Temp_unit.png',
                unit_tc: 'Temp_unit.png',
                unit_en: 'Temp_unit.png',
                imperial_unit_sc: 'Temp_unit.png',
                imperial_unit_tc: 'Temp_unit.png',
                imperial_unit_en: 'Temp_unit.png',
                negative_image: 'Temp_Error.png',
                invalid_image: 'Temp_Error.png',
                align_h: hmUI.align.CENTER_H,
                type: hmUI.data_type.WEATHER_CURRENT,
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
            };
            //#endregion

            let screenType = hmSetting.getScreenType();
            if (screenType != hmSetting.screen_type.AOD) {
              normal_battery_linear_scale = hmUI.createWidget(hmUI.widget.FILL_RECT);
            };

            // normal_battery_linear_scale = hmUI.createWidget(hmUI.widget.Linear_Scale, {
              // start_x: 83,
              // start_y: 81,
              // color: 0xFF856C55,
              // lenght: 30,
              // line_width: 11,
              // line_cap: Flat,
              // vertical: False,
              // mirror: False,
              // inversion: False,
              // alpha: 255,
              // type: hmUI.data_type.BATTERY,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });
            
            const battery = hmSensor.createSensor(hmSensor.id.BATTERY);
            battery.addEventListener(hmSensor.event.CHANGE, function() {
              scale_call();
            });

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 49,
              y: 118,
              font_array: ["Act_0.png","Act_1.png","Act_2.png","Act_3.png","Act_4.png","Act_5.png","Act_6.png","Act_7.png","Act_8.png","Act_9.png"],
              padding: false,
              h_space: 1,
              unit_sc: 'Batt_unit.png',
              unit_tc: 'Batt_unit.png',
              unit_en: 'Batt_unit.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 85,
              y: 80,
              src: 'FG_Batt.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_calorie_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 324,
              y: 322,
              font_array: ["Act_0.png","Act_1.png","Act_2.png","Act_3.png","Act_4.png","Act_5.png","Act_6.png","Act_7.png","Act_8.png","Act_9.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_distance_text_rotate_img = hmUI.createWidget(hmUI.widget.Text_Rotate, {
              // x: 337,
              // y: 369,
              // font_array: ["DisE0.png","DisE1.png","DisE2.png","DisE3.png","DisE4.png","DisE5.png","DisE6.png","DisE7.png","DisE8.png","DisE9.png"],
              // zero: false,
              // unit_in_alignment: false,
              // h_space: 0,
              // angle: 0,
              // unit_en: 'Dis_KM.png',
              // imperial_unit_en: 'Dis_Mi.png',
              // negative_image: 'DisE0.png',
              // invalid_image: 'DisE0.png',
              // dot_image: 'DisE0.png',
              // align_h: hmUI.align.LEFT,
              // type: hmUI.data_type.DISTANCE,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_distance_TextRotate_ASCIIARRAY[0] = 'DisE0.png';  // set of images with numbers
            normal_distance_TextRotate_ASCIIARRAY[1] = 'DisE1.png';  // set of images with numbers
            normal_distance_TextRotate_ASCIIARRAY[2] = 'DisE2.png';  // set of images with numbers
            normal_distance_TextRotate_ASCIIARRAY[3] = 'DisE3.png';  // set of images with numbers
            normal_distance_TextRotate_ASCIIARRAY[4] = 'DisE4.png';  // set of images with numbers
            normal_distance_TextRotate_ASCIIARRAY[5] = 'DisE5.png';  // set of images with numbers
            normal_distance_TextRotate_ASCIIARRAY[6] = 'DisE6.png';  // set of images with numbers
            normal_distance_TextRotate_ASCIIARRAY[7] = 'DisE7.png';  // set of images with numbers
            normal_distance_TextRotate_ASCIIARRAY[8] = 'DisE8.png';  // set of images with numbers
            normal_distance_TextRotate_ASCIIARRAY[9] = 'DisE9.png';  // set of images with numbers

            //#region TextRotate
            for (let i = 0; i < 5; i++) {
              normal_distance_TextRotate[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 466,
                h: 466,
                center_x: 337,
                center_y: 76,
                pos_x: 337,
                pos_y: 76,
                angle: 0,
                src: 'DisE0.png',
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
              normal_distance_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
            };

            normal_distance_TextRotate_unit = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 466,
              h: 466,
              center_x: 337,
              center_y: 76,
              pos_x: 337,
              pos_y: 76,
              angle: 0,
              src: 'Dis_KM.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            themeImgs.push({w: normal_distance_TextRotate_unit, base: () => (hmSetting.getMileageUnit() == 1 ? 'Dis_Mi' : 'Dis_KM')});
            normal_distance_TextRotate_unit.setProperty(hmUI.prop.VISIBLE, false);

            const mileageUnit = hmSetting.getMileageUnit();
            if (mileageUnit == 1) {
              normal_distance_TextRotate_unit.setProperty(hmUI.prop.SRC, 'Dis_Mi.png');
            };
            //#endregion
            
            const distance = hmSensor.createSensor(hmSensor.id.DISTANCE);
            distance.addEventListener(hmSensor.event.CHANGE, function() {
              text_update();
            });
            
            function toDegree (radian) {
              return radian * (180 / Math.PI);
            };

            normal_distance_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 323,
              y: 120,
              font_array: ["Act_0.png","Act_1.png","Act_2.png","Act_3.png","Act_4.png","Act_5.png","Act_6.png","Act_7.png","Act_8.png","Act_9.png"],
              padding: false,
              h_space: 0,
              dot_image: 'Dis_Dot.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.DISTANCE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 197,
              y: 322,
              font_array: ["Act_0.png","Act_1.png","Act_2.png","Act_3.png","Act_4.png","Act_5.png","Act_6.png","Act_7.png","Act_8.png","Act_9.png"],
              padding: true,
              h_space: 3,
              invalid_image: 'Act_0.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 36,
              y: 322,
              font_array: ["Act_0.png","Act_1.png","Act_2.png","Act_3.png","Act_4.png","Act_5.png","Act_6.png","Act_7.png","Act_8.png","Act_9.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 367,
              day_startY: 239,
              day_sc_array: ["Day_0.png","Day_1.png","Day_2.png","Day_3.png","Day_4.png","Day_5.png","Day_6.png","Day_7.png","Day_8.png","Day_9.png"],
              day_tc_array: ["Day_0.png","Day_1.png","Day_2.png","Day_3.png","Day_4.png","Day_5.png","Day_6.png","Day_7.png","Day_8.png","Day_9.png"],
              day_en_array: ["Day_0.png","Day_1.png","Day_2.png","Day_3.png","Day_4.png","Day_5.png","Day_6.png","Day_7.png","Day_8.png","Day_9.png"],
              day_zero: 0,
              day_space: 1,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            const normal_date_img_date_day_t1 = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 367,
              day_startY: 239,
              day_sc_array: ["Day_0_a.png","Day_1_a.png","Day_2_a.png","Day_3_a.png","Day_4_a.png","Day_5_a.png","Day_6_a.png","Day_7_a.png","Day_8_a.png","Day_9_a.png"],
              day_tc_array: ["Day_0_a.png","Day_1_a.png","Day_2_a.png","Day_3_a.png","Day_4_a.png","Day_5_a.png","Day_6_a.png","Day_7_a.png","Day_8_a.png","Day_9_a.png"],
              day_en_array: ["Day_0_a.png","Day_1_a.png","Day_2_a.png","Day_3_a.png","Day_4_a.png","Day_5_a.png","Day_6_a.png","Day_7_a.png","Day_8_a.png","Day_9_a.png"],
              day_zero: 0,
              day_space: 1,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            const normal_date_img_date_day_t2 = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 367,
              day_startY: 239,
              day_sc_array: ["Day_0_b.png","Day_1_b.png","Day_2_b.png","Day_3_b.png","Day_4_b.png","Day_5_b.png","Day_6_b.png","Day_7_b.png","Day_8_b.png","Day_9_b.png"],
              day_tc_array: ["Day_0_b.png","Day_1_b.png","Day_2_b.png","Day_3_b.png","Day_4_b.png","Day_5_b.png","Day_6_b.png","Day_7_b.png","Day_8_b.png","Day_9_b.png"],
              day_en_array: ["Day_0_b.png","Day_1_b.png","Day_2_b.png","Day_3_b.png","Day_4_b.png","Day_5_b.png","Day_6_b.png","Day_7_b.png","Day_8_b.png","Day_9_b.png"],
              day_zero: 0,
              day_space: 1,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            const normal_date_img_date_day_t3 = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 367,
              day_startY: 239,
              day_sc_array: ["Day_0_c.png","Day_1_c.png","Day_2_c.png","Day_3_c.png","Day_4_c.png","Day_5_c.png","Day_6_c.png","Day_7_c.png","Day_8_c.png","Day_9_c.png"],
              day_tc_array: ["Day_0_c.png","Day_1_c.png","Day_2_c.png","Day_3_c.png","Day_4_c.png","Day_5_c.png","Day_6_c.png","Day_7_c.png","Day_8_c.png","Day_9_c.png"],
              day_en_array: ["Day_0_c.png","Day_1_c.png","Day_2_c.png","Day_3_c.png","Day_4_c.png","Day_5_c.png","Day_6_c.png","Day_7_c.png","Day_8_c.png","Day_9_c.png"],
              day_zero: 0,
              day_space: 1,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            const normal_date_img_date_day_t4 = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 367,
              day_startY: 239,
              day_sc_array: ["Day_0_d.png","Day_1_d.png","Day_2_d.png","Day_3_d.png","Day_4_d.png","Day_5_d.png","Day_6_d.png","Day_7_d.png","Day_8_d.png","Day_9_d.png"],
              day_tc_array: ["Day_0_d.png","Day_1_d.png","Day_2_d.png","Day_3_d.png","Day_4_d.png","Day_5_d.png","Day_6_d.png","Day_7_d.png","Day_8_d.png","Day_9_d.png"],
              day_en_array: ["Day_0_d.png","Day_1_d.png","Day_2_d.png","Day_3_d.png","Day_4_d.png","Day_5_d.png","Day_6_d.png","Day_7_d.png","Day_8_d.png","Day_9_d.png"],
              day_zero: 0,
              day_space: 1,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            const normal_date_img_date_day_t5 = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 367,
              day_startY: 239,
              day_sc_array: ["Day_0_e.png","Day_1_e.png","Day_2_e.png","Day_3_e.png","Day_4_e.png","Day_5_e.png","Day_6_e.png","Day_7_e.png","Day_8_e.png","Day_9_e.png"],
              day_tc_array: ["Day_0_e.png","Day_1_e.png","Day_2_e.png","Day_3_e.png","Day_4_e.png","Day_5_e.png","Day_6_e.png","Day_7_e.png","Day_8_e.png","Day_9_e.png"],
              day_en_array: ["Day_0_e.png","Day_1_e.png","Day_2_e.png","Day_3_e.png","Day_4_e.png","Day_5_e.png","Day_6_e.png","Day_7_e.png","Day_8_e.png","Day_9_e.png"],
              day_zero: 0,
              day_space: 1,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            const normal_date_img_date_day_t6 = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 367,
              day_startY: 239,
              day_sc_array: ["Day_0_f.png","Day_1_f.png","Day_2_f.png","Day_3_f.png","Day_4_f.png","Day_5_f.png","Day_6_f.png","Day_7_f.png","Day_8_f.png","Day_9_f.png"],
              day_tc_array: ["Day_0_f.png","Day_1_f.png","Day_2_f.png","Day_3_f.png","Day_4_f.png","Day_5_f.png","Day_6_f.png","Day_7_f.png","Day_8_f.png","Day_9_f.png"],
              day_en_array: ["Day_0_f.png","Day_1_f.png","Day_2_f.png","Day_3_f.png","Day_4_f.png","Day_5_f.png","Day_6_f.png","Day_7_f.png","Day_8_f.png","Day_9_f.png"],
              day_zero: 0,
              day_space: 1,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            const normal_date_img_date_day_t7 = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 367,
              day_startY: 239,
              day_sc_array: ["Day_0_g.png","Day_1_g.png","Day_2_g.png","Day_3_g.png","Day_4_g.png","Day_5_g.png","Day_6_g.png","Day_7_g.png","Day_8_g.png","Day_9_g.png"],
              day_tc_array: ["Day_0_g.png","Day_1_g.png","Day_2_g.png","Day_3_g.png","Day_4_g.png","Day_5_g.png","Day_6_g.png","Day_7_g.png","Day_8_g.png","Day_9_g.png"],
              day_en_array: ["Day_0_g.png","Day_1_g.png","Day_2_g.png","Day_3_g.png","Day_4_g.png","Day_5_g.png","Day_6_g.png","Day_7_g.png","Day_8_g.png","Day_9_g.png"],
              day_zero: 0,
              day_space: 1,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            themeGroups.push([normal_date_img_date_day, normal_date_img_date_day_t1, normal_date_img_date_day_t2, normal_date_img_date_day_t3, normal_date_img_date_day_t4, normal_date_img_date_day_t5, normal_date_img_date_day_t6, normal_date_img_date_day_t7]);

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 347,
              y: 186,
              week_en: ["Week_1.png","Week_2.png","Week_3.png","Week_4.png","Week_5.png","Week_6.png","Week_7.png"],
              week_tc: ["Week_1.png","Week_2.png","Week_3.png","Week_4.png","Week_5.png","Week_6.png","Week_7.png"],
              week_sc: ["Week_1.png","Week_2.png","Week_3.png","Week_4.png","Week_5.png","Week_6.png","Week_7.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            const normal_date_img_date_week_img_t1 = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 347,
              y: 186,
              week_en: ["Week_1_a.png","Week_2_a.png","Week_3_a.png","Week_4_a.png","Week_5_a.png","Week_6_a.png","Week_7_a.png"],
              week_tc: ["Week_1_a.png","Week_2_a.png","Week_3_a.png","Week_4_a.png","Week_5_a.png","Week_6_a.png","Week_7_a.png"],
              week_sc: ["Week_1_a.png","Week_2_a.png","Week_3_a.png","Week_4_a.png","Week_5_a.png","Week_6_a.png","Week_7_a.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            const normal_date_img_date_week_img_t2 = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 347,
              y: 186,
              week_en: ["Week_1_b.png","Week_2_b.png","Week_3_b.png","Week_4_b.png","Week_5_b.png","Week_6_b.png","Week_7_b.png"],
              week_tc: ["Week_1_b.png","Week_2_b.png","Week_3_b.png","Week_4_b.png","Week_5_b.png","Week_6_b.png","Week_7_b.png"],
              week_sc: ["Week_1_b.png","Week_2_b.png","Week_3_b.png","Week_4_b.png","Week_5_b.png","Week_6_b.png","Week_7_b.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            const normal_date_img_date_week_img_t3 = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 347,
              y: 186,
              week_en: ["Week_1_c.png","Week_2_c.png","Week_3_c.png","Week_4_c.png","Week_5_c.png","Week_6_c.png","Week_7_c.png"],
              week_tc: ["Week_1_c.png","Week_2_c.png","Week_3_c.png","Week_4_c.png","Week_5_c.png","Week_6_c.png","Week_7_c.png"],
              week_sc: ["Week_1_c.png","Week_2_c.png","Week_3_c.png","Week_4_c.png","Week_5_c.png","Week_6_c.png","Week_7_c.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            const normal_date_img_date_week_img_t4 = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 347,
              y: 186,
              week_en: ["Week_1_d.png","Week_2_d.png","Week_3_d.png","Week_4_d.png","Week_5_d.png","Week_6_d.png","Week_7_d.png"],
              week_tc: ["Week_1_d.png","Week_2_d.png","Week_3_d.png","Week_4_d.png","Week_5_d.png","Week_6_d.png","Week_7_d.png"],
              week_sc: ["Week_1_d.png","Week_2_d.png","Week_3_d.png","Week_4_d.png","Week_5_d.png","Week_6_d.png","Week_7_d.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            const normal_date_img_date_week_img_t5 = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 347,
              y: 186,
              week_en: ["Week_1_e.png","Week_2_e.png","Week_3_e.png","Week_4_e.png","Week_5_e.png","Week_6_e.png","Week_7_e.png"],
              week_tc: ["Week_1_e.png","Week_2_e.png","Week_3_e.png","Week_4_e.png","Week_5_e.png","Week_6_e.png","Week_7_e.png"],
              week_sc: ["Week_1_e.png","Week_2_e.png","Week_3_e.png","Week_4_e.png","Week_5_e.png","Week_6_e.png","Week_7_e.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            const normal_date_img_date_week_img_t6 = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 347,
              y: 186,
              week_en: ["Week_1_f.png","Week_2_f.png","Week_3_f.png","Week_4_f.png","Week_5_f.png","Week_6_f.png","Week_7_f.png"],
              week_tc: ["Week_1_f.png","Week_2_f.png","Week_3_f.png","Week_4_f.png","Week_5_f.png","Week_6_f.png","Week_7_f.png"],
              week_sc: ["Week_1_f.png","Week_2_f.png","Week_3_f.png","Week_4_f.png","Week_5_f.png","Week_6_f.png","Week_7_f.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            const normal_date_img_date_week_img_t7 = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 347,
              y: 186,
              week_en: ["Week_1_g.png","Week_2_g.png","Week_3_g.png","Week_4_g.png","Week_5_g.png","Week_6_g.png","Week_7_g.png"],
              week_tc: ["Week_1_g.png","Week_2_g.png","Week_3_g.png","Week_4_g.png","Week_5_g.png","Week_6_g.png","Week_7_g.png"],
              week_sc: ["Week_1_g.png","Week_2_g.png","Week_3_g.png","Week_4_g.png","Week_5_g.png","Week_6_g.png","Week_7_g.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            themeGroups.push([normal_date_img_date_week_img, normal_date_img_date_week_img_t1, normal_date_img_date_week_img_t2, normal_date_img_date_week_img_t3, normal_date_img_date_week_img_t4, normal_date_img_date_week_img_t5, normal_date_img_date_week_img_t6, normal_date_img_date_week_img_t7]);

            normal_digital_clock_img_time_minute = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              minute_startX: 192,
              minute_startY: 185,
              minute_array: ["Time_0.png","Time_1.png","Time_2.png","Time_3.png","Time_4.png","Time_5.png","Time_6.png","Time_7.png","Time_8.png","Time_9.png"],
              minute_zero: 1,
              minute_space: 0,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            const normal_digital_clock_img_time_minute_t1 = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              minute_startX: 192,
              minute_startY: 185,
              minute_array: ["Time_0_a.png","Time_1_a.png","Time_2_a.png","Time_3_a.png","Time_4_a.png","Time_5_a.png","Time_6_a.png","Time_7_a.png","Time_8_a.png","Time_9_a.png"],
              minute_zero: 1,
              minute_space: 0,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            const normal_digital_clock_img_time_minute_t2 = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              minute_startX: 192,
              minute_startY: 185,
              minute_array: ["Time_0_b.png","Time_1_b.png","Time_2_b.png","Time_3_b.png","Time_4_b.png","Time_5_b.png","Time_6_b.png","Time_7_b.png","Time_8_b.png","Time_9_b.png"],
              minute_zero: 1,
              minute_space: 0,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            const normal_digital_clock_img_time_minute_t3 = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              minute_startX: 192,
              minute_startY: 185,
              minute_array: ["Time_0_c.png","Time_1_c.png","Time_2_c.png","Time_3_c.png","Time_4_c.png","Time_5_c.png","Time_6_c.png","Time_7_c.png","Time_8_c.png","Time_9_c.png"],
              minute_zero: 1,
              minute_space: 0,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            const normal_digital_clock_img_time_minute_t4 = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              minute_startX: 192,
              minute_startY: 185,
              minute_array: ["Time_0_d.png","Time_1_d.png","Time_2_d.png","Time_3_d.png","Time_4_d.png","Time_5_d.png","Time_6_d.png","Time_7_d.png","Time_8_d.png","Time_9_d.png"],
              minute_zero: 1,
              minute_space: 0,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            const normal_digital_clock_img_time_minute_t5 = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              minute_startX: 192,
              minute_startY: 185,
              minute_array: ["Time_0_e.png","Time_1_e.png","Time_2_e.png","Time_3_e.png","Time_4_e.png","Time_5_e.png","Time_6_e.png","Time_7_e.png","Time_8_e.png","Time_9_e.png"],
              minute_zero: 1,
              minute_space: 0,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            const normal_digital_clock_img_time_minute_t6 = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              minute_startX: 192,
              minute_startY: 185,
              minute_array: ["Time_0_f.png","Time_1_f.png","Time_2_f.png","Time_3_f.png","Time_4_f.png","Time_5_f.png","Time_6_f.png","Time_7_f.png","Time_8_f.png","Time_9_f.png"],
              minute_zero: 1,
              minute_space: 0,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            const normal_digital_clock_img_time_minute_t7 = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              minute_startX: 192,
              minute_startY: 185,
              minute_array: ["Time_0_g.png","Time_1_g.png","Time_2_g.png","Time_3_g.png","Time_4_g.png","Time_5_g.png","Time_6_g.png","Time_7_g.png","Time_8_g.png","Time_9_g.png"],
              minute_zero: 1,
              minute_space: 0,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            themeGroups.push([normal_digital_clock_img_time_minute, normal_digital_clock_img_time_minute_t1, normal_digital_clock_img_time_minute_t2, normal_digital_clock_img_time_minute_t3, normal_digital_clock_img_time_minute_t4, normal_digital_clock_img_time_minute_t5, normal_digital_clock_img_time_minute_t6, normal_digital_clock_img_time_minute_t7]);

            normal_digital_clock_img_time_hour = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 21,
              hour_startY: 185,
              hour_array: ["Time_0.png","Time_1.png","Time_2.png","Time_3.png","Time_4.png","Time_5.png","Time_6.png","Time_7.png","Time_8.png","Time_9.png"],
              hour_zero: 1,
              hour_space: 0,
              hour_angle: 0,
              hour_align: hmUI.align.LEFT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            const normal_digital_clock_img_time_hour_t1 = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 21,
              hour_startY: 185,
              hour_array: ["Time_0_a.png","Time_1_a.png","Time_2_a.png","Time_3_a.png","Time_4_a.png","Time_5_a.png","Time_6_a.png","Time_7_a.png","Time_8_a.png","Time_9_a.png"],
              hour_zero: 1,
              hour_space: 0,
              hour_angle: 0,
              hour_align: hmUI.align.LEFT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            const normal_digital_clock_img_time_hour_t2 = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 21,
              hour_startY: 185,
              hour_array: ["Time_0_b.png","Time_1_b.png","Time_2_b.png","Time_3_b.png","Time_4_b.png","Time_5_b.png","Time_6_b.png","Time_7_b.png","Time_8_b.png","Time_9_b.png"],
              hour_zero: 1,
              hour_space: 0,
              hour_angle: 0,
              hour_align: hmUI.align.LEFT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            const normal_digital_clock_img_time_hour_t3 = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 21,
              hour_startY: 185,
              hour_array: ["Time_0_c.png","Time_1_c.png","Time_2_c.png","Time_3_c.png","Time_4_c.png","Time_5_c.png","Time_6_c.png","Time_7_c.png","Time_8_c.png","Time_9_c.png"],
              hour_zero: 1,
              hour_space: 0,
              hour_angle: 0,
              hour_align: hmUI.align.LEFT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            const normal_digital_clock_img_time_hour_t4 = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 21,
              hour_startY: 185,
              hour_array: ["Time_0_d.png","Time_1_d.png","Time_2_d.png","Time_3_d.png","Time_4_d.png","Time_5_d.png","Time_6_d.png","Time_7_d.png","Time_8_d.png","Time_9_d.png"],
              hour_zero: 1,
              hour_space: 0,
              hour_angle: 0,
              hour_align: hmUI.align.LEFT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            const normal_digital_clock_img_time_hour_t5 = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 21,
              hour_startY: 185,
              hour_array: ["Time_0_e.png","Time_1_e.png","Time_2_e.png","Time_3_e.png","Time_4_e.png","Time_5_e.png","Time_6_e.png","Time_7_e.png","Time_8_e.png","Time_9_e.png"],
              hour_zero: 1,
              hour_space: 0,
              hour_angle: 0,
              hour_align: hmUI.align.LEFT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            const normal_digital_clock_img_time_hour_t6 = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 21,
              hour_startY: 185,
              hour_array: ["Time_0_f.png","Time_1_f.png","Time_2_f.png","Time_3_f.png","Time_4_f.png","Time_5_f.png","Time_6_f.png","Time_7_f.png","Time_8_f.png","Time_9_f.png"],
              hour_zero: 1,
              hour_space: 0,
              hour_angle: 0,
              hour_align: hmUI.align.LEFT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            const normal_digital_clock_img_time_hour_t7 = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 21,
              hour_startY: 185,
              hour_array: ["Time_0_g.png","Time_1_g.png","Time_2_g.png","Time_3_g.png","Time_4_g.png","Time_5_g.png","Time_6_g.png","Time_7_g.png","Time_8_g.png","Time_9_g.png"],
              hour_zero: 1,
              hour_space: 0,
              hour_angle: 0,
              hour_align: hmUI.align.LEFT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            themeGroups.push([normal_digital_clock_img_time_hour, normal_digital_clock_img_time_hour_t1, normal_digital_clock_img_time_hour_t2, normal_digital_clock_img_time_hour_t3, normal_digital_clock_img_time_hour_t4, normal_digital_clock_img_time_hour_t5, normal_digital_clock_img_time_hour_t6, normal_digital_clock_img_time_hour_t7]);

            normal_digital_clock_hour_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 143,
              y: 185,
              src: 'TimeDot.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            themeImgs.push({w: normal_digital_clock_hour_separator_img, base: () => 'TimeDot'});


            console.log('Watch_Face.ScreenAOD');
            idle_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 466,
              h: 466,
              src: 'Bg1.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });
            themeImgs.push({w: idle_background_bg_img, base: () => 'Bg1'});

            idle_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 208,
              y: 47,
              image_array: ["Weather_icon_01.png","Weather_icon_02.png","Weather_icon_03.png","Weather_icon_04.png","Weather_icon_05.png","Weather_icon_06.png","Weather_icon_07.png","Weather_icon_08.png","Weather_icon_09.png","Weather_icon_10.png","Weather_icon_11.png","Weather_icon_12.png","Weather_icon_13.png","Weather_icon_14.png","Weather_icon_15.png","Weather_icon_16.png","Weather_icon_17.png","Weather_icon_18.png","Weather_icon_19.png","Weather_icon_20.png","Weather_icon_21.png","Weather_icon_22.png","Weather_icon_23.png","Weather_icon_24.png","Weather_icon_25.png","Weather_icon_26.png","Weather_icon_27.png","Weather_icon_28.png","Weather_icon_29.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            const idle_weather_image_progress_img_level_t1 = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 208,
              y: 47,
              image_array: ["Weather_icon_01_a.png","Weather_icon_02_a.png","Weather_icon_03_a.png","Weather_icon_04_a.png","Weather_icon_05_a.png","Weather_icon_06_a.png","Weather_icon_07_a.png","Weather_icon_08_a.png","Weather_icon_09_a.png","Weather_icon_10_a.png","Weather_icon_11_a.png","Weather_icon_12_a.png","Weather_icon_13_a.png","Weather_icon_14_a.png","Weather_icon_15_a.png","Weather_icon_16_a.png","Weather_icon_17_a.png","Weather_icon_18_a.png","Weather_icon_19_a.png","Weather_icon_20_a.png","Weather_icon_21_a.png","Weather_icon_22_a.png","Weather_icon_23_a.png","Weather_icon_24_a.png","Weather_icon_25_a.png","Weather_icon_26_a.png","Weather_icon_27_a.png","Weather_icon_28_a.png","Weather_icon_29_a.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            const idle_weather_image_progress_img_level_t2 = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 208,
              y: 47,
              image_array: ["Weather_icon_01_b.png","Weather_icon_02_b.png","Weather_icon_03_b.png","Weather_icon_04_b.png","Weather_icon_05_b.png","Weather_icon_06_b.png","Weather_icon_07_b.png","Weather_icon_08_b.png","Weather_icon_09_b.png","Weather_icon_10_b.png","Weather_icon_11_b.png","Weather_icon_12_b.png","Weather_icon_13_b.png","Weather_icon_14_b.png","Weather_icon_15_b.png","Weather_icon_16_b.png","Weather_icon_17_b.png","Weather_icon_18_b.png","Weather_icon_19_b.png","Weather_icon_20_b.png","Weather_icon_21_b.png","Weather_icon_22_b.png","Weather_icon_23_b.png","Weather_icon_24_b.png","Weather_icon_25_b.png","Weather_icon_26_b.png","Weather_icon_27_b.png","Weather_icon_28_b.png","Weather_icon_29_b.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            const idle_weather_image_progress_img_level_t3 = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 208,
              y: 47,
              image_array: ["Weather_icon_01_c.png","Weather_icon_02_c.png","Weather_icon_03_c.png","Weather_icon_04_c.png","Weather_icon_05_c.png","Weather_icon_06_c.png","Weather_icon_07_c.png","Weather_icon_08_c.png","Weather_icon_09_c.png","Weather_icon_10_c.png","Weather_icon_11_c.png","Weather_icon_12_c.png","Weather_icon_13_c.png","Weather_icon_14_c.png","Weather_icon_15_c.png","Weather_icon_16_c.png","Weather_icon_17_c.png","Weather_icon_18_c.png","Weather_icon_19_c.png","Weather_icon_20_c.png","Weather_icon_21_c.png","Weather_icon_22_c.png","Weather_icon_23_c.png","Weather_icon_24_c.png","Weather_icon_25_c.png","Weather_icon_26_c.png","Weather_icon_27_c.png","Weather_icon_28_c.png","Weather_icon_29_c.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            const idle_weather_image_progress_img_level_t4 = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 208,
              y: 47,
              image_array: ["Weather_icon_01_d.png","Weather_icon_02_d.png","Weather_icon_03_d.png","Weather_icon_04_d.png","Weather_icon_05_d.png","Weather_icon_06_d.png","Weather_icon_07_d.png","Weather_icon_08_d.png","Weather_icon_09_d.png","Weather_icon_10_d.png","Weather_icon_11_d.png","Weather_icon_12_d.png","Weather_icon_13_d.png","Weather_icon_14_d.png","Weather_icon_15_d.png","Weather_icon_16_d.png","Weather_icon_17_d.png","Weather_icon_18_d.png","Weather_icon_19_d.png","Weather_icon_20_d.png","Weather_icon_21_d.png","Weather_icon_22_d.png","Weather_icon_23_d.png","Weather_icon_24_d.png","Weather_icon_25_d.png","Weather_icon_26_d.png","Weather_icon_27_d.png","Weather_icon_28_d.png","Weather_icon_29_d.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            const idle_weather_image_progress_img_level_t5 = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 208,
              y: 47,
              image_array: ["Weather_icon_01_e.png","Weather_icon_02_e.png","Weather_icon_03_e.png","Weather_icon_04_e.png","Weather_icon_05_e.png","Weather_icon_06_e.png","Weather_icon_07_e.png","Weather_icon_08_e.png","Weather_icon_09_e.png","Weather_icon_10_e.png","Weather_icon_11_e.png","Weather_icon_12_e.png","Weather_icon_13_e.png","Weather_icon_14_e.png","Weather_icon_15_e.png","Weather_icon_16_e.png","Weather_icon_17_e.png","Weather_icon_18_e.png","Weather_icon_19_e.png","Weather_icon_20_e.png","Weather_icon_21_e.png","Weather_icon_22_e.png","Weather_icon_23_e.png","Weather_icon_24_e.png","Weather_icon_25_e.png","Weather_icon_26_e.png","Weather_icon_27_e.png","Weather_icon_28_e.png","Weather_icon_29_e.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            const idle_weather_image_progress_img_level_t6 = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 208,
              y: 47,
              image_array: ["Weather_icon_01_f.png","Weather_icon_02_f.png","Weather_icon_03_f.png","Weather_icon_04_f.png","Weather_icon_05_f.png","Weather_icon_06_f.png","Weather_icon_07_f.png","Weather_icon_08_f.png","Weather_icon_09_f.png","Weather_icon_10_f.png","Weather_icon_11_f.png","Weather_icon_12_f.png","Weather_icon_13_f.png","Weather_icon_14_f.png","Weather_icon_15_f.png","Weather_icon_16_f.png","Weather_icon_17_f.png","Weather_icon_18_f.png","Weather_icon_19_f.png","Weather_icon_20_f.png","Weather_icon_21_f.png","Weather_icon_22_f.png","Weather_icon_23_f.png","Weather_icon_24_f.png","Weather_icon_25_f.png","Weather_icon_26_f.png","Weather_icon_27_f.png","Weather_icon_28_f.png","Weather_icon_29_f.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            const idle_weather_image_progress_img_level_t7 = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 208,
              y: 47,
              image_array: ["Weather_icon_01_g.png","Weather_icon_02_g.png","Weather_icon_03_g.png","Weather_icon_04_g.png","Weather_icon_05_g.png","Weather_icon_06_g.png","Weather_icon_07_g.png","Weather_icon_08_g.png","Weather_icon_09_g.png","Weather_icon_10_g.png","Weather_icon_11_g.png","Weather_icon_12_g.png","Weather_icon_13_g.png","Weather_icon_14_g.png","Weather_icon_15_g.png","Weather_icon_16_g.png","Weather_icon_17_g.png","Weather_icon_18_g.png","Weather_icon_19_g.png","Weather_icon_20_g.png","Weather_icon_21_g.png","Weather_icon_22_g.png","Weather_icon_23_g.png","Weather_icon_24_g.png","Weather_icon_25_g.png","Weather_icon_26_g.png","Weather_icon_27_g.png","Weather_icon_28_g.png","Weather_icon_29_g.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_AOD,
            });
            themeGroups.push([idle_weather_image_progress_img_level, idle_weather_image_progress_img_level_t1, idle_weather_image_progress_img_level_t2, idle_weather_image_progress_img_level_t3, idle_weather_image_progress_img_level_t4, idle_weather_image_progress_img_level_t5, idle_weather_image_progress_img_level_t6, idle_weather_image_progress_img_level_t7]);

            idle_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 194,
              y: 115,
              font_array: ["Act_0.png","Act_1.png","Act_2.png","Act_3.png","Act_4.png","Act_5.png","Act_6.png","Act_7.png","Act_8.png","Act_9.png"],
              padding: false,
              h_space: 1,
              unit_sc: 'Temp_unit.png',
              unit_tc: 'Temp_unit.png',
              unit_en: 'Temp_unit.png',
              imperial_unit_sc: 'Temp_unit.png',
              imperial_unit_tc: 'Temp_unit.png',
              imperial_unit_en: 'Temp_unit.png',
              negative_image: 'Temp_Error.png',
              invalid_image: 'Temp_Error.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            //#region temperatureUnit
            if (temperatureUnit == 1) {
              idle_temperature_current_text_img.setProperty(hmUI.prop.MORE, {
                x: 194,
                y: 115,
                font_array: ["Act_0.png","Act_1.png","Act_2.png","Act_3.png","Act_4.png","Act_5.png","Act_6.png","Act_7.png","Act_8.png","Act_9.png"],
                padding: false,
                h_space: 1,
                unit_sc: 'Temp_unit.png',
                unit_tc: 'Temp_unit.png',
                unit_en: 'Temp_unit.png',
                imperial_unit_sc: 'Temp_unit.png',
                imperial_unit_tc: 'Temp_unit.png',
                imperial_unit_en: 'Temp_unit.png',
                negative_image: 'Temp_Error.png',
                invalid_image: 'Temp_Error.png',
                align_h: hmUI.align.CENTER_H,
                type: hmUI.data_type.WEATHER_CURRENT,
                show_level: hmUI.show_level.ONLY_AOD,
              });
            };
            //#endregion

            if (screenType == hmSetting.screen_type.AOD) {
              idle_battery_linear_scale = hmUI.createWidget(hmUI.widget.FILL_RECT);
            };

            // idle_battery_linear_scale = hmUI.createWidget(hmUI.widget.Linear_Scale, {
              // start_x: 83,
              // start_y: 81,
              // color: 0xFF856C55,
              // lenght: 30,
              // line_width: 11,
              // line_cap: Flat,
              // vertical: False,
              // mirror: False,
              // inversion: False,
              // alpha: 255,
              // type: hmUI.data_type.BATTERY,
              // show_level: hmUI.show_level.ONLY_AOD,
            // });

            idle_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 49,
              y: 118,
              font_array: ["Act_0.png","Act_1.png","Act_2.png","Act_3.png","Act_4.png","Act_5.png","Act_6.png","Act_7.png","Act_8.png","Act_9.png"],
              padding: false,
              h_space: 1,
              unit_sc: 'Batt_unit.png',
              unit_tc: 'Batt_unit.png',
              unit_en: 'Batt_unit.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_battery_text_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 85,
              y: 80,
              src: 'FG_Batt.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_calorie_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 324,
              y: 322,
              font_array: ["Act_0.png","Act_1.png","Act_2.png","Act_3.png","Act_4.png","Act_5.png","Act_6.png","Act_7.png","Act_8.png","Act_9.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            // idle_distance_text_rotate_img = hmUI.createWidget(hmUI.widget.Text_Rotate, {
              // x: 337,
              // y: 369,
              // font_array: ["DisE0.png","DisE1.png","DisE2.png","DisE3.png","DisE4.png","DisE5.png","DisE6.png","DisE7.png","DisE8.png","DisE9.png"],
              // zero: false,
              // unit_in_alignment: false,
              // h_space: 0,
              // angle: 0,
              // unit_en: 'Dis_KM.png',
              // imperial_unit_en: 'Dis_Mi.png',
              // negative_image: 'DisE0.png',
              // invalid_image: 'DisE0.png',
              // dot_image: 'DisE0.png',
              // align_h: hmUI.align.LEFT,
              // type: hmUI.data_type.DISTANCE,
              // show_level: hmUI.show_level.ONLY_AOD,
            // });

            idle_distance_TextRotate_ASCIIARRAY[0] = 'DisE0.png';  // set of images with numbers
            idle_distance_TextRotate_ASCIIARRAY[1] = 'DisE1.png';  // set of images with numbers
            idle_distance_TextRotate_ASCIIARRAY[2] = 'DisE2.png';  // set of images with numbers
            idle_distance_TextRotate_ASCIIARRAY[3] = 'DisE3.png';  // set of images with numbers
            idle_distance_TextRotate_ASCIIARRAY[4] = 'DisE4.png';  // set of images with numbers
            idle_distance_TextRotate_ASCIIARRAY[5] = 'DisE5.png';  // set of images with numbers
            idle_distance_TextRotate_ASCIIARRAY[6] = 'DisE6.png';  // set of images with numbers
            idle_distance_TextRotate_ASCIIARRAY[7] = 'DisE7.png';  // set of images with numbers
            idle_distance_TextRotate_ASCIIARRAY[8] = 'DisE8.png';  // set of images with numbers
            idle_distance_TextRotate_ASCIIARRAY[9] = 'DisE9.png';  // set of images with numbers

            //#region TextRotate
            for (let i = 0; i < 5; i++) {
              idle_distance_TextRotate[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 466,
                h: 466,
                center_x: 337,
                center_y: 76,
                pos_x: 337,
                pos_y: 76,
                angle: 0,
                src: 'DisE0.png',
                show_level: hmUI.show_level.ONLY_AOD,
              });
              idle_distance_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
            };

            idle_distance_TextRotate_unit = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 466,
              h: 466,
              center_x: 337,
              center_y: 76,
              pos_x: 337,
              pos_y: 76,
              angle: 0,
              src: 'Dis_KM.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });
            themeImgs.push({w: idle_distance_TextRotate_unit, base: () => (hmSetting.getMileageUnit() == 1 ? 'Dis_Mi' : 'Dis_KM')});
            idle_distance_TextRotate_unit.setProperty(hmUI.prop.VISIBLE, false);

            if (mileageUnit == 1) {
              idle_distance_TextRotate_unit.setProperty(hmUI.prop.SRC, 'Dis_Mi.png');
            };
            //#endregion

            idle_distance_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 323,
              y: 120,
              font_array: ["Act_0.png","Act_1.png","Act_2.png","Act_3.png","Act_4.png","Act_5.png","Act_6.png","Act_7.png","Act_8.png","Act_9.png"],
              padding: false,
              h_space: 0,
              dot_image: 'Dis_Dot.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.DISTANCE,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 197,
              y: 322,
              font_array: ["Act_0.png","Act_1.png","Act_2.png","Act_3.png","Act_4.png","Act_5.png","Act_6.png","Act_7.png","Act_8.png","Act_9.png"],
              padding: true,
              h_space: 3,
              invalid_image: 'Act_0.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 36,
              y: 322,
              font_array: ["Act_0.png","Act_1.png","Act_2.png","Act_3.png","Act_4.png","Act_5.png","Act_6.png","Act_7.png","Act_8.png","Act_9.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 367,
              day_startY: 239,
              day_sc_array: ["Day_0.png","Day_1.png","Day_2.png","Day_3.png","Day_4.png","Day_5.png","Day_6.png","Day_7.png","Day_8.png","Day_9.png"],
              day_tc_array: ["Day_0.png","Day_1.png","Day_2.png","Day_3.png","Day_4.png","Day_5.png","Day_6.png","Day_7.png","Day_8.png","Day_9.png"],
              day_en_array: ["Day_0.png","Day_1.png","Day_2.png","Day_3.png","Day_4.png","Day_5.png","Day_6.png","Day_7.png","Day_8.png","Day_9.png"],
              day_zero: 0,
              day_space: 1,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            const idle_date_img_date_day_t1 = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 367,
              day_startY: 239,
              day_sc_array: ["Day_0_a.png","Day_1_a.png","Day_2_a.png","Day_3_a.png","Day_4_a.png","Day_5_a.png","Day_6_a.png","Day_7_a.png","Day_8_a.png","Day_9_a.png"],
              day_tc_array: ["Day_0_a.png","Day_1_a.png","Day_2_a.png","Day_3_a.png","Day_4_a.png","Day_5_a.png","Day_6_a.png","Day_7_a.png","Day_8_a.png","Day_9_a.png"],
              day_en_array: ["Day_0_a.png","Day_1_a.png","Day_2_a.png","Day_3_a.png","Day_4_a.png","Day_5_a.png","Day_6_a.png","Day_7_a.png","Day_8_a.png","Day_9_a.png"],
              day_zero: 0,
              day_space: 1,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            const idle_date_img_date_day_t2 = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 367,
              day_startY: 239,
              day_sc_array: ["Day_0_b.png","Day_1_b.png","Day_2_b.png","Day_3_b.png","Day_4_b.png","Day_5_b.png","Day_6_b.png","Day_7_b.png","Day_8_b.png","Day_9_b.png"],
              day_tc_array: ["Day_0_b.png","Day_1_b.png","Day_2_b.png","Day_3_b.png","Day_4_b.png","Day_5_b.png","Day_6_b.png","Day_7_b.png","Day_8_b.png","Day_9_b.png"],
              day_en_array: ["Day_0_b.png","Day_1_b.png","Day_2_b.png","Day_3_b.png","Day_4_b.png","Day_5_b.png","Day_6_b.png","Day_7_b.png","Day_8_b.png","Day_9_b.png"],
              day_zero: 0,
              day_space: 1,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            const idle_date_img_date_day_t3 = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 367,
              day_startY: 239,
              day_sc_array: ["Day_0_c.png","Day_1_c.png","Day_2_c.png","Day_3_c.png","Day_4_c.png","Day_5_c.png","Day_6_c.png","Day_7_c.png","Day_8_c.png","Day_9_c.png"],
              day_tc_array: ["Day_0_c.png","Day_1_c.png","Day_2_c.png","Day_3_c.png","Day_4_c.png","Day_5_c.png","Day_6_c.png","Day_7_c.png","Day_8_c.png","Day_9_c.png"],
              day_en_array: ["Day_0_c.png","Day_1_c.png","Day_2_c.png","Day_3_c.png","Day_4_c.png","Day_5_c.png","Day_6_c.png","Day_7_c.png","Day_8_c.png","Day_9_c.png"],
              day_zero: 0,
              day_space: 1,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            const idle_date_img_date_day_t4 = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 367,
              day_startY: 239,
              day_sc_array: ["Day_0_d.png","Day_1_d.png","Day_2_d.png","Day_3_d.png","Day_4_d.png","Day_5_d.png","Day_6_d.png","Day_7_d.png","Day_8_d.png","Day_9_d.png"],
              day_tc_array: ["Day_0_d.png","Day_1_d.png","Day_2_d.png","Day_3_d.png","Day_4_d.png","Day_5_d.png","Day_6_d.png","Day_7_d.png","Day_8_d.png","Day_9_d.png"],
              day_en_array: ["Day_0_d.png","Day_1_d.png","Day_2_d.png","Day_3_d.png","Day_4_d.png","Day_5_d.png","Day_6_d.png","Day_7_d.png","Day_8_d.png","Day_9_d.png"],
              day_zero: 0,
              day_space: 1,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            const idle_date_img_date_day_t5 = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 367,
              day_startY: 239,
              day_sc_array: ["Day_0_e.png","Day_1_e.png","Day_2_e.png","Day_3_e.png","Day_4_e.png","Day_5_e.png","Day_6_e.png","Day_7_e.png","Day_8_e.png","Day_9_e.png"],
              day_tc_array: ["Day_0_e.png","Day_1_e.png","Day_2_e.png","Day_3_e.png","Day_4_e.png","Day_5_e.png","Day_6_e.png","Day_7_e.png","Day_8_e.png","Day_9_e.png"],
              day_en_array: ["Day_0_e.png","Day_1_e.png","Day_2_e.png","Day_3_e.png","Day_4_e.png","Day_5_e.png","Day_6_e.png","Day_7_e.png","Day_8_e.png","Day_9_e.png"],
              day_zero: 0,
              day_space: 1,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            const idle_date_img_date_day_t6 = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 367,
              day_startY: 239,
              day_sc_array: ["Day_0_f.png","Day_1_f.png","Day_2_f.png","Day_3_f.png","Day_4_f.png","Day_5_f.png","Day_6_f.png","Day_7_f.png","Day_8_f.png","Day_9_f.png"],
              day_tc_array: ["Day_0_f.png","Day_1_f.png","Day_2_f.png","Day_3_f.png","Day_4_f.png","Day_5_f.png","Day_6_f.png","Day_7_f.png","Day_8_f.png","Day_9_f.png"],
              day_en_array: ["Day_0_f.png","Day_1_f.png","Day_2_f.png","Day_3_f.png","Day_4_f.png","Day_5_f.png","Day_6_f.png","Day_7_f.png","Day_8_f.png","Day_9_f.png"],
              day_zero: 0,
              day_space: 1,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            const idle_date_img_date_day_t7 = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 367,
              day_startY: 239,
              day_sc_array: ["Day_0_g.png","Day_1_g.png","Day_2_g.png","Day_3_g.png","Day_4_g.png","Day_5_g.png","Day_6_g.png","Day_7_g.png","Day_8_g.png","Day_9_g.png"],
              day_tc_array: ["Day_0_g.png","Day_1_g.png","Day_2_g.png","Day_3_g.png","Day_4_g.png","Day_5_g.png","Day_6_g.png","Day_7_g.png","Day_8_g.png","Day_9_g.png"],
              day_en_array: ["Day_0_g.png","Day_1_g.png","Day_2_g.png","Day_3_g.png","Day_4_g.png","Day_5_g.png","Day_6_g.png","Day_7_g.png","Day_8_g.png","Day_9_g.png"],
              day_zero: 0,
              day_space: 1,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_AOD,
            });
            themeGroups.push([idle_date_img_date_day, idle_date_img_date_day_t1, idle_date_img_date_day_t2, idle_date_img_date_day_t3, idle_date_img_date_day_t4, idle_date_img_date_day_t5, idle_date_img_date_day_t6, idle_date_img_date_day_t7]);

            idle_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 347,
              y: 186,
              week_en: ["Week_1.png","Week_2.png","Week_3.png","Week_4.png","Week_5.png","Week_6.png","Week_7.png"],
              week_tc: ["Week_1.png","Week_2.png","Week_3.png","Week_4.png","Week_5.png","Week_6.png","Week_7.png"],
              week_sc: ["Week_1.png","Week_2.png","Week_3.png","Week_4.png","Week_5.png","Week_6.png","Week_7.png"],
              show_level: hmUI.show_level.ONLY_AOD,
            });

            const idle_date_img_date_week_img_t1 = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 347,
              y: 186,
              week_en: ["Week_1_a.png","Week_2_a.png","Week_3_a.png","Week_4_a.png","Week_5_a.png","Week_6_a.png","Week_7_a.png"],
              week_tc: ["Week_1_a.png","Week_2_a.png","Week_3_a.png","Week_4_a.png","Week_5_a.png","Week_6_a.png","Week_7_a.png"],
              week_sc: ["Week_1_a.png","Week_2_a.png","Week_3_a.png","Week_4_a.png","Week_5_a.png","Week_6_a.png","Week_7_a.png"],
              show_level: hmUI.show_level.ONLY_AOD,
            });

            const idle_date_img_date_week_img_t2 = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 347,
              y: 186,
              week_en: ["Week_1_b.png","Week_2_b.png","Week_3_b.png","Week_4_b.png","Week_5_b.png","Week_6_b.png","Week_7_b.png"],
              week_tc: ["Week_1_b.png","Week_2_b.png","Week_3_b.png","Week_4_b.png","Week_5_b.png","Week_6_b.png","Week_7_b.png"],
              week_sc: ["Week_1_b.png","Week_2_b.png","Week_3_b.png","Week_4_b.png","Week_5_b.png","Week_6_b.png","Week_7_b.png"],
              show_level: hmUI.show_level.ONLY_AOD,
            });

            const idle_date_img_date_week_img_t3 = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 347,
              y: 186,
              week_en: ["Week_1_c.png","Week_2_c.png","Week_3_c.png","Week_4_c.png","Week_5_c.png","Week_6_c.png","Week_7_c.png"],
              week_tc: ["Week_1_c.png","Week_2_c.png","Week_3_c.png","Week_4_c.png","Week_5_c.png","Week_6_c.png","Week_7_c.png"],
              week_sc: ["Week_1_c.png","Week_2_c.png","Week_3_c.png","Week_4_c.png","Week_5_c.png","Week_6_c.png","Week_7_c.png"],
              show_level: hmUI.show_level.ONLY_AOD,
            });

            const idle_date_img_date_week_img_t4 = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 347,
              y: 186,
              week_en: ["Week_1_d.png","Week_2_d.png","Week_3_d.png","Week_4_d.png","Week_5_d.png","Week_6_d.png","Week_7_d.png"],
              week_tc: ["Week_1_d.png","Week_2_d.png","Week_3_d.png","Week_4_d.png","Week_5_d.png","Week_6_d.png","Week_7_d.png"],
              week_sc: ["Week_1_d.png","Week_2_d.png","Week_3_d.png","Week_4_d.png","Week_5_d.png","Week_6_d.png","Week_7_d.png"],
              show_level: hmUI.show_level.ONLY_AOD,
            });

            const idle_date_img_date_week_img_t5 = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 347,
              y: 186,
              week_en: ["Week_1_e.png","Week_2_e.png","Week_3_e.png","Week_4_e.png","Week_5_e.png","Week_6_e.png","Week_7_e.png"],
              week_tc: ["Week_1_e.png","Week_2_e.png","Week_3_e.png","Week_4_e.png","Week_5_e.png","Week_6_e.png","Week_7_e.png"],
              week_sc: ["Week_1_e.png","Week_2_e.png","Week_3_e.png","Week_4_e.png","Week_5_e.png","Week_6_e.png","Week_7_e.png"],
              show_level: hmUI.show_level.ONLY_AOD,
            });

            const idle_date_img_date_week_img_t6 = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 347,
              y: 186,
              week_en: ["Week_1_f.png","Week_2_f.png","Week_3_f.png","Week_4_f.png","Week_5_f.png","Week_6_f.png","Week_7_f.png"],
              week_tc: ["Week_1_f.png","Week_2_f.png","Week_3_f.png","Week_4_f.png","Week_5_f.png","Week_6_f.png","Week_7_f.png"],
              week_sc: ["Week_1_f.png","Week_2_f.png","Week_3_f.png","Week_4_f.png","Week_5_f.png","Week_6_f.png","Week_7_f.png"],
              show_level: hmUI.show_level.ONLY_AOD,
            });

            const idle_date_img_date_week_img_t7 = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 347,
              y: 186,
              week_en: ["Week_1_g.png","Week_2_g.png","Week_3_g.png","Week_4_g.png","Week_5_g.png","Week_6_g.png","Week_7_g.png"],
              week_tc: ["Week_1_g.png","Week_2_g.png","Week_3_g.png","Week_4_g.png","Week_5_g.png","Week_6_g.png","Week_7_g.png"],
              week_sc: ["Week_1_g.png","Week_2_g.png","Week_3_g.png","Week_4_g.png","Week_5_g.png","Week_6_g.png","Week_7_g.png"],
              show_level: hmUI.show_level.ONLY_AOD,
            });
            themeGroups.push([idle_date_img_date_week_img, idle_date_img_date_week_img_t1, idle_date_img_date_week_img_t2, idle_date_img_date_week_img_t3, idle_date_img_date_week_img_t4, idle_date_img_date_week_img_t5, idle_date_img_date_week_img_t6, idle_date_img_date_week_img_t7]);

            idle_digital_clock_img_time_minute = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              minute_startX: 192,
              minute_startY: 185,
              minute_array: ["Time_0.png","Time_1.png","Time_2.png","Time_3.png","Time_4.png","Time_5.png","Time_6.png","Time_7.png","Time_8.png","Time_9.png"],
              minute_zero: 1,
              minute_space: 0,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            const idle_digital_clock_img_time_minute_t1 = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              minute_startX: 192,
              minute_startY: 185,
              minute_array: ["Time_0_a.png","Time_1_a.png","Time_2_a.png","Time_3_a.png","Time_4_a.png","Time_5_a.png","Time_6_a.png","Time_7_a.png","Time_8_a.png","Time_9_a.png"],
              minute_zero: 1,
              minute_space: 0,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            const idle_digital_clock_img_time_minute_t2 = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              minute_startX: 192,
              minute_startY: 185,
              minute_array: ["Time_0_b.png","Time_1_b.png","Time_2_b.png","Time_3_b.png","Time_4_b.png","Time_5_b.png","Time_6_b.png","Time_7_b.png","Time_8_b.png","Time_9_b.png"],
              minute_zero: 1,
              minute_space: 0,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            const idle_digital_clock_img_time_minute_t3 = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              minute_startX: 192,
              minute_startY: 185,
              minute_array: ["Time_0_c.png","Time_1_c.png","Time_2_c.png","Time_3_c.png","Time_4_c.png","Time_5_c.png","Time_6_c.png","Time_7_c.png","Time_8_c.png","Time_9_c.png"],
              minute_zero: 1,
              minute_space: 0,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            const idle_digital_clock_img_time_minute_t4 = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              minute_startX: 192,
              minute_startY: 185,
              minute_array: ["Time_0_d.png","Time_1_d.png","Time_2_d.png","Time_3_d.png","Time_4_d.png","Time_5_d.png","Time_6_d.png","Time_7_d.png","Time_8_d.png","Time_9_d.png"],
              minute_zero: 1,
              minute_space: 0,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            const idle_digital_clock_img_time_minute_t5 = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              minute_startX: 192,
              minute_startY: 185,
              minute_array: ["Time_0_e.png","Time_1_e.png","Time_2_e.png","Time_3_e.png","Time_4_e.png","Time_5_e.png","Time_6_e.png","Time_7_e.png","Time_8_e.png","Time_9_e.png"],
              minute_zero: 1,
              minute_space: 0,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            const idle_digital_clock_img_time_minute_t6 = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              minute_startX: 192,
              minute_startY: 185,
              minute_array: ["Time_0_f.png","Time_1_f.png","Time_2_f.png","Time_3_f.png","Time_4_f.png","Time_5_f.png","Time_6_f.png","Time_7_f.png","Time_8_f.png","Time_9_f.png"],
              minute_zero: 1,
              minute_space: 0,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            const idle_digital_clock_img_time_minute_t7 = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              minute_startX: 192,
              minute_startY: 185,
              minute_array: ["Time_0_g.png","Time_1_g.png","Time_2_g.png","Time_3_g.png","Time_4_g.png","Time_5_g.png","Time_6_g.png","Time_7_g.png","Time_8_g.png","Time_9_g.png"],
              minute_zero: 1,
              minute_space: 0,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,
              show_level: hmUI.show_level.ONLY_AOD,
            });
            themeGroups.push([idle_digital_clock_img_time_minute, idle_digital_clock_img_time_minute_t1, idle_digital_clock_img_time_minute_t2, idle_digital_clock_img_time_minute_t3, idle_digital_clock_img_time_minute_t4, idle_digital_clock_img_time_minute_t5, idle_digital_clock_img_time_minute_t6, idle_digital_clock_img_time_minute_t7]);

            idle_digital_clock_img_time_hour = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 21,
              hour_startY: 185,
              hour_array: ["Time_0.png","Time_1.png","Time_2.png","Time_3.png","Time_4.png","Time_5.png","Time_6.png","Time_7.png","Time_8.png","Time_9.png"],
              hour_zero: 1,
              hour_space: 0,
              hour_angle: 0,
              hour_align: hmUI.align.LEFT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            const idle_digital_clock_img_time_hour_t1 = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 21,
              hour_startY: 185,
              hour_array: ["Time_0_a.png","Time_1_a.png","Time_2_a.png","Time_3_a.png","Time_4_a.png","Time_5_a.png","Time_6_a.png","Time_7_a.png","Time_8_a.png","Time_9_a.png"],
              hour_zero: 1,
              hour_space: 0,
              hour_angle: 0,
              hour_align: hmUI.align.LEFT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            const idle_digital_clock_img_time_hour_t2 = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 21,
              hour_startY: 185,
              hour_array: ["Time_0_b.png","Time_1_b.png","Time_2_b.png","Time_3_b.png","Time_4_b.png","Time_5_b.png","Time_6_b.png","Time_7_b.png","Time_8_b.png","Time_9_b.png"],
              hour_zero: 1,
              hour_space: 0,
              hour_angle: 0,
              hour_align: hmUI.align.LEFT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            const idle_digital_clock_img_time_hour_t3 = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 21,
              hour_startY: 185,
              hour_array: ["Time_0_c.png","Time_1_c.png","Time_2_c.png","Time_3_c.png","Time_4_c.png","Time_5_c.png","Time_6_c.png","Time_7_c.png","Time_8_c.png","Time_9_c.png"],
              hour_zero: 1,
              hour_space: 0,
              hour_angle: 0,
              hour_align: hmUI.align.LEFT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            const idle_digital_clock_img_time_hour_t4 = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 21,
              hour_startY: 185,
              hour_array: ["Time_0_d.png","Time_1_d.png","Time_2_d.png","Time_3_d.png","Time_4_d.png","Time_5_d.png","Time_6_d.png","Time_7_d.png","Time_8_d.png","Time_9_d.png"],
              hour_zero: 1,
              hour_space: 0,
              hour_angle: 0,
              hour_align: hmUI.align.LEFT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            const idle_digital_clock_img_time_hour_t5 = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 21,
              hour_startY: 185,
              hour_array: ["Time_0_e.png","Time_1_e.png","Time_2_e.png","Time_3_e.png","Time_4_e.png","Time_5_e.png","Time_6_e.png","Time_7_e.png","Time_8_e.png","Time_9_e.png"],
              hour_zero: 1,
              hour_space: 0,
              hour_angle: 0,
              hour_align: hmUI.align.LEFT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            const idle_digital_clock_img_time_hour_t6 = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 21,
              hour_startY: 185,
              hour_array: ["Time_0_f.png","Time_1_f.png","Time_2_f.png","Time_3_f.png","Time_4_f.png","Time_5_f.png","Time_6_f.png","Time_7_f.png","Time_8_f.png","Time_9_f.png"],
              hour_zero: 1,
              hour_space: 0,
              hour_angle: 0,
              hour_align: hmUI.align.LEFT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            const idle_digital_clock_img_time_hour_t7 = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 21,
              hour_startY: 185,
              hour_array: ["Time_0_g.png","Time_1_g.png","Time_2_g.png","Time_3_g.png","Time_4_g.png","Time_5_g.png","Time_6_g.png","Time_7_g.png","Time_8_g.png","Time_9_g.png"],
              hour_zero: 1,
              hour_space: 0,
              hour_angle: 0,
              hour_align: hmUI.align.LEFT,
              show_level: hmUI.show_level.ONLY_AOD,
            });
            themeGroups.push([idle_digital_clock_img_time_hour, idle_digital_clock_img_time_hour_t1, idle_digital_clock_img_time_hour_t2, idle_digital_clock_img_time_hour_t3, idle_digital_clock_img_time_hour_t4, idle_digital_clock_img_time_hour_t5, idle_digital_clock_img_time_hour_t6, idle_digital_clock_img_time_hour_t7]);

            idle_digital_clock_hour_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 143,
              y: 185,
              src: 'TimeDot.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });
            themeImgs.push({w: idle_digital_clock_hour_separator_img, base: () => 'TimeDot'});

            console.log('Watch_Face.Shortcuts');
            tap_battery = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 30,
              y: 55,
              w: 128,
              h: 100,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            tap_weather = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 168,
              y: 28,
              w: 132,
              h: 124,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            tap_steps = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 36,
              y: 318,
              w: 122,
              h: 92,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            tap_heart = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 168,
              y: 318,
              w: 132,
              h: 92,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            tap_calories = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 308,
              y: 318,
              w: 84,
              h: 92,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            tap_date = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 350,
              y: 180,
              w: 108,
              h: 96,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'ScheduleCalScreen', native: true });
              },
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            console.log('Watch_Face.ColorTheme');
            const THEME_SUFFIX = ["", "_a", "_b", "_c", "_d", "_e", "_f", "_g"];
            const THEME_NAMES = ["BROWN", "GREY", "BLUE GREY", "SAFFRON ORANGE", "RED", "YELLOW", "CAMO GREEN", "COTTON CANDY"];
            const BATT_COLORS = [0xFF856C55, 0xFF848482, 0xFF6699CC, 0xFFFF9933, 0xFFE30022, 0xFFFFF600, 0xFF78866B, 0xFFFFBCD9];
            const THEME_COUNT = THEME_SUFFIX.length;
            let themeWfId = 'garmin_reborn';
            try { themeWfId = hmApp.packageInfo().watchfaceId; } catch (e) {}
            let themeIndex = 0;
            try {
              const saved = hmFS.SysProGetInt('garminRebornTheme3_' + themeWfId);
              if (saved !== undefined && saved !== null && saved >= 0 && saved < THEME_COUNT) themeIndex = saved;
            } catch (e) {}

            function applyTheme(i) {
              themeBattColor = BATT_COLORS[i];
              try { scale_call(); } catch (e) {}
              themeGroups.forEach(function (g) {
                g.forEach(function (w, k) {
                  try { w.setProperty(hmUI.prop.VISIBLE, k === i); } catch (e) {}
                });
              });
              themeImgs.forEach(function (o) {
                try { o.w.setProperty(hmUI.prop.SRC, o.base() + THEME_SUFFIX[i] + '.png'); } catch (e) {}
              });
            }
            applyTheme(themeIndex);

            // tap the clock to cycle through the colours
            tap_theme = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 20,
              y: 180,
              w: 325,
              h: 100,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                themeIndex = (themeIndex + 1) % THEME_COUNT;
                try { hmFS.SysProSetInt('garminRebornTheme3_' + themeWfId, themeIndex); } catch (e) {}
                applyTheme(themeIndex);
                try { hmUI.showToast({text: THEME_NAMES[themeIndex]}); } catch (e) {}
              },
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            //#region text_update
            function text_update() {
              console.log('text_update()');

              console.log('update text rotate DISTANCE');
              let distanceCurrent = distance.current;
              let normal_distance_rotate_string = (distanceCurrent / 1000).toFixed(2);
              if (mileageUnit == 1) normal_distance_rotate_string = (0.621371 * distanceCurrent / 1000).toFixed(2);

              if (screenType != hmSetting.screen_type.AOD) {
                for (var i = 1; i < 5; i++) {  // hide all symbols
                  normal_distance_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                normal_distance_TextRotate_unit.setProperty(hmUI.prop.VISIBLE, false);
                if (distanceCurrent != null && distanceCurrent != undefined && isFinite(distanceCurrent) && normal_distance_rotate_string.length > 0 && normal_distance_rotate_string.length <= 5) {  // display data if it was possible to get it
                  let img_offset = 0;
                  
                  let index = 0;
                  for (let char of normal_distance_rotate_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 5) break;
                    if (charCode >= 0 && charCode < 10) { 
                      normal_distance_TextRotate[index].setProperty(hmUI.prop.POS_X, 337 + img_offset);
                      normal_distance_TextRotate[index].setProperty(hmUI.prop.SRC, normal_distance_TextRotate_ASCIIARRAY[charCode]);
                      normal_distance_TextRotate[index].setProperty(hmUI.prop.VISIBLE, true);
                      img_offset += normal_distance_TextRotate_img_width;
                      index++;
                    }  // end if digit
                    else { 
                      normal_distance_TextRotate[index].setProperty(hmUI.prop.POS_X, 337 + img_offset);
                      normal_distance_TextRotate[index].setProperty(hmUI.prop.SRC, 'DisE0.png');
                      normal_distance_TextRotate[index].setProperty(hmUI.prop.VISIBLE, true);
                      img_offset += normal_distance_TextRotate_dot_width;
                      index++;
                    };  // end if dot point 
                  };  // end char of string
                  normal_distance_TextRotate_unit.setProperty(hmUI.prop.POS_X, 337 + img_offset);
                  normal_distance_TextRotate_unit.setProperty(hmUI.prop.VISIBLE, true);
                }  // end isFinite
                else {
                  normal_distance_TextRotate[0].setProperty(hmUI.prop.POS_X, 337);
                  normal_distance_TextRotate[0].setProperty(hmUI.prop.SRC, 'DisE0.png');
                  normal_distance_TextRotate[0].setProperty(hmUI.prop.VISIBLE, true);
                };  // end else isFinite

              };

              console.log('update text rotate DISTANCE');
              let idle_distance_rotate_string = (distanceCurrent / 1000).toFixed(2);
              if (mileageUnit == 1) idle_distance_rotate_string = (0.621371 * distanceCurrent / 1000).toFixed(2);

              if (screenType == hmSetting.screen_type.AOD) {
                for (var i = 1; i < 5; i++) {  // hide all symbols
                  idle_distance_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                idle_distance_TextRotate_unit.setProperty(hmUI.prop.VISIBLE, false);
                if (distanceCurrent != null && distanceCurrent != undefined && isFinite(distanceCurrent) && idle_distance_rotate_string.length > 0 && idle_distance_rotate_string.length <= 5) {  // display data if it was possible to get it
                  let img_offset = 0;
                  
                  let index = 0;
                  for (let char of idle_distance_rotate_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 5) break;
                    if (charCode >= 0 && charCode < 10) { 
                      idle_distance_TextRotate[index].setProperty(hmUI.prop.POS_X, 337 + img_offset);
                      idle_distance_TextRotate[index].setProperty(hmUI.prop.SRC, idle_distance_TextRotate_ASCIIARRAY[charCode]);
                      idle_distance_TextRotate[index].setProperty(hmUI.prop.VISIBLE, true);
                      img_offset += idle_distance_TextRotate_img_width;
                      index++;
                    }  // end if digit
                    else { 
                      idle_distance_TextRotate[index].setProperty(hmUI.prop.POS_X, 337 + img_offset);
                      idle_distance_TextRotate[index].setProperty(hmUI.prop.SRC, 'DisE0.png');
                      idle_distance_TextRotate[index].setProperty(hmUI.prop.VISIBLE, true);
                      img_offset += idle_distance_TextRotate_dot_width;
                      index++;
                    };  // end if dot point 
                  };  // end char of string
                  idle_distance_TextRotate_unit.setProperty(hmUI.prop.POS_X, 337 + img_offset);
                  idle_distance_TextRotate_unit.setProperty(hmUI.prop.VISIBLE, true);
                }  // end isFinite
                else {
                  idle_distance_TextRotate[0].setProperty(hmUI.prop.POS_X, 337);
                  idle_distance_TextRotate[0].setProperty(hmUI.prop.SRC, 'DisE0.png');
                  idle_distance_TextRotate[0].setProperty(hmUI.prop.VISIBLE, true);
                };  // end else isFinite

              };

            };

            //#endregion
            function scale_call() {
              console.log('scale_call()');

                console.log('update scales BATTERY');
                
                let valueBattery = battery.current;
                let targetBattery = 100;
                let progressBattery = valueBattery/targetBattery;
                if (progressBattery > 1) progressBattery = 1;
                let progress_ls_normal_battery = progressBattery;

                if (screenType != hmSetting.screen_type.AOD) {

                  // normal_battery_linear_scale
                  // initial parameters
                  let start_x_normal_battery = 83;
                  let start_y_normal_battery = 81;
                  let lenght_ls_normal_battery = 30;
                  let line_width_ls_normal_battery = 11;
                  let color_ls_normal_battery = themeBattColor;
                  
                  // calculated parameters
                  let start_x_normal_battery_draw = start_x_normal_battery;
                  let start_y_normal_battery_draw = start_y_normal_battery;
                  lenght_ls_normal_battery = lenght_ls_normal_battery * progress_ls_normal_battery;
                  let lenght_ls_normal_battery_draw = lenght_ls_normal_battery;
                  let line_width_ls_normal_battery_draw = line_width_ls_normal_battery;
                  if (lenght_ls_normal_battery < 0){
                    lenght_ls_normal_battery_draw = -lenght_ls_normal_battery;
                    start_x_normal_battery_draw = start_x_normal_battery - lenght_ls_normal_battery_draw;
                  };
                  
                  normal_battery_linear_scale.setProperty(hmUI.prop.MORE, {
                    x: start_x_normal_battery_draw,
                    y: start_y_normal_battery_draw,
                    w: lenght_ls_normal_battery_draw,
                    h: line_width_ls_normal_battery_draw,
                    color: color_ls_normal_battery,
                  });
                };

                console.log('update scales BATTERY');
                let progress_ls_idle_battery = progressBattery;

                if (screenType == hmSetting.screen_type.AOD) {

                  // idle_battery_linear_scale
                  // initial parameters
                  let start_x_idle_battery = 83;
                  let start_y_idle_battery = 81;
                  let lenght_ls_idle_battery = 30;
                  let line_width_ls_idle_battery = 11;
                  let color_ls_idle_battery = themeBattColor;
                  
                  // calculated parameters
                  let start_x_idle_battery_draw = start_x_idle_battery;
                  let start_y_idle_battery_draw = start_y_idle_battery;
                  lenght_ls_idle_battery = lenght_ls_idle_battery * progress_ls_idle_battery;
                  let lenght_ls_idle_battery_draw = lenght_ls_idle_battery;
                  let line_width_ls_idle_battery_draw = line_width_ls_idle_battery;
                  if (lenght_ls_idle_battery < 0){
                    lenght_ls_idle_battery_draw = -lenght_ls_idle_battery;
                    start_x_idle_battery_draw = start_x_idle_battery - lenght_ls_idle_battery_draw;
                  };
                  
                  idle_battery_linear_scale.setProperty(hmUI.prop.MORE, {
                    x: start_x_idle_battery_draw,
                    y: start_y_idle_battery_draw,
                    w: lenght_ls_idle_battery_draw,
                    h: line_width_ls_idle_battery_draw,
                    color: color_ls_idle_battery,
                  });
                };

            };

            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                console.log('resume_call()');
                scale_call();
                text_update();
              }),
            });

                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}