﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        const logger = Logger.getLogger('watchface_SashaCX75');
        //end of ignored block

        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_battery_circle_scale = ''
        let normal_battery_TextRotate = new Array(3);
        let normal_battery_TextRotate_ASCIIARRAY = new Array(10);
        let normal_battery_TextRotate_img_width = 14;
        let normal_date_img_date_day = ''
        let normal_digital_clock_img_time = ''
        let idle_battery_circle_scale = ''
        let idle_digital_clock_img_time = ''


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 466,
              h: 466,
              src: 'kz_bg.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_battery_circle_scale = hmUI.createWidget(hmUI.widget.Circle_Scale, {
              // center_x: 330,
              // center_y: 318,
              // start_angle: 0,
              // end_angle: 360,
              // radius: 65,
              // line_width: 25,
              // line_cap: Flat,
              // color: 0xFFA0C936,
              // mirror: False,
              // inversion: False,
              // type: hmUI.data_type.BATTERY,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            let screenType = hmSetting.getScreenType();
            normal_battery_circle_scale = hmUI.createWidget(hmUI.widget.ARC_PROGRESS, {
              center_x: 330,
              center_y: 318,
              start_angle: 0,
              end_angle: 360,
              radius: 53,
              line_width: 25,
              corner_flag: 3,
              color: 0xFFA0C936,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            
            const battery = hmSensor.createSensor(hmSensor.id.BATTERY);
            battery.addEventListener(hmSensor.event.CHANGE, function() {
              text_update();
              scale_call();
            });

            // normal_battery_text_rotate_img = hmUI.createWidget(hmUI.widget.Text_Rotate, {
              // x: 315,
              // y: 304,
              // font_array: ["0032.png","0033.png","0034.png","0035.png","0036.png","0037.png","0038.png","0039.png","0040.png","0041.png"],
              // zero: false,
              // unit_in_alignment: false,
              // h_space: 0,
              // angle: 0,
              // align_h: hmUI.align.LEFT,
              // type: hmUI.data_type.BATTERY,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_battery_TextRotate_ASCIIARRAY[0] = '0032.png';  // set of images with numbers
            normal_battery_TextRotate_ASCIIARRAY[1] = '0033.png';  // set of images with numbers
            normal_battery_TextRotate_ASCIIARRAY[2] = '0034.png';  // set of images with numbers
            normal_battery_TextRotate_ASCIIARRAY[3] = '0035.png';  // set of images with numbers
            normal_battery_TextRotate_ASCIIARRAY[4] = '0036.png';  // set of images with numbers
            normal_battery_TextRotate_ASCIIARRAY[5] = '0037.png';  // set of images with numbers
            normal_battery_TextRotate_ASCIIARRAY[6] = '0038.png';  // set of images with numbers
            normal_battery_TextRotate_ASCIIARRAY[7] = '0039.png';  // set of images with numbers
            normal_battery_TextRotate_ASCIIARRAY[8] = '0040.png';  // set of images with numbers
            normal_battery_TextRotate_ASCIIARRAY[9] = '0041.png';  // set of images with numbers

            //start of ignored block
            for (let i = 0; i < 3; i++) {
              normal_battery_TextRotate[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 466,
                h: 466,
                center_x: 315,
                center_y: 304,
                pos_x: 315,
                pos_y: 304,
                angle: 0,
                src: '0032.png',
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
              normal_battery_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
            };
            //end of ignored block

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 17,
              day_startY: 219,
              day_sc_array: ["dtn_o_1.png","dtn_o_2.png","dtn_o_3.png","dtn_o_4.png","dtn_o_5.png","dtn_o_6.png","dtn_o_7.png","dtn_o_8.png","dtn_o_9.png","dtn_o_10.png"],
              day_tc_array: ["dtn_o_1.png","dtn_o_2.png","dtn_o_3.png","dtn_o_4.png","dtn_o_5.png","dtn_o_6.png","dtn_o_7.png","dtn_o_8.png","dtn_o_9.png","dtn_o_10.png"],
              day_en_array: ["dtn_o_1.png","dtn_o_2.png","dtn_o_3.png","dtn_o_4.png","dtn_o_5.png","dtn_o_6.png","dtn_o_7.png","dtn_o_8.png","dtn_o_9.png","dtn_o_10.png"],
              day_zero: 1,
              day_space: -104,
              day_align: hmUI.align.LEFT,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 65,
              hour_startY: 105,
              hour_array: ["0003.png","0004.png","0005.png","0006.png","0007.png","0008.png","0009.png","0010.png","0011.png","0012.png"],
              hour_zero: 1,
              hour_space: 0,
              hour_angle: 0,
              hour_align: hmUI.align.LEFT,

              minute_startX: 246,
              minute_startY: 105,
              minute_array: ["0003.png","0004.png","0005.png","0006.png","0007.png","0008.png","0009.png","0010.png","0011.png","0012.png"],
              minute_zero: 1,
              minute_space: 0,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });



            // idle_battery_circle_scale = hmUI.createWidget(hmUI.widget.Circle_Scale, {
              // center_x: 233,
              // center_y: 233,
              // start_angle: 0,
              // end_angle: 360,
              // radius: 218,
              // line_width: 15,
              // line_cap: Rounded,
              // color: 0xFFFF8000,
              // mirror: False,
              // inversion: False,
              // type: hmUI.data_type.BATTERY,
              // show_level: hmUI.show_level.ONLY_AOD,
            // });

            idle_battery_circle_scale = hmUI.createWidget(hmUI.widget.ARC_PROGRESS, {
              center_x: 233,
              center_y: 233,
              start_angle: 0,
              end_angle: 360,
              radius: 211,
              line_width: 15,
              corner_flag: 0,
              color: 0xFFFF8000,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 100,
              hour_startY: 45,
              hour_array: ["dtn_w_1.png","dtn_w_2.png","dtn_w_3.png","dtn_w_4.png","dtn_w_5.png","dtn_w_6.png","dtn_w_7.png","dtn_w_8.png","dtn_w_9.png","dtn_w_10.png"],
              hour_zero: 1,
              hour_space: -60,
              hour_angle: 0,
              hour_align: hmUI.align.LEFT,

              minute_startX: 100,
              minute_startY: 232,
              minute_array: ["dtn_o_1.png","dtn_o_2.png","dtn_o_3.png","dtn_o_4.png","dtn_o_5.png","dtn_o_6.png","dtn_o_7.png","dtn_o_8.png","dtn_o_9.png","dtn_o_10.png"],
              minute_zero: 1,
              minute_space: -60,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_AOD,
            });

            function text_update() {

              console.log('update text rotate battery_BATTERY');
              let valueBattery = battery.current;
              let normal_battery_rotate_string = parseInt(valueBattery).toString();

              if (screenType != hmSetting.screen_type.AOD) {
                for (var i = 1; i < 3; i++) {  // hide all symbols
                  normal_battery_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                if (valueBattery != null && valueBattery != undefined && isFinite(valueBattery) && normal_battery_rotate_string.length > 0 && normal_battery_rotate_string.length < 6) {  // display data if it was possible to get it
                  let img_offset = 0;
                  
                  let index = 0;
                  for (let char of normal_battery_rotate_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 3) break;
                    if (charCode >= 0 && charCode < 10) { 
                      normal_battery_TextRotate[index].setProperty(hmUI.prop.POS_X, 315 + img_offset);
                      normal_battery_TextRotate[index].setProperty(hmUI.prop.SRC, normal_battery_TextRotate_ASCIIARRAY[charCode]);
                      normal_battery_TextRotate[index].setProperty(hmUI.prop.VISIBLE, true);
                      img_offset += normal_battery_TextRotate_img_width;
                      index++;
                    };  // end if digit
                  };  // end char of string
                }  // end isFinite

              };

            };

            function scale_call() {

                console.log('update scales BATTERY');
                
                let valueBattery = battery.current;
                let targetBattery = 100;
                let progressBattery = valueBattery/targetBattery;
                if (progressBattery > 1) progressBattery = 1;
                let progress_cs_normal_battery = progressBattery;

                if (screenType != hmSetting.screen_type.AOD) {

                  // normal_battery_circle_scale_circle_scale
                  let level = Math.round(progress_cs_normal_battery * 100);
                  if (normal_battery_circle_scale) {
                    normal_battery_circle_scale.setProperty(hmUI.prop.MORE, {                      
                      center_x: 330,
                      center_y: 318,
                      start_angle: 0,
                      end_angle: 360,
                      radius: 53,
                      line_width: 25,
                      corner_flag: 3,
                      color: 0xFFA0C936,
                      show_level: hmUI.show_level.ONLY_NORMAL,
                      level: level,
                    });
                  };
                };

                console.log('update scales BATTERY');
                let progress_cs_idle_battery = progressBattery;

                if (screenType == hmSetting.screen_type.AOD) {

                  // idle_battery_circle_scale_circle_scale
                  let level = Math.round(progress_cs_idle_battery * 100);
                  if (idle_battery_circle_scale) {
                    idle_battery_circle_scale.setProperty(hmUI.prop.MORE, {                      
                      center_x: 233,
                      center_y: 233,
                      start_angle: 0,
                      end_angle: 360,
                      radius: 211,
                      line_width: 15,
                      corner_flag: 0,
                      color: 0xFFFF8000,
                      show_level: hmUI.show_level.ONLY_AOD,
                      level: level,
                    });
                  };
                };

            };

            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                scale_call();
                text_update();
              }),
            });

                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}