﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        const logger = Logger.getLogger('watchface_SashaCX75');
        //end of ignored block

        //dynamic modify start

        
        let normal_background_bg = ''
        let normal_pai_icon_img = ''
        let normal_calorie_icon_img = ''
        let normal_system_disconnect_img = ''
        let normal_battery_image_progress_img_level = ''
        let normal_battery_text_text_img = ''
        let normal_date_img_date_day = ''
        let normal_date_img_date_week_img = ''
        let normal_analog_clock_time_pointer_minute = ''
        let normal_analog_clock_time_pointer_hour = ''
        let normal_analog_clock_time_pointer_smooth_second = ''
        let idle_background_bg = ''
        let idle_pai_icon_img = ''
        let idle_system_dnd_img = ''
        let idle_system_disconnect_img = ''
        let idle_battery_icon_img = ''
        let idle_calorie_icon_img = ''
        let idle_analog_clock_time_pointer_minute = ''
        let idle_analog_clock_time_pointer_hour = ''
        let idle_analog_clock_time_pointer_second = ''


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            normal_background_bg = hmUI.createWidget(hmUI.widget.FILL_RECT, {
              x: 0,
              y: 0,
              w: 466,
              h: 466,
              color: '0xFF000000',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_pai_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: -1,
              y: 0,
              src: 'Dails_0038dark-grey.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_calorie_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 335,
              y: 205,
              src: 'mini_bred.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 69,
              y: 214,
              src: 'icon_bluetooth_lightgrey.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 210,
              y: 367,
              image_array: ["battry_0001.png","battry_0002.png","battry_0003.png","battry_0004.png","battry_0005.png","battry_0006.png","battry_0007.png"],
              image_length: 7,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 200,
              y: 360,
              font_array: ["digi_size4.5_along_001.png","digi_size4.5_along_002.png","digi_size4.5_along_003.png","digi_size4.5_along_004.png","digi_size4.5_along_005.png","digi_size4.5_along_006.png","digi_size4.5_along_007.png","digi_size4.5_along_008.png","digi_size4.5_along_009.png","digi_size4.5_along_010.png"],
              padding: false,
              h_space: -33,
              angle: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 397,
              day_startY: 204,
              day_sc_array: ["digi_googlesan_redsmallsize_0001.png","digi_googlesan_redsmallsize_0002.png","digi_googlesan_redsmallsize_0003.png","digi_googlesan_redsmallsize_0004.png","digi_googlesan_redsmallsize_0005.png","digi_googlesan_redsmallsize_0006.png","digi_googlesan_redsmallsize_0007.png","digi_googlesan_redsmallsize_0008.png","digi_googlesan_redsmallsize_0009.png","digi_googlesan_redsmallsize_0010.png"],
              day_tc_array: ["digi_googlesan_redsmallsize_0001.png","digi_googlesan_redsmallsize_0002.png","digi_googlesan_redsmallsize_0003.png","digi_googlesan_redsmallsize_0004.png","digi_googlesan_redsmallsize_0005.png","digi_googlesan_redsmallsize_0006.png","digi_googlesan_redsmallsize_0007.png","digi_googlesan_redsmallsize_0008.png","digi_googlesan_redsmallsize_0009.png","digi_googlesan_redsmallsize_0010.png"],
              day_en_array: ["digi_googlesan_redsmallsize_0001.png","digi_googlesan_redsmallsize_0002.png","digi_googlesan_redsmallsize_0003.png","digi_googlesan_redsmallsize_0004.png","digi_googlesan_redsmallsize_0005.png","digi_googlesan_redsmallsize_0006.png","digi_googlesan_redsmallsize_0007.png","digi_googlesan_redsmallsize_0008.png","digi_googlesan_redsmallsize_0009.png","digi_googlesan_redsmallsize_0010.png"],
              day_zero: 0,
              day_space: -44,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 320,
              y: 208,
              week_en: ["digi_googlesan_darksmallsize3_0001.png","digi_googlesan_darksmallsize3_0002.png","digi_googlesan_darksmallsize3_0003.png","digi_googlesan_darksmallsize3_0004.png","digi_googlesan_darksmallsize3_0005.png","digi_googlesan_darksmallsize3_0006.png","digi_googlesan_darksmallsize3_0007.png"],
              week_tc: ["digi_googlesan_darksmallsize3_0001.png","digi_googlesan_darksmallsize3_0002.png","digi_googlesan_darksmallsize3_0003.png","digi_googlesan_darksmallsize3_0004.png","digi_googlesan_darksmallsize3_0005.png","digi_googlesan_darksmallsize3_0006.png","digi_googlesan_darksmallsize3_0007.png"],
              week_sc: ["digi_googlesan_darksmallsize3_0001.png","digi_googlesan_darksmallsize3_0002.png","digi_googlesan_darksmallsize3_0003.png","digi_googlesan_darksmallsize3_0004.png","digi_googlesan_darksmallsize3_0005.png","digi_googlesan_darksmallsize3_0006.png","digi_googlesan_darksmallsize3_0007.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_minute = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              minute_path: '0055M.png',
              minute_centerX: 233,
              minute_centerY: 233,
              minute_posX: 23,
              minute_posY: 240,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_hour = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              hour_path: '0055H.png',
              hour_centerX: 233,
              hour_centerY: 233,
              hour_posX: 23,
              hour_posY: 239,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_analog_clock_pro_second_pointer_img = hmUI.createWidget(hmUI.widget.TIME_POINTER_PRO, {
              // src: '0046S.png',
              // center_x: 233,
              // center_y: 233,
              // x: 25,
              // y: 240,
              // start_angle: 0,
              // end_angle: 360,
              // type: hmUI.data_type.second,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });


            normal_analog_clock_time_pointer_smooth_second = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              second_path: '0046S.png',
              second_centerX: 233,
              second_centerY: 233,
              second_posX: 25,
              second_posY: 240,
              fresh_frequency: 40,
              fresh_freqency: 40,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_analog_clock_pro_smooth_second = hmUI.createWidget(hmUI.widget.SMOOTH_SECOND, {
              // type: 3,
              // fps: 40,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });



            idle_background_bg = hmUI.createWidget(hmUI.widget.FILL_RECT, {
              x: 0,
              y: 0,
              w: 466,
              h: 466,
              color: '0xFF000000',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_pai_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: -1,
              y: 0,
              src: 'Dails_0038dark-grey.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_system_dnd_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 94,
              y: 312,
              src: 'icon_DND_lightgrey.png',
              type: hmUI.system_status.DISTURB,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 69,
              y: 214,
              src: 'icon_bluetooth_lightgrey.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_battery_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 347,
              y: 207,
              src: 'icon_Picture - OG.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_calorie_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: -45,
              y: -40,
              src: 'AOB Overlay.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_analog_clock_time_pointer_minute = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              minute_path: '0055M.png',
              minute_centerX: 233,
              minute_centerY: 233,
              minute_posX: 23,
              minute_posY: 240,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_analog_clock_time_pointer_hour = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              hour_path: '0055H.png',
              hour_centerX: 233,
              hour_centerY: 233,
              hour_posX: 23,
              hour_posY: 239,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_analog_clock_time_pointer_second = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              second_path: '0046S.png',
              second_centerX: 233,
              second_centerY: 233,
              second_posX: 25,
              second_posY: 240,
              show_level: hmUI.show_level.ONLY_AOD,
            });


                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}