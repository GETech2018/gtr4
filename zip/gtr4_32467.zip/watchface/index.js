﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        const logger = Logger.getLogger('watchface_SashaCX75');
        //end of ignored block

        //dynamic modify start

        
        let editBg = ''
        let normal_system_disconnect_img = ''
        let normal_date_img_date_week_img = ''
        let normal_date_img_date_day = ''
        let idle_system_disconnect_img = ''
        let idle_date_img_date_week_img = ''
        let idle_date_img_date_day = ''
        let editGroup_1  = ''
        let editGroup_2  = ''
        let editGroup_3  = ''
        let fg_mask = ''
        let editableTimePointers = ''


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            editBg = hmUI.createWidget(hmUI.widget.WATCHFACE_EDIT_BG, {
              edit_id: 1002,
              x: 0,
              y: 0,
              // w: 466,
              // h: 466,
              // AOD_show: True,
              bg_config: [
                { id: 1, preview: 'preview_1.png', path: 'bg_edit_1.png' },
                { id: 2, preview: 'preview_2.png', path: 'bg_edit_2.png' },
                { id: 3, preview: 'preview_3.png', path: 'bg_edit_3.png' },
                { id: 4, preview: 'preview_4.png', path: 'bg_edit_5.png' },
                { id: 5, preview: 'preview_5.png', path: 'bg_edit_5.png' },
              ],
              count: 5,
              default_id: 1,
              fg: '.png',
              tips_bg: 'bg_tips.png',
              tips_x: 173,
              tips_y: 408,
            });

            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 438,
              y: 220,
              src: 'BT3.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 337,
              y: 220,
              week_en: ["day_1.png","day_2.png","day_3.png","day_4.png","day_5.png","day_6.png","day_7.png"],
              week_tc: ["day_1.png","day_2.png","day_3.png","day_4.png","day_5.png","day_6.png","day_7.png"],
              week_sc: ["day_1.png","day_2.png","day_3.png","day_4.png","day_5.png","day_6.png","day_7.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 295,
              day_startY: 220,
              day_sc_array: ["date_1.png","date_2.png","date_3.png","date_4.png","date_5.png","date_6.png","date_7.png","date_8.png","date_9.png","date_10.png"],
              day_tc_array: ["date_1.png","date_2.png","date_3.png","date_4.png","date_5.png","date_6.png","date_7.png","date_8.png","date_9.png","date_10.png"],
              day_en_array: ["date_1.png","date_2.png","date_3.png","date_4.png","date_5.png","date_6.png","date_7.png","date_8.png","date_9.png","date_10.png"],
              day_zero: 1,
              day_space: 0,
              day_align: hmUI.align.LEFT,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });



            idle_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 438,
              y: 220,
              src: 'BT3.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 337,
              y: 220,
              week_en: ["day_1.png","day_2.png","day_3.png","day_4.png","day_5.png","day_6.png","day_7.png"],
              week_tc: ["day_1.png","day_2.png","day_3.png","day_4.png","day_5.png","day_6.png","day_7.png"],
              week_sc: ["day_1.png","day_2.png","day_3.png","day_4.png","day_5.png","day_6.png","day_7.png"],
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 295,
              day_startY: 220,
              day_sc_array: ["date_1.png","date_2.png","date_3.png","date_4.png","date_5.png","date_6.png","date_7.png","date_8.png","date_9.png","date_10.png"],
              day_tc_array: ["date_1.png","date_2.png","date_3.png","date_4.png","date_5.png","date_6.png","date_7.png","date_8.png","date_9.png","date_10.png"],
              day_en_array: ["date_1.png","date_2.png","date_3.png","date_4.png","date_5.png","date_6.png","date_7.png","date_8.png","date_9.png","date_10.png"],
              day_zero: 1,
              day_space: 0,
              day_align: hmUI.align.LEFT,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            editGroup_1 = hmUI.createWidget(hmUI.widget.WATCHFACE_EDIT_GROUP, {
              edit_id: 10021,
              x: 166,
              y: 63,
              w: 136,
              h: 134,
              select_image: 'select.png',
              un_select_image: 'unselect.png',
              default_type: hmUI.edit_type.STEP,
              optional_types: [
                { type: hmUI.edit_type.STEP, preview: 'step1.png' },
                { type: hmUI.edit_type.CAL, preview: 'kcal1.png' },
                { type: hmUI.edit_type.HEART, preview: 'heart1.png' },
                { type: hmUI.edit_type.BATTERY, preview: 'battery1.png' },
                { type: hmUI.edit_type.PAI, preview: 'pai1.png' },
                { type: hmUI.edit_type.HUMIDITY, preview: 'hum1.png' },
                { type: hmUI.edit_type.FAT_BURN, preview: 'sport1.png'},
                { type: hmUI.edit_type.STRESS, preview: 'stress1.png' },
                { type: hmUI.edit_type.UVI, preview: 'uvi1.png' },
                { type: hmUI.edit_type.STAND, preview: 'stand1.png' },
                { type: hmUI.edit_type.ALTIMETER, preview: 'kpa1.png' },
                { type: hmUI.edit_type.WEATHER, preview: 'weather1.png' },
                { type: hmUI.edit_type.WIND, preview: 'wind1.png' },
                { type: hmUI.edit_type.SPO2, preview: 'spo21.png' },
                { type: hmUI.edit_type.MOON, preview: 'bgmoon.png' },
                { type: hmUI.edit_type.DISTANCE, preview: 'distance1.png' },
              ],
              count: 16,
              select_list: {
                title_font_size: 34,
                title_align_h: hmUI.align.CENTER_H,
                list_item_vspace: 8,
                list_tips_text_font_size: 32,
                list_tips_text_align_h: hmUI.align.LEFT
              },
              tips_BG: 'widget_tips.png',
              tips_x: 19,
              tips_y: -36,
              tips_width: 101,
              tips_margin: 0,
            });

            const editType_1 = editGroup_1.getProperty(hmUI.prop.CURRENT_TYPE);

            switch (editType_1) {
              case hmUI.edit_type.BATTERY:
                hmUI.createWidget(hmUI.widget.IMG, {
                  x: 167,
                  y: 63,
                  src: 'bg11.png',
                  show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_AOD,
                });

                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                  x: 215,
                  y: 150,
                  font_array: ["font_0.png","font_1.png","font_2.png","font_3.png","font_4.png","font_5.png","font_6.png","font_7.png","font_8.png","font_9.png"],
                  padding: false,
                  h_space: 0,
                  unit_sc: 'proz.png',
                  unit_tc: 'proz.png',
                  unit_en: 'proz.png',
                  align_h: hmUI.align.CENTER_H,
                  type: hmUI.data_type.BATTERY,
                  show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_AOD,
                });

                hmUI.createWidget(hmUI.widget.IMG, {
                  x: 218,
                  y: 80,
                  src: 'power.png',
                  show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_AOD,
                });

                hmUI.createWidget(hmUI.widget.IMG_POINTER, {
                  src: 'point.png',
                  center_x: 232,
                  center_y: 127,
                  x: 5,
                  y: 49,
                  start_angle: 0,
                  end_angle: 360,
                  type: hmUI.data_type.BATTERY,
                  show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_AOD,
                });
                break;

              case hmUI.edit_type.STEP:
                hmUI.createWidget(hmUI.widget.IMG, {
                  x: 167,
                  y: 63,
                  src: 'bg22.png',
                  show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_AOD,
                });

                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                  x: 208,
                  y: 150,
                  font_array: ["font_0.png","font_1.png","font_2.png","font_3.png","font_4.png","font_5.png","font_6.png","font_7.png","font_8.png","font_9.png"],
                  padding: false,
                  h_space: 0,
                  align_h: hmUI.align.CENTER_H,
                  type: hmUI.data_type.STEP,
                  show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_AOD,
                });

                hmUI.createWidget(hmUI.widget.IMG, {
                  x: 218,
                  y: 80,
                  src: 'step.png',
                  show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_AOD,
                });

                hmUI.createWidget(hmUI.widget.IMG_POINTER, {
                  src: 'point.png',
                  center_x: 232,
                  center_y: 127,
                  x: 5,
                  y: 49,
                  start_angle: 0,
                  end_angle: 360,
                  type: hmUI.data_type.STEP,
                  show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_AOD,
                });
                break;

              case hmUI.edit_type.CAL:
                hmUI.createWidget(hmUI.widget.IMG, {
                  x: 167,
                  y: 63,
                  src: 'bg22.png',
                  show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_AOD,
                });

                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                  x: 213,
                  y: 150,
                  font_array: ["font_0.png","font_1.png","font_2.png","font_3.png","font_4.png","font_5.png","font_6.png","font_7.png","font_8.png","font_9.png"],
                  padding: false,
                  h_space: 0,
                  align_h: hmUI.align.CENTER_H,
                  type: hmUI.data_type.CAL,
                  show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_AOD,
                });

                hmUI.createWidget(hmUI.widget.IMG, {
                  x: 218,
                  y: 80,
                  src: 'cal.png',
                  show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_AOD,
                });

                hmUI.createWidget(hmUI.widget.IMG_POINTER, {
                  src: 'point.png',
                  center_x: 232,
                  center_y: 127,
                  x: 5,
                  y: 49,
                  start_angle: 0,
                  end_angle: 360,
                  type: hmUI.data_type.CAL,
                  show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_AOD,
                });
                break;

              case hmUI.edit_type.HEART:
                hmUI.createWidget(hmUI.widget.IMG, {
                  x: 167,
                  y: 63,
                  src: 'bg33.png',
                  show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_AOD,
                });

                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                  x: 218,
                  y: 150,
                  font_array: ["font_0.png","font_1.png","font_2.png","font_3.png","font_4.png","font_5.png","font_6.png","font_7.png","font_8.png","font_9.png"],
                  padding: false,
                  h_space: 0,
                  align_h: hmUI.align.CENTER_H,
                  type: hmUI.data_type.HEART,
                  show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_AOD,
                });

                hmUI.createWidget(hmUI.widget.IMG, {
                  x: 217,
                  y: 80,
                  src: 'heart.png',
                  show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_AOD,
                });

                hmUI.createWidget(hmUI.widget.IMG_POINTER, {
                  src: 'point.png',
                  center_x: 232,
                  center_y: 127,
                  x: 5,
                  y: 49,
                  start_angle: 0,
                  end_angle: 360,
                  type: hmUI.data_type.HEART,
                  show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_AOD,
                });
                break;

              case hmUI.edit_type.PAI:
                hmUI.createWidget(hmUI.widget.IMG, {
                  x: 167,
                  y: 63,
                  src: 'bg22.png',
                  show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_AOD,
                });

                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                  x: 217,
                  y: 150,
                  font_array: ["font_0.png","font_1.png","font_2.png","font_3.png","font_4.png","font_5.png","font_6.png","font_7.png","font_8.png","font_9.png"],
                  padding: false,
                  h_space: 0,
                  align_h: hmUI.align.CENTER_H,
                  type: hmUI.data_type.PAI_WEEKLY,
                  show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_AOD,
                });

                hmUI.createWidget(hmUI.widget.IMG, {
                  x: 218,
                  y: 80,
                  src: 'PAI.png',
                  show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_AOD,
                });

                hmUI.createWidget(hmUI.widget.IMG_POINTER, {
              src: 'point.png',
              center_x: 232,
              center_y: 127,
              x: 5,
              y: 49,
              start_angle: 0,
              end_angle: 360,
              type: hmUI.data_type.PAI_WEEKLY,
              show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_AOD,
                });
                break;

              case hmUI.edit_type.DISTANCE:
                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                  x: 210,
                  y: 150,
                  font_array: ["font_0.png","font_1.png","font_2.png","font_3.png","font_4.png","font_5.png","font_6.png","font_7.png","font_8.png","font_9.png"],
                  padding: false,
                  h_space: 0,
                  dot_image: 'dot.png',
                  align_h: hmUI.align.CENTER_H,
                  type: hmUI.data_type.DISTANCE,
                  show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_AOD,
                });

                hmUI.createWidget(hmUI.widget.IMG, {
                  x: 218,
                  y: 80,
                  src: 'distance.png',
                  show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_AOD,
                });
                break;

              case hmUI.edit_type.STAND:
                hmUI.createWidget(hmUI.widget.IMG, {
                  x: 167,
                  y: 63,
                  src: 'bg44.png',
                  show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_AOD,
                });

                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                  x: 223,
                  y: 150,
                  font_array: ["font_0.png","font_1.png","font_2.png","font_3.png","font_4.png","font_5.png","font_6.png","font_7.png","font_8.png","font_9.png"],
                  padding: true,
                  h_space: 0,
                  align_h: hmUI.align.LEFT,
                  type: hmUI.data_type.STAND,
                  show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_AOD,
                });

                editableZone_1_stand_current_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
                  x: 218,
                  y: 80,
                  src: 'stand.png',
                  show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_AOD,
                });

                hmUI.createWidget(hmUI.widget.IMG_POINTER, {
              src: 'point.png',
              center_x: 232,
              center_y: 127,
              x: 5,
              y: 49,
              start_angle: 0,
              end_angle: 360,
              type: hmUI.data_type.STAND,
              show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_AOD,
                });
                break;

              case hmUI.edit_type.STRESS:
                hmUI.createWidget(hmUI.widget.IMG, {
                  x: 167,
                  y: 63,
                  src: 'bg44.png',
                  show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_AOD,
                });

                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                  x: 216,
                  y: 150,
                  font_array: ["font_0.png","font_1.png","font_2.png","font_3.png","font_4.png","font_5.png","font_6.png","font_7.png","font_8.png","font_9.png"],
                  padding: false,
                  h_space: 0,
                  align_h: hmUI.align.CENTER_H,
                  type: hmUI.data_type.STRESS,
                  show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_AOD,
                });

                hmUI.createWidget(hmUI.widget.IMG, {
                  x: 216,
                  y: 80,
                  src: 'pressure.png',
                  show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_AOD,
                });

                hmUI.createWidget(hmUI.widget.IMG_POINTER, {
                  src: 'point.png',
                  center_x: 232,
                  center_y: 127,
                  x: 5,
                  y: 49,
                  start_angle: 0,
                  end_angle: 360,
                  type: hmUI.data_type.STRESS,
                  show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_AOD,
                });
                break;

              case hmUI.edit_type.FAT_BURN:
                hmUI.createWidget(hmUI.widget.IMG, {
              x: 167,
              y: 63,
              src: 'bg22.png',
              show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_AOD,
                });

                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                  x: 215,
                  y: 150,
                  font_array: ["font_0.png","font_1.png","font_2.png","font_3.png","font_4.png","font_5.png","font_6.png","font_7.png","font_8.png","font_9.png"],
                  padding: false,
                  h_space: 0,
                  unit_sc: 'min.png',
                  unit_tc: 'min.png',
                  unit_en: 'min.png',
                  align_h: hmUI.align.CENTER_H,
                  type: hmUI.data_type.FAT_BURNING,
                  show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_AOD,
                });

                hmUI.createWidget(hmUI.widget.IMG, {
                  x: 218,
                  y: 80,
                  src: 'fat_burning.png',
                  show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_AOD,
                });

                hmUI.createWidget(hmUI.widget.IMG_POINTER, {
                  src: 'point.png',
                  center_x: 232,
                  center_y: 127,
                  x: 5,
                  y: 49,
                  start_angle: 0,
                  end_angle: 360,
                  type: hmUI.data_type.FAT_BURNING,
                  show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_AOD,
                });
                break;

              case hmUI.edit_type.SPO2:
                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                  x: 217,
                  y: 150,
                  font_array: ["font_0.png","font_1.png","font_2.png","font_3.png","font_4.png","font_5.png","font_6.png","font_7.png","font_8.png","font_9.png"],
                  padding: false,
                  h_space: 0,
                  unit_sc: 'proz.png',
                  unit_tc: 'proz.png',
                  unit_en: 'proz.png',
                  align_h: hmUI.align.CENTER_H,
                  type: hmUI.data_type.SPO2,
                  show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_AOD,
                });

                hmUI.createWidget(hmUI.widget.IMG, {
                  x: 218,
                  y: 80,
                  src: 'spo2.png',
                  show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_AOD,
                });
                break;

              case hmUI.edit_type.WEATHER:
                hmUI.createWidget(hmUI.widget.IMG, {
                  x: 167,
                  y: 63,
                  src: 'bg33.png',
                  show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_AOD,
                });

                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                  x: 216,
                  y: 150,
                  font_array: ["font_0.png","font_1.png","font_2.png","font_3.png","font_4.png","font_5.png","font_6.png","font_7.png","font_8.png","font_9.png"],
                  padding: false,
                  h_space: 0,
                  unit_sc: 'gradus.png',
                  unit_tc: 'gradus.png',
                  unit_en: 'gradus.png',
                  negative_image: 'minus.png',
                  align_h: hmUI.align.CENTER_H,
                  type: hmUI.data_type.WEATHER_CURRENT,
                  show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_AOD,
                });

                hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
                  x: 208,
                  y: 80,
                  image_array: ["weather_1.png","weather_2.png","weather_3.png","weather_4.png","weather_5.png","weather_6.png","weather_7.png","weather_8.png","weather_9.png","weather_10.png","weather_11.png","weather_12.png","weather_13.png","weather_14.png","weather_15.png","weather_16.png","weather_17.png","weather_18.png","weather_19.png","weather_20.png","weather_21.png","weather_22.png","weather_23.png","weather_24.png","weather_25.png","weather_26.png","weather_27.png","weather_28.png","weather_29.png"],
                  image_length: 29,
                  type: hmUI.data_type.WEATHER_CURRENT,
                  show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_AOD,
                });
                break;

              case hmUI.edit_type.UVI:
                 hmUI.createWidget(hmUI.widget.IMG, {
                  x: 167,
                  y: 63,
                  src: 'bg22.png',
                  show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_AOD,
                });

                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                  x: 222,
                  y: 150,
                  font_array: ["font_0.png","font_1.png","font_2.png","font_3.png","font_4.png","font_5.png","font_6.png","font_7.png","font_8.png","font_9.png"],
                  padding: false,
                  h_space: 0,
                  align_h: hmUI.align.CENTER_H,
                  type: hmUI.data_type.UVI,
                  show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_AOD,
                });

                hmUI.createWidget(hmUI.widget.IMG, {
                  x: 218,
                  y: 80,
                  src: 'UVI.png',
                  show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_AOD,
                });

                hmUI.createWidget(hmUI.widget.IMG_POINTER, {
                  src: 'point.png',
                  center_x: 232,
                  center_y: 127,
                  x: 5,
                  y: 49,
                  start_angle: 0,
                  end_angle: 360,
                  type: hmUI.data_type.UVI,
                  show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_AOD,
                });
                break;

              case hmUI.edit_type.HUMIDITY:
                hmUI.createWidget(hmUI.widget.IMG, {
                  x: 167,
                  y: 63,
                  src: 'bg22.png',
                  show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_AOD,
                });

                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                  x: 215,
                  y: 150,
                  font_array: ["font_0.png","font_1.png","font_2.png","font_3.png","font_4.png","font_5.png","font_6.png","font_7.png","font_8.png","font_9.png"],
                  padding: false,
                  h_space: 0,
                  unit_sc: 'proz.png',
                  unit_tc: 'proz.png',
                  unit_en: 'proz.png',
                  align_h: hmUI.align.CENTER_H,
                  type: hmUI.data_type.HUMIDITY,
                  show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_AOD,
                });

                hmUI.createWidget(hmUI.widget.IMG, {
                  x: 218,
                  y: 80,
                  src: 'humidity.png',
                  show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_AOD,
                });

                hmUI.createWidget(hmUI.widget.IMG_POINTER, {
                  src: 'point.png',
                  center_x: 232,
                  center_y: 127,
                  x: 5,
                  y: 49,
                  start_angle: 0,
                  end_angle: 360,
                  type: hmUI.data_type.HUMIDITY,
                  show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_AOD,
                });
                break;

              case hmUI.edit_type.ALTIMETER:
                hmUI.createWidget(hmUI.widget.IMG, {
                  x: 167,
                  y: 63,
                  src: 'bg55.png',
                  show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_AOD,
                });

                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                  x: 211,
                  y: 150,
                  font_array: ["font_0.png","font_1.png","font_2.png","font_3.png","font_4.png","font_5.png","font_6.png","font_7.png","font_8.png","font_9.png"],
                  padding: false,
                  h_space: 0,
                  align_h: hmUI.align.CENTER_H,
                  type: hmUI.data_type.ALTIMETER,
                  show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_AOD,
                });

                hmUI.createWidget(hmUI.widget.IMG, {
                  x: 218,
                  y: 80,
                  src: 'KPA.png',
                  show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_AOD,
                });

                hmUI.createWidget(hmUI.widget.IMG_POINTER, {
                  src: 'point.png',
                  center_x: 232,
                  center_y: 127,
                  x: 5,
                  y: 49,
                  start_angle: 0,
                  end_angle: 360,
                  type: hmUI.data_type.ALTIMETER,
                  show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_AOD,
                });
                break;

              case hmUI.edit_type.WIND:
                hmUI.createWidget(hmUI.widget.IMG, {
                  x: 167,
                  y: 63,
                  src: 'bg22.png',
                  show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_AOD,
                });

                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                  x: 222,
                  y: 150,
                  font_array: ["font_0.png","font_1.png","font_2.png","font_3.png","font_4.png","font_5.png","font_6.png","font_7.png","font_8.png","font_9.png"],
                  padding: false,
                  h_space: 0,
                  align_h: hmUI.align.CENTER_H,
                  type: hmUI.data_type.WIND,
                  show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_AOD,
                });

                hmUI.createWidget(hmUI.widget.IMG_POINTER, {
                  src: 'point.png',
                  center_x: 232,
                  center_y: 127,
                  x: 5,
                  y: 49,
                  start_angle: 0,
                  end_angle: 360,
                  type: hmUI.data_type.WIND,
                  show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_AOD,
                });

                hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
                  x: 211,
                  y: 79,
                  image_array: ["winds_1.png","winds_2.png","winds_3.png","winds_4.png","winds_5.png","winds_6.png","winds_7.png","winds_8.png"],
                  image_length: 8,
                  type: hmUI.data_type.WIND_DIRECTION,
                  show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_AOD,
                });
                break;

              case hmUI.edit_type.MOON:
            hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
                  x: 155,
                  y: 52,
                  image_array: ["moon_01.png","moon_02.png","moon_03.png","moon_04.png","moon_05.png","moon_06.png","moon_07.png","moon_08.png","moon_09.png","moon_10.png","moon_11.png","moon_12.png","moon_13.png","moon_14.png","moon_15.png","moon_16.png","moon_17.png","moon_18.png","moon_19.png","moon_20.png","moon_21.png","moon_22.png","moon_23.png","moon_24.png","moon_25.png","moon_26.png","moon_27.png","moon_28.png","moon_29.png","moon_30.png"],
                  image_length: 30,
                  type: hmUI.data_type.MOON,
                  show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_AOD,
            });
                break;
            }; // end switch

            editGroup_2 = hmUI.createWidget(hmUI.widget.WATCHFACE_EDIT_GROUP, {
              edit_id: 10022,
              x: 63,
              y: 166,
              w: 136,
              h: 134,
              select_image: 'select.png',
              un_select_image: 'unselect.png',
              default_type: hmUI.edit_type.STEP,
              optional_types: [
                { type: hmUI.edit_type.STEP, preview: 'step1.png' },
                { type: hmUI.edit_type.ALTIMETER, preview: 'kpa1.png' },
                { type: hmUI.edit_type.BATTERY, preview: 'battery1.png' },
                { type: hmUI.edit_type.CAL, preview: 'kcal1.png' },
                { type: hmUI.edit_type.HEART, preview: 'heart1.png' },
                { type: hmUI.edit_type.PAI, preview: 'pai1.png' },
                { type: hmUI.edit_type.STAND, preview: 'stand1.png' },
                { type: hmUI.edit_type.STRESS, preview: 'stress1.png' },
                { type: hmUI.edit_type.FAT_BURN, preview: 'sport1.png'},
                { type: hmUI.edit_type.WEATHER, preview: 'weather1.png' },
                { type: hmUI.edit_type.HUMIDITY, preview: 'hum1.png' },
                { type: hmUI.edit_type.DISTANCE, preview: 'distance1.png' },
                { type: hmUI.edit_type.MOON, preview: 'bgmoon.png' },
                { type: hmUI.edit_type.SPO2, preview: 'spo21.png' },
                { type: hmUI.edit_type.WIND, preview: 'wind1.png' },
                { type: hmUI.edit_type.UVI, preview: 'uvi1.png' },
              ],
              count: 16,
              select_list: {
                title_font_size: 34,
                title_align_h: hmUI.align.CENTER_H,
                list_item_vspace: 8,
                list_tips_text_font_size: 32,
                list_tips_text_align_h: hmUI.align.LEFT
              },
              tips_BG: 'widget_tips.png',
              tips_x: 17,
              tips_y: -36,
              tips_width: 101,
              tips_margin: 0,
            });

            const editType_2 = editGroup_2.getProperty(hmUI.prop.CURRENT_TYPE);

            switch (editType_2) {
              case hmUI.edit_type.BATTERY:
                hmUI.createWidget(hmUI.widget.IMG, {
                  x: 63,
                  y: 167,
                  src: 'bg11.png',
                  show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_AOD,
                });

                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                  x: 112,
                  y: 255,
                  font_array: ["font_0.png","font_1.png","font_2.png","font_3.png","font_4.png","font_5.png","font_6.png","font_7.png","font_8.png","font_9.png"],
                  padding: false,
                  h_space: 0,
                  unit_sc: 'proz.png',
                  unit_tc: 'proz.png',
                  unit_en: 'proz.png',
                  align_h: hmUI.align.CENTER_H,
                  type: hmUI.data_type.BATTERY,
                  show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_AOD,
                });

                hmUI.createWidget(hmUI.widget.IMG, {
                  x: 113,
                  y: 183,
                  src: 'power.png',
                  show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_AOD,
                });

                hmUI.createWidget(hmUI.widget.IMG_POINTER, {
                  src: 'point.png',
                  center_x: 128,
                  center_y: 231,
                  x: 5,
                  y: 49,
                  start_angle: 0,
                  end_angle: 360,
                  type: hmUI.data_type.BATTERY,
                  show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_AOD,
                });
                break;

              case hmUI.edit_type.STEP:
                hmUI.createWidget(hmUI.widget.IMG, {
                  x: 63,
                  y: 167,
                  src: 'bg22.png',
                  show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_AOD,
                });

                hmUI.createWidget(hmUI.widget.IMG_POINTER, {
                  src: 'point.png',
                  center_x: 128,
                  center_y: 231,
                  x: 5,
                  y: 49,
                  start_angle: 0,
                  end_angle: 360,
                  type: hmUI.data_type.STEP,
                  show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_AOD,
                });

                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                  x: 104,
                  y: 255,
                  font_array: ["font_0.png","font_1.png","font_2.png","font_3.png","font_4.png","font_5.png","font_6.png","font_7.png","font_8.png","font_9.png"],
                  padding: false,
                  h_space: 0,
                  align_h: hmUI.align.CENTER_H,
                  type: hmUI.data_type.STEP,
                  show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_AOD,
                });

                hmUI.createWidget(hmUI.widget.IMG, {
                  x: 113,
                  y: 183,
                  src: 'step.png',
                  show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_AOD,
                });
                break;

              case hmUI.edit_type.CAL:
                hmUI.createWidget(hmUI.widget.IMG, {
                  x: 63,
                  y: 167,
                  src: 'bg22.png',
                  show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_AOD,
                });

                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                  x: 108,
                  y: 255,
                  font_array: ["font_0.png","font_1.png","font_2.png","font_3.png","font_4.png","font_5.png","font_6.png","font_7.png","font_8.png","font_9.png"],
                  padding: false,
                  h_space: 0,
                  align_h: hmUI.align.CENTER_H,
                  type: hmUI.data_type.CAL,
                  show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_AOD,
                });

                hmUI.createWidget(hmUI.widget.IMG, {
                  x: 113,
                  y: 183,
                  src: 'cal.png',
                  show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_AOD,
                });

                hmUI.createWidget(hmUI.widget.IMG_POINTER, {
                  src: 'point.png',
                  center_x: 128,
                  center_y: 231,
                  x: 5,
                  y: 49,
                  start_angle: 0,
                  end_angle: 360,
                  type: hmUI.data_type.CAL,
                  show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_AOD,
                });
                break;

              case hmUI.edit_type.HEART:
                hmUI.createWidget(hmUI.widget.IMG, {
                  x: 63,
                  y: 167,
                  src: 'bg33.png',
                  show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_AOD,
                });

                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                  x: 112,
                  y: 255,
                  font_array: ["font_0.png","font_1.png","font_2.png","font_3.png","font_4.png","font_5.png","font_6.png","font_7.png","font_8.png","font_9.png"],
                  padding: false,
                  h_space: 0,
                  align_h: hmUI.align.CENTER_H,
                  type: hmUI.data_type.HEART,
                  show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_AOD,
                });

                hmUI.createWidget(hmUI.widget.IMG, {
                  x: 113,
                  y: 183,
                  src: 'heart.png',
                  show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_AOD,
                });

                hmUI.createWidget(hmUI.widget.IMG_POINTER, {
                  src: 'point.png',
                  center_x: 128,
                  center_y: 231,
                  x: 5,
                  y: 49,
                  start_angle: 0,
                  end_angle: 360,
                  type: hmUI.data_type.HEART,
                  show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_AOD,
                });
                break;

              case hmUI.edit_type.PAI:
                hmUI.createWidget(hmUI.widget.IMG, {
                  x: 63,
                  y: 167,
                  src: 'bg22.png',
                  show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_AOD,
                });

                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                  x: 113,
                  y: 255,
                  font_array: ["font_0.png","font_1.png","font_2.png","font_3.png","font_4.png","font_5.png","font_6.png","font_7.png","font_8.png","font_9.png"],
                  padding: false,
                  h_space: 0,
                  align_h: hmUI.align.CENTER_H,
                  type: hmUI.data_type.PAI_WEEKLY,
                  show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_AOD,
                });

                hmUI.createWidget(hmUI.widget.IMG, {
                  x: 113,
                  y: 183,
                  src: 'PAI.png',
                  show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_AOD,
                });

                hmUI.createWidget(hmUI.widget.IMG_POINTER, {
              src: 'point.png',
              center_x: 128,
              center_y: 231,
              x: 5,
              y: 49,
              start_angle: 0,
              end_angle: 360,
              type: hmUI.data_type.PAI_WEEKLY,
              show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_AOD,
                });
                break;

              case hmUI.edit_type.DISTANCE:
                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                  x: 107,
                  y: 255,
                  font_array: ["font_0.png","font_1.png","font_2.png","font_3.png","font_4.png","font_5.png","font_6.png","font_7.png","font_8.png","font_9.png"],
                  padding: false,
                  h_space: 0,
                  dot_image: 'dot.png',
                  align_h: hmUI.align.CENTER_H,
                  type: hmUI.data_type.DISTANCE,
                  show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_AOD,
                });

                hmUI.createWidget(hmUI.widget.IMG, {
                  x: 113,
                  y: 183,
                  src: 'distance.png',
                  show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_AOD,
                });
                break;

              case hmUI.edit_type.STAND:
                hmUI.createWidget(hmUI.widget.IMG, {
                  x: 63,
                  y: 167,
                  src: 'bg44.png',
                  show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_AOD,
                });

                hmUI.createWidget(hmUI.widget.IMG_POINTER, {
              src: 'point.png',
              center_x: 128,
              center_y: 231,
              x: 5,
              y: 49,
              start_angle: 0,
              end_angle: 360,
              type: hmUI.data_type.STAND,
              show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_AOD,
                });

                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                  x: 118,
                  y: 255,
                  font_array: ["font_0.png","font_1.png","font_2.png","font_3.png","font_4.png","font_5.png","font_6.png","font_7.png","font_8.png","font_9.png"],
                  padding: true,
                  h_space: 0,
                  align_h: hmUI.align.LEFT,
                  type: hmUI.data_type.STAND,
                  show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_AOD,
                });

                editableZone_2_stand_current_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
                  x: 113,
                  y: 183,
                  src: 'stand.png',
                  show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_AOD,
                });
                break;

              case hmUI.edit_type.STRESS:
                hmUI.createWidget(hmUI.widget.IMG, {
                  x: 63,
                  y: 167,
                  src: 'bg55.png',
                  show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_AOD,
                });

                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                  x: 113,
                  y: 255,
                  font_array: ["font_0.png","font_1.png","font_2.png","font_3.png","font_4.png","font_5.png","font_6.png","font_7.png","font_8.png","font_9.png"],
                  padding: false,
                  h_space: 0,
                  align_h: hmUI.align.CENTER_H,
                  type: hmUI.data_type.STRESS,
                  show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_AOD,
                });

                hmUI.createWidget(hmUI.widget.IMG, {
                  x: 112,
                  y: 183,
                  src: 'pressure.png',
                  show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_AOD,
                });

                hmUI.createWidget(hmUI.widget.IMG_POINTER, {
                  src: 'point.png',
                  center_x: 128,
                  center_y: 231,
                  x: 5,
                  y: 49,
                  start_angle: 0,
                  end_angle: 360,
                  type: hmUI.data_type.STRESS,
                  show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_AOD,
                });
                break;

              case hmUI.edit_type.FAT_BURN:
                hmUI.createWidget(hmUI.widget.IMG, {
              x: 63,
              y: 167,
              src: 'bg22.png',
              show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_AOD,
                });

                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                  x: 111,
                  y: 255,
                  font_array: ["font_0.png","font_1.png","font_2.png","font_3.png","font_4.png","font_5.png","font_6.png","font_7.png","font_8.png","font_9.png"],
                  padding: false,
                  h_space: 0,
                  unit_sc: 'min.png',
                  unit_tc: 'min.png',
                  unit_en: 'min.png',
                  align_h: hmUI.align.CENTER_H,
                  type: hmUI.data_type.FAT_BURNING,
                  show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_AOD,
                });

                hmUI.createWidget(hmUI.widget.IMG, {
                  x: 113,
                  y: 183,
                  src: 'fat_burning.png',
                  show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_AOD,
                });

                hmUI.createWidget(hmUI.widget.IMG_POINTER, {
                  src: 'point.png',
                  center_x: 128,
                  center_y: 231,
                  x: 5,
                  y: 49,
                  start_angle: 0,
                  end_angle: 360,
                  type: hmUI.data_type.FAT_BURNING,
                  show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_AOD,
                });
                break;

              case hmUI.edit_type.SPO2:
                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                  x: 114,
                  y: 255,
                  font_array: ["font_0.png","font_1.png","font_2.png","font_3.png","font_4.png","font_5.png","font_6.png","font_7.png","font_8.png","font_9.png"],
                  padding: false,
                  h_space: 0,
                  unit_sc: 'proz.png',
                  unit_tc: 'proz.png',
                  unit_en: 'proz.png',
                  align_h: hmUI.align.CENTER_H,
                  type: hmUI.data_type.SPO2,
                  show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_AOD,
                });

                hmUI.createWidget(hmUI.widget.IMG, {
                  x: 113,
                  y: 183,
                  src: 'spo2.png',
                  show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_AOD,
                });
                break;

              case hmUI.edit_type.WEATHER:
                hmUI.createWidget(hmUI.widget.IMG, {
                  x: 63,
                  y: 167,
                  src: 'bg33.png',
                  show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_AOD,
                });

                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                  x: 113,
                  y: 255,
                  font_array: ["font_0.png","font_1.png","font_2.png","font_3.png","font_4.png","font_5.png","font_6.png","font_7.png","font_8.png","font_9.png"],
                  padding: false,
                  h_space: 0,
                  unit_sc: 'gradus.png',
                  unit_tc: 'gradus.png',
                  unit_en: 'gradus.png',
                  negative_image: 'minus.png',
                  align_h: hmUI.align.CENTER_H,
                  type: hmUI.data_type.WEATHER_CURRENT,
                  show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_AOD,
                });

                hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
                  x: 103,
                  y: 182,
                  image_array: ["weather_1.png","weather_2.png","weather_3.png","weather_4.png","weather_5.png","weather_6.png","weather_7.png","weather_8.png","weather_9.png","weather_10.png","weather_11.png","weather_12.png","weather_13.png","weather_14.png","weather_15.png","weather_16.png","weather_17.png","weather_18.png","weather_19.png","weather_20.png","weather_21.png","weather_22.png","weather_23.png","weather_24.png","weather_25.png","weather_26.png","weather_27.png","weather_28.png","weather_29.png"],
                  image_length: 29,
                  type: hmUI.data_type.WEATHER_CURRENT,
                  show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_AOD,
                });
                break;

              case hmUI.edit_type.UVI:
                 hmUI.createWidget(hmUI.widget.IMG, {
                  x: 63,
                  y: 167,
                  src: 'bg33.png',
                  show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_AOD,
                });

                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                  x: 118,
                  y: 255,
                  font_array: ["font_0.png","font_1.png","font_2.png","font_3.png","font_4.png","font_5.png","font_6.png","font_7.png","font_8.png","font_9.png"],
                  padding: false,
                  h_space: 0,
                  align_h: hmUI.align.CENTER_H,
                  type: hmUI.data_type.UVI,
                  show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_AOD,
                });

                hmUI.createWidget(hmUI.widget.IMG, {
                  x: 113,
                  y: 183,
                  src: 'UVI.png',
                  show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_AOD,
                });

                hmUI.createWidget(hmUI.widget.IMG_POINTER, {
                  src: 'point.png',
                  center_x: 128,
                  center_y: 231,
                  x: 5,
                  y: 49,
                  start_angle: 0,
                  end_angle: 360,
                  type: hmUI.data_type.UVI,
                  show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_AOD,
                });
                break;

              case hmUI.edit_type.HUMIDITY:
                hmUI.createWidget(hmUI.widget.IMG, {
                  x: 63,
                  y: 167,
                  src: 'bg22.png',
                  show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_AOD,
                });

                hmUI.createWidget(hmUI.widget.IMG_POINTER, {
                  src: 'point.png',
                  center_x: 128,
                  center_y: 231,
                  x: 5,
                  y: 49,
                  start_angle: 0,
                  end_angle: 360,
                  type: hmUI.data_type.HUMIDITY,
                  show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_AOD,
                });

                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                  x: 113,
                  y: 255,
                  font_array: ["font_0.png","font_1.png","font_2.png","font_3.png","font_4.png","font_5.png","font_6.png","font_7.png","font_8.png","font_9.png"],
                  padding: false,
                  h_space: 0,
                  unit_sc: 'proz.png',
                  unit_tc: 'proz.png',
                  unit_en: 'proz.png',
                  align_h: hmUI.align.CENTER_H,
                  type: hmUI.data_type.HUMIDITY,
                  show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_AOD,
                });

                hmUI.createWidget(hmUI.widget.IMG, {
                  x: 114,
                  y: 183,
                  src: 'humidity.png',
                  show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_AOD,
                });
                break;

              case hmUI.edit_type.ALTIMETER:
                hmUI.createWidget(hmUI.widget.IMG, {
                  x: 63,
                  y: 167,
                  src: 'bg55.png',
                  show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_AOD,
                });

                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                  x: 108,
                  y: 255,
                  font_array: ["font_0.png","font_1.png","font_2.png","font_3.png","font_4.png","font_5.png","font_6.png","font_7.png","font_8.png","font_9.png"],
                  padding: false,
                  h_space: 0,
                  align_h: hmUI.align.CENTER_H,
                  type: hmUI.data_type.ALTIMETER,
                  show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_AOD,
                });

                hmUI.createWidget(hmUI.widget.IMG, {
                  x: 114,
                  y: 183,
                  src: 'KPA.png',
                  show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_AOD,
                });

                hmUI.createWidget(hmUI.widget.IMG_POINTER, {
                  src: 'point.png',
                  center_x: 128,
                  center_y: 231,
                  x: 5,
                  y: 49,
                  start_angle: 0,
                  end_angle: 360,
                  type: hmUI.data_type.ALTIMETER,
                  show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_AOD,
                });
                break;

              case hmUI.edit_type.WIND:
                hmUI.createWidget(hmUI.widget.IMG, {
                  x: 63,
                  y: 167,
                  src: 'bg22.png',
                  show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_AOD,
                });

                hmUI.createWidget(hmUI.widget.IMG_POINTER, {
                  src: 'point.png',
                  center_x: 128,
                  center_y: 231,
                  x: 5,
                  y: 49,
                  start_angle: 0,
                  end_angle: 360,
                  type: hmUI.data_type.WIND,
                  show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_AOD,
                });

                hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
                  x: 109,
                  y: 187,
                  image_array: ["winds_1.png","winds_2.png","winds_3.png","winds_4.png","winds_5.png","winds_6.png","winds_7.png","winds_8.png"],
                  image_length: 8,
                  type: hmUI.data_type.WIND_DIRECTION,
                  show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_AOD,
                });

                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                  x: 120,
                  y: 255,
                  font_array: ["font_0.png","font_1.png","font_2.png","font_3.png","font_4.png","font_5.png","font_6.png","font_7.png","font_8.png","font_9.png"],
                  padding: false,
                  h_space: 0,
                  align_h: hmUI.align.CENTER_H,
                  type: hmUI.data_type.WIND,
                  show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_AOD,
                });
                break;

              case hmUI.edit_type.MOON:
            hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
                  x: 52,
                  y: 155,
                  image_array: ["moon_01.png","moon_02.png","moon_03.png","moon_04.png","moon_05.png","moon_06.png","moon_07.png","moon_08.png","moon_09.png","moon_10.png","moon_11.png","moon_12.png","moon_13.png","moon_14.png","moon_15.png","moon_16.png","moon_17.png","moon_18.png","moon_19.png","moon_20.png","moon_21.png","moon_22.png","moon_23.png","moon_24.png","moon_25.png","moon_26.png","moon_27.png","moon_28.png","moon_29.png","moon_30.png"],
                  image_length: 30,
                  type: hmUI.data_type.MOON,
                  show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_AOD,
            });
                break;
            }; // end switch

            editGroup_3 = hmUI.createWidget(hmUI.widget.WATCHFACE_EDIT_GROUP, {
              edit_id: 10023,
              x: 166,
              y: 268,
              w: 136,
              h: 134,
              select_image: 'select.png',
              un_select_image: 'unselect.png',
              default_type: hmUI.edit_type.STEP,
              optional_types: [
                { type: hmUI.edit_type.STEP, preview: 'step1.png' },
                { type: hmUI.edit_type.CAL, preview: 'kcal1.png' },
                { type: hmUI.edit_type.HEART, preview: 'heart1.png' },
                { type: hmUI.edit_type.PAI, preview: 'pai1.png' },
                { type: hmUI.edit_type.STAND, preview: 'stand1.png' },
                { type: hmUI.edit_type.STRESS, preview: 'stress1.png' },
                { type: hmUI.edit_type.FAT_BURN, preview: 'sport1.png'},
                { type: hmUI.edit_type.WEATHER, preview: 'weather1.png' },
                { type: hmUI.edit_type.HUMIDITY, preview: 'hum1.png' },
                { type: hmUI.edit_type.ALTIMETER, preview: 'kpa1.png' },
                { type: hmUI.edit_type.MOON, preview: 'bgmoon.png' },
                { type: hmUI.edit_type.BATTERY, preview: 'battery1.png' },
                { type: hmUI.edit_type.DISTANCE, preview: 'distance1.png' },
                { type: hmUI.edit_type.UVI, preview: 'uvi1.png' },
                { type: hmUI.edit_type.SPO2, preview: 'spo21.png' },
                { type: hmUI.edit_type.WIND, preview: 'wind1.png' },
                { type: hmUI.edit_type.SUN, preview: 'ez(3)_SUN.png' },
              ],
              count: 17,
              select_list: {
                title_font_size: 34,
                title_align_h: hmUI.align.CENTER_H,
                list_item_vspace: 8,
                list_tips_text_font_size: 32,
                list_tips_text_align_h: hmUI.align.LEFT
              },
              tips_BG: 'widget_tips.png',
              tips_x: 20,
              tips_y: -36,
              tips_width: 101,
              tips_margin: 0,
            });

            const editType_3 = editGroup_3.getProperty(hmUI.prop.CURRENT_TYPE);

            switch (editType_3) {
              case hmUI.edit_type.BATTERY:
                hmUI.createWidget(hmUI.widget.IMG, {
                  x: 167,
                  y: 269,
                  src: 'bg11.png',
                  show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_AOD,
                });

                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                  x: 216,
                  y: 360,
                  font_array: ["font_0.png","font_1.png","font_2.png","font_3.png","font_4.png","font_5.png","font_6.png","font_7.png","font_8.png","font_9.png"],
                  padding: false,
                  h_space: 0,
                  unit_sc: 'proz.png',
                  unit_tc: 'proz.png',
                  unit_en: 'proz.png',
                  align_h: hmUI.align.CENTER_H,
                  type: hmUI.data_type.BATTERY,
                  show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_AOD,
                });

                hmUI.createWidget(hmUI.widget.IMG, {
                  x: 216,
                  y: 285,
                  src: 'power.png',
                  show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_AOD,
                });

                hmUI.createWidget(hmUI.widget.IMG_POINTER, {
                  src: 'point.png',
                  center_x: 231,
                  center_y: 331,
                  x: 5,
                  y: 49,
                  start_angle: 0,
                  end_angle: 360,
                  type: hmUI.data_type.BATTERY,
                  show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_AOD,
                });
                break;

              case hmUI.edit_type.STEP:
                hmUI.createWidget(hmUI.widget.IMG, {
                  x: 167,
                  y: 269,
                  src: 'bg22.png',
                  show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_AOD,
                });

                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                  x: 208,
                  y: 360,
                  font_array: ["font_0.png","font_1.png","font_2.png","font_3.png","font_4.png","font_5.png","font_6.png","font_7.png","font_8.png","font_9.png"],
                  padding: false,
                  h_space: 0,
                  align_h: hmUI.align.CENTER_H,
                  type: hmUI.data_type.STEP,
                  show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_AOD,
                });

                hmUI.createWidget(hmUI.widget.IMG, {
                  x: 216,
                  y: 285,
                  src: 'step.png',
                  show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_AOD,
                });

                hmUI.createWidget(hmUI.widget.IMG_POINTER, {
                  src: 'point.png',
                  center_x: 231,
                  center_y: 331,
                  x: 5,
                  y: 49,
                  start_angle: 0,
                  end_angle: 360,
                  type: hmUI.data_type.STEP,
                  show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_AOD,
                });
                break;

              case hmUI.edit_type.CAL:
                hmUI.createWidget(hmUI.widget.IMG, {
                  x: 167,
                  y: 269,
                  src: 'bg22.png',
                  show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_AOD,
                });

                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                  x: 212,
                  y: 360,
                  font_array: ["font_0.png","font_1.png","font_2.png","font_3.png","font_4.png","font_5.png","font_6.png","font_7.png","font_8.png","font_9.png"],
                  padding: false,
                  h_space: 0,
                  align_h: hmUI.align.CENTER_H,
                  type: hmUI.data_type.CAL,
                  show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_AOD,
                });

                hmUI.createWidget(hmUI.widget.IMG, {
                  x: 216,
                  y: 285,
                  src: 'cal.png',
                  show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_AOD,
                });

                hmUI.createWidget(hmUI.widget.IMG_POINTER, {
                  src: 'point.png',
                  center_x: 231,
                  center_y: 331,
                  x: 5,
                  y: 49,
                  start_angle: 0,
                  end_angle: 360,
                  type: hmUI.data_type.CAL,
                  show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_AOD,
                });
                break;

              case hmUI.edit_type.HEART:
                hmUI.createWidget(hmUI.widget.IMG, {
                  x: 167,
                  y: 269,
                  src: 'bg44.png',
                  show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_AOD,
                });

                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                  x: 217,
                  y: 360,
                  font_array: ["font_0.png","font_1.png","font_2.png","font_3.png","font_4.png","font_5.png","font_6.png","font_7.png","font_8.png","font_9.png"],
                  padding: false,
                  h_space: 0,
                  align_h: hmUI.align.CENTER_H,
                  type: hmUI.data_type.HEART,
                  show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_AOD,
                });

                hmUI.createWidget(hmUI.widget.IMG, {
                  x: 216,
                  y: 285,
                  src: 'heart.png',
                  show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_AOD,
                });

                hmUI.createWidget(hmUI.widget.IMG_POINTER, {
                  src: 'point.png',
                  center_x: 231,
                  center_y: 331,
                  x: 5,
                  y: 49,
                  start_angle: 0,
                  end_angle: 360,
                  type: hmUI.data_type.HEART,
                  show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_AOD,
                });
                break;

              case hmUI.edit_type.PAI:
                hmUI.createWidget(hmUI.widget.IMG, {
                  x: 167,
                  y: 269,
                  src: 'bg55.png',
                  show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_AOD,
                });

                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                  x: 215,
                  y: 360,
                  font_array: ["font_0.png","font_1.png","font_2.png","font_3.png","font_4.png","font_5.png","font_6.png","font_7.png","font_8.png","font_9.png"],
                  padding: false,
                  h_space: 0,
                  align_h: hmUI.align.CENTER_H,
                  type: hmUI.data_type.PAI_WEEKLY,
                  show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_AOD,
                });

                hmUI.createWidget(hmUI.widget.IMG, {
                  x: 216,
                  y: 285,
                  src: 'PAI.png',
                  show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_AOD,
                });

                hmUI.createWidget(hmUI.widget.IMG_POINTER, {
              src: 'point.png',
              center_x: 231,
              center_y: 331,
              x: 5,
              y: 49,
              start_angle: 0,
              end_angle: 360,
              type: hmUI.data_type.PAI_WEEKLY,
              show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_AOD,
                });
                break;

              case hmUI.edit_type.DISTANCE:
                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                  x: 210,
                  y: 360,
                  font_array: ["font_0.png","font_1.png","font_2.png","font_3.png","font_4.png","font_5.png","font_6.png","font_7.png","font_8.png","font_9.png"],
                  padding: false,
                  h_space: 0,
                  dot_image: 'dot.png',
                  align_h: hmUI.align.CENTER_H,
                  type: hmUI.data_type.DISTANCE,
                  show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_AOD,
                });

                hmUI.createWidget(hmUI.widget.IMG, {
                  x: 216,
                  y: 285,
                  src: 'distance.png',
                  show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_AOD,
                });
                break;

              case hmUI.edit_type.STAND:
                hmUI.createWidget(hmUI.widget.IMG, {
                  x: 167,
                  y: 269,
                  src: 'bg44.png',
                  show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_AOD,
                });

                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                  x: 222,
                  y: 360,
                  font_array: ["font_0.png","font_1.png","font_2.png","font_3.png","font_4.png","font_5.png","font_6.png","font_7.png","font_8.png","font_9.png"],
                  padding: true,
                  h_space: 0,
                  align_h: hmUI.align.LEFT,
                  type: hmUI.data_type.STAND,
                  show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_AOD,
                });

                editableZone_3_stand_current_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
                  x: 216,
                  y: 285,
                  src: 'stand.png',
                  show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_AOD,
                });

                hmUI.createWidget(hmUI.widget.IMG_POINTER, {
              src: 'point.png',
              center_x: 231,
              center_y: 331,
              x: 5,
              y: 49,
              start_angle: 0,
              end_angle: 360,
              type: hmUI.data_type.STAND,
              show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_AOD,
                });
                break;

              case hmUI.edit_type.STRESS:
                hmUI.createWidget(hmUI.widget.IMG, {
                  x: 167,
                  y: 269,
                  src: 'bg55.png',
                  show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_AOD,
                });

                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                  x: 217,
                  y: 360,
                  font_array: ["font_0.png","font_1.png","font_2.png","font_3.png","font_4.png","font_5.png","font_6.png","font_7.png","font_8.png","font_9.png"],
                  padding: false,
                  h_space: 0,
                  align_h: hmUI.align.CENTER_H,
                  type: hmUI.data_type.STRESS,
                  show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_AOD,
                });

                hmUI.createWidget(hmUI.widget.IMG, {
                  x: 216,
                  y: 285,
                  src: 'pressure.png',
                  show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_AOD,
                });

                hmUI.createWidget(hmUI.widget.IMG_POINTER, {
                  src: 'point.png',
                  center_x: 231,
                  center_y: 331,
                  x: 5,
                  y: 49,
                  start_angle: 0,
                  end_angle: 360,
                  type: hmUI.data_type.STRESS,
                  show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_AOD,
                });
                break;

              case hmUI.edit_type.FAT_BURN:
                hmUI.createWidget(hmUI.widget.IMG, {
              x: 167,
              y: 269,
              src: 'bg22.png',
              show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_AOD,
                });

                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                  x: 214,
                  y: 360,
                  font_array: ["font_0.png","font_1.png","font_2.png","font_3.png","font_4.png","font_5.png","font_6.png","font_7.png","font_8.png","font_9.png"],
                  padding: false,
                  h_space: 0,
                  unit_sc: 'min.png',
                  unit_tc: 'min.png',
                  unit_en: 'min.png',
                  align_h: hmUI.align.CENTER_H,
                  type: hmUI.data_type.FAT_BURNING,
                  show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_AOD,
                });

                hmUI.createWidget(hmUI.widget.IMG, {
                  x: 216,
                  y: 285,
                  src: 'fat_burning.png',
                  show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_AOD,
                });

                hmUI.createWidget(hmUI.widget.IMG_POINTER, {
                  src: 'point.png',
                  center_x: 231,
                  center_y: 331,
                  x: 5,
                  y: 49,
                  start_angle: 0,
                  end_angle: 360,
                  type: hmUI.data_type.FAT_BURNING,
                  show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_AOD,
                });
                break;

              case hmUI.edit_type.SPO2:
                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                  x: 213,
                  y: 360,
                  font_array: ["font_0.png","font_1.png","font_2.png","font_3.png","font_4.png","font_5.png","font_6.png","font_7.png","font_8.png","font_9.png"],
                  padding: false,
                  h_space: 0,
                  unit_sc: 'proz.png',
                  unit_tc: 'proz.png',
                  unit_en: 'proz.png',
                  align_h: hmUI.align.CENTER_H,
                  type: hmUI.data_type.SPO2,
                  show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_AOD,
                });

                hmUI.createWidget(hmUI.widget.IMG, {
                  x: 216,
                  y: 285,
                  src: 'spo2.png',
                  show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_AOD,
                });
                break;

              case hmUI.edit_type.WEATHER:
                hmUI.createWidget(hmUI.widget.IMG, {
                  x: 167,
                  y: 269,
                  src: 'bg33.png',
                  show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_AOD,
                });

                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                  x: 216,
                  y: 360,
                  font_array: ["font_0.png","font_1.png","font_2.png","font_3.png","font_4.png","font_5.png","font_6.png","font_7.png","font_8.png","font_9.png"],
                  padding: false,
                  h_space: 0,
                  unit_sc: 'gradus.png',
                  unit_tc: 'gradus.png',
                  unit_en: 'gradus.png',
                  negative_image: 'minus.png',
                  align_h: hmUI.align.CENTER_H,
                  type: hmUI.data_type.WEATHER_CURRENT,
                  show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_AOD,
                });

                hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
                  x: 209,
                  y: 285,
                  image_array: ["weather_1.png","weather_2.png","weather_3.png","weather_4.png","weather_5.png","weather_6.png","weather_7.png","weather_8.png","weather_9.png","weather_10.png","weather_11.png","weather_12.png","weather_13.png","weather_14.png","weather_15.png","weather_16.png","weather_17.png","weather_18.png","weather_19.png","weather_20.png","weather_21.png","weather_22.png","weather_23.png","weather_24.png","weather_25.png","weather_26.png","weather_27.png","weather_28.png","weather_29.png"],
                  image_length: 29,
                  type: hmUI.data_type.WEATHER_CURRENT,
                  show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_AOD,
                });
                break;

              case hmUI.edit_type.UVI:
                hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
                  x: 167,
                  y: 269,
                  image_array: ["bg44.png","bg55.png","bg_edit_1.png","bg_edit_2.png","bg_edit_3.png"],
                  image_length: 5,
                  type: hmUI.data_type.UVI,
                  show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_AOD,
                });

                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                  x: 223,
                  y: 360,
                  font_array: ["font_0.png","font_1.png","font_2.png","font_3.png","font_4.png","font_5.png","font_6.png","font_7.png","font_8.png","font_9.png"],
                  padding: false,
                  h_space: 0,
                  align_h: hmUI.align.CENTER_H,
                  type: hmUI.data_type.UVI,
                  show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_AOD,
                });

                hmUI.createWidget(hmUI.widget.IMG, {
                  x: 216,
                  y: 285,
                  src: 'UVI.png',
                  show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_AOD,
                });

                hmUI.createWidget(hmUI.widget.IMG_POINTER, {
                  src: 'point.png',
                  center_x: 231,
                  center_y: 331,
                  x: 5,
                  y: 49,
                  start_angle: 0,
                  end_angle: 360,
                  type: hmUI.data_type.UVI,
                  show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_AOD,
                });
                break;

              case hmUI.edit_type.HUMIDITY:
                hmUI.createWidget(hmUI.widget.IMG, {
                  x: 167,
                  y: 269,
                  src: 'bg22.png',
                  show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_AOD,
                });

                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                  x: 215,
                  y: 360,
                  font_array: ["font_0.png","font_1.png","font_2.png","font_3.png","font_4.png","font_5.png","font_6.png","font_7.png","font_8.png","font_9.png"],
                  padding: false,
                  h_space: 0,
                  unit_sc: 'proz.png',
                  unit_tc: 'proz.png',
                  unit_en: 'proz.png',
                  align_h: hmUI.align.CENTER_H,
                  type: hmUI.data_type.HUMIDITY,
                  show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_AOD,
                });

                hmUI.createWidget(hmUI.widget.IMG, {
                  x: 218,
                  y: 285,
                  src: 'humidity.png',
                  show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_AOD,
                });

                hmUI.createWidget(hmUI.widget.IMG_POINTER, {
                  src: 'point.png',
                  center_x: 231,
                  center_y: 331,
                  x: 5,
                  y: 49,
                  start_angle: 0,
                  end_angle: 360,
                  type: hmUI.data_type.HUMIDITY,
                  show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_AOD,
                });
                break;

              case hmUI.edit_type.ALTIMETER:
                hmUI.createWidget(hmUI.widget.IMG, {
                  x: 167,
                  y: 269,
                  src: 'bg44.png',
                  show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_AOD,
                });

                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                  x: 212,
                  y: 360,
                  font_array: ["font_0.png","font_1.png","font_2.png","font_3.png","font_4.png","font_5.png","font_6.png","font_7.png","font_8.png","font_9.png"],
                  padding: false,
                  h_space: 0,
                  align_h: hmUI.align.CENTER_H,
                  type: hmUI.data_type.ALTIMETER,
                  show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_AOD,
                });

                hmUI.createWidget(hmUI.widget.IMG, {
                  x: 218,
                  y: 285,
                  src: 'KPA.png',
                  show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_AOD,
                });

                hmUI.createWidget(hmUI.widget.IMG_POINTER, {
                  src: 'point.png',
                  center_x: 231,
                  center_y: 331,
                  x: 5,
                  y: 49,
                  start_angle: 0,
                  end_angle: 360,
                  type: hmUI.data_type.ALTIMETER,
                  show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_AOD,
                });
                break;

              case hmUI.edit_type.SUN:
                hmUI.createWidget(hmUI.widget.IMG_POINTER, {
                  src: 'weather_4.png',
                  center_x: 232,
                  center_y: 334,
                  x: 21,
                  y: 84,
                  start_angle: -93,
                  end_angle: 86,
                  type: hmUI.data_type.SUN_CURRENT,
                  show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_AOD,
                });

                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                  x: 210,
                  y: 318,
                  font_array: ["font_0.png","font_1.png","font_2.png","font_3.png","font_4.png","font_5.png","font_6.png","font_7.png","font_8.png","font_9.png"],
                  padding: false,
                  h_space: 0,
                  dot_image: 'dot.png',
                  align_h: hmUI.align.LEFT,
                  type: hmUI.data_type.SUN_RISE,
                  show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_AOD,
                });

                hmUI.createWidget(hmUI.widget.IMG, {
                  x: 216,
                  y: 292,
                  src: 'sun1.png',
                  show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_AOD,
                });

                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                  x: 210,
                  y: 365,
                  font_array: ["font_0.png","font_1.png","font_2.png","font_3.png","font_4.png","font_5.png","font_6.png","font_7.png","font_8.png","font_9.png"],
                  padding: false,
                  h_space: 0,
                  dot_image: 'dot.png',
                  align_h: hmUI.align.LEFT,
                  type: hmUI.data_type.SUN_SET,
                  show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_AOD,
                });

                hmUI.createWidget(hmUI.widget.IMG, {
                  x: 215,
                  y: 337,
                  src: 'sun2.png',
                  show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_AOD,
                });
                break;

              case hmUI.edit_type.WIND:
                hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
                  x: 211,
                  y: 285,
                  image_array: ["winds_1.png","winds_2.png","winds_3.png","winds_4.png","winds_5.png","winds_6.png","winds_7.png","winds_8.png"],
                  image_length: 8,
                  type: hmUI.data_type.WIND_DIRECTION,
                  show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_AOD,
                });

                hmUI.createWidget(hmUI.widget.IMG, {
                  x: 167,
                  y: 269,
                  src: 'bg22.png',
                  show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_AOD,
                });

                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                  x: 221,
                  y: 360,
                  font_array: ["font_0.png","font_1.png","font_2.png","font_3.png","font_4.png","font_5.png","font_6.png","font_7.png","font_8.png","font_9.png"],
                  padding: false,
                  h_space: 0,
                  align_h: hmUI.align.CENTER_H,
                  type: hmUI.data_type.WIND,
                  show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_AOD,
                });

                hmUI.createWidget(hmUI.widget.IMG_POINTER, {
                  src: 'point.png',
                  center_x: 231,
                  center_y: 331,
                  x: 5,
                  y: 49,
                  start_angle: 0,
                  end_angle: 360,
                  type: hmUI.data_type.WIND,
                  show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_AOD,
                });
                break;

              case hmUI.edit_type.MOON:
            hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
                  x: 155,
                  y: 258,
                  image_array: ["moon_01.png","moon_02.png","moon_03.png","moon_04.png","moon_05.png","moon_06.png","moon_07.png","moon_08.png","moon_09.png","moon_10.png","moon_11.png","moon_12.png","moon_13.png","moon_14.png","moon_15.png","moon_16.png","moon_17.png","moon_18.png","moon_19.png","moon_20.png","moon_21.png","moon_22.png","moon_23.png","moon_24.png","moon_25.png","moon_26.png","moon_27.png","moon_28.png","moon_29.png","moon_30.png"],
                  image_length: 30,
                  type: hmUI.data_type.MOON,
                  show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_AOD,
            });
                break;
            }; // end switch

            fg_mask = hmUI.createWidget(hmUI.widget.WATCHFACE_EDIT_FG_MASK, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: 'mask70.png',
              show_level: hmUI.show_level.ONLY_EDIT,
            });

            const pointerEdit = hmUI.createWidget(hmUI.widget.WATCHFACE_EDIT_POINTER, {
              edit_id: 1003,
              x: 0,
              y: 0,
              config: [
                {
                  id: 1,
                  second: {
                    centerX: 233,
                    centerY: 233,
                    posX: 13,
                    posY: 232,
                    path: 'hand_all_sec.png',
                  },
                  hour: {
                    centerX: 233,
                    centerY: 233,
                    posX: 11,
                    posY: 167,
                    path: 'hand_4_h.png',
                  },
                  minute: {
                    centerX: 233,
                    centerY: 233,
                    posX: 17,
                    posY: 222,
                    path: 'hand_4_m.png',
                  },
                  preview: 'preview1.png',
                },
                {
                  id: 2,
                  second: {
                    centerX: 233,
                    centerY: 233,
                    posX: 13,
                    posY: 232,
                    path: 'hand_all_sec.png',
                  },
                  hour: {
                    centerX: 233,
                    centerY: 233,
                    posX: 16,
                    posY: 167,
                    path: 'hand_1_h.png',
                  },
                  minute: {
                    centerX: 233,
                    centerY: 233,
                    posX: 17,
                    posY: 231,
                    path: 'hand_1_m.png',
                  },
                  preview: 'preview2.png',
                },
                {
                  id: 3,
                  second: {
                    centerX: 233,
                    centerY: 233,
                    posX: 13,
                    posY: 237,
                    path: 'hand_all_s.png',
                  },
                  hour: {
                    centerX: 233,
                    centerY: 233,
                    posX: 16,
                    posY: 167,
                    path: 'hand_2_h.png',
                  },
                  minute: {
                    centerX: 233,
                    centerY: 233,
                    posX: 17,
                    posY: 232,
                    path: 'hand_2_m.png',
                  },
                  preview: 'preview3.png',
                },
                {
                  id: 4,
                  second: {
                    centerX: 233,
                    centerY: 233,
                    posX: 13,
                    posY: 232,
                    path: 'hand_all_sec.png',
                  },
                  hour: {
                    centerX: 233,
                    centerY: 233,
                    posX: 12,
                    posY: 167,
                    path: 'hand_3_h.png',
                  },
                  minute: {
                    centerX: 233,
                    centerY: 233,
                    posX: 17,
                    posY: 222,
                    path: 'hand_3_m.png',
                  },
                  preview: 'preview4.png',
                },
              ],
              count: 4,
              default_id: 1,
              fg: 'fg.png',
              tips_x: 175,
              tips_y: 406,
              tips_bg: 'bg_tips.png',
            });
            const pointerProp = pointerEdit.getProperty(hmUI.prop.CURRENT_CONFIG, true);
            editableTimePointers = hmUI.createWidget(hmUI.widget.TIME_POINTER, pointerProp);


                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}