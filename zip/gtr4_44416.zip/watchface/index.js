﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        //const logger = Logger.getLogger('watchface_SashaCX75');
        const logger = DeviceRuntimeCore.HmLogger.getLogger('watchface_SashaCX75')
        //end of ignored block

        //dynamic modify start

        
        let normal_background_bg = ''
        let normal_temperature_icon_img = ''
        let normal_weather_image_progress_img_level = ''
        let normal_temperature_high_text_img = ''
        let normal_temperature_low_text_img = ''
        let normal_temperature_current_text_img = ''
        let normal_date_img_date_week_img = ''
        let normal_date_img_date_month_img = ''
        let normal_moon_image_progress_img_level = ''
        let normal_system_disconnect_img = ''
        let normal_altimeter_text_text_img = ''
        let normal_wind_text_text_img = ''
        let normal_wind_image_progress_img_level = ''
        let normal_humidity_text_text_img = ''
        let normal_uvi_text_text_img = ''
        let normal_battery_text_text_img = ''
        let normal_heart_rate_text_text_img = ''
        let normal_step_current_text_img = ''
        let normal_date_img_date_day = ''
        let normal_digital_clock_img_time = ''
        let normal_step_jumpable_img_click = ''
        let normal_heart_jumpable_img_click = ''
        let normal_battery_jumpable_img_click = ''
        let normal_sunrise_jumpable_img_click = ''
        let normal_countdown_jumpable_img_click = ''
        let normal_stopwatch_jumpable_img_click = ''
		
			/********************************
*	класс AdvancedBarometer		*
*		v1.2 (через сенсор)		*
*		2025 © leXxiR [4pda]	*
********************************/
	class AdvancedBarometer {
	  constructor(props = {}) {
		this.props = {
			unit_index: hmFS.SysProGetInt('BaroUnitIndex') ?? 0,		// текущий индекс единицы измерения (сохраняется и считывается из памяти): 0 - мм рт.ст., 1 - гПа
			show_toast: true,											// показывать всплывающее сообщение при переключении единицы измерения
			widget: null,												// виджет TEXT для отображения давления
			show_trend: true,											// показывать тренд (растет, падает) после значения давления при обновлении виджета
			time_sensor: null,											// сенсор времени (для обновления давления), если не задан, то создается новый
			baro_sensor: null,											// сенсор давления, если не задан, то создается новый
			auto_update: true,											// автоматическое обновление давления (нет необходимости добавлять метод .update() в event.MINUTEEND и WIDGET_DELEGATE)
			d_time: 30,													// период времени (в мин), после которого происходит переинициализация опорного давления
			lang: hmSetting.getLanguage() == 4 ? 0 : 1,					// языка устройства	(Русский = 0 / Английский = 1)
			...props,
		};

		this.unitStr = [	['мм рт.ст.',  'mmHg'],		// 0
							['гПа',  'hPa'],			// 1	
						]

		this.last = {
			value: null,
			trend: '',
		}

		this.prev = {
			value: null,
			time: 0,
		}

		if (!this.props.time_sensor) this.props.time_sensor = hmSensor.createSensor(hmSensor.id.TIME);
		if (!this.props.baro_sensor) this.props.baro_sensor = hmSensor.createSensor(hmSensor.id.BARO);
		if (isFinite(props.unit_index)) hmFS.SysProSetInt('BaroUnitIndex', props.unit_index);
		if (this.props.auto_update) this.createHandlers();
	  }

	// создание обработчиков автоматического обновления давления
		createHandlers() {
			this.props.time_sensor.addEventListener(this.props.time_sensor.event.MINUTEEND, () => this.update());

			this.widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
			  resume_call: ( () => this.update() )
			})
		}

	// получить текущее значения  давления и тренда
		getPressureAndTrend(){
			const value = this.props.baro_sensor.pressure;
			//const value = randomInt(980, 1020)

			let trend = '';
			let pressureChange = 0;
			
			if (value && this.prev.value) pressureChange = value - this.prev.value;

			if (pressureChange < 0) trend = "↓";
			else if (pressureChange > 0) trend = "↑";

			return {value, trend}
		}

	// задать опорное показание давления и время его измерения
		set referenceValue(v) {
			this.prev.value = v;
			this.prev.time = Date.now();
		}

	// пришло время обновить опорное значение (если прошло времени больше, чем d_time)
		get needToUpdateReference() {
			return (Date.now() - this.prev.time > this.props.d_time * 1000 * 60)
		}

	// установить единицы измерения по индексу: 0 - мм рт.ст., 1 - гПа
		setUnits(unit_index) {
			if(!isFinite(unit_index)) return
			this.props.unit_index = unit_index == 1 ? 1 : 0;
			hmFS.SysProSetInt('BaroUnitIndex', this.props.unit_index);
			if (this.props.widget) this.updateWidget();
		}

	// переключить единицы измерения на следующие по кругу
		toggleUnits(show_toast = this.props.show_toast) {
			const newIndex = (this.props.unit_index + 1) % this.unitStr.length;
			this.setUnits(newIndex);
			if (show_toast) hmUI.showToast({text: this.unit});
		}

	// обновить показания давления и виджет
		update() {
			const {value, trend}  = this.getPressureAndTrend();
			if (value != this.last.value || trend != this.last.trend){
				this.last.value = value;
				this.last.trend = trend;
				if (this.props.widget) this.updateWidget();
			}
			
			// обновляем опорное значение, если вышло время
			if (this.needToUpdateReference) this.referenceValue = value;
		}

	// обновить виджет
		updateWidget() {
			let str = this.pressure;
			if (this.props.show_trend) str += ` ${this.last.trend}`;
			this.props.widget.setProperty(hmUI.prop.TEXT, str);
		}

	// получить текущее значение давление в мм рт. ст.
		get mmHg() {
			let v = this.last.value;
			if (!(v)) return '--'
			else v *= 0.750064;
			return Math.round(v).toString();
		}

	// получить текущее значение давление в гПа
		get hPa() {
			let v = this.last.value;
			if (!(v)) return '--'
			return this.last.value
		}

	// получить давление в текущих единицах измерения
		get pressure() {
			if (this.props.unit_index == 0) return this.mmHg
			else return this.hPa
		}

	// получить название текущей единицы измерения
		get unit() {
			return this.unitStr[this.props.unit_index][this.props.lang]
		}

	// получить индекс текущей единицы измерения
		get unit_index() {
			return this.props.unit_index
		}

	// получить тренд
		get trend() {
			return this.last.trend
		}

	// удалить
	  delete() {
		this.props = null;
		this.last = null;
		this.unitStr = null;
		if (this.widgetDelegate) {
			hmUI.deleteWidget(this.widgetDelegate);
			this.widgetDelegate = null;
		}
	  }

	}



        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            console.log('Watch_Face.ScreenNormal');
            normal_background_bg = hmUI.createWidget(hmUI.widget.FILL_RECT, {
              x: 0,
              y: 0,
              w: 466,
              h: 466,
              color: '0xFF000000',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'wi_3_1.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 8,
              y: 167,
              image_array: ["w_0.png","w_1.png","w_2.png","w_3.png","w_4.png","w_5.png","w_6.png","w_7.png","w_8.png","w_9.png","w_10.png","w_11.png","w_12.png","w_13.png","w_14.png","w_15.png","w_16.png","w_17.png","w_18.png","w_19.png","w_20.png","w_21.png","w_22.png","w_23.png","w_24.png","w_25.png","w_26.png","w_27.png","w_28.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_high_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 170,
              y: 130,
              font_array: ["ddig_00.png","ddig_01.png","ddig_02.png","ddig_03.png","ddig_04.png","ddig_05.png","ddig_06.png","ddig_07.png","ddig_08.png","ddig_09.png"],
              padding: false,
              h_space: 1,
              negative_image: 'mminus.png',
              invalid_image: 'mminus.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_HIGH,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_low_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 170,
              y: 102,
              font_array: ["ddig_00.png","ddig_01.png","ddig_02.png","ddig_03.png","ddig_04.png","ddig_05.png","ddig_06.png","ddig_07.png","ddig_08.png","ddig_09.png"],
              padding: false,
              h_space: 1,
              negative_image: 'mminus.png',
              invalid_image: 'mminus.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_LOW,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 100,
              y: 48,
              font_array: ["dig_00.png","dig_01.png","dig_02.png","dig_03.png","dig_04.png","dig_05.png","dig_06.png","dig_07.png","dig_08.png","dig_09.png"],
              padding: false,
              h_space: 3,
              negative_image: 'minus.png',
              invalid_image: 'minus.png',
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 194,
              y: 250,
              week_en: ["day_01.png","day_02.png","day_03.png","day_04.png","day_05.png","day_06.png","day_07.png"],
              week_tc: ["day_01.png","day_02.png","day_03.png","day_04.png","day_05.png","day_06.png","day_07.png"],
              week_sc: ["day_01.png","day_02.png","day_03.png","day_04.png","day_05.png","day_06.png","day_07.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_month_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 193,
              month_startY: 172,
              month_sc_array: ["month_01.png","month_02.png","month_03.png","month_04.png","month_05.png","month_06.png","month_07.png","month_08.png","month_09.png","month_10.png","month_11.png","month_12.png"],
              month_tc_array: ["month_01.png","month_02.png","month_03.png","month_04.png","month_05.png","month_06.png","month_07.png","month_08.png","month_09.png","month_10.png","month_11.png","month_12.png"],
              month_en_array: ["month_01.png","month_02.png","month_03.png","month_04.png","month_05.png","month_06.png","month_07.png","month_08.png","month_09.png","month_10.png","month_11.png","month_12.png"],
              month_is_character: true ,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_moon_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 342,
              y: 186,
              image_array: ["moon_01.png","moon_02.png","moon_03.png","moon_04.png","moon_05.png","moon_06.png","moon_07.png","moon_08.png","moon_09.png","moon_10.png","moon_11.png","moon_12.png","moon_13.png","moon_14.png","moon_15.png","moon_16.png","moon_17.png","moon_18.png","moon_19.png","moon_20.png","moon_21.png","moon_22.png","moon_23.png","moon_24.png","moon_25.png","moon_26.png","moon_27.png","moon_28.png","moon_29.png","moon_30.png"],
              image_length: 30,
              type: hmUI.data_type.MOON,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 186,
              y: 427,
              src: 'blue.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_altimeter_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 311,
              y: 125,
              font_array: ["ddig_00.png","ddig_01.png","ddig_02.png","ddig_03.png","ddig_04.png","ddig_05.png","ddig_06.png","ddig_07.png","ddig_08.png","ddig_09.png"],
              padding: false,
              h_space: 2,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.ALTIMETER,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
			
			// экземпляр класса
			const barometer = new AdvancedBarometer({
				widget: normal_altimeter_text_text_img,
			});

            normal_wind_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 304,
              y: 92,
              font_array: ["ddig_00.png","ddig_01.png","ddig_02.png","ddig_03.png","ddig_04.png","ddig_05.png","ddig_06.png","ddig_07.png","ddig_08.png","ddig_09.png"],
              padding: false,
              h_space: 2,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WIND,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_wind_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 342,
              y: 84,
              image_array: ["wind_01.png","wind_02.png","wind_03.png","wind_04.png","wind_05.png","wind_06.png","wind_07.png","wind_08.png"],
              image_length: 8,
              type: hmUI.data_type.WIND,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_humidity_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 294,
              y: 60,
              font_array: ["ddig_00.png","ddig_01.png","ddig_02.png","ddig_03.png","ddig_04.png","ddig_05.png","ddig_06.png","ddig_07.png","ddig_08.png","ddig_09.png"],
              padding: false,
              h_space: 2,
              unit_sc: 'proc.png',
              unit_tc: 'proc.png',
              unit_en: 'proc.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HUMIDITY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_uvi_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 301,
              y: 28,
              font_array: ["ddig_00.png","ddig_01.png","ddig_02.png","ddig_03.png","ddig_04.png","ddig_05.png","ddig_06.png","ddig_07.png","ddig_08.png","ddig_09.png"],
              padding: false,
              h_space: 2,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.UVI,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 308,
              y: 402,
              font_array: ["ddig_00.png","ddig_01.png","ddig_02.png","ddig_03.png","ddig_04.png","ddig_05.png","ddig_06.png","ddig_07.png","ddig_08.png","ddig_09.png"],
              padding: false,
              h_space: 3,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 109,
              y: 402,
              font_array: ["ddig_00.png","ddig_01.png","ddig_02.png","ddig_03.png","ddig_04.png","ddig_05.png","ddig_06.png","ddig_07.png","ddig_08.png","ddig_09.png"],
              padding: false,
              h_space: 3,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 189,
              y: 402,
              font_array: ["ddig_00.png","ddig_01.png","ddig_02.png","ddig_03.png","ddig_04.png","ddig_05.png","ddig_06.png","ddig_07.png","ddig_08.png","ddig_09.png"],
              padding: false,
              h_space: 3,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 204,
              day_startY: 213,
              day_sc_array: ["dig_00.png","dig_01.png","dig_02.png","dig_03.png","dig_04.png","dig_05.png","dig_06.png","dig_07.png","dig_08.png","dig_09.png"],
              day_tc_array: ["dig_00.png","dig_01.png","dig_02.png","dig_03.png","dig_04.png","dig_05.png","dig_06.png","dig_07.png","dig_08.png","dig_09.png"],
              day_en_array: ["dig_00.png","dig_01.png","dig_02.png","dig_03.png","dig_04.png","dig_05.png","dig_06.png","dig_07.png","dig_08.png","dig_09.png"],
              day_zero: 1,
              day_space: 2,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 120,
              hour_startY: 315,
              hour_array: ["dig_00.png","dig_01.png","dig_02.png","dig_03.png","dig_04.png","dig_05.png","dig_06.png","dig_07.png","dig_08.png","dig_09.png"],
              hour_zero: 1,
              hour_space: 3,
              hour_angle: 0,
              hour_align: hmUI.align.RIGHT,

              minute_startX: 203,
              minute_startY: 315,
              minute_array: ["dig_00.png","dig_01.png","dig_02.png","dig_03.png","dig_04.png","dig_05.png","dig_06.png","dig_07.png","dig_08.png","dig_09.png"],
              minute_zero: 1,
              minute_space: 3,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.CENTER_H,

              second_startX: 285,
              second_startY: 315,
              second_array: ["dig_00.png","dig_01.png","dig_02.png","dig_03.png","dig_04.png","dig_05.png","dig_06.png","dig_07.png","dig_08.png","dig_09.png"],
              second_zero: 1,
              second_space: 3,
              second_angle: 0,
              second_follow: 0,
              second_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            console.log('Watch_Face.Shortcuts');

            normal_step_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 188,
              y: 372,
              w: 90,
              h: 90,
              src: 'empty.png',
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 86,
              y: 372,
              w: 90,
              h: 90,
              src: 'empty.png',
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 288,
              y: 372,
              w: 90,
              h: 90,
              src: 'empty.png',
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sunrise_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 338,
              y: 183,
              w: 100,
              h: 100,
              src: 'empty.png',
              type: hmUI.data_type.SUN_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_countdown_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 112,
              y: 295,
              w: 80,
              h: 80,
              src: 'empty.png',
              type: hmUI.data_type.COUNT_DOWN,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_stopwatch_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 275,
              y: 295,
              w: 80,
              h: 80,
              src: 'empty.png',
              type: hmUI.data_type.STOP_WATCH,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
			
			hmUI.createWidget(hmUI.widget.BUTTON, {
            x: 182,        // координата кнопки X
            y: 182,      // координата кнопки Y
            w: 100,       // ширина кнопки
            h: 100,      // высота кнопки
            text: '',      // здесь можно написать текст, который будет на кнопке
            normal_src: 'empty.png',         // картинка кнопки, тут пустая
            press_src: 'empty.png',           // картинка кнопки при нажатии, тут пустая
            click_func: () => {
	        hmApp.startApp({ appid: 1057409, url: 'page/index' });         // вот тут вызывается нужное приложение
            },
            show_level: hmUI.show_level.ONLY_NORMAL,
            });
			
			hmUI.createWidget(hmUI.widget.BUTTON, {
            x: 25,        // координата кнопки X
            y: 182,      // координата кнопки Y
            w: 100,       // ширина кнопки
            h: 100,      // высота кнопки
            text: '',      // здесь можно написать текст, который будет на кнопке
            normal_src: 'empty.png',         // картинка кнопки, тут пустая
            press_src: 'empty.png',           // картинка кнопки при нажатии, тут пустая
            click_func: () => {
	        hmApp.startApp({ appid: 1051195, url: 'page/index', params: { from_wf: true} });         // вот тут вызывается нужное приложение
            },
            show_level: hmUI.show_level.ONLY_NORMAL,
            });


                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}