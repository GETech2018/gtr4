﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        const logger = Logger.getLogger('watchface_SashaCX75');
        //end of ignored block

        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_date_img_date_year = ''
        let normal_date_img_date_month = ''
        let normal_date_month_separator_img = ''
        let normal_date_img_date_day = ''
        let normal_date_day_separator_img = ''
        let normal_heart_rate_text_text_img = ''
        let normal_heart_rate_text_separator_img = ''
        let normal_step_current_text_img = ''
        let normal_step_current_separator_img = ''
        let normal_battery_circle_scale = ''
        let normal_analog_clock_time_pointer_hour = ''
        let normal_analog_clock_time_pointer_minute = ''
        let normal_analog_clock_time_pointer_second = ''
        let idle_background_bg = ''
        let idle_date_img_date_year = ''
        let idle_date_img_date_month = ''
        let idle_date_month_separator_img = ''
        let idle_date_img_date_day = ''
        let idle_date_day_separator_img = ''
        let idle_heart_rate_text_text_img = ''
        let idle_heart_rate_text_separator_img = ''
        let idle_step_current_text_img = ''
        let idle_step_current_separator_img = ''
        let idle_battery_circle_scale = ''
        let idle_analog_clock_time_pointer_hour = ''
        let idle_analog_clock_time_pointer_minute = ''
        let idle_analog_clock_time_pointer_second = ''
        let normal_step_jumpable_img_click = ''
        let normal_heart_jumpable_img_click = ''


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            console.log('Watch_Face.ScreenNormal');
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 466,
              h: 466,
              src: 'bg.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_year = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              year_startX: 279,
              year_startY: 256,
              year_sc_array: ["step00.png","step01.png","step02.png","step03.png","step04.png","step05.png","step06.png","step07.png","step08.png","step09.png"],
              year_tc_array: ["step00.png","step01.png","step02.png","step03.png","step04.png","step05.png","step06.png","step07.png","step08.png","step09.png"],
              year_en_array: ["step00.png","step01.png","step02.png","step03.png","step04.png","step05.png","step06.png","step07.png","step08.png","step09.png"],
              year_zero: 0,
              year_space: 0,
              year_align: hmUI.align.LEFT,
              year_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_month = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 279,
              month_startY: 220,
              month_sc_array: ["step00.png","step01.png","step02.png","step03.png","step04.png","step05.png","step06.png","step07.png","step08.png","step09.png"],
              month_tc_array: ["step00.png","step01.png","step02.png","step03.png","step04.png","step05.png","step06.png","step07.png","step08.png","step09.png"],
              month_en_array: ["step00.png","step01.png","step02.png","step03.png","step04.png","step05.png","step06.png","step07.png","step08.png","step09.png"],
              month_zero: 1,
              month_space: 0,
              month_align: hmUI.align.CENTER_H,
              month_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_month_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 279,
              y: 239,
              src: 'kreska.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 279,
              day_startY: 184,
              day_sc_array: ["step00.png","step01.png","step02.png","step03.png","step04.png","step05.png","step06.png","step07.png","step08.png","step09.png"],
              day_tc_array: ["step00.png","step01.png","step02.png","step03.png","step04.png","step05.png","step06.png","step07.png","step08.png","step09.png"],
              day_en_array: ["step00.png","step01.png","step02.png","step03.png","step04.png","step05.png","step06.png","step07.png","step08.png","step09.png"],
              day_zero: 0,
              day_space: 0,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_day_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 279,
              y: 203,
              src: 'kreska.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 193,
              y: 144,
              font_array: ["step00.png","step01.png","step02.png","step03.png","step04.png","step05.png","step06.png","step07.png","step08.png","step09.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 158,
              y: 143,
              src: 'hearth.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 166,
              y: 295,
              font_array: ["step00.png","step01.png","step02.png","step03.png","step04.png","step05.png","step06.png","step07.png","step08.png","step09.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 139,
              y: 293,
              src: 'step.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_battery_circle_scale = hmUI.createWidget(hmUI.widget.Circle_Scale, {
              // center_x: 233,
              // center_y: 233,
              // start_angle: 0,
              // end_angle: 360,
              // radius: 234,
              // line_width: 6,
              // line_cap: Flat,
              // color: 0xFF00FF00,
              // mirror: False,
              // inversion: False,
              // type: hmUI.data_type.BATTERY,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            let screenType = hmSetting.getScreenType();
            normal_battery_circle_scale = hmUI.createWidget(hmUI.widget.ARC_PROGRESS, {
              center_x: 233,
              center_y: 233,
              start_angle: 0,
              end_angle: 360,
              radius: 231,
              line_width: 6,
              corner_flag: 3,
              color: 0xFF00FF00,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            
            const battery = hmSensor.createSensor(hmSensor.id.BATTERY);
            battery.addEventListener(hmSensor.event.CHANGE, function() {
              scale_call();
            });

            normal_analog_clock_time_pointer_hour = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              hour_path: 'hour.png',
              hour_centerX: 233,
              hour_centerY: 233,
              hour_posX: 81,
              hour_posY: 313,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_minute = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              minute_path: 'minute.png',
              minute_centerX: 233,
              minute_centerY: 233,
              minute_posX: 43,
              minute_posY: 219,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_second = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              second_path: 'second.png',
              second_centerX: 233,
              second_centerY: 233,
              second_posX: 33,
              second_posY: 229,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            console.log('Watch_Face.ScreenAOD');
            idle_background_bg = hmUI.createWidget(hmUI.widget.FILL_RECT, {
              x: 0,
              y: 0,
              w: 466,
              h: 466,
              color: '0xFF000000',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_year = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              year_startX: 279,
              year_startY: 256,
              year_sc_array: ["step00.png","step01.png","step02.png","step03.png","step04.png","step05.png","step06.png","step07.png","step08.png","step09.png"],
              year_tc_array: ["step00.png","step01.png","step02.png","step03.png","step04.png","step05.png","step06.png","step07.png","step08.png","step09.png"],
              year_en_array: ["step00.png","step01.png","step02.png","step03.png","step04.png","step05.png","step06.png","step07.png","step08.png","step09.png"],
              year_zero: 0,
              year_space: 0,
              year_align: hmUI.align.LEFT,
              year_is_character: false,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_month = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 279,
              month_startY: 220,
              month_sc_array: ["step00.png","step01.png","step02.png","step03.png","step04.png","step05.png","step06.png","step07.png","step08.png","step09.png"],
              month_tc_array: ["step00.png","step01.png","step02.png","step03.png","step04.png","step05.png","step06.png","step07.png","step08.png","step09.png"],
              month_en_array: ["step00.png","step01.png","step02.png","step03.png","step04.png","step05.png","step06.png","step07.png","step08.png","step09.png"],
              month_zero: 1,
              month_space: 0,
              month_align: hmUI.align.CENTER_H,
              month_is_character: false,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_month_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 279,
              y: 239,
              src: 'kreska.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 279,
              day_startY: 184,
              day_sc_array: ["step00.png","step01.png","step02.png","step03.png","step04.png","step05.png","step06.png","step07.png","step08.png","step09.png"],
              day_tc_array: ["step00.png","step01.png","step02.png","step03.png","step04.png","step05.png","step06.png","step07.png","step08.png","step09.png"],
              day_en_array: ["step00.png","step01.png","step02.png","step03.png","step04.png","step05.png","step06.png","step07.png","step08.png","step09.png"],
              day_zero: 0,
              day_space: 0,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_day_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 279,
              y: 203,
              src: 'kreska.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 193,
              y: 144,
              font_array: ["step00.png","step01.png","step02.png","step03.png","step04.png","step05.png","step06.png","step07.png","step08.png","step09.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_heart_rate_text_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 158,
              y: 143,
              src: 'hearth.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 166,
              y: 295,
              font_array: ["step00.png","step01.png","step02.png","step03.png","step04.png","step05.png","step06.png","step07.png","step08.png","step09.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_step_current_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 139,
              y: 293,
              src: 'step.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            // idle_battery_circle_scale = hmUI.createWidget(hmUI.widget.Circle_Scale, {
              // center_x: 233,
              // center_y: 233,
              // start_angle: 0,
              // end_angle: 360,
              // radius: 234,
              // line_width: 6,
              // line_cap: Flat,
              // color: 0xFF00FF00,
              // mirror: False,
              // inversion: False,
              // type: hmUI.data_type.BATTERY,
              // show_level: hmUI.show_level.ONLY_AOD,
            // });

            idle_battery_circle_scale = hmUI.createWidget(hmUI.widget.ARC_PROGRESS, {
              center_x: 233,
              center_y: 233,
              start_angle: 0,
              end_angle: 360,
              radius: 231,
              line_width: 6,
              corner_flag: 3,
              color: 0xFF00FF00,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_analog_clock_time_pointer_hour = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              hour_path: 'hour.png',
              hour_centerX: 233,
              hour_centerY: 233,
              hour_posX: 81,
              hour_posY: 313,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_analog_clock_time_pointer_minute = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              minute_path: 'minute.png',
              minute_centerX: 233,
              minute_centerY: 233,
              minute_posX: 43,
              minute_posY: 219,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_analog_clock_time_pointer_second = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              second_path: 'second.png',
              second_centerX: 233,
              second_centerY: 233,
              second_posX: 33,
              second_posY: 229,
              show_level: hmUI.show_level.ONLY_AOD,
            });
            console.log('Watch_Face.Shortcuts');

            normal_step_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 141,
              y: 289,
              w: 153,
              h: 41,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 157,
              y: 137,
              w: 126,
              h: 42,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            function scale_call() {
              console.log('scale_call()');

                console.log('update scales BATTERY');
                
                let valueBattery = battery.current;
                let targetBattery = 100;
                let progressBattery = valueBattery/targetBattery;
                if (progressBattery > 1) progressBattery = 1;
                let progress_cs_normal_battery = progressBattery;

                if (screenType != hmSetting.screen_type.AOD) {

                  // normal_battery_circle_scale_circle_scale
                  let level = Math.round(progress_cs_normal_battery * 100);
                  if (normal_battery_circle_scale) {
                    normal_battery_circle_scale.setProperty(hmUI.prop.MORE, {                      
                      center_x: 233,
                      center_y: 233,
                      start_angle: 0,
                      end_angle: 360,
                      radius: 231,
                      line_width: 6,
                      corner_flag: 3,
                      color: 0xFF00FF00,
                      show_level: hmUI.show_level.ONLY_NORMAL,
                      level: level,
                    });
                  };
                };

                console.log('update scales BATTERY');
                let progress_cs_idle_battery = progressBattery;

                if (screenType == hmSetting.screen_type.AOD) {

                  // idle_battery_circle_scale_circle_scale
                  let level = Math.round(progress_cs_idle_battery * 100);
                  if (idle_battery_circle_scale) {
                    idle_battery_circle_scale.setProperty(hmUI.prop.MORE, {                      
                      center_x: 233,
                      center_y: 233,
                      start_angle: 0,
                      end_angle: 360,
                      radius: 231,
                      line_width: 6,
                      corner_flag: 3,
                      color: 0xFF00FF00,
                      show_level: hmUI.show_level.ONLY_AOD,
                      level: level,
                    });
                  };
                };

            };

            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                console.log('resume_call()');
                scale_call();
              }),
            });

                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}