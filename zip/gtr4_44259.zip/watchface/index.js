﻿
    /*
    ** Watch_Face_Editor tool
    ** watchface js version v1.0.1
    ** Copyright © CashaCX75. All Rights Reserved
    */

    try {

      (() => {

        var __$$app$$__ = __$$hmAppManager$$__.currentApp;
        var __$$module$$__ = __$$app$$__.current;
        //drink is a name,can modify
        var h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__), 'drink');

        'use strict';

        //dynamic modify start

        
        let normal_background_bg = ''
        let normal_digital_clock_img_time = ''
        let normal_date_img_date_day = ''
        let normal_date_img_date_week_img = ''
        let normal_analog_clock_time_pointer_minute = ''
        let normal_analog_clock_time_pointer_hour = ''
        let normal_analog_clock_time_pointer_second = ''
        let normal_calorie_icon_img = ''
        let idle_background_bg = ''
        let idle_digital_clock_img_time = ''
        let idle_step_icon_img = ''


        //dynamic modify end

        //not required
        const logger = DeviceRuntimeCore.HmLogger.getLogger("yeguang");

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({

          init_view() {

            //dynamic modify start
                    
            
            normal_background_bg = hmUI.createWidget(hmUI.widget.FILL_RECT, {
              x: 0,
              y: 0,
              w: 466,
              h: 466,
              color: '0xFF000000',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 13,
              hour_startY: -67,
              hour_array: ["shadow_0001.png","shadow_0002.png","shadow_0003.png","shadow_0004.png","shadow_0005.png","shadow_0006.png","shadow_0007.png","shadow_0008.png","shadow_0009.png","shadow_0010.png"],
              hour_zero: 1,
              hour_space: -299,
              hour_align: hmUI.align.LEFT,

              minute_startX: 13,
              minute_startY: 114,
              minute_array: ["shadow_0001.png","shadow_0002.png","shadow_0003.png","shadow_0004.png","shadow_0005.png","shadow_0006.png","shadow_0007.png","shadow_0008.png","shadow_0009.png","shadow_0010.png"],
              minute_zero: 1,
              minute_space: -299,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 33,
              day_startY: 141,
              day_sc_array: ["Date_share_28_0001.png","Date_share_28_0002.png","Date_share_28_0003.png","Date_share_28_0004.png","Date_share_28_0005.png","Date_share_28_0006.png","Date_share_28_0007.png","Date_share_28_0008.png","Date_share_28_0009.png","Date_share_28_0010.png"],
              day_tc_array: ["Date_share_28_0001.png","Date_share_28_0002.png","Date_share_28_0003.png","Date_share_28_0004.png","Date_share_28_0005.png","Date_share_28_0006.png","Date_share_28_0007.png","Date_share_28_0008.png","Date_share_28_0009.png","Date_share_28_0010.png"],
              day_en_array: ["Date_share_28_0001.png","Date_share_28_0002.png","Date_share_28_0003.png","Date_share_28_0004.png","Date_share_28_0005.png","Date_share_28_0006.png","Date_share_28_0007.png","Date_share_28_0008.png","Date_share_28_0009.png","Date_share_28_0010.png"],
              day_zero: 0,
              day_space: 0,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 53,
              y: -10,
              week_en: ["Day_share_28_0001.png","Day_share_28_0002.png","Day_share_28_0003.png","Day_share_28_0004.png","Day_share_28_0005.png","Day_share_28_0006.png","Day_share_28_0007.png"],
              week_tc: ["Day_share_28_0001.png","Day_share_28_0002.png","Day_share_28_0003.png","Day_share_28_0004.png","Day_share_28_0005.png","Day_share_28_0006.png","Day_share_28_0007.png"],
              week_sc: ["Day_share_28_0001.png","Day_share_28_0002.png","Day_share_28_0003.png","Day_share_28_0004.png","Day_share_28_0005.png","Day_share_28_0006.png","Day_share_28_0007.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_minute = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              minute_path: 'Picture42M.png',
              minute_centerX: 233,
              minute_centerY: 233,
              minute_posX: 32,
              minute_posY: 202,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_hour = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              hour_path: 'Picture42H.png',
              hour_centerX: 233,
              hour_centerY: 233,
              hour_posX: 31,
              hour_posY: 145,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_second = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              second_path: 'Picture27.png',
              second_centerX: 233,
              second_centerY: 233,
              second_posX: 12,
              second_posY: 236,
              second_cover_path: 'Picture29.png',
              second_cover_x: 202,
              second_cover_y: 202,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_calorie_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: -33,
              y: -21,
              src: 'ring_edge_double.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            idle_background_bg = hmUI.createWidget(hmUI.widget.FILL_RECT, {
              x: 0,
              y: 0,
              w: 466,
              h: 466,
              color: '0xFF000000',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 13,
              hour_startY: -67,
              hour_array: ["shadow_0001.png","shadow_0002.png","shadow_0003.png","shadow_0004.png","shadow_0005.png","shadow_0006.png","shadow_0007.png","shadow_0008.png","shadow_0009.png","shadow_0010.png"],
              hour_zero: 1,
              hour_space: -299,
              hour_align: hmUI.align.LEFT,

              minute_startX: 13,
              minute_startY: 114,
              minute_array: ["shadow_0001.png","shadow_0002.png","shadow_0003.png","shadow_0004.png","shadow_0005.png","shadow_0006.png","shadow_0007.png","shadow_0008.png","shadow_0009.png","shadow_0010.png"],
              minute_zero: 1,
              minute_space: -299,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_step_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: -38,
              y: 12,
              src: 'AOB Overlay.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });


            //dynamic modify end
          },

          onInit() {
            console.log('index page.js on init invoke')

            this.init_view()

          },

          onReady() {
            console.log('index page.js on ready invoke')
          },

          onShow() {
            console.log('index page.js on show invoke')
          },

          onHide() {
            console.log('index page.js on hide invoke')
          },

          onDestory() {
            console.log('index page.js on destory invoke')
          },
        });

      })()
    } catch (e) {
      console.log(e)
    }
  