﻿    /*
    ** Watch_Face_Editor tool v 18.0
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        //const logger = Logger.getLogger('watchface_SashaCX75');
        const logger = DeviceRuntimeCore.HmLogger.getLogger('watchface_SashaCX75')
        //end of ignored block

        //dynamic modify start

        
        console.log('user_functions.js');
        // start user_functions.js

// Необъявленные виджеты, группы и вспомогательные переменные
let normal_background = '';
let bg_edit_img = '';
let btn_str = '';
let normal_background_Pogoda = '';
let canvas = '';
let normal_temp_text_font = '';
let normal_weather_text_font = '';
let ic_graf_img = '';
let windSpeedText = '';
let chanceOfRainText = '';
let RainImg = '';
let g_ACR_panel = '';
let menu_ARC_PROGRES_bg = '';
let menu_ARC_PROGRES = '';
let g_ACR_color_PROGRES = '';
let CIRCLE_select = '';
let bg_app_text = '';
let g_Set = '';
let normal_background_Set = '';
let btn_Set_exit = '';
let btn_crown = '';
let g_btn_crown = '';
let normal_background_btn_crown = '';
let btn_crown_left = '';
let btn_crown_right = '';
let btn_crown_exit = '';
let WF_ID = '';
let btn_on = 0;
let array_ic_weater = [];
let normal_time_hour_min_text_font = '';
//let normal_time_second_text_font = '';
let normal_sun_circle_scale = '';	
let HUMIDITY_LEVEL_prov = '';	
	const arr_HUMIDITY = 	["images/Grafik/ic_activ/vl_0.png", "images/Grafik/ic_activ/vl_1.png", "images/Grafik/ic_activ/vl_2.png", "images/Grafik/ic_activ/vl_3.png", "images/Grafik/ic_activ/vl_4.png", "images/Grafik/ic_activ/vl_5.png", "images/Grafik/ic_activ/vl_6.png", "images/Grafik/ic_activ/vl_7.png", "images/Grafik/ic_activ/vl_8.png", "images/Grafik/ic_activ/vl_9.png"]	
let update_time_weather = '';	
let wind_DIRECTION_Text_zepp = '';	
let windSpeedText_zepp = '';	
let normal_temperature_Feels_img = '';	
let normal_temperature_Feels_text_font = '';	
let HUMIDITY_zepp = '';	
let HUMIDITY_prov = '';	
let HUMIDITY_LEVEL_zepp = '';	

let normal_weather_text_font_pro = ''
let normal_weather_text_info = ''
let btn_weather_info  = ''
let btn_city_info  = ''
let city_pro  = ''
var clean_pro = '';   // дополнительная часть
let normal_background_up  = ''
let normal_data_bg  = ''
let normal_bat_bg  = ''
let normal_step_bg  = ''
let normal_setka_icon_img  = ''

        let milli_dot = 0
        let dotTimer = null
var dotAlpha = [0, 43, 85, 128, 170, 212, 255];
var dotIndex = 0;

let normal_text_bag  = ''
let weatherProviderName  = ''
let btn_tip_grafik  = ''



let appLaunched = false;      // был ли запущен проблемный провайдер (1 или 2)
let blackScreenActive = false; // активен ли сейчас чёрный экран

let canvas0 = '';


const {
    width: D_W,
    height: D_H
   } = hmSetting.getDeviceInfo();

    const packageInfo = hmApp.packageInfo(); 
    WF_ID = packageInfo.appId;	

let kf = D_W / 466;

//   const baro = hmSensor.createSensor(hmSensor.id.BARO);
//    const pressureValue = baro.pressure;
//    const altitudeValue = baro.altitude;
    
      const windDirectionStr = [
       ['Северный', 'N', 'С'], // 0
       ['Сев-Вос', 'NE', 'СВ'], // 1
       ['Восточный', 'E', 'В'], // 2
       ['Юго-Вос', 'SE', 'ЮВ'], // 3
       ['Южный', 'S', 'Ю'], // 4
       ['Юго-Зап', 'SW', 'ЮЗ'], // 5
       ['Западный', 'W', 'З'], // 6
       ['Сев-Зап', 'NW', 'СЗ'], // 7
      ];


function getWindDescription(angle, lang) {
    const normalizedAngle = parseFloat(angle) % 360;
    const index = Math.floor((normalizedAngle + 22.5) / 45) % 8;
    return windDirectionStr[index][lang];
} 
    

 let screenTypeJS = hmSetting.getScreenType();







/********  класс Провайдер погоды  ********/
/******				v2.8			*******/
/******	 2025-2026 © leXxiR [4pda]	*******/

class WeatherProvider {
  constructor(props = {}) {
    this.props = {
      night_icons: [],
      index: hmFS.SysProGetInt('WeatherProviderIndex') ?? 0,
      show_toast: true,
      use_plus_sign: hmFS.SysProGetBool('WeatherProviderPlusSign') ?? true,
      full_wind_title: false,
      baro_unit_index: 0,
      temp_widget: null,
      temp_max_widget: null,
      temp_min_widget: null,
      temp_feels_widget: null,
      description_widget: null,
      cityName_widget: null,
      wind_speed_widget: null,
      wind_dir_widget: null,
      humidity_widget: null,
      pressure_widget: null,
      uvi_widget: null,
      chance_of_rain_widget: null,
      icon_widget: null,
      sunrise_widget: null,
      sunset_widget: null,
      time_sensor: null,
      weather_sensor: null,
      baro_sensor: null,
      file_name: 'weather.json',
      forecast_file_name: 'forecast.json',
      auto_update: true,
      lang: hmSetting.getLanguage() == 4 ? 0 : 1,
      ...props,
    };

    if (this.props.chance_Of_Rain && !this.props.chance_of_rain_widget)
      this.props.chance_of_rain_widget = this.props.chance_Of_Rain;
    if (this.props.windDirection_widget && !this.props.wind_dir_widget)
      this.props.wind_dir_widget = this.props.windDirection_widget;
    if (this.props.windSpeed_widget && !this.props.wind_speed_widget)
      this.props.wind_speed_widget = this.props.windSpeed_widget;

    this.providers = [
      { name: ['Zepp', 'Zepp'], appId: null },
      { name: ['Погодный сервис', 'Weather service'], appId: 1065824 },
      { name: ['RuWeather', 'RWeather'], appId: 1066654 },
    ];

    this.description = [
      ['Облачно', 'Временами дождь', 'Временами снег', 'Ясно', 'Пасмурно', 'Слабый дождь', 'Слабый снег', 'Умеренный дождь', 'Умеренный снег', 'Сильный снегопад', 'Сильный дождь', 'Песчаная буря', 'Мокрый снег', 'Туман', 'Дымка', 'Дождь с грозой', 'Метель', 'Пыльно', 'Ливень', 'Дождь с градом', 'Сильный дождь с градом', 'Сильный дождь', 'Пыльная буря', 'Сильная песчаная буря', 'Сильный дождь', 'Обновите погоду', 'Облачно ночью', 'Дождливо ночью', 'Ясно ночью'],
      ['Cloudy', 'Showers', 'Snow Showers', 'Sunny', 'Overcast', 'Light Rain', 'Light Snow', 'Moderate Rain', 'Moderate Snow', 'Heavy Snow', 'Heavy Rain', 'Sandstorm', 'Rain and Snow', 'Fog', 'Hazy', 'T-Storms', 'Snowstorm', 'Floating dust', 'Very Heavy Rainstorm', 'Rain and Hail', 'T-Storms and Hail', 'Heavy Rainstorm', 'Dust', 'Heavy sand storm', 'Rainstorm', 'Unknown', 'Cloudy Nighttime', 'Showers Nighttime', 'Sunny Nighttime'],
    ];

    this.windTitles = [
      [ ['С', 'N'], ['СВ', 'NE'], ['В', 'E'], ['ЮВ', 'SE'], ['Ю', 'S'], ['ЮЗ', 'SW'], ['З', 'W'], ['СЗ', 'NW'] ],
      [ ['Северный', 'North'], ['Северо-Восточный', 'Northeast'], ['Восточный', 'East'], ['Юго-Восточный', 'Southeast'], ['Южный', 'South'], ['Юго-Западный', 'Southwest'], ['Западный', 'West'], ['Северо-Западный', 'Northwest'] ]
    ];

    this.last = {
      weatherIcon: 25,
      weatherDescription: 'Нет данных',
      temperature: '--',
      temperatureFeels: '--',
      temperatureMax: '--',
      temperatureMin: '--',
      cityName: '--',
      windSpeed: '--',
      windDirection: '--',
      windTitle: '--',
      humidity: '--',
      pressure: '--',
      uvi: '--',
      chanceOfRain: '--',
      sunriseTime: '--',
      sunsetTime: '--',
      updateTime: '--',
      updateDate: '--',
      modTime: null,
      forecast: [],
      forecastModTime: null,
    };

    this.allProvidersData = [
      { chanceOfRain: '--', temperatureFeels: '--', windSpeed: '--', windDirection: '--' },
      { chanceOfRain: '--', temperatureFeels: '--', windSpeed: '--', windDirection: '--' },
      { chanceOfRain: '--', temperatureFeels: '--', windSpeed: '--', windDirection: '--' }
    ];

    if (!this.props.time_sensor) this.props.time_sensor = hmSensor.createSensor(hmSensor.id.TIME);
    if (!this.props.weather_sensor) this.props.weather_sensor = hmSensor.createSensor(hmSensor.id.WEATHER);
    if (!this.props.baro_sensor) this.props.baro_sensor = hmSensor.createSensor(hmSensor.id.BARO);
    if (isFinite(props.index)) hmFS.SysProSetInt('WeatherProviderIndex', props.index);
    if (this.props.auto_update) this.createHandlers();
  }

  createHandlers() {
    this.props.time_sensor.addEventListener(this.props.time_sensor.event.MINUTEEND, () => this.update());
    this.widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
      resume_call: () => this.update()
    });
  }

  arrayBufferToCyrillic(buffer) {
    let result = '';
    const bytes = new Uint8Array(buffer);
    let i = 0;
    while (i < bytes.length) {
      let byte1 = bytes[i++];
      if (byte1 < 0x80) result += String.fromCharCode(byte1);
      else if (byte1 >= 0xC0 && byte1 < 0xE0) {
        let byte2 = bytes[i++];
        let charCode = ((byte1 & 0x1F) << 6) | (byte2 & 0x3F);
        result += String.fromCharCode(charCode);
      } else if (byte1 >= 0xE0 && byte1 < 0xF0) {
        let byte2 = bytes[i++];
        let byte3 = bytes[i++];
        let charCode = ((byte1 & 0x0F) << 12) | ((byte2 & 0x3F) << 6) | (byte3 & 0x3F);
        result += String.fromCharCode(charCode);
      }
    }
    return result;
  }

  readFile(app_id, fileName) {
    if (!app_id) return null;
    let str_result = "";
    try {
      const [fs_stat, err] = hmFS.stat(fileName, { appid: app_id });
      if (err == 0) {
        const fh = hmFS.open(fileName, hmFS.O_RDONLY, { appid: app_id });
        const len = fs_stat.size;
        let array_buffer = new ArrayBuffer(len);
        hmFS.read(fh, array_buffer, 0, len);
        hmFS.close(fh);
        str_result = this.arrayBufferToCyrillic(array_buffer);
        return str_result;
      }
    } catch (error) {}
    return null;
  }

  getFileModTime(app_id, fileName) {
    if (!app_id) return null;
    try {
      const [fs_stat, err] = hmFS.stat(fileName, { appid: app_id });
      if (err == 0) return fs_stat.mtime;
    } catch (error) {}
    return null;
  }

  getDaysBetweenDates(date1, date2) {
    const d1 = new Date(date1);
    const d2 = new Date(date2);
    const diffTime = d2 - d1;
    const diffDays = Math.floor(diffTime / (1000 * 60 * 60 * 24));
    return diffDays;
  }

  isDayNow() {
    const sunData = this.props.weather_sensor.getForecastWeather().tideData;
    let sunriseMins = 8 * 60;
    let sunsetMins = 20 * 60;
    if (sunData.count > 0) {
      const today = sunData.data[0];
      sunriseMins = today.sunrise.hour * 60 + today.sunrise.minute;
      sunsetMins = today.sunset.hour * 60 + today.sunset.minute;
    }
    const curMins = this.props.time_sensor.hour * 60 + this.props.time_sensor.minute;
    return (curMins >= sunriseMins) && (curMins < sunsetMins);
  }

  getZeppIconIndex(index, app_id = null) {
    if (!app_id) return index;
    let newIndex = 25;
    if (app_id == 1065824) {
      switch(index) {
        case 1: newIndex = 3; break;
        case 2: newIndex = 0; break;
        case 3: case 4: newIndex = 4; break;
        case 5: newIndex = 1; break;
        case 6: newIndex = 5; break;
        case 7: newIndex = 10; break;
        case 8: newIndex = 15; break;
        case 9: newIndex = 6; break;
        case 10: newIndex = 8; break;
        case 11: newIndex = 9; break;
        case 12: newIndex = 12; break;
        case 13: newIndex = 13; break;
        case 14: newIndex = 17; break;
        default: newIndex = 25; break;
      }
    } else if (app_id == 1066654) {
      newIndex = index - 1;
    }
    return newIndex;
  }

  tempWithSign(val) {
    val = parseFloat(val);
    if (!isFinite(val)) return '--';
    val = Math.round(val);
    if (val > 0 && this.props.use_plus_sign) val = '+' + val;
    val += '°';
    return val;
  }

  tempWithSign0(val) {
    val = parseFloat(val);
    if (!isFinite(val)) return '--';
    val = Math.round(val);
    if (val > 0) val = '' + val;
    return val;
  }

  rainWithSign(val) {
    val = parseFloat(val);
    if (!isFinite(val)) return '--';
    return val + '';
  }

  getPressureFromSensor() {
    let v = this.props.baro_sensor.pressure;
    if (!isFinite(v)) return '--';
    if (this.props.baro_unit_index == 0) v *= 0.750064;
    return Math.round(v).toString();
  }

  formatTime(value) {
    if (value === undefined || value === null) return '--';
    if (typeof value === 'number' && isFinite(value)) {
      if (value > 1e12) {
        const date = new Date(value);
        const hours = date.getHours();
        const minutes = date.getMinutes();
        return hours.toString().padStart(2, '0') + ':' + minutes.toString().padStart(2, '0');
      }
      if (value >= 0 && value <= 1440) {
        const hours = Math.floor(value / 60);
        const minutes = value % 60;
        return hours.toString().padStart(2, '0') + ':' + minutes.toString().padStart(2, '0');
      }
      return '--';
    }
    return (value && value !== '') ? value : '--';
  }

  getZeppWeatherData() {
    const iconIndex = this.props.weather_sensor.curAirIconIndex ?? 25;
    const tideData = this.props.weather_sensor.getForecastWeather().tideData;
    let sunrise = '--', sunset = '--';
    if (tideData.count > 0) {
      const today = tideData.data[0];
      sunrise = today.sunrise.hour.toString().padStart(2,'0') + ':' + today.sunrise.minute.toString().padStart(2,'0');
      sunset  = today.sunset.hour.toString().padStart(2,'0') + ':' + today.sunset.minute.toString().padStart(2,'0');
    }
    return {
      weatherIcon: iconIndex,
      weatherDescription: this.description[this.props.lang][iconIndex],
      temperature: this.props.weather_sensor.current ?? '--',
      temperatureFeels: '--',
      chanceOfRain: '--',
      windDirection: 0,
      windSpeed: '--',
      temperatureMax: this.props.weather_sensor.high ?? '--',
      temperatureMin: this.props.weather_sensor.low ?? '--',
      cityName: this.props.weather_sensor.getForecastWeather().cityName ?? '--',
      sunriseTime: sunrise,
      sunsetTime: sunset,
      humidity: '--',
      pressure: this.getPressureFromSensor(),
      uvi: '--',
      updateTime: '--',
      updateDate: '--',
    };
  }

  getAppWeatherData(app_id) {
    const data = {
      weatherIcon: 25,
      weatherDescription: 'Нет данных',
      temperature: '--',
      temperatureFeels: '--',
      chanceOfRain: '--',
      windDirection: 0,
      windSpeed: '--',
      temperatureMax: '--',
      temperatureMin: '--',
      cityName: '--',
      sunriseTime: '--',
      sunsetTime: '--',
      humidity: '--',
      pressure: '--',
      uvi: '--',
      updateTime: '--',
      updateDate: '--',
    };

    let weather_str = this.readFile(app_id, this.props.file_name);
    if (!weather_str) return data;
    let weatherJson = JSON.parse(weather_str);
    if (!weatherJson) return data;

    if (isFinite(weatherJson.weatherIcon))
      data.weatherIcon = this.getZeppIconIndex(parseInt(weatherJson.weatherIcon), app_id);
    if (weatherJson?.weatherDescriptionExtended?.length) {
      data.weatherDescription = weatherJson.weatherDescriptionExtended;
      data.weatherDescription = data.weatherDescription[0].toUpperCase() + data.weatherDescription.slice(1);
    } else data.weatherDescription = this.description[this.props.lang][data.weatherIcon];
    if (isFinite(weatherJson.temperature)) data.temperature = Math.round(parseFloat(weatherJson.temperature));
    if (isFinite(weatherJson.temperatureFeels)) data.temperatureFeels = Math.round(parseFloat(weatherJson.temperatureFeels));
    if (isFinite(weatherJson.temperatureMax)) data.temperatureMax = Math.round(parseFloat(weatherJson.temperatureMax));
    if (isFinite(weatherJson.temperatureMin)) data.temperatureMin = Math.round(parseFloat(weatherJson.temperatureMin));
    if (isFinite(weatherJson.chanceOfRain)) data.chanceOfRain = Math.round(parseFloat(weatherJson.chanceOfRain));
    if (isFinite(weatherJson.windDirection)) data.windDirection = parseFloat(weatherJson.windDirection);
    if (isFinite(weatherJson.windSpeed)) {
      let ws = parseFloat(weatherJson.windSpeed);
      data.windSpeed = ws > 10 ? Math.round(ws) : ws.toFixed(1);
    }
    if (isFinite(weatherJson.humidity)) data.humidity = Math.round(parseFloat(weatherJson.humidity));
    
    if (isFinite(weatherJson.pressure)) {
      let p = parseFloat(weatherJson.pressure);
      if (app_id == 1065824 && this.props.baro_unit_index == 0) {
        if (p > 800) p = Math.round(p * 0.750064);
      }
      if (app_id == 1066654 && this.props.baro_unit_index == 1) p = Math.round(p * 1.33322);
      data.pressure = Math.round(p);
    }
    if (isFinite(weatherJson.uvi)) data.uvi = Math.round(parseFloat(weatherJson.uvi));
    if (weatherJson.city) data.cityName = weatherJson.city;
    if (weatherJson.sunriseTime !== undefined) data.sunriseTime = this.formatTime(weatherJson.sunriseTime);
    if (weatherJson.sunsetTime !== undefined) data.sunsetTime = this.formatTime(weatherJson.sunsetTime);
    
    if (isFinite(weatherJson.weatherTime)) {
      let dt = new Date(weatherJson.weatherTime);
      let hours = dt.getHours().toString().padStart(2, '0');
      let minutes = dt.getMinutes().toString().padStart(2, '0');
      data.updateTime = hours + ':' + minutes;
      let day = dt.getDate().toString().padStart(2, '0');
      let month = (dt.getMonth() + 1).toString().padStart(2, '0');
      data.updateDate = day + '.' + month;
    }
    
    return data;
  }

  getZeppForecast() {
    const forecastData = this.props.weather_sensor.getForecastWeather().forecastData;
    let forecast = [];
    if (forecastData && forecastData.count) {
      for (let i = 0; i < forecastData.count; i++) {
        let day = forecastData.data[i];
        forecast.push({
          weatherIcon: day.index,
          temperatureMax: Math.round(day.high),
          temperatureMin: Math.round(day.low),
        });
      }
    }
    return forecast;
  }

  getAppForecast(app_id) {
    let forecast = [];
    let forecast_str = this.readFile(app_id, this.props.forecast_file_name);
    if (!forecast_str) return forecast;
    let forecastJson = JSON.parse(forecast_str);
    if (!forecastJson) return forecast;
    let weatherTime = null;
    if (isFinite(forecastJson.weatherTime)) weatherTime = parseInt(forecastJson.weatherTime);
    if (forecastJson.forecast && Array.isArray(forecastJson.forecast)) {
      for (let i = 0; i < forecastJson.forecast.length; i++) {
        let item = forecastJson.forecast[i];
        let day = { weatherIcon: 25, temperatureMax: '--', temperatureMin: '--' };
        if (isFinite(item.weatherIcon)) day.weatherIcon = this.getZeppIconIndex(parseInt(item.weatherIcon), app_id);
        if (isFinite(item.temperatureMax)) day.temperatureMax = Math.round(parseFloat(item.temperatureMax));
        if (isFinite(item.temperatureMin)) day.temperatureMin = Math.round(parseFloat(item.temperatureMin));
        forecast.push(day);
      }
    }
    if (weatherTime !== null && forecast.length > 0) {
      let dayOffset = this.getDaysBetweenDates(weatherTime, Date.now());
      if (dayOffset < 0) dayOffset = 0;
      if (dayOffset >= forecast.length) dayOffset = 0;
      let shifted = [];
      for (let i = dayOffset; i < forecast.length; i++) shifted.push(forecast[i]);
      forecast = shifted;
    }
    return forecast;
  }

  getForecastData(app_id = null) {
    if (!app_id) return this.getZeppForecast();
    else return this.getAppForecast(app_id);
  }

  getWeatherData(app_id = null) {
    if (!app_id) return this.getZeppWeatherData();
    else return this.getAppWeatherData(app_id);
  }

  fetchProviderData(providerIndex) {
    if (providerIndex < 0 || providerIndex >= this.providers.length) return;
    const appId = this.providers[providerIndex].appId;
    if (appId === null) return;
    const weatherData = this.getAppWeatherData(appId);
    this.allProvidersData[providerIndex].chanceOfRain = weatherData.chanceOfRain;
    this.allProvidersData[providerIndex].temperatureFeels = weatherData.temperatureFeels;
    this.allProvidersData[providerIndex].windSpeed = weatherData.windSpeed;
    this.allProvidersData[providerIndex].windDirection = weatherData.windDirection;
  }

  getChanceOfRainForProvider(providerIndex) {
    return this.allProvidersData[providerIndex]?.chanceOfRain ?? '--';
  }

  getTemperatureFeelsForProvider(providerIndex) {
    return this.allProvidersData[providerIndex]?.temperatureFeels ?? '--';
  }

  getWindSpeedForProvider(providerIndex) {
    return this.allProvidersData[providerIndex]?.windSpeed ?? '--';
  }

  getWindDirectionForProvider(providerIndex) {
    return this.allProvidersData[providerIndex]?.windDirection ?? '--';
  }

  update(force_update = false) {
    let curIcon = parseInt(this.last.weatherIcon);
    const weatherModTime = this.getFileModTime(this.providers[this.props.index].appId, this.props.file_name);
    if (!weatherModTime || this.last.modTime != weatherModTime || force_update) {
      const newData = this.getWeatherData(this.providers[this.props.index].appId);
      this.last.modTime = weatherModTime;

      const idx = this.props.index;
      this.allProvidersData[idx].chanceOfRain = newData.chanceOfRain;
      this.allProvidersData[idx].temperatureFeels = newData.temperatureFeels;
      this.allProvidersData[idx].windSpeed = newData.windSpeed;
      this.allProvidersData[idx].windDirection = newData.windDirection;

      let val = this.tempWithSign(newData.temperature);
      if (val != this.last.temperature) {
        this.last.temperature = val;
        if (this.props.temp_widget) this.props.temp_widget.setProperty(hmUI.prop.TEXT, val);
      }
      val = this.tempWithSign0(newData.temperatureMax);
      if (val != this.last.temperatureMax) {
        this.last.temperatureMax = val;
        if (this.props.temp_max_widget) this.props.temp_max_widget.setProperty(hmUI.prop.TEXT, val);
      }
      val = this.tempWithSign0(newData.temperatureMin);
      if (val != this.last.temperatureMin) {
        this.last.temperatureMin = val;
        if (this.props.temp_min_widget) this.props.temp_min_widget.setProperty(hmUI.prop.TEXT, val);
      }
      val = this.tempWithSign(newData.temperatureFeels);
      if (val != this.last.temperatureFeels) {
        this.last.temperatureFeels = val;
        if (this.props.temp_feels_widget) this.props.temp_feels_widget.setProperty(hmUI.prop.TEXT, val);
      }
      val = this.rainWithSign(newData.chanceOfRain);
      if (val != this.last.chanceOfRain) {
        this.last.chanceOfRain = val;
        if (this.props.chance_of_rain_widget) this.props.chance_of_rain_widget.setProperty(hmUI.prop.TEXT, val);
      }
      if (newData.windDirection != this.last.windDirection) {
        this.last.windDirection = newData.windDirection;
        this.last.windTitle = this.getWindTitle(newData.windDirection);
        if (this.props.wind_dir_widget) this.props.wind_dir_widget.setProperty(hmUI.prop.TEXT, this.last.windTitle);
      }
      if (newData.windSpeed != this.last.windSpeed) {
        this.last.windSpeed = newData.windSpeed;
        if (this.props.wind_speed_widget) this.props.wind_speed_widget.setProperty(hmUI.prop.TEXT, newData.windSpeed.toString());
      }
      if (newData.humidity != this.last.humidity) {
        this.last.humidity = newData.humidity;
        if (this.props.humidity_widget) this.props.humidity_widget.setProperty(hmUI.prop.TEXT, newData.humidity + '%');
      }
      if (newData.uvi != this.last.uvi) {
        this.last.uvi = newData.uvi;
        if (this.props.uvi_widget) this.props.uvi_widget.setProperty(hmUI.prop.TEXT, newData.uvi.toString());
      }

      let pressureVal = newData.pressure;
      if (this.providers[this.props.index].appId == 1065824 && this.props.baro_unit_index == 0) {
        if (pressureVal > 800) pressureVal = Math.round(pressureVal * 0.750064);
      } else if (this.providers[this.props.index].appId == 1066654 && this.props.baro_unit_index == 1) {
        pressureVal = Math.round(pressureVal * 1.33322);
      }
      if (!pressureVal) pressureVal = this.getPressureFromSensor();

      if (pressureVal !== "--" && pressureVal !== undefined && pressureVal !== null) {
        pressureVal = parseFloat(pressureVal);
        if (!isNaN(pressureVal)) {
          let idx = this.props.index;
          let keyOld = "svr_press_old_" + idx;
          let keyTime = "svr_press_old_time_" + idx;
          let oldPressure = hmFS.SysProGetInt(keyOld) || 0;
          let oldTime = hmFS.SysProGetInt(keyTime) || 0;

          let now = Math.floor(Date.now() / 1000);
          let delta = 0;
          let trend = "=";

          if (oldPressure === 0 || (now - oldTime) >= 10800) {
            hmFS.SysProSetInt(keyOld, pressureVal);
            hmFS.SysProSetInt(keyTime, now);
          } else {
            delta = pressureVal - oldPressure;
            trend = (delta < 0) ? "↓" : ((delta > 0) ? "↑" : "=");
          }

          let color;
          if (this.props.baro_unit_index === 0) {
            color = (pressureVal < 760) ? 0xffff00 : ((pressureVal > 760) ? 0xff0000 : 0x00ff00);
          } else {
            color = (pressureVal < 1013.25) ? 0xffff00 : ((pressureVal > 1013.25) ? 0xff0000 : 0x00ff00);
          }
          let displayStr = Math.round(pressureVal) + trend;
          if (this.props.pressure_widget) {
            this.props.pressure_widget.setProperty(hmUI.prop.TEXT, displayStr);
            this.props.pressure_widget.setProperty(hmUI.prop.COLOR, color);
          }
          this.last.pressure = pressureVal;
        }
      }

      if (newData.updateTime != this.last.updateTime) {
        this.last.updateTime = newData.updateTime;
      }
      if (newData.updateDate != this.last.updateDate) {
        this.last.updateDate = newData.updateDate;
      }

      let cityVal = newData.cityName;
      if (typeof cityVal === 'string') cityVal = cityVal.toUpperCase();
      if (cityVal != this.last.cityName) {
        this.last.cityName = cityVal;
        if (this.props.cityName_widget) this.props.cityName_widget.setProperty(hmUI.prop.TEXT, cityVal);
      }
      let descVal = newData.weatherDescription;
      if (typeof descVal === 'string') descVal = descVal.toUpperCase();
      if (descVal != this.last.weatherDescription) {
        this.last.weatherDescription = descVal;
        if (this.props.description_widget) this.props.description_widget.setProperty(hmUI.prop.TEXT, descVal);
      }
      if (newData.sunriseTime != this.last.sunriseTime) {
        this.last.sunriseTime = newData.sunriseTime;
        if (this.props.sunrise_widget) this.props.sunrise_widget.setProperty(hmUI.prop.TEXT, newData.sunriseTime);
      }
      if (newData.sunsetTime != this.last.sunsetTime) {
        this.last.sunsetTime = newData.sunsetTime;
        if (this.props.sunset_widget) this.props.sunset_widget.setProperty(hmUI.prop.TEXT, newData.sunsetTime);
      }
      curIcon = newData.weatherIcon;
    }

    const forecastModTime = this.getFileModTime(this.providers[this.props.index].appId, this.props.forecast_file_name);
    if (!forecastModTime || this.last.forecastModTime != forecastModTime) {
      const newForecast = this.getForecastData(this.providers[this.props.index].appId);
      if (newForecast && newForecast.length) {
        this.last.forecast = newForecast;
        this.last.forecastModTime = forecastModTime;
      }
    }

    if (this.props.night_icons.includes(curIcon) && !this.isDayNow()) curIcon += 'n';
    if (curIcon != this.last.weatherIcon) {
      this.last.weatherIcon = curIcon;
      if (this.props.icon_widget) this.props.icon_widget.setProperty(hmUI.prop.SRC, "w_" + curIcon + ".png");
    }
  }

  next(show_toast = this.props.show_toast) {
    const v = (this.props.index + 1) % this.providers.length;
    this.provider = v;
    if (show_toast) hmUI.showToast({ text: this.name });
  }
  prev(show_toast = this.props.show_toast) {
    const v = (this.props.index - 1 + this.providers.length) % this.providers.length;
    this.provider = v;
    if (show_toast) hmUI.showToast({ text: this.name });
  }
  toggle(dir, show_toast = this.props.show_toast) {
    if (dir > 0) this.next(show_toast);
    else this.prev(show_toast);
  }
  set provider(v) {
    this.props.index = v;
    hmFS.SysProSetInt('WeatherProviderIndex', v);
    this.update();
  }

  get index() { return this.props.index; }
  get name() { return this.providers[this.props.index].name[this.props.lang]; }
  get cityName() { return this.last.cityName; }
  get weatherIcon() { return this.last.weatherIcon; }
  get temperature() { return this.last.temperature; }
  get temperatureMax() { return this.last.temperatureMax; }
  get temperatureMin() { return this.last.temperatureMin; }
  get temperatureFeels() { return this.last.temperatureFeels; }
  get weatherDescription() { return this.last.weatherDescription; }
  get windSpeed() { return this.last.windSpeed; }
  get windDirection() { return this.last.windDirection; }
  get windTitle() { return this.last.windTitle; }
  get uvi() { return this.last.uvi; }
  get humidity() { return this.last.humidity; }
  get pressure() { return this.last.pressure; }
  get barometer() { return this.getPressureFromSensor(); }
  get chanceOfRain() { return this.last.chanceOfRain; }
  get sunriseTime() { return this.last.sunriseTime; }
  get sunsetTime() { return this.last.sunsetTime; }
  get forecast() { return this.last.forecast; }
  get updateTime() { return this.last.updateTime; }
  get updateDate() { return this.last.updateDate; }

  getWindTitle(angle) {
    if (!isFinite(angle)) return '--';
    angle = (360 + angle) % 360;
    const i = Math.round(angle / 45) % 8;
    return this.windTitles[Number(this.props.full_wind_title)][i][this.props.lang];
  }
  set usePlusSign(v) {
    this.props.use_plus_sign = v;
    hmFS.SysProSetBool('WeatherProviderPlusSign', v);
    this.update(true);
  }
  get usePlusSign() { return this.props.use_plus_sign; }
  setProperty(v = {}) {
    this.props = { ...this.props, ...v };
    this.update(true);
  }
  getProperty(k) { return this.props[k]; }
  delete() {
    this.providers = null;
    this.props = null;
    this.last = null;
    this.description = null;
    this.windTitles = null;
    this.allProvidersData = null;
    if (this.widgetDelegate) {
      hmUI.deleteWidget(this.widgetDelegate);
      this.widgetDelegate = null;
    }
  }
}

	
      let normal_line_left = ''
      let normal_line_right = ''
        //let normal_timerTimeUpdate2 = undefined;
        let normal_weater_text_bg = ''
        let normal_mask_0_icon_img = ''
        let normal_mask_1_icon_img = ''
        let normal_mask_2_icon_img = ''
        let normal_mask_3_icon_img = ''
	
		
		
//        let normal_sun_circle_scale = ''
		
		
		
//let timeSensor = hmSensor.createSensor(hmSensor.id.TIME);	  

	
		
      
      let groupVremya = ''
      let groupPogoda = ''
      let groupTap = ''
    //  let groupActiv = ''
      //let canvas0 = ''
      //let canvas = ''


      let alpha_grey = 76
	  
	  
	  
      let normal_unit_ic_up = ''	  
      let normal_unit_ic_dw = ''	
	  
      let normal_progress_bg_0 = ''	
      let normal_progress_bg_1 = ''	
      let normal_progress_bg_2 = ''	
      let normal_progress_bg_3 = ''	



      const weatherSensor = hmSensor.createSensor(hmSensor.id.WEATHER);
     // const battery = hmSensor.createSensor(hmSensor.id.BATTERY)
     // const step = hmSensor.createSensor(hmSensor.id.STEP);
     // const heart_rate = hmSensor.createSensor(hmSensor.id.HEART); //heart_rate.last
   const distance = hmSensor.createSensor(hmSensor.id.DISTANCE);
//      const calorie = hmSensor.createSensor(hmSensor.id.CALORIE);
//      const stand = hmSensor.createSensor(hmSensor.id.STAND)
//      const pai = hmSensor.createSensor(hmSensor.id.PAI);
//      const fatburn = hmSensor.createSensor(hmSensor.id.FAT_BURRING);
//      const spo2 = hmSensor.createSensor(hmSensor.id.SPO2);
//      const stress = hmSensor.createSensor(hmSensor.id.STRESS);

let normal_background_bg = ''

let normal_weater_ic = ''





let text_pressere; // отображаем давление
let text_pressere_changes; // отображаем изменение давления 


function makeAOD() {
 //loadSettings()

 const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
  resume_call: (function () {

   stopVibro();
  }),

  pause_call: (function () {

   //    hmApp.unregisterSpinEvent();
   stopVibro();
  }),
 });


}


let Activ_color_alpha = ''
let menu = 0
let color_ic = 0
let Activ_color = 0



let Btn_set_ = []
let Shag_Y = 66

let color_bg = [
  // Группа 1 (первые 30 цветов — первые цвета из каждой ColorOption)
  [0xcfd8f7, 0x0c0e14, 0xcfd8f7, 0x0c0e14, 0xcfd8f7,
   0x0c0e14, 0xcfd8f7, 0x0c0e14, 0xcfd8f7, 0x0c0e14,
   0xcfd8f7, 0x0c0e14, 0xcfd8f7, 0x0c0e14, 0x6cff00,
   0xfff437, 0xfff100, 0xff971c, 0xff0060, 0x00a9ff,
   0x00a9ff, 0x00ffe4, 0x0c0e14, 0x0c0e14, 0x0c0e14,
   0x0c0e14, 0x0c0e14, 0x0c0e14, 0x0c0e14, 0xcfd8f7],
  
  // Группа 2 (вторые цвета из каждой ColorOption)
  [0xff5600, 0xff5600, 0x6cff00, 0x6cff00, 0xff9e00,
   0xff9e00, 0xfff100, 0xfff100, 0x00c4ff, 0x00c4ff,
   0x00ffe4, 0x00ffe4, 0xff0060, 0xff0060, 0x00a9ff,
   0x6cff00, 0xff971c, 0xff5600, 0x00c4ff, 0xfff100,
   0x00ffe4, 0xff971c, 0x6cff00, 0xff9e00, 0xff5600,
   0xff0060, 0xfff100, 0x00ffe4, 0xcfd8f7, 0xcfd8f7],
  
  // Группа 3 (третьи цвета из каждой ColorOption)
  [0x151a28, 0xcfd8f7, 0x151a28, 0xcfd8f7, 0x151a28,
   0xcfd8f7, 0x151a28, 0xcfd8f7, 0x151a28, 0xcfd8f7,
   0x151a28, 0xcfd8f7, 0x151a28, 0xcfd8f7, 0x151a28,
   0x151a28, 0x151a28, 0x000000, 0x000000, 0x151a28,
   0x151a28, 0x151a28, 0x00c4ff, 0x00c4ff, 0x00c4ff,
   0x00a9ff, 0x00c4ff, 0x00a9ff, 0xcfd8f7, 0x0c0e14],
	
  [0xff9428, 0xff4b21, 0x47ff2f, 0x00bbfb, 0xff4b21,
   0xff9428, 0xfcf135, 0x00bbfb, 0x00ffdf, 0xff0059]

];

let colorNames = ["Красный", "Алый", "Малиновый", "Тёмно-красный", "Бордовый", "Розовый", "Оранжевый", "Горчичный", "Золотой", "Жёлтый", "Лимонный", "Мятный", "Изумрудный", "Лесной зелёный", "Оливковый", "Зелёный", "Бирюзовый", "Голубой", "Лазурный", "Синий", "Тёмно-синий", "Индиго", "Пурпурный", "Пурпурный (маджента)", "Белый", "Медовый", "Бежевый", "Светло-серый", "Серый", "Тёмно-серый", "Коричневый", "Чёрный"];

let app_TF = []
let app_ic = []
let app_ACR_text = []

let app_text_arr = [
/* ['КАЛОРИИ', hmUI.data_type.CAL, false, 0, 'ic_app_0.png'],
 ['КМ', hmUI.data_type.DISTANCE, false, 0, 'ic_app_1.png'],
 ['ММ.РТ.СТ', hmUI.data_type.ALTIMETER, false, 0, 'ic_app_2.png'],
 ['ВЫСОТА', hmUI.data_type.ALTITUDE, false, 0, 'ic_app_3.png'],
 ['ВЛАЖНОСТЬ', hmUI.data_type.HUMIDITY, false, 1, 'ic_app_4.png'],
 ['НОЧЬ/ДЕНЬ', hmUI.data_type.WEATHER_HIGH_LOW, false, 0, 'ic_app_5.png'],
 ['ВОСХОД', hmUI.data_type.SUN_RISE, false, 0, 'ic_app_7.png'],
 ['СТРЕСС', hmUI.data_type.STRESS, false, 0, 'ic_app_8.png'],
 ['КИСЛОРОД', hmUI.data_type.SPO2, false, 0, 'ic_app_9.png'],
 ['PAI', hmUI.data_type.PAI_DAILY, false, 0, 'ic_app_10.png'],
 ['ЖИР', hmUI.data_type.FAT_BURNING, false, 0, 'ic_app_11.png'],
 ['УФ', hmUI.data_type.UVI, false, 0, 'ic_app_12.png'],
 ['РАЗМИНКА', hmUI.data_type.STAND, false, 0, 'ic_app_13.png'],
 // ['БУДИЛЬНИК', hmUI.data_type.ALARM_CLOCK, true, 0, 'ic_app_14.png'],
 ['ТАЙМЕР', hmUI.data_type.COUNT_DOWN, true, 0, 'ic_app_15.png'],
 ['ЭТАЖ', hmUI.data_type.FLOOR, false, 0, 'ic_app_16.png'],
 ['ВЕТЕР', hmUI.data_type.WIND, false, 0, 'ic_app_17.png'],
 ['ПУЛЬС', hmUI.data_type.HEART, false, 0, 'ic_app_18.png'],*/
];

let Line_arr = [
/* ['C', '--', 'SENS', 'КАЛОРИИ', 0xff791f, '', '--'], //0 калории
 ['L', '--', 0, 'ЭТАЖ', 0x00ff0c, hmUI.data_type.FLOOR, false], //1 ЭТАЖ
 ['^', '--', 'SENS', 'ДАВЛЕНИЕ', 0x12c200, '', '--'], //2 давление
 ['t', '--', 0, 'ГОТОВНОСТЬ', 0xccff66, hmUI.data_type.READINESS, false], //3  ГОТОВНОСТЬ
 ['I', '--', 'SENS', 'PAI', 0xff51d4, '', '--'], //4 pai
 ['O', '--', 'SENS', 'КИСЛОРОД', 0xe400ff, '', '--'], //5 o2
 ['R', '--', 'SENS', 'РАЗМИНКА', 0x01a8ff, '', '--'], //6 разминка
 ['G', '--', 'SENS', 'ЖИР', 0xd7c637, '', '--'], //7 жир
 ['V', '--', 1, 'ВАЛЖНОСТЬ', 0x00ff90, hmUI.data_type.HUMIDITY, false], //8 ВАЛЖНОСТЬ
 ['!', '--', 'SENS', 'СТРЕСС', 0xfcff00, '', '--'], //9 стресс
 ['a', '--', 'SENS', 'СОН', 0x25ced4, '', '--'], //10 сон
 [']', '--', 'SENS', 'ОСАДКИ', 0xFF0000, '', '--'], //11 садки
 ['=', '--', 'SENS', 'ОЩУЩАЕМАЯ', 0xff7e3f, '', '--'], // 12 ощущаемая
 ['W', '--', 'SENS', 'ВЕТЕР', 0x01f6ff, '', '--'], //13 ВЕТЕР
 ['f', '--', 'SENS', 'МИРОВОЕ', 0x21a5d1, '', '--'], //14 МИРОВОЕ
 ['S', '--', 'SENS', 'ШАГИ %', 0x01f6ff, '', '--'], //15 ШАГИ %
 ['U', '--', 0, 'УФ', 0x01f6ff, hmUI.data_type.UVI, false], //16 УФ
 ['E', '--', 'SENS', 'ВЫСОТА', 0x00ff06, '', '--'], //17 ВЫСОТА
 ['T', '--', 0, 'ТАЙМЕР', 0x00ff06, hmUI.data_type.COUNT_DOWN, true], //18 ТАЙМЕР
 ['r', '--', 0, 'AQI', 0xccff33, hmUI.data_type.AQI, false], //19 AQI
 ['K', '--', 'SENS', 'ВОС/ЗАК', 0x01f6ff, '', '--'], //20 ВОС/ЗАК
 ['', '', '', 'ПУСТО'], //21 пусто*/
];

let CONF_MAIN = [{ // 0. Вертикальный градиент (3 цвета)
 name: 'КОНФИГУРАЦИЯ', // кнопка
 id: 0, // при старте
 len: color_bg[0].length, // длина
 type: 'color', // цвет или данные
 colorArrayIndex: 0 // ← явно указываем индекс массива
},{ // 1. Горизонтальный градиент (2 цвета)
 name: 'СЕК СТРЕЛКА', // кнопка
 id: 0,
 len: color_bg[3].length, // длина
 type: 'color',
 colorArrayIndex: 3 // ← явно указываем индекс массива
}, /* { // 2. Одноцветный прямоугольник
 name: 'ЦВЕТ АНИМ', // кнопка
 id: 0,
 len: color_bg[2].length, // длина
 type: 'color',
 colorArrayIndex: 2 // ← явно указываем индекс массива
}, { // 3. Одноцветный прямоугольник
 name: 'КОНФИГУРАЦИЯ', // кнопка
 id: 0,
 len: color_bg[2].length, // длина
 type: 'color',
 colorArrayIndex: 2 // ← явно указываем индекс массива
}, { // 4. Одноцветный прямоугольник
 name: 'АНАЛОГ ЦВЕТ', // кнопка
 id: 0,
 len: color_bg[0].length, // длина
 type: 'color',
 colorArrayIndex: 0 // ← явно указываем индекс массива
}, { // 5. Одноцветный прямоугольник
 name: 'ПРОГРЕСС ВИД', // кнопка
 id: 0,
 len: 2, // длина
 type: 'png',
}, { // 6. Одноцветный прямоугольник
 name: 'ПРОГРЕСС ЦВЕТ', // кнопка
 id: 0,
 len: color_bg[0].length, // длина
 type: 'color', // цвет или данные
 colorArrayIndex: 0 // ← явно указываем индекс массива
},{ // 7. Одноцветный прямоугольник
 name: 'AOD тип', // кнопка
 id: 0,
 len: 3, // длина
 type: 'png_crown_off', // Новый тип - коронка отключается после выхода
}, { // 8. Кнопка конфигурации
  name: 'конфигурация',
  id: 0,
  len: 3, // 3 позиции: 0,1,2
  type: 'save_conf',
 },*/{ // 8. Одноцветный прямоугольник
 name: ['КОРОНКА ОТКЛЮЧЕНА', 'КОРОНКА ВКЛЮЧЕНА'],
 id: 0,
 len: 2,
 type: 'toggle', // тип: переключатель ВКЛ/ВЫКЛ
 //toggleBgColors: [0x800000, 0x008000], // Темно-красный для ОТКЛЮЧЕНА, Зеленый для ВКЛЮЧЕНА

}]

function loadSettings() {
//   left = hmFS.SysProGetInt(`${WF_ID}_left`) === undefined ? (hmFS.SysProSetInt(`${WF_ID}_left`, 0), 0) : hmFS.SysProGetInt(`${WF_ID}_left`);
	
  // tap_Anim = hmFS.SysProGetInt(`${WF_ID}_tap_Anim`) === undefined ? (hmFS.SysProSetInt(`${WF_ID}_tap_Anim`, 0), 0) : hmFS.SysProGetInt(`${WF_ID}_tap_Anim`);
    tip_grafik = hmFS.SysProGetInt(`${WF_ID}_tip_grafik`) === undefined ? (hmFS.SysProSetInt(`${WF_ID}_tip_grafik`, 0), 0) : hmFS.SysProGetInt(`${WF_ID}_tip_grafik`);
   // right = hmFS.SysProGetInt(`${WF_ID}_right`) === undefined ? (hmFS.SysProSetInt(`${WF_ID}_right`, 0), 0) : hmFS.SysProGetInt(`${WF_ID}_right`);	
    left = hmFS.SysProGetInt(`${WF_ID}_left`) === undefined ? (hmFS.SysProSetInt(`${WF_ID}_left`, 0), 0) : hmFS.SysProGetInt(`${WF_ID}_left`);	
	block = hmFS.SysProGetInt(`${WF_ID}_block`) === undefined ? (hmFS.SysProSetInt(`${WF_ID}_block`, 0), 0) : hmFS.SysProGetInt(`${WF_ID}_block`);

    if (hmFS.SysProGetInt(`${WF_ID}_crown`) === undefined) {
        crown = 0;
        hmFS.SysProSetInt(`${WF_ID}_crown`, crown);
    } else {
        crown = hmFS.SysProGetInt(`${WF_ID}_crown`);
    }

	
	
    // ЗАГРУЖАЕМ ВСЕ КНОПКИ (включая 7-ю) - УБЕРИТЕ -1
    for (let i = 0; i < CONF_MAIN.length; i++) {
        const defaultValue = CONF_MAIN[i].id;
        CONF_MAIN[i].id = hmFS.SysProGetInt(`${WF_ID}_color_` + i) === undefined
            ? (hmFS.SysProSetInt(`${WF_ID}_color_` + i, defaultValue), defaultValue)
            : hmFS.SysProGetInt(`${WF_ID}_color_` + i);
    }
	
}

function update_app() {

  let distanceCurrent = distance.current;
normal_widget_text_13.setProperty( hmUI.prop.TEXT,(distanceCurrent < 0 ? 0 : distanceCurrent / 1000).toFixed(2).toString());

}









      const hour_pointer = [
       [70, 211], // 0
       [60, 148], // 1
       [40, 129], // 2
       [63, 129], // 3
      ];

      const minute_pointer = [
       [61, 207], // 0
       [59, 205], // 1
       [36, 192], // 2
       [61, 207], // 3
      ];




let normal_block_FILL_RECT = ""
let btn_block = ""
let block = 0

function clik_block() {
 block = (block + 1) % 2
 hmFS.SysProSetInt(`${WF_ID}_block`, block);
// normal_widget_text_4.setProperty(hmUI.prop.TEXT, block == 0 ? 'ОТКР' : 'БЛОК');
normal_widget_text_14.setProperty(hmUI.prop.TEXT, block == 0 ? '{' : '}');	
 normal_block_FILL_RECT.setProperty(hmUI.prop.VISIBLE, block == 1);
 btn_block.setProperty(hmUI.prop.VISIBLE, block == 1);
vibro();
}




let ARC_set = [
 [383, 107, 18],
 [398, 129, 22],
 [412, 159, 26],
 [423, 192, 30],
 [427, 233, 34],
 [423, 274, 30],
 [412, 307, 26],
 [398, 337, 22],
 [383, 359, 18],
]

let menu_ARC_color = [];
let normal_left_data = [];
let normal_right_data = [];
let normal_up_data = [];

function app_update() {
 //let distanceCurrent = distance.current;
}
		
		


// Состояния экрана
const SCREEN_STATE = {
    MAIN: 'MAIN',
    SETTINGS: 'SETTINGS', 
    CROWN_MODE: 'CROWN_MODE'
};
		
// Текущее состояние экрана
let currentScreenState = SCREEN_STATE.MAIN;		
		
// ====================== ПОИСК ЭЛЕМЕНТОВ ПО ТИПУ ======================

// Функция для поиска индекса элемента по типу
function findConfigIndex(type) {
    for (let i = 0; i < CONF_MAIN.length; i++) {
        if (CONF_MAIN[i].type === type) {
            return i;
        }
    }
    return -1;
}		
		
let crownSensitivity = 70; // уровень чувствительности колесика
let color = 0;
let color_str = 0;
let bridg = 127;
let crown = 0
let text_start = 70		
		
let set = 0;
let degreeSum = 0;
let MenuCirkl_Timer = null;

let debugCounter = 0;

function showDebug(message) {
    hmUI.showToast({text: message});
}

// ====================== ОБРАБОТКА ЦИФРОВОЙ КОРОНКИ ======================

function onDigitalCrown() {
    hmApp.registerSpinEvent((key, degree) => {
        if (key !== hmApp.key.HOME) return;
        degreeSum += degree;
        if (Math.abs(degreeSum) <= crownSensitivity) return;
        
        const step = Math.sign(degreeSum);
        
        // Находим toggle элемент
        const toggleIndex = findConfigIndex('toggle');
        
        // 1. В состоянии SETTINGS коронка НЕ РАБОТАЕТ
        if (currentScreenState === SCREEN_STATE.SETTINGS) {
            degreeSum = 0;
            return;
        }
        

        
        // 3. На главном экране
        if (currentScreenState === SCREEN_STATE.MAIN) {
            // Проверяем, включена ли коронка на главном экране
            if (toggleIndex !== -1 && CONF_MAIN[toggleIndex].id === 0) {
                degreeSum = 0;
                return;
            }
            
            // Для png_crown_off НЕ обрабатываем на главном экране
            if (crown < CONF_MAIN.length && CONF_MAIN[crown].type === 'png_crown_off') {
                degreeSum = 0;
                return;
            }
            
            // Меняем параметры
            crown_color(crown, step, false);
            
            // ПОКАЗЫВАЕМ ПРОГРЕСС И ЗАПУСКАЕМ ТАЙМЕР
            g_ACR_panel.setProperty(hmUI.prop.VISIBLE, true);
            if (crown < CONF_MAIN.length && CONF_MAIN[crown].type === 'color') {
                g_ACR_color_PROGRES.setProperty(hmUI.prop.VISIBLE, true);
                updateCrownColorElements();
            }
            updateProgressArc();
            
            // ЗАПУСК ТАЙМЕРА
            if (MenuCirkl_Timer) timer.stopTimer(MenuCirkl_Timer);
            MenuCirkl_Timer = timer.createTimer(1000, 1, () => {
                g_ACR_color_PROGRES.setProperty(hmUI.prop.VISIBLE, false);
                g_ACR_panel.setProperty(hmUI.prop.VISIBLE, false);
                bg_app_text.setProperty(hmUI.prop.VISIBLE, false);
                Line_arr.forEach((_, i) => app_ACR_text[i].setProperty(hmUI.prop.VISIBLE, false));
                timer.stopTimer(MenuCirkl_Timer);
            });
            
            degreeSum = 0;
            return;
        }
        
        // 4. В режиме коронки
        if (currentScreenState === SCREEN_STATE.CROWN_MODE) {
            // Для toggle типа не обрабатываем
            if (crown < CONF_MAIN.length && CONF_MAIN[crown].type === 'toggle') {
                degreeSum = 0;
                return;
            }
            
            // Меняем параметры
            crown_color(crown, step, false);
            
            // Обновляем панель коронки
            g_ACR_panel.setProperty(hmUI.prop.VISIBLE, true);
            
            // Для цветовых элементов показываем цветовой прогресс
            if (crown < CONF_MAIN.length && CONF_MAIN[crown].type === 'color') {
                g_ACR_color_PROGRES.setProperty(hmUI.prop.VISIBLE, true);
                updateCrownColorElements();
            } else {
                g_ACR_color_PROGRES.setProperty(hmUI.prop.VISIBLE, false);
            }
            
            // Обновляем дугу прогресса
            updateProgressArc();
            
            degreeSum = 0;
            return;
        }
        
        degreeSum = 0;
    });
}


// ====================== УПРАВЛЕНИЕ СОСТОЯНИЯМИ ======================
function changeState(newState) {
    const oldState = currentScreenState;
    currentScreenState = newState;
    
    // Всегда скрываем элементы при смене состояния
    g_ACR_panel.setProperty(hmUI.prop.VISIBLE, false);
    g_ACR_color_PROGRES.setProperty(hmUI.prop.VISIBLE, false);
    bg_app_text.setProperty(hmUI.prop.VISIBLE, false);
    Line_arr.forEach((_, i) => app_ACR_text[i].setProperty(hmUI.prop.VISIBLE, false));
    
    
    switch (newState) {
        case SCREEN_STATE.MAIN:
            groupVremya.setProperty(hmUI.prop.VISIBLE, true);
            g_Set.setProperty(hmUI.prop.VISIBLE, false);
            g_btn_crown.setProperty(hmUI.prop.VISIBLE, false);
            
            // Восстанавливаем состояние через start_WG() для основного режима
            start_WG();
            
            break;
            
        case SCREEN_STATE.SETTINGS:
            groupVremya.setProperty(hmUI.prop.VISIBLE, true);
            g_Set.setProperty(hmUI.prop.VISIBLE, true);
            g_btn_crown.setProperty(hmUI.prop.VISIBLE, false);
            updateButtons();
            
            // Восстанавливаем состояние через start_WG()
          start_WG();
            
            MenuCirkl_Timer_on();
            break;
            
        case SCREEN_STATE.CROWN_MODE:
            groupVremya.setProperty(hmUI.prop.VISIBLE, true);
            g_Set.setProperty(hmUI.prop.VISIBLE, false);
            g_btn_crown.setProperty(hmUI.prop.VISIBLE, true);
            
            // Восстанавливаем состояние через start_WG()
           start_WG();
            
            // Показываем панель коронки
            g_ACR_panel.setProperty(hmUI.prop.VISIBLE, true);
            
            // Обновляем элементы в зависимости от типа
            if (crown < CONF_MAIN.length) {
                if (CONF_MAIN[crown].type === 'color') {
                    g_ACR_color_PROGRES.setProperty(hmUI.prop.VISIBLE, true);
                    updateCrownColorElements();
                } else if (CONF_MAIN[crown].type === 'text') {
                    g_ACR_color_PROGRES.setProperty(hmUI.prop.VISIBLE, false);
                    updateText();
                } else if (CONF_MAIN[crown].type === 'png' || CONF_MAIN[crown].type === 'png_crown_off') {
                    g_ACR_color_PROGRES.setProperty(hmUI.prop.VISIBLE, false);
                }
            }
            
            break;
    }
}		




// ====================== КНОПКИ ЛЕВО/ПРАВО ======================


function click_btn_crown_left() {
//    if (menu === 1 && Activ_color === 1) {
//        handleColorChange(-1);
//        return;
//    }
	
	
    if (currentScreenState !== SCREEN_STATE.CROWN_MODE) return;
    
    if (CONF_MAIN[crown].type !== 'toggle') {
        crown_color(crown, -1, false);
        
        g_ACR_panel.setProperty(hmUI.prop.VISIBLE, true);
        if (CONF_MAIN[crown].type === 'color') {
            g_ACR_color_PROGRES.setProperty(hmUI.prop.VISIBLE, true);
            updateCrownColorElements();
        } else {
            g_ACR_color_PROGRES.setProperty(hmUI.prop.VISIBLE, false);
        }
        updateProgressArc();
    }
}

function click_btn_crown_right() {
//    if (menu === 1 && Activ_color === 1) {
//        handleColorChange(1);
//        return;
//    }

	
	
    if (currentScreenState !== SCREEN_STATE.CROWN_MODE) return;
    
    if (CONF_MAIN[crown].type !== 'toggle') {
        crown_color(crown, 1, false);
        
        g_ACR_panel.setProperty(hmUI.prop.VISIBLE, true);
        if (CONF_MAIN[crown].type === 'color') {
            g_ACR_color_PROGRES.setProperty(hmUI.prop.VISIBLE, true);
            updateCrownColorElements();
        } else {
            g_ACR_color_PROGRES.setProperty(hmUI.prop.VISIBLE, false);
        }
        updateProgressArc();
    }
}





// ====================== НАСТРОЙКИ ======================
/*function click_Set_on() {
    changeState(SCREEN_STATE.SETTINGS);
}*/


function click_Set_on() {
    changeState(SCREEN_STATE.SETTINGS);
}


function click_crown(index) {
    const toggleIndex = CONF_MAIN.length - 1;
    const isToggle = index === toggleIndex;
    
    // Если коронка отключена и это не toggle-кнопка - блокируем нажатие
    if (CONF_MAIN[toggleIndex].id === 0 && !isToggle) {
        return;
    }
    
    // Обработка toggle-кнопки
    if (isToggle && CONF_MAIN[index].type === 'toggle') {
        CONF_MAIN[index].id = (CONF_MAIN[index].id + 1) % 2;
        hmFS.SysProSetInt(`${WF_ID}_color_` + index, CONF_MAIN[index].id);
        
        crown = index;
        updateButtons();
        vibro();
        return;
    }
    
    // Вся остальная логика без изменений
    if (currentScreenState === SCREEN_STATE.CROWN_MODE && CONF_MAIN[index].type === 'save_conf') {
        return;
    }
    
    if (currentScreenState === SCREEN_STATE.SETTINGS && CONF_MAIN[index].type === 'save_conf') {
        CONF_MAIN[index].id = (CONF_MAIN[index].id + 1) % CONF_MAIN[index].len;
        hmFS.SysProSetInt(`${WF_ID}_color_` + index, CONF_MAIN[index].id);
        
        crown = index;
        updateButtons();
        g_ACR_panel.setProperty(hmUI.prop.VISIBLE, true);
        updateProgressArc();
        vibro();
        return;
    }
    
    if (currentScreenState === SCREEN_STATE.SETTINGS) {
        crown = index;
        updateButtons();
        g_ACR_panel.setProperty(hmUI.prop.VISIBLE, true);
        updateProgressArc();
        updateCrownColorElements();
        updateText();
        vibro();
    }
}



function click_Set_off() {
    const toggleIndex = CONF_MAIN.length - 1;
    
    // ЕСЛИ ВЫБРАНА TOGGLE-КНОПКА
    if (crown === toggleIndex) {
        hmFS.SysProSetInt(`${WF_ID}_crown`, crown); // ← Сохраняем
        changeState(SCREEN_STATE.MAIN);
    } else {
        // Для всех остальных кнопок - старая логика
        if (CONF_MAIN[toggleIndex].id === 0) {
            hmFS.SysProSetInt(`${WF_ID}_crown`, crown); // ← Сохраняем
            changeState(SCREEN_STATE.MAIN);
        } else {
            hmFS.SysProSetInt(`${WF_ID}_crown`, crown); // ← Сохраняем
            changeState(SCREEN_STATE.CROWN_MODE);
        }
    }
}

// Функция для выхода из CROWN_MODE должна быть отдельной
function click_btn_crown_exit() {
/*    if (menu === 1 && Activ_color === 1) {
        // Выходим из режима выбора цвета
        Activ_color = 0;
        ic_activ_color_off_img.setProperty(hmUI.prop.VISIBLE, true);
        hmFS.SysProSetInt('PT31', 0);
        g_ACR_color_PROGRES.setProperty(hmUI.prop.VISIBLE, false);
        g_ACR_panel.setProperty(hmUI.prop.VISIBLE, false);
        g_btn_crown.setProperty(hmUI.prop.VISIBLE, false);
//        btn_Activ_color.setProperty(hmUI.prop.VISIBLE, true);
//        btn_Activ_off.setProperty(hmUI.prop.VISIBLE, true);
        return;
    }*/
    changeState(SCREEN_STATE.MAIN);
}

function updateCrownColorElements() {
    // Показываем прогресс только для COLOR типа
    g_ACR_color_PROGRES.setProperty(hmUI.prop.VISIBLE, CONF_MAIN[crown].type === 'color');
    
    if (CONF_MAIN[crown].type === 'color') {
        updateProgressArc(); // ✓ Без параметров - использует значения по умолчанию из CONF_MAIN[crown]
        
        // Обновляем цветные элементы
        const colorInfo = getColorInfo();
        updateArcElements(CONF_MAIN[crown].id, colorInfo.colorArray);
    }
}


function updateColorUI(index, colorArray) {


 // Обновление цветовых арок
 for (let i = 0; i < ARC_set.length; i++) {
  const colorIndex = index - 4 + i;
  const colorValue = colorArray[colorIndex];
  const hasColor = colorValue !== undefined && colorValue !== null;

  menu_ARC_color[i].setProperty(hmUI.prop.MORE, {
   center_x: ARC_set[i][0],
   center_y: ARC_set[i][1],
   radius: ARC_set[i][2] / 2,
   color: hasColor ? colorValue : 0,
   alpha: hasColor ? 255 : 0,
   show_level: hmUI.show_level.ONLY_NORMAL,
  });
 }
}

// ====================== УНИВЕРСАЛЬНЫЕ ФУНКЦИИ ======================
function updateColorElements(targetIndex, colorArray, isMainColor = false) {


 // Обновление цветовых арок
 for (let i = 0; i < ARC_set.length; i++) {
  const colorIndex = targetIndex - 4 + i;
  const colorValue = colorArray[colorIndex];
  const hasColor = colorValue !== undefined && colorValue !== null;

  menu_ARC_color[i].setProperty(hmUI.prop.MORE, {
   center_x: ARC_set[i][0],
   center_y: ARC_set[i][1],
   radius: ARC_set[i][2] / 2,
   color: hasColor ? colorValue : 0,
   alpha: hasColor ? 255 : 0,
   show_level: hmUI.show_level.ONLY_NORMAL,
  });
 }

 // Для основного цвета обновляем прогресс
 if (isMainColor) {
  updateProgressArc(colorArray.length, targetIndex);
 }
}

function updateArcElements(startIndex, colorArray) {
    for (let i = 0; i < ARC_set.length; i++) {
        const colorIndex = startIndex - 4 + i;
        const colorValue = colorArray[colorIndex];
        const hasColor = colorValue !== undefined && colorValue !== null;

        menu_ARC_color[i].setProperty(hmUI.prop.MORE, {
            center_x: ARC_set[i][0],
            center_y: ARC_set[i][1],
            radius: ARC_set[i][2] / 2,
            color: hasColor ? colorValue : 0,
            alpha: hasColor ? 255 : 0,
            show_level: hmUI.show_level.ONLY_NORMAL,
        });
    }
}

// ====================== ОСНОВНЫЕ ФУНКЦИИ (БЕЗ ИЗМЕНЕНИЙ) ======================
/*function handleColorChange(step) {
    color_ic = Math.max(0, Math.min(color_bg[1].length - 1, color_ic + step));
    degreeSum = 0;
    hmFS.SysProSetInt(`${WF_ID}_color_ic`, color_ic);

    updateColorUI(color_ic, color_bg[1]);
    updateProgressArc(color_bg[1].length, color_ic); // ✓ Правильно: передаем длину массива цветов и индекс
    g_ACR_panel.setProperty(hmUI.prop.VISIBLE, true);
    g_ACR_color_PROGRES.setProperty(hmUI.prop.VISIBLE, true);
    vibro();
}*/

const KEY_SENSITIVITY = 3; // Чувствительность кнопок (2-быстро, 5-медленно)

function onKeyEvent() {
  let pressCounter = 0;

  hmApp.registerKeyEvent((key, action) => {
    if (action !== hmApp.action.CLICK) return;

    const direction = (key === hmApp.key.UP) ? 1 : -1;
    pressCounter++;

    if (pressCounter < KEY_SENSITIVITY) return;
    pressCounter = 0;



    // 2. В состоянии SETTINGS - НЕ обрабатываем (кнопки вверх/вниз не работают в настройках)
    if (currentScreenState === SCREEN_STATE.SETTINGS) {
      return;
    }

    // 3. На главном экране (MAIN)
    if (currentScreenState === SCREEN_STATE.MAIN) {
      // Для png_crown_off НЕ обрабатываем на главном экране
      const aodIndex = findConfigIndex('png_crown_off');
      if (aodIndex !== -1 && crown === aodIndex && CONF_MAIN[aodIndex].type === 'png_crown_off') {
        return;
      }

      // Меняем параметры
      crown_color(crown, direction, false);

      // ПОКАЗЫВАЕМ ПРОГРЕСС И ЗАПУСКАЕМ ТАЙМЕР
      g_ACR_panel.setProperty(hmUI.prop.VISIBLE, true);
      if (CONF_MAIN[crown].type === 'color') {
        g_ACR_color_PROGRES.setProperty(hmUI.prop.VISIBLE, true);
        updateCrownColorElements();
      }
      updateProgressArc();

      // ЗАПУСК ТАЙМЕРА
      if (MenuCirkl_Timer) timer.stopTimer(MenuCirkl_Timer);
      MenuCirkl_Timer = timer.createTimer(1000, 1, () => {
        g_ACR_color_PROGRES.setProperty(hmUI.prop.VISIBLE, false);
        g_ACR_panel.setProperty(hmUI.prop.VISIBLE, false);
        bg_app_text.setProperty(hmUI.prop.VISIBLE, false);
        Line_arr.forEach((_, i) => app_ACR_text[i].setProperty(hmUI.prop.VISIBLE, false));
        timer.stopTimer(MenuCirkl_Timer);
      });

      vibro();
      return;
    }

    // 4. В режиме коронки (CROWN_MODE)
    if (currentScreenState === SCREEN_STATE.CROWN_MODE) {
      // Для toggle типа не обрабатываем
      if (CONF_MAIN[crown].type === 'toggle') {
        return;
      }

      // Меняем параметры
      crown_color(crown, direction, false);

      // Обновляем панель коронки
      g_ACR_panel.setProperty(hmUI.prop.VISIBLE, true);

      // Для цветовых элементов показываем цветовой прогресс
      if (CONF_MAIN[crown].type === 'color') {
        g_ACR_color_PROGRES.setProperty(hmUI.prop.VISIBLE, true);
        updateCrownColorElements();
      } else {
        // Для всех остальных типов (включая png_crown_off) скрываем цветовой прогресс
        g_ACR_color_PROGRES.setProperty(hmUI.prop.VISIBLE, false);
      }

      // Обновляем дугу прогресса
      updateProgressArc();

      vibro();
      return;
    }
  });
}
		
		
// ====================== ФУНКЦИИ С МИНИМАЛЬНЫМИ ИЗМЕНЕНИЯМИ ======================
function MenuCirkl_Timer_off() {
 if (btn_on == 0) {
  if (MenuCirkl_Timer) timer.stopTimer(MenuCirkl_Timer);
  MenuCirkl_Timer = timer.createTimer(1000, 1, () => {
   g_ACR_color_PROGRES.setProperty(hmUI.prop.VISIBLE, false);
   g_ACR_panel.setProperty(hmUI.prop.VISIBLE, false);
   bg_app_text.setProperty(hmUI.prop.VISIBLE, false);
   Line_arr.forEach((_, i) => app_ACR_text[i].setProperty(hmUI.prop.VISIBLE, false));
   timer.stopTimer(MenuCirkl_Timer);
  });
 }
}

function MenuCirkl_Timer_on() {
 if (btn_on == 0) {
  if (MenuCirkl_Timer) timer.stopTimer(MenuCirkl_Timer);
  MenuCirkl_Timer = timer.createTimer(1000, 1, () => {
   g_Set.setProperty(hmUI.prop.VISIBLE, true);
   timer.stopTimer(MenuCirkl_Timer);
  });
 }
}


// ====================== ФУНКЦИИ БЕЗ ИЗМЕНЕНИЙ ======================
function handleCrownNavigation() {
 crown_color(crown, 0, true);
}
		
function processCrownAction(step) {


    if (Activ_color === 0 && menu === 0) {
        // Используем currentScreenState напрямую
        if (currentScreenState === SCREEN_STATE.SETTINGS) {
            // В настройках меняем выбранную кнопку
            handleCrownNavigation();
            
            // Показываем прогресс в настройках и запускаем таймер
            g_ACR_panel.setProperty(hmUI.prop.VISIBLE, true);
            updateProgressArc();
            MenuCirkl_Timer_off();
            
            return true;
        } else if (currentScreenState === SCREEN_STATE.CROWN_MODE) {
            // В режиме коронки меняем параметры
            crown_color(crown, step, false);
            return true;
        } else if (currentScreenState === SCREEN_STATE.MAIN) {
            // На главном экране, если коронка включена
            if (CONF_MAIN[CONF_MAIN.length - 1].id === 1) {
                // Проверяем тип элемента - для 'png_crown_off' не обрабатываем
                if (CONF_MAIN[crown].type === 'png_crown_off') {
                    return false;
                }
                
                crown_color(crown, step, false);
                return true;
            }
        }

    }

    return false;
}		


// Вспомогательная функция для обновления текстовых элементов
function updateText() {
    // Показываем/скрываем текстовые элементы в зависимости от типа
    const isTextType = CONF_MAIN[crown].type === 'text';
    bg_app_text.setProperty(hmUI.prop.VISIBLE, isTextType);
    
    Line_arr.forEach((_, i) => {
        app_ACR_text[i].setProperty(hmUI.prop.VISIBLE, isTextType);
        // Подсвечиваем выбранный элемент
        if (isTextType) {
            app_ACR_text[i].setProperty(hmUI.prop.COLOR, 
                CONF_MAIN[crown].id == i ? 0xff0000 : 0xffffff);
        }
    });
    
    // Для не-текстовых типов скрываем текстовые элементы
    if (!isTextType) {
        bg_app_text.setProperty(hmUI.prop.VISIBLE, false);
        Line_arr.forEach((_, i) => app_ACR_text[i].setProperty(hmUI.prop.VISIBLE, false));
    }
}		

function offKeyEvent() {
 try {
  hmApp.unregisterKeyEvent();
 } catch (e) {
  console.log("Unregister key event error:", e);
 }
}

function updateProgressArc(len = CONF_MAIN[crown].len, id = CONF_MAIN[crown].id) {
 menu_ARC_PROGRES.setProperty(hmUI.prop.MORE, {
  center_x: D_W / 2,
  center_y: D_W / 2,
  start_angle: 45 + 81 / len * id,
  end_angle: 45 + 9 + 81 / len * (id + 1),
  radius: 219 + 8,
  line_width: 8,
  corner_flag: 0,
  color: 0xFF0000,
  level: 100,
  show_level: hmUI.show_level.ONLY_NORMAL
 });
 menu_ARC_PROGRES.setProperty(hmUI.prop.VISIBLE, true);
}

function updateButtons() {
    const toggleIndex = CONF_MAIN.length - 1;
    const isCrownEnabled = CONF_MAIN[toggleIndex].id === 1;
    
    for (let i = 0; i < CONF_MAIN.length; i++) {
        const yPos = CONF_MAIN.length <= 5 
            ? 70 + i * Shag_Y 
            : i < Math.ceil(CONF_MAIN.length / 2) 
                ? 70 + i * Shag_Y 
                : 70 + i * Shag_Y - Shag_Y * Math.ceil(CONF_MAIN.length / 2);
        
        const xPos = CONF_MAIN.length <= 5 
            ? 153 
            : i < Math.ceil(CONF_MAIN.length / 2) 
                ? 70 
                : 233;
        
        // Определяем, активна ли кнопка
        const isToggleButton = (i === toggleIndex && CONF_MAIN[i].type === 'toggle');
        const isActive = isCrownEnabled || isToggleButton;
        
        let buttonText = '';
        if (CONF_MAIN[i].type === 'save_conf') {
            buttonText = 'конфигурация ' + (CONF_MAIN[i].id + 1);
        } else if (CONF_MAIN[i].type === 'toggle') {
            buttonText = Array.isArray(CONF_MAIN[i].name) 
                ? CONF_MAIN[i].name[CONF_MAIN[i].id] 
                : CONF_MAIN[i].name + ' ' + (CONF_MAIN[i].id + 1);
        } else {
            buttonText = CONF_MAIN[i].name + ' ' + (CONF_MAIN[i].id + 1);
        }
        
        // Определяем цвет кнопки
        let normalColor;
        if (CONF_MAIN[i].type === 'toggle') {
            normalColor = CONF_MAIN[i].id === 0 ? 0x800000 : 0x008000; // Темно-красный/Темно-зеленый
        } else {
            if (!isActive) {
                normalColor = 0x333333; // Серый для неактивных кнопок
            } else {
                normalColor = (i === crown) ? 0x800000 : 0x000000; // Красный/Черный
            }
        }
        
        // Текст кнопки
        let textColor = isActive ? 0xFFFFFFFF : 0x888888; // Белый для активных, серый для неактивных
        
        Btn_set_[i].setProperty(hmUI.prop.MORE, {
            x: xPos,
            y: yPos,
            w: 160,
            h: 60,
            text: buttonText,
            char_space: 0,
            line_space: -35,
            color: textColor,
            text_size: 24,
            radius: 12,
            press_color: isActive ? 0xFFFF0000 : 0x333333,
            normal_color: normalColor,
            text_style: hmUI.text_style.WRAP
        });
    }
}
		
// Функция для обработки текста приложения
function click_app_text_on_off() {
 // Позиционирование текста
 Line_arr.forEach((_, i) => {
  app_ACR_text[i].setProperty(hmUI.prop.X, i < Line_arr.length / 2 ? 68 : 233);
  app_ACR_text[i].setProperty(hmUI.prop.Y, i < Line_arr.length / 2 ? text_start + i * 21 : text_start + (i - Line_arr.length / 2) * 21);
 });

 // Отображение элементов
 bg_app_text.setProperty(hmUI.prop.VISIBLE, true);
 Line_arr.forEach((_, i) => app_ACR_text[i].setProperty(hmUI.prop.VISIBLE, true));
 g_ACR_panel.setProperty(hmUI.prop.VISIBLE, true);

 // Скрываем цветовые элементы
 g_ACR_color_PROGRES.setProperty(hmUI.prop.VISIBLE, false);

 // Установка цветов текста
 Line_arr.forEach((_, i) => {
  app_ACR_text[i].setProperty(hmUI.prop.COLOR,
   CONF_MAIN[crown].id == i ? 0xff0000 : 0xffffff);
 });
}



		
// Обновляем crown_color
function crown_color(crown_index, step, only_nav = false) {
    if (only_nav) {
        crown = crown_index;
        return;
    }
    
    const currentItem = CONF_MAIN[crown_index];
    const oldId = currentItem.id;
    let newId;
    
    if (currentItem.type === 'toggle' || currentItem.type === 'save_conf') {
        // Для save_conf циклическое переключение 0→1→2→0
        newId = (oldId + step + currentItem.len) % currentItem.len;
    } else {
        newId = oldId + step;
        
        // Одинаковая логика для всех типов
        if (newId < 0) {
            newId = 0;
        } else if (newId >= currentItem.len) {
            newId = currentItem.len - 1;
        }
    }
    
    if (oldId !== newId) {
        CONF_MAIN[crown_index].id = newId;
        hmFS.SysProSetInt(`${WF_ID}_color_` + crown_index, newId);
        switch_crown(crown_index);
        vibro();
    } else {
        // ВИБРАЦИЯ ПРИ ПОПЫТКЕ ВЫЙТИ ЗА ГРАНИЦЫ
        // Если значение не изменилось, но мы пытались изменить (шаг не 0)
        // и находимся на границе (0 или max)
        if (step !== 0) {
            const isMinBorder = (oldId === 0 && step < 0);
            const isMaxBorder = (oldId === currentItem.len - 1 && step > 0);
            
            if (isMinBorder || isMaxBorder) {
                vibro(); // Вибрация при попытке выйти за границы
            }
        }
    }
}

function getColorInfo(crownIndex = crown) {
    const colorArrayIndex = CONF_MAIN[crownIndex].colorArrayIndex || 0;
    const colorArray = color_bg[colorArrayIndex];
    const colorIndex = Math.min(CONF_MAIN[crownIndex].id, colorArray.length - 1);
    const colorValue = colorArray[colorIndex];
    
    return {
        colorArrayIndex,
        colorArray,
        colorIndex,
        colorValue
    };
}


const BG_INDEX_TO_PICTURE = [0,1,0,1,0,1,0,1,0,1,0,1,0,1,0,0,0,2,2,0,0,0,3,3,3,4,3,4,1,5];

// ЕДИНАЯ функция для применения ВСЕХ стилей
function applyAllStyles(changedIndex, left) {
	
	
 if (changedIndex === undefined || changedIndex === 'left') {
 normal_widget_text_12.setProperty(hmUI.prop.VISIBLE, left == 0);
 normal_pressure_text_font.setProperty(hmUI.prop.VISIBLE, left == 1);
 normal_temperature_max_min_text_font.setProperty(hmUI.prop.VISIBLE, left == 2);

 normal_widget_text_9.setProperty(hmUI.prop.TEXT, left == 1 ? 'H' : left == 2 ? '=' : !isDayIcons ? 'K' : 'J');
 normal_widget_text_15.setProperty(hmUI.prop.TEXT, left == 1 ? 'ММ.РТ.СТ' : left == 2 ? 'НОЧЬ/ДЕНЬ' : !isDayIcons ? 'ВОСХОД' : 'ЗАКАТ');
	}

 // Если изменился пункт 0 ИЛИ это старт (changedIndex === undefined)
 if (changedIndex === 0 || changedIndex === undefined || changedIndex === 'left') {
  const colorValueId = CONF_MAIN[0].id;
  const color0 = color_bg[0][colorValueId];
  const color1 = color_bg[1][colorValueId];
  const color2 = color_bg[2][colorValueId];

  normal_widget_text_9.setProperty(hmUI.prop.COLOR, color2);
  normal_widget_text_15.setProperty(hmUI.prop.COLOR, color2);
  normal_city_name_text.setProperty(hmUI.prop.COLOR, color2);
  normal_pressure_text_font.setProperty(hmUI.prop.COLOR, color2);

  normal_temperature_max_min_text_font.setProperty(hmUI.prop.MORE, {
   x: 104 * kf,
   y: 159 * kf,
   w: 150 * kf,
   h: 60 * kf,
   text_size: 43 * kf,
   char_space: 0,
   font: 'fonts/dsb.ttf',
   color: color2,
   line_space: 0,
   align_v: hmUI.align.TOP,
   text_style: hmUI.text_style.ELLIPSIS,
   align_h: hmUI.align.RIGHT,
   unit_type: 1,
   type: hmUI.data_type.WEATHER_HIGH_LOW,
   show_level: hmUI.show_level.ONLY_NORMAL,
  });


  normal_background.setProperty(hmUI.prop.COLOR, color1);
  normal_background_up.setProperty(hmUI.prop.COLOR, color0);
  normal_data_bg.setProperty(hmUI.prop.COLOR, color1);
  normal_bat_bg.setProperty(hmUI.prop.COLOR, color1);
  normal_step_bg.setProperty(hmUI.prop.COLOR, color1);

        normal_time_second_text_font.setProperty(hmUI.prop.COLOR, color1);
        normal_month_name_font.setProperty(hmUI.prop.COLOR, color1);
        normal_widget_text_4.setProperty(hmUI.prop.COLOR, color1);
        normal_widget_text_6.setProperty(hmUI.prop.COLOR, color2);
        normal_widget_text_9.setProperty(hmUI.prop.COLOR, color2);
        normal_widget_text_10.setProperty(hmUI.prop.COLOR, color2);
        normal_widget_text_12.setProperty(hmUI.prop.COLOR, color2);
        normal_widget_text_1.setProperty(hmUI.prop.COLOR, color1);

        normal_temperature_current_text_font.setProperty(hmUI.prop.MORE, {
            x: 93 * kf, y: 96 * kf, w: 150 * kf, h: 60 * kf,
            text_size: 43 * kf, char_space: 0,
            font: 'fonts/dsb.ttf', color: color2,
            line_space: 0, align_v: hmUI.align.TOP,
            text_style: hmUI.text_style.ELLIPSIS, align_h: hmUI.align.RIGHT,
            unit_type: 1, type: hmUI.data_type.WEATHER_CURRENT,
            show_level: hmUI.show_level.ONLY_NORMAL,
        });

normal_widget_text_13.setProperty(hmUI.prop.COLOR, color2);

        normal_step_current_text_font.setProperty(hmUI.prop.MORE, {
            x: 129 * kf, y: 313 * kf, w: 150 * kf, h: 50 * kf,
            text_size: 41 * kf, char_space: 0,
            font: 'fonts/dsb.ttf', color: color2,
            line_space: 0, align_v: hmUI.align.TOP,
            text_style: hmUI.text_style.ELLIPSIS, align_h: hmUI.align.RIGHT,
            type: hmUI.data_type.STEP,
            show_level: hmUI.show_level.ONLY_NORMAL,
        });

        let idx = CONF_MAIN[0].id;
        let pictureIndex = BG_INDEX_TO_PICTURE[idx];
        normal_setka_icon_img.setProperty(hmUI.prop.SRC, 'setka_' + pictureIndex + '.png');
    }

    // Если изменился пункт 1 ИЛИ это старт
    if (changedIndex === 1 || changedIndex === undefined) {
        const secondImageIndex = CONF_MAIN[1].id;
        normal_analog_clock_time_pointer_smooth_second.setProperty(hmUI.prop.MORE, {
            second_path: 'sec_' + secondImageIndex + '.png',
            second_centerX: D_W/2,
            second_centerY: D_W/2,
            second_posX: 20 * kf,
            second_posY: 231 * kf,
            fresh_frequency: 15,
            show_level: hmUI.show_level.ONLY_NORMAL,
        });
    }
}


// Старт циферблата
function start_WG() {
    applyAllStyles(undefined, left);  // undefined = обновить всё
}

// Переключение левого/правого режима
let left = 0
function clik_left() {
    left = (left + 1) % 3;
    hmFS.SysProSetInt(`${WF_ID}_left`, left);
    
    // Просто вызываем ту же функцию с текущим crown
    applyAllStyles(undefined, left);
    
    vibro();
}

// Переключение коронки
function switch_crown_0() {
    applyAllStyles(0, left);   // передаём индекс изменённого пункта
    vibro();
}

function switch_crown_1() {
    applyAllStyles(1, left);
    vibro();
}

function switch_crown_2() {
   const colorInfo = getColorInfo();
	
	
     normal_mask_1_icon_img.setProperty(hmUI.prop.SRC, 'mask_1_' + colorInfo.colorIndex + '.png');
     normal_mask_2_icon_img.setProperty(hmUI.prop.SRC, 'mask_2_' + colorInfo.colorIndex + '.png');
     normal_mask_3_icon_img.setProperty(hmUI.prop.SRC, 'mask_2_' + colorInfo.colorIndex + '.png');
	
	

	
    vibro();
}

function switch_crown_3() {
 const colorInfo = getColorInfo();
 //const colorInfo4 = getColorInfo(4);
	
	
	
	

}

function switch_crown_4() {
 const colorInfo = getColorInfo();

}

function switch_crown_5() {
 const colorInfo = getColorInfo();
	const colorInfo6 = getColorInfo(6);



 //vibro();
}

function switch_crown_6() {
 const colorInfo = getColorInfo();
 const colorInfo5 = getColorInfo(5);



 //vibro();
}


function switch_crown_7() {

//CONF_MAIN[crown].name = CONF_MAIN[crown].id == 0 ? 'ккккк': 'ггггг'
//    vibro();
}

		
function switch_crown_8() {
// Обновляем текст кнопки при изменении состояния toggle
    updateButtons();	

   vibro();
}
		
function switch_crown_9() {
	
//CONF_MAIN[crown].name = CONF_MAIN[crown].id == 0 ? 'ккккк': 'ггггг'
//    vibro();
}


// Создаём массив, где каждый элемент — соответствующая функция
const crownFunctions = [switch_crown_0, switch_crown_1, switch_crown_2, switch_crown_3, switch_crown_4, switch_crown_5, switch_crown_6, switch_crown_7, switch_crown_8, switch_crown_9];

// Функция переключения коронок с проверкой на отключение
function switch_crown(crown) {
    if (crown >= 0 && crown < crownFunctions.length) {
        crownFunctions[crown]();
    }
}


const vibrate = hmSensor.createSensor(hmSensor.id.VIBRATE)
let stopVibro_Timer = null;

/*      function vibro(scene = 25) {
       let stopDelay = 50;
       vibrate.stop();
       vibrate.scene = scene;
       if (scene < 23 || scene > 25) stopDelay = 1220;
       vibrate.start();
       stopVibro_Timer = timer.createTimer(stopDelay, 0, stopVibro, {});
      }*/

function vibro(scene = 25) {
 //let stopDelay = 50;
 vibrate.stop();
 vibrate.scene = scene;
 vibrate.start();

 // stopVibro_Timer = timer.createTimer(stopDelay, 0, stopVibro, {});
}


function stopVibro() {
 vibrate.stop();
 timer.stopTimer(stopVibro_Timer);
}


// Обновлённая click_Pogoda_on
function click_Pogoda_on(weatherProvider) {
 if (!weatherProvider) return;

 normal_background_Pogoda.setProperty(hmUI.prop.VISIBLE, true);
 menu = 2;
 groupVremya.setProperty(hmUI.prop.VISIBLE, false);
 groupPogoda.setProperty(hmUI.prop.VISIBLE, true);

 setTimeout(() => {
  updateWeatherUI(weatherProvider);
 }, 100);
 setTimeout(() => {
  updateGrafik(weatherProvider.forecast);
 }, 300);


}


// Функция для обновления основной погодной информации (температура, осадки и т.д.)
function updateWeatherUI(weatherProvider) {
    if (!weatherProvider) return;
    
    var zeppTemp = parseFloat(weatherProvider.temperature) || 0;

    var getValue = (idx, type) => { 
        var v = type === 'rain' ? weatherProvider.getChanceOfRainForProvider(idx) : weatherProvider.getTemperatureFeelsForProvider(idx); 
        return (v !== '--' && !isNaN(parseFloat(v))) ? parseFloat(v) : null; 
    };

    var cur = weatherProvider.index;
    var rain = null, feels = null;

    if (cur === 1 || cur === 2) {
        rain = getValue(cur, 'rain');
        if (rain === null) rain = getValue(cur === 1 ? 2 : 1, 'rain');
    } else {
        var r1 = getValue(1, 'rain');
        var r2 = getValue(2, 'rain');
        if (r1 !== null && r2 !== null) rain = Math.random() < 0.5 ? r1 : r2;
        else if (r1 !== null) rain = r1;
        else if (r2 !== null) rain = r2;
    }

    if (rain !== null) {
        normal_temperature_Feels_text_font.setProperty(hmUI.prop.TEXT, Math.round(rain) + '%');
        normal_temperature_Feels_text_font.setProperty(hmUI.prop.COLOR, 0xFFFFFF);
        normal_temperature_Feels_img.setProperty(hmUI.prop.TEXT, ']');
        normal_temperature_Feels_img.setProperty(hmUI.prop.COLOR, rain >= 50 ? 0xFF0000 : 0x808080);
        normal_temperature_Feels_text_font.setProperty(hmUI.prop.VISIBLE, true);
        normal_temperature_Feels_img.setProperty(hmUI.prop.VISIBLE, true);
    } else {
        if (cur === 1 || cur === 2) {
            feels = getValue(cur, 'feels');
            if (feels === null) feels = getValue(cur === 1 ? 2 : 1, 'feels');
        } else {
            var f1 = getValue(1, 'feels');
            var f2 = getValue(2, 'feels');
            if (f1 !== null && f2 !== null) feels = Math.random() < 0.5 ? f1 : f2;
            else if (f1 !== null) feels = f1;
            else if (f2 !== null) feels = f2;
        }

        if (feels !== null) {
            var f = feels, a = zeppTemp;
            var color = f > a ? 0xff0000 : (f < a ? 0x00ffff : 0xffffff);
            normal_temperature_Feels_text_font.setProperty(hmUI.prop.TEXT, Math.round(f) + '°');
            normal_temperature_Feels_text_font.setProperty(hmUI.prop.COLOR, color);
            normal_temperature_Feels_img.setProperty(hmUI.prop.COLOR, color);
            normal_temperature_Feels_img.setProperty(hmUI.prop.TEXT, f > a ? '>' : (f < a ? '<' : 'N'));
            normal_temperature_Feels_text_font.setProperty(hmUI.prop.VISIBLE, true);
            normal_temperature_Feels_img.setProperty(hmUI.prop.VISIBLE, true);
        } else {
            normal_temperature_Feels_text_font.setProperty(hmUI.prop.VISIBLE, false);
            normal_temperature_Feels_img.setProperty(hmUI.prop.VISIBLE, false);
        }
    }
	
	
   updateWeatherVisibility(weatherProvider);
	updateWindUI(weatherProvider);
}

// Функция для обновления видимости и текстовых элементов
function updateWeatherVisibility(weatherProvider) {
    if (!weatherProvider) return;
    
    const isProv = weatherProvider.index != 0;
    const isZepp = weatherProvider.index == 0;

    if (isProv) HUMIDITY_LEVEL_prov.setProperty(hmUI.prop.SRC, arr_HUMIDITY[Math.floor(parseFloat(weatherProvider.humidity) / 10)]);

    HUMIDITY_zepp.setProperty(hmUI.prop.VISIBLE, isZepp);
    HUMIDITY_prov.setProperty(hmUI.prop.VISIBLE, isProv);
    HUMIDITY_LEVEL_zepp.setProperty(hmUI.prop.VISIBLE, isZepp);
    HUMIDITY_LEVEL_prov.setProperty(hmUI.prop.VISIBLE, isProv);
    
    setTimeout(() => {
        var clean = (weatherProvider.weatherDescription || '').replace(/[^\w\sа-яА-ЯёЁ\.\,\:\-\°]/g, '');
        var dotIndex = clean.indexOf('.');
        dotIndex !== -1 ? (clean_pro = clean.substring(dotIndex + 1).trim(), clean = clean.substring(0, dotIndex).trim()) : (clean_pro = '');
        
        var hasVisibleText = /[^\s]/.test(clean_pro);
        btn_weather_info.setProperty(hmUI.prop.VISIBLE, hasVisibleText);
        
        var cityNameRaw = weatherProvider.cityName || '';
        var commaIndex = cityNameRaw.indexOf(',');
        city_pro = commaIndex !== -1 ? cityNameRaw.substring(commaIndex + 1).trim() : '';
        btn_city_info.setProperty(hmUI.prop.VISIBLE, /[^\s]/.test(city_pro));
        
        normal_temp_text_font.setProperty(hmUI.prop.MORE, {
            x: 115, y: clean.length < 38 ? 2 : -8, w: 236, h: 32,
            text: weatherProvider.temperature + "С",
            text_size: clean.length < 38 ? 27 : 22,
            char_space: 0, line_space: 0,
            font: 'fonts/Bebas22.ttf', color: 0xFFFFFFFF,
            align_h: hmUI.align.CENTER_H, align_v: hmUI.align.CENTER_V,
            text_style: hmUI.text_style.NONE,
            show_level: hmUI.show_level.ONLY_NORMAL,
        });
        
        normal_weather_text_font.setProperty(hmUI.prop.MORE, {
            x: 119, y: clean.length < 38 ? -6 : -8, w: 228, h: 102,
            text: clean,
            text_size: clean.length < 19 ? 27 : 22,
            char_space: 0, line_space: -30,
            font: 'fonts/Bebas22.ttf', color: 0xFFFFFFFF,
            align_h: hmUI.align.CENTER_H, align_v: hmUI.align.CENTER_V,
            text_style: hmUI.text_style.WRAP,
            show_level: hmUI.show_level.ONLY_NORMAL,
        });
        
        normal_city_name_text_0.setProperty(hmUI.prop.MORE, {
            x: 74, y: clean.length < 38 ? 60 : 63, w: 318, h: 32,
            text: weatherProvider.index == 2 ? weatherProvider.sunriseTime + "   " + weatherProvider.cityName.split(',')[0].trim().toUpperCase() + "   " + weatherProvider.sunsetTime : weatherProvider.sunriseTime + "   " + weatherProvider.cityName.toUpperCase() + "   " + weatherProvider.sunsetTime,
            text_size: clean.length < 38 ? 27 : 22,
            char_space: 0, line_space: 0,
            font: 'fonts/Bebas22.ttf', color: 0xFFFFFFFF,
            align_h: hmUI.align.CENTER_H, align_v: hmUI.align.CENTER_V,
            text_style: hmUI.text_style.NONE,
            show_level: hmUI.show_level.ONLY_NORMAL,
        });
    }, 100);

    update_time_weather.setProperty(hmUI.prop.TEXT, '# ' + weatherProvider.updateDate + ' ' + weatherProvider.updateTime);
    update_time_weather.setProperty(hmUI.prop.VISIBLE, isProv);
}

function click_Pogoda_off() {
 normal_background_Pogoda.setProperty(hmUI.prop.VISIBLE, false);
 menu = 0
 groupVremya.setProperty(hmUI.prop.VISIBLE, true);
 groupPogoda.setProperty(hmUI.prop.VISIBLE, false);

}


function updateWindUI(weatherProvider) {
    if (!weatherProvider) return;
    
    var cur = weatherProvider.index;
    var windSpeedValue = null;
    var windDirectionValue = null;
    
    if (cur === 1 || cur === 2) {
        var spd = weatherProvider.getWindSpeedForProvider(cur);
        var dir = weatherProvider.getWindDirectionForProvider(cur);
        if (spd !== '--' && !isNaN(parseFloat(spd))) {
            windSpeedValue = parseFloat(spd);
            windDirectionValue = (dir !== '--' && !isNaN(parseFloat(dir))) ? parseFloat(dir) : null;
        } else {
            var other = cur === 1 ? 2 : 1;
            spd = weatherProvider.getWindSpeedForProvider(other);
            dir = weatherProvider.getWindDirectionForProvider(other);
            if (spd !== '--' && !isNaN(parseFloat(spd))) {
                windSpeedValue = parseFloat(spd);
                windDirectionValue = (dir !== '--' && !isNaN(parseFloat(dir))) ? parseFloat(dir) : null;
            }
        }
    } else {
        var spd1 = weatherProvider.getWindSpeedForProvider(1);
        var spd2 = weatherProvider.getWindSpeedForProvider(2);
        var dir1 = weatherProvider.getWindDirectionForProvider(1);
        var dir2 = weatherProvider.getWindDirectionForProvider(2);
        
        var has1 = (spd1 !== '--' && !isNaN(parseFloat(spd1)));
        var has2 = (spd2 !== '--' && !isNaN(parseFloat(spd2)));
        
        if (has1 && has2) {
            var useFirst = Math.random() < 0.5;
            windSpeedValue = useFirst ? parseFloat(spd1) : parseFloat(spd2);
            var dirVal = useFirst ? dir1 : dir2;
            windDirectionValue = (dirVal !== '--' && !isNaN(parseFloat(dirVal))) ? parseFloat(dirVal) : null;
        } else if (has1) {
            windSpeedValue = parseFloat(spd1);
            windDirectionValue = (dir1 !== '--' && !isNaN(parseFloat(dir1))) ? parseFloat(dir1) : null;
        } else if (has2) {
            windSpeedValue = parseFloat(spd2);
            windDirectionValue = (dir2 !== '--' && !isNaN(parseFloat(dir2))) ? parseFloat(dir2) : null;
        }
    }
    
    if (windSpeedValue !== null) {
        var speedText = getWindDescription(windDirectionValue, 0) + " " + windSpeedValue + ' м/с';
        windSpeedText.setProperty(hmUI.prop.TEXT, speedText);
        windSpeedText.setProperty(hmUI.prop.X, 0);
        windSpeedText.setProperty(hmUI.prop.Y, 391);
        windSpeedText.setProperty(hmUI.prop.VISIBLE, true);
        windSpeedText_zepp.setProperty(hmUI.prop.VISIBLE, false);
        wind_DIRECTION_Text_zepp.setProperty(hmUI.prop.VISIBLE, false);
    } else {
        if (cur === 0) {
            windSpeedText.setProperty(hmUI.prop.TEXT, 'балл');
            windSpeedText.setProperty(hmUI.prop.X, 70);
            windSpeedText.setProperty(hmUI.prop.Y, 399);
            windSpeedText.setProperty(hmUI.prop.VISIBLE, true);
            windSpeedText_zepp.setProperty(hmUI.prop.VISIBLE, true);
            wind_DIRECTION_Text_zepp.setProperty(hmUI.prop.VISIBLE, true);
        } else {
            windSpeedText.setProperty(hmUI.prop.VISIBLE, false);
            windSpeedText_zepp.setProperty(hmUI.prop.VISIBLE, false);
            wind_DIRECTION_Text_zepp.setProperty(hmUI.prop.VISIBLE, false);
        }
    }
}



let apps = [
 ['Нет действия', '-', `tap/i_tap_pusto.png`, 0, 'page/index'],
 ['Таймер', 'CountdownAppScreen', `tap/i_tap_obrat_otchet.png`, 0, 'page/index'],
 ['Секундомер', 'StopWatchScreen', `tap/i_tap_secundomer.png`, 0, 'page/index'],
 ['Мировые часы', 'WorldClockScreen', `tap/i_tap_mirivie_chasi.png`, 0, 'page/index'],
 ['Восход/закат', 'TideScreen', `tap/i_tap_voshod_zakat.png`, 0, 'page/index'],
 ['Сон', 'Sleep_HomeScreen', `tap/i_tap_son.png`, 0, 'page/index'],
 ['Стресс', 'StressHomeScreen', `tap/i_tap_stress.png`, 0, 'page/index'],
 ['SP02 (Кислород)', 'spo_HomeScreen', `tap/i_tap_kislorod.png`, 0, 'page/index'],
 ['Дыхание', 'RespirationsettingScreen', `tap/i_tap_dihanie.png`, 0, 'page/index'],
 ['Измерение одним касанием', 'oneKeyAppScreen', `tap/i_tap_1_kosanie.png`, 0, 'page/index'],
 ['Женский календарь', 'menstrualAppScreen', `tap/i_tap_gensk_calendar.png`, 0, 'page/index'],
 ['Найти телефон', 'FindPhoneScreen', `tap/i_tap_naiti_telo.png`, 0, 'page/index'],
 ['Музыка', 'LocalMusicScreen', `tap/i_tap_musik.png`, 0, 'page/index'], //'PhoneMusicCtrlScreen'
 ['Компас', 'CompassScreen', `tap/i_tap_kompas.png`, 0, 'page/index'],
 ['Набрать номер', 'DialCallScreen', `tap/i_tap_nabor.png`, 0, 'page/index'],
 ['Телефон', 'PhoneHomeScreen', `tap/i_tap_telefon.png`, 0, 'page/index'],
 ['Диктофон', 'VoiceMemoScreen', `tap/i_tap_dictofon.png`, 0, 'page/index'],
 ['Расписание', 'ScheduleListScreen', `tap/i_tap_raspisanie.png`, 0, 'page/index'],
 ['Список дел', 'todoListScreen', `tap/i_tap_spisok_del.png`, 0, 'page/index'],
 ['Календарь', 'ScheduleCalScreen', `tap/i_tap_calendar.png`, 0, 'page/index'],
 ['Погода', 'WeatherScreen', `tap/i_tap_pogoda.png`, 0, 'page/index'],
 ['Настройка', 'Settings_homeScreen', `tap/i_tap_sitting.png`, 0, 'page/index'],
 ['Камера', 'HidcameraScreen', `tap/i_tap_camera.png`, 0, 'page/index'],
 ['Пульс', 'heart_app_Screen', `tap/i_tap_puls.png`, 0, 'page/index'],
 ['Будильник', 'AlarmInfoScreen', `tap/i_tap_budilnik.png`, 0, 'page/index'],
 ['PAI', 'PAI_app_Screen', `tap/i_tap_pai.png`, 0, 'page/index'],
 ['Тренировка', 'SportListScreen', `tap/i_tap_trenerovka.png`, 0, 'page/index'],
 ['AOD', 'Settings_standbyModelScreen', `tap/i_tap_aod.png`, 0, 'page/index'],
 ['Экономия заряда', 'LowBatteryScreen', `tap/i_tap_LowBattery.png`, 0, 'page/index'],
 ['Давление/Высота', 'BaroAltimeterScreen', `tap/i_tap_barometr.png`, 0, 'page/index'],
 ['Погода LeXxiR', '1051195', `tap/i_tap_LeXxiR.png`, 1, 'page/index'],
 ['Календарь Sasha', '1057409', `tap/i_tap_calen_Sasha.png`, 1, 'page/index'],
 ['Flow', '1038314', `tap/i_tap_flow.png`, 1, 'page/gtr/home/index.page'],
 ['Ночной режим', 'Settings_nsModeHomeScreen', `tap/i_tap_night_Mode_Screen.png`, 0, 'page/index'],
 ['Говорящие часы', '1066653', `tap/i_tap_talking_watch.png`, 1, 'page/index.page'],
 ['Перезагрузка', 'HmReStartScreen', `tap/i_tap_restart.png`, 0, 'page/index'],
];


let btn_tap = ''
let btn_click_tap_exit = ''


function tap_zona_exit() {
 groupVremya.setProperty(hmUI.prop.VISIBLE, true);
 groupTap.setProperty(hmUI.prop.VISIBLE, false);

}


function tap_run() {
 groupVremya.setProperty(hmUI.prop.VISIBLE, false);
 groupTap.setProperty(hmUI.prop.VISIBLE, true);
}


//-------------------------------- 
//переменные для ргафика
let weather_ic_array = []
let weather_ic = []
let DigDay = []
let DigNight = []
let yArrH = [];
let arr_xH = [];
let arr_yH = [];
let arr_x = [];
let arr_y = [];
let arr_xL = [];
let arr_yL = [];
let yArrAll = [];
let yArrL = [];
let y_pogodaH = [];
let y_pogodaL = [];
let week_array = ["ПН", "ВТ", "СР", "ЧТ", "ПТ", "СБ", "ВС"];
let week_text = []
let data_text = []
const ROOTPATH = "images/"
var shag = 46*kf;
var x0 = 73*kf;
let dney = 8;
let isDayIcons = false

let shotWeaterhNames = ["Облачно", "Местами дождь", "Местами снег", "Cолнечно", "Пасмурно", "Слабый дождь", "Слабый снег", "Умеренный дождь", "Умеренный снег", "Сильный снегопад", "Сильный дождь", "Песчаная буря", "Мокрый снег", "Туман", "Дымка", "Дождь с грозой", "Метель", "Пыльно", "Ливень", "Дождь с градом", "Сильный дождь с градом", "Сильный дождь ", "Песчаная буря", "Сильная песчаная буря ", "Сильный дождь", "Неизвестная погода", "Облачно ночью", "Дождливо ночью", "Ясно ночью"];

  let array_ic_weater_2 = ["А", "Б", "В", "Г", "Д", "Е", "Ж", "З", "И", "Й", "К", "Л", "М", "Н", "О", "П", "Р", "С", "У", "Ф", "Х", "Ц", "Ч", "Ш", "?", "Ъ", "Ы", "Ь"];

let tip_grafik = 0

/*function click_tip_grafik(weatherProvider) {
    tip_grafik = (tip_grafik + 1) % 2;
    hmFS.SysProSetInt(`${WF_ID}_tip_grafik`, tip_grafik);
    ic_graf_img.setProperty(hmUI.prop.SRC, "images/Grafik/ic_graf_" + tip_grafik + ".png");
	
	
	    // Принудительно синхронизируем данные с провайдером
    weatherProvider.update(true);
    var forecastData = weatherProvider.getForecastData(weatherProvider.providers[weatherProvider.index].appId);
	updateWeatherUI(weatherProvider);
	autoToggleWeatherIcons();
	weatherProvider.next(false);
	
	
	setTimeout(() => {
	weatherProvider.next(true);	
    updateGrafik(forecastData);   // перерисовывает график с новыми данными и новым типом
	}, 500);	
   // tip();
}*/

// Глобальный кеш для всех провайдеров
var forecastCache = {
    0: { data: null, key: '' },  // Zepp
    1: { data: null, key: '' },  // Weather service
    2: { data: null, key: '' }   // RuWeather
};
//Функция получения прогноза с кешированием
function getCachedForecast(weatherProvider) {
    var idx = weatherProvider.index;
    var cache = forecastCache[idx];
    var currentKey = weatherProvider.updateDate + '|' + weatherProvider.updateTime;
    
    // Если кеш есть и данные не обновлялись
    if (cache.data && cache.key === currentKey) {
        return cache.data;
    }
    
    // Читаем свежий прогноз для этого провайдера
    var forecastData = weatherProvider.getForecastData(
        weatherProvider.providers[idx].appId
    );
    
    cache.data = forecastData;
    cache.key = currentKey;
    return forecastData;
}




/*function click_tip_grafik(weatherProvider) {
    tip_grafik = (tip_grafik + 1) % 2;
    hmFS.SysProSetInt(`${WF_ID}_tip_grafik`, tip_grafik);
    ic_graf_img.setProperty(hmUI.prop.SRC, "images/Grafik/ic_graf_" + tip_grafik + ".png");	
	weatherProvider.next();
	weatherProvider.prev();	

	
	setTimeout(() => {
	    tip();
	}, 300);
    
}*/

function click_tip_grafik(weatherProvider) {
    tip_grafik = (tip_grafik + 1) % 2;
    hmFS.SysProSetInt(`${WF_ID}_tip_grafik`, tip_grafik);
    ic_graf_img.setProperty(hmUI.prop.SRC, "images/Grafik/ic_graf_" + tip_grafik + ".png");
    
    // Используем кешированный прогноз (без чтения файлов)
    var forecastData = getCachedForecast(weatherProvider);
    if (forecastData && forecastData.length) {
        for (let i = 0; i < dney && i < forecastData.length; i++) {
            yArrH[i] = Math.round(forecastData[i].temperatureMax);
            if (i < dney - 1) yArrL[i] = Math.round(forecastData[i].temperatureMin);
        }
    }
	
//	weatherProvider.next();
//	weatherProvider.prev();	
	click_Pogoda_off();
	
	
 	//setTimeout(() => {   


 setTimeout(() => {
	 normal_background_Pogoda.setProperty(hmUI.prop.VISIBLE, true);
 menu = 2;
 groupVremya.setProperty(hmUI.prop.VISIBLE, false);
 groupPogoda.setProperty(hmUI.prop.VISIBLE, true); 
	 
  updateWeatherUI(weatherProvider);
 }, 100);
 setTimeout(() => {
  updateGrafik(weatherProvider.forecast);
 }, 300);
	//}, 300);
}





 let normal_city_name_text_0 = ''

 //-------------------------------- 

 //массив иконок для графика       
 for (var i = 0; i <= 28; i++) {
  weather_ic_array.push(ROOTPATH + "Grafik/weather/" + i + ".png"); //0-28
 }



function getSunTimes(weatherData) {
  let tideData = weatherData.tideData;

  // Получение времени заката
  let sunset_hour = -1;
  let sunset_minute = -1;
  if (tideData.count > 0) {
   sunset_hour = tideData.data[0].sunset.hour;
   sunset_minute = tideData.data[0].sunset.minute;
  }

  let normal_sunset = undefined;
  if (sunset_hour >= 0 && sunset_minute >= 0) {
   normal_sunset = String(sunset_hour).padStart(2, '0') + ':' + String(sunset_minute).padStart(2, '0');
  }

  // Получение времени восхода
  let sunrise_hour = -1;
  let sunrise_minute = -1;
  if (tideData.count > 0) {
   sunrise_hour = tideData.data[0].sunrise.hour;
   sunrise_minute = tideData.data[0].sunrise.minute;
  }

  let normal_sunrise = undefined;
  if (sunrise_hour >= 0 && sunrise_minute >= 0) {
   normal_sunrise = String(sunrise_hour).padStart(2, '0') + ':' + String(sunrise_minute).padStart(2, '0');
  }

  return {
   normal_sunset_circle_string: normal_sunset,
   normal_sunrise_circle_string: normal_sunrise
  };
 }

// Глобальные тестовые данные (добавить в начало файла после остальных объявлений)
const IS_SIMULATOR = false; // для симулятора true, для устройства false
const testHighs = [12, 22, 15, 5, 11, 33, 9, 6];
const testLows  = [-22, 0, 1, -4, 2, 10, 1, -3];
const testIcons = [0, 1, 2, 3, 4, 5, 6, 7];
const testWeekDays = ["ПН", "ВТ", "СР", "ЧТ", "ПТ", "СБ", "ВС"]; // для подмены дней недели (опционально)





// Полностью переписанная функция autoToggleWeatherIcons
function autoToggleWeatherIcons() {
  // Для симулятора сразу выходим, так как там нет реальных данных погоды
  //if (IS_SIMULATOR) return;

  const weatherSensor = hmSensor.createSensor(hmSensor.id.WEATHER);
  let weatherData = weatherSensor.getForecastWeather();
  let forecastData = weatherData.forecastData;
	
  // ЗАЩИТА ОТ ОТСУТСТВИЯ ДАННЫХ
/*  if (!forecastData || !forecastData.data || forecastData.data.length < 3) {
    if (normal_widget_text_7) normal_widget_text_7.setProperty(hmUI.prop.TEXT, 'Н:--° Д:--°');
    if (normal_widget_text_13) normal_widget_text_13.setProperty(hmUI.prop.TEXT, '--°');
    if (normal_widget_text_14) normal_widget_text_14.setProperty(hmUI.prop.TEXT, '--°');
    return;
  }	*/
	
	
  let tideData = weatherData.tideData;
	
  
  sunData = weatherData.tideData;
  let sunriseMins, sunsetMins, sunriseMins_def, sunsetMins_def;
  if (sunData.count > 0) {
    let today = sunData.data[0];
    sunriseMins = (today.sunrise.hour) * 60 + today.sunrise.minute;
    sunsetMins = (today.sunset.hour) * 60 + today.sunset.minute;
  } else {
    // значения по умолчанию (8:00 и 20:00)
    sunriseMins = 8 * 60;
    sunsetMins = 20 * 60;
  }
  let curMins = timeSensor.hour * 60 + timeSensor.minute;
  let isDayNow = (curMins >= sunriseMins) && (curMins < sunsetMins);

  isDayIcons = isDayNow;
  
  const {
    normal_sunset_circle_string,
    normal_sunrise_circle_string
  } = getSunTimes(weatherData);
  
  let currentTemp = weatherSensor.current;
  if (typeof currentTemp !== 'number' || isNaN(currentTemp)) {
    return;
  }
  
  const [sunriseHours, sunriseMinutes] = normal_sunrise_circle_string.split(':').map(Number);
  const [sunsetHours, sunsetMinutes] = normal_sunset_circle_string.split(':').map(Number);
  
  //normal_widget_text_7.setProperty(hmUI.prop.TEXT, 'Н:' + forecastData.data[0].low + '° Д:'+forecastData.data[0].high+'°');
//  normal_widget_text_13.setProperty(hmUI.prop.TEXT, forecastData.data[1].high+'°');
//  normal_widget_text_14.setProperty(hmUI.prop.TEXT, forecastData.data[2].high+'°');
  normal_widget_text_9.setProperty(hmUI.prop.TEXT, !isDayIcons ? 'K':'J');
  normal_widget_text_12.setProperty(hmUI.prop.TEXT, !isDayIcons ? normal_sunrise_circle_string : normal_sunset_circle_string);
	
normal_widget_text_9.setProperty(hmUI.prop.TEXT, left == 1 ? 'H' : left == 2 ? '=' : !isDayIcons ? 'K' : 'J');	
normal_widget_text_15.setProperty(hmUI.prop.TEXT, left == 1 ? 'ММ.РТ.СТ' : left == 2 ? 'НОЧЬ/ДЕНЬ' : !isDayIcons ? 'ВОСХОД' : 'ЗАКАТ');	

	
  
  let shotWeaterhNames = isDayIcons == false ? 
    ["Облачно ночью", "Местами дождь", "Местами снег", "Ясно ночью", "Пасмурно ночью", "Слабый дождь", "Слабый снег", "Умеренный дождь", "Умеренный снег", "Сильный снегопад", "Сильный дождь", "Песчаная буря", "Мокрый снег", "Туман", "Дымка", "Дождь с грозой", "Метель", "Пыльно", "Ливень", "Дождь с градом", "Сильный дождь с градом", "Сильный дождь ", "Песчаная буря", "Сильная песчаная буря", "Сильный дождь", "Неизвестная погода", "Облачно ночью", "Дождливо ночью", "Ясно ночью"] : 
    ["Облачно", "Местами дождь", "Местами снег", "Cолнечно", "Пасмурно", "Слабый дождь", "Слабый снег", "Умеренный дождь", "Умеренный снег", "Сильный снегопад", "Сильный дождь", "Песчаная буря", "Мокрый снег", "Туман", "Дымка", "Дождь с грозой", "Метель", "Пыльно", "Ливень", "Дождь с градом", "Сильный дождь с градом", "Сильный дождь ", "Песчаная буря", "Сильная песчаная буря ", "Сильный дождь", "Неизвестная погода", "Облачно ночью", "Дождливо ночью", "Ясно ночью"];

  let array_ic_weater = isDayIcons == false ? 
    ["Ъ", "Ы", "Э", "Ь", "Д", "Е", "Ж", "З", "И", "Й", "К", "Л", "М", "Н", "О", "П", "Р", "С", "У", "Ф", "Х", "Ц", "Ч", "Ш", "?", "Ъ", "Ы", "Ь"] : 
    ["А", "Б", "В", "Г", "Д", "Е", "Ж", "З", "И", "Й", "К", "Л", "М", "Н", "О", "П", "Р", "С", "У", "Ф", "Х", "Ц", "Ч", "Ш", "?", "Ъ", "Ы", "Ь"];
  
  let curAirIconIndex = weatherSensor.curAirIconIndex;
  normal_widget_text_11.setProperty(hmUI.prop.TEXT, shotWeaterhNames[curAirIconIndex].toUpperCase());	
  normal_widget_text_10.setProperty(hmUI.prop.TEXT, array_ic_weater[curAirIconIndex].toUpperCase());	 
  
  let array_ic_weater_2 = ["А", "Б", "В", "Г", "Д", "Е", "Ж", "З", "И", "Й", "К", "Л", "М", "Н", "О", "П", "Р", "С", "У", "Ф", "Х", "Ц", "Ч", "Ш", "?", "Ъ", "Ы", "Ь"];
/*  normal_widget_text_10.setProperty(hmUI.prop.TEXT, array_ic_weater_2[forecastData.data[1].index]);
  normal_widget_text_11.setProperty(hmUI.prop.TEXT, array_ic_weater_2[forecastData.data[2].index]);*/
}






//обновление для   графика           
// Полностью переписанная функция updateGrafik

function updateGrafik(forecastArray) {
  // Для симулятора используем тестовые данные
/*  if (IS_SIMULATOR) {
    for (let i = 0; i < dney; i++) {
      yArrH[i] = testHighs[i];
      yArrL[i] = testLows[i];
      if (weather_ic[i]) {
        weather_ic[i].setProperty(hmUI.prop.SRC, weather_ic_array[testIcons[i]]);
      }
      if (week_text[i]) {
        week_text[i].setProperty(hmUI.prop.MORE, {
          color: "0xFFFFFFFF",
          text: testWeekDays[i % 7]
        });
      }
      if (data_text[i]) {
        data_text[i].setProperty(hmUI.prop.MORE, {
          color: "0xFFFFFFFF",
          text: (i + 1).toString()
        });
      }
    }
    normal_temp_text_font.setProperty(hmUI.prop.TEXT, "22°С");
    normal_weather_text_font.setProperty(hmUI.prop.TEXT, "ТЕСТОВАЯ ПОГОДА");
    normal_city_name_text_0.setProperty(hmUI.prop.TEXT, "06:00   ТЕСТОВЫЙ ГОРОД   20:00");
    tip();
    return;
  }*/

  autoToggleWeatherIcons();

  const now = new Date();
  const year = now.getFullYear();
  const month = now.getMonth() + 1;
  const day = now.getDate();
  const weekDay = now.getDay();
  const weekIdx = weekDay === 0 ? 6 : weekDay - 1;

  let weatherData = weatherSensor.getForecastWeather();
  let forecastData = weatherData.forecastData;

  if (forecastArray && forecastArray.length > 0) {
    for (let i = 0; i < dney && i < forecastArray.length; i++) {
      yArrH[i] = Math.round(forecastArray[i].temperatureMax);
      if (i < dney - 1) yArrL[i] = Math.round(forecastArray[i].temperatureMin);
      weather_ic[i].setProperty(hmUI.prop.SRC, weather_ic_array[forecastArray[i].weatherIcon]);
    }
  } else if (forecastData.count == 0) {
    for (let i = 0; i < dney; i++) {
      weather_ic[i].setProperty(hmUI.prop.SRC, ROOTPATH + "Grafik/weather/25.png");
      yArrH[i] = 0;
      if (i < dney - 1) yArrL[i] = 0;
    }
  } else {
    for (let i = 0; i < dney; i++) {
      yArrH[i] = forecastData.data[i].high;
      const element = forecastData.data[i];
      const iconIndex = element.index;
      weather_ic[i].setProperty(hmUI.prop.SRC, weather_ic_array[iconIndex]);
      if (i < dney - 1) yArrL[i] = forecastData.data[i].low;
    }
  }

  let curWeek = weekIdx;
  let curYear = year;
  let curMonth = month;
  let curDay = day;

  for (let i = 0; i < dney; i++) {
    const weekName = week_array[curWeek];
    week_text[i].setProperty(hmUI.prop.MORE, {
      color: curWeek < 5 ? "0xFFFFFFFF" : "0xFFFF0000",
      text: weekName,
    });
    data_text[i].setProperty(hmUI.prop.MORE, {
      color: curWeek < 5 ? "0xFFFFFFFF" : "0xFFFF0000",
      text: curDay,
    });
    curWeek = (curWeek + 1) % 7;
    const nextDate = new Date(curYear, curMonth - 1, curDay + 1);
    curDay = nextDate.getDate();
    curMonth = nextDate.getMonth() + 1;
    curYear = nextDate.getFullYear();
  }
  
  tip();
}


 function tip() {

  canvas.clear({
   x: 0,
   y: 0,
   w: D_W,
   h: D_W,
  })

  canvas.setPaint({
   color: 0x00ff00,
   line_width: 4
  })

  for (let i = 0; i < dney - 1; i++) {
   canvas.drawRect({
    x1: 94  + shag * [i],
    y1: 93 ,
    x2: 94  + shag * [i] + 1,
    y2: 351 ,
    color: 0xc0c0c0
   })
  }


  let maxH = Math.max(...yArrH)
  let maxL = Math.min(...yArrL)
  let delta = 120  / (maxL - maxH)

  let RedArray = [];
  let BlueArray = [];

  if (tip_grafik == 0) {
   for (let i = 0; i < dney; i++) {
    arr_x[i] = x0 + shag * [i];
    arr_y[i] = yArrH[i] * delta + 162  - maxH * delta;
   }
   // let n = arr_x.length;
   splain(dney)

   for (let i = 0; i < dney - 1; i++) {
    arr_x[i] = x0 + 23  + shag * [i];
    arr_y[i] = yArrL[i] * delta + 162  - maxH * delta;
   }
   // n = dney - 1;
   splain(dney - 1)
  }
  if (tip_grafik == 1) {
   let k = 0
   for (let i = 0; i < dney; i++) {

    yArrAll[k] = yArrH[i]
    k = k + 1
    yArrAll[k] = yArrL[i]
    k = k + 1

   }


   for (let i = 0; i < yArrAll.length; i++) {
    arr_x[i] = x0 + shag / 2 * [i];
    arr_y[i] = yArrAll[i] * delta + 162  - maxH * delta;
   }
   //n = yArrAll.length - 1;
   splain(yArrAll.length - 1)
  }


  for (let i = 0; i < dney; i++) {
   if (tip_grafik == 0) {
    canvas.drawCircle({
     center_x: x0 + shag * [i],
     center_y: yArrH[i] * delta + 162  - maxH * delta,
     radius: 5 ,
     color: 0xFF0000
    })
   }
   y_pogodaH[i] = (yArrH[i] * delta + 145  - maxH * delta) - 5;
   DigDay[i].setProperty(hmUI.prop.more, {
    x: x0 - 28  + i * 45*kf  * 1.02,
    y: y_pogodaH[i] - 18 , //120-7//120-7/- 38
    w: 50 ,
    h: 40 ,
    color: "0xFFffffff",
    text_size: 27*kf ,
    text: yArrH[i],
    text_style: hmUI.text_style.NONE,
    align_h: hmUI.align.CENTER_H,
    align_v: hmUI.align.CENTER_V,
    show_level: hmUI.show_level.ONLY_NORMAL
   });

   if (i < dney - 1) {
    if (tip_grafik == 0) {
     canvas.drawCircle({
      center_x: x0 + 23  + shag * [i],
      center_y: yArrL[i] * delta + 162  - maxH * delta,
      radius: 5 ,
      color: 0x00eaff
     })
    }
    y_pogodaL[i] = (yArrL[i] * delta + 145  - maxH * delta) - 5;;
    DigNight[i].setProperty(hmUI.prop.more, {
     x: x0 - 5  + i * 45*kf * 1.02,
     y: y_pogodaL[i] + 19 , //120-7 / - 1  
     w: 50 ,
     h: 40 ,
     color: "0xFFffffff",
     text_size: 27*kf,
     text: yArrL[i],
     text_style: hmUI.text_style.NONE,
     align_h: hmUI.align.CENTER_H,
     align_v: hmUI.align.CENTER_V,
     show_level: hmUI.show_level.ONLY_NORMAL
    });
   } //dney - 1
  }; //dney   
 }


 function splain(n) {
  let arr_a = new Array(n).fill().map(() => new Array(1));
  let arr_b = new Array(n - 1).fill().map(() => new Array(1));
  let arr_c = new Array(n).fill().map(() => new Array(1));
  let arr_d = new Array(n - 1).fill().map(() => new Array(1));

  let arr_h = new Array(n - 1).fill().map(() => new Array(1));
  let arr_alpha = new Array(n).fill().map(() => new Array(1));
  let arr_l = new Array(n).fill().map(() => new Array(1));
  let arr_mu = new Array(n).fill().map(() => new Array(1));
  let arr_z = new Array(n).fill().map(() => new Array(1));

  for (var i = 0; i < n - 1; i++) {
   arr_h[i] = arr_x[i + 1] - arr_x[i];
  }

  for (var i = 1; i < n - 1; i++) {
   arr_alpha[i] = 3 * ((arr_y[i + 1] - arr_y[i]) / arr_h[i] - (arr_y[i] - arr_y[i - 1]) / arr_h[i - 1]);
  }

  arr_l[0] = 1;
  arr_mu[0] = 0;
  arr_z[0] = 0;

  for (var i = 1; i < n - 1; i++) {
   arr_l[i] = 2 * (arr_x[i + 1] - arr_x[i - 1]) - arr_h[i - 1] * arr_mu[i - 1];
   arr_mu[i] = arr_h[i] / arr_l[i];
   arr_z[i] = (arr_alpha[i] - arr_h[i - 1] * arr_z[i - 1]) / arr_l[i];
  }

  arr_l[n - 1] = 1;
  arr_z[n - 1] = 0;
  arr_c[n - 1] = 0;

  for (var j = n - 2; j >= 0; j--) {
   arr_c[j] = arr_z[j] - arr_mu[j] * arr_c[j + 1];
   arr_b[j] = (arr_y[j + 1] - arr_y[j]) / arr_h[j] - arr_h[j] * (arr_c[j + 1] + 2 * arr_c[j]) / 3;
   arr_d[j] = (arr_c[j + 1] - arr_c[j]) / (3 * arr_h[j]);
   arr_a[j] = arr_y[j];
  }

  for (var i = 0; i < n - 1; i++) {
   for (xi = arr_x[i]; xi < arr_x[i + 1] - 1; xi += 5) {
    yi = arr_a[i] + arr_b[i] * (xi - arr_x[i]) + arr_c[i] * Math.pow((xi - arr_x[i]), 2) + arr_d[i] * Math.pow((xi - arr_x[i]), 3);

    if (tip_grafik == 0) {
     canvas.drawImage({
      x: xi,
      y: yi,
      w: 5,
      h: 310 - yi,
      alpha: 127,
      image: n == dney ? 'images/Grafik/line_day.png' : 'images/Grafik/line_night.png'
     })
    }

    canvas.drawLine({
     x1: xi,
     y1: yi,
     x2: xi + 5,
     y2: arr_a[i] + arr_b[i] * (xi + 5 - arr_x[i]) + arr_c[i] * Math.pow((xi + 5 - arr_x[i]), 2) + arr_d[i] * Math.pow((xi + 5 - arr_x[i]), 3),
     // color: n == dney ? 0xff0000 : 0x00eaff//0x009cff  yArrAll.length - 1
     color: n == dney ? 0xff0000 : n == dney - 1 ? 0x00eaff : 0x12a2fd //0x009cff
    })


   }
  }

 }



// Получить текущее давление с датчика (Паскали)
// Константы для глобального хранения давления (общие для всех циферблатов)

function updatePressureFromProvider(pressStr) {
    let pressure = parseFloat(pressStr);
    if (isNaN(pressure) || pressure === 0) return;

    let idx = weatherProvider.index;
    let nowSec = Math.floor(Date.now() / 1000);
    let keyOld = `svr_press_old_${idx}`;
    let keyTime = `svr_press_old_time_${idx}`;

    let oldPress = hmFS.SysProGetInt(keyOld) || 0;
    let oldTime = hmFS.SysProGetInt(keyTime) || 0;

    if (oldPress === 0 || (nowSec - oldTime) >= 10800) {
        hmFS.SysProSetInt(keyOld, pressure);
        hmFS.SysProSetInt(keyTime, nowSec);
        oldPress = pressure;
    }

    let delta = pressure - oldPress;
    let trend = (delta < 0) ? "↓" : ((delta > 0) ? "↑" : "=");
    
    let color;
    if (weatherProvider.props.baro_unit_index === 0) {
        color = (pressure < 760) ? 0xffff00 : ((pressure > 760) ? 0xff0000 : 0x00ff00);
    } else {
        color = (pressure < 1013.25) ? 0xffff00 : ((pressure > 1013.25) ? 0xff0000 : 0x00ff00);
    }

    let displayStr = Math.round(pressure) + trend;
    if (typeof text_pressere !== 'undefined') {
        text_pressere.setProperty(hmUI.prop.TEXT, displayStr);
        text_pressere.setProperty(hmUI.prop.COLOR, color);
    }
}





// ---- масштабируемые константы ----
const SQUARE_SIZE = 112 * kf;
const INNER_DIAMETER = 302 * kf;
const OUTER_DIAMETER = D_W;
const OFFSET = -6 * kf;            // сдвиг масштабируем
const EDIT_W = 124 * kf;           // ширина области редактирования
const EDIT_H = 124 * kf;
const BUTTON_W = 113 * kf;         // размер кликабельной зоны
const BUTTON_H = 113 * kf;
const TIPS_WIDTH = 195 * kf;       // ширина подсказки
const TIPS_MARGIN = 10 * kf;
const COMMON_TIPS_X = -35 * kf;    // общий сдвиг подсказки по X

// ---- массив конфигураций (с масштабированными tipsY) ----
const tapConfigs = Array.from({ length: 6 }, (_, i) => {
  const angle = -Math.PI / 2 + i * (2 * Math.PI / 6);
  const centerX = (OUTER_DIAMETER / 2) + (INNER_DIAMETER / 2) * Math.cos(angle);
  const centerY = (OUTER_DIAMETER / 2) + (INNER_DIAMETER / 2) * Math.sin(angle);

  const x = Math.round(centerX - SQUARE_SIZE / 2) + Math.round(OFFSET);
  const y = Math.round(centerY - SQUARE_SIZE / 2) + Math.round(OFFSET);

  let defaultType, tipsY_base;
  switch (i) {
    case 0: defaultType = 19; tipsY_base = 130; break;
    case 1: defaultType = 20; tipsY_base = 130; break;
    case 2: defaultType = 24; tipsY_base = -62; break;
    case 3: defaultType = 11; tipsY_base = -64; break;
    case 4: defaultType = 35; tipsY_base = -62; break;
    case 5: defaultType = 0;  tipsY_base = 130; break;
  }

  return {
    id: 101 + i,
    x: x,
    y: y,
    defaultType: defaultType,
    tipsX: COMMON_TIPS_X,
    tipsY: Math.round(tipsY_base * kf)   // масштабируем вертикальный сдвиг
  };
});

// ---- позиции квадратов (без OFFSET, только центры) ----
const tapPositions = Array.from({ length: 6 }, (_, i) => {
  const angle = -Math.PI / 2 + i * (2 * Math.PI / 6);
  const centerX = (OUTER_DIAMETER / 2) + (INNER_DIAMETER / 2) * Math.cos(angle);
  const centerY = (OUTER_DIAMETER / 2) + (INNER_DIAMETER / 2) * Math.sin(angle);
  return {
    x: Math.round(centerX - SQUARE_SIZE / 2),
    y: Math.round(centerY - SQUARE_SIZE / 2),
    index: i
  };
});

// ---- получение выбранных типов приложений ----
const tapSelections = [];
for (let i = 0; i < tapConfigs.length; i++) {
  const config = tapConfigs[i];
  const edit = hmUI.createWidget(hmUI.widget.WATCHFACE_EDIT_GROUP, {
    edit_id: config.id,
    x: config.x,
    y: config.y,
    w: Math.round(EDIT_W),
    h: Math.round(EDIT_H),
    select_image: 'tap/edit_red_1.png',
    un_select_image: 'tap/edit_griin_1.png',
    default_type: config.defaultType,
    optional_types: apps.map((app, index) => ({
      type: index,
      preview: app[2],
      title_en: app[0]
    })),
    count: apps.length,
    tips_x: Math.round(config.tipsX),
    tips_y: Math.round(config.tipsY),
    tips_width: Math.round(TIPS_WIDTH),
    tips_margin: Math.round(TIPS_MARGIN),
    tips_BG: 'tap/tips_bg.png'
  });
  // небольшая задержка (лучше использовать setTimeout, но цикл оставлен как в оригинале)
  for (let c = 0; c < 1000; c++) {}
  tapSelections[i] = edit.getProperty(hmUI.prop.CURRENT_TYPE);
}

// ---- создание интерфейса с иконками и кнопками ----
function createTapInterface() {
  const groupTap = hmUI.createWidget(hmUI.widget.GROUP, {
    x: 0, y: 0, w: D_W, h: D_H,
    show_level: hmUI.show_level.ONLY_NORMAL
  });

  groupTap.createWidget(hmUI.widget.IMG, {
    x: 0, y: 0, w: D_W, h: D_H,
    src: 'tap/i_tap_bg.png',
    show_level: hmUI.show_level.ONLY_NORMAL,
  });

  for (let i = 0; i < 6; i++) {
    const pos = tapPositions[i];
    const appIndex = tapSelections[i];
    if (appIndex === undefined) continue;

    // иконка приложения
    groupTap.createWidget(hmUI.widget.IMG, {
      x: pos.x,
      y: pos.y,
      src: apps[appIndex][2],
      show_level: hmUI.show_level.ONLY_NORMAL,
    });

    // невидимая кнопка
    groupTap.createWidget(hmUI.widget.BUTTON, {
      x: pos.x,
      y: pos.y,
      w: Math.round(BUTTON_W),
      h: Math.round(BUTTON_H),
      normal_src: '0_Empty.png',
      press_src: '0_Empty.png',
      click_func: () => {
        vibro();
        const app = apps[appIndex];
        hmApp.startApp({
          appid: app[3] === 0 ? '' : app[1],
          url: app[3] === 0 ? app[1] : app[4],
          native: app[3] === 0,
          params: app[3] === 0 ? null : { from_wf: true }
        });
      },
      show_level: hmUI.show_level.ONLY_NORMAL,
    });
  }
  return groupTap;
}
	 

 const TIME_ZONES = [
  "UTC", "CET", "КЛГ", "МСК", "САМ", "ЕКБ", "ОМСК", "КРАС",
  "ИРК", "ЯКУ", "ВЛД", "МАГ", "КАМ", "SST", "HST", "AKST",
  "PST", "MST", "CST", "EST", "AST", "BRT", "GST", "CVT"
 ];



let normal_unit_font = [];
function createUnitText(x, y, visible) {
  const widget = hmUI.createWidget(hmUI.widget.TEXT, {
    x, y,
    w: 150,
    h: 80,
    text_size: 19,
    text: '',
    font: 'fonts/Oswald-Medium.ttf',
    color: 0x90ffff,
    align_h: hmUI.align.CENTER_H,
    align_v: hmUI.align.CENTER_V,
    show_level: hmUI.show_level.ONLY_NORMAL
  });
  widget.setProperty(hmUI.prop.VISIBLE, visible);
  return widget;
} 
 
let normal_ic = [];
function createIconWidget(x, y, index) {
  const id = CONF_MAIN[index].id;
  const widget = hmUI.createWidget(hmUI.widget.TEXT, {
    x, y,
    w: 80,
    h: 80,
    text_size: 34,
    text: Line_arr[id][0],
    char_space: 0,
    line_space: 0,
    font: 'fonts/ic_Sever1.ttf',
    color: Line_arr[id][4],
    align_h: hmUI.align.CENTER_H,
    align_v: hmUI.align.CENTER_V,
    text_style: hmUI.text_style.ELLIPSIS,
    show_level: hmUI.show_level.ONLY_NORMAL
  });
  widget.setProperty(hmUI.prop.VISIBLE, id != 16 && id != 20 && id != 14);
  return widget;
}


let normal_uvi_img = [];
function createUviImg(x, y, visible) {
    const widget = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
    x, y,
    image_array: ["images/APP/uv_0.png", "images/APP/uv_1.png", "images/Grafik/ic_activ/uv_2.png", "images/APP/uv_3.png", "images/APP/uv_4.png"],
    image_length: 5,
    type: hmUI.data_type.UVI,
    show_level: hmUI.show_level.ONLY_NORMAL,
    });
    widget.setProperty(hmUI.prop.VISIBLE, visible);
    return widget;
} 

let normal_sun_img = [];
function createSunImg(x, y, visible) {
    const widget = hmUI.createWidget(hmUI.widget.IMG, {
    x, y,
    src: 'images/APP/ic_vos_n.png',
    show_level: hmUI.show_level.ONLY_NORMAL,
    });
    widget.setProperty(hmUI.prop.VISIBLE, visible);
    return widget;
} 

  //let normal_data = Array(3*2).fill().map(() => []);

// Объявляем массив для виджетов данных
const normal_data = [[], [], [], [], [], []]; // Индексы 0-5, будем использовать 3,4,5
// Функция для создания виджета данных для конкретной позиции
function createDataWidget(i, position) {
  // Определяем параметры для каждой позиции
  const positionConfig = {
    3: { x: 12, y: 299 },   // Левая позиция
    4: { x: 309, y: 299 },  // Правая позиция
    5: { x: 158, y: 29 }      // Верхняя позиция
  };
  const config = positionConfig[position];
  // Создаем виджет
  const widget = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
    x: config.x,
    y: config.y,
    w: 150,
    h: 60,
    text_size: 33,
    char_space: 0,
    line_space: 0,
    font: 'fonts/Oswald-Regular.ttf',
    color: color_bg[0][CONF_MAIN[1].id],
    align_h: hmUI.align.CENTER_H,
    align_v: hmUI.align.CENTER_V,
    text_style: hmUI.text_style.ELLIPSIS,
    unit_type: Line_arr[i][2],
    padding: Line_arr[i][6],
    type: Line_arr[i][5],
    show_level: hmUI.show_level.ONLY_NORMAL
  });
  // Устанавливаем видимость ВНУТРИ функции
  widget.setProperty(hmUI.prop.VISIBLE, CONF_MAIN[position].id == i);
  return widget;
}


// Объявляем массив для текстовых виджетов значений
const normal_sensor_value = []; // Индексы 3,4,5 для left, right, up
// Функция для создания текстовых виджетов значений
function createValueWidget(position) {
  // Конфигурация позиций (только координаты, ширина всегда 150)
  const positionConfig = {
    3: { x: 12, y: 299 },   // Левая позиция
    4: { x: 309, y: 299 },  // Правая позиция
    5: { x: 158, y: 29 }    // Верхняя позиция
  };
  const id = CONF_MAIN[position].id;
  const config = positionConfig[position];
  const widget = hmUI.createWidget(hmUI.widget.TEXT, {
    x: config.x,
    y: config.y,
    w: 150,  // Фиксированная ширина для всех виджетов
    h: 60,
    text_size: 33,
    text: Line_arr[id][1],
    char_space: 0,
    line_space: 0,
    font: 'fonts/Oswald-Regular.ttf',
    color: color_bg[0][CONF_MAIN[1].id],
    align_h: hmUI.align.CENTER_H,
    align_v: hmUI.align.CENTER_V,
    text_style: hmUI.text_style.ELLIPSIS,
    show_level: hmUI.show_level.ONLY_NORMAL
  });
  // Устанавливаем видимость сразу
  widget.setProperty(hmUI.prop.VISIBLE, Line_arr[id][5] == '');
  return widget;
}
 
 

        // end user_functions.js

        let normal_image_img = ''
        let normal_step_linear_scale = ''
        let normal_step_current_text_font = ''
        let normal_battery_circle_scale = ''
        let normal_battery_icon_img = ''
        let normal_battery_current_text_font = ''
        let normal_widget_text_1 = ''
        let normal_widget_text_2 = ''
        let normal_widget_text_3 = ''
        let normal_widget_text_4 = ''
        let normal_widget_text_5 = ''
        let normal_widget_text_6 = ''
        let normal_widget_text_7 = ''
        let normal_widget_text_8 = ''
        let normal_widget_text_9 = ''
        let normal_widget_text_10 = ''
        let normal_widget_text_11 = ''
        let normal_widget_text_12 = ''
        let normal_widget_text_13 = ''
        let normal_widget_text_14 = ''
        let normal_widget_text_15 = ''
        let normal_time_hour_text_font = ''
        let normal_timerTimeUpdate = undefined;
        let normal_time_minute_text_font = ''
        let normal_time_second_text_font = ''
        let normal_month_name_font = ''
        let normal_Month_Array = ['ЯНВАРЬ', 'ФЕВРАЛЬ', 'МАРТ', 'АПРЕЛЬ', 'МАЙ', 'ИЮНЬ', 'ИЮЛЬ', 'АВГУСТ', 'СЕНТЯБРЬ', 'ОКТЯБРЬ', 'НОЯБРЬ', 'ДЕКАБРЬ', ];
        let normal_pressure_text_font = ''
        let normal_city_name_text = ''
        let normal_temperature_max_min_text_font = ''
        let normal_temperature_current_text_font = ''
        let normal_date_img_date_week_img = ''
        let normal_calorie_current_text_font = ''
        let normal_heart_rate_text_font = ''
        let normal_day_text_font = ''
        let normal_system_disconnect_img = ''
        let normal_system_clock_img = ''
        let normal_alarm_clock_current_text_font = ''
        let normal_analog_clock_time_pointer_smooth_second = ''
        let Button_1 = ''
        let Button_2 = ''
        let timeSensor = '';


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            // FontName: dsb.ttf; FontSize: 41
            hmUI.createWidget(hmUI.widget.TEXT, {
              x: 464,
              y: 464,
              w: 536,
              h: 49,
              text_size: 41,
              char_space: 0,
              line_space: 0,
              font: 'fonts/dsb.ttf',
              color: 0xFF000000,
              align_h: hmUI.align.RIGHT,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              text: "0123456789 _+-.,:;`'%°\\/",
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // FontName: conthrax_sb.ttf; FontSize: 21
            hmUI.createWidget(hmUI.widget.TEXT, {
              x: 464,
              y: 464,
              w: 388,
              h: 30,
              text_size: 21,
              char_space: 0,
              line_space: 0,
              font: 'fonts/conthrax_sb.ttf',
              color: 0xFFCFD8F7,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              text: "0123456789 _+-.,:;`'%°\\/",
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // FontName: segment2new-Regular.ttf; FontSize: 88
            hmUI.createWidget(hmUI.widget.TEXT, {
              x: 464,
              y: 464,
              w: 1357,
              h: 106,
              text_size: 88,
              char_space: 0,
              line_space: 0,
              font: 'fonts/segment2new-Regular.ttf',
              color: 0xFFCF4900,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              text: "0123456789 _+-.,:;`'%°\\/",
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // FontName: segment2new-Regular.ttf; FontSize: 63
            hmUI.createWidget(hmUI.widget.TEXT, {
              x: 464,
              y: 464,
              w: 626,
              h: 75,
              text_size: 63,
              char_space: -11,
              line_space: 0,
              font: 'fonts/segment2new-Regular.ttf',
              color: 0xFFCF4900,
              align_h: hmUI.align.LEFT,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              text: "0123456789 _+-.,:;`'%°\\/",
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // FontName: ArtegraSansExtendedAlt-ExBdIt.ttf; FontSize: 14
            hmUI.createWidget(hmUI.widget.TEXT, {
              x: 464,
              y: 464,
              w: 283,
              h: 27,
              text_size: 14,
              char_space: 0,
              line_space: 0,
              font: 'fonts/ArtegraSansExtendedAlt-ExBdIt.ttf',
              color: 0xFFCFD8F7,
              align_h: hmUI.align.LEFT,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              text: "0123456789 _+-.,:;`'%°\\/",
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // FontName: HeadingSmallcaseProicv8-Bold.ttf; FontSize: 33
            hmUI.createWidget(hmUI.widget.TEXT, {
              x: 464,
              y: 464,
              w: 476,
              h: 48,
              text_size: 33,
              char_space: 0,
              line_space: 0,
              font: 'fonts/HeadingSmallcaseProicv8-Bold.ttf',
              color: 0xFFCFD8F7,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              text: "0123456789 _+-.,:;`'%°\\/",
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // FontName: weater_contur_by_Sever5187_V5-Regular.ttf; FontSize: 39
            hmUI.createWidget(hmUI.widget.TEXT, {
              x: 464,
              y: 464,
              w: 496,
              h: 56,
              text_size: 39,
              char_space: 0,
              line_space: 0,
              font: 'fonts/weater_contur_by_Sever5187_V5-Regular.ttf',
              color: 0xFF000000,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              text: "0123456789 _+-.,:;`'%°\\/",
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // FontName: Bebas22.ttf; FontSize: 18
            hmUI.createWidget(hmUI.widget.TEXT, {
              x: 464,
              y: 464,
              w: 244,
              h: 25,
              text_size: 18,
              char_space: 0,
              line_space: 0,
              font: 'fonts/Bebas22.ttf',
              color: 0xFFCFD8F7,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              text: "0123456789 _+-.,:;`'%°\\/",
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // FontName: dsb.ttf; FontSize: 43
            hmUI.createWidget(hmUI.widget.TEXT, {
              x: 464,
              y: 464,
              w: 564,
              h: 51,
              text_size: 43,
              char_space: 0,
              line_space: 0,
              font: 'fonts/dsb.ttf',
              color: 0xFF000000,
              align_h: hmUI.align.RIGHT,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              text: "0123456789 _+-.,:;`'%°\\/",
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // FontName: HeadingSmallcaseProicv8-Bold.ttf; FontSize: 30
            hmUI.createWidget(hmUI.widget.TEXT, {
              x: 464,
              y: 464,
              w: 412,
              h: 42,
              text_size: 30,
              char_space: 0,
              line_space: 0,
              font: 'fonts/HeadingSmallcaseProicv8-Bold.ttf',
              color: 0xFFCFD8F7,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              text: "0123456789 _+-.,:;`'%°\\/",
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // FontName: ArtegraSansExtendedAlt-ExBdIt.ttf; FontSize: 18; Cache: full
            hmUI.createWidget(hmUI.widget.TEXT, {
              x: 464,
              y: 464,
              w: 21,
              h: 21,
              text_size: 18,
              char_space: 0,
              line_space: 0,
              font: 'fonts/ArtegraSansExtendedAlt-ExBdIt.ttf',
              color: 0xFFCF4900,
              align_h: hmUI.align.LEFT,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.NONE,
              text: "0123456789 ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz АБВГДЕЁЖЗИЙКЛМНОПРСТУФХЦЧШЩЪЫЬЭЮЯабвгдеёжзийклмнопрстуфхцчшщъыьэюя  ҐЄІЇґєії _+-.,:;`'%°\\/",
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // FontName: dsb.ttf; FontSize: 43; Cache: full
            hmUI.createWidget(hmUI.widget.TEXT, {
              x: 464,
              y: 464,
              w: 51,
              h: 51,
              text_size: 43,
              char_space: 0,
              line_space: 0,
              font: 'fonts/dsb.ttf',
              color: 0xFF000000,
              align_h: hmUI.align.RIGHT,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.NONE,
              text: "0123456789 ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz АБВГДЕЁЖЗИЙКЛМНОПРСТУФХЦЧШЩЪЫЬЭЮЯабвгдеёжзийклмнопрстуфхцчшщъыьэюя  ҐЄІЇґєії _+-.,:;`'%°\\/",
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // FontName: ArtegraSansExtendedAlt-ExBdIt.ttf; FontSize: 14; Cache: full
            hmUI.createWidget(hmUI.widget.TEXT, {
              x: 464,
              y: 464,
              w: 16,
              h: 16,
              text_size: 14,
              char_space: 0,
              line_space: 0,
              font: 'fonts/ArtegraSansExtendedAlt-ExBdIt.ttf',
              color: 0xFF000000,
              align_h: hmUI.align.RIGHT,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.NONE,
              text: "0123456789 ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz АБВГДЕЁЖЗИЙКЛМНОПРСТУФХЦЧШЩЪЫЬЭЮЯабвгдеёжзийклмнопрстуфхцчшщъыьэюя  ҐЄІЇґєії _+-.,:;`'%°\\/",
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // FontName: dsb.ttf; FontSize: 30
            hmUI.createWidget(hmUI.widget.TEXT, {
              x: 464,
              y: 464,
              w: 381,
              h: 36,
              text_size: 30,
              char_space: 0,
              line_space: 0,
              font: 'fonts/dsb.ttf',
              color: 0xFFCFD8F7,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              text: "0123456789 _+-.,:;`'%°\\/",
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // FontName: conthrax_sb.ttf; FontSize: 37
            hmUI.createWidget(hmUI.widget.TEXT, {
              x: 464,
              y: 464,
              w: 679,
              h: 52,
              text_size: 37,
              char_space: 0,
              line_space: 0,
              font: 'fonts/conthrax_sb.ttf',
              color: 0xFFCFD8F7,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              text: "0123456789 _+-.,:;`'%°\\/",
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            console.log('user_script_start.js');
            // start user_script_start.js

loadSettings()

hmUI.createWidget(hmUI.widget.TEXT, {
 x: D_W + 2,
 y: D_W + 2,
 w: 42 * kf,
 h: 42 * kf,
 text_size: 27 * kf,
 char_space: 0,
 line_space: 0,
 font: 'fonts/Bebas22.ttf',
 color: 0xFFFFFF00,
 align_h: hmUI.align.LEFT,
 align_v: hmUI.align.CENTER_V,
 text_style: hmUI.text_style.NONE,
 text: "0123456789 ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz АБВГДЕЁЖЗИЙКЛМНОПРСТУФХЦЧШЩЪЫЬЭЮЯабвгдеёжзийклмнопрстуфхцчшщъыьэюя   _-.,:;`'%°\\/←→↓↑#",
 show_level: hmUI.show_level.ONLY_NORMAL,
});

hmUI.createWidget(hmUI.widget.TEXT, {
 x: D_W + 2,
 y: D_W + 2,
 w: 42 * kf,
 h: 42 * kf,
 text_size: 33 * kf,
 char_space: 0,
 line_space: 0,
 font: 'fonts/Bebas22.ttf',
 color: 0xFFFFFF00,
 align_h: hmUI.align.LEFT,
 align_v: hmUI.align.CENTER_V,
 text_style: hmUI.text_style.NONE,
 text: "0123456789 ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz АБВГДЕЁЖЗИЙКЛМНОПРСТУФХЦЧШЩЪЫЬЭЮЯабвгдеёжзийклмнопрстуфхцчшщъыьэюя   _-.,:;`'%°\\/←→↓↑",
 show_level: hmUI.show_level.ONLY_NORMAL,
});

hmUI.createWidget(hmUI.widget.TEXT, {
 x: D_W + 2,
 y: D_W + 2,
 w: 328 * kf,
 h: 48 * kf,
 text_size: 35 * kf,
 char_space: 0,
 line_space: 0,
 font: 'fonts/Bebas22.ttf',
 color: 0xFFFFFFFF,
 align_h: hmUI.align.CENTER_H,
 align_v: hmUI.align.CENTER_V,
 text_style: hmUI.text_style.ELLIPSIS,
 text: "0123456789 ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz АБВГДЕЁЖЗИЙКЛМНОПРСТУФХЦЧШЩЪЫЬЭЮЯабвгдеёжзийклмнопрстуфхцчшщъыьэюя _-.,:;`'%°\\/←→↓↑",
 show_level: hmUI.show_level.ONLY_NORMAL,
});

hmUI.createWidget(hmUI.widget.TEXT, {
 x: D_W + 2,
 y: D_W + 2,
 w: 328 * kf,
 h: 48 * kf,
 text_size: 33 * kf,
 char_space: 0,
 line_space: 0,
 font: 'fonts/Bebas22.ttf',
 color: 0xFFFFFFFF,
 align_h: hmUI.align.CENTER_H,
 align_v: hmUI.align.CENTER_V,
 text_style: hmUI.text_style.ELLIPSIS,
 text: "JK=H",
 show_level: hmUI.show_level.ONLY_NORMAL,
});


/*hmUI.createWidget(hmUI.widget.TEXT, {
 x: D_W+2,
 y: D_W+2,
 w: 50*kf,
 h: 50*kf,
 text_size: 24*kf,
 char_space: 0,
 line_space: 0,
  font: 'fonts/arbrnplt.ttf',
 color: 0xFFFFFF00,
 align_h: hmUI.align.LEFT,
 align_v: hmUI.align.CENTER_V,
 text_style: hmUI.text_style.NONE,
 text: "0123456789 ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz АБВГДЕЁЖЗИЙКЛМНОПРСТУФХЦЧШЩЪЫЬЭЮЯабвгдеёжзийклмнопрстуфхцчшщъыьэюя _-.,:;`'%°\\/←→↓↑",
 show_level: hmUI.show_level.ONLY_NORMAL,
});*/

hmUI.createWidget(hmUI.widget.TEXT, {
 x: D_W + 2,
 y: D_W + 2,
 w: 70 * kf,
 h: 70 * kf,
 text_size: 58 * kf,
 char_space: 0,
 line_space: 0,
 font: 'fonts/weater_contur_by_Sever5187_V5-Regular.ttf',
 color: 0xFFFFFF00,
 align_h: hmUI.align.LEFT,
 align_v: hmUI.align.CENTER_V,
 text_style: hmUI.text_style.NONE,
 text: "0123456789 ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz АБВГДЕЁЖЗИЙКЛМНОПРСТУФХЦЧШЩЪЫЬЭЮЯабвгдеёжзийклмнопрстуфхцчшщъыьэюя _-.,:;`'%°\\/←→↓↑",
 show_level: hmUI.show_level.ONLY_NORMAL,
});

hmUI.createWidget(hmUI.widget.TEXT, {
 x: D_W + 2,
 y: D_W + 2,
 w: 50 * kf,
 h: 50 * kf,
 text_size: 26 * kf,
 char_space: 0,
 line_space: 0,
 font: 'fonts/weater_contur_by_Sever5187_V5-Regular.ttf',
 color: 0xFFFFFF00,
 align_h: hmUI.align.LEFT,
 align_v: hmUI.align.CENTER_V,
 text_style: hmUI.text_style.NONE,
 text: "0123456789 ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz АБВГДЕЁЖЗИЙКЛМНОПРСТУФХЦЧШЩЪЫЬЭЮЯабвгдеёжзийклмнопрстуфхцчшщъыьэюя _-.,:;`'%°\\/←→↓↑",
 show_level: hmUI.show_level.ONLY_NORMAL,
});

/*            hmUI.createWidget(hmUI.widget.TEXT, {
             x: D_W + 2,
             y: D_W + 2,
             w: 918 * kf,
             h: 112 * kf,
             text_size: 93 * kf,
             char_space: -16 * kf,
             line_space: 0,
             font: 'fonts/segmentBlacknew-Regular.ttf',
             color: 0xFFFFFFFF,
             align_h: hmUI.align.RIGHT,
             align_v: hmUI.align.TOP,
             text_style: hmUI.text_style.ELLIPSIS,
             text: "0123456789 _-.,:;`'%°\\/",
             show_level: hmUI.show_level.ONLY_NORMAL,
            });*/

hmUI.createWidget(hmUI.widget.TEXT, {
 x: D_W + 2,
 y: D_W + 2,
 w: 42 * kf,
 h: 42 * kf,
 text_size: 27 * kf,
 char_space: 0,
 line_space: 0,
 font: 'fonts/Bebas22.ttf',
 color: 0xFFFFFF00,
 align_h: hmUI.align.LEFT,
 align_v: hmUI.align.CENTER_V,
 text_style: hmUI.text_style.NONE,
 text: "0123456789 ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz АБВГДЕЁЖЗИЙКЛМНОПРСТУФХЦЧШЩЪЫЬЭЮЯабвгдеёжзийклмнопрстуфхцчшщъыьэюя   _-.,:;`'%°\\/←→↓↑",
 show_level: hmUI.show_level.ONLY_NORMAL,
});

hmUI.createWidget(hmUI.widget.TEXT, {
 x: D_W + 2,
 y: D_W + 2,
 w: 42 * kf,
 h: 42 * kf,
 text_size: 22 * kf,
 char_space: 0,
 line_space: 0,
 font: 'fonts/Bebas22.ttf',
 color: 0xFFFFFF00,
 align_h: hmUI.align.LEFT,
 align_v: hmUI.align.CENTER_V,
 text_style: hmUI.text_style.NONE,
 text: "0123456789 ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz АБВГДЕЁЖЗИЙКЛМНОПРСТУФХЦЧШЩЪЫЬЭЮЯабвгдеёжзийклмнопрстуфхцчшщъыьэюя   _-.,:;`'%°\\/←→↓↑",
 show_level: hmUI.show_level.ONLY_NORMAL,
});


if (screenTypeJS == hmSetting.screen_type.WATCHFACE) {
 normal_background = hmUI.createWidget(hmUI.widget.FILL_RECT, {
  x: 0,
  y: 0,
  w: D_W,
  h: D_W,
  color: color_bg[0][CONF_MAIN[0].id],
  //color: 0xFFFF0000,
  show_level: hmUI.show_level.ONLY_NORMAL,
 });


 normal_background_up = hmUI.createWidget(hmUI.widget.CIRCLE, {
  center_x: D_W / 2,
  center_y: D_W / 2,
  radius: 204 * kf,
  color: 0xffffff,
  // alpha: 255,
  show_level: hmUI.show_level.ONLY_NORMAL,
 });


 normal_data_bg = hmUI.createWidget(hmUI.widget.CIRCLE, {
  center_x: 333 * kf,
  center_y: 136 * kf,
  radius: 134 / 2 * kf,
  color: 0xffffff,
  // alpha: 255,
  show_level: hmUI.show_level.ONLY_NORMAL,
 });


 normal_bat_bg = hmUI.createWidget(hmUI.widget.CIRCLE, {
  center_x: 350 * kf,
  center_y: 343 * kf,
  radius: 48 * kf,
  color: 0xffffff,
  // alpha: 255,
  show_level: hmUI.show_level.ONLY_NORMAL,
 });

 normal_step_bg = hmUI.createWidget(hmUI.widget.FILL_RECT, {
  x: 154 * kf,
  y: 415 * kf,
  w: 107 * kf,
  h: 12 * kf,
  color: color_bg[0][CONF_MAIN[0].id],
  //color: 0xFFFF0000,
  show_level: hmUI.show_level.ONLY_NORMAL,
 });

}

/*            normal_mask_0_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
             x: 0,
             y: 0,
             w: D_W,
             h: D_W,
             src: 'maskUp_2.png',
             auto_scale: true,
             show_level: hmUI.show_level.ONLY_NORMAL,
            });


normal_mask_1_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
    x: 0,
    y: 0,
    w: D_W+1,
    h: D_W+1,
    pos_x: 0,
    pos_y: 0,
    center_x: D_W/2,
    center_y: D_W/2,
    angle: 0,
    src: 'mask_1_0.png',
	auto_scale: true,
    show_level: hmUI.show_level.ONLY_NORMAL,
});*/
            // end user_script_start.js

            console.log('Watch_Face.ScreenNormal');

            normal_image_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'bg.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            console.log('user_script.js');
            // start user_script.js
normal_setka_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
  x: 50 * kf,
  y: 79 * kf,
  w: 322 * kf,
  h: 325 * kf,
  src: 'setka_0.png',
  auto_scale: true,
  show_level: hmUI.show_level.ONLY_NORMAL,
 });
            // end user_script.js

            let screenType = hmSetting.getScreenType();
            if (screenType != hmSetting.screen_type.AOD) {
              normal_step_linear_scale = hmUI.createWidget(hmUI.widget.FILL_RECT);

            normal_step_linear_scale.setAlpha(128);
            };

            // normal_step_linear_scale = hmUI.createWidget(hmUI.widget.Linear_Scale, {
              // start_x: 156,
              // start_y: 415,
              // color: 0xFF000000,
              // lenght: 103,
              // line_width: 10,
              // line_cap: Flat,
              // vertical: False,
              // mirror: False,
              // inversion: True,
              // alpha: 128,
              // type: hmUI.data_type.STEP,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });
            
            const step = hmSensor.createSensor(hmSensor.id.STEP);
            step.addEventListener(hmSensor.event.CHANGE, function() {
              scale_call();
            });

            normal_step_current_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 129,
              y: 313,
              w: 150,
              h: 50,
              text_size: 41,
              char_space: 0,
              font: 'fonts/dsb.ttf',
              color: 0xFF000000,
              line_space: 0,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_battery_circle_scale = hmUI.createWidget(hmUI.widget.Circle_Scale, {
              // center_x: 349,
              // center_y: 342,
              // start_angle: -152,
              // end_angle: 150,
              // radius: 44,
              // line_width: 13,
              // line_cap: Flat,
              // color: 0xFF000000,
              // mirror: False,
              // inversion: True,
              // alpha: 125,
              // type: hmUI.data_type.BATTERY,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_battery_circle_scale = hmUI.createWidget(hmUI.widget.ARC_PROGRESS, {
              center_x: 349,
              center_y: 342,
              start_angle: 150,
              end_angle: -152,
              radius: 38,
              line_width: 13,
              corner_flag: 3,
              color: 0xFF000000,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_circle_scale.setAlpha(125);
            
            const battery = hmSensor.createSensor(hmSensor.id.BATTERY);
            battery.addEventListener(hmSensor.event.CHANGE, function() {
              scale_call();
            });

            normal_battery_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 155,
              y: 299,
              src: 'cap_progress.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_current_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 274,
              y: 329,
              w: 150,
              h: 30,
              text_size: 21,
              char_space: 0,
              font: 'fonts/conthrax_sb.ttf',
              color: 0xFFCFD8F7,
              line_space: 0,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_widget_text_1 = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 117,
              y: 214,
              w: 70,
              h: 120,
              text_size: 88,
              char_space: 0,
              font: 'fonts/segment2new-Regular.ttf',
              color: 0xFFCF4900,
              line_space: 0,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.NONE,
              align_h: hmUI.align.CENTER_H,
              text: ':',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_widget_text_2 = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 6,
              y: 214,
              w: 150,
              h: 120,
              text_size: 88,
              char_space: -11,
              font: 'fonts/segment2new-Regular.ttf',
              alpha: 35,
              color: 0xFFCFD8F7,
              line_space: 0,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.NONE,
              align_h: hmUI.align.RIGHT,
              text: '88',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_widget_text_3 = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 156,
              y: 214,
              w: 150,
              h: 120,
              text_size: 88,
              char_space: -11,
              font: 'fonts/segment2new-Regular.ttf',
              alpha: 35,
              color: 0xFFCFD8F7,
              line_space: 0,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.NONE,
              align_h: hmUI.align.LEFT,
              text: '88',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_widget_text_4 = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 252,
              y: 232,
              w: 150,
              h: 100,
              text_size: 63,
              char_space: -11,
              font: 'fonts/segment2new-Regular.ttf',
              alpha: 35,
              color: 0xFFCF4900,
              line_space: 0,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.NONE,
              align_h: hmUI.align.LEFT,
              text: '88',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_widget_text_5 = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 265,
              y: 356,
              w: 150,
              h: 100,
              text_size: 14,
              char_space: 0,
              font: 'fonts/ArtegraSansExtendedAlt-ExBdIt.ttf',
              color: 0xFFCFD8F7,
              line_space: 0,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.NONE,
              align_h: hmUI.align.LEFT,
              text: 'КМ',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_widget_text_6 = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 123,
              y: 297,
              w: 150,
              h: 100,
              text_size: 14,
              char_space: 0,
              font: 'fonts/ArtegraSansExtendedAlt-ExBdIt.ttf',
              color: 0xFF000000,
              line_space: 0,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.RIGHT,
              text: 'ШАГОВ',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_widget_text_7 = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 381,
              y: 171,
              w: 70,
              h: 70,
              text_size: 33,
              char_space: 0,
              font: 'fonts/HeadingSmallcaseProicv8-Bold.ttf',
              color: 0xFFCFD8F7,
              line_space: 0,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.CENTER_H,
              text: 'P',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_widget_text_8 = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 381,
              y: 290,
              w: 70,
              h: 70,
              text_size: 33,
              char_space: 0,
              font: 'fonts/HeadingSmallcaseProicv8-Bold.ttf',
              color: 0xFFCFD8F7,
              line_space: 0,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.CENTER_H,
              text: 'C',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_widget_text_9 = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 60,
              y: 161,
              w: 70,
              h: 70,
              text_size: 33,
              char_space: 0,
              font: 'fonts/HeadingSmallcaseProicv8-Bold.ttf',
              color: 0xFF000000,
              line_space: 0,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.CENTER_H,
              text: 'JK=H',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_widget_text_10 = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 78,
              y: 87,
              w: 70,
              h: 70,
              text_size: 39,
              char_space: 0,
              font: 'fonts/weater_contur_by_Sever5187_V5-Regular.ttf',
              color: 0xFF000000,
              line_space: 0,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.CENTER_H,
              text: 'Г',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_widget_text_11 = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 100,
              y: 49,
              w: 266,
              h: 70,
              text_size: 18,
              char_space: 0,
              font: 'fonts/Bebas22.ttf',
              color: 0xFFCFD8F7,
              line_space: 0,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.CENTER_H,
              text: 'НЕИЗВЕСТНАЯ ПОГОДА',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_widget_text_12 = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 104,
              y: 159,
              w: 150,
              h: 60,
              text_size: 43,
              char_space: 0,
              font: 'fonts/dsb.ttf',
              color: 0xFF000000,
              line_space: 0,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.RIGHT,
              text: '18:30',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_widget_text_13 = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 90,
              y: 360,
              w: 150,
              h: 60,
              text_size: 41,
              char_space: 0,
              font: 'fonts/dsb.ttf',
              color: 0xFF000000,
              line_space: 0,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.RIGHT,
              text: '5.41',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_widget_text_14 = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 355,
              y: 247,
              w: 50,
              h: 50,
              text_size: 30,
              char_space: 0,
              font: 'fonts/HeadingSmallcaseProicv8-Bold.ttf',
              color: 0xFFCFD8F7,
              line_space: 0,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.CENTER_H,
              text: '{}',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_widget_text_15 = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 59,
              y: 144,
              w: 200,
              h: 100,
              text_size: 14,
              char_space: 0,
              font: 'fonts/ArtegraSansExtendedAlt-ExBdIt.ttf',
              color: 0xFF000000,
              line_space: 0,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.RIGHT,
              text: 'НОЧЬ/ДЕНЬ',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            if (!timeSensor) timeSensor = hmSensor.createSensor(hmSensor.id.TIME);
            normal_time_hour_text_font = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 6,
              y: 213,
              w: 150,
              h: 120,
              text_size: 88,
              char_space: -11,
              font: 'fonts/segment2new-Regular.ttf',
              color: 0xFFCFD8F7,
              line_space: 0,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.RIGHT,
              // padding: true,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_time_minute_text_font = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 156,
              y: 213,
              w: 150,
              h: 120,
              text_size: 88,
              char_space: -11,
              font: 'fonts/segment2new-Regular.ttf',
              color: 0xFFCFD8F7,
              line_space: 0,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.LEFT,
              // padding: true,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_time_second_text_font = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 252,
              y: 232,
              w: 150,
              h: 100,
              text_size: 63,
              char_space: -11,
              font: 'fonts/segment2new-Regular.ttf',
              color: 0xFFCF4900,
              line_space: 0,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.LEFT,
              // padding: true,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            timeSensor.addEventListener(timeSensor.event.DAYCHANGE, function() {
              time_update(true);
            });

            normal_month_name_font = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 252,
              y: 208,
              w: 150,
              h: 30,
              text_size: 18,
              char_space: 0,
              font: 'fonts/ArtegraSansExtendedAlt-ExBdIt.ttf',
              color: 0xFFCF4900,
              line_space: 0,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.LEFT,
              // unit_string: ЯНВАРЬ, ФЕВРАЛЬ, МАРТ, АПРЕЛЬ, МАЙ, ИЮНЬ, ИЮЛЬ, АВГУСТ, СЕНТЯБРЬ, ОКТЯБРЬ, НОЯБРЬ, ДЕКАБРЬ,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_pressure_text_font = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 104,
              y: 159,
              w: 150,
              h: 60,
              text_size: 43,
              char_space: 0,
              font: 'fonts/dsb.ttf',
              color: 0xFF000000,
              line_space: 0,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.RIGHT,
              // unit_type: 1,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            const baroSensor = hmSensor.createSensor(hmSensor.id.BARO);
              const weatherSensor = hmSensor.createSensor(hmSensor.id.WEATHER);

            normal_city_name_text = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 98,
              y: 82,
              w: 174,
              h: 100,
              text_size: 14,
              char_space: 0,
              font: 'fonts/ArtegraSansExtendedAlt-ExBdIt.ttf',
              color: 0xFF000000,
              line_space: 0,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.NONE,
              align_h: hmUI.align.RIGHT,
              // unit_type: 1,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_max_min_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 104,
              y: 159,
              w: 150,
              h: 60,
              text_size: 43,
              char_space: 0,
              font: 'fonts/dsb.ttf',
              color: 0xFF000000,
              line_space: 0,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.RIGHT,
              unit_type: 1,
              type: hmUI.data_type.WEATHER_HIGH_LOW,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 93,
              y: 96,
              w: 150,
              h: 60,
              text_size: 43,
              char_space: 0,
              font: 'fonts/dsb.ttf',
              color: 0xFF000000,
              line_space: 0,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.RIGHT,
              unit_type: 1,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 237,
              y: 57,
              week_en: ["week_0.png","week_1.png","week_2.png","week_3.png","week_4.png","week_5.png","week_6.png"],
              week_tc: ["week_0.png","week_1.png","week_2.png","week_3.png","week_4.png","week_5.png","week_6.png"],
              week_sc: ["week_0.png","week_1.png","week_2.png","week_3.png","week_4.png","week_5.png","week_6.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_calorie_current_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 341,
              y: 256,
              w: 150,
              h: 50,
              text_size: 30,
              char_space: 0,
              font: 'fonts/dsb.ttf',
              color: 0xFFCFD8F7,
              line_space: 0,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 341,
              y: 202,
              w: 150,
              h: 50,
              text_size: 30,
              char_space: 0,
              font: 'fonts/dsb.ttf',
              color: 0xFFCFD8F7,
              line_space: 0,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_day_text_font = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 259,
              y: 114,
              w: 150,
              h: 50,
              text_size: 37,
              char_space: 0,
              font: 'fonts/conthrax_sb.ttf',
              color: 0xFFCFD8F7,
              line_space: 0,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.CENTER_H,
              // padding: true,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 316,
              y: 257,
              src: 'bt_off.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 321,
              y: 232,
              src: 'AL_on.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_alarm_clock_current_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 285,
              y: 232,
              w: 150,
              h: 30,
              text_size: 18,
              char_space: 0,
              font: 'fonts/ArtegraSansExtendedAlt-ExBdIt.ttf',
              color: 0xFF000000,
              line_space: 0,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.CENTER_H,
              padding: true,
              type: hmUI.data_type.ALARM_CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_analog_clock_pro_second_pointer_img = hmUI.createWidget(hmUI.widget.TIME_POINTER_PRO, {
              // src: 'sec_0.png',
              // center_x: 233,
              // center_y: 233,
              // x: 20,
              // y: 231,
              // start_angle: 0,
              // end_angle: 360,
              // type: hmUI.data_type.second,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });


            normal_analog_clock_time_pointer_smooth_second = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              second_path: 'sec_0.png',
              second_centerX: 233,
              second_centerY: 233,
              second_posX: 20,
              second_posY: 231,
              fresh_frequency: 15,
              fresh_freqency: 15,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_analog_clock_pro_smooth_second = hmUI.createWidget(hmUI.widget.SMOOTH_SECOND, {
              // type: 3,
              // fps: 15,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });



            console.log('Watch_Face.ScreenAOD');

            console.log('Watch_Face.Buttons');
            Button_1 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 319,
              y: 316,
              w: 100,
              h: 100,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '0.png',
              normal_src: '0.png',
              click_func: (button_widget) => {
                clik_block();
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_2 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 39,
              y: 316,
              w: 100,
              h: 100,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '0.png',
              normal_src: '0.png',
              click_func: (button_widget) => {
                clik_left();
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            console.log('user_script_end.js');
            // start user_script_end.js

bg_edit_img = hmUI.createWidget(hmUI.widget.IMG, {
 x: 0,
 y: 0,
 src: 'tap/bg_edit.png',
 show_level: hmUI.show_level.ONLY_EDIT,
});

if (screenTypeJS == hmSetting.screen_type.WATCHFACE) {
 groupTap = createTapInterface();

 groupVremya = hmUI.createWidget(hmUI.widget.GROUP, {
  x: 0,
  y: 0,
  w: D_W,
  h: D_H,
 }); //

 btn_tap = groupVremya.createWidget(hmUI.widget.BUTTON, {
  x: 50,
  y: 50,
  text: '',
  w: 100,
  h: 100,
  normal_src: '0_Empty.png',
  press_src: '0_Empty.png',
  click_func: () => {
   vibro();
   tap_run();
  },
  show_level: hmUI.show_level.ONLY_NORMAL,
 });

 btn_str = groupVremya.createWidget(hmUI.widget.BUTTON, {
  x: 183, //x кнопки
  y: 183, //y кнопки
  text: '',
  w: 100, //ширина кнопки
  h: 100, //высота кнопки
  normal_src: '0_Empty.png',
  press_src: '0_Empty.png',
  click_func: () => {
   vibro();
   click_Pogoda_on(weatherProvider);
  },
  show_level: hmUI.show_level.ONLY_NORMAL,
 });


 btn_click_tap_exit = groupTap.createWidget(hmUI.widget.BUTTON, {
  x: 183,
  y: 183,
  text: '',
  w: 100,
  h: 100,
  normal_src: '0_Empty.png',
  press_src: '0_Empty.png',
  click_func: () => {
   vibro();
   tap_zona_exit();
  },
  show_level: hmUI.show_level.ONLY_NORMAL,
 });


 normal_background_Pogoda = hmUI.createWidget(hmUI.widget.FILL_RECT, {
  x: 0,
  y: 0,
  w: D_W,
  h: D_W,
  color: 0x000000,
  show_level: hmUI.show_level.ONLY_NORMAL,
 });
 normal_background_Pogoda.setProperty(hmUI.prop.VISIBLE, false);

 //---------------------------    погода
 groupPogoda = hmUI.createWidget(hmUI.widget.GROUP, {
  x: 0,
  y: 0,
  w: D_W,
  h: D_H,
  show_level: hmUI.show_level.ONLY_NORMAL,
 });

 canvas = groupPogoda.createWidget(hmUI.widget.CANVAS, {
  x: 0,
  y: 0,
  w: D_W,
  h: D_W,
  show_level: hmUI.show_level.ONLY_NORMAL,
 });

 canvas.setPaint({
  color: 0x00ff00,
  line_width: 4
 })

 normal_weather_text_font = groupPogoda.createWidget(hmUI.widget.TEXT, {
  x: 119,
  y: 31,
  w: 228,
  h: 32,
  text_size: 27,
  char_space: 0,
  line_space: 0,
  font: 'fonts/Bebas22.ttf',
  color: 0xFFFFFFFF,
  align_h: hmUI.align.CENTER_H,
  align_v: hmUI.align.CENTER_V,
  text_style: hmUI.text_style.NONE,
  show_level: hmUI.show_level.ONLY_NORMAL,
 })

 normal_temp_text_font = groupPogoda.createWidget(hmUI.widget.TEXT, {
  x: 115,
  y: 2,
  w: 236,
  h: 32,
  text_size: 27,
  char_space: 0,
  line_space: 0,
  font: 'fonts/Bebas22.ttf',
  color: 0xFFFFFFFF,
  align_h: hmUI.align.CENTER_H,
  align_v: hmUI.align.CENTER_V,
  text_style: hmUI.text_style.NONE,
  show_level: hmUI.show_level.ONLY_NORMAL,
 })


 normal_city_name_text_0 = groupPogoda.createWidget(hmUI.widget.TEXT, {
  x: 74,
  y: 60,
  w: 318,
  h: 32,
  text_size: 27,
  char_space: 0,
  line_space: 0,
  font: 'fonts/Bebas22.ttf',
  color: 0xFFFFFFFF,
  align_h: hmUI.align.CENTER_H,
  align_v: hmUI.align.CENTER_V,
  text_style: hmUI.text_style.NONE,
  show_level: hmUI.show_level.ONLY_NORMAL,
 });

 ic_graf_img = groupPogoda.createWidget(hmUI.widget.IMG, {
  x: 414,
  y: 212,
  src: 'images/Grafik/ic_graf_0.png',
  show_level: hmUI.show_level.ONLY_NORMAL,
 });


 windSpeedText = groupPogoda.createWidget(hmUI.widget.TEXT, {
  x: 0,
  y: 399,
  w: D_W,
  h: 40,
  text_size: 35,
  char_space: 0,
  line_space: 0,
  color: 0xFFFFFFFF,
  font: 'fonts/Bebas22.ttf',
  align_h: hmUI.align.CENTER_H,
  align_v: hmUI.align.CENTER_V,
  unit_type: 1,
  text_style: hmUI.text_style.ELLIPSIS,
  // type: hmUI.data_type.WIND,
  show_level: hmUI.show_level.ONLY_NORMAL,
 });

 windSpeedText_zepp = groupPogoda.createWidget(hmUI.widget.TEXT_FONT, {
  x: 0,
  y: 399,
  w: D_W,
  h: 40,
  text_size: 35,
  char_space: 0,
  line_space: 0,
  color: 0xFFFFFFFF,
  font: 'fonts/Bebas22.ttf',
  align_h: hmUI.align.CENTER_H,
  align_v: hmUI.align.CENTER_V,
  unit_type: 1,
  text_style: hmUI.text_style.ELLIPSIS,
  type: hmUI.data_type.WIND,
  show_level: hmUI.show_level.ONLY_NORMAL,
 });

 wind_DIRECTION_Text_zepp = groupPogoda.createWidget(hmUI.widget.TEXT_FONT, {
  x: -60,
  y: 399,
  w: D_W,
  h: 40,
  // text: windDirectionStr[2][hmUI.data_type.WIND_DIRECTION],
  text_size: 35,
  char_space: 0,
  line_space: 0,
  color: 0xFFFFFFFF,
  font: 'fonts/wind-Bold.ttf',
  align_h: hmUI.align.CENTER_H,
  align_v: hmUI.align.CENTER_V,
  unit_type: 1,
  text_style: hmUI.text_style.ELLIPSIS,
  type: hmUI.data_type.WIND_DIRECTION,
  show_level: hmUI.show_level.ONLY_NORMAL,
 });

 update_time_weather = groupPogoda.createWidget(hmUI.widget.TEXT, {
  x: 0,
  y: 420,
  w: D_W,
  h: 40,
  text_size: 27,
  char_space: 0,
  line_space: 0,
  color: 0x9c9a9c,
  font: 'fonts/Bebas22.ttf',
  align_h: hmUI.align.CENTER_H,
  align_v: hmUI.align.CENTER_V,
  unit_type: 1,
  text_style: hmUI.text_style.ELLIPSIS,
  //type: hmUI.data_type.WIND,
  show_level: hmUI.show_level.ONLY_NORMAL,
 });


 normal_temperature_Feels_text_font = groupPogoda.createWidget(hmUI.widget.TEXT, {
  x: 210,
  y: 357,
  w: 150,
  h: 40,
  // text: '100%',
  text_size: 35,
  char_space: 0,
  line_space: 0,
  color: 0xFFFFFFFF,
  font: 'fonts/Bebas22.ttf',
  align_h: hmUI.align.LEFT,
  align_v: hmUI.align.CENTER_V,
  unit_type: 1,
  text_style: hmUI.text_style.ELLIPSIS,
  // type: hmUI.data_type.HUMIDITY,
  show_level: hmUI.show_level.ONLY_NORMAL,
 });

 normal_temperature_Feels_img = groupPogoda.createWidget(hmUI.widget.TEXT, {
  x: 169,
  y: 359,
  w: 50,
  h: 50,
  text_size: 45,
  char_space: 0,
  font: 'fonts/HeadingSmallcaseProicv8-Bold.ttf',
  color: 0xFFFFFFFF,
  line_space: 0,
  align_v: hmUI.align.TOP,
  text_style: hmUI.text_style.ELLIPSIS,
  align_h: hmUI.align.CENTER_H,
  text: '<>=]',
  show_level: hmUI.show_level.ONLY_NORMAL,
 });

 groupPogoda.createWidget(hmUI.widget.IMG, {
  x: 285,
  y: 360,
  src: ROOTPATH + 'Grafik/ic_activ/ic_davl_txt.png',
  show_level: hmUI.show_level.ONLY_NORMAL,
 });

 groupPogoda.createWidget(hmUI.widget.IMG_LEVEL, {
  x: 12,
  y: 166,
  image_array: ["images/Grafik/ic_activ/uv_0.png", "images/Grafik/ic_activ/uv_1.png", "images/Grafik/ic_activ/uv_2.png", "images/Grafik/ic_activ/uv_3.png", "images/Grafik/ic_activ/uv_4.png"],
  image_length: 5,
  type: hmUI.data_type.UVI,
  show_level: hmUI.show_level.ONLY_NORMAL,
 });


 HUMIDITY_LEVEL_zepp = groupPogoda.createWidget(hmUI.widget.IMG_LEVEL, {
  x: 66,
  y: 358,
  image_array: arr_HUMIDITY,
  image_length: 10,
  type: hmUI.data_type.HUMIDITY,
  show_level: hmUI.show_level.ONLY_NORMAL,
 });


 HUMIDITY_LEVEL_prov = groupPogoda.createWidget(hmUI.widget.IMG, {
  x: 66,
  y: 358,
  src: arr_HUMIDITY[0],
  show_level: hmUI.show_level.ONLY_NORMAL,
 });


 groupPogoda.createWidget(hmUI.widget.TEXT_FONT, {
  x: -43,
  y: 265 + 5,
  w: 150,
  h: 30,
  text_size: 27,
  font: 'fonts/Bebas22.ttf',
  char_space: 0,
  line_space: 0,
  color: 0xFFFFFFFF,
  align_h: hmUI.align.CENTER_H,
  align_v: hmUI.align.CENTER_V,
  text_style: hmUI.text_style.ELLIPSIS,
  type: hmUI.data_type.UVI,
  show_level: hmUI.show_level.ONLY_NORMAL,
 });

 groupPogoda.createWidget(hmUI.widget.IMG, {
  x: 420,
  y: 171,
  src: ROOTPATH + 'Grafik/ic_activ/ic_visota.png',
  show_level: hmUI.show_level.ONLY_NORMAL,
 });

 groupPogoda.createWidget(hmUI.widget.TEXT_FONT, {
  x: 359,
  y: 265 + 5,
  w: 150,
  h: 30,
  text_size: 27,
  font: 'fonts/Bebas22.ttf',
  char_space: 0,
  line_space: 0,
  color: 0xFFFFFFFF,
  align_h: hmUI.align.CENTER_H,
  align_v: hmUI.align.CENTER_V,
  text_style: hmUI.text_style.ELLIPSIS,
  type: hmUI.data_type.ALTITUDE,
  show_level: hmUI.show_level.ONLY_NORMAL,
 });

 text_pressere = groupPogoda.createWidget(hmUI.widget.TEXT, {
  x: 347,
  y: 357,
  w: 150,
  h: 40,
  color: 0xffffff,
  font: 'fonts/Bebas22.ttf',
  text_size: 35,
  align_h: hmUI.align.LEFT,
  align_v: hmUI.align.CENTER_V,
  text_style: hmUI.text_style.NONE,
  text: "--",
 });


 HUMIDITY_zepp = groupPogoda.createWidget(hmUI.widget.TEXT_FONT, {
  x: 97,
  y: 357,
  w: 150,
  h: 40,
  text_size: 35,
  char_space: 0,
  line_space: 0,
  color: 0xFFFFFFFF,
  font: 'fonts/Bebas22.ttf',
  align_h: hmUI.align.LEFT,
  align_v: hmUI.align.CENTER_V,
  unit_type: 1,
  text_style: hmUI.text_style.ELLIPSIS,
  type: hmUI.data_type.HUMIDITY,
  show_level: hmUI.show_level.ONLY_NORMAL,
 });

 HUMIDITY_prov = groupPogoda.createWidget(hmUI.widget.TEXT, {
  x: 97,
  y: 357,
  w: 150,
  h: 40,
  text_size: 35,
  char_space: 0,
  line_space: 0,
  color: 0xFFFFFFFF,
  font: 'fonts/Bebas22.ttf',
  align_h: hmUI.align.LEFT,
  align_v: hmUI.align.CENTER_V,
  unit_type: 1,
  text_style: hmUI.text_style.ELLIPSIS,
  // type: hmUI.data_type.HUMIDITY,
  show_level: hmUI.show_level.ONLY_NORMAL,
 });


 for (var i = 0; i < dney; i++) {
  week_text[i] = groupPogoda.createWidget(hmUI.widget.TEXT, {
   x: x0 - 3 - 23 + i * 46 * 1.0, //,107 + i * 45 * 1.02,
   y: 295 - 1 + 2, //- 21
   w: 50,
   h: 50,
   char_space: 0, //-1
   line_space: 0,
   color: "0xFFffffff",
   text: week_array[i],
   text_size: 22,
   text_style: hmUI.text_style.NONE,
   align_h: hmUI.align.CENTER_H,
   align_v: hmUI.align.CENTER_V,
   show_level: hmUI.show_level.ONLY_NORMAL
  });
  // hmUI.deleteWidget(data_text[i]);
  data_text[i] = groupPogoda.createWidget(hmUI.widget.TEXT, {
   x: x0 - 3 - 23 + i * 46 * 1.0, //,107 + i * 45 * 1.02,
   y: 295 - 1 + 2 + 20, //- 21
   w: 50,
   h: 50,

   char_space: 0, //-1
   line_space: 0,
   color: "0xFFffffff",
   text: 31,
   text_size: 22,
   text_style: hmUI.text_style.NONE,
   align_h: hmUI.align.CENTER_H,
   align_v: hmUI.align.CENTER_V,
   show_level: hmUI.show_level.ONLY_NORMAL
  });

  weather_ic[i] = groupPogoda.createWidget(hmUI.widget.IMG, {
   x: x0 - 23 + i * shag,
   y: 78 + 10, //- 10
   w: 40,
   h: 40,
   // src: weatherArray[i],
   shortcut: true,
   show_level: hmUI.show_level.ONLY_NORMAL,
  });

  DigDay[i] = groupPogoda.createWidget(hmUI.widget.TEXT);
  if (i < dney - 1) DigNight[i] = groupPogoda.createWidget(hmUI.widget.TEXT);

 }


 btn_Pogoda_off = groupPogoda.createWidget(hmUI.widget.BUTTON, {
  x: 183, //x кнопки
  y: 183, //y кнопки
  text: '',
  w: 100, //ширина кнопки
  h: 100, //высота кнопки
  normal_src: '0_Empty.png',
  press_src: 'press_100.png',
  click_func: () => {
   vibro(); //имя вызываемой функции
   click_Pogoda_off();
  },
  //           longpress_func: () => {
  //            vibro();
  //			   blok_btn_off();
  //           },
  show_level: hmUI.show_level.ONLY_NORMAL,
 });

 g_ACR_panel = hmUI.createWidget(hmUI.widget.GROUP, {
  x: 0,
  y: 0,
  w: D_W,
  h: D_H,
 })

 //цвет	
 menu_ARC_PROGRES_bg = g_ACR_panel.createWidget(hmUI.widget.ARC_PROGRESS, {
  center_x: 233,
  center_y: 233,
  start_angle: 60 - 15,
  end_angle: 120 + 15,
  radius: 219 + 8,
  line_width: 8,
  corner_flag: 0,
  color: 0xFF5b5b5b,
  level: 100,
  show_level: hmUI.show_level.ONLY_NORMAL,
 });

 menu_ARC_PROGRES = g_ACR_panel.createWidget(hmUI.widget.ARC_PROGRESS, {
  center_x: 233,
  center_y: 233,
  start_angle: 45 + 90 / CONF_MAIN[0].len * (-CONF_MAIN[0].id * 95), // start_angle: 45 + 90 / array * gde,
  end_angle: 135 + 90 / CONF_MAIN[0].len * (-CONF_MAIN[0].id * 95), //end_angle: 135 + 90 / array * gde,
  radius: 219,
  line_width: 16,
  corner_flag: 0,
  color: 0xFF0000, //0xFF007eff
  level: 100 / CONF_MAIN[0].len, //level: pointer,
  show_level: hmUI.show_level.ONLY_NORMAL,
 });
 g_ACR_panel.setProperty(hmUI.prop.VISIBLE, false);


 g_ACR_color_PROGRES = hmUI.createWidget(hmUI.widget.GROUP, {
  x: 0,
  y: 0,
  w: D_W,
  h: D_H,
 })

 for (let i = 0; i < ARC_set.length; i++) {
  menu_ARC_color[i] = g_ACR_color_PROGRES.createWidget(hmUI.widget.CIRCLE, {
   center_x: ARC_set[i][0],
   center_y: ARC_set[i][1],
   radius: ARC_set[i][2] / 2,
   color: color_bg[0][i],
   alpha: 255,
   show_level: hmUI.show_level.ONLY_NORMAL,
  });
 };

 CIRCLE_select = g_ACR_color_PROGRES.createWidget(hmUI.widget.ARC_PROGRESS, {
  center_x: ARC_set[4][0],
  center_y: ARC_set[4][1],
  radius: ARC_set[4][2] / 2 + 6,
  start_angle: 0,
  end_angle: 360,
  line_width: 6,
  corner_flag: 3,
  color: 0xff0000,
  //alpha: 255,
  level: 100,
  show_level: hmUI.show_level.ONLY_NORMAL,
 });

 g_ACR_color_PROGRES.setProperty(hmUI.prop.VISIBLE, false);


 bg_app_text = hmUI.createWidget(hmUI.widget.FILL_RECT, {
  // x: crown == 1 ? 233 - 163 : 233 + 163,
  x: 68 * kf,
  y: (4 + text_start) * kf,
  w: 331 * kf,
  h: Line_arr.length / 2 * 21 + 21 / 2,
  color: 0x000000,
  alpha: 178,
  show_level: hmUI.show_level.ONLY_NORMAL,
 });


 bg_app_text.setProperty(hmUI.prop.VISIBLE, false);

 for (let i = 0; i < Line_arr.length; i++) {
  app_ACR_text[i] = hmUI.createWidget(hmUI.widget.TEXT, {
   x: i < Line_arr.length / 2 ? 68 * kf : D_W / 2,
   y: i < Line_arr.length / 2 ? (text_start + i * 21) * kf : (text_start + (i - Line_arr.length / 2) * 21) * kf,
   w: 166 * kf,
   h: 30 * kf,
   text: Line_arr[i][3],
   text_size: 21,
   char_space: 0,
   line_space: 0,
   //font: 'fonts/Bebas22.ttf',
   color: CONF_MAIN[1].id == i ? 0xff0000 : 0xffffff,
   align_h: hmUI.align.CENTER_H,
   align_v: hmUI.align.CENTER_V,
   text_style: hmUI.text_style.NONE,
   show_level: hmUI.show_level.ONLY_NORMAL,
  });
  app_ACR_text[i].setProperty(hmUI.prop.VISIBLE, false);
 };

 bg_app_text.setProperty(hmUI.prop.VISIBLE, false);


 g_Set = hmUI.createWidget(hmUI.widget.GROUP, {
  x: 0,
  y: 0,
  w: D_W,
  h: D_H,
 })

 normal_background_Set = g_Set.createWidget(hmUI.widget.FILL_RECT, {
  x: 0,
  y: 0,
  w: D_W,
  h: D_H,
  color: 0x000000,
  // radius: 12,
  alpha: 153,
  show_level: hmUI.show_level.ONLY_NORMAL,
 });

 for (let i = 0; i < CONF_MAIN.length; i++) {
  Btn_set_[i] = g_Set.createWidget(hmUI.widget.BUTTON, {
   x: CONF_MAIN.length <= 5 ? 153 : i < Math.ceil(CONF_MAIN.length / 2) ? 70 : D_W / 2,
   y: CONF_MAIN.length <= 5 ? 70 + i * Shag_Y : i < Math.ceil(CONF_MAIN.length / 2) ? 70 + i * Shag_Y : 70 + i * Shag_Y - Shag_Y * Math.ceil(CONF_MAIN.length / 2),
   w: 160,
   h: 60,
   text: CONF_MAIN[i].name,
   char_space: 0,
   line_space: -35,
   color: 0xFFFFFFFF,
   text_size: 24,
   radius: 12,
   press_color: 0xFFFF0000,
   normal_color: i != crown ? 0x000000 : 0x800000,
   click_func: () => {
    vibro();
    click_crown(i);
   },
   text_style: hmUI.text_style.WRAP,
   show_level: hmUI.show_level.ONLY_NORMAL,
  }); // end button
 };

 btn_Set_exit = g_Set.createWidget(hmUI.widget.BUTTON, {
  x: 203, //x кнопки
  y: 70 + Shag_Y * 5, //y кнопки
  w: 60,
  h: 60,
  text: "ОК",
  char_space: 0,
  line_space: -35,
  color: 0xFFFFFFFF,
  text_size: 24,
  radius: 12,
  press_color: 0xFFFF0000,
  normal_color: 0xFF000000,
  click_func: () => {
   vibro();
   click_Set_off();
  },
  text_style: hmUI.text_style.WRAP,
  show_level: hmUI.show_level.ONLY_NORMAL,
 });
 g_Set.setProperty(hmUI.prop.VISIBLE, false);

 btn_crown = groupVremya.createWidget(hmUI.widget.BUTTON, {
  x: 320, //x кнопки
  y: 50, //y кнопки
  text: '',
  w: 100, //ширина кнопки
  h: 100, //высота кнопки
  normal_src: '0_Empty.png',
  press_src: '0_Empty.png',
  click_func: () => {
   // vibro();
   click_Set_on();
  },
  show_level: hmUI.show_level.ONLY_NORMAL,
 });


 g_btn_crown = hmUI.createWidget(hmUI.widget.GROUP, {
  x: 0,
  y: 0,
  w: D_W,
  h: D_H,
 })

 g_btn_crown.createWidget(hmUI.widget.TEXT, {
  x: 14,
  y: 14,
  w: (D_W - 14 * 2),
  h: (D_H - 14 * 2),
  text_size: 33,
  color: 0xffffff,
  text: "←",
  font: 'fonts/Bebas22.ttf',
  align_h: hmUI.align.CENTER_H,
  char_space: 1,
  start_angle: 37 - 90,
  end_angle: 37 + 90,
  show_level: hmUI.show_level.ONLY_NORMAL,
 })

 g_btn_crown.createWidget(hmUI.widget.TEXT, {
  x: 14,
  y: 14,
  w: (D_W - 14 * 2),
  h: (D_H - 14 * 2),
  text_size: 33,
  color: 0xffffff,
  text: "→",
  font: 'fonts/Bebas22.ttf',
  align_h: hmUI.align.CENTER_H,
  char_space: 1,
  start_angle: 143 - 90,
  end_angle: 143 + 90,
  show_level: hmUI.show_level.ONLY_NORMAL,
 })

 normal_background_btn_crown = g_btn_crown.createWidget(hmUI.widget.FILL_RECT, {
  x: 0,
  y: 0,
  w: D_W,
  h: D_H,
  color: 0x000000,
  alpha: 0,
  show_level: hmUI.show_level.ONLY_NORMAL,
 });

 btn_crown_left = g_btn_crown.createWidget(hmUI.widget.BUTTON, {
  x: 305, //x кнопки
  y: 31, //y кнопки
  w: 100,
  h: 100,
  //text: "<<",
  char_space: 0,
  line_space: -35,
  color: 0xFFFFFFFF,
  text_size: 50,
  radius: 12,
  normal_src: '0_Empty.png',
  press_src: '0_Empty.png',
  //         press_color: 0xFFFF0000,
  //         normal_color: 0xFF800000,
  click_func: () => {
   vibro();
   click_btn_crown_left();
  },
  text_style: hmUI.text_style.WRAP,
  show_level: hmUI.show_level.ONLY_NORMAL,
 });

 btn_crown_right = g_btn_crown.createWidget(hmUI.widget.BUTTON, {
  x: 305, //x кнопки
  y: 335, //y кнопки
  w: 100,
  h: 100,
  //text: ">>",
  char_space: 0,
  line_space: -35,
  color: 0xFFFFFFFF,
  text_size: 50,
  radius: 12,
  normal_src: '0_Empty.png',
  press_src: '0_Empty.png',
  //         press_color: 0xFFFF0000,
  //         normal_color: 0xFF800000,
  click_func: () => {
   vibro();
   click_btn_crown_right();
  },
  text_style: hmUI.text_style.WRAP,
  show_level: hmUI.show_level.ONLY_NORMAL,
 });

 btn_crown_exit = g_btn_crown.createWidget(hmUI.widget.BUTTON, {
  x: 203, //x кнопки
  y: 400, //y кнопки
  w: 60,
  h: 60,
  text: "ОК",
  char_space: 0,
  line_space: -35,
  color: 0xFFFFFFFF,
  text_size: 24,
  radius: 12,
  press_color: 0xFFFF0000,
  normal_color: 0xFF800000,
  click_func: () => {
   vibro();
   click_btn_crown_exit();
  },
  text_style: hmUI.text_style.WRAP,
  show_level: hmUI.show_level.ONLY_NORMAL,
 });
 g_btn_crown.setProperty(hmUI.prop.VISIBLE, false);




const weatherProvider = new WeatherProvider({
 pressure_widget: text_pressere, // временный виджет 
 humidity_widget: HUMIDITY_prov,
});

weatherProvider.fetchProviderData(1);
weatherProvider.fetchProviderData(2);


	
	
weatherProviderName = groupPogoda.createWidget(hmUI.widget.IMG, {
 x: 10,
 y: 212,
 w: 42,
 h: 42,
 src: weatherProvider.index == 0 ? 'tap/i_tap_pogoda.png' : weatherProvider.index == 1 ? 'tap/i_tap_wSasha.png' : 'tap/i_tap_RuWeather.png',
 auto_scale: true,
 show_level: hmUI.show_level.ONLY_NORMAL,
});

btn_weather_info = groupPogoda.createWidget(hmUI.widget.BUTTON, {
 x: 332,
 y: 28,
 text: '$',
 color: 0x9c9a9c,
 w: 42,
 h: 42,
 normal_src: '0_Empty.png',
 press_src: 'press_100.png',
 text_size: 27,
 font: 'fonts/Bebas22.ttf',
 click_func: () => {
  vibro(28); //имя вызываемой функции
  hmUI.showToast({
   text: clean_pro
  });
 },
 show_level: hmUI.show_level.ONLY_NORMAL,
});

btn_city_info = groupPogoda.createWidget(hmUI.widget.BUTTON, {
 x: 92,
 y: 28,
 text: '$',
 color: 0x9c9a9c,
 w: 42,
 h: 42,
 normal_src: '0_Empty.png',
 press_src: 'press_100.png',
 text_size: 27,
 font: 'fonts/Bebas22.ttf',
 click_func: () => {
  vibro(28); //имя вызываемой функции
  hmUI.showToast({
   text: city_pro
  });
 },
 show_level: hmUI.show_level.ONLY_NORMAL,
});

btn_tip_grafik = groupPogoda.createWidget(hmUI.widget.BUTTON, {
 x: 366, //x кнопки
 y: 183, //y кнопки
 text: '',
 w: 100, //ширина кнопки
 h: 100, //высота кнопки
 normal_src: '0_Empty.png',
 press_src: 'press_100.png',
 click_func: () => {
  vibro(28); //имя вызываемой функции
  click_tip_grafik(weatherProvider);
 },
 show_level: hmUI.show_level.ONLY_NORMAL,
});



// Обновлённый weatherProvider_Button
weatherProvider_Button = groupPogoda.createWidget(hmUI.widget.BUTTON, {
 x: 0,
 y: 183,
 w: 100,
 h: 100,
 text: '',
 color: 0x000000,
 text_size: 25,
 normal_src: '0_Empty.png',
 press_src: '0_Empty.png',
 click_func: (button_widget) => {
  vibro(28);
  weatherProvider.next(false);
  var forecastData = getCachedForecast(weatherProvider); // ← добавить
  var forecastData = weatherProvider.getForecastData(weatherProvider.providers[weatherProvider.index].appId);

  updateGrafik(forecastData);
  weatherProviderName.setProperty(hmUI.prop.SRC, weatherProvider.index == 0 ? 'tap/i_tap_pogoda.png' : weatherProvider.index == 1 ? 'tap/i_tap_wSasha.png' : 'tap/i_tap_RuWeather.png');
  updateWeatherUI(weatherProvider);
 },
 longpress_func: () => {
  click_Pogoda_off();
  vibro(28);
  appLaunched = (weatherProvider.index == 1 || weatherProvider.index == 2);
  if (weatherProvider.index == 0) hmApp.startApp({
   url: 'WeatherScreen',
   native: true
  });
  else if (weatherProvider.index == 1) hmApp.startApp({
   appid: 1065824,
   url: 'page/index'
  });
  else if (weatherProvider.index == 2) hmApp.startApp({
   appid: 1066654,
   url: 'page/index'
  });
 },
 show_level: hmUI.show_level.ONLY_NORMAL,
});

updateWeatherUI(weatherProvider);



normal_block_FILL_RECT = hmUI.createWidget(hmUI.widget.FILL_RECT, {
 x: 0,
 y: 0,
 w: D_W,
 h: D_W,
 color: 0x000000,
 alpha: 0,
 show_level: hmUI.show_level.ONLY_NORMAL,
});
normal_block_FILL_RECT.setProperty(hmUI.prop.VISIBLE, block == 1);

normal_text_bag = hmUI.createWidget(hmUI.widget.TEXT, {
 x: 100 * kf,
 y: 0,
 w: 266 * kf,
 h: D_W,
 text_size: 27 * kf,
 char_space: 0,
 font: 'fonts/Bebas22.ttf',
 color: 0xFFFFFFFF,
 line_space: 0,
 align_v: hmUI.align.CENTER_V,
 text_style: hmUI.text_style.WRAP,
 align_h: hmUI.align.CENTER_H,
 text: 'ЭТО НЕ БАГ, ЭТО КОСТЫЛЬ, НУЖЕН СВАЙП ИЛИ БЛОК/РАЗБЛОК :)',
 show_level: hmUI.show_level.ONLY_NORMAL,
});
normal_text_bag.setProperty(hmUI.prop.VISIBLE, false);

btn_block = hmUI.createWidget(hmUI.widget.BUTTON, {
 x: 315 * kf,
 y: 333 * kf,
 text: '',
 w: 100 * kf,
 h: 100 * kf,
 normal_src: '0_Empty.png',
 press_src: '0_Empty.png',
 click_func: (button_widget) => {
  //vibro();
  hmUI.showToast({
   text: "Для разблокировки нужно долгое нажатие",
  });
 },
 longpress_func: () => {
  vibro();
  clik_block();
 },
 show_level: hmUI.show_level.ONLY_NORMAL,
});
btn_block.setProperty(hmUI.prop.VISIBLE, block == 1);
normal_widget_text_14.setProperty(hmUI.prop.TEXT, block == 0 ? '{' : '}');

	
}; // end screenType	

 // setTimeout(() => {
   start_WG()
   groupVremya.setProperty(hmUI.prop.VISIBLE, true);
   groupTap.setProperty(hmUI.prop.VISIBLE, false);
   groupPogoda.setProperty(hmUI.prop.VISIBLE, false);
 // }, 300);	  
            // end user_script_end.js

            //#region time_update
            function time_update(updateHour = false, updateMinute = false) {
              console.log('time_update()');
              let hour = timeSensor.hour;
              let minute = timeSensor.minute;
              let second = timeSensor.second;
              let format_hour = timeSensor.format_hour;

              console.log('hour font');
              if (updateHour) {
                let normal_hourStr = format_hour.toString();
                normal_hourStr = normal_hourStr.padStart(2, '0');
                normal_time_hour_text_font.setProperty(hmUI.prop.TEXT, normal_hourStr );
              };

              console.log('minute font');
              if (updateMinute) {
                let normal_minuteStr = minute.toString();
                normal_minuteStr = normal_minuteStr.padStart(2, '0');
                normal_time_minute_text_font.setProperty(hmUI.prop.TEXT, normal_minuteStr );
              };

              console.log('second font');
                let normal_secondStr = second.toString();
                normal_secondStr = normal_secondStr.padStart(2, '0');
                normal_time_second_text_font.setProperty(hmUI.prop.TEXT, normal_secondStr );
              console.log('month font');
              if (updateHour) {
                let normal_Month_Str = normal_Month_Array[timeSensor.month-1];
                normal_month_name_font.setProperty(hmUI.prop.TEXT, normal_Month_Str );
              };

              console.log('day font');
              if (updateHour) {
                let normal_dayStr = timeSensor.day.toString();
                normal_dayStr = normal_dayStr.padStart(2, '0');
                normal_day_text_font.setProperty(hmUI.prop.TEXT, normal_dayStr );
              };

            };

            //#endregion
            //#region text_update
            function text_update() {
              console.log('text_update()');
              // Pressure Font
              let pressureValue = baroSensor.pressure;
              let normal_pressure_font = '-';
              if (pressureValue) normal_pressure_font = Math.round(pressureValue * 0.75006375541921).toString();
              normal_pressure_text_font.setProperty(hmUI.prop.TEXT, normal_pressure_font);

            };

            //#endregion
            function scale_call() {
              console.log('scale_call()');

                console.log('update scales STEP');
                
                let valueStep = step.current;
                let targetStep = step.target;
                let progressStep = valueStep/targetStep;
                if (progressStep > 1) progressStep = 1;
                let progress_ls_normal_step = 1 - progressStep;

                if (screenType != hmSetting.screen_type.AOD) {

                  // normal_step_linear_scale
                  // initial parameters
                  let start_x_normal_step = 259;
                  let start_y_normal_step = 415;
                  let lenght_ls_normal_step = -103;
                  let line_width_ls_normal_step = 10;
                  let color_ls_normal_step = 0xFF000000;
                  
                  // calculated parameters
                  let start_x_normal_step_draw = start_x_normal_step;
                  let start_y_normal_step_draw = start_y_normal_step;
                  lenght_ls_normal_step = lenght_ls_normal_step * progress_ls_normal_step;
                  let lenght_ls_normal_step_draw = lenght_ls_normal_step;
                  let line_width_ls_normal_step_draw = line_width_ls_normal_step;
                  if (lenght_ls_normal_step < 0){
                    lenght_ls_normal_step_draw = -lenght_ls_normal_step;
                    start_x_normal_step_draw = start_x_normal_step - lenght_ls_normal_step_draw;
                  };
                  
                  normal_step_linear_scale.setProperty(hmUI.prop.MORE, {
                    x: start_x_normal_step_draw,
                    y: start_y_normal_step_draw,
                    w: lenght_ls_normal_step_draw,
                    h: line_width_ls_normal_step_draw,
                    color: color_ls_normal_step,
                  });
                };

                console.log('update scales BATTERY');
                
                let valueBattery = battery.current;
                let targetBattery = 100;
                let progressBattery = valueBattery/targetBattery;
                if (progressBattery > 1) progressBattery = 1;
                let progress_cs_normal_battery = 1 - progressBattery;

                if (screenType != hmSetting.screen_type.AOD) {

                  // normal_battery_circle_scale_circle_scale
                  let level = Math.round(progress_cs_normal_battery * 100);
                  if (normal_battery_circle_scale) {
                    normal_battery_circle_scale.setProperty(hmUI.prop.MORE, {                      
                      center_x: 349,
                      center_y: 342,
                      start_angle: 150,
                      end_angle: -152,
                      radius: 38,
                      line_width: 13,
                      corner_flag: 3,
                      color: 0xFF000000,
                      show_level: hmUI.show_level.ONLY_NORMAL,
                      level: level,
                    });
                  };
                };

              console.log('Weather city name');
              let weatherData = weatherSensor.getForecastWeather();
              let normal_cityNameStr = weatherData.cityName;
              normal_cityNameStr = normal_cityNameStr.toUpperCase();
              normal_city_name_text.setProperty(hmUI.prop.TEXT, normal_cityNameStr);

            };

            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                console.log('resume_call()');
                scale_call();
                time_update(true, true);
                text_update();
                if (screenType == hmSetting.screen_type.WATCHFACE) {
                  if (!normal_timerTimeUpdate) {
                    normal_timerTimeUpdate = timer.createTimer(0, 1000, (function (option) {
                      let updateHour = timeSensor.minute == 0 && timeSensor.second < 2;
                      let updateMinute = timeSensor.second < 2;
                      time_update(updateHour, updateMinute);
                    }));  // end timer 
                  };  // end timer check
                };  // end screenType


                console.log('resume_call.js');
                // start resume_call.js


loadSettings();
autoToggleWeatherIcons();

if (screenTypeJS == hmSetting.screen_type.WATCHFACE) {
	
appLaunched ? (appLaunched = false, normal_block_FILL_RECT.setProperty(hmUI.prop.ALPHA, 255), normal_block_FILL_RECT.setProperty(hmUI.prop.VISIBLE, true), normal_text_bag.setProperty(hmUI.prop.VISIBLE, true), blackScreenActive = true) : blackScreenActive && (normal_block_FILL_RECT.setProperty(hmUI.prop.ALPHA, 0), normal_block_FILL_RECT.setProperty(hmUI.prop.VISIBLE, false), normal_text_bag.setProperty(hmUI.prop.VISIBLE, false), blackScreenActive = false);
	
dotTimer = timer.createTimer(0, 143, function() {
    dotIndex = (dotIndex + 1) % dotAlpha.length;
    normal_widget_text_1.setProperty(hmUI.prop.ALPHA, dotAlpha[dotIndex]);
});

}


//updateSleep();
update_app();
//    setTimeout(() => {
//        updatePressureFromProvider(weatherProvider.pressure);
//    }, 150);
//updateGrafik();
click_Pogoda_off();
setTimeout(() => {
 onDigitalCrown();
}, 300);
setTimeout(() => {
 onKeyEvent();
}, 300);

stopVibro();
                // end resume_call.js

              }),
              pause_call: (function () {
                console.log('pause_call()');
                if (normal_timerTimeUpdate) {
                  timer.stopTimer(normal_timerTimeUpdate);
                  normal_timerTimeUpdate = undefined;
                }

                console.log('pause_call.js');
                // start pause_call.js

vibrate.stop();
          hmApp.unregisterSpinEvent();
          offKeyEvent()
          normal_background_Pogoda.setProperty(hmUI.prop.VISIBLE, false);
          groupTap.setProperty(hmUI.prop.VISIBLE, false);
          groupVremya.setProperty(hmUI.prop.VISIBLE, true);
          groupPogoda.setProperty(hmUI.prop.VISIBLE, false);
          timer.stopTimer(dotTimer)

       // stopFireAnimation();
                // end pause_call.js

              }),
            });

                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}