﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.0.1
    ** Copyright © CashaCX75. All Rights Reserved
    */

    try {
    (()=>{
        //dynamic modify start

        


        //dynamic modify end
        const e = __$$hmAppManager$$__.currentApp;
        const o = e.current
          , {px: i} = (new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(e,o)),
        e.__globals__)
          , n = Logger.getLogger("watchface6");
        o.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
			const _0x2368d1=_0x51a3;(function(_0x550318,_0x428484){const _0xe5966b=_0x51a3,_0x20bff6=_0x550318();while(!![]){try{const _0x4807d5=-parseInt(_0xe5966b(0x104))/0x1+parseInt(_0xe5966b(0x11d))/0x2+-parseInt(_0xe5966b(0xe3))/0x3*(-parseInt(_0xe5966b(0x109))/0x4)+parseInt(_0xe5966b(0xd0))/0x5+parseInt(_0xe5966b(0xc8))/0x6+parseInt(_0xe5966b(0x132))/0x7*(-parseInt(_0xe5966b(0xd7))/0x8)+-parseInt(_0xe5966b(0x137))/0x9;if(_0x4807d5===_0x428484)break;else _0x20bff6['push'](_0x20bff6['shift']());}catch(_0x19fe55){_0x20bff6['push'](_0x20bff6['shift']());}}}(_0x10b3,0x32bfa));let normal_background_bg_img='',normal_distance_text_text_img='',normal_battery_text_text_img='',normal_battery_text_separator_img='',normal_battery_image_progress_img_level='',normal_heart_rate_text_text_img='',normal_sun_high_text_img='',normal_sun_high_separator_img='',normal_date_img_date_week_img='',normal_date_img_date_month='',normal_date_img_date_day='',normal_date_day_separator_img='',normal_digital_clock_img_time_AmPm='',normal_digital_clock_img_time='',normal_step_linear_scale='',normal_step_current_text_img='',normal_system_disconnect_img='',normal_system_clock_img='',normal_city_name_text='',normal_temperature_current_text_img='',normal_weather_image_progress_img_level='',normal_frame_animation_1='',normal_frame_animation_2='',idle_background_bg_img='',idle_digital_clock_img_time='',idle_system_disconnect_img='',normal_alarm_jumpable_img_click='',normal_sunrise_jumpable_img_click='',normal_temperature_jumpable_img_click='',normal_heart_jumpable_img_click='',normal_step_jumpable_img_click='',img='',prefix_img=_0x2368d1(0xd8),img_index=0x0,img_count=0x7;function toggleColor(){const _0x55384d=_0x2368d1;img_index=(img_index+0x1)%img_count,hmFS[_0x55384d(0x112)](_0x55384d(0x120),img_index),img[_0x55384d(0xcb)](hmUI[_0x55384d(0xe5)][_0x55384d(0xe6)],prefix_img+img_index+_0x55384d(0x11c));}function _0x51a3(_0x57211c,_0x56e3af){const _0x10b32b=_0x10b3();return _0x51a3=function(_0x51a3ff,_0x141d4c){_0x51a3ff=_0x51a3ff-0xa7;let _0x4ab018=_0x10b32b[_0x51a3ff];return _0x4ab018;},_0x51a3(_0x57211c,_0x56e3af);}function loadSettings(){const _0x399b65=_0x2368d1;hmFS[_0x399b65(0x144)](_0x399b65(0x120))===undefined?(img_index=0x0,hmFS[_0x399b65(0x112)](_0x399b65(0x120),img_index)):img_index=hmFS[_0x399b65(0x144)](_0x399b65(0x120));}normal_background_bg_img=hmUI[_0x2368d1(0xc0)](hmUI['widget'][_0x2368d1(0x126)],{'x':0x0,'y':0x0,'w':0x1d2,'h':0x1d2,'src':_0x2368d1(0x117),'show_level':hmUI[_0x2368d1(0x105)]['ONLY_NORMAL']}),normal_distance_text_text_img=hmUI[_0x2368d1(0xc0)](hmUI[_0x2368d1(0x11b)][_0x2368d1(0xc3)],{'x':0xfd,'y':0x93,'font_array':[_0x2368d1(0x12f),'S_numbs_steps_01.png','S_numbs_steps_02.png',_0x2368d1(0xe1),'S_numbs_steps_04.png',_0x2368d1(0x122),_0x2368d1(0x102),'S_numbs_steps_07.png',_0x2368d1(0xfc),'S_numbs_steps_09.png'],'padding':![],'h_space':0x0,'unit_sc':'icon_KM.png','unit_tc':_0x2368d1(0xef),'unit_en':_0x2368d1(0xef),'imperial_unit_sc':'icon_ML.png','imperial_unit_tc':_0x2368d1(0x10f),'imperial_unit_en':_0x2368d1(0x10f),'dot_image':_0x2368d1(0xac),'align_h':hmUI[_0x2368d1(0x133)]['RIGHT'],'type':hmUI['data_type'][_0x2368d1(0xf0)],'show_level':hmUI[_0x2368d1(0x105)][_0x2368d1(0x115)]}),normal_battery_text_text_img=hmUI['createWidget'](hmUI[_0x2368d1(0x11b)][_0x2368d1(0xc3)],{'x':0x140,'y':0x75,'font_array':[_0x2368d1(0x12f),_0x2368d1(0x129),_0x2368d1(0x113),_0x2368d1(0xe1),'S_numbs_steps_04.png',_0x2368d1(0x122),_0x2368d1(0x102),_0x2368d1(0xf5),'S_numbs_steps_08.png',_0x2368d1(0xf7)],'padding':!![],'h_space':0x0,'align_h':hmUI[_0x2368d1(0x133)]['RIGHT'],'type':hmUI[_0x2368d1(0xb3)][_0x2368d1(0x114)],'show_level':hmUI[_0x2368d1(0x105)][_0x2368d1(0x115)]}),normal_battery_text_separator_img=hmUI[_0x2368d1(0xc0)](hmUI[_0x2368d1(0x11b)][_0x2368d1(0x126)],{'x':0x172,'y':0x7a,'src':_0x2368d1(0xc2),'show_level':hmUI['show_level'][_0x2368d1(0x115)]}),normal_battery_image_progress_img_level=hmUI[_0x2368d1(0xc0)](hmUI[_0x2368d1(0x11b)][_0x2368d1(0x13e)],{'x':0x158,'y':0x57,'image_array':[_0x2368d1(0xdf),_0x2368d1(0x124),_0x2368d1(0xbd),_0x2368d1(0x145),_0x2368d1(0xad),_0x2368d1(0x136),_0x2368d1(0xb7),'battery_7.png',_0x2368d1(0xc9),_0x2368d1(0xe7),_0x2368d1(0xab),'battery_11.png',_0x2368d1(0x123),_0x2368d1(0xb8),_0x2368d1(0x134),_0x2368d1(0x130),_0x2368d1(0xfb),'battery_17.png'],'image_length':0x12,'type':hmUI['data_type'][_0x2368d1(0x114)],'show_level':hmUI[_0x2368d1(0x105)]['ONLY_NORMAL']}),normal_heart_rate_text_text_img=hmUI[_0x2368d1(0xc0)](hmUI[_0x2368d1(0x11b)]['TEXT_IMG'],{'x':0xfa,'y':0x75,'font_array':[_0x2368d1(0x12f),_0x2368d1(0x129),_0x2368d1(0x113),_0x2368d1(0xe1),_0x2368d1(0x10c),_0x2368d1(0x122),_0x2368d1(0x102),_0x2368d1(0xf5),_0x2368d1(0xfc),'S_numbs_steps_09.png'],'padding':!![],'h_space':0x0,'align_h':hmUI[_0x2368d1(0x133)][_0x2368d1(0x101)],'type':hmUI[_0x2368d1(0xb3)][_0x2368d1(0x11a)],'show_level':hmUI[_0x2368d1(0x105)][_0x2368d1(0x115)]}),normal_sun_high_text_img=hmUI[_0x2368d1(0xc0)](hmUI['widget'][_0x2368d1(0xc3)],{'x':0x84,'y':0xe5,'font_array':['S_numbers_00.png',_0x2368d1(0x12a),_0x2368d1(0x108),_0x2368d1(0xd5),_0x2368d1(0xd3),_0x2368d1(0x125),_0x2368d1(0xf4),_0x2368d1(0x106),_0x2368d1(0xb0),_0x2368d1(0xbc)],'padding':![],'h_space':-0x1,'dot_image':_0x2368d1(0xf1),'align_h':hmUI['align'][_0x2368d1(0x101)],'type':hmUI[_0x2368d1(0xb3)]['SUN_RISE'],'show_level':hmUI[_0x2368d1(0x105)][_0x2368d1(0x115)]}),normal_sun_high_separator_img=hmUI[_0x2368d1(0xc0)](hmUI['widget']['IMG'],{'x':0xd6,'y':0xe0,'src':_0x2368d1(0xeb),'show_level':hmUI[_0x2368d1(0x105)][_0x2368d1(0x115)]}),normal_date_img_date_week_img=hmUI[_0x2368d1(0xc0)](hmUI['widget']['IMG_WEEK'],{'x':0x116,'y':0xe3,'week_en':[_0x2368d1(0xdc),_0x2368d1(0x13d),_0x2368d1(0x103),'weekdays_04.png','weekdays_05.png',_0x2368d1(0x121),'weekdays_07.png'],'week_tc':[_0x2368d1(0xdc),_0x2368d1(0x13d),_0x2368d1(0x103),_0x2368d1(0xf9),_0x2368d1(0xa8),_0x2368d1(0x121),_0x2368d1(0xb5)],'week_sc':['weekdays_01.png',_0x2368d1(0x13d),_0x2368d1(0x103),'weekdays_04.png','weekdays_05.png',_0x2368d1(0x121),_0x2368d1(0xb5)],'show_level':hmUI['show_level']['ONLY_NORMAL']}),normal_date_img_date_month=hmUI[_0x2368d1(0xc0)](hmUI[_0x2368d1(0x11b)][_0x2368d1(0x110)],{'month_startX':0x181,'month_startY':0xe4,'month_sc_array':[_0x2368d1(0xba),_0x2368d1(0x12a),_0x2368d1(0x108),_0x2368d1(0xd5),_0x2368d1(0xd3),'S_numbers_05.png',_0x2368d1(0xf4),_0x2368d1(0x106),_0x2368d1(0xb0),_0x2368d1(0xbc)],'month_tc_array':[_0x2368d1(0xba),'S_numbers_01.png',_0x2368d1(0x108),_0x2368d1(0xd5),'S_numbers_04.png',_0x2368d1(0x125),_0x2368d1(0xf4),_0x2368d1(0x106),'S_numbers_08.png','S_numbers_09.png'],'month_en_array':[_0x2368d1(0xba),_0x2368d1(0x12a),_0x2368d1(0x108),'S_numbers_03.png','S_numbers_04.png','S_numbers_05.png',_0x2368d1(0xf4),'S_numbers_07.png',_0x2368d1(0xb0),_0x2368d1(0xbc)],'month_zero':0x1,'month_space':-0x1,'month_align':hmUI[_0x2368d1(0x133)][_0x2368d1(0x10b)],'month_is_character':![],'show_level':hmUI['show_level'][_0x2368d1(0x115)]}),normal_date_img_date_day=hmUI['createWidget'](hmUI[_0x2368d1(0x11b)][_0x2368d1(0x110)],{'day_startX':0x15a,'day_startY':0xe4,'day_sc_array':[_0x2368d1(0xba),'S_numbers_01.png',_0x2368d1(0x108),_0x2368d1(0xd5),_0x2368d1(0xd3),'S_numbers_05.png',_0x2368d1(0xf4),_0x2368d1(0x106),'S_numbers_08.png',_0x2368d1(0xbc)],'day_tc_array':[_0x2368d1(0xba),_0x2368d1(0x12a),_0x2368d1(0x108),_0x2368d1(0xd5),_0x2368d1(0xd3),_0x2368d1(0x125),_0x2368d1(0xf4),'S_numbers_07.png',_0x2368d1(0xb0),_0x2368d1(0xbc)],'day_en_array':['S_numbers_00.png',_0x2368d1(0x12a),_0x2368d1(0x108),'S_numbers_03.png',_0x2368d1(0xd3),_0x2368d1(0x125),'S_numbers_06.png',_0x2368d1(0x106),_0x2368d1(0xb0),_0x2368d1(0xbc)],'day_zero':0x1,'day_space':-0x1,'day_align':hmUI[_0x2368d1(0x133)][_0x2368d1(0x10b)],'day_is_character':![],'show_level':hmUI[_0x2368d1(0x105)][_0x2368d1(0x115)]}),normal_date_day_separator_img=hmUI['createWidget'](hmUI[_0x2368d1(0x11b)][_0x2368d1(0x126)],{'x':0x17c,'y':0xe4,'src':_0x2368d1(0xed),'show_level':hmUI[_0x2368d1(0x105)][_0x2368d1(0x115)]}),normal_digital_clock_img_time_AmPm=hmUI[_0x2368d1(0xc0)](hmUI[_0x2368d1(0x11b)][_0x2368d1(0xd2)],{'am_x':0x2b,'am_y':0xe8,'am_sc_path':_0x2368d1(0x140),'am_en_path':'AM.png','pm_x':0x2b,'pm_y':0xe8,'pm_sc_path':'PM.png','pm_en_path':_0x2368d1(0xfa),'show_level':hmUI[_0x2368d1(0x105)][_0x2368d1(0x115)]}),normal_digital_clock_img_time=hmUI[_0x2368d1(0xc0)](hmUI['widget']['IMG_TIME'],{'hour_startX':0x4d,'hour_startY':0x109,'hour_array':[_0x2368d1(0xaa),_0x2368d1(0xd9),_0x2368d1(0x12d),_0x2368d1(0x131),_0x2368d1(0x12b),'B_numbers_05.png',_0x2368d1(0xc5),_0x2368d1(0xe9),_0x2368d1(0x135),_0x2368d1(0xcf)],'hour_zero':0x1,'hour_space':-0x22,'hour_align':hmUI[_0x2368d1(0x133)]['LEFT'],'minute_startX':0xd7,'minute_startY':0x109,'minute_array':[_0x2368d1(0xaa),_0x2368d1(0xd9),_0x2368d1(0x12d),_0x2368d1(0x131),_0x2368d1(0x12b),_0x2368d1(0xc7),'B_numbers_06.png','B_numbers_07.png',_0x2368d1(0x135),_0x2368d1(0xcf)],'minute_zero':0x1,'minute_space':-0x22,'minute_follow':0x0,'minute_align':hmUI[_0x2368d1(0x133)][_0x2368d1(0x10b)],'second_startX':0x160,'second_startY':0x10e,'second_array':[_0x2368d1(0xe0),_0x2368d1(0xbb),_0x2368d1(0xc4),'L_numbers_03.png',_0x2368d1(0xca),_0x2368d1(0xd4),_0x2368d1(0x111),_0x2368d1(0xf8),_0x2368d1(0xb1),_0x2368d1(0xf3)],'second_zero':0x1,'second_space':-0xa,'second_follow':0x0,'second_align':hmUI['align'][_0x2368d1(0x10b)],'show_level':hmUI['show_level'][_0x2368d1(0x115)]});let screenType=hmSetting[_0x2368d1(0x118)]();screenType!=hmSetting[_0x2368d1(0x10a)][_0x2368d1(0xc1)]&&(normal_step_linear_scale=hmUI['createWidget'](hmUI['widget'][_0x2368d1(0xbf)]));;const step=hmSensor['createSensor'](hmSensor['id'][_0x2368d1(0xb6)]);step['addEventListener'](hmSensor[_0x2368d1(0xf2)][_0x2368d1(0xdd)],function(){scale_call();}),normal_step_current_text_img=hmUI[_0x2368d1(0xc0)](hmUI[_0x2368d1(0x11b)][_0x2368d1(0xc3)],{'x':0x72,'y':0x5b,'font_array':[_0x2368d1(0x12f),_0x2368d1(0x129),_0x2368d1(0x113),'S_numbs_steps_03.png',_0x2368d1(0x10c),_0x2368d1(0x122),_0x2368d1(0x102),_0x2368d1(0xf5),_0x2368d1(0xfc),_0x2368d1(0xf7)],'padding':![],'h_space':0x0,'align_h':hmUI[_0x2368d1(0x133)][_0x2368d1(0x10b)],'type':hmUI['data_type'][_0x2368d1(0xb6)],'show_level':hmUI[_0x2368d1(0x105)][_0x2368d1(0x115)]}),img=hmUI['createWidget'](hmUI['widget']['IMG'],{'x':0x0,'y':0x0,'src':prefix_img+parseInt(img_index)+_0x2368d1(0x11c),'show_level':hmUI[_0x2368d1(0x105)]['ONLY_NORMAL']}),normal_system_disconnect_img=hmUI[_0x2368d1(0xc0)](hmUI[_0x2368d1(0x11b)][_0x2368d1(0xff)],{'x':0xa0,'y':0x18c,'src':'bluetooth_OFF.png','type':hmUI['system_status'][_0x2368d1(0x142)],'show_level':hmUI[_0x2368d1(0x105)]['ONLY_NORMAL']}),normal_system_clock_img=hmUI['createWidget'](hmUI['widget']['IMG_STATUS'],{'x':0x3b,'y':0x128,'src':_0x2368d1(0xdb),'type':hmUI['system_status'][_0x2368d1(0x13b)],'show_level':hmUI['show_level']['ONLY_NORMAL']}),normal_city_name_text=hmUI[_0x2368d1(0xc0)](hmUI[_0x2368d1(0x11b)][_0x2368d1(0xa7)],{'x':0x102,'y':0xb7,'w':0xc8,'h':0x1e,'text_size':0x14,'char_space':0x0,'line_space':0x0,'color':0xffcdcdcd,'align_h':hmUI[_0x2368d1(0x133)]['LEFT'],'align_v':hmUI[_0x2368d1(0x133)][_0x2368d1(0x127)],'text_style':hmUI[_0x2368d1(0xde)][_0x2368d1(0xd1)],'show_level':hmUI['show_level'][_0x2368d1(0x115)]}),normal_temperature_current_text_img=hmUI['createWidget'](hmUI[_0x2368d1(0x11b)][_0x2368d1(0xc3)],{'x':0x6d,'y':0xa9,'font_array':[_0x2368d1(0xbe),_0x2368d1(0xc6),_0x2368d1(0x11f),_0x2368d1(0xe2),_0x2368d1(0x13a),_0x2368d1(0xea),_0x2368d1(0x13f),_0x2368d1(0x138),'weather_numbers_08.png',_0x2368d1(0x11e)],'padding':![],'h_space':-0x2,'unit_sc':_0x2368d1(0xe8),'unit_tc':_0x2368d1(0xe8),'unit_en':_0x2368d1(0xe8),'negative_image':_0x2368d1(0xcd),'align_h':hmUI[_0x2368d1(0x133)]['CENTER_H'],'type':hmUI[_0x2368d1(0xb3)]['WEATHER_CURRENT'],'show_level':hmUI[_0x2368d1(0x105)][_0x2368d1(0x115)]}),normal_weather_image_progress_img_level=hmUI[_0x2368d1(0xc0)](hmUI[_0x2368d1(0x11b)]['IMG_LEVEL'],{'x':0x3d,'y':0x9c,'image_array':[_0x2368d1(0xee),_0x2368d1(0xe4),_0x2368d1(0xcc),'4.png',_0x2368d1(0xb4),_0x2368d1(0xaf),_0x2368d1(0x10d),_0x2368d1(0xae),'9.png','10.png',_0x2368d1(0xda),'12.png',_0x2368d1(0xd6),_0x2368d1(0x12e),'15.png',_0x2368d1(0x107),'17.png',_0x2368d1(0x100),_0x2368d1(0x13c),_0x2368d1(0x12c),_0x2368d1(0x10e),_0x2368d1(0x116),_0x2368d1(0x146),_0x2368d1(0xce),_0x2368d1(0x128),'26.png','27.png','28.png','29.png'],'image_length':0x1d,'type':hmUI[_0x2368d1(0xb3)][_0x2368d1(0xb2)],'show_level':hmUI[_0x2368d1(0x105)][_0x2368d1(0x115)]}),normal_frame_animation_1=hmUI[_0x2368d1(0xc0)](hmUI['widget'][_0x2368d1(0xfe)],{'x':0xe3,'y':0xbd,'anim_path':_0x2368d1(0x119),'anim_ext':_0x2368d1(0xfd),'anim_prefix':_0x2368d1(0x139),'anim_fps':0x1e,'anim_size':0x1c,'repeat_count':0x0,'anim_repeat':!![],'anim_status':hmUI[_0x2368d1(0xb9)][_0x2368d1(0x143)],'show_level':hmUI[_0x2368d1(0x105)][_0x2368d1(0x115)]}),normal_frame_animation_2=hmUI[_0x2368d1(0xc0)](hmUI['widget'][_0x2368d1(0xfe)],{'x':0x109,'y':0x57,'anim_path':_0x2368d1(0x119),'anim_ext':_0x2368d1(0xfd),'anim_prefix':'hr','anim_fps':0x22,'anim_size':0x18,'repeat_count':0x0,'anim_repeat':!![],'anim_status':hmUI[_0x2368d1(0xb9)][_0x2368d1(0x143)],'show_level':hmUI[_0x2368d1(0x105)][_0x2368d1(0x115)]}),hmUI[_0x2368d1(0xc0)](hmUI['widget'][_0x2368d1(0xec)],{'x':0x1a6,'y':0xb6,'text':'','w':0x64,'h':0x64,'normal_src':'click_e.png','press_src':_0x2368d1(0xa9),'show_level':hmUI['show_level'][_0x2368d1(0x115)],'click_func':()=>{toggleColor();}}),hmUI[_0x2368d1(0xc0)](hmUI['widget']['BUTTON'],{'x':0x112,'y':0xde,'text':'','w':0x91,'h':0x23,'normal_src':_0x2368d1(0xa9),'press_src':_0x2368d1(0xa9),'click_func':()=>{const _0x2a84b7=_0x2368d1;hmApp[_0x2a84b7(0x141)]({'url':_0x2a84b7(0xf6),'native':!![]});},'show_level':hmUI['show_level'][_0x2368d1(0x115)]});function _0x10b3(){const _0x3cf9c9=['battery_14.png','B_numbers_08.png','battery_5.png','5473332EbEdEu','weather_numbers_07.png','geo','weather_numbers_04.png','CLOCK','19.png','weekdays_02.png','IMG_LEVEL','weather_numbers_06.png','AM.png','startApp','DISCONNECT','START','SysProGetInt','battery_3.png','23.png','TEXT','weekdays_05.png','click_e.png','B_numbers_00.png','battery_10.png','icon_dot.png','battery_4.png','8.png','6.png','S_numbers_08.png','L_numbers_08.png','WEATHER_CURRENT','data_type','5.png','weekdays_07.png','STEP','battery_6.png','battery_13.png','anim_status','S_numbers_00.png','L_numbers_01.png','S_numbers_09.png','battery_2.png','weather_numbers_00.png','FILL_RECT','createWidget','AOD','battery_percent.png','TEXT_IMG','L_numbers_02.png','B_numbers_06.png','weather_numbers_01.png','B_numbers_05.png','1789950Vuewaq','battery_8.png','L_numbers_04.png','setProperty','3.png','weather_numbers_minus.png','24.png','B_numbers_09.png','1135390RmBkoX','NONE','IMG_TIME','S_numbers_04.png','L_numbers_05.png','S_numbers_03.png','13.png','104VCnDOT','bg_','B_numbers_01.png','11.png','ALARM.png','weekdays_01.png','CHANGE','text_style','battery_0.png','L_numbers_00.png','S_numbs_steps_03.png','weather_numbers_03.png','66MLtxQS','2.png','prop','SRC','battery_9.png','weather_numbers_celcius.png','B_numbers_07.png','weather_numbers_05.png','AM_2.png','BUTTON','dot.png','1.png','icon_KM.png','DISTANCE','dot_2.png','event','L_numbers_09.png','S_numbers_06.png','S_numbs_steps_07.png','ScheduleCalScreen','S_numbs_steps_09.png','L_numbers_07.png','weekdays_04.png','PM.png','battery_16.png','S_numbs_steps_08.png','png','IMG_ANIM','IMG_STATUS','18.png','RIGHT','S_numbs_steps_06.png','weekdays_03.png','58855wAhSBG','show_level','S_numbers_07.png','16.png','S_numbers_02.png','59216qnyevJ','screen_type','LEFT','S_numbs_steps_04.png','7.png','21.png','icon_ML.png','IMG_DATE','L_numbers_06.png','SysProSetInt','S_numbs_steps_02.png','BATTERY','ONLY_NORMAL','22.png','Main1_ver2.png','getScreenType','animation','HEART','widget','.png','274016dxPNYx','weather_numbers_09.png','weather_numbers_02.png','COLOR','weekdays_06.png','S_numbs_steps_05.png','battery_12.png','battery_1.png','S_numbers_05.png','IMG','CENTER_V','25.png','S_numbs_steps_01.png','S_numbers_01.png','B_numbers_04.png','20.png','B_numbers_02.png','14.png','S_numbs_steps_00.png','battery_15.png','B_numbers_03.png','60970hYVPYz','align'];_0x10b3=function(){return _0x3cf9c9;};return _0x10b3();}                


            idle_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 466,
              h: 466,
              src: 'Main1_ver2_CROP_AOD.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 77,
              hour_startY: 265,
              hour_array: ["AOD_B_numbers_00.png","AOD_B_numbers_01.png","AOD_B_numbers_02.png","AOD_B_numbers_03.png","AOD_B_numbers_04.png","AOD_B_numbers_05.png","AOD_B_numbers_06.png","AOD_B_numbers_07.png","AOD_B_numbers_08.png","AOD_B_numbers_09.png"],
              hour_zero: 1,
              hour_space: -34,
              hour_align: hmUI.align.LEFT,

              minute_startX: 215,
              minute_startY: 265,
              minute_array: ["AOD_B_numbers_00.png","AOD_B_numbers_01.png","AOD_B_numbers_02.png","AOD_B_numbers_03.png","AOD_B_numbers_04.png","AOD_B_numbers_05.png","AOD_B_numbers_06.png","AOD_B_numbers_07.png","AOD_B_numbers_08.png","AOD_B_numbers_09.png"],
              minute_zero: 1,
              minute_space: -34,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 206,
              y: 387,
              src: 'bluetooth.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_AOD,
            });
            
            // disconnectAlert = hmUI.createWidget(hmUI.widget.DisconnectAlert, {
              // disconneсnt_vibrate_type: 9,
              // conneсnt_vibrate_type: 9,
              // conneсnt_toast_text: CONNECTION RESTORED,
            // });

            // vibration when connecting or disconnecting

            function checkConnection() {
              hmBle.removeListener;
              hmBle.addListener(function (status) {
                if(!status) {
                  vibro(9);
                }
                if(status) {
                  hmUI.showToast({text: "CONNECTION RESTORED"});
                  vibro(9);
                }
              });
            }

            // end vibration when connecting or disconnecting
            // vibrate function

            const vibrate = hmSensor.createSensor(hmSensor.id.VIBRATE);
            let timer_StopVibrate = null;


            function vibro(scene = 25) {
              let stopDelay = 50;
              stopVibro();
              vibrate.stop();
              vibrate.scene = scene;
              if(scene < 23 || scene > 25) stopDelay = 1300;
              vibrate.start();
              timer_StopVibrate = timer.createTimer(stopDelay, 3000, stopVibro, {});
            }

            function stopVibro(){
              vibrate.stop();
              if(timer_StopVibrate) timer.stopTimer(timer_StopVibrate);
            }

            // end vibrate function

            normal_alarm_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 0,
              y: 188,
              w: 44,
              h: 91,
              src: 'click_e.png',
              type: hmUI.data_type.ALARM_CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sunrise_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 106,
              y: 223,
              w: 161,
              h: 33,
              src: 'click_e.png',
              type: hmUI.data_type.SUN_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 61,
              y: 142,
              w: 123,
              h: 76,
              src: 'click_e.png',
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 221,
              y: 77,
              w: 89,
              h: 64,
              src: 'click_e.png',
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 83,
              y: 77,
              w: 105,
              h: 62,
              src: 'click_e.png',
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            function scale_call() {

                console.log('update scales STEP');
                
                let valueStep = step.current;
                let targetStep = step.target;
                let progressStep = valueStep/targetStep;
                if (progressStep > 1) progressStep = 1;
                let progress_ls_normal_step = progressStep;

                if (screenType != hmSetting.screen_type.AOD) {

                  // normal_step_linear_scale
                  // initial parameters
                  let start_x_normal_step = 69;
                  let start_y_normal_step = 124;
                  let lenght_ls_normal_step = 71;
                  let line_width_ls_normal_step = 6;
                  let color_ls_normal_step = 0xFF000000;
                  
                  // calculated parameters
                  let start_x_normal_step_draw = start_x_normal_step;
                  let start_y_normal_step_draw = start_y_normal_step;
                  lenght_ls_normal_step = lenght_ls_normal_step * progress_ls_normal_step;
                  let lenght_ls_normal_step_draw = lenght_ls_normal_step;
                  let line_width_ls_normal_step_draw = line_width_ls_normal_step;
                  if (lenght_ls_normal_step < 0){
                    lenght_ls_normal_step_draw = -lenght_ls_normal_step;
                    start_x_normal_step_draw = start_x_normal_step - lenght_ls_normal_step_draw;
                  };
                  
                  normal_step_linear_scale.setProperty(hmUI.prop.MORE, {
                    x: start_x_normal_step_draw,
                    y: start_y_normal_step_draw,
                    w: lenght_ls_normal_step_draw,
                    h: line_width_ls_normal_step_draw,
                    color: color_ls_normal_step,
                  });
                };

              console.log('Weather city name');
              const weatherSensor = hmSensor.createSensor(hmSensor.id.WEATHER);
              const weatherData = weatherSensor.getForecastWeather();
              normal_city_name_text.setProperty(hmUI.prop.TEXT, weatherData.cityName);

            };

            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                scale_call();
                normal_frame_animation_1.setProperty(hmUI.prop.ANIM_STATUS,hmUI.anim_status.START);
                normal_frame_animation_2.setProperty(hmUI.prop.ANIM_STATUS,hmUI.anim_status.START);
                checkConnection();
                stopVibro();

              }),
              pause_call: (function () {
                normal_frame_animation_1.setProperty(hmUI.prop.ANIM_STATUS,hmUI.anim_status.STOP);
                normal_frame_animation_2.setProperty(hmUI.prop.ANIM_STATUS,hmUI.anim_status.STOP);
                stopVibro();

              }),
            });

                //dynamic modify end
            },
            onInit() {
                n.log("index page.js on init invoke")
            },
            build() {
                this.init_view(),
                n.log("index page.js on ready invoke")
            },
            onDestroy() {
                n.log("index page.js on destroy invoke")
            }
        })
    }
    )()
} catch (e) {
    console.log("Mini Program Error", e),
    e && e.stack && e.stack.split(/\n/).forEach((e=>console.log("error stack", e)))
}
