﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        //const logger = Logger.getLogger('watchface_SashaCX75');
        const logger = DeviceRuntimeCore.HmLogger.getLogger('watchface_SashaCX75')
        //end of ignored block

        //dynamic modify start

        
        let editBg = ''
        let normal_date_img_date_month_img = ''
        let normal_moon_image_progress_img_level = ''
        let normal_system_disconnect_img = ''
        let normal_system_clock_img = ''
        let normal_heart_rate_text_text_img = ''
        let normal_heart_rate_image_progress_img_level = ''
        let normal_battery_text_text_img = ''
        let normal_battery_image_progress_img_level = ''
        let normal_battery_pointer_progress_img_pointer = ''
        let normal_pai_weekly_text_img = ''
        let normal_pai_image_progress_img_level = ''
        let normal_frame_animation_1 = ''
        let normal_frame_animation_2 = ''
        let normal_distance_text_text_img = ''
        let normal_step_current_text_img = ''
        let normal_step_image_progress_img_level = ''
        let normal_step_pointer_progress_img_pointer = ''
        let normal_week_pointer_progress_date_pointer = ''
        let normal_day_pointer_progress_date_pointer = ''
        let idle_background_bg_img = ''
        let editableTimePointers = ''
        let normal_stopwatch_jumpable_img_click = ''
        let normal_alarm_jumpable_img_click = ''
        let normal_temperature_jumpable_img_click = ''
        let normal_pai_jumpable_img_click = ''
        let normal_heart_jumpable_img_click = ''
        let normal_step_jumpable_img_click = ''


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            console.log('Watch_Face.ScreenNormal');
            editBg = hmUI.createWidget(hmUI.widget.WATCHFACE_EDIT_BG, {
              edit_id: 1002,
              x: 0,
              y: 0,
              // w: 466,
              // h: 466,
              // AOD_show: False,
              bg_config: [
                { id: 1, preview: 'bg_edit_1_preview.png', path: 'base_1.png' },
                { id: 2, preview: 'bg_edit_2_preview.png', path: 'base_2.png' },
                { id: 3, preview: 'bg_edit_3_preview.png', path: 'base_3.png' },
                { id: 4, preview: 'bg_edit_4_preview.png', path: 'base_4.png' },
                { id: 5, preview: 'bg_edit_5_preview.png', path: 'base_5.png' },
                { id: 6, preview: 'bg_edit_6_preview.png', path: 'base_6.png' },
                { id: 7, preview: 'bg_edit_7_preview.png', path: 'base_7.png' },
              ],
              count: 7,
              default_id: 1,
              fg: '.png',
              tips_bg: 'bg-mde.png',
              tips_x: 108,
              tips_y: 74,
              show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_EDIT,
            });

            normal_date_img_date_month_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 214,
              month_startY: 365,
              month_sc_array: ["mo-01.png","mo-02.png","mo-03.png","mo-04.png","mo-05.png","mo-06.png","mo-07.png","mo-08.png","mo-09.png","mo-10.png","mo-11.png","mo-12.png"],
              month_tc_array: ["mo-01.png","mo-02.png","mo-03.png","mo-04.png","mo-05.png","mo-06.png","mo-07.png","mo-08.png","mo-09.png","mo-10.png","mo-11.png","mo-12.png"],
              month_en_array: ["mo-01.png","mo-02.png","mo-03.png","mo-04.png","mo-05.png","mo-06.png","mo-07.png","mo-08.png","mo-09.png","mo-10.png","mo-11.png","mo-12.png"],
              month_is_character: true ,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_moon_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 184,
              y: 299,
              image_array: ["mp_01.png","mp_02.png","mp_03.png","mp_04.png","mp_05.png","mp_06.png","mp_07.png","mp_08.png","mp_09.png","mp_10.png","mp_11.png","mp_12.png","mp_13.png","mp_14.png","mp_15.png","mp_16.png","mp_17.png","mp_18.png","mp_19.png","mp_20.png","mp_21.png","mp_22.png","mp_23.png","mp_24.png","mp_25.png","mp_26.png","mp_27.png","mp_28.png","mp_29.png","mp_30.png"],
              image_length: 30,
              type: hmUI.data_type.MOON,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 360,
              y: 358,
              src: 'bluetooth.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 89,
              y: 360,
              src: 'alarm.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 98,
              y: 250,
              font_array: ["n_0.png","n_1.png","n_2.png","n_3.png","n_4.png","n_5.png","n_6.png","n_7.png","n_8.png","n_9.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 81,
              y: 253,
              image_array: ["hr_01.png","hr_02.png","hr_03.png","hr_04.png","hr_05.png","hr_06.png"],
              image_length: 6,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 95,
              y: 202,
              font_array: ["n_0.png","n_1.png","n_2.png","n_3.png","n_4.png","n_5.png","n_6.png","n_7.png","n_8.png","n_9.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'k_1.png',
              unit_tc: 'k_1.png',
              unit_en: 'k_1.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 50,
              y: 239,
              image_array: ["bt_00.png","bt_01.png","bt_02.png","bt_03.png","bt_04.png","bt_05.png","bt_06.png","bt_07.png","bt_08.png","bt_09.png","bt_10.png","bt_11.png","bt_12.png","bt_13.png","bt_14.png","bt_15.png","bt_16.png","bt_17.png","bt_18.png","bt_19.png","bt_20.png","bt_21.png","bt_22.png","bt_23.png","bt_24.png","bt_25.png","bt_26.png","bt_27.png","bt_28.png","bt_29.png","bt_30.png","bt_31.png","bt_32.png","bt_33.png","bt_34.png","bt_35.png","bt_36.png","bt_37.png","bt_38.png","bt_39.png","bt_40.png","bt_41.png","bt_42.png","bt_43.png","bt_44.png","bt_45.png","bt_46.png","bt_47.png","bt_48.png","bt_49.png","bt_50.png","bt_51.png","bt_52.png","bt_53.png","bt_54.png","bt_55.png","bt_56.png","bt_57.png","bt_58.png","bt_59.png","bt_60.png","bt_61.png","bt_62.png","bt_63.png","bt_64.png","bt_65.png","bt_66.png","bt_67.png","bt_68.png","bt_69.png","bt_70.png","bt_71.png","bt_72.png","bt_73.png","bt_74.png","bt_75.png","bt_76.png","bt_77.png","bt_78.png","bt_79.png","bt_80.png","bt_81.png","bt_82.png","bt_83.png","bt_84.png","bt_85.png","bt_86.png","bt_87.png","bt_88.png","bt_89.png","bt_90.png","bt_91.png","bt_92.png","bt_93.png","bt_94.png","bt_95.png","bt_96.png","bt_97.png","bt_98.png","bt_99.png"],
              image_length: 100,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_pointer_progress_img_pointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
              src: 'ch_4.png',
              center_x: 118,
              center_y: 233,
              x: 11,
              y: 71,
              start_angle: -90,
              end_angle: 90,
              invalid_visible: false,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_pai_weekly_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 321,
              y: 273,
              font_array: ["n_0.png","n_1.png","n_2.png","n_3.png","n_4.png","n_5.png","n_6.png","n_7.png","n_8.png","n_9.png"],
              padding: false,
              h_space: -1,
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.PAI_WEEKLY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_pai_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 305,
              y: 273,
              image_array: ["pai_000.png","pai_001.png","pai_002.png","pai_003.png","pai_004.png","pai_005.png","pai_006.png","pai_007.png","pai_008.png","pai_009.png","pai_010.png","pai_011.png","pai_012.png","pai_013.png","pai_014.png","pai_015.png","pai_016.png","pai_017.png","pai_018.png","pai_019.png","pai_020.png","pai_021.png","pai_022.png","pai_023.png","pai_024.png","pai_025.png","pai_026.png","pai_027.png","pai_028.png","pai_029.png","pai_030.png","pai_031.png","pai_032.png","pai_033.png","pai_034.png","pai_035.png","pai_036.png","pai_037.png","pai_038.png","pai_039.png","pai_040.png","pai_041.png","pai_042.png","pai_043.png","pai_044.png","pai_045.png","pai_046.png","pai_047.png","pai_048.png","pai_049.png","pai_050.png","pai_051.png","pai_052.png","pai_053.png","pai_054.png","pai_055.png","pai_056.png","pai_057.png","pai_058.png","pai_059.png","pai_060.png","pai_061.png","pai_062.png","pai_063.png","pai_064.png","pai_065.png","pai_066.png","pai_067.png","pai_068.png","pai_069.png","pai_070.png","pai_071.png","pai_072.png","pai_073.png","pai_074.png","pai_075.png","pai_076.png","pai_077.png","pai_078.png","pai_079.png","pai_080.png","pai_081.png","pai_082.png","pai_083.png","pai_084.png","pai_085.png","pai_086.png","pai_087.png","pai_088.png","pai_089.png","pai_090.png","pai_091.png","pai_092.png","pai_093.png","pai_094.png","pai_095.png","pai_096.png","pai_097.png","pai_098.png","pai_099.png","pai_100.png","pai_101.png","pai_102.png","pai_103.png","pai_104.png"],
              image_length: 105,
              type: hmUI.data_type.PAI_WEEKLY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_frame_animation_1 = hmUI.createWidget(hmUI.widget.IMG_ANIM, {
              x: 81,
              y: 253,
              anim_path: "animation",
              anim_ext: "png",
              anim_prefix: "hr",
              anim_fps: 2,
              anim_size: 2,
              repeat_count: 0,
              anim_repeat: true,
              anim_status:hmUI.anim_status.START,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_frame_animation_2 = hmUI.createWidget(hmUI.widget.IMG_ANIM, {
              x: 50,
              y: 239,
              anim_path: "animation",
              anim_ext: "png",
              anim_prefix: "bt",
              anim_fps: 2,
              anim_size: 2,
              repeat_count: 0,
              anim_repeat: true,
              anim_status:hmUI.anim_status.START,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_distance_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 313,
              y: 249,
              font_array: ["n_0.png","n_1.png","n_2.png","n_3.png","n_4.png","n_5.png","n_6.png","n_7.png","n_8.png","n_9.png"],
              padding: false,
              h_space: -1,
              unit_sc: 'l_0.png',
              unit_tc: 'l_0.png',
              unit_en: 'l_0.png',
              imperial_unit_sc: 'l_1.png',
              imperial_unit_tc: 'l_1.png',
              imperial_unit_en: 'l_1.png',
              dot_image: 'k_0.png',
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.DISTANCE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 317,
              y: 202,
              font_array: ["n_0.png","n_1.png","n_2.png","n_3.png","n_4.png","n_5.png","n_6.png","n_7.png","n_8.png","n_9.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 397,
              y: 239,
              image_array: ["st_00.png","st_01.png","st_02.png","st_03.png","st_04.png","st_05.png","st_06.png","st_07.png","st_08.png","st_09.png","st_10.png","st_11.png","st_12.png","st_13.png","st_14.png","st_15.png","st_16.png","st_17.png","st_18.png","st_19.png","st_20.png","st_21.png","st_22.png","st_23.png","st_24.png","st_25.png","st_26.png","st_27.png","st_28.png","st_29.png","st_30.png","st_31.png","st_32.png","st_33.png","st_34.png","st_35.png","st_36.png","st_37.png","st_38.png","st_39.png","st_40.png","st_41.png","st_42.png","st_43.png","st_44.png","st_45.png","st_46.png","st_47.png","st_48.png","st_49.png","st_50.png","st_51.png","st_52.png","st_53.png","st_54.png","st_55.png","st_56.png","st_57.png","st_58.png","st_59.png","st_60.png","st_61.png","st_62.png","st_63.png","st_64.png","st_65.png","st_66.png","st_67.png","st_68.png","st_69.png","st_70.png","st_71.png","st_72.png","st_73.png","st_74.png","st_75.png","st_76.png","st_77.png","st_78.png","st_79.png","st_80.png","st_81.png","st_82.png","st_83.png","st_84.png","st_85.png","st_86.png","st_87.png","st_88.png","st_89.png","st_90.png","st_91.png","st_92.png","st_93.png","st_94.png","st_95.png","st_96.png","st_97.png","st_98.png","st_99.png"],
              image_length: 100,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_pointer_progress_img_pointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
              src: 'ch_4.png',
              center_x: 348,
              center_y: 233,
              x: 11,
              y: 71,
              start_angle: -90,
              end_angle: 90,
              invalid_visible: false,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_week_pointer_progress_date_pointer = hmUI.createWidget(hmUI.widget.DATE_POINTER, {
              src: 'ch_5.png',
              center_x: 233,
              center_y: 347,
              posX: 11,
              posY: 71,
              start_angle: -52,
              end_angle: 308,
              type: hmUI.date.WEEK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_day_pointer_progress_date_pointer = hmUI.createWidget(hmUI.widget.DATE_POINTER, {
              src: 'ch_3.png',
              center_x: 233,
              center_y: 233,
              posX: 20,
              posY: 227,
              start_angle: 0,
              end_angle: 360,
              type: hmUI.date.DAY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            console.log('Watch_Face.ScreenAOD');
            idle_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 466,
              h: 466,
              src: 'aod_base.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });
            console.log('Watch_Face.ElementEditablePointers');

            const pointerEdit = hmUI.createWidget(hmUI.widget.WATCHFACE_EDIT_POINTER, {
              edit_id: 1003,
              x: 0,
              y: 0,
              config: [
                {
                  id: 1,
                  second: {
                    centerX: 233,
                    centerY: 233,
                    posX: 13,
                    posY: 208,
                    path: 'ch_2-1.png',
                  },
                  hour: {
                    centerX: 233,
                    centerY: 233,
                    posX: 27,
                    posY: 154,
                    path: 'ch_0-1.png',
                  },
                  minute: {
                    centerX: 233,
                    centerY: 233,
                    posX: 20,
                    posY: 199,
                    path: 'ch_1-1.png',
                  },
                  preview: 'pointer_edit_1_preview.png',
                },
                {
                  id: 2,
                  second: {
                    centerX: 233,
                    centerY: 233,
                    posX: 13,
                    posY: 208,
                    path: 'ch_2-2.png',
                  },
                  hour: {
                    centerX: 233,
                    centerY: 233,
                    posX: 27,
                    posY: 154,
                    path: 'ch_0-2.png',
                  },
                  minute: {
                    centerX: 233,
                    centerY: 233,
                    posX: 20,
                    posY: 199,
                    path: 'ch_1-2.png',
                  },
                  preview: 'pointer_edit_2_preview.png',
                },
                {
                  id: 3,
                  second: {
                    centerX: 233,
                    centerY: 233,
                    posX: 13,
                    posY: 208,
                    path: 'ch_2-3.png',
                  },
                  hour: {
                    centerX: 233,
                    centerY: 233,
                    posX: 27,
                    posY: 154,
                    path: 'ch_0-3.png',
                  },
                  minute: {
                    centerX: 233,
                    centerY: 233,
                    posX: 20,
                    posY: 199,
                    path: 'ch_1-3.png',
                  },
                  preview: 'pointer_edit_3_preview.png',
                },
                {
                  id: 4,
                  second: {
                    centerX: 233,
                    centerY: 233,
                    posX: 13,
                    posY: 208,
                    path: 'ch_2-4.png',
                  },
                  hour: {
                    centerX: 233,
                    centerY: 233,
                    posX: 27,
                    posY: 154,
                    path: 'ch_0-4.png',
                  },
                  minute: {
                    centerX: 233,
                    centerY: 233,
                    posX: 20,
                    posY: 199,
                    path: 'ch_1-4.png',
                  },
                  preview: 'pointer_edit_4_preview.png',
                },
                {
                  id: 5,
                  second: {
                    centerX: 233,
                    centerY: 233,
                    posX: 13,
                    posY: 208,
                    path: 'aod_2-1.png',
                  },
                  hour: {
                    centerX: 233,
                    centerY: 233,
                    posX: 27,
                    posY: 154,
                    path: 'aod_0-1.png',
                  },
                  minute: {
                    centerX: 233,
                    centerY: 233,
                    posX: 20,
                    posY: 199,
                    path: 'aod_1-1.png',
                  },
                  preview: 'pointer_edit_5_preview.png',
                },
                {
                  id: 6,
                  second: {
                    centerX: 233,
                    centerY: 233,
                    posX: 13,
                    posY: 208,
                    path: 'aod_2-2.png',
                  },
                  hour: {
                    centerX: 233,
                    centerY: 233,
                    posX: 27,
                    posY: 154,
                    path: 'aod_0-2.png',
                  },
                  minute: {
                    centerX: 233,
                    centerY: 233,
                    posX: 20,
                    posY: 199,
                    path: 'aod_1-2.png',
                  },
                  preview: 'pointer_edit_6_preview.png',
                },
              ],
              count: 6,
              default_id: 1,
              fg: '.png',
              tips_x: 108,
              tips_y: 74,
              tips_bg: 'pt-mode.png',
            });
            const screenTypeForETP = hmSetting.getScreenType();
            const aodModel = screenTypeForETP == hmSetting.screen_type.AOD;
            const pointerProp = pointerEdit.getProperty(hmUI.prop.CURRENT_CONFIG, !aodModel);
            editableTimePointers = hmUI.createWidget(hmUI.widget.TIME_POINTER, pointerProp);
            console.log('Watch_Face.Shortcuts');

            normal_stopwatch_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 193,
              y: 193,
              w: 80,
              h: 80,
              type: hmUI.data_type.STOP_WATCH,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_alarm_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 78,
              y: 339,
              w: 50,
              h: 50,
              type: hmUI.data_type.ALARM_CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 183,
              y: 297,
              w: 100,
              h: 100,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_pai_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 288,
              y: 236,
              w: 120,
              h: 60,
              type: hmUI.data_type.PAI_WEEKLY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 58,
              y: 236,
              w: 120,
              h: 60,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 288,
              y: 169,
              w: 120,
              h: 60,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                console.log('resume_call()');
                normal_frame_animation_1.setProperty(hmUI.prop.ANIM_STATUS,hmUI.anim_status.START);
                normal_frame_animation_2.setProperty(hmUI.prop.ANIM_STATUS,hmUI.anim_status.START);

              }),
              pause_call: (function () {
                console.log('pause_call()');
                normal_frame_animation_1.setProperty(hmUI.prop.ANIM_STATUS,hmUI.anim_status.STOP);
                normal_frame_animation_2.setProperty(hmUI.prop.ANIM_STATUS,hmUI.anim_status.STOP);

              }),
            });

                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}