/*
** Facemaker bundle tool v0.0.3
* *huamiOS watchface js version v2.0.1
* *Copyright © Huami. All Rights Reserved
*/


try {
	(() => {
		var __$$app$$__ = __$$hmAppManager$$__.currentApp;
		var __$$module$$__ = __$$app$$__.current;

		//drink is a name,can modify
		var h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__), 'drink');

		'use strict';

		//dynamic modify start
		let normal_img0 = '';
		let normal_img1 = '';
		let normal_img2 = '';
		let normal_img3 = '';
		let normal_img4 = '';
		let normal_img5 = '';
		let normal_img6 = '';
		let normal_img7 = '';
		let normal_img8 = '';
		let normal_img9 = '';
		let normal_img10 = '';
		let normal_img11 = '';
		let timeInterval;
		let normal_hour_high_imageset13 = '';
		let normal_hour_high_imageset13_array = ['0013.png','0014.png','0015.png'];
		let normal_hour_low_imageset14 = '';
		let normal_hour_low_imageset14_array = ['0016.png','0017.png','0018.png','0019.png','0020.png','0021.png','0022.png','0023.png','0024.png','0025.png'];
		let normal_minute_high_imageset15 = '';
		let normal_minute_high_imageset15_array = ['0026.png','0027.png','0028.png','0029.png','0030.png','0031.png'];
		let normal_minute_low_imageset16 = '';
		let normal_minute_low_imageset16_array = ['0032.png','0033.png','0034.png','0035.png','0036.png','0037.png','0038.png','0039.png','0040.png','0041.png'];
		let normal_img17 = '';
		let normal_hour_high_imageset19 = '';
		let normal_hour_high_imageset19_array = ['0043.png','0044.png','0045.png'];
		let normal_hour_low_imageset20 = '';
		let normal_hour_low_imageset20_array = ['0046.png','0047.png','0048.png','0049.png','0050.png','0051.png','0052.png','0053.png','0054.png','0055.png'];
		let normal_minute_high_imageset21 = '';
		let normal_minute_high_imageset21_array = ['0056.png','0057.png','0058.png','0059.png','0060.png','0061.png'];
		let normal_minute_low_imageset22 = '';
		let normal_minute_low_imageset22_array = ['0062.png','0063.png','0064.png','0065.png','0066.png','0067.png','0068.png','0069.png','0070.png','0071.png'];
		let normal_img23 = '';
		let normal_hour_high_imageset25 = '';
		let normal_hour_high_imageset25_array = ['0073.png','0074.png','0075.png'];
		let normal_hour_low_imageset26 = '';
		let normal_hour_low_imageset26_array = ['0076.png','0077.png','0078.png','0079.png','0080.png','0081.png','0082.png','0083.png','0084.png','0085.png'];
		let normal_minute_high_imageset27 = '';
		let normal_minute_high_imageset27_array = ['0086.png','0087.png','0088.png','0089.png','0090.png','0091.png'];
		let normal_minute_low_imageset28 = '';
		let normal_minute_low_imageset28_array = ['0092.png','0093.png','0094.png','0095.png','0096.png','0097.png','0098.png','0099.png','0100.png','0101.png'];
		let normal_img29 = '';
		let normal_hour_high_imageset31 = '';
		let normal_hour_high_imageset31_array = ['0103.png','0104.png','0105.png'];
		let normal_hour_low_imageset32 = '';
		let normal_hour_low_imageset32_array = ['0106.png','0107.png','0108.png','0109.png','0110.png','0111.png','0112.png','0113.png','0114.png','0115.png'];
		let normal_minute_high_imageset33 = '';
		let normal_minute_high_imageset33_array = ['0116.png','0117.png','0118.png','0119.png','0120.png','0121.png'];
		let normal_minute_low_imageset34 = '';
		let normal_minute_low_imageset34_array = ['0122.png','0123.png','0124.png','0125.png','0126.png','0127.png','0128.png','0129.png','0130.png','0131.png'];
		let normal_img35 = '';
		let normal_hour_high_imageset37 = '';
		let normal_hour_high_imageset37_array = ['0133.png','0134.png','0135.png'];
		let normal_hour_low_imageset38 = '';
		let normal_hour_low_imageset38_array = ['0136.png','0137.png','0138.png','0139.png','0140.png','0141.png','0142.png','0143.png','0144.png','0145.png'];
		let normal_minute_high_imageset39 = '';
		let normal_minute_high_imageset39_array = ['0146.png','0147.png','0148.png','0149.png','0150.png','0151.png'];
		let normal_minute_low_imageset40 = '';
		let normal_minute_low_imageset40_array = ['0152.png','0153.png','0154.png','0155.png','0156.png','0157.png','0158.png','0159.png','0160.png','0161.png'];
		let normal_img41 = '';
		let normal_bt_status44 = '';
		let normal_alarm_status45 = '';
		let normal_week_imageset47 = '';
		let normal_date_high_imageset48 = '';
		let normal_date_high_imageset48_array = ['0173.png','0174.png','0175.png','0176.png'];
		let normal_date_low_imageset49 = '';
		let normal_date_low_imageset49_array = ['0173.png','0174.png','0175.png','0176.png','0177.png','0178.png','0179.png','0180.png','0181.png','0182.png'];
		let normal_month_imageset50 = '';
		let normal_year_imagecombo51 = '';
		let normal_current_city_text53 = '';
		let normal_img54 = '';
		let normal_temperature_current_imagecombo55 = '';
		let normal_weather_imageset56 = '';
		let normal_humidity_imagecombo58 = '';
		let normal_img59 = '';
		let normal_steps_imagecombo61 = '';
		let normal_img62 = '';
		let normal_distance_imagecombo64 = '';
		let normal_img65 = '';
		let normal_img67 = '';
		let normal_calories_imagecombo68 = '';
		let normal_img70 = '';
		let normal_heart_current_imagecombo71 = '';
		let normal_img73 = '';
		let normal_blood_oxygen_imagecombo74 = '';
		let normal_battery_imagecombo76 = '';
		let normal_img77 = '';
		let normal_img78 = '';
		let container_1685261443999 = '';
		let container_1685261443999_customs = [
			{
				label: 'Digital Dial',
				widgets: [
					'normal_hour_high_imageset13',
					'normal_hour_low_imageset14',
					'normal_minute_high_imageset15',
					'normal_minute_low_imageset16',
					'normal_img17',
				]
			},
			{
				label: 'Digital Dial',
				widgets: [
					'normal_hour_high_imageset19',
					'normal_hour_low_imageset20',
					'normal_minute_high_imageset21',
					'normal_minute_low_imageset22',
					'normal_img23',
				]
			},
			{
				label: 'Digital Dial',
				widgets: [
					'normal_hour_high_imageset25',
					'normal_hour_low_imageset26',
					'normal_minute_high_imageset27',
					'normal_minute_low_imageset28',
					'normal_img29',
				]
			},
			{
				label: 'Digital Dial',
				widgets: [
					'normal_hour_high_imageset31',
					'normal_hour_low_imageset32',
					'normal_minute_high_imageset33',
					'normal_minute_low_imageset34',
					'normal_img35',
				]
			},
			{
				label: 'Digital Dial',
				widgets: [
					'normal_hour_high_imageset37',
					'normal_hour_low_imageset38',
					'normal_minute_high_imageset39',
					'normal_minute_low_imageset40',
					'normal_img41',
				]
			},
		];
		let container_1685261443999_selected = 0;
		//dynamic modify end

		//not required
		const logger = DeviceRuntimeCore.HmLogger.getLogger("yeguang");

		__$$module$$__.module = DeviceRuntimeCore.WatchFace({
			init_view() {

				const timeSensor = hmSensor.createSensor(hmSensor.id.TIME);
				const weatherSensor = hmSensor.createSensor(hmSensor.id.WEATHER);
				const vibrateSensor = hmSensor.createSensor(hmSensor.id.VIBRATE);
				let screenType = hmSetting.getScreenType();

				normal_img0 = hmUI.createWidget(hmUI.widget.IMG, {
					x: -3,
					y: 244,
					w: 476,
					h: 56,
					src: '0002.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img1 = hmUI.createWidget(hmUI.widget.IMG, {
					x: -2,
					y: 241,
					w: 472,
					h: 4,
					src: '0003.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img2 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 7,
					y: 298,
					w: 452,
					h: 4,
					src: '0004.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img3 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 32,
					y: 353,
					w: 404,
					h: 4,
					src: '0005.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img4 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 94,
					y: 421,
					w: 283,
					h: 4,
					src: '0006.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img5 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 178,
					y: 354,
					w: 4,
					h: 70,
					src: '0007.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img6 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 284,
					y: 354,
					w: 4,
					h: 70,
					src: '0007.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img7 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 39,
					y: 92,
					w: 383,
					h: 4,
					src: '0008.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img8 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 217,
					y: 207,
					w: 33,
					h: 33,
					src: '0009.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img9 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 1,
					y: 198,
					w: 35,
					h: 35,
					src: '0010.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img10 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 433,
					y: 198,
					w: 34,
					h: 35,
					src: '0011.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img11 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 205,
					y: 309,
					w: 54,
					h: 38,
					src: '0012.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_hour_high_imageset13 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 31,
					y: 83,
					w: 31,
					h: 83,
					src: '0015.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				})

				normal_hour_low_imageset14 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 116,
					y: 83,
					w: 116,
					h: 83,
					src: '0025.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				})

				normal_minute_high_imageset15 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 240,
					y: 83,
					w: 240,
					h: 83,
					src: '0031.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				})

				normal_minute_low_imageset16 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 327,
					y: 83,
					w: 327,
					h: 83,
					src: '0041.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				})

				normal_img17 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 216,
					y: 105,
					w: 35,
					h: 113,
					src: '0042.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_hour_high_imageset19 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 31,
					y: 83,
					w: 31,
					h: 83,
					src: '0045.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				})

				normal_hour_high_imageset19.setProperty(hmUI.prop.VISIBLE, false);

				normal_hour_low_imageset20 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 116,
					y: 83,
					w: 116,
					h: 83,
					src: '0055.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				})

				normal_hour_low_imageset20.setProperty(hmUI.prop.VISIBLE, false);

				normal_minute_high_imageset21 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 240,
					y: 83,
					w: 240,
					h: 83,
					src: '0061.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				})

				normal_minute_high_imageset21.setProperty(hmUI.prop.VISIBLE, false);

				normal_minute_low_imageset22 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 327,
					y: 83,
					w: 327,
					h: 83,
					src: '0071.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				})

				normal_minute_low_imageset22.setProperty(hmUI.prop.VISIBLE, false);

				normal_img23 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 216,
					y: 105,
					w: 35,
					h: 113,
					src: '0072.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img23.setProperty(hmUI.prop.VISIBLE, false);

				normal_hour_high_imageset25 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 31,
					y: 83,
					w: 31,
					h: 83,
					src: '0075.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				})

				normal_hour_high_imageset25.setProperty(hmUI.prop.VISIBLE, false);

				normal_hour_low_imageset26 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 116,
					y: 83,
					w: 116,
					h: 83,
					src: '0085.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				})

				normal_hour_low_imageset26.setProperty(hmUI.prop.VISIBLE, false);

				normal_minute_high_imageset27 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 240,
					y: 83,
					w: 240,
					h: 83,
					src: '0091.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				})

				normal_minute_high_imageset27.setProperty(hmUI.prop.VISIBLE, false);

				normal_minute_low_imageset28 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 327,
					y: 83,
					w: 327,
					h: 83,
					src: '0101.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				})

				normal_minute_low_imageset28.setProperty(hmUI.prop.VISIBLE, false);

				normal_img29 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 216,
					y: 105,
					w: 35,
					h: 113,
					src: '0102.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img29.setProperty(hmUI.prop.VISIBLE, false);

				normal_hour_high_imageset31 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 31,
					y: 83,
					w: 31,
					h: 83,
					src: '0105.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				})

				normal_hour_high_imageset31.setProperty(hmUI.prop.VISIBLE, false);

				normal_hour_low_imageset32 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 116,
					y: 83,
					w: 116,
					h: 83,
					src: '0115.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				})

				normal_hour_low_imageset32.setProperty(hmUI.prop.VISIBLE, false);

				normal_minute_high_imageset33 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 240,
					y: 83,
					w: 240,
					h: 83,
					src: '0121.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				})

				normal_minute_high_imageset33.setProperty(hmUI.prop.VISIBLE, false);

				normal_minute_low_imageset34 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 327,
					y: 83,
					w: 327,
					h: 83,
					src: '0131.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				})

				normal_minute_low_imageset34.setProperty(hmUI.prop.VISIBLE, false);

				normal_img35 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 216,
					y: 105,
					w: 35,
					h: 113,
					src: '0132.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img35.setProperty(hmUI.prop.VISIBLE, false);

				normal_hour_high_imageset37 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 31,
					y: 83,
					w: 31,
					h: 83,
					src: '0135.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				})

				normal_hour_high_imageset37.setProperty(hmUI.prop.VISIBLE, false);

				normal_hour_low_imageset38 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 116,
					y: 83,
					w: 116,
					h: 83,
					src: '0145.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				})

				normal_hour_low_imageset38.setProperty(hmUI.prop.VISIBLE, false);

				normal_minute_high_imageset39 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 240,
					y: 83,
					w: 240,
					h: 83,
					src: '0151.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				})

				normal_minute_high_imageset39.setProperty(hmUI.prop.VISIBLE, false);

				normal_minute_low_imageset40 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 327,
					y: 83,
					w: 327,
					h: 83,
					src: '0161.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				})

				normal_minute_low_imageset40.setProperty(hmUI.prop.VISIBLE, false);

				normal_img41 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 216,
					y: 105,
					w: 35,
					h: 113,
					src: '0162.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img41.setProperty(hmUI.prop.VISIBLE, false);

				normal_bt_status44 = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
					x: 1,
					y: 198,
					w: 35,
					h: 35,
					type: hmUI.system_status.DISCONNECT,
					src: '0164.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_alarm_status45 = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
					x: 433,
					y: 198,
					w: 34,
					h: 35,
					type: hmUI.system_status.CLOCK,
					src: '0165.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_week_imageset47 = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
					x: 11,
					y: 248,
					week_en: ["0166.png","0167.png","0168.png","0169.png","0170.png","0171.png","0172.png"],
					week_tc: ["0166.png","0167.png","0168.png","0169.png","0170.png","0171.png","0172.png"],
					week_sc: ["0166.png","0167.png","0168.png","0169.png","0170.png","0171.png","0172.png"],
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_date_high_imageset48 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 116,
					y: 242,
					w: 116,
					h: 242,
					src: '0176.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				})

				normal_date_low_imageset49 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 149,
					y: 242,
					w: 149,
					h: 242,
					src: '0182.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				})

				normal_month_imageset50 = hmUI.createWidget(hmUI.widget.IMG_DATE, {
					month_startX: 205,
					month_startY: 248,
					month_sc_array: ["0183.png","0184.png","0185.png","0186.png","0187.png","0188.png","0189.png","0190.png","0191.png","0192.png","0193.png","0194.png"],
					month_tc_array: ["0183.png","0184.png","0185.png","0186.png","0187.png","0188.png","0189.png","0190.png","0191.png","0192.png","0193.png","0194.png"],
					month_en_array: ["0183.png","0184.png","0185.png","0186.png","0187.png","0188.png","0189.png","0190.png","0191.png","0192.png","0193.png","0194.png"],
					month_is_character: true,
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_year_imagecombo51 = hmUI.createWidget(hmUI.widget.IMG_DATE, {
					year_startX: 314,
					year_startY: 242,
					year_sc_array: ["0195.png","0196.png","0197.png","0198.png","0199.png","0200.png","0201.png","0202.png","0203.png","0204.png"],
					year_tc_array: ["0195.png","0196.png","0197.png","0198.png","0199.png","0200.png","0201.png","0202.png","0203.png","0204.png"],
					year_en_array: ["0195.png","0196.png","0197.png","0198.png","0199.png","0200.png","0201.png","0202.png","0203.png","0204.png"],
					year_zero: true,
					year_space: -16,
					year_align: hmUI.align.CENTER_H,
					year_is_character: false,
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_current_city_text53 = hmUI.createWidget(hmUI.widget.TEXT, {
					x: 79,
					y: 61,
					w: 306,
					h: 25,
					color: 0x8C8C8C,
					text: '--',
					text_size: 25,
					align_h: hmUI.align.CENTER_H,
					align_v: hmUI.align.CENTER_V,
					text_style: hmUI.text_style.NONE,
					font: 'fonts/Roboto-Medium.ttf',
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img54 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 331,
					y: 26,
					w: 23,
					h: 30,
					src: '0205.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_temperature_current_imagecombo55 = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
					x: 263,
					y: 23,
					font_array: ["0206.png","0207.png","0208.png","0209.png","0210.png","0211.png","0212.png","0213.png","0214.png","0215.png"],
					padding: false,
					h_space: -3,
					unit_sc: ["0217.png"],
					unit_tc: ["0217.png"],
					unit_en: ["0217.png"],
					negative_image: ["0216.png"],
					invalid_image: ["0216.png"],
					align_h: hmUI.align.CENTER_H,
					type: hmUI.data_type.WEATHER_CURRENT,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_weather_imageset56 = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
					x: 205,
					y: -4,
					image_array: ["0218.png","0219.png","0220.png","0221.png","0222.png","0223.png","0220.png","0224.png","0225.png","0226.png","0227.png","0228.png","0229.png","0230.png","0231.png","0232.png","0233.png","0234.png","0235.png","0236.png","0237.png","0238.png","0239.png","0240.png","0241.png","0242.png","0218.png","0219.png","0221.png"],
					image_length: 29,
					type: hmUI.data_type.WEATHER_CURRENT,
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_humidity_imagecombo58 = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
					x: 131,
					y: 23,
					font_array: ["0243.png","0244.png","0245.png","0246.png","0247.png","0248.png","0249.png","0250.png","0251.png","0252.png"],
					padding: false,
					h_space: 0,
					align_h: hmUI.align.CENTER_H,
					type: hmUI.data_type.HUMIDITY,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img59 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 110,
					y: 26,
					w: 20,
					h: 30,
					src: '0253.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_steps_imagecombo61 = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
					x: 57,
					y: 306,
					font_array: ["0254.png","0255.png","0256.png","0257.png","0258.png","0259.png","0260.png","0261.png","0262.png","0263.png"],
					padding: false,
					h_space: -3,
					align_h: hmUI.align.CENTER_H,
					type: hmUI.data_type.STEP,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img62 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 19,
					y: 309,
					w: 32,
					h: 25,
					src: '0264.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_distance_imagecombo64 = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
					x: 274,
					y: 306,
					font_array: ["0254.png","0255.png","0256.png","0257.png","0258.png","0259.png","0260.png","0261.png","0262.png","0263.png"],
					padding: false,
					h_space: -3,
					dot_image: '0265.png',
					align_h: hmUI.align.CENTER_H,
					type: hmUI.data_type.DISTANCE,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img65 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 400,
					y: 309,
					w: 47,
					h: 25,
					src: '0266.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img67 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 208,
					y: 398,
					w: 50,
					h: 25,
					src: '0267.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_calories_imagecombo68 = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
					x: 182,
					y: 361,
					font_array: ["0268.png","0269.png","0270.png","0271.png","0272.png","0273.png","0274.png","0275.png","0276.png","0277.png"],
					padding: false,
					h_space: -2,
					align_h: hmUI.align.CENTER_H,
					type: hmUI.data_type.CAL,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img70 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 382,
					y: 363,
					w: 30,
					h: 30,
					src: '0278.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_heart_current_imagecombo71 = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
					x: 297,
					y: 361,
					font_array: ["0279.png","0280.png","0281.png","0282.png","0283.png","0284.png","0285.png","0286.png","0287.png","0288.png"],
					padding: false,
					h_space: -3,
					invalid_image: '0289.png',
					align_h: hmUI.align.CENTER_H,
					type: hmUI.data_type.HEART,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img73 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 60,
					y: 363,
					w: 31,
					h: 33,
					src: '0290.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_blood_oxygen_imagecombo74 = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
					x: 96,
					y: 361,
					font_array: ["0291.png","0292.png","0293.png","0294.png","0295.png","0296.png","0297.png","0298.png","0299.png","0300.png"],
					padding: false,
					h_space: -2,
					align_h: hmUI.align.CENTER_H,
					type: hmUI.data_type.SPO2,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_battery_imagecombo76 = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
					x: 187,
					y: 433,
					font_array: ["0301.png","0302.png","0303.png","0304.png","0305.png","0306.png","0307.png","0308.png","0309.png","0310.png"],
					padding: false,
					h_space: -2,
					unit_sc: '0311.png',
					unit_tc: '0311.png',
					unit_en: '0311.png',
					align_h: hmUI.align.CENTER_H,
					type: hmUI.data_type.BATTERY,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img77 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 292,
					y: 430,
					w: 31,
					h: 34,
					src: '0312.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img78 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 145,
					y: 430,
					w: 31,
					h: 34,
					src: '0313.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				container_1685261443999 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 43,
					y: 102,
					w: 382,
					h: 133,
					src: '0163.png',
					show_level: hmUI.show_level.ONLY_NORMAL
				});

				container_1685261443999.addEventListener(hmUI.event.CLICK_DOWN, (info) => {
					container_1685261443999_selected = (container_1685261443999_selected+1 > container_1685261443999_customs.length-1) ? 0 : container_1685261443999_selected+1;
					for (let w = 0; w < container_1685261443999_customs.length; w++) {
						for (let z of container_1685261443999_customs[w].widgets) {
							eval(z).setProperty(hmUI.prop.VISIBLE, ((w == container_1685261443999_selected) ? true : false));
						}
					}
					hmUI.showToast({
						text: container_1685261443999_customs[container_1685261443999_selected].label.toString() + ' Włączony'
					});
					vibrateSensor.stop();
					vibrateSensor.scene = 25;
					vibrateSensor.start();
				});

				function updateTime() {
					normal_hour_high_imageset13.setProperty(hmUI.prop.MORE, {
						src: normal_hour_high_imageset13_array[(timeSensor.format_hour.toString().length == 2 ? timeSensor.format_hour.toString().charAt(0) : 0)]
					})
					normal_hour_low_imageset14.setProperty(hmUI.prop.MORE, {
						src: normal_hour_low_imageset14_array[(timeSensor.format_hour.toString().length == 2 ? timeSensor.format_hour.toString().charAt(1) : timeSensor.format_hour.toString().charAt(0))]
					})
					normal_minute_high_imageset15.setProperty(hmUI.prop.MORE, {
						src: normal_minute_high_imageset15_array[(timeSensor.minute.toString().length == 2 ? timeSensor.minute.toString().charAt(0) : 0)]
					})
					normal_minute_low_imageset16.setProperty(hmUI.prop.MORE, {
						src: normal_minute_low_imageset16_array[(timeSensor.minute.toString().length == 2 ? timeSensor.minute.toString().charAt(1) : timeSensor.minute.toString().charAt(0))]
					})
					normal_hour_high_imageset19.setProperty(hmUI.prop.MORE, {
						src: normal_hour_high_imageset19_array[(timeSensor.format_hour.toString().length == 2 ? timeSensor.format_hour.toString().charAt(0) : 0)]
					})
					normal_hour_low_imageset20.setProperty(hmUI.prop.MORE, {
						src: normal_hour_low_imageset20_array[(timeSensor.format_hour.toString().length == 2 ? timeSensor.format_hour.toString().charAt(1) : timeSensor.format_hour.toString().charAt(0))]
					})
					normal_minute_high_imageset21.setProperty(hmUI.prop.MORE, {
						src: normal_minute_high_imageset21_array[(timeSensor.minute.toString().length == 2 ? timeSensor.minute.toString().charAt(0) : 0)]
					})
					normal_minute_low_imageset22.setProperty(hmUI.prop.MORE, {
						src: normal_minute_low_imageset22_array[(timeSensor.minute.toString().length == 2 ? timeSensor.minute.toString().charAt(1) : timeSensor.minute.toString().charAt(0))]
					})
					normal_hour_high_imageset25.setProperty(hmUI.prop.MORE, {
						src: normal_hour_high_imageset25_array[(timeSensor.format_hour.toString().length == 2 ? timeSensor.format_hour.toString().charAt(0) : 0)]
					})
					normal_hour_low_imageset26.setProperty(hmUI.prop.MORE, {
						src: normal_hour_low_imageset26_array[(timeSensor.format_hour.toString().length == 2 ? timeSensor.format_hour.toString().charAt(1) : timeSensor.format_hour.toString().charAt(0))]
					})
					normal_minute_high_imageset27.setProperty(hmUI.prop.MORE, {
						src: normal_minute_high_imageset27_array[(timeSensor.minute.toString().length == 2 ? timeSensor.minute.toString().charAt(0) : 0)]
					})
					normal_minute_low_imageset28.setProperty(hmUI.prop.MORE, {
						src: normal_minute_low_imageset28_array[(timeSensor.minute.toString().length == 2 ? timeSensor.minute.toString().charAt(1) : timeSensor.minute.toString().charAt(0))]
					})
					normal_hour_high_imageset31.setProperty(hmUI.prop.MORE, {
						src: normal_hour_high_imageset31_array[(timeSensor.format_hour.toString().length == 2 ? timeSensor.format_hour.toString().charAt(0) : 0)]
					})
					normal_hour_low_imageset32.setProperty(hmUI.prop.MORE, {
						src: normal_hour_low_imageset32_array[(timeSensor.format_hour.toString().length == 2 ? timeSensor.format_hour.toString().charAt(1) : timeSensor.format_hour.toString().charAt(0))]
					})
					normal_minute_high_imageset33.setProperty(hmUI.prop.MORE, {
						src: normal_minute_high_imageset33_array[(timeSensor.minute.toString().length == 2 ? timeSensor.minute.toString().charAt(0) : 0)]
					})
					normal_minute_low_imageset34.setProperty(hmUI.prop.MORE, {
						src: normal_minute_low_imageset34_array[(timeSensor.minute.toString().length == 2 ? timeSensor.minute.toString().charAt(1) : timeSensor.minute.toString().charAt(0))]
					})
					normal_hour_high_imageset37.setProperty(hmUI.prop.MORE, {
						src: normal_hour_high_imageset37_array[(timeSensor.format_hour.toString().length == 2 ? timeSensor.format_hour.toString().charAt(0) : 0)]
					})
					normal_hour_low_imageset38.setProperty(hmUI.prop.MORE, {
						src: normal_hour_low_imageset38_array[(timeSensor.format_hour.toString().length == 2 ? timeSensor.format_hour.toString().charAt(1) : timeSensor.format_hour.toString().charAt(0))]
					})
					normal_minute_high_imageset39.setProperty(hmUI.prop.MORE, {
						src: normal_minute_high_imageset39_array[(timeSensor.minute.toString().length == 2 ? timeSensor.minute.toString().charAt(0) : 0)]
					})
					normal_minute_low_imageset40.setProperty(hmUI.prop.MORE, {
						src: normal_minute_low_imageset40_array[(timeSensor.minute.toString().length == 2 ? timeSensor.minute.toString().charAt(1) : timeSensor.minute.toString().charAt(0))]
					})
					normal_date_high_imageset48.setProperty(hmUI.prop.MORE, {
						src: normal_date_high_imageset48_array[(timeSensor.day.toString().length == 2 ? timeSensor.day.toString().charAt(0) : 0)]
					})
					normal_date_low_imageset49.setProperty(hmUI.prop.MORE, {
						src: normal_date_low_imageset49_array[(timeSensor.day.toString().length == 2 ? timeSensor.day.toString().charAt(1) : timeSensor.day.toString().charAt(0))]
					})
				}

				function updateWeather() {
					normal_current_city_text53.setProperty(hmUI.prop.TEXT, weatherSensor.getForecastWeather().cityName);
				}

				timeSensor.addEventListener(hmSensor.event.CHANGE, function() {
					updateTime();
				});

				weatherSensor.addEventListener(hmSensor.event.CHANGE, function() {
					updateWeather();
				});

				const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
					resume_call: (function () {
						updateTime();
						updateWeather();
						timeInterval = setInterval(updateTime, 1000);
					}),
					pause_call: (function () {
						clearInterval(timeInterval);
					}),
				})
			},

		onInit() {
			console.log('index page.js on init invoke')
			this.init_view()
		},
		onReady() {
			console.log('index page.js on ready invoke')
		},
		onShow() {
			console.log('index page.js on show invoke')
		},
		onHide() {
			console.log('index page.js on hide invoke')
		},
		onDestroy() {
			console.log('index page.js on destroy invoke')
		},
	});	})()
} catch (e) {
	console.log(e)
}