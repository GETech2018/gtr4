﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.0.1
    ** Copyright © CashaCX75. All Rights Reserved
    */

    try {
    (()=>{
        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_system_lock_img = ''
        let normal_system_dnd_img = ''
        let normal_system_disconnect_img = ''
        let normal_system_clock_img = ''
        let normal_date_img_date_month_img = ''
        let normal_date_img_date_week_img = ''
        let normal_date_img_date_day = ''
        let normal_pai_pointer_progress_img_pointer = ''
        let normal_pai_weekly_text_img = ''
        let idle_background_bg_img = ''
        let idle_pai_day_text_img = ''
        let idle_date_img_date_week_img = ''
        let idle_battery_icon_img = ''
        let idle_battery_text_text_img = ''
        let idle_heart_rate_icon_img = ''
        let idle_heart_rate_text_text_img = ''
        let idle_heart_rate_pointer_progress_img_pointer = ''
        let idle_step_icon_img = ''
        let idle_step_current_text_img = ''
        let editGroup_1  = ''
        let editGroup_2  = ''
        let editGroup_3  = ''
        let mask = ''
        let fg_mask = ''
        let editableTimePointers = ''


        //dynamic modify end
        const e = __$$hmAppManager$$__.currentApp;
        const o = e.current
          , {px: i} = (new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(e,o)),
        e.__globals__)
          , n = Logger.getLogger("watchface6");
        o.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 466,
              h: 466,
              src: 'bg.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_lock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 290,
              y: 20,
              src: 'Lock.png',
              type: hmUI.system_status.LOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_dnd_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 316,
              y: 392,
              src: 'DND.png',
              type: hmUI.system_status.DISTURB,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 296,
              y: 417,
              src: 'BT_(2).png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 316,
              y: 49,
              src: 'Alarm_(2).png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_month_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 62,
              month_startY: 230,
              month_sc_array: ["0006.png","0007.png","0008.png","0009.png","0010.png","0011.png","0012.png","0013.png","0014.png","0015.png","0016.png","0017.png"],
              month_tc_array: ["0006.png","0007.png","0008.png","0009.png","0010.png","0011.png","0012.png","0013.png","0014.png","0015.png","0016.png","0017.png"],
              month_en_array: ["0006.png","0007.png","0008.png","0009.png","0010.png","0011.png","0012.png","0013.png","0014.png","0015.png","0016.png","0017.png"],
              month_is_character: true ,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 76,
              y: 195,
              week_en: ["0028.png","0029.png","0030.png","0031.png","0032.png","0033.png","0034.png"],
              week_tc: ["0028.png","0029.png","0030.png","0031.png","0032.png","0033.png","0034.png"],
              week_sc: ["0028.png","0029.png","0030.png","0031.png","0032.png","0033.png","0034.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 130,
              day_startY: 230,
              day_sc_array: ["0018.png","0019.png","0020.png","0021.png","0022.png","0023.png","0024.png","0025.png","0026.png","0027.png"],
              day_tc_array: ["0018.png","0019.png","0020.png","0021.png","0022.png","0023.png","0024.png","0025.png","0026.png","0027.png"],
              day_en_array: ["0018.png","0019.png","0020.png","0021.png","0022.png","0023.png","0024.png","0025.png","0026.png","0027.png"],
              day_zero: 1,
              day_space: 0,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_pai_pointer_progress_img_pointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
              src: 'point.png',
              center_x: 233,
              center_y: 233,
              x: 11,
              y: 236,
              start_angle: -150,
              end_angle: -30,
              type: hmUI.data_type.PAI_WEEKLY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_pai_weekly_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 129,
              y: 25,
              font_array: ["0056.png","0057.png","0058.png","0059.png","0060.png","0061.png","0062.png","0063.png","0064.png","0065.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.PAI_WEEKLY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            idle_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 466,
              h: 466,
              src: 'bg.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_pai_day_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 122,
              y: 30,
              font_array: ["0035.png","0036.png","0037.png","0038.png","0039.png","0040.png","0041.png","0042.png","0043.png","0044.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.PAI_DAILY,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 60,
              y: 225,
              week_en: ["0028.png","0029.png","0030.png","0031.png","0032.png","0033.png","0034.png"],
              week_tc: ["0028.png","0029.png","0030.png","0031.png","0032.png","0033.png","0034.png"],
              week_sc: ["0028.png","0029.png","0030.png","0031.png","0032.png","0033.png","0034.png"],
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_battery_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 154,
              y: 280,
              src: '0053.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 204,
              y: 350,
              font_array: ["0056.png","0057.png","0058.png","0059.png","0060.png","0061.png","0062.png","0063.png","0064.png","0065.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_heart_rate_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 279,
              y: 156,
              src: '0071.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 334,
              y: 255,
              font_array: ["0035.png","0036.png","0037.png","0038.png","0039.png","0040.png","0041.png","0042.png","0043.png","0044.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_heart_rate_pointer_progress_img_pointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
              src: '0049.png',
              center_x: 356,
              center_y: 233,
              x: 21,
              y: 69,
              start_angle: 0,
              end_angle: 360,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_step_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 155,
              y: 27,
              src: '0048.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 195,
              y: 99,
              font_array: ["0035.png","0036.png","0037.png","0038.png","0039.png","0040.png","0041.png","0042.png","0043.png","0044.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            editGroup_1 = hmUI.createWidget(hmUI.widget.WATCHFACE_EDIT_GROUP, {
              edit_id: 10021,
              x: 155,
              y: 31,
              w: 149,
              h: 149,
              select_image: '0046.png',
              un_select_image: '0045.png',
              default_type: hmUI.edit_type.HEART,
              optional_types: [
                { type: hmUI.edit_type.HEART, preview: '0072.png' },
                { type: hmUI.edit_type.BATTERY, preview: '0054.png' },
                { type: hmUI.edit_type.UVI, preview: '0067.png' },
                { type: hmUI.edit_type.PAI, preview: '0074.png' },
                { type: hmUI.edit_type.STEP, preview: '0050.png' },
                { type: hmUI.edit_type.CAL, preview: '0052.png' },
              ],
              count: 6,
              tips_BG: '0073.png',
              tips_x: -60,
              tips_y: 189,
              tips_width: 114,
              tips_margin: 0,
            });

            const editType_1 = editGroup_1.getProperty(hmUI.prop.CURRENT_TYPE);

            switch (editType_1) {
              case hmUI.edit_type.BATTERY:
                hmUI.createWidget(hmUI.widget.IMG, {
                  x: 155,
                  y: 31,
                  src: '0053.png',
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });

                hmUI.createWidget(hmUI.widget.IMG_POINTER, {
                  src: '0049.png',
                  center_x: 233,
                  center_y: 108,
                  x: 21,
                  y: 69,
                  start_angle: 0,
                  end_angle: 360,
                  type: hmUI.data_type.BATTERY,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });
                break;

              case hmUI.edit_type.STEP:
                hmUI.createWidget(hmUI.widget.IMG, {
                  x: 155,
                  y: 31,
                  src: '0048.png',
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });

                hmUI.createWidget(hmUI.widget.IMG_POINTER, {
                  src: '0049.png',
                  center_x: 233,
                  center_y: 108,
                  x: 21,
                  y: 69,
                  start_angle: 0,
                  end_angle: 360,
                  type: hmUI.data_type.STEP,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });
                break;

              case hmUI.edit_type.CAL:
                hmUI.createWidget(hmUI.widget.IMG, {
                  x: 155,
                  y: 31,
                  src: '0051.png',
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });

                hmUI.createWidget(hmUI.widget.IMG_POINTER, {
                  src: '0049.png',
                  center_x: 233,
                  center_y: 108,
                  x: 21,
                  y: 69,
                  start_angle: 0,
                  end_angle: 360,
                  type: hmUI.data_type.CAL,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });
                break;

              case hmUI.edit_type.HEART:
                hmUI.createWidget(hmUI.widget.IMG, {
                  x: 155,
                  y: 32,
                  src: '0071.png',
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });

                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                  x: 203,
                  y: 138,
                  font_array: ["0056.png","0057.png","0058.png","0059.png","0060.png","0061.png","0062.png","0063.png","0064.png","0065.png"],
                  padding: false,
                  h_space: 0,
                  align_h: hmUI.align.CENTER_H,
                  type: hmUI.data_type.HEART,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });

                hmUI.createWidget(hmUI.widget.IMG_POINTER, {
                  src: '0049.png',
                  center_x: 233,
                  center_y: 108,
                  x: 21,
                  y: 69,
                  start_angle: 0,
                  end_angle: 360,
                  type: hmUI.data_type.HEART,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });
                break;

              case hmUI.edit_type.PAI:
                hmUI.createWidget(hmUI.widget.IMG, {
                  x: 155,
                  y: 31,
                  src: '0068.png',
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });

                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                  x: 205,
                  y: 140,
                  font_array: ["0056.png","0057.png","0058.png","0059.png","0060.png","0061.png","0062.png","0063.png","0064.png","0065.png"],
                  padding: false,
                  h_space: 0,
                  align_h: hmUI.align.CENTER_H,
                  type: hmUI.data_type.PAI_WEEKLY,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });

                hmUI.createWidget(hmUI.widget.IMG_POINTER, {
              src: '0049.png',
              center_x: 233,
              center_y: 108,
              x: 21,
              y: 69,
              start_angle: 0,
              end_angle: 360,
              type: hmUI.data_type.PAI_WEEKLY,
              show_level: hmUI.show_level.ONLY_NORMAL,
                });
                break;

              case hmUI.edit_type.UVI:
                 hmUI.createWidget(hmUI.widget.IMG, {
                  x: 155,
                  y: 31,
                  src: '0055.png',
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });

                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                  x: 219,
                  y: 143,
                  font_array: ["0035.png","0036.png","0037.png","0038.png","0039.png","0040.png","0041.png","0042.png","0043.png","0044.png"],
                  padding: false,
                  h_space: 0,
                  align_h: hmUI.align.CENTER_H,
                  type: hmUI.data_type.UVI,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });

                hmUI.createWidget(hmUI.widget.IMG_POINTER, {
                  src: '0049.png',
                  center_x: 233,
                  center_y: 108,
                  x: 21,
                  y: 69,
                  start_angle: 0,
                  end_angle: 360,
                  type: hmUI.data_type.UVI,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });
                break;
            }; // end switch

            editGroup_2 = hmUI.createWidget(hmUI.widget.WATCHFACE_EDIT_GROUP, {
              edit_id: 10022,
              x: 281,
              y: 156,
              w: 149,
              h: 149,
              select_image: '0046.png',
              un_select_image: '0045.png',
              default_type: hmUI.edit_type.STEP,
              optional_types: [
                { type: hmUI.edit_type.STEP, preview: '0050.png' },
                { type: hmUI.edit_type.CAL, preview: '0052.png' },
                { type: hmUI.edit_type.BATTERY, preview: '0054.png' },
                { type: hmUI.edit_type.HEART, preview: '0072.png' },
                { type: hmUI.edit_type.UVI, preview: '0067.png' },
                { type: hmUI.edit_type.PAI, preview: '0074.png' },
              ],
              count: 6,
              tips_BG: '0073.png',
              tips_x: -186,
              tips_y: 64,
              tips_width: 114,
              tips_margin: 0,
            });

            const editType_2 = editGroup_2.getProperty(hmUI.prop.CURRENT_TYPE);

            switch (editType_2) {
              case hmUI.edit_type.BATTERY:
                hmUI.createWidget(hmUI.widget.IMG, {
                  x: 279,
                  y: 154,
                  src: '0053.png',
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });

                hmUI.createWidget(hmUI.widget.IMG_POINTER, {
                  src: '0049.png',
                  center_x: 357,
                  center_y: 232,
                  x: 21,
                  y: 69,
                  start_angle: 0,
                  end_angle: 360,
                  type: hmUI.data_type.BATTERY,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });
                break;

              case hmUI.edit_type.STEP:
                hmUI.createWidget(hmUI.widget.IMG, {
                  x: 279,
                  y: 154,
                  src: '0048.png',
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });

                hmUI.createWidget(hmUI.widget.IMG_POINTER, {
                  src: '0049.png',
                  center_x: 359,
                  center_y: 232,
                  x: 21,
                  y: 69,
                  start_angle: 0,
                  end_angle: 360,
                  type: hmUI.data_type.STEP,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });
                break;

              case hmUI.edit_type.CAL:
                hmUI.createWidget(hmUI.widget.IMG, {
                  x: 279,
                  y: 156,
                  src: '0051.png',
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });

                hmUI.createWidget(hmUI.widget.IMG_POINTER, {
                  src: '0049.png',
                  center_x: 357,
                  center_y: 232,
                  x: 21,
                  y: 69,
                  start_angle: 0,
                  end_angle: 360,
                  type: hmUI.data_type.CAL,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });
                break;

              case hmUI.edit_type.HEART:
                hmUI.createWidget(hmUI.widget.IMG, {
                  x: 279,
                  y: 156,
                  src: '0071.png',
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });

                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                  x: 335,
                  y: 264,
                  font_array: ["0035.png","0036.png","0037.png","0038.png","0039.png","0040.png","0041.png","0042.png","0043.png","0044.png"],
                  padding: false,
                  h_space: 0,
                  align_h: hmUI.align.CENTER_H,
                  type: hmUI.data_type.HEART,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });

                hmUI.createWidget(hmUI.widget.IMG_POINTER, {
                  src: '0049.png',
                  center_x: 357,
                  center_y: 232,
                  x: 21,
                  y: 69,
                  start_angle: 0,
                  end_angle: 360,
                  type: hmUI.data_type.HEART,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });
                break;

              case hmUI.edit_type.PAI:
                hmUI.createWidget(hmUI.widget.IMG, {
                  x: 279,
                  y: 154,
                  src: '0068.png',
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });

                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                  x: 336,
                  y: 270,
                  font_array: ["0035.png","0036.png","0037.png","0038.png","0039.png","0040.png","0041.png","0042.png","0043.png","0044.png"],
                  padding: false,
                  h_space: 0,
                  align_h: hmUI.align.CENTER_H,
                  type: hmUI.data_type.PAI_WEEKLY,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });

                hmUI.createWidget(hmUI.widget.IMG_POINTER, {
              src: '0049.png',
              center_x: 357,
              center_y: 232,
              x: 21,
              y: 69,
              start_angle: 0,
              end_angle: 360,
              type: hmUI.data_type.PAI_WEEKLY,
              show_level: hmUI.show_level.ONLY_NORMAL,
                });
                break;

              case hmUI.edit_type.UVI:
                 hmUI.createWidget(hmUI.widget.IMG, {
                  x: 279,
                  y: 154,
                  src: '0055.png',
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });

                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                  x: 342,
                  y: 270,
                  font_array: ["0035.png","0036.png","0037.png","0038.png","0039.png","0040.png","0041.png","0042.png","0043.png","0044.png"],
                  padding: false,
                  h_space: 0,
                  align_h: hmUI.align.CENTER_H,
                  type: hmUI.data_type.UVI,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });

                hmUI.createWidget(hmUI.widget.IMG_POINTER, {
                  src: '0049.png',
                  center_x: 357,
                  center_y: 232,
                  x: 21,
                  y: 69,
                  start_angle: 0,
                  end_angle: 360,
                  type: hmUI.data_type.UVI,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });
                break;
            }; // end switch

            editGroup_3 = hmUI.createWidget(hmUI.widget.WATCHFACE_EDIT_GROUP, {
              edit_id: 10023,
              x: 160,
              y: 285,
              w: 149,
              h: 149,
              select_image: '0046.png',
              un_select_image: '0045.png',
              default_type: hmUI.edit_type.STEP,
              optional_types: [
                { type: hmUI.edit_type.STEP, preview: '0050.png' },
                { type: hmUI.edit_type.CAL, preview: '0052.png' },
                { type: hmUI.edit_type.HEART, preview: '0072.png' },
                { type: hmUI.edit_type.BATTERY, preview: '0054.png' },
                { type: hmUI.edit_type.UVI, preview: '0067.png' },
                { type: hmUI.edit_type.PAI, preview: '0074.png' },
              ],
              count: 6,
              tips_BG: '0073.png',
              tips_x: -65,
              tips_y: -65,
              tips_width: 114,
              tips_margin: 0,
            });

            const editType_3 = editGroup_3.getProperty(hmUI.prop.CURRENT_TYPE);

            switch (editType_3) {
              case hmUI.edit_type.BATTERY:
                hmUI.createWidget(hmUI.widget.IMG, {
                  x: 155,
                  y: 278,
                  src: '0053.png',
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });

                hmUI.createWidget(hmUI.widget.IMG_POINTER, {
                  src: '0049.png',
                  center_x: 233,
                  center_y: 356,
                  x: 21,
                  y: 69,
                  start_angle: 0,
                  end_angle: 360,
                  type: hmUI.data_type.BATTERY,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });
                break;

              case hmUI.edit_type.STEP:
                hmUI.createWidget(hmUI.widget.IMG, {
                  x: 155,
                  y: 278,
                  src: '0048.png',
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });

                hmUI.createWidget(hmUI.widget.IMG_POINTER, {
                  src: '0049.png',
                  center_x: 233,
                  center_y: 356,
                  x: 21,
                  y: 69,
                  start_angle: 0,
                  end_angle: 360,
                  type: hmUI.data_type.STEP,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });
                break;

              case hmUI.edit_type.CAL:
                hmUI.createWidget(hmUI.widget.IMG, {
                  x: 155,
                  y: 280,
                  src: '0051.png',
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });

                hmUI.createWidget(hmUI.widget.IMG_POINTER, {
                  src: '0049.png',
                  center_x: 233,
                  center_y: 356,
                  x: 21,
                  y: 69,
                  start_angle: 0,
                  end_angle: 360,
                  type: hmUI.data_type.CAL,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });
                break;

              case hmUI.edit_type.HEART:
                hmUI.createWidget(hmUI.widget.IMG, {
                  x: 155,
                  y: 280,
                  src: '0071.png',
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });

                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                  x: 211,
                  y: 386,
                  font_array: ["0035.png","0036.png","0037.png","0038.png","0039.png","0040.png","0041.png","0042.png","0043.png","0044.png"],
                  padding: false,
                  h_space: 0,
                  align_h: hmUI.align.CENTER_H,
                  type: hmUI.data_type.HEART,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });

                hmUI.createWidget(hmUI.widget.IMG_POINTER, {
                  src: '0049.png',
                  center_x: 233,
                  center_y: 356,
                  x: 21,
                  y: 69,
                  start_angle: 0,
                  end_angle: 360,
                  type: hmUI.data_type.HEART,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });
                break;

              case hmUI.edit_type.PAI:
                hmUI.createWidget(hmUI.widget.IMG, {
                  x: 155,
                  y: 279,
                  src: '0068.png',
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });

                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                  x: 203,
                  y: 387,
                  font_array: ["0056.png","0057.png","0058.png","0059.png","0060.png","0061.png","0062.png","0063.png","0064.png","0065.png"],
                  padding: false,
                  h_space: 0,
                  align_h: hmUI.align.CENTER_H,
                  type: hmUI.data_type.PAI_WEEKLY,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });

                hmUI.createWidget(hmUI.widget.IMG_POINTER, {
              src: '0049.png',
              center_x: 233,
              center_y: 356,
              x: 21,
              y: 69,
              start_angle: 0,
              end_angle: 360,
              type: hmUI.data_type.PAI_WEEKLY,
              show_level: hmUI.show_level.ONLY_NORMAL,
                });
                break;

              case hmUI.edit_type.UVI:
                 hmUI.createWidget(hmUI.widget.IMG, {
                  x: 155,
                  y: 279,
                  src: '0055.png',
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });

                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                  x: 219,
                  y: 390,
                  font_array: ["0035.png","0036.png","0037.png","0038.png","0039.png","0040.png","0041.png","0042.png","0043.png","0044.png"],
                  padding: false,
                  h_space: 0,
                  align_h: hmUI.align.CENTER_H,
                  type: hmUI.data_type.UVI,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });

                hmUI.createWidget(hmUI.widget.IMG_POINTER, {
                  src: '0049.png',
                  center_x: 233,
                  center_y: 356,
                  x: 21,
                  y: 69,
                  start_angle: 0,
                  end_angle: 360,
                  type: hmUI.data_type.UVI,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });
                break;
            }; // end switch

            mask = hmUI.createWidget(hmUI.widget.WATCHFACE_EDIT_MASK, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: '0075.png',
              show_level: hmUI.show_level.ONLY_EDIT,
            });

            fg_mask = hmUI.createWidget(hmUI.widget.WATCHFACE_EDIT_FG_MASK, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: '0076.png',
              show_level: hmUI.show_level.ONLY_EDIT,
            });

            const pointerEdit = hmUI.createWidget(hmUI.widget.WATCHFACE_EDIT_POINTER, {
              edit_id: 1003,
              x: 0,
              y: 0,
              config: [
                {
                  id: 1,
                  second: {
                    centerX: 233,
                    centerY: 233,
                    posX: 28,
                    posY: 233,
                    path: '0005.png',
                  },
                  hour: {
                    centerX: 233,
                    centerY: 233,
                    posX: 28,
                    posY: 160,
                    path: '0003.png',
                  },
                  minute: {
                    centerX: 233,
                    centerY: 233,
                    posX: 28,
                    posY: 238,
                    path: '0004.png',
                  },
                },
              ],
              count: 1,
              default_id: 1,
              fg: '.png',
              tips_x: 0,
              tips_y: 0,
              tips_bg: '.png',
            });
            const screenTypeForETP = hmSetting.getScreenType();
            const aodModel = screenTypeForETP == hmSetting.screen_type.AOD;
            const pointerProp = pointerEdit.getProperty(hmUI.prop.CURRENT_CONFIG, !aodModel);
            editableTimePointers = hmUI.createWidget(hmUI.widget.TIME_POINTER, pointerProp);


                //dynamic modify end
            },
            onInit() {
                n.log("index page.js on init invoke")
            },
            build() {
                this.init_view(),
                n.log("index page.js on ready invoke")
            },
            onDestroy() {
                n.log("index page.js on destroy invoke")
            }
        })
    }
    )()
} catch (e) {
    console.log("Mini Program Error", e),
    e && e.stack && e.stack.split(/\n/).forEach((e=>console.log("error stack", e)))
}
