    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        //const logger = Logger.getLogger('watchface_SashaCX75');
        const logger = DeviceRuntimeCore.HmLogger.getLogger('watchface_SashaCX75')
        //end of ignored block

        const SUF = ["", "_a", "_b", "_c", "_d", "_e"];
        const NAMES = ["GOLD", "ORANGE", "GREEN", "CYAN", "PINK", "CREAM"];
        const TD = ["Time_0.png","Time_1.png","Time_2.png","Time_3.png","Time_4.png","Time_5.png","Time_6.png","Time_7.png","Time_8.png","Time_9.png"];
        const AD = ["Act_0.png","Act_1.png","Act_2.png","Act_3.png","Act_4.png","Act_5.png","Act_6.png","Act_7.png","Act_8.png","Act_9.png"];
        const MONTH_IMGS = [], DAY_IMGS = [], WEEK_IMGS = [];
        for (let i = 1; i <= 12; i++) MONTH_IMGS.push('Month_' + i + '.png');
        for (let i = 1; i <= 31; i++) DAY_IMGS.push('Day_' + i + '.png');
        for (let i = 1; i <= 7; i++) WEEK_IMGS.push('Week_' + i + '.png');

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                const themed = [];

                // ---------- normal screen ----------
                hmUI.createWidget(hmUI.widget.IMG, { x: 0, y: 0, w: 466, h: 466, src: 'Bg.png', show_level: hmUI.show_level.ONLY_NORMAL });

                hmUI.createWidget(hmUI.widget.IMG_TIME, {
                  hour_startX: 115, hour_startY: 94, hour_array: TD, hour_zero: 1, hour_space: 0, hour_angle: 0, hour_align: hmUI.align.LEFT,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });
                hmUI.createWidget(hmUI.widget.IMG_TIME, {
                  minute_startX: 115, minute_startY: 235, minute_array: TD, minute_zero: 1, minute_space: 0, minute_angle: 0, minute_follow: 0, minute_align: hmUI.align.LEFT,
                  am_x: 32, am_y: 213, am_sc_path: 'AM.png', am_en_path: 'AM.png',
                  pm_x: 32, pm_y: 213, pm_sc_path: 'PM.png', pm_en_path: 'PM.png',
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });

                const vline = hmUI.createWidget(hmUI.widget.IMG, { x: 263, y: 98, src: 'Vline.png', show_level: hmUI.show_level.ONLY_NORMAL });
                themed.push({ w: vline, base: 'Vline' });
                const hline = hmUI.createWidget(hmUI.widget.IMG, { x: 280, y: 228, src: 'Hline.png', show_level: hmUI.show_level.ONLY_NORMAL });
                themed.push({ w: hline, base: 'Hline' });

                hmUI.createWidget(hmUI.widget.IMG_DATE, {
                  month_startX: 267, month_startY: 102,
                  month_sc_array: MONTH_IMGS, month_tc_array: MONTH_IMGS, month_en_array: MONTH_IMGS,
                  month_is_character: true,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });
                hmUI.createWidget(hmUI.widget.IMG_DATE, {
                  day_startX: 277, day_startY: 156,
                  day_sc_array: DAY_IMGS, day_tc_array: DAY_IMGS, day_en_array: DAY_IMGS,
                  day_is_character: true,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });
                hmUI.createWidget(hmUI.widget.IMG_WEEK, {
                  x: 144, y: 394, week_en: WEEK_IMGS, week_tc: WEEK_IMGS, week_sc: WEEK_IMGS,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });

                // stat icons
                const icoStep = hmUI.createWidget(hmUI.widget.IMG, { x: 285, y: 241, src: 'IcoStep.png', show_level: hmUI.show_level.ONLY_NORMAL });
                themed.push({ w: icoStep, base: 'IcoStep' });
                const icoHeart = hmUI.createWidget(hmUI.widget.IMG, { x: 285, y: 288, src: 'IcoHeart.png', show_level: hmUI.show_level.ONLY_NORMAL });
                themed.push({ w: icoHeart, base: 'IcoHeart' });
                const icoBatt = hmUI.createWidget(hmUI.widget.IMG, { x: 285, y: 336, src: 'IcoBatt.png', show_level: hmUI.show_level.ONLY_NORMAL });
                themed.push({ w: icoBatt, base: 'IcoBatt' });

                // stat numbers
                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                  x: 313, y: 242, w: 130, h: 34, font_array: AD, padding: false, h_space: 1, align_h: hmUI.align.CENTER_H,
                  type: hmUI.data_type.STEP, show_level: hmUI.show_level.ONLY_NORMAL,
                });
                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                  x: 313, y: 289, w: 130, h: 34, font_array: AD, padding: false, h_space: 1, invalid_image: 'Act_dash.png', align_h: hmUI.align.CENTER_H,
                  type: hmUI.data_type.HEART, show_level: hmUI.show_level.ONLY_NORMAL,
                });
                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                  x: 313, y: 337, w: 130, h: 34, font_array: AD, padding: false, h_space: 1,
                  unit_sc: 'Act_pct.png', unit_tc: 'Act_pct.png', unit_en: 'Act_pct.png',
                  align_h: hmUI.align.CENTER_H,
                  type: hmUI.data_type.BATTERY, show_level: hmUI.show_level.ONLY_NORMAL,
                });

                // ---------- always-on display ----------
                hmUI.createWidget(hmUI.widget.IMG, { x: 0, y: 0, w: 466, h: 466, src: 'Bg.png', show_level: hmUI.show_level.ONLY_AOD });
                hmUI.createWidget(hmUI.widget.IMG_TIME, {
                  hour_startX: 115, hour_startY: 94, hour_array: TD, hour_zero: 1, hour_space: 0, hour_angle: 0, hour_align: hmUI.align.LEFT,
                  show_level: hmUI.show_level.ONLY_AOD,
                });
                hmUI.createWidget(hmUI.widget.IMG_TIME, {
                  minute_startX: 115, minute_startY: 235, minute_array: TD, minute_zero: 1, minute_space: 0, minute_angle: 0, minute_follow: 0, minute_align: hmUI.align.LEFT,
                  show_level: hmUI.show_level.ONLY_AOD,
                });

                // ---------- colour theme ----------
                let wfId = 'digital_minimalist';
                try { wfId = hmApp.packageInfo().watchfaceId; } catch (e) {}
                let themeIndex = 0;
                try {
                  const saved = hmFS.SysProGetInt('digMinTheme1_' + wfId);
                  if (saved !== undefined && saved !== null && saved >= 0 && saved < SUF.length) themeIndex = saved;
                } catch (e) {}
                function applyTheme(i) {
                  themed.forEach(function (o) {
                    try { o.w.setProperty(hmUI.prop.SRC, o.base + SUF[i] + '.png'); } catch (e) {}
                  });
                }
                applyTheme(themeIndex);

                // ---------- tap areas ----------
                hmUI.createWidget(hmUI.widget.IMG_CLICK, { x: 280, y: 236, w: 167, h: 46, type: hmUI.data_type.STEP, show_level: hmUI.show_level.ONLY_NORMAL });
                hmUI.createWidget(hmUI.widget.IMG_CLICK, { x: 280, y: 283, w: 167, h: 46, type: hmUI.data_type.HEART, show_level: hmUI.show_level.ONLY_NORMAL });
                hmUI.createWidget(hmUI.widget.IMG_CLICK, { x: 280, y: 331, w: 167, h: 46, type: hmUI.data_type.BATTERY, show_level: hmUI.show_level.ONLY_NORMAL });

                hmUI.createWidget(hmUI.widget.BUTTON, {
                  x: 280, y: 100, w: 167, h: 122, text: '', color: 0xFFFF8C00, text_size: 25,
                  press_src: '0_Empty.png', normal_src: '0_Empty.png',
                  click_func: (button_widget) => {
                    hmApp.startApp({ url: 'ScheduleCalScreen', native: true });
                  },
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });

                // tap the clock to cycle colours
                hmUI.createWidget(hmUI.widget.BUTTON, {
                  x: 20, y: 90, w: 240, h: 275, text: '', color: 0xFFFF8C00, text_size: 25,
                  press_src: '0_Empty.png', normal_src: '0_Empty.png',
                  click_func: (button_widget) => {
                    themeIndex = (themeIndex + 1) % SUF.length;
                    try { hmFS.SysProSetInt('digMinTheme1_' + wfId, themeIndex); } catch (e) {}
                    applyTheme(themeIndex);
                    try { hmUI.showToast({ text: NAMES[themeIndex] }); } catch (e) {}
                  },
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}