﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        //const logger = Logger.getLogger('watchface_SashaCX75');
        const logger = DeviceRuntimeCore.HmLogger.getLogger('watchface_SashaCX75')
        //end of ignored block

        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_step_linear_scale = ''
        let normal_step_linear_scale_pointer_img = ''
        let normal_step_current_text_img = ''
        let normal_distance_text_text_img = ''
        let normal_heart_rate_text_text_img = ''
        let normal_battery_text_text_img = ''
        let normal_battery_image_progress_img_level = ''
        let normal_frame_animation_1 = ''
        let normal_system_disconnect_img = ''
        let normal_system_clock_img = ''
        let normal_humidity_text_text_img = ''
        let normal_weather_image_progress_img_level = ''
        let normal_temperature_high_text_img = ''
        let normal_temperature_low_text_img = ''
        let normal_temperature_current_text_img = ''
        let normal_date_img_date_month_img = ''
        let normal_date_img_date_day = ''
        let normal_date_img_date_week_img = ''
        let normal_digital_clock_img_time = ''
        let normal_analog_clock_time_pointer_second = ''
        let idle_background_bg_img = ''
        let idle_step_linear_scale = ''
        let idle_step_linear_scale_pointer_img = ''
        let idle_step_current_text_img = ''
        let idle_distance_text_text_img = ''
        let idle_heart_rate_text_text_img = ''
        let idle_battery_text_text_img = ''
        let idle_battery_image_progress_img_level = ''
        let idle_system_disconnect_img = ''
        let idle_system_clock_img = ''
        let idle_humidity_text_text_img = ''
        let idle_weather_image_progress_img_level = ''
        let idle_temperature_high_text_img = ''
        let idle_temperature_low_text_img = ''
        let idle_temperature_current_text_img = ''
        let idle_date_img_date_month_img = ''
        let idle_date_img_date_day = ''
        let idle_date_img_date_week_img = ''
        let idle_digital_clock_img_time = ''


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            console.log('Watch_Face.ScreenNormal');
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 466,
              h: 466,
              src: 'Quadrante_00.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            let screenType = hmSetting.getScreenType();
            if (screenType != hmSetting.screen_type.AOD) {
              normal_step_linear_scale = hmUI.createWidget(hmUI.widget.FILL_RECT);

            normal_step_linear_scale.setAlpha(154);
            };

            normal_step_linear_scale_pointer_img = hmUI.createWidget(hmUI.widget.IMG);
            // normal_step_linear_scale = hmUI.createWidget(hmUI.widget.Linear_Scale, {
              // start_x: 129,
              // start_y: 401,
              // color: 0xFFF8EF87,
              // pointer: 'Puntatore_00.png',
              // lenght: 212,
              // line_width: 3,
              // line_cap: Flat,
              // vertical: False,
              // mirror: False,
              // inversion: False,
              // alpha: 154,
              // type: hmUI.data_type.STEP,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });
            
            const step = hmSensor.createSensor(hmSensor.id.STEP);
            step.addEventListener(hmSensor.event.CHANGE, function() {
              scale_call();
            });

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 179,
              y: 356,
              font_array: ["Att_00.png","Att_01.png","Att_02.png","Att_03.png","Att_04.png","Att_05.png","Att_06.png","Att_07.png","Att_08.png","Att_09.png"],
              padding: false,
              h_space: 4,
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_distance_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 253,
              y: 302,
              font_array: ["Att_00.png","Att_01.png","Att_02.png","Att_03.png","Att_04.png","Att_05.png","Att_06.png","Att_07.png","Att_08.png","Att_09.png"],
              padding: false,
              h_space: 4,
              dot_image: 'Att_12.png',
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.DISTANCE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 317,
              y: 248,
              font_array: ["Att_00.png","Att_01.png","Att_02.png","Att_03.png","Att_04.png","Att_05.png","Att_06.png","Att_07.png","Att_08.png","Att_09.png"],
              padding: false,
              h_space: 4,
              invalid_image: 'Att_13.png',
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 50,
              y: 271,
              font_array: ["Att_00.png","Att_01.png","Att_02.png","Att_03.png","Att_04.png","Att_05.png","Att_06.png","Att_07.png","Att_08.png","Att_09.png"],
              padding: false,
              h_space: 4,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 80,
              y: 315,
              image_array: ["Batt_00.png","Batt_01.png","Batt_02.png","Batt_03.png","Batt_04.png","Batt_05.png","Batt_06.png","Batt_07.png"],
              image_length: 8,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_frame_animation_1 = hmUI.createWidget(hmUI.widget.IMG_ANIM, {
              x: -17,
              y: -7,
              anim_path: "animation",
              anim_ext: "png",
              anim_prefix: "Anim",
              anim_fps: 2,
              anim_size: 2,
              repeat_count: 0,
              anim_repeat: true,
              anim_status:hmUI.anim_status.START,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 397,
              y: 122,
              src: 'Off.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 417,
              y: 223,
              src: 'AL.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_humidity_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 340,
              y: 128,
              font_array: ["Sist_00.png","Sist_01.png","Sist_02.png","Sist_03.png","Sist_04.png","Sist_05.png","Sist_06.png","Sist_07.png","Sist_08.png","Sist_09.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HUMIDITY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 101,
              y: 57,
              image_array: ["weatherd_00.png","weatherd_01.png","weatherd_02.png","weatherd_03.png","weatherd_04.png","weatherd_05.png","weatherd_06.png","weatherd_07.png","weatherd_08.png","weatherd_09.png","weatherd_10.png","weatherd_11.png","weatherd_12.png","weatherd_13.png","weatherd_14.png","weatherd_15.png","weatherd_16.png","weatherd_17.png","weatherd_18.png","weatherd_19.png","weatherd_20.png","weatherd_21.png","weatherd_22.png","weatherd_23.png","weatherd_24.png","weatherd_25.png","weatherd_26.png","weatherd_27.png","weatherd_28.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_high_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 261,
              y: 128,
              font_array: ["Sist_00.png","Sist_01.png","Sist_02.png","Sist_03.png","Sist_04.png","Sist_05.png","Sist_06.png","Sist_07.png","Sist_08.png","Sist_09.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'Sist_12.png',
              unit_tc: 'Sist_12.png',
              unit_en: 'Sist_12.png',
              imperial_unit_sc: 'Sist_12.png',
              imperial_unit_tc: 'Sist_12.png',
              imperial_unit_en: 'Sist_12.png',
              negative_image: 'Sist_10.png',
              invalid_image: 'Sist_11.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_HIGH,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            const temperatureUnit = hmSetting.getTemperatureUnit();
            //#region temperatureUnit
            if (temperatureUnit == 1) {
              normal_temperature_high_text_img.setProperty(hmUI.prop.MORE, {
                x: 261,
                y: 128,
                font_array: ["Sist_00.png","Sist_01.png","Sist_02.png","Sist_03.png","Sist_04.png","Sist_05.png","Sist_06.png","Sist_07.png","Sist_08.png","Sist_09.png"],
                padding: false,
                h_space: 0,
                unit_sc: 'Sist_12.png',
                unit_tc: 'Sist_12.png',
                unit_en: 'Sist_12.png',
                imperial_unit_sc: 'Sist_12.png',
                imperial_unit_tc: 'Sist_12.png',
                imperial_unit_en: 'Sist_12.png',
                negative_image: 'Sist_10.png',
                invalid_image: 'Sist_11.png',
                align_h: hmUI.align.CENTER_H,
                type: hmUI.data_type.WEATHER_HIGH,
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
            };
            //#endregion

            normal_temperature_low_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 189,
              y: 128,
              font_array: ["Sist_00.png","Sist_01.png","Sist_02.png","Sist_03.png","Sist_04.png","Sist_05.png","Sist_06.png","Sist_07.png","Sist_08.png","Sist_09.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'Sist_12.png',
              unit_tc: 'Sist_12.png',
              unit_en: 'Sist_12.png',
              imperial_unit_sc: 'Sist_12.png',
              imperial_unit_tc: 'Sist_12.png',
              imperial_unit_en: 'Sist_12.png',
              negative_image: 'Sist_10.png',
              invalid_image: 'Sist_11.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_LOW,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            //#region temperatureUnit
            if (temperatureUnit == 1) {
              normal_temperature_low_text_img.setProperty(hmUI.prop.MORE, {
                x: 189,
                y: 128,
                font_array: ["Sist_00.png","Sist_01.png","Sist_02.png","Sist_03.png","Sist_04.png","Sist_05.png","Sist_06.png","Sist_07.png","Sist_08.png","Sist_09.png"],
                padding: false,
                h_space: 0,
                unit_sc: 'Sist_12.png',
                unit_tc: 'Sist_12.png',
                unit_en: 'Sist_12.png',
                imperial_unit_sc: 'Sist_12.png',
                imperial_unit_tc: 'Sist_12.png',
                imperial_unit_en: 'Sist_12.png',
                negative_image: 'Sist_10.png',
                invalid_image: 'Sist_11.png',
                align_h: hmUI.align.CENTER_H,
                type: hmUI.data_type.WEATHER_LOW,
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
            };
            //#endregion

            normal_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 52,
              y: 113,
              font_array: ["Att_00.png","Att_01.png","Att_02.png","Att_03.png","Att_04.png","Att_05.png","Att_06.png","Att_07.png","Att_08.png","Att_09.png"],
              padding: false,
              h_space: 2,
              unit_sc: 'Att_11.png',
              unit_tc: 'Att_11.png',
              unit_en: 'Att_11.png',
              imperial_unit_sc: 'Att_11.png',
              imperial_unit_tc: 'Att_11.png',
              imperial_unit_en: 'Att_11.png',
              negative_image: 'Att_10.png',
              invalid_image: 'Att_13.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            //#region temperatureUnit
            if (temperatureUnit == 1) {
              normal_temperature_current_text_img.setProperty(hmUI.prop.MORE, {
                x: 52,
                y: 113,
                font_array: ["Att_00.png","Att_01.png","Att_02.png","Att_03.png","Att_04.png","Att_05.png","Att_06.png","Att_07.png","Att_08.png","Att_09.png"],
                padding: false,
                h_space: 2,
                unit_sc: 'Att_11.png',
                unit_tc: 'Att_11.png',
                unit_en: 'Att_11.png',
                imperial_unit_sc: 'Att_11.png',
                imperial_unit_tc: 'Att_11.png',
                imperial_unit_en: 'Att_11.png',
                negative_image: 'Att_10.png',
                invalid_image: 'Att_13.png',
                align_h: hmUI.align.CENTER_H,
                type: hmUI.data_type.WEATHER_CURRENT,
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
            };
            //#endregion

            normal_date_img_date_month_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 267,
              month_startY: 77,
              month_sc_array: ["Mese_00.png","Mese_01.png","Mese_02.png","Mese_03.png","Mese_04.png","Mese_05.png","Mese_06.png","Mese_07.png","Mese_08.png","Mese_09.png","Mese_10.png","Mese_11.png"],
              month_tc_array: ["Mese_00.png","Mese_01.png","Mese_02.png","Mese_03.png","Mese_04.png","Mese_05.png","Mese_06.png","Mese_07.png","Mese_08.png","Mese_09.png","Mese_10.png","Mese_11.png"],
              month_en_array: ["Mese_00.png","Mese_01.png","Mese_02.png","Mese_03.png","Mese_04.png","Mese_05.png","Mese_06.png","Mese_07.png","Mese_08.png","Mese_09.png","Mese_10.png","Mese_11.png"],
              month_is_character: true ,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 178,
              day_startY: 77,
              day_sc_array: ["Att_00.png","Att_01.png","Att_02.png","Att_03.png","Att_04.png","Att_05.png","Att_06.png","Att_07.png","Att_08.png","Att_09.png"],
              day_tc_array: ["Att_00.png","Att_01.png","Att_02.png","Att_03.png","Att_04.png","Att_05.png","Att_06.png","Att_07.png","Att_08.png","Att_09.png"],
              day_en_array: ["Att_00.png","Att_01.png","Att_02.png","Att_03.png","Att_04.png","Att_05.png","Att_06.png","Att_07.png","Att_08.png","Att_09.png"],
              day_zero: 1,
              day_space: 4,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 177,
              y: 31,
              week_en: ["Giorno_00.png","Giorno_01.png","Giorno_02.png","Giorno_03.png","Giorno_04.png","Giorno_05.png","Giorno_06.png"],
              week_tc: ["Giorno_00.png","Giorno_01.png","Giorno_02.png","Giorno_03.png","Giorno_04.png","Giorno_05.png","Giorno_06.png"],
              week_sc: ["Giorno_00.png","Giorno_01.png","Giorno_02.png","Giorno_03.png","Giorno_04.png","Giorno_05.png","Giorno_06.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 41,
              hour_startY: 157,
              hour_array: ["Ore_00.png","Ore_01.png","Ore_02.png","Ore_03.png","Ore_04.png","Ore_05.png","Ore_06.png","Ore_07.png","Ore_08.png","Ore_09.png"],
              hour_zero: 1,
              hour_space: 6,
              hour_angle: 0,
              hour_align: hmUI.align.CENTER_H,

              minute_startX: 271,
              minute_startY: 157,
              minute_array: ["Minuti_00.png","Minuti_01.png","Minuti_02.png","Minuti_03.png","Minuti_04.png","Minuti_05.png","Minuti_06.png","Minuti_07.png","Minuti_08.png","Minuti_09.png"],
              minute_zero: 1,
              minute_space: 6,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.CENTER_H,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_second = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              second_path: 'Puntatore_00.png',
              second_centerX: 234,
              second_centerY: 233,
              second_posX: 6,
              second_posY: 231,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            console.log('Watch_Face.ScreenAOD');
            idle_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 466,
              h: 466,
              src: 'Quadrante_00.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            if (screenType == hmSetting.screen_type.AOD) {
              idle_step_linear_scale = hmUI.createWidget(hmUI.widget.FILL_RECT);

            idle_step_linear_scale.setAlpha(154);
            };

            idle_step_linear_scale_pointer_img = hmUI.createWidget(hmUI.widget.IMG);
            // idle_step_linear_scale = hmUI.createWidget(hmUI.widget.Linear_Scale, {
              // start_x: 129,
              // start_y: 401,
              // color: 0xFFF8EF87,
              // pointer: 'Puntatore_00.png',
              // lenght: 212,
              // line_width: 3,
              // line_cap: Flat,
              // vertical: False,
              // mirror: False,
              // inversion: False,
              // alpha: 154,
              // type: hmUI.data_type.STEP,
              // show_level: hmUI.show_level.ONLY_AOD,
            // });

            idle_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 179,
              y: 356,
              font_array: ["Att_00.png","Att_01.png","Att_02.png","Att_03.png","Att_04.png","Att_05.png","Att_06.png","Att_07.png","Att_08.png","Att_09.png"],
              padding: false,
              h_space: 4,
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_distance_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 253,
              y: 302,
              font_array: ["Att_00.png","Att_01.png","Att_02.png","Att_03.png","Att_04.png","Att_05.png","Att_06.png","Att_07.png","Att_08.png","Att_09.png"],
              padding: false,
              h_space: 4,
              dot_image: 'Att_12.png',
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.DISTANCE,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 317,
              y: 248,
              font_array: ["Att_00.png","Att_01.png","Att_02.png","Att_03.png","Att_04.png","Att_05.png","Att_06.png","Att_07.png","Att_08.png","Att_09.png"],
              padding: false,
              h_space: 4,
              invalid_image: 'Att_13.png',
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 50,
              y: 271,
              font_array: ["Att_00.png","Att_01.png","Att_02.png","Att_03.png","Att_04.png","Att_05.png","Att_06.png","Att_07.png","Att_08.png","Att_09.png"],
              padding: false,
              h_space: 4,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_battery_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 80,
              y: 315,
              image_array: ["Batt_00.png","Batt_01.png","Batt_02.png","Batt_03.png","Batt_04.png","Batt_05.png","Batt_06.png","Batt_07.png"],
              image_length: 8,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 397,
              y: 122,
              src: 'Off.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 417,
              y: 223,
              src: 'AL.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_humidity_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 340,
              y: 128,
              font_array: ["Sist_00.png","Sist_01.png","Sist_02.png","Sist_03.png","Sist_04.png","Sist_05.png","Sist_06.png","Sist_07.png","Sist_08.png","Sist_09.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HUMIDITY,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 101,
              y: 57,
              image_array: ["weatherd_00.png","weatherd_01.png","weatherd_02.png","weatherd_03.png","weatherd_04.png","weatherd_05.png","weatherd_06.png","weatherd_07.png","weatherd_08.png","weatherd_09.png","weatherd_10.png","weatherd_11.png","weatherd_12.png","weatherd_13.png","weatherd_14.png","weatherd_15.png","weatherd_16.png","weatherd_17.png","weatherd_18.png","weatherd_19.png","weatherd_20.png","weatherd_21.png","weatherd_22.png","weatherd_23.png","weatherd_24.png","weatherd_25.png","weatherd_26.png","weatherd_27.png","weatherd_28.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_temperature_high_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 261,
              y: 128,
              font_array: ["Sist_00.png","Sist_01.png","Sist_02.png","Sist_03.png","Sist_04.png","Sist_05.png","Sist_06.png","Sist_07.png","Sist_08.png","Sist_09.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'Sist_12.png',
              unit_tc: 'Sist_12.png',
              unit_en: 'Sist_12.png',
              imperial_unit_sc: 'Sist_12.png',
              imperial_unit_tc: 'Sist_12.png',
              imperial_unit_en: 'Sist_12.png',
              negative_image: 'Sist_10.png',
              invalid_image: 'Sist_11.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_HIGH,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            //#region temperatureUnit
            if (temperatureUnit == 1) {
              idle_temperature_high_text_img.setProperty(hmUI.prop.MORE, {
                x: 261,
                y: 128,
                font_array: ["Sist_00.png","Sist_01.png","Sist_02.png","Sist_03.png","Sist_04.png","Sist_05.png","Sist_06.png","Sist_07.png","Sist_08.png","Sist_09.png"],
                padding: false,
                h_space: 0,
                unit_sc: 'Sist_12.png',
                unit_tc: 'Sist_12.png',
                unit_en: 'Sist_12.png',
                imperial_unit_sc: 'Sist_12.png',
                imperial_unit_tc: 'Sist_12.png',
                imperial_unit_en: 'Sist_12.png',
                negative_image: 'Sist_10.png',
                invalid_image: 'Sist_11.png',
                align_h: hmUI.align.CENTER_H,
                type: hmUI.data_type.WEATHER_HIGH,
                show_level: hmUI.show_level.ONLY_AOD,
              });
            };
            //#endregion

            idle_temperature_low_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 189,
              y: 128,
              font_array: ["Sist_00.png","Sist_01.png","Sist_02.png","Sist_03.png","Sist_04.png","Sist_05.png","Sist_06.png","Sist_07.png","Sist_08.png","Sist_09.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'Sist_12.png',
              unit_tc: 'Sist_12.png',
              unit_en: 'Sist_12.png',
              imperial_unit_sc: 'Sist_12.png',
              imperial_unit_tc: 'Sist_12.png',
              imperial_unit_en: 'Sist_12.png',
              negative_image: 'Sist_10.png',
              invalid_image: 'Sist_11.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_LOW,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            //#region temperatureUnit
            if (temperatureUnit == 1) {
              idle_temperature_low_text_img.setProperty(hmUI.prop.MORE, {
                x: 189,
                y: 128,
                font_array: ["Sist_00.png","Sist_01.png","Sist_02.png","Sist_03.png","Sist_04.png","Sist_05.png","Sist_06.png","Sist_07.png","Sist_08.png","Sist_09.png"],
                padding: false,
                h_space: 0,
                unit_sc: 'Sist_12.png',
                unit_tc: 'Sist_12.png',
                unit_en: 'Sist_12.png',
                imperial_unit_sc: 'Sist_12.png',
                imperial_unit_tc: 'Sist_12.png',
                imperial_unit_en: 'Sist_12.png',
                negative_image: 'Sist_10.png',
                invalid_image: 'Sist_11.png',
                align_h: hmUI.align.CENTER_H,
                type: hmUI.data_type.WEATHER_LOW,
                show_level: hmUI.show_level.ONLY_AOD,
              });
            };
            //#endregion

            idle_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 52,
              y: 113,
              font_array: ["Att_00.png","Att_01.png","Att_02.png","Att_03.png","Att_04.png","Att_05.png","Att_06.png","Att_07.png","Att_08.png","Att_09.png"],
              padding: false,
              h_space: 2,
              unit_sc: 'Att_11.png',
              unit_tc: 'Att_11.png',
              unit_en: 'Att_11.png',
              imperial_unit_sc: 'Att_11.png',
              imperial_unit_tc: 'Att_11.png',
              imperial_unit_en: 'Att_11.png',
              negative_image: 'Att_10.png',
              invalid_image: 'Att_13.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            //#region temperatureUnit
            if (temperatureUnit == 1) {
              idle_temperature_current_text_img.setProperty(hmUI.prop.MORE, {
                x: 52,
                y: 113,
                font_array: ["Att_00.png","Att_01.png","Att_02.png","Att_03.png","Att_04.png","Att_05.png","Att_06.png","Att_07.png","Att_08.png","Att_09.png"],
                padding: false,
                h_space: 2,
                unit_sc: 'Att_11.png',
                unit_tc: 'Att_11.png',
                unit_en: 'Att_11.png',
                imperial_unit_sc: 'Att_11.png',
                imperial_unit_tc: 'Att_11.png',
                imperial_unit_en: 'Att_11.png',
                negative_image: 'Att_10.png',
                invalid_image: 'Att_13.png',
                align_h: hmUI.align.CENTER_H,
                type: hmUI.data_type.WEATHER_CURRENT,
                show_level: hmUI.show_level.ONLY_AOD,
              });
            };
            //#endregion

            idle_date_img_date_month_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 267,
              month_startY: 77,
              month_sc_array: ["Mese_00.png","Mese_01.png","Mese_02.png","Mese_03.png","Mese_04.png","Mese_05.png","Mese_06.png","Mese_07.png","Mese_08.png","Mese_09.png","Mese_10.png","Mese_11.png"],
              month_tc_array: ["Mese_00.png","Mese_01.png","Mese_02.png","Mese_03.png","Mese_04.png","Mese_05.png","Mese_06.png","Mese_07.png","Mese_08.png","Mese_09.png","Mese_10.png","Mese_11.png"],
              month_en_array: ["Mese_00.png","Mese_01.png","Mese_02.png","Mese_03.png","Mese_04.png","Mese_05.png","Mese_06.png","Mese_07.png","Mese_08.png","Mese_09.png","Mese_10.png","Mese_11.png"],
              month_is_character: true ,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 178,
              day_startY: 77,
              day_sc_array: ["Att_00.png","Att_01.png","Att_02.png","Att_03.png","Att_04.png","Att_05.png","Att_06.png","Att_07.png","Att_08.png","Att_09.png"],
              day_tc_array: ["Att_00.png","Att_01.png","Att_02.png","Att_03.png","Att_04.png","Att_05.png","Att_06.png","Att_07.png","Att_08.png","Att_09.png"],
              day_en_array: ["Att_00.png","Att_01.png","Att_02.png","Att_03.png","Att_04.png","Att_05.png","Att_06.png","Att_07.png","Att_08.png","Att_09.png"],
              day_zero: 1,
              day_space: 4,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 177,
              y: 31,
              week_en: ["Giorno_00.png","Giorno_01.png","Giorno_02.png","Giorno_03.png","Giorno_04.png","Giorno_05.png","Giorno_06.png"],
              week_tc: ["Giorno_00.png","Giorno_01.png","Giorno_02.png","Giorno_03.png","Giorno_04.png","Giorno_05.png","Giorno_06.png"],
              week_sc: ["Giorno_00.png","Giorno_01.png","Giorno_02.png","Giorno_03.png","Giorno_04.png","Giorno_05.png","Giorno_06.png"],
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 41,
              hour_startY: 157,
              hour_array: ["Ore_00.png","Ore_01.png","Ore_02.png","Ore_03.png","Ore_04.png","Ore_05.png","Ore_06.png","Ore_07.png","Ore_08.png","Ore_09.png"],
              hour_zero: 1,
              hour_space: 6,
              hour_angle: 0,
              hour_align: hmUI.align.CENTER_H,

              minute_startX: 271,
              minute_startY: 157,
              minute_array: ["Minuti_00.png","Minuti_01.png","Minuti_02.png","Minuti_03.png","Minuti_04.png","Minuti_05.png","Minuti_06.png","Minuti_07.png","Minuti_08.png","Minuti_09.png"],
              minute_zero: 1,
              minute_space: 6,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.CENTER_H,

              show_level: hmUI.show_level.ONLY_AOD,
            });

            function scale_call() {
              console.log('scale_call()');

                console.log('update scales STEP');
                
                let valueStep = step.current;
                let targetStep = step.target;
                let progressStep = valueStep/targetStep;
                if (progressStep > 1) progressStep = 1;
                let progress_ls_normal_step = progressStep;

                if (screenType != hmSetting.screen_type.AOD) {

                  // normal_step_linear_scale
                  // initial parameters
                  let start_x_normal_step = 129;
                  let start_y_normal_step = 401;
                  let lenght_ls_normal_step = 212;
                  let line_width_ls_normal_step = 3;
                  let color_ls_normal_step = 0xFFF8EF87;
                  
                  // calculated parameters
                  let start_x_normal_step_draw = start_x_normal_step;
                  let start_y_normal_step_draw = start_y_normal_step;
                  lenght_ls_normal_step = lenght_ls_normal_step * progress_ls_normal_step;
                  let lenght_ls_normal_step_draw = lenght_ls_normal_step;
                  let line_width_ls_normal_step_draw = line_width_ls_normal_step;
                  if (lenght_ls_normal_step < 0){
                    lenght_ls_normal_step_draw = -lenght_ls_normal_step;
                    start_x_normal_step_draw = start_x_normal_step - lenght_ls_normal_step_draw;
                  };
                  
                  normal_step_linear_scale.setProperty(hmUI.prop.MORE, {
                    x: start_x_normal_step_draw,
                    y: start_y_normal_step_draw,
                    w: lenght_ls_normal_step_draw,
                    h: line_width_ls_normal_step_draw,
                    color: color_ls_normal_step,
                  });
                  
                  // pointers parameters
                  let pointer_offset_x_ls_normal_step = 6;
                  let pointer_offset_y_ls_normal_step = 9;
                  normal_step_linear_scale_pointer_img.setProperty(hmUI.prop.MORE, {
                    x: start_x_normal_step + lenght_ls_normal_step - pointer_offset_x_ls_normal_step,
                    y: start_y_normal_step_draw + line_width_ls_normal_step / 2 - pointer_offset_y_ls_normal_step,
                    src: 'Puntatore_00.png',
                    show_level: hmUI.show_level.ONLY_NORMAL,
                  });
                };

                console.log('update scales STEP');
                let progress_ls_idle_step = progressStep;

                if (screenType == hmSetting.screen_type.AOD) {

                  // idle_step_linear_scale
                  // initial parameters
                  let start_x_idle_step = 129;
                  let start_y_idle_step = 401;
                  let lenght_ls_idle_step = 212;
                  let line_width_ls_idle_step = 3;
                  let color_ls_idle_step = 0xFFF8EF87;
                  
                  // calculated parameters
                  let start_x_idle_step_draw = start_x_idle_step;
                  let start_y_idle_step_draw = start_y_idle_step;
                  lenght_ls_idle_step = lenght_ls_idle_step * progress_ls_idle_step;
                  let lenght_ls_idle_step_draw = lenght_ls_idle_step;
                  let line_width_ls_idle_step_draw = line_width_ls_idle_step;
                  if (lenght_ls_idle_step < 0){
                    lenght_ls_idle_step_draw = -lenght_ls_idle_step;
                    start_x_idle_step_draw = start_x_idle_step - lenght_ls_idle_step_draw;
                  };
                  
                  idle_step_linear_scale.setProperty(hmUI.prop.MORE, {
                    x: start_x_idle_step_draw,
                    y: start_y_idle_step_draw,
                    w: lenght_ls_idle_step_draw,
                    h: line_width_ls_idle_step_draw,
                    color: color_ls_idle_step,
                  });
                  
                  // pointers parameters
                  let pointer_offset_x_ls_idle_step = 6;
                  let pointer_offset_y_ls_idle_step = 9;
                  idle_step_linear_scale_pointer_img.setProperty(hmUI.prop.MORE, {
                    x: start_x_idle_step + lenght_ls_idle_step - pointer_offset_x_ls_idle_step,
                    y: start_y_idle_step_draw + line_width_ls_idle_step / 2 - pointer_offset_y_ls_idle_step,
                    src: 'Puntatore_00.png',
                    show_level: hmUI.show_level.ONLY_AOD,
                  });
                };

            };

            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                console.log('resume_call()');
                scale_call();
                normal_frame_animation_1.setProperty(hmUI.prop.ANIM_STATUS,hmUI.anim_status.START);

              }),
              pause_call: (function () {
                console.log('pause_call()');
                normal_frame_animation_1.setProperty(hmUI.prop.ANIM_STATUS,hmUI.anim_status.STOP);

              }),
            });

                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}