    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        //const logger = Logger.getLogger('watchface_SashaCX75');
        const logger = DeviceRuntimeCore.HmLogger.getLogger('watchface_SashaCX75')
        //end of ignored block

         //dynamic modify start
		// Start change city
        let elementdate_1 = 1
        let total_elemente = 2

        function click_citi() {
            if(elementdate_1==total_elemente) {
            elementdate_1=1;
                UpdateElementeOne();
                }
            else {
                elementdate_1=elementdate_1+1;
                if(elementdate_1==2) {
                  UpdateElementeTwo();
                }
            }
          }

        //on
        function UpdateElementeOne(){
        normal_city_name_text.setProperty(hmUI.prop.VISIBLE, true);
        }

        //off
        function UpdateElementeTwo(){
        normal_city_name_text.setProperty(hmUI.prop.VISIBLE, false);
        }
		
		
		// Start change Temp
        let elementtemp_1 = 1
        let total_elements = 2

        function click_temp() {
            if(elementtemp_1==total_elements) {
            elementtemp_1=1;
                UpdateElementOne();
                }
            else {
                elementtemp_1=elementtemp_1+1;
                if(elementtemp_1==2) {
                  UpdateElementTwo();
                }
            }
          }

        //on
        function UpdateElementOne(){
        normal_weather_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, true);
		normal_temperature_current_text_font.setProperty(hmUI.prop.VISIBLE, true);
		Button_3.setProperty(hmUI.prop.VISIBLE, true);
        }

        //off
        function UpdateElementTwo(){
        normal_weather_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, false);
		normal_temperature_current_text_font.setProperty(hmUI.prop.VISIBLE, false);
		Button_3.setProperty(hmUI.prop.VISIBLE, false);
        }

		
        const lang = DeviceRuntimeCore.HmUtils.getLanguage()
        let normal_background_bg_img = ''
        let normal_city_name_text = ''
        let normal_weather_image_progress_img_level = ''
        let normal_temperature_current_text_font = ''
        let normal_moon_image_progress_img_level = ''
        let normal_date_img_date_week_img = ''
        let normal_day_month_font = ''
        let normal_timerTimeUpdate = undefined;
        let normal_fat_burning_icon_img = ''
        let normal_fat_burning_linear_scale = ''
        let normal_calorie_linear_scale = ''
        let normal_pai_linear_scale = ''
        let normal_pai_weekly_text_font = ''
        let normal_step_linear_scale = ''
        let normal_step_current_text_font = ''
        let normal_sun_icon_img = ''
        let normal_sun_low_text_font = ''
        let normal_sun_high_text_font = ''
        let normal_heart_rate_linear_scale = ''
        let normal_heart_rate_text_font = ''
        let normal_battery_linear_scale = ''
        let normal_battery_current_text_font = ''
        let normal_system_lock_img = ''
        let normal_system_dnd_img = ''
        let normal_system_disconnect_img = ''
        let normal_system_clock_img = ''
        let normal_digital_clock_img_time_AmPm = ''
        let normal_time_hour_text_font = ''
        let normal_time_minute_text_font = ''
        let normal_time_second_text_font = ''
        let idle_background_bg_img = ''
        let idle_moon_image_progress_img_level = ''
        let idle_date_img_date_week_img = ''
        let idle_day_month_font = ''
        let idle_timerTimeUpdate = undefined;
        let idle_fat_burning_icon_img = ''
        let idle_fat_burning_linear_scale = ''
        let idle_calorie_linear_scale = ''
        let idle_pai_linear_scale = ''
        let idle_pai_weekly_text_font = ''
        let idle_step_linear_scale = ''
        let idle_step_current_text_font = ''
        let idle_sun_icon_img = ''
        let idle_sun_low_text_font = ''
        let idle_sun_high_text_font = ''
        let idle_heart_rate_linear_scale = ''
        let idle_heart_rate_text_font = ''
        let idle_battery_linear_scale = ''
        let idle_battery_current_text_font = ''
        let idle_system_lock_img = ''
        let idle_system_dnd_img = ''
        let idle_system_disconnect_img = ''
        let idle_system_clock_img = ''
        let idle_digital_clock_img_time_AmPm = ''
        let idle_time_hour_text_font = ''
        let idle_time_minute_text_font = ''
        let idle_time_second_text_font = ''
        let normal_step_jumpable_img_click = ''
        let normal_cal_jumpable_img_click = ''
        let normal_heart_jumpable_img_click = ''
        let normal_pai_jumpable_img_click = ''
        let normal_battery_jumpable_img_click = ''
        let normal_sunrise_jumpable_img_click = ''
        let normal_moon_jumpable_img_click = ''
        let normal_fatBurning_jumpable_img_click = ''
        let Button_1 = ''
        let Button_2 = ''
        let Button_3 = ''
        let Button_5 = ''
        let Button_6 = ''
        let Button_7 = ''
        let timeSensor = '';


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            // FontName: Handjet-Regular.ttf; FontSize: 30; Cache: full
            hmUI.createWidget(hmUI.widget.TEXT, {
              x: 464,
              y: 464,
              w: 36,
              h: 36,
              text_size: 30,
              char_space: 2,
              line_space: 0,
              font: 'fonts/Handjet-Regular.ttf',
              color: 0xFFD9D9D9,
              align_h: hmUI.align.LEFT,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.NONE,
              text: "0123456789 ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz АБВГДЕЁЖЗИЙКЛМНОПРСТУФХЦЧШЩЪЫЬЭЮЯабвгдеёжзийклмнопрстуфхцчшщъыьэюя  ҐЄІЇґєії _-.,:;`'%°\\/",
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // FontName: Handjet-Regular.ttf; FontSize: 32
            hmUI.createWidget(hmUI.widget.TEXT, {
              x: 464,
              y: 464,
              w: 424,
              h: 43,
              text_size: 32,
              char_space: 0,
              line_space: 0,
              font: 'fonts/Handjet-Regular.ttf',
              color: 0xFFD9D9D9,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              text: "0123456789 _-.,:;`'%°\\/",
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // FontName: Tomorrow-SemiBold.ttf; FontSize: 31
            hmUI.createWidget(hmUI.widget.TEXT, {
              x: 464,
              y: 464,
              w: 488,
              h: 56,
              text_size: 31,
              char_space: 0,
              line_space: 0,
              font: 'fonts/Tomorrow-SemiBold.ttf',
              color: 0xFFD9D9D9,
              align_h: hmUI.align.RIGHT,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              text: "0123456789 _-.,:;`'%°\\/",
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // FontName: Handjet-Regular.ttf; FontSize: 31
            hmUI.createWidget(hmUI.widget.TEXT, {
              x: 464,
              y: 464,
              w: 436,
              h: 42,
              text_size: 31,
              char_space: 1,
              line_space: 0,
              font: 'fonts/Handjet-Regular.ttf',
              color: 0xFFD9D9D9,
              align_h: hmUI.align.LEFT,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              text: "0123456789 _-.,:;`'%°\\/",
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // FontName: Handjet-Medium.ttf; FontSize: 32
            hmUI.createWidget(hmUI.widget.TEXT, {
              x: 464,
              y: 464,
              w: 453,
              h: 43,
              text_size: 32,
              char_space: 1,
              line_space: 0,
              font: 'fonts/Handjet-Medium.ttf',
              color: 0xFFD9D9D9,
              align_h: hmUI.align.LEFT,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              text: "0123456789 _-.,:;`'%°\\/",
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // FontName: Handjet-Light.ttf; FontSize: 25
            hmUI.createWidget(hmUI.widget.TEXT, {
              x: 464,
              y: 464,
              w: 330,
              h: 33,
              text_size: 25,
              char_space: 0,
              line_space: 0,
              font: 'fonts/Handjet-Light.ttf',
              color: 0xFF000000,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              text: "0123456789 _-.,:;`'%°\\/",
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // FontName: Tomorrow-SemiBold.ttf; FontSize: 86
            hmUI.createWidget(hmUI.widget.TEXT, {
              x: 464,
              y: 464,
              w: 1292,
              h: 156,
              text_size: 86,
              char_space: -2,
              line_space: 0,
              font: 'fonts/Tomorrow-SemiBold.ttf',
              color: 0xFFD9D9D9,
              align_h: hmUI.align.RIGHT,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              text: "0123456789 _-.,:;`'%°\\/",
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // FontName: Tomorrow-SemiBold.ttf; FontSize: 53
            hmUI.createWidget(hmUI.widget.TEXT, {
              x: 464,
              y: 464,
              w: 831,
              h: 96,
              text_size: 53,
              char_space: 0,
              line_space: 0,
              font: 'fonts/Tomorrow-SemiBold.ttf',
              color: 0xFFD9D9D9,
              align_h: hmUI.align.LEFT,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              text: "0123456789 _-.,:;`'%°\\/",
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            console.log('Watch_Face.ScreenNormal');
				
			let dst=['en_Bg.png']
      			if(lang=='pt-BR'){
      				dst=['pt_Bg.png']
      			}
      			if(lang=='es-ES'){
      				dst=["es_Bg.png"]
      			}

            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 466,
              h: 466,
              src: dst,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
              const weatherSensor = hmSensor.createSensor(hmSensor.id.WEATHER);

            normal_city_name_text = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 37,
              y: 260,
              w: 314,
              h: 30,
              text_size: 30,
              char_space: 2,
              line_space: 0,
              font: 'fonts/Handjet-Regular.ttf',
              color: 0xFFD9D9D9,
              align_h: hmUI.align.LEFT,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.NONE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 410,
              y: 262,
              image_array: ["w00.png","w01.png","w02.png","w03.png","w04.png","w05.png","w06.png","w07.png","w08.png","w09.png","w10.png","w11.png","w12.png","w13.png","w14.png","w15.png","w16.png","w17.png","w18.png","w19.png","w20.png","w21.png","w22.png","w23.png","w24.png","w25.png","w26.png","w27.png","w28.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 341,
              y: 261,
              w: 66,
              h: 29,
              text_size: 30,
              char_space: 0,
              line_space: 0,
              font: 'fonts/Handjet-Regular.ttf',
              color: 0xFFD9D9D9,
              align_h: hmUI.align.RIGHT,
              align_v: hmUI.align.CENTER_V,
              unit_type: 1,
              text_style: hmUI.text_style.NONE,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_moon_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 53,
              y: 171,
              image_array: ["253.png","254.png","255.png","256.png","257.png","258.png","259.png","260.png","261.png","262.png","263.png","264.png","265.png","266.png","267.png","268.png","269.png","270.png","271.png","272.png","273.png","274.png","275.png","276.png","277.png","278.png","279.png","280.png","281.png","282.png"],
              image_length: 30,
              type: hmUI.data_type.MOON,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
				
			let ddow=['en_week_01.png', 'en_week_02.png', 'en_week_03.png', 'en_week_04.png', 'en_week_05.png', 'en_week_06.png', 'en_week_07.png']
			if(lang=='pt-BR'){
				ddow=['pt_week_01.png', 'pt_week_02.png', 'pt_week_03.png', 'pt_week_04.png', 'pt_week_05.png', 'pt_week_06.png', 'pt_week_07.png']
			}
			if(lang=='es-ES'){
				ddow=['es_week_01.png', 'es_week_02.png', 'es_week_03.png', 'es_week_04.png', 'es_week_05.png', 'es_week_06.png', 'es_week_07.png']
			}

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 295,
              y: 69,
              week_en: ddow,
              week_tc: ["en_week_01.png","en_week_02.png","en_week_03.png","en_week_04.png","en_week_05.png","en_week_06.png","en_week_07.png"],
              week_sc: ["en_week_01.png","en_week_02.png","en_week_03.png","en_week_04.png","en_week_05.png","en_week_06.png","en_week_07.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            if (!timeSensor) timeSensor = hmSensor.createSensor(hmSensor.id.TIME);
            let screenType = hmSetting.getScreenType();
            normal_day_month_font = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 287,
              y: 286,
              w: 150,
              h: 30,
              text_size: 32,
              char_space: 0,
              line_space: 0,
              font: 'fonts/Handjet-Regular.ttf',
              color: 0xFFD9D9D9,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              // padding: true,
              // unit_string: / ,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_fat_burning_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 181,
              y: 305,
              src: 'pnt.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            if (screenType != hmSetting.screen_type.AOD) {
              normal_fat_burning_linear_scale = hmUI.createWidget(hmUI.widget.FILL_RECT);
            };

            // normal_fat_burning_linear_scale = hmUI.createWidget(hmUI.widget.Linear_Scale, {
              // start_x: 340,
              // start_y: 222,
              // color: 0xFFD9D9D9,
              // lenght: -55,
              // line_width: 32,
              // line_cap: Flat,
              // vertical: True,
              // mirror: False,
              // inversion: False,
              // alpha: 255,
              // type: hmUI.data_type.FAT_BURNING,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });
            
            const fat_burning = hmSensor.createSensor(hmSensor.id.FAT_BURRING);
            fat_burning.addEventListener(hmSensor.event.CHANGE, function() {
              scale_call();
            });

            if (screenType != hmSetting.screen_type.AOD) {
              normal_calorie_linear_scale = hmUI.createWidget(hmUI.widget.FILL_RECT);
            };

            // normal_calorie_linear_scale = hmUI.createWidget(hmUI.widget.Linear_Scale, {
              // start_x: 300,
              // start_y: 222,
              // color: 0xFFD9D9D9,
              // lenght: -55,
              // line_width: 32,
              // line_cap: Flat,
              // vertical: True,
              // mirror: False,
              // inversion: False,
              // alpha: 255,
              // type: hmUI.data_type.CAL,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });
            
            const calorie = hmSensor.createSensor(hmSensor.id.CALORIE);
            calorie.addEventListener(hmSensor.event.CHANGE, function() {
              scale_call();
            });

            if (screenType != hmSetting.screen_type.AOD) {
              normal_pai_linear_scale = hmUI.createWidget(hmUI.widget.FILL_RECT);
            };

            // normal_pai_linear_scale = hmUI.createWidget(hmUI.widget.Linear_Scale, {
              // start_x: 259,
              // start_y: 222,
              // color: 0xFFD9D9D9,
              // lenght: -55,
              // line_width: 32,
              // line_cap: Flat,
              // vertical: True,
              // mirror: False,
              // inversion: False,
              // alpha: 255,
              // type: hmUI.data_type.PAI_WEEKLY,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });
            
            const pai = hmSensor.createSensor(hmSensor.id.PAI);

            normal_pai_weekly_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 176,
              y: 126,
              w: 150,
              h: 39,
              text_size: 31,
              char_space: 0,
              line_space: 0,
              font: 'fonts/Tomorrow-SemiBold.ttf',
              color: 0xFFD9D9D9,
              align_h: hmUI.align.RIGHT,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              type: hmUI.data_type.PAI_WEEKLY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            if (screenType != hmSetting.screen_type.AOD) {
              normal_step_linear_scale = hmUI.createWidget(hmUI.widget.FILL_RECT);
            };

            // normal_step_linear_scale = hmUI.createWidget(hmUI.widget.Linear_Scale, {
              // start_x: 218,
              // start_y: 222,
              // color: 0xFFD9D9D9,
              // lenght: -55,
              // line_width: 32,
              // line_cap: Flat,
              // vertical: True,
              // mirror: False,
              // inversion: False,
              // alpha: 255,
              // type: hmUI.data_type.STEP,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });
            
            const step = hmSensor.createSensor(hmSensor.id.STEP);
            step.addEventListener(hmSensor.event.CHANGE, function() {
              scale_call();
            });

            normal_step_current_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 176,
              y: 98,
              w: 150,
              h: 32,
              text_size: 31,
              char_space: 0,
              line_space: 0,
              font: 'fonts/Tomorrow-SemiBold.ttf',
              color: 0xFFD9D9D9,
              align_h: hmUI.align.RIGHT,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sun_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 46,
              y: 105,
              src: 'sun.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sun_low_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 129,
              y: 128,
              w: 150,
              h: 30,
              text_size: 31,
              char_space: 1,
              line_space: 0,
              font: 'fonts/Handjet-Regular.ttf',
              color: 0xFFD9D9D9,
              align_h: hmUI.align.LEFT,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              type: hmUI.data_type.SUN_SET,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sun_high_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 129,
              y: 101,
              w: 150,
              h: 30,
              text_size: 31,
              char_space: 1,
              line_space: 0,
              font: 'fonts/Handjet-Regular.ttf',
              color: 0xFFD9D9D9,
              align_h: hmUI.align.LEFT,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              type: hmUI.data_type.SUN_RISE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            if (screenType != hmSetting.screen_type.AOD) {
              normal_heart_rate_linear_scale = hmUI.createWidget(hmUI.widget.FILL_RECT);
            };

            // normal_heart_rate_linear_scale = hmUI.createWidget(hmUI.widget.Linear_Scale, {
              // start_x: 177,
              // start_y: 222,
              // color: 0xFFD9D9D9,
              // lenght: -55,
              // line_width: 32,
              // line_cap: Flat,
              // vertical: True,
              // mirror: False,
              // inversion: False,
              // alpha: 255,
              // type: hmUI.data_type.HEART,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });
            
            const heart_rate = hmSensor.createSensor(hmSensor.id.HEART);
            heart_rate.addEventListener(hmSensor.event.CHANGE, function() {
              scale_call();
            });

            normal_heart_rate_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 231,
              y: 69,
              w: 150,
              h: 30,
              text_size: 32,
              char_space: 1,
              line_space: 0,
              font: 'fonts/Handjet-Medium.ttf',
              color: 0xFFD9D9D9,
              align_h: hmUI.align.LEFT,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            if (screenType != hmSetting.screen_type.AOD) {
              normal_battery_linear_scale = hmUI.createWidget(hmUI.widget.FILL_RECT);
            };

            // normal_battery_linear_scale = hmUI.createWidget(hmUI.widget.Linear_Scale, {
              // start_x: 137,
              // start_y: 222,
              // color: 0xFFD9D9D9,
              // lenght: -55,
              // line_width: 32,
              // line_cap: Flat,
              // vertical: True,
              // mirror: False,
              // inversion: False,
              // alpha: 255,
              // type: hmUI.data_type.BATTERY,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });
            
            const battery = hmSensor.createSensor(hmSensor.id.BATTERY);
            battery.addEventListener(hmSensor.event.CHANGE, function() {
              scale_call();
            });

            normal_battery_current_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 70,
              y: 68,
              w: 150,
              h: 30,
              text_size: 25,
              char_space: 0,
              line_space: 0,
              font: 'fonts/Handjet-Light.ttf',
              color: 0xFF000000,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.CENTER_V,
              unit_type: 1,
              text_style: hmUI.text_style.ELLIPSIS,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_lock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 262,
              y: 370,
              src: 'lock.png',
              type: hmUI.system_status.LOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_dnd_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 176,
              y: 366,
              src: 'mute.png',
              type: hmUI.system_status.DISTURB,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 71,
              y: 70,
              src: 'connectedoff.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 211,
              y: 362,
              src: 'alarm.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time_AmPm = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              am_x: 32,
              am_y: 308,
              am_sc_path: 'am.png',
              am_en_path: 'am.png',
              pm_x: 30,
              pm_y: 308,
              pm_sc_path: 'pm.png',
              pm_en_path: 'pm.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_time_hour_text_font = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 29,
              y: 279,
              w: 153,
              h: 89,
              text_size: 86,
              char_space: -2,
              line_space: 0,
              font: 'fonts/Tomorrow-SemiBold.ttf',
              color: 0xFFD9D9D9,
              align_h: hmUI.align.RIGHT,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              // padding: true,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_time_minute_text_font = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 201,
              y: 272,
              w: 153,
              h: 90,
              text_size: 86,
              char_space: -2,
              line_space: 0,
              font: 'fonts/Tomorrow-SemiBold.ttf',
              color: 0xFFD9D9D9,
              align_h: hmUI.align.LEFT,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              // padding: true,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_time_second_text_font = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 324,
              y: 305,
              w: 150,
              h: 90,
              text_size: 53,
              char_space: 0,
              line_space: 0,
              font: 'fonts/Tomorrow-SemiBold.ttf',
              color: 0xFFD9D9D9,
              align_h: hmUI.align.LEFT,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              // padding: true,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            console.log('Watch_Face.ScreenAOD');
            idle_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 466,
              h: 466,
              src: dst,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_moon_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 53,
              y: 171,
              image_array: ["253.png","254.png","255.png","256.png","257.png","258.png","259.png","260.png","261.png","262.png","263.png","264.png","265.png","266.png","267.png","268.png","269.png","270.png","271.png","272.png","273.png","274.png","275.png","276.png","277.png","278.png","279.png","280.png","281.png","282.png"],
              image_length: 30,
              type: hmUI.data_type.MOON,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 295,
              y: 69,
              week_en: ddow,
              week_tc: ["en_week_01.png","en_week_02.png","en_week_03.png","en_week_04.png","en_week_05.png","en_week_06.png","en_week_07.png"],
              week_sc: ["en_week_01.png","en_week_02.png","en_week_03.png","en_week_04.png","en_week_05.png","en_week_06.png","en_week_07.png"],
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_day_month_font = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 287,
              y: 286,
              w: 150,
              h: 30,
              text_size: 32,
              char_space: 0,
              line_space: 0,
              font: 'fonts/Handjet-Regular.ttf',
              color: 0xFFD9D9D9,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              // padding: true,
              // unit_string: / ,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_fat_burning_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 181,
              y: 305,
              src: 'pnt.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            if (screenType == hmSetting.screen_type.AOD) {
              idle_fat_burning_linear_scale = hmUI.createWidget(hmUI.widget.FILL_RECT);
            };

            // idle_fat_burning_linear_scale = hmUI.createWidget(hmUI.widget.Linear_Scale, {
              // start_x: 340,
              // start_y: 222,
              // color: 0xFFD9D9D9,
              // lenght: -55,
              // line_width: 32,
              // line_cap: Flat,
              // vertical: True,
              // mirror: False,
              // inversion: False,
              // alpha: 255,
              // type: hmUI.data_type.FAT_BURNING,
              // show_level: hmUI.show_level.ONLY_AOD,
            // });

            if (screenType == hmSetting.screen_type.AOD) {
              idle_calorie_linear_scale = hmUI.createWidget(hmUI.widget.FILL_RECT);
            };

            // idle_calorie_linear_scale = hmUI.createWidget(hmUI.widget.Linear_Scale, {
              // start_x: 300,
              // start_y: 222,
              // color: 0xFFD9D9D9,
              // lenght: -55,
              // line_width: 32,
              // line_cap: Flat,
              // vertical: True,
              // mirror: False,
              // inversion: False,
              // alpha: 255,
              // type: hmUI.data_type.CAL,
              // show_level: hmUI.show_level.ONLY_AOD,
            // });

            if (screenType == hmSetting.screen_type.AOD) {
              idle_pai_linear_scale = hmUI.createWidget(hmUI.widget.FILL_RECT);
            };

            // idle_pai_linear_scale = hmUI.createWidget(hmUI.widget.Linear_Scale, {
              // start_x: 259,
              // start_y: 222,
              // color: 0xFFD9D9D9,
              // lenght: -55,
              // line_width: 32,
              // line_cap: Flat,
              // vertical: True,
              // mirror: False,
              // inversion: False,
              // alpha: 255,
              // type: hmUI.data_type.PAI_WEEKLY,
              // show_level: hmUI.show_level.ONLY_AOD,
            // });

            idle_pai_weekly_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 176,
              y: 126,
              w: 150,
              h: 39,
              text_size: 31,
              char_space: 0,
              line_space: 0,
              font: 'fonts/Tomorrow-SemiBold.ttf',
              color: 0xFFD9D9D9,
              align_h: hmUI.align.RIGHT,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              type: hmUI.data_type.PAI_WEEKLY,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            if (screenType == hmSetting.screen_type.AOD) {
              idle_step_linear_scale = hmUI.createWidget(hmUI.widget.FILL_RECT);
            };

            // idle_step_linear_scale = hmUI.createWidget(hmUI.widget.Linear_Scale, {
              // start_x: 218,
              // start_y: 222,
              // color: 0xFFD9D9D9,
              // lenght: -55,
              // line_width: 32,
              // line_cap: Flat,
              // vertical: True,
              // mirror: False,
              // inversion: False,
              // alpha: 255,
              // type: hmUI.data_type.STEP,
              // show_level: hmUI.show_level.ONLY_AOD,
            // });

            idle_step_current_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 176,
              y: 98,
              w: 150,
              h: 32,
              text_size: 31,
              char_space: 0,
              line_space: 0,
              font: 'fonts/Tomorrow-SemiBold.ttf',
              color: 0xFFD9D9D9,
              align_h: hmUI.align.RIGHT,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_sun_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 46,
              y: 105,
              src: 'sun.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_sun_low_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 129,
              y: 128,
              w: 150,
              h: 30,
              text_size: 31,
              char_space: 1,
              line_space: 0,
              font: 'fonts/Handjet-Regular.ttf',
              color: 0xFFD9D9D9,
              align_h: hmUI.align.LEFT,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              type: hmUI.data_type.SUN_SET,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_sun_high_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 129,
              y: 101,
              w: 150,
              h: 30,
              text_size: 31,
              char_space: 1,
              line_space: 0,
              font: 'fonts/Handjet-Regular.ttf',
              color: 0xFFD9D9D9,
              align_h: hmUI.align.LEFT,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              type: hmUI.data_type.SUN_RISE,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            if (screenType == hmSetting.screen_type.AOD) {
              idle_heart_rate_linear_scale = hmUI.createWidget(hmUI.widget.FILL_RECT);
            };

            // idle_heart_rate_linear_scale = hmUI.createWidget(hmUI.widget.Linear_Scale, {
              // start_x: 177,
              // start_y: 222,
              // color: 0xFFD9D9D9,
              // lenght: -55,
              // line_width: 32,
              // line_cap: Flat,
              // vertical: True,
              // mirror: False,
              // inversion: False,
              // alpha: 255,
              // type: hmUI.data_type.HEART,
              // show_level: hmUI.show_level.ONLY_AOD,
            // });

            idle_heart_rate_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 231,
              y: 69,
              w: 150,
              h: 30,
              text_size: 32,
              char_space: 1,
              line_space: 0,
              font: 'fonts/Handjet-Medium.ttf',
              color: 0xFFD9D9D9,
              align_h: hmUI.align.LEFT,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            if (screenType == hmSetting.screen_type.AOD) {
              idle_battery_linear_scale = hmUI.createWidget(hmUI.widget.FILL_RECT);
            };

            // idle_battery_linear_scale = hmUI.createWidget(hmUI.widget.Linear_Scale, {
              // start_x: 137,
              // start_y: 222,
              // color: 0xFFD9D9D9,
              // lenght: -55,
              // line_width: 32,
              // line_cap: Flat,
              // vertical: True,
              // mirror: False,
              // inversion: False,
              // alpha: 255,
              // type: hmUI.data_type.BATTERY,
              // show_level: hmUI.show_level.ONLY_AOD,
            // });

            idle_battery_current_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 70,
              y: 68,
              w: 150,
              h: 30,
              text_size: 25,
              char_space: 0,
              line_space: 0,
              font: 'fonts/Handjet-Light.ttf',
              color: 0xFF000000,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.CENTER_V,
              unit_type: 1,
              text_style: hmUI.text_style.ELLIPSIS,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_system_lock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 262,
              y: 370,
              src: 'lock.png',
              type: hmUI.system_status.LOCK,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_system_dnd_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 176,
              y: 366,
              src: 'mute.png',
              type: hmUI.system_status.DISTURB,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 71,
              y: 70,
              src: 'connectedoff.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 211,
              y: 362,
              src: 'alarm.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time_AmPm = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              am_x: 32,
              am_y: 308,
              am_sc_path: 'am.png',
              am_en_path: 'am.png',
              pm_x: 30,
              pm_y: 308,
              pm_sc_path: 'pm.png',
              pm_en_path: 'pm.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_time_hour_text_font = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 29,
              y: 279,
              w: 153,
              h: 89,
              text_size: 86,
              char_space: -2,
              line_space: 0,
              font: 'fonts/Tomorrow-SemiBold.ttf',
              color: 0xFFD9D9D9,
              align_h: hmUI.align.RIGHT,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              // padding: true,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_time_minute_text_font = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 201,
              y: 272,
              w: 153,
              h: 90,
              text_size: 86,
              char_space: -2,
              line_space: 0,
              font: 'fonts/Tomorrow-SemiBold.ttf',
              color: 0xFFD9D9D9,
              align_h: hmUI.align.LEFT,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              // padding: true,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_time_second_text_font = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 324,
              y: 305,
              w: 150,
              h: 90,
              text_size: 53,
              char_space: 0,
              line_space: 0,
              font: 'fonts/Tomorrow-SemiBold.ttf',
              color: 0xFFD9D9D9,
              align_h: hmUI.align.LEFT,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              // padding: true,
              show_level: hmUI.show_level.ONLY_AOD,
            });
            console.log('Watch_Face.Shortcuts');

            normal_step_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 218,
              y: 167,
              w: 32,
              h: 55,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_cal_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 300,
              y: 167,
              w: 32,
              h: 55,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 177,
              y: 167,
              w: 32,
              h: 55,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_pai_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 259,
              y: 167,
              w: 32,
              h: 55,
              type: hmUI.data_type.PAI_WEEKLY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 137,
              y: 167,
              w: 32,
              h: 55,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sunrise_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 45,
              y: 104,
              w: 54,
              h: 53,
              type: hmUI.data_type.SUN_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_moon_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 54,
              y: 172,
              w: 40,
              h: 40,
              type: hmUI.data_type.MOON_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_fatBurning_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 340,
              y: 167,
              w: 32,
              h: 55,
              type: hmUI.data_type.FAT_BURNING,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
			
			// vibrate function
            const vibrate = hmSensor.createSensor(hmSensor.id.VIBRATE);
            let timer_StopVibrate = null;


            function vibro(scene = 25) {
              let stopDelay = 50;
              stopVibro();
              vibrate.stop();
              vibrate.scene = scene;
              if(scene < 23 || scene > 25) stopDelay = 1300;
              vibrate.start();
              if (scene != 1) timer_StopVibrate = timer.createTimer(stopDelay, 3000, stopVibro, {});
            }

            function stopVibro(){
              vibrate.stop();
              if(timer_StopVibrate) timer.stopTimer(timer_StopVibrate);
            }
			// end vibrate function 

            console.log('Watch_Face.Buttons');
            Button_1 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 270,
              y: 24,
              w: 79,
              h: 29,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'null.png',
              normal_src: 'null.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'Settings_homeScreen', native: true });
				vibro(25);
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_2 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 312,
              y: 313,
              w: 99,
              h: 53,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'null.png',
              normal_src: 'null.png',
              click_func: (button_widget) => {
                click_temp();
				vibro(25);

              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_3 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 358,
              y: 254,
              w: 80,
              h: 37,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'null.png',
              normal_src: 'null.png',
              click_func: (button_widget) => {
                hmApp.startApp({ appid: 1051195, url: 'page/index', params: { from_wf: true} });
				vibro(25);
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_5 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 141,
              y: 24,
              w: 95,
              h: 29,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'null.png',
              normal_src: 'null.png',
              click_func: (button_widget) => {
                click_citi();
				vibro(25);
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_6 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 291,
              y: 69,
              w: 98,
              h: 28,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'null.png',
              normal_src: 'null.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'ScheduleCalScreen', native: true });
				vibro(25);
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_7 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 113,
              y: 72,
              w: 62,
              h: 24,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'null.png',
              normal_src: 'null.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'LowBatteryScreen', native: true });
				vibro(25);
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            //start of ignored block
            function time_update(updateHour = false, updateMinute = false) {
              console.log('time_update()');
              let hour = timeSensor.hour;
              let minute = timeSensor.minute;
              let second = timeSensor.second;
              let format_hour = timeSensor.format_hour;

              console.log('day/month font');
              if (updateHour) {
                let normal_DayStr = timeSensor.day.toString();
                let normal_MonthStr = timeSensor.month.toString();
                normal_DayStr = normal_DayStr.padStart(2, '0');
                normal_MonthStr = normal_MonthStr.padStart(2, '0');
                let normal_DayMonthStr = '--';
                const dateFormat = hmSetting.getDateFormat();
                if (dateFormat == 0 || dateFormat == 2) {
                  normal_DayMonthStr = normal_MonthStr + '/ ' + normal_DayStr;
                }
                if (dateFormat == 1) {
                  normal_DayMonthStr = normal_DayStr + '/ ' + normal_MonthStr;
                }
                normal_day_month_font.setProperty(hmUI.prop.TEXT, normal_DayMonthStr );
              };

              console.log('hour font');
              if (updateHour) {
                let normal_hourStr = format_hour.toString();
                normal_hourStr = normal_hourStr.padStart(2, '0');
                normal_time_hour_text_font.setProperty(hmUI.prop.TEXT, normal_hourStr );
              };

              console.log('minute font');
              if (updateMinute) {
                let normal_minuteStr = minute.toString();
                normal_minuteStr = normal_minuteStr.padStart(2, '0');
                normal_time_minute_text_font.setProperty(hmUI.prop.TEXT, normal_minuteStr );
              };

              console.log('second font');
                let normal_secondStr = second.toString();
                normal_secondStr = normal_secondStr.padStart(2, '0');
                normal_time_second_text_font.setProperty(hmUI.prop.TEXT, normal_secondStr );
              console.log('day/month font');
              if (updateHour) {
                let idle_DayStr = timeSensor.day.toString();
                let idle_MonthStr = timeSensor.month.toString();
                idle_DayStr = idle_DayStr.padStart(2, '0');
                idle_MonthStr = idle_MonthStr.padStart(2, '0');
                let idle_DayMonthStr = '--';
                const dateFormat = hmSetting.getDateFormat();
                if (dateFormat == 0 || dateFormat == 2) {
                  idle_DayMonthStr = idle_MonthStr + '/ ' + idle_DayStr;
                }
                if (dateFormat == 1) {
                  idle_DayMonthStr = idle_DayStr + '/ ' + idle_MonthStr;
                }
                idle_day_month_font.setProperty(hmUI.prop.TEXT, idle_DayMonthStr );
              };

              console.log('hour font');
              if (updateHour) {
                let idle_hourStr = format_hour.toString();
                idle_hourStr = idle_hourStr.padStart(2, '0');
                idle_time_hour_text_font.setProperty(hmUI.prop.TEXT, idle_hourStr );
              };

              console.log('minute font');
              if (updateMinute) {
                let idle_minuteStr = minute.toString();
                idle_minuteStr = idle_minuteStr.padStart(2, '0');
                idle_time_minute_text_font.setProperty(hmUI.prop.TEXT, idle_minuteStr );
              };

              console.log('second font');
                let idle_secondStr = second.toString();
                idle_secondStr = idle_secondStr.padStart(2, '0');
                idle_time_second_text_font.setProperty(hmUI.prop.TEXT, idle_secondStr );
            };

            //end of ignored block
            function scale_call() {
              console.log('scale_call()');

              console.log('Weather city name');
              let weatherData = weatherSensor.getForecastWeather();
              normal_city_name_text.setProperty(hmUI.prop.TEXT, weatherData.cityName);

                console.log('update scales FAT_BURNING');
                
                let valueFatBurning = fat_burning.current;
                let targetFatBurning = fat_burning.target;
                let progressFatBurning = valueFatBurning/targetFatBurning;
                if (progressFatBurning > 1) progressFatBurning = 1;
                let progress_ls_normal_fat_burning = progressFatBurning;

                if (screenType != hmSetting.screen_type.AOD) {

                  // normal_fat_burning_linear_scale
                  // initial parameters
                  let start_x_normal_fat_burning = 340;
                  let start_y_normal_fat_burning = 222;
                  let lenght_ls_normal_fat_burning = -55;
                  let line_width_ls_normal_fat_burning = 32;
                  let color_ls_normal_fat_burning = 0xFFD9D9D9;
                  
                  // calculated parameters
                  let start_x_normal_fat_burning_draw = start_x_normal_fat_burning;
                  let start_y_normal_fat_burning_draw = start_y_normal_fat_burning;
                  lenght_ls_normal_fat_burning = lenght_ls_normal_fat_burning * progress_ls_normal_fat_burning;
                  let lenght_ls_normal_fat_burning_draw = line_width_ls_normal_fat_burning;
                  let line_width_ls_normal_fat_burning_draw = lenght_ls_normal_fat_burning;
                  if (lenght_ls_normal_fat_burning < 0){
                    line_width_ls_normal_fat_burning_draw = -lenght_ls_normal_fat_burning;
                    start_y_normal_fat_burning_draw = start_y_normal_fat_burning_draw - line_width_ls_normal_fat_burning_draw;
                  };
                  
                  normal_fat_burning_linear_scale.setProperty(hmUI.prop.MORE, {
                    x: start_x_normal_fat_burning_draw,
                    y: start_y_normal_fat_burning_draw,
                    w: lenght_ls_normal_fat_burning_draw,
                    h: line_width_ls_normal_fat_burning_draw,
                    color: color_ls_normal_fat_burning,
                  });
                };

                console.log('update scales CALORIE');
                
                let valueCalories = calorie.current;
                let targetCalories = calorie.target;
                let progressCalories = valueCalories/targetCalories;
                if (progressCalories > 1) progressCalories = 1;
                let progress_ls_normal_calorie = progressCalories;

                if (screenType != hmSetting.screen_type.AOD) {

                  // normal_calorie_linear_scale
                  // initial parameters
                  let start_x_normal_calorie = 300;
                  let start_y_normal_calorie = 222;
                  let lenght_ls_normal_calorie = -55;
                  let line_width_ls_normal_calorie = 32;
                  let color_ls_normal_calorie = 0xFFD9D9D9;
                  
                  // calculated parameters
                  let start_x_normal_calorie_draw = start_x_normal_calorie;
                  let start_y_normal_calorie_draw = start_y_normal_calorie;
                  lenght_ls_normal_calorie = lenght_ls_normal_calorie * progress_ls_normal_calorie;
                  let lenght_ls_normal_calorie_draw = line_width_ls_normal_calorie;
                  let line_width_ls_normal_calorie_draw = lenght_ls_normal_calorie;
                  if (lenght_ls_normal_calorie < 0){
                    line_width_ls_normal_calorie_draw = -lenght_ls_normal_calorie;
                    start_y_normal_calorie_draw = start_y_normal_calorie_draw - line_width_ls_normal_calorie_draw;
                  };
                  
                  normal_calorie_linear_scale.setProperty(hmUI.prop.MORE, {
                    x: start_x_normal_calorie_draw,
                    y: start_y_normal_calorie_draw,
                    w: lenght_ls_normal_calorie_draw,
                    h: line_width_ls_normal_calorie_draw,
                    color: color_ls_normal_calorie,
                  });
                };

                console.log('update scales PAI');
                
                let valuePAI = pai.totalpai;
                let targetPAI = 100;
                let progressPAI = valuePAI/targetPAI;
                if (progressPAI > 1) progressPAI = 1;
                let progress_ls_normal_pai = progressPAI;

                if (screenType != hmSetting.screen_type.AOD) {

                  // normal_pai_linear_scale
                  // initial parameters
                  let start_x_normal_pai = 259;
                  let start_y_normal_pai = 222;
                  let lenght_ls_normal_pai = -55;
                  let line_width_ls_normal_pai = 32;
                  let color_ls_normal_pai = 0xFFD9D9D9;
                  
                  // calculated parameters
                  let start_x_normal_pai_draw = start_x_normal_pai;
                  let start_y_normal_pai_draw = start_y_normal_pai;
                  lenght_ls_normal_pai = lenght_ls_normal_pai * progress_ls_normal_pai;
                  let lenght_ls_normal_pai_draw = line_width_ls_normal_pai;
                  let line_width_ls_normal_pai_draw = lenght_ls_normal_pai;
                  if (lenght_ls_normal_pai < 0){
                    line_width_ls_normal_pai_draw = -lenght_ls_normal_pai;
                    start_y_normal_pai_draw = start_y_normal_pai_draw - line_width_ls_normal_pai_draw;
                  };
                  
                  normal_pai_linear_scale.setProperty(hmUI.prop.MORE, {
                    x: start_x_normal_pai_draw,
                    y: start_y_normal_pai_draw,
                    w: lenght_ls_normal_pai_draw,
                    h: line_width_ls_normal_pai_draw,
                    color: color_ls_normal_pai,
                  });
                };

                console.log('update scales STEP');
                
                let valueStep = step.current;
                let targetStep = step.target;
                let progressStep = valueStep/targetStep;
                if (progressStep > 1) progressStep = 1;
                let progress_ls_normal_step = progressStep;

                if (screenType != hmSetting.screen_type.AOD) {

                  // normal_step_linear_scale
                  // initial parameters
                  let start_x_normal_step = 218;
                  let start_y_normal_step = 222;
                  let lenght_ls_normal_step = -55;
                  let line_width_ls_normal_step = 32;
                  let color_ls_normal_step = 0xFFD9D9D9;
                  
                  // calculated parameters
                  let start_x_normal_step_draw = start_x_normal_step;
                  let start_y_normal_step_draw = start_y_normal_step;
                  lenght_ls_normal_step = lenght_ls_normal_step * progress_ls_normal_step;
                  let lenght_ls_normal_step_draw = line_width_ls_normal_step;
                  let line_width_ls_normal_step_draw = lenght_ls_normal_step;
                  if (lenght_ls_normal_step < 0){
                    line_width_ls_normal_step_draw = -lenght_ls_normal_step;
                    start_y_normal_step_draw = start_y_normal_step_draw - line_width_ls_normal_step_draw;
                  };
                  
                  normal_step_linear_scale.setProperty(hmUI.prop.MORE, {
                    x: start_x_normal_step_draw,
                    y: start_y_normal_step_draw,
                    w: lenght_ls_normal_step_draw,
                    h: line_width_ls_normal_step_draw,
                    color: color_ls_normal_step,
                  });
                };

                console.log('update scales HEART');
                
                let valueHeartRate = heart_rate.last;
                let targetHeartRate = 184;
                let progressHeartRate = (valueHeartRate - 30)/(targetHeartRate - 30);
                if (progressHeartRate < 0) progressHeartRate = 0;
                if (progressHeartRate > 1) progressHeartRate = 1;
                let progress_ls_normal_heart_rate = progressHeartRate;

                if (screenType != hmSetting.screen_type.AOD) {

                  // normal_heart_rate_linear_scale
                  // initial parameters
                  let start_x_normal_heart_rate = 177;
                  let start_y_normal_heart_rate = 222;
                  let lenght_ls_normal_heart_rate = -55;
                  let line_width_ls_normal_heart_rate = 32;
                  let color_ls_normal_heart_rate = 0xFFD9D9D9;
                  
                  // calculated parameters
                  let start_x_normal_heart_rate_draw = start_x_normal_heart_rate;
                  let start_y_normal_heart_rate_draw = start_y_normal_heart_rate;
                  lenght_ls_normal_heart_rate = lenght_ls_normal_heart_rate * progress_ls_normal_heart_rate;
                  let lenght_ls_normal_heart_rate_draw = line_width_ls_normal_heart_rate;
                  let line_width_ls_normal_heart_rate_draw = lenght_ls_normal_heart_rate;
                  if (lenght_ls_normal_heart_rate < 0){
                    line_width_ls_normal_heart_rate_draw = -lenght_ls_normal_heart_rate;
                    start_y_normal_heart_rate_draw = start_y_normal_heart_rate_draw - line_width_ls_normal_heart_rate_draw;
                  };
                  
                  normal_heart_rate_linear_scale.setProperty(hmUI.prop.MORE, {
                    x: start_x_normal_heart_rate_draw,
                    y: start_y_normal_heart_rate_draw,
                    w: lenght_ls_normal_heart_rate_draw,
                    h: line_width_ls_normal_heart_rate_draw,
                    color: color_ls_normal_heart_rate,
                  });
                };

                console.log('update scales BATTERY');
                
                let valueBattery = battery.current;
                let targetBattery = 100;
                let progressBattery = valueBattery/targetBattery;
                if (progressBattery > 1) progressBattery = 1;
                let progress_ls_normal_battery = progressBattery;

                if (screenType != hmSetting.screen_type.AOD) {

                  // normal_battery_linear_scale
                  // initial parameters
                  let start_x_normal_battery = 137;
                  let start_y_normal_battery = 222;
                  let lenght_ls_normal_battery = -55;
                  let line_width_ls_normal_battery = 32;
                  let color_ls_normal_battery = 0xFFD9D9D9;
                  
                  // calculated parameters
                  let start_x_normal_battery_draw = start_x_normal_battery;
                  let start_y_normal_battery_draw = start_y_normal_battery;
                  lenght_ls_normal_battery = lenght_ls_normal_battery * progress_ls_normal_battery;
                  let lenght_ls_normal_battery_draw = line_width_ls_normal_battery;
                  let line_width_ls_normal_battery_draw = lenght_ls_normal_battery;
                  if (lenght_ls_normal_battery < 0){
                    line_width_ls_normal_battery_draw = -lenght_ls_normal_battery;
                    start_y_normal_battery_draw = start_y_normal_battery_draw - line_width_ls_normal_battery_draw;
                  };
                  
                  normal_battery_linear_scale.setProperty(hmUI.prop.MORE, {
                    x: start_x_normal_battery_draw,
                    y: start_y_normal_battery_draw,
                    w: lenght_ls_normal_battery_draw,
                    h: line_width_ls_normal_battery_draw,
                    color: color_ls_normal_battery,
                  });
                };

                console.log('update scales FAT_BURNING');
                let progress_ls_idle_fat_burning = progressFatBurning;

                if (screenType == hmSetting.screen_type.AOD) {

                  // idle_fat_burning_linear_scale
                  // initial parameters
                  let start_x_idle_fat_burning = 340;
                  let start_y_idle_fat_burning = 222;
                  let lenght_ls_idle_fat_burning = -55;
                  let line_width_ls_idle_fat_burning = 32;
                  let color_ls_idle_fat_burning = 0xFFD9D9D9;
                  
                  // calculated parameters
                  let start_x_idle_fat_burning_draw = start_x_idle_fat_burning;
                  let start_y_idle_fat_burning_draw = start_y_idle_fat_burning;
                  lenght_ls_idle_fat_burning = lenght_ls_idle_fat_burning * progress_ls_idle_fat_burning;
                  let lenght_ls_idle_fat_burning_draw = line_width_ls_idle_fat_burning;
                  let line_width_ls_idle_fat_burning_draw = lenght_ls_idle_fat_burning;
                  if (lenght_ls_idle_fat_burning < 0){
                    line_width_ls_idle_fat_burning_draw = -lenght_ls_idle_fat_burning;
                    start_y_idle_fat_burning_draw = start_y_idle_fat_burning_draw - line_width_ls_idle_fat_burning_draw;
                  };
                  
                  idle_fat_burning_linear_scale.setProperty(hmUI.prop.MORE, {
                    x: start_x_idle_fat_burning_draw,
                    y: start_y_idle_fat_burning_draw,
                    w: lenght_ls_idle_fat_burning_draw,
                    h: line_width_ls_idle_fat_burning_draw,
                    color: color_ls_idle_fat_burning,
                  });
                };

                console.log('update scales CALORIE');
                let progress_ls_idle_calorie = progressCalories;

                if (screenType == hmSetting.screen_type.AOD) {

                  // idle_calorie_linear_scale
                  // initial parameters
                  let start_x_idle_calorie = 300;
                  let start_y_idle_calorie = 222;
                  let lenght_ls_idle_calorie = -55;
                  let line_width_ls_idle_calorie = 32;
                  let color_ls_idle_calorie = 0xFFD9D9D9;
                  
                  // calculated parameters
                  let start_x_idle_calorie_draw = start_x_idle_calorie;
                  let start_y_idle_calorie_draw = start_y_idle_calorie;
                  lenght_ls_idle_calorie = lenght_ls_idle_calorie * progress_ls_idle_calorie;
                  let lenght_ls_idle_calorie_draw = line_width_ls_idle_calorie;
                  let line_width_ls_idle_calorie_draw = lenght_ls_idle_calorie;
                  if (lenght_ls_idle_calorie < 0){
                    line_width_ls_idle_calorie_draw = -lenght_ls_idle_calorie;
                    start_y_idle_calorie_draw = start_y_idle_calorie_draw - line_width_ls_idle_calorie_draw;
                  };
                  
                  idle_calorie_linear_scale.setProperty(hmUI.prop.MORE, {
                    x: start_x_idle_calorie_draw,
                    y: start_y_idle_calorie_draw,
                    w: lenght_ls_idle_calorie_draw,
                    h: line_width_ls_idle_calorie_draw,
                    color: color_ls_idle_calorie,
                  });
                };

                console.log('update scales PAI');
                let progress_ls_idle_pai = progressPAI;

                if (screenType == hmSetting.screen_type.AOD) {

                  // idle_pai_linear_scale
                  // initial parameters
                  let start_x_idle_pai = 259;
                  let start_y_idle_pai = 222;
                  let lenght_ls_idle_pai = -55;
                  let line_width_ls_idle_pai = 32;
                  let color_ls_idle_pai = 0xFFD9D9D9;
                  
                  // calculated parameters
                  let start_x_idle_pai_draw = start_x_idle_pai;
                  let start_y_idle_pai_draw = start_y_idle_pai;
                  lenght_ls_idle_pai = lenght_ls_idle_pai * progress_ls_idle_pai;
                  let lenght_ls_idle_pai_draw = line_width_ls_idle_pai;
                  let line_width_ls_idle_pai_draw = lenght_ls_idle_pai;
                  if (lenght_ls_idle_pai < 0){
                    line_width_ls_idle_pai_draw = -lenght_ls_idle_pai;
                    start_y_idle_pai_draw = start_y_idle_pai_draw - line_width_ls_idle_pai_draw;
                  };
                  
                  idle_pai_linear_scale.setProperty(hmUI.prop.MORE, {
                    x: start_x_idle_pai_draw,
                    y: start_y_idle_pai_draw,
                    w: lenght_ls_idle_pai_draw,
                    h: line_width_ls_idle_pai_draw,
                    color: color_ls_idle_pai,
                  });
                };

                console.log('update scales STEP');
                let progress_ls_idle_step = progressStep;

                if (screenType == hmSetting.screen_type.AOD) {

                  // idle_step_linear_scale
                  // initial parameters
                  let start_x_idle_step = 218;
                  let start_y_idle_step = 222;
                  let lenght_ls_idle_step = -55;
                  let line_width_ls_idle_step = 32;
                  let color_ls_idle_step = 0xFFD9D9D9;
                  
                  // calculated parameters
                  let start_x_idle_step_draw = start_x_idle_step;
                  let start_y_idle_step_draw = start_y_idle_step;
                  lenght_ls_idle_step = lenght_ls_idle_step * progress_ls_idle_step;
                  let lenght_ls_idle_step_draw = line_width_ls_idle_step;
                  let line_width_ls_idle_step_draw = lenght_ls_idle_step;
                  if (lenght_ls_idle_step < 0){
                    line_width_ls_idle_step_draw = -lenght_ls_idle_step;
                    start_y_idle_step_draw = start_y_idle_step_draw - line_width_ls_idle_step_draw;
                  };
                  
                  idle_step_linear_scale.setProperty(hmUI.prop.MORE, {
                    x: start_x_idle_step_draw,
                    y: start_y_idle_step_draw,
                    w: lenght_ls_idle_step_draw,
                    h: line_width_ls_idle_step_draw,
                    color: color_ls_idle_step,
                  });
                };

                console.log('update scales HEART');
                let progress_ls_idle_heart_rate = progressHeartRate;

                if (screenType == hmSetting.screen_type.AOD) {

                  // idle_heart_rate_linear_scale
                  // initial parameters
                  let start_x_idle_heart_rate = 177;
                  let start_y_idle_heart_rate = 222;
                  let lenght_ls_idle_heart_rate = -55;
                  let line_width_ls_idle_heart_rate = 32;
                  let color_ls_idle_heart_rate = 0xFFD9D9D9;
                  
                  // calculated parameters
                  let start_x_idle_heart_rate_draw = start_x_idle_heart_rate;
                  let start_y_idle_heart_rate_draw = start_y_idle_heart_rate;
                  lenght_ls_idle_heart_rate = lenght_ls_idle_heart_rate * progress_ls_idle_heart_rate;
                  let lenght_ls_idle_heart_rate_draw = line_width_ls_idle_heart_rate;
                  let line_width_ls_idle_heart_rate_draw = lenght_ls_idle_heart_rate;
                  if (lenght_ls_idle_heart_rate < 0){
                    line_width_ls_idle_heart_rate_draw = -lenght_ls_idle_heart_rate;
                    start_y_idle_heart_rate_draw = start_y_idle_heart_rate_draw - line_width_ls_idle_heart_rate_draw;
                  };
                  
                  idle_heart_rate_linear_scale.setProperty(hmUI.prop.MORE, {
                    x: start_x_idle_heart_rate_draw,
                    y: start_y_idle_heart_rate_draw,
                    w: lenght_ls_idle_heart_rate_draw,
                    h: line_width_ls_idle_heart_rate_draw,
                    color: color_ls_idle_heart_rate,
                  });
                };

                console.log('update scales BATTERY');
                let progress_ls_idle_battery = progressBattery;

                if (screenType == hmSetting.screen_type.AOD) {

                  // idle_battery_linear_scale
                  // initial parameters
                  let start_x_idle_battery = 137;
                  let start_y_idle_battery = 222;
                  let lenght_ls_idle_battery = -55;
                  let line_width_ls_idle_battery = 32;
                  let color_ls_idle_battery = 0xFFD9D9D9;
                  
                  // calculated parameters
                  let start_x_idle_battery_draw = start_x_idle_battery;
                  let start_y_idle_battery_draw = start_y_idle_battery;
                  lenght_ls_idle_battery = lenght_ls_idle_battery * progress_ls_idle_battery;
                  let lenght_ls_idle_battery_draw = line_width_ls_idle_battery;
                  let line_width_ls_idle_battery_draw = lenght_ls_idle_battery;
                  if (lenght_ls_idle_battery < 0){
                    line_width_ls_idle_battery_draw = -lenght_ls_idle_battery;
                    start_y_idle_battery_draw = start_y_idle_battery_draw - line_width_ls_idle_battery_draw;
                  };
                  
                  idle_battery_linear_scale.setProperty(hmUI.prop.MORE, {
                    x: start_x_idle_battery_draw,
                    y: start_y_idle_battery_draw,
                    w: lenght_ls_idle_battery_draw,
                    h: line_width_ls_idle_battery_draw,
                    color: color_ls_idle_battery,
                  });
                };

            };

            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                console.log('resume_call()');
                scale_call();
                time_update(true, true);
                if (screenType == hmSetting.screen_type.WATCHFACE) {
                  if (!normal_timerTimeUpdate) {
                    normal_timerTimeUpdate = timer.createTimer(0, 1000, (function (option) {
                      let updateHour = timeSensor.minute == 0;
                      let updateMinute = timeSensor.second < 2;
                      time_update(updateHour, updateMinute);
                    }));  // end timer 
                  };  // end timer check
                };  // end screenType

                if (screenType == hmSetting.screen_type.AOD) {
                  if (!idle_timerTimeUpdate) {
                    idle_timerTimeUpdate = timer.createTimer(0, 1000, (function (option) {
                      let updateHour = timeSensor.minute == 0;
                      let updateMinute = timeSensor.second < 2;
                      time_update(updateHour, updateMinute);
                    }));  // end timer 
                  };  // end timer check
                };  // end screenType


              }),
              pause_call: (function () {
                console.log('pause_call()');
                if (normal_timerTimeUpdate) {
                  timer.stopTimer(normal_timerTimeUpdate);
                  normal_timerTimeUpdate = undefined;
                }
                if (idle_timerTimeUpdate) {
                  timer.stopTimer(idle_timerTimeUpdate);
                  idle_timerTimeUpdate = undefined;
                }

              }),
            });

                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}