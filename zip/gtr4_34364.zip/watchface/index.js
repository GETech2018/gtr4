﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        var __$$app$$__ = __$$hmAppManager$$__.currentApp;
		var __$$module$$__ = __$$app$$__.current;

		//drink is a name,can modify
		var h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__), 'drink');

		'use strict';

        //dynamic modify start
        let normal_background_bg_img = ''
        let normal_system_disconnect_img = ''
        let normal_date_img_date_day = ''
        let normal_analog_clock_pro_hour_pointer_img = ''
        let normal_analog_clock_time_pointer_hour = ''
        let normal_analog_clock_time_pointer_minute = ''
        let normal_analog_clock_time_pointer_second = ''
		let chronoInterval;
		let chronoIsRunning = false;
		let chronoStart = 0;
		let chronoStoppedAt = 0;
		let normal_chrono_seconds_rotary = '';
		let normal_chrono_seconds_rotary_start_angle = 0;
		let normal_chrono_seconds_rotary_end_angle = 360;
		let normal_chrono_minutes_rotary = '';
		let normal_chrono_minutes_rotary_start_angle = 0;
		let normal_chrono_minutes_rotary_end_angle = 720;
		let normal_chrono_start_stop = '';
		let normal_chrono_start_stop_array = ['minute.png','minute.png'];
		let normal_chrono_reset = '';
		let normal_chrono_reset_array = ['minute.png','second.png'];
        let idle_background_bg_img = ''
        let idle_battery_pointer_progress_img_pointer = ''
        let idle_system_disconnect_img = ''
        let idle_date_img_date_day = ''
        let idle_analog_clock_time_pointer_hour = ''
        let idle_analog_clock_time_pointer_minute = ''
        let idle_analog_clock_time_pointer_second = ''
        let timeSensor = ''
        //dynamic modify end

        
		//not required
		const logger = DeviceRuntimeCore.HmLogger.getLogger("yeguang");

		__$$module$$__.module = DeviceRuntimeCore.WatchFace({
			init_view() {

				const timeSensor = hmSensor.createSensor(hmSensor.id.TIME);
				let screenType = hmSetting.getScreenType();
                    
                
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 466,
              h: 466,
              src: '2.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
			
			normal_chrono_seconds_rotary = hmUI.createWidget(hmUI.widget.IMG, {
				x: 0,
				y: 0,
				w: 466,
				h: 466,
				center_x: 127,
				center_y: 233,
				pos_x: 122,
				pos_y: 198,
				src: '3.png',
				enable: false,
				show_level: hmUI.show_level.ONLY_NORMAL,
			});
			

			normal_chrono_minutes_rotary = hmUI.createWidget(hmUI.widget.IMG, {
				x: 0,
				y: 0,
				w: 466,
				h: 466,
				center_x: 233,
				center_y: 133,
				pos_x: 228,
				pos_y: 97,
				src: '8.png',
				enable: false,
				show_level: hmUI.show_level.ONLY_NORMAL,
			});

            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 290,
              y: 258,
              src: 'bt.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 356,
              day_startY: 220,
              day_sc_array: ["12.png","13.png","14.png","15.png","16.png","17.png","18.png","19.png","20.png","21.png"],
              day_tc_array: ["12.png","13.png","14.png","15.png","16.png","17.png","18.png","19.png","20.png","21.png"],
              day_en_array: ["12.png","13.png","14.png","15.png","16.png","17.png","18.png","19.png","20.png","21.png"],
              day_zero: 0,
              day_space: -2,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            const deviceInfo = hmSetting.getDeviceInfo();
            if (!timeSensor) timeSensor = hmSensor.createSensor(hmSensor.id.TIME);
            timeSensor.addEventListener(timeSensor.event.MINUTEEND, function() {
              time_update(true, true);
            });

            // normal_analog_clock_pro_hour_pointer_img = hmUI.createWidget(hmUI.widget.TIME_POINTER_PRO, {
              // src: '8.png',
              // center_x: 233,
              // center_y: 333,
              // x: 4,
              // y: 36,
              // start_angle: 0,
              // end_angle: 360,
              // type: hmUI.data_type.hour,
              // show_level: hmUI.show_level.ONLY_NORMAL,
              // format24h: true,
            // });


            normal_analog_clock_pro_hour_pointer_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: deviceInfo.width,
              h: deviceInfo.height,
              pos_x: 233 - 4,
              pos_y: 333 - 36,
              center_x: 233,
              center_y: 333,
              src: '8.png',
              angle: 0,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_hour = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              hour_path: '5.png',
              hour_centerX: 233,
              hour_centerY: 233,
              hour_posX: 25,
              hour_posY: 233,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_minute = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              minute_path: '4.png',
              minute_centerX: 233,
              minute_centerY: 233,
              minute_posX: 25,
              minute_posY: 228,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_second = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              second_path: '7.png',
              second_centerX: 233,
              second_centerY: 233,
              second_posX: 25,
              second_posY: 215,
              second_cover_path: '6.png',
              second_cover_x: 209,
              second_cover_y: 209,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
			
			    normal_chrono_start_stop = hmUI.createWidget(hmUI.widget.IMG, {
					x: 185,
					y: 85,
					w: 100,
					h: 100,
					src: 'minute.png',
					show_level: hmUI.show_level.ONLY_NORMAL
				});

				normal_chrono_start_stop.addEventListener(hmUI.event.CLICK_DOWN, (info) => {
					if (!chronoIsRunning) {
						chronoInterval = setInterval(updateChrono, 1);
						chronoIsRunning = true;
						chronoStart = chronoStart == 0 ? timeSensor.utc : chronoStart + (timeSensor.utc-chronoStoppedAt);
					} else {
						clearInterval(chronoInterval);
						chronoIsRunning = false;
						chronoStoppedAt = timeSensor.utc;
					}
					normal_chrono_start_stop.setProperty(hmUI.prop.MORE, {
						src: normal_chrono_start_stop_array[Number(chronoIsRunning)]
					})
					normal_chrono_reset.setProperty(hmUI.prop.MORE, {
						src: normal_chrono_reset_array[Number(chronoIsRunning)],
						enable: !chronoIsRunning
					})
					vibro();
				});

				normal_chrono_reset = hmUI.createWidget(hmUI.widget.IMG, {
					x: 75,
					y: 190,
					w: 75,
					h: 75,
					src: 'second.png',
					show_level: hmUI.show_level.ONLY_NORMAL
				});

				normal_chrono_reset.addEventListener(hmUI.event.CLICK_DOWN, (info) => {
					if (!chronoIsRunning) {
						chronoStart = 0;
						/*
						if (typeof normal_chrono_hours != 'undefined') {
							for (let i=0; i < normal_chrono_hours.length; i++) {
								normal_chrono_hours[i].setProperty(hmUI.prop.MORE, {
									src: normal_chrono_hours_array[0]
								})
							}
						}
						if (typeof normal_chrono_minutes != 'undefined') {
							for (let i=0; i < normal_chrono_minutes.length; i++) {
								normal_chrono_minutes[i].setProperty(hmUI.prop.MORE, {
									src: normal_chrono_minutes_array[0]
								})
							}
						}
						if (typeof normal_chrono_seconds != 'undefined') {
							for (let i=0; i < normal_chrono_seconds.length; i++) {
								normal_chrono_seconds[i].setProperty(hmUI.prop.MORE, {
									src: normal_chrono_seconds_array[0]
								})
							}
						}
						if (typeof normal_chrono_milliseconds != 'undefined') {
							for (let i=0; i < normal_chrono_milliseconds.length; i++) {
								normal_chrono_milliseconds[i].setProperty(hmUI.prop.MORE, {
									src: normal_chrono_milliseconds_array[0]
								})
							}
						}

						if (typeof normal_chrono_hours_rotary != 'undefined') {
							normal_chrono_hours_rotary.setProperty(hmUI.prop.MORE, {
								angle: normal_chrono_hours_rotary_start_angle
							})
						}
						*/
						if (typeof normal_chrono_minutes_rotary != 'undefined') {
							normal_chrono_minutes_rotary.setProperty(hmUI.prop.MORE, {
								angle: normal_chrono_minutes_rotary_start_angle
							})
						}

						if (typeof normal_chrono_seconds_rotary != 'undefined') {
							normal_chrono_seconds_rotary.setProperty(hmUI.prop.MORE, {
								angle: normal_chrono_seconds_rotary_start_angle
							})
						}

						vibro();
					}
				});


            idle_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 466,
              h: 466,
              src: 'aod.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_battery_pointer_progress_img_pointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
              src: '3.png',
              center_x: 127,
              center_y: 233,
              x: 4,
              y: 36,
              start_angle: 0,
              end_angle: 360,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 290,
              y: 258,
              src: 'bt.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 356,
              day_startY: 220,
              day_sc_array: ["12.png","13.png","14.png","15.png","16.png","17.png","18.png","19.png","20.png","21.png"],
              day_tc_array: ["12.png","13.png","14.png","15.png","16.png","17.png","18.png","19.png","20.png","21.png"],
              day_en_array: ["12.png","13.png","14.png","15.png","16.png","17.png","18.png","19.png","20.png","21.png"],
              day_zero: 0,
              day_space: -2,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_analog_clock_time_pointer_hour = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              hour_path: '5.png',
              hour_centerX: 233,
              hour_centerY: 233,
              hour_posX: 25,
              hour_posY: 233,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_analog_clock_time_pointer_minute = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              minute_path: '4.png',
              minute_centerX: 233,
              minute_centerY: 233,
              minute_posX: 25,
              minute_posY: 228,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_analog_clock_time_pointer_second = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              second_path: '7.png',
              second_centerX: 233,
              second_centerY: 233,
              second_posX: 25,
              second_posY: 215,
              second_cover_path: '6.png',
              second_cover_x: 209,
              second_cover_y: 209,
              show_level: hmUI.show_level.ONLY_AOD,
            });
			
			function updateChrono() {
					let curTime = timeSensor.utc;
					let curDiff = curTime-chronoStart;
					let curMilli = curDiff.toString().substr(curDiff.toString().length - 3).padStart(3, '0');
					let curSeconds = Math.floor((curDiff)/1000).toString().padStart(2, '0');
					let curMinutes = Math.floor(curSeconds/60).toString().padStart(2, '0');
					let curHours = Math.floor(curMinutes/60).toString().padStart(2, '0');
					/*
					if (typeof normal_chrono_hours != 'undefined' && normal_chrono_hours.length > 0) {
						for (let i=0; i < normal_chrono_hours.length; i++) {
							normal_chrono_hours[i].setProperty(hmUI.prop.MORE, {
								src: normal_chrono_hours_array[curHours.charAt(i)]
							})
						}
					}

					if (typeof normal_chrono_minutes != 'undefined' && normal_chrono_minutes.length > 0) {
						for (let i=0; i < normal_chrono_minutes.length; i++) {
							normal_chrono_minutes[i].setProperty(hmUI.prop.MORE, {
								src: normal_chrono_minutes_array[curMinutes.charAt(i)]
							})
						}
					}

					if (typeof normal_chrono_seconds != 'undefined' && normal_chrono_seconds.length > 0) {
						for (let i=0; i < normal_chrono_seconds.length; i++) {
							normal_chrono_seconds[i].setProperty(hmUI.prop.MORE, {
								src: normal_chrono_seconds_array[curSeconds.charAt(i)]
							})
						}
					}

					if (typeof normal_chrono_milliseconds != 'undefined' && normal_chrono_milliseconds.length > 0) {
						for (let i=0; i < normal_chrono_milliseconds.length; i++) {
							normal_chrono_milliseconds[i].setProperty(hmUI.prop.MORE, {
								src: normal_chrono_milliseconds_array[curMilli.charAt(i)]
							})
						}
					}

					if (typeof normal_chrono_hours_rotary != 'undefined') {
						let hsa = normal_chrono_hours_rotary_start_angle;
						let hea = normal_chrono_hours_rotary_end_angle;
						let hcw = hea > hsa;
						let hd = hcw ? hea - hsa : hsa - hea;
						let hfac = hd / 360;
						normal_chrono_hours_rotary.setProperty(hmUI.prop.MORE, {
							angle: (hcw ? (hsa + (parseInt(curHours) * (6 * hfac))) : (hsa - (parseInt(curHours) * (6 * hfac))))
						})
					}
*/
					if (typeof normal_chrono_minutes_rotary != 'undefined') {
						let msa = normal_chrono_minutes_rotary_start_angle;
						let mea = normal_chrono_minutes_rotary_end_angle;
						let mcw = mea > msa;
						let md = mcw ? mea - msa : msa - mea;
						let mfac = md / 360;
						normal_chrono_minutes_rotary.setProperty(hmUI.prop.MORE, {
							angle: (mcw ? (msa + (parseInt(curMinutes) * (6 * mfac))) : (msa - (parseInt(curMinutes) * (6 * mfac))))
						})
					}

					if (typeof normal_chrono_seconds_rotary != 'undefined') {
						let ssa = normal_chrono_seconds_rotary_start_angle;
						let sea = normal_chrono_seconds_rotary_end_angle;
						let scw = sea > ssa;
						let sd = scw ? sea - ssa : ssa - sea;
						let sfac = sd / 360;
						normal_chrono_seconds_rotary.setProperty(hmUI.prop.MORE, {
							angle: (scw ? (ssa + ((parseInt(curSeconds) + (parseInt(curMilli) / 1000)) * (6 * sfac))) : (ssa - ((parseInt(curSeconds) + (parseInt(curMilli) / 1000)) * (6 * sfac))))
						})
					}

				}
            
            // disconnectAlert = hmUI.createWidget(hmUI.widget.DisconnectAlert, {
              // disconneсnt_vibrate_type: 9,
              // disconneсnt_toast_text: Connect \n LOST,
              // conneсnt_vibrate_type: 0,
              // conneсnt_toast_text: Connect \n FIND,
            // });

            // vibration when connecting or disconnecting

            function checkConnection() {
              hmBle.removeListener;
              hmBle.addListener(function (status) {
                if(!status) {
                  hmUI.showToast({text: "Connect \n LOST"});
                  vibro(9);
                }
                if(status) {
                  hmUI.showToast({text: "Connect \n FIND"});
                  vibro(0);
                }
              });
            }

            // end vibration when connecting or disconnecting
            // vibrate function

            const vibrate = hmSensor.createSensor(hmSensor.id.VIBRATE);
            let timer_StopVibrate = null;


            function vibro(scene = 25) {
              let stopDelay = 50;
              stopVibro();
              vibrate.stop();
              vibrate.scene = scene;
              if(scene < 23 || scene > 25) stopDelay = 1300;
              vibrate.start();
              timer_StopVibrate = timer.createTimer(stopDelay, 3000, stopVibro, {});
            }

            function stopVibro(){
              vibrate.stop();
              if(timer_StopVibrate) timer.stopTimer(timer_StopVibrate);
            }

            // end vibrate function

            function time_update(updateHour = false, updateMinute = false) {
              let hour = timeSensor.hour;
              let minute = timeSensor.minute;
              let second = timeSensor.second;

              if (updateHour) {
                let normal_hour = hour;
                let normal_fullAngle_hour = 360;
                let normal_angle_hour = 0 + normal_fullAngle_hour*normal_hour/24 + (normal_fullAngle_hour/24)*minute/60;
                if (normal_analog_clock_pro_hour_pointer_img) normal_analog_clock_pro_hour_pointer_img.setProperty(hmUI.prop.ANGLE, normal_angle_hour);
              };

            };

            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                if (chronoIsRunning) {
					chronoInterval = setInterval(updateChrono, 50);
				}
				time_update(true, true);
                checkConnection();
                stopVibro();
              }),
              pause_call: (function () {
                clearInterval(chronoInterval);
				stopVibro();
              }),
            });

        },

                //dynamic modify end
        onInit() {
			console.log('index page.js on init invoke')
			this.init_view()
		},
		onReady() {
			console.log('index page.js on ready invoke')
		},
		onShow() {
			console.log('index page.js on show invoke')
		},
		onHide() {
			console.log('index page.js on hide invoke')
		},
		onDestroy() {
			console.log('index page.js on destroy invoke')
        },
        });	})()
} catch (e) {
	console.log(e)
}