﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        const logger = Logger.getLogger('watchface_SashaCX75');
        //end of ignored block

        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_date_img_date_day = ''
        let normal_step_pointer_progress_img_pointer = ''
        let normal_step_current_text_img = ''
        let normal_battery_pointer_progress_img_pointer = ''
        let normal_battery_text_text_img = ''
        let normal_compass_direction_pointer_img = ''
		let normal_analog_clock_pro_hour_pointer_img = "";
        let normal_analog_clock_pro_minute_pointer_img = "";
        let normal_analog_clock_pro_second_pointer_img = "";
        let normal_world_clock_pointer_img = "";
        let normal_timerUpdate = undefined;
        let normal_timerUpdateSec = undefined;
        let normal_analog_clock_pro_second_cover_pointer_img = "";
        let idle_background_bg_img = ''
		let idle_analog_clock_time_pointer_hour = "";
        let idle_analog_clock_time_pointer_minute = "";
        let idle_world_clock_pointer_img = "";
        let timeSensor = "";

        let wt_angle_delta = 360 / 24 / 60;
        let wt_current_angle = 0;
        let wt_target_angle = 0;
        let index = 0;
        let worldData = undefined;

        let timer_animate_seconds = undefined;
        let timer_animate_wt = undefined;
        
		let normal_step_jumpable_img_click = ''
        let normal_battery_jumpable_img_click = ''
        let normal_spo2_jumpable_img_click = ''
        let Button_1 = ''


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            console.log('Watch_Face.ScreenNormal');
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 466,
              h: 466,
              src: 'bg.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 355,
              day_startY: 219,
              day_sc_array: ["9.png","10.png","11.png","12.png","13.png","14.png","15.png","16.png","17.png","18.png"],
              day_tc_array: ["9.png","10.png","11.png","12.png","13.png","14.png","15.png","16.png","17.png","18.png"],
              day_en_array: ["9.png","10.png","11.png","12.png","13.png","14.png","15.png","16.png","17.png","18.png"],
              day_zero: 1,
              day_space: -1,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_pointer_progress_img_pointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
              src: 'normal_mini_handle.png',
              center_x: 232,
              center_y: 338,
              x: 52,
              y: 52,
              start_angle: 0,
              end_angle: 360,
              invalid_visible: false,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 199,
              y: 350,
              font_array: ["94.png","95.png","96.png","97.png","98.png","99.png","100.png","101.png","102.png","103.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_pointer_progress_img_pointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
              src: 'normal_mini_handle.png',
              center_x: 232,
              center_y: 126,
              x: 52,
              y: 53,
              start_angle: 0,
              end_angle: 360,
              invalid_visible: false,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 208,
              y: 138,
              font_array: ["94.png","95.png","96.png","97.png","98.png","99.png","100.png","101.png","102.png","103.png"],
              padding: false,
              h_space: 0,
              unit_sc: '92.png',
              unit_tc: '92.png',
              unit_en: '92.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            const deviceInfo = hmSetting.getDeviceInfo();
            
            // normal_compass_custom_pointer_img = hmUI.createWidget(hmUI.widget.CUSTOM_POINTER, {
              // src: 'compass.png',
              // center_x: 123,
              // center_y: 230,
              // x: 26,
              // y: 32,
              // start_angle: 0,
              // end_angle: 360,
              // type: hmUI.data_type.COMPASS,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });


            //start of ignored block
            normal_compass_direction_pointer_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: deviceInfo.width,
              h: deviceInfo.height,
              pos_x: 123 - 26,
              pos_y: 230 - 32,
              center_x: 123,
              center_y: 230,
              src: 'compass.png',
              angle: 0,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            //end of ignored block
			
			const world_clock = hmSensor.createSensor(hmSensor.id.WORLD_CLOCK);
            world_clock.init();
            if (hmFS.SysProGetInt("SEIKO_wt_index")) index = hmFS.SysProGetInt("SEIKO_wt_index");

            if (!timeSensor) timeSensor = hmSensor.createSensor(hmSensor.id.TIME);
            timeSensor.addEventListener(timeSensor.event.MINUTEEND, function () {
              time_update(true, true);
            });
			
			normal_world_clock_pointer_img = hmUI.createWidget(hmUI.widget.IMG, {
          x: 0,
          y: 0,
          w: deviceInfo.width,
          h: deviceInfo.height,
          pos_x: 233 - 20,
          pos_y: 233 - 233,
          center_x: 233,
          center_y: 233,
          src: "normal_gmt.png",
          angle: 0,
          show_level: hmUI.show_level.ONLY_NORMAL,
        });

        normal_analog_clock_pro_hour_pointer_img = hmUI.createWidget(hmUI.widget.IMG, {
          x: 0,
          y: 0,
          w: deviceInfo.width,
          h: deviceInfo.height,
          pos_x: 233 - 25,
          pos_y: 233 - 233,
          center_x: 233,
          center_y: 233,
          src: "normal_hours.png",
          angle: 0,
          show_level: hmUI.show_level.ONLY_NORMAL,
        });

        normal_analog_clock_pro_minute_pointer_img = hmUI.createWidget(hmUI.widget.IMG, {
          x: 0,
          y: 0,
          w: deviceInfo.width,
          h: deviceInfo.height,
          pos_x: 233 - 24,
          pos_y: 233 - 233,
          center_x: 233,
          center_y: 233,
          src: "normal_minutes.png",
          angle: 0,
          show_level: hmUI.show_level.ONLY_NORMAL,
        });

        normal_analog_clock_pro_second_pointer_img = hmUI.createWidget(hmUI.widget.IMG, {
          x: 0,
          y: 0,
          w: deviceInfo.width,
          h: deviceInfo.height,
          pos_x: 233 - 22,
          pos_y: 233 - 233,
          center_x: 233,
          center_y: 233,
          src: "normal_seconds.png",
          angle: 0,
          show_level: hmUI.show_level.ONLY_NORMAL,
        });

        let screenType = hmSetting.getScreenType();
        normal_analog_clock_pro_second_cover_pointer_img = hmUI.createWidget(hmUI.widget.IMG, {
          x: 228,
          y: 228,
          src: "normal_center.png",
          show_level: hmUI.show_level.ONLY_NORMAL,
        });


            console.log('Watch_Face.ScreenAOD');
            idle_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 466,
              h: 466,
              src: 'idle_bg.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });
			
			idle_world_clock_pointer_img = hmUI.createWidget(hmUI.widget.IMG, {
          x: 0,
          y: 0,
          w: deviceInfo.width,
          h: deviceInfo.height,
          pos_x: 233 - 20,
          pos_y: 233 - 233,
          center_x: 233,
          center_y: 233,
          src: "idle_gmt.png",
          angle: 0,
          show_level: hmUI.show_level.ONLY_AOD,
        });

        idle_analog_clock_time_pointer_hour = hmUI.createWidget(hmUI.widget.IMG, {
          x: 0,
          y: 0,
          w: deviceInfo.width,
          h: deviceInfo.height,
          pos_x: 233 - 25,
          pos_y: 233 - 233,
          center_x: 233,
          center_y: 233,
          src: "idle_hours.png",
          angle: 0,
          show_level: hmUI.show_level.ONLY_AOD,
        });

        idle_analog_clock_time_pointer_minute = hmUI.createWidget(hmUI.widget.IMG, {
          x: 0,
          y: 0,
          w: deviceInfo.width,
          h: deviceInfo.height,
          pos_x: 233 - 24,
          pos_y: 233 - 233,
          center_x: 233,
          center_y: 233,
          src: "idle_minutes.png",
          angle: 0,
          show_level: hmUI.show_level.ONLY_AOD,
        });
            console.log('Watch_Face.Shortcuts');

            normal_step_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 186,
              y: 291,
              w: 97,
              h: 97,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 194,
              y: 117,
              w: 78,
              h: 49,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            let gmtButton = hmUI.createWidget(hmUI.widget.BUTTON, {
          x: 272, // x coordinate of the button
          y: 204, // y coordinate of the button
          text: "",
          w: 78, // button width
          h: 58, // button height
          normal_src: "Empty.png", // transparent image
          press_src: "Empty.png", // transparent image
          show_level: hmUI.show_level.ONLY_NORMAL,
          click_func: () => {
            gmtButtonClick();
          },
        });

            console.log('Watch_Face.Buttons');
            Button_1 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 83,
              y: 194,
              w: 78,
              h: 78,
              text: '',
              color: 0xFFFF8C00,
              text_size: 24,
              press_src: 'Empty.png',
              normal_src: 'Empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'CompassScreen', native: true });
              }, // end func
              longpress_func: (button_widget) => {
                hmApp.startApp({url: 'BaroAltimeterScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button
			
			function time_update(updateHour = false, updateMinute = false) {
          let hour = timeSensor.hour;
          let minute = timeSensor.minute;
          let second = timeSensor.second;

          if (updateHour) {
            let normal_hour = hour;
            let normal_fullAngle_hour = 360;
            if (normal_hour > 11) normal_hour -= 12;
            let normal_angle_hour = 0 + (normal_fullAngle_hour * normal_hour) / 12 + ((normal_fullAngle_hour / 12) * minute) / 60;

            // normal
            if (normal_analog_clock_pro_hour_pointer_img) normal_analog_clock_pro_hour_pointer_img.setProperty(hmUI.prop.ANGLE, normal_angle_hour);
            // aod
            if (idle_analog_clock_time_pointer_hour) idle_analog_clock_time_pointer_hour.setProperty(hmUI.prop.ANGLE, normal_angle_hour);
          }

          if (updateMinute) {
            let normal_fullAngle_minute = 360;
            let normal_angle_minute = 0 + (normal_fullAngle_minute * (minute + second / 60)) / 60;

            // normal
            if (normal_analog_clock_pro_minute_pointer_img) normal_analog_clock_pro_minute_pointer_img.setProperty(hmUI.prop.ANGLE, normal_angle_minute);
            // aod
            if (idle_analog_clock_time_pointer_minute) idle_analog_clock_time_pointer_minute.setProperty(hmUI.prop.ANGLE, normal_angle_minute);

            // gmt
            worldData = getWorldData(index);
            update_world_clock(false);
          }
        }

        let lastAngleSeconds = 0;
        let second_current_angle = 0;

        function time_update_sec() {
          // start timer
          second_current_angle = getSecondsNormalAngle(timeSensor.second - 1);
          lastAngleSeconds = getSecondsNormalAngle(timeSensor.second);
          setSeconds(second_current_angle);

          if (!timer_animate_seconds) {
            timer_animate_seconds = timer.createTimer(30, 30, function (option) {
              animate_seconds();
            });
          }
        }

        function animate_seconds() {
          second_current_angle += 360 / 60 / 3;

          setSeconds(second_current_angle);

          if (timer_animate_seconds && second_current_angle == lastAngleSeconds) {
            timer.stopTimer(timer_animate_seconds);
            timer_animate_seconds = undefined;

            lastAngleSeconds = second_current_angle;
          }
        }

        function setSeconds(angle) {
          if (normal_analog_clock_pro_second_pointer_img) normal_analog_clock_pro_second_pointer_img.setProperty(hmUI.prop.ANGLE, angle);
        }

        function getSecondsNormalAngle(second) {
          let normal_fullAngle_second = 360;
          let normal_angle_second = 0 + (normal_fullAngle_second * second) / 60;

          return normal_angle_second;
        }

        function gmtButtonClick() {
          let count = world_clock.getWorldClockCount();

          index++;
          if (index == count) index = 0;

          hmFS.SysProSetInt("SEIKO_wt_index", index);

          worldData = getWorldData(index);
          if (worldData) hmUI.showToast({ text: worldData.city + " (" + (index + 1) + "/" + count + ")" });
          update_world_clock();
        }

        function getWorldData(idx) {
          let count = world_clock.getWorldClockCount();
          let data = undefined;

          if (idx >= count) idx = 0;
          if (count > 0 && idx < count) data = world_clock.getWorldClockInfo(idx);

          return data;
        }

        function update_world_clock(animate = true) {
          if (worldData) {
            if (normal_world_clock_pointer_img) normal_world_clock_pointer_img.setProperty(hmUI.prop.VISIBLE, true);
            if (idle_world_clock_pointer_img) idle_world_clock_pointer_img.setProperty(hmUI.prop.VISIBLE, true);
            wt_target_angle = (worldData.hour * 60 + worldData.minute) * wt_angle_delta;

            if (animate) {
              if (!timer_animate_wt) {
                timer_animate_wt = timer.createTimer(0, 30, function (option) {
                  animate_wt();
                });
              }
            } else {
              wt_current_angle = wt_target_angle;
              set_wt(wt_target_angle);
            }
          } else {
            if (normal_world_clock_pointer_img) normal_world_clock_pointer_img.setProperty(hmUI.prop.VISIBLE, false);
            if (idle_world_clock_pointer_img) idle_world_clock_pointer_img.setProperty(hmUI.prop.VISIBLE, false);
          }
        }
		
		function valuesAreClose(firstValue, secondValue, tolerance = 10) {
          return Math.abs(firstValue - secondValue) <= tolerance;
        }

        function animate_wt() {
          let da = wt_current_angle > wt_target_angle ? -3 : 3;
          wt_current_angle += da;
          if (wt_current_angle >= 360) wt_current_angle = wt_current_angle - 360;
          if (valuesAreClose(wt_current_angle, wt_target_angle, 4)) wt_current_angle = wt_target_angle;

          set_wt(wt_current_angle);

          if (timer_animate_wt && wt_current_angle == wt_target_angle) {
            timer.stopTimer(timer_animate_wt);
            timer_animate_wt = undefined;
          }
        }

        function set_wt(angle) {
          if (normal_world_clock_pointer_img) normal_world_clock_pointer_img.setProperty(hmUI.prop.ANGLE, angle);
          if (idle_world_clock_pointer_img) idle_world_clock_pointer_img.setProperty(hmUI.prop.ANGLE, angle);
        }

            //start of ignored block
            console.log('compass_update()');
            if (screenType == hmSetting.screen_type.WATCHFACE){
              compass = hmSensor.createSensor(hmSensor.id.COMPASS);
              compass.start();

              if (compass.direction_angle && compass.direction  && compass.direction_angle != 'INVALID') { // initial data
                // Compass Pointer
                let compass_direction_angle = parseInt(compass.direction_angle);
                normal_compass_direction_pointer_img.setProperty(hmUI.prop.ANGLE, -compass_direction_angle);

              } else { // error data
                normal_compass_direction_pointer_img.setProperty(hmUI.prop.ANGLE, 0);

              }

              compass.addEventListener(hmSensor.event.CHANGE, function (compass_res) { // change values when changing direction

                if (compass_res.calibration_status) {
                  // Compass Pointer
                  let compass_direction_angle = parseInt(compass_res.direction_angle);
                  normal_compass_direction_pointer_img.setProperty(hmUI.prop.ANGLE, -compass_direction_angle);

                } else { // error data
                  normal_compass_direction_pointer_img.setProperty(hmUI.prop.ANGLE, 0);

                }

              }); // Listener end

            };
            //end of ignored block

            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                console.log('resume_call()');
				worldData = getWorldData(index);
            time_update(true, true);
            // init seconds arrow angle
            second_current_angle = getSecondsNormalAngle(timeSensor.second - 1);
            lastAngleSeconds = getSecondsNormalAngle(timeSensor.second);
            setSeconds(second_current_angle);

            if (screenType == hmSetting.screen_type.WATCHFACE) {
              if (!normal_timerUpdate) {
                let animDelay = timeSensor.utc % 1000;
                let animRepeat = 1000;
                normal_timerUpdate = timer.createTimer(animDelay, animRepeat, function (option) {
                  time_update(false, false);
                }); // end timer
              } // end timer check
            } // end screenType
            if (screenType == hmSetting.screen_type.WATCHFACE) {
              if (!normal_timerUpdateSec) {
                normal_timerUpdateSec = timer.createTimer(0, 1000, function (option) {
                  time_update_sec();
                }); // end timer
              } // end timer check
            } // end screenType
                if (compass && screenType == hmSetting.screen_type.WATCHFACE) compass.start();

              }),
              pause_call: (function () {
                console.log('pause_call()');
                if (compass) compass.stop();
				if (normal_timerUpdateSec) {
              timer.stopTimer(normal_timerUpdateSec);
              normal_timerUpdateSec = undefined;
            }

              }),
            });

                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}