﻿
    /*
    ** Watch_Face_Editor tool
    ** watchface js version v1.0.1
    ** Copyright © CashaCX75. All Rights Reserved
    */

    try {

      (() => {

        var __$$app$$__ = __$$hmAppManager$$__.currentApp;
        var __$$module$$__ = __$$app$$__.current;
        //drink is a name,can modify
        var h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__), 'drink');

        'use strict';

        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_system_disconnect_img = ''
        let normal_system_clock_img = ''
        let normal_moon_image_progress_img_level = ''
        let normal_temperature_current_text_img = ''
        let normal_weather_image_progress_img_level = ''
        let normal_date_img_date_day = ''
        let normal_date_img_date_week_img = ''
        let normal_date_img_date_month_img = ''
        let normal_frame_animation_1 = ''
        let normal_step_current_text_img = ''
        let normal_step_image_progress_img_level = ''
        let normal_heart_rate_text_text_img = ''
        let normal_heart_rate_image_progress_img_level = ''
        let normal_battery_text_text_img = ''
        let normal_battery_image_progress_img_level = ''
        let normal_digital_clock_img_time_AmPm = ''
        let normal_digital_clock_img_time = ''
        let normal_analog_clock_time_pointer_hour = ''
        let normal_analog_clock_time_pointer_minute = ''
        let normal_analog_clock_time_pointer_second = ''
        let normal_stopwatch_jumpable_img_click = ''
        let normal_countdown_jumpable_img_click = ''
        let normal_alarm_jumpable_img_click = ''
        let normal_sunrise_jumpable_img_click = ''
        let normal_temperature_jumpable_img_click = ''
        let normal_spo2_jumpable_img_click = ''
        let normal_heart_jumpable_img_click = ''
        let normal_step_jumpable_img_click = ''
        let idle_background_bg_img = ''
        let idle_system_disconnect_img = ''
        let idle_system_clock_img = ''
        let idle_moon_image_progress_img_level = ''
        let idle_temperature_current_text_img = ''
        let idle_weather_image_progress_img_level = ''
        let idle_date_img_date_day = ''
        let idle_date_img_date_week_img = ''
        let idle_date_img_date_month_img = ''
        let idle_step_current_text_img = ''
        let idle_step_current_separator_img = ''
        let idle_step_image_progress_img_level = ''
        let idle_heart_rate_text_text_img = ''
        let idle_heart_rate_image_progress_img_level = ''
        let idle_battery_text_text_img = ''
        let idle_battery_image_progress_img_level = ''
        let idle_digital_clock_img_time_AmPm = ''
        let idle_digital_clock_img_time = ''
        let idle_analog_clock_time_pointer_hour = ''
        let idle_analog_clock_time_pointer_minute = ''
        let idle_analog_clock_time_pointer_second = ''


        //dynamic modify end

        //not required
        const logger = DeviceRuntimeCore.HmLogger.getLogger("yeguang");

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({

          init_view() {

            //dynamic modify start
                    
            
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 466,
              h: 466,
              src: 'main1.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 339,
              y: 89,
              src: 'System_BT_Disconnect.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 396,
              y: 259,
              src: 'System_Alarm.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_moon_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 329,
              y: 280,
              image_array: ["Moon_01.png","Moon_02.png","Moon_03.png","Moon_04.png","Moon_05.png","Moon_06.png","Moon_07.png","Moon_08.png","Moon_09.png","Moon_10.png","Moon_11.png","Moon_12.png","Moon_13.png","Moon_14.png","Moon_15.png","Moon_16.png","Moon_17.png","Moon_18.png","Moon_19.png","Moon_20.png","Moon_21.png","Moon_22.png","Moon_23.png","Moon_24.png","Moon_25.png","Moon_26.png","Moon_27.png","Moon_28.png","Moon_29.png","Moon_30.png"],
              image_length: 30,
              type: hmUI.data_type.MOON,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 96,
              y: 338,
              font_array: ["act_small_font_01.png","act_small_font_02.png","act_small_font_03.png","act_small_font_04.png","act_small_font_05.png","act_small_font_06.png","act_small_font_07.png","act_small_font_08.png","act_small_font_09.png","act_small_font_10.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'act_small_font_11.png',
              unit_tc: 'act_small_font_11.png',
              unit_en: 'act_small_font_11.png',
              negative_image: 'act_small_font_12.png',
              invalid_image: 'act_small_font_12.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 102,
              y: 105,
              image_array: ["Weather_icon_01.png","Weather_icon_02.png","Weather_icon_03.png","Weather_icon_04.png","Weather_icon_05.png","Weather_icon_06.png","Weather_icon_07.png","Weather_icon_08.png","Weather_icon_09.png","Weather_icon_10.png","Weather_icon_11.png","Weather_icon_12.png","Weather_icon_13.png","Weather_icon_14.png","Weather_icon_15.png","Weather_icon_16.png","Weather_icon_17.png","Weather_icon_18.png","Weather_icon_19.png","Weather_icon_20.png","Weather_icon_21.png","Weather_icon_22.png","Weather_icon_23.png","Weather_icon_24.png","Weather_icon_25.png","Weather_icon_26.png","Weather_icon_27.png","Weather_icon_28.png","Weather_icon_29.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 343,
              day_startY: 142,
              day_sc_array: ["act_small_font_01.png","act_small_font_02.png","act_small_font_03.png","act_small_font_04.png","act_small_font_05.png","act_small_font_06.png","act_small_font_07.png","act_small_font_08.png","act_small_font_09.png","act_small_font_10.png"],
              day_tc_array: ["act_small_font_01.png","act_small_font_02.png","act_small_font_03.png","act_small_font_04.png","act_small_font_05.png","act_small_font_06.png","act_small_font_07.png","act_small_font_08.png","act_small_font_09.png","act_small_font_10.png"],
              day_en_array: ["act_small_font_01.png","act_small_font_02.png","act_small_font_03.png","act_small_font_04.png","act_small_font_05.png","act_small_font_06.png","act_small_font_07.png","act_small_font_08.png","act_small_font_09.png","act_small_font_10.png"],
              day_zero: 0,
              day_space: 3,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 320,
              y: 170,
              week_en: ["Day_Week_1.png","Day_Week_2.png","Day_Week_3.png","Day_Week_4.png","Day_Week_5.png","Day_Week_6.png","Day_Week_7.png"],
              week_tc: ["Day_Week_1.png","Day_Week_2.png","Day_Week_3.png","Day_Week_4.png","Day_Week_5.png","Day_Week_6.png","Day_Week_7.png"],
              week_sc: ["Day_Week_1.png","Day_Week_2.png","Day_Week_3.png","Day_Week_4.png","Day_Week_5.png","Day_Week_6.png","Day_Week_7.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_month_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 304,
              month_startY: 193,
              month_sc_array: ["month_01.png","month_02.png","month_03.png","month_04.png","month_05.png","month_06.png","month_07.png","month_08.png","month_09.png","month_10.png","month_11.png","month_12.png"],
              month_tc_array: ["month_01.png","month_02.png","month_03.png","month_04.png","month_05.png","month_06.png","month_07.png","month_08.png","month_09.png","month_10.png","month_11.png","month_12.png"],
              month_en_array: ["month_01.png","month_02.png","month_03.png","month_04.png","month_05.png","month_06.png","month_07.png","month_08.png","month_09.png","month_10.png","month_11.png","month_12.png"],
              month_is_character: true ,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_frame_animation_1 = hmUI.createWidget(hmUI.widget.IMG_ANIM, {
              x: 226,
              y: 387,
              anim_path: "animation",
              anim_ext: "png",
              anim_prefix: "Run",
              anim_fps: 15,
              anim_size: 6,
              repeat_count: 0,
              anim_repeat: true,
              anim_status:hmUI.anim_status.START,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 201,
              y: 342,
              font_array: ["act_small_font_01.png","act_small_font_02.png","act_small_font_03.png","act_small_font_04.png","act_small_font_05.png","act_small_font_06.png","act_small_font_07.png","act_small_font_08.png","act_small_font_09.png","act_small_font_10.png"],
              padding: false,
              h_space: 1,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 165,
              y: 296,
              image_array: ["Step_icon_01.png","Step_icon_02.png","Step_icon_03.png","Step_icon_04.png","Step_icon_05.png","Step_icon_06.png","Step_icon_07.png","Step_icon_08.png","Step_icon_09.png"],
              image_length: 9,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 211,
              y: 88,
              font_array: ["act_small_font_01.png","act_small_font_02.png","act_small_font_03.png","act_small_font_04.png","act_small_font_05.png","act_small_font_06.png","act_small_font_07.png","act_small_font_08.png","act_small_font_09.png","act_small_font_10.png"],
              padding: false,
              h_space: 4,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 165,
              y: 40,
              image_array: ["Zone1.png","Zone2.png","Zone3.png","Zone4.png","Zone5.png","Zone6.png"],
              image_length: 6,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 83,
              y: 216,
              font_array: ["act_small_font_01.png","act_small_font_02.png","act_small_font_03.png","act_small_font_04.png","act_small_font_05.png","act_small_font_06.png","act_small_font_07.png","act_small_font_08.png","act_small_font_09.png","act_small_font_10.png"],
              padding: false,
              h_space: 2,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 44,
              y: 172,
              image_array: ["Battery_01.png","Battery_02.png","Battery_03.png","Battery_04.png","Battery_05.png","Battery_06.png","Battery_07.png","Battery_08.png","Battery_09.png","Battery_10.png"],
              image_length: 10,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time_AmPm = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              am_x: 304,
              am_y: 259,
              am_sc_path: 'Clock_AM.png',
              am_en_path: 'Clock_AM.png',
              pm_x: 304,
              pm_y: 259,
              pm_sc_path: 'Clock_PM.png',
              pm_en_path: 'Clock_PM.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 288,
              hour_startY: 217,
              hour_array: ["Time_font_01.png","Time_font_02.png","Time_font_03.png","Time_font_04.png","Time_font_05.png","Time_font_06.png","Time_font_07.png","Time_font_08.png","Time_font_09.png","Time_font_10.png"],
              hour_zero: 1,
              hour_space: 3,
              hour_align: hmUI.align.LEFT,

              minute_startX: 348,
              minute_startY: 217,
              minute_array: ["Time_font_01.png","Time_font_02.png","Time_font_03.png","Time_font_04.png","Time_font_05.png","Time_font_06.png","Time_font_07.png","Time_font_08.png","Time_font_09.png","Time_font_10.png"],
              minute_zero: 1,
              minute_space: 3,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_hour = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              hour_path: 'Hand_Hour.png',
              hour_centerX: 233,
              hour_centerY: 233,
              hour_posX: 22,
              hour_posY: 224,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_minute = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              minute_path: 'Hand_minutes.png',
              minute_centerX: 233,
              minute_centerY: 233,
              minute_posX: 22,
              minute_posY: 224,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_second = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              second_path: 'Hand_second.png',
              second_centerX: 233,
              second_centerY: 233,
              second_posX: 22,
              second_posY: 224,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_stopwatch_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 323,
              y: 215,
              w: 38,
              h: 37,
              src: '0_Empty.png',
              type: hmUI.data_type.STOP_WATCH,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_countdown_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 203,
              y: 202,
              w: 62,
              h: 59,
              src: '0_Empty.png',
              type: hmUI.data_type.COUNT_DOWN,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_alarm_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 391,
              y: 253,
              w: 46,
              h: 35,
              src: '0_Empty.png',
              type: hmUI.data_type.ALARM_CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sunrise_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 324,
              y: 278,
              w: 56,
              h: 52,
              src: '0_Empty.png',
              type: hmUI.data_type.SUN_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 89,
              y: 319,
              w: 56,
              h: 53,
              src: '0_Empty.png',
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_spo2_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 202,
              y: 119,
              w: 64,
              h: 30,
              src: '0_Empty.png',
              type: hmUI.data_type.SPO2,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 192,
              y: 76,
              w: 86,
              h: 39,
              src: '0_Empty.png',
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 193,
              y: 332,
              w: 83,
              h: 37,
              src: '0_Empty.png',
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            idle_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 466,
              h: 466,
              src: 'main1.png',
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 339,
              y: 89,
              src: 'System_BT_Disconnect.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 396,
              y: 259,
              src: 'System_Alarm.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_moon_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 329,
              y: 280,
              image_array: ["Moon_01.png","Moon_02.png","Moon_03.png","Moon_04.png","Moon_05.png","Moon_06.png","Moon_07.png","Moon_08.png","Moon_09.png","Moon_10.png","Moon_11.png","Moon_12.png","Moon_13.png","Moon_14.png","Moon_15.png","Moon_16.png","Moon_17.png","Moon_18.png","Moon_19.png","Moon_20.png","Moon_21.png","Moon_22.png","Moon_23.png","Moon_24.png","Moon_25.png","Moon_26.png","Moon_27.png","Moon_28.png","Moon_29.png","Moon_30.png"],
              image_length: 30,
              type: hmUI.data_type.MOON,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 96,
              y: 338,
              font_array: ["act_small_font_01.png","act_small_font_02.png","act_small_font_03.png","act_small_font_04.png","act_small_font_05.png","act_small_font_06.png","act_small_font_07.png","act_small_font_08.png","act_small_font_09.png","act_small_font_10.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'act_small_font_11.png',
              unit_tc: 'act_small_font_11.png',
              unit_en: 'act_small_font_11.png',
              negative_image: 'act_small_font_12.png',
              invalid_image: 'act_small_font_12.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 102,
              y: 105,
              image_array: ["Weather_icon_01.png","Weather_icon_02.png","Weather_icon_03.png","Weather_icon_04.png","Weather_icon_05.png","Weather_icon_06.png","Weather_icon_07.png","Weather_icon_08.png","Weather_icon_09.png","Weather_icon_10.png","Weather_icon_11.png","Weather_icon_12.png","Weather_icon_13.png","Weather_icon_14.png","Weather_icon_15.png","Weather_icon_16.png","Weather_icon_17.png","Weather_icon_18.png","Weather_icon_19.png","Weather_icon_20.png","Weather_icon_21.png","Weather_icon_22.png","Weather_icon_23.png","Weather_icon_24.png","Weather_icon_25.png","Weather_icon_26.png","Weather_icon_27.png","Weather_icon_28.png","Weather_icon_29.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 343,
              day_startY: 142,
              day_sc_array: ["act_small_font_01.png","act_small_font_02.png","act_small_font_03.png","act_small_font_04.png","act_small_font_05.png","act_small_font_06.png","act_small_font_07.png","act_small_font_08.png","act_small_font_09.png","act_small_font_10.png"],
              day_tc_array: ["act_small_font_01.png","act_small_font_02.png","act_small_font_03.png","act_small_font_04.png","act_small_font_05.png","act_small_font_06.png","act_small_font_07.png","act_small_font_08.png","act_small_font_09.png","act_small_font_10.png"],
              day_en_array: ["act_small_font_01.png","act_small_font_02.png","act_small_font_03.png","act_small_font_04.png","act_small_font_05.png","act_small_font_06.png","act_small_font_07.png","act_small_font_08.png","act_small_font_09.png","act_small_font_10.png"],
              day_zero: 0,
              day_space: 3,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 320,
              y: 170,
              week_en: ["Day_Week_1.png","Day_Week_2.png","Day_Week_3.png","Day_Week_4.png","Day_Week_5.png","Day_Week_6.png","Day_Week_7.png"],
              week_tc: ["Day_Week_1.png","Day_Week_2.png","Day_Week_3.png","Day_Week_4.png","Day_Week_5.png","Day_Week_6.png","Day_Week_7.png"],
              week_sc: ["Day_Week_1.png","Day_Week_2.png","Day_Week_3.png","Day_Week_4.png","Day_Week_5.png","Day_Week_6.png","Day_Week_7.png"],
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_date_img_date_month_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 304,
              month_startY: 193,
              month_sc_array: ["month_01.png","month_02.png","month_03.png","month_04.png","month_05.png","month_06.png","month_07.png","month_08.png","month_09.png","month_10.png","month_11.png","month_12.png"],
              month_tc_array: ["month_01.png","month_02.png","month_03.png","month_04.png","month_05.png","month_06.png","month_07.png","month_08.png","month_09.png","month_10.png","month_11.png","month_12.png"],
              month_en_array: ["month_01.png","month_02.png","month_03.png","month_04.png","month_05.png","month_06.png","month_07.png","month_08.png","month_09.png","month_10.png","month_11.png","month_12.png"],
              month_is_character: true ,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 201,
              y: 342,
              font_array: ["act_small_font_01.png","act_small_font_02.png","act_small_font_03.png","act_small_font_04.png","act_small_font_05.png","act_small_font_06.png","act_small_font_07.png","act_small_font_08.png","act_small_font_09.png","act_small_font_10.png"],
              padding: false,
              h_space: 1,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_step_current_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 226,
              y: 387,
              src: 'run0.png',
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_step_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 165,
              y: 296,
              image_array: ["Step_icon_01.png","Step_icon_02.png","Step_icon_03.png","Step_icon_04.png","Step_icon_05.png","Step_icon_06.png","Step_icon_07.png","Step_icon_08.png","Step_icon_09.png"],
              image_length: 9,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 211,
              y: 88,
              font_array: ["act_small_font_01.png","act_small_font_02.png","act_small_font_03.png","act_small_font_04.png","act_small_font_05.png","act_small_font_06.png","act_small_font_07.png","act_small_font_08.png","act_small_font_09.png","act_small_font_10.png"],
              padding: false,
              h_space: 4,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_heart_rate_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 165,
              y: 40,
              image_array: ["Zone1.png","Zone2.png","Zone3.png","Zone4.png","Zone5.png","Zone6.png"],
              image_length: 6,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 83,
              y: 216,
              font_array: ["act_small_font_01.png","act_small_font_02.png","act_small_font_03.png","act_small_font_04.png","act_small_font_05.png","act_small_font_06.png","act_small_font_07.png","act_small_font_08.png","act_small_font_09.png","act_small_font_10.png"],
              padding: false,
              h_space: 2,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_battery_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 44,
              y: 172,
              image_array: ["Battery_01.png","Battery_02.png","Battery_03.png","Battery_04.png","Battery_05.png","Battery_06.png","Battery_07.png","Battery_08.png","Battery_09.png","Battery_10.png"],
              image_length: 10,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_digital_clock_img_time_AmPm = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              am_x: 304,
              am_y: 259,
              am_sc_path: 'Clock_AM.png',
              am_en_path: 'Clock_AM.png',
              pm_x: 304,
              pm_y: 259,
              pm_sc_path: 'Clock_PM.png',
              pm_en_path: 'Clock_PM.png',
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 288,
              hour_startY: 217,
              hour_array: ["Time_font_01.png","Time_font_02.png","Time_font_03.png","Time_font_04.png","Time_font_05.png","Time_font_06.png","Time_font_07.png","Time_font_08.png","Time_font_09.png","Time_font_10.png"],
              hour_zero: 1,
              hour_space: 3,
              hour_align: hmUI.align.LEFT,

              minute_startX: 348,
              minute_startY: 217,
              minute_array: ["Time_font_01.png","Time_font_02.png","Time_font_03.png","Time_font_04.png","Time_font_05.png","Time_font_06.png","Time_font_07.png","Time_font_08.png","Time_font_09.png","Time_font_10.png"],
              minute_zero: 1,
              minute_space: 3,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_analog_clock_time_pointer_hour = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              hour_path: 'Hand_Hour.png',
              hour_centerX: 233,
              hour_centerY: 233,
              hour_posX: 22,
              hour_posY: 224,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_analog_clock_time_pointer_minute = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              minute_path: 'Hand_minutes.png',
              minute_centerX: 233,
              minute_centerY: 233,
              minute_posX: 22,
              minute_posY: 224,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_analog_clock_time_pointer_second = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              second_path: 'Hand_second.png',
              second_centerX: 233,
              second_centerY: 233,
              second_posX: 22,
              second_posY: 224,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                normal_frame_animation_1.setProperty(hmUI.prop.ANIM_STATUS,hmUI.anim_status.START);

              }),
              pause_call: (function () {
                normal_frame_animation_1.setProperty(hmUI.prop.ANIM_STATUS,hmUI.anim_status.STOP);

              }),
            });

            //dynamic modify end
          },

          onInit() {
            console.log('index page.js on init invoke')

            this.init_view()

          },

          onReady() {
            console.log('index page.js on ready invoke')
          },

          onShow() {
            console.log('index page.js on show invoke')
          },

          onHide() {
            console.log('index page.js on hide invoke')
          },

          onDestory() {
            console.log('index page.js on destory invoke')
          },
        });

      })()
    } catch (e) {
      console.log(e)
    }
  