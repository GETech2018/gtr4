﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        const logger = Logger.getLogger('watchface_SashaCX75');
        //end of ignored block

        //dynamic modify start

        
        let normal_background_bg = ''
        let normal_sun_current_text_img = ''
        let normal_sun_current_separator_img = ''
        let normal_battery_text_text_img = ''
        let normal_system_dnd_img = ''
        let normal_system_disconnect_img = ''
        let normal_system_clock_img = ''
        let normal_temperature_current_text_img = ''
        let normal_moon_image_progress_img_level = ''
        let normal_date_img_date_week_img = ''
        let normal_date_img_date_day = ''
        let normal_frame_animation_1 = ''
        let normal_digital_clock_img_time_AmPm = ''
        let normal_digital_clock_img_time = ''
        let idle_background_bg = ''
        let idle_sun_current_text_img = ''
        let idle_sun_current_separator_img = ''
        let idle_battery_text_text_img = ''
        let idle_system_dnd_img = ''
        let idle_system_disconnect_img = ''
        let idle_system_clock_img = ''
        let idle_temperature_current_text_img = ''
        let idle_moon_image_progress_img_level = ''
        let idle_date_img_date_week_img = ''
        let idle_date_img_date_day = ''
        let idle_digital_clock_img_time_AmPm = ''
        let idle_digital_clock_img_time = ''
        let idle_digital_clock_minute_separator_img = ''
        let normal_countdown_jumpable_img_click = ''
        let normal_sleep_jumpable_img_click = ''
        let normal_alarm_jumpable_img_click = ''
        let normal_sunrise_jumpable_img_click = ''
        let normal_altimeter_jumpable_img_click = ''
        let normal_temperature_jumpable_img_click = ''


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            normal_background_bg = hmUI.createWidget(hmUI.widget.FILL_RECT, {
              x: 0,
              y: 0,
              w: 466,
              h: 466,
              color: '0xFF000000',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sun_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 323,
              y: 60,
              font_array: ["dig_10.png","dig_11.png","dig_12.png","dig_13.png","dig_14.png","dig_15.png","dig_16.png","dig_17.png","dig_18.png","dig_19.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.SUN_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sun_current_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 295,
              y: 61,
              src: 'dig_sec_deg.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 210,
              y: 439,
              font_array: ["dig_10.png","dig_11.png","dig_12.png","dig_13.png","dig_14.png","dig_15.png","dig_16.png","dig_17.png","dig_18.png","dig_19.png"],
              padding: false,
              h_space: 0,
              unit_sc: '0050.png',
              unit_tc: '0050.png',
              unit_en: '0050.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_dnd_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 110,
              y: 395,
              src: '0069.png',
              type: hmUI.system_status.DISTURB,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 54,
              y: 345,
              src: 'BT7.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 17,
              y: 280,
              src: 'Ala.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 202,
              y: 16,
              font_array: ["dig_10.png","dig_11.png","dig_12.png","dig_13.png","dig_14.png","dig_15.png","dig_16.png","dig_17.png","dig_18.png","dig_19.png"],
              padding: false,
              h_space: 0,
              unit_sc: '0046.png',
              unit_tc: '0046.png',
              unit_en: '0046.png',
              negative_image: '0048.png',
              invalid_image: '0047.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_moon_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 63,
              y: 67,
              image_array: ["fase1.png","fase2.png","fase3.png","fase4.png","fase5.png","fase6.png","fase7.png","fase8.png"],
              image_length: 8,
              type: hmUI.data_type.MOON,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 18,
              y: 135,
              week_en: ["D0001.png","D0002.png","D0003.png","D0004.png","D0005.png","D0006.png","D0007.png"],
              week_tc: ["D0001.png","D0002.png","D0003.png","D0004.png","D0005.png","D0006.png","D0007.png"],
              week_sc: ["D0001.png","D0002.png","D0003.png","D0004.png","D0005.png","D0006.png","D0007.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 14,
              day_startY: 190,
              day_sc_array: ["dig_10.png","dig_11.png","dig_12.png","dig_13.png","dig_14.png","dig_15.png","dig_16.png","dig_17.png","dig_18.png","dig_19.png"],
              day_tc_array: ["dig_10.png","dig_11.png","dig_12.png","dig_13.png","dig_14.png","dig_15.png","dig_16.png","dig_17.png","dig_18.png","dig_19.png"],
              day_en_array: ["dig_10.png","dig_11.png","dig_12.png","dig_13.png","dig_14.png","dig_15.png","dig_16.png","dig_17.png","dig_18.png","dig_19.png"],
              day_zero: 1,
              day_space: 0,
              day_align: hmUI.align.LEFT,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_frame_animation_1 = hmUI.createWidget(hmUI.widget.IMG_ANIM, {
              x: -50,
              y: 0,
              anim_path: "animation",
              anim_ext: "png",
              anim_prefix: "hr_anim",
              anim_fps: 6,
              anim_size: 32,
              repeat_count: 1,
              anim_repeat: false,
              anim_status:hmUI.anim_status.START,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time_AmPm = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              am_x: 412,
              am_y: 190,
              am_sc_path: 'H1.png',
              am_en_path: 'H1.png',
              pm_x: 412,
              pm_y: 190,
              pm_sc_path: 'H2.png',
              pm_en_path: 'H2.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 283,
              hour_startY: 161,
              hour_array: ["dig_0.png","dig_1.png","dig_2.png","dig_3.png","dig_4.png","dig_5.png","dig_6.png","dig_7.png","dig_8.png","dig_9.png"],
              hour_zero: 1,
              hour_space: 0,
              hour_angle: 0,
              hour_align: hmUI.align.CENTER_H,

              minute_startX: 283,
              minute_startY: 253,
              minute_array: ["dig_0.png","dig_1.png","dig_2.png","dig_3.png","dig_4.png","dig_5.png","dig_6.png","dig_7.png","dig_8.png","dig_9.png"],
              minute_zero: 0,
              minute_space: 0,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              second_startX: 414,
              second_startY: 261,
              second_array: ["dig_10.png","dig_11.png","dig_12.png","dig_13.png","dig_14.png","dig_15.png","dig_16.png","dig_17.png","dig_18.png","dig_19.png"],
              second_zero: 1,
              second_space: 0,
              second_angle: 0,
              second_follow: 0,
              second_align: hmUI.align.CENTER_H,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            idle_background_bg = hmUI.createWidget(hmUI.widget.FILL_RECT, {
              x: 0,
              y: 0,
              w: 466,
              h: 466,
              color: '0xFF000000',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_sun_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 323,
              y: 60,
              font_array: ["dig_10.png","dig_11.png","dig_12.png","dig_13.png","dig_14.png","dig_15.png","dig_16.png","dig_17.png","dig_18.png","dig_19.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.SUN_CURRENT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_sun_current_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 295,
              y: 61,
              src: 'dig_sec_deg.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 210,
              y: 439,
              font_array: ["dig_10.png","dig_11.png","dig_12.png","dig_13.png","dig_14.png","dig_15.png","dig_16.png","dig_17.png","dig_18.png","dig_19.png"],
              padding: false,
              h_space: 0,
              unit_sc: '0050.png',
              unit_tc: '0050.png',
              unit_en: '0050.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_system_dnd_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 110,
              y: 395,
              src: '0069.png',
              type: hmUI.system_status.DISTURB,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 54,
              y: 345,
              src: 'BT7.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 17,
              y: 280,
              src: 'Ala.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 202,
              y: 16,
              font_array: ["dig_10.png","dig_11.png","dig_12.png","dig_13.png","dig_14.png","dig_15.png","dig_16.png","dig_17.png","dig_18.png","dig_19.png"],
              padding: false,
              h_space: 0,
              unit_sc: '0046.png',
              unit_tc: '0046.png',
              unit_en: '0046.png',
              negative_image: '0048.png',
              invalid_image: '0047.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_moon_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 63,
              y: 67,
              image_array: ["fase1.png","fase2.png","fase3.png","fase4.png","fase5.png","fase6.png","fase7.png","fase8.png"],
              image_length: 8,
              type: hmUI.data_type.MOON,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 18,
              y: 135,
              week_en: ["D0001.png","D0002.png","D0003.png","D0004.png","D0005.png","D0006.png","D0007.png"],
              week_tc: ["D0001.png","D0002.png","D0003.png","D0004.png","D0005.png","D0006.png","D0007.png"],
              week_sc: ["D0001.png","D0002.png","D0003.png","D0004.png","D0005.png","D0006.png","D0007.png"],
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 14,
              day_startY: 190,
              day_sc_array: ["dig_10.png","dig_11.png","dig_12.png","dig_13.png","dig_14.png","dig_15.png","dig_16.png","dig_17.png","dig_18.png","dig_19.png"],
              day_tc_array: ["dig_10.png","dig_11.png","dig_12.png","dig_13.png","dig_14.png","dig_15.png","dig_16.png","dig_17.png","dig_18.png","dig_19.png"],
              day_en_array: ["dig_10.png","dig_11.png","dig_12.png","dig_13.png","dig_14.png","dig_15.png","dig_16.png","dig_17.png","dig_18.png","dig_19.png"],
              day_zero: 1,
              day_space: 0,
              day_align: hmUI.align.LEFT,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time_AmPm = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              am_x: 412,
              am_y: 190,
              am_sc_path: 'H1.png',
              am_en_path: 'H1.png',
              pm_x: 412,
              pm_y: 190,
              pm_sc_path: 'H2.png',
              pm_en_path: 'H2.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 283,
              hour_startY: 161,
              hour_array: ["dig_0.png","dig_1.png","dig_2.png","dig_3.png","dig_4.png","dig_5.png","dig_6.png","dig_7.png","dig_8.png","dig_9.png"],
              hour_zero: 1,
              hour_space: 0,
              hour_angle: 0,
              hour_align: hmUI.align.CENTER_H,

              minute_startX: 283,
              minute_startY: 253,
              minute_array: ["dig_0.png","dig_1.png","dig_2.png","dig_3.png","dig_4.png","dig_5.png","dig_6.png","dig_7.png","dig_8.png","dig_9.png"],
              minute_zero: 0,
              minute_space: 0,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_minute_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'shape.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });
            
            // disconnectAlert = hmUI.createWidget(hmUI.widget.DisconnectAlert, {
              // disconneсnt_vibrate_type: 0,
              // disconneсnt_toast_text: DESCONECTADO,
              // conneсnt_vibrate_type: 0,
              // conneсnt_toast_text: CONECTADO,
            // });

            // vibration when connecting or disconnecting

            function checkConnection() {
              hmBle.removeListener;
              hmBle.addListener(function (status) {
                if(!status) {
                  hmUI.showToast({text: "DESCONECTADO"});
                  vibro(0);
                }
                if(status) {
                  hmUI.showToast({text: "CONECTADO"});
                  vibro(0);
                }
              });
            }

            // end vibration when connecting or disconnecting
            // vibrate function

            const vibrate = hmSensor.createSensor(hmSensor.id.VIBRATE);
            let timer_StopVibrate = null;


            function vibro(scene = 25) {
              let stopDelay = 50;
              stopVibro();
              vibrate.stop();
              vibrate.scene = scene;
              if(scene < 23 || scene > 25) stopDelay = 1300;
              vibrate.start();
              timer_StopVibrate = timer.createTimer(stopDelay, 3000, stopVibro, {});
            }

            function stopVibro(){
              vibrate.stop();
              if(timer_StopVibrate) timer.stopTimer(timer_StopVibrate);
            }

            // end vibrate function

            normal_countdown_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 120,
              y: 326,
              w: 80,
              h: 80,
              type: hmUI.data_type.COUNT_DOWN,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sleep_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 133,
              y: 106,
              w: 80,
              h: 80,
              type: hmUI.data_type.SLEEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_alarm_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 9,
              y: 271,
              w: 50,
              h: 50,
              type: hmUI.data_type.ALARM_CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sunrise_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 296,
              y: 52,
              w: 100,
              h: 50,
              type: hmUI.data_type.SUN_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_altimeter_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 61,
              y: 64,
              w: 50,
              h: 50,
              type: hmUI.data_type.ALTIMETER,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 188,
              y: -2,
              w: 100,
              h: 80,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                normal_frame_animation_1.setProperty(hmUI.prop.ANIM_STATUS,hmUI.anim_status.START);
                checkConnection();
                stopVibro();

              }),
              pause_call: (function () {
                normal_frame_animation_1.setProperty(hmUI.prop.ANIM_STATUS,hmUI.anim_status.STOP);
                stopVibro();

              }),
            });

                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}