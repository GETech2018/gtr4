(() => {
    var __$$app$$__ = __$$hmAppManager$$__.currentApp;
    __$$app$$__.app = DeviceRuntimeCore.App({
        globalData: {},
        onCreate(options) {},
        onShow(options) {},
        onHide(options) {},
        onDestroy(options) {},
        onError(error) {},
        onPageNotFound(obj) {},
        onUnhandledRejection(obj) {}
    });
})()
