try {
  (() => {
    const init_view = () => {
      let editScreen = hmSetting.getScreenType() == hmSetting.screen_type.SETTINGS
      let isAoD = hmSetting.getScreenType() == hmSetting.screen_type.AOD

      const deviceInfo = hmSetting.getDeviceInfo()
      const screenWidth = deviceInfo.width
      const screenHeight = deviceInfo.height

      const editAccentColor = hmUI.createWidget(hmUI.widget.WATCHFACE_EDIT_GROUP, {
        edit_id: 101,
        x: 0,
        y: screenHeight / 2 - 200,
        w: screenWidth,
        h: 70,
        select_image: 'void.png',
        un_select_image: 'void.png',
        default_type: 0,
        optional_types: [
          { type: 0, preview: 'edit/c0.png', title_en: 'Красный' },
          { type: 1, preview: 'edit/c1.png', title_en: 'Оранжевый' },
          { type: 2, preview: 'edit/c2.png', title_en: 'Жёлтый' },
          { type: 3, preview: 'edit/c3.png', title_en: 'Салатовый' },
          { type: 4, preview: 'edit/c4.png', title_en: 'Зелёный' },
          { type: 5, preview: 'edit/c5.png', title_en: 'Бирюзовый' },
          { type: 6, preview: 'edit/c6.png', title_en: 'Голубой' },
          { type: 7, preview: 'edit/c7.png', title_en: 'Синий' },
          { type: 8, preview: 'edit/c8.png', title_en: 'Фиолетовый' },
          { type: 9, preview: 'edit/c9.png', title_en: 'Малиновый' }
        ],
        count: 10,
        tips_width: 92,
        tips_margin: 5,
        tips_x: screenWidth / 2 - 46,
        tips_y: 330,
        tips_BG: 'tips_bg.png'
      })
      let colorType = editAccentColor.getProperty(hmUI.prop.CURRENT_TYPE)

      const editBgColor = hmUI.createWidget(hmUI.widget.WATCHFACE_EDIT_GROUP, {
        edit_id: 102,
        x: 0,
        y: screenHeight / 2 - 110,
        w: screenWidth,
        h: 220,
        select_image: 'void.png',
        un_select_image: 'void.png',
        default_type: 0,
        optional_types: [
          { type: 0, preview: 'edit/0.png', title_en: 'Фон: чёрный' },
          { type: 1, preview: 'edit/1.png', title_en: 'Фон: белыйый' }
        ],
        count: 2,
        tips_width: 92,
        tips_margin: 5,
        tips_x: screenWidth / 2 - 46,
        tips_y: 240,
        tips_BG: 'tips_bg.png'
      })

      let bgType = editBgColor.getProperty(hmUI.prop.CURRENT_TYPE)

      if (editScreen) return

      let suffix = bgType && !isAoD ? '_black' : ''
      let textArray = Array.from(Array(10), (v, k) => `main/${k}${suffix}.png`)
      let whiteTextArray = Array.from(Array(10), (v, k) => `main/${k}.png`)
      let timeArray = Array.from(Array(10), (v, k) => `main/t${k}${suffix}.png`)
      let dayArray = Array.from(Array(10), (v, k) => `main/d${k}${suffix}.png`)
      let monthArray = Array.from(Array(12), (v, k) => `main/m${k}${suffix}.png`)
      let weekArray = Array.from(Array(7), (v, k) => `main/w${k}${bgType && !isAoD ? '_white' : ''}.png`)
      let weatherIconArray = Array.from(Array(29), (v, k) => `weather/${k}.png`)
      let colors = [0xb80c00, 0xB84900, 0xB88700, 0x6EB800, 0x00B80D, 0x00B888, 0x006DB8, 0x0E00B8, 0x8900B8, 0xB8006C]
      let accentColor = colors[colorType]

      if (bgType) {
        hmUI.createWidget(hmUI.widget.FILL_RECT, {
          x: 0,
          y: 0,
          w: screenWidth,
          h: screenHeight,
          radius: screenWidth / 2,
          color: 0xffffff,
          show_level: hmUI.show_level.ONLY_NORMAL
        })
      }

      hmUI.createWidget(hmUI.widget.IMG_STATUS, {
        x: screenWidth / 2 - 16,
        y: 14,
        type: hmUI.system_status.DISCONNECT,
        src: `main/bt${suffix}.png`
      })

      hmUI.createWidget(hmUI.widget.FILL_RECT, {
        x: screenWidth / 2 - 95,
        y: 38,
        w: 43,
        h: 43,
        color: bgType ? 0xb2b2b2 : 0x4d4d4d,
        show_level: hmUI.show_level.ONLY_NORMAL
      })
      let batteryScale = []
      for (let i = 0; i < 5; i++) {
        batteryScale[i] = hmUI.createWidget(hmUI.widget.FILL_RECT, {
          x: screenWidth / 2 - 95,
          y: 74 - 9 * i,
          w: 0,
          h: 7,
          color: bgType ? 0x000000 : 0xffffff,
          show_level: hmUI.show_level.ONLY_NORMAL
        })
      }
      hmUI.createWidget(hmUI.widget.IMG, {
        x: screenWidth / 2 - 97,
        y: 36,
        src: `main/bfg${bgType ? '_white' : ''}.png`,
        show_level: hmUI.show_level.ONLY_NORMAL
      })
      hmUI.createWidget(hmUI.widget.FILL_RECT, {
        x: screenWidth / 2 + 2,
        y: 35,
        w: 100,
        h: 50,
        radius: 25,
        color: accentColor,
        show_level: hmUI.show_level.ONLY_NORMAL
      })
      hmUI.createWidget(hmUI.widget.TEXT_IMG, {
        x: screenWidth / 2 + 2,
        y: 51,
        w: 100,
        h: 18,
        font_array: whiteTextArray,
        type: hmUI.data_type.BATTERY,
        unit_en: `main/%.png`,
        align_h: hmUI.align.CENTER_H,
        h_space: 0,
        show_level: hmUI.show_level.ONLY_NORMAL
      })

      hmUI.createWidget(hmUI.widget.FILL_RECT, {
        x: 50,
        y: 95,
        w: 50,
        h: 50,
        radius: 25,
        color: accentColor,
        show_level: hmUI.show_level.ONLY_NORMAL
      })
      hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
        x: 55,
        y: 100,
        image_array: weatherIconArray,
        image_length: weatherIconArray.length,
        type: hmUI.data_type.WEATHER,
        show_level: hmUI.show_level.ONLY_NORMAL
      })
      hmUI.createWidget(hmUI.widget.TEXT_IMG, {
        x: 120,
        y: 111,
        w: 70,
        h: 18,
        font_array: textArray,
        align_h: hmUI.align.LEFT,
        type: hmUI.data_type.WEATHER_CURRENT,
        unit_en: `main/deg${suffix}.png`,
        negative_image: `main/-${suffix}.png`,
        invalid_image: `main/-${suffix}.png`,
        h_space: 0,
        show_level: hmUI.show_level.ONLY_NORMAL
      })
      hmUI.createWidget(hmUI.widget.TEXT_IMG, {
        x: 220,
        y: 111,
        w: 70,
        h: 18,
        font_array: textArray,
        align_h: hmUI.align.LEFT,
        type: hmUI.data_type.WEATHER_HIGH,
        unit_en: `main/deg${suffix}.png`,
        negative_image: `main/-${suffix}.png`,
        invalid_image: `main/-${suffix}.png`,
        h_space: 0,
        show_level: hmUI.show_level.ONLY_NORMAL
      })
      hmUI.createWidget(hmUI.widget.TEXT_IMG, {
        x: 320,
        y: 111,
        w: 70,
        h: 18,
        font_array: textArray,
        align_h: hmUI.align.LEFT,
        type: hmUI.data_type.WEATHER_LOW,
        unit_en: `main/deg${suffix}.png`,
        negative_image: `main/-${suffix}.png`,
        invalid_image: `main/-${suffix}.png`,
        h_space: 0,
        show_level: hmUI.show_level.ONLY_NORMAL
      })

      hmUI.createWidget(hmUI.widget.IMG_DATE, {
        day_startX: 18,
        day_startY: 160,
        day_space: 6,
        day_zero: true,
        day_en_array: dayArray,
        day_is_character: false,
        month_startX: 111,
        month_startY: 160,
        month_space: -2,
        month_zero: true,
        month_en_array: monthArray,
        month_is_character: true,
        show_level: hmUI.show_level.ONLY_NORMAL
      })
      hmUI.createWidget(hmUI.widget.FILL_RECT, {
        x: 111,
        y: 189,
        w: 63,
        h: 19,
        color: accentColor,
        show_level: hmUI.show_level.ONLY_NORMAL
      })
      hmUI.createWidget(hmUI.widget.IMG_WEEK, {
        x: 110,
        y: 188,
        week_en: weekArray,
        week_tc: weekArray,
        week_sc: weekArray,
        show_level: hmUI.show_level.ONLY_NORMAL
      })
      hmUI.createWidget(hmUI.widget.IMG, {
        x: 190,
        y: 161,
        src: `main/today${bgType ? '_black' : ''}.png`,
        show_level: hmUI.show_level.ONLY_NORMAL
      })
      const costil = hmUI.createWidget(hmUI.widget.FILL_RECT, {
        x: screenWidth - 10,
        y: 200,
        w: 0,
        h: 9,
        color: bgType ? 0xffffff : 0x000000,
        show_level: hmUI.show_level.ONLY_NORMAL
      })

      hmUI.createWidget(hmUI.widget.TEXT_IMG, {
        x: screenWidth - 110,
        y: screenHeight / 2 - 40,
        w: 100,
        h: 18,
        font_array: textArray,
        align_h: hmUI.align.RIGHT,
        type: hmUI.data_type.STEP,
        h_space: 0,
        show_level: hmUI.show_level.ONLY_NORMAL
      })
      let stepsScale = []
      for (let i = 0; i < 35; i++) {
        stepsScale[i] = hmUI.createWidget(hmUI.widget.CIRCLE, {
          center_x: 12 + i * 13,
          center_y: screenHeight / 2,
          radius: 5,
          color: bgType ? 0xb2b2b2 : 0x4d4d4d,
          show_level: hmUI.show_level.ONLY_NORMAL
        })
      }
      hmUI.createWidget(hmUI.widget.FILL_RECT, {
        x: 10,
        y: 245,
        w: 43,
        h: 39,
        color: accentColor,
        show_level: hmUI.show_level.ONLY_NORMAL
      })
      hmUI.createWidget(hmUI.widget.IMG, {
        x: 8,
        y: 243,
        src: `main/heart${bgType ? '_white' : ''}.png`,
        show_level: hmUI.show_level.ONLY_NORMAL
      })
      hmUI.createWidget(hmUI.widget.TEXT_IMG, {
        x: 60,
        y: 255,
        w: 54,
        h: 18,
        font_array: textArray,
        align_h: hmUI.align.LEFT,
        type: hmUI.data_type.HEART,
        h_space: 0,
        show_level: hmUI.show_level.ONLY_NORMAL
      })
      hmUI.createWidget(hmUI.widget.FILL_RECT, {
        x: screenWidth - 53,
        y: 245,
        w: 43,
        h: 39,
        color: accentColor,
        show_level: hmUI.show_level.ONLY_NORMAL
      })
      hmUI.createWidget(hmUI.widget.IMG, {
        x: screenWidth - 55,
        y: 243,
        src: `main/cal${bgType ? '_white' : ''}.png`,
        show_level: hmUI.show_level.ONLY_NORMAL
      })
      hmUI.createWidget(hmUI.widget.TEXT_IMG, {
        x: screenWidth - 160,
        y: 255,
        w: 100,
        h: 18,
        font_array: textArray,
        align_h: hmUI.align.RIGHT,
        type: hmUI.data_type.CAL,
        h_space: 0,
        show_level: hmUI.show_level.ONLY_NORMAL
      })

      hmUI.createWidget(hmUI.widget.CIRCLE, {
        center_x: screenWidth / 2 - 130,
        center_y: 345,
        radius: 50,
        color: bgType ? 0x000000 : 0xffffff,
        show_level: hmUI.show_level.ONLY_NORMAL
      })
      hmUI.createWidget(hmUI.widget.CIRCLE, {
        center_x: screenWidth / 2 + 130,
        center_y: 345,
        radius: 50,
        color: accentColor,
        show_level: hmUI.show_level.ONLY_NORMAL
      })
      hmUI.createWidget(hmUI.widget.TIME_POINTER, {
        hour_centerX: screenWidth / 2 - 130,
        hour_centerY: 345,
        hour_posX: 2,
        hour_posY: 38,
        hour_path: `main/arrow${bgType ? '_white' : ''}.png`,
        minute_centerX: screenWidth / 2 + 130,
        minute_centerY: 345,
        minute_posX: 2,
        minute_posY: 38,
        minute_path: `main/arrow${bgType ? '_white' : ''}.png`,
        show_level: hmUI.show_level.ONLY_NORMAL
      })
      hmUI.createWidget(hmUI.widget.IMG_TIME, {
        hour_zero: 1,
        hour_startX: screenWidth / 2 - 44,
        hour_startY: isAoD ? screenHeight / 2 - 80 : 280,
        hour_array: timeArray,
        hour_space: 8,
        minute_zero: 1,
        minute_startX: screenWidth / 2 - 44,
        minute_startY: isAoD ? screenHeight / 2 + 10 : 362,
        minute_array: timeArray,
        minute_space: 8
      })

      const battery = hmSensor.createSensor(hmSensor.id.BATTERY)
      function BatteryUpdate() {
        for (let i = 0; i < batteryScale.length; i++) {
          let lineWidth = 20 * (i + 1) <= battery.current ? 43 : Math.floor(battery.current / 4 - 5 * i) * 9 - 2
          if (lineWidth < 0) lineWidth = 0
          batteryScale[i].setProperty(hmUI.prop.W, lineWidth)
        }
      }
      if (!isAoD) battery.addEventListener(hmSensor.event.CHANGE, () => BatteryUpdate())

      const step = hmSensor.createSensor(hmSensor.id.STEP)
      function StepsUpdate() {
        let scaleStep = Math.floor(step.target / stepsScale.length)
        for(let i = 0; i < stepsScale.length; i++) {
          stepsScale[i].setProperty(hmUI.prop.COLOR, step.current >= scaleStep * (i+1) ? (bgType ? 0x000000 : 0xffffff) : (bgType ? 0xb2b2b2 : 0x4d4d4d))
        }
        let costilW = step.current.toString().length * 18 + 8
        let space = 38
        costilW = Math.ceil((costilW - space) / 4) * 4 + space
        costil.setProperty(hmUI.prop.X, screenWidth - 10 - costilW)
        costil.setProperty(hmUI.prop.W, costilW)
        console.log(screenWidth, screenWidth - 10 - costilW, costilW)
      }
      step.addEventListener(hmSensor.event.CHANGE, () => StepsUpdate())

      hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
        resume_call: function () {
          if (!isAoD) {
            BatteryUpdate()
            StepsUpdate()
          }
        },
        pause_call: function () { console.log("ui pause") }
      })
    }

    __$$hmAppManager$$__.currentApp.current.module = DeviceRuntimeCore.WatchFace({
      onInit() {},
      build() { init_view() },
      onDestory() {}
    })
  })()
} catch (error) {
  console.log(error)
}