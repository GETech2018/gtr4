﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        const logger = Logger.getLogger('watchface_SashaCX75');
        //end of ignored block

        //dynamic modify start

        
        console.log('user_functions.js');
        // start user_functions.js
let element_index = 1;
        let element_count = 3;
		
		function click_Content() {
              element_index++;
              if(element_index > element_count) element_index = 1;
			  
			  normal_moon_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, element_index == 1);
			  normal_sun_current_text_img.setProperty(hmUI.prop.VISIBLE, element_index == 1);
			  normal_digital_clock_img_time.setProperty(hmUI.prop.VISIBLE, element_index == 1);
			  normal_city_name_text.setProperty(hmUI.prop.VISIBLE, element_index == 1);
			  normal_battery_text_text_img.setProperty(hmUI.prop.VISIBLE, element_index == 1);
			  Button_1.setProperty(hmUI.prop.VISIBLE, element_index == 1);
			  Button_2.setProperty(hmUI.prop.VISIBLE, element_index == 1);
			  Button_3.setProperty(hmUI.prop.VISIBLE, element_index == 1);
			  Button_9.setProperty(hmUI.prop.VISIBLE, element_index == 1);

              normal_step_icon_img.setProperty(hmUI.prop.VISIBLE, element_index == 2);
			  normal_step_pointer_progress_img_pointer.setProperty(hmUI.prop.VISIBLE, element_index == 2);
			  normal_step_current_text_img.setProperty(hmUI.prop.VISIBLE, element_index == 2);
			  normal_distance_text_text_img.setProperty(hmUI.prop.VISIBLE, element_index == 2);
			  normal_calorie_current_text_img.setProperty(hmUI.prop.VISIBLE, element_index == 2);
			  normal_heart_rate_text_text_img.setProperty(hmUI.prop.VISIBLE, element_index == 2);
			  Button_4.setProperty(hmUI.prop.VISIBLE, element_index == 2);
			  Button_5.setProperty(hmUI.prop.VISIBLE, element_index == 2);
			  
			  normal_temperature_icon_img.setProperty(hmUI.prop.VISIBLE, element_index == 3);
			  normal_temperature_high_text_img.setProperty(hmUI.prop.VISIBLE, element_index == 3);
			  normal_temperature_low_text_img.setProperty(hmUI.prop.VISIBLE, element_index == 3);
			  normal_temperature_low_separator_img.setProperty(hmUI.prop.VISIBLE, element_index == 3);
			  normal_temperature_current_text_img.setProperty(hmUI.prop.VISIBLE, element_index == 3);
			  normal_weather_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, element_index == 3);
			  Button_6.setProperty(hmUI.prop.VISIBLE, element_index == 3);
			  Button_7.setProperty(hmUI.prop.VISIBLE, element_index == 3);
			  Button_8.setProperty(hmUI.prop.VISIBLE, element_index == 3);
			  
              if (element_index == 1) {
                 hmUI.showToast({text: 'TIME & MOON'});
               };
              if (element_index == 2) {
                 hmUI.showToast({text: 'ACTIVITY'});
               };
			  if (element_index == 3) {
                 hmUI.showToast({text: 'WEATHER'});
               };
        };
		
		let handsnumber_main = 1
        let totalhands_main = 5
		let hourstring = 'hand_hour1.png'
		let minstring = 'hand_min1.png'
		let secstring = 'hand_sec.png'

        function click_Hands() {
            if(handsnumber_main>=totalhands_main) {
            handsnumber_main=1;
                }
            else {
                handsnumber_main=handsnumber_main+1;
            }

			if ( handsnumber_main == 1) { namecolor_main = "HAND STYLE 1"
				hourstring = 'hand_hour' +handsnumber_main+ '.png'
				minstring = 'hand_min' +handsnumber_main+ '.png'
				secstring = 'hand_sec.png'
			}

			if ( handsnumber_main == 2) { namecolor_main = "HAND STYLE 2"
				hourstring = 'hand_hour' +handsnumber_main+ '.png'
				minstring = 'hand_min' +handsnumber_main+ '.png'
				secstring = 'hand_sec.png'
			}

			if ( handsnumber_main == 3) { namecolor_main = "HAND STYLE 3"
				hourstring = 'hand_hour' +handsnumber_main+ '.png'
				minstring = 'hand_min' +handsnumber_main+ '.png'
				secstring = 'hand_sec.png'
			}

			if ( handsnumber_main == 4) { namecolor_main = "HAND STYLE 4"
				hourstring = 'hand_hour' +handsnumber_main+ '.png'
				minstring =  'hand_min' +handsnumber_main+ '.png'
				secstring = 'hand_sec.png'
			}

			if ( handsnumber_main == 5) { namecolor_main = "NO HANDS"
				hourstring = '0_Empty.png'
				minstring = '0_Empty.png'
				secstring = '0_Empty.png'
			}

			if ( handsnumber_main <= 5) { 
			
            normal_analog_clock_time_pointer_hour.setProperty(hmUI.prop.MORE, {
              hour_path: hourstring,
              hour_centerX: 233,
              hour_centerY: 233,
              hour_posX: 233,
              hour_posY: 233,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
			normal_analog_clock_time_pointer_minute.setProperty(hmUI.prop.MORE, {
              minute_path: minstring,
              minute_centerX: 233,
              minute_centerY: 233,
              minute_posX: 233,
              minute_posY: 233,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
			normal_analog_clock_time_pointer_second.setProperty(hmUI.prop.MORE, {
              second_path: secstring,
              second_centerX: 233,
              second_centerY: 233,
              second_posX: 233,
              second_posY: 233,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
			
			}
			hmUI.showToast({text: namecolor_main });
        }
        // end user_functions.js

        let normal_background_bg = ''
        let normal_analog_clock_pro_hour_pointer_img = ''
        let normal_analog_clock_pro_minute_pointer_img = ''
        let normal_analog_clock_pro_second_pointer_img = ''
        let normal_timerUpdateSec = undefined;
        let normal_stress_icon_img = ''
        let normal_step_icon_img = ''
        let normal_step_pointer_progress_img_pointer = ''
        let normal_step_current_text_img = ''
        let normal_distance_text_text_img = ''
        let normal_calorie_current_text_img = ''
        let normal_heart_rate_text_text_img = ''
        let normal_moon_image_progress_img_level = ''
        let normal_sun_current_text_img = ''
        let normal_digital_clock_img_time_AmPm = ''
        let normal_digital_clock_img_time = ''
        let normal_city_name_text = ''
        let normal_temperature_icon_img = ''
        let normal_temperature_high_text_img = ''
        let normal_temperature_low_text_img = ''
        let normal_temperature_low_separator_img = ''
        let normal_temperature_current_text_img = ''
        let normal_weather_image_progress_img_level = ''
        let normal_pai_icon_img = ''
        let normal_battery_text_text_img = ''
        let normal_battery_circle_scale = ''
        let normal_battery_icon_img = ''
        let normal_battery_pointer_progress_img_pointer = ''
        let normal_week_pointer_progress_date_pointer = ''
        let normal_month_pointer_progress_date_pointer = ''
        let normal_year_TextRotate = new Array(4);
        let normal_year_TextRotate_ASCIIARRAY = new Array(10);
        let normal_year_TextRotate_img_width = 14;
        let normal_timerTextUpdate = undefined;
        let normal_day_TextRotate = new Array(2);
        let normal_day_TextRotate_ASCIIARRAY = new Array(10);
        let normal_day_TextRotate_img_width = 21;
        let normal_system_disconnect_img = ''
        let normal_system_clock_img = ''
        let normal_analog_clock_time_pointer_hour = ''
        let normal_analog_clock_time_pointer_minute = ''
        let normal_analog_clock_time_pointer_second = ''
        let idle_background_bg_img = ''
        let idle_digital_clock_img_time = ''
        let idle_battery_text_text_img = ''
        let idle_system_disconnect_img = ''
        let idle_system_clock_img = ''
        let normal_alarm_jumpable_img_click = ''
        let Button_1 = ''
        let Button_2 = ''
        let Button_3 = ''
        let Button_4 = ''
        let Button_5 = ''
        let Button_6 = ''
        let Button_7 = ''
        let Button_8 = ''
        let Button_9 = ''
        let Button_10 = ''
        let Button_11 = ''
        let Button_12 = ''
        let Button_13 = ''
        let Button_14 = ''
        let Button_15 = ''
        let timeSensor = ''


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            console.log('Watch_Face.ScreenNormal');
            normal_background_bg = hmUI.createWidget(hmUI.widget.FILL_RECT, {
              x: 0,
              y: 0,
              w: 466,
              h: 466,
              color: '0xFF000000',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            const deviceInfo = hmSetting.getDeviceInfo();
            if (!timeSensor) timeSensor = hmSensor.createSensor(hmSensor.id.TIME);
            timeSensor.addEventListener(timeSensor.event.MINUTEEND, function() {
              time_update(true, true);
            });

            // normal_analog_clock_pro_hour_pointer_img = hmUI.createWidget(hmUI.widget.TIME_POINTER_PRO, {
              // src: 'time_hour.png',
              // center_x: 233,
              // center_y: 233,
              // x: 231,
              // y: 230,
              // start_angle: 1,
              // end_angle: 151,
              // type: hmUI.data_type.hour,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });


            normal_analog_clock_pro_hour_pointer_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: deviceInfo.width,
              h: deviceInfo.height,
              pos_x: 233 - 231,
              pos_y: 233 - 230,
              center_x: 233,
              center_y: 233,
              src: 'time_hour.png',
              angle: 0,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_analog_clock_pro_minute_pointer_img = hmUI.createWidget(hmUI.widget.TIME_POINTER_PRO, {
              // src: 'time_min.png',
              // center_x: 233,
              // center_y: 233,
              // x: 231,
              // y: 230,
              // start_angle: 2,
              // end_angle: 152,
              // type: hmUI.data_type.minute,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });


            normal_analog_clock_pro_minute_pointer_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: deviceInfo.width,
              h: deviceInfo.height,
              pos_x: 233 - 231,
              pos_y: 233 - 230,
              center_x: 233,
              center_y: 233,
              src: 'time_min.png',
              angle: 0,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_analog_clock_pro_second_pointer_img = hmUI.createWidget(hmUI.widget.TIME_POINTER_PRO, {
              // src: 'time_sec.png',
              // center_x: 233,
              // center_y: 233,
              // x: 233,
              // y: 233,
              // start_angle: -152,
              // end_angle: -3,
              // type: hmUI.data_type.second,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });


            normal_analog_clock_pro_second_pointer_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: deviceInfo.width,
              h: deviceInfo.height,
              pos_x: 233 - 233,
              pos_y: 233 - 233,
              center_x: 233,
              center_y: 233,
              src: 'time_sec.png',
              angle: 0,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            let screenType = hmSetting.getScreenType();
            normal_stress_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'panel_tim.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'panel_bck.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_pointer_progress_img_pointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
              src: 'hand_step.png',
              center_x: 233,
              center_y: 233,
              x: 233,
              y: 233,
              start_angle: 0,
              end_angle: -70,
              cover_path: 'panel_act.png',
              cover_x: 0,
              cover_y: 0,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 261,
              y: 320,
              font_array: ["big_00.png","big_01.png","big_02.png","big_03.png","big_04.png","big_05.png","big_06.png","big_07.png","big_08.png","big_09.png"],
              padding: false,
              h_space: 1,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_distance_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 262,
              y: 369,
              font_array: ["num_00.png","num_01.png","num_02.png","num_03.png","num_04.png","num_05.png","num_06.png","num_07.png","num_08.png","num_09.png"],
              padding: false,
              h_space: 0,
              dot_image: 'num_10.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.DISTANCE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_calorie_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 338,
              y: 267,
              font_array: ["num_00.png","num_01.png","num_02.png","num_03.png","num_04.png","num_05.png","num_06.png","num_07.png","num_08.png","num_09.png"],
              padding: false,
              h_space: 2,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 338,
              y: 289,
              font_array: ["num_00.png","num_01.png","num_02.png","num_03.png","num_04.png","num_05.png","num_06.png","num_07.png","num_08.png","num_09.png"],
              padding: false,
              h_space: 2,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_moon_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 259,
              y: 357,
              image_array: ["Moon_01.png","Moon_02.png","Moon_03.png","Moon_04.png","Moon_05.png","Moon_06.png","Moon_07.png","Moon_08.png","Moon_09.png","Moon_10.png","Moon_11.png","Moon_12.png","Moon_13.png","Moon_14.png","Moon_15.png","Moon_16.png","Moon_17.png","Moon_18.png","Moon_19.png","Moon_20.png","Moon_21.png","Moon_22.png","Moon_23.png","Moon_24.png","Moon_25.png","Moon_26.png","Moon_27.png","Moon_28.png","Moon_29.png","Moon_30.png"],
              image_length: 30,
              type: hmUI.data_type.MOON,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sun_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 306,
              y: 341,
              font_array: ["num_00.png","num_01.png","num_02.png","num_03.png","num_04.png","num_05.png","num_06.png","num_07.png","num_08.png","num_09.png"],
              padding: false,
              h_space: 0,
              dot_image: 'num_11.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.SUN_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time_AmPm = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              am_x: 0,
              am_y: 0,
              am_sc_path: 'time_am.png',
              am_en_path: 'time_am.png',
              pm_x: 0,
              pm_y: 0,
              pm_sc_path: 'time_pm.png',
              pm_en_path: 'time_pm.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 277,
              hour_startY: 301,
              hour_array: ["big_00.png","big_01.png","big_02.png","big_03.png","big_04.png","big_05.png","big_06.png","big_07.png","big_08.png","big_09.png"],
              hour_zero: 1,
              hour_space: 2,
              hour_angle: 0,
              hour_unit_sc: 'big_10.png',
              hour_unit_tc: 'big_10.png',
              hour_unit_en: 'big_10.png',
              hour_align: hmUI.align.LEFT,

              minute_startX: 0,
              minute_startY: 0,
              minute_array: ["big_00.png","big_01.png","big_02.png","big_03.png","big_04.png","big_05.png","big_06.png","big_07.png","big_08.png","big_09.png"],
              minute_zero: 1,
              minute_space: 2,
              minute_angle: 0,
              minute_follow: 1,
              minute_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });
              const weatherSensor = hmSensor.createSensor(hmSensor.id.WEATHER);

            normal_city_name_text = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 277,
              y: 269,
              w: 136,
              h: 29,
              text_size: 19,
              char_space: 0,
              line_space: 0,
              color: 0xFFC0C0C0,
              align_h: hmUI.align.LEFT,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'panel_we.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_high_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 336,
              y: 334,
              font_array: ["num_00.png","num_01.png","num_02.png","num_03.png","num_04.png","num_05.png","num_06.png","num_07.png","num_08.png","num_09.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'num_14.png',
              unit_tc: 'num_14.png',
              unit_en: 'num_14.png',
              negative_image: 'num_12.png',
              invalid_image: 'num_13.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_HIGH,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_low_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 268,
              y: 334,
              font_array: ["num_00.png","num_01.png","num_02.png","num_03.png","num_04.png","num_05.png","num_06.png","num_07.png","num_08.png","num_09.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'num_14.png',
              unit_tc: 'num_14.png',
              unit_en: 'num_14.png',
              negative_image: 'num_12.png',
              invalid_image: 'num_13.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_LOW,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_low_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 322,
              y: 334,
              src: 'num_15.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 259,
              y: 293,
              font_array: ["big_00.png","big_01.png","big_02.png","big_03.png","big_04.png","big_05.png","big_06.png","big_07.png","big_08.png","big_09.png"],
              padding: false,
              h_space: 1,
              unit_sc: 'big_13.png',
              unit_tc: 'big_13.png',
              unit_en: 'big_13.png',
              negative_image: 'big_12.png',
              invalid_image: 'big_14.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 343,
              y: 273,
              image_array: ["weatherl_00.png","weatherl_01.png","weatherl_02.png","weatherl_03.png","weatherl_04.png","weatherl_05.png","weatherl_06.png","weatherl_07.png","weatherl_08.png","weatherl_09.png","weatherl_10.png","weatherl_11.png","weatherl_12.png","weatherl_13.png","weatherl_14.png","weatherl_15.png","weatherl_16.png","weatherl_17.png","weatherl_18.png","weatherl_19.png","weatherl_20.png","weatherl_21.png","weatherl_22.png","weatherl_23.png","weatherl_24.png","weatherl_25.png","weatherl_26.png","weatherl_27.png","weatherl_28.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_pai_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'main1.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 368,
              y: 258,
              font_array: ["num_00.png","num_01.png","num_02.png","num_03.png","num_04.png","num_05.png","num_06.png","num_07.png","num_08.png","num_09.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'num_16.png',
              unit_tc: 'num_16.png',
              unit_en: 'num_16.png',
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_battery_circle_scale = hmUI.createWidget(hmUI.widget.Circle_Scale, {
              // center_x: 352,
              // center_y: 232,
              // start_angle: -116,
              // end_angle: 93,
              // radius: 72,
              // line_width: 31,
              // line_cap: Flat,
              // color: 0xFF000000,
              // mirror: False,
              // inversion: True,
              // type: hmUI.data_type.BATTERY,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_battery_circle_scale = hmUI.createWidget(hmUI.widget.ARC_PROGRESS, {
              center_x: 352,
              center_y: 232,
              start_angle: 93,
              end_angle: -116,
              radius: 57,
              line_width: 31,
              corner_flag: 3,
              color: 0xFF000000,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            
            const battery = hmSensor.createSensor(hmSensor.id.BATTERY);
            battery.addEventListener(hmSensor.event.CHANGE, function() {
              scale_call();
            });

            normal_battery_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'bat_for.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_pointer_progress_img_pointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
              src: 'hand_batt.png',
              center_x: 352,
              center_y: 232,
              x: 116,
              y: 104,
              start_angle: -110,
              end_angle: 90,
              cover_path: 'hand_batt_top.png',
              cover_x: 238,
              cover_y: 114,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_week_pointer_progress_date_pointer = hmUI.createWidget(hmUI.widget.DATE_POINTER, {
              src: 'hand_wd.png',
              center_x: 146,
              center_y: 383,
              posX: 118,
              posY: 117,
              start_angle: -20,
              end_angle: 150,
              scale_sc: 'date_bck.png',
              scale_tc: 'date_bck.png',
              scale_en: 'date_bck.png',
              scale_x: 0,
              scale_y: 0,
              type: hmUI.date.WEEK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_month_pointer_progress_date_pointer = hmUI.createWidget(hmUI.widget.DATE_POINTER, {
              src: 'hand_month.png',
              center_x: 146,
              center_y: 383,
              posX: 113,
              posY: 113,
              start_angle: -18,
              end_angle: 152,
              cover_path: 'date_for.png',
              cover_x: 0,
              cover_y: 0,
              type: hmUI.date.MONTH,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_year_text_rotate_img = hmUI.createWidget(hmUI.widget.Text_Rotate, {
              // x: 121,
              // y: 372,
              // font_array: ["num_00.png","num_01.png","num_02.png","num_03.png","num_04.png","num_05.png","num_06.png","num_07.png","num_08.png","num_09.png"],
              // zero: true,
              // unit_in_alignment: false,
              // h_space: 0,
              // angle: 30,
              // align_h: hmUI.align.LEFT,
              // type: hmUI.data_type.YEAR,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_year_TextRotate_ASCIIARRAY[0] = 'num_00.png';  // set of images with numbers
            normal_year_TextRotate_ASCIIARRAY[1] = 'num_01.png';  // set of images with numbers
            normal_year_TextRotate_ASCIIARRAY[2] = 'num_02.png';  // set of images with numbers
            normal_year_TextRotate_ASCIIARRAY[3] = 'num_03.png';  // set of images with numbers
            normal_year_TextRotate_ASCIIARRAY[4] = 'num_04.png';  // set of images with numbers
            normal_year_TextRotate_ASCIIARRAY[5] = 'num_05.png';  // set of images with numbers
            normal_year_TextRotate_ASCIIARRAY[6] = 'num_06.png';  // set of images with numbers
            normal_year_TextRotate_ASCIIARRAY[7] = 'num_07.png';  // set of images with numbers
            normal_year_TextRotate_ASCIIARRAY[8] = 'num_08.png';  // set of images with numbers
            normal_year_TextRotate_ASCIIARRAY[9] = 'num_09.png';  // set of images with numbers

            //start of ignored block
            for (let i = 0; i < 4; i++) {
              normal_year_TextRotate[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 466,
                h: 466,
                center_x: 121,
                center_y: 372,
                pos_x: 121,
                pos_y: 372,
                angle: 30,
                src: 'num_00.png',
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
              normal_year_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
            };
            //end of ignored block
            
            const timeNaw = hmSensor.createSensor(hmSensor.id.TIME);

            // normal_day_text_rotate_img = hmUI.createWidget(hmUI.widget.Text_Rotate, {
              // x: 162,
              // y: 357,
              // font_array: ["big_00.png","big_01.png","big_02.png","big_03.png","big_04.png","big_05.png","big_06.png","big_07.png","big_08.png","big_09.png"],
              // zero: true,
              // unit_in_alignment: false,
              // h_space: 2,
              // angle: 30,
              // align_h: hmUI.align.CENTER_H,
              // type: hmUI.data_type.DAY,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_day_TextRotate_ASCIIARRAY[0] = 'big_00.png';  // set of images with numbers
            normal_day_TextRotate_ASCIIARRAY[1] = 'big_01.png';  // set of images with numbers
            normal_day_TextRotate_ASCIIARRAY[2] = 'big_02.png';  // set of images with numbers
            normal_day_TextRotate_ASCIIARRAY[3] = 'big_03.png';  // set of images with numbers
            normal_day_TextRotate_ASCIIARRAY[4] = 'big_04.png';  // set of images with numbers
            normal_day_TextRotate_ASCIIARRAY[5] = 'big_05.png';  // set of images with numbers
            normal_day_TextRotate_ASCIIARRAY[6] = 'big_06.png';  // set of images with numbers
            normal_day_TextRotate_ASCIIARRAY[7] = 'big_07.png';  // set of images with numbers
            normal_day_TextRotate_ASCIIARRAY[8] = 'big_08.png';  // set of images with numbers
            normal_day_TextRotate_ASCIIARRAY[9] = 'big_09.png';  // set of images with numbers

            //start of ignored block
            for (let i = 0; i < 2; i++) {
              normal_day_TextRotate[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 466,
                h: 466,
                center_x: 162,
                center_y: 357,
                pos_x: 162,
                pos_y: 357,
                angle: 30,
                src: 'big_00.png',
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
              normal_day_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
            };
            //end of ignored block

            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 0,
              y: 0,
              src: 'status_bt.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 0,
              y: 0,
              src: 'status_al.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_hour = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              hour_path: 'hand_hour1.png',
              hour_centerX: 233,
              hour_centerY: 233,
              hour_posX: 232,
              hour_posY: 232,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_minute = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              minute_path: 'hand_min1.png',
              minute_centerX: 233,
              minute_centerY: 233,
              minute_posX: 233,
              minute_posY: 233,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_second = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              second_path: 'hand_sec.png',
              second_centerX: 233,
              second_centerY: 233,
              second_posX: 233,
              second_posY: 232,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            console.log('Watch_Face.ScreenAOD');
            idle_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 466,
              h: 466,
              src: 'aod_bg.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 227,
              hour_startY: 208,
              hour_array: ["0010.png","0011.png","0012.png","0013.png","0014.png","0015.png","0016.png","0017.png","0018.png","0019.png"],
              hour_zero: 1,
              hour_space: 3,
              hour_angle: 0,
              hour_unit_sc: 'sep.png',
              hour_unit_tc: 'sep.png',
              hour_unit_en: 'sep.png',
              hour_align: hmUI.align.LEFT,

              minute_startX: 0,
              minute_startY: 0,
              minute_array: ["0010.png","0011.png","0012.png","0013.png","0014.png","0015.png","0016.png","0017.png","0018.png","0019.png"],
              minute_zero: 1,
              minute_space: 3,
              minute_angle: 0,
              minute_follow: 1,
              minute_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 391,
              y: 219,
              font_array: ["dark_00.png","dark_01.png","dark_02.png","dark_03.png","dark_04.png","dark_05.png","dark_06.png","dark_07.png","dark_08.png","dark_09.png"],
              padding: false,
              h_space: 1,
              unit_sc: '0020.png',
              unit_tc: '0020.png',
              unit_en: '0020.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 170,
              y: 216,
              src: '0008.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 106,
              y: 211,
              src: '0009.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_AOD,
            });
            
            // disconnectAlert = hmUI.createWidget(hmUI.widget.DisconnectAlert, {
              // disconneсnt_vibrate_type: 0,
              // disconneсnt_toast_text: Bluetooth OFF,
              // conneсnt_vibrate_type: 0,
              // conneсnt_toast_text: Bluetooth ON,
            // });

            // vibration when connecting or disconnecting

            function checkConnection() {
              console.log('checkConnection()');
              hmBle.removeListener;
              hmBle.addListener(function (status) {
                if(!status) {
                  hmUI.showToast({text: "Bluetooth OFF"});
                  vibro(0);
                }
                if(status) {
                  hmUI.showToast({text: "Bluetooth ON"});
                  vibro(0);
                }
              });
            }

            // end vibration when connecting or disconnecting
            // vibrate function

            const vibrate = hmSensor.createSensor(hmSensor.id.VIBRATE);
            let timer_StopVibrate = null;


            function vibro(scene = 25) {
              let stopDelay = 50;
              stopVibro();
              vibrate.stop();
              vibrate.scene = scene;
              if(scene < 23 || scene > 25) stopDelay = 1300;
              vibrate.start();
              if (scene != 1) timer_StopVibrate = timer.createTimer(stopDelay, 3000, stopVibro, {});
            }

            function stopVibro(){
              vibrate.stop();
              if(timer_StopVibrate) timer.stopTimer(timer_StopVibrate);
            }

            // end vibrate function
            console.log('Watch_Face.Shortcuts');

            normal_alarm_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 0,
              y: 192,
              w: 80,
              h: 80,
              type: hmUI.data_type.ALARM_CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            console.log('Watch_Face.Buttons');
            Button_1 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 204,
              y: 204,
              w: 58,
              h: 58,
              text: '',
              color: 0xFFFF8C00,
              text_size: 24,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'CountdownAppScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_2 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 267,
              y: 330,
              w: 102,
              h: 39,
              text: '',
              color: 0xFFFF8C00,
              text_size: 24,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'TideScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_3 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 267,
              y: 369,
              w: 49,
              h: 49,
              text: '',
              color: 0xFFFF8C00,
              text_size: 24,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'Sleep_HomeScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_4 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 262,
              y: 316,
              w: 117,
              h: 49,
              text: '',
              color: 0xFFFF8C00,
              text_size: 24,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'activityAppScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_5 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 332,
              y: 257,
              w: 73,
              h: 49,
              text: '',
              color: 0xFFFF8C00,
              text_size: 24,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'heart_app_Screen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_6 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 267,
              y: 277,
              w: 73,
              h: 73,
              text: '',
              color: 0xFFFF8C00,
              text_size: 24,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'WeatherScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_7 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 267,
              y: 370,
              w: 80,
              h: 50,
              text: '',
              color: 0xFFFF8C00,
              text_size: 24,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'BaroAltimeterScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_8 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 194,
              y: 5,
              w: 78,
              h: 44,
              text: '',
              color: 0xFFFF8C00,
              text_size: 24,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'HmReStartScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_9 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 266,
              y: 290,
              w: 58,
              h: 40,
              text: '',
              color: 0xFFFF8C00,
              text_size: 24,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'StopWatchScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_10 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 49,
              y: 44,
              w: 73,
              h: 73,
              text: '',
              color: 0xFFFF8C00,
              text_size: 24,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'FindPhoneScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_11 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 345,
              y: 44,
              w: 73,
              h: 73,
              text: '',
              color: 0xFFFF8C00,
              text_size: 24,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'Settings_homeScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_12 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 306,
              y: 170,
              w: 97,
              h: 80,
              text: '',
              color: 0xFFFF8C00,
              text_size: 24,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'PowerSaveHintScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_13 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 91,
              y: 340,
              w: 97,
              h: 97,
              text: '',
              color: 0xFFFF8C00,
              text_size: 24,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'ScheduleCalScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_14 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 24,
              y: 307,
              w: 60,
              h: 60,
              text: '',
              color: 0xFFFF8C00,
              text_size: 24,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                click_Hands();
                				vibro(25);
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_15 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 202,
              y: 417,
              w: 58,
              h: 58,
              text: '',
              color: 0xFFFF8C00,
              text_size: 24,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                click_Content();
                				vibro(25);
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            console.log('user_script_end.js');
            // start user_script_end.js
let cc = 0
if (cc ==0 ){
	normal_step_icon_img.setProperty(hmUI.prop.VISIBLE, false);  
	normal_step_pointer_progress_img_pointer.setProperty(hmUI.prop.VISIBLE, false);  
	normal_step_current_text_img.setProperty(hmUI.prop.VISIBLE, false);  
	normal_distance_text_text_img.setProperty(hmUI.prop.VISIBLE, false);  
	normal_calorie_current_text_img.setProperty(hmUI.prop.VISIBLE, false);  
	normal_heart_rate_text_text_img.setProperty(hmUI.prop.VISIBLE, false);  
	Button_5.setProperty(hmUI.prop.VISIBLE, false);  
	Button_6.setProperty(hmUI.prop.VISIBLE, false);  
	Button_7.setProperty(hmUI.prop.VISIBLE, false);  
			  
	normal_temperature_icon_img.setProperty(hmUI.prop.VISIBLE, false);  
	normal_temperature_high_text_img.setProperty(hmUI.prop.VISIBLE, false);  
	normal_temperature_low_text_img.setProperty(hmUI.prop.VISIBLE, false);  
	normal_temperature_low_separator_img.setProperty(hmUI.prop.VISIBLE, false);  
	normal_temperature_current_text_img.setProperty(hmUI.prop.VISIBLE, false);  
	normal_weather_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, false); 
	Button_8.setProperty(hmUI.prop.VISIBLE, false);  
	Button_9	.setProperty(hmUI.prop.VISIBLE, false);  
	cc = 1;
}
            // end user_script_end.js

            function time_update(updateHour = false, updateMinute = false) {
              console.log('time_update()');
              let hour = timeSensor.hour;
              let minute = timeSensor.minute;
              let second = timeSensor.second;

              if (updateHour) {
                let normal_hour = hour;
                let normal_fullAngle_hour = 150;
                if (normal_hour > 11) normal_hour -= 12;
                let normal_angle_hour = 1 + normal_fullAngle_hour*normal_hour/12 + (normal_fullAngle_hour/12)*minute/60;
                if (normal_analog_clock_pro_hour_pointer_img) normal_analog_clock_pro_hour_pointer_img.setProperty(hmUI.prop.ANGLE, normal_angle_hour);
              };

              if (updateMinute) {
                let normal_fullAngle_minute = 150;
                let normal_angle_minute = 2 + normal_fullAngle_minute*minute/60;
                if (normal_analog_clock_pro_minute_pointer_img) normal_analog_clock_pro_minute_pointer_img.setProperty(hmUI.prop.ANGLE, normal_angle_minute);
              };

              let normal_fullAngle_second = 149;
              let normal_angle_second = -152 + normal_fullAngle_second*second/60;
              if (normal_analog_clock_pro_second_pointer_img) normal_analog_clock_pro_second_pointer_img.setProperty(hmUI.prop.ANGLE, normal_angle_second);

            };

            function text_update() {
              console.log('text_update()');

              console.log('update text rotate year_TIME');
              let valueYear = timeNaw.year;
              let normal_year_rotate_string = parseInt(valueYear).toString();

              if (screenType != hmSetting.screen_type.AOD) {
                for (var i = 1; i < 4; i++) {  // hide all symbols
                  normal_year_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                if (valueYear != null && valueYear != undefined && isFinite(valueYear) && normal_year_rotate_string.length > 0 && normal_year_rotate_string.length < 6) {  // display data if it was possible to get it
                  let img_offset = 0;
                  
                  let index = 0;
                  for (let char of normal_year_rotate_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 4) break;
                    if (charCode >= 0 && charCode < 10) { 
                      normal_year_TextRotate[index].setProperty(hmUI.prop.POS_X, 121 + img_offset);
                      normal_year_TextRotate[index].setProperty(hmUI.prop.SRC, normal_year_TextRotate_ASCIIARRAY[charCode]);
                      normal_year_TextRotate[index].setProperty(hmUI.prop.VISIBLE, true);
                      img_offset += normal_year_TextRotate_img_width;
                      index++;
                    };  // end if digit
                  };  // end char of string
                }  // end isFinite

              };

              console.log('update text rotate day_TIME');
              let valueDay = timeNaw.day;
              let normal_day_rotate_string = parseInt(valueDay).toString();
              normal_day_rotate_string = normal_day_rotate_string.padStart(2, '0');

              if (screenType != hmSetting.screen_type.AOD) {
                for (var i = 1; i < 2; i++) {  // hide all symbols
                  normal_day_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                if (valueDay != null && valueDay != undefined && isFinite(valueDay) && normal_day_rotate_string.length > 0 && normal_day_rotate_string.length < 6) {  // display data if it was possible to get it
                  let img_offset = 0;
                  // alignment = CENTER_H
                  let normal_day_TextRotate_posOffset = normal_day_TextRotate_img_width * normal_day_rotate_string.length;
                  normal_day_TextRotate_posOffset = normal_day_TextRotate_posOffset + 2 * (normal_day_rotate_string.length - 1);
                  img_offset -= normal_day_TextRotate_posOffset/2;
                  // alignment end
                  
                  let index = 0;
                  for (let char of normal_day_rotate_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 2) break;
                    if (charCode >= 0 && charCode < 10) { 
                      normal_day_TextRotate[index].setProperty(hmUI.prop.POS_X, 162 + img_offset);
                      normal_day_TextRotate[index].setProperty(hmUI.prop.SRC, normal_day_TextRotate_ASCIIARRAY[charCode]);
                      normal_day_TextRotate[index].setProperty(hmUI.prop.VISIBLE, true);
                      img_offset += normal_day_TextRotate_img_width + 2;
                      index++;
                    };  // end if digit
                  };  // end char of string
                }  // end isFinite

              };

            };

            function scale_call() {
              console.log('scale_call()');

              console.log('Weather city name');
              let weatherData = weatherSensor.getForecastWeather();
              normal_city_name_text.setProperty(hmUI.prop.TEXT, weatherData.cityName);

                console.log('update scales BATTERY');
                
                let valueBattery = battery.current;
                let targetBattery = 100;
                let progressBattery = valueBattery/targetBattery;
                if (progressBattery > 1) progressBattery = 1;
                let progress_cs_normal_battery = 1 - progressBattery;

                if (screenType != hmSetting.screen_type.AOD) {

                  // normal_battery_circle_scale_circle_scale
                  let level = Math.round(progress_cs_normal_battery * 100);
                  if (normal_battery_circle_scale) {
                    normal_battery_circle_scale.setProperty(hmUI.prop.MORE, {                      
                      center_x: 352,
                      center_y: 232,
                      start_angle: 93,
                      end_angle: -116,
                      radius: 57,
                      line_width: 31,
                      corner_flag: 3,
                      color: 0xFF000000,
                      show_level: hmUI.show_level.ONLY_NORMAL,
                      level: level,
                    });
                  };
                };

            };

            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                console.log('resume_call()');
                scale_call();
                time_update(true, true);
                text_update();
                if (screenType == hmSetting.screen_type.WATCHFACE) {
                  if (!normal_timerUpdateSec) {
                    let animDelay = timeSensor.utc % 1000;
                    let animRepeat = 1000;
                    normal_timerUpdateSec = timer.createTimer(animDelay, animRepeat, (function (option) {
                      time_update(false, false);
                    }));  // end timer 
                  };  // end timer check
                };  // end screenType

                if (screenType == hmSetting.screen_type.WATCHFACE) {
                  if (!normal_timerTextUpdate) {
                    normal_timerTextUpdate = timer.createTimer(0, 1000, (function (option) {
                      text_update();
                    }));  // end timer 
                  };  // end timer check
                };  // end screenType

                checkConnection();
                stopVibro();

              }),
              pause_call: (function () {
                console.log('pause_call()');
                if (normal_timerUpdateSec) {
                  timer.stopTimer(normal_timerUpdateSec);
                  normal_timerUpdateSec = undefined;
                }
                if (normal_timerTextUpdate) {
                  timer.stopTimer(normal_timerTextUpdate);
                  normal_timerTextUpdate = undefined;
                }
                stopVibro();

              }),
            });

                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}