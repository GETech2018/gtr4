﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.0.1
    ** Copyright © CashaCX75. All Rights Reserved
    */

    try {
    (()=>{
        //dynamic modify start

        let img = ''
        let prefix_img = 'fundo_'
        let img_index = '1'
        let img_count = '12'
        
        // let normal_background_bg_img = ''
        let normal_battery_icon_img = ''
        let normal_battery_text_text_img = ''
        let normal_step_circle_scale = ''
        let normal_step_current_text_img = ''
        let normal_analog_clock_time_pointer_hour = ''
        let normal_analog_clock_time_pointer_minute = ''
        let normal_analog_clock_time_pointer_second = ''
        let normal_digital_clock_img_time_AmPm = ''
        let normal_digital_clock_img_time = ''
        let normal_digital_clock_hour_separator_img = ''
        let normal_digital_clock_second_separator_img = ''
        let idle_background_bg = ''
        let idle_battery_icon_img = ''
        let idle_battery_text_text_img = ''
        let idle_step_circle_scale = ''
        let idle_step_current_text_img = ''
        let idle_analog_clock_time_pointer_hour = ''
        let idle_analog_clock_time_pointer_minute = ''
        let idle_analog_clock_time_pointer_second = ''
        let idle_digital_clock_img_time_AmPm = ''
        let idle_digital_clock_img_time = ''
        let idle_digital_clock_hour_separator_img = ''
        let idle_digital_clock_second_separator_img = ''


        //dynamic modify end
        const e = __$$hmAppManager$$__.currentApp;
        const o = e.current
          , {px: i} = (new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(e,o)),
        e.__globals__)
          , n = Logger.getLogger("watchface6");
        o.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            // normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
            //   x: 0,
            //   y: 0,
            //   w: 466,
            //   h: 466,
            //   src: 'fundo_1.png',
            //   show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 466,
              h: 466,
              src: prefix_img + parseInt(img_index) + '.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'BG.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 134,
              y: 255,
              font_array: ["10.png","11.png","12.png","13.png","14.png","15.png","16.png","17.png","18.png","19.png"],
              padding: false,
              h_space: 2,
              unit_sc: 'porc.png',
              unit_tc: 'porc.png',
              unit_en: 'porc.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_step_circle_scale = hmUI.createWidget(hmUI.widget.Circle_Scale, {
              // center_x: 233,
              // center_y: 233,
              // start_angle: 0,
              // end_angle: 360,
              // radius: 35,
              // line_width: 2,
              // color: 0xFFFFFFFF,
              // mirror: False,
              // inversion: False,
              // type: hmUI.data_type.STEP,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            let screenType = hmSetting.getScreenType();
            if (screenType != hmSetting.screen_type.AOD) {
              normal_step_circle_scale = hmUI.createWidget(hmUI.widget.ARC);
            };
            
            const step = hmSensor.createSensor(hmSensor.id.STEP);
            step.addEventListener(hmSensor.event.CHANGE, function() {
              scale_call();
            });

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 181,
              y: 308,
              font_array: ["00.png","01.png","02.png","03.png","04.png","05.png","06.png","07.png","08.png","09.png"],
              padding: false,
              h_space: 4,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_hour = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              hour_path: 'hr_1.png',
              hour_centerX: 233,
              hour_centerY: 233,
              hour_posX: 233,
              hour_posY: 233,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_minute = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              minute_path: 'min_1.png',
              minute_centerX: 233,
              minute_centerY: 233,
              minute_posX: 233,
              minute_posY: 233,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_analog_clock_time_pointer_second = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
            //   second_path: 'seg_1.png',
            //   second_centerX: 233,
            //   second_centerY: 233,
            //   second_posX: 233,
            //   second_posY: 233,
            //   show_level: hmUI.show_level.ONLY_NORMAL,
            // });

              // Smooth Seconds

    		let sec_pointer;
    		let clock_timer;

            // pos_x and pos_y and center values taken from above. The 8 and 223 frome above.
            // set PNG name here

            sec_pointer = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 466,
              h: 466,
              pos_x: 466 / 2 - 233,
              pos_y: 466 / 2 - 233,
              center_x: 233,
              center_y: 233,
              src: "seg_1.png",
              angle: 0,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            const now = hmSensor.createSensor(hmSensor .id.TIME);

            const vDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
                resume_call: (function () {
                    console.log('ui resume');

                    const animFps = 60;                 // Frames per second 
                    const animRepeat = 1000/animFps;    // execute every <animRepeat>ms
                    const animProgress = 6/animFps;
					let animAngle = 0;
                    let animDelay = 0;                   
					var sec = now.second;

                    if (animAngle == 0) {
                        var sec = now.second;
                        var startSec = sec*6;
                        sec_pointer.setProperty(hmUI.prop.ANGLE, startSec);
                    }

                    clock_timer = timer.createTimer(animDelay, animRepeat, (function(option) {
                            animAngle = animAngle + animProgress
                            sec_pointer.setProperty(hmUI.prop.ANGLE, startSec + animAngle);
                    }));
                }),
                pause_call: (function () {
                    console.log('ui pause');
					timer.stopTimer(clock_timer);
                }),
            });

            // End Smooth Seconds

            normal_digital_clock_img_time_AmPm = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              am_x: 124,
              am_y: 133,
              am_sc_path: 'am.png',
              am_en_path: 'am.png',
              pm_x: 126,
              pm_y: 133,
              pm_sc_path: 'pm.png',
              pm_en_path: 'pm.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 199,
              hour_startY: 133,
              hour_array: ["00.png","01.png","02.png","03.png","04.png","05.png","06.png","07.png","08.png","09.png"],
              hour_zero: 1,
              hour_space: 4,
              hour_align: hmUI.align.CENTER_H,

              minute_startX: 261,
              minute_startY: 133,
              minute_array: ["00.png","01.png","02.png","03.png","04.png","05.png","06.png","07.png","08.png","09.png"],
              minute_zero: 1,
              minute_space: 4,
              minute_follow: 0,
              minute_align: hmUI.align.CENTER_H,

              second_startX: 318,
              second_startY: 139,
              second_array: ["10.png","11.png","12.png","13.png","14.png","15.png","16.png","17.png","18.png","19.png"],
              second_zero: 1,
              second_space: 2,
              second_follow: 0,
              second_align: hmUI.align.CENTER_H,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_hour_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 249,
              y: 133,
              src: 'ponts.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_second_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 308,
              y: 139,
              src: 'ponts2.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            idle_background_bg = hmUI.createWidget(hmUI.widget.FILL_RECT, {
              x: 0,
              y: 0,
              w: 466,
              h: 466,
              color: '0xFF545629',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_battery_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'BG.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 134,
              y: 255,
              font_array: ["10.png","11.png","12.png","13.png","14.png","15.png","16.png","17.png","18.png","19.png"],
              padding: false,
              h_space: 2,
              unit_sc: 'porc.png',
              unit_tc: 'porc.png',
              unit_en: 'porc.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            // idle_step_circle_scale = hmUI.createWidget(hmUI.widget.Circle_Scale, {
              // center_x: 233,
              // center_y: 233,
              // start_angle: 0,
              // end_angle: 360,
              // radius: 35,
              // line_width: 2,
              // color: 0xFFFFFFFF,
              // mirror: False,
              // inversion: False,
              // type: hmUI.data_type.STEP,
              // show_level: hmUI.show_level.ONLY_AOD,
            // });

            
            if (screenType == hmSetting.screen_type.AOD) {
              idle_step_circle_scale = hmUI.createWidget(hmUI.widget.ARC);
            };

            idle_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 181,
              y: 308,
              font_array: ["00.png","01.png","02.png","03.png","04.png","05.png","06.png","07.png","08.png","09.png"],
              padding: false,
              h_space: 4,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_analog_clock_time_pointer_hour = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              hour_path: 'hr_2.png',
              hour_centerX: 233,
              hour_centerY: 233,
              hour_posX: 233,
              hour_posY: 233,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_analog_clock_time_pointer_minute = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              minute_path: 'min_2.png',
              minute_centerX: 233,
              minute_centerY: 233,
              minute_posX: 233,
              minute_posY: 233,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_analog_clock_time_pointer_second = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              second_path: 'seg_2.png',
              second_centerX: 233,
              second_centerY: 233,
              second_posX: 233,
              second_posY: 233,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time_AmPm = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              am_x: 124,
              am_y: 133,
              am_sc_path: 'am.png',
              am_en_path: 'am.png',
              pm_x: 126,
              pm_y: 133,
              pm_sc_path: 'pm.png',
              pm_en_path: 'pm.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 199,
              hour_startY: 133,
              hour_array: ["00.png","01.png","02.png","03.png","04.png","05.png","06.png","07.png","08.png","09.png"],
              hour_zero: 1,
              hour_space: 4,
              hour_align: hmUI.align.CENTER_H,

              minute_startX: 261,
              minute_startY: 133,
              minute_array: ["00.png","01.png","02.png","03.png","04.png","05.png","06.png","07.png","08.png","09.png"],
              minute_zero: 1,
              minute_space: 4,
              minute_follow: 0,
              minute_align: hmUI.align.CENTER_H,

              second_startX: 318,
              second_startY: 139,
              second_array: ["10.png","11.png","12.png","13.png","14.png","15.png","16.png","17.png","18.png","19.png"],
              second_zero: 1,
              second_space: 2,
              second_follow: 0,
              second_align: hmUI.align.CENTER_H,

              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_hour_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 249,
              y: 133,
              src: 'ponts.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_second_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 308,
              y: 139,
              src: 'ponts2.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            function scale_call() {

                console.log('update scales STEP');
                
                let valueStep = step.current;
                let targetStep = step.target;
                let progressStep = valueStep/targetStep;
                if (progressStep > 1) progressStep = 1;
                let progress_cs_normal_step = progressStep;

                if (screenType != hmSetting.screen_type.AOD) {

                  // normal_step_circle_scale
                  // initial parameters
                  let start_angle_normal_step = -90;
                  let end_angle_normal_step = 270;
                  let center_x_normal_step = 233;
                  let center_y_normal_step = 233;
                  let radius_normal_step = 35;
                  let line_width_cs_normal_step = 2;
                  let color_cs_normal_step = 0xFFFFFFFF;
                  
                  // calculated parameters
                  let arcX_normal_step = center_x_normal_step - radius_normal_step;
                  let arcY_normal_step = center_y_normal_step - radius_normal_step;
                  let CircleWidth_normal_step = 2 * radius_normal_step;
                  let angle_offset_normal_step = end_angle_normal_step - start_angle_normal_step;
                  angle_offset_normal_step = angle_offset_normal_step * progress_cs_normal_step;
                  let end_angle_normal_step_draw = start_angle_normal_step + angle_offset_normal_step;
                  
                  normal_step_circle_scale.setProperty(hmUI.prop.MORE, {
                    x: arcX_normal_step,
                    y: arcY_normal_step,
                    w: CircleWidth_normal_step,
                    h: CircleWidth_normal_step,
                    start_angle: start_angle_normal_step,
                    end_angle: end_angle_normal_step_draw,
                    color: color_cs_normal_step,
                    line_width: line_width_cs_normal_step,
                  });
                };

                console.log('update scales STEP');
                let progress_cs_idle_step = progressStep;

                if (screenType == hmSetting.screen_type.AOD) {

                  // idle_step_circle_scale
                  // initial parameters
                  let start_angle_idle_step = -90;
                  let end_angle_idle_step = 270;
                  let center_x_idle_step = 233;
                  let center_y_idle_step = 233;
                  let radius_idle_step = 35;
                  let line_width_cs_idle_step = 2;
                  let color_cs_idle_step = 0xFFFFFFFF;
                  
                  // calculated parameters
                  let arcX_idle_step = center_x_idle_step - radius_idle_step;
                  let arcY_idle_step = center_y_idle_step - radius_idle_step;
                  let CircleWidth_idle_step = 2 * radius_idle_step;
                  let angle_offset_idle_step = end_angle_idle_step - start_angle_idle_step;
                  angle_offset_idle_step = angle_offset_idle_step * progress_cs_idle_step;
                  let end_angle_idle_step_draw = start_angle_idle_step + angle_offset_idle_step;
                  
                  idle_step_circle_scale.setProperty(hmUI.prop.MORE, {
                    x: arcX_idle_step,
                    y: arcY_idle_step,
                    w: CircleWidth_idle_step,
                    h: CircleWidth_idle_step,
                    start_angle: start_angle_idle_step,
                    end_angle: end_angle_idle_step_draw,
                    color: color_cs_idle_step,
                    line_width: line_width_cs_idle_step,
                  });
                };

            };

            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                scale_call();
              }),
            });

            // Button to switch images. This block should be after all blocks with display elements.
            hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 100,  // x coordinate of the button
              y: 100,  // y coordinate of the button
              text: '',
              w: 280,  // button width
              h: 280,  // button height
              normal_src: 'transparent_img.png',  // transparent image
              press_src: 'transparent_img.png',  // transparent image
              show_level: hmUI.show_level.ONLY_NORMAL,
              click_func: () => {
                img_index++;
                if(img_index > img_count) img_index = 1;
                hmUI.showToast({text: 'COLOR ' + parseInt(img_index) });  // Remove if you do not want to display a message with the number of the selected image
                img.setProperty(hmUI.prop.SRC, prefix_img + parseInt(img_index) + '.png');
              }
            });

                //dynamic modify end
            },
            onInit() {
                n.log("index page.js on init invoke")
            },
            build() {
                this.init_view(),
                n.log("index page.js on ready invoke")
            },
            onDestroy() {
                n.log("index page.js on destroy invoke")
            }
        })
    }
    )()
} catch (e) {
    console.log("Mini Program Error", e),
    e && e.stack && e.stack.split(/\n/).forEach((e=>console.log("error stack", e)))
}
