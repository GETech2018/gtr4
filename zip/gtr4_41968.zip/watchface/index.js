﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (()=>{
        //dynamic modify start

        const lang = DeviceRuntimeCore.HmUtils.getLanguage()
        let normal_background_bg_img = ''
        let normal_system_disconnect_img = ''
        let normal_system_clock_img = ''
        let normal_distance_text_text_img = ''
        let normal_date_img_date_year = ''
        let normal_digital_clock_img_time = ''
        let normal_digital_clock_img_time_AmPm = ''
        let normal_weather_image_progress_img_level = ''
        let normal_temperature_current_text_img = ''
        let normal_date_img_date_week_img = ''
        let normal_date_img_date_day = ''
        let normal_date_img_date_month = ''
        let normal_step_image_progress_img_level = ''
        let normal_step_current_text_img = ''
        let normal_step_icon_img = ''
        let normal_calorie_image_progress_img_level = ''
        let normal_calorie_current_text_img = ''
        let normal_calorie_icon_img = ''
        let normal_pai_image_progress_img_level = ''
        let normal_pai_weekly_text_img = ''
        let normal_pai_icon_img = ''
        let normal_heart_rate_text_text_img = ''
        let normal_heart_rate_icon_img = ''
        let normal_battery_image_progress_img_level = ''
        let normal_battery_text_text_img = ''
        let normal_analog_clock_time_pointer_hour = ''
        let normal_analog_clock_time_pointer_minute = ''
        let normal_analog_clock_time_pointer_second = ''
        let idle_digital_clock_img_time = ''
        let normal_step_jumpable_img_click = ''
        let normal_cal_jumpable_img_click = ''
        let normal_heart_jumpable_img_click = ''
        let normal_pai_jumpable_img_click = ''
        let normal_battery_jumpable_img_click = ''
        let normal_temperature_jumpable_img_click = ''
        let normal_stand_jumpable_img_click = ''
        let normal_countdown_jumpable_img_click = ''
        let normal_stopwatch_jumpable_img_click = ''
        let Button_1 = ''
		
		let time=false
		let showarrow=true;
		let normal_showhide_arrow= '';


        //dynamic modify end
        const e = __$$hmAppManager$$__.currentApp;
        const o = e.current
          , {px: i} = (new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(e,o)),
        e.__globals__)
          , n = Logger.getLogger("watchface6");
        o.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            console.log('Watch_Face.ScreenNormal');
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 466,
              h: 466,
              src: 'bg.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 321,
              y: 382,
              src: 'bt.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 124,
              y: 382,
              src: 'alarms.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_distance_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 268,
              y: 325,
              font_array: ["14.png","15.png","16.png","17.png","18.png","19.png","20.png","21.png","22.png","23.png"],
              padding: false,
              h_space: 0,
              unit_sc: '102.png',
              unit_tc: '102.png',
              unit_en: '102.png',
              dot_image: '101.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.DISTANCE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_year = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              year_startX: 318,
              year_startY: 121,
              year_sc_array: ["64.png","65.png","66.png","67.png","68.png","69.png","70.png","71.png","72.png","73.png"],
              year_tc_array: ["64.png","65.png","66.png","67.png","68.png","69.png","70.png","71.png","72.png","73.png"],
              year_en_array: ["64.png","65.png","66.png","67.png","68.png","69.png","70.png","71.png","72.png","73.png"],
              year_zero: 0,
              year_space: -2,
              year_align: hmUI.align.LEFT,
              year_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 187,
              hour_startY: 73,
              hour_array: ["3.png","4.png","5.png","6.png","7.png","8.png","9.png","10.png","11.png","12.png"],
              hour_zero: 1,
              hour_space: 3,
              hour_angle: 0,
              hour_unit_sc: '13.png',
              hour_unit_tc: '13.png',
              hour_unit_en: '13.png',
              hour_align: hmUI.align.LEFT,

              minute_startX: 252,
              minute_startY: 73,
              minute_array: ["3.png","4.png","5.png","6.png","7.png","8.png","9.png","10.png","11.png","12.png"],
              minute_zero: 1,
              minute_space: 3,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              second_startX: 308,
              second_startY: 82,
              second_array: ["14.png","15.png","16.png","17.png","18.png","19.png","20.png","21.png","22.png","23.png"],
              second_zero: 1,
              second_space: 0,
              second_angle: 0,
              second_follow: 0,
              second_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time_AmPm = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              am_x: 212,
              am_y: 32,
              am_sc_path: '25.png',
              am_en_path: '25.png',
              pm_x: 212,
              pm_y: 32,
              pm_sc_path: '27.png',
              pm_en_path: '27.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 123,
              y: 66,
              image_array: ["28.png","29.png","30.png","31.png","32.png","33.png","34.png","35.png","36.png","37.png","38.png","39.png","40.png","41.png","42.png","43.png","44.png","45.png","46.png","47.png","48.png","49.png","50.png","51.png","52.png","53.png","54.png","55.png","56.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 127,
              y: 121,
              font_array: ["64.png","65.png","66.png","67.png","68.png","69.png","70.png","71.png","72.png","73.png"],
              padding: false,
              h_space: -1,
              unit_sc: '76.png',
              unit_tc: '76.png',
              unit_en: '76.png',
              negative_image: '75.png',
              invalid_image: '74.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
			
			let dned=["day_1.png","day_2.png","day_3.png","day_4.png","day_5.png","day_6.png","day_7.png"]
			if(lang=='ru-RU'){
				dned=["dayru_1.png","dayru_2.png","dayru_3.png","dayru_4.png","dayru_5.png","dayru_6.png","dayru_7.png"]
			}
            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 187,
              y: 120,
              week_en: dned,
              week_tc: ["day_1.png","day_2.png","day_3.png","day_4.png","day_5.png","day_6.png","day_7.png"],
              week_sc: ["day_1.png","day_2.png","day_3.png","day_4.png","day_5.png","day_6.png","day_7.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 240,
              day_startY: 121,
              day_sc_array: ["64.png","65.png","66.png","67.png","68.png","69.png","70.png","71.png","72.png","73.png"],
              day_tc_array: ["64.png","65.png","66.png","67.png","68.png","69.png","70.png","71.png","72.png","73.png"],
              day_en_array: ["64.png","65.png","66.png","67.png","68.png","69.png","70.png","71.png","72.png","73.png"],
              day_zero: 1,
              day_space: -2,
              day_unit_sc: 'sl.png',
              day_unit_tc: 'sl.png',
              day_unit_en: 'sl.png',
              day_align: hmUI.align.LEFT,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_month = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 279,
              month_startY: 121,
              month_sc_array: ["64.png","65.png","66.png","67.png","68.png","69.png","70.png","71.png","72.png","73.png"],
              month_tc_array: ["64.png","65.png","66.png","67.png","68.png","69.png","70.png","71.png","72.png","73.png"],
              month_en_array: ["64.png","65.png","66.png","67.png","68.png","69.png","70.png","71.png","72.png","73.png"],
              month_zero: 1,
              month_space: -2,
              month_unit_sc: 'sl.png',
              month_unit_tc: 'sl.png',
              month_unit_en: 'sl.png',
              month_align: hmUI.align.LEFT,
              month_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 258,
              y: 188,
              image_array: ["77.png","78.png","79.png","80.png","81.png","82.png","83.png"],
              image_length: 7,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 315,
              y: 156,
              font_array: ["14.png","15.png","16.png","17.png","18.png","19.png","20.png","21.png","22.png","23.png"],
              padding: false,
              h_space: -1,
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
			
			let dstep='step.png'
			if(lang=='ru-RU'){
				dstep='stepru.png'
			}
            normal_step_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 250,
              y: 156,
              src: dstep,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_calorie_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 258,
              y: 245,
              image_array: ["85.png","86.png","87.png","88.png","89.png","90.png","91.png"],
              image_length: 7,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_calorie_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 332,
              y: 212,
              font_array: ["14.png","15.png","16.png","17.png","18.png","19.png","20.png","21.png","22.png","23.png"],
              padding: false,
              h_space: -1,
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
			
			let dcal='cal.png'
			if(lang=='ru-RU'){
				dcal='calru.png'
			}
            normal_calorie_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 251,
              y: 212,
              src: dcal,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_pai_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 258,
              y: 301,
              image_array: ["93.png","94.png","95.png","96.png","97.png","98.png","99.png"],
              image_length: 7,
              type: hmUI.data_type.PAI_WEEKLY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_pai_weekly_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 348,
              y: 269,
              font_array: ["14.png","15.png","16.png","17.png","18.png","19.png","20.png","21.png","22.png","23.png"],
              padding: false,
              h_space: -1,
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.PAI_WEEKLY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
			
			let dpai='pai.png'
			if(lang=='ru-RU'){
				dpai='pairu.png'
			}
            normal_pai_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 255,
              y: 269,
              src: dpai,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 98,
              y: 216,
              font_array: ["14.png","15.png","16.png","17.png","18.png","19.png","20.png","21.png","22.png","23.png"],
              padding: false,
              h_space: -1,
              invalid_image: '104.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
			
			let dbpm='bpm.png'
			if(lang=='ru-RU'){
				dbpm='bpmru.png'
			}
            normal_heart_rate_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 89,
              y: 273,
              src: dbpm,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 167,
              y: 387,
              image_array: ["105.png","106.png","107.png","108.png","109.png","110.png","111.png","112.png","113.png","114.png"],
              image_length: 10,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 202,
              y: 383,
              font_array: ["14.png","15.png","16.png","17.png","18.png","19.png","20.png","21.png","22.png","23.png"],
              padding: false,
              h_space: -1,
              unit_sc: '115.png',
              unit_tc: '115.png',
              unit_en: '115.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_hour = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              hour_path: '116.png',
              hour_centerX: 233,
              hour_centerY: 233,
              hour_posX: 17,
              hour_posY: 141,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_minute = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              minute_path: '117.png',
              minute_centerX: 233,
              minute_centerY: 233,
              minute_posX: 17,
              minute_posY: 218,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_second = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              second_path: '118.png',
              second_centerX: 233,
              second_centerY: 233,
              second_posX: 16,
              second_posY: 217,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            console.log('Watch_Face.ScreenAOD');

            idle_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 133,
              hour_startY: 204,
              hour_array: ["119.png","120.png","121.png","122.png","123.png","124.png","125.png","126.png","127.png","128.png"],
              hour_zero: 1,
              hour_space: 1,
              hour_angle: 0,
              hour_unit_sc: '129.png',
              hour_unit_tc: '129.png',
              hour_unit_en: '129.png',
              hour_align: hmUI.align.LEFT,

              minute_startX: 246,
              minute_startY: 204,
              minute_array: ["119.png","120.png","121.png","122.png","123.png","124.png","125.png","126.png","127.png","128.png"],
              minute_zero: 1,
              minute_space: 1,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_AOD,
            });
            console.log('Watch_Face.Shortcuts');

            normal_step_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 305,
              y: 150,
              w: 100,
              h: 45,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_cal_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 305,
              y: 205,
              w: 100,
              h: 45,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 77,
              y: 190,
              w: 100,
              h: 100,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_pai_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 305,
              y: 260,
              w: 100,
              h: 45,
              type: hmUI.data_type.PAI_WEEKLY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 195,
              y: 365,
              w: 100,
              h: 60,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 116,
              y: 70,
              w: 60,
              h: 70,
              src: 'Empty.png',
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_showhide_arrow=hmUI.createWidget(hmUI.widget.BUTTON, {
				  x: 197,
				  y: 197,
				  w: 75,
				  h: 75,
				  text: '',
				  normal_src: 'Empty.png',
				  press_src: 'Empty.png',
				  click_func: (button_widget) => {
					showarrow=!showarrow;
					show_hide_arrow(showarrow);
				  },
				  show_level: hmUI.show_level.ONLY_NORMAL,
				});				
			
			function show_hide_arrow(vis){
				normal_analog_clock_time_pointer_hour.setProperty(hmUI.prop.VISIBLE, vis); 
				normal_analog_clock_time_pointer_minute.setProperty(hmUI.prop.VISIBLE, vis); 
				normal_analog_clock_time_pointer_second.setProperty(hmUI.prop.VISIBLE, vis); 				
			}

            normal_countdown_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 251,
              y: 75,
              w: 50,
              h: 35,
              type: hmUI.data_type.COUNT_DOWN,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_stopwatch_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 310,
              y: 60,
              w: 50,
              h: 50,
              type: hmUI.data_type.STOP_WATCH,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            console.log('Watch_Face.Buttons');
            Button_1 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 195,
              y: 116,
              w: 100,
              h: 40,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'Empty.png',
              normal_src: 'Empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'ScheduleCalScreen', native: true });
              }, // end func
              longpress_func: (button_widget) => {
                hmApp.startApp({url: 'todoListScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button


                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}