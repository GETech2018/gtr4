/*
** Facemaker bundle tool v0.0.3
* *huamiOS watchface js version v2.0.1
* *Copyright © Huami. All Rights Reserved
*/


try {
	(() => {
		var __$$app$$__ = __$$hmAppManager$$__.currentApp;
		var __$$module$$__ = __$$app$$__.current;

		//drink is a name,can modify
		var h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__), 'drink');

		'use strict';

		//dynamic modify start
		let normal_img0 = '';
		let normal_img1 = '';
		let normal_hour_rotary3 = '';
		let normal_minute_rotary4 = '';
		let normal_second_rotary5 = '';
		let normal_sleep_shortcut8 = '';
		let idle_hour_rotary10 = '';
		let idle_minute_rotary11 = '';
		let idle_img12 = '';
		//dynamic modify end

		//not required
		const logger = DeviceRuntimeCore.HmLogger.getLogger("yeguang");

		__$$module$$__.module = DeviceRuntimeCore.WatchFace({
			init_view() {

				let screenType = hmSetting.getScreenType();

				normal_img0 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 0,
					y: 0,
					w: 466,
					h: 466,
					src: '0002.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img1 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 96,
					y: 137,
					w: 359,
					h: 359,
					src: '0003.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_hour_rotary3 = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
					hour_path: '0004.png',
					hour_centerX: 235,
					hour_centerY: 233,
					hour_posX: 191,
					hour_posY: 192,
					hour_start_angle: 0,
					hour_end_angle: 360,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_minute_rotary4 = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
					minute_path: '0005.png',
					minute_centerX: 234,
					minute_centerY: 231,
					minute_posX: 167,
					minute_posY: 169,
					minute_start_angle: 0,
					minute_end_angle: 360,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_second_rotary5 = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
					second_path: '0006.png',
					second_centerX: 233,
					second_centerY: 232,
					second_posX: 233,
					second_posY: 232,
					second_start_angle: 0,
					second_end_angle: 360,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_sleep_shortcut8 = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
					x: 183,
					y: 183,
					w: 100,
					h: 100,
					src: '',
					type: hmUI.data_type.SLEEP,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				idle_hour_rotary10 = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
					hour_path: '0007.png',
					hour_centerX: 233,
					hour_centerY: 233,
					hour_posX: 233,
					hour_posY: 233,
					hour_start_angle: 0,
					hour_end_angle: 360,
					show_level: hmUI.show_level.ONAL_AOD,
				});

				idle_minute_rotary11 = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
					minute_path: '0007.png',
					minute_centerX: 233,
					minute_centerY: 233,
					minute_posX: 233,
					minute_posY: 233,
					minute_start_angle: 0,
					minute_end_angle: 360,
					show_level: hmUI.show_level.ONAL_AOD,
				});

				idle_img12 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 118,
					y: 150,
					w: 314,
					h: 314,
					src: '0008.png',
					enable: false,
					show_level: hmUI.show_level.ONAL_AOD,
				});

			},

		onInit() {
			console.log('index page.js on init invoke')
			this.init_view()
		},
		onReady() {
			console.log('index page.js on ready invoke')
		},
		onShow() {
			console.log('index page.js on show invoke')
		},
		onHide() {
			console.log('index page.js on hide invoke')
		},
		onDestroy() {
			console.log('index page.js on destroy invoke')
		},
	});	})()
} catch (e) {
	console.log(e)
}