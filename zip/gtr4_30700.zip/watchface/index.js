﻿
    /*
    ** Watch_Face_Editor tool
    ** watchface js version v1.0.1
    ** Copyright © CashaCX75. All Rights Reserved
    */

    try {

      (() => {

        var __$$app$$__ = __$$hmAppManager$$__.currentApp;
        var __$$module$$__ = __$$app$$__.current;
        //drink is a name,can modify
        var h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__), 'drink');

        'use strict';

        //dynamic modify start
      
        let normal_background_bg = ''
    let img = ''
	  let prefix_img = 'hr_'
	  let img_index = '1'
	  let img_count = '9'
        let normal_analog_clock_time_pointer_minute = ''
        let normal_analog_clock_time_pointer_hour = ''
        let normal_analog_clock_time_pointer_second = ''
        let idle_background_bg = ''
        let idle_analog_clock_time_pointer_hour = ''
        let idle_analog_clock_time_pointer_minute = ''
        let idle_analog_clock_time_pointer_second = ''


        //dynamic modify end

        //not required
        const logger = DeviceRuntimeCore.HmLogger.getLogger("yeguang");

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({

          init_view() {

            //dynamic modify start
              
            // normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
            //   x: 0,
            //   y: 0,
            //   w: 466,
            //   h: 466,
            //   src: 'fundo.png',
            //   show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            img1 = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: -78,
              hour_startY: 4,
              hour_zero: 0,
              hour_space: -313,
              hour_align: hmUI.align.CENTER_H,
              show_level: hmUI.show_level.ONLY_NORMAL,
              hour_array: ["hr_0.png","hr_1.png","hr_2.png","hr_3.png","hr_4.png","hr_5.png","hr_6.png","hr_7.png","hr_8.png","hr_9.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            img2 = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: -78,
              hour_startY: 4,
              hour_zero: 0,
              hour_space: -313,
              hour_align: hmUI.align.CENTER_H,
              show_level: hmUI.show_level.ONLY_NORMAL,
              hour_array: ["hr_10.png","hr_11.png","hr_12.png","hr_13.png","hr_14.png","hr_15.png","hr_16.png","hr_17.png","hr_18.png","hr_19.png"],
            });

            img3 = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: -78,
              hour_startY: 4,
              hour_zero: 0,
              hour_space: -313,
              hour_align: hmUI.align.CENTER_H,
              show_level: hmUI.show_level.ONLY_NORMAL,
              hour_array: ["hr_20.png","hr_21.png","hr_22.png","hr_23.png","hr_24.png","hr_25.png","hr_26.png","hr_27.png","hr_28.png","hr_29.png"],
            });

            img4 = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: -78,
              hour_startY: 4,
              hour_zero: 0,
              hour_space: -313,
              hour_align: hmUI.align.CENTER_H,
              show_level: hmUI.show_level.ONLY_NORMAL,
              hour_array: ["hr_30.png","hr_31.png","hr_32.png","hr_33.png","hr_34.png","hr_35.png","hr_36.png","hr_37.png","hr_38.png","hr_39.png"],
            });

            img5 = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: -78,
              hour_startY: 4,
              hour_zero: 0,
              hour_space: -313,
              hour_align: hmUI.align.CENTER_H,
              show_level: hmUI.show_level.ONLY_NORMAL,
              hour_array: ["hr_40.png","hr_41.png","hr_42.png","hr_43.png","hr_44.png","hr_45.png","hr_46.png","hr_47.png","hr_48.png","hr_49.png"],
            });

            img6 = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: -78,
              hour_startY: 4,
              hour_zero: 0,
              hour_space: -313,
              hour_align: hmUI.align.CENTER_H,
              show_level: hmUI.show_level.ONLY_NORMAL,
              hour_array: ["hr_50.png","hr_51.png","hr_52.png","hr_53.png","hr_54.png","hr_55.png","hr_56.png","hr_57.png","hr_58.png","hr_59.png"],
            });

            img7 = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: -78,
              hour_startY: 4,
              hour_zero: 0,
              hour_space: -313,
              hour_align: hmUI.align.CENTER_H,
              show_level: hmUI.show_level.ONLY_NORMAL,
              hour_array: ["hr_60.png","hr_61.png","hr_62.png","hr_63.png","hr_64.png","hr_65.png","hr_66.png","hr_67.png","hr_68.png","hr_69.png"],
            });

            img8 = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: -78,
              hour_startY: 4,
              hour_zero: 0,
              hour_space: -313,
              hour_align: hmUI.align.CENTER_H,
              show_level: hmUI.show_level.ONLY_NORMAL,
              hour_array: ["hr_70.png","hr_71.png","hr_72.png","hr_73.png","hr_74.png","hr_75.png","hr_76.png","hr_77.png","hr_78.png","hr_79.png"],
            });

            img9 = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: -78,
              hour_startY: 4,
              hour_zero: 0,
              hour_space: -313,
              hour_align: hmUI.align.CENTER_H,
              show_level: hmUI.show_level.ONLY_NORMAL,
              hour_array: ["hr_80.png","hr_81.png","hr_82.png","hr_83.png","hr_84.png","hr_85.png","hr_86.png","hr_87.png","hr_88.png","hr_89.png"],
            });

            // im10 = hmUI.createWidget(hmUI.widget.IMG_TIME, {
            //   hour_startX: -78,
            //   hour_startY: 4,
            //   hour_zero: 0,
            //   hour_space: -313,
            //   hour_align: hmUI.align.CENTER_H,
            //   show_level: hmUI.show_level.ONLY_NORMAL,
            //   hour_array: ["hr_90.png","hr_91.png","hr_92.png","hr_93.png","hr_94.png","hr_95.png","hr_96.png","hr_97.png","hr_98.png","hr_99.png"],
            // });

            // img11 = hmUI.createWidget(hmUI.widget.IMG_TIME, {
            //   hour_startX: -78,
            //   hour_startY: 4,
            //   hour_zero: 0,
            //   hour_space: -313,
            //   hour_align: hmUI.align.CENTER_H,
            //   show_level: hmUI.show_level.ONLY_NORMAL,
            //   hour_array: ["hr_100.png","hr_101.png","hr_102.png","hr_103.png","hr_104.png","hr_105.png","hr_106.png","hr_107.png","hr_108.png","hr_109.png"],
            // });

            normal_analog_clock_time_pointer_minute = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              minute_path: 'min.png',
              minute_centerX: 233,
              minute_centerY: 233,
              minute_posX: 233,
              minute_posY: 233,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_hour = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              hour_path: 'hr.png',
              hour_centerX: 233,
              hour_centerY: 233,
              hour_posX: 233,
              hour_posY: 233,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // Smooth Seconds

    		let sec_pointer;
    		let clock_timer;

            // pos_x and pos_y and center values taken from above. The 8 and 223 frome above.
            // set PNG name here

            sec_pointer = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 466,
              h: 466,
              pos_x: 466 / 2 - 233,
              pos_y: 466 / 2 - 233,
              center_x: 233,
              center_y: 233,
              src: "seg.png",
              angle: 0,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            const now = hmSensor.createSensor(hmSensor .id.TIME);

            const vDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
                resume_call: (function () {
                    console.log('ui resume');

                    const animFps = 60;                 // Frames per second 
                    const animRepeat = 1000/animFps;    // execute every <animRepeat>ms
                    const animProgress = 6/animFps;
					let animAngle = 0;
                    let animDelay = 0;                   
					var sec = now.second;

                    if (animAngle == 0) {
                        var sec = now.second;
                        var startSec = sec*6;
                        sec_pointer.setProperty(hmUI.prop.ANGLE, startSec);
                    }

                    clock_timer = timer.createTimer(animDelay, animRepeat, (function(option) {
                            animAngle = animAngle + animProgress
                            sec_pointer.setProperty(hmUI.prop.ANGLE, startSec + animAngle);
                    }));
                }),
                pause_call: (function () {
                    console.log('ui pause');
					timer.stopTimer(clock_timer);
                }),
            });

            // End Smooth Seconds

            idle_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 466,
              h: 466,
              src: 'fundo.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });
         
            idle_analog_clock_time_pointer_hour = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              hour_path: 'hr.png',
              hour_centerX: 233,
              hour_centerY: 233,
              hour_posX: 233,
              hour_posY: 233,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_analog_clock_time_pointer_minute = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              minute_path: 'min.png',
              minute_centerX: 233,
              minute_centerY: 233,
              minute_posX: 233,
              minute_posY: 233,
              show_level: hmUI.show_level.ONLY_AOD,
            });

           // Button to switch elements. This block should be after all blocks with display elements.
            function click_btn() {
              img_index++;
              if(img_index > img_count) img_index = 1;

              img1.setProperty(hmUI.prop.VISIBLE, img_index == 1);
              img2.setProperty(hmUI.prop.VISIBLE, img_index == 2);
              img3.setProperty(hmUI.prop.VISIBLE, img_index == 3);
              img4.setProperty(hmUI.prop.VISIBLE, img_index == 4);
              img5.setProperty(hmUI.prop.VISIBLE, img_index == 5);
              img6.setProperty(hmUI.prop.VISIBLE, img_index == 6);
              img7.setProperty(hmUI.prop.VISIBLE, img_index == 7);
              img8.setProperty(hmUI.prop.VISIBLE, img_index == 8);
              img9.setProperty(hmUI.prop.VISIBLE, img_index == 9);
              // img10.setProperty(hmUI.prop.VISIBLE, img_index == 10);
              // img11.setProperty(hmUI.prop.VISIBLE, img_index == 11);

            }

           hmUI.createWidget(hmUI.widget.BUTTON, {
            x: 100,  // x coordinate of the button
            y: 100,  // y coordinate of the button
            text: '',
            w: 280,  // button width
            h: 280,  // button height
            normal_src: 'transparent_img.png',  // transparent image
            press_src: 'transparent_img.png',  // transparent image
            show_level: hmUI.show_level.ONLY_NORMAL,
            click_func: () => {
             
              click_btn();
            }
          });

            //dynamic modify end
          },

          onInit() {
            console.log('index page.js on init invoke')

            this.init_view()

          },

          onReady() {
            console.log('index page.js on ready invoke')
          },

          onShow() {
            console.log('index page.js on show invoke')
          },

          onHide() {
            console.log('index page.js on hide invoke')
          },

          onDestory() {
            console.log('index page.js on destory invoke')
          },
        });

      })()
    } catch (e) {
      console.log(e)
    }
  