    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        const logger = Logger.getLogger('watchface_SashaCX75');
        //end of ignored block

        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_date_img_date_month = ''
        let normal_date_img_date_day = ''
        let normal_date_img_date_week_img = ''
        let normal_digital_clock_img_time = ''
        let normal_digital_clock_img_time_AmPm = ''
        let normal_system_disconnect_img = ''
        let normal_system_dnd_img = ''
        let normal_system_lock_img = ''
        let normal_system_clock_img = ''
		let normal_calorie_jumpable_img_click = ''
        let idle_digital_clock_img_time = ''
        let idle_digital_clock_hour_separator_img = ''
        let idle_digital_clock_img_time_AmPm = ''
        let editGroup_1  = ''
        let editGroup_2  = ''
        let Button_1 = ''
        let Button_2 = ''
        let Button_3 = ''
        let Button_4 = ''
        let Button_5 = ''
        let Button_6 = ''
        let Button_7 = ''
        let Button_8 = ''
        let Button_9 = ''
        let Button_10 = ''
        let Button_11 = ''
        let Button_12 = ''
        let Button_13 = ''


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            console.log('Watch_Face.ScreenNormal');
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 466,
              h: 466,
              src: '2.png',
              show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_EDIT,
            });

            normal_date_img_date_month = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 247,
              month_startY: 159,
              month_sc_array: ["17.png","18.png","19.png","20.png","21.png","22.png","23.png","24.png","25.png","26.png"],
              month_tc_array: ["17.png","18.png","19.png","20.png","21.png","22.png","23.png","24.png","25.png","26.png"],
              month_en_array: ["17.png","18.png","19.png","20.png","21.png","22.png","23.png","24.png","25.png","26.png"],
              month_zero: 1,
              month_space: 0,
              month_align: hmUI.align.LEFT,
              month_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 184,
              day_startY: 159,
              day_sc_array: ["17.png","18.png","19.png","20.png","21.png","22.png","23.png","24.png","25.png","26.png"],
              day_tc_array: ["17.png","18.png","19.png","20.png","21.png","22.png","23.png","24.png","25.png","26.png"],
              day_en_array: ["17.png","18.png","19.png","20.png","21.png","22.png","23.png","24.png","25.png","26.png"],
              day_zero: 1,
              day_space: 0,
              day_align: hmUI.align.LEFT,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 96,
              y: 158,
              week_en: ["3.png","4.png","5.png","6.png","7.png","8.png","9.png"],
              week_tc: ["3.png","4.png","5.png","6.png","7.png","8.png","9.png"],
              week_sc: ["3.png","4.png","5.png","6.png","7.png","8.png","9.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 105,
              hour_startY: 198,
              hour_array: ["54.png","55.png","56.png","57.png","58.png","59.png","60.png","61.png","62.png","63.png"],
              hour_zero: 1,
              hour_space: 0,
              hour_angle: 0,
              hour_align: hmUI.align.CENTER_H,

              minute_startX: 249,
              minute_startY: 198,
              minute_array: ["54.png","55.png","56.png","57.png","58.png","59.png","60.png","61.png","62.png","63.png"],
              minute_zero: 1,
              minute_space: 0,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.CENTER_H,

              second_startX: 301,
              second_startY: 141,
              second_array: ["64.png","65.png","66.png","67.png","68.png","69.png","70.png","71.png","72.png","73.png"],
              second_zero: 1,
              second_space: 0,
              second_angle: 0,
              second_follow: 0,
              second_align: hmUI.align.CENTER_H,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time_AmPm = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              am_x: 310,
              am_y: 292,
              am_sc_path: '74.png',
              am_en_path: '74.png',
              pm_x: 310,
              pm_y: 292,
              pm_sc_path: '75.png',
              pm_en_path: '75.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 344,
              y: 47,
              src: '76.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_dnd_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 47,
              y: 55,
              src: '77.png',
              type: hmUI.system_status.DISTURB,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_lock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 351,
              y: 360,
              src: '78.png',
              type: hmUI.system_status.LOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 47,
              y: 348,
              src: '79.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            console.log('Watch_Face.ScreenAOD');

            idle_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 105,
              hour_startY: 198,
              hour_array: ["81.png","82.png","83.png","84.png","85.png","86.png","87.png","88.png","89.png","90.png"],
              hour_zero: 1,
              hour_space: 0,
              hour_angle: 0,
              hour_align: hmUI.align.CENTER_H,

              minute_startX: 251,
              minute_startY: 198,
              minute_array: ["91.png","92.png","93.png","94.png","95.png","96.png","97.png","98.png","99.png","100.png"],
              minute_zero: 1,
              minute_space: 0,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.CENTER_H,

              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_hour_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 224,
              y: 206,
              src: '80.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time_AmPm = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              am_x: 310,
              am_y: 292,
              am_sc_path: '101.png',
              am_en_path: '101.png',
              pm_x: 310,
              pm_y: 292,
              pm_sc_path: '102.png',
              pm_en_path: '102.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });
            console.log('Watch_Face.Editable_Elements');

            editGroup_1 = hmUI.createWidget(hmUI.widget.WATCHFACE_EDIT_GROUP, {
              edit_id: 10021,
              x: 92,
              y: 288,
              w: 109,
              h: 40,
              select_image: 'op0.png',
              un_select_image: 'op1.png',
              default_type: hmUI.edit_type.STEP,
              optional_types: [
                { type: hmUI.edit_type.STEP, preview: 'ez(1)_STEP.png' },
                { type: hmUI.edit_type.CAL, preview: 'ez(1)_CAL.png' },
                { type: hmUI.edit_type.HEART, preview: 'ez(1)_HEART.png' },
                { type: hmUI.edit_type.BATTERY, preview: 'ez(1)_BATTERY.png' },
                { type: hmUI.edit_type.WEATHER, preview: 'ez(1)_WEATHER.png' },
              ],
              count: 5,
              select_list: {
                title_font_size: 34,
                title_align_h: hmUI.align.CENTER_H,
                list_item_vspace: 8,
                list_tips_text_font_size: 32,
                list_tips_text_align_h: hmUI.align.LEFT
              },
              tips_BG: '.png',
              tips_x: 2,
              tips_y: 37,
              tips_width: 0,
              tips_margin: 0,
            });

            const editType_1 = editGroup_1.getProperty(hmUI.prop.CURRENT_TYPE);

            switch (editType_1) {
              case hmUI.edit_type.BATTERY:
                hmUI.createWidget(hmUI.widget.IMG, {
                  x: 126,
                  y: 287,
                  src: 'wbg3.png',
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });

                hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
                  x: 92,
                  y: 295,
                  image_array: ["49.png","50.png","51.png","52.png","53.png"],
                  image_length: 5,
                  type: hmUI.data_type.BATTERY,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });

                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                  x: 146,
                  y: 296,
                  font_array: ["27.png","28.png","29.png","30.png","31.png","32.png","33.png","34.png","35.png","36.png"],
                  padding: false,
                  h_space: 0,
                  unit_sc: '104.png',
                  unit_tc: '104.png',
                  unit_en: '104.png',
                  align_h: hmUI.align.RIGHT,
                  type: hmUI.data_type.BATTERY,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });
					
				Button_6 = hmUI.createWidget(hmUI.widget.BUTTON, {
	              x: 91,
	              y: 289,
	              w: 112,
	              h: 40,
	              text: '',
	              color: 0xFFFF8C00,
	              text_size: 25,
	              press_src: 'null.png',
	              normal_src: 'null.png',
	              click_func: (button_widget) => {
	                hmApp.startApp({url: 'Settings_batteryManagerScreen', native: true });
					vibro(25);
	              }, // end func
	              show_level: hmUI.show_level.ONLY_NORMAL,
	            }); // end button
                break;

              case hmUI.edit_type.STEP:
                hmUI.createWidget(hmUI.widget.IMG, {
                  x: 87,
                  y: 287,
                  src: 'wbg2.png',
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });

                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                  x: 129,
                  y: 297,
                  font_array: ["27.png","28.png","29.png","30.png","31.png","32.png","33.png","34.png","35.png","36.png"],
                  padding: false,
                  h_space: 0,
                  align_h: hmUI.align.RIGHT,
                  type: hmUI.data_type.STEP,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });
					
				Button_8 = hmUI.createWidget(hmUI.widget.BUTTON, {
	              x: 91,
	              y: 289,
	              w: 112,
	              h: 40,
	              text: '',
	              color: 0xFFFF8C00,
	              text_size: 25,
	              press_src: 'null.png',
	              normal_src: 'null.png',
	              click_func: (button_widget) => {
	                hmApp.startApp({url: 'activityAppScreen', native: true });
					vibro(25);
	              }, // end func
	              show_level: hmUI.show_level.ONLY_NORMAL,
	            }); // end button
                break;

              case hmUI.edit_type.CAL:
                hmUI.createWidget(hmUI.widget.IMG, {
                  x: 123,
                  y: 287,
                  src: 'wbg3.png',
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });

                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                  x: 143,
                  y: 297,
                  font_array: ["27.png","28.png","29.png","30.png","31.png","32.png","33.png","34.png","35.png","36.png"],
                  padding: false,
                  h_space: 0,
                  align_h: hmUI.align.RIGHT,
                  type: hmUI.data_type.CAL,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });

                hmUI.createWidget(hmUI.widget.IMG, {
                  x: 97,
                  y: 294,
                  src: '110.png',
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });
					
				normal_calorie_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
	              x: 91,
	              y: 289,
	              w: 112,
	              h: 40,
	              type: hmUI.data_type.CAL,
	              show_level: hmUI.show_level.ONLY_NORMAL,
	            });
                break;

              case hmUI.edit_type.HEART:
                hmUI.createWidget(hmUI.widget.IMG, {
                  x: 123,
                  y: 287,
                  src: 'wbg3.png',
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });

                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                  x: 156,
                  y: 297,
                  font_array: ["27.png","28.png","29.png","30.png","31.png","32.png","33.png","34.png","35.png","36.png"],
                  padding: true,
                  h_space: 0,
                  align_h: hmUI.align.RIGHT,
                  type: hmUI.data_type.HEART,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });

                hmUI.createWidget(hmUI.widget.IMG, {
                  x: 92,
                  y: 295,
                  src: '106.png',
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });
					
				Button_7 = hmUI.createWidget(hmUI.widget.BUTTON, {
	              x: 91,
	              y: 289,
	              w: 112,
	              h: 40,
	              text: '',
	              color: 0xFFFF8C00,
	              text_size: 25,
	              press_src: 'null.png',
	              normal_src: 'null.png',
	              click_func: (button_widget) => {
	                hmApp.startApp({url: 'heart_app_Screen', native: true });
					vibro(25);
	              }, // end func
	              show_level: hmUI.show_level.ONLY_NORMAL,
	            }); // end button
                break;

              case hmUI.edit_type.WEATHER:
                hmUI.createWidget(hmUI.widget.IMG, {
                  x: 123,
                  y: 287,
                  src: 'wbg3.png',
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });

                hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
                  x: 88,
                  y: 288,
                  image_array: ["w00.png","w01.png","w02.png","w03.png","w04.png","w05.png","w06.png","w07.png","w08.png","w09.png","w10.png","w11.png","w12.png","w13.png","w14.png","w15.png","w16.png","w17.png","w18.png","w19.png","w20.png","w21.png","w22.png","w23.png","w24.png","w25.png","w26.png","w27.png","w28.png"],
                  image_length: 29,
                  type: hmUI.data_type.WEATHER_CURRENT,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });

                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                  x: 141,
                  y: 297,
                  font_array: ["27.png","28.png","29.png","30.png","31.png","32.png","33.png","34.png","35.png","36.png"],
                  padding: false,
                  h_space: 0,
                  unit_sc: '112.png',
                  unit_tc: '112.png',
                  unit_en: '112.png',
                  negative_image: '111.png',
                  invalid_image: '37.png',
                  align_h: hmUI.align.RIGHT,
                  type: hmUI.data_type.WEATHER_CURRENT,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });
					
				Button_5 = hmUI.createWidget(hmUI.widget.BUTTON, {
	              x: 91,
	              y: 289,
	              w: 112,
	              h: 40,
	              text: '',
	              color: 0xFFFF8C00,
	              text_size: 25,
	              press_src: 'null.png',
	              normal_src: 'null.png',
	              click_func: (button_widget) => {
	                hmApp.startApp({url: 'WeatherScreen', native: true });
					vibro(25);
	              }, // end func
	              show_level: hmUI.show_level.ONLY_NORMAL,
	            }); // end button
                break;
            }; // end switch

            editGroup_2 = hmUI.createWidget(hmUI.widget.WATCHFACE_EDIT_GROUP, {
              edit_id: 10022,
              x: 204,
              y: 288,
              w: 105,
              h: 40,
              select_image: 'op0.png',
              un_select_image: 'op1.png',
              default_type: hmUI.edit_type.BATTERY,
              optional_types: [
                { type: hmUI.edit_type.BATTERY, preview: 'ez(2)_BATTERY.png' },
                { type: hmUI.edit_type.HEART, preview: 'ez(2)_HEART.png' },
                { type: hmUI.edit_type.CAL, preview: 'ez(2)_CAL.png' },
                { type: hmUI.edit_type.STEP, preview: 'ez(2)_STEP.png' },
                { type: hmUI.edit_type.WEATHER, preview: 'ez(2)_WEATHER.png' },
              ],
              count: 5,
              select_list: {
                title_font_size: 34,
                title_align_h: hmUI.align.CENTER_H,
                list_item_vspace: 8,
                list_tips_text_font_size: 32,
                list_tips_text_align_h: hmUI.align.LEFT
              },
              tips_BG: '.png',
              tips_x: 105,
              tips_y: 36,
              tips_width: 0,
              tips_margin: 0,
            });

            const editType_2 = editGroup_2.getProperty(hmUI.prop.CURRENT_TYPE);

            switch (editType_2) {
              case hmUI.edit_type.BATTERY:
                hmUI.createWidget(hmUI.widget.IMG, {
                  x: 245,
                  y: 295,
                  src: 'wbg4.png',
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });

                hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
                  x: 206,
                  y: 297,
                  image_array: ["49.png","50.png","51.png","52.png","53.png"],
                  image_length: 5,
                  type: hmUI.data_type.BATTERY,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });

                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                  x: 259,
                  y: 299,
                  font_array: ["38.png","39.png","40.png","41.png","42.png","43.png","44.png","45.png","46.png","47.png"],
                  padding: false,
                  h_space: 0,
                  unit_sc: '48.png',
                  unit_tc: '48.png',
                  unit_en: '48.png',
                  align_h: hmUI.align.RIGHT,
                  type: hmUI.data_type.BATTERY,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });
					
				Button_4 = hmUI.createWidget(hmUI.widget.BUTTON, {
	              x: 206,
	              y: 289,
	              w: 102,
	              h: 40,
	              text: '',
	              color: 0xFFFF8C00,
	              text_size: 25,
	              press_src: 'null.png',
	              normal_src: 'null.png',
	              click_func: (button_widget) => {
	                hmApp.startApp({url: 'Settings_batteryManagerScreen', native: true });
					vibro(25);
	              }, // end func
	              show_level: hmUI.show_level.ONLY_NORMAL,
	            }); // end button
                break;

              case hmUI.edit_type.STEP:
                hmUI.createWidget(hmUI.widget.IMG, {
                  x: 245,
                  y: 295,
                  src: 'wbg4.png',
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });

                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                  x: 248,
                  y: 299,
                  font_array: ["38.png","39.png","40.png","41.png","42.png","43.png","44.png","45.png","46.png","47.png"],
                  padding: false,
                  h_space: 0,
                  align_h: hmUI.align.RIGHT,
                  type: hmUI.data_type.STEP,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });

                hmUI.createWidget(hmUI.widget.IMG, {
                  x: 213,
                  y: 288,
                  src: '109.png',
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });
					
				Button_2 = hmUI.createWidget(hmUI.widget.BUTTON, {
	              x: 206,
	              y: 289,
	              w: 102,
	              h: 40,
	              text: '',
	              color: 0xFFFF8C00,
	              text_size: 25,
	              press_src: 'null.png',
	              normal_src: 'null.png',
	              click_func: (button_widget) => {
	                hmApp.startApp({url: 'activityAppScreen', native: true });
					vibro(25);
	              }, // end func
	              show_level: hmUI.show_level.ONLY_NORMAL,
	            }); // end button
                break;

              case hmUI.edit_type.CAL:
                hmUI.createWidget(hmUI.widget.IMG, {
                  x: 245,
                  y: 295,
                  src: 'wbg4.png',
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });

                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                  x: 259,
                  y: 299,
                  font_array: ["38.png","39.png","40.png","41.png","42.png","43.png","44.png","45.png","46.png","47.png"],
                  padding: true,
                  h_space: 0,
                  align_h: hmUI.align.RIGHT,
                  type: hmUI.data_type.CAL,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });

                hmUI.createWidget(hmUI.widget.IMG, {
                  x: 213,
                  y: 294,
                  src: '110.png',
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });
					
				normal_calorie_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
	              x: 206,
	              y: 289,
	              w: 102,
	              h: 40,
	              type: hmUI.data_type.CAL,
	              show_level: hmUI.show_level.ONLY_NORMAL,
	            });
                break;

              case hmUI.edit_type.HEART:
                hmUI.createWidget(hmUI.widget.IMG, {
                  x: 245,
                  y: 295,
                  src: 'wbg4.png',
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });

                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                  x: 271,
                  y: 299,
                  font_array: ["38.png","39.png","40.png","41.png","42.png","43.png","44.png","45.png","46.png","47.png"],
                  padding: true,
                  h_space: 0,
                  align_h: hmUI.align.RIGHT,
                  type: hmUI.data_type.HEART,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });

                hmUI.createWidget(hmUI.widget.IMG, {
                  x: 213,
                  y: 295,
                  src: '106.png',
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });
					
				Button_3 = hmUI.createWidget(hmUI.widget.BUTTON, {
	              x: 206,
	              y: 289,
	              w: 102,
	              h: 40,
	              text: '',
	              color: 0xFFFF8C00,
	              text_size: 25,
	              press_src: 'null.png',
	              normal_src: 'null.png',
	              click_func: (button_widget) => {
	                hmApp.startApp({url: 'heart_app_Screen', native: true });
					vibro(25);
	              }, // end func
	              show_level: hmUI.show_level.ONLY_NORMAL,
	            }); // end button
                break;

              case hmUI.edit_type.WEATHER:
                hmUI.createWidget(hmUI.widget.IMG, {
                  x: 245,
                  y: 295,
                  src: 'wbg4.png',
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });

                hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
                  x: 209,
                  y: 288,
                  image_array: ["w00.png","w01.png","w02.png","w03.png","w04.png","w05.png","w06.png","w07.png","w08.png","w09.png","w10.png","w11.png","w12.png","w13.png","w14.png","w15.png","w16.png","w17.png","w18.png","w19.png","w20.png","w21.png","w22.png","w23.png","w24.png","w25.png","w26.png","w27.png","w28.png"],
                  image_length: 29,
                  type: hmUI.data_type.WEATHER_CURRENT,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });

                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                  x: 258,
                  y: 299,
                  font_array: ["38.png","39.png","40.png","41.png","42.png","43.png","44.png","45.png","46.png","47.png"],
                  padding: false,
                  h_space: 0,
                  unit_sc: '105.png',
                  unit_tc: '105.png',
                  unit_en: '105.png',
                  negative_image: '103.png',
                  invalid_image: '37.png',
                  align_h: hmUI.align.RIGHT,
                  type: hmUI.data_type.WEATHER_CURRENT,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });
				Button_1 = hmUI.createWidget(hmUI.widget.BUTTON, {
	              x: 206,
	              y: 289,
	              w: 102,
	              h: 40,
	              text: '',
	              color: 0xFFFF8C00,
	              text_size: 25,
	              press_src: 'null.png',
	              normal_src: 'null.png',
	              click_func: (button_widget) => {
	                hmApp.startApp({url: 'WeatherScreen', native: true });
					vibro(25);
	              }, // end func
	              show_level: hmUI.show_level.ONLY_NORMAL,
	            }); // end button
	                break;
	            }; // end switch
			
// vibrate function

            const vibrate = hmSensor.createSensor(hmSensor.id.VIBRATE);
            let timer_StopVibrate = null;

            function vibro(scene = 25) {
              let stopDelay = 50;
              stopVibro();
              vibrate.stop();
              vibrate.scene = scene;
              if(scene < 23 || scene > 25) stopDelay = 1300;
              vibrate.start();
              if (scene != 1) timer_StopVibrate = timer.createTimer(stopDelay, 3000, stopVibro, {});
            }

            function stopVibro(){
              vibrate.stop();
              if(timer_StopVibrate) timer.stopTimer(timer_StopVibrate);
            }

            // end vibrate function

            console.log('Watch_Face.Buttons');
            Button_9 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 351,
              y: 39,
              w: 69,
              h: 70,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'null.png',
              normal_src: 'null.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'Settings_homeScreen', native: true });
				vibro(25);
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_10 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 358,
              y: 358,
              w: 69,
              h: 70,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'null.png',
              normal_src: 'null.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'Settings_displayBrightScreen', native: true });
				vibro(25);
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_11 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 39,
              y: 358,
              w: 69,
              h: 70,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'null.png',
              normal_src: 'null.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'AlarmInfoScreen', native: true });
				vibro(25);
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_12 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 52,
              y: 43,
              w: 62,
              h: 64,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'null.png',
              normal_src: 'null.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'Settings_dndScreen', native: true });
				vibro(25);
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_13 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 109,
              y: 158,
              w: 184,
              h: 40,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'null.png',
              normal_src: 'null.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'ScheduleCalScreen', native: true });
				vibro(25);
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button


                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}