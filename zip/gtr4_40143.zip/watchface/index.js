﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (()=>{
        //dynamic modify start

        const lang = DeviceRuntimeCore.HmUtils.getLanguage()
        let normal_background_bg_img = ''
        let normal_date_img_date_week_img = ''
        let normal_date_img_date_day = ''
        let normal_battery_icon_img = ''
        let normal_battery_text_text_img = ''
        let normal_battery_text_separator_img = ''
        let normal_stand_icon_img = ''
        let normal_stand_target_text_img = ''
        let normal_stand_current_text_img = ''
        let normal_stand_current_separator_img = ''
        let normal_heart_rate_icon_img = ''
        let normal_heart_rate_text_text_img = ''
        let normal_heart_rate_text_separator_img = ''
        let normal_distance_icon_img = ''
        let normal_distance_text_text_img = ''
        let normal_distance_text_separator_img = ''
        let normal_calorie_icon_img = ''
        let normal_calorie_current_text_img = ''
        let normal_calorie_current_separator_img = ''
        let normal_step_icon_img = ''
        let normal_step_current_text_img = ''
        let normal_step_current_separator_img = ''
        let normal_compass_direction_pointer_img = ''
        let normal_compass_text_img = ''
        let normal_compass_direction_img_level = ''
        let normal_compass_direction_arr = ["d_1.png", "d_2.png", "d_3.png", "d_4.png", "d_5.png", "d_6.png", "d_7.png", "d_8.png"];
        let normal_pai_icon_img = ''
        let normal_digital_clock_img_time = ''
        let normal_analog_clock_time_pointer_second = ''
        let idle_background_bg = ''
        let idle_date_img_date_week_img = ''
        let idle_date_img_date_day = ''
        let idle_battery_text_text_img = ''
        let idle_battery_text_separator_img = ''
        let idle_heart_rate_text_text_img = ''
        let idle_heart_rate_text_separator_img = ''
        let idle_digital_clock_img_time = ''
        let normal_step_jumpable_img_click = ''
        let normal_heart_jumpable_img_click = ''
        let normal_pai_jumpable_img_click = ''
        let normal_countdown_jumpable_img_click = ''
        let Button_1 = ''
		
		let btn_zona1 = ''
        let zona1_num = 0
        let zona1_all = 2
		
		function click_zona1() {
		  zona1_num = (zona1_num + 1) % (zona1_all + 1);
          if (zona1_num == 0) {		
		    normal_step_icon_img.setProperty(hmUI.prop.VISIBLE, true);
            normal_step_current_text_img.setProperty(hmUI.prop.VISIBLE, true);
			normal_step_current_separator_img.setProperty(hmUI.prop.VISIBLE, true);
			normal_calorie_icon_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_calorie_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_calorie_current_separator_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_distance_icon_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_distance_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_distance_text_separator_img.setProperty(hmUI.prop.VISIBLE, false);
		    hmUI.showToast({
            });
          };
		  
		 if (zona1_num == 1) {
			normal_step_icon_img.setProperty(hmUI.prop.VISIBLE, false);
            normal_step_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_step_current_separator_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_calorie_icon_img.setProperty(hmUI.prop.VISIBLE, true);
			normal_calorie_current_text_img.setProperty(hmUI.prop.VISIBLE, true);
			normal_calorie_current_separator_img.setProperty(hmUI.prop.VISIBLE, true);
			normal_distance_icon_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_distance_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_distance_text_separator_img.setProperty(hmUI.prop.VISIBLE, false);
		    hmUI.showToast({
            });
          };
		  
		  if (zona1_num == 2) {
			normal_step_icon_img.setProperty(hmUI.prop.VISIBLE, false);
            normal_step_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_step_current_separator_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_calorie_icon_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_calorie_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_calorie_current_separator_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_distance_icon_img.setProperty(hmUI.prop.VISIBLE, true);
			normal_distance_text_text_img.setProperty(hmUI.prop.VISIBLE, true);
			normal_distance_text_separator_img.setProperty(hmUI.prop.VISIBLE, true);
		    hmUI.showToast({
            });
          };
        }
		
		let btn_zona2 = ''
        let zona2_num = 0
        let zona2_all = 2
		
		function click_zona2() {
		  zona2_num = (zona2_num + 1) % (zona2_all + 1);
          if (zona2_num == 0) {		
		    normal_heart_rate_icon_img.setProperty(hmUI.prop.VISIBLE, true);
            normal_heart_rate_text_text_img.setProperty(hmUI.prop.VISIBLE, true);
			normal_heart_rate_text_separator_img.setProperty(hmUI.prop.VISIBLE, true);
			normal_stand_icon_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_stand_target_text_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_stand_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_stand_current_separator_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_battery_icon_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_battery_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_battery_text_separator_img.setProperty(hmUI.prop.VISIBLE, false);
		    hmUI.showToast({
            });
          };
		  
		 if (zona2_num == 1) {
			normal_heart_rate_icon_img.setProperty(hmUI.prop.VISIBLE, false);
            normal_heart_rate_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_heart_rate_text_separator_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_stand_icon_img.setProperty(hmUI.prop.VISIBLE, true);
			normal_stand_target_text_img.setProperty(hmUI.prop.VISIBLE, true);
			normal_stand_current_text_img.setProperty(hmUI.prop.VISIBLE, true);
			normal_stand_current_separator_img.setProperty(hmUI.prop.VISIBLE, true);
			normal_battery_icon_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_battery_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_battery_text_separator_img.setProperty(hmUI.prop.VISIBLE, false);
		    hmUI.showToast({
            });
          };
		  
		  if (zona2_num == 2) {
			normal_heart_rate_icon_img.setProperty(hmUI.prop.VISIBLE, false);
            normal_heart_rate_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_heart_rate_text_separator_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_stand_icon_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_stand_target_text_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_stand_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_stand_current_separator_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_battery_icon_img.setProperty(hmUI.prop.VISIBLE, true);
			normal_battery_text_text_img.setProperty(hmUI.prop.VISIBLE, true);
			normal_battery_text_separator_img.setProperty(hmUI.prop.VISIBLE, true);
		    hmUI.showToast({
            });
          };
        }
		
		let btn_zona3 = ''
        let zona3_num = 0
        let zona3_all = 1
		
		function click_zona3() {
		  zona3_num = (zona3_num + 1) % (zona3_all + 1);
          if (zona3_num == 0) {		
		    normal_compass_direction_pointer_img.setProperty(hmUI.prop.VISIBLE, true);
            normal_compass_text_img.setProperty(hmUI.prop.VISIBLE, true);
			normal_compass_direction_img_level.setProperty(hmUI.prop.VISIBLE, true);
			normal_pai_icon_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_analog_clock_time_pointer_second.setProperty(hmUI.prop.VISIBLE, false);
		    hmUI.showToast({
            });
          };
		  
		 if (zona3_num == 1) {
			normal_compass_direction_pointer_img.setProperty(hmUI.prop.VISIBLE, false);
            normal_compass_text_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_compass_direction_img_level.setProperty(hmUI.prop.VISIBLE, false);
			normal_pai_icon_img.setProperty(hmUI.prop.VISIBLE, true);
			normal_analog_clock_time_pointer_second.setProperty(hmUI.prop.VISIBLE, true);
		    hmUI.showToast({
            });
          };
        }


        //dynamic modify end
        const e = __$$hmAppManager$$__.currentApp;
        const o = e.current
          , {px: i} = (new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(e,o)),
        e.__globals__)
          , n = Logger.getLogger("watchface6");
        o.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            console.log('Watch_Face.ScreenNormal');
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 466,
              h: 466,
              src: 'bg.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
			
			let dned=["week_1.png","week_2.png","week_3.png","week_4.png","week_5.png","week_6.png","week_7.png"]
			if(lang=='ru-RU'){
				dned=["weekru_1.png","weekru_2.png","weekru_3.png","weekru_4.png","weekru_5.png","weekru_6.png","weekru_7.png"]
			}
            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 168,
              y: 343,
              week_en: dned,
              week_tc: ["week_1.png","week_2.png","week_3.png","week_4.png","week_5.png","week_6.png","week_7.png"],
              week_sc: ["week_1.png","week_2.png","week_3.png","week_4.png","week_5.png","week_6.png","week_7.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 243,
              day_startY: 342,
              day_sc_array: ["date_0.png","date_1.png","date_2.png","date_3.png","date_4.png","date_5.png","date_6.png","date_7.png","date_8.png","date_9.png"],
              day_tc_array: ["date_0.png","date_1.png","date_2.png","date_3.png","date_4.png","date_5.png","date_6.png","date_7.png","date_8.png","date_9.png"],
              day_en_array: ["date_0.png","date_1.png","date_2.png","date_3.png","date_4.png","date_5.png","date_6.png","date_7.png","date_8.png","date_9.png"],
              day_zero: 1,
              day_space: 0,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
			
			let dbatt='batt.png'
			if(lang=='ru-RU'){
				dbatt='batt_ru.png'
			}
            normal_battery_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 316,
              y: 245,
              src: dbatt,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 324,
              y: 218,
              font_array: ["font_0.png","font_1.png","font_2.png","font_3.png","font_4.png","font_5.png","font_6.png","font_7.png","font_8.png","font_9.png"],
              padding: false,
              h_space: 1,
              unit_sc: 'per.png',
              unit_tc: 'per.png',
              unit_en: 'per.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 331,
              y: 175,
              src: 'bat.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
			
			let dstand='stand.png'
			if(lang=='ru-RU'){
				dstand='stand_ru.png'
			}
            normal_stand_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 314,
              y: 245,
              src: dstand,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_stand_target_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 353,
              y: 218,
              font_array: ["font_0.png","font_1.png","font_2.png","font_3.png","font_4.png","font_5.png","font_6.png","font_7.png","font_8.png","font_9.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STAND_TARGET,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_stand_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 284,
              y: 218,
              font_array: ["font_0.png","font_1.png","font_2.png","font_3.png","font_4.png","font_5.png","font_6.png","font_7.png","font_8.png","font_9.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'gang.png',
              unit_tc: 'gang.png',
              unit_en: 'gang.png',
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.STAND,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_stand_current_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 328,
              y: 175,
              src: 'stands.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
			
			let dbpm='heart.png'
			if(lang=='ru-RU'){
				dbpm='heart_ru.png'
			}
            normal_heart_rate_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 316,
              y: 245,
              src: dbpm,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 330,
              y: 218,
              font_array: ["font_0.png","font_1.png","font_2.png","font_3.png","font_4.png","font_5.png","font_6.png","font_7.png","font_8.png","font_9.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 330,
              y: 175,
              src: 'heart_rate.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
			
			let ddist='dist.png'
			if(lang=='ru-RU'){
				ddist='dist_ru.png'
			}
            normal_distance_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 75,
              y: 245,
              src: ddist,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_distance_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 80,
              y: 218,
              font_array: ["font_0.png","font_1.png","font_2.png","font_3.png","font_4.png","font_5.png","font_6.png","font_7.png","font_8.png","font_9.png"],
              padding: false,
              h_space: 0,
              dot_image: 'dot.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.DISTANCE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_distance_text_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 88,
              y: 175,
              src: 'dists.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
			
			let dcal='cal.png'
			if(lang=='ru-RU'){
				dcal='cal_ru.png'
			}
            normal_calorie_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 75,
              y: 245,
              src: dcal,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_calorie_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 83,
              y: 218,
              font_array: ["font_0.png","font_1.png","font_2.png","font_3.png","font_4.png","font_5.png","font_6.png","font_7.png","font_8.png","font_9.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_calorie_current_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 88,
              y: 175,
              src: 'calorie.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
			
			let dstep='step.png'
			if(lang=='ru-RU'){
				dstep='step_ru.png'
			}
            normal_step_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 76,
              y: 245,
              src: dstep,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 78,
              y: 218,
              font_array: ["font_0.png","font_1.png","font_2.png","font_3.png","font_4.png","font_5.png","font_6.png","font_7.png","font_8.png","font_9.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 92,
              y: 175,
              src: 'steps.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            const deviceInfo = hmSetting.getDeviceInfo();
            
            // normal_compass_custom_pointer_img = hmUI.createWidget(hmUI.widget.CUSTOM_POINTER, {
              // src: 'pointer.png',
              // center_x: 233,
              // center_y: 233,
              // x: 233,
              // y: 233,
              // start_angle: 0,
              // end_angle: 360,
              // type: hmUI.data_type.COMPASS,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });


            //start of ignored block
            normal_compass_direction_pointer_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: deviceInfo.width,
              h: deviceInfo.height,
              pos_x: 233 - 233,
              pos_y: 233 - 233,
              center_x: 233,
              center_y: 233,
              src: 'pointer.png',
              angle: 0,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            //end of ignored block

            normal_compass_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 193,
              y: 105,
              font_array: ["wind_0.png","wind_1.png","wind_2.png","wind_3.png","wind_4.png","wind_5.png","wind_6.png","wind_7.png","wind_8.png","wind_9.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'du.png',
              unit_tc: 'du.png',
              unit_en: 'du.png',
              align_h: hmUI.align.CENTER_H,
              // type: hmUI.data_type.COMPASS,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_compass_direction_img_level = hmUI.createWidget(hmUI.widget.IMG, {
              x: 216,
              y: 75,
              src: 'd_1.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
              // type: hmUI.data_type.COMPASS,
            });

            normal_pai_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'mask.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 166,
              hour_startY: 138,
              hour_array: ["hour_0.png","hour_1.png","hour_2.png","hour_3.png","hour_4.png","hour_5.png","hour_6.png","hour_7.png","hour_8.png","hour_9.png"],
              hour_zero: 1,
              hour_space: 0,
              hour_angle: 0,
              hour_align: hmUI.align.LEFT,

              minute_startX: 166,
              minute_startY: 233,
              minute_array: ["min_0.png","min_1.png","min_2.png","min_3.png","min_4.png","min_5.png","min_6.png","min_7.png","min_8.png","min_9.png"],
              minute_zero: 1,
              minute_space: 0,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_second = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              second_path: 'bezel.png',
              second_centerX: 233,
              second_centerY: 233,
              second_posX: 233,
              second_posY: 233,
              second_cover_path: 'points.png',
              second_cover_x: 214,
              second_cover_y: 33,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            console.log('Watch_Face.ScreenAOD');
            idle_background_bg = hmUI.createWidget(hmUI.widget.FILL_RECT, {
              x: 0,
              y: 0,
              w: 466,
              h: 466,
              color: '0xFF000000',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 168,
              y: 343,
              week_en: ["week_1.png","week_2.png","week_3.png","week_4.png","week_5.png","week_6.png","week_7.png"],
              week_tc: ["week_1.png","week_2.png","week_3.png","week_4.png","week_5.png","week_6.png","week_7.png"],
              week_sc: ["week_1.png","week_2.png","week_3.png","week_4.png","week_5.png","week_6.png","week_7.png"],
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 243,
              day_startY: 342,
              day_sc_array: ["date_0.png","date_1.png","date_2.png","date_3.png","date_4.png","date_5.png","date_6.png","date_7.png","date_8.png","date_9.png"],
              day_tc_array: ["date_0.png","date_1.png","date_2.png","date_3.png","date_4.png","date_5.png","date_6.png","date_7.png","date_8.png","date_9.png"],
              day_en_array: ["date_0.png","date_1.png","date_2.png","date_3.png","date_4.png","date_5.png","date_6.png","date_7.png","date_8.png","date_9.png"],
              day_zero: 1,
              day_space: 0,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 324,
              y: 218,
              font_array: ["font_0.png","font_1.png","font_2.png","font_3.png","font_4.png","font_5.png","font_6.png","font_7.png","font_8.png","font_9.png"],
              padding: false,
              h_space: 1,
              unit_sc: 'per.png',
              unit_tc: 'per.png',
              unit_en: 'per.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_battery_text_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 331,
              y: 175,
              src: 'bat.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 87,
              y: 218,
              font_array: ["font_0.png","font_1.png","font_2.png","font_3.png","font_4.png","font_5.png","font_6.png","font_7.png","font_8.png","font_9.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_heart_rate_text_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 87,
              y: 175,
              src: 'heart_rate.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 166,
              hour_startY: 138,
              hour_array: ["hour_0.png","hour_1.png","hour_2.png","hour_3.png","hour_4.png","hour_5.png","hour_6.png","hour_7.png","hour_8.png","hour_9.png"],
              hour_zero: 1,
              hour_space: 0,
              hour_angle: 0,
              hour_align: hmUI.align.LEFT,

              minute_startX: 166,
              minute_startY: 233,
              minute_array: ["hour_0.png","hour_1.png","hour_2.png","hour_3.png","hour_4.png","hour_5.png","hour_6.png","hour_7.png","hour_8.png","hour_9.png"],
              minute_zero: 1,
              minute_space: 0,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_AOD,
            });
            console.log('Watch_Face.Shortcuts');

            btn_zona1 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 68,
              y: 180,
              text: '',
              w: 68,
              h: 97,
              normal_src: 'Empty.png',
              press_src: 'Empty.png',
              click_func: () => {
				click_zona1();
             },
			  longpress_func: () => {
             hmApp.startApp({ url: "activityAppScreen", native: true });
             },
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            btn_zona1.setProperty(hmUI.prop.VISIBLE, true);
			normal_calorie_icon_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_calorie_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_calorie_current_separator_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_distance_icon_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_distance_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_distance_text_separator_img.setProperty(hmUI.prop.VISIBLE, false);

            btn_zona2 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 316,
              y: 180,
              text: '',
              w: 68,
              h: 97,
              normal_src: 'Empty.png',
              press_src: 'Empty.png',
              click_func: () => {
				click_zona2();
             },
			  longpress_func: () => {
             hmApp.startApp({ url: "heart_app_Screen", native: true });
             },
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            btn_zona2.setProperty(hmUI.prop.VISIBLE, true);
			normal_stand_icon_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_stand_target_text_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_stand_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_stand_current_separator_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_battery_icon_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_battery_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_battery_text_separator_img.setProperty(hmUI.prop.VISIBLE, false);

            btn_zona3 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 194,
              y: 146,
              text: '',
              w: 78,
              h: 78,
              normal_src: 'Empty.png',
              press_src: 'Empty.png',
              click_func: () => {
				click_zona3();
             },
			  longpress_func: () => {
             hmApp.startApp({ url: "StopWatchScreen", native: true });
             },
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            btn_zona3.setProperty(hmUI.prop.VISIBLE, true);
			normal_pai_icon_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_analog_clock_time_pointer_second.setProperty(hmUI.prop.VISIBLE, false);

            normal_countdown_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 194,
              y: 248,
              w: 78,
              h: 78,
              type: hmUI.data_type.COUNT_DOWN,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            console.log('Watch_Face.Buttons');
            Button_1 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 184,
              y: 340,
              w: 97,
              h: 39,
              text: '',
              color: 0xFFFF8C00,
              text_size: 24,
              press_src: 'Empty.png',
              normal_src: 'Empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'ScheduleCalScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            let screenType = hmSetting.getScreenType();
            //start of ignored block
            console.log('compass_update()');
            if (screenType == hmSetting.screen_type.WATCHFACE){
              compass = hmSensor.createSensor(hmSensor.id.COMPASS);
              compass.start();

              if (compass.direction_angle && compass.direction  && compass.direction_angle != 'INVALID') { // initial data
                // Compass Pointer
                let compass_direction_angle = parseInt(compass.direction_angle);
                normal_compass_direction_pointer_img.setProperty(hmUI.prop.ANGLE, -compass_direction_angle);
                // Compass Number
                let normal_compass_direction_angle_text = compass_direction_angle.toString();
                normal_compass_text_img.setProperty(hmUI.prop.TEXT, normal_compass_direction_angle_text);
                // Compass Images
                let compass_direction_angle_img = compass_direction_angle + 45 / 2;
                let compass_direction_index = parseInt(compass_direction_angle_img/45);
                if (compass_direction_index > 7) compass_direction_index = 0;
                normal_compass_direction_img_level.setProperty(hmUI.prop.SRC, normal_compass_direction_arr[compass_direction_index]);

              } else { // error data
                normal_compass_direction_pointer_img.setProperty(hmUI.prop.ANGLE, 0);
                normal_compass_text_img.setProperty(hmUI.prop.TEXT, '-');
                normal_compass_direction_img_level.setProperty(hmUI.prop.SRC, normal_compass_direction_arr[0]);

              }

              compass.addEventListener(hmSensor.event.CHANGE, function (compass_res) { // change values when changing direction

                if (compass_res.calibration_status) {
                  // Compass Pointer
                  let compass_direction_angle = parseInt(compass_res.direction_angle);
                  normal_compass_direction_pointer_img.setProperty(hmUI.prop.ANGLE, -compass_direction_angle);
                  // Compass Number
                  let normal_compass_direction_angle_text = compass_direction_angle.toString();
                  normal_compass_text_img.setProperty(hmUI.prop.TEXT, normal_compass_direction_angle_text);
                  // Compass Images
                  let compass_direction_angle_img = compass_direction_angle + 45 / 2;
                  let compass_direction_index = parseInt(compass_direction_angle_img/45);
                  if (compass_direction_index > 7) compass_direction_index = 0;
                  normal_compass_direction_img_level.setProperty(hmUI.prop.SRC, normal_compass_direction_arr[compass_direction_index]);

                } else { // error data
                  normal_compass_direction_pointer_img.setProperty(hmUI.prop.ANGLE, 0);
                  normal_compass_text_img.setProperty(hmUI.prop.TEXT, '-');
                  normal_compass_direction_img_level.setProperty(hmUI.prop.SRC, normal_compass_direction_arr[0]);

                }

              }); // Listener end

            };
            //end of ignored block

            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                console.log('resume_call()');
                if (compass && screenType == hmSetting.screen_type.WATCHFACE) compass.start();

              }),
              pause_call: (function () {
                console.log('pause_call()');
                if (compass) compass.stop();

              }),
            });

                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}