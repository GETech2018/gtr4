﻿
    /*
    ** Watch_Face_Editor tool
    ** watchface js version v1.0.1
    ** Copyright © CashaCX75. All Rights Reserved
    */

    try {

      (() => {

        var __$$app$$__ = __$$hmAppManager$$__.currentApp;
        var __$$module$$__ = __$$app$$__.current;
        //drink is a name,can modify
        var h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__), 'drink');

        'use strict';

        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_heart_rate_text_text_img = ''
        let normal_battery_text_text_img = ''
        let normal_altimeter_icon_img = ''
        let normal_temperature_high_text_img = ''
        let normal_temperature_low_text_img = ''
        let normal_temperature_current_text_img = ''
        let normal_weather_image_progress_img_level = ''
        let normal_date_img_date_week_img = ''
        let normal_digital_clock_img_time_AmPm = ''
        let normal_digital_clock_img_time = ''
        let normal_distance_text_text_img = ''
        let normal_step_current_text_img = ''
        let normal_sun_high_text_img = ''
        let normal_sun_low_text_img = ''
        let normal_date_img_date_day = ''
        let normal_date_img_date_month_img = ''
        let normal_system_lock_img = ''
        let normal_system_disconnect_img = ''
        let normal_system_clock_img = ''
        let normal_sunrise_jumpable_img_click = ''
        let normal_temperature_jumpable_img_click = ''
        let normal_heart_jumpable_img_click = ''
        let normal_step_jumpable_img_click = ''
        let normal_countdown_jumpable_img_click = ''
        let normal_sleep_jumpable_img_click = ''
        let normal_altimeter_jumpable_img_click = ''
        let normal_pai_jumpable_img_click = ''
        let idle_background_bg_img = ''
        let idle_date_img_date_week_img = ''
        let idle_digital_clock_img_time_AmPm = ''
        let idle_digital_clock_img_time = ''
        let idle_date_img_date_day = ''


        //dynamic modify end

        //not required
        const logger = DeviceRuntimeCore.HmLogger.getLogger("yeguang");

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({

          init_view() {

            //dynamic modify start
                    
            
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 466,
              h: 466,
              src: '0000.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 365,
              y: 194,
              font_array: ["MinWh001.png","MinWh002.png","MinWh003.png","MinWh004.png","MinWh005.png","MinWh006.png","MinWh007.png","MinWh008.png","MinWh009.png","MinWh010.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 44,
              y: 194,
              font_array: ["MinWh001.png","MinWh002.png","MinWh003.png","MinWh004.png","MinWh005.png","MinWh006.png","MinWh007.png","MinWh008.png","MinWh009.png","MinWh010.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_altimeter_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: '0001.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_high_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 325,
              y: 352,
              font_array: ["Oth001.png","Oth002.png","Oth003.png","Oth004.png","Oth005.png","Oth006.png","Oth007.png","Oth008.png","Oth009.png","Oth010.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'Oth012.png',
              unit_tc: 'Oth012.png',
              unit_en: 'Oth012.png',
              negative_image: 'Oth011.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_HIGH,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_low_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 75,
              y: 352,
              font_array: ["Oth001.png","Oth002.png","Oth003.png","Oth004.png","Oth005.png","Oth006.png","Oth007.png","Oth008.png","Oth009.png","Oth010.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'Oth012.png',
              unit_tc: 'Oth012.png',
              unit_en: 'Oth012.png',
              negative_image: 'Oth011.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_LOW,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 193,
              y: 423,
              font_array: ["Sec01.png","Sec02.png","Sec03.png","Sec04.png","Sec05.png","Sec06.png","Sec07.png","Sec08.png","Sec09.png","Sec10.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'Sec12.png',
              unit_tc: 'Sec12.png',
              unit_en: 'Sec12.png',
              negative_image: 'Sec11.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 166,
              y: 311,
              image_array: ["w001.png","w002.png","w003.png","w004.png","w005.png","w006.png","w007.png","w008.png","w009.png","w010.png","w011.png","w012.png","w013.png","w014.png","w015.png","w016.png","w017.png","w018.png","w019.png","w020.png","w021.png","w022.png","w023.png","w024.png","w025.png","w026.png","w027.png","w028.png","w029.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 79,
              y: 117,
              week_en: ["week001.png","week002.png","week003.png","week004.png","week005.png","week006.png","week007.png"],
              week_tc: ["week001.png","week002.png","week003.png","week004.png","week005.png","week006.png","week007.png"],
              week_sc: ["week001.png","week002.png","week003.png","week004.png","week005.png","week006.png","week007.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time_AmPm = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              am_x: 205,
              am_y: 170,
              am_sc_path: 'am01.png',
              am_en_path: 'am01.png',
              pm_x: 205,
              pm_y: 170,
              pm_sc_path: 'am02.png',
              pm_en_path: 'am02.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 117,
              hour_startY: 203,
              hour_array: ["hrs01.png","hrs02.png","hrs03.png","hrs04.png","hrs05.png","hrs06.png","hrs07.png","hrs08.png","hrs09.png","hrs10.png"],
              hour_zero: 1,
              hour_space: 2,
              hour_align: hmUI.align.RIGHT,

              minute_startX: 246,
              minute_startY: 203,
              minute_array: ["hrs01.png","hrs02.png","hrs03.png","hrs04.png","hrs05.png","hrs06.png","hrs07.png","hrs08.png","hrs09.png","hrs10.png"],
              minute_zero: 1,
              minute_space: 2,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              second_startX: 208,
              second_startY: 275,
              second_array: ["Sec01.png","Sec02.png","Sec03.png","Sec04.png","Sec05.png","Sec06.png","Sec07.png","Sec08.png","Sec09.png","Sec10.png"],
              second_zero: 1,
              second_space: -1,
              second_follow: 0,
              second_align: hmUI.align.CENTER_H,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_distance_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 92,
              y: 108,
              font_array: ["MinWh001.png","MinWh002.png","MinWh003.png","MinWh004.png","MinWh005.png","MinWh006.png","MinWh007.png","MinWh008.png","MinWh009.png","MinWh010.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'MinWh014.png',
              unit_tc: 'MinWh014.png',
              unit_en: 'MinWh014.png',
              dot_image: 'MinWh013.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.DISTANCE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 276,
              y: 108,
              font_array: ["MinWh001.png","MinWh002.png","MinWh003.png","MinWh004.png","MinWh005.png","MinWh006.png","MinWh007.png","MinWh008.png","MinWh009.png","MinWh010.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sun_high_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 25,
              y: 285,
              font_array: ["time001.png","time002.png","time003.png","time004.png","time005.png","time006.png","time007.png","time008.png","time009.png","time010.png"],
              padding: false,
              h_space: 0,
              dot_image: 'time011.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.SUN_RISE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sun_low_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 353,
              y: 285,
              font_array: ["time001.png","time002.png","time003.png","time004.png","time005.png","time006.png","time007.png","time008.png","time009.png","time010.png"],
              padding: false,
              h_space: 0,
              dot_image: 'time011.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.SUN_SET,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 213,
              day_startY: 30,
              day_sc_array: ["MinWh001.png","MinWh002.png","MinWh003.png","MinWh004.png","MinWh005.png","MinWh006.png","MinWh007.png","MinWh008.png","MinWh009.png","MinWh010.png"],
              day_tc_array: ["MinWh001.png","MinWh002.png","MinWh003.png","MinWh004.png","MinWh005.png","MinWh006.png","MinWh007.png","MinWh008.png","MinWh009.png","MinWh010.png"],
              day_en_array: ["MinWh001.png","MinWh002.png","MinWh003.png","MinWh004.png","MinWh005.png","MinWh006.png","MinWh007.png","MinWh008.png","MinWh009.png","MinWh010.png"],
              day_zero: 0,
              day_space: 1,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_month_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 153,
              month_startY: 57,
              month_sc_array: ["Mon001.png","Mon002.png","Mon003.png","Mon004.png","Mon005.png","Mon006.png","Mon007.png","Mon008.png","Mon009.png","Mon010.png","Mon011.png","Mon012.png"],
              month_tc_array: ["Mon001.png","Mon002.png","Mon003.png","Mon004.png","Mon005.png","Mon006.png","Mon007.png","Mon008.png","Mon009.png","Mon010.png","Mon011.png","Mon012.png"],
              month_en_array: ["Mon001.png","Mon002.png","Mon003.png","Mon004.png","Mon005.png","Mon006.png","Mon007.png","Mon008.png","Mon009.png","Mon010.png","Mon011.png","Mon012.png"],
              month_is_character: true ,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_lock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 39,
              y: 146,
              src: 'BLK.png',
              type: hmUI.system_status.LOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 120,
              y: 284,
              src: 'BT.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 395,
              y: 146,
              src: 'BDNK.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sunrise_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 6,
              y: 191,
              w: 112,
              h: 121,
              src: 'Ya.png',
              type: hmUI.data_type.SUN_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 156,
              y: 315,
              w: 155,
              h: 155,
              src: 'Ya.png',
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 350,
              y: 188,
              w: 118,
              h: 121,
              src: 'Ya.png',
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 273,
              y: 73,
              w: 158,
              h: 106,
              src: 'Ya.png',
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_countdown_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 239,
              y: 188,
              w: 108,
              h: 120,
              src: 'Ya.png',
              type: hmUI.data_type.COUNT_DOWN,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sleep_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 122,
              y: 190,
              w: 106,
              h: 117,
              src: 'Ya.png',
              type: hmUI.data_type.SLEEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_altimeter_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 319,
              y: 314,
              w: 100,
              h: 100,
              src: 'Ya.png',
              type: hmUI.data_type.ALTIMETER,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_pai_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 25,
              y: 71,
              w: 150,
              h: 106,
              src: 'Ya.png',
              type: hmUI.data_type.PAI_WEEKLY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            idle_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 466,
              h: 466,
              src: 'AOD.png',
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 79,
              y: 120,
              week_en: ["week001.png","week002.png","week003.png","week004.png","week005.png","week006.png","week007.png"],
              week_tc: ["week001.png","week002.png","week003.png","week004.png","week005.png","week006.png","week007.png"],
              week_sc: ["week001.png","week002.png","week003.png","week004.png","week005.png","week006.png","week007.png"],
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_digital_clock_img_time_AmPm = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              am_x: 205,
              am_y: 170,
              am_sc_path: 'am01.png',
              am_en_path: 'am01.png',
              pm_x: 205,
              pm_y: 170,
              pm_sc_path: 'am02.png',
              pm_en_path: 'am02.png',
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 123,
              hour_startY: 203,
              hour_array: ["hrs01.png","hrs02.png","hrs03.png","hrs04.png","hrs05.png","hrs06.png","hrs07.png","hrs08.png","hrs09.png","hrs10.png"],
              hour_zero: 1,
              hour_space: -2,
              hour_align: hmUI.align.RIGHT,

              minute_startX: 241,
              minute_startY: 203,
              minute_array: ["hrs01.png","hrs02.png","hrs03.png","hrs04.png","hrs05.png","hrs06.png","hrs07.png","hrs08.png","hrs09.png","hrs10.png"],
              minute_zero: 1,
              minute_space: -2,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              second_startX: 208,
              second_startY: 275,
              second_array: ["Sec01.png","Sec02.png","Sec03.png","Sec04.png","Sec05.png","Sec06.png","Sec07.png","Sec08.png","Sec09.png","Sec10.png"],
              second_zero: 1,
              second_space: -1,
              second_follow: 0,
              second_align: hmUI.align.CENTER_H,

              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 213,
              day_startY: 90,
              day_sc_array: ["Oth001.png","Oth002.png","Oth003.png","Oth004.png","Oth005.png","Oth006.png","Oth007.png","Oth008.png","Oth009.png","Oth010.png"],
              day_tc_array: ["Oth001.png","Oth002.png","Oth003.png","Oth004.png","Oth005.png","Oth006.png","Oth007.png","Oth008.png","Oth009.png","Oth010.png"],
              day_en_array: ["Oth001.png","Oth002.png","Oth003.png","Oth004.png","Oth005.png","Oth006.png","Oth007.png","Oth008.png","Oth009.png","Oth010.png"],
              day_zero: 0,
              day_space: 0,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONAL_AOD,
            });


            //dynamic modify end
          },

          onInit() {
            console.log('index page.js on init invoke')

            this.init_view()

          },

          onReady() {
            console.log('index page.js on ready invoke')
          },

          onShow() {
            console.log('index page.js on show invoke')
          },

          onHide() {
            console.log('index page.js on hide invoke')
          },

          onDestory() {
            console.log('index page.js on destory invoke')
          },
        });

      })()
    } catch (e) {
      console.log(e)
    }
  