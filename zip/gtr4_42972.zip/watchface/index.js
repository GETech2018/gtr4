﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        const logger = Logger.getLogger('watchface_SashaCX75');
        //end of ignored block

        //dynamic modify start

        
        let normal_pai_icon_img = ''
        let normal_spo2_icon_img = ''
        let normal_digital_clock_img_time = ''
		let normal_digital_clock_img_time_1 = ''
        let normal_digital_clock_img_time_AmPm = ''
		let normal_digital_clock_img_time_AmPm_1 = ''
        let normal_date_img_date_day = ''
		let normal_date_img_date_day_1 = ''
        let normal_date_img_date_week_img = ''
		let normal_date_img_date_week_img_1 = ''
        let normal_battery_image_progress_img_level = ''
		let normal_battery_image_progress_img_level_1 = ''
        let normal_battery_text_text_img = ''
		let normal_battery_text_text_img_1 = ''
        let normal_step_current_text_img = ''
		let normal_step_current_text_img_1 = ''
        let normal_calorie_current_text_img = ''
		let normal_calorie_current_text_img_1 = ''
        let normal_heart_rate_text_text_img = ''
		let normal_heart_rate_text_text_img_1 = ''
        let normal_distance_text_text_img = ''
		let normal_distance_text_text_img_1 = ''
        let normal_system_clock_img = ''
        let normal_system_disconnect_img = ''
        let idle_background_bg_img = ''
        let idle_digital_clock_img_time = ''
        let normal_step_jumpable_img_click = ''
        let normal_cal_jumpable_img_click = ''
        let normal_heart_jumpable_img_click = ''
        let normal_pai_jumpable_img_click = ''
        let normal_battery_jumpable_img_click = ''
        let normal_countdown_jumpable_img_click = ''
        let normal_stopwatch_jumpable_img_click = ''
        let Button_1 = ''
		
		let btn_zona1 = ''
        let zona1_num = 0
        let zona1_all = 1
		
		function click_zona1() {
		  zona1_num = (zona1_num + 1) % (zona1_all + 1);
          if (zona1_num == 0) {		
		    normal_spo2_icon_img.setProperty(hmUI.prop.VISIBLE, true);
			normal_pai_icon_img.setProperty(hmUI.prop.VISIBLE, false);
            normal_digital_clock_img_time.setProperty(hmUI.prop.VISIBLE, true);
			normal_digital_clock_img_time_1.setProperty(hmUI.prop.VISIBLE, false);
			normal_digital_clock_img_time_AmPm.setProperty(hmUI.prop.VISIBLE, true);
			normal_digital_clock_img_time_AmPm_1.setProperty(hmUI.prop.VISIBLE, false);
			normal_date_img_date_day.setProperty(hmUI.prop.VISIBLE, true);
			normal_date_img_date_day_1.setProperty(hmUI.prop.VISIBLE, false);
			normal_date_img_date_week_img.setProperty(hmUI.prop.VISIBLE, true);
			normal_date_img_date_week_img_1.setProperty(hmUI.prop.VISIBLE, false);
			normal_battery_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, true);
			normal_battery_image_progress_img_level_1.setProperty(hmUI.prop.VISIBLE, false);
			normal_battery_text_text_img.setProperty(hmUI.prop.VISIBLE, true);
			normal_battery_text_text_img_1.setProperty(hmUI.prop.VISIBLE, false);
			normal_step_current_text_img.setProperty(hmUI.prop.VISIBLE, true);
			normal_step_current_text_img_1.setProperty(hmUI.prop.VISIBLE, false);
			normal_calorie_current_text_img.setProperty(hmUI.prop.VISIBLE, true);
			normal_calorie_current_text_img_1.setProperty(hmUI.prop.VISIBLE, false);
			normal_heart_rate_text_text_img.setProperty(hmUI.prop.VISIBLE, true);
			normal_heart_rate_text_text_img_1.setProperty(hmUI.prop.VISIBLE, false);
			normal_distance_text_text_img.setProperty(hmUI.prop.VISIBLE, true);
			normal_distance_text_text_img_1.setProperty(hmUI.prop.VISIBLE, false);
		    hmUI.showToast({
            });
          };
		  
		 if (zona1_num == 1) {
			normal_spo2_icon_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_pai_icon_img.setProperty(hmUI.prop.VISIBLE, true);
            normal_digital_clock_img_time.setProperty(hmUI.prop.VISIBLE, false);
			normal_digital_clock_img_time_1.setProperty(hmUI.prop.VISIBLE, true);
			normal_digital_clock_img_time_AmPm.setProperty(hmUI.prop.VISIBLE, false);
			normal_digital_clock_img_time_AmPm_1.setProperty(hmUI.prop.VISIBLE, true);
			normal_date_img_date_day.setProperty(hmUI.prop.VISIBLE, false);
			normal_date_img_date_day_1.setProperty(hmUI.prop.VISIBLE, true);
			normal_date_img_date_week_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_date_img_date_week_img_1.setProperty(hmUI.prop.VISIBLE, true);
			normal_battery_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, false);
			normal_battery_image_progress_img_level_1.setProperty(hmUI.prop.VISIBLE, true);
			normal_battery_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_battery_text_text_img_1.setProperty(hmUI.prop.VISIBLE, true);
			normal_step_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_step_current_text_img_1.setProperty(hmUI.prop.VISIBLE, true);
			normal_calorie_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_calorie_current_text_img_1.setProperty(hmUI.prop.VISIBLE, true);
			normal_heart_rate_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_heart_rate_text_text_img_1.setProperty(hmUI.prop.VISIBLE, true);
			normal_distance_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_distance_text_text_img_1.setProperty(hmUI.prop.VISIBLE, true);
		    hmUI.showToast({
            });
          };
        }


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            console.log('Watch_Face.ScreenNormal');

            normal_pai_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'bg_2.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_spo2_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'bg_1.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 57,
              hour_startY: 154,
              hour_array: ["3.png","4.png","5.png","6.png","7.png","8.png","9.png","10.png","11.png","12.png"],
              hour_zero: 1,
              hour_space: 0,
              hour_angle: 0,
              hour_align: hmUI.align.LEFT,

              minute_startX: 258,
              minute_startY: 152,
              minute_array: ["mib_0.png","mib_1.png","mib_2.png","mib_3.png","mib_4.png","mib_5.png","mib_6.png","mib_7.png","mib_8.png","mib_9.png"],
              minute_zero: 1,
              minute_space: 0,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              second_startX: 349,
              second_startY: 255,
              second_array: ["secb_0.png","secb_1.png","secb_2.png","secb_3.png","secb_4.png","secb_5.png","secb_6.png","secb_7.png","secb_8.png","secb_9.png"],
              second_zero: 1,
              second_space: 0,
              second_angle: 0,
              second_follow: 0,
              second_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });
			
			normal_digital_clock_img_time_1 = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 57,
              hour_startY: 154,
              hour_array: ["3.png","4.png","5.png","6.png","7.png","8.png","9.png","10.png","11.png","12.png"],
              hour_zero: 1,
              hour_space: 0,
              hour_angle: 0,
              hour_align: hmUI.align.LEFT,

              minute_startX: 258,
              minute_startY: 152,
              minute_array: ["miw_0.png","miw_1.png","miw_2.png","miw_3.png","miw_4.png","miw_5.png","miw_6.png","miw_7.png","miw_8.png","miw_9.png"],
              minute_zero: 1,
              minute_space: 0,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              second_startX: 349,
              second_startY: 255,
              second_array: ["secw_0.png","secw_1.png","secw_2.png","secw_3.png","secw_4.png","secw_5.png","secw_6.png","secw_7.png","secw_8.png","secw_9.png"],
              second_zero: 1,
              second_space: 0,
              second_angle: 0,
              second_follow: 0,
              second_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time_AmPm = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              am_x: 273,
              am_y: 256,
              am_sc_path: 'amb.png',
              am_en_path: 'amb.png',
              pm_x: 273,
              pm_y: 256,
              pm_sc_path: 'pmb.png',
              pm_en_path: 'pmb.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
			
			normal_digital_clock_img_time_AmPm_1 = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              am_x: 273,
              am_y: 256,
              am_sc_path: 'amw.png',
              am_en_path: 'amw.png',
              pm_x: 273,
              pm_y: 256,
              pm_sc_path: 'pmw.png',
              pm_en_path: 'pmw.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 190,
              day_startY: 76,
              day_sc_array: ["dateb_0.png","dateb_1.png","dateb_2.png","dateb_3.png","dateb_4.png","dateb_5.png","dateb_6.png","dateb_7.png","dateb_8.png","dateb_9.png"],
              day_tc_array: ["dateb_0.png","dateb_1.png","dateb_2.png","dateb_3.png","dateb_4.png","dateb_5.png","dateb_6.png","dateb_7.png","dateb_8.png","dateb_9.png"],
              day_en_array: ["dateb_0.png","dateb_1.png","dateb_2.png","dateb_3.png","dateb_4.png","dateb_5.png","dateb_6.png","dateb_7.png","dateb_8.png","dateb_9.png"],
              day_zero: 1,
              day_space: 0,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
			
			normal_date_img_date_day_1 = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 190,
              day_startY: 76,
              day_sc_array: ["datew_0.png","datew_1.png","datew_2.png","datew_3.png","datew_4.png","datew_5.png","datew_6.png","datew_7.png","datew_8.png","datew_9.png"],
              day_tc_array: ["datew_0.png","datew_1.png","datew_2.png","datew_3.png","datew_4.png","datew_5.png","datew_6.png","datew_7.png","datew_8.png","datew_9.png"],
              day_en_array: ["datew_0.png","datew_1.png","datew_2.png","datew_3.png","datew_4.png","datew_5.png","datew_6.png","datew_7.png","datew_8.png","datew_9.png"],
              day_zero: 1,
              day_space: 0,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 91,
              y: 96,
              week_en: ["weekb_1.png","weekb_2.png","weekb_3.png","weekb_4.png","weekb_5.png","weekb_6.png","weekb_7.png"],
              week_tc: ["weekb_1.png","weekb_2.png","weekb_3.png","weekb_4.png","weekb_5.png","weekb_6.png","weekb_7.png"],
              week_sc: ["weekb_1.png","weekb_2.png","weekb_3.png","weekb_4.png","weekb_5.png","weekb_6.png","weekb_7.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
			
			normal_date_img_date_week_img_1 = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 91,
              y: 96,
              week_en: ["weekw_1.png","weekw_2.png","weekw_3.png","weekw_4.png","weekw_5.png","weekw_6.png","weekw_7.png"],
              week_tc: ["weekw_1.png","weekw_2.png","weekw_3.png","weekw_4.png","weekw_5.png","weekw_6.png","weekw_7.png"],
              week_sc: ["weekw_1.png","weekw_2.png","weekw_3.png","weekw_4.png","weekw_5.png","weekw_6.png","weekw_7.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 288,
              y: 60,
              image_array: ["battb_0.png","battb_1.png","battb_2.png","battb_3.png","battb_4.png","battb_5.png","battb_6.png","battb_7.png","battb_8.png","battb_9.png"],
              image_length: 10,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
			
			normal_battery_image_progress_img_level_1 = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 288,
              y: 60,
              image_array: ["battw_0.png","battw_1.png","battw_2.png","battw_3.png","battw_4.png","battw_5.png","battw_6.png","battw_7.png","battw_8.png","battw_9.png"],
              image_length: 10,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 274,
              y: 95,
              font_array: ["pwrb_0.png","pwrb_1.png","pwrb_2.png","pwrb_3.png","pwrb_4.png","pwrb_5.png","pwrb_6.png","pwrb_7.png","pwrb_8.png","pwrb_9.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
			
			normal_battery_text_text_img_1 = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 274,
              y: 95,
              font_array: ["pwrw_0.png","pwrw_1.png","pwrw_2.png","pwrw_3.png","pwrw_4.png","pwrw_5.png","pwrw_6.png","pwrw_7.png","pwrw_8.png","pwrw_9.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 184,
              y: 380,
              font_array: ["secb_0.png","secb_1.png","secb_2.png","secb_3.png","secb_4.png","secb_5.png","secb_6.png","secb_7.png","secb_8.png","secb_9.png"],
              padding: false,
              h_space: 0,
              invalid_image: '72.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
			
			normal_step_current_text_img_1 = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 184,
              y: 380,
              font_array: ["secw_0.png","secw_1.png","secw_2.png","secw_3.png","secw_4.png","secw_5.png","secw_6.png","secw_7.png","secw_8.png","secw_9.png"],
              padding: false,
              h_space: 0,
              invalid_image: '72.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_calorie_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 74,
              y: 316,
              font_array: ["secb_0.png","secb_1.png","secb_2.png","secb_3.png","secb_4.png","secb_5.png","secb_6.png","secb_7.png","secb_8.png","secb_9.png"],
              padding: false,
              h_space: 0,
              invalid_image: '73.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
			
			normal_calorie_current_text_img_1 = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 74,
              y: 316,
              font_array: ["secw_0.png","secw_1.png","secw_2.png","secw_3.png","secw_4.png","secw_5.png","secw_6.png","secw_7.png","secw_8.png","secw_9.png"],
              padding: false,
              h_space: 0,
              invalid_image: '73.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 319,
              y: 316,
              font_array: ["secb_0.png","secb_1.png","secb_2.png","secb_3.png","secb_4.png","secb_5.png","secb_6.png","secb_7.png","secb_8.png","secb_9.png"],
              padding: false,
              h_space: 0,
              invalid_image: '74.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
			
			normal_heart_rate_text_text_img_1 = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 319,
              y: 316,
              font_array: ["secw_0.png","secw_1.png","secw_2.png","secw_3.png","secw_4.png","secw_5.png","secw_6.png","secw_7.png","secw_8.png","secw_9.png"],
              padding: false,
              h_space: 0,
              invalid_image: '74.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_distance_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 192,
              y: 316,
              font_array: ["secb_0.png","secb_1.png","secb_2.png","secb_3.png","secb_4.png","secb_5.png","secb_6.png","secb_7.png","secb_8.png","secb_9.png"],
              padding: false,
              h_space: 0,
              invalid_image: '75.png',
              dot_image: 'dotb.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.DISTANCE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
			
			normal_distance_text_text_img_1 = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 192,
              y: 316,
              font_array: ["secw_0.png","secw_1.png","secw_2.png","secw_3.png","secw_4.png","secw_5.png","secw_6.png","secw_7.png","secw_8.png","secw_9.png"],
              padding: false,
              h_space: 0,
              invalid_image: '75.png',
              dot_image: 'dotw.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.DISTANCE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 312,
              y: 378,
              src: 'clock.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 125,
              y: 380,
              src: 'bts.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            console.log('Watch_Face.ScreenAOD');
            idle_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 466,
              h: 466,
              src: '79.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 60,
              hour_startY: 149,
              hour_array: ["80.png","81.png","82.png","83.png","84.png","85.png","86.png","87.png","88.png","89.png"],
              hour_zero: 1,
              hour_space: 0,
              hour_angle: 0,
              hour_align: hmUI.align.LEFT,

              minute_startX: 265,
              minute_startY: 149,
              minute_array: ["90.png","91.png","92.png","93.png","94.png","95.png","96.png","97.png","98.png","99.png"],
              minute_zero: 1,
              minute_space: 0,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_AOD,
            });
            console.log('Watch_Face.Shortcuts');

            normal_step_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 189,
              y: 330,
              w: 97,
              h: 97,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_cal_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 73,
              y: 306,
              w: 78,
              h: 78,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 311,
              y: 306,
              w: 78,
              h: 78,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            btn_zona1 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 107,
              y: 165,
              text: '',
              w: 117,
              h: 117,
              normal_src: 'Empty.png',
              press_src: 'Empty.png',
              click_func: () => {
				click_zona1();
             },
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            btn_zona1.setProperty(hmUI.prop.VISIBLE, true);
			normal_pai_icon_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_digital_clock_img_time_1.setProperty(hmUI.prop.VISIBLE, false);
			normal_digital_clock_img_time_AmPm_1.setProperty(hmUI.prop.VISIBLE, false);
			normal_date_img_date_day_1.setProperty(hmUI.prop.VISIBLE, false);
			normal_date_img_date_week_img_1.setProperty(hmUI.prop.VISIBLE, false);
			normal_battery_image_progress_img_level_1.setProperty(hmUI.prop.VISIBLE, false);
			normal_battery_text_text_img_1.setProperty(hmUI.prop.VISIBLE, false);
			normal_step_current_text_img_1.setProperty(hmUI.prop.VISIBLE, false);
			normal_calorie_current_text_img_1.setProperty(hmUI.prop.VISIBLE, false);
			normal_heart_rate_text_text_img_1.setProperty(hmUI.prop.VISIBLE, false);
			normal_distance_text_text_img_1.setProperty(hmUI.prop.VISIBLE, false);

            normal_battery_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 286,
              y: 68,
              w: 78,
              h: 68,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_countdown_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 282,
              y: 150,
              w: 97,
              h: 97,
              type: hmUI.data_type.COUNT_DOWN,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_stopwatch_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 350,
              y: 252,
              w: 73,
              h: 49,
              type: hmUI.data_type.STOP_WATCH,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            console.log('Watch_Face.Buttons');
            Button_1 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 87,
              y: 73,
              w: 97,
              h: 58,
              text: '',
              color: 0xFFFF8C00,
              text_size: 24,
              press_src: 'Empty.png',
              normal_src: 'Empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'ScheduleCalScreen', native: true });
              }, // end func
              longpress_func: (button_widget) => {
                hmApp.startApp({url: 'todoListScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button


                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}