﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.0.1
    ** Copyright © CashaCX75. All Rights Reserved
    */

    try {
    (()=>{
        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_humidity_text_text_img = ''
        let normal_temperature_high_text_img = ''
        let normal_temperature_low_text_img = ''
        let normal_temperature_current_text_img = ''
        let normal_heart_rate_text_text_img = ''
        let normal_pai_day_text_img = ''
        let normal_step_current_text_img = ''
        let normal_step_image_progress_img_level = ''
        let normal_date_img_date_month = ''
        let normal_date_img_date_day = ''
        let normal_battery_text_text_img = ''
        let normal_digital_clock_img_time = ''
        let idle_background_bg_img = ''
        let idle_date_img_date_month = ''
        let idle_date_img_date_day = ''
        let idle_battery_text_text_img = ''
        let idle_digital_clock_img_time = ''


        //dynamic modify end
        const e = __$$hmAppManager$$__.currentApp;
        const o = e.current
          , {px: i} = (new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(e,o)),
        e.__globals__)
          , n = Logger.getLogger("watchface6");
        o.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 466,
              h: 466,
              src: 'GTR4_80s_Bckg.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_humidity_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 290,
              y: 329,
              font_array: ["SP_Small_White_0.png","SP_Small_White_1.png","SP_Small_White_2.png","SP_Small_White_3.png","SP_Small_White_4.png","SP_Small_White_5.png","SP_Small_White_6.png","SP_Small_White_7.png","SP_Small_White_8.png","SP_Small_White_9.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'SP_Small_White_Perc.png',
              unit_tc: 'SP_Small_White_Perc.png',
              unit_en: 'SP_Small_White_Perc.png',
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.HUMIDITY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_high_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 290,
              y: 360,
              font_array: ["SP_Small_White_0.png","SP_Small_White_1.png","SP_Small_White_2.png","SP_Small_White_3.png","SP_Small_White_4.png","SP_Small_White_5.png","SP_Small_White_6.png","SP_Small_White_7.png","SP_Small_White_8.png","SP_Small_White_9.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'SP_Small_White_Deg.png',
              unit_tc: 'SP_Small_White_Deg.png',
              unit_en: 'SP_Small_White_Deg.png',
              negative_image: 'SP_Small_White_Minus.png',
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.WEATHER_HIGH,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_low_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 290,
              y: 391,
              font_array: ["SP_Small_White_0.png","SP_Small_White_1.png","SP_Small_White_2.png","SP_Small_White_3.png","SP_Small_White_4.png","SP_Small_White_5.png","SP_Small_White_6.png","SP_Small_White_7.png","SP_Small_White_8.png","SP_Small_White_9.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'SP_Small_White_Deg.png',
              unit_tc: 'SP_Small_White_Deg.png',
              unit_en: 'SP_Small_White_Deg.png',
              negative_image: 'SP_Small_White_Minus.png',
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.WEATHER_LOW,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 112,
              y: 351,
              font_array: ["SP_Mid_White_0.png","SP_Mid_White_1.png","SP_Mid_White_2.png","SP_Mid_White_3.png","SP_Mid_White_4.png","SP_Mid_White_5.png","SP_Mid_White_6.png","SP_Mid_White_7.png","SP_Mid_White_8.png","SP_Mid_White_9.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'SP_Mid_White_Deg.png',
              unit_tc: 'SP_Mid_White_Deg.png',
              unit_en: 'SP_Mid_White_Deg.png',
              negative_image: 'SP_Mid_White_Minus.png',
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 315,
              y: 119,
              font_array: ["SP_Mid_White_0.png","SP_Mid_White_1.png","SP_Mid_White_2.png","SP_Mid_White_3.png","SP_Mid_White_4.png","SP_Mid_White_5.png","SP_Mid_White_6.png","SP_Mid_White_7.png","SP_Mid_White_8.png","SP_Mid_White_9.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_pai_day_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 315,
              y: 72,
              font_array: ["SP_Mid_White_0.png","SP_Mid_White_1.png","SP_Mid_White_2.png","SP_Mid_White_3.png","SP_Mid_White_4.png","SP_Mid_White_5.png","SP_Mid_White_6.png","SP_Mid_White_7.png","SP_Mid_White_8.png","SP_Mid_White_9.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.PAI_DAILY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 127,
              y: 70,
              font_array: ["SP_Mid_Red_0.png","SP_Mid_Red_1.png","SP_Mid_Red_2.png","SP_Mid_Red_3.png","SP_Mid_Red_4.png","SP_Mid_Red_5.png","SP_Mid_Red_6.png","SP_Mid_Red_7.png","SP_Mid_Red_8.png","SP_Mid_Red_9.png"],
              padding: false,
              h_space: 3,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 41,
              y: 117,
              image_array: ["Batt_NC_0.png","Batt_NC_1.png","Batt_NC_2.png","Batt_NC_3.png","Batt_NC_4.png","Batt_NC_5.png","Batt_NC_6.png"],
              image_length: 7,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_month = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 95,
              month_startY: 221,
              month_sc_array: ["SP_Mid_White_0.png","SP_Mid_White_1.png","SP_Mid_White_2.png","SP_Mid_White_3.png","SP_Mid_White_4.png","SP_Mid_White_5.png","SP_Mid_White_6.png","SP_Mid_White_7.png","SP_Mid_White_8.png","SP_Mid_White_9.png"],
              month_tc_array: ["SP_Mid_White_0.png","SP_Mid_White_1.png","SP_Mid_White_2.png","SP_Mid_White_3.png","SP_Mid_White_4.png","SP_Mid_White_5.png","SP_Mid_White_6.png","SP_Mid_White_7.png","SP_Mid_White_8.png","SP_Mid_White_9.png"],
              month_en_array: ["SP_Mid_White_0.png","SP_Mid_White_1.png","SP_Mid_White_2.png","SP_Mid_White_3.png","SP_Mid_White_4.png","SP_Mid_White_5.png","SP_Mid_White_6.png","SP_Mid_White_7.png","SP_Mid_White_8.png","SP_Mid_White_9.png"],
              month_zero: 1,
              month_space: 3,
              month_align: hmUI.align.LEFT,
              month_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 95,
              day_startY: 171,
              day_sc_array: ["SP_Mid_White_0.png","SP_Mid_White_1.png","SP_Mid_White_2.png","SP_Mid_White_3.png","SP_Mid_White_4.png","SP_Mid_White_5.png","SP_Mid_White_6.png","SP_Mid_White_7.png","SP_Mid_White_8.png","SP_Mid_White_9.png"],
              day_tc_array: ["SP_Mid_White_0.png","SP_Mid_White_1.png","SP_Mid_White_2.png","SP_Mid_White_3.png","SP_Mid_White_4.png","SP_Mid_White_5.png","SP_Mid_White_6.png","SP_Mid_White_7.png","SP_Mid_White_8.png","SP_Mid_White_9.png"],
              day_en_array: ["SP_Mid_White_0.png","SP_Mid_White_1.png","SP_Mid_White_2.png","SP_Mid_White_3.png","SP_Mid_White_4.png","SP_Mid_White_5.png","SP_Mid_White_6.png","SP_Mid_White_7.png","SP_Mid_White_8.png","SP_Mid_White_9.png"],
              day_zero: 1,
              day_space: 3,
              day_align: hmUI.align.LEFT,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 328,
              y: 169,
              font_array: ["SP_Mid_White_0.png","SP_Mid_White_1.png","SP_Mid_White_2.png","SP_Mid_White_3.png","SP_Mid_White_4.png","SP_Mid_White_5.png","SP_Mid_White_6.png","SP_Mid_White_7.png","SP_Mid_White_8.png","SP_Mid_White_9.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'SP_Mid_White_Perc.png',
              unit_tc: 'SP_Mid_White_Perc.png',
              unit_en: 'SP_Mid_White_Perc.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 170,
              hour_startY: 230,
              hour_array: ["SP_Big_Green_0.png","SP_Big_Green_1.png","SP_Big_Green_2.png","SP_Big_Green_3.png","SP_Big_Green_4.png","SP_Big_Green_5.png","SP_Big_Green_6.png","SP_Big_Green_7.png","SP_Big_Green_8.png","SP_Big_Green_9.png"],
              hour_zero: 1,
              hour_space: 8,
              hour_unit_sc: 'SP_Big_Green_DDot.png',
              hour_unit_tc: 'SP_Big_Green_DDot.png',
              hour_unit_en: 'SP_Big_Green_DDot.png',
              hour_align: hmUI.align.LEFT,

              minute_startX: 0,
              minute_startY: 0,
              minute_array: ["SP_Big_Green_0.png","SP_Big_Green_1.png","SP_Big_Green_2.png","SP_Big_Green_3.png","SP_Big_Green_4.png","SP_Big_Green_5.png","SP_Big_Green_6.png","SP_Big_Green_7.png","SP_Big_Green_8.png","SP_Big_Green_9.png"],
              minute_zero: 1,
              minute_space: 8,
              minute_follow: 1,
              minute_align: hmUI.align.LEFT,

              second_startX: 95,
              second_startY: 275,
              second_array: ["SP_Mid_Red_0.png","SP_Mid_Red_1.png","SP_Mid_Red_2.png","SP_Mid_Red_3.png","SP_Mid_Red_4.png","SP_Mid_Red_5.png","SP_Mid_Red_6.png","SP_Mid_Red_7.png","SP_Mid_Red_8.png","SP_Mid_Red_9.png"],
              second_zero: 1,
              second_space: 3,
              second_follow: 0,
              second_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            idle_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 466,
              h: 466,
              src: 'GTR4_80s_Bckg_AOD.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_month = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 95,
              month_startY: 221,
              month_sc_array: ["SP_Mid_White_0.png","SP_Mid_White_1.png","SP_Mid_White_2.png","SP_Mid_White_3.png","SP_Mid_White_4.png","SP_Mid_White_5.png","SP_Mid_White_6.png","SP_Mid_White_7.png","SP_Mid_White_8.png","SP_Mid_White_9.png"],
              month_tc_array: ["SP_Mid_White_0.png","SP_Mid_White_1.png","SP_Mid_White_2.png","SP_Mid_White_3.png","SP_Mid_White_4.png","SP_Mid_White_5.png","SP_Mid_White_6.png","SP_Mid_White_7.png","SP_Mid_White_8.png","SP_Mid_White_9.png"],
              month_en_array: ["SP_Mid_White_0.png","SP_Mid_White_1.png","SP_Mid_White_2.png","SP_Mid_White_3.png","SP_Mid_White_4.png","SP_Mid_White_5.png","SP_Mid_White_6.png","SP_Mid_White_7.png","SP_Mid_White_8.png","SP_Mid_White_9.png"],
              month_zero: 1,
              month_space: 3,
              month_align: hmUI.align.LEFT,
              month_is_character: false,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 95,
              day_startY: 171,
              day_sc_array: ["SP_Mid_White_0.png","SP_Mid_White_1.png","SP_Mid_White_2.png","SP_Mid_White_3.png","SP_Mid_White_4.png","SP_Mid_White_5.png","SP_Mid_White_6.png","SP_Mid_White_7.png","SP_Mid_White_8.png","SP_Mid_White_9.png"],
              day_tc_array: ["SP_Mid_White_0.png","SP_Mid_White_1.png","SP_Mid_White_2.png","SP_Mid_White_3.png","SP_Mid_White_4.png","SP_Mid_White_5.png","SP_Mid_White_6.png","SP_Mid_White_7.png","SP_Mid_White_8.png","SP_Mid_White_9.png"],
              day_en_array: ["SP_Mid_White_0.png","SP_Mid_White_1.png","SP_Mid_White_2.png","SP_Mid_White_3.png","SP_Mid_White_4.png","SP_Mid_White_5.png","SP_Mid_White_6.png","SP_Mid_White_7.png","SP_Mid_White_8.png","SP_Mid_White_9.png"],
              day_zero: 1,
              day_space: 3,
              day_align: hmUI.align.LEFT,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 328,
              y: 169,
              font_array: ["SP_Mid_White_0.png","SP_Mid_White_1.png","SP_Mid_White_2.png","SP_Mid_White_3.png","SP_Mid_White_4.png","SP_Mid_White_5.png","SP_Mid_White_6.png","SP_Mid_White_7.png","SP_Mid_White_8.png","SP_Mid_White_9.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'SP_Mid_White_Perc.png',
              unit_tc: 'SP_Mid_White_Perc.png',
              unit_en: 'SP_Mid_White_Perc.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 170,
              hour_startY: 230,
              hour_array: ["SP_Big_Green_0.png","SP_Big_Green_1.png","SP_Big_Green_2.png","SP_Big_Green_3.png","SP_Big_Green_4.png","SP_Big_Green_5.png","SP_Big_Green_6.png","SP_Big_Green_7.png","SP_Big_Green_8.png","SP_Big_Green_9.png"],
              hour_zero: 1,
              hour_space: 8,
              hour_unit_sc: 'SP_Big_Green_DDot.png',
              hour_unit_tc: 'SP_Big_Green_DDot.png',
              hour_unit_en: 'SP_Big_Green_DDot.png',
              hour_align: hmUI.align.LEFT,

              minute_startX: 0,
              minute_startY: 0,
              minute_array: ["SP_Big_Green_0.png","SP_Big_Green_1.png","SP_Big_Green_2.png","SP_Big_Green_3.png","SP_Big_Green_4.png","SP_Big_Green_5.png","SP_Big_Green_6.png","SP_Big_Green_7.png","SP_Big_Green_8.png","SP_Big_Green_9.png"],
              minute_zero: 1,
              minute_space: 8,
              minute_follow: 1,
              minute_align: hmUI.align.LEFT,

              second_startX: 95,
              second_startY: 275,
              second_array: ["SP_Mid_Red_0.png","SP_Mid_Red_1.png","SP_Mid_Red_2.png","SP_Mid_Red_3.png","SP_Mid_Red_4.png","SP_Mid_Red_5.png","SP_Mid_Red_6.png","SP_Mid_Red_7.png","SP_Mid_Red_8.png","SP_Mid_Red_9.png"],
              second_zero: 1,
              second_space: 3,
              second_follow: 0,
              second_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_AOD,
            });


                //dynamic modify end
            },
            onInit() {
                n.log("index page.js on init invoke")
            },
            build() {
                this.init_view(),
                n.log("index page.js on ready invoke")
            },
            onDestroy() {
                n.log("index page.js on destroy invoke")
            }
        })
    }
    )()
} catch (e) {
    console.log("Mini Program Error", e),
    e && e.stack && e.stack.split(/\n/).forEach((e=>console.log("error stack", e)))
}
