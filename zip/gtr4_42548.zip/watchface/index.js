﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        const logger = Logger.getLogger('watchface_SashaCX75');
        //end of ignored block

        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_stress_text_text_img = ''
        let normal_stress_image_progress_img_progress = ''
        let normal_spo2_icon_img = ''
        let normal_spo2_text_text_img = ''
        let normal_calorie_icon_img = ''
        let normal_calorie_current_text_img = ''
        let normal_distance_icon_img = ''
        let normal_distance_text_text_img = ''
        let normal_system_disconnect_img = ''
        let normal_system_clock_img = ''
        let normal_battery_text_text_img = ''
        let normal_battery_text_separator_img = ''
        let normal_heart_rate_text_text_img = ''
        let normal_heart_rate_text_separator_img = ''
        let normal_date_img_date_month = ''
        let normal_date_img_date_day = ''
        let normal_temperature_current_text_img = ''
        let normal_step_current_text_img = ''
        let normal_step_current_separator_img = ''
        let normal_date_img_date_week_img = ''
        let normal_analog_clock_time_pointer_hour = ''
        let normal_analog_clock_time_pointer_minute = ''
        let normal_analog_clock_time_pointer_second = ''
        let normal_digital_clock_img_time = ''
        let idle_background_bg = ''
        let idle_temperature_current_text_img = ''
        let idle_date_img_date_week_img = ''
        let idle_date_img_date_month = ''
        let idle_date_img_date_day = ''
        let idle_battery_text_text_img = ''
        let idle_battery_text_separator_img = ''
        let idle_system_disconnect_img = ''
        let idle_digital_clock_img_time = ''
        let normal_temperature_jumpable_img_click = ''
        let normal_step_jumpable_img_click = ''
        let normal_alarm_jumpable_img_click = ''
        let normal_heart_jumpable_img_click = ''
        let normal_stopwatch_jumpable_img_click = ''
        let normal_countdown_jumpable_img_click = ''
        let normal_stress_jumpable_img_click = ''
        let normal_spo2_jumpable_img_click = ''
        let Button_1 = ''
        let Button_2 = ''
        let Button_3 = ''
        let Button_4 = ''
        let Button_5 = ''
        let Button_6 = ''
        let Button_7 = ''


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 466,
              h: 466,
              src: 'bg_1b.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_stress_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 345,
              y: 277,
              font_array: ["s_00.png","s_01.png","s_02.png","s_03.png","s_04.png","s_05.png","s_06.png","s_07.png","s_08.png","s_09.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.STRESS,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_stress_image_progress_img_progress = hmUI.createWidget(hmUI.widget.IMG_PROGRESS, {
              x: [315,315,315,315],
              y: [278,278,278,278],
              image_array: ["strs_p_0.png","strs_p_1.png","strs_p_2.png","strs_p_3.png"],
              image_length: 4,
              type: hmUI.data_type.STRESS,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_spo2_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 313,
              y: 186,
              src: 'o22.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_spo2_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 346,
              y: 184,
              font_array: ["s_00.png","s_01.png","s_02.png","s_03.png","s_04.png","s_05.png","s_06.png","s_07.png","s_08.png","s_09.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.SPO2,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_calorie_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 314,
              y: 214,
              src: 'calorias.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_calorie_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 345,
              y: 212,
              font_array: ["s_00.png","s_01.png","s_02.png","s_03.png","s_04.png","s_05.png","s_06.png","s_07.png","s_08.png","s_09.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_distance_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 54,
              y: 275,
              src: 'Distancia.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_distance_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 84,
              y: 275,
              font_array: ["s_00.png","s_01.png","s_02.png","s_03.png","s_04.png","s_05.png","s_06.png","s_07.png","s_08.png","s_09.png"],
              padding: false,
              h_space: 0,
              dot_image: 's_sep.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.DISTANCE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 331,
              y: 132,
              src: 'i_bt2.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 117,
              y: 141,
              src: 'i_alarm.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 209,
              y: 368,
              font_array: ["s_00.png","s_01.png","s_02.png","s_03.png","s_04.png","s_05.png","s_06.png","s_07.png","s_08.png","s_09.png"],
              padding: false,
              h_space: 0,
              unit_sc: 's_perc.png',
              unit_tc: 's_perc.png',
              unit_en: 's_perc.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 182,
              y: 367,
              src: 'i_batt.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 347,
              y: 247,
              font_array: ["s_00.png","s_01.png","s_02.png","s_03.png","s_04.png","s_05.png","s_06.png","s_07.png","s_08.png","s_09.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 314,
              y: 248,
              src: 'i_bpm.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_month = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 242,
              month_startY: 154,
              month_sc_array: ["s_00.png","s_01.png","s_02.png","s_03.png","s_04.png","s_05.png","s_06.png","s_07.png","s_08.png","s_09.png"],
              month_tc_array: ["s_00.png","s_01.png","s_02.png","s_03.png","s_04.png","s_05.png","s_06.png","s_07.png","s_08.png","s_09.png"],
              month_en_array: ["s_00.png","s_01.png","s_02.png","s_03.png","s_04.png","s_05.png","s_06.png","s_07.png","s_08.png","s_09.png"],
              month_zero: 1,
              month_space: 0,
              month_align: hmUI.align.LEFT,
              month_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 191,
              day_startY: 154,
              day_sc_array: ["s_00.png","s_01.png","s_02.png","s_03.png","s_04.png","s_05.png","s_06.png","s_07.png","s_08.png","s_09.png"],
              day_tc_array: ["s_00.png","s_01.png","s_02.png","s_03.png","s_04.png","s_05.png","s_06.png","s_07.png","s_08.png","s_09.png"],
              day_en_array: ["s_00.png","s_01.png","s_02.png","s_03.png","s_04.png","s_05.png","s_06.png","s_07.png","s_08.png","s_09.png"],
              day_zero: 1,
              day_space: 0,
              day_unit_sc: 's_sep.png',
              day_unit_tc: 's_sep.png',
              day_unit_en: 's_sep.png',
              day_align: hmUI.align.LEFT,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 199,
              y: 83,
              font_array: ["s_00.png","s_01.png","s_02.png","s_03.png","s_04.png","s_05.png","s_06.png","s_07.png","s_08.png","s_09.png"],
              padding: false,
              h_space: -5,
              unit_sc: 's_sep2.png',
              unit_tc: 's_sep2.png',
              unit_en: 's_sep2.png',
              negative_image: 's_minus.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 79,
              y: 247,
              font_array: ["s_00.png","s_01.png","s_02.png","s_03.png","s_04.png","s_05.png","s_06.png","s_07.png","s_08.png","s_09.png"],
              padding: false,
              h_space: -3,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 55,
              y: 244,
              src: 'i_steps.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 174,
              y: 111,
              week_en: ["w_pl_00.png","w_pl_01.png","w_pl_02.png","w_pl_03.png","w_pl_04.png","w_pl_05.png","w_pl_06.png"],
              week_tc: ["w_pl_00.png","w_pl_01.png","w_pl_02.png","w_pl_03.png","w_pl_04.png","w_pl_05.png","w_pl_06.png"],
              week_sc: ["w_pl_00.png","w_pl_01.png","w_pl_02.png","w_pl_03.png","w_pl_04.png","w_pl_05.png","w_pl_06.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_hour = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              hour_path: 'hour_hand.png',
              hour_centerX: 235,
              hour_centerY: 235,
              hour_posX: 15,
              hour_posY: 105,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_minute = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              minute_path: 'minute_hand.png',
              minute_centerX: 235,
              minute_centerY: 235,
              minute_posX: 18,
              minute_posY: 213,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_second = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              second_path: 'sec_hand.png',
              second_centerX: 235,
              second_centerY: 235,
              second_posX: 20,
              second_posY: 238,
              second_cover_path: 'dot.png',
              second_cover_x: 218,
              second_cover_y: 218,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 126,
              hour_startY: 311,
              hour_array: ["n_00.png","n_01.png","n_02.png","n_03.png","n_04.png","n_05.png","n_06.png","n_07.png","n_08.png","n_09.png"],
              hour_zero: 1,
              hour_space: -4,
              hour_angle: 0,
              hour_unit_sc: 'n_dots.png',
              hour_unit_tc: 'n_dots.png',
              hour_unit_en: 'n_dots.png',
              hour_align: hmUI.align.LEFT,

              minute_startX: 0,
              minute_startY: 0,
              minute_array: ["n_00.png","n_01.png","n_02.png","n_03.png","n_04.png","n_05.png","n_06.png","n_07.png","n_08.png","n_09.png"],
              minute_zero: 1,
              minute_space: 0,
              minute_angle: 0,
              minute_follow: 1,
              minute_align: hmUI.align.LEFT,

              second_startX: 324,
              second_startY: 333,
              second_array: ["s_00.png","s_01.png","s_02.png","s_03.png","s_04.png","s_05.png","s_06.png","s_07.png","s_08.png","s_09.png"],
              second_zero: 1,
              second_space: 0,
              second_angle: 0,
              second_follow: 0,
              second_align: hmUI.align.CENTER_H,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            idle_background_bg = hmUI.createWidget(hmUI.widget.FILL_RECT, {
              x: 0,
              y: 0,
              w: 466,
              h: 466,
              color: '0xFF000000',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 215,
              y: 117,
              font_array: ["s_00.png","s_01.png","s_02.png","s_03.png","s_04.png","s_05.png","s_06.png","s_07.png","s_08.png","s_09.png"],
              padding: false,
              h_space: 0,
              unit_sc: 's_sep2.png',
              unit_tc: 's_sep2.png',
              unit_en: 's_sep2.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 176,
              y: 200,
              week_en: ["w_pl_00.png","w_pl_01.png","w_pl_02.png","w_pl_03.png","w_pl_04.png","w_pl_05.png","w_pl_06.png"],
              week_tc: ["w_pl_00.png","w_pl_01.png","w_pl_02.png","w_pl_03.png","w_pl_04.png","w_pl_05.png","w_pl_06.png"],
              week_sc: ["w_pl_00.png","w_pl_01.png","w_pl_02.png","w_pl_03.png","w_pl_04.png","w_pl_05.png","w_pl_06.png"],
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_month = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 261,
              month_startY: 167,
              month_sc_array: ["s_00.png","s_01.png","s_02.png","s_03.png","s_04.png","s_05.png","s_06.png","s_07.png","s_08.png","s_09.png"],
              month_tc_array: ["s_00.png","s_01.png","s_02.png","s_03.png","s_04.png","s_05.png","s_06.png","s_07.png","s_08.png","s_09.png"],
              month_en_array: ["s_00.png","s_01.png","s_02.png","s_03.png","s_04.png","s_05.png","s_06.png","s_07.png","s_08.png","s_09.png"],
              month_zero: 1,
              month_space: 0,
              month_align: hmUI.align.LEFT,
              month_is_character: false,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 195,
              day_startY: 167,
              day_sc_array: ["s_00.png","s_01.png","s_02.png","s_03.png","s_04.png","s_05.png","s_06.png","s_07.png","s_08.png","s_09.png"],
              day_tc_array: ["s_00.png","s_01.png","s_02.png","s_03.png","s_04.png","s_05.png","s_06.png","s_07.png","s_08.png","s_09.png"],
              day_en_array: ["s_00.png","s_01.png","s_02.png","s_03.png","s_04.png","s_05.png","s_06.png","s_07.png","s_08.png","s_09.png"],
              day_zero: 1,
              day_space: 0,
              day_unit_sc: 's_sep.png',
              day_unit_tc: 's_sep.png',
              day_unit_en: 's_sep.png',
              day_align: hmUI.align.LEFT,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 226,
              y: 407,
              font_array: ["s_00.png","s_01.png","s_02.png","s_03.png","s_04.png","s_05.png","s_06.png","s_07.png","s_08.png","s_09.png"],
              padding: false,
              h_space: 0,
              unit_sc: 's_perc.png',
              unit_tc: 's_perc.png',
              unit_en: 's_perc.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_battery_text_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 201,
              y: 406,
              src: 'i_batt.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 222,
              y: 10,
              src: 'i_bt.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 152,
              hour_startY: 239,
              hour_array: ["n_00.png","n_01.png","n_02.png","n_03.png","n_04.png","n_05.png","n_06.png","n_07.png","n_08.png","n_09.png"],
              hour_zero: 1,
              hour_space: 0,
              hour_angle: 0,
              hour_unit_sc: 'n_dots.png',
              hour_unit_tc: 'n_dots.png',
              hour_unit_en: 'n_dots.png',
              hour_align: hmUI.align.LEFT,

              minute_startX: 275,
              minute_startY: 238,
              minute_array: ["n_00.png","n_01.png","n_02.png","n_03.png","n_04.png","n_05.png","n_06.png","n_07.png","n_08.png","n_09.png"],
              minute_zero: 1,
              minute_space: 0,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              second_startX: 363,
              second_startY: 262,
              second_array: ["s_00.png","s_01.png","s_02.png","s_03.png","s_04.png","s_05.png","s_06.png","s_07.png","s_08.png","s_09.png"],
              second_zero: 1,
              second_space: 0,
              second_angle: 0,
              second_follow: 0,
              second_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_AOD,
            });
            
            // disconnectAlert = hmUI.createWidget(hmUI.widget.DisconnectAlert, {
              // disconneсnt_vibrate_type: 9,
              // disconneсnt_toast_text: Bluetooth OFF,
              // conneсnt_vibrate_type: 9,
              // conneсnt_toast_text: Bluetooth ON,
            // });

            // vibration when connecting or disconnecting

            function checkConnection() {
              hmBle.removeListener;
              hmBle.addListener(function (status) {
                if(!status) {
                  hmUI.showToast({text: "Bluetooth OFF"});
                  vibro(9);
                }
                if(status) {
                  hmUI.showToast({text: "Bluetooth ON"});
                  vibro(9);
                }
              });
            }

            // end vibration when connecting or disconnecting
            // vibrate function

            const vibrate = hmSensor.createSensor(hmSensor.id.VIBRATE);
            let timer_StopVibrate = null;


            function vibro(scene = 25) {
              let stopDelay = 50;
              stopVibro();
              vibrate.stop();
              vibrate.scene = scene;
              if(scene < 23 || scene > 25) stopDelay = 1300;
              vibrate.start();
              timer_StopVibrate = timer.createTimer(stopDelay, 3000, stopVibro, {});
            }

            function stopVibro(){
              vibrate.stop();
              if(timer_StopVibrate) timer.stopTimer(timer_StopVibrate);
            }

            // end vibrate function

            normal_temperature_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 189,
              y: 78,
              w: 98,
              h: 44,
              src: 'clear.png',
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 55,
              y: 244,
              w: 98,
              h: 53,
              src: 'clear.png',
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_alarm_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 87,
              y: 125,
              w: 98,
              h: 68,
              src: 'clear.png',
              type: hmUI.data_type.ALARM_CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 299,
              y: 225,
              w: 99,
              h: 50,
              src: 'clear.png',
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_stopwatch_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 155,
              y: 404,
              w: 60,
              h: 50,
              src: 'transparent.png',
              type: hmUI.data_type.STOP_WATCH,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_countdown_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 251,
              y: 402,
              w: 57,
              h: 54,
              src: 'transparent.png',
              type: hmUI.data_type.COUNT_DOWN,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_stress_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 309,
              y: 276,
              w: 72,
              h: 43,
              src: 'transparent.png',
              type: hmUI.data_type.STRESS,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_spo2_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 303,
              y: 178,
              w: 91,
              h: 38,
              type: hmUI.data_type.SPO2,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            Button_1 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 78,
              y: 56,
              w: 58,
              h: 50,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'transparent.png',
              normal_src: 'transparent.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'SportListScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_2 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 64,
              y: 369,
              w: 58,
              h: 50,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'transparent.png',
              normal_src: 'transparent.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'PhoneHomeScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_3 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 197,
              y: 148,
              w: 89,
              h: 38,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'transparent.png',
              normal_src: 'transparent.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'ScheduleCalScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_4 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 206,
              y: 217,
              w: 61,
              h: 38,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'transparent.png',
              normal_src: 'transparent.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'VoiceMemoScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_5 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 403,
              y: 165,
              w: 61,
              h: 38,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'transparent.png',
              normal_src: 'transparent.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'DragListScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_6 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 344,
              y: 67,
              w: 61,
              h: 38,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'transparent.png',
              normal_src: 'transparent.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'AppListScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_7 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 403,
              y: 261,
              w: 61,
              h: 48,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'transparent.png',
              normal_src: 'transparent.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'MoreListScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                checkConnection();
                stopVibro();

              }),
              pause_call: (function () {
                stopVibro();

              }),
            });

                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}