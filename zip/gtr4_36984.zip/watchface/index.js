﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        const logger = Logger.getLogger('watchface_SashaCX75');
        //end of ignored block

        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_system_clock_img = ''
        let normal_temperature_current_text_img = ''
        let normal_weather_image_progress_img_level = ''
        let normal_battery_icon_img = ''
        let normal_battery_text_text_img = ''
        let normal_heart_rate_icon_img = ''
        let normal_heart_rate_text_text_img = ''
        let normal_step_icon_img = ''
        let normal_step_current_text_img = ''
        let normal_date_img_date_year = ''
        let normal_date_img_date_month = ''
        let normal_date_img_date_day = ''
        let normal_date_img_date_week_img = ''
        let normal_digital_clock_img_time_AmPm = ''
        let normal_digital_clock_img_time = ''
        let normal_digital_clock_hour_separator_img = ''
        let idle_background_bg = ''
        let idle_digital_clock_img_time_AmPm = ''
        let idle_digital_clock_img_time = ''
        let normal_alarm_jumpable_img_click = ''
        let normal_temperature_jumpable_img_click = ''
        let normal_heart_jumpable_img_click = ''
        let normal_step_jumpable_img_click = ''


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            console.log('Watch_Face.ScreenNormal');
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 466,
              h: 466,
              src: 'clean.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 63,
              y: 138,
              src: 'alarm.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 199,
              y: 346,
              font_array: ["digital7_0.png","digital7_1.png","digital7_2.png","digital7_3.png","digital7_4.png","digital7_5.png","digital7_6.png","digital7_7.png","digital7_8.png","digital7_9.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'celcius.png',
              unit_tc: 'celcius.png',
              unit_en: 'celcius.png',
              negative_image: 'minus.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 213,
              y: 300,
              image_array: ["0071.png","0072.png","0073.png","0074.png","0075.png","0076.png","0077.png","0078.png","0079.png","0080.png","0081.png","0082.png","0083.png","0084.png","0085.png","0086.png","0087.png","0088.png","0089.png","0090.png","0091.png","0092.png","0093.png","0094.png","0095.png","0096.png","0097.png","0098.png","0099.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 68,
              y: 194,
              src: 'image2.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 44,
              y: 233,
              font_array: ["digital7_0.png","digital7_1.png","digital7_2.png","digital7_3.png","digital7_4.png","digital7_5.png","digital7_6.png","digital7_7.png","digital7_8.png","digital7_9.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'digital7_11.png',
              unit_tc: 'digital7_11.png',
              unit_en: 'digital7_11.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 223,
              y: 289,
              src: 'heart.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 301,
              y: 323,
              font_array: ["digital7_0.png","digital7_1.png","digital7_2.png","digital7_3.png","digital7_4.png","digital7_5.png","digital7_6.png","digital7_7.png","digital7_8.png","digital7_9.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 29,
              y: 289,
              src: 'steps.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 89,
              y: 323,
              font_array: ["digital7_0.png","digital7_1.png","digital7_2.png","digital7_3.png","digital7_4.png","digital7_5.png","digital7_6.png","digital7_7.png","digital7_8.png","digital7_9.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_year = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              year_startX: 251,
              year_startY: 136,
              year_sc_array: ["digital2_0.png","digital2_1.png","digital2_2.png","digital2_3.png","digital2_4.png","digital2_5.png","digital2_6.png","digital2_7.png","digital2_8.png","digital2_9.png"],
              year_tc_array: ["digital2_0.png","digital2_1.png","digital2_2.png","digital2_3.png","digital2_4.png","digital2_5.png","digital2_6.png","digital2_7.png","digital2_8.png","digital2_9.png"],
              year_en_array: ["digital2_0.png","digital2_1.png","digital2_2.png","digital2_3.png","digital2_4.png","digital2_5.png","digital2_6.png","digital2_7.png","digital2_8.png","digital2_9.png"],
              year_zero: 1,
              year_space: 0,
              year_align: hmUI.align.LEFT,
              year_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_month = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 185,
              month_startY: 136,
              month_sc_array: ["digital2_0.png","digital2_1.png","digital2_2.png","digital2_3.png","digital2_4.png","digital2_5.png","digital2_6.png","digital2_7.png","digital2_8.png","digital2_9.png"],
              month_tc_array: ["digital2_0.png","digital2_1.png","digital2_2.png","digital2_3.png","digital2_4.png","digital2_5.png","digital2_6.png","digital2_7.png","digital2_8.png","digital2_9.png"],
              month_en_array: ["digital2_0.png","digital2_1.png","digital2_2.png","digital2_3.png","digital2_4.png","digital2_5.png","digital2_6.png","digital2_7.png","digital2_8.png","digital2_9.png"],
              month_zero: 1,
              month_space: 0,
              month_unit_sc: 'digital3_10.png',
              month_unit_tc: 'digital3_10.png',
              month_unit_en: 'digital3_10.png',
              month_align: hmUI.align.LEFT,
              month_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 119,
              day_startY: 136,
              day_sc_array: ["digital2_0.png","digital2_1.png","digital2_2.png","digital2_3.png","digital2_4.png","digital2_5.png","digital2_6.png","digital2_7.png","digital2_8.png","digital2_9.png"],
              day_tc_array: ["digital2_0.png","digital2_1.png","digital2_2.png","digital2_3.png","digital2_4.png","digital2_5.png","digital2_6.png","digital2_7.png","digital2_8.png","digital2_9.png"],
              day_en_array: ["digital2_0.png","digital2_1.png","digital2_2.png","digital2_3.png","digital2_4.png","digital2_5.png","digital2_6.png","digital2_7.png","digital2_8.png","digital2_9.png"],
              day_zero: 1,
              day_space: 0,
              day_unit_sc: 'digital3_10.png',
              day_unit_tc: 'digital3_10.png',
              day_unit_en: 'digital3_10.png',
              day_align: hmUI.align.LEFT,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 129,
              y: 95,
              week_en: ["digital9_1.png","digital9_2.png","digital9_3.png","digital9_4.png","digital9_5.png","digital9_6.png","digital9_7.png"],
              week_tc: ["digital9_1.png","digital9_2.png","digital9_3.png","digital9_4.png","digital9_5.png","digital9_6.png","digital9_7.png"],
              week_sc: ["digital9_1.png","digital9_2.png","digital9_3.png","digital9_4.png","digital9_5.png","digital9_6.png","digital9_7.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time_AmPm = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              am_x: 270,
              am_y: 193,
              am_sc_path: 'AM.png',
              am_en_path: 'AM.png',
              pm_x: 270,
              pm_y: 193,
              pm_sc_path: 'PM.png',
              pm_en_path: 'PM.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 119,
              hour_startY: 188,
              hour_array: ["digital1_0.png","digital1_1.png","digital1_2.png","digital1_3.png","digital1_4.png","digital1_5.png","digital1_6.png","digital1_7.png","digital1_8.png","digital1_9.png"],
              hour_zero: 1,
              hour_space: 0,
              hour_angle: 0,
              hour_unit_sc: 'digital1_10.png',
              hour_unit_tc: 'digital1_10.png',
              hour_unit_en: 'digital1_10.png',
              hour_align: hmUI.align.LEFT,

              minute_startX: 0,
              minute_startY: 0,
              minute_array: ["digital1_0.png","digital1_1.png","digital1_2.png","digital1_3.png","digital1_4.png","digital1_5.png","digital1_6.png","digital1_7.png","digital1_8.png","digital1_9.png"],
              minute_zero: 1,
              minute_space: 0,
              minute_angle: 0,
              minute_follow: 1,
              minute_align: hmUI.align.LEFT,

              second_startX: 354,
              second_startY: 234,
              second_array: ["digital2_0.png","digital2_1.png","digital2_2.png","digital2_3.png","digital2_4.png","digital2_5.png","digital2_6.png","digital2_7.png","digital2_8.png","digital2_9.png"],
              second_zero: 1,
              second_space: 0,
              second_angle: 0,
              second_follow: 0,
              second_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_hour_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 13,
              y: 11,
              src: 'image4.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            console.log('Watch_Face.ScreenAOD');
            idle_background_bg = hmUI.createWidget(hmUI.widget.FILL_RECT, {
              x: 0,
              y: 0,
              w: 466,
              h: 466,
              color: '0xFF000000',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time_AmPm = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              am_x: 270,
              am_y: 193,
              am_sc_path: 'AM_aod.png',
              am_en_path: 'AM_aod.png',
              pm_x: 270,
              pm_y: 193,
              pm_sc_path: 'PM_aod.png',
              pm_en_path: 'PM_aod.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 119,
              hour_startY: 188,
              hour_array: ["digital1_aod_0.png","digital1_aod_1.png","digital1_aod_2.png","digital1_aod_3.png","digital1_aod_4.png","digital1_aod_5.png","digital1_aod_6.png","digital1_aod_7.png","digital1_aod_8.png","digital1_aod_9.png"],
              hour_zero: 1,
              hour_space: 0,
              hour_angle: 0,
              hour_unit_sc: 'digital1_aod_10.png',
              hour_unit_tc: 'digital1_aod_10.png',
              hour_unit_en: 'digital1_aod_10.png',
              hour_align: hmUI.align.LEFT,

              minute_startX: 0,
              minute_startY: 0,
              minute_array: ["digital1_aod_0.png","digital1_aod_1.png","digital1_aod_2.png","digital1_aod_3.png","digital1_aod_4.png","digital1_aod_5.png","digital1_aod_6.png","digital1_aod_7.png","digital1_aod_8.png","digital1_aod_9.png"],
              minute_zero: 1,
              minute_space: 0,
              minute_angle: 0,
              minute_follow: 1,
              minute_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_AOD,
            });
            console.log('Watch_Face.Shortcuts');

            normal_alarm_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 39,
              y: 119,
              w: 97,
              h: 58,
              src: 'shortcut.png',
              type: hmUI.data_type.ALARM_CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 186,
              y: 300,
              w: 97,
              h: 97,
              src: 'shortcut.png',
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 290,
              y: 275,
              w: 97,
              h: 97,
              src: 'shortcut.png',
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 82,
              y: 275,
              w: 97,
              h: 97,
              src: 'shortcut.png',
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}