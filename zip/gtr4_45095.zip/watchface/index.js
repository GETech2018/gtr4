﻿    /*
    ** Watch_Face_Editor tool v 18.1
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        //const logger = Logger.getLogger('watchface_SashaCX75');
        const logger = DeviceRuntimeCore.HmLogger.getLogger('watchface_SashaCX75')
        //end of ignored block

        //dynamic modify start

        
        console.log('user_functions.js');
        // start user_functions.js

let time24 = hmSensor.createSensor(hmSensor.id.TIME);
let normal_24Hcheck =''
let idle_24Hcheck = ''
let checknum = ''
let txtsize = 59

 function check24h(){
       if (time24.is24Hour){
        checknum = 1
        is24H()
       }

       if (!time24.is24Hour){
       checknum = 2
       isAMPM()
       }
hmFS.SysProSetInt('ampm24h', checknum);
 }

function is24H(){
        normal_24Hcheck.setProperty(hmUI.prop.VISIBLE, true);
        idle_24Hcheck.setProperty(hmUI.prop.VISIBLE, true);

}

function isAMPM(){
        normal_24Hcheck.setProperty(hmUI.prop.VISIBLE, false);
        idle_24Hcheck.setProperty(hmUI.prop.VISIBLE, false);

}


// ---------------------------

let colorswitch = ['0xFFFFFFFF' , '0xFF94FF00' , '0xFFFFF600' , '0xFFFF6600' , '0xFFFF0000' , '0xFFFF007B' , '0xFF0099FF' , '0xFF00FFE9' , '0xFFB5B5B5'];

        // Seconds on off
        let elementnumber_1 = 1
        let total_elemente = 2

        function secondsONOFF() {
            if(elementnumber_1==total_elemente) {
            elementnumber_1=1;
                UpdateElementeOne();
                }
            else {
                elementnumber_1=elementnumber_1+1;
                if(elementnumber_1==2) {
                  UpdateElementeTwo();
                }

            }
         //   if(elementnumber_1==1) hmUI.showToast({text: 'Seconds ON'});
       //    if(elementnumber_1==2) hmUI.showToast({text: 'Seconds OFF'});
        }

        //Seconds on 
        function UpdateElementeOne(){

        normal_time_hour_min_sec_text_font.setProperty(hmUI.prop.VISIBLE, true);
        normal_time_hour_min_text_font.setProperty(hmUI.prop.VISIBLE, false);

normal_image_img.setProperty(hmUI.prop.SRC, 'Seconds_on.png');

        }

        //Seconds off
        function UpdateElementeTwo(){

        normal_time_hour_min_sec_text_font.setProperty(hmUI.prop.VISIBLE, false);
        normal_time_hour_min_text_font.setProperty(hmUI.prop.VISIBLE, true);
normal_image_img.setProperty(hmUI.prop.SRC, 'Seconds_off.png');

        }

// -----------------------------------------------------------------------------------------------

       let elementnumber_2 = 1
        let total_elemente2 = 2

        function BigSmall() {
            if(elementnumber_2==total_elemente2) {
            elementnumber_2=1;
                UpdateElemente2One();
                }
            else {
                elementnumber_2=elementnumber_2+1;
                if(elementnumber_2==2) {
                  UpdateElemente2Two();
                }

            }
      //      if(elementnumber_2==1) hmUI.showToast({text: 'Big'});
      //      if(elementnumber_2==2) hmUI.showToast({text: 'Small'});
        }

        //Digital Big
        function UpdateElemente2One(){
txtsize =59
normal_time_hour_min_sec_text_font.setProperty(hmUI.prop.MORE, {
    x: 142,
    y: 162,
    w: 300,
    h: 60,
    text_size: txtsize,
    char_space: 0,
    font: 'fonts/BergenMono-SemiBold.ttf',
    color: colorswitch[backgroundIndex],
    line_space: 0,
    align_v: hmUI.align.CENTER_V,
    text_style: hmUI.text_style.ELLIPSIS,
    align_h: hmUI.align.LEFT,
    show_level: hmUI.show_level.ONLY_NORMAL,
});

normal_time_hour_min_text_font.setProperty(hmUI.prop.MORE, {
    x: 142,
    y: 162,
    w: 300,
    h: 60,
    text_size: txtsize,
    char_space: 0,
    font: 'fonts/BergenMono-SemiBold.ttf',
    color: colorswitch[backgroundIndex],
    line_space: 0,
    align_v: hmUI.align.CENTER_V,
    text_style: hmUI.text_style.ELLIPSIS,
    align_h: hmUI.align.LEFT,
    show_level: hmUI.show_level.ONLY_NORMAL,
});

normal_temperature_icon_img.setProperty(hmUI.prop.SRC, 'Time_Big.png');

        }

        //Digital Small
        function UpdateElemente2Two(){
txtsize = 39
normal_time_hour_min_sec_text_font.setProperty(hmUI.prop.MORE, {
    x: 142,
    y: 162,
    w: 300,
    h: 60,
    text_size: txtsize,
    char_space: 0,
    font: 'fonts/BergenMono-SemiBold.ttf',
    color: colorswitch[backgroundIndex],
    line_space: 0,
    align_v: hmUI.align.CENTER_V,
    text_style: hmUI.text_style.ELLIPSIS,
    align_h: hmUI.align.LEFT,
    show_level: hmUI.show_level.ONLY_NORMAL,
});

normal_time_hour_min_text_font.setProperty(hmUI.prop.MORE, {
    x: 142,
    y: 162,
    w: 300,
    h: 60,
    text_size: txtsize,
    char_space: 0,
    font: 'fonts/BergenMono-SemiBold.ttf',
    color: colorswitch[backgroundIndex],
    line_space: 0,
    align_v: hmUI.align.CENTER_V,
    text_style: hmUI.text_style.ELLIPSIS,
    align_h: hmUI.align.LEFT,
    show_level: hmUI.show_level.ONLY_NORMAL,
});

normal_temperature_icon_img.setProperty(hmUI.prop.SRC, 'Time_Small.png');
        }


        // end user_functions.js

        let normal_background_bg_img = ''
        let normal_heart_rate_text_font = ''
        let normal_calorie_current_text_font = ''
        let normal_step_current_text_font = ''
        let normal_image_img = ''
        let normal_temperature_icon_img = ''
        let normal_weather_image_progress_img_level = ''
        let normal_temperature_current_text_font = ''
        let normal_day_month_year_font = ''
        let normal_timerTimeUpdate = undefined;
        let normal_time_hour_min_sec_text_font = ''
        let normal_time_hour_min_text_font = ''
        let normal_digital_clock_img_time_AmPm = ''
        let idle_background_bg_img = ''
        let idle_heart_rate_text_font = ''
        let idle_calorie_current_text_font = ''
        let idle_step_current_text_font = ''
        let idle_image_img = ''
        let idle_temperature_icon_img = ''
        let idle_weather_image_progress_img_level = ''
        let idle_temperature_current_text_font = ''
        let idle_day_month_year_font = ''
        let idle_timerTimeUpdate = undefined;
        let idle_time_hour_min_sec_text_font = ''
        let idle_time_hour_min_text_font = ''
        let idle_digital_clock_img_time_AmPm = ''
        let Button_1 = ''
        let Button_2 = ''
        let Button_Switch_BG = ''

        let backgroundIndex = 0;
        let backgroundList = ['Bg1.png', 'Bg2.png', 'Bg3.png', 'Bg4.png', 'Bg5.png', 'Bg6.png', 'Bg7.png', 'Bg8.png', 'Bg9.png'];
        let backgroundToastList = ['Background %s', 'Background %s', 'Background %s', 'Background %s', 'Background %s', 'Background %s', 'Background %s', 'Background %s', 'Background %s'];
        const watchfaceId = hmApp.packageInfo().watchfaceId;
        let timeSensor = '';


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            // FontName: BergenMono-SemiBold.ttf; FontSize: 36
            hmUI.createWidget(hmUI.widget.TEXT, {
              x: 478,
              y: 478,
              w: 703,
              h: 51,
              text_size: 36,
              char_space: 2,
              line_space: 0,
              font: 'fonts/BergenMono-SemiBold.ttf',
              color: 0xFFFFFFFF,
              align_h: hmUI.align.LEFT,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              text: "0123456789 _-.,:;`'%°\\/",
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // FontName: BergenMono-SemiBold.ttf; FontSize: 30
            hmUI.createWidget(hmUI.widget.TEXT, {
              x: 478,
              y: 478,
              w: 555,
              h: 43,
              text_size: 30,
              char_space: 1,
              line_space: 0,
              font: 'fonts/BergenMono-SemiBold.ttf',
              color: 0xFFFFFFFF,
              align_h: hmUI.align.LEFT,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              text: "0123456789 _-.,:;`'%°\\/",
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // FontName: BergenMono-SemiBold.ttf; FontSize: 23
            hmUI.createWidget(hmUI.widget.TEXT, {
              x: 478,
              y: 478,
              w: 408,
              h: 33,
              text_size: 23,
              char_space: 0,
              line_space: 0,
              font: 'fonts/BergenMono-SemiBold.ttf',
              color: 0xFFFFFFFF,
              align_h: hmUI.align.LEFT,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              text: "0123456789 _-.,:;`'%°\\/",
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // FontName: BergenMono-SemiBold.ttf; FontSize: 59
            hmUI.createWidget(hmUI.widget.TEXT, {
              x: 478,
              y: 478,
              w: 1054,
              h: 85,
              text_size: 59,
              char_space: 0,
              line_space: 0,
              font: 'fonts/BergenMono-SemiBold.ttf',
              color: 0xFFFFFFFF,
              align_h: hmUI.align.LEFT,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              text: "0123456789 _-.,:;`'%°\\/",
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            //#region SwitchBackground
            console.log('SwitchBackground');
            function switchBackground() {
              backgroundIndex++;
              if (backgroundIndex >= backgroundList.length) backgroundIndex = 0;
              hmFS.SysProSetInt(`backgroundIndex_${watchfaceId}`, backgroundIndex);
              let toastText = backgroundToastList[backgroundIndex].replace('%s', `${backgroundIndex + 1}`);
              if (toastText.length > 0) hmUI.showToast({text: toastText});
              normal_background_bg_img.setProperty(hmUI.prop.SRC, backgroundList[backgroundIndex]);
 normal_heart_rate_text_font.setProperty(hmUI.prop.MORE, {
    x: 168,
    y: 420,
    w: 150,
    h: 37,
    text_size: 36,
    char_space: 2,
    font: 'fonts/BergenMono-SemiBold.ttf',
    color: colorswitch[backgroundIndex],
    line_space: 0,
    align_v: hmUI.align.CENTER_V,
    text_style: hmUI.text_style.ELLIPSIS,
    align_h: hmUI.align.LEFT,
    type: hmUI.data_type.HEART,
    show_level: hmUI.show_level.ONLY_NORMAL,
});

normal_calorie_current_text_font.setProperty(hmUI.prop.MORE, {
    x: 168,
    y: 359,
    w: 150,
    h: 30,
    text_size: 30,
    char_space: 1,
    font: 'fonts/BergenMono-SemiBold.ttf',
    color: colorswitch[backgroundIndex],
    line_space: 0,
    align_v: hmUI.align.CENTER_V,
    text_style: hmUI.text_style.ELLIPSIS,
    align_h: hmUI.align.LEFT,
    type: hmUI.data_type.CAL,
    show_level: hmUI.show_level.ONLY_NORMAL,
});

normal_step_current_text_font.setProperty(hmUI.prop.MORE, {
    x: 167,
    y: 301,
    w: 150,
    h: 30,
    text_size: 30,
    char_space: 1,
    font: 'fonts/BergenMono-SemiBold.ttf',
    color: colorswitch[backgroundIndex],
    line_space: 0,
    align_v: hmUI.align.CENTER_V,
    text_style: hmUI.text_style.ELLIPSIS,
    align_h: hmUI.align.LEFT,
    type: hmUI.data_type.STEP,
    show_level: hmUI.show_level.ONLY_NORMAL,
});

normal_temperature_current_text_font.setProperty(hmUI.prop.MORE, {
    x: 170,
    y: 244,
    w: 150,
    h: 30,
    text_size: 30,
    char_space: 0,
    font: 'fonts/BergenMono-SemiBold.ttf',
    color: colorswitch[backgroundIndex],
    line_space: 0,
    align_v: hmUI.align.CENTER_V,
    text_style: hmUI.text_style.ELLIPSIS,
    align_h: hmUI.align.LEFT,
    unit_type: 1,
    type: hmUI.data_type.WEATHER_CURRENT,
    show_level: hmUI.show_level.ONLY_NORMAL,
});

normal_day_month_year_font.setProperty(hmUI.prop.MORE, {
    x: 168,
    y: 54,
    w: 145,
    h: 30,
    text_size: 23,
    char_space: 0,
    font: 'fonts/BergenMono-SemiBold.ttf',
    color: colorswitch[backgroundIndex],
    line_space: 0,
    align_v: hmUI.align.CENTER_V,
    text_style: hmUI.text_style.ELLIPSIS,
    align_h: hmUI.align.LEFT,
    show_level: hmUI.show_level.ONLY_NORMAL,
});

normal_time_hour_min_sec_text_font.setProperty(hmUI.prop.MORE, {
    x: 142,
    y: 162,
    w: 300,
    h: 60,
    text_size: txtsize,
    char_space: 0,
    font: 'fonts/BergenMono-SemiBold.ttf',
    color: colorswitch[backgroundIndex],
    line_space: 0,
    align_v: hmUI.align.CENTER_V,
    text_style: hmUI.text_style.ELLIPSIS,
    align_h: hmUI.align.LEFT,
    show_level: hmUI.show_level.ONLY_NORMAL,
});

normal_time_hour_min_text_font.setProperty(hmUI.prop.MORE, {
    x: 142,
    y: 162,
    w: 300,
    h: 60,
    text_size: txtsize,
    char_space: 0,
    font: 'fonts/BergenMono-SemiBold.ttf',
    color: colorswitch[backgroundIndex],
    line_space: 0,
    align_v: hmUI.align.CENTER_V,
    text_style: hmUI.text_style.ELLIPSIS,
    align_h: hmUI.align.LEFT,
    show_level: hmUI.show_level.ONLY_NORMAL,
});


            };
            //#endregion

            console.log('Watch_Face.ScreenNormal');
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: 'Bg1.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            console.log('user_script.js');
            // start user_script.js
            normal_24Hcheck = hmUI.createWidget(hmUI.widget.IMG, {
              x: 254,
              y: 115,
              src: 'Clock_24H.png',
             show_level: hmUI.show_level.ONLY_NORMAL,
            });


//check24h()
            // end user_script.js

            normal_heart_rate_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 168,
              y: 420,
              w: 150,
              h: 37,
              text_size: 36,
              char_space: 2,
              font: 'fonts/BergenMono-SemiBold.ttf',
              color: 0xFFFFFFFF,
              line_space: 0,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_calorie_current_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 168,
              y: 359,
              w: 150,
              h: 30,
              text_size: 30,
              char_space: 1,
              font: 'fonts/BergenMono-SemiBold.ttf',
              color: 0xFFFFFFFF,
              line_space: 0,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 167,
              y: 301,
              w: 150,
              h: 30,
              text_size: 30,
              char_space: 1,
              font: 'fonts/BergenMono-SemiBold.ttf',
              color: 0xFFFFFFFF,
              line_space: 0,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_image_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 273,
              y: 140,
              src: 'Seconds_on.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 280,
              y: 84,
              src: 'Time_Big.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 248,
              y: 241,
              image_array: ["Weather_TxT_01.png","Weather_TxT_02.png","Weather_TxT_03.png","Weather_TxT_04.png","Weather_TxT_05.png","Weather_TxT_06.png","Weather_TxT_07.png","Weather_TxT_08.png","Weather_TxT_09.png","Weather_TxT_10.png","Weather_TxT_11.png","Weather_TxT_12.png","Weather_TxT_13.png","Weather_TxT_14.png","Weather_TxT_15.png","Weather_TxT_16.png","Weather_TxT_17.png","Weather_TxT_18.png","Weather_TxT_19.png","Weather_TxT_20.png","Weather_TxT_21.png","Weather_TxT_22.png","Weather_TxT_23.png","Weather_TxT_24.png","Weather_TxT_25.png","Weather_TxT_26.png","Weather_TxT_27.png","Weather_TxT_28.png","Weather_TxT_29.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 170,
              y: 244,
              w: 150,
              h: 30,
              text_size: 30,
              char_space: 0,
              font: 'fonts/BergenMono-SemiBold.ttf',
              color: 0xFFFFFFFF,
              line_space: 0,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.LEFT,
              unit_type: 1,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            if (!timeSensor) timeSensor = hmSensor.createSensor(hmSensor.id.TIME);
            let screenType = hmSetting.getScreenType();
            normal_day_month_year_font = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 168,
              y: 54,
              w: 145,
              h: 30,
              text_size: 23,
              char_space: 0,
              font: 'fonts/BergenMono-SemiBold.ttf',
              color: 0xFFFFFFFF,
              line_space: 0,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.LEFT,
              // padding: true,
              // unit_type: 1,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_time_hour_min_sec_text_font = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 142,
              y: 162,
              w: 300,
              h: 60,
              text_size: txtsize,
              char_space: 0,
              font: 'fonts/BergenMono-SemiBold.ttf',
              color: 0xFFFFFFFF,
              line_space: 0,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.LEFT,
              // padding: true,
              // unit_end: 2,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_time_hour_min_text_font = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 142,
              y: 162,
              w: 300,
              h: 60,
              text_size: txtsize,
              char_space: 0,
              font: 'fonts/BergenMono-SemiBold.ttf',
              color: 0xFFFFFFFF,
              line_space: 0,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.LEFT,
              // padding: true,
              // unit_end: 2,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time_AmPm = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              am_x: 254,
              am_y: 115,
              am_sc_path: 'Clock_AM.png',
              am_en_path: 'Clock_AM.png',
              pm_x: 254,
              pm_y: 115,
              pm_sc_path: 'Clock_PM.png',
              pm_en_path: 'Clock_PM.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            console.log('Watch_Face.ScreenAOD');
            idle_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: 'Bg1.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            console.log('AOD_user_script.js');
            // start AOD_user_script.js

// ต้องอยู่ในพื้นที่ let ของ AOD เท่านั้น 

            idle_24Hcheck = hmUI.createWidget(hmUI.widget.IMG, {
              x: 254,
              y: 115,
              src: 'Clock_24H.png',
            show_level: hmUI.show_level.ONLY_AOD,
            });


check24h()
            // end AOD_user_script.js

            idle_heart_rate_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 168,
              y: 420,
              w: 150,
              h: 37,
              text_size: 36,
              char_space: 2,
              font: 'fonts/BergenMono-SemiBold.ttf',
              color: 0xFFFFFFFF,
              line_space: 0,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_calorie_current_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 168,
              y: 359,
              w: 150,
              h: 30,
              text_size: 30,
              char_space: 1,
              font: 'fonts/BergenMono-SemiBold.ttf',
              color: 0xFFFFFFFF,
              line_space: 0,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_step_current_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 167,
              y: 301,
              w: 150,
              h: 30,
              text_size: 30,
              char_space: 1,
              font: 'fonts/BergenMono-SemiBold.ttf',
              color: 0xFFFFFFFF,
              line_space: 0,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_image_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 273,
              y: 140,
              src: 'Seconds_on.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_temperature_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 280,
              y: 84,
              src: 'Time_Big.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 248,
              y: 241,
              image_array: ["Weather_TxT_01.png","Weather_TxT_02.png","Weather_TxT_03.png","Weather_TxT_04.png","Weather_TxT_05.png","Weather_TxT_06.png","Weather_TxT_07.png","Weather_TxT_08.png","Weather_TxT_09.png","Weather_TxT_10.png","Weather_TxT_11.png","Weather_TxT_12.png","Weather_TxT_13.png","Weather_TxT_14.png","Weather_TxT_15.png","Weather_TxT_16.png","Weather_TxT_17.png","Weather_TxT_18.png","Weather_TxT_19.png","Weather_TxT_20.png","Weather_TxT_21.png","Weather_TxT_22.png","Weather_TxT_23.png","Weather_TxT_24.png","Weather_TxT_25.png","Weather_TxT_26.png","Weather_TxT_27.png","Weather_TxT_28.png","Weather_TxT_29.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_temperature_current_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 170,
              y: 244,
              w: 150,
              h: 30,
              text_size: 30,
              char_space: 0,
              font: 'fonts/BergenMono-SemiBold.ttf',
              color: 0xFFFFFFFF,
              line_space: 0,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.LEFT,
              unit_type: 1,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_day_month_year_font = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 168,
              y: 54,
              w: 145,
              h: 30,
              text_size: 23,
              char_space: 0,
              font: 'fonts/BergenMono-SemiBold.ttf',
              color: 0xFFFFFFFF,
              line_space: 0,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.LEFT,
              // padding: true,
              // unit_type: 1,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_time_hour_min_sec_text_font = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 142,
              y: 162,
              w: 300,
              h: 60,
              text_size: 59,
              char_space: 0,
              font: 'fonts/BergenMono-SemiBold.ttf',
              color: 0xFFFFFFFF,
              line_space: 0,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.LEFT,
              // padding: true,
              // unit_end: 2,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_time_hour_min_text_font = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 142,
              y: 162,
              w: 300,
              h: 60,
              text_size: 59,
              char_space: 0,
              font: 'fonts/BergenMono-SemiBold.ttf',
              color: 0xFFFFFFFF,
              line_space: 0,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.LEFT,
              // padding: true,
              // unit_end: 2,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time_AmPm = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              am_x: 254,
              am_y: 115,
              am_sc_path: 'Clock_AM.png',
              am_en_path: 'Clock_AM.png',
              pm_x: 254,
              pm_y: 115,
              pm_sc_path: 'Clock_PM.png',
              pm_en_path: 'Clock_PM.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            console.log('Watch_Face.Buttons');
            Button_1 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 143,
              y: 131,
              w: 297,
              h: 32,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                // ON_OFF Seconds
secondsONOFF()
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_2 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 69,
              y: 80,
              w: 346,
              h: 32,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                //Big small time
BigSmall()
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            console.log('Watch_Face.SwitchBackground');
            // Button_Switch_BG = hmUI.createWidget(hmUI.widget.SwitchBackground, {
              // x: 0,
              // y: 151,
              // w: 94,
              // h: 174,
              // text: '',
              // color: 0xFFFF8C00,
              // text_size: 25,
              // press_src: '0_Empty.png',
              // normal_src: '0_Empty.png',
              // bg_list: Bg1|Bg2|Bg3|Bg4|Bg5|Bg6|Bg7|Bg8|Bg9,
              // toast_list: Background %s|Background %s|Background %s|Background %s|Background %s|Background %s|Background %s|Background %s|Background %s,
              // use_crown: False,
              // use_in_AOD: False,
              // vibro: False,
            // });

            Button_Switch_BG = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 0,
              y: 151,
              w: 94,
              h: 174,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                switchBackground();
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            console.log('user_script_end.js');
            // start user_script_end.js


if(hmFS.SysProGetInt('ampm24h') == 1) {
                  is24H();}

if(hmFS.SysProGetInt('ampm24h') == 2) {
                  isAMPM();}
            // end user_script_end.js

            //#region time_update
            function time_update(updateHour = false, updateMinute = false) {
              console.log('time_update()');
              let hour = timeSensor.hour;
              let minute = timeSensor.minute;
              let second = timeSensor.second;
              let format_hour = timeSensor.format_hour;

              console.log('day/month/year font');
              if (updateHour) {
                let normal_DayStr = timeSensor.day.toString();
                let normal_MonthStr = timeSensor.month.toString();
                let normal_YearStr = timeSensor.year.toString();
                normal_DayStr = normal_DayStr.padStart(2, '0');
                normal_MonthStr = normal_MonthStr.padStart(2, '0');
                let normal_DayMonthYearStr = '--';
                const dateFormat = hmSetting.getDateFormat();
                if (dateFormat == 0) {
                  normal_DayMonthYearStr = normal_YearStr + '/' + normal_MonthStr + '/' + normal_DayStr;
                }
                if (dateFormat == 1) {
                  normal_DayMonthYearStr = normal_DayStr + '/' + normal_MonthStr + '/' + normal_YearStr;
                }
                if (dateFormat == 2) {
                  normal_DayMonthYearStr = normal_MonthStr + '/' + normal_DayStr + '/' + normal_YearStr;
                }
                normal_day_month_year_font.setProperty(hmUI.prop.TEXT, normal_DayMonthYearStr );
              };

              console.log('hour:min:sec font');
              let normal_HourMinSecStr = format_hour.toString();
              normal_HourMinSecStr = normal_HourMinSecStr.padStart(2, '0');
              normal_HourMinSecStr = normal_HourMinSecStr + ':' + minute.toString().padStart(2, '0') + ':' + second.toString().padStart(2, '0');
              normal_time_hour_min_sec_text_font.setProperty(hmUI.prop.TEXT, normal_HourMinSecStr );
              console.log('hour:min font');
              if (updateMinute) {
                let normal_HourMinStr = format_hour.toString();
                normal_HourMinStr = normal_HourMinStr.padStart(2, '0');
                normal_HourMinStr = normal_HourMinStr + ':' + minute.toString().padStart(2, '0');
                normal_time_hour_min_text_font.setProperty(hmUI.prop.TEXT, normal_HourMinStr );
              };

              console.log('day/month/year font');
              if (updateHour) {
                let idle_DayStr = timeSensor.day.toString();
                let idle_MonthStr = timeSensor.month.toString();
                let idle_YearStr = timeSensor.year.toString();
                idle_DayStr = idle_DayStr.padStart(2, '0');
                idle_MonthStr = idle_MonthStr.padStart(2, '0');
                let idle_DayMonthYearStr = '--';
                const dateFormat = hmSetting.getDateFormat();
                if (dateFormat == 0) {
                  idle_DayMonthYearStr = idle_YearStr + '/' + idle_MonthStr + '/' + idle_DayStr;
                }
                if (dateFormat == 1) {
                  idle_DayMonthYearStr = idle_DayStr + '/' + idle_MonthStr + '/' + idle_YearStr;
                }
                if (dateFormat == 2) {
                  idle_DayMonthYearStr = idle_MonthStr + '/' + idle_DayStr + '/' + idle_YearStr;
                }
                idle_day_month_year_font.setProperty(hmUI.prop.TEXT, idle_DayMonthYearStr );
              };

              console.log('hour:min:sec font');
              let idle_HourMinSecStr = format_hour.toString();
              idle_HourMinSecStr = idle_HourMinSecStr.padStart(2, '0');
              idle_HourMinSecStr = idle_HourMinSecStr + ':' + minute.toString().padStart(2, '0') + ':' + second.toString().padStart(2, '0');
              idle_time_hour_min_sec_text_font.setProperty(hmUI.prop.TEXT, idle_HourMinSecStr );
              console.log('hour:min font');
              if (updateMinute) {
                let idle_HourMinStr = format_hour.toString();
                idle_HourMinStr = idle_HourMinStr.padStart(2, '0');
                idle_HourMinStr = idle_HourMinStr + ':' + minute.toString().padStart(2, '0');
                idle_time_hour_min_text_font.setProperty(hmUI.prop.TEXT, idle_HourMinStr );
              };

            };

            //#endregion
            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                console.log('resume_call()');
                time_update(true, true);
                if (screenType == hmSetting.screen_type.WATCHFACE) {
                  if (!normal_timerTimeUpdate) {
                    normal_timerTimeUpdate = timer.createTimer(0, 1000, (function (option) {
                      let updateHour = timeSensor.minute == 0;
                      let updateMinute = timeSensor.second < 2;
                      time_update(updateHour, updateMinute);
                    }));  // end timer 
                  };  // end timer check
                };  // end screenType

                if (screenType == hmSetting.screen_type.AOD) {
                  if (!idle_timerTimeUpdate) {
                    idle_timerTimeUpdate = timer.createTimer(0, 1000, (function (option) {
                      let updateHour = timeSensor.minute == 0;
                      let updateMinute = timeSensor.second < 2;
                      time_update(updateHour, updateMinute);
                    }));  // end timer 
                  };  // end timer check
                };  // end screenType


                //SwitchBackground
                if (hmFS.SysProGetInt(`backgroundIndex_${watchfaceId}`) === undefined) {
                  backgroundIndex = 0;
                  hmFS.SysProSetInt(`backgroundIndex_${watchfaceId}`, backgroundIndex);
                } else {
                  backgroundIndex = hmFS.SysProGetInt(`backgroundIndex_${watchfaceId}`);
                };
                if (screenType == hmSetting.screen_type.WATCHFACE && normal_background_bg_img) {
normal_background_bg_img.setProperty(hmUI.prop.SRC, backgroundList[backgroundIndex]);
normal_heart_rate_text_font.setProperty(hmUI.prop.MORE, {
    x: 168,
    y: 420,
    w: 150,
    h: 37,
    text_size: 36,
    char_space: 2,
    font: 'fonts/BergenMono-SemiBold.ttf',
    color: colorswitch[backgroundIndex],
    line_space: 0,
    align_v: hmUI.align.CENTER_V,
    text_style: hmUI.text_style.ELLIPSIS,
    align_h: hmUI.align.LEFT,
    type: hmUI.data_type.HEART,
    show_level: hmUI.show_level.ONLY_NORMAL,
});

normal_calorie_current_text_font.setProperty(hmUI.prop.MORE, {
    x: 168,
    y: 359,
    w: 150,
    h: 30,
    text_size: 30,
    char_space: 1,
    font: 'fonts/BergenMono-SemiBold.ttf',
    color: colorswitch[backgroundIndex],
    line_space: 0,
    align_v: hmUI.align.CENTER_V,
    text_style: hmUI.text_style.ELLIPSIS,
    align_h: hmUI.align.LEFT,
    type: hmUI.data_type.CAL,
    show_level: hmUI.show_level.ONLY_NORMAL,
});

normal_step_current_text_font.setProperty(hmUI.prop.MORE, {
    x: 167,
    y: 301,
    w: 150,
    h: 30,
    text_size: 30,
    char_space: 1,
    font: 'fonts/BergenMono-SemiBold.ttf',
    color: colorswitch[backgroundIndex],
    line_space: 0,
    align_v: hmUI.align.CENTER_V,
    text_style: hmUI.text_style.ELLIPSIS,
    align_h: hmUI.align.LEFT,
    type: hmUI.data_type.STEP,
    show_level: hmUI.show_level.ONLY_NORMAL,
});

normal_temperature_current_text_font.setProperty(hmUI.prop.MORE, {
    x: 170,
    y: 244,
    w: 150,
    h: 30,
    text_size: 30,
    char_space: 0,
    font: 'fonts/BergenMono-SemiBold.ttf',
    color: colorswitch[backgroundIndex],
    line_space: 0,
    align_v: hmUI.align.CENTER_V,
    text_style: hmUI.text_style.ELLIPSIS,
    align_h: hmUI.align.LEFT,
    unit_type: 1,
    type: hmUI.data_type.WEATHER_CURRENT,
    show_level: hmUI.show_level.ONLY_NORMAL,
});

normal_day_month_year_font.setProperty(hmUI.prop.MORE, {
    x: 168,
    y: 54,
    w: 145,
    h: 30,
    text_size: 23,
    char_space: 0,
    font: 'fonts/BergenMono-SemiBold.ttf',
    color: colorswitch[backgroundIndex],
    line_space: 0,
    align_v: hmUI.align.CENTER_V,
    text_style: hmUI.text_style.ELLIPSIS,
    align_h: hmUI.align.LEFT,
    show_level: hmUI.show_level.ONLY_NORMAL,
});

normal_time_hour_min_sec_text_font.setProperty(hmUI.prop.MORE, {
    x: 142,
    y: 162,
    w: 300,
    h: 60,
    text_size: txtsize,
    char_space: 0,
    font: 'fonts/BergenMono-SemiBold.ttf',
    color: colorswitch[backgroundIndex],
    line_space: 0,
    align_v: hmUI.align.CENTER_V,
    text_style: hmUI.text_style.ELLIPSIS,
    align_h: hmUI.align.LEFT,
    show_level: hmUI.show_level.ONLY_NORMAL,
});

normal_time_hour_min_text_font.setProperty(hmUI.prop.MORE, {
    x: 142,
    y: 162,
    w: 300,
    h: 60,
    text_size: txtsize,
    char_space: 0,
    font: 'fonts/BergenMono-SemiBold.ttf',
    color: colorswitch[backgroundIndex],
    line_space: 0,
    align_v: hmUI.align.CENTER_V,
    text_style: hmUI.text_style.ELLIPSIS,
    align_h: hmUI.align.LEFT,
    show_level: hmUI.show_level.ONLY_NORMAL,
});
}
                console.log('resume_call.js');
                // start resume_call.js

 check24h()
                // end resume_call.js

              }),
              pause_call: (function () {
                console.log('pause_call()');
                if (normal_timerTimeUpdate) {
                  timer.stopTimer(normal_timerTimeUpdate);
                  normal_timerTimeUpdate = undefined;
                }
                if (idle_timerTimeUpdate) {
                  timer.stopTimer(idle_timerTimeUpdate);
                  idle_timerTimeUpdate = undefined;
                }

              }),
            });

                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}