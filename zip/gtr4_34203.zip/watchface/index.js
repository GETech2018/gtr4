/*
** Facemaker bundle tool v0.0.3
* *huamiOS watchface js version v2.0.1
* *Copyright © Huami. All Rights Reserved
*/


try {
	(() => {
		var __$$app$$__ = __$$hmAppManager$$__.currentApp;
		var __$$module$$__ = __$$app$$__.current;

		//drink is a name,can modify
		var h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__), 'drink');

		'use strict';

		//dynamic modify start
		let normal_img0 = '';
		let normal_img1 = '';
		let normal_img2 = '';
		let normal_img3 = '';
		let normal_img4 = '';
		let normal_img5 = '';
		let normal_img6 = '';
		let normal_second_rotary8 = '';
		let normal_img9 = '';
		let normal_img10 = '';
		let normal_img11 = '';
		let normal_steps_rotary13 = '';
		let normal_date_imagecombo15 = '';
		let normal_week_rotary16 = '';
		let normal_month_rotary17 = '';
		let timeInterval;
		let normal_minute_high_imageset19 = '';
		let normal_minute_high_imageset19_array = ['0024.png','0025.png','0026.png','0027.png','0028.png','0029.png'];
		let normal_hour_low_imageset20 = '';
		let normal_hour_low_imageset20_array = ['0030.png','0031.png','0032.png','0033.png','0034.png','0035.png','0036.png','0037.png','0038.png','0039.png'];
		let normal_hour_high_imageset21 = '';
		let normal_hour_high_imageset21_array = ['0040.png','0041.png','0042.png'];
		let normal_second_low_imageset22 = '';
		let normal_second_low_imageset22_array = ['0043.png','0044.png','0043.png','0044.png','0043.png','0044.png','0043.png','0044.png','0043.png','0044.png'];
		let normal_second_high_imageset23 = '';
		let normal_second_high_imageset23_array = ['0045.png','0046.png','0047.png','0048.png','0049.png','0050.png'];
		let normal_second_low_imageset24 = '';
		let normal_second_low_imageset24_array = ['0045.png','0046.png','0047.png','0048.png','0049.png','0050.png','0051.png','0052.png','0053.png','0054.png'];
		let normal_minute_low_imageset25 = '';
		let normal_minute_low_imageset25_array = ['0055.png','0056.png','0057.png','0058.png','0059.png','0060.png','0061.png','0062.png','0063.png','0064.png'];
		let normal_weather_imageset27 = '';
		let normal_battery_imageset29 = '';
		let normal_steps_shortcut32 = '';
		let normal_sleep_shortcut33 = '';
		let idle_img35 = '';
		let idle_img36 = '';
		let idle_img37 = '';
		let idle_hour_rotary39 = '';
		let idle_minute_rotary40 = '';
		let idle_second_sweep_rotary41 = '';
		let clock_timer;
		//dynamic modify end

		//not required
		const logger = DeviceRuntimeCore.HmLogger.getLogger("yeguang");

		__$$module$$__.module = DeviceRuntimeCore.WatchFace({
			init_view() {

				const timeSensor = hmSensor.createSensor(hmSensor.id.TIME);
				let screenType = hmSetting.getScreenType();

				normal_img0 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 0,
					y: 0,
					w: 466,
					h: 466,
					src: '0002.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img1 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 0,
					y: 0,
					w: 466,
					h: 466,
					src: '0003.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img2 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 138,
					y: 69,
					w: 160,
					h: 75,
					src: '0004.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img3 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 303,
					y: 90,
					w: 48,
					h: 50,
					src: '0005.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img4 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 190,
					y: 370,
					w: 11,
					h: 20,
					src: '0006.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img5 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 216,
					y: 298,
					w: 40,
					h: 20,
					src: '0007.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img6 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 244,
					y: 370,
					w: 35,
					h: 20,
					src: '0008.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_second_rotary8 = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
					second_path: '0009.png',
					second_centerX: 233,
					second_centerY: 233,
					second_posX: 233,
					second_posY: 233,
					second_start_angle: 0,
					second_end_angle: 360,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img9 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 0,
					y: 0,
					w: 466,
					h: 466,
					src: '0010.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img10 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 211,
					y: 213,
					w: 31,
					h: 50,
					src: '0011.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img11 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 230,
					y: 213,
					w: 27,
					h: 50,
					src: '0012.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_steps_rotary13 = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
					src: '0013.png',
					center_x: 234,
					center_y: 348,
					x: 20,
					y: 61,
					start_angle: -120,
					end_angle: 122,
					type: hmUI.data_type.STEP,
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_date_imagecombo15 = hmUI.createWidget(hmUI.widget.IMG_DATE, {
					day_startX: 92,
					day_startY: 323,
					day_sc_array: ["0014.png","0015.png","0016.png","0017.png","0018.png","0019.png","0020.png","0021.png","0022.png","0023.png"],
					day_tc_array: ["0014.png","0015.png","0016.png","0017.png","0018.png","0019.png","0020.png","0021.png","0022.png","0023.png"],
					day_en_array: ["0014.png","0015.png","0016.png","0017.png","0018.png","0019.png","0020.png","0021.png","0022.png","0023.png"],
					day_zero: false,
					day_space: 0,
					day_align: hmUI.align.CENTER_H,
					day_is_character: false,
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_week_rotary16 = hmUI.createWidget(hmUI.widget.DATE_POINTER, {
					src: '0013.png',
					center_x: 125,
					center_y: 233,
					posX: 20,
					posY: 61,
					start_angle: 0,
					end_angle: 360,
					type: hmUI.date.WEEK,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_month_rotary17 = hmUI.createWidget(hmUI.widget.DATE_POINTER, {
					src: '0013.png',
					center_x: 343,
					center_y: 233,
					posX: 20,
					posY: 61,
					start_angle: 0,
					end_angle: 360,
					type: hmUI.date.MONTH,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_minute_high_imageset19 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 226,
					y: 70,
					w: 226,
					h: 70,
					src: '0029.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				})

				normal_hour_low_imageset20 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 174,
					y: 70,
					w: 174,
					h: 70,
					src: '0039.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				})

				normal_hour_high_imageset21 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 138,
					y: 70,
					w: 138,
					h: 70,
					src: '0042.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				})

				normal_second_low_imageset22 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 210,
					y: 69,
					w: 210,
					h: 69,
					src: '0044.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				})

				normal_second_high_imageset23 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 303,
					y: 90,
					w: 303,
					h: 90,
					src: '0050.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				})

				normal_second_low_imageset24 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 327,
					y: 90,
					w: 327,
					h: 90,
					src: '0054.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				})

				normal_minute_low_imageset25 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 262,
					y: 69,
					w: 262,
					h: 69,
					src: '0064.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				})

				normal_weather_imageset27 = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
					x: 207,
					y: 140,
					image_array: ["0065.png","0066.png","0067.png","0068.png","0069.png","0070.png","0067.png","0071.png","0072.png","0073.png","0074.png","0075.png","0076.png","0077.png","0078.png","0079.png","0080.png","0081.png","0082.png","0083.png","0084.png","0085.png","0086.png","0087.png","0088.png","0089.png","0065.png","0066.png","0090.png"],
					image_length: 29,
					type: hmUI.data_type.WEATHER_CURRENT,
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_battery_imageset29 = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
					x: 323,
					y: 322,
					image_array: ["0091.png","0092.png","0093.png","0094.png","0095.png","0096.png","0097.png","0098.png","0099.png","0100.png","0101.png"],
					image_length: 11,
					type: hmUI.data_type.BATTERY,
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_steps_shortcut32 = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
					x: 183,
					y: 297,
					w: 100,
					h: 100,
					src: '',
					type: hmUI.data_type.STEP,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_sleep_shortcut33 = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
					x: 197,
					y: 201,
					w: 70,
					h: 70,
					src: '',
					type: hmUI.data_type.SLEEP,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				idle_img35 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 204,
					y: 71,
					w: 38,
					h: 60,
					src: '0102.png',
					enable: false,
					show_level: hmUI.show_level.ONAL_AOD,
				});

				idle_img36 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 226,
					y: 71,
					w: 32,
					h: 60,
					src: '0103.png',
					enable: false,
					show_level: hmUI.show_level.ONAL_AOD,
				});

				idle_img37 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 204,
					y: 71,
					w: 38,
					h: 60,
					src: '0104.png',
					enable: false,
					show_level: hmUI.show_level.ONAL_AOD,
				});

				idle_hour_rotary39 = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
					hour_path: '0105.png',
					hour_centerX: 233,
					hour_centerY: 233,
					hour_posX: 25,
					hour_posY: 151,
					hour_start_angle: 0,
					hour_end_angle: 360,
					show_level: hmUI.show_level.ONAL_AOD,
				});

				idle_minute_rotary40 = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
					minute_path: '0106.png',
					minute_centerX: 233,
					minute_centerY: 233,
					minute_posX: 25,
					minute_posY: 213,
					minute_start_angle: 0,
					minute_end_angle: 360,
					show_level: hmUI.show_level.ONAL_AOD,
				});

				idle_second_sweep_rotary41 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 0,
					y: 0,
					w: 466,
					h: 466,
					center_x: 233,
					center_y: 233,
					pos_x: 212,
					pos_y: 14,
					src: '0107.png',
					enable: false,
					show_level: hmUI.show_level.ONAL_AOD,
				});

				function updateTime() {
					normal_minute_high_imageset19.setProperty(hmUI.prop.MORE, {
						src: normal_minute_high_imageset19_array[(timeSensor.minute.toString().length == 2 ? timeSensor.minute.toString().charAt(0) : 0)]
					})
					normal_hour_low_imageset20.setProperty(hmUI.prop.MORE, {
						src: normal_hour_low_imageset20_array[(timeSensor.format_hour.toString().length == 2 ? timeSensor.format_hour.toString().charAt(1) : timeSensor.format_hour.toString().charAt(0))]
					})
					normal_hour_high_imageset21.setProperty(hmUI.prop.MORE, {
						src: normal_hour_high_imageset21_array[(timeSensor.format_hour.toString().length == 2 ? timeSensor.format_hour.toString().charAt(0) : 0)]
					})
					normal_second_low_imageset22.setProperty(hmUI.prop.MORE, {
						src: normal_second_low_imageset22_array[(timeSensor.second.toString().length == 2 ? timeSensor.second.toString().charAt(1) : timeSensor.second.toString().charAt(0))]
					})
					normal_second_high_imageset23.setProperty(hmUI.prop.MORE, {
						src: normal_second_high_imageset23_array[(timeSensor.second.toString().length == 2 ? timeSensor.second.toString().charAt(0) : 0)]
					})
					normal_second_low_imageset24.setProperty(hmUI.prop.MORE, {
						src: normal_second_low_imageset24_array[(timeSensor.second.toString().length == 2 ? timeSensor.second.toString().charAt(1) : timeSensor.second.toString().charAt(0))]
					})
					normal_minute_low_imageset25.setProperty(hmUI.prop.MORE, {
						src: normal_minute_low_imageset25_array[(timeSensor.minute.toString().length == 2 ? timeSensor.minute.toString().charAt(1) : timeSensor.minute.toString().charAt(0))]
					})
				}

				timeSensor.addEventListener(hmSensor.event.CHANGE, function() {
					updateTime();
				});

				const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
					resume_call: (function () {
						const animFps = 60;
						const animRepeat = 1000/animFps;
						const animProgress = 6/animFps;
						let animAngle = 0;
						let animDelay = 0;
						clock_timer = timer.createTimer(animDelay, animRepeat, (function(option) {
							animAngle = timeSensor.second * 6 + ((timeSensor.utc % 1000) / 1000) * 6;
							idle_second_sweep_rotary41.setProperty(hmUI.prop.ANGLE, animAngle);
						}));

						updateTime();
						timeInterval = setInterval(updateTime, 1000);
					}),
					pause_call: (function () {
						timer.stopTimer(clock_timer);
						clearInterval(timeInterval);
					}),
				})
			},

		onInit() {
			console.log('index page.js on init invoke')
			this.init_view()
		},
		onReady() {
			console.log('index page.js on ready invoke')
		},
		onShow() {
			console.log('index page.js on show invoke')
		},
		onHide() {
			console.log('index page.js on hide invoke')
		},
		onDestroy() {
			console.log('index page.js on destroy invoke')
						timer.stopTimer(clock_timer);
		},
	});	})()
} catch (e) {
	console.log(e)
}