﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        //const logger = Logger.getLogger('watchface_SashaCX75');
        const logger = DeviceRuntimeCore.HmLogger.getLogger('watchface_SashaCX75')
        //end of ignored block

        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_system_disconnect_img = ''
        let normal_system_clock_img = ''
        let normal_uvi_pointer_progress_img_pointer = ''
        let normal_weather_image_progress_img_level = ''
        let normal_temperature_current_text_img = ''
        let normal_date_img_date_day = ''
        let normal_date_img_date_month = ''
        let normal_battery_text_text_img = ''
        let normal_battery_image_progress_img_level = ''
        let normal_calorie_current_text_img = ''
        let normal_step_current_text_img = ''
        let normal_heart_rate_text_text_img = ''
        let normal_digital_clock_img_time = ''
        let normal_analog_clock_time_pointer_hour = ''
        let normal_analog_clock_time_pointer_minute = ''
        let normal_analog_clock_time_pointer_second = ''
        let idle_background_bg_img = ''
        let idle_date_img_date_day = ''
        let idle_date_img_date_month = ''
        let idle_step_current_text_img = ''
        let idle_analog_clock_time_pointer_hour = ''
        let idle_analog_clock_time_pointer_minute = ''
        let normal_step_jumpable_img_click = ''
        let normal_cal_jumpable_img_click = ''
        let normal_heart_jumpable_img_click = ''
        let normal_battery_jumpable_img_click = ''
        let normal_temperature_jumpable_img_click = ''
        let normal_countdown_jumpable_img_click = ''
        let normal_stopwatch_jumpable_img_click = ''
        let normal_alarm_jumpable_img_click = ''


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            console.log('Watch_Face.ScreenNormal');
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 466,
              h: 466,
              src: 'bg.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 297,
              y: 217,
              src: 'bt.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 305,
              y: 101,
              src: 'A100_051.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_uvi_pointer_progress_img_pointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
              src: 'point.png',
              center_x: 144,
              center_y: 175,
              x: 11,
              y: 51,
              start_angle: -84,
              end_angle: 84,
              invalid_visible: false,
              cover_path: 'A100_053.png',
              cover_x: 121,
              cover_y: 130,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 129,
              y: 146,
              image_array: ["sw_0.png","sw_1.png","sw_2.png","sw_3.png","sw_4.png","sw_5.png","sw_6.png","sw_7.png","sw_8.png","sw_9.png","sw_10.png","sw_11.png","sw_12.png","sw_13.png","sw_14.png","sw_15.png","sw_16.png","sw_17.png","sw_18.png","sw_19.png","sw_20.png","sw_21.png","sw_22.png","sw_23.png","sw_24.png","sw_25.png","sw_26.png","sw_27.png","sw_28.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 126,
              y: 185,
              font_array: ["A100_038.png","A100_039.png","A100_040.png","A100_041.png","A100_042.png","A100_043.png","A100_044.png","A100_045.png","A100_046.png","A100_047.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'A100_076.png',
              unit_tc: 'A100_076.png',
              unit_en: 'A100_076.png',
              negative_image: 'minus.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 275,
              day_startY: 299,
              day_sc_array: ["A100_038.png","A100_039.png","A100_040.png","A100_041.png","A100_042.png","A100_043.png","A100_044.png","A100_045.png","A100_046.png","A100_047.png"],
              day_tc_array: ["A100_038.png","A100_039.png","A100_040.png","A100_041.png","A100_042.png","A100_043.png","A100_044.png","A100_045.png","A100_046.png","A100_047.png"],
              day_en_array: ["A100_038.png","A100_039.png","A100_040.png","A100_041.png","A100_042.png","A100_043.png","A100_044.png","A100_045.png","A100_046.png","A100_047.png"],
              day_zero: 1,
              day_space: 0,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_month = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 311,
              month_startY: 299,
              month_sc_array: ["A100_038.png","A100_039.png","A100_040.png","A100_041.png","A100_042.png","A100_043.png","A100_044.png","A100_045.png","A100_046.png","A100_047.png"],
              month_tc_array: ["A100_038.png","A100_039.png","A100_040.png","A100_041.png","A100_042.png","A100_043.png","A100_044.png","A100_045.png","A100_046.png","A100_047.png"],
              month_en_array: ["A100_038.png","A100_039.png","A100_040.png","A100_041.png","A100_042.png","A100_043.png","A100_044.png","A100_045.png","A100_046.png","A100_047.png"],
              month_zero: 1,
              month_space: 0,
              month_align: hmUI.align.CENTER_H,
              month_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 295,
              y: 327,
              font_array: ["A100_038.png","A100_039.png","A100_040.png","A100_041.png","A100_042.png","A100_043.png","A100_044.png","A100_045.png","A100_046.png","A100_047.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 201,
              y: 199,
              image_array: ["batt_1.png","batt_2.png","batt_3.png","batt_4.png","batt_5.png","batt_6.png","batt_7.png","batt_8.png","batt_9.png","batt_10.png"],
              image_length: 10,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_calorie_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 125,
              y: 293,
              font_array: ["A100_038.png","A100_039.png","A100_040.png","A100_041.png","A100_042.png","A100_043.png","A100_044.png","A100_045.png","A100_046.png","A100_047.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 147,
              y: 337,
              font_array: ["A100_038.png","A100_039.png","A100_040.png","A100_041.png","A100_042.png","A100_043.png","A100_044.png","A100_045.png","A100_046.png","A100_047.png"],
              padding: false,
              h_space: -2,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 320,
              y: 137,
              font_array: ["A100_038.png","A100_039.png","A100_040.png","A100_041.png","A100_042.png","A100_043.png","A100_044.png","A100_045.png","A100_046.png","A100_047.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 256,
              hour_startY: 256,
              hour_array: ["A100_004.png","A100_005.png","A100_006.png","A100_007.png","A100_008.png","A100_009.png","A100_010.png","A100_011.png","A100_012.png","A100_013.png"],
              hour_zero: 1,
              hour_space: 2,
              hour_angle: 0,
              hour_align: hmUI.align.LEFT,

              minute_startX: 315,
              minute_startY: 256,
              minute_array: ["A100_004.png","A100_005.png","A100_006.png","A100_007.png","A100_008.png","A100_009.png","A100_010.png","A100_011.png","A100_012.png","A100_013.png"],
              minute_zero: 1,
              minute_space: 2,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_hour = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              hour_path: 'A100_016.png',
              hour_centerX: 233,
              hour_centerY: 233,
              hour_posX: 43,
              hour_posY: 223,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_minute = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              minute_path: 'A100_015.png',
              minute_centerX: 233,
              minute_centerY: 233,
              minute_posX: 43,
              minute_posY: 224,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_second = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              second_path: 'A100_017.png',
              second_centerX: 233,
              second_centerY: 233,
              second_posX: 44,
              second_posY: 224,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            console.log('Watch_Face.ScreenAOD');
            idle_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 466,
              h: 466,
              src: 'A100_003.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 200,
              day_startY: 135,
              day_sc_array: ["A100_038.png","A100_039.png","A100_040.png","A100_041.png","A100_042.png","A100_043.png","A100_044.png","A100_045.png","A100_046.png","A100_047.png"],
              day_tc_array: ["A100_038.png","A100_039.png","A100_040.png","A100_041.png","A100_042.png","A100_043.png","A100_044.png","A100_045.png","A100_046.png","A100_047.png"],
              day_en_array: ["A100_038.png","A100_039.png","A100_040.png","A100_041.png","A100_042.png","A100_043.png","A100_044.png","A100_045.png","A100_046.png","A100_047.png"],
              day_zero: 1,
              day_space: 0,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_month = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 240,
              month_startY: 135,
              month_sc_array: ["A100_038.png","A100_039.png","A100_040.png","A100_041.png","A100_042.png","A100_043.png","A100_044.png","A100_045.png","A100_046.png","A100_047.png"],
              month_tc_array: ["A100_038.png","A100_039.png","A100_040.png","A100_041.png","A100_042.png","A100_043.png","A100_044.png","A100_045.png","A100_046.png","A100_047.png"],
              month_en_array: ["A100_038.png","A100_039.png","A100_040.png","A100_041.png","A100_042.png","A100_043.png","A100_044.png","A100_045.png","A100_046.png","A100_047.png"],
              month_zero: 1,
              month_space: 0,
              month_align: hmUI.align.CENTER_H,
              month_is_character: false,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 202,
              y: 337,
              font_array: ["A100_038.png","A100_039.png","A100_040.png","A100_041.png","A100_042.png","A100_043.png","A100_044.png","A100_045.png","A100_046.png","A100_047.png"],
              padding: false,
              h_space: -1,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_analog_clock_time_pointer_hour = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              hour_path: 'A100_016.png',
              hour_centerX: 233,
              hour_centerY: 233,
              hour_posX: 43,
              hour_posY: 223,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_analog_clock_time_pointer_minute = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              minute_path: 'A100_015.png',
              minute_centerX: 233,
              minute_centerY: 233,
              minute_posX: 43,
              minute_posY: 224,
              minute_cover_path: 'A100_018.png',
              minute_cover_x: 223,
              minute_cover_y: 222,
              show_level: hmUI.show_level.ONLY_AOD,
            });
            console.log('Watch_Face.Shortcuts');

            normal_step_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 105,
              y: 327,
              w: 100,
              h: 65,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_cal_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 85,
              y: 260,
              w: 100,
              h: 65,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 280,
              y: 125,
              w: 100,
              h: 60,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 265,
              y: 320,
              w: 80,
              h: 60,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 93,
              y: 125,
              w: 100,
              h: 100,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_countdown_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 222,
              y: 235,
              w: 80,
              h: 55,
              type: hmUI.data_type.COUNT_DOWN,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_stopwatch_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 313,
              y: 235,
              w: 80,
              h: 55,
              type: hmUI.data_type.STOP_WATCH,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_alarm_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 280,
              y: 62,
              w: 100,
              h: 60,
              type: hmUI.data_type.ALARM_CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}