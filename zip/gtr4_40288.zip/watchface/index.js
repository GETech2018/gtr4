﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        const logger = Logger.getLogger('watchface_SashaCX75');
        //end of ignored block

        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_day_pointer_progress_date_pointer = ''
        let normal_battery_circle_scale = ''
        let normal_battery_icon_img = ''
        let normal_week_pointer_progress_date_pointer = ''
        let normal_analog_clock_time_pointer_hour = ''
        let normal_analog_clock_time_pointer_minute = ''
        let normal_analog_clock_time_pointer_second = ''
        let idle_background_bg_img = ''
        let idle_day_pointer_progress_date_pointer = ''
        let idle_battery_circle_scale = ''
        let idle_battery_icon_img = ''
        let idle_week_pointer_progress_date_pointer = ''
        let idle_analog_clock_time_pointer_hour = ''
        let idle_analog_clock_time_pointer_minute = ''


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            console.log('Watch_Face.ScreenNormal');
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 466,
              h: 466,
              src: '0007.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_day_pointer_progress_date_pointer = hmUI.createWidget(hmUI.widget.DATE_POINTER, {
              src: '0008.png',
              center_x: 233,
              center_y: 233,
              posX: 233,
              posY: 233,
              start_angle: -212,
              end_angle: 149,
              cover_path: '0002.png',
              cover_x: 0,
              cover_y: 0,
              type: hmUI.date.DAY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_battery_circle_scale = hmUI.createWidget(hmUI.widget.Circle_Scale, {
              // center_x: 233,
              // center_y: 310,
              // start_angle: 0,
              // end_angle: 360,
              // radius: 47,
              // line_width: 8,
              // line_cap: Flat,
              // color: 0xFFFF0000,
              // mirror: False,
              // inversion: False,
              // type: hmUI.data_type.BATTERY,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            let screenType = hmSetting.getScreenType();
            normal_battery_circle_scale = hmUI.createWidget(hmUI.widget.ARC_PROGRESS, {
              center_x: 233,
              center_y: 310,
              start_angle: 0,
              end_angle: 360,
              radius: 43,
              line_width: 8,
              corner_flag: 3,
              color: 0xFFFF0000,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            
            const battery = hmSensor.createSensor(hmSensor.id.BATTERY);
            battery.addEventListener(hmSensor.event.CHANGE, function() {
              scale_call();
            });

            normal_battery_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 189,
              y: 266,
              src: '0011.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_week_pointer_progress_date_pointer = hmUI.createWidget(hmUI.widget.DATE_POINTER, {
              src: '0009.png',
              center_x: 233,
              center_y: 309,
              posX: 15,
              posY: 16,
              start_angle: 0,
              end_angle: 360,
              cover_path: '0010.png',
              cover_x: 218,
              cover_y: 295,
              type: hmUI.date.WEEK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_hour = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              hour_path: '0003.png',
              hour_centerX: 233,
              hour_centerY: 233,
              hour_posX: 32,
              hour_posY: 136,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_minute = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              minute_path: '0004.png',
              minute_centerX: 233,
              minute_centerY: 233,
              minute_posX: 32,
              minute_posY: 203,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_second = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              second_path: '0005.png',
              second_centerX: 233,
              second_centerY: 233,
              second_posX: 38,
              second_posY: 219,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            console.log('Watch_Face.ScreenAOD');
            idle_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 466,
              h: 466,
              src: '0007.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_day_pointer_progress_date_pointer = hmUI.createWidget(hmUI.widget.DATE_POINTER, {
              src: '0008.png',
              center_x: 233,
              center_y: 233,
              posX: 233,
              posY: 233,
              start_angle: -212,
              end_angle: 149,
              cover_path: '0002.png',
              cover_x: 0,
              cover_y: 0,
              type: hmUI.date.DAY,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            // idle_battery_circle_scale = hmUI.createWidget(hmUI.widget.Circle_Scale, {
              // center_x: 233,
              // center_y: 310,
              // start_angle: 0,
              // end_angle: 360,
              // radius: 47,
              // line_width: 8,
              // line_cap: Flat,
              // color: 0xFFFF0000,
              // mirror: False,
              // inversion: False,
              // type: hmUI.data_type.BATTERY,
              // show_level: hmUI.show_level.ONLY_AOD,
            // });

            idle_battery_circle_scale = hmUI.createWidget(hmUI.widget.ARC_PROGRESS, {
              center_x: 233,
              center_y: 310,
              start_angle: 0,
              end_angle: 360,
              radius: 43,
              line_width: 8,
              corner_flag: 3,
              color: 0xFFFF0000,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_battery_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 189,
              y: 266,
              src: '0011.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_week_pointer_progress_date_pointer = hmUI.createWidget(hmUI.widget.DATE_POINTER, {
              src: '0009.png',
              center_x: 233,
              center_y: 309,
              posX: 15,
              posY: 16,
              start_angle: 0,
              end_angle: 360,
              cover_path: '0010.png',
              cover_x: 218,
              cover_y: 295,
              type: hmUI.date.WEEK,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_analog_clock_time_pointer_hour = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              hour_path: '0003.png',
              hour_centerX: 233,
              hour_centerY: 233,
              hour_posX: 32,
              hour_posY: 136,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_analog_clock_time_pointer_minute = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              minute_path: '0004.png',
              minute_centerX: 233,
              minute_centerY: 233,
              minute_posX: 32,
              minute_posY: 203,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            function scale_call() {
              console.log('scale_call()');

                console.log('update scales BATTERY');
                
                let valueBattery = battery.current;
                let targetBattery = 100;
                let progressBattery = valueBattery/targetBattery;
                if (progressBattery > 1) progressBattery = 1;
                let progress_cs_normal_battery = progressBattery;

                if (screenType != hmSetting.screen_type.AOD) {

                  // normal_battery_circle_scale_circle_scale
                  let level = Math.round(progress_cs_normal_battery * 100);
                  if (normal_battery_circle_scale) {
                    normal_battery_circle_scale.setProperty(hmUI.prop.MORE, {                      
                      center_x: 233,
                      center_y: 310,
                      start_angle: 0,
                      end_angle: 360,
                      radius: 43,
                      line_width: 8,
                      corner_flag: 3,
                      color: 0xFFFF0000,
                      show_level: hmUI.show_level.ONLY_NORMAL,
                      level: level,
                    });
                  };
                };

                console.log('update scales BATTERY');
                let progress_cs_idle_battery = progressBattery;

                if (screenType == hmSetting.screen_type.AOD) {

                  // idle_battery_circle_scale_circle_scale
                  let level = Math.round(progress_cs_idle_battery * 100);
                  if (idle_battery_circle_scale) {
                    idle_battery_circle_scale.setProperty(hmUI.prop.MORE, {                      
                      center_x: 233,
                      center_y: 310,
                      start_angle: 0,
                      end_angle: 360,
                      radius: 43,
                      line_width: 8,
                      corner_flag: 3,
                      color: 0xFFFF0000,
                      show_level: hmUI.show_level.ONLY_AOD,
                      level: level,
                    });
                  };
                };

            };

            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                console.log('resume_call()');
                scale_call();
              }),
            });

                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}