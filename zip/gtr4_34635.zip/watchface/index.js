﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        const logger = Logger.getLogger('watchface_SashaCX75');
        //end of ignored block

        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_system_disconnect_img = ''
        let normal_system_clock_img = ''
        let normal_battery_pointer_progress_img_pointer = ''
        let normal_battery_text_text_img = ''
        let normal_heart_rate_pointer_progress_img_pointer = ''
        let normal_heart_rate_text_text_img = ''
        let normal_stress_text_text_img = ''
        let normal_stress_image_progress_img_level = ''
        let normal_stand_image_progress_img_level = ''
        let normal_fat_burning_image_progress_img_level = ''
        let normal_calorie_image_progress_img_level = ''
        let normal_step_image_progress_img_level = ''
        let normal_analog_clock_time_pointer_hour = ''
        let normal_analog_clock_time_pointer_minute = ''
        let normal_analog_clock_time_pointer_second = ''
        let idle_background_bg_img = ''
        let idle_system_disconnect_img = ''
        let idle_system_clock_img = ''
        let idle_battery_pointer_progress_img_pointer = ''
        let idle_battery_text_text_img = ''
        let idle_heart_rate_pointer_progress_img_pointer = ''
        let idle_heart_rate_text_text_img = ''
        let idle_stress_text_text_img = ''
        let idle_stress_image_progress_img_level = ''
        let idle_stand_image_progress_img_level = ''
        let idle_fat_burning_image_progress_img_level = ''
        let idle_calorie_image_progress_img_level = ''
        let idle_step_image_progress_img_level = ''
        let idle_analog_clock_time_pointer_hour = ''
        let idle_analog_clock_time_pointer_minute = ''
        let idle_analog_clock_time_pointer_second = ''


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 466,
              h: 466,
              src: 'bg.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 222,
              y: 30,
              src: 'bluetooth_(10).png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 221,
              y: 415,
              src: 'free-icon-notification-bell-3541850.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_pointer_progress_img_pointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
              src: 'weatherpinter.png',
              center_x: 233,
              center_y: 350,
              x: 10,
              y: 63,
              start_angle: -140,
              end_angle: 143,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 194,
              y: 328,
              font_array: ["Time-S1-0.png","Time-S1-1.png","Time-S1-2.png","Time-S1-3.png","Time-S1-4.png","Time-S1-5.png","Time-S1-6.png","Time-S1-7.png","Time-S1-8.png","Time-S1-9.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_pointer_progress_img_pointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
              src: 'weatherpinter.png',
              center_x: 233,
              center_y: 118,
              x: 12,
              y: 63,
              start_angle: -140,
              end_angle: 143,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 194,
              y: 95,
              font_array: ["Time-S1-0.png","Time-S1-1.png","Time-S1-2.png","Time-S1-3.png","Time-S1-4.png","Time-S1-5.png","Time-S1-6.png","Time-S1-7.png","Time-S1-8.png","Time-S1-9.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_stress_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 90,
              y: 198,
              font_array: ["Time-S1-0.png","Time-S1-1.png","Time-S1-2.png","Time-S1-3.png","Time-S1-4.png","Time-S1-5.png","Time-S1-6.png","Time-S1-7.png","Time-S1-8.png","Time-S1-9.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STRESS,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_stress_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 14,
              y: 0,
              image_array: ["h0.png","h1.png","h2.png","h3.png","h4.png","h5.png"],
              image_length: 6,
              type: hmUI.data_type.STRESS,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_stand_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 284,
              y: 284,
              image_array: ["stand_1.png","stand_2.png","stand_3.png","stand_4.png","stand_5.png","stand_6.png","stand_7.png"],
              image_length: 7,
              type: hmUI.data_type.STAND,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_fat_burning_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 284,
              y: 250,
              image_array: ["fat_1.png","fat_2.png","fat_3.png","fat_4.png","fat_5.png","fat_6.png","fat_7.png"],
              image_length: 7,
              type: hmUI.data_type.FAT_BURNING,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_calorie_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 284,
              y: 217,
              image_array: ["cal_1.png","cal_2.png","cal_3.png","cal_4.png","cal_5.png","cal_6.png","cal_7.png"],
              image_length: 7,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 284,
              y: 185,
              image_array: ["step_1.png","step_2.png","step_3.png","step_4.png","step_5.png","step_6.png","step_7.png"],
              image_length: 7,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_hour = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              hour_path: 'hour.png',
              hour_centerX: 233,
              hour_centerY: 233,
              hour_posX: 16,
              hour_posY: 232,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_minute = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              minute_path: 'min.png',
              minute_centerX: 233,
              minute_centerY: 233,
              minute_posX: 16,
              minute_posY: 232,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_second = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              second_path: 'sec.png',
              second_centerX: 233,
              second_centerY: 233,
              second_posX: 16,
              second_posY: 233,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            idle_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 466,
              h: 466,
              src: 'bg.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 222,
              y: 30,
              src: 'bluetooth_(10).png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 221,
              y: 415,
              src: 'free-icon-notification-bell-3541850.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_battery_pointer_progress_img_pointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
              src: 'weatherpinter.png',
              center_x: 233,
              center_y: 350,
              x: 10,
              y: 63,
              start_angle: -140,
              end_angle: 143,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 194,
              y: 328,
              font_array: ["Time-S1-0.png","Time-S1-1.png","Time-S1-2.png","Time-S1-3.png","Time-S1-4.png","Time-S1-5.png","Time-S1-6.png","Time-S1-7.png","Time-S1-8.png","Time-S1-9.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_heart_rate_pointer_progress_img_pointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
              src: 'weatherpinter.png',
              center_x: 233,
              center_y: 118,
              x: 12,
              y: 63,
              start_angle: -140,
              end_angle: 143,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 194,
              y: 95,
              font_array: ["Time-S1-0.png","Time-S1-1.png","Time-S1-2.png","Time-S1-3.png","Time-S1-4.png","Time-S1-5.png","Time-S1-6.png","Time-S1-7.png","Time-S1-8.png","Time-S1-9.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_stress_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 90,
              y: 198,
              font_array: ["Time-S1-0.png","Time-S1-1.png","Time-S1-2.png","Time-S1-3.png","Time-S1-4.png","Time-S1-5.png","Time-S1-6.png","Time-S1-7.png","Time-S1-8.png","Time-S1-9.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STRESS,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_stress_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 14,
              y: 0,
              image_array: ["h0.png","h1.png","h2.png","h3.png","h4.png","h5.png"],
              image_length: 6,
              type: hmUI.data_type.STRESS,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_stand_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 284,
              y: 284,
              image_array: ["stand_1.png","stand_2.png","stand_3.png","stand_4.png","stand_5.png","stand_6.png","stand_7.png"],
              image_length: 7,
              type: hmUI.data_type.STAND,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_fat_burning_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 284,
              y: 250,
              image_array: ["fat_1.png","fat_2.png","fat_3.png","fat_4.png","fat_5.png","fat_6.png","fat_7.png"],
              image_length: 7,
              type: hmUI.data_type.FAT_BURNING,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_calorie_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 284,
              y: 217,
              image_array: ["cal_1.png","cal_2.png","cal_3.png","cal_4.png","cal_5.png","cal_6.png","cal_7.png"],
              image_length: 7,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_step_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 284,
              y: 185,
              image_array: ["step_1.png","step_2.png","step_3.png","step_4.png","step_5.png","step_6.png","step_7.png"],
              image_length: 7,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_analog_clock_time_pointer_hour = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              hour_path: 'hour.png',
              hour_centerX: 233,
              hour_centerY: 233,
              hour_posX: 16,
              hour_posY: 232,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_analog_clock_time_pointer_minute = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              minute_path: 'min.png',
              minute_centerX: 233,
              minute_centerY: 233,
              minute_posX: 16,
              minute_posY: 232,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_analog_clock_time_pointer_second = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              second_path: 'sec.png',
              second_centerX: 233,
              second_centerY: 233,
              second_posX: 16,
              second_posY: 233,
              second_cover_path: 'A100_066.png',
              second_cover_x: 0,
              second_cover_y: 0,
              show_level: hmUI.show_level.ONLY_AOD,
            });


                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}