﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (()=>{
        //dynamic modify start

        const lang = DeviceRuntimeCore.HmUtils.getLanguage()
        let normal_background_bg_img = ''
        let normal_step_icon_img = ''
        let normal_step_current_text_img = ''
        let normal_step_current_separator_img = ''
        let normal_pai_weekly_text_img = ''
        let normal_pai_weekly_separator_img = ''
        let normal_calorie_current_text_img = ''
        let normal_calorie_current_separator_img = ''
        let normal_distance_text_text_img = ''
        let normal_distance_text_separator_img = ''
        let normal_heart_rate_icon_img = ''
		let normal_heart_rate_text_text_img = ''
        let normal_heart_rate_image_progress_img_level = ''
        let normal_date_img_date_week_img = ''
        let normal_date_img_date_day = ''
        let normal_battery_text_text_img = ''
        let normal_battery_text_separator_img = ''
        let normal_stress_text_text_img = ''
        let normal_stress_image_progress_img_level = ''
        let normal_analog_clock_time_pointer_hour = ''
        let normal_analog_clock_time_pointer_minute = ''
        let normal_analog_clock_time_pointer_second = ''
        let idle_background_bg_img = ''
        let idle_analog_clock_time_pointer_hour = ''
        let idle_analog_clock_time_pointer_minute = ''
		
		let btn_zona1 = ''
        let zona1_num = 0
        let zona1_all = 3
		
		function click_zona1() {
		  zona1_num = (zona1_num + 1) % (zona1_all + 1);
          if (zona1_num == 0) {		
		    normal_heart_rate_icon_img.setProperty(hmUI.prop.VISIBLE, false);
            normal_heart_rate_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_heart_rate_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, false);
			normal_stress_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_stress_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, false);
			normal_battery_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_battery_text_separator_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_date_img_date_week_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_date_img_date_day.setProperty(hmUI.prop.VISIBLE, false);
		    hmUI.showToast({
            });
          };
		  
		 if (zona1_num == 1) {
			normal_heart_rate_icon_img.setProperty(hmUI.prop.VISIBLE, true);
            normal_heart_rate_text_text_img.setProperty(hmUI.prop.VISIBLE, true);
			normal_heart_rate_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, true);
			normal_stress_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_stress_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, false);
			normal_battery_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_battery_text_separator_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_date_img_date_week_img.setProperty(hmUI.prop.VISIBLE, true);
			normal_date_img_date_day.setProperty(hmUI.prop.VISIBLE, true);
		    hmUI.showToast({
            });
          };
		  
		  if (zona1_num == 2) {
			normal_heart_rate_icon_img.setProperty(hmUI.prop.VISIBLE, true);
            normal_heart_rate_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_heart_rate_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, false);
			normal_stress_text_text_img.setProperty(hmUI.prop.VISIBLE, true);
			normal_stress_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, true);
			normal_battery_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_battery_text_separator_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_date_img_date_week_img.setProperty(hmUI.prop.VISIBLE, true);
			normal_date_img_date_day.setProperty(hmUI.prop.VISIBLE, true);
		    hmUI.showToast({
            });
          };
		  
		  if (zona1_num == 3) {
			normal_heart_rate_icon_img.setProperty(hmUI.prop.VISIBLE, true);
            normal_heart_rate_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_heart_rate_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, false);
			normal_stress_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_stress_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, false);
			normal_battery_text_text_img.setProperty(hmUI.prop.VISIBLE, true);
			normal_battery_text_separator_img.setProperty(hmUI.prop.VISIBLE, true);
			normal_date_img_date_week_img.setProperty(hmUI.prop.VISIBLE, true);
			normal_date_img_date_day.setProperty(hmUI.prop.VISIBLE, true);
		    hmUI.showToast({
            });
          };
        }
		
		let btn_zona2 = ''
        let zona2_num = 0
        let zona2_all = 2
		
		function click_zona2() {
		  zona2_num = (zona2_num + 1) % (zona2_all + 1);
          if (zona2_num == 0) {		
		    normal_step_icon_img.setProperty(hmUI.prop.VISIBLE, false);
            normal_step_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_step_current_separator_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_distance_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_distance_text_separator_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_calorie_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_calorie_current_separator_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_pai_weekly_text_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_pai_weekly_separator_img.setProperty(hmUI.prop.VISIBLE, false);
		    hmUI.showToast({
            });
          };
		  
		 if (zona2_num == 1) {
			normal_step_icon_img.setProperty(hmUI.prop.VISIBLE, true);
            normal_step_current_text_img.setProperty(hmUI.prop.VISIBLE, true);
			normal_step_current_separator_img.setProperty(hmUI.prop.VISIBLE, true);
			normal_distance_text_text_img.setProperty(hmUI.prop.VISIBLE, true);
			normal_distance_text_separator_img.setProperty(hmUI.prop.VISIBLE, true);
			normal_calorie_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_calorie_current_separator_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_pai_weekly_text_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_pai_weekly_separator_img.setProperty(hmUI.prop.VISIBLE, false);
		    hmUI.showToast({
            });
          };
		  
		  if (zona2_num == 2) {
			normal_step_icon_img.setProperty(hmUI.prop.VISIBLE, true);
            normal_step_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_step_current_separator_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_distance_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_distance_text_separator_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_calorie_current_text_img.setProperty(hmUI.prop.VISIBLE, true);
			normal_calorie_current_separator_img.setProperty(hmUI.prop.VISIBLE, true);
			normal_pai_weekly_text_img.setProperty(hmUI.prop.VISIBLE, true);
			normal_pai_weekly_separator_img.setProperty(hmUI.prop.VISIBLE, true);
		    hmUI.showToast({
            });
          };
        }
		
		let btn_bezel = ''
        let bezel_num = 1
        let bezel_all = 6
     
        function click_Bezel() {
            if(bezel_num>=bezel_all) {bezel_num=1;}
            else { bezel_num=bezel_num+1;}
            hmUI.showToast({text: "<BackGround> " + parseInt(bezel_num) });
            normal_background_bg_img.setProperty(hmUI.prop.SRC, "bg_" + parseInt(bezel_num) + ".png");
        }
		
		let delay_Timer = null;
        let clicks = 0;
        let clicksDelay = 400;       
		

          function checkClicks() {

            switch(clicks) {
              case 1:
                click_Bezel();
             break;
              case 2:
                click_bot_circle_Switcher();
             break;
              default:
             break;
           }
            
           timer.stopTimer(delay_Timer);
           clicks = 0;

          }
            
        
      
              function getClick() {		
      
            clicks++;
            if(delay_Timer) timer.stopTimer(delay_Timer);
            delay_Timer = timer.createTimer(clicksDelay, 0, checkClicks, {});
      
              }
		
		let bot_circle_btn = ''
        let bot_circle_state = 0 
        let bot_circle_state_txt = ''

        function click_bot_circle_Switcher() {

          let bot_circle_state_total = 4;

          bot_circle_state = (bot_circle_state + 1) % bot_circle_state_total;

          switch (bot_circle_state) {

              case 0:
 
                  normal_analog_clock_time_pointer_hour.setProperty(hmUI.prop.MORE, {
                    hour_path: 'h_2.png',
                    hour_centerX: 233,
                    hour_centerY: 233,
                    hour_posX: 26,
                    hour_posY: 232,
                    show_level: hmUI.show_level.ONLY_NORMAL,
                  });
      
                  normal_analog_clock_time_pointer_minute.setProperty(hmUI.prop.MORE, {
                    minute_path: 'm_2.png',
                    minute_centerX: 233,
                    minute_centerY: 233,
                    minute_posX: 27,
                    minute_posY: 232,
                    show_level: hmUI.show_level.ONLY_NORMAL,
                  });
      
                  bot_circle_state_txt = 'Hands 1';
                  break;

              case 1:

                normal_analog_clock_time_pointer_hour.setProperty(hmUI.prop.MORE, {
                  hour_path: 'h_3.png',
                  hour_centerX: 233,
                  hour_centerY: 233,
                  hour_posX: 26,
                  hour_posY: 232,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });
    
                normal_analog_clock_time_pointer_minute.setProperty(hmUI.prop.MORE, {
                  minute_path: 'm_3.png',
                  minute_centerX: 233,
                  minute_centerY: 233,
                  minute_posX: 27,
                  minute_posY: 232,
                 show_level: hmUI.show_level.ONLY_NORMAL,
                });
   
              bot_circle_state_txt = 'Hands 2';
                  break;

              case 2:

                    normal_analog_clock_time_pointer_hour.setProperty(hmUI.prop.MORE, {
                      hour_path: 'h_4.png',
                      hour_centerX: 233,
                      hour_centerY: 233,
                      hour_posX: 26,
                      hour_posY: 232,
                      show_level: hmUI.show_level.ONLY_NORMAL,
                    });
        
                    normal_analog_clock_time_pointer_minute.setProperty(hmUI.prop.MORE, {
                      minute_path: 'm_4.png',
                      minute_centerX: 233,
                      minute_centerY: 233,
                      minute_posX: 27,
                      minute_posY: 232,
                      show_level: hmUI.show_level.ONLY_NORMAL,
                    });
       
                  bot_circle_state_txt = 'Hands 3';
              break;
			  
			  case 3:

                    normal_analog_clock_time_pointer_hour.setProperty(hmUI.prop.MORE, {
                      hour_path: 'h_5.png',
                      hour_centerX: 233,
                      hour_centerY: 233,
                      hour_posX: 22,
                      hour_posY: 152,
                      show_level: hmUI.show_level.ONLY_NORMAL,
                    });
        
                    normal_analog_clock_time_pointer_minute.setProperty(hmUI.prop.MORE, {
                      minute_path: 'm_5.png',
                      minute_centerX: 233,
                      minute_centerY: 233,
                      minute_posX: 36,
                      minute_posY: 249,
                      show_level: hmUI.show_level.ONLY_NORMAL,
                    });
       
                  bot_circle_state_txt = 'Hands 4';
              break;
    
              default:
                  break;
          }

          hmUI.showToast({ text: bot_circle_state_txt });
      }


        //dynamic modify end
        const e = __$$hmAppManager$$__.currentApp;
        const o = e.current
          , {px: i} = (new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(e,o)),
        e.__globals__)
          , n = Logger.getLogger("watchface6");
        o.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            console.log('Watch_Face.ScreenNormal');
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 466,
              h: 466,
              src: 'bg_1.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: -5,
              y: 0,
              src: 'style_wfs_30e2e7c5_5691_4cef_9c65_90652f954f65_2.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 88,
              y: 235,
              font_array: ["n_0.png","n_1.png","n_2.png","n_3.png","n_4.png","n_5.png","n_6.png","n_7.png","n_8.png","n_9.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 104,
              y: 180,
              src: 'step.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_pai_weekly_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 312,
              y: 235,
              font_array: ["n_0.png","n_1.png","n_2.png","n_3.png","n_4.png","n_5.png","n_6.png","n_7.png","n_8.png","n_9.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.PAI_WEEKLY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_pai_weekly_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 313,
              y: 178,
              src: 'pai3.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_calorie_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 94,
              y: 235,
              font_array: ["n_0.png","n_1.png","n_2.png","n_3.png","n_4.png","n_5.png","n_6.png","n_7.png","n_8.png","n_9.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_calorie_current_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 105,
              y: 180,
              src: 'sport_remind_icon_calorie.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_distance_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 299,
              y: 235,
              font_array: ["n_0.png","n_1.png","n_2.png","n_3.png","n_4.png","n_5.png","n_6.png","n_7.png","n_8.png","n_9.png"],
              padding: false,
              h_space: 0,
              dot_image: 'dot.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.DISTANCE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_distance_text_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 314,
              y: 178,
              src: 'sport_remind_track_yaw.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: -5,
              y: 0,
              src: 'style_wfs_30e2e7c5_5691_4cef_9c65_90652f954f65_1.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
			
			normal_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 209,
              y: 343,
              font_array: ["n_0.png","n_1.png","n_2.png","n_3.png","n_4.png","n_5.png","n_6.png","n_7.png","n_8.png","n_9.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 212,
              y: 287,
              image_array: ["P_1.png","P_2.png","P_3.png","P_4.png","P_5.png","P_6.png"],
              image_length: 6,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
			
			let dned=["week_0.png","week_1.png","week_2.png","week_3.png","week_4.png","week_5.png","week_6.png"]
			if(lang=='ru-RU'){
				dned=["weekru_0.png","weekru_1.png","weekru_2.png","weekru_3.png","weekru_4.png","weekru_5.png","weekru_6.png"]
			}
            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 197,
              y: 146,
              week_en: dned,
              week_tc: ["week_0.png","week_1.png","week_2.png","week_3.png","week_4.png","week_5.png","week_6.png"],
              week_sc: ["week_0.png","week_1.png","week_2.png","week_3.png","week_4.png","week_5.png","week_6.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 215,
              day_startY: 92,
              day_sc_array: ["n_0.png","n_1.png","n_2.png","n_3.png","n_4.png","n_5.png","n_6.png","n_7.png","n_8.png","n_9.png"],
              day_tc_array: ["n_0.png","n_1.png","n_2.png","n_3.png","n_4.png","n_5.png","n_6.png","n_7.png","n_8.png","n_9.png"],
              day_en_array: ["n_0.png","n_1.png","n_2.png","n_3.png","n_4.png","n_5.png","n_6.png","n_7.png","n_8.png","n_9.png"],
              day_zero: 1,
              day_space: 0,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 201,
              y: 343,
              font_array: ["n_0.png","n_1.png","n_2.png","n_3.png","n_4.png","n_5.png","n_6.png","n_7.png","n_8.png","n_9.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'unit_1.png',
              unit_tc: 'unit_1.png',
              unit_en: 'unit_1.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 210,
              y: 286,
              src: 'stress.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_stress_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 211,
              y: 343,
              font_array: ["n_0.png","n_1.png","n_2.png","n_3.png","n_4.png","n_5.png","n_6.png","n_7.png","n_8.png","n_9.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STRESS,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_stress_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 212,
              y: 287,
              image_array: ["stress_0.png","stress_1.png","stress_2.png","stress_3.png","stress_4.png","stress_5.png"],
              image_length: 6,
              type: hmUI.data_type.STRESS,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_hour = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              hour_path: 'h_2.png',
              hour_centerX: 233,
              hour_centerY: 233,
              hour_posX: 26,
              hour_posY: 232,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_minute = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              minute_path: 'm_2.png',
              minute_centerX: 233,
              minute_centerY: 233,
              minute_posX: 27,
              minute_posY: 232,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_second = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              second_path: 'sec.png',
              second_centerX: 233,
              second_centerY: 233,
              second_posX: 27,
              second_posY: 232,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            console.log('Watch_Face.ScreenAOD');
            idle_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 466,
              h: 466,
              src: 'aod.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_analog_clock_time_pointer_hour = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              hour_path: 'aod_h.png',
              hour_centerX: 233,
              hour_centerY: 233,
              hour_posX: 17,
              hour_posY: 148,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_analog_clock_time_pointer_minute = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              minute_path: 'aod_m.png',
              minute_centerX: 233,
              minute_centerY: 233,
              minute_posX: 21,
              minute_posY: 228,
              show_level: hmUI.show_level.ONLY_AOD,
            });
            console.log('Watch_Face.Shortcuts');

            btn_zona2 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 90,
              y: 199,
              text: '',
              w: 78,
              h: 78,
              normal_src: 'Empty.png',
              press_src: 'Empty.png',
              click_func: () => {
				click_zona2();
				click_Vibrate();
             },
			  longpress_func: () => {
             hmApp.startApp({ url: "activityAppScreen", native: true });
             },
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            btn_zona2.setProperty(hmUI.prop.VISIBLE, true);
			normal_step_icon_img.setProperty(hmUI.prop.VISIBLE, false);
            normal_step_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_step_current_separator_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_distance_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_distance_text_separator_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_calorie_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_calorie_current_separator_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_pai_weekly_text_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_pai_weekly_separator_img.setProperty(hmUI.prop.VISIBLE, false);

            btn_zona1 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 194,
              y: 301,
              text: '',
              w: 78,
              h: 78,
              normal_src: 'Empty.png',
              press_src: 'Empty.png',
              click_func: () => {
				click_zona1();
				click_Vibrate();
             },
			  longpress_func: () => {
             hmApp.startApp({ url: "heart_app_Screen", native: true });
             },
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            btn_zona1.setProperty(hmUI.prop.VISIBLE, true);
			normal_heart_rate_icon_img.setProperty(hmUI.prop.VISIBLE, false);
            normal_heart_rate_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_heart_rate_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, false);
			normal_stress_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_stress_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, false);
			normal_battery_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_battery_text_separator_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_date_img_date_week_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_date_img_date_day.setProperty(hmUI.prop.VISIBLE, false);

            bot_circle_btn = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 197,
              y: 197,
              text: '',
              w: 73,
              h: 73,
              normal_src: 'Empty.png',
              press_src: 'Empty.png',
              click_func: () => {
                  getClick();
              },
			  longpress_func: () => {
             hmApp.startApp({ url: "CountdownAppScreen", native: true });
             },
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
              bot_circle_btn.setProperty(hmUI.prop.VISIBLE, true);


                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}