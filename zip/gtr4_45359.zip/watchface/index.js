try {
    (() => {
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() { return __$$app$$__.app; }
        function getCurrentPage() { return __$$app$$__.current && __$$app$$__.current.module; }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
// Chrono Yellow - Amazfit GTR 4 (466x466), Zepp OS 2.x
const A = (n) => n + '.png'
const digits = (p) => Array.from({ length: 10 }, (_, i) => A(p + '_' + i))
const AD = digits('a'), T = digits('t'), SM = digits('s'), YL = digits('y'), DY = digits('d')
const ON = hmUI.show_level.ONLY_NORMAL
const arr = (p, n) => Array.from({ length: n }, (_, i) => A(p + '_' + i))

__$$module$$__.module = DeviceRuntimeCore.WatchFace({
  build() {
    hmUI.createWidget(hmUI.widget.IMG, { x: 0, y: 0, w: 466, h: 466, src: A('bg'), show_level: ON })

    const TW = 44, CW = 22, X0 = 79, TY = 190
    hmUI.createWidget(hmUI.widget.IMG_TIME, {
      hour_zero: 1, hour_startX: X0, hour_startY: TY, hour_array: T, hour_space: 0, hour_follow: 0, hour_align: hmUI.align.LEFT,
      minute_zero: 1, minute_startX: X0 + 2 * TW + CW, minute_startY: TY, minute_array: T, minute_space: 0, minute_follow: 0, minute_align: hmUI.align.LEFT,
      second_zero: 1, second_startX: X0 + 4 * TW + 2 * CW, second_startY: TY, second_array: T, second_space: 0, second_follow: 0, second_align: hmUI.align.LEFT,
      show_level: ON
    })

    hmUI.createWidget(hmUI.widget.IMG_WEEK, { x: 97, y: 86, week_en: arr('wk', 7), week_tc: arr('wk', 7), week_sc: arr('wk', 7), show_level: ON })
    hmUI.createWidget(hmUI.widget.IMG_DATE, {
      month_startX: 298, month_startY: 86, month_is_character: true,
      month_en_array: arr('mo', 12), month_sc_array: arr('mo', 12), month_tc_array: arr('mo', 12), show_level: ON
    })
    hmUI.createWidget(hmUI.widget.IMG_DATE, {
      day_startX: 200, day_startY: 72, day_zero: 0, day_space: 1, day_is_character: false, day_align: hmUI.align.CENTER_H,
      day_en_array: DY, day_sc_array: DY, day_tc_array: DY, show_level: ON
    })

    hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
      x: 80, y: 124, image_array: arr('w', 29), image_length: 29, type: hmUI.data_type.WEATHER_CURRENT, show_level: ON
    })
    hmUI.createWidget(hmUI.widget.TEXT_IMG, {
      x: 126, y: 130, w: 70, h: 22, font_array: SM, h_space: 1, align_h: hmUI.align.LEFT,
      type: hmUI.data_type.WEATHER_CURRENT, unit_en: A('s_deg'), unit_sc: A('s_deg'), unit_tc: A('s_deg'),
      negative_image: A('s_minus'), show_level: ON
    })
    hmUI.createWidget(hmUI.widget.TEXT_IMG, {
      x: 239, y: 131, w: 129, h: 22, font_array: SM, h_space: 1, align_h: hmUI.align.RIGHT,
      type: hmUI.data_type.BATTERY, unit_en: A('s_pct'), unit_sc: A('s_pct'), unit_tc: A('s_pct'), show_level: ON
    })
    hmUI.createWidget(hmUI.widget.TEXT_IMG, {
      x: 56, y: 277, w: 100, h: 22, font_array: SM, h_space: 1, align_h: hmUI.align.CENTER_H,
      type: hmUI.data_type.DISTANCE, dot_image: A('s_dot'), show_level: ON
    })
    hmUI.createWidget(hmUI.widget.TEXT_IMG, {
      x: 163, y: 277, w: 139, h: 22, font_array: SM, h_space: 1, align_h: hmUI.align.CENTER_H,
      type: hmUI.data_type.HEART, invalid_image: A('s_minus'), show_level: ON
    })
    hmUI.createWidget(hmUI.widget.TEXT_IMG, {
      x: 312, y: 277, w: 88, h: 22, font_array: SM, h_space: 1, align_h: hmUI.align.CENTER_H,
      type: hmUI.data_type.CAL, show_level: ON
    })
    hmUI.createWidget(hmUI.widget.TEXT_IMG, {
      x: 127, y: 348, w: 207, h: 29, font_array: YL, h_space: 1, align_h: hmUI.align.CENTER_H,
      type: hmUI.data_type.STEP, show_level: ON
    })

    hmUI.createWidget(hmUI.widget.IMG, { x: 0, y: 0, w: 466, h: 466, src: A('aod_bg'), show_level: hmUI.show_level.ONLY_AOD })
    hmUI.createWidget(hmUI.widget.IMG_TIME, {
      hour_zero: 1, hour_startX: 134, hour_startY: 212, hour_array: AD, hour_space: 0, hour_follow: 0, hour_align: hmUI.align.LEFT,
      minute_zero: 1, minute_startX: 134+2*44+22, minute_startY: 212, minute_array: AD, minute_space: 0, minute_follow: 0, minute_align: hmUI.align.LEFT,
      show_level: hmUI.show_level.ONLY_AOD
    })

    const tap = (x, y, w, h, type) =>
      hmUI.createWidget(hmUI.widget.IMG_CLICK, { x, y, w, h, type, show_level: ON })
    tap(76, 119, 100, 44, hmUI.data_type.WEATHER)
    tap(303, 119, 104, 44, hmUI.data_type.BATTERY)
    tap(48, 171, 374, 64, hmUI.data_type.ALARM_CLOCK)
    tap(56, 275, 100, 56, hmUI.data_type.DISTANCE)
    tap(163, 275, 139, 56, hmUI.data_type.HEART)
    tap(312, 275, 92, 56, hmUI.data_type.CAL)
    tap(151, 335, 167, 80, hmUI.data_type.STEP)

    // ---- working chrono: tap play/pause icon (or label) to start/stop, tap reset icon to clear ----
    let acc = 0, startTs = 0, running = false, tmr = null
    const pad = (n, l) => ('00' + n).slice(-l)
    const fmt = (ms) => {
      const h = Math.floor(ms / 3600000), m = Math.floor(ms / 60000) % 60, s = Math.floor(ms / 1000) % 60, d = Math.floor(ms / 100) % 10
      return h > 0 ? h + ':' + pad(m, 2) + ':' + pad(s, 2) : pad(m, 2) + ':' + pad(s, 2) + '.' + d
    }
    const lbl = hmUI.createWidget(hmUI.widget.TEXT, {
      x: 171, y: 237, w: 133, h: 30, text: 'CHRONO', text_size: 17, color: 0xE8C60C,
      align_h: hmUI.align.CENTER_H, align_v: hmUI.align.CENTER_V, show_level: ON
    })
    const icPlay = hmUI.createWidget(hmUI.widget.IMG, { x: 47, y: 243, src: A('ic_play'), show_level: ON })
    const icPause = hmUI.createWidget(hmUI.widget.IMG, { x: 47, y: 243, src: A('ic_pause'), show_level: ON })
    icPause.setProperty(hmUI.prop.VISIBLE, false)
    const elapsed = () => acc + (running ? new Date().getTime() - startTs : 0)
    const refresh = () => lbl.setProperty(hmUI.prop.TEXT, fmt(elapsed()))
    const stopTmr = () => { if (tmr) { timer.stopTimer(tmr); tmr = null } }
    const toggle = () => {
      if (running) {
        acc += new Date().getTime() - startTs; running = false; stopTmr()
        icPlay.setProperty(hmUI.prop.VISIBLE, true); icPause.setProperty(hmUI.prop.VISIBLE, false)
        refresh()
      } else {
        startTs = new Date().getTime(); running = true
        tmr = timer.createTimer(0, 100, refresh, {})
        icPlay.setProperty(hmUI.prop.VISIBLE, false); icPause.setProperty(hmUI.prop.VISIBLE, true)
      }
    }
    const reset = () => {
      stopTmr(); running = false; acc = 0
      lbl.setProperty(hmUI.prop.TEXT, 'CHRONO')
      icPlay.setProperty(hmUI.prop.VISIBLE, true); icPause.setProperty(hmUI.prop.VISIBLE, false)
    }
    const btn = (x, y, w, h, fn) => hmUI.createWidget(hmUI.widget.BUTTON, {
      x, y, w, h, normal_src: A('tap'), press_src: A('tap'), click_func: fn, show_level: ON
    })
    btn(28, 232, 56, 40, toggle)
    btn(171, 232, 133, 40, toggle)
    btn(378, 232, 56, 40, reset)

  },
  onInit() {},
  onDestroy() { try { timer && 0 } catch (e) {} }
})

    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
}
