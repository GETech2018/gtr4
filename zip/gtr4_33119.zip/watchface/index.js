﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        const logger = Logger.getLogger('watchface_SashaCX75');
        //end of ignored block

        //dynamic modify start

        
        // let normal_background_bg_img = ''
        let img = ''
        let prefix_img = 'bg_'
        let img_index = 1
        let img_count = 5
        let normal_system_connected_img = ''
        let normal_system_disconnect_img = ''
        let normal_battery_text_text_img = ''
        let normal_battery_text_separator_img = ''
        let normal_battery_image_progress_img_level = ''
        let normal_temperature_current_text_img = ''
        let normal_weather_image_progress_img_level = ''
        let normal_stress_text_text_img = ''
        let normal_distance_text_text_img = ''
        let normal_heart_rate_text_text_img = ''
        let normal_calorie_current_text_img = ''
        let normal_step_current_text_img = ''
        let normal_date_img_date_year = ''
        let normal_date_img_date_month = ''
        let normal_date_month_separator_img = ''
        let normal_date_img_date_day = ''
        let normal_date_day_separator_img = ''
        let normal_digital_clock_img_time_AmPm = ''
        let normal_digital_clock_img_time = ''
        let normal_digital_clock_hour_separator_img = ''
        let idle_battery_text_text_img = ''
        let idle_battery_text_separator_img = ''
        let idle_battery_image_progress_img_level = ''
        let idle_date_img_date_year = ''
        let idle_date_img_date_month = ''
        let idle_date_month_separator_img = ''
        let idle_date_img_date_day = ''
        let idle_date_day_separator_img = ''
        let idle_digital_clock_img_time_AmPm = ''
        let idle_digital_clock_img_time = ''
        let idle_digital_clock_hour_separator_img = ''


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            // normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
            //   x: 0,
            //   y: 0,
            //   w: 466,
            //   h: 466,
            //   src: 'bg_1.png',
            //   show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 466,
              h: 466,
              src: prefix_img + parseInt(img_index) + '.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 218,
              y: 440,
              src: 'blue.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 218,
              y: 440,
              src: 'blue2.png',
              type: hmUI.system_status.CONNECTED,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 155,
              y: 32,
              font_array: ["10.png","11.png","12.png","13.png","14.png","15.png","16.png","17.png","18.png","19.png"],
              padding: false,
              h_space: 3,
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 211,
              y: 32,
              src: 'porce.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 241,
              y: 28,
              image_array: ["40.png","41.png","42.png","43.png","44.png"],
              image_length: 5,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 380,
              y: 266,
              font_array: ["10.png","11.png","12.png","13.png","14.png","15.png","16.png","17.png","18.png","19.png"],
              padding: false,
              h_space: 4,
              unit_sc: 'grau.png',
              unit_tc: 'grau.png',
              unit_en: 'grau.png',
              negative_image: 'menos.png',
              invalid_image: 'inter.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 384,
              y: 206,
              image_array: ["100.png","101.png","102.png","103.png","104.png","105.png","106.png","107.png","108.png","109.png","110.png","111.png","112.png","113.png","114.png","115.png","116.png","117.png","118.png","119.png","120.png","121.png","122.png","123.png","124.png","125.png","126.png","127.png","128.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_stress_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 226,
              y: 264,
              font_array: ["30.png","31.png","32.png","33.png","34.png","35.png","36.png","37.png","38.png","39.png"],
              padding: true,
              h_space: 4,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STRESS,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_distance_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 306,
              y: 322,
              font_array: ["20.png","21.png","22.png","23.png","24.png","25.png","26.png","27.png","28.png","29.png"],
              padding: false,
              h_space: 3,
              dot_image: 'pont.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.DISTANCE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 88,
              y: 322,
              font_array: ["20.png","21.png","22.png","23.png","24.png","25.png","26.png","27.png","28.png","29.png"],
              padding: false,
              h_space: 4,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_calorie_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 182,
              y: 390,
              font_array: ["20.png","21.png","22.png","23.png","24.png","25.png","26.png","27.png","28.png","29.png"],
              padding: false,
              h_space: 5,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 89,
              y: 264,
              font_array: ["30.png","31.png","32.png","33.png","34.png","35.png","36.png","37.png","38.png","39.png"],
              padding: false,
              h_space: 3,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_year = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              year_startX: 243,
              year_startY: 200,
              year_sc_array: ["30.png","31.png","32.png","33.png","34.png","35.png","36.png","37.png","38.png","39.png"],
              year_tc_array: ["30.png","31.png","32.png","33.png","34.png","35.png","36.png","37.png","38.png","39.png"],
              year_en_array: ["30.png","31.png","32.png","33.png","34.png","35.png","36.png","37.png","38.png","39.png"],
              year_zero: 1,
              year_space: 4,
              year_align: hmUI.align.CENTER_H,
              year_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_month = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 173,
              month_startY: 200,
              month_sc_array: ["30.png","31.png","32.png","33.png","34.png","35.png","36.png","37.png","38.png","39.png"],
              month_tc_array: ["30.png","31.png","32.png","33.png","34.png","35.png","36.png","37.png","38.png","39.png"],
              month_en_array: ["30.png","31.png","32.png","33.png","34.png","35.png","36.png","37.png","38.png","39.png"],
              month_zero: 1,
              month_space: 3,
              month_align: hmUI.align.CENTER_H,
              month_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_month_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 225,
              y: 199,
              src: 'menos.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 106,
              day_startY: 200,
              day_sc_array: ["30.png","31.png","32.png","33.png","34.png","35.png","36.png","37.png","38.png","39.png"],
              day_tc_array: ["30.png","31.png","32.png","33.png","34.png","35.png","36.png","37.png","38.png","39.png"],
              day_en_array: ["30.png","31.png","32.png","33.png","34.png","35.png","36.png","37.png","38.png","39.png"],
              day_zero: 1,
              day_space: 2,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_day_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 154,
              y: 199,
              src: 'menos.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time_AmPm = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              am_x: 38,
              am_y: 206,
              am_sc_path: 'am.png',
              am_en_path: 'am.png',
              pm_x: 38,
              pm_y: 206,
              pm_sc_path: 'pm.png',
              pm_en_path: 'pm.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 80,
              hour_startY: 84,
              hour_array: ["00.png","01.png","02.png","03.png","04.png","05.png","06.png","07.png","08.png","09.png"],
              hour_zero: 1,
              hour_space: 10,
              hour_align: hmUI.align.CENTER_H,

              minute_startX: 256,
              minute_startY: 84,
              minute_array: ["00.png","01.png","02.png","03.png","04.png","05.png","06.png","07.png","08.png","09.png"],
              minute_zero: 1,
              minute_space: 10,
              minute_follow: 0,
              minute_align: hmUI.align.CENTER_H,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_hour_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 217,
              y: 85,
              src: 'ponts.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });



            idle_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 213,
              y: 130,
              font_array: ["10.png","11.png","12.png","13.png","14.png","15.png","16.png","17.png","18.png","19.png"],
              padding: false,
              h_space: 5,
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_battery_text_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 275,
              y: 130,
              src: 'porce.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_battery_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 314,
              y: 127,
              image_array: ["40.png","41.png","42.png","43.png","44.png"],
              image_length: 5,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_year = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              year_startX: 264,
              year_startY: 291,
              year_sc_array: ["30.png","31.png","32.png","33.png","34.png","35.png","36.png","37.png","38.png","39.png"],
              year_tc_array: ["30.png","31.png","32.png","33.png","34.png","35.png","36.png","37.png","38.png","39.png"],
              year_en_array: ["30.png","31.png","32.png","33.png","34.png","35.png","36.png","37.png","38.png","39.png"],
              year_zero: 1,
              year_space: 4,
              year_align: hmUI.align.CENTER_H,
              year_is_character: false,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_month = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 185,
              month_startY: 291,
              month_sc_array: ["30.png","31.png","32.png","33.png","34.png","35.png","36.png","37.png","38.png","39.png"],
              month_tc_array: ["30.png","31.png","32.png","33.png","34.png","35.png","36.png","37.png","38.png","39.png"],
              month_en_array: ["30.png","31.png","32.png","33.png","34.png","35.png","36.png","37.png","38.png","39.png"],
              month_zero: 1,
              month_space: 3,
              month_align: hmUI.align.CENTER_H,
              month_is_character: false,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_month_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 242,
              y: 294,
              src: 'menos.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 114,
              day_startY: 291,
              day_sc_array: ["30.png","31.png","32.png","33.png","34.png","35.png","36.png","37.png","38.png","39.png"],
              day_tc_array: ["30.png","31.png","32.png","33.png","34.png","35.png","36.png","37.png","38.png","39.png"],
              day_en_array: ["30.png","31.png","32.png","33.png","34.png","35.png","36.png","37.png","38.png","39.png"],
              day_zero: 1,
              day_space: 2,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_day_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 167,
              y: 294,
              src: 'menos.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time_AmPm = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              am_x: 95,
              am_y: 130,
              am_sc_path: 'am.png',
              am_en_path: 'am.png',
              pm_x: 95,
              pm_y: 130,
              pm_sc_path: 'pm.png',
              pm_en_path: 'pm.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 82,
              hour_startY: 174,
              hour_array: ["00.png","01.png","02.png","03.png","04.png","05.png","06.png","07.png","08.png","09.png"],
              hour_zero: 1,
              hour_space: 10,
              hour_align: hmUI.align.CENTER_H,

              minute_startX: 256,
              minute_startY: 174,
              minute_array: ["00.png","01.png","02.png","03.png","04.png","05.png","06.png","07.png","08.png","09.png"],
              minute_zero: 1,
              minute_space: 10,
              minute_follow: 0,
              minute_align: hmUI.align.CENTER_H,

              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_hour_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 218,
              y: 180,
              src: 'ponts.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            // Button to switch images. This block should be after all blocks with display elements.
            hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 100,  // x coordinate of the button
              y: 100,  // y coordinate of the button
              text: '',
              w: 280,  // button width
              h: 280,  // button height
              normal_src: 'transparent_img.png',  // transparent image
              press_src: 'transparent_img.png',  // transparent image
              show_level: hmUI.show_level.ONLY_NORMAL,
              click_func: () => {
                img_index++;
                if(img_index > img_count) img_index = 1;
                // hmUI.showToast({text: 'Background ' + parseInt(img_index) });  // Remove if you do not want to display a message with the number of the selected image
                img.setProperty(hmUI.prop.SRC, prefix_img + parseInt(img_index) + '.png');
              }
            });


                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}