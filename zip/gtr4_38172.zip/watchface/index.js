﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        const logger = Logger.getLogger('watchface_SashaCX75');
        //end of ignored block

        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_motion_animation_img_1 = '';
        let normal_motion_animation_paramX_1 = null;
        let normal_motion_animation_paramY_1 = null;
        let normal_motion_animation_lastTime_1 = 0;
        let timer_anim_motion_1;
        let timer_anim_motion_1_mirror = false;
        let normal_motion_animation_paramX_1_mirror = null;
        let normal_motion_animation_paramY_1_mirror = null;
        let normal_motion_animation_count_1 = 0;
        let normal_motion_animation_img_2 = '';
        let normal_motion_animation_paramX_2 = null;
        let normal_motion_animation_paramY_2 = null;
        let normal_motion_animation_lastTime_2 = 0;
        let timer_anim_motion_2;
        let timer_anim_motion_2_mirror = false;
        let normal_motion_animation_paramX_2_mirror = null;
        let normal_motion_animation_paramY_2_mirror = null;
        let normal_motion_animation_count_2 = 0;
        let normal_image_img = ''

        let normal_date_img_date_week_img = ''
        let normal_date2_img_date_week_img = ''
        let normal_date3_img_date_week_img = ''
        let normal_date4_img_date_week_img = ''
        let normal_date5_img_date_week_img = ''
        let normal_date6_img_date_week_img = ''

        let normal_date_img_date_day = ''
        let normal_date2_img_date_day = ''
        let normal_date3_img_date_day = ''
        let normal_date4_img_date_day = ''
        let normal_date5_img_date_day = ''
        let normal_date6_img_date_day = ''

        let normal_battery_text_text_img = ''
        let normal_battery2_text_text_img = ''
        let normal_battery3_text_text_img = ''
        let normal_battery4_text_text_img = ''
        let normal_battery5_text_text_img = ''
        let normal_battery6_text_text_img = ''

        let normal_step_TextRotate = new Array(5);

        let normal_step_TextRotate_ASCIIARRAY = new Array(10);
        let normal_step2_TextRotate_ASCIIARRAY = new Array(10);
        let normal_step3_TextRotate_ASCIIARRAY = new Array(10);
        let normal_step4_TextRotate_ASCIIARRAY = new Array(10);
        let normal_step5_TextRotate_ASCIIARRAY = new Array(10);
        let normal_step6_TextRotate_ASCIIARRAY = new Array(10);

        let normal_step_TextRotate_img_width = 22;
        let normal_step_TextRotate_error_img_width = 22;
        let normal_heart_rate_TextRotate = new Array(5);

        let normal_heart_rate_TextRotate_ASCIIARRAY = new Array(10);
        let normal_heart2_rate_TextRotate_ASCIIARRAY = new Array(10);
        let normal_heart3_rate_TextRotate_ASCIIARRAY = new Array(10);
        let normal_heart4_rate_TextRotate_ASCIIARRAY = new Array(10);
        let normal_heart5_rate_TextRotate_ASCIIARRAY = new Array(10);
        let normal_heart6_rate_TextRotate_ASCIIARRAY = new Array(10);
       
        let normal_heart_rate_TextRotate_img_width = 22;
        let normal_heart_rate_TextRotate_error_img_width = 22;

        let normal_digital_clock_img_time = ''
        let normal_digital2_clock_img_time = ''
        let normal_digital3_clock_img_time = ''
        let normal_digital4_clock_img_time = ''
        let normal_digital5_clock_img_time = ''
        let normal_digital6_clock_img_time = ''
        let normal_digital7_clock_img_time = ''
        let normal_digital8_clock_img_time = ''
       

        let idle_background_bg_img = ''
        let idle_image_img = ''
        let idle_date_img_date_week_img = ''
        let idle_date_img_date_day = ''
        let idle_battery_text_text_img = ''
        let idle_step_TextRotate = new Array(5);
        let idle_step_TextRotate_ASCIIARRAY = new Array(10);
        let idle_step_TextRotate_img_width = 22;
        let idle_step_TextRotate_error_img_width = 22;
        let idle_heart_rate_TextRotate = new Array(5);
        let idle_heart_rate_TextRotate_ASCIIARRAY = new Array(10);
        let idle_heart_rate_TextRotate_img_width = 22;
        let idle_heart_rate_TextRotate_error_img_width = 22;
        let idle_digital_clock_img_time = ''

        let normal_stopwatch_jumpable_img_click = ''
        let normal_countdown_jumpable_img_click = ''
        let normal_sunrise_jumpable_img_click = ''
        let normal_temperature_jumpable_img_click = ''
        let normal_spo2_jumpable_img_click = ''
        let normal_heart_jumpable_img_click = ''
        let normal_step_jumpable_img_click = ''
     
        // Activity select
        let btnbackground = ''
        let backgroundnumber = 1
        let totalpictures = 6
        let cc = 0

        function click_Background() {
            if(backgroundnumber>=totalpictures) {
            backgroundnumber=1;
                UpdateBackgroundOne();
                }
            else {
                backgroundnumber=backgroundnumber+1;
                if(backgroundnumber==2) {
                  UpdateBackgroundTwo();
                }
                if(backgroundnumber==3) {
                  UpdateBackgroundThree();
                }
                if(backgroundnumber==4) {
                  UpdateBackgroundFour();
                }
                if(backgroundnumber==5) {
                  UpdateBackgroundFive();
                }
                if(backgroundnumber==6) {
                  UpdateBackgroundSix();
                }

    

            }
          if(backgroundnumber==1) hmUI.showToast({text: 'Yellow'});
          if(backgroundnumber==2) hmUI.showToast({text: 'Blue'});
          if(backgroundnumber==3) hmUI.showToast({text: 'Green'});
          if(backgroundnumber==4) hmUI.showToast({text: 'Pink'});
          if(backgroundnumber==5) hmUI.showToast({text: 'Orange'});
          if(backgroundnumber==6) hmUI.showToast({text: 'Black & White'});

        }

        //ONE
        function UpdateBackgroundOne(){

normal_background_bg_img.setProperty(hmUI.prop.SRC, "main" + parseInt(backgroundnumber) + ".png");
normal_motion_animation_img_1.setProperty(hmUI.prop.SRC, "animation/anim_0.png");
normal_motion_animation_img_2.setProperty(hmUI.prop.SRC, "animation/anim_0.png");


        normal_battery_text_text_img.setProperty(hmUI.prop.VISIBLE, true);
        normal_battery2_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
        normal_battery3_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
        normal_battery4_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
     normal_battery5_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
     normal_battery6_text_text_img.setProperty(hmUI.prop.VISIBLE, false);

        normal_date_img_date_week_img.setProperty(hmUI.prop.VISIBLE, true);
        normal_date2_img_date_week_img.setProperty(hmUI.prop.VISIBLE, false);
        normal_date3_img_date_week_img.setProperty(hmUI.prop.VISIBLE, false);
        normal_date4_img_date_week_img.setProperty(hmUI.prop.VISIBLE, false);
     normal_date5_img_date_week_img.setProperty(hmUI.prop.VISIBLE, false);
       normal_date6_img_date_week_img.setProperty(hmUI.prop.VISIBLE, false);

        normal_date_img_date_day.setProperty(hmUI.prop.VISIBLE, true);
       normal_date2_img_date_day.setProperty(hmUI.prop.VISIBLE, false);
       normal_date3_img_date_day.setProperty(hmUI.prop.VISIBLE, false);
       normal_date4_img_date_day.setProperty(hmUI.prop.VISIBLE, false);
     normal_date5_img_date_day.setProperty(hmUI.prop.VISIBLE, false);
     normal_date6_img_date_day.setProperty(hmUI.prop.VISIBLE, false);




const result = hmSetting.setScreenOff()
        }

//////////////////////////////////////////////////////////////////////////////////////////////////

        //Two
        function UpdateBackgroundTwo(){

normal_background_bg_img.setProperty(hmUI.prop.SRC, "main" + parseInt(backgroundnumber) + ".png");
normal_motion_animation_img_1.setProperty(hmUI.prop.SRC, "animation/anim_1.png");
normal_motion_animation_img_2.setProperty(hmUI.prop.SRC, "animation/anim_1.png");



        normal_battery_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
        normal_battery2_text_text_img.setProperty(hmUI.prop.VISIBLE, true);
        normal_battery3_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
        normal_battery4_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
     normal_battery5_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
     normal_battery6_text_text_img.setProperty(hmUI.prop.VISIBLE, false);

        normal_date_img_date_week_img.setProperty(hmUI.prop.VISIBLE, false);
        normal_date2_img_date_week_img.setProperty(hmUI.prop.VISIBLE, true);
        normal_date3_img_date_week_img.setProperty(hmUI.prop.VISIBLE, false);
        normal_date4_img_date_week_img.setProperty(hmUI.prop.VISIBLE, false);
     normal_date5_img_date_week_img.setProperty(hmUI.prop.VISIBLE, false);
       normal_date6_img_date_week_img.setProperty(hmUI.prop.VISIBLE, false);


        normal_date_img_date_day.setProperty(hmUI.prop.VISIBLE, false);
       normal_date2_img_date_day.setProperty(hmUI.prop.VISIBLE, true);
       normal_date3_img_date_day.setProperty(hmUI.prop.VISIBLE, false);
       normal_date4_img_date_day.setProperty(hmUI.prop.VISIBLE, false);
     normal_date5_img_date_day.setProperty(hmUI.prop.VISIBLE, false);
     normal_date6_img_date_day.setProperty(hmUI.prop.VISIBLE, false);

const result = hmSetting.setScreenOff()
        }

//////////////////////////////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////////////////////////////

        //Three
        function UpdateBackgroundThree(){

normal_background_bg_img.setProperty(hmUI.prop.SRC, "main" + parseInt(backgroundnumber) + ".png");
normal_motion_animation_img_1.setProperty(hmUI.prop.SRC, "animation/anim_2.png");
normal_motion_animation_img_2.setProperty(hmUI.prop.SRC, "animation/anim_2.png");



        normal_battery_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
        normal_battery2_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
        normal_battery3_text_text_img.setProperty(hmUI.prop.VISIBLE, true);
     normal_battery4_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
     normal_battery5_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
     normal_battery6_text_text_img.setProperty(hmUI.prop.VISIBLE, false);

        normal_date_img_date_week_img.setProperty(hmUI.prop.VISIBLE, false);
        normal_date2_img_date_week_img.setProperty(hmUI.prop.VISIBLE, false);
        normal_date3_img_date_week_img.setProperty(hmUI.prop.VISIBLE, true);
      normal_date4_img_date_week_img.setProperty(hmUI.prop.VISIBLE, false);
      normal_date5_img_date_week_img.setProperty(hmUI.prop.VISIBLE, false);
       normal_date6_img_date_week_img.setProperty(hmUI.prop.VISIBLE, false);

        normal_date_img_date_day.setProperty(hmUI.prop.VISIBLE, false);
       normal_date2_img_date_day.setProperty(hmUI.prop.VISIBLE, false);
       normal_date3_img_date_day.setProperty(hmUI.prop.VISIBLE, true);
     normal_date4_img_date_day.setProperty(hmUI.prop.VISIBLE, false);
     normal_date5_img_date_day.setProperty(hmUI.prop.VISIBLE, false);
     normal_date6_img_date_day.setProperty(hmUI.prop.VISIBLE, false);

const result = hmSetting.setScreenOff()

}


        //Four
        function UpdateBackgroundFour(){

normal_background_bg_img.setProperty(hmUI.prop.SRC, "main" + parseInt(backgroundnumber) + ".png");
normal_motion_animation_img_1.setProperty(hmUI.prop.SRC, "animation/anim_3.png");
normal_motion_animation_img_2.setProperty(hmUI.prop.SRC, "animation/anim_3.png");



        normal_battery_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
        normal_battery2_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
        normal_battery3_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
     normal_battery4_text_text_img.setProperty(hmUI.prop.VISIBLE, true);
     normal_battery5_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
     normal_battery6_text_text_img.setProperty(hmUI.prop.VISIBLE, false);

        normal_date_img_date_week_img.setProperty(hmUI.prop.VISIBLE, false);
        normal_date2_img_date_week_img.setProperty(hmUI.prop.VISIBLE, false);
        normal_date3_img_date_week_img.setProperty(hmUI.prop.VISIBLE, false);
      normal_date4_img_date_week_img.setProperty(hmUI.prop.VISIBLE, true);
      normal_date5_img_date_week_img.setProperty(hmUI.prop.VISIBLE, false);
       normal_date6_img_date_week_img.setProperty(hmUI.prop.VISIBLE, false);

        normal_date_img_date_day.setProperty(hmUI.prop.VISIBLE, false);
       normal_date2_img_date_day.setProperty(hmUI.prop.VISIBLE, false);
       normal_date3_img_date_day.setProperty(hmUI.prop.VISIBLE, false);
     normal_date4_img_date_day.setProperty(hmUI.prop.VISIBLE, true);
     normal_date5_img_date_day.setProperty(hmUI.prop.VISIBLE, false);
     normal_date6_img_date_day.setProperty(hmUI.prop.VISIBLE, false);

const result = hmSetting.setScreenOff()

}

//////////////////////////////////////////////////////////////////////////////////////////////////


        //Five
        function UpdateBackgroundFive(){

normal_background_bg_img.setProperty(hmUI.prop.SRC, "main" + parseInt(backgroundnumber) + ".png");
normal_motion_animation_img_1.setProperty(hmUI.prop.SRC, "animation/anim_4.png");
normal_motion_animation_img_2.setProperty(hmUI.prop.SRC, "animation/anim_4.png");


        normal_battery_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
        normal_battery2_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
        normal_battery3_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
     normal_battery4_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
     normal_battery5_text_text_img.setProperty(hmUI.prop.VISIBLE, true);
     normal_battery6_text_text_img.setProperty(hmUI.prop.VISIBLE, false);

        normal_date_img_date_week_img.setProperty(hmUI.prop.VISIBLE, false);
        normal_date2_img_date_week_img.setProperty(hmUI.prop.VISIBLE, false);
        normal_date3_img_date_week_img.setProperty(hmUI.prop.VISIBLE, false);
      normal_date4_img_date_week_img.setProperty(hmUI.prop.VISIBLE, false);
       normal_date5_img_date_week_img.setProperty(hmUI.prop.VISIBLE, true);
       normal_date6_img_date_week_img.setProperty(hmUI.prop.VISIBLE, false);

        normal_date_img_date_day.setProperty(hmUI.prop.VISIBLE, false);
       normal_date2_img_date_day.setProperty(hmUI.prop.VISIBLE, false);
       normal_date3_img_date_day.setProperty(hmUI.prop.VISIBLE, false);
     normal_date4_img_date_day.setProperty(hmUI.prop.VISIBLE, false);
    normal_date5_img_date_day.setProperty(hmUI.prop.VISIBLE, true);
     normal_date6_img_date_day.setProperty(hmUI.prop.VISIBLE, false);

const result = hmSetting.setScreenOff()
        }

//////////////////////////////////////////////////////////////////////////////////////////////////

        //six
        function UpdateBackgroundSix(){

normal_background_bg_img.setProperty(hmUI.prop.SRC, "main" + parseInt(backgroundnumber) + ".png");
normal_motion_animation_img_1.setProperty(hmUI.prop.SRC, "animation/anim_5.png");
normal_motion_animation_img_2.setProperty(hmUI.prop.SRC, "animation/anim_5.png");


        normal_battery_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
        normal_battery2_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
        normal_battery3_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
     normal_battery4_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
     normal_battery5_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
     normal_battery6_text_text_img.setProperty(hmUI.prop.VISIBLE, true);

        normal_date_img_date_week_img.setProperty(hmUI.prop.VISIBLE, false);
        normal_date2_img_date_week_img.setProperty(hmUI.prop.VISIBLE, false);
        normal_date3_img_date_week_img.setProperty(hmUI.prop.VISIBLE, false);
      normal_date4_img_date_week_img.setProperty(hmUI.prop.VISIBLE, false);
       normal_date5_img_date_week_img.setProperty(hmUI.prop.VISIBLE, false);
       normal_date6_img_date_week_img.setProperty(hmUI.prop.VISIBLE, true);

        normal_date_img_date_day.setProperty(hmUI.prop.VISIBLE, false);
       normal_date2_img_date_day.setProperty(hmUI.prop.VISIBLE, false);
       normal_date3_img_date_day.setProperty(hmUI.prop.VISIBLE, false);
     normal_date4_img_date_day.setProperty(hmUI.prop.VISIBLE, false);
    normal_date5_img_date_day.setProperty(hmUI.prop.VISIBLE, false);
     normal_date6_img_date_day.setProperty(hmUI.prop.VISIBLE, true);

const result = hmSetting.setScreenOff()
        }


//////////////////////////////////////////////////////////////////////////////////////////////////

        // change time color
        let btncolorfont = ''
        let colornumber = 1
        let totalcolorpictures = 8

        function click_color() {
            if(colornumber>=totalcolorpictures) {
            colornumber=1;
                UpdatecolorOne();
                }
            else {
                colornumber=colornumber+1;
                if(colornumber==2) {
                  UpdatecolorTwo();
                }
                if(colornumber==3) {
                  UpdatecolorThree();
                }
                if(colornumber==4) {
                  UpdatecolorFour();
                }
                if(colornumber==5) {
                  UpdatecolorFive();
                }
                if(colornumber==6) {
                  UpdatecolorSix();
                }
                if(colornumber==7) {
                  UpdatecolorSeven();
                }
                if(colornumber==8) {
                  UpdatecolorEight();
                }
 
            }
          if(colornumber==1) hmUI.showToast({text: 'White'});
          if(colornumber==2) hmUI.showToast({text: 'Cyan'});
          if(colornumber==3) hmUI.showToast({text: 'Red'});
          if(colornumber==4) hmUI.showToast({text: 'Orange'});
          if(colornumber==5) hmUI.showToast({text: 'Yellow'});
          if(colornumber==6) hmUI.showToast({text: 'Magenta'});
          if(colornumber==7) hmUI.showToast({text: 'Green'});
          if(colornumber==8) hmUI.showToast({text: 'Blue'});

        }

//////////////////////////////////////////////////////////////////////////////////////////////////

        //Time color1
        function UpdatecolorOne(){

        normal_digital_clock_img_time.setProperty(hmUI.prop.VISIBLE, true);
        normal_digital2_clock_img_time.setProperty(hmUI.prop.VISIBLE, false);
        normal_digital3_clock_img_time.setProperty(hmUI.prop.VISIBLE, false);
        normal_digital4_clock_img_time.setProperty(hmUI.prop.VISIBLE, false);
        normal_digital5_clock_img_time.setProperty(hmUI.prop.VISIBLE, false);
        normal_digital6_clock_img_time.setProperty(hmUI.prop.VISIBLE, false);
        normal_digital7_clock_img_time.setProperty(hmUI.prop.VISIBLE, false);
        normal_digital8_clock_img_time.setProperty(hmUI.prop.VISIBLE, false);

        }

//////////////////////////////////////////////////////////////////////////////////////////////////

        //Time color2
        function UpdatecolorTwo(){

        normal_digital_clock_img_time.setProperty(hmUI.prop.VISIBLE, false);
        normal_digital2_clock_img_time.setProperty(hmUI.prop.VISIBLE, true);
        normal_digital3_clock_img_time.setProperty(hmUI.prop.VISIBLE, false);
        normal_digital4_clock_img_time.setProperty(hmUI.prop.VISIBLE, false);
        normal_digital5_clock_img_time.setProperty(hmUI.prop.VISIBLE, false);
        normal_digital6_clock_img_time.setProperty(hmUI.prop.VISIBLE, false);
        normal_digital7_clock_img_time.setProperty(hmUI.prop.VISIBLE, false);
        normal_digital8_clock_img_time.setProperty(hmUI.prop.VISIBLE, false);


        }

//////////////////////////////////////////////////////////////////////////////////////////////////
        //Time color3
        function UpdatecolorThree(){

        normal_digital_clock_img_time.setProperty(hmUI.prop.VISIBLE, false);
        normal_digital2_clock_img_time.setProperty(hmUI.prop.VISIBLE, false);
        normal_digital3_clock_img_time.setProperty(hmUI.prop.VISIBLE, true);
        normal_digital4_clock_img_time.setProperty(hmUI.prop.VISIBLE, false);
        normal_digital5_clock_img_time.setProperty(hmUI.prop.VISIBLE, false);
        normal_digital6_clock_img_time.setProperty(hmUI.prop.VISIBLE, false);
        normal_digital7_clock_img_time.setProperty(hmUI.prop.VISIBLE, false);
        normal_digital8_clock_img_time.setProperty(hmUI.prop.VISIBLE, false);


        }

//////////////////////////////////////////////////////////////////////////////////////////////////
        //Time color4
        function UpdatecolorFour(){

        normal_digital_clock_img_time.setProperty(hmUI.prop.VISIBLE, false);
        normal_digital2_clock_img_time.setProperty(hmUI.prop.VISIBLE, false);
        normal_digital3_clock_img_time.setProperty(hmUI.prop.VISIBLE, false);
        normal_digital4_clock_img_time.setProperty(hmUI.prop.VISIBLE, true);
        normal_digital5_clock_img_time.setProperty(hmUI.prop.VISIBLE, false);
        normal_digital6_clock_img_time.setProperty(hmUI.prop.VISIBLE, false);
        normal_digital7_clock_img_time.setProperty(hmUI.prop.VISIBLE, false);
        normal_digital8_clock_img_time.setProperty(hmUI.prop.VISIBLE, false);


        }

//////////////////////////////////////////////////////////////////////////////////////////////////
        //Time color5
        function UpdatecolorFive(){

        normal_digital_clock_img_time.setProperty(hmUI.prop.VISIBLE, false);
        normal_digital2_clock_img_time.setProperty(hmUI.prop.VISIBLE, false);
        normal_digital3_clock_img_time.setProperty(hmUI.prop.VISIBLE, false);
        normal_digital4_clock_img_time.setProperty(hmUI.prop.VISIBLE, false);
        normal_digital5_clock_img_time.setProperty(hmUI.prop.VISIBLE, true);
        normal_digital6_clock_img_time.setProperty(hmUI.prop.VISIBLE, false);
        normal_digital7_clock_img_time.setProperty(hmUI.prop.VISIBLE, false);
        normal_digital8_clock_img_time.setProperty(hmUI.prop.VISIBLE, false);


        }

//////////////////////////////////////////////////////////////////////////////////////////////////
        //Time color6
        function UpdatecolorSix(){

        normal_digital_clock_img_time.setProperty(hmUI.prop.VISIBLE, false);
        normal_digital2_clock_img_time.setProperty(hmUI.prop.VISIBLE, false);
        normal_digital3_clock_img_time.setProperty(hmUI.prop.VISIBLE, false);
        normal_digital4_clock_img_time.setProperty(hmUI.prop.VISIBLE, false);
        normal_digital5_clock_img_time.setProperty(hmUI.prop.VISIBLE, false);
        normal_digital6_clock_img_time.setProperty(hmUI.prop.VISIBLE, true);
        normal_digital7_clock_img_time.setProperty(hmUI.prop.VISIBLE, false);
        normal_digital8_clock_img_time.setProperty(hmUI.prop.VISIBLE, false);


        }

//////////////////////////////////////////////////////////////////////////////////////////////////
        //Time color7
        function UpdatecolorSeven(){

        normal_digital_clock_img_time.setProperty(hmUI.prop.VISIBLE, false);
        normal_digital2_clock_img_time.setProperty(hmUI.prop.VISIBLE, false);
        normal_digital3_clock_img_time.setProperty(hmUI.prop.VISIBLE, false);
        normal_digital4_clock_img_time.setProperty(hmUI.prop.VISIBLE, false);
        normal_digital5_clock_img_time.setProperty(hmUI.prop.VISIBLE, false);
        normal_digital6_clock_img_time.setProperty(hmUI.prop.VISIBLE, false);
        normal_digital7_clock_img_time.setProperty(hmUI.prop.VISIBLE, true);
        normal_digital8_clock_img_time.setProperty(hmUI.prop.VISIBLE, false);


        }

//////////////////////////////////////////////////////////////////////////////////////////////////
        //Time color8
        function UpdatecolorEight(){

        normal_digital_clock_img_time.setProperty(hmUI.prop.VISIBLE, false);
        normal_digital2_clock_img_time.setProperty(hmUI.prop.VISIBLE, false);
        normal_digital3_clock_img_time.setProperty(hmUI.prop.VISIBLE, false);
        normal_digital4_clock_img_time.setProperty(hmUI.prop.VISIBLE, false);
        normal_digital5_clock_img_time.setProperty(hmUI.prop.VISIBLE, false);
        normal_digital6_clock_img_time.setProperty(hmUI.prop.VISIBLE, false);
        normal_digital7_clock_img_time.setProperty(hmUI.prop.VISIBLE, false);
        normal_digital8_clock_img_time.setProperty(hmUI.prop.VISIBLE, true);


        }

//////////////////////////////////////////////////////////////////////////////////////////////////





        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 466,
              h: 466,
              src: 'main1.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

             normal_motion_animation_img_1 = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 465,
              h: 465,
              pos_x: 28,
              pos_y: 150,
              src: 'animation/anim_0.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_motion_animation_paramX_1 = {
              anim_steps: [{
                anim_rate: 'linear',
                anim_duration: 500,
                anim_from: 28,
                anim_to: 28,
                anim_key: "pos_x",
              }],
              anim_fps: 15,
              anim_auto_start: 1,
              anim_repeat: 1,
              anim_auto_destroy: 1,
            };

            normal_motion_animation_paramY_1 = {
              anim_steps: [{
                anim_rate: 'linear',
                anim_duration: 500,
                anim_from: 150,
                anim_to: 248,
                anim_key: "pos_y",
              }],
              anim_fps: 15,
              anim_auto_start: 1,
              anim_repeat: 1,
              anim_auto_destroy: 1,
            };

            let now = hmSensor.createSensor(hmSensor.id.TIME);

            normal_motion_animation_paramX_1_mirror = {
              anim_steps: [{
                anim_rate: 'linear',
                anim_duration: 500,
                anim_from: 28,
                anim_to: 28,
                anim_key: "pos_x",
              }],
              anim_fps: 15,
              anim_auto_start: 1,
              anim_repeat: 1,
              anim_auto_destroy: 1,
            };

            normal_motion_animation_paramY_1_mirror = {
              anim_steps: [{
                anim_rate: 'linear',
                anim_duration: 500,
                anim_from: 248,
                anim_to: 150,
                anim_key: "pos_y",
              }],
              anim_fps: 15,
              anim_auto_start: 1,
              anim_repeat: 1,
              anim_auto_destroy: 1,
            };

            function anim_motion_1_mirror() {
              normal_motion_animation_img_1.setProperty(hmUI.prop.ANIM, normal_motion_animation_paramX_1_mirror);
              normal_motion_animation_img_1.setProperty(hmUI.prop.ANIM, normal_motion_animation_paramY_1_mirror);
              normal_motion_animation_lastTime_1 = now.utc;
              normal_motion_animation_count_1 = normal_motion_animation_count_1 - 1;
              if(normal_motion_animation_count_1 < -1) normal_motion_animation_count_1 = - 1;
              if(normal_motion_animation_count_1 == 0) stop_anim_motion_1();
            }; // end animation_mirror callback function

            function anim_motion_1_complete_call() {
              normal_motion_animation_img_1.setProperty(hmUI.prop.ANIM, normal_motion_animation_paramX_1);
              normal_motion_animation_img_1.setProperty(hmUI.prop.ANIM, normal_motion_animation_paramY_1);
                normal_motion_animation_lastTime_1 = now.utc;
            }; // end animation callback function
            
            function stop_anim_motion_1() {
              if (timer_anim_motion_1) {
                timer.stopTimer(timer_anim_motion_1);
                timer_anim_motion_1 = undefined;
              };
            }; // end stop_anim_motion function

            // normal_motion_anime_1 = hmUI.createWidget(hmUI.widget.Motion_Animation, {
              // x_start: 28,
              // y_start: 150,
              // x_end: 28,
              // y_end: 248,
              // src: 'anim_0.png',
              // anim_fps: 15,
              // anim_duration: 500,
              // repeat_count: 0,
              // anim_two_sides: True,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_motion_animation_img_2 = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 465,
              h: 465,
              pos_x: 426,
              pos_y: 248,
              src: 'animation/anim_0.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_motion_animation_paramX_2 = {
              anim_steps: [{
                anim_rate: 'linear',
                anim_duration: 500,
                anim_from: 426,
                anim_to: 426,
                anim_key: "pos_x",
              }],
              anim_fps: 15,
              anim_auto_start: 1,
              anim_repeat: 1,
              anim_auto_destroy: 1,
            };

            normal_motion_animation_paramY_2 = {
              anim_steps: [{
                anim_rate: 'linear',
                anim_duration: 500,
                anim_from: 248,
                anim_to: 150,
                anim_key: "pos_y",
              }],
              anim_fps: 15,
              anim_auto_start: 1,
              anim_repeat: 1,
              anim_auto_destroy: 1,
            };

            normal_motion_animation_paramX_2_mirror = {
              anim_steps: [{
                anim_rate: 'linear',
                anim_duration: 500,
                anim_from: 426,
                anim_to: 426,
                anim_key: "pos_x",
              }],
              anim_fps: 15,
              anim_auto_start: 1,
              anim_repeat: 1,
              anim_auto_destroy: 1,
            };

            normal_motion_animation_paramY_2_mirror = {
              anim_steps: [{
                anim_rate: 'linear',
                anim_duration: 500,
                anim_from: 150,
                anim_to: 248,
                anim_key: "pos_y",
              }],
              anim_fps: 15,
              anim_auto_start: 1,
              anim_repeat: 1,
              anim_auto_destroy: 1,
            };

            function anim_motion_2_mirror() {
              normal_motion_animation_img_2.setProperty(hmUI.prop.ANIM, normal_motion_animation_paramX_2_mirror);
              normal_motion_animation_img_2.setProperty(hmUI.prop.ANIM, normal_motion_animation_paramY_2_mirror);
              normal_motion_animation_lastTime_2 = now.utc;
              normal_motion_animation_count_2 = normal_motion_animation_count_2 - 1;
              if(normal_motion_animation_count_2 < -1) normal_motion_animation_count_2 = - 1;
              if(normal_motion_animation_count_2 == 0) stop_anim_motion_2();
            }; // end animation_mirror callback function

            function anim_motion_2_complete_call() {
              normal_motion_animation_img_2.setProperty(hmUI.prop.ANIM, normal_motion_animation_paramX_2);
              normal_motion_animation_img_2.setProperty(hmUI.prop.ANIM, normal_motion_animation_paramY_2);
                normal_motion_animation_lastTime_2 = now.utc;
            }; // end animation callback function
            
            function stop_anim_motion_2() {
              if (timer_anim_motion_2) {
                timer.stopTimer(timer_anim_motion_2);
                timer_anim_motion_2 = undefined;
              };
            }; // end stop_anim_motion function

            // normal_motion_anime_2 = hmUI.createWidget(hmUI.widget.Motion_Animation, {
              // x_start: 426,
              // y_start: 248,
              // x_end: 426,
              // y_end: 150,
              // src: 'anim_0.png',
              // anim_fps: 15,
              // anim_duration: 500,
              // repeat_count: 0,
              // anim_two_sides: True,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_image_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 17,
              y: 145,
              src: 'top_image.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

///////////////////////////////////////////

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 196,
              y: 15,
              week_en: ["WE1_1.png","WE1_2.png","WE1_3.png","WE1_4.png","WE1_5.png","WE1_6.png","WE1_7.png"],
              week_tc: ["WE1_1.png","WE1_2.png","WE1_3.png","WE1_4.png","WE1_5.png","WE1_6.png","WE1_7.png"],
              week_sc: ["WE1_1.png","WE1_2.png","WE1_3.png","WE1_4.png","WE1_5.png","WE1_6.png","WE1_7.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date2_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 196,
              y: 15,
              week_en: ["WE2_1.png","WE2_2.png","WE2_3.png","WE2_4.png","WE2_5.png","WE2_6.png","WE2_7.png"],
              week_tc: ["WE2_1.png","WE2_2.png","WE2_3.png","WE2_4.png","WE2_5.png","WE2_6.png","WE2_7.png"],
              week_sc: ["WE2_1.png","WE2_2.png","WE2_3.png","WE2_4.png","WE2_5.png","WE2_6.png","WE2_7.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });



            normal_date3_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 196,
              y: 15,
              week_en: ["WE3_1.png","WE3_2.png","WE3_3.png","WE3_4.png","WE3_5.png","WE3_6.png","WE3_7.png"],
              week_tc: ["WE3_1.png","WE3_2.png","WE3_3.png","WE3_4.png","WE3_5.png","WE3_6.png","WE3_7.png"],
              week_sc: ["WE3_1.png","WE3_2.png","WE3_3.png","WE3_4.png","WE3_5.png","WE3_6.png","WE3_7.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date4_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 196,
              y: 15,
              week_en: ["WE4_1.png","WE4_2.png","WE4_3.png","WE4_4.png","WE4_5.png","WE4_6.png","WE4_7.png"],
              week_tc: ["WE4_1.png","WE4_2.png","WE4_3.png","WE4_4.png","WE4_5.png","WE4_6.png","WE4_7.png"],
              week_sc: ["WE4_1.png","WE4_2.png","WE4_3.png","WE4_4.png","WE4_5.png","WE4_6.png","WE4_7.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date5_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 196,
              y: 15,
              week_en: ["WE5_1.png","WE5_2.png","WE5_3.png","WE5_4.png","WE5_5.png","WE5_6.png","WE5_7.png"],
              week_tc: ["WE5_1.png","WE5_2.png","WE5_3.png","WE5_4.png","WE5_5.png","WE5_6.png","WE5_7.png"],
              week_sc: ["WE5_1.png","WE5_2.png","WE5_3.png","WE5_4.png","WE5_5.png","WE5_6.png","WE5_7.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date6_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 196,
              y: 15,
              week_en: ["WE6_1.png","WE6_2.png","WE6_3.png","WE6_4.png","WE6_5.png","WE6_6.png","WE6_7.png"],
              week_tc: ["WE6_1.png","WE6_2.png","WE6_3.png","WE6_4.png","WE6_5.png","WE6_6.png","WE6_7.png"],
              week_sc: ["WE6_1.png","WE6_2.png","WE6_3.png","WE6_4.png","WE6_5.png","WE6_6.png","WE6_7.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


////////////////////////////////////////////////////////////////////

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 195,
              day_startY: 42,
              day_sc_array: ["day1_0.png","day1_1.png","day1_2.png","day1_3.png","day1_4.png","day1_5.png","day1_6.png","day1_7.png","day1_8.png","day1_9.png"],
              day_tc_array: ["day1_0.png","day1_1.png","day1_2.png","day1_3.png","day1_4.png","day1_5.png","day1_6.png","day1_7.png","day1_8.png","day1_9.png"],
              day_en_array: ["day1_0.png","day1_1.png","day1_2.png","day1_3.png","day1_4.png","day1_5.png","day1_6.png","day1_7.png","day1_8.png","day1_9.png"],
              day_zero: 1,
              day_space: 4,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date2_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 195,
              day_startY: 42,
              day_sc_array: ["day2_0.png","day2_1.png","day2_2.png","day2_3.png","day2_4.png","day2_5.png","day2_6.png","day2_7.png","day2_8.png","day2_9.png"],
              day_tc_array: ["day2_0.png","day2_1.png","day2_2.png","day2_3.png","day2_4.png","day2_5.png","day2_6.png","day2_7.png","day2_8.png","day2_9.png"],
              day_en_array: ["day2_0.png","day2_1.png","day2_2.png","day2_3.png","day2_4.png","day2_5.png","day2_6.png","day2_7.png","day2_8.png","day2_9.png"],
              day_zero: 1,
              day_space: 4,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });



            normal_date3_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 195,
              day_startY: 42,
              day_sc_array: ["day3_0.png","day3_1.png","day3_2.png","day3_3.png","day3_4.png","day3_5.png","day3_6.png","day3_7.png","day3_8.png","day3_9.png"],
              day_tc_array: ["day3_0.png","day3_1.png","day3_2.png","day3_3.png","day3_4.png","day3_5.png","day3_6.png","day3_7.png","day3_8.png","day3_9.png"],
              day_en_array: ["day3_0.png","day3_1.png","day3_2.png","day3_3.png","day3_4.png","day3_5.png","day3_6.png","day3_7.png","day3_8.png","day3_9.png"],
              day_zero: 1,
              day_space: 4,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });



            normal_date4_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 195,
              day_startY: 42,
              day_sc_array: ["day4_0.png","day4_1.png","day4_2.png","day4_3.png","day4_4.png","day4_5.png","day4_6.png","day4_7.png","day4_8.png","day4_9.png"],
              day_tc_array: ["day4_0.png","day4_1.png","day4_2.png","day4_3.png","day4_4.png","day4_5.png","day4_6.png","day4_7.png","day4_8.png","day4_9.png"],
              day_en_array: ["day4_0.png","day4_1.png","day4_2.png","day4_3.png","day4_4.png","day4_5.png","day4_6.png","day4_7.png","day4_8.png","day4_9.png"],
              day_zero: 1,
              day_space: 4,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

           normal_date5_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 195,
              day_startY: 42,
              day_sc_array: ["day5_0.png","day5_1.png","day5_2.png","day5_3.png","day5_4.png","day5_5.png","day5_6.png","day5_7.png","day5_8.png","day5_9.png"],
              day_tc_array: ["day5_0.png","day5_1.png","day5_2.png","day5_3.png","day5_4.png","day5_5.png","day5_6.png","day5_7.png","day5_8.png","day5_9.png"],
              day_en_array: ["day5_0.png","day5_1.png","day5_2.png","day5_3.png","day5_4.png","day5_5.png","day5_6.png","day5_7.png","day5_8.png","day5_9.png"],
              day_zero: 1,
              day_space: 4,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

          normal_date6_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 195,
              day_startY: 42,
              day_sc_array: ["day6_0.png","day6_1.png","day6_2.png","day6_3.png","day6_4.png","day6_5.png","day6_6.png","day6_7.png","day6_8.png","day6_9.png"],
              day_tc_array: ["day6_0.png","day6_1.png","day6_2.png","day6_3.png","day6_4.png","day6_5.png","day6_6.png","day6_7.png","day6_8.png","day6_9.png"],
              day_en_array: ["day6_0.png","day6_1.png","day6_2.png","day6_3.png","day6_4.png","day6_5.png","day6_6.png","day6_7.png","day6_8.png","day6_9.png"],
              day_zero: 1,
              day_space: 4,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

//////////////////////////

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 181,
              y: 393,
              font_array: ["day1_0.png","day1_1.png","day1_2.png","day1_3.png","day1_4.png","day1_5.png","day1_6.png","day1_7.png","day1_8.png","day1_9.png"],
              padding: false,
              h_space: 3,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


           normal_battery2_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 181,
              y: 393,
              font_array: ["day2_0.png","day2_1.png","day2_2.png","day2_3.png","day2_4.png","day2_5.png","day2_6.png","day2_7.png","day2_8.png","day2_9.png"],
              padding: false,
              h_space: 3,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


           normal_battery3_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 181,
              y: 393,
              font_array: ["day3_0.png","day3_1.png","day3_2.png","day3_3.png","day3_4.png","day3_5.png","day3_6.png","day3_7.png","day3_8.png","day3_9.png"],
              padding: false,
              h_space: 3,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

           normal_battery4_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 181,
              y: 393,
              font_array: ["day4_0.png","day4_1.png","day4_2.png","day4_3.png","day4_4.png","day4_5.png","day4_6.png","day4_7.png","day4_8.png","day4_9.png"],
              padding: false,
              h_space: 3,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

           normal_battery5_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 181,
              y: 393,
              font_array: ["day5_0.png","day5_1.png","day5_2.png","day5_3.png","day5_4.png","day5_5.png","day5_6.png","day5_7.png","day5_8.png","day5_9.png"],
              padding: false,
              h_space: 3,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

           normal_battery6_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 181,
              y: 393,
              font_array: ["day6_0.png","day6_1.png","day6_2.png","day6_3.png","day6_4.png","day6_5.png","day6_6.png","day6_7.png","day6_8.png","day6_9.png"],
              padding: false,
              h_space: 3,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


//////////////////////////////

            // normal_step_text_rotate_img = hmUI.createWidget(hmUI.widget.Text_Rotate, {
              // x: 406,
              // y: 234,
              // font_array: ["act1_0.png","act1_1.png","act1_2.png","act1_3.png","act1_4.png","act1_5.png","act1_6.png","act1_7.png","act1_8.png","act1_9.png"],
              // zero: true,
              // unit_in_alignment: false,
              // h_space: 3,
              // angle: 90,
              // invalid_image: 'act1_0.png',
              // align_h: hmUI.align.CENTER_H,
              // type: hmUI.data_type.STEP,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });
/////////////////////////////
       
            normal_step_TextRotate_ASCIIARRAY[0] = 'act1_0.png';  // set of images with numbers
            normal_step_TextRotate_ASCIIARRAY[1] = 'act1_1.png';  // set of images with numbers
            normal_step_TextRotate_ASCIIARRAY[2] = 'act1_2.png';  // set of images with numbers
            normal_step_TextRotate_ASCIIARRAY[3] = 'act1_3.png';  // set of images with numbers
            normal_step_TextRotate_ASCIIARRAY[4] = 'act1_4.png';  // set of images with numbers
            normal_step_TextRotate_ASCIIARRAY[5] = 'act1_5.png';  // set of images with numbers
            normal_step_TextRotate_ASCIIARRAY[6] = 'act1_6.png';  // set of images with numbers
            normal_step_TextRotate_ASCIIARRAY[7] = 'act1_7.png';  // set of images with numbers
            normal_step_TextRotate_ASCIIARRAY[8] = 'act1_8.png';  // set of images with numbers
            normal_step_TextRotate_ASCIIARRAY[9] = 'act1_9.png';  // set of images with numbers
 
            normal_step2_TextRotate_ASCIIARRAY[0] = 'act2_0.png';  // set of images with numbers
            normal_step2_TextRotate_ASCIIARRAY[1] = 'act2_1.png';  // set of images with numbers
            normal_step2_TextRotate_ASCIIARRAY[2] = 'act2_2.png';  // set of images with numbers
            normal_step2_TextRotate_ASCIIARRAY[3] = 'act2_3.png';  // set of images with numbers
            normal_step2_TextRotate_ASCIIARRAY[4] = 'act2_4.png';  // set of images with numbers
            normal_step2_TextRotate_ASCIIARRAY[5] = 'act2_5.png';  // set of images with numbers
            normal_step2_TextRotate_ASCIIARRAY[6] = 'act2_6.png';  // set of images with numbers
            normal_step2_TextRotate_ASCIIARRAY[7] = 'act2_7.png';  // set of images with numbers
            normal_step2_TextRotate_ASCIIARRAY[8] = 'act2_8.png';  // set of images with numbers
            normal_step2_TextRotate_ASCIIARRAY[9] = 'act2_9.png';  // set of images with numbers
          

 
            normal_step3_TextRotate_ASCIIARRAY[0] = 'act3_0.png';  // set of images with numbers
            normal_step3_TextRotate_ASCIIARRAY[1] = 'act3_1.png';  // set of images with numbers
            normal_step3_TextRotate_ASCIIARRAY[2] = 'act3_2.png';  // set of images with numbers
            normal_step3_TextRotate_ASCIIARRAY[3] = 'act3_3.png';  // set of images with numbers
            normal_step3_TextRotate_ASCIIARRAY[4] = 'act3_4.png';  // set of images with numbers
            normal_step3_TextRotate_ASCIIARRAY[5] = 'act3_5.png';  // set of images with numbers
            normal_step3_TextRotate_ASCIIARRAY[6] = 'act3_6.png';  // set of images with numbers
            normal_step3_TextRotate_ASCIIARRAY[7] = 'act3_7.png';  // set of images with numbers
            normal_step3_TextRotate_ASCIIARRAY[8] = 'act3_8.png';  // set of images with numbers
            normal_step3_TextRotate_ASCIIARRAY[9] = 'act3_9.png';  // set of images with numbers


            normal_step4_TextRotate_ASCIIARRAY[0] = 'act4_0.png';  // set of images with numbers
            normal_step4_TextRotate_ASCIIARRAY[1] = 'act4_1.png';  // set of images with numbers
            normal_step4_TextRotate_ASCIIARRAY[2] = 'act4_2.png';  // set of images with numbers
            normal_step4_TextRotate_ASCIIARRAY[3] = 'act4_3.png';  // set of images with numbers
            normal_step4_TextRotate_ASCIIARRAY[4] = 'act4_4.png';  // set of images with numbers
            normal_step4_TextRotate_ASCIIARRAY[5] = 'act4_5.png';  // set of images with numbers
            normal_step4_TextRotate_ASCIIARRAY[6] = 'act4_6.png';  // set of images with numbers
            normal_step4_TextRotate_ASCIIARRAY[7] = 'act4_7.png';  // set of images with numbers
            normal_step4_TextRotate_ASCIIARRAY[8] = 'act4_8.png';  // set of images with numbers
            normal_step4_TextRotate_ASCIIARRAY[9] = 'act4_9.png';  // set of images with numbers

            normal_step5_TextRotate_ASCIIARRAY[0] = 'act5_0.png';  // set of images with numbers
            normal_step5_TextRotate_ASCIIARRAY[1] = 'act5_1.png';  // set of images with numbers
            normal_step5_TextRotate_ASCIIARRAY[2] = 'act5_2.png';  // set of images with numbers
            normal_step5_TextRotate_ASCIIARRAY[3] = 'act5_3.png';  // set of images with numbers
            normal_step5_TextRotate_ASCIIARRAY[4] = 'act5_4.png';  // set of images with numbers
            normal_step5_TextRotate_ASCIIARRAY[5] = 'act5_5.png';  // set of images with numbers
            normal_step5_TextRotate_ASCIIARRAY[6] = 'act5_6.png';  // set of images with numbers
            normal_step5_TextRotate_ASCIIARRAY[7] = 'act5_7.png';  // set of images with numbers
            normal_step5_TextRotate_ASCIIARRAY[8] = 'act5_8.png';  // set of images with numbers
            normal_step5_TextRotate_ASCIIARRAY[9] = 'act5_9.png';  // set of images with numbers

            normal_step6_TextRotate_ASCIIARRAY[0] = 'act6_0.png';  // set of images with numbers
            normal_step6_TextRotate_ASCIIARRAY[1] = 'act6_1.png';  // set of images with numbers
            normal_step6_TextRotate_ASCIIARRAY[2] = 'act6_2.png';  // set of images with numbers
            normal_step6_TextRotate_ASCIIARRAY[3] = 'act6_3.png';  // set of images with numbers
            normal_step6_TextRotate_ASCIIARRAY[4] = 'act6_4.png';  // set of images with numbers
            normal_step6_TextRotate_ASCIIARRAY[5] = 'act6_5.png';  // set of images with numbers
            normal_step6_TextRotate_ASCIIARRAY[6] = 'act6_6.png';  // set of images with numbers
            normal_step6_TextRotate_ASCIIARRAY[7] = 'act6_7.png';  // set of images with numbers
            normal_step6_TextRotate_ASCIIARRAY[8] = 'act6_8.png';  // set of images with numbers
            normal_step6_TextRotate_ASCIIARRAY[9] = 'act6_9.png';  // set of images with numbers


////////////////////////

            //start of ignored block
            for (let i = 0; i < 5; i++) {
              normal_step_TextRotate[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 466,
                h: 466,
                center_x: 406,
                center_y: 234,
                pos_x: 406,
                pos_y: 234,
                angle: 90,
                src: 'act1_0.png',
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
              normal_step_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
            };
            //end of ignored block
            
            const step = hmSensor.createSensor(hmSensor.id.STEP);
            step.addEventListener(hmSensor.event.CHANGE, function() {
              text_update();
            });
            
            function toDegree (radian) {
              return radian * (180 / Math.PI);
            };

            // normal_heart_rate_text_rotate_img = hmUI.createWidget(hmUI.widget.Text_Rotate, {
              // x: 62,
              // y: 275,
              // font_array: ["act1_0.png","act1_1.png","act1_2.png","act1_3.png","act1_4.png","act1_5.png","act1_6.png","act1_7.png","act1_8.png","act1_9.png"],
              // zero: true,
              // unit_in_alignment: false,
              // h_space: 3,
              // angle: -90,
              // invalid_image: 'act1_0.png',
              // align_h: hmUI.align.CENTER_H,
              // type: hmUI.data_type.HEART,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_heart_rate_TextRotate_ASCIIARRAY[0] = 'act1_0.png';  // set of images with numbers
            normal_heart_rate_TextRotate_ASCIIARRAY[1] = 'act1_1.png';  // set of images with numbers
            normal_heart_rate_TextRotate_ASCIIARRAY[2] = 'act1_2.png';  // set of images with numbers
            normal_heart_rate_TextRotate_ASCIIARRAY[3] = 'act1_3.png';  // set of images with numbers
            normal_heart_rate_TextRotate_ASCIIARRAY[4] = 'act1_4.png';  // set of images with numbers
            normal_heart_rate_TextRotate_ASCIIARRAY[5] = 'act1_5.png';  // set of images with numbers
            normal_heart_rate_TextRotate_ASCIIARRAY[6] = 'act1_6.png';  // set of images with numbers
            normal_heart_rate_TextRotate_ASCIIARRAY[7] = 'act1_7.png';  // set of images with numbers
            normal_heart_rate_TextRotate_ASCIIARRAY[8] = 'act1_8.png';  // set of images with numbers
            normal_heart_rate_TextRotate_ASCIIARRAY[9] = 'act1_9.png';  // set of images with numbers


            normal_heart2_rate_TextRotate_ASCIIARRAY[0] = 'act2_0.png';  // set of images with numbers
            normal_heart2_rate_TextRotate_ASCIIARRAY[1] = 'act2_1.png';  // set of images with numbers
            normal_heart2_rate_TextRotate_ASCIIARRAY[2] = 'act2_2.png';  // set of images with numbers
            normal_heart2_rate_TextRotate_ASCIIARRAY[3] = 'act2_3.png';  // set of images with numbers
            normal_heart2_rate_TextRotate_ASCIIARRAY[4] = 'act2_4.png';  // set of images with numbers
            normal_heart2_rate_TextRotate_ASCIIARRAY[5] = 'act2_5.png';  // set of images with numbers
            normal_heart2_rate_TextRotate_ASCIIARRAY[6] = 'act2_6.png';  // set of images with numbers
            normal_heart2_rate_TextRotate_ASCIIARRAY[7] = 'act2_7.png';  // set of images with numbers
            normal_heart2_rate_TextRotate_ASCIIARRAY[8] = 'act2_8.png';  // set of images with numbers
            normal_heart2_rate_TextRotate_ASCIIARRAY[9] = 'act2_9.png';  // set of images with numbers

            normal_heart3_rate_TextRotate_ASCIIARRAY[0] = 'act3_0.png';  // set of images with numbers
            normal_heart3_rate_TextRotate_ASCIIARRAY[1] = 'act3_1.png';  // set of images with numbers
            normal_heart3_rate_TextRotate_ASCIIARRAY[2] = 'act3_2.png';  // set of images with numbers
            normal_heart3_rate_TextRotate_ASCIIARRAY[3] = 'act3_3.png';  // set of images with numbers
            normal_heart3_rate_TextRotate_ASCIIARRAY[4] = 'act3_4.png';  // set of images with numbers
            normal_heart3_rate_TextRotate_ASCIIARRAY[5] = 'act3_5.png';  // set of images with numbers
            normal_heart3_rate_TextRotate_ASCIIARRAY[6] = 'act3_6.png';  // set of images with numbers
            normal_heart3_rate_TextRotate_ASCIIARRAY[7] = 'act3_7.png';  // set of images with numbers
            normal_heart3_rate_TextRotate_ASCIIARRAY[8] = 'act3_8.png';  // set of images with numbers
            normal_heart3_rate_TextRotate_ASCIIARRAY[9] = 'act3_9.png';  // set of images with numbers

            normal_heart4_rate_TextRotate_ASCIIARRAY[0] = 'act4_0.png';  // set of images with numbers
            normal_heart4_rate_TextRotate_ASCIIARRAY[1] = 'act4_1.png';  // set of images with numbers
            normal_heart4_rate_TextRotate_ASCIIARRAY[2] = 'act4_2.png';  // set of images with numbers
            normal_heart4_rate_TextRotate_ASCIIARRAY[3] = 'act4_3.png';  // set of images with numbers
            normal_heart4_rate_TextRotate_ASCIIARRAY[4] = 'act4_4.png';  // set of images with numbers
            normal_heart4_rate_TextRotate_ASCIIARRAY[5] = 'act4_5.png';  // set of images with numbers
            normal_heart4_rate_TextRotate_ASCIIARRAY[6] = 'act4_6.png';  // set of images with numbers
            normal_heart4_rate_TextRotate_ASCIIARRAY[7] = 'act4_7.png';  // set of images with numbers
            normal_heart4_rate_TextRotate_ASCIIARRAY[8] = 'act4_8.png';  // set of images with numbers
            normal_heart4_rate_TextRotate_ASCIIARRAY[9] = 'act4_9.png';  // set of images with numbers


            normal_heart5_rate_TextRotate_ASCIIARRAY[0] = 'act5_0.png';  // set of images with numbers
            normal_heart5_rate_TextRotate_ASCIIARRAY[1] = 'act5_1.png';  // set of images with numbers
            normal_heart5_rate_TextRotate_ASCIIARRAY[2] = 'act5_2.png';  // set of images with numbers
            normal_heart5_rate_TextRotate_ASCIIARRAY[3] = 'act5_3.png';  // set of images with numbers
            normal_heart5_rate_TextRotate_ASCIIARRAY[4] = 'act5_4.png';  // set of images with numbers
            normal_heart5_rate_TextRotate_ASCIIARRAY[5] = 'act5_5.png';  // set of images with numbers
            normal_heart5_rate_TextRotate_ASCIIARRAY[6] = 'act5_6.png';  // set of images with numbers
            normal_heart5_rate_TextRotate_ASCIIARRAY[7] = 'act5_7.png';  // set of images with numbers
            normal_heart5_rate_TextRotate_ASCIIARRAY[8] = 'act5_8.png';  // set of images with numbers
            normal_heart5_rate_TextRotate_ASCIIARRAY[9] = 'act5_9.png';  // set of images with numbers

            normal_heart6_rate_TextRotate_ASCIIARRAY[0] = 'act6_0.png';  // set of images with numbers
            normal_heart6_rate_TextRotate_ASCIIARRAY[1] = 'act6_1.png';  // set of images with numbers
            normal_heart6_rate_TextRotate_ASCIIARRAY[2] = 'act6_2.png';  // set of images with numbers
            normal_heart6_rate_TextRotate_ASCIIARRAY[3] = 'act6_3.png';  // set of images with numbers
            normal_heart6_rate_TextRotate_ASCIIARRAY[4] = 'act6_4.png';  // set of images with numbers
            normal_heart6_rate_TextRotate_ASCIIARRAY[5] = 'act6_5.png';  // set of images with numbers
            normal_heart6_rate_TextRotate_ASCIIARRAY[6] = 'act6_6.png';  // set of images with numbers
            normal_heart6_rate_TextRotate_ASCIIARRAY[7] = 'act6_7.png';  // set of images with numbers
            normal_heart6_rate_TextRotate_ASCIIARRAY[8] = 'act6_8.png';  // set of images with numbers
            normal_heart6_rate_TextRotate_ASCIIARRAY[9] = 'act6_9.png';  // set of images with numbers

////////////////////////////////////////////////

            //start of ignored block
            for (let i = 0; i < 5; i++) {
              normal_heart_rate_TextRotate[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 466,
                h: 466,
                center_x: 62,
                center_y: 275,
                pos_x: 62,
                pos_y: 275,
                angle: -90,
                src: 'act1_0.png',
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
              normal_heart_rate_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
            };
            //end of ignored block
            
            const heart_rate = hmSensor.createSensor(hmSensor.id.HEART);
            heart_rate.addEventListener(hmSensor.event.CHANGE, function() {
              text_update();
            });


///////////////////////////////////// digital time /////////////////////////////

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 93,
              hour_startY: 126,
              hour_array: ["t1_0.png","t1_1.png","t1_2.png","t1_3.png","t1_4.png","t1_5.png","t1_6.png","t1_7.png","t1_8.png","t1_9.png"],
              hour_zero: 1,
              hour_space: 3,
              hour_angle: 0,
              hour_align: hmUI.align.LEFT,

              minute_startX: 93,
              minute_startY: 248,
              minute_array: ["t1_0.png","t1_1.png","t1_2.png","t1_3.png","t1_4.png","t1_5.png","t1_6.png","t1_7.png","t1_8.png","t1_9.png"],
              minute_zero: 1,
              minute_space: 0,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            normal_digital2_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 93,
              hour_startY: 126,
              hour_array: ["t2_0.png","t2_1.png","t2_2.png","t2_3.png","t2_4.png","t2_5.png","t2_6.png","t2_7.png","t2_8.png","t2_9.png"],
              hour_zero: 1,
              hour_space: 3,
              hour_angle: 0,
              hour_align: hmUI.align.LEFT,

              minute_startX: 93,
              minute_startY: 248,
              minute_array: ["t2_0.png","t2_1.png","t2_2.png","t2_3.png","t2_4.png","t2_5.png","t2_6.png","t2_7.png","t2_8.png","t2_9.png"],
              minute_zero: 1,
              minute_space: 0,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });



            normal_digital3_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 93,
              hour_startY: 126,
              hour_array: ["t3_0.png","t3_1.png","t3_2.png","t3_3.png","t3_4.png","t3_5.png","t3_6.png","t3_7.png","t3_8.png","t3_9.png"],
              hour_zero: 1,
              hour_space: 3,
              hour_angle: 0,
              hour_align: hmUI.align.LEFT,

              minute_startX: 93,
              minute_startY: 248,
              minute_array: ["t3_0.png","t3_1.png","t3_2.png","t3_3.png","t3_4.png","t3_5.png","t3_6.png","t3_7.png","t3_8.png","t3_9.png"],
              minute_zero: 1,
              minute_space: 0,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital4_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 93,
              hour_startY: 126,
              hour_array: ["t4_0.png","t4_1.png","t4_2.png","t4_3.png","t4_4.png","t4_5.png","t4_6.png","t4_7.png","t4_8.png","t4_9.png"],
              hour_zero: 1,
              hour_space: 3,
              hour_angle: 0,
              hour_align: hmUI.align.LEFT,

              minute_startX: 93,
              minute_startY: 248,
              minute_array: ["t4_0.png","t4_1.png","t4_2.png","t4_3.png","t4_4.png","t4_5.png","t4_6.png","t4_7.png","t4_8.png","t4_9.png"],
              minute_zero: 1,
              minute_space: 0,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital5_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 93,
              hour_startY: 126,
              hour_array: ["t5_0.png","t5_1.png","t5_2.png","t5_3.png","t5_4.png","t5_5.png","t5_6.png","t5_7.png","t5_8.png","t5_9.png"],
              hour_zero: 1,
              hour_space: 3,
              hour_angle: 0,
              hour_align: hmUI.align.LEFT,

              minute_startX: 93,
              minute_startY: 248,
              minute_array: ["t5_0.png","t5_1.png","t5_2.png","t5_3.png","t5_4.png","t5_5.png","t5_6.png","t5_7.png","t5_8.png","t5_9.png"],
              minute_zero: 1,
              minute_space: 0,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital6_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 93,
              hour_startY: 126,
              hour_array: ["t6_0.png","t6_1.png","t6_2.png","t6_3.png","t6_4.png","t6_5.png","t6_6.png","t6_7.png","t6_8.png","t6_9.png"],
              hour_zero: 1,
              hour_space: 3,
              hour_angle: 0,
              hour_align: hmUI.align.LEFT,

              minute_startX: 93,
              minute_startY: 248,
              minute_array: ["t6_0.png","t6_1.png","t6_2.png","t6_3.png","t6_4.png","t6_5.png","t6_6.png","t6_7.png","t6_8.png","t6_9.png"],
              minute_zero: 1,
              minute_space: 0,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital7_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 93,
              hour_startY: 126,
              hour_array: ["t7_0.png","t7_1.png","t7_2.png","t7_3.png","t7_4.png","t7_5.png","t7_6.png","t7_7.png","t7_8.png","t7_9.png"],
              hour_zero: 1,
              hour_space: 3,
              hour_angle: 0,
              hour_align: hmUI.align.LEFT,

              minute_startX: 93,
              minute_startY: 248,
              minute_array: ["t7_0.png","t7_1.png","t7_2.png","t7_3.png","t7_4.png","t7_5.png","t7_6.png","t7_7.png","t7_8.png","t7_9.png"],
              minute_zero: 1,
              minute_space: 0,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital8_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 93,
              hour_startY: 126,
              hour_array: ["t8_0.png","t8_1.png","t8_2.png","t8_3.png","t8_4.png","t8_5.png","t8_6.png","t8_7.png","t8_8.png","t8_9.png"],
              hour_zero: 1,
              hour_space: 3,
              hour_angle: 0,
              hour_align: hmUI.align.LEFT,

              minute_startX: 93,
              minute_startY: 248,
              minute_array: ["t8_0.png","t8_1.png","t8_2.png","t8_3.png","t8_4.png","t8_5.png","t8_6.png","t8_7.png","t8_8.png","t8_9.png"],
              minute_zero: 1,
              minute_space: 0,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });

/////////////////////////////////////////////////////////////////

            idle_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 466,
              h: 466,
              src: 'main6.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_image_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 17,
              y: 145,
              src: 'top_image.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 196,
              y: 15,
              week_en: ["WE6_1.png","WE6_2.png","WE6_3.png","WE6_4.png","WE6_5.png","WE6_6.png","WE6_7.png"],
              week_tc: ["WE6_1.png","WE6_2.png","WE6_3.png","WE6_4.png","WE6_5.png","WE6_6.png","WE6_7.png"],
              week_sc: ["WE6_1.png","WE6_2.png","WE6_3.png","WE6_4.png","WE6_5.png","WE6_6.png","WE6_7.png"],
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 195,
              day_startY: 42,
              day_sc_array: ["day6_0.png","day6_1.png","day6_2.png","day6_3.png","day6_4.png","day6_5.png","day6_6.png","day6_7.png","day6_8.png","day6_9.png"],
              day_tc_array: ["day6_0.png","day6_1.png","day6_2.png","day6_3.png","day6_4.png","day6_5.png","day6_6.png","day6_7.png","day6_8.png","day6_9.png"],
              day_en_array: ["day6_0.png","day6_1.png","day6_2.png","day6_3.png","day6_4.png","day6_5.png","day6_6.png","day6_7.png","day6_8.png","day6_9.png"],
              day_zero: 1,
              day_space: 4,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 181,
              y: 393,
              font_array: ["day6_0.png","day1_1.png","day6_2.png","day6_3.png","day6_4.png","day6_5.png","day6_6.png","day6_7.png","day6_8.png","day6_9.png"],
              padding: false,
              h_space: 3,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            // idle_step_text_rotate_img = hmUI.createWidget(hmUI.widget.Text_Rotate, {
              // x: 406,
              // y: 234,
              // font_array: ["act1_0.png","act1_1.png","act1_2.png","act1_3.png","act1_4.png","act1_5.png","act1_6.png","act1_7.png","act1_8.png","act1_9.png"],
              // zero: true,
              // unit_in_alignment: false,
              // h_space: 3,
              // angle: 90,
              // invalid_image: 'act1_0.png',
              // align_h: hmUI.align.CENTER_H,
              // type: hmUI.data_type.STEP,
              // show_level: hmUI.show_level.ONLY_AOD,
            // });

            idle_step_TextRotate_ASCIIARRAY[0] = 'act6_0.png';  // set of images with numbers
            idle_step_TextRotate_ASCIIARRAY[1] = 'act6_1.png';  // set of images with numbers
            idle_step_TextRotate_ASCIIARRAY[2] = 'act6_2.png';  // set of images with numbers
            idle_step_TextRotate_ASCIIARRAY[3] = 'act6_3.png';  // set of images with numbers
            idle_step_TextRotate_ASCIIARRAY[4] = 'act6_4.png';  // set of images with numbers
            idle_step_TextRotate_ASCIIARRAY[5] = 'act6_5.png';  // set of images with numbers
            idle_step_TextRotate_ASCIIARRAY[6] = 'act6_6.png';  // set of images with numbers
            idle_step_TextRotate_ASCIIARRAY[7] = 'act6_7.png';  // set of images with numbers
            idle_step_TextRotate_ASCIIARRAY[8] = 'act6_8.png';  // set of images with numbers
            idle_step_TextRotate_ASCIIARRAY[9] = 'act6_9.png';  // set of images with numbers

            //start of ignored block
            for (let i = 0; i < 5; i++) {
              idle_step_TextRotate[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 466,
                h: 466,
                center_x: 406,
                center_y: 234,
                pos_x: 406,
                pos_y: 234,
                angle: 90,
                src: 'act1_0.png',
                show_level: hmUI.show_level.ONLY_AOD,
              });
              idle_step_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
            };
            //end of ignored block

            // idle_heart_rate_text_rotate_img = hmUI.createWidget(hmUI.widget.Text_Rotate, {
              // x: 62,
              // y: 275,
              // font_array: ["act1_0.png","act1_1.png","act1_2.png","act1_3.png","act1_4.png","act1_5.png","act1_6.png","act1_7.png","act1_8.png","act1_9.png"],
              // zero: true,
              // unit_in_alignment: false,
              // h_space: 3,
              // angle: -90,
              // invalid_image: 'act1_0.png',
              // align_h: hmUI.align.CENTER_H,
              // type: hmUI.data_type.HEART,
              // show_level: hmUI.show_level.ONLY_AOD,
            // });

            idle_heart_rate_TextRotate_ASCIIARRAY[0] = 'act6_0.png';  // set of images with numbers
            idle_heart_rate_TextRotate_ASCIIARRAY[1] = 'act6_1.png';  // set of images with numbers
            idle_heart_rate_TextRotate_ASCIIARRAY[2] = 'act6_2.png';  // set of images with numbers
            idle_heart_rate_TextRotate_ASCIIARRAY[3] = 'act6_3.png';  // set of images with numbers
            idle_heart_rate_TextRotate_ASCIIARRAY[4] = 'act6_4.png';  // set of images with numbers
            idle_heart_rate_TextRotate_ASCIIARRAY[5] = 'act6_5.png';  // set of images with numbers
            idle_heart_rate_TextRotate_ASCIIARRAY[6] = 'act6_6.png';  // set of images with numbers
            idle_heart_rate_TextRotate_ASCIIARRAY[7] = 'act6_7.png';  // set of images with numbers
            idle_heart_rate_TextRotate_ASCIIARRAY[8] = 'act6_8.png';  // set of images with numbers
            idle_heart_rate_TextRotate_ASCIIARRAY[9] = 'act6_9.png';  // set of images with numbers

            //start of ignored block
            for (let i = 0; i < 5; i++) {
              idle_heart_rate_TextRotate[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 466,
                h: 466,
                center_x: 62,
                center_y: 275,
                pos_x: 62,
                pos_y: 275,
                angle: -90,
                src: 'act1_0.png',
                show_level: hmUI.show_level.ONLY_AOD,
              });
              idle_heart_rate_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
            };
            //end of ignored block

            idle_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 93,
              hour_startY: 126,
              hour_array: ["t1_0.png","t1_1.png","t1_2.png","t1_3.png","t1_4.png","t1_5.png","t1_6.png","t1_7.png","t1_8.png","t1_9.png"],
              hour_zero: 1,
              hour_space: 3,
              hour_angle: 0,
              hour_align: hmUI.align.LEFT,

              minute_startX: 93,
              minute_startY: 248,
              minute_array: ["t1_0.png","t1_1.png","t1_2.png","t1_3.png","t1_4.png","t1_5.png","t1_6.png","t1_7.png","t1_8.png","t1_9.png"],
              minute_zero: 1,
              minute_space: 0,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_AOD,
            });

        normal_stopwatch_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 195,
              y: 260,
              w: 97,

              h: 97,

              type: hmUI.data_type.STOP_WATCH,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_countdown_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 197,
              y: 128,
              w: 97,

              h: 97,

              type: hmUI.data_type.COUNT_DOWN,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sunrise_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 86,
              y: 23,
              w: 92,
              h: 60,
              src: '0_Empty.png',
              type: hmUI.data_type.SUN_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 295,
              y: 19,
              w: 86,
              h: 72,
              src: '0_Empty.png',
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_spo2_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 65,
              y: 153,
              w: 26,
              h: 64,
              src: '0_Empty.png',
              type: hmUI.data_type.SPO2,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 63,
              y: 244,
              w: 29,
              h: 68,
              src: '0_Empty.png',
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

	// calendar
	hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 198,
              y: 11,
              w: 87,
              h: 87,
	 text: '',
	  normal_src: '0_Empty.png',
	  press_src: '0_Empty.png',
	  click_func: () => {
	hmApp.startApp({ url: 'ScheduleCalScreen', native: true });
	  },
	  show_level: hmUI.show_level.ONLY_NORMAL,
	});

            normal_step_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 377,
              y: 175,
              w: 31,
              h: 119,
              src: '0_Empty.png',
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            let screenType = hmSetting.getScreenType();
            function text_update() {

              console.log('update text rotate STEP');
              let valueStep = step.current;
              let normal_step_rotate_string = parseInt(valueStep).toString();
              normal_step_rotate_string = normal_step_rotate_string.padStart(5, '0');

              if (screenType != hmSetting.screen_type.AOD) {
                for (var i = 1; i < 5; i++) {  // hide all symbols
                  normal_step_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                if (valueStep != null && valueStep != undefined && isFinite(valueStep) && normal_step_rotate_string.length > 0 && normal_step_rotate_string.length < 6) {  // display data if it was possible to get it
                  let img_offset = 0;
                  // alignment = CENTER_H
                  let normal_step_TextRotate_posOffset = normal_step_TextRotate_img_width * normal_step_rotate_string.length;
                  normal_step_TextRotate_posOffset = normal_step_TextRotate_posOffset + 3 * (normal_step_rotate_string.length - 1);
                  img_offset -= normal_step_TextRotate_posOffset/2;
                  // alignment end
                  
                  let index = 0;
                  for (let char of normal_step_rotate_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 5) break;
                    if (charCode >= 0 && charCode < 10) { 
                      normal_step_TextRotate[index].setProperty(hmUI.prop.POS_X, 418 + img_offset);


///////////////////////////////              

	   if ( backgroundnumber==1){
                      normal_step_TextRotate[index].setProperty(hmUI.prop.SRC, normal_step_TextRotate_ASCIIARRAY[charCode]);
                    }

	  if ( backgroundnumber==2){
                      normal_step_TextRotate[index].setProperty(hmUI.prop.SRC, normal_step2_TextRotate_ASCIIARRAY[charCode]);
                    }


	  if ( backgroundnumber==3){
                      normal_step_TextRotate[index].setProperty(hmUI.prop.SRC, normal_step3_TextRotate_ASCIIARRAY[charCode]);
                    }


	  if ( backgroundnumber==4){
                      normal_step_TextRotate[index].setProperty(hmUI.prop.SRC, normal_step4_TextRotate_ASCIIARRAY[charCode]);
                    }


	  if ( backgroundnumber==5){
                      normal_step_TextRotate[index].setProperty(hmUI.prop.SRC, normal_step5_TextRotate_ASCIIARRAY[charCode]);
                    }

	  if ( backgroundnumber==6){
                      normal_step_TextRotate[index].setProperty(hmUI.prop.SRC, normal_step6_TextRotate_ASCIIARRAY[charCode]);
                    }


/////////////////////////////////////


                      normal_step_TextRotate[index].setProperty(hmUI.prop.VISIBLE, true);
                      img_offset += normal_step_TextRotate_img_width + 3;
                      index++;
                    };  // end if digit
                  };  // end char of string
                }  // end isFinite
                else {
                  normal_step_TextRotate[0].setProperty(hmUI.prop.POS_X, 418 - normal_step_TextRotate_error_img_width / 2);
                  normal_step_TextRotate[0].setProperty(hmUI.prop.SRC, 'act1_0.png');
                  normal_step_TextRotate[0].setProperty(hmUI.prop.VISIBLE, true);
                };  // end else isFinite

              };

              console.log('update text rotate HEART');
              let valueHeartRate = heart_rate.last;
              let normal_heart_rate_rotate_string = parseInt(valueHeartRate).toString();
              normal_heart_rate_rotate_string = normal_heart_rate_rotate_string.padStart(3, '0');

              if (screenType != hmSetting.screen_type.AOD) {
                for (var i = 1; i < 5; i++) {  // hide all symbols
                  normal_heart_rate_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                if (valueHeartRate != null && valueHeartRate != undefined && isFinite(valueHeartRate) && normal_heart_rate_rotate_string.length > 0 && normal_heart_rate_rotate_string.length < 6) {  // display data if it was possible to get it
                  let img_offset = 0;
                  // alignment = CENTER_H
                  let normal_heart_rate_TextRotate_posOffset = normal_heart_rate_TextRotate_img_width * normal_heart_rate_rotate_string.length;
                  normal_heart_rate_TextRotate_posOffset = normal_heart_rate_TextRotate_posOffset + 3 * (normal_heart_rate_rotate_string.length - 1);
                  img_offset -= normal_heart_rate_TextRotate_posOffset/2;
                  // alignment end
                  
                  let index = 0;
                  for (let char of normal_heart_rate_rotate_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 5) break;
                    if (charCode >= 0 && charCode < 10) { 
                      normal_heart_rate_TextRotate[index].setProperty(hmUI.prop.POS_X, 64 + img_offset);


//////////////////////////////////////

  if ( backgroundnumber==1){
                      normal_heart_rate_TextRotate[index].setProperty(hmUI.prop.SRC, normal_heart_rate_TextRotate_ASCIIARRAY[charCode]);
       }

  if ( backgroundnumber==2){
                      normal_heart_rate_TextRotate[index].setProperty(hmUI.prop.SRC, normal_heart2_rate_TextRotate_ASCIIARRAY[charCode]);
       }

  if ( backgroundnumber==3){
                      normal_heart_rate_TextRotate[index].setProperty(hmUI.prop.SRC, normal_heart3_rate_TextRotate_ASCIIARRAY[charCode]);
       }

  if ( backgroundnumber==4){
                      normal_heart_rate_TextRotate[index].setProperty(hmUI.prop.SRC, normal_heart4_rate_TextRotate_ASCIIARRAY[charCode]);
       }

if ( backgroundnumber==5){
                      normal_heart_rate_TextRotate[index].setProperty(hmUI.prop.SRC, normal_heart5_rate_TextRotate_ASCIIARRAY[charCode]);
       }

if ( backgroundnumber==6){
                      normal_heart_rate_TextRotate[index].setProperty(hmUI.prop.SRC, normal_heart6_rate_TextRotate_ASCIIARRAY[charCode]);
       }


////////////////////////////
                   
   normal_heart_rate_TextRotate[index].setProperty(hmUI.prop.VISIBLE, true);
                      img_offset += normal_heart_rate_TextRotate_img_width + 3;
                      index++;
                    };  // end if digit
                  };  // end char of string
                }  // end isFinite
                else {
                  normal_heart_rate_TextRotate[0].setProperty(hmUI.prop.POS_X, 64 - normal_heart_rate_TextRotate_error_img_width / 2);
                  normal_heart_rate_TextRotate[0].setProperty(hmUI.prop.SRC, 'act1_0.png');
                  normal_heart_rate_TextRotate[0].setProperty(hmUI.prop.VISIBLE, true);
                };  // end else isFinite

              };

              console.log('update text rotate STEP');
              let idle_step_rotate_string = parseInt(valueStep).toString();
              idle_step_rotate_string = idle_step_rotate_string.padStart(5, '0');

              if (screenType == hmSetting.screen_type.AOD) {
                for (var i = 1; i < 5; i++) {  // hide all symbols
                  idle_step_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                if (valueStep != null && valueStep != undefined && isFinite(valueStep) && idle_step_rotate_string.length > 0 && idle_step_rotate_string.length < 6) {  // display data if it was possible to get it
                  let img_offset = 0;
                  // alignment = CENTER_H
                  let idle_step_TextRotate_posOffset = idle_step_TextRotate_img_width * idle_step_rotate_string.length;
                  idle_step_TextRotate_posOffset = idle_step_TextRotate_posOffset + 3 * (idle_step_rotate_string.length - 1);
                  img_offset -= idle_step_TextRotate_posOffset/2;
                  // alignment end
                  
                  let index = 0;
                  for (let char of idle_step_rotate_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 5) break;
                    if (charCode >= 0 && charCode < 10) { 
                      idle_step_TextRotate[index].setProperty(hmUI.prop.POS_X, 418 + img_offset);
                      idle_step_TextRotate[index].setProperty(hmUI.prop.SRC, idle_step_TextRotate_ASCIIARRAY[charCode]);
                      idle_step_TextRotate[index].setProperty(hmUI.prop.VISIBLE, true);
                      img_offset += idle_step_TextRotate_img_width + 3;
                      index++;
                    };  // end if digit
                  };  // end char of string
                }  // end isFinite
                else {
                  idle_step_TextRotate[0].setProperty(hmUI.prop.POS_X, 418 - idle_step_TextRotate_error_img_width / 2);
                  idle_step_TextRotate[0].setProperty(hmUI.prop.SRC, 'act1_0.png');
                  idle_step_TextRotate[0].setProperty(hmUI.prop.VISIBLE, true);
                };  // end else isFinite

              };

              console.log('update text rotate HEART');
              let idle_heart_rate_rotate_string = parseInt(valueHeartRate).toString();
              idle_heart_rate_rotate_string = idle_heart_rate_rotate_string.padStart(3, '0');

              if (screenType == hmSetting.screen_type.AOD) {
                for (var i = 1; i < 5; i++) {  // hide all symbols
                  idle_heart_rate_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                if (valueHeartRate != null && valueHeartRate != undefined && isFinite(valueHeartRate) && idle_heart_rate_rotate_string.length > 0 && idle_heart_rate_rotate_string.length < 6) {  // display data if it was possible to get it
                  let img_offset = 0;
                  // alignment = CENTER_H
                  let idle_heart_rate_TextRotate_posOffset = idle_heart_rate_TextRotate_img_width * idle_heart_rate_rotate_string.length;
                  idle_heart_rate_TextRotate_posOffset = idle_heart_rate_TextRotate_posOffset + 3 * (idle_heart_rate_rotate_string.length - 1);
                  img_offset -= idle_heart_rate_TextRotate_posOffset/2;
                  // alignment end
                  
                  let index = 0;
                  for (let char of idle_heart_rate_rotate_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 5) break;
                    if (charCode >= 0 && charCode < 10) { 
                      idle_heart_rate_TextRotate[index].setProperty(hmUI.prop.POS_X, 64 + img_offset);
                      idle_heart_rate_TextRotate[index].setProperty(hmUI.prop.SRC, idle_heart_rate_TextRotate_ASCIIARRAY[charCode]);
                      idle_heart_rate_TextRotate[index].setProperty(hmUI.prop.VISIBLE, true);
                      img_offset += idle_heart_rate_TextRotate_img_width + 3;
                      index++;
                    };  // end if digit
                  };  // end char of string
                }  // end isFinite
                else {
                  idle_heart_rate_TextRotate[0].setProperty(hmUI.prop.POS_X, 64 - idle_heart_rate_TextRotate_error_img_width / 2);
                  idle_heart_rate_TextRotate[0].setProperty(hmUI.prop.SRC, 'act1_0.png');
                  idle_heart_rate_TextRotate[0].setProperty(hmUI.prop.VISIBLE, true);
                };  // end else isFinite

              };

            };

            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                text_update();

                let nawAnimationTime = now.utc;;
                
                let delay_anim_motion_1 = 0;
                let repeat_anim_motion_1 = 500;
                delay_anim_motion_1 = repeat_anim_motion_1 - (nawAnimationTime - normal_motion_animation_lastTime_1);
                if(delay_anim_motion_1 < 0) delay_anim_motion_1 = 0; 
                if((nawAnimationTime - normal_motion_animation_lastTime_1) > repeat_anim_motion_1*2) {
                  normal_motion_animation_count_1 = 0;
                  timer_anim_motion_1_mirror = false;
                };

                if (!timer_anim_motion_1) {
                  timer_anim_motion_1 = timer.createTimer(delay_anim_motion_1, repeat_anim_motion_1, (function (option) {
                    if(timer_anim_motion_1_mirror) {
                      anim_motion_1_mirror()
                    } else {
                      anim_motion_1_complete_call()
                    };
                    timer_anim_motion_1_mirror = !timer_anim_motion_1_mirror;
                  })); // end timer create
                };
                
                let delay_anim_motion_2 = 0;
                let repeat_anim_motion_2 = 500;
                delay_anim_motion_2 = repeat_anim_motion_2 - (nawAnimationTime - normal_motion_animation_lastTime_2);
                if(delay_anim_motion_2 < 0) delay_anim_motion_2 = 0; 
                if((nawAnimationTime - normal_motion_animation_lastTime_2) > repeat_anim_motion_2*2) {
                  normal_motion_animation_count_2 = 0;
                  timer_anim_motion_2_mirror = false;
                };

                if (!timer_anim_motion_2) {
                  timer_anim_motion_2 = timer.createTimer(delay_anim_motion_2, repeat_anim_motion_2, (function (option) {
                    if(timer_anim_motion_2_mirror) {
                      anim_motion_2_mirror()
                    } else {
                      anim_motion_2_complete_call()
                    };
                    timer_anim_motion_2_mirror = !timer_anim_motion_2_mirror;
                  })); // end timer create
                };

              }),
              pause_call: (function () {
              console.log('pause_call()');
                stop_anim_motion_1();
                stop_anim_motion_2();

              }),
            });

/////////////////Show element at the first time //////////

if (cc==0) {
  cc = 1;


        normal_battery_text_text_img.setProperty(hmUI.prop.VISIBLE, true);
        normal_battery2_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
        normal_battery3_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
        normal_battery4_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
     normal_battery5_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
     normal_battery6_text_text_img.setProperty(hmUI.prop.VISIBLE, false);

        normal_date_img_date_week_img.setProperty(hmUI.prop.VISIBLE, true);
        normal_date2_img_date_week_img.setProperty(hmUI.prop.VISIBLE, false);
        normal_date3_img_date_week_img.setProperty(hmUI.prop.VISIBLE, false);
        normal_date4_img_date_week_img.setProperty(hmUI.prop.VISIBLE, false);
     normal_date5_img_date_week_img.setProperty(hmUI.prop.VISIBLE, false);
       normal_date6_img_date_week_img.setProperty(hmUI.prop.VISIBLE, false);

        normal_date_img_date_day.setProperty(hmUI.prop.VISIBLE, true);
       normal_date2_img_date_day.setProperty(hmUI.prop.VISIBLE, false);
       normal_date3_img_date_day.setProperty(hmUI.prop.VISIBLE, false);
       normal_date4_img_date_day.setProperty(hmUI.prop.VISIBLE, false);
     normal_date5_img_date_day.setProperty(hmUI.prop.VISIBLE, false);
     normal_date6_img_date_day.setProperty(hmUI.prop.VISIBLE, false);


////////////// time font 
    
        normal_digital_clock_img_time.setProperty(hmUI.prop.VISIBLE, true);
        normal_digital2_clock_img_time.setProperty(hmUI.prop.VISIBLE, false);
        normal_digital3_clock_img_time.setProperty(hmUI.prop.VISIBLE, false);
        normal_digital4_clock_img_time.setProperty(hmUI.prop.VISIBLE, false);
        normal_digital5_clock_img_time.setProperty(hmUI.prop.VISIBLE, false);
        normal_digital6_clock_img_time.setProperty(hmUI.prop.VISIBLE, false);
        normal_digital7_clock_img_time.setProperty(hmUI.prop.VISIBLE, false);
        normal_digital8_clock_img_time.setProperty(hmUI.prop.VISIBLE, false);

}
//////////////////////////////////////////////////////////////////////////////////////////////////
 
 
           // Element on/off
            btnbackground = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 92,
             y: 379,
              text: '',
              w: 97,

              h: 97,

              normal_src: '0_Empty.png',
              press_src: '0_Empty.png',
              click_func: () => {
               click_Background();
              },
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            btnbackground.setProperty(hmUI.prop.VISIBLE, true);
            // Change background shortcut end


//////////////////////////////////////////////////////////////////////////////////////////////////
         // change color time //
            btncolorfont = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 284,
              y: 382,
              text: '',
              w: 97,

              h: 97,

              normal_src: '0_Empty.png',
              press_src: '0_Empty.png',
              click_func: () => {
               click_color();
              },
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            btncolorfont.setProperty(hmUI.prop.VISIBLE, true);
            // Change background shortcut end

//////////////////////////////////////////////////////////////////////////////////////////////////




                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}