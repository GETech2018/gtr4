﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        const logger = Logger.getLogger('watchface_SashaCX75');
        //end of ignored block

        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_calorie_TextCircle = new Array(4);
        let normal_calorie_TextCircle_ASCIIARRAY = new Array(10);
        let normal_calorie_TextCircle_img_width = 15;
        let normal_calorie_TextCircle_img_height = 32;
        let normal_temperature_current_text_img = ''
        let normal_distance_TextCircle = new Array(5);
        let normal_distance_TextCircle_ASCIIARRAY = new Array(10);
        let normal_distance_TextCircle_img_width = 15;
        let normal_distance_TextCircle_img_height = 32;
        let normal_distance_TextCircle_dot_width = 8;
        let normal_distance_TextCircle_error_img_width = 32;
        let normal_step_TextCircle = new Array(5);
        let normal_step_TextCircle_ASCIIARRAY = new Array(10);
        let normal_step_TextCircle_img_width = 15;
        let normal_step_TextCircle_img_height = 32;
        let normal_step_TextCircle_error_img_width = 32;
        let normal_battery_TextCircle = new Array(3);
        let normal_battery_TextCircle_ASCIIARRAY = new Array(10);
        let normal_battery_TextCircle_img_width = 15;
        let normal_battery_TextCircle_img_height = 32;
        let normal_battery_TextCircle_unit = null;
        let normal_battery_TextCircle_unit_width = 24;
        let normal_date_img_date_month_img = ''
        let normal_date_img_date_week_img = ''
        let normal_date_img_date_day = ''
        let normal_analog_clock_time_pointer_hour = ''
        let normal_analog_clock_time_pointer_minute = ''
        let normal_analog_clock_time_pointer_second = ''
        let idle_background_bg_img = ''
        let idle_calorie_TextCircle = new Array(4);
        let idle_calorie_TextCircle_ASCIIARRAY = new Array(10);
        let idle_calorie_TextCircle_img_width = 15;
        let idle_calorie_TextCircle_img_height = 32;
        let idle_temperature_current_text_img = ''
        let idle_distance_TextCircle = new Array(5);
        let idle_distance_TextCircle_ASCIIARRAY = new Array(10);
        let idle_distance_TextCircle_img_width = 15;
        let idle_distance_TextCircle_img_height = 32;
        let idle_distance_TextCircle_dot_width = 8;
        let idle_distance_TextCircle_error_img_width = 32;
        let idle_step_TextCircle = new Array(5);
        let idle_step_TextCircle_ASCIIARRAY = new Array(10);
        let idle_step_TextCircle_img_width = 15;
        let idle_step_TextCircle_img_height = 32;
        let idle_step_TextCircle_error_img_width = 32;
        let idle_battery_TextCircle = new Array(3);
        let idle_battery_TextCircle_ASCIIARRAY = new Array(10);
        let idle_battery_TextCircle_img_width = 15;
        let idle_battery_TextCircle_img_height = 32;
        let idle_battery_TextCircle_unit = null;
        let idle_battery_TextCircle_unit_width = 24;
        let idle_date_img_date_month_img = ''
        let idle_date_img_date_week_img = ''
        let idle_date_img_date_day = ''
        let idle_analog_clock_time_pointer_hour = ''
        let idle_analog_clock_time_pointer_minute = ''
        let idle_analog_clock_time_pointer_second = ''


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            console.log('Watch_Face.ScreenNormal');
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 466,
              h: 466,
              src: '0002.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_calorie_text_circle_img = hmUI.createWidget(hmUI.widget.Text_Circle, {
              // circle_center_X: 233,
              // circle_center_Y: 233,
              // font_array: ["BN_01.png","BN_02.png","BN_03.png","BN_04.png","BN_05.png","BN_06.png","BN_07.png","BN_08.png","BN_09.png","BN_10.png"],
              // radius: 217,
              // angle: 111,
              // char_space_angle: 0,
              // zero: false,
              // reverse_direction: true,
              // unit_in_alignment: true,
              // vertical_alignment: CENTER_V,
              // horizontal_alignment: LEFT,
              // type: hmUI.data_type.CAL,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_calorie_TextCircle_ASCIIARRAY[0] = 'BN_01.png';  // set of images with numbers
            normal_calorie_TextCircle_ASCIIARRAY[1] = 'BN_02.png';  // set of images with numbers
            normal_calorie_TextCircle_ASCIIARRAY[2] = 'BN_03.png';  // set of images with numbers
            normal_calorie_TextCircle_ASCIIARRAY[3] = 'BN_04.png';  // set of images with numbers
            normal_calorie_TextCircle_ASCIIARRAY[4] = 'BN_05.png';  // set of images with numbers
            normal_calorie_TextCircle_ASCIIARRAY[5] = 'BN_06.png';  // set of images with numbers
            normal_calorie_TextCircle_ASCIIARRAY[6] = 'BN_07.png';  // set of images with numbers
            normal_calorie_TextCircle_ASCIIARRAY[7] = 'BN_08.png';  // set of images with numbers
            normal_calorie_TextCircle_ASCIIARRAY[8] = 'BN_09.png';  // set of images with numbers
            normal_calorie_TextCircle_ASCIIARRAY[9] = 'BN_10.png';  // set of images with numbers

            //start of ignored block
            for (let i = 0; i < 4; i++) {
              normal_calorie_TextCircle[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 466,
                h: 466,
                center_x: 233,
                center_y: 233,
                pos_x: 233 - normal_calorie_TextCircle_img_width / 2,
                pos_y: 233 + 201,
                src: 'BN_01.png',
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
              normal_calorie_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
            };
            //end of ignored block
            
            const calorie = hmSensor.createSensor(hmSensor.id.CALORIE);
            calorie.addEventListener(hmSensor.event.CHANGE, function() {
              text_update();
            });
            
            function toDegree (radian) {
              return radian * (180 / Math.PI);
            };

            normal_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 46,
              y: 353,
              font_array: ["BN_01.png","BN_02.png","BN_03.png","BN_04.png","BN_05.png","BN_06.png","BN_07.png","BN_08.png","BN_09.png","BN_10.png"],
              padding: false,
              h_space: 0,
              angle: 50,
              unit_sc: 'Grad.png',
              unit_tc: 'Grad.png',
              unit_en: 'Grad.png',
              negative_image: 'Min.png',
              invalid_image: 'Error.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_distance_text_circle_img = hmUI.createWidget(hmUI.widget.Text_Circle, {
              // circle_center_X: 233,
              // circle_center_Y: 233,
              // font_array: ["BN_01.png","BN_02.png","BN_03.png","BN_04.png","BN_05.png","BN_06.png","BN_07.png","BN_08.png","BN_09.png","BN_10.png"],
              // radius: 203,
              // angle: -46,
              // char_space_angle: 0,
              // dot_image: 'Zpt.png',
              // error_image: 'Error.png',
              // zero: false,
              // reverse_direction: false,
              // unit_in_alignment: true,
              // vertical_alignment: BOTTOM,
              // horizontal_alignment: CENTER_H,
              // type: hmUI.data_type.DISTANCE,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_distance_TextCircle_ASCIIARRAY[0] = 'BN_01.png';  // set of images with numbers
            normal_distance_TextCircle_ASCIIARRAY[1] = 'BN_02.png';  // set of images with numbers
            normal_distance_TextCircle_ASCIIARRAY[2] = 'BN_03.png';  // set of images with numbers
            normal_distance_TextCircle_ASCIIARRAY[3] = 'BN_04.png';  // set of images with numbers
            normal_distance_TextCircle_ASCIIARRAY[4] = 'BN_05.png';  // set of images with numbers
            normal_distance_TextCircle_ASCIIARRAY[5] = 'BN_06.png';  // set of images with numbers
            normal_distance_TextCircle_ASCIIARRAY[6] = 'BN_07.png';  // set of images with numbers
            normal_distance_TextCircle_ASCIIARRAY[7] = 'BN_08.png';  // set of images with numbers
            normal_distance_TextCircle_ASCIIARRAY[8] = 'BN_09.png';  // set of images with numbers
            normal_distance_TextCircle_ASCIIARRAY[9] = 'BN_10.png';  // set of images with numbers

            //start of ignored block
            for (let i = 0; i < 5; i++) {
              normal_distance_TextCircle[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 466,
                h: 466,
                center_x: 233,
                center_y: 233,
                pos_x: 233 - normal_distance_TextCircle_img_width / 2,
                pos_y: 233 - 235,
                src: 'BN_01.png',
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
              normal_distance_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
            };
            //end of ignored block
            
            const distance = hmSensor.createSensor(hmSensor.id.DISTANCE);
            distance.addEventListener(hmSensor.event.CHANGE, function() {
              text_update();
            });

            // normal_step_text_circle_img = hmUI.createWidget(hmUI.widget.Text_Circle, {
              // circle_center_X: 233,
              // circle_center_Y: 233,
              // font_array: ["BN_01.png","BN_02.png","BN_03.png","BN_04.png","BN_05.png","BN_06.png","BN_07.png","BN_08.png","BN_09.png","BN_10.png"],
              // radius: 202,
              // angle: 72,
              // char_space_angle: 0,
              // error_image: 'Error.png',
              // zero: false,
              // reverse_direction: false,
              // unit_in_alignment: true,
              // vertical_alignment: BOTTOM,
              // horizontal_alignment: CENTER_H,
              // type: hmUI.data_type.STEP,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_step_TextCircle_ASCIIARRAY[0] = 'BN_01.png';  // set of images with numbers
            normal_step_TextCircle_ASCIIARRAY[1] = 'BN_02.png';  // set of images with numbers
            normal_step_TextCircle_ASCIIARRAY[2] = 'BN_03.png';  // set of images with numbers
            normal_step_TextCircle_ASCIIARRAY[3] = 'BN_04.png';  // set of images with numbers
            normal_step_TextCircle_ASCIIARRAY[4] = 'BN_05.png';  // set of images with numbers
            normal_step_TextCircle_ASCIIARRAY[5] = 'BN_06.png';  // set of images with numbers
            normal_step_TextCircle_ASCIIARRAY[6] = 'BN_07.png';  // set of images with numbers
            normal_step_TextCircle_ASCIIARRAY[7] = 'BN_08.png';  // set of images with numbers
            normal_step_TextCircle_ASCIIARRAY[8] = 'BN_09.png';  // set of images with numbers
            normal_step_TextCircle_ASCIIARRAY[9] = 'BN_10.png';  // set of images with numbers

            //start of ignored block
            for (let i = 0; i < 5; i++) {
              normal_step_TextCircle[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 466,
                h: 466,
                center_x: 233,
                center_y: 233,
                pos_x: 233 - normal_step_TextCircle_img_width / 2,
                pos_y: 233 - 234,
                src: 'BN_01.png',
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
              normal_step_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
            };
            //end of ignored block
            
            const step = hmSensor.createSensor(hmSensor.id.STEP);
            step.addEventListener(hmSensor.event.CHANGE, function() {
              text_update();
            });

            // normal_battery_text_circle_img = hmUI.createWidget(hmUI.widget.Text_Circle, {
              // circle_center_X: 233,
              // circle_center_Y: 233,
              // font_array: ["BN_01.png","BN_02.png","BN_03.png","BN_04.png","BN_05.png","BN_06.png","BN_07.png","BN_08.png","BN_09.png","BN_10.png"],
              // radius: 234,
              // angle: 165,
              // char_space_angle: 0,
              // unit: 'Proc.png',
              // zero: false,
              // reverse_direction: true,
              // unit_in_alignment: true,
              // vertical_alignment: BOTTOM,
              // horizontal_alignment: CENTER_H,
              // type: hmUI.data_type.BATTERY,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_battery_TextCircle_ASCIIARRAY[0] = 'BN_01.png';  // set of images with numbers
            normal_battery_TextCircle_ASCIIARRAY[1] = 'BN_02.png';  // set of images with numbers
            normal_battery_TextCircle_ASCIIARRAY[2] = 'BN_03.png';  // set of images with numbers
            normal_battery_TextCircle_ASCIIARRAY[3] = 'BN_04.png';  // set of images with numbers
            normal_battery_TextCircle_ASCIIARRAY[4] = 'BN_05.png';  // set of images with numbers
            normal_battery_TextCircle_ASCIIARRAY[5] = 'BN_06.png';  // set of images with numbers
            normal_battery_TextCircle_ASCIIARRAY[6] = 'BN_07.png';  // set of images with numbers
            normal_battery_TextCircle_ASCIIARRAY[7] = 'BN_08.png';  // set of images with numbers
            normal_battery_TextCircle_ASCIIARRAY[8] = 'BN_09.png';  // set of images with numbers
            normal_battery_TextCircle_ASCIIARRAY[9] = 'BN_10.png';  // set of images with numbers

            //start of ignored block
            for (let i = 0; i < 3; i++) {
              normal_battery_TextCircle[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 466,
                h: 466,
                center_x: 233,
                center_y: 233,
                pos_x: 233 - normal_battery_TextCircle_img_width / 2,
                pos_y: 233 + 202,
                src: 'BN_01.png',
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
              normal_battery_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
            };

            normal_battery_TextCircle_unit = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 466,
              h: 466,
              center_x: 233,
              center_y: 233,
              pos_x: 233 - normal_battery_TextCircle_unit_width / 2,
              pos_y: 233 + 202,
              src: 'Proc.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            normal_battery_TextCircle_unit.setProperty(hmUI.prop.VISIBLE, false);
            //end of ignored block
            
            const battery = hmSensor.createSensor(hmSensor.id.BATTERY);
            battery.addEventListener(hmSensor.event.CHANGE, function() {
              text_update();
            });

            normal_date_img_date_month_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 256,
              month_startY: 5,
              month_sc_array: ["M_01.png","M_02.png","M_03.png","M_04.png","M_05.png","M_06.png","M_07.png","M_08.png","M_09.png","M_10.png","M_11.png","M_12.png"],
              month_tc_array: ["M_01.png","M_02.png","M_03.png","M_04.png","M_05.png","M_06.png","M_07.png","M_08.png","M_09.png","M_10.png","M_11.png","M_12.png"],
              month_en_array: ["M_01.png","M_02.png","M_03.png","M_04.png","M_05.png","M_06.png","M_07.png","M_08.png","M_09.png","M_10.png","M_11.png","M_12.png"],
              month_is_character: true ,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 133,
              y: 5,
              week_en: ["W_01.png","W_02.png","W_03.png","W_04.png","W_05.png","W_06.png","W_07.png"],
              week_tc: ["W_01.png","W_02.png","W_03.png","W_04.png","W_05.png","W_06.png","W_07.png"],
              week_sc: ["W_01.png","W_02.png","W_03.png","W_04.png","W_05.png","W_06.png","W_07.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 218,
              day_startY: -3,
              day_sc_array: ["BN_01.png","BN_02.png","BN_03.png","BN_04.png","BN_05.png","BN_06.png","BN_07.png","BN_08.png","BN_09.png","BN_10.png"],
              day_tc_array: ["BN_01.png","BN_02.png","BN_03.png","BN_04.png","BN_05.png","BN_06.png","BN_07.png","BN_08.png","BN_09.png","BN_10.png"],
              day_en_array: ["BN_01.png","BN_02.png","BN_03.png","BN_04.png","BN_05.png","BN_06.png","BN_07.png","BN_08.png","BN_09.png","BN_10.png"],
              day_zero: 0,
              day_space: 0,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_hour = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              hour_path: 'Hour.png',
              hour_centerX: 233,
              hour_centerY: 233,
              hour_posX: 40,
              hour_posY: 128,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_minute = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              minute_path: 'Minute.png',
              minute_centerX: 233,
              minute_centerY: 233,
              minute_posX: 34,
              minute_posY: 193,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_second = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              second_path: 'Second.png',
              second_centerX: 233,
              second_centerY: 233,
              second_posX: 39,
              second_posY: 203,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            console.log('Watch_Face.ScreenAOD');
            idle_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 466,
              h: 466,
              src: '0002.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            // idle_calorie_text_circle_img = hmUI.createWidget(hmUI.widget.Text_Circle, {
              // circle_center_X: 233,
              // circle_center_Y: 233,
              // font_array: ["BN_01.png","BN_02.png","BN_03.png","BN_04.png","BN_05.png","BN_06.png","BN_07.png","BN_08.png","BN_09.png","BN_10.png"],
              // radius: 217,
              // angle: 111,
              // char_space_angle: 0,
              // zero: false,
              // reverse_direction: true,
              // unit_in_alignment: true,
              // vertical_alignment: CENTER_V,
              // horizontal_alignment: LEFT,
              // type: hmUI.data_type.CAL,
              // show_level: hmUI.show_level.ONLY_AOD,
            // });

            idle_calorie_TextCircle_ASCIIARRAY[0] = 'BN_01.png';  // set of images with numbers
            idle_calorie_TextCircle_ASCIIARRAY[1] = 'BN_02.png';  // set of images with numbers
            idle_calorie_TextCircle_ASCIIARRAY[2] = 'BN_03.png';  // set of images with numbers
            idle_calorie_TextCircle_ASCIIARRAY[3] = 'BN_04.png';  // set of images with numbers
            idle_calorie_TextCircle_ASCIIARRAY[4] = 'BN_05.png';  // set of images with numbers
            idle_calorie_TextCircle_ASCIIARRAY[5] = 'BN_06.png';  // set of images with numbers
            idle_calorie_TextCircle_ASCIIARRAY[6] = 'BN_07.png';  // set of images with numbers
            idle_calorie_TextCircle_ASCIIARRAY[7] = 'BN_08.png';  // set of images with numbers
            idle_calorie_TextCircle_ASCIIARRAY[8] = 'BN_09.png';  // set of images with numbers
            idle_calorie_TextCircle_ASCIIARRAY[9] = 'BN_10.png';  // set of images with numbers

            //start of ignored block
            for (let i = 0; i < 4; i++) {
              idle_calorie_TextCircle[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 466,
                h: 466,
                center_x: 233,
                center_y: 233,
                pos_x: 233 - idle_calorie_TextCircle_img_width / 2,
                pos_y: 233 + 201,
                src: 'BN_01.png',
                show_level: hmUI.show_level.ONLY_AOD,
              });
              idle_calorie_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
            };
            //end of ignored block

            idle_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 46,
              y: 353,
              font_array: ["BN_01.png","BN_02.png","BN_03.png","BN_04.png","BN_05.png","BN_06.png","BN_07.png","BN_08.png","BN_09.png","BN_10.png"],
              padding: false,
              h_space: 0,
              angle: 50,
              unit_sc: 'Grad.png',
              unit_tc: 'Grad.png',
              unit_en: 'Grad.png',
              negative_image: 'Min.png',
              invalid_image: 'Error.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            // idle_distance_text_circle_img = hmUI.createWidget(hmUI.widget.Text_Circle, {
              // circle_center_X: 233,
              // circle_center_Y: 233,
              // font_array: ["BN_01.png","BN_02.png","BN_03.png","BN_04.png","BN_05.png","BN_06.png","BN_07.png","BN_08.png","BN_09.png","BN_10.png"],
              // radius: 203,
              // angle: -46,
              // char_space_angle: 0,
              // dot_image: 'Zpt.png',
              // error_image: 'Error.png',
              // zero: false,
              // reverse_direction: false,
              // unit_in_alignment: true,
              // vertical_alignment: BOTTOM,
              // horizontal_alignment: CENTER_H,
              // type: hmUI.data_type.DISTANCE,
              // show_level: hmUI.show_level.ONLY_AOD,
            // });

            idle_distance_TextCircle_ASCIIARRAY[0] = 'BN_01.png';  // set of images with numbers
            idle_distance_TextCircle_ASCIIARRAY[1] = 'BN_02.png';  // set of images with numbers
            idle_distance_TextCircle_ASCIIARRAY[2] = 'BN_03.png';  // set of images with numbers
            idle_distance_TextCircle_ASCIIARRAY[3] = 'BN_04.png';  // set of images with numbers
            idle_distance_TextCircle_ASCIIARRAY[4] = 'BN_05.png';  // set of images with numbers
            idle_distance_TextCircle_ASCIIARRAY[5] = 'BN_06.png';  // set of images with numbers
            idle_distance_TextCircle_ASCIIARRAY[6] = 'BN_07.png';  // set of images with numbers
            idle_distance_TextCircle_ASCIIARRAY[7] = 'BN_08.png';  // set of images with numbers
            idle_distance_TextCircle_ASCIIARRAY[8] = 'BN_09.png';  // set of images with numbers
            idle_distance_TextCircle_ASCIIARRAY[9] = 'BN_10.png';  // set of images with numbers

            //start of ignored block
            for (let i = 0; i < 5; i++) {
              idle_distance_TextCircle[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 466,
                h: 466,
                center_x: 233,
                center_y: 233,
                pos_x: 233 - idle_distance_TextCircle_img_width / 2,
                pos_y: 233 - 235,
                src: 'BN_01.png',
                show_level: hmUI.show_level.ONLY_AOD,
              });
              idle_distance_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
            };
            //end of ignored block

            // idle_step_text_circle_img = hmUI.createWidget(hmUI.widget.Text_Circle, {
              // circle_center_X: 233,
              // circle_center_Y: 233,
              // font_array: ["BN_01.png","BN_02.png","BN_03.png","BN_04.png","BN_05.png","BN_06.png","BN_07.png","BN_08.png","BN_09.png","BN_10.png"],
              // radius: 202,
              // angle: 72,
              // char_space_angle: 0,
              // error_image: 'Error.png',
              // zero: false,
              // reverse_direction: false,
              // unit_in_alignment: true,
              // vertical_alignment: BOTTOM,
              // horizontal_alignment: CENTER_H,
              // type: hmUI.data_type.STEP,
              // show_level: hmUI.show_level.ONLY_AOD,
            // });

            idle_step_TextCircle_ASCIIARRAY[0] = 'BN_01.png';  // set of images with numbers
            idle_step_TextCircle_ASCIIARRAY[1] = 'BN_02.png';  // set of images with numbers
            idle_step_TextCircle_ASCIIARRAY[2] = 'BN_03.png';  // set of images with numbers
            idle_step_TextCircle_ASCIIARRAY[3] = 'BN_04.png';  // set of images with numbers
            idle_step_TextCircle_ASCIIARRAY[4] = 'BN_05.png';  // set of images with numbers
            idle_step_TextCircle_ASCIIARRAY[5] = 'BN_06.png';  // set of images with numbers
            idle_step_TextCircle_ASCIIARRAY[6] = 'BN_07.png';  // set of images with numbers
            idle_step_TextCircle_ASCIIARRAY[7] = 'BN_08.png';  // set of images with numbers
            idle_step_TextCircle_ASCIIARRAY[8] = 'BN_09.png';  // set of images with numbers
            idle_step_TextCircle_ASCIIARRAY[9] = 'BN_10.png';  // set of images with numbers

            //start of ignored block
            for (let i = 0; i < 5; i++) {
              idle_step_TextCircle[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 466,
                h: 466,
                center_x: 233,
                center_y: 233,
                pos_x: 233 - idle_step_TextCircle_img_width / 2,
                pos_y: 233 - 234,
                src: 'BN_01.png',
                show_level: hmUI.show_level.ONLY_AOD,
              });
              idle_step_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
            };
            //end of ignored block

            // idle_battery_text_circle_img = hmUI.createWidget(hmUI.widget.Text_Circle, {
              // circle_center_X: 233,
              // circle_center_Y: 233,
              // font_array: ["BN_01.png","BN_02.png","BN_03.png","BN_04.png","BN_05.png","BN_06.png","BN_07.png","BN_08.png","BN_09.png","BN_10.png"],
              // radius: 234,
              // angle: 165,
              // char_space_angle: 0,
              // unit: 'Proc.png',
              // zero: false,
              // reverse_direction: true,
              // unit_in_alignment: true,
              // vertical_alignment: BOTTOM,
              // horizontal_alignment: CENTER_H,
              // type: hmUI.data_type.BATTERY,
              // show_level: hmUI.show_level.ONLY_AOD,
            // });

            idle_battery_TextCircle_ASCIIARRAY[0] = 'BN_01.png';  // set of images with numbers
            idle_battery_TextCircle_ASCIIARRAY[1] = 'BN_02.png';  // set of images with numbers
            idle_battery_TextCircle_ASCIIARRAY[2] = 'BN_03.png';  // set of images with numbers
            idle_battery_TextCircle_ASCIIARRAY[3] = 'BN_04.png';  // set of images with numbers
            idle_battery_TextCircle_ASCIIARRAY[4] = 'BN_05.png';  // set of images with numbers
            idle_battery_TextCircle_ASCIIARRAY[5] = 'BN_06.png';  // set of images with numbers
            idle_battery_TextCircle_ASCIIARRAY[6] = 'BN_07.png';  // set of images with numbers
            idle_battery_TextCircle_ASCIIARRAY[7] = 'BN_08.png';  // set of images with numbers
            idle_battery_TextCircle_ASCIIARRAY[8] = 'BN_09.png';  // set of images with numbers
            idle_battery_TextCircle_ASCIIARRAY[9] = 'BN_10.png';  // set of images with numbers

            //start of ignored block
            for (let i = 0; i < 3; i++) {
              idle_battery_TextCircle[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 466,
                h: 466,
                center_x: 233,
                center_y: 233,
                pos_x: 233 - idle_battery_TextCircle_img_width / 2,
                pos_y: 233 + 202,
                src: 'BN_01.png',
                show_level: hmUI.show_level.ONLY_AOD,
              });
              idle_battery_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
            };

            idle_battery_TextCircle_unit = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 466,
              h: 466,
              center_x: 233,
              center_y: 233,
              pos_x: 233 - idle_battery_TextCircle_unit_width / 2,
              pos_y: 233 + 202,
              src: 'Proc.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });
            idle_battery_TextCircle_unit.setProperty(hmUI.prop.VISIBLE, false);
            //end of ignored block

            idle_date_img_date_month_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 256,
              month_startY: 5,
              month_sc_array: ["M_01.png","M_02.png","M_03.png","M_04.png","M_05.png","M_06.png","M_07.png","M_08.png","M_09.png","M_10.png","M_11.png","M_12.png"],
              month_tc_array: ["M_01.png","M_02.png","M_03.png","M_04.png","M_05.png","M_06.png","M_07.png","M_08.png","M_09.png","M_10.png","M_11.png","M_12.png"],
              month_en_array: ["M_01.png","M_02.png","M_03.png","M_04.png","M_05.png","M_06.png","M_07.png","M_08.png","M_09.png","M_10.png","M_11.png","M_12.png"],
              month_is_character: true ,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 133,
              y: 5,
              week_en: ["W_01.png","W_02.png","W_03.png","W_04.png","W_05.png","W_06.png","W_07.png"],
              week_tc: ["W_01.png","W_02.png","W_03.png","W_04.png","W_05.png","W_06.png","W_07.png"],
              week_sc: ["W_01.png","W_02.png","W_03.png","W_04.png","W_05.png","W_06.png","W_07.png"],
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 218,
              day_startY: -3,
              day_sc_array: ["BN_01.png","BN_02.png","BN_03.png","BN_04.png","BN_05.png","BN_06.png","BN_07.png","BN_08.png","BN_09.png","BN_10.png"],
              day_tc_array: ["BN_01.png","BN_02.png","BN_03.png","BN_04.png","BN_05.png","BN_06.png","BN_07.png","BN_08.png","BN_09.png","BN_10.png"],
              day_en_array: ["BN_01.png","BN_02.png","BN_03.png","BN_04.png","BN_05.png","BN_06.png","BN_07.png","BN_08.png","BN_09.png","BN_10.png"],
              day_zero: 0,
              day_space: 0,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_analog_clock_time_pointer_hour = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              hour_path: 'Hour.png',
              hour_centerX: 233,
              hour_centerY: 233,
              hour_posX: 40,
              hour_posY: 128,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_analog_clock_time_pointer_minute = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              minute_path: 'Minute.png',
              minute_centerX: 233,
              minute_centerY: 233,
              minute_posX: 34,
              minute_posY: 193,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_analog_clock_time_pointer_second = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              second_path: 'Second.png',
              second_centerX: 233,
              second_centerY: 233,
              second_posX: 39,
              second_posY: 203,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            let screenType = hmSetting.getScreenType();
            function text_update() {
              console.log('text_update()');

              console.log('update text circle calorie_CALORIE');
              let valueCalories = calorie.current;
              let normal_calorie_circle_string = parseInt(valueCalories).toString();

              if (screenType != hmSetting.screen_type.AOD) {
                for (var i = 1; i < 4; i++) {  // hide all symbols
                  normal_calorie_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                let char_Angle = 291;
                if (valueCalories != null && valueCalories != undefined && isFinite(valueCalories) && normal_calorie_circle_string.length > 0 && normal_calorie_circle_string.length < 6) {  // display data if it was possible to get it
                  let normal_calorie_TextCircle_img_angle = 0;
                  let normal_calorie_TextCircle_dot_img_angle = 0;
                  normal_calorie_TextCircle_img_angle = toDegree(Math.atan2(normal_calorie_TextCircle_img_width/2, 217));
                  
                  let firstSymbol = true;
                  let index = 0;
                  for (let char of normal_calorie_circle_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 4) break;
                    if (charCode >= 0 && charCode < 10) { 
                      if (!firstSymbol) char_Angle -= normal_calorie_TextCircle_img_angle;
                      firstSymbol = false;
                      normal_calorie_TextCircle[index].setProperty(hmUI.prop.ANGLE, char_Angle);
                      normal_calorie_TextCircle[index].setProperty(hmUI.prop.POS_X, 233 - normal_calorie_TextCircle_img_width / 2);
                      normal_calorie_TextCircle[index].setProperty(hmUI.prop.SRC, normal_calorie_TextCircle_ASCIIARRAY[charCode]);
                      normal_calorie_TextCircle[index].setProperty(hmUI.prop.VISIBLE, true);
                      char_Angle -= normal_calorie_TextCircle_img_angle;
                      index++;
                    };  // end if digit
                  };  // end char of string
                }  // end isFinite

              };

              console.log('update text circle DISTANCE');
              let distanceCurrent = distance.current;
              let normal_distance_circle_string = (distanceCurrent / 1000).toFixed(2);

              if (screenType != hmSetting.screen_type.AOD) {
                for (var i = 1; i < 5; i++) {  // hide all symbols
                  normal_distance_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                let char_Angle = -46;
                if (distanceCurrent != null && distanceCurrent != undefined && isFinite(distanceCurrent) && normal_distance_circle_string.length > 0 && normal_distance_circle_string.length < 6) {  // display data if it was possible to get it
                  let normal_distance_TextCircle_img_angle = 0;
                  let normal_distance_TextCircle_dot_img_angle = 0;
                  normal_distance_TextCircle_img_angle = toDegree(Math.atan2(normal_distance_TextCircle_img_width/2, 203));
                  normal_distance_TextCircle_dot_img_angle = toDegree(Math.atan2(normal_distance_TextCircle_dot_width/2, 203));
                  // alignment = CENTER_H
                  let normal_distance_TextCircle_angleOffset = normal_distance_TextCircle_img_angle * (normal_distance_circle_string.length - 1);
                  normal_distance_TextCircle_angleOffset = normal_distance_TextCircle_angleOffset - normal_distance_TextCircle_img_angle + normal_distance_TextCircle_dot_img_angle;
                  char_Angle -= normal_distance_TextCircle_angleOffset;
                  // alignment end
                  
                  let firstSymbol = true;
                  let index = 0;
                  for (let char of normal_distance_circle_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 5) break;
                    if (charCode >= 0 && charCode < 10) { 
                      if (!firstSymbol) char_Angle += normal_distance_TextCircle_img_angle;
                      firstSymbol = false;
                      normal_distance_TextCircle[index].setProperty(hmUI.prop.ANGLE, char_Angle);
                      normal_distance_TextCircle[index].setProperty(hmUI.prop.POS_X, 233 - normal_distance_TextCircle_img_width / 2);
                      normal_distance_TextCircle[index].setProperty(hmUI.prop.SRC, normal_distance_TextCircle_ASCIIARRAY[charCode]);
                      normal_distance_TextCircle[index].setProperty(hmUI.prop.VISIBLE, true);
                      char_Angle += normal_distance_TextCircle_img_angle;
                      index++;
                    }  // end if digit
                    else { 
                      if (!firstSymbol) char_Angle += normal_distance_TextCircle_dot_img_angle; 
                      firstSymbol = false;
                      normal_distance_TextCircle[index].setProperty(hmUI.prop.ANGLE, char_Angle);
                      normal_distance_TextCircle[index].setProperty(hmUI.prop.POS_X, 233 - normal_distance_TextCircle_dot_width / 2);
                      normal_distance_TextCircle[index].setProperty(hmUI.prop.SRC, 'Zpt.png');
                      normal_distance_TextCircle[index].setProperty(hmUI.prop.VISIBLE, true);
                      char_Angle += normal_distance_TextCircle_dot_img_angle;
                      index++;
                    };  // end if dot point 
                  };  // end char of string
                }  // end isFinite
                else {
                  normal_distance_TextCircle[0].setProperty(hmUI.prop.ANGLE, char_Angle);
                  normal_distance_TextCircle[0].setProperty(hmUI.prop.POS_X, 233 - normal_distance_TextCircle_error_img_width / 2);
                  normal_distance_TextCircle[0].setProperty(hmUI.prop.SRC, 'Error.png');
                  normal_distance_TextCircle[0].setProperty(hmUI.prop.VISIBLE, true);
                };  // end else isFinite

              };

              console.log('update text circle step_STEP');
              let valueStep = step.current;
              let normal_step_circle_string = parseInt(valueStep).toString();

              if (screenType != hmSetting.screen_type.AOD) {
                for (var i = 1; i < 5; i++) {  // hide all symbols
                  normal_step_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                let char_Angle = 72;
                if (valueStep != null && valueStep != undefined && isFinite(valueStep) && normal_step_circle_string.length > 0 && normal_step_circle_string.length < 6) {  // display data if it was possible to get it
                  let normal_step_TextCircle_img_angle = 0;
                  let normal_step_TextCircle_dot_img_angle = 0;
                  normal_step_TextCircle_img_angle = toDegree(Math.atan2(normal_step_TextCircle_img_width/2, 202));
                  // alignment = CENTER_H
                  let normal_step_TextCircle_angleOffset = normal_step_TextCircle_img_angle * (normal_step_circle_string.length - 1);
                  char_Angle -= normal_step_TextCircle_angleOffset;
                  // alignment end
                  
                  let firstSymbol = true;
                  let index = 0;
                  for (let char of normal_step_circle_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 5) break;
                    if (charCode >= 0 && charCode < 10) { 
                      if (!firstSymbol) char_Angle += normal_step_TextCircle_img_angle;
                      firstSymbol = false;
                      normal_step_TextCircle[index].setProperty(hmUI.prop.ANGLE, char_Angle);
                      normal_step_TextCircle[index].setProperty(hmUI.prop.POS_X, 233 - normal_step_TextCircle_img_width / 2);
                      normal_step_TextCircle[index].setProperty(hmUI.prop.SRC, normal_step_TextCircle_ASCIIARRAY[charCode]);
                      normal_step_TextCircle[index].setProperty(hmUI.prop.VISIBLE, true);
                      char_Angle += normal_step_TextCircle_img_angle;
                      index++;
                    };  // end if digit
                  };  // end char of string
                }  // end isFinite
                else {
                  normal_step_TextCircle[0].setProperty(hmUI.prop.ANGLE, char_Angle);
                  normal_step_TextCircle[0].setProperty(hmUI.prop.POS_X, 233 - normal_step_TextCircle_error_img_width / 2);
                  normal_step_TextCircle[0].setProperty(hmUI.prop.SRC, 'Error.png');
                  normal_step_TextCircle[0].setProperty(hmUI.prop.VISIBLE, true);
                };  // end else isFinite

              };

              console.log('update text circle battery_BATTERY');
              let valueBattery = battery.current;
              let normal_battery_circle_string = parseInt(valueBattery).toString();

              if (screenType != hmSetting.screen_type.AOD) {
                for (var i = 1; i < 3; i++) {  // hide all symbols
                  normal_battery_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                normal_battery_TextCircle_unit.setProperty(hmUI.prop.VISIBLE, false);
                let char_Angle = 345;
                if (valueBattery != null && valueBattery != undefined && isFinite(valueBattery) && normal_battery_circle_string.length > 0 && normal_battery_circle_string.length < 6) {  // display data if it was possible to get it
                  let normal_battery_TextCircle_img_angle = 0;
                  let normal_battery_TextCircle_dot_img_angle = 0;
                  let normal_battery_TextCircle_unit_angle = 0;
                  normal_battery_TextCircle_img_angle = toDegree(Math.atan2(normal_battery_TextCircle_img_width/2, 234));
                  normal_battery_TextCircle_unit_angle = toDegree(Math.atan2(normal_battery_TextCircle_unit_width/2, 234));
                  // alignment = CENTER_H
                  let normal_battery_TextCircle_angleOffset = normal_battery_TextCircle_img_angle * (normal_battery_circle_string.length - 1);
                  normal_battery_TextCircle_angleOffset = normal_battery_TextCircle_angleOffset + (normal_battery_TextCircle_img_angle + normal_battery_TextCircle_unit_angle + 0) / 2;
                  normal_battery_TextCircle_angleOffset = -normal_battery_TextCircle_angleOffset;
                  char_Angle -= normal_battery_TextCircle_angleOffset;
                  // alignment end
                  
                  let firstSymbol = true;
                  let index = 0;
                  for (let char of normal_battery_circle_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 3) break;
                    if (charCode >= 0 && charCode < 10) { 
                      if (!firstSymbol) char_Angle -= normal_battery_TextCircle_img_angle;
                      firstSymbol = false;
                      normal_battery_TextCircle[index].setProperty(hmUI.prop.ANGLE, char_Angle);
                      normal_battery_TextCircle[index].setProperty(hmUI.prop.POS_X, 233 - normal_battery_TextCircle_img_width / 2);
                      normal_battery_TextCircle[index].setProperty(hmUI.prop.SRC, normal_battery_TextCircle_ASCIIARRAY[charCode]);
                      normal_battery_TextCircle[index].setProperty(hmUI.prop.VISIBLE, true);
                      char_Angle -= normal_battery_TextCircle_img_angle;
                      index++;
                    };  // end if digit
                  };  // end char of string
                  char_Angle -= normal_battery_TextCircle_unit_angle;
                  normal_battery_TextCircle_unit.setProperty(hmUI.prop.ANGLE, char_Angle);
                  normal_battery_TextCircle_unit.setProperty(hmUI.prop.VISIBLE, true);
                }  // end isFinite

              };

              console.log('update text circle calorie_CALORIE');
              let idle_calorie_circle_string = parseInt(valueCalories).toString();

              if (screenType == hmSetting.screen_type.AOD) {
                for (var i = 1; i < 4; i++) {  // hide all symbols
                  idle_calorie_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                let char_Angle = 291;
                if (valueCalories != null && valueCalories != undefined && isFinite(valueCalories) && idle_calorie_circle_string.length > 0 && idle_calorie_circle_string.length < 6) {  // display data if it was possible to get it
                  let idle_calorie_TextCircle_img_angle = 0;
                  let idle_calorie_TextCircle_dot_img_angle = 0;
                  idle_calorie_TextCircle_img_angle = toDegree(Math.atan2(idle_calorie_TextCircle_img_width/2, 217));
                  
                  let firstSymbol = true;
                  let index = 0;
                  for (let char of idle_calorie_circle_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 4) break;
                    if (charCode >= 0 && charCode < 10) { 
                      if (!firstSymbol) char_Angle -= idle_calorie_TextCircle_img_angle;
                      firstSymbol = false;
                      idle_calorie_TextCircle[index].setProperty(hmUI.prop.ANGLE, char_Angle);
                      idle_calorie_TextCircle[index].setProperty(hmUI.prop.POS_X, 233 - idle_calorie_TextCircle_img_width / 2);
                      idle_calorie_TextCircle[index].setProperty(hmUI.prop.SRC, idle_calorie_TextCircle_ASCIIARRAY[charCode]);
                      idle_calorie_TextCircle[index].setProperty(hmUI.prop.VISIBLE, true);
                      char_Angle -= idle_calorie_TextCircle_img_angle;
                      index++;
                    };  // end if digit
                  };  // end char of string
                }  // end isFinite

              };

              console.log('update text circle DISTANCE');
              let idle_distance_circle_string = (distanceCurrent / 1000).toFixed(2);

              if (screenType == hmSetting.screen_type.AOD) {
                for (var i = 1; i < 5; i++) {  // hide all symbols
                  idle_distance_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                let char_Angle = -46;
                if (distanceCurrent != null && distanceCurrent != undefined && isFinite(distanceCurrent) && idle_distance_circle_string.length > 0 && idle_distance_circle_string.length < 6) {  // display data if it was possible to get it
                  let idle_distance_TextCircle_img_angle = 0;
                  let idle_distance_TextCircle_dot_img_angle = 0;
                  idle_distance_TextCircle_img_angle = toDegree(Math.atan2(idle_distance_TextCircle_img_width/2, 203));
                  idle_distance_TextCircle_dot_img_angle = toDegree(Math.atan2(idle_distance_TextCircle_dot_width/2, 203));
                  // alignment = CENTER_H
                  let idle_distance_TextCircle_angleOffset = idle_distance_TextCircle_img_angle * (idle_distance_circle_string.length - 1);
                  idle_distance_TextCircle_angleOffset = idle_distance_TextCircle_angleOffset - idle_distance_TextCircle_img_angle + idle_distance_TextCircle_dot_img_angle;
                  char_Angle -= idle_distance_TextCircle_angleOffset;
                  // alignment end
                  
                  let firstSymbol = true;
                  let index = 0;
                  for (let char of idle_distance_circle_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 5) break;
                    if (charCode >= 0 && charCode < 10) { 
                      if (!firstSymbol) char_Angle += idle_distance_TextCircle_img_angle;
                      firstSymbol = false;
                      idle_distance_TextCircle[index].setProperty(hmUI.prop.ANGLE, char_Angle);
                      idle_distance_TextCircle[index].setProperty(hmUI.prop.POS_X, 233 - idle_distance_TextCircle_img_width / 2);
                      idle_distance_TextCircle[index].setProperty(hmUI.prop.SRC, idle_distance_TextCircle_ASCIIARRAY[charCode]);
                      idle_distance_TextCircle[index].setProperty(hmUI.prop.VISIBLE, true);
                      char_Angle += idle_distance_TextCircle_img_angle;
                      index++;
                    }  // end if digit
                    else { 
                      if (!firstSymbol) char_Angle += idle_distance_TextCircle_dot_img_angle; 
                      firstSymbol = false;
                      idle_distance_TextCircle[index].setProperty(hmUI.prop.ANGLE, char_Angle);
                      idle_distance_TextCircle[index].setProperty(hmUI.prop.POS_X, 233 - idle_distance_TextCircle_dot_width / 2);
                      idle_distance_TextCircle[index].setProperty(hmUI.prop.SRC, 'Zpt.png');
                      idle_distance_TextCircle[index].setProperty(hmUI.prop.VISIBLE, true);
                      char_Angle += idle_distance_TextCircle_dot_img_angle;
                      index++;
                    };  // end if dot point 
                  };  // end char of string
                }  // end isFinite
                else {
                  idle_distance_TextCircle[0].setProperty(hmUI.prop.ANGLE, char_Angle);
                  idle_distance_TextCircle[0].setProperty(hmUI.prop.POS_X, 233 - idle_distance_TextCircle_error_img_width / 2);
                  idle_distance_TextCircle[0].setProperty(hmUI.prop.SRC, 'Error.png');
                  idle_distance_TextCircle[0].setProperty(hmUI.prop.VISIBLE, true);
                };  // end else isFinite

              };

              console.log('update text circle step_STEP');
              let idle_step_circle_string = parseInt(valueStep).toString();

              if (screenType == hmSetting.screen_type.AOD) {
                for (var i = 1; i < 5; i++) {  // hide all symbols
                  idle_step_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                let char_Angle = 72;
                if (valueStep != null && valueStep != undefined && isFinite(valueStep) && idle_step_circle_string.length > 0 && idle_step_circle_string.length < 6) {  // display data if it was possible to get it
                  let idle_step_TextCircle_img_angle = 0;
                  let idle_step_TextCircle_dot_img_angle = 0;
                  idle_step_TextCircle_img_angle = toDegree(Math.atan2(idle_step_TextCircle_img_width/2, 202));
                  // alignment = CENTER_H
                  let idle_step_TextCircle_angleOffset = idle_step_TextCircle_img_angle * (idle_step_circle_string.length - 1);
                  char_Angle -= idle_step_TextCircle_angleOffset;
                  // alignment end
                  
                  let firstSymbol = true;
                  let index = 0;
                  for (let char of idle_step_circle_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 5) break;
                    if (charCode >= 0 && charCode < 10) { 
                      if (!firstSymbol) char_Angle += idle_step_TextCircle_img_angle;
                      firstSymbol = false;
                      idle_step_TextCircle[index].setProperty(hmUI.prop.ANGLE, char_Angle);
                      idle_step_TextCircle[index].setProperty(hmUI.prop.POS_X, 233 - idle_step_TextCircle_img_width / 2);
                      idle_step_TextCircle[index].setProperty(hmUI.prop.SRC, idle_step_TextCircle_ASCIIARRAY[charCode]);
                      idle_step_TextCircle[index].setProperty(hmUI.prop.VISIBLE, true);
                      char_Angle += idle_step_TextCircle_img_angle;
                      index++;
                    };  // end if digit
                  };  // end char of string
                }  // end isFinite
                else {
                  idle_step_TextCircle[0].setProperty(hmUI.prop.ANGLE, char_Angle);
                  idle_step_TextCircle[0].setProperty(hmUI.prop.POS_X, 233 - idle_step_TextCircle_error_img_width / 2);
                  idle_step_TextCircle[0].setProperty(hmUI.prop.SRC, 'Error.png');
                  idle_step_TextCircle[0].setProperty(hmUI.prop.VISIBLE, true);
                };  // end else isFinite

              };

              console.log('update text circle battery_BATTERY');
              let idle_battery_circle_string = parseInt(valueBattery).toString();

              if (screenType == hmSetting.screen_type.AOD) {
                for (var i = 1; i < 3; i++) {  // hide all symbols
                  idle_battery_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                idle_battery_TextCircle_unit.setProperty(hmUI.prop.VISIBLE, false);
                let char_Angle = 345;
                if (valueBattery != null && valueBattery != undefined && isFinite(valueBattery) && idle_battery_circle_string.length > 0 && idle_battery_circle_string.length < 6) {  // display data if it was possible to get it
                  let idle_battery_TextCircle_img_angle = 0;
                  let idle_battery_TextCircle_dot_img_angle = 0;
                  let idle_battery_TextCircle_unit_angle = 0;
                  idle_battery_TextCircle_img_angle = toDegree(Math.atan2(idle_battery_TextCircle_img_width/2, 234));
                  idle_battery_TextCircle_unit_angle = toDegree(Math.atan2(idle_battery_TextCircle_unit_width/2, 234));
                  // alignment = CENTER_H
                  let idle_battery_TextCircle_angleOffset = idle_battery_TextCircle_img_angle * (idle_battery_circle_string.length - 1);
                  idle_battery_TextCircle_angleOffset = idle_battery_TextCircle_angleOffset + (idle_battery_TextCircle_img_angle + idle_battery_TextCircle_unit_angle + 0) / 2;
                  idle_battery_TextCircle_angleOffset = -idle_battery_TextCircle_angleOffset;
                  char_Angle -= idle_battery_TextCircle_angleOffset;
                  // alignment end
                  
                  let firstSymbol = true;
                  let index = 0;
                  for (let char of idle_battery_circle_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 3) break;
                    if (charCode >= 0 && charCode < 10) { 
                      if (!firstSymbol) char_Angle -= idle_battery_TextCircle_img_angle;
                      firstSymbol = false;
                      idle_battery_TextCircle[index].setProperty(hmUI.prop.ANGLE, char_Angle);
                      idle_battery_TextCircle[index].setProperty(hmUI.prop.POS_X, 233 - idle_battery_TextCircle_img_width / 2);
                      idle_battery_TextCircle[index].setProperty(hmUI.prop.SRC, idle_battery_TextCircle_ASCIIARRAY[charCode]);
                      idle_battery_TextCircle[index].setProperty(hmUI.prop.VISIBLE, true);
                      char_Angle -= idle_battery_TextCircle_img_angle;
                      index++;
                    };  // end if digit
                  };  // end char of string
                  char_Angle -= idle_battery_TextCircle_unit_angle;
                  idle_battery_TextCircle_unit.setProperty(hmUI.prop.ANGLE, char_Angle);
                  idle_battery_TextCircle_unit.setProperty(hmUI.prop.VISIBLE, true);
                }  // end isFinite

              };

            };

            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                console.log('resume_call()');
                text_update();
              }),
            });

                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}