﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v1.0.1
    ** Copyright Â© CashaCX75. All Rights Reserved
	Index.js aditional scripts and design by MagoNegro SEP-2022
	Glashutte Tourbillon senator edition by Glashutte Inc.
    */

    try {

      (() => {

        var __$$app$$__ = __$$hmAppManager$$__.currentApp;
        var __$$module$$__ = __$$app$$__.current;
        //drink is a name,can modify
        var h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__), 'drink');

        'use strict';

        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_date_img_date_day = ''
        let normal_analog_clock_time_pointer_hour = ''
        let normal_analog_clock_time_pointer_minute = ''
        let normal_analog_clock_time_pointer_second = ''
        let idle_background_bg_img = ''
        let idle_date_img_date_day = ''
        let idle_analog_clock_time_pointer_hour = ''
        let idle_analog_clock_time_pointer_minute = ''
        let idle_analog_clock_time_pointer_second = ''


        //dynamic modify end

        //not required
        const logger = DeviceRuntimeCore.HmLogger.getLogger("yeguang");

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({

          init_view() {

            //dynamic modify start
                    
            
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 466,
              h: 466,
              src: 'Background.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

	let screenType = hmSetting.getScreenType();
            // animate
            if (screenType != hmSetting.screen_type.AOD) {
				   let animate = hmUI.createWidget(hmUI.widget.IMG_ANIM, {
						x: 156,
						y: 270,
						anim_path: "",
						anim_prefix: "F",
						anim_ext: "png",
						anim_fps: 60,
						anim_size: 22,
						anim_repeat: true,
						repeat_count: 0,
						anim_status: hmUI.anim_status.START,
						display_on_restart: false,
				   });
				}

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 207,
              day_startY: 116,
              day_sc_array: ["Num0.png","Num1.png","Num2.png","Num3.png","Num4.png","Num5.png","Num6.png","Num7.png","Num8.png","Num9.png"],
              day_tc_array: ["Num0.png","Num1.png","Num2.png","Num3.png","Num4.png","Num5.png","Num6.png","Num7.png","Num8.png","Num9.png"],
              day_en_array: ["Num0.png","Num1.png","Num2.png","Num3.png","Num4.png","Num5.png","Num6.png","Num7.png","Num8.png","Num9.png"],
              day_zero: 1,
              day_space: 3,
              day_align: hmUI.align.LEFT,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_second = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              second_path: 'seconds.png',
              second_centerX: 233,
              second_centerY: 347,
              second_posX: 101,
              second_posY: 101,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_hour = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              hour_path: 'hour.png',
              hour_centerX: 233,
              hour_centerY: 233,
              hour_posX: 17,
              hour_posY: 155,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_minute = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              minute_path: 'minute.png',
              minute_centerX: 233,
              minute_centerY: 233,
              minute_posX: 21,
              minute_posY: 225,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            idle_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 466,
              h: 466,
              src: 'BackAOD.png',
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 207,
              day_startY: 116,
              day_sc_array: ["Num0.png","Num1.png","Num2.png","Num3.png","Num4.png","Num5.png","Num6.png","Num7.png","Num8.png","Num9.png"],
              day_tc_array: ["Num0.png","Num1.png","Num2.png","Num3.png","Num4.png","Num5.png","Num6.png","Num7.png","Num8.png","Num9.png"],
              day_en_array: ["Num0.png","Num1.png","Num2.png","Num3.png","Num4.png","Num5.png","Num6.png","Num7.png","Num8.png","Num9.png"],
              day_zero: 1,
              day_space: 3,
              day_align: hmUI.align.LEFT,
              day_is_character: false,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_analog_clock_time_pointer_second = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              second_path: 'seconds.png',
              second_centerX: 233,
              second_centerY: 347,
              second_posX: 101,
              second_posY: 101,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_analog_clock_time_pointer_hour = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              hour_path: 'hour.png',
              hour_centerX: 233,
              hour_centerY: 233,
              hour_posX: 17,
              hour_posY: 155,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_analog_clock_time_pointer_minute = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              minute_path: 'minute.png',
              minute_centerX: 233,
              minute_centerY: 233,
              minute_posX: 21,
              minute_posY: 225,
              show_level: hmUI.show_level.ONAL_AOD,
            });



            //dynamic modify end
          },

          onInit() {
            console.log('index page.js on init invoke')

            this.init_view()

          },

          onReady() {
            console.log('index page.js on ready invoke')
          },

          onShow() {
            console.log('index page.js on show invoke')
          },

          onHide() {
            console.log('index page.js on hide invoke')
          },

          onDestory() {
            console.log('index page.js on destory invoke')
          },
        });

      })()
    } catch (e) {
      console.log(e)
    }
  