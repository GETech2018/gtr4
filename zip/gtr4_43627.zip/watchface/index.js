﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        //const logger = Logger.getLogger('watchface_SashaCX75');
        const logger = DeviceRuntimeCore.HmLogger.getLogger('watchface_SashaCX75')
        //end of ignored block

        //dynamic modify start

        
        console.log('user_functions.js');
        // start user_functions.js

//      let normal_SUN_CURRENT_PROGRESS = '';
     let normal_weather_text_font = '';
      let idle_weather_text_font = '';
//      let normal_min_text_font = '';
//      let normal_temp_text_font = '';
//      let normal_press_text_font = '';
//      let normal_second_pointer = '';
//      

      let weather = hmSensor.createSensor(hmSensor.id.WEATHER);
   const baro = hmSensor.createSensor(hmSensor.id.BARO);
    const pressureValue = baro.pressure;
   // const altitudeValue = baro.altitude;  
   
   

 
     let tap_left = '';
      function clik_tap_left() {
 tap_left = (tap_left + 1)%2 
		  
 normal_system_disconnect_img.setProperty(hmUI.prop.SRC, tap_left == 0 ? 'stat_BT_b.png':'stat_BT_w.png');	
		  
normal_system_lock_img_b.setProperty(hmUI.prop.VISIBLE, tap_left == 0); 
normal_system_lock_img_w.setProperty(hmUI.prop.VISIBLE, tap_left == 1);  

normal_background_bg_img.setProperty(hmUI.prop.SRC, tap_left == 0 ? 'bg_b24.png':'bg_w24.png');
normal_month_name_font.setProperty(hmUI.prop.COLOR, tap_left == 0 ? 0xffffff:0x000000);
normal_weather_text_font.setProperty(hmUI.prop.COLOR, tap_left == 0 ? 0xffffff:0x000000);
 }
 
     let tap_midl = '';
      function clik_tap_midl() {
 tap_midl = (tap_midl + 1)%2     

normal_analog_clock_time_pointer_hour.setProperty(hmUI.prop.VISIBLE, tap_midl == 0);
normal_analog_clock_time_pointer_minute.setProperty(hmUI.prop.VISIBLE, tap_midl == 0);
normal_analog_clock_time_pointer_second.setProperty(hmUI.prop.VISIBLE, tap_midl == 0);


 }
   

      let weatherData = weather.getForecastWeather();
      let sunData = weatherData.tideData;
      let today = '';
      let sunriseMins = '';
      let sunsetMins = '';
      let sunriseMins_def = 8 * 60; // время восхода
      let sunsetMins_def = 20 * 60; // и заката по умолчанию
      let curMins = '';
      let idle_SUN_CURRENT_PROGRESS = '';
      let isDayIcons = true;

      const screenType = hmSetting.getScreenType();

      function autoToggleWeatherIcons() {
        if (!timeSensor) timeSensor = hmSensor.createSensor(hmSensor.id.TIME);
		  

       weatherData = weather.getForecastWeather();
       sunData = weatherData.tideData;
       if (sunData.count > 0) {
        today = sunData.data[0];
        sunriseMins = today.sunrise.hour * 60 + today.sunrise.minute;
        sunsetMins = today.sunset.hour * 60 + today.sunset.minute;
       } else {
        sunriseMins = sunriseMins_def;
        sunsetMins = sunsetMins_def;
       }

       curMins = timeSensor.hour * 60 + timeSensor.minute;
       let isDayNow = (curMins >= sunriseMins) && (curMins < sunsetMins);

       if (isDayNow) {
        if (!isDayIcons) {
         isDayIcons = true;
        }
       } else {
        if (isDayIcons) {
         isDayIcons = false;
        }

       }

//       normal_sun_low_text_font.setProperty(hmUI.prop.VISIBLE, isDayIcons);
//       normal_sun_high_text_font.setProperty(hmUI.prop.VISIBLE, !isDayIcons);


       let sunAngle;
       if (isDayNow) {
        // Расчет для дня
        sunAngle = 90 + 180 * (curMins - sunriseMins) / (sunsetMins - sunriseMins);
       } else {
        // Расчет для ночи
        const nightDuration = (24 * 60 - sunsetMins) + sunriseMins;
        let timeFromSunset;

        if (curMins >= sunsetMins) {
         // После заката до полуночи
         timeFromSunset = curMins - sunsetMins;
        } else {
         // После полуночи до восхода
         timeFromSunset = (24 * 60 - sunsetMins) + curMins;
        }
        sunAngle = 270 + 180 * (timeFromSunset / nightDuration);
       }
		  
       shotWeaterhNames = isDayIcons == false ? ["Облачно ночью", "Местами дождь", "Местами снег", "Ясно ночью", "Пасмурно ночью", "Слабый дождь", "Слабый снег", "Умеренный дождь", "Умеренный снег", "Сильный снегопад", "Сильный дождь", "Песчаная буря", "Мокрый снег", "Туман", "Дымка", "Дождь с грозой", "Метель", "Пыльно", "Ливень", "Дождь с градом", "Сильный дождь с градом", "Сильный дождь ", "Песчаная буря", "Сильная песчаная буря", "Сильный дождь", "Неизвестная погода", "Облачно ночью", "Дождливо ночью", "Ясно ночью"] : ["Облачно", "Местами дождь", "Местами снег", "Cолнечно", "Пасмурно", "Слабый дождь", "Слабый снег", "Умеренный дождь", "Умеренный снег", "Сильный снегопад", "Сильный дождь", "Песчаная буря", "Мокрый снег", "Туман", "Дымка", "Дождь с грозой", "Метель", "Пыльно", "Ливень", "Дождь с градом", "Сильный дождь с градом", "Сильный дождь ", "Песчаная буря", "Сильная песчаная буря ", "Сильный дождь", "Неизвестная погода", "Облачно ночью", "Дождливо ночью", "Ясно ночью"];		  
		  
       let curAirIconIndex = weather.curAirIconIndex;

     //  normal_SUN_CURRENT_PROGRESS.setProperty(hmUI.prop.ANGLE, sunAngle);
       normal_weather_text_font.setProperty(hmUI.prop.TEXT, shotWeaterhNames[curAirIconIndex].toUpperCase());
       idle_weather_text_font.setProperty(hmUI.prop.TEXT, shotWeaterhNames[curAirIconIndex].toUpperCase());		  
/*       if (screenType == hmSetting.screen_type.AOD) {
        idle_SUN_CURRENT_PROGRESS.setProperty(hmUI.prop.ANGLE, sunAngle);
        idle_sun_low_text_font.setProperty(hmUI.prop.VISIBLE, isDayIcons);
        idle_sun_high_text_font.setProperty(hmUI.prop.VISIBLE, !isDayIcons);
       }; // end screenType*/
      }
      
            const vibrate = hmSensor.createSensor(hmSensor.id.VIBRATE);
            let timer_StopVibrate = null;


            function vibro(scene = 25) {
              let stopDelay = 50;
              stopVibro();
              vibrate.stop();
              vibrate.scene = scene;
              if(scene < 23 || scene > 25) stopDelay = 1300;
              vibrate.start();
              timer_StopVibrate = timer.createTimer(stopDelay, 3000, stopVibro, {});
            }

            function stopVibro(){
              vibrate.stop();
              if(timer_StopVibrate) timer.stopTimer(timer_StopVibrate);
            }      
        // end user_functions.js

        let normal_background_bg_img = ''
        let normal_battery_pointer_progress_img_pointer = ''
        let normal_step_pointer_progress_img_pointer = ''
        let normal_week_pointer_progress_date_pointer = ''
        let normal_month_name_font = ''
        let normal_Month_Array = ['ЯНВАРЬ', 'ФЕВРАЛЬ', 'МАРТ', 'АПРЕЛЬ', 'МАЙ', 'ИЮНЬ', 'ИЮЛЬ', 'АВГУСТ', 'СЕНТЯБРЬ', 'ОКТЯБРЬ', 'НОЯБРЬ', 'ДЕКАБРЬ', ];
        
        let idle_Month_Array = ['ЯНВ', 'ФЕВ', 'МАР', 'АПР', 'МАЙ', 'ИЮН', 'ИЮЛ', 'АВГ', 'СЕН', 'ОКТ', 'НОЯ', 'ДЕК', ];        
        
        let normal_DOW_Array = ['ПНД', 'ВТР', 'СРД', 'ЧТВ', 'ПТН', 'СБТ', 'ВСК'];
        let normal_day_text_font = ''
        let normal_time_hour_text_font = ''
        let normal_timerTimeUpdate = undefined;
        let normal_time_minute_text_font = ''
        let normal_analog_clock_time_pointer_hour = ''
        let normal_analog_clock_time_pointer_minute = ''
        let normal_analog_clock_time_pointer_second = ''
        let idle_background_bg_img = ''
        let idle_day_text_font = ''
        let idle_digital_clock_img_time_hour = ''
        let idle_analog_clock_time_pointer_hour = ''
        let idle_analog_clock_time_pointer_minute = ''
        let Button_1 = ''
        let Button_2 = ''
        let Button_3 = ''
        let Button_4 = ''
        let Button_5 = ''
        let Button_6 = ''
        let normal_system_disconnect_img = ''
        let normal_system_lock_img_b = ''
        let normal_system_lock_img_w = ''
        let timeSensor = '';


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            // FontName: ArtegraSans-Medium.ttf; FontSize: 27; Cache: full
            hmUI.createWidget(hmUI.widget.TEXT, {
              x: 464,
              y: 464,
              w: 32,
              h: 32,
              text_size: 27,
              char_space: 0,
              line_space: 0,
              font: 'fonts/ArtegraSans-Medium.ttf',
              color: 0xFFFFFFFF,
              align_h: hmUI.align.LEFT,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.NONE,
              text: "0123456789 ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz АБВГДЕЁЖЗИЙКЛМНОПРСТУФХЦЧШЩЪЫЬЭЮЯабвгдеёжзийклмнопрстуфхцчшщъыьэюя  ҐЄІЇґєії _-.,:;`'%°\\/",
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // FontName: BebasNeue Bold.ttf; FontSize: 46
            hmUI.createWidget(hmUI.widget.TEXT, {
              x: 464,
              y: 464,
              w: 474,
              h: 66,
              text_size: 46,
              char_space: 0,
              line_space: 0,
              font: 'fonts/BebasNeue Bold.ttf',
              color: 0xFFFFFFFF,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              text: "0123456789 _-.,:;`'%°\\/",
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            console.log('user_script_start.js');
            // start user_script_start.js

   hmUI.createWidget(hmUI.widget.TEXT, {
            x: 464,
            y: 464,
            w: 22,
            h: 50,
            text_size: 17,
            char_space: 0,
            line_space: 0,
    font: 'fonts/ArtegraSans-Medium.ttf',
            color: 0xFFFFFFFF,
            align_h: hmUI.align.CENTER_H,
            align_v: hmUI.align.CENTER_V,
            text_style: hmUI.text_style.NONE,
            text: "0123456789 ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz АБВГДЕЁЖЗИЙКЛМНОПРСТУФХЦЧШЩЪЫЬЭЮЯабвгдеёжзийклмнопрстуфхцчшщъыьэюя  ҐЄІЇґєії _-.,:;`'%°\\/",
            show_level: hmUI.show_level.ONLY_NORMAL,
        });
        
            // end user_script_start.js

            console.log('Watch_Face.ScreenNormal');
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 466,
              h: 466,
              src: 'bg_b24.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_pointer_progress_img_pointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
              src: '0041.png',
              center_x: 133,
              center_y: 233,
              x: 11,
              y: 34,
              start_angle: 0,
              end_angle: 360,
              invalid_visible: false,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_pointer_progress_img_pointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
              src: '0041.png',
              center_x: 233,
              center_y: 333,
              x: 11,
              y: 34,
              start_angle: 0,
              end_angle: 360,
              invalid_visible: false,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_week_pointer_progress_date_pointer = hmUI.createWidget(hmUI.widget.DATE_POINTER, {
              src: '0041.png',
              center_x: 333,
              center_y: 233,
              posX: 11,
              posY: 37,
              start_angle: -52,
              end_angle: 308,
              type: hmUI.date.WEEK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            if (!timeSensor) timeSensor = hmSensor.createSensor(hmSensor.id.TIME);
            timeSensor.addEventListener(timeSensor.event.DAYCHANGE, function() {
              time_update(true);
            });

            normal_month_name_font = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 108,
              y: 85,
              w: 250,
              h: 40,
              text_size: 27,
              char_space: 0,
              line_space: 0,
              font: 'fonts/ArtegraSans-Medium.ttf',
              color: 0xFFFFFFFF,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              // unit_string: ЯНВАРЬ, ФЕВРАЛЬ, МАРТ, АПРЕЛЬ, МАЙ, ИЮНЬ, ИЮЛЬ, АВГУСТ, СЕНТЯБРЬ, ОКТЯБРЬ, НОЯБРЬ, ДЕКАБРЬ,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_day_text_font = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 0,
              y: 141,
              w: 466,
              h: 70,
              text_size: 46,
              char_space: 0,
              line_space: 0,
              font: 'fonts/BebasNeue Bold.ttf',
              color: 0xFFFFFFFF,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            console.log('user_script.js');
            // start user_script.js
normal_weather_text_font = hmUI.createWidget(hmUI.widget.TEXT, {
    x: 107,
    y: 103,
    w: 252,
    h: 50,
    text_size: 17,
    char_space: 3,
    line_space: 0,
    font: 'fonts/ArtegraSans-Medium.ttf',
    color: 0xFFFFFF,
    align_h: hmUI.align.CENTER_H,
    align_v: hmUI.align.CENTER_V,
    text_style: hmUI.text_style.NONE,
    show_level: hmUI.show_level.ONLY_NORMAL,
})


            // end user_script.js

            let screenType = hmSetting.getScreenType();
            normal_time_hour_text_font = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 89-3,
              y: 296,
              w: 100,
              h: 70,
              text_size: 46,
              char_space: 0,
              line_space: 0,
              font: 'fonts/BebasNeue Bold.ttf',
              color: 0xFFFFFFFF,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              // padding: true,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_time_minute_text_font = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 279,
              y: 296,
              w: 100,
              h: 70,
              text_size: 46,
              char_space: 0,
              line_space: 0,
              font: 'fonts/BebasNeue Bold.ttf',
              color: 0xFFFFFFFF,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              // padding: true,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_hour = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              hour_path: '0042.png',
              hour_centerX: 233,
              hour_centerY: 233,
              hour_posX: 21,
              hour_posY: 139,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
				
            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 168,
              y: 149,
              src: tap_left == 0 ? 'stat_BT_b.png':'stat_BT_w.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            normal_system_disconnect_img.setProperty(hmUI.prop.VISIBLE, hmBle.connectStatus());

            normal_system_lock_img_b = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 276,
              y: 149,
              src: 'stat_AL_b.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
				
            normal_system_lock_img_w = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 276,
              y: 149,
              src: 'stat_AL_w.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
				
normal_system_lock_img_b.setProperty(hmUI.prop.VISIBLE, tap_left == 0); 
normal_system_lock_img_w.setProperty(hmUI.prop.VISIBLE, tap_left == 1);  
				
				normal_analog_clock_time_pointer_minute = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              minute_path: '0043.png',
              minute_centerX: 233,
              minute_centerY: 233,
              minute_posX: 16,
              minute_posY: 204,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_second = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              second_path: '0037.png',
              second_centerX: 233,
              second_centerY: 233,
              second_posX: 14,
              second_posY: 221,
         fresh_frequency: 25,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            console.log('Watch_Face.ScreenAOD');
            idle_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 466,
              h: 466,
              src: 'bg_aod_24.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_day_text_font = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 0,
              y: 297,
              w: 466,
              h: 70,
              text_size: 46,
              char_space: 0,
              line_space: 0,
              font: 'fonts/BebasNeue Bold.ttf',
              color: 0xFFFFFFFF,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              show_level: hmUI.show_level.ONLY_AOD,
            });
				
idle_weather_text_font = hmUI.createWidget(hmUI.widget.TEXT, {
    x: 107,
    y: 103,
    w: 252,
    h: 50,
    text_size: 17,
    char_space: 3,
    line_space: 0,
    font: 'fonts/ArtegraSans-Medium.ttf',
    color: 0xFFFFFF,
    align_h: hmUI.align.CENTER_H,
    align_v: hmUI.align.CENTER_V,
    text_style: hmUI.text_style.NONE,
    show_level: hmUI.show_level.ONLY_AOD,
})				
				

            idle_digital_clock_img_time_hour = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 216,
              hour_startY: 157,
              hour_array: ["D_aod_0.png","D_aod_1.png","D_aod_2.png","D_aod_3.png","D_aod_4.png","D_aod_5.png","D_aod_6.png","D_aod_7.png","D_aod_8.png","D_aod_9.png"],
              hour_zero: 1,
              hour_space: 0,
              hour_angle: 0,
              hour_align: hmUI.align.CENTER_H,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_analog_clock_time_pointer_hour = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              hour_path: 's_aod_1.png',
              hour_centerX: 233,
              hour_centerY: 233,
              hour_posX: 16,
              hour_posY: 135,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_analog_clock_time_pointer_minute = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              minute_path: 's_aod_2.png',
              minute_centerX: 233,
              minute_centerY: 233,
              minute_posX: 12,
              minute_posY: 199,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            console.log('user_script_beforeShortcuts.js');
            // start user_script_beforeShortcuts.js

/*            normal_second_pointer = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 467,
              h: 467,
              pos_x: 210,
              pos_y: -1,
              center_x: 233,
              center_y: 233,
              angle: 0,
              src: 'str_S.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });*/
            // end user_script_beforeShortcuts.js

            console.log('Watch_Face.Buttons');
            Button_1 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 0,
              y: 183,
              w: 100,
              h: 100,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '0.png',
              normal_src: '0.png',
              click_func: (button_widget) => {
                clik_tap_left();
vibro(28);
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_2 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 183,
              y: 183,
              w: 100,
              h: 100,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '0.png',
              normal_src: '0.png',
              click_func: (button_widget) => {
                clik_tap_midl();
vibro(28);
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button
				
            Button_3 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 183,
              y: 76,
              w: 100,
              h: 100,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '0.png',
              normal_src: '0.png',
              click_func: (button_widget) => {
                hmApp.startApp({ appid: 1051195, url: 'page/index', params: { from_wf: true} });
vibro(28);
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_4 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 284,
              y: 183,
              w: 100,
              h: 100,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '0.png',
              normal_src: '0.png',
              click_func: (button_widget) => {
                 hmApp.startApp({ appid: 1057409, url: 'page/index', params: { from_wf: true} });
vibro(28);
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_5 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 50,
              y: 47,
              w: 100,
              h: 100,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '0.png',
              normal_src: '0.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'AlarmInfoScreen', native: true });
vibro(28);
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_6 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 318,
              y: 47,
              w: 100,
              h: 100,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '0.png',
              normal_src: '0.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'CountdownAppScreen', native: true });
vibro(28);
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button
				
				

            //#region time_update
            function time_update(updateHour = false, updateMinute = false) {
              console.log('time_update()');
              let hour = timeSensor.hour;
              let minute = timeSensor.minute;
              let second = timeSensor.second;
              let format_hour = timeSensor.format_hour;
              
         const timeFormat = hmSetting.getTimeFormat()
		 
 normal_system_disconnect_img.setProperty(hmUI.prop.SRC, tap_left == 0 ? 'stat_BT_b.png':'stat_BT_w.png');	
				
normal_system_disconnect_img.setProperty(hmUI.prop.VISIBLE, hmBle.connectStatus());
		 
		 
              
 normal_background_bg_img.setProperty(hmUI.prop.SRC, tap_left == 0 ? timeFormat !== 0 ? 'bg_b24.png' : 'bg_b12.png' : timeFormat !== 0 ? 'bg_w24.png' : 'bg_w12.png');
				
idle_background_bg_img.setProperty(hmUI.prop.SRC,  timeFormat !== 0 ? 'bg_aod_24.png' : 'bg_aod_12.png');				
 
            
              if (updateHour) {
                let normal_Month_Str = normal_Month_Array[timeSensor.month-1];
                normal_month_name_font.setProperty(hmUI.prop.TEXT, normal_Month_Str );
                
                let idle_Month_Str = idle_Month_Array[timeSensor.month-1];
                
                
                let idle_dayStr = timeSensor.day.toString();
                let idle_DOW_Str = normal_DOW_Array[timeSensor.week-1];
idle_day_text_font.setProperty(hmUI.prop.TEXT, idle_DOW_Str + " " + idle_dayStr + " " + idle_Month_Str); 

                let normal_dayStr = timeSensor.day.toString();
                normal_day_text_font.setProperty(hmUI.prop.TEXT, normal_dayStr );

                let normal_hourStr = format_hour.toString();
                normal_hourStr = normal_hourStr.padStart(2, '0');
                normal_time_hour_text_font.setProperty(hmUI.prop.TEXT, normal_hourStr );
              };

              console.log('minute font');
              if (updateMinute) {
                let normal_minuteStr = minute.toString();
                normal_minuteStr = normal_minuteStr.padStart(2, '0');
                normal_time_minute_text_font.setProperty(hmUI.prop.TEXT, normal_minuteStr );
              };


              

                
           

            };

            //#endregion
            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                console.log('resume_call()');
                time_update(true, true);
                if (screenType == hmSetting.screen_type.WATCHFACE) {
                  if (!normal_timerTimeUpdate) {
                    normal_timerTimeUpdate = timer.createTimer(0, 1000, (function (option) {
                      let updateHour = timeSensor.minute == 0 && timeSensor.second < 2;
                      let updateMinute = timeSensor.second < 2;
                      time_update(updateHour, updateMinute);
                    }));  // end timer 
                  };  // end timer check
                };  // end screenType


                console.log('resume_call.js');
                // start resume_call.js

          autoToggleWeatherIcons();
         // normal_press_text_font.setProperty(hmUI.prop.TEXT, Math.round(pressureValue * 0.750064).toString());

                // end resume_call.js

              }),
              pause_call: (function () {
                console.log('pause_call()');
                if (normal_timerTimeUpdate) {
                  timer.stopTimer(normal_timerTimeUpdate);
                  normal_timerTimeUpdate = undefined;
                }

              }),
            });

                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}