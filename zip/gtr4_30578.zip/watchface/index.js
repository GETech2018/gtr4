﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.0.1
    ** Copyright © CashaCX75. All Rights Reserved
    */

    try {
    (()=>{
        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_moon_image_progress_img_level = ''
        let normal_heart_rate_text_text_img = ''
        let normal_heart_rate_text_separator_img = ''
        let normal_temperature_current_text_img = ''
        let normal_weather_image_progress_img_level = ''
        let normal_date_img_date_week_img = ''
        let normal_date_img_date_month = ''
        let normal_date_img_date_day = ''
        let normal_date_day_separator_img = ''
        let normal_calorie_current_text_img = ''
        let normal_calorie_current_separator_img = ''
        let normal_calorie_image_progress_img_level = ''
        let normal_step_current_text_img = ''
        let normal_step_current_separator_img = ''
        let normal_step_image_progress_img_level = ''
        let normal_battery_text_text_img = ''
        let normal_battery_text_separator_img = ''
        let normal_battery_image_progress_img_level = ''
        let normal_system_disconnect_img = ''
        let normal_system_lock_img = ''
        let normal_system_dnd_img = ''
        let normal_system_clock_img = ''
        let normal_digital_clock_img_time_AmPm = ''
        let normal_digital_clock_img_time = ''
        let normal_digital_clock_hour_separator_img = ''
        let normal_analog_clock_time_pointer_second = ''
        let normal_sleep_jumpable_img_click = ''
        let normal_alarm_jumpable_img_click = ''
        let normal_temperature_jumpable_img_click = ''
        let normal_stress_jumpable_img_click = ''
        let normal_heart_jumpable_img_click = ''
        let normal_step_jumpable_img_click = ''
        let idle_date_img_date_week_img = ''
        let idle_date_img_date_month = ''
        let idle_date_img_date_day = ''
        let idle_date_day_separator_img = ''
        let idle_system_disconnect_img = ''
        let idle_system_lock_img = ''
        let idle_system_dnd_img = ''
        let idle_system_clock_img = ''
        let idle_digital_clock_img_time_AmPm = ''
        let idle_digital_clock_img_time = ''
        let idle_digital_clock_hour_separator_img = ''


        //dynamic modify end
        const e = __$$hmAppManager$$__.currentApp;
        const o = e.current
          , {px: i} = (new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(e,o)),
        e.__globals__)
          , n = Logger.getLogger("watchface6");
        o.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 466,
              h: 466,
              src: '2.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_moon_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 366,
              y: 318,
              image_array: ["Moon11.png","Moon12.png","Moon13.png","Moon14.png","Moon15.png","Moon16.png","Moon17.png","Moon18.png","Moon19.png","Moon20.png","Moon21.png","Moon22.png","Moon23.png","Moon24.png","Moon25.png","Moon26.png","Moon27.png","Moon28.png","Moon29.png","Moon30.png","Moon31.png","Moon32.png","Moon33.png","Moon34.png","Moon35.png","Moon36.png","Moon37.png","Moon38.png","Moon39.png","Moon40.png"],
              image_length: 30,
              type: hmUI.data_type.MOON,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 313,
              y: 384,
              font_array: ["175.png","176.png","177.png","178.png","179.png","180.png","181.png","182.png","183.png","184.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 311,
              y: 332,
              src: '188.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 348,
              y: 108,
              font_array: ["175.png","176.png","177.png","178.png","179.png","180.png","181.png","182.png","183.png","184.png"],
              padding: false,
              h_space: 0,
              unit_sc: '192.png',
              unit_tc: '192.png',
              unit_en: '192.png',
              negative_image: '191.png',
              invalid_image: '191.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 350,
              y: 63,
              image_array: ["w01.png","w02.png","w03.png","w04.png","w05.png","w06.png","w07.png","w08.png","w09.png","w10.png","w11.png","w12.png","w13.png","w14.png","w15.png","w16.png","w17.png","w18.png","w19.png","w20.png","w21.png","w22.png","w23.png","w24.png","w25.png","w26.png","w27.png","w28.png","w29.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 300,
              y: 278,
              week_en: ["233.png","234.png","235.png","236.png","237.png","238.png","239.png"],
              week_tc: ["233.png","234.png","235.png","236.png","237.png","238.png","239.png"],
              week_sc: ["233.png","234.png","235.png","236.png","237.png","238.png","239.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_month = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 243,
              month_startY: 279,
              month_sc_array: ["222.png","223.png","224.png","225.png","226.png","227.png","228.png","229.png","230.png","231.png"],
              month_tc_array: ["222.png","223.png","224.png","225.png","226.png","227.png","228.png","229.png","230.png","231.png"],
              month_en_array: ["222.png","223.png","224.png","225.png","226.png","227.png","228.png","229.png","230.png","231.png"],
              month_zero: 1,
              month_space: 0,
              month_align: hmUI.align.CENTER_H,
              month_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 189,
              day_startY: 279,
              day_sc_array: ["222.png","223.png","224.png","225.png","226.png","227.png","228.png","229.png","230.png","231.png"],
              day_tc_array: ["222.png","223.png","224.png","225.png","226.png","227.png","228.png","229.png","230.png","231.png"],
              day_en_array: ["222.png","223.png","224.png","225.png","226.png","227.png","228.png","229.png","230.png","231.png"],
              day_zero: 1,
              day_space: 0,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_day_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 231,
              y: 279,
              src: '232.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_calorie_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 261,
              y: 12,
              font_array: ["136.png","137.png","138.png","139.png","140.png","141.png","142.png","143.png","144.png","145.png"],
              padding: false,
              h_space: -1,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_calorie_current_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 255,
              y: 428,
              src: '162.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_calorie_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 0,
              y: 0,
              image_array: ["131.png","132.png","133.png","134.png","135.png"],
              image_length: 5,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 260,
              y: 59,
              font_array: ["78.png","79.png","80.png","81.png","82.png","83.png","84.png","85.png","86.png","87.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 257,
              y: 373,
              src: '186.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 47,
              y: 50,
              image_array: ["89.png","90.png","91.png","92.png","93.png"],
              image_length: 5,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 260,
              y: 106,
              font_array: ["24.png","25.png","26.png","27.png","28.png","29.png","30.png","31.png","32.png","33.png"],
              padding: false,
              h_space: 0,
              unit_sc: '47.png',
              unit_tc: '47.png',
              unit_en: '47.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 244,
              y: 325,
              src: '19.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 100,
              y: 100,
              image_array: ["35.png","36.png","37.png","38.png","39.png"],
              image_length: 5,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 356,
              y: 146,
              src: 'BT3.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_lock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 177,
              y: 144,
              src: 'candado.png',
              type: hmUI.system_status.LOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_dnd_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 312,
              y: 143,
              src: 'w29.png',
              type: hmUI.system_status.DISTURB,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 283,
              y: 147,
              src: 'ALAR.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time_AmPm = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              am_x: 395,
              am_y: 144,
              am_sc_path: '14.png',
              am_en_path: '14.png',
              pm_x: 395,
              pm_y: 144,
              pm_sc_path: '15.png',
              pm_en_path: '15.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 164,
              hour_startY: 180,
              hour_array: ["3.png","4.png","5.png","6.png","7.png","8.png","9.png","10.png","11.png","12.png"],
              hour_zero: 1,
              hour_space: 0,
              hour_align: hmUI.align.CENTER_H,

              minute_startX: 328,
              minute_startY: 180,
              minute_array: ["3.png","4.png","5.png","6.png","7.png","8.png","9.png","10.png","11.png","12.png"],
              minute_zero: 1,
              minute_space: 0,
              minute_follow: 0,
              minute_align: hmUI.align.CENTER_H,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_hour_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 294,
              y: 180,
              src: '13.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_second = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              second_path: 'Seg.png',
              second_centerX: 233,
              second_centerY: 233,
              second_posX: 44,
              second_posY: 232,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sleep_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 210,
              y: 140,
              w: 30,
              h: 40,
              src: 'transparent.png',
              type: hmUI.data_type.SLEEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_alarm_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 280,
              y: 137,
              w: 40,
              h: 40,
              src: 'transparent.png',
              type: hmUI.data_type.ALARM_CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 345,
              y: 53,
              w: 50,
              h: 90,
              src: 'transparent.png',
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_stress_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 247,
              y: 140,
              w: 30,
              h: 40,
              src: 'transparent.png',
              type: hmUI.data_type.STRESS,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 305,
              y: 331,
              w: 50,
              h: 100,
              src: 'transparent.png',
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 254,
              y: 46,
              w: 75,
              h: 50,
              src: 'transparent.png',
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });



            idle_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 296,
              y: 289,
              week_en: ["233.png","234.png","235.png","236.png","237.png","238.png","239.png"],
              week_tc: ["233.png","234.png","235.png","236.png","237.png","238.png","239.png"],
              week_sc: ["233.png","234.png","235.png","236.png","237.png","238.png","239.png"],
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_month = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 243,
              month_startY: 279,
              month_sc_array: ["222.png","223.png","224.png","225.png","226.png","227.png","228.png","229.png","230.png","231.png"],
              month_tc_array: ["222.png","223.png","224.png","225.png","226.png","227.png","228.png","229.png","230.png","231.png"],
              month_en_array: ["222.png","223.png","224.png","225.png","226.png","227.png","228.png","229.png","230.png","231.png"],
              month_zero: 1,
              month_space: 0,
              month_align: hmUI.align.CENTER_H,
              month_is_character: false,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 189,
              day_startY: 279,
              day_sc_array: ["222.png","223.png","224.png","225.png","226.png","227.png","228.png","229.png","230.png","231.png"],
              day_tc_array: ["222.png","223.png","224.png","225.png","226.png","227.png","228.png","229.png","230.png","231.png"],
              day_en_array: ["222.png","223.png","224.png","225.png","226.png","227.png","228.png","229.png","230.png","231.png"],
              day_zero: 1,
              day_space: 0,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_day_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 231,
              y: 279,
              src: '232.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 356,
              y: 146,
              src: 'BT3.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_system_lock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 239,
              y: 143,
              src: 'candado.png',
              type: hmUI.system_status.LOCK,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_system_dnd_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 312,
              y: 143,
              src: 'w29.png',
              type: hmUI.system_status.DISTURB,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 283,
              y: 147,
              src: 'ALAR.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time_AmPm = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              am_x: 395,
              am_y: 144,
              am_sc_path: '14.png',
              am_en_path: '14.png',
              pm_x: 395,
              pm_y: 144,
              pm_sc_path: '15.png',
              pm_en_path: '15.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 164,
              hour_startY: 180,
              hour_array: ["3.png","4.png","5.png","6.png","7.png","8.png","9.png","10.png","11.png","12.png"],
              hour_zero: 1,
              hour_space: 0,
              hour_align: hmUI.align.CENTER_H,

              minute_startX: 328,
              minute_startY: 180,
              minute_array: ["3.png","4.png","5.png","6.png","7.png","8.png","9.png","10.png","11.png","12.png"],
              minute_zero: 1,
              minute_space: 0,
              minute_follow: 0,
              minute_align: hmUI.align.CENTER_H,

              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_hour_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 294,
              y: 180,
              src: '13.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });


                //dynamic modify end
            },
            onInit() {
                n.log("index page.js on init invoke")
            },
            build() {
                this.init_view(),
                n.log("index page.js on ready invoke")
            },
            onDestroy() {
                n.log("index page.js on destroy invoke")
            }
        })
    }
    )()
} catch (e) {
    console.log("Mini Program Error", e),
    e && e.stack && e.stack.split(/\n/).forEach((e=>console.log("error stack", e)))
}
