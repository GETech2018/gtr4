﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        const logger = Logger.getLogger('watchface_SashaCX75');
        //end of ignored block

        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_system_dnd_img = ''
        let normal_system_disconnect_img = ''
        let normal_system_clock_img = ''
        let normal_date_img_date_week_img = ''
        let normal_date_img_date_day = ''
        let normal_temperature_current_text_img = ''
        let normal_weather_image_progress_img_level = ''
        let normal_heart_rate_text_text_img = ''
        let normal_altitude_text_text_img = ''
        let normal_altimeter_text_text_img = ''
        let normal_step_current_text_img = ''
        let normal_distance_text_text_img = ''
        let normal_calorie_current_text_img = ''
        let normal_vo2max_text_text_img = ''
        let normal_fat_burning_current_text_img = ''
        let normal_battery_text_text_img = ''
        let normal_battery_image_progress_img_level = ''
        let normal_digital_clock_img_time = ''
        let normal_digital_clock_hour_separator_img = ''
        let normal_analog_clock_time_pointer_hour = ''
        let normal_analog_clock_time_pointer_minute = ''
        let normal_analog_clock_time_pointer_second = ''
        let idle_background_bg = ''
        let idle_system_dnd_img = ''
        let idle_system_disconnect_img = ''
        let idle_system_clock_img = ''
        let idle_date_img_date_week_img = ''
        let idle_date_img_date_month_img = ''
        let idle_date_img_date_day = ''
        let idle_temperature_current_text_img = ''
        let idle_weather_image_progress_img_level = ''
        let idle_battery_text_text_img = ''
        let idle_battery_image_progress_img_level = ''
        let idle_digital_clock_img_time = ''
        let idle_digital_clock_hour_separator_img = ''
        let normal_stopwatch_jumpable_img_click = ''
        let normal_countdown_jumpable_img_click = ''
        let normal_sleep_jumpable_img_click = ''
        let normal_alarm_jumpable_img_click = ''
        let normal_sunrise_jumpable_img_click = ''
        let normal_altimeter_jumpable_img_click = ''
        let normal_temperature_jumpable_img_click = ''
        let normal_stress_jumpable_img_click = ''
        let normal_pai_jumpable_img_click = ''
        let normal_spo2_jumpable_img_click = ''
        let normal_heart_jumpable_img_click = ''
        let normal_step_jumpable_img_click = ''
		
		let heart = hmSensor.createSensor(hmSensor.id.HEART);
	    let heartArr = ''
	   
	    function HeartUpdate() {
		   heartArr = heart.today
		   min_heart_txt.setProperty(hmUI.prop.TEXT, Math.min(...heartArr).toString())
		   max_heart_txt.setProperty(hmUI.prop.TEXT, Math.max(...heartArr).toString())
	   }
	   
	   heart.addEventListener(hmSensor.event.CHANGE, function() { HeartUpdate() })
	   
	   let sleep_time_txt = ''
	   //let sleep_start_time_txt = ''
	   //let sleep_end_time_txt = ''
	   //let sleep_score_txt = ''
	   
	   const sleep = hmSensor.createSensor(hmSensor.id.SLEEP);
		let sleepInfo = sleep.getBasicInfo();
		
		let sleepTotalTime = sleep.getTotalTime();		
		let sleepStartTime = sleepInfo.startTime;
		let sleepEndTime = sleepInfo.endTime + 1;
		let sleepScore = sleepInfo.score;

		function updateSleepInfo() {
			sleepTotalTime = sleep.getTotalTime();
			sleepInfo = sleep.getBasicInfo();
			sleepStartTime = sleepInfo.startTime;
			if (sleepStartTime >= 24*60) {
				sleepStartTime -= 24*60
			}
			
			sleepEndTime = sleepInfo.endTime + 1;
			if (sleepEndTime >= 24*60) {
				sleepEndTime -= 24*60
			}

			sleep_time_txt.setProperty(hmUI.prop.TEXT, '' + Math.floor(sleepTotalTime / 60).toString().padStart(2, "0") + ':' + (sleepTotalTime % 60).toString().padStart(2, "0"));
			//sleep_start_time_txt.setProperty(hmUI.prop.TEXT, Math.floor(sleepStartTime / 60).toString().padStart(2, "0") + ':' + (sleepStartTime % 60).toString().padStart(2, "0"));
			//sleep_end_time_txt.setProperty(hmUI.prop.TEXT, Math.floor(sleepEndTime / 60).toString().padStart(2, "0") + ':' + (sleepEndTime % 60).toString().padStart(2, "0"));
			//sleep_score_txt.setProperty(hmUI.prop.TEXT, 'Очки: ' + String(sleepScore));
		}


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 466,
              h: 466,
              src: '3.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
			
			sleep_time_txt = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 220,
              y: 238,
			  w: 150,
			  h: 50,
			  text_size: 30,
			  text: '',
			  color: 0x000000,
              align_h: hmUI.align.LEFT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
			
			min_heart_txt = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 187,
              y: 330,
			  w: 50,
			  h: 50,
			  text_size: 24,
			  text: '',
			  color: 0x808080,
              align_h: hmUI.align.CENTR,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
			
			max_heart_txt = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 250,
              y: 330,
			  w: 50,
			  h: 50,
			  text_size: 24,
			  text: '',
			  color: 0x000000,
              align_h: hmUI.align.CENTR,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_dnd_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 365,
              y: 373,
              src: 'dnd_(2).png',
              type: hmUI.system_status.DISTURB,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 105,
              y: 88,
              src: 'BT_(2).png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 78,
              y: 373,
              src: 'clock_(2).png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 232,
              y: 21,
              week_en: ["day_1.png","day_2.png","day_3.png","day_4.png","day_5.png","day_6.png","day_7.png"],
              week_tc: ["day_1.png","day_2.png","day_3.png","day_4.png","day_5.png","day_6.png","day_7.png"],
              week_sc: ["day_1.png","day_2.png","day_3.png","day_4.png","day_5.png","day_6.png","day_7.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 180,
              day_startY: 11,
              day_sc_array: ["date_0.png","date_1.png","date_2.png","date_3.png","date_4.png","date_5.png","date_6.png","date_7.png","date_8.png","date_9.png"],
              day_tc_array: ["date_0.png","date_1.png","date_2.png","date_3.png","date_4.png","date_5.png","date_6.png","date_7.png","date_8.png","date_9.png"],
              day_en_array: ["date_0.png","date_1.png","date_2.png","date_3.png","date_4.png","date_5.png","date_6.png","date_7.png","date_8.png","date_9.png"],
              day_zero: 1,
              day_space: 0,
              day_align: hmUI.align.LEFT,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 355,
              y: 272,
              font_array: ["font_0.png","font_1.png","font_2.png","font_3.png","font_4.png","font_5.png","font_6.png","font_7.png","font_8.png","font_9.png"],
              padding: false,
              h_space: 0,
              angle: 0,
              unit_sc: '35.png',
              unit_tc: '35.png',
              unit_en: '35.png',
              negative_image: 'minus.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 340,
              y: 210,
              image_array: ["weather_1.png","weather_2.png","weather_3.png","weather_4.png","weather_5.png","weather_6.png","weather_7.png","weather_8.png","weather_9.png","weather_10.png","weather_11.png","weather_12.png","weather_13.png","weather_14.png","weather_15.png","weather_16.png","weather_17.png","weather_18.png","weather_19.png","weather_20.png","weather_21.png","weather_22.png","weather_23.png","weather_24.png","weather_25.png","weather_26.png","weather_27.png","weather_28.png","weather_29.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 230,
              y: 290,
              font_array: ["font_0.png","font_1.png","font_2.png","font_3.png","font_4.png","font_5.png","font_6.png","font_7.png","font_8.png","font_9.png"],
              padding: false,
              h_space: 0,
              angle: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_altitude_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 361,
              y: 308,
              font_array: ["font_0.png","font_1.png","font_2.png","font_3.png","font_4.png","font_5.png","font_6.png","font_7.png","font_8.png","font_9.png"],
              padding: false,
              h_space: 0,
              angle: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.ALTITUDE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_altimeter_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 354,
              y: 333,
              font_array: ["font_0.png","font_1.png","font_2.png","font_3.png","font_4.png","font_5.png","font_6.png","font_7.png","font_8.png","font_9.png"],
              padding: false,
              h_space: 0,
              angle: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.ALTIMETER,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 96,
              y: 234,
              font_array: ["f_0.png","f_1.png","f_2.png","f_3.png","f_4.png","f_5.png","f_6.png","f_7.png","f_8.png","f_9.png"],
              padding: false,
              h_space: 0,
              angle: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_distance_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 224,
              y: 217,
              font_array: ["f_0.png","f_1.png","f_2.png","f_3.png","f_4.png","f_5.png","f_6.png","f_7.png","f_8.png","f_9.png"],
              padding: false,
              h_space: 0,
              angle: 0,
              dot_image: 'dot.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.DISTANCE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_calorie_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 80,
              y: 295,
              font_array: ["f_0.png","f_1.png","f_2.png","f_3.png","f_4.png","f_5.png","f_6.png","f_7.png","f_8.png","f_9.png"],
              padding: false,
              h_space: 0,
              angle: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_vo2max_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 124,
              y: 334,
              font_array: ["min_0.png","min_1.png","min_2.png","min_3.png","min_4.png","min_5.png","min_6.png","min_7.png","min_8.png","min_9.png"],
              padding: false,
              h_space: 0,
              angle: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.VO2MAX,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_fat_burning_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 61,
              y: 334,
              font_array: ["min_0.png","min_1.png","min_2.png","min_3.png","min_4.png","min_5.png","min_6.png","min_7.png","min_8.png","min_9.png"],
              padding: false,
              h_space: 0,
              angle: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.FAT_BURNING,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 225,
              y: 430,
              font_array: ["font_0.png","font_1.png","font_2.png","font_3.png","font_4.png","font_5.png","font_6.png","font_7.png","font_8.png","font_9.png"],
              padding: false,
              h_space: 0,
              angle: 0,
              unit_sc: '%.png',
              unit_tc: '%.png',
              unit_en: '%.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 180,
              y: 435,
              image_array: ["39.png","40.png","41.png","42.png","43.png","44.png","45.png","46.png","47.png","48.png","49.png"],
              image_length: 11,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 193,
              hour_startY: 74,
              hour_array: ["82.png","83.png","84.png","85.png","86.png","87.png","88.png","89.png","90.png","91.png"],
              hour_zero: 1,
              hour_space: -5,
              hour_angle: 0,
              hour_align: hmUI.align.LEFT,

              minute_startX: 301,
              minute_startY: 74,
              minute_array: ["82.png","83.png","84.png","85.png","86.png","87.png","88.png","89.png","90.png","91.png"],
              minute_zero: 1,
              minute_space: -5,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_hour_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 282,
              y: 86,
              src: '93.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_hour = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              hour_path: '6.png',
              hour_centerX: 113,
              hour_centerY: 129,
              hour_posX: 3,
              hour_posY: 36,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_minute = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              minute_path: '7.png',
              minute_centerX: 113,
              minute_centerY: 129,
              minute_posX: 3,
              minute_posY: 58,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_second = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              second_path: '92.png',
              second_centerX: 113,
              second_centerY: 129,
              second_posX: 5,
              second_posY: 69,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            idle_background_bg = hmUI.createWidget(hmUI.widget.FILL_RECT, {
              x: 0,
              y: 0,
              w: 466,
              h: 466,
              color: '0xFF000000',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_system_dnd_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 365,
              y: 373,
              src: 'dnd_(2).png',
              type: hmUI.system_status.DISTURB,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 105,
              y: 88,
              src: 'BT_(2).png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 78,
              y: 373,
              src: 'clock_(2).png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 171,
              y: 21,
              week_en: ["9.png","10.png","11.png","12.png","13.png","14.png","15.png"],
              week_tc: ["9.png","10.png","11.png","12.png","13.png","14.png","15.png"],
              week_sc: ["9.png","10.png","11.png","12.png","13.png","14.png","15.png"],
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_month_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 260,
              month_startY: 21,
              month_sc_array: ["70.png","71.png","72.png","73.png","74.png","75.png","76.png","77.png","78.png","79.png","80.png","81.png"],
              month_tc_array: ["70.png","71.png","72.png","73.png","74.png","75.png","76.png","77.png","78.png","79.png","80.png","81.png"],
              month_en_array: ["70.png","71.png","72.png","73.png","74.png","75.png","76.png","77.png","78.png","79.png","80.png","81.png"],
              month_is_character: true ,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 210,
              day_startY: 11,
              day_sc_array: ["date_0.png","date_1.png","date_2.png","date_3.png","date_4.png","date_5.png","date_6.png","date_7.png","date_8.png","date_9.png"],
              day_tc_array: ["date_0.png","date_1.png","date_2.png","date_3.png","date_4.png","date_5.png","date_6.png","date_7.png","date_8.png","date_9.png"],
              day_en_array: ["date_0.png","date_1.png","date_2.png","date_3.png","date_4.png","date_5.png","date_6.png","date_7.png","date_8.png","date_9.png"],
              day_zero: 1,
              day_space: 0,
              day_align: hmUI.align.LEFT,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 355,
              y: 272,
              font_array: ["font_0.png","font_1.png","font_2.png","font_3.png","font_4.png","font_5.png","font_6.png","font_7.png","font_8.png","font_9.png"],
              padding: false,
              h_space: 0,
              angle: 0,
              unit_sc: '35.png',
              unit_tc: '35.png',
              unit_en: '35.png',
              negative_image: 'minus.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 340,
              y: 210,
              image_array: ["weather_1.png","weather_2.png","weather_3.png","weather_4.png","weather_5.png","weather_6.png","weather_7.png","weather_8.png","weather_9.png","weather_10.png","weather_11.png","weather_12.png","weather_13.png","weather_14.png","weather_15.png","weather_16.png","weather_17.png","weather_18.png","weather_19.png","weather_20.png","weather_21.png","weather_22.png","weather_23.png","weather_24.png","weather_25.png","weather_26.png","weather_27.png","weather_28.png","weather_29.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 225,
              y: 430,
              font_array: ["font_0.png","font_1.png","font_2.png","font_3.png","font_4.png","font_5.png","font_6.png","font_7.png","font_8.png","font_9.png"],
              padding: false,
              h_space: 0,
              angle: 0,
              unit_sc: '%.png',
              unit_tc: '%.png',
              unit_en: '%.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_battery_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 180,
              y: 435,
              image_array: ["39.png","40.png","41.png","42.png","43.png","44.png","45.png","46.png","47.png","48.png","49.png"],
              image_length: 11,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 193,
              hour_startY: 74,
              hour_array: ["82.png","83.png","84.png","85.png","86.png","87.png","88.png","89.png","90.png","91.png"],
              hour_zero: 1,
              hour_space: -5,
              hour_angle: 0,
              hour_align: hmUI.align.LEFT,

              minute_startX: 301,
              minute_startY: 74,
              minute_array: ["82.png","83.png","84.png","85.png","86.png","87.png","88.png","89.png","90.png","91.png"],
              minute_zero: 1,
              minute_space: -5,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_hour_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 282,
              y: 86,
              src: '93.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });
            
            // disconnectAlert = hmUI.createWidget(hmUI.widget.DisconnectAlert, {
              // disconneсnt_vibrate_type: 9,
              // disconneсnt_toast_text: Connect LOST,
              // conneсnt_vibrate_type: 0,
              // conneсnt_toast_text: Connect FIND,
            // });

            // vibration when connecting or disconnecting

            function checkConnection() {
              hmBle.removeListener;
              hmBle.addListener(function (status) {
                if(!status) {
                  hmUI.showToast({text: "Connect LOST"});
                  vibro(9);
                }
                if(status) {
                  hmUI.showToast({text: "Connect FIND"});
                  vibro(0);
                }
              });
            }

            // end vibration when connecting or disconnecting
            // vibrate function

            const vibrate = hmSensor.createSensor(hmSensor.id.VIBRATE);
            let timer_StopVibrate = null;


            function vibro(scene = 25) {
              let stopDelay = 50;
              stopVibro();
              vibrate.stop();
              vibrate.scene = scene;
              if(scene < 23 || scene > 25) stopDelay = 1300;
              vibrate.start();
              timer_StopVibrate = timer.createTimer(stopDelay, 3000, stopVibro, {});
            }

            function stopVibro(){
              vibrate.stop();
              if(timer_StopVibrate) timer.stopTimer(timer_StopVibrate);
            }

            // end vibrate function

            normal_stopwatch_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 235,
              y: 155,
              w: 50,
              h: 50,
              src: 'Empty.png',
              type: hmUI.data_type.STOP_WATCH,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_countdown_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 369,
              y: 155,
              w: 50,
              h: 50,
              src: 'Empty.png',
              type: hmUI.data_type.COUNT_DOWN,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sleep_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 193,
              y: 216,
              w: 100,
              h: 55,
              src: 'Empty.png',
              type: hmUI.data_type.SLEEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_alarm_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 170,
              y: 154,
              w: 50,
              h: 50,
              src: 'Empty.png',
              type: hmUI.data_type.ALARM_CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            hmUI.createWidget(hmUI.widget.BUTTON, {
				 x: 302,       
				 y: 370,     
				 w: 55,       
				 h: 55,      
				 text: '',      
				 normal_src: 'Empty.png',        
				 press_src: 'Empty.png', 
				 click_func: () => {
				hmApp.startApp({ url: 'SportListScreen', native: true });
				 },
				 show_level: hmUI.show_level.ONLY_NORMAL,
			});

            normal_altimeter_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 320,
              y: 304,
              w: 100,
              h: 60,
              src: 'Empty.png',
              type: hmUI.data_type.ALTIMETER,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 330,
              y: 220,
              w: 80,
              h: 70,
              src: 'Empty.png',
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            hmUI.createWidget(hmUI.widget.BUTTON, {
				 x: 237,       
				 y: 370,     
				 w: 55,       
				 h: 55,      
				 text: '',      
				 normal_src: 'Empty.png',        
				 press_src: 'Empty.png', 
				 click_func: () => {
				hmApp.startApp({ url: 'LocalMusicScreen', native: true });
				 },
				 show_level: hmUI.show_level.ONLY_NORMAL,
			});

            hmUI.createWidget(hmUI.widget.BUTTON, {
				 x: 173,       
				 y: 370,     
				 w: 55,       
				 h: 55,      
				 text: '',      
				 normal_src: 'Empty.png',        
				 press_src: 'Empty.png', 
				 click_func: () => {
				hmApp.startApp({ url: 'PhoneContactsScreen', native: true });
				 },
				 show_level: hmUI.show_level.ONLY_NORMAL,
			});

            hmUI.createWidget(hmUI.widget.BUTTON, {
				 x: 106,       
				 y: 370,     
				 w: 55,       
				 h: 55,      
				 text: '',      
				 normal_src: 'Empty.png',        
				 press_src: 'Empty.png', 
				 click_func: () => {
				hmApp.startApp({ url: 'PhoneRecentCallScreen', native: true });
				 },
				 show_level: hmUI.show_level.ONLY_NORMAL,
			});

            normal_heart_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 187,
              y: 296,
              w: 100,
              h: 60,
              src: 'Empty.png',
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 71,
              y: 211,
              w: 100,
              h: 67,
              src: 'Empty.png',
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
			
			hmUI.createWidget(hmUI.widget.BUTTON, {
				 x: 302,       
				 y: 155,     
				 w: 55,       
				 h: 55,      
				 text: '',      
				 normal_src: 'Empty.png',        
				 press_src: 'Empty.png', 
				 click_func: () => {
				hmApp.startApp({ url: 'CompassScreen', native: true });
				 },
				 show_level: hmUI.show_level.ONLY_NORMAL,
			});

            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                HeartUpdate ()
				updateSleepInfo();
				checkConnection();
                stopVibro();

              }),
              pause_call: (function () {
                stopVibro();

              }),
            });

                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}