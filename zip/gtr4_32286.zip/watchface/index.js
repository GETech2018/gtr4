﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.0.1
    ** Copyright © CashaCX75. All Rights Reserved
    */

    try {
    (()=>{
        //dynamic modify start

        
        let normal_background_bg = ''
        let normal_stand_icon_img = ''
        let normal_date_img_date_month_img = ''
        let normal_date_img_date_day = ''
        let normal_system_disconnect_img = ''
        let normal_calorie_current_text_img = ''
        let normal_heart_rate_text_text_img = ''
        let normal_step_current_text_img = ''
        let normal_battery_text_text_img = ''
        let normal_stress_icon_img = ''
        let normal_analog_clock_time_pointer_hour = ''
        let normal_analog_clock_time_pointer_minute = ''
        let normal_analog_clock_time_pointer_second = ''
        let idle_background_bg = ''
        let idle_system_disconnect_img = ''
        let idle_battery_text_text_img = ''
        let idle_battery_text_separator_img = ''
        let idle_digital_clock_img_time = ''
        let idle_digital_clock_hour_separator_img = ''
        let idle_digital_clock_img_time_AmPm = ''
        let normal_heart_jumpable_img_click = ''
        let normal_step_jumpable_img_click = ''


        //dynamic modify end
        const e = __$$hmAppManager$$__.currentApp;
        const o = e.current
          , {px: i} = (new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(e,o)),
        e.__globals__)
          , n = Logger.getLogger("watchface6");
        o.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            normal_background_bg = hmUI.createWidget(hmUI.widget.FILL_RECT, {
              x: 0,
              y: 0,
              w: 466,
              h: 466,
              color: '0xFF000000',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_stand_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: -55,
              y: -53,
              src: 'rain_backg (3).png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_month_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: -6,
              month_startY: 211,
              month_sc_array: ["Picture159.png","Picture160.png","Picture161.png","Picture162.png","Picture163.png","Picture164.png","Picture165.png","Picture166.png","Picture167.png","Picture168.png","Picture169.png","Picture170.png"],
              month_tc_array: ["Picture159.png","Picture160.png","Picture161.png","Picture162.png","Picture163.png","Picture164.png","Picture165.png","Picture166.png","Picture167.png","Picture168.png","Picture169.png","Picture170.png"],
              month_en_array: ["Picture159.png","Picture160.png","Picture161.png","Picture162.png","Picture163.png","Picture164.png","Picture165.png","Picture166.png","Picture167.png","Picture168.png","Picture169.png","Picture170.png"],
              month_is_character: true ,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: -1,
              day_startY: 187,
              day_sc_array: ["pidigi_grey_sec0001.png","pidigi_grey_sec0002.png","pidigi_grey_sec0003.png","pidigi_grey_sec0004.png","pidigi_grey_sec0005.png","pidigi_grey_sec0006.png","pidigi_grey_sec0007.png","pidigi_grey_sec0008.png","pidigi_grey_sec0009.png","pidigi_grey_sec0010.png"],
              day_tc_array: ["pidigi_grey_sec0001.png","pidigi_grey_sec0002.png","pidigi_grey_sec0003.png","pidigi_grey_sec0004.png","pidigi_grey_sec0005.png","pidigi_grey_sec0006.png","pidigi_grey_sec0007.png","pidigi_grey_sec0008.png","pidigi_grey_sec0009.png","pidigi_grey_sec0010.png"],
              day_en_array: ["pidigi_grey_sec0001.png","pidigi_grey_sec0002.png","pidigi_grey_sec0003.png","pidigi_grey_sec0004.png","pidigi_grey_sec0005.png","pidigi_grey_sec0006.png","pidigi_grey_sec0007.png","pidigi_grey_sec0008.png","pidigi_grey_sec0009.png","pidigi_grey_sec0010.png"],
              day_zero: 1,
              day_space: -44,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 222,
              y: 427,
              src: 'blu.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_calorie_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 92,
              y: 324,
              font_array: ["digi_smafruline_white_0001.png","digi_smafruline_white_0002.png","digi_smafruline_white_0003.png","digi_smafruline_white_0004.png","digi_smafruline_white_0005.png","digi_smafruline_white_0006.png","digi_smafruline_white_0007.png","digi_smafruline_white_0008.png","digi_smafruline_white_0009.png","digi_smafruline_white_0010.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 254,
              y: 85,
              font_array: ["digi_smafruline_white_0001.png","digi_smafruline_white_0002.png","digi_smafruline_white_0003.png","digi_smafruline_white_0004.png","digi_smafruline_white_0005.png","digi_smafruline_white_0006.png","digi_smafruline_white_0007.png","digi_smafruline_white_0008.png","digi_smafruline_white_0009.png","digi_smafruline_white_0010.png"],
              padding: true,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 111,
              y: 86,
              font_array: ["digi_smafruline_white_0001.png","digi_smafruline_white_0002.png","digi_smafruline_white_0003.png","digi_smafruline_white_0004.png","digi_smafruline_white_0005.png","digi_smafruline_white_0006.png","digi_smafruline_white_0007.png","digi_smafruline_white_0008.png","digi_smafruline_white_0009.png","digi_smafruline_white_0010.png"],
              padding: false,
              h_space: 1,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 293,
              y: 324,
              font_array: ["digi_smafruline_white_0001.png","digi_smafruline_white_0002.png","digi_smafruline_white_0003.png","digi_smafruline_white_0004.png","digi_smafruline_white_0005.png","digi_smafruline_white_0006.png","digi_smafruline_white_0007.png","digi_smafruline_white_0008.png","digi_smafruline_white_0009.png","digi_smafruline_white_0010.png"],
              padding: true,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_stress_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: -46,
              y: -33,
              src: 'Shadow ring 239.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_hour = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              hour_path: 'aodh.png',
              hour_centerX: 233,
              hour_centerY: 233,
              hour_posX: 24,
              hour_posY: 183,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_minute = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              minute_path: 'aodm.png',
              minute_centerX: 233,
              minute_centerY: 233,
              minute_posX: 23,
              minute_posY: 216,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_second = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              second_path: 'sec_01.png',
              second_centerX: 233,
              second_centerY: 233,
              second_posX: 22,
              second_posY: 229,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            idle_background_bg = hmUI.createWidget(hmUI.widget.FILL_RECT, {
              x: 0,
              y: 0,
              w: 466,
              h: 466,
              color: '0xFF090400',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 222,
              y: 425,
              src: 'blu.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 354,
              y: 309,
              font_array: ["small5_size_googlesan_grey_0001.png","small5_size_googlesan_grey_0002.png","small5_size_googlesan_grey_0003.png","small5_size_googlesan_grey_0004.png","small5_size_googlesan_grey_0005.png","small5_size_googlesan_grey_0006.png","small5_size_googlesan_grey_0007.png","small5_size_googlesan_grey_0008.png","small5_size_googlesan_grey_0009.png","small5_size_googlesan_grey_0010.png"],
              padding: false,
              h_space: -34,
              unit_sc: 'icon_pecnet_lightgrey.png',
              unit_tc: 'icon_pecnet_lightgrey.png',
              unit_en: 'icon_pecnet_lightgrey.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_battery_text_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 345,
              y: 318,
              src: 'icon_batt_grey.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: -111,
              hour_startY: 55,
              hour_array: ["digi_grey_0001.png","digi_grey_0002.png","digi_grey_0003.png","digi_grey_0004.png","digi_grey_0005.png","digi_grey_0006.png","digi_grey_0007.png","digi_grey_0008.png","digi_grey_0009.png","digi_grey_0010.png"],
              hour_zero: 1,
              hour_space: -275,
              hour_align: hmUI.align.LEFT,

              minute_startX: 108,
              minute_startY: 56,
              minute_array: ["digi_grey_0001.png","digi_grey_0002.png","digi_grey_0003.png","digi_grey_0004.png","digi_grey_0005.png","digi_grey_0006.png","digi_grey_0007.png","digi_grey_0008.png","digi_grey_0009.png","digi_grey_0010.png"],
              minute_zero: 1,
              minute_space: -275,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_hour_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 121,
              y: 126,
              src: 'digi_column.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time_AmPm = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              am_x: 354,
              am_y: 195,
              am_sc_path: 'zzblank_icon_AM.png',
              am_en_path: 'zzblank_icon_AM.png',
              pm_x: 347,
              pm_y: 195,
              pm_sc_path: 'zzblank_icon_PM.png',
              pm_en_path: 'zzblank_icon_PM.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            normal_heart_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 248,
              y: 62,
              w: 100,
              h: 100,
              src: 'transparent.png',
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 107,
              y: 57,
              w: 100,
              h: 100,
              src: 'transparent.png',
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


                //dynamic modify end
            },
            onInit() {
                n.log("index page.js on init invoke")
            },
            build() {
                this.init_view(),
                n.log("index page.js on ready invoke")
            },
            onDestroy() {
                n.log("index page.js on destroy invoke")
            }
        })
    }
    )()
} catch (e) {
    console.log("Mini Program Error", e),
    e && e.stack && e.stack.split(/\n/).forEach((e=>console.log("error stack", e)))
}
