﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        const logger = Logger.getLogger('watchface_SashaCX75');
        //end of ignored block

        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_pai_icon_img = ''
        let normal_calorie_icon_img = ''
        let normal_system_disconnect_img = ''
        let normal_battery_icon_img = ''
        let normal_battery_circle_scale = ''
        let normal_date_img_date_day = ''
        let normal_date_img_date_week_img = ''
        let normal_stand_icon_img = ''
        let normal_step_icon_img = ''
        let normal_digital_clock_img_time_second = ''
        let normal_analog_clock_time_pointer_minute = ''
        let normal_analog_clock_time_pointer_hour = ''
        let idle_background_bg_img = ''
        let idle_pai_icon_img = ''
        let idle_system_dnd_img = ''
        let idle_system_disconnect_img = ''
        let idle_calorie_icon_img = ''
        let idle_battery_icon_img = ''
        let idle_analog_clock_time_pointer_minute = ''
        let idle_analog_clock_time_pointer_hour = ''


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 466,
              h: 466,
              src: 'index_modern02 - blackback - 476.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_pai_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: -6,
              y: -6,
              src: 'index_modern02 - whiteback - 476.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_calorie_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 335,
              y: 205,
              src: 'mini_123.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 69,
              y: 214,
              src: 'icon_bluetooth_lightgrey.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 199,
              y: 64,
              src: 'icon_Picture - red.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_battery_circle_scale = hmUI.createWidget(hmUI.widget.Circle_Scale, {
              // center_x: 233,
              // center_y: 233,
              // start_angle: 0,
              // end_angle: 360,
              // radius: 236,
              // line_width: 6,
              // color: 0xFF85C203,
              // mirror: False,
              // inversion: False,
              // type: hmUI.data_type.BATTERY,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            let screenType = hmSetting.getScreenType();
            if (screenType != hmSetting.screen_type.AOD) {
              normal_battery_circle_scale = hmUI.createWidget(hmUI.widget.ARC);
            };
            
            const battery = hmSensor.createSensor(hmSensor.id.BATTERY);
            battery.addEventListener(hmSensor.event.CHANGE, function() {
              scale_call();
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 414,
              day_startY: 204,
              day_sc_array: ["digi_googlesan_redsmallsize3_0001.png","digi_googlesan_redsmallsize3_0002.png","digi_googlesan_redsmallsize3_0003.png","digi_googlesan_redsmallsize3_0004.png","digi_googlesan_redsmallsize3_0005.png","digi_googlesan_redsmallsize3_0006.png","digi_googlesan_redsmallsize3_0007.png","digi_googlesan_redsmallsize3_0008.png","digi_googlesan_redsmallsize3_0009.png","digi_googlesan_redsmallsize3_0010.png"],
              day_tc_array: ["digi_googlesan_redsmallsize3_0001.png","digi_googlesan_redsmallsize3_0002.png","digi_googlesan_redsmallsize3_0003.png","digi_googlesan_redsmallsize3_0004.png","digi_googlesan_redsmallsize3_0005.png","digi_googlesan_redsmallsize3_0006.png","digi_googlesan_redsmallsize3_0007.png","digi_googlesan_redsmallsize3_0008.png","digi_googlesan_redsmallsize3_0009.png","digi_googlesan_redsmallsize3_0010.png"],
              day_en_array: ["digi_googlesan_redsmallsize3_0001.png","digi_googlesan_redsmallsize3_0002.png","digi_googlesan_redsmallsize3_0003.png","digi_googlesan_redsmallsize3_0004.png","digi_googlesan_redsmallsize3_0005.png","digi_googlesan_redsmallsize3_0006.png","digi_googlesan_redsmallsize3_0007.png","digi_googlesan_redsmallsize3_0008.png","digi_googlesan_redsmallsize3_0009.png","digi_googlesan_redsmallsize3_0010.png"],
              day_zero: 0,
              day_space: 0,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 338,
              y: 208,
              week_en: ["digi_googlesan_darksmallsize3_0001.png","digi_googlesan_darksmallsize3_0002.png","digi_googlesan_darksmallsize3_0003.png","digi_googlesan_darksmallsize3_0004.png","digi_googlesan_darksmallsize3_0005.png","digi_googlesan_darksmallsize3_0006.png","digi_googlesan_darksmallsize3_0007.png"],
              week_tc: ["digi_googlesan_darksmallsize3_0001.png","digi_googlesan_darksmallsize3_0002.png","digi_googlesan_darksmallsize3_0003.png","digi_googlesan_darksmallsize3_0004.png","digi_googlesan_darksmallsize3_0005.png","digi_googlesan_darksmallsize3_0006.png","digi_googlesan_darksmallsize3_0007.png"],
              week_sc: ["digi_googlesan_darksmallsize3_0001.png","digi_googlesan_darksmallsize3_0002.png","digi_googlesan_darksmallsize3_0003.png","digi_googlesan_darksmallsize3_0004.png","digi_googlesan_darksmallsize3_0005.png","digi_googlesan_darksmallsize3_0006.png","digi_googlesan_darksmallsize3_0007.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_stand_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 179,
              y: 300,
              src: 'Picture17.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 226,
              y: -17,
              src: 'mark.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time_second = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              second_startX: 210,
              second_startY: 323,
              second_array: ["digi_googlesan_redsmallsize3_0001.png","digi_googlesan_redsmallsize3_0002.png","digi_googlesan_redsmallsize3_0003.png","digi_googlesan_redsmallsize3_0004.png","digi_googlesan_redsmallsize3_0005.png","digi_googlesan_redsmallsize3_0006.png","digi_googlesan_redsmallsize3_0007.png","digi_googlesan_redsmallsize3_0008.png","digi_googlesan_redsmallsize3_0009.png","digi_googlesan_redsmallsize3_0010.png"],
              second_zero: 1,
              second_space: 0,
              second_follow: 0,
              second_align: hmUI.align.CENTER_H,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_minute = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              minute_path: '0052M.png',
              minute_centerX: 233,
              minute_centerY: 233,
              minute_posX: 31,
              minute_posY: 212,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_hour = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              hour_path: '0052H.png',
              hour_centerX: 233,
              hour_centerY: 233,
              hour_posX: 32,
              hour_posY: 212,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            idle_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 466,
              h: 466,
              src: 'index_modern02 - blackback - 476.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_pai_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: -6,
              y: -6,
              src: 'index_modern02 - whiteback - 476.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_system_dnd_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 94,
              y: 312,
              src: 'icon_DND_lightgrey.png',
              type: hmUI.system_status.DISTURB,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 69,
              y: 214,
              src: 'icon_bluetooth_lightgrey.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_calorie_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: -49,
              y: -45,
              src: 'AOB Overlay.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_battery_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 199,
              y: 64,
              src: 'icon_Picture - red.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_analog_clock_time_pointer_minute = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              minute_path: '0052M.png',
              minute_centerX: 233,
              minute_centerY: 233,
              minute_posX: 31,
              minute_posY: 212,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_analog_clock_time_pointer_hour = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              hour_path: '0052H.png',
              hour_centerX: 233,
              hour_centerY: 233,
              hour_posX: 32,
              hour_posY: 212,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            function scale_call() {

                console.log('update scales BATTERY');
                
                let valueBattery = battery.current;
                let targetBattery = 100;
                let progressBattery = valueBattery/targetBattery;
                if (progressBattery > 1) progressBattery = 1;
                let progress_cs_normal_battery = progressBattery;

                if (screenType != hmSetting.screen_type.AOD) {

                  // normal_battery_circle_scale
                  // initial parameters
                  let start_angle_normal_battery = -90;
                  let end_angle_normal_battery = 270;
                  let center_x_normal_battery = 233;
                  let center_y_normal_battery = 233;
                  let radius_normal_battery = 236;
                  let line_width_cs_normal_battery = 6;
                  let color_cs_normal_battery = 0xFF85C203;
                  
                  // calculated parameters
                  let arcX_normal_battery = center_x_normal_battery - radius_normal_battery;
                  let arcY_normal_battery = center_y_normal_battery - radius_normal_battery;
                  let CircleWidth_normal_battery = 2 * radius_normal_battery;
                  let angle_offset_normal_battery = end_angle_normal_battery - start_angle_normal_battery;
                  angle_offset_normal_battery = angle_offset_normal_battery * progress_cs_normal_battery;
                  let end_angle_normal_battery_draw = start_angle_normal_battery + angle_offset_normal_battery;
                  
                  normal_battery_circle_scale.setProperty(hmUI.prop.MORE, {
                    x: arcX_normal_battery,
                    y: arcY_normal_battery,
                    w: CircleWidth_normal_battery,
                    h: CircleWidth_normal_battery,
                    start_angle: start_angle_normal_battery,
                    end_angle: end_angle_normal_battery_draw,
                    color: color_cs_normal_battery,
                    line_width: line_width_cs_normal_battery,
                  });
                };

            };

            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                scale_call();
              }),
            });

                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}