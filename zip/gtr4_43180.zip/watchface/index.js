﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        const logger = Logger.getLogger('watchface_SashaCX75');
        //end of ignored block

        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_date_img_date_week_img = ''
        let normal_battery_icon_img = ''
        let normal_battery_text_text_img = ''
        let normal_battery_text_separator_img = ''
        let normal_date_img_date_day = ''
        let normal_analog_clock_time_pointer_minute = ''
        let normal_analog_clock_time_pointer_hour = ''
        let normal_analog_clock_time_pointer_second = ''
        let normal_calorie_icon_img = ''
        let idle_background_bg = ''
        let idle_step_icon_img = ''
        let idle_analog_clock_time_pointer_minute = ''
        let idle_analog_clock_time_pointer_hour = ''
        let idle_calorie_icon_img = ''
        let Button_Switch_BG = ''

        let backgroundIndex = 0;
        let backgroundList = ['black background with text overlay (2).png', 'black background.png'];
        let backgroundToastList = ['Background %s', 'Background %s'];
        const watchfaceId = hmApp.packageInfo().watchfaceId;


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            //start of ignored block
            console.log('SwitchBackground');
            function switchBackground() {
              backgroundIndex++;
              if (backgroundIndex >= backgroundList.length) backgroundIndex = 0;
              hmFS.SysProSetInt(`backgroundIndex_${watchfaceId}`, backgroundIndex);
              let toastText = backgroundToastList[backgroundIndex].replace('%s', `${backgroundIndex + 1}`);
              if (toastText.length > 0) hmUI.showToast({text: toastText});
              normal_background_bg_img.setProperty(hmUI.prop.SRC, backgroundList[backgroundIndex]);
            };
            //end of ignored block

            console.log('Watch_Face.ScreenNormal');
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 466,
              h: 466,
              src: 'black background with text overlay (2).png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: -38,
              y: -43,
              week_en: ["zdays_orange_5_0001.png","zdays_orange_5_0002.png","zdays_orange_5_0003.png","zdays_orange_5_0004.png","zdays_orange_5_0005.png","zdays_orange_5_0006.png","zdays_orange_5_0007.png"],
              week_tc: ["zdays_orange_5_0001.png","zdays_orange_5_0002.png","zdays_orange_5_0003.png","zdays_orange_5_0004.png","zdays_orange_5_0005.png","zdays_orange_5_0006.png","zdays_orange_5_0007.png"],
              week_sc: ["zdays_orange_5_0001.png","zdays_orange_5_0002.png","zdays_orange_5_0003.png","zdays_orange_5_0004.png","zdays_orange_5_0005.png","zdays_orange_5_0006.png","zdays_orange_5_0007.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 349,
              y: 285,
              src: 'icon_Picture - OG.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 363,
              y: 259,
              font_array: ["stats_orange_5_0001.png","stats_orange_5_0002.png","stats_orange_5_0003.png","stats_orange_5_0004.png","stats_orange_5_0005.png","stats_orange_5_0006.png","stats_orange_5_0007.png","stats_orange_5_0008.png","stats_orange_5_0009.png","stats_orange_5_0010.png"],
              padding: false,
              h_space: -40,
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 288,
              y: 259,
              src: 'batt_Picture105.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 305,
              day_startY: 142,
              day_sc_array: ["day_orange_aceh_12_0001.png","day_orange_aceh_12_0002.png","day_orange_aceh_12_0003.png","day_orange_aceh_12_0004.png","day_orange_aceh_12_0005.png","day_orange_aceh_12_0006.png","day_orange_aceh_12_0007.png","day_orange_aceh_12_0008.png","day_orange_aceh_12_0009.png","day_orange_aceh_12_0010.png"],
              day_tc_array: ["day_orange_aceh_12_0001.png","day_orange_aceh_12_0002.png","day_orange_aceh_12_0003.png","day_orange_aceh_12_0004.png","day_orange_aceh_12_0005.png","day_orange_aceh_12_0006.png","day_orange_aceh_12_0007.png","day_orange_aceh_12_0008.png","day_orange_aceh_12_0009.png","day_orange_aceh_12_0010.png"],
              day_en_array: ["day_orange_aceh_12_0001.png","day_orange_aceh_12_0002.png","day_orange_aceh_12_0003.png","day_orange_aceh_12_0004.png","day_orange_aceh_12_0005.png","day_orange_aceh_12_0006.png","day_orange_aceh_12_0007.png","day_orange_aceh_12_0008.png","day_orange_aceh_12_0009.png","day_orange_aceh_12_0010.png"],
              day_zero: 1,
              day_space: -112,
              day_align: hmUI.align.LEFT,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_minute = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              minute_path: 'Picture13M.png',
              minute_centerX: 233,
              minute_centerY: 233,
              minute_posX: 31,
              minute_posY: 180,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_hour = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              hour_path: 'Picture13H.png',
              hour_centerX: 233,
              hour_centerY: 233,
              hour_posX: 31,
              hour_posY: 148,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_second = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              second_path: 'Picture13S3.png',
              second_centerX: 233,
              second_centerY: 233,
              second_posX: 9,
              second_posY: 221,
              second_cover_path: 'Picture13R.png',
              second_cover_x: 201,
              second_cover_y: 202,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_calorie_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: -33,
              y: -21,
              src: 'ring_edge_double.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            console.log('Watch_Face.ScreenAOD');
            idle_background_bg = hmUI.createWidget(hmUI.widget.FILL_RECT, {
              x: 0,
              y: 0,
              w: 466,
              h: 466,
              color: '0xFF000000',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_step_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: -42,
              y: -15,
              src: 'AOB Overlay.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_analog_clock_time_pointer_minute = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              minute_path: 'Picture13M.png',
              minute_centerX: 233,
              minute_centerY: 233,
              minute_posX: 32,
              minute_posY: 180,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_analog_clock_time_pointer_hour = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              hour_path: 'Picture13H.png',
              hour_centerX: 233,
              hour_centerY: 233,
              hour_posX: 32,
              hour_posY: 148,
              hour_cover_path: 'Picture13R.png',
              hour_cover_x: 202,
              hour_cover_y: 202,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_calorie_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: -33,
              y: -21,
              src: 'ring_edge_double.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            console.log('Watch_Face.SwitchBackground');
            // Button_Switch_BG = hmUI.createWidget(hmUI.widget.SwitchBackground, {
              // x: 0,
              // y: 0,
              // w: 100,
              // h: 40,
              // text: '',
              // color: 0xFFFF8C00,
              // text_size: 25,
              // radius: 12,
              // press_color: 0xFFA0A0A0,
              // normal_color: 0xFF696969,
              // bg_list: black background with text overlay (2)|black background,
              // toast_list: Background %s|Background %s,
              // use_crown: False,
              // use_in_AOD: False,
              // vibro: False,
            // });

            Button_Switch_BG = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 0,
              y: 0,
              w: 100,
              h: 40,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              radius: 12,
              press_color: 0xFFA0A0A0,
              normal_color: 0xFF696969,
              click_func: (button_widget) => {
                switchBackground();
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            let screenType = hmSetting.getScreenType();
            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                console.log('resume_call()');

                //SwitchBackground
                if (hmFS.SysProGetInt(`backgroundIndex_${watchfaceId}`) === undefined) {
                  backgroundIndex = 0;
                  hmFS.SysProSetInt(`backgroundIndex_${watchfaceId}`, backgroundIndex);
                } else {
                  backgroundIndex = hmFS.SysProGetInt(`backgroundIndex_${watchfaceId}`);
                };
                if (screenType == hmSetting.screen_type.WATCHFACE && normal_background_bg_img) normal_background_bg_img.setProperty(hmUI.prop.SRC, backgroundList[backgroundIndex]);
              }),
            });

                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}