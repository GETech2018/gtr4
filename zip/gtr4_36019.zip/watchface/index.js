﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        const logger = Logger.getLogger('watchface_SashaCX75');
        //end of ignored block

        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_distance_TextCircle = new Array(5);
        let normal_distance_TextCircle_ASCIIARRAY = new Array(10);
        let normal_distance_TextCircle_img_width = 22;
        let normal_distance_TextCircle_img_height = 40;
        let normal_distance_TextCircle_dot_width = 7;
        let normal_heart_rate_TextCircle = new Array(3);
        let normal_heart_rate_TextCircle_ASCIIARRAY = new Array(10);
        let normal_heart_rate_TextCircle_img_width = 22;
        let normal_heart_rate_TextCircle_img_height = 40;
        let normal_calorie_TextCircle = new Array(4);
        let normal_calorie_TextCircle_ASCIIARRAY = new Array(10);
        let normal_calorie_TextCircle_img_width = 22;
        let normal_calorie_TextCircle_img_height = 40;
        let normal_step_TextCircle = new Array(5);
        let normal_step_TextCircle_ASCIIARRAY = new Array(10);
        let normal_step_TextCircle_img_width = 22;
        let normal_step_TextCircle_img_height = 40;
        let normal_battery_TextCircle = new Array(3);
        let normal_battery_TextCircle_ASCIIARRAY = new Array(10);
        let normal_battery_TextCircle_img_width = 22;
        let normal_battery_TextCircle_img_height = 40;
        let normal_system_lock_img = ''
        let normal_system_disconnect_img = ''
        let normal_system_clock_img = ''
        let normal_sun_current_text_img = ''
        let normal_moon_image_progress_img_level = ''
        let normal_temperature_current_text_img = ''
        let normal_weather_image_progress_img_level = ''
        let normal_date_img_date_month_img = ''
        let normal_date_img_date_day = ''
        let normal_date_img_date_week_img = ''
        let normal_digital_clock_img_time_AmPm = ''
        let normal_digital_clock_img_time = ''
        let normal_analog_clock_time_pointer_second = ''
        let idle_battery_TextCircle = new Array(3);
        let idle_battery_TextCircle_ASCIIARRAY = new Array(10);
        let idle_battery_TextCircle_img_width = 22;
        let idle_battery_TextCircle_img_height = 40;
        let idle_battery_TextCircle_unit = null;
        let idle_battery_TextCircle_unit_width = 29;
        let idle_system_lock_img = ''
        let idle_system_disconnect_img = ''
        let idle_system_clock_img = ''
        let idle_sun_current_text_img = ''
        let idle_moon_image_progress_img_level = ''
        let idle_date_img_date_month_img = ''
        let idle_date_img_date_day = ''
        let idle_date_img_date_week_img = ''
        let idle_digital_clock_img_time_AmPm = ''
        let idle_digital_clock_img_time = ''
        let idle_digital_clock_minute_separator_img = ''
        let normal_alarm_jumpable_img_click = ''
        let normal_sunrise_jumpable_img_click = ''
        let normal_altimeter_jumpable_img_click = ''
        let normal_temperature_jumpable_img_click = ''
        let normal_heart_jumpable_img_click = ''
        let normal_step_jumpable_img_click = ''
        let Button_1 = ''
        let Button_2 = ''


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 466,
              h: 466,
              src: '0.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_distance_text_circle_img = hmUI.createWidget(hmUI.widget.Text_Circle, {
              // circle_center_X: 233,
              // circle_center_Y: 233,
              // font_array: ["51.png","52.png","53.png","54.png","55.png","56.png","57.png","58.png","59.png","60.png"],
              // radius: 178,
              // angle: -41,
              // char_space_angle: 0,
              // dot_image: 'Punto2.png',
              // zero: false,
              // reverse_direction: false,
              // unit_in_alignment: true,
              // vertical_alignment: BOTTOM,
              // horizontal_alignment: LEFT,
              // type: hmUI.data_type.DISTANCE,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_distance_TextCircle_ASCIIARRAY[0] = '51.png';  // set of images with numbers
            normal_distance_TextCircle_ASCIIARRAY[1] = '52.png';  // set of images with numbers
            normal_distance_TextCircle_ASCIIARRAY[2] = '53.png';  // set of images with numbers
            normal_distance_TextCircle_ASCIIARRAY[3] = '54.png';  // set of images with numbers
            normal_distance_TextCircle_ASCIIARRAY[4] = '55.png';  // set of images with numbers
            normal_distance_TextCircle_ASCIIARRAY[5] = '56.png';  // set of images with numbers
            normal_distance_TextCircle_ASCIIARRAY[6] = '57.png';  // set of images with numbers
            normal_distance_TextCircle_ASCIIARRAY[7] = '58.png';  // set of images with numbers
            normal_distance_TextCircle_ASCIIARRAY[8] = '59.png';  // set of images with numbers
            normal_distance_TextCircle_ASCIIARRAY[9] = '60.png';  // set of images with numbers

            //start of ignored block
            for (let i = 0; i < 5; i++) {
              normal_distance_TextCircle[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 466,
                h: 466,
                center_x: 233,
                center_y: 233,
                pos_x: 233 - normal_distance_TextCircle_img_width / 2,
                pos_y: 233 - 218,
                src: '51.png',
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
              normal_distance_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
            };
            //end of ignored block
            
            const distance = hmSensor.createSensor(hmSensor.id.DISTANCE);
            distance.addEventListener(hmSensor.event.CHANGE, function() {
              text_update();
            });
            
            function toDegree (radian) {
              return radian * (180 / Math.PI);
            };

            // normal_heart_rate_text_circle_img = hmUI.createWidget(hmUI.widget.Text_Circle, {
              // circle_center_X: 233,
              // circle_center_Y: 233,
              // font_array: ["51.png","52.png","53.png","54.png","55.png","56.png","57.png","58.png","59.png","60.png"],
              // radius: 216,
              // angle: 103,
              // char_space_angle: 2,
              // zero: false,
              // reverse_direction: true,
              // unit_in_alignment: true,
              // vertical_alignment: BOTTOM,
              // horizontal_alignment: RIGHT,
              // type: hmUI.data_type.HEART,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_heart_rate_TextCircle_ASCIIARRAY[0] = '51.png';  // set of images with numbers
            normal_heart_rate_TextCircle_ASCIIARRAY[1] = '52.png';  // set of images with numbers
            normal_heart_rate_TextCircle_ASCIIARRAY[2] = '53.png';  // set of images with numbers
            normal_heart_rate_TextCircle_ASCIIARRAY[3] = '54.png';  // set of images with numbers
            normal_heart_rate_TextCircle_ASCIIARRAY[4] = '55.png';  // set of images with numbers
            normal_heart_rate_TextCircle_ASCIIARRAY[5] = '56.png';  // set of images with numbers
            normal_heart_rate_TextCircle_ASCIIARRAY[6] = '57.png';  // set of images with numbers
            normal_heart_rate_TextCircle_ASCIIARRAY[7] = '58.png';  // set of images with numbers
            normal_heart_rate_TextCircle_ASCIIARRAY[8] = '59.png';  // set of images with numbers
            normal_heart_rate_TextCircle_ASCIIARRAY[9] = '60.png';  // set of images with numbers

            //start of ignored block
            for (let i = 0; i < 3; i++) {
              normal_heart_rate_TextCircle[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 466,
                h: 466,
                center_x: 233,
                center_y: 233,
                pos_x: 233 - normal_heart_rate_TextCircle_img_width / 2,
                pos_y: 233 + 176,
                src: '51.png',
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
              normal_heart_rate_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
            };
            //end of ignored block
            
            const heart_rate = hmSensor.createSensor(hmSensor.id.HEART);
            heart_rate.addEventListener(hmSensor.event.CHANGE, function() {
              text_update();
            });

            // normal_calorie_text_circle_img = hmUI.createWidget(hmUI.widget.Text_Circle, {
              // circle_center_X: 233,
              // circle_center_Y: 233,
              // font_array: ["51.png","52.png","53.png","54.png","55.png","56.png","57.png","58.png","59.png","60.png"],
              // radius: 215,
              // angle: 175,
              // char_space_angle: 2,
              // zero: false,
              // reverse_direction: true,
              // unit_in_alignment: true,
              // vertical_alignment: BOTTOM,
              // horizontal_alignment: RIGHT,
              // type: hmUI.data_type.CAL,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_calorie_TextCircle_ASCIIARRAY[0] = '51.png';  // set of images with numbers
            normal_calorie_TextCircle_ASCIIARRAY[1] = '52.png';  // set of images with numbers
            normal_calorie_TextCircle_ASCIIARRAY[2] = '53.png';  // set of images with numbers
            normal_calorie_TextCircle_ASCIIARRAY[3] = '54.png';  // set of images with numbers
            normal_calorie_TextCircle_ASCIIARRAY[4] = '55.png';  // set of images with numbers
            normal_calorie_TextCircle_ASCIIARRAY[5] = '56.png';  // set of images with numbers
            normal_calorie_TextCircle_ASCIIARRAY[6] = '57.png';  // set of images with numbers
            normal_calorie_TextCircle_ASCIIARRAY[7] = '58.png';  // set of images with numbers
            normal_calorie_TextCircle_ASCIIARRAY[8] = '59.png';  // set of images with numbers
            normal_calorie_TextCircle_ASCIIARRAY[9] = '60.png';  // set of images with numbers

            //start of ignored block
            for (let i = 0; i < 4; i++) {
              normal_calorie_TextCircle[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 466,
                h: 466,
                center_x: 233,
                center_y: 233,
                pos_x: 233 - normal_calorie_TextCircle_img_width / 2,
                pos_y: 233 + 175,
                src: '51.png',
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
              normal_calorie_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
            };
            //end of ignored block
            
            const calorie = hmSensor.createSensor(hmSensor.id.CALORIE);
            calorie.addEventListener(hmSensor.event.CHANGE, function() {
              text_update();
            });

            // normal_step_text_circle_img = hmUI.createWidget(hmUI.widget.Text_Circle, {
              // circle_center_X: 233,
              // circle_center_Y: 233,
              // font_array: ["51.png","52.png","53.png","54.png","55.png","56.png","57.png","58.png","59.png","60.png"],
              // radius: 176,
              // angle: 30,
              // char_space_angle: 0,
              // zero: false,
              // reverse_direction: false,
              // unit_in_alignment: true,
              // vertical_alignment: BOTTOM,
              // horizontal_alignment: LEFT,
              // type: hmUI.data_type.STEP,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_step_TextCircle_ASCIIARRAY[0] = '51.png';  // set of images with numbers
            normal_step_TextCircle_ASCIIARRAY[1] = '52.png';  // set of images with numbers
            normal_step_TextCircle_ASCIIARRAY[2] = '53.png';  // set of images with numbers
            normal_step_TextCircle_ASCIIARRAY[3] = '54.png';  // set of images with numbers
            normal_step_TextCircle_ASCIIARRAY[4] = '55.png';  // set of images with numbers
            normal_step_TextCircle_ASCIIARRAY[5] = '56.png';  // set of images with numbers
            normal_step_TextCircle_ASCIIARRAY[6] = '57.png';  // set of images with numbers
            normal_step_TextCircle_ASCIIARRAY[7] = '58.png';  // set of images with numbers
            normal_step_TextCircle_ASCIIARRAY[8] = '59.png';  // set of images with numbers
            normal_step_TextCircle_ASCIIARRAY[9] = '60.png';  // set of images with numbers

            //start of ignored block
            for (let i = 0; i < 5; i++) {
              normal_step_TextCircle[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 466,
                h: 466,
                center_x: 233,
                center_y: 233,
                pos_x: 233 - normal_step_TextCircle_img_width / 2,
                pos_y: 233 - 216,
                src: '51.png',
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
              normal_step_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
            };
            //end of ignored block
            
            const step = hmSensor.createSensor(hmSensor.id.STEP);
            step.addEventListener(hmSensor.event.CHANGE, function() {
              text_update();
            });

            // normal_battery_text_circle_img = hmUI.createWidget(hmUI.widget.Text_Circle, {
              // circle_center_X: 233,
              // circle_center_Y: 233,
              // font_array: ["51.png","52.png","53.png","54.png","55.png","56.png","57.png","58.png","59.png","60.png"],
              // radius: 217,
              // angle: -113,
              // char_space_angle: 2,
              // zero: false,
              // reverse_direction: true,
              // unit_in_alignment: true,
              // vertical_alignment: BOTTOM,
              // horizontal_alignment: RIGHT,
              // type: hmUI.data_type.BATTERY,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_battery_TextCircle_ASCIIARRAY[0] = '51.png';  // set of images with numbers
            normal_battery_TextCircle_ASCIIARRAY[1] = '52.png';  // set of images with numbers
            normal_battery_TextCircle_ASCIIARRAY[2] = '53.png';  // set of images with numbers
            normal_battery_TextCircle_ASCIIARRAY[3] = '54.png';  // set of images with numbers
            normal_battery_TextCircle_ASCIIARRAY[4] = '55.png';  // set of images with numbers
            normal_battery_TextCircle_ASCIIARRAY[5] = '56.png';  // set of images with numbers
            normal_battery_TextCircle_ASCIIARRAY[6] = '57.png';  // set of images with numbers
            normal_battery_TextCircle_ASCIIARRAY[7] = '58.png';  // set of images with numbers
            normal_battery_TextCircle_ASCIIARRAY[8] = '59.png';  // set of images with numbers
            normal_battery_TextCircle_ASCIIARRAY[9] = '60.png';  // set of images with numbers

            //start of ignored block
            for (let i = 0; i < 3; i++) {
              normal_battery_TextCircle[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 466,
                h: 466,
                center_x: 233,
                center_y: 233,
                pos_x: 233 - normal_battery_TextCircle_img_width / 2,
                pos_y: 233 + 177,
                src: '51.png',
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
              normal_battery_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
            };
            //end of ignored block
            
            const battery = hmSensor.createSensor(hmSensor.id.BATTERY);
            battery.addEventListener(hmSensor.event.CHANGE, function() {
              text_update();
            });

            normal_system_lock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 216,
              y: 362,
              src: 'can4.png',
              type: hmUI.system_status.LOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 345,
              y: 296,
              src: 'BT2.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 93,
              y: 299,
              src: 'alar20.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sun_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 185,
              y: 93,
              font_array: ["b0.png","b1.png","b2.png","b3.png","b4.png","b5.png","b6.png","b7.png","b8.png","b9.png"],
              padding: false,
              h_space: 0,
              dot_image: 'Puntos.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.SUN_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_moon_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 334,
              y: 144,
              image_array: ["fase1.png","fase2.png","fase3.png","fase4.png","fase5.png","fase6.png","fase7.png","fase8.png"],
              image_length: 8,
              type: hmUI.data_type.MOON,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 189,
              y: 147,
              font_array: ["51.png","52.png","53.png","54.png","55.png","56.png","57.png","58.png","59.png","60.png"],
              padding: false,
              h_space: 0,
              unit_sc: '0044.png',
              unit_tc: '0044.png',
              unit_en: '0044.png',
              negative_image: '0024.png',
              invalid_image: 'invalid.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 94,
              y: 138,
              image_array: ["0124.png","0125.png","0126.png","0127.png","0128.png","0129.png","0130.png","0131.png","0132.png","0133.png","0134.png","0135.png","0136.png","0137.png","0138.png","0139.png","0140.png","0141.png","0142.png","0143.png","0144.png","0145.png","0146.png","0147.png","0148.png","0149.png","0150.png","0151.png","0152.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_month_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 275,
              month_startY: 300,
              month_sc_array: ["mes01.png","mes02.png","mes03.png","mes04.png","mes05.png","mes06.png","mes07.png","mes08.png","mes09.png","mes10.png","mes11.png","mes12.png"],
              month_tc_array: ["mes01.png","mes02.png","mes03.png","mes04.png","mes05.png","mes06.png","mes07.png","mes08.png","mes09.png","mes10.png","mes11.png","mes12.png"],
              month_en_array: ["mes01.png","mes02.png","mes03.png","mes04.png","mes05.png","mes06.png","mes07.png","mes08.png","mes09.png","mes10.png","mes11.png","mes12.png"],
              month_is_character: true ,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 217,
              day_startY: 299,
              day_sc_array: ["b0.png","b1.png","b2.png","b3.png","b4.png","b5.png","b6.png","b7.png","b8.png","b9.png"],
              day_tc_array: ["b0.png","b1.png","b2.png","b3.png","b4.png","b5.png","b6.png","b7.png","b8.png","b9.png"],
              day_en_array: ["b0.png","b1.png","b2.png","b3.png","b4.png","b5.png","b6.png","b7.png","b8.png","b9.png"],
              day_zero: 1,
              day_space: 0,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 128,
              y: 300,
              week_en: ["dia1.png","dia2.png","dia3.png","dia4.png","dia5.png","dia6.png","dia7.png"],
              week_tc: ["dia1.png","dia2.png","dia3.png","dia4.png","dia5.png","dia6.png","dia7.png"],
              week_sc: ["dia1.png","dia2.png","dia3.png","dia4.png","dia5.png","dia6.png","dia7.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time_AmPm = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              am_x: 213,
              am_y: 65,
              am_sc_path: '33.png',
              am_en_path: '33.png',
              pm_x: 213,
              pm_y: 65,
              pm_sc_path: '34.png',
              pm_en_path: '34.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 81,
              hour_startY: 203,
              hour_array: ["0003.png","0004.png","0005.png","0006.png","0007.png","0008.png","0009.png","0010.png","0011.png","0012.png"],
              hour_zero: 1,
              hour_space: 0,
              hour_angle: 0,
              hour_align: hmUI.align.CENTER_H,

              minute_startX: 242,
              minute_startY: 203,
              minute_array: ["0003.png","0004.png","0005.png","0006.png","0007.png","0008.png","0009.png","0010.png","0011.png","0012.png"],
              minute_zero: 1,
              minute_space: 0,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.CENTER_H,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_second = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              second_path: 'Segb3.png',
              second_centerX: 233,
              second_centerY: 233,
              second_posX: 41,
              second_posY: 233,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });



            // idle_battery_text_circle_img = hmUI.createWidget(hmUI.widget.Text_Circle, {
              // circle_center_X: 233,
              // circle_center_Y: 233,
              // font_array: ["51.png","52.png","53.png","54.png","55.png","56.png","57.png","58.png","59.png","60.png"],
              // radius: 231,
              // angle: -113,
              // char_space_angle: 2,
              // unit: '0053.png',
              // zero: false,
              // reverse_direction: true,
              // unit_in_alignment: true,
              // vertical_alignment: BOTTOM,
              // horizontal_alignment: RIGHT,
              // type: hmUI.data_type.BATTERY,
              // show_level: hmUI.show_level.ONLY_AOD,
            // });

            idle_battery_TextCircle_ASCIIARRAY[0] = '51.png';  // set of images with numbers
            idle_battery_TextCircle_ASCIIARRAY[1] = '52.png';  // set of images with numbers
            idle_battery_TextCircle_ASCIIARRAY[2] = '53.png';  // set of images with numbers
            idle_battery_TextCircle_ASCIIARRAY[3] = '54.png';  // set of images with numbers
            idle_battery_TextCircle_ASCIIARRAY[4] = '55.png';  // set of images with numbers
            idle_battery_TextCircle_ASCIIARRAY[5] = '56.png';  // set of images with numbers
            idle_battery_TextCircle_ASCIIARRAY[6] = '57.png';  // set of images with numbers
            idle_battery_TextCircle_ASCIIARRAY[7] = '58.png';  // set of images with numbers
            idle_battery_TextCircle_ASCIIARRAY[8] = '59.png';  // set of images with numbers
            idle_battery_TextCircle_ASCIIARRAY[9] = '60.png';  // set of images with numbers

            //start of ignored block
            for (let i = 0; i < 3; i++) {
              idle_battery_TextCircle[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 466,
                h: 466,
                center_x: 233,
                center_y: 233,
                pos_x: 233 - idle_battery_TextCircle_img_width / 2,
                pos_y: 233 + 191,
                src: '51.png',
                show_level: hmUI.show_level.ONLY_AOD,
              });
              idle_battery_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
            };

            idle_battery_TextCircle_unit = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 466,
              h: 466,
              center_x: 233,
              center_y: 233,
              pos_x: 233 - idle_battery_TextCircle_unit_width / 2,
              pos_y: 233 + 191,
              src: '0053.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });
            idle_battery_TextCircle_unit.setProperty(hmUI.prop.VISIBLE, false);
            //end of ignored block

            idle_system_lock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 216,
              y: 362,
              src: 'can4.png',
              type: hmUI.system_status.LOCK,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 345,
              y: 296,
              src: 'BT2.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 93,
              y: 299,
              src: 'alar20.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_sun_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 185,
              y: 148,
              font_array: ["b0.png","b1.png","b2.png","b3.png","b4.png","b5.png","b6.png","b7.png","b8.png","b9.png"],
              padding: false,
              h_space: 0,
              dot_image: 'Puntos.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.SUN_CURRENT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_moon_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 316,
              y: 142,
              image_array: ["fase1.png","fase2.png","fase3.png","fase4.png","fase5.png","fase6.png","fase7.png","fase8.png"],
              image_length: 8,
              type: hmUI.data_type.MOON,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_month_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 275,
              month_startY: 300,
              month_sc_array: ["mes01.png","mes02.png","mes03.png","mes04.png","mes05.png","mes06.png","mes07.png","mes08.png","mes09.png","mes10.png","mes11.png","mes12.png"],
              month_tc_array: ["mes01.png","mes02.png","mes03.png","mes04.png","mes05.png","mes06.png","mes07.png","mes08.png","mes09.png","mes10.png","mes11.png","mes12.png"],
              month_en_array: ["mes01.png","mes02.png","mes03.png","mes04.png","mes05.png","mes06.png","mes07.png","mes08.png","mes09.png","mes10.png","mes11.png","mes12.png"],
              month_is_character: true ,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 217,
              day_startY: 299,
              day_sc_array: ["b0.png","b1.png","b2.png","b3.png","b4.png","b5.png","b6.png","b7.png","b8.png","b9.png"],
              day_tc_array: ["b0.png","b1.png","b2.png","b3.png","b4.png","b5.png","b6.png","b7.png","b8.png","b9.png"],
              day_en_array: ["b0.png","b1.png","b2.png","b3.png","b4.png","b5.png","b6.png","b7.png","b8.png","b9.png"],
              day_zero: 1,
              day_space: 0,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 128,
              y: 300,
              week_en: ["dia1.png","dia2.png","dia3.png","dia4.png","dia5.png","dia6.png","dia7.png"],
              week_tc: ["dia1.png","dia2.png","dia3.png","dia4.png","dia5.png","dia6.png","dia7.png"],
              week_sc: ["dia1.png","dia2.png","dia3.png","dia4.png","dia5.png","dia6.png","dia7.png"],
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time_AmPm = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              am_x: 210,
              am_y: 126,
              am_sc_path: '33.png',
              am_en_path: '33.png',
              pm_x: 210,
              pm_y: 126,
              pm_sc_path: '34.png',
              pm_en_path: '34.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 81,
              hour_startY: 203,
              hour_array: ["0003.png","0004.png","0005.png","0006.png","0007.png","0008.png","0009.png","0010.png","0011.png","0012.png"],
              hour_zero: 1,
              hour_space: 0,
              hour_angle: 0,
              hour_align: hmUI.align.CENTER_H,

              minute_startX: 242,
              minute_startY: 203,
              minute_array: ["0003.png","0004.png","0005.png","0006.png","0007.png","0008.png","0009.png","0010.png","0011.png","0012.png"],
              minute_zero: 1,
              minute_space: 0,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.CENTER_H,

              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_minute_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'sharp.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });
            
            // disconnectAlert = hmUI.createWidget(hmUI.widget.DisconnectAlert, {
              // disconneсnt_vibrate_type: 0,
              // disconneсnt_toast_text: BT DESC.\r\n,
              // conneсnt_vibrate_type: 0,
            // });

            // vibration when connecting or disconnecting

            function checkConnection() {
              hmBle.removeListener;
              hmBle.addListener(function (status) {
                if(!status) {
                  hmUI.showToast({text: "BT DESC.\r\n"});
                  vibro(0);
                }
                if(status) {
                  vibro(0);
                }
              });
            }

            // end vibration when connecting or disconnecting
            // vibrate function

            const vibrate = hmSensor.createSensor(hmSensor.id.VIBRATE);
            let timer_StopVibrate = null;


            function vibro(scene = 25) {
              let stopDelay = 50;
              stopVibro();
              vibrate.stop();
              vibrate.scene = scene;
              if(scene < 23 || scene > 25) stopDelay = 1300;
              vibrate.start();
              timer_StopVibrate = timer.createTimer(stopDelay, 3000, stopVibro, {});
            }

            function stopVibro(){
              vibrate.stop();
              if(timer_StopVibrate) timer.stopTimer(timer_StopVibrate);
            }

            // end vibrate function

            normal_alarm_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 84,
              y: 292,
              w: 40,
              h: 40,
              type: hmUI.data_type.ALARM_CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sunrise_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 153,
              y: 86,
              w: 160,
              h: 40,
              type: hmUI.data_type.SUN_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_altimeter_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 331,
              y: 139,
              w: 50,
              h: 50,
              type: hmUI.data_type.ALTIMETER,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 105,
              y: 140,
              w: 170,
              h: 50,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 370,
              y: 227,
              w: 100,
              h: 100,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 320,
              y: 34,
              w: 100,
              h: 100,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            Button_1 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 254,
              y: 332,
              w: 60,
              h: 60,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'transparent.png',
              normal_src: 'transparent.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'HidcameraScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_2 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 155,
              y: 332,
              w: 60,
              h: 60,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'transparent.png',
              normal_src: 'transparent.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'PhoneHomeScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            let screenType = hmSetting.getScreenType();
            function text_update() {

              console.log('update text circle DISTANCE');
              let distanceCurrent = distance.current;
              let normal_distance_circle_string = (distanceCurrent / 1000).toFixed(2);

              if (screenType != hmSetting.screen_type.AOD) {
                for (var i = 1; i < 5; i++) {  // hide all symbols
                  normal_distance_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                let char_Angle = -41;
                if (distanceCurrent != null && distanceCurrent != undefined && isFinite(distanceCurrent) && normal_distance_circle_string.length > 0 && normal_distance_circle_string.length < 6) {  // display data if it was possible to get it
                  let normal_distance_TextCircle_img_angle = 0;
                  let normal_distance_TextCircle_dot_img_angle = 0;
                  normal_distance_TextCircle_img_angle = toDegree(Math.atan2(normal_distance_TextCircle_img_width/2, 178));
                  normal_distance_TextCircle_dot_img_angle = toDegree(Math.atan2(normal_distance_TextCircle_dot_width/2, 178));
                  
                  let firstSymbol = true;
                  let index = 0;
                  for (let char of normal_distance_circle_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 5) break;
                    if (charCode >= 0 && charCode < 10) { 
                      if (!firstSymbol) char_Angle += normal_distance_TextCircle_img_angle;
                      firstSymbol = false;
                      normal_distance_TextCircle[index].setProperty(hmUI.prop.ANGLE, char_Angle);
                      normal_distance_TextCircle[index].setProperty(hmUI.prop.POS_X, 233 - normal_distance_TextCircle_img_width / 2);
                      normal_distance_TextCircle[index].setProperty(hmUI.prop.SRC, normal_distance_TextCircle_ASCIIARRAY[charCode]);
                      normal_distance_TextCircle[index].setProperty(hmUI.prop.VISIBLE, true);
                      char_Angle += normal_distance_TextCircle_img_angle;
                      index++;
                    }  // end if digit
                    else { 
                      if (!firstSymbol) char_Angle += normal_distance_TextCircle_dot_img_angle; 
                      firstSymbol = false;
                      normal_distance_TextCircle[index].setProperty(hmUI.prop.ANGLE, char_Angle);
                      normal_distance_TextCircle[index].setProperty(hmUI.prop.POS_X, 233 - normal_distance_TextCircle_dot_width / 2);
                      normal_distance_TextCircle[index].setProperty(hmUI.prop.SRC, 'Punto2.png');
                      normal_distance_TextCircle[index].setProperty(hmUI.prop.VISIBLE, true);
                      char_Angle += normal_distance_TextCircle_dot_img_angle;
                      index++;
                    };  // end if dot point 
                  };  // end char of string
                }  // end isFinite

              };

              console.log('update text circle heart_rate_HEART');
              let valueHeartRate = heart_rate.last;
              let normal_heart_rate_circle_string = parseInt(valueHeartRate).toString();

              if (screenType != hmSetting.screen_type.AOD) {
                for (var i = 1; i < 3; i++) {  // hide all symbols
                  normal_heart_rate_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                let char_Angle = 283;
                if (valueHeartRate != null && valueHeartRate != undefined && isFinite(valueHeartRate) && normal_heart_rate_circle_string.length > 0 && normal_heart_rate_circle_string.length < 6) {  // display data if it was possible to get it
                  let normal_heart_rate_TextCircle_img_angle = 0;
                  let normal_heart_rate_TextCircle_dot_img_angle = 0;
                  normal_heart_rate_TextCircle_img_angle = toDegree(Math.atan2(normal_heart_rate_TextCircle_img_width/2, 216));
                  // alignment = RIGHT
                  let normal_heart_rate_TextCircle_angleOffset = normal_heart_rate_TextCircle_img_angle * (normal_heart_rate_circle_string.length - 1);
                  normal_heart_rate_TextCircle_angleOffset = normal_heart_rate_TextCircle_angleOffset + 2 * (normal_heart_rate_circle_string.length - 1) / 2;
                  normal_heart_rate_TextCircle_angleOffset = -normal_heart_rate_TextCircle_angleOffset;
                  char_Angle -= 2 * normal_heart_rate_TextCircle_angleOffset;
                  // alignment end
                  
                  let firstSymbol = true;
                  let index = 0;
                  for (let char of normal_heart_rate_circle_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 3) break;
                    if (charCode >= 0 && charCode < 10) { 
                      if (!firstSymbol) char_Angle -= normal_heart_rate_TextCircle_img_angle;
                      firstSymbol = false;
                      normal_heart_rate_TextCircle[index].setProperty(hmUI.prop.ANGLE, char_Angle);
                      normal_heart_rate_TextCircle[index].setProperty(hmUI.prop.POS_X, 233 - normal_heart_rate_TextCircle_img_width / 2);
                      normal_heart_rate_TextCircle[index].setProperty(hmUI.prop.SRC, normal_heart_rate_TextCircle_ASCIIARRAY[charCode]);
                      normal_heart_rate_TextCircle[index].setProperty(hmUI.prop.VISIBLE, true);
                      char_Angle -= normal_heart_rate_TextCircle_img_angle + 2;
                      index++;
                    };  // end if digit
                  };  // end char of string
                }  // end isFinite

              };

              console.log('update text circle calorie_CALORIE');
              let valueCalories = calorie.current;
              let normal_calorie_circle_string = parseInt(valueCalories).toString();

              if (screenType != hmSetting.screen_type.AOD) {
                for (var i = 1; i < 4; i++) {  // hide all symbols
                  normal_calorie_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                let char_Angle = 355;
                if (valueCalories != null && valueCalories != undefined && isFinite(valueCalories) && normal_calorie_circle_string.length > 0 && normal_calorie_circle_string.length < 6) {  // display data if it was possible to get it
                  let normal_calorie_TextCircle_img_angle = 0;
                  let normal_calorie_TextCircle_dot_img_angle = 0;
                  normal_calorie_TextCircle_img_angle = toDegree(Math.atan2(normal_calorie_TextCircle_img_width/2, 215));
                  // alignment = RIGHT
                  let normal_calorie_TextCircle_angleOffset = normal_calorie_TextCircle_img_angle * (normal_calorie_circle_string.length - 1);
                  normal_calorie_TextCircle_angleOffset = normal_calorie_TextCircle_angleOffset + 2 * (normal_calorie_circle_string.length - 1) / 2;
                  normal_calorie_TextCircle_angleOffset = -normal_calorie_TextCircle_angleOffset;
                  char_Angle -= 2 * normal_calorie_TextCircle_angleOffset;
                  // alignment end
                  
                  let firstSymbol = true;
                  let index = 0;
                  for (let char of normal_calorie_circle_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 4) break;
                    if (charCode >= 0 && charCode < 10) { 
                      if (!firstSymbol) char_Angle -= normal_calorie_TextCircle_img_angle;
                      firstSymbol = false;
                      normal_calorie_TextCircle[index].setProperty(hmUI.prop.ANGLE, char_Angle);
                      normal_calorie_TextCircle[index].setProperty(hmUI.prop.POS_X, 233 - normal_calorie_TextCircle_img_width / 2);
                      normal_calorie_TextCircle[index].setProperty(hmUI.prop.SRC, normal_calorie_TextCircle_ASCIIARRAY[charCode]);
                      normal_calorie_TextCircle[index].setProperty(hmUI.prop.VISIBLE, true);
                      char_Angle -= normal_calorie_TextCircle_img_angle + 2;
                      index++;
                    };  // end if digit
                  };  // end char of string
                }  // end isFinite

              };

              console.log('update text circle step_STEP');
              let valueStep = step.current;
              let normal_step_circle_string = parseInt(valueStep).toString();

              if (screenType != hmSetting.screen_type.AOD) {
                for (var i = 1; i < 5; i++) {  // hide all symbols
                  normal_step_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                let char_Angle = 30;
                if (valueStep != null && valueStep != undefined && isFinite(valueStep) && normal_step_circle_string.length > 0 && normal_step_circle_string.length < 6) {  // display data if it was possible to get it
                  let normal_step_TextCircle_img_angle = 0;
                  let normal_step_TextCircle_dot_img_angle = 0;
                  normal_step_TextCircle_img_angle = toDegree(Math.atan2(normal_step_TextCircle_img_width/2, 176));
                  
                  let firstSymbol = true;
                  let index = 0;
                  for (let char of normal_step_circle_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 5) break;
                    if (charCode >= 0 && charCode < 10) { 
                      if (!firstSymbol) char_Angle += normal_step_TextCircle_img_angle;
                      firstSymbol = false;
                      normal_step_TextCircle[index].setProperty(hmUI.prop.ANGLE, char_Angle);
                      normal_step_TextCircle[index].setProperty(hmUI.prop.POS_X, 233 - normal_step_TextCircle_img_width / 2);
                      normal_step_TextCircle[index].setProperty(hmUI.prop.SRC, normal_step_TextCircle_ASCIIARRAY[charCode]);
                      normal_step_TextCircle[index].setProperty(hmUI.prop.VISIBLE, true);
                      char_Angle += normal_step_TextCircle_img_angle;
                      index++;
                    };  // end if digit
                  };  // end char of string
                }  // end isFinite

              };

              console.log('update text circle battery_BATTERY');
              let valueBattery = battery.current;
              let normal_battery_circle_string = parseInt(valueBattery).toString();

              if (screenType != hmSetting.screen_type.AOD) {
                for (var i = 1; i < 3; i++) {  // hide all symbols
                  normal_battery_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                let char_Angle = 67;
                if (valueBattery != null && valueBattery != undefined && isFinite(valueBattery) && normal_battery_circle_string.length > 0 && normal_battery_circle_string.length < 6) {  // display data if it was possible to get it
                  let normal_battery_TextCircle_img_angle = 0;
                  let normal_battery_TextCircle_dot_img_angle = 0;
                  normal_battery_TextCircle_img_angle = toDegree(Math.atan2(normal_battery_TextCircle_img_width/2, 217));
                  // alignment = RIGHT
                  let normal_battery_TextCircle_angleOffset = normal_battery_TextCircle_img_angle * (normal_battery_circle_string.length - 1);
                  normal_battery_TextCircle_angleOffset = normal_battery_TextCircle_angleOffset + 2 * (normal_battery_circle_string.length - 1) / 2;
                  normal_battery_TextCircle_angleOffset = -normal_battery_TextCircle_angleOffset;
                  char_Angle -= 2 * normal_battery_TextCircle_angleOffset;
                  // alignment end
                  
                  let firstSymbol = true;
                  let index = 0;
                  for (let char of normal_battery_circle_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 3) break;
                    if (charCode >= 0 && charCode < 10) { 
                      if (!firstSymbol) char_Angle -= normal_battery_TextCircle_img_angle;
                      firstSymbol = false;
                      normal_battery_TextCircle[index].setProperty(hmUI.prop.ANGLE, char_Angle);
                      normal_battery_TextCircle[index].setProperty(hmUI.prop.POS_X, 233 - normal_battery_TextCircle_img_width / 2);
                      normal_battery_TextCircle[index].setProperty(hmUI.prop.SRC, normal_battery_TextCircle_ASCIIARRAY[charCode]);
                      normal_battery_TextCircle[index].setProperty(hmUI.prop.VISIBLE, true);
                      char_Angle -= normal_battery_TextCircle_img_angle + 2;
                      index++;
                    };  // end if digit
                  };  // end char of string
                }  // end isFinite

              };

              console.log('update text circle battery_BATTERY');
              let idle_battery_circle_string = parseInt(valueBattery).toString();

              if (screenType == hmSetting.screen_type.AOD) {
                for (var i = 1; i < 3; i++) {  // hide all symbols
                  idle_battery_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                idle_battery_TextCircle_unit.setProperty(hmUI.prop.VISIBLE, false);
                let char_Angle = 67;
                if (valueBattery != null && valueBattery != undefined && isFinite(valueBattery) && idle_battery_circle_string.length > 0 && idle_battery_circle_string.length < 6) {  // display data if it was possible to get it
                  let idle_battery_TextCircle_img_angle = 0;
                  let idle_battery_TextCircle_dot_img_angle = 0;
                  let idle_battery_TextCircle_unit_angle = 0;
                  idle_battery_TextCircle_img_angle = toDegree(Math.atan2(idle_battery_TextCircle_img_width/2, 231));
                  idle_battery_TextCircle_unit_angle = toDegree(Math.atan2(idle_battery_TextCircle_unit_width/2, 231));
                  // alignment = RIGHT
                  let idle_battery_TextCircle_angleOffset = idle_battery_TextCircle_img_angle * (idle_battery_circle_string.length - 1);
                  idle_battery_TextCircle_angleOffset = idle_battery_TextCircle_angleOffset + 2 * (idle_battery_circle_string.length - 1) / 2;
                  idle_battery_TextCircle_angleOffset = idle_battery_TextCircle_angleOffset + (idle_battery_TextCircle_img_angle + idle_battery_TextCircle_unit_angle + 2) / 2;
                  idle_battery_TextCircle_angleOffset = -idle_battery_TextCircle_angleOffset;
                  char_Angle -= 2 * idle_battery_TextCircle_angleOffset;
                  // alignment end
                  
                  let firstSymbol = true;
                  let index = 0;
                  for (let char of idle_battery_circle_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 3) break;
                    if (charCode >= 0 && charCode < 10) { 
                      if (!firstSymbol) char_Angle -= idle_battery_TextCircle_img_angle;
                      firstSymbol = false;
                      idle_battery_TextCircle[index].setProperty(hmUI.prop.ANGLE, char_Angle);
                      idle_battery_TextCircle[index].setProperty(hmUI.prop.POS_X, 233 - idle_battery_TextCircle_img_width / 2);
                      idle_battery_TextCircle[index].setProperty(hmUI.prop.SRC, idle_battery_TextCircle_ASCIIARRAY[charCode]);
                      idle_battery_TextCircle[index].setProperty(hmUI.prop.VISIBLE, true);
                      char_Angle -= idle_battery_TextCircle_img_angle + 2;
                      index++;
                    };  // end if digit
                  };  // end char of string
                  char_Angle -= idle_battery_TextCircle_unit_angle;
                  idle_battery_TextCircle_unit.setProperty(hmUI.prop.ANGLE, char_Angle);
                  idle_battery_TextCircle_unit.setProperty(hmUI.prop.VISIBLE, true);
                }  // end isFinite

              };

            };

            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                text_update();
                checkConnection();
                stopVibro();

              }),
              pause_call: (function () {
                stopVibro();

              }),
            });

                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}