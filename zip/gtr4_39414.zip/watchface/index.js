﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (()=>{
        //dynamic modify start

        const lang = DeviceRuntimeCore.HmUtils.getLanguage()
        let normal_system_disconnect_img = ''
		let normal_frame_animation_1 = ''
        let normal_battery_text_text_img = ''
        let normal_battery_text_separator_img = ''
        let normal_heart_rate_text_text_img = ''
        let normal_heart_rate_text_separator_img = ''
        let normal_calorie_current_text_img = ''
        let normal_calorie_current_separator_img = ''
        let normal_step_current_text_img = ''
        let normal_step_current_separator_img = ''
        let normal_date_img_date_week_img = ''
        let normal_date_img_date_month = ''
        let normal_date_img_date_day = ''
        let normal_digital_clock_img_time = ''
        let idle_background_bg = ''
        let idle_battery_text_text_img = ''
        let idle_date_img_date_week_img = ''
        let idle_date_img_date_month = ''
        let idle_date_img_date_day = ''
        let idle_digital_clock_img_time = ''
        let normal_heart_jumpable_img_click = ''
        let normal_step_jumpable_img_click = ''
		
		let zodiacIndex = 1;
		let zodiac_img = ''
		

		function hide(widget) {
			widget.setProperty(hmUI.prop.VISIBLE, false);
		}

		function show(widget) {
			widget.setProperty(hmUI.prop.VISIBLE, true);
		}

		function toggleZodiac(widget) {
			zodiacIndex = (zodiacIndex + 1) % 3;
			console.log('zodiacIndex: ' + zodiacIndex);
			const isRunning = normal_frame_animation_1.getProperty(hmUI.prop.ANIM_IS_RUNINNG);
			if (isRunning) {
				normal_frame_animation_1.setProperty(hmUI.prop.ANIM_STATUS, hmUI.anim_status.STOP);
			};

			zodiac_img.setProperty(hmUI.prop.SRC, `bg/bg_${zodiacIndex}.png`);
            normal_frame_animation_1.setProperty(hmUI.prop.MORE, {
              x: 0,
              y: 0,
              anim_path: `animation/${zodiacIndex}`,
              anim_ext: "png",
              anim_prefix: "Charge",
              anim_fps: 25,
              anim_size: 39,
              repeat_count: 0,
              anim_repeat: false,
			  anim_complete_call: () => {
				show(zodiac_img);
			  },
			  anim_status:hmUI.anim_status.STOP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
			normal_frame_animation_1.setProperty(hmUI.prop.ANIM_STATUS,hmUI.anim_status.START);
		}
		
		let btn_zona1 = ''
        let zona1_num = 0
        let zona1_all = 3
		
		function click_zona1() {
		  zona1_num = (zona1_num + 1) % (zona1_all + 1);
          if (zona1_num == 0) {		
		    normal_step_current_text_img.setProperty(hmUI.prop.VISIBLE, true);
            normal_step_current_separator_img.setProperty(hmUI.prop.VISIBLE, true);
			normal_calorie_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_calorie_current_separator_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_heart_rate_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_heart_rate_text_separator_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_battery_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_battery_text_separator_img.setProperty(hmUI.prop.VISIBLE, false);
		    hmUI.showToast({
            });
          };
		  
		 if (zona1_num == 1) {
			normal_step_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
            normal_step_current_separator_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_calorie_current_text_img.setProperty(hmUI.prop.VISIBLE, true);
			normal_calorie_current_separator_img.setProperty(hmUI.prop.VISIBLE, true);
			normal_heart_rate_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_heart_rate_text_separator_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_battery_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_battery_text_separator_img.setProperty(hmUI.prop.VISIBLE, false);
		    hmUI.showToast({
            });
          };
		  
		  if (zona1_num == 2) {
			normal_step_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
            normal_step_current_separator_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_calorie_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_calorie_current_separator_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_heart_rate_text_text_img.setProperty(hmUI.prop.VISIBLE, true);
			normal_heart_rate_text_separator_img.setProperty(hmUI.prop.VISIBLE, true);
			normal_battery_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_battery_text_separator_img.setProperty(hmUI.prop.VISIBLE, false);
		    hmUI.showToast({
            });
          };
		  
		  if (zona1_num == 3) {
			normal_step_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
            normal_step_current_separator_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_calorie_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_calorie_current_separator_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_heart_rate_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_heart_rate_text_separator_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_battery_text_text_img.setProperty(hmUI.prop.VISIBLE, true);
			normal_battery_text_separator_img.setProperty(hmUI.prop.VISIBLE, true);
		    hmUI.showToast({
            });
          };
        }


        //dynamic modify end
        const e = __$$hmAppManager$$__.currentApp;
        const o = e.current
          , {px: i} = (new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(e,o)),
        e.__globals__)
          , n = Logger.getLogger("watchface6");
        o.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            console.log('Watch_Face.ScreenNormal');
             hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 466,
              h: 466,
              src: 'bg.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
			
			normal_frame_animation_1 = hmUI.createWidget(hmUI.widget.IMG_ANIM, {
              x: 0,
              y: 0,
              anim_path: `animation/${zodiacIndex}`,
              anim_ext: "png",
              anim_prefix: "Charge",
              anim_fps: 25,
              anim_size: 39,
              repeat_count: 0,
              anim_repeat: false,
			  anim_complete_call: () => {
				show(zodiac_img);
			  },
              anim_status:hmUI.anim_status.START,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            zodiac_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 466,
              h: 466,
              src: `bg/bg_${zodiacIndex}.png`,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 0,
              y: 0,
              src: 'bt.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 205,
              y: 345,
              font_array: ["num_0.png","num_1.png","num_2.png","num_3.png","num_4.png","num_5.png","num_6.png","num_7.png","num_8.png","num_9.png"],
              padding: false,
              h_space: -2,
              unit_sc: '%.png',
              unit_tc: '%.png',
              unit_en: '%.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 223,
              y: 320,
              src: 'A100_019.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 205,
              y: 345,
              font_array: ["num_0.png","num_1.png","num_2.png","num_3.png","num_4.png","num_5.png","num_6.png","num_7.png","num_8.png","num_9.png"],
              padding: false,
              h_space: -3,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 219,
              y: 311,
              src: 'A100_045.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_calorie_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 199,
              y: 345,
              font_array: ["num_0.png","num_1.png","num_2.png","num_3.png","num_4.png","num_5.png","num_6.png","num_7.png","num_8.png","num_9.png"],
              padding: false,
              h_space: -3,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_calorie_current_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 225,
              y: 311,
              src: 'A100_042.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 190,
              y: 345,
              font_array: ["num_0.png","num_1.png","num_2.png","num_3.png","num_4.png","num_5.png","num_6.png","num_7.png","num_8.png","num_9.png"],
              padding: false,
              h_space: -3,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 222,
              y: 311,
              src: 'A100_002.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
			
			let dned=["week_0.png","week_1.png","week_2.png","week_3.png","week_4.png","week_5.png","week_6.png"]
			if(lang=='ru-RU'){
				dned=["weekru_0.png","weekru_1.png","weekru_2.png","weekru_3.png","weekru_4.png","weekru_5.png","weekru_6.png"]
			}
            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 211,
              y: 131,
              week_en: dned,
              week_tc: ["week_0.png","week_1.png","week_2.png","week_3.png","week_4.png","week_5.png","week_6.png"],
              week_sc: ["week_0.png","week_1.png","week_2.png","week_3.png","week_4.png","week_5.png","week_6.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_month = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 238,
              month_startY: 97,
              month_sc_array: ["num_0.png","num_1.png","num_2.png","num_3.png","num_4.png","num_5.png","num_6.png","num_7.png","num_8.png","num_9.png"],
              month_tc_array: ["num_0.png","num_1.png","num_2.png","num_3.png","num_4.png","num_5.png","num_6.png","num_7.png","num_8.png","num_9.png"],
              month_en_array: ["num_0.png","num_1.png","num_2.png","num_3.png","num_4.png","num_5.png","num_6.png","num_7.png","num_8.png","num_9.png"],
              month_zero: 1,
              month_space: -5,
              month_align: hmUI.align.CENTER_H,
              month_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 191,
              day_startY: 97,
              day_sc_array: ["num_0.png","num_1.png","num_2.png","num_3.png","num_4.png","num_5.png","num_6.png","num_7.png","num_8.png","num_9.png"],
              day_tc_array: ["num_0.png","num_1.png","num_2.png","num_3.png","num_4.png","num_5.png","num_6.png","num_7.png","num_8.png","num_9.png"],
              day_en_array: ["num_0.png","num_1.png","num_2.png","num_3.png","num_4.png","num_5.png","num_6.png","num_7.png","num_8.png","num_9.png"],
              day_zero: 1,
              day_space: -5,
              day_unit_sc: 'dot_1.png',
              day_unit_tc: 'dot_1.png',
              day_unit_en: 'dot_1.png',
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 109,
              hour_startY: 183,
              hour_array: ["t_0.png","t_1.png","t_2.png","t_3.png","t_4.png","t_5.png","t_6.png","t_7.png","t_8.png","t_9.png"],
              hour_zero: 1,
              hour_space: -10,
              hour_angle: 0,
              hour_unit_sc: 'colon.png',
              hour_unit_tc: 'colon.png',
              hour_unit_en: 'colon.png',
              hour_align: hmUI.align.LEFT,

              minute_startX: 246,
              minute_startY: 183,
              minute_array: ["t_0.png","t_1.png","t_2.png","t_3.png","t_4.png","t_5.png","t_6.png","t_7.png","t_8.png","t_9.png"],
              minute_zero: 1,
              minute_space: -10,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            console.log('Watch_Face.ScreenAOD');
            idle_background_bg = hmUI.createWidget(hmUI.widget.FILL_RECT, {
              x: 0,
              y: 0,
              w: 466,
              h: 466,
              color: '0xFF000000',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 205,
              y: 97,
              font_array: ["num_0.png","num_1.png","num_2.png","num_3.png","num_4.png","num_5.png","num_6.png","num_7.png","num_8.png","num_9.png"],
              padding: false,
              h_space: -2,
              unit_sc: '%.png',
              unit_tc: '%.png',
              unit_en: '%.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 211,
              y: 335,
              week_en: ["week_0.png","week_1.png","week_2.png","week_3.png","week_4.png","week_5.png","week_6.png"],
              week_tc: ["week_0.png","week_1.png","week_2.png","week_3.png","week_4.png","week_5.png","week_6.png"],
              week_sc: ["week_0.png","week_1.png","week_2.png","week_3.png","week_4.png","week_5.png","week_6.png"],
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_month = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 238,
              month_startY: 296,
              month_sc_array: ["num_0.png","num_1.png","num_2.png","num_3.png","num_4.png","num_5.png","num_6.png","num_7.png","num_8.png","num_9.png"],
              month_tc_array: ["num_0.png","num_1.png","num_2.png","num_3.png","num_4.png","num_5.png","num_6.png","num_7.png","num_8.png","num_9.png"],
              month_en_array: ["num_0.png","num_1.png","num_2.png","num_3.png","num_4.png","num_5.png","num_6.png","num_7.png","num_8.png","num_9.png"],
              month_zero: 1,
              month_space: -5,
              month_align: hmUI.align.CENTER_H,
              month_is_character: false,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 191,
              day_startY: 296,
              day_sc_array: ["num_0.png","num_1.png","num_2.png","num_3.png","num_4.png","num_5.png","num_6.png","num_7.png","num_8.png","num_9.png"],
              day_tc_array: ["num_0.png","num_1.png","num_2.png","num_3.png","num_4.png","num_5.png","num_6.png","num_7.png","num_8.png","num_9.png"],
              day_en_array: ["num_0.png","num_1.png","num_2.png","num_3.png","num_4.png","num_5.png","num_6.png","num_7.png","num_8.png","num_9.png"],
              day_zero: 1,
              day_space: -5,
              day_unit_sc: 'dot_1.png',
              day_unit_tc: 'dot_1.png',
              day_unit_en: 'dot_1.png',
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 109,
              hour_startY: 183,
              hour_array: ["t_0.png","t_1.png","t_2.png","t_3.png","t_4.png","t_5.png","t_6.png","t_7.png","t_8.png","t_9.png"],
              hour_zero: 1,
              hour_space: -10,
              hour_angle: 0,
              hour_unit_sc: 'colon.png',
              hour_unit_tc: 'colon.png',
              hour_unit_en: 'colon.png',
              hour_align: hmUI.align.LEFT,

              minute_startX: 246,
              minute_startY: 183,
              minute_array: ["t_0.png","t_1.png","t_2.png","t_3.png","t_4.png","t_5.png","t_6.png","t_7.png","t_8.png","t_9.png"],
              minute_zero: 1,
              minute_space: -10,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_AOD,
            });
            console.log('Watch_Face.Shortcuts');

            hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 191,
              y: 192,
              w: 97,
              h: 97,
			  text: '',
			  normal_src: 'Empty.png',
			  press_src: 'Empty.png',
			  click_func: () => {
				toggleZodiac();
			  },
			});

            btn_zona1 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 197,
              y: 316,
              text: '',
              w: 87,
              h: 58,
              normal_src: 'Empty.png',
              press_src: 'Empty.png',
              click_func: () => {
				click_zona1();
                click_Vibrate();
             },
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            btn_zona1.setProperty(hmUI.prop.VISIBLE, true);
			normal_calorie_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_calorie_current_separator_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_heart_rate_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_heart_rate_text_separator_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_battery_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_battery_text_separator_img.setProperty(hmUI.prop.VISIBLE, false);
			
			const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                console.log('resume_call()');
               
                normal_frame_animation_1.setProperty(hmUI.prop.ANIM_STATUS,hmUI.anim_status.START);

              }),
              pause_call: (function () {
                console.log('pause_call()');
                
                normal_frame_animation_1.setProperty(hmUI.prop.ANIM_STATUS,hmUI.anim_status.STOP);

              }),
            });

                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}