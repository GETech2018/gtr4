﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.0.1
    ** Copyright © CashaCX75. All Rights Reserved
    */

    try {
    (()=>{
        //dynamic modify start

        
        let normal_background_bg = ''
        let normal_analog_clock_time_pointer_hour = ''
        let normal_analog_clock_time_pointer_minute = ''
        let normal_analog_clock_time_pointer_second = ''

	let img = ''  // Hintergrund
        let prefix_img = 'bg_'  // prefix image (name without sequence number)
        let img_index = 1  // image number
        let img_count = 3  // number of images

        //dynamic modify end
        const e = __$$hmAppManager$$__.currentApp;
        const o = e.current
          , {px: i} = (new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(e,o)),
        e.__globals__)
          , n = Logger.getLogger("watchface6");
        o.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 466,
              h: 466,
              src: prefix_img + parseInt(img_index) + '.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal1_analog_clock_time_pointer_hour = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              hour_path: 'Stunde_1.png',
              hour_centerX: 233,
              hour_centerY: 233,
              hour_posX: 17,
              hour_posY: 117,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal1_analog_clock_time_pointer_minute = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              minute_path: 'Minute_1.png',
              minute_centerX: 233,
              minute_centerY: 233,
              minute_posX: 16,
              minute_posY: 163,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal1_analog_clock_time_pointer_second = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              second_path: 'Sekunde_1.png',
              second_centerX: 233,
              second_centerY: 233,
              second_posX: 16,
              second_posY: 185,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal2_analog_clock_time_pointer_hour = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              hour_path: 'Stunde_2.png',
              hour_centerX: 233,
              hour_centerY: 233,
              hour_posX: 22,
              hour_posY: 137,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
	    normal2_analog_clock_time_pointer_hour.setProperty(hmUI.prop.VISIBLE, false);

            normal2_analog_clock_time_pointer_minute = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              minute_path: 'Minute_2.png',
              minute_centerX: 233,
              minute_centerY: 233,
              minute_posX: 25,
              minute_posY: 196,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            normal2_analog_clock_time_pointer_minute.setProperty(hmUI.prop.VISIBLE, false);

            normal2_analog_clock_time_pointer_second = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              second_path: 'Sekunde_2.png',
              second_centerX: 233,
              second_centerY: 233,
              second_posX: 14,
              second_posY: 206,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            normal2_analog_clock_time_pointer_second.setProperty(hmUI.prop.VISIBLE, false);

            normal3_analog_clock_time_pointer_hour = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              hour_path: 'Stunde_3.png',
              hour_centerX: 233,
              hour_centerY: 233,
              hour_posX: 24,
              hour_posY: 134,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            normal3_analog_clock_time_pointer_hour.setProperty(hmUI.prop.VISIBLE, false);

            normal3_analog_clock_time_pointer_minute = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              minute_path: 'Minute_3.png',
              minute_centerX: 233,
              minute_centerY: 233,
              minute_posX: 22,
              minute_posY: 196,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            normal3_analog_clock_time_pointer_minute.setProperty(hmUI.prop.VISIBLE, false);

            normal3_analog_clock_time_pointer_second = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              second_path: 'Sekunde_3.png',
              second_centerX: 233,
              second_centerY: 233,
              second_posX: 17,
              second_posY: 184,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            normal3_analog_clock_time_pointer_second.setProperty(hmUI.prop.VISIBLE, false);

            // Button to switch images. This block should be after all blocks with display elements.
            hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 0,  // x coordinate of the button
              y: 0,  // y coordinate of the button
              text: '',
              w: 466,  // button width
              h: 466,  // button height
              normal_src: 'leer.png',  // transparent image
              press_src: 'leer.png',  // transparent image
              show_level: hmUI.show_level.ONLY_NORMAL,
              click_func: () => {
                img_index++;
                if(img_index > img_count) img_index = 1;
                hmUI.showToast({text: 'Zifferblatt ' + parseInt(img_index) });  // Remove if you do not want to display a message with the number of the selected image
                img.setProperty(hmUI.prop.SRC, prefix_img + parseInt(img_index) + '.png');
            	normal1_analog_clock_time_pointer_hour.setProperty(hmUI.prop.VISIBLE, img_index == 1);
            	normal1_analog_clock_time_pointer_minute.setProperty(hmUI.prop.VISIBLE, img_index == 1);
          	normal1_analog_clock_time_pointer_second.setProperty(hmUI.prop.VISIBLE, img_index == 1);
            	normal2_analog_clock_time_pointer_hour.setProperty(hmUI.prop.VISIBLE, img_index == 2);
            	normal2_analog_clock_time_pointer_minute.setProperty(hmUI.prop.VISIBLE, img_index == 2);
          	normal2_analog_clock_time_pointer_second.setProperty(hmUI.prop.VISIBLE, img_index == 2);
            	normal3_analog_clock_time_pointer_hour.setProperty(hmUI.prop.VISIBLE, img_index == 3);
            	normal3_analog_clock_time_pointer_minute.setProperty(hmUI.prop.VISIBLE, img_index == 3);
          	normal3_analog_clock_time_pointer_second.setProperty(hmUI.prop.VISIBLE, img_index == 3);
              }
            });


                //dynamic modify end
            },
            onInit() {
                n.log("index page.js on init invoke")
            },
            build() {
                this.init_view(),
                n.log("index page.js on ready invoke")
            },
            onDestroy() {
                n.log("index page.js on destroy invoke")
            }
        })
    }
    )()
} catch (e) {
    console.log("Mini Program Error", e),
    e && e.stack && e.stack.split(/\n/).forEach((e=>console.log("error stack", e)))
}
