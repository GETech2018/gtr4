﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        const logger = Logger.getLogger('watchface_SashaCX75');
        //end of ignored block

        //dynamic modify start
let colornumber_main = 1
        let totalcolors_main = 20
        let namecolor_main = ''

        function click_Color() {
            if(colornumber_main>=totalcolors_main) {
            colornumber_main=1;
                }
            else {
                colornumber_main=colornumber_main+1;
            }

			
            normal_background_bg_img.setProperty(hmUI.prop.SRC, "bg" + parseInt(colornumber_main) + ".png");																											 
         
        }
        
        let normal_background_bg_img = ''
        let normal_image_img = ''
        let normal_weather_image_progress_img_level = ''
        let normal_temperature_current_text_img = ''
        let normal_date_img_date_month_img = ''
        let normal_heart_rate_text_text_img = ''
        let normal_calorie_current_text_img = ''
        let normal_battery_text_text_img = ''
        let normal_date_img_date_week_img = ''
        let normal_distance_text_text_img = ''
        let normal_step_current_text_img = ''
        let normal_date_img_date_day = ''
        let normal_digital_clock_img_time = ''
        let normal_moon_image_progress_img_level = ''
        let normal_system_disconnect_img = ''
        let normal_system_clock_img = ''
        let idle_background_bg = ''
        let idle_battery_text_text_img = ''
        let idle_digital_clock_img_time = ''
        let idle_digital_clock_img_time_AmPm = ''
        let Button_1 = ''
        let Button_2 = ''
        let Button_3 = ''
        let Button_4 = ''
        let Button_5 = ''
        let Button_6 = ''
        let Button_7 = ''


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            console.log('Watch_Face.ScreenNormal');
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 466,
              h: 466,
              src: 'bg17.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_image_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'maskaeN.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 183,
              y: 10,
              image_array: ["weather_0.png","weather_1.png","weather_2.png","weather_3.png","weather_4.png","weather_5.png","weather_6.png","weather_7.png","weather_8.png","weather_9.png","weather_10.png","weather_11.png","weather_12.png","weather_13.png","weather_14.png","weather_15.png","weather_16.png","weather_17.png","weather_18.png","weather_19.png","weather_20.png","weather_21.png","weather_22.png","weather_23.png","weather_24.png","weather_25.png","weather_26.png","weather_27.png","weather_28.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 235,
              y: 21,
              font_array: ["sm_00.png","sm_01.png","sm_02.png","sm_03.png","sm_04.png","sm_05.png","sm_06.png","sm_07.png","sm_08.png","sm_09.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'sm_tmp.png',
              unit_tc: 'sm_tmp.png',
              unit_en: 'sm_tmp.png',
              imperial_unit_sc: 'sm_tmp.png',
              imperial_unit_tc: 'sm_tmp.png',
              imperial_unit_en: 'sm_tmp.png',
              negative_image: 'sm_min.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            const temperatureUnit = hmSetting.getTemperatureUnit();
            //start of ignored block
            if (temperatureUnit == 1) {
              normal_temperature_current_text_img.setProperty(hmUI.prop.MORE, {
                x: 235,
                y: 21,
                font_array: ["sm_00.png","sm_01.png","sm_02.png","sm_03.png","sm_04.png","sm_05.png","sm_06.png","sm_07.png","sm_08.png","sm_09.png"],
                padding: false,
                h_space: 0,
                unit_sc: 'sm_tmp.png',
                unit_tc: 'sm_tmp.png',
                unit_en: 'sm_tmp.png',
                imperial_unit_sc: 'sm_tmp.png',
                imperial_unit_tc: 'sm_tmp.png',
                imperial_unit_en: 'sm_tmp.png',
                negative_image: 'sm_min.png',
                align_h: hmUI.align.LEFT,
                type: hmUI.data_type.WEATHER_CURRENT,
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
            };
            //end of ignored block

            normal_date_img_date_month_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 268,
              month_startY: 67,
              month_sc_array: ["mthl_en_00.png","mthl_en_01.png","mthl_en_02.png","mthl_en_03.png","mthl_en_04.png","mthl_en_05.png","mthl_en_06.png","mthl_en_07.png","mthl_en_08.png","mthl_en_09.png","mthl_en_10.png","mthl_en_11.png"],
              month_tc_array: ["mthl_en_00.png","mthl_en_01.png","mthl_en_02.png","mthl_en_03.png","mthl_en_04.png","mthl_en_05.png","mthl_en_06.png","mthl_en_07.png","mthl_en_08.png","mthl_en_09.png","mthl_en_10.png","mthl_en_11.png"],
              month_en_array: ["mthl_en_00.png","mthl_en_01.png","mthl_en_02.png","mthl_en_03.png","mthl_en_04.png","mthl_en_05.png","mthl_en_06.png","mthl_en_07.png","mthl_en_08.png","mthl_en_09.png","mthl_en_10.png","mthl_en_11.png"],
              month_is_character: true ,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 60,
              y: 321,
              font_array: ["sm_00.png","sm_01.png","sm_02.png","sm_03.png","sm_04.png","sm_05.png","sm_06.png","sm_07.png","sm_08.png","sm_09.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_calorie_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 344,
              y: 321,
              font_array: ["sm_00.png","sm_01.png","sm_02.png","sm_03.png","sm_04.png","sm_05.png","sm_06.png","sm_07.png","sm_08.png","sm_09.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 195,
              y: 416,
              font_array: ["sm_00.png","sm_01.png","sm_02.png","sm_03.png","sm_04.png","sm_05.png","sm_06.png","sm_07.png","sm_08.png","sm_09.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'sm_proc2.png',
              unit_tc: 'sm_proc2.png',
              unit_en: 'sm_proc2.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 66,
              y: 67,
              week_en: ["dwl_en_00.png","dwl_en_01.png","dwl_en_02.png","dwl_en_03.png","dwl_en_04.png","dwl_en_05.png","dwl_en_06.png"],
              week_tc: ["dwl_en_00.png","dwl_en_01.png","dwl_en_02.png","dwl_en_03.png","dwl_en_04.png","dwl_en_05.png","dwl_en_06.png"],
              week_sc: ["dwl_en_00.png","dwl_en_01.png","dwl_en_02.png","dwl_en_03.png","dwl_en_04.png","dwl_en_05.png","dwl_en_06.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_distance_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 259,
              y: 360,
              font_array: ["sm_00.png","sm_01.png","sm_02.png","sm_03.png","sm_04.png","sm_05.png","sm_06.png","sm_07.png","sm_08.png","sm_09.png"],
              padding: false,
              h_space: 0,
              dot_image: 'sm_dot.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.DISTANCE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 105,
              y: 360,
              font_array: ["sm_00.png","sm_01.png","sm_02.png","sm_03.png","sm_04.png","sm_05.png","sm_06.png","sm_07.png","sm_08.png","sm_09.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 203,
              day_startY: 68,
              day_sc_array: ["med_00.png","med_01.png","med_02.png","med_03.png","med_04.png","med_05.png","med_06.png","med_07.png","med_08.png","med_09.png"],
              day_tc_array: ["med_00.png","med_01.png","med_02.png","med_03.png","med_04.png","med_05.png","med_06.png","med_07.png","med_08.png","med_09.png"],
              day_en_array: ["med_00.png","med_01.png","med_02.png","med_03.png","med_04.png","med_05.png","med_06.png","med_07.png","med_08.png","med_09.png"],
              day_zero: 1,
              day_space: 0,
              day_align: hmUI.align.LEFT,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 29,
              hour_startY: 140,
              hour_array: ["h_00.png","h_01.png","h_02.png","h_03.png","h_04.png","h_05.png","h_06.png","h_07.png","h_08.png","h_09.png"],
              hour_zero: 1,
              hour_space: 0,
              hour_angle: 0,
              hour_align: hmUI.align.LEFT,

              minute_startX: 262,
              minute_startY: 142,
              minute_array: ["min_00.png","min_01.png","min_02.png","min_03.png","min_04.png","min_05.png","min_06.png","min_07.png","min_08.png","min_09.png"],
              minute_zero: 1,
              minute_space: 0,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              second_startX: 373,
              second_startY: 140,
              second_array: ["sec_00.png","sec_01.png","sec_02.png","sec_03.png","sec_04.png","sec_05.png","sec_06.png","sec_07.png","sec_08.png","sec_09.png"],
              second_zero: 1,
              second_space: 0,
              second_angle: 0,
              second_follow: 0,
              second_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_moon_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 218,
              y: 371,
              image_array: ["Moon_01.png","Moon_02.png","Moon_03.png","Moon_04.png","Moon_05.png","Moon_06.png","Moon_07.png","Moon_08.png","Moon_09.png","Moon_10.png","Moon_11.png","Moon_12.png","Moon_13.png","Moon_14.png","Moon_15.png","Moon_16.png","Moon_17.png","Moon_18.png","Moon_19.png","Moon_20.png","Moon_21.png","Moon_22.png","Moon_23.png","Moon_24.png","Moon_25.png","Moon_26.png","Moon_27.png","Moon_28.png","Moon_29.png","Moon_30.png"],
              image_length: 30,
              type: hmUI.data_type.MOON,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 282,
              y: 421,
              src: 'bt_off.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 153,
              y: 417,
              src: 'alarm_on2.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            console.log('Watch_Face.ScreenAOD');
            idle_background_bg = hmUI.createWidget(hmUI.widget.FILL_RECT, {
              x: 0,
              y: 0,
              w: 466,
              h: 466,
              color: '0xFF000000',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 195,
              y: 416,
              font_array: ["sm_00.png","sm_01.png","sm_02.png","sm_03.png","sm_04.png","sm_05.png","sm_06.png","sm_07.png","sm_08.png","sm_09.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'sm_proc.png',
              unit_tc: 'sm_proc.png',
              unit_en: 'sm_proc.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 29,
              hour_startY: 139,
              hour_array: ["h_aod_00.png","h_aod_01.png","h_aod_02.png","h_aod_03.png","h_aod_04.png","h_aod_05.png","h_aod_06.png","h_aod_07.png","h_aod_08.png","h_aod_09.png"],
              hour_zero: 1,
              hour_space: 0,
              hour_angle: 0,
              hour_align: hmUI.align.LEFT,

              minute_startX: 262,
              minute_startY: 142,
              minute_array: ["min_aod_00.png","min_aod_01.png","min_aod_02.png","min_aod_03.png","min_aod_04.png","min_aod_05.png","min_aod_06.png","min_aod_07.png","min_aod_08.png","min_aod_09.png"],
              minute_zero: 1,
              minute_space: 0,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time_AmPm = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              am_x: 377,
              am_y: 209,
              am_sc_path: 'i_am.png',
              am_en_path: 'i_am.png',
              pm_x: 377,
              pm_y: 209,
              pm_sc_path: 'i_pm.png',
              pm_en_path: 'i_pm.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            console.log('Watch_Face.Buttons');
            Button_1 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 184,
              y: 15,
              w: 100,
              h: 39,
              text: '',
              color: 0xFFFF8C00,
              text_size: 24,
              press_src: '_WFbyTRK88PL.png',
              normal_src: '_WFbyTRK88PL.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'WeatherScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_2 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 160,
              y: 315,
              w: 150,
              h: 39,
              text: '',
              color: 0xFFFF8C00,
              text_size: 24,
              press_src: '_WFbyTRK88PL.png',
              normal_src: '_WFbyTRK88PL.png',
              click_func: (button_widget) => {
                click_Color();
				vibro(25);
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_3 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 118,
              y: 73,
              w: 229,
              h: 39,
              text: '',
              color: 0xFFFF8C00,
              text_size: 24,
              press_src: '_WFbyTRK88PL.png',
              normal_src: '_WFbyTRK88PL.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'ScheduleCalScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_4 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 374,
              y: 189,
              w: 53,
              h: 53,
              text: '',
              color: 0xFFFF8C00,
              text_size: 24,
              press_src: '_WFbyTRK88PL.png',
              normal_src: '_WFbyTRK88PL.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'CountdownAppScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_5 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 75,
              y: 314,
              w: 47,
              h: 41,
              text: '',
              color: 0xFFFF8C00,
              text_size: 24,
              press_src: '_WFbyTRK88PL.png',
              normal_src: '_WFbyTRK88PL.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'heart_app_Screen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_6 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 117,
              y: 363,
              w: 78,
              h: 47,
              text: '',
              color: 0xFFFF8C00,
              text_size: 24,
              press_src: '_WFbyTRK88PL.png',
              normal_src: '_WFbyTRK88PL.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'activityAppScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_7 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 214,
              y: 362,
              w: 39,
              h: 49,
              text: '',
              color: 0xFFFF8C00,
              text_size: 24,
              press_src: '_WFbyTRK88PL.png',
              normal_src: '_WFbyTRK88PL.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'TideScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button


                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}