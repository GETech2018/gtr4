﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        const logger = Logger.getLogger('watchface_SashaCX75');
        //end of ignored block

        //dynamic modify start

        
        let editBg = ''
        let normal_sun_high_text_img = ''
        let normal_sun_high_separator_img = ''
        let normal_sun_low_text_img = ''
        let normal_sun_low_separator_img = ''
        let normal_date_img_date_week_img = ''
        let normal_month_TextCircle = new Array(2);
        let normal_month_TextCircle_ASCIIARRAY = new Array(10);
        let normal_month_TextCircle_img_width = 24;
        let normal_month_TextCircle_img_height = 37;
        let normal_timerTextUpdate = undefined;
        let normal_day_TextCircle = new Array(2);
        let normal_day_TextCircle_ASCIIARRAY = new Array(10);
        let normal_day_TextCircle_img_width = 24;
        let normal_day_TextCircle_img_height = 37;
        let normal_heart_rate_pointer_progress_img_pointer = ''
        let normal_heart_rate_text_font = ''
        let normal_battery_pointer_progress_img_pointer = ''
        let normal_battery_current_text_font = ''
        let normal_weather_image_progress_img_level = ''
        let normal_temperature_current_text_font = ''
        let normal_moon_image_progress_img_level = ''
        let normal_step_icon_img = ''
        let normal_step_current_text_font = ''
        let normal_hour_TextCircle = new Array(2);
        let normal_hour_TextCircle_ASCIIARRAY = new Array(10);
        let normal_hour_TextCircle_img_width = 38;
        let normal_hour_TextCircle_img_height = 73;
        let normal_minute_TextCircle = new Array(2);
        let normal_minute_TextCircle_ASCIIARRAY = new Array(10);
        let normal_minute_TextCircle_img_width = 38;
        let normal_minute_TextCircle_img_height = 73;
        let normal_second_TextCircle = new Array(2);
        let normal_second_TextCircle_ASCIIARRAY = new Array(10);
        let normal_second_TextCircle_img_width = 38;
        let normal_second_TextCircle_img_height = 73;
        let idle_background_bg_img = ''
        let idle_digital_clock_img_time = ''
        let normal_cal_jumpable_img_click = ''
        let normal_heart_jumpable_img_click = ''
        let normal_sunrise_jumpable_img_click = ''
        let normal_moon_jumpable_img_click = ''
        let normal_temperature_jumpable_img_click = ''
        let normal_alarm_jumpable_img_click = ''
        let Button_1 = ''
        let Button_2 = ''
        let timeSensor = ''


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            console.log('Watch_Face.ScreenNormal');
            editBg = hmUI.createWidget(hmUI.widget.WATCHFACE_EDIT_BG, {
              edit_id: 1002,
              x: 0,
              y: 0,
              // w: 466,
              // h: 466,
              // AOD_show: False,
              bg_config: [
                { id: 1, preview: 'bg_edit_1_preview.png', path: 'A100_002.png' },
                { id: 2, preview: 'bg_edit_2_preview.png', path: 'A100_003.png' },
                { id: 3, preview: 'bg_edit_3_preview.png', path: 'A100_004.png' },
                { id: 4, preview: 'bg_edit_4_preview.png', path: 'A100_005.png' },
                { id: 5, preview: 'bg_edit_5_preview.png', path: 'A100_006.png' },
              ],
              count: 5,
              default_id: 1,
              fg: '.png',
              tips_bg: '.png',
              tips_x: 0,
              tips_y: 0,
              show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_EDIT,
            });

            normal_sun_high_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 345,
              y: 401,
              font_array: ["f0.png","f1.png","f2.png","f3.png","f4.png","f5.png","f6.png","f7.png","f8.png","f9.png"],
              padding: false,
              h_space: 0,
              angle: -40,
              invalid_image: 'none.png',
              dot_image: 'maohao.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.SUN_RISE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sun_high_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 356,
              y: 366,
              src: 'A100_021.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sun_low_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 285,
              y: 430,
              font_array: ["f0.png","f1.png","f2.png","f3.png","f4.png","f5.png","f6.png","f7.png","f8.png","f9.png"],
              padding: false,
              h_space: 0,
              angle: -25,
              invalid_image: 'none.png',
              dot_image: 'maohao.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.SUN_SET,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sun_low_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 300,
              y: 400,
              src: 'A100_022.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 202,
              y: 422,
              week_en: ["A100_512.png","A100_513.png","A100_514.png","A100_515.png","A100_516.png","A100_517.png","A100_518.png"],
              week_tc: ["A100_512.png","A100_513.png","A100_514.png","A100_515.png","A100_516.png","A100_517.png","A100_518.png"],
              week_sc: ["A100_512.png","A100_513.png","A100_514.png","A100_515.png","A100_516.png","A100_517.png","A100_518.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_month_text_circle_img = hmUI.createWidget(hmUI.widget.Text_Circle, {
              // circle_center_X: 233,
              // circle_center_Y: 233,
              // font_array: ["date_0.png","date_1.png","date_2.png","date_3.png","date_4.png","date_5.png","date_6.png","date_7.png","date_8.png","date_9.png"],
              // radius: 222,
              // angle: 222,
              // char_space_angle: 0,
              // zero: true,
              // reverse_direction: true,
              // unit_in_alignment: true,
              // vertical_alignment: BOTTOM,
              // horizontal_alignment: CENTER_H,
              // type: hmUI.data_type.MONTH,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_month_TextCircle_ASCIIARRAY[0] = 'date_0.png';  // set of images with numbers
            normal_month_TextCircle_ASCIIARRAY[1] = 'date_1.png';  // set of images with numbers
            normal_month_TextCircle_ASCIIARRAY[2] = 'date_2.png';  // set of images with numbers
            normal_month_TextCircle_ASCIIARRAY[3] = 'date_3.png';  // set of images with numbers
            normal_month_TextCircle_ASCIIARRAY[4] = 'date_4.png';  // set of images with numbers
            normal_month_TextCircle_ASCIIARRAY[5] = 'date_5.png';  // set of images with numbers
            normal_month_TextCircle_ASCIIARRAY[6] = 'date_6.png';  // set of images with numbers
            normal_month_TextCircle_ASCIIARRAY[7] = 'date_7.png';  // set of images with numbers
            normal_month_TextCircle_ASCIIARRAY[8] = 'date_8.png';  // set of images with numbers
            normal_month_TextCircle_ASCIIARRAY[9] = 'date_9.png';  // set of images with numbers

            //start of ignored block
            for (let i = 0; i < 2; i++) {
              normal_month_TextCircle[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 466,
                h: 466,
                center_x: 233,
                center_y: 233,
                pos_x: 233 - normal_month_TextCircle_img_width / 2,
                pos_y: 233 + 185,
                src: 'date_0.png',
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
              normal_month_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
            };
            //end of ignored block

            if (!timeSensor) timeSensor = hmSensor.createSensor(hmSensor.id.TIME);
            let screenType = hmSetting.getScreenType();            
            function toDegree (radian) {
              return radian * (180 / Math.PI);
            };

            // normal_day_text_circle_img = hmUI.createWidget(hmUI.widget.Text_Circle, {
              // circle_center_X: 233,
              // circle_center_Y: 233,
              // font_array: ["date_0.png","date_1.png","date_2.png","date_3.png","date_4.png","date_5.png","date_6.png","date_7.png","date_8.png","date_9.png"],
              // radius: 222,
              // angle: 202,
              // char_space_angle: 0,
              // zero: true,
              // reverse_direction: true,
              // unit_in_alignment: true,
              // vertical_alignment: BOTTOM,
              // horizontal_alignment: CENTER_H,
              // type: hmUI.data_type.DAY,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_day_TextCircle_ASCIIARRAY[0] = 'date_0.png';  // set of images with numbers
            normal_day_TextCircle_ASCIIARRAY[1] = 'date_1.png';  // set of images with numbers
            normal_day_TextCircle_ASCIIARRAY[2] = 'date_2.png';  // set of images with numbers
            normal_day_TextCircle_ASCIIARRAY[3] = 'date_3.png';  // set of images with numbers
            normal_day_TextCircle_ASCIIARRAY[4] = 'date_4.png';  // set of images with numbers
            normal_day_TextCircle_ASCIIARRAY[5] = 'date_5.png';  // set of images with numbers
            normal_day_TextCircle_ASCIIARRAY[6] = 'date_6.png';  // set of images with numbers
            normal_day_TextCircle_ASCIIARRAY[7] = 'date_7.png';  // set of images with numbers
            normal_day_TextCircle_ASCIIARRAY[8] = 'date_8.png';  // set of images with numbers
            normal_day_TextCircle_ASCIIARRAY[9] = 'date_9.png';  // set of images with numbers

            //start of ignored block
            for (let i = 0; i < 2; i++) {
              normal_day_TextCircle[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 466,
                h: 466,
                center_x: 233,
                center_y: 233,
                pos_x: 233 - normal_day_TextCircle_img_width / 2,
                pos_y: 233 + 185,
                src: 'date_0.png',
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
              normal_day_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
            };
            //end of ignored block

            normal_heart_rate_pointer_progress_img_pointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
              src: 'A100_011.png',
              center_x: 233,
              center_y: 233,
              x: 14,
              y: 230,
              start_angle: 222,
              end_angle: 260,
              invalid_visible: false,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 2,
              y: 234,
              w: 60,
              h: 50,
              text_size: 20,
              char_space: 0,
              line_space: 0,
              color: 0xFFFF0000,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_pointer_progress_img_pointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
              src: 'A100_010.png',
              center_x: 233,
              center_y: 233,
              x: 14,
              y: 230,
              start_angle: 280,
              end_angle: 308,
              invalid_visible: false,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_current_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 5,
              y: 202,
              w: 60,
              h: 50,
              text_size: 18,
              char_space: 0,
              line_space: 0,
              color: 0xFFFFFFFF,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.TOP,
              unit_type: 1,
              text_style: hmUI.text_style.ELLIPSIS,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 373,
              y: 310,
              image_array: ["49.png","50.png","51.png","52.png","53.png","54.png","55.png","56.png","57.png","58.png","59.png","60.png","61.png","62.png","63.png","64.png","65.png","66.png","67.png","68.png","69.png","70.png","71.png","72.png","73.png","74.png","75.png","76.png","77.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 410,
              y: 260,
              w: 150,
              h: 50,
              text_size: 25,
              char_space: 0,
              line_space: 0,
              color: 0xFFFFFFFF,
              align_h: hmUI.align.LEFT,
              align_v: hmUI.align.TOP,
              unit_type: 2,
              text_style: hmUI.text_style.ELLIPSIS,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_moon_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 360,
              y: 101,
              image_array: ["Moon_01.png","Moon_02.png","Moon_03.png","Moon_04.png","Moon_05.png","Moon_06.png","Moon_07.png","Moon_08.png","Moon_09.png","Moon_10.png","Moon_11.png","Moon_12.png","Moon_13.png","Moon_14.png","Moon_15.png","Moon_16.png","Moon_17.png","Moon_18.png","Moon_19.png","Moon_20.png","Moon_21.png","Moon_22.png","Moon_23.png","Moon_24.png","Moon_25.png","Moon_26.png","Moon_27.png","Moon_28.png","Moon_29.png","Moon_30.png"],
              image_length: 30,
              type: hmUI.data_type.MOON,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 406,
              y: 172,
              src: 'A100_411.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 404,
              y: 206,
              w: 140,
              h: 60,
              text_size: 20,
              char_space: 0,
              line_space: 0,
              color: 0xFFFFFFFF,
              align_h: hmUI.align.LEFT,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_hour_text_circle_img = hmUI.createWidget(hmUI.widget.Text_Circle, {
              // circle_center_X: 233,
              // circle_center_Y: 233,
              // font_array: ["informative_analog_digital_time_num_0.png","informative_analog_digital_time_num_1.png","informative_analog_digital_time_num_2.png","informative_analog_digital_time_num_3.png","informative_analog_digital_time_num_4.png","informative_analog_digital_time_num_5.png","informative_analog_digital_time_num_6.png","informative_analog_digital_time_num_7.png","informative_analog_digital_time_num_8.png","informative_analog_digital_time_num_9.png"],
              // radius: 202,
              // angle: -32,
              // char_space_angle: 0,
              // zero: true,
              // reverse_direction: false,
              // unit_in_alignment: true,
              // vertical_alignment: CENTER_V,
              // horizontal_alignment: CENTER_H,
              // type: hmUI.data_type.HOUR,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_hour_TextCircle_ASCIIARRAY[0] = 'informative_analog_digital_time_num_0.png';  // set of images with numbers
            normal_hour_TextCircle_ASCIIARRAY[1] = 'informative_analog_digital_time_num_1.png';  // set of images with numbers
            normal_hour_TextCircle_ASCIIARRAY[2] = 'informative_analog_digital_time_num_2.png';  // set of images with numbers
            normal_hour_TextCircle_ASCIIARRAY[3] = 'informative_analog_digital_time_num_3.png';  // set of images with numbers
            normal_hour_TextCircle_ASCIIARRAY[4] = 'informative_analog_digital_time_num_4.png';  // set of images with numbers
            normal_hour_TextCircle_ASCIIARRAY[5] = 'informative_analog_digital_time_num_5.png';  // set of images with numbers
            normal_hour_TextCircle_ASCIIARRAY[6] = 'informative_analog_digital_time_num_6.png';  // set of images with numbers
            normal_hour_TextCircle_ASCIIARRAY[7] = 'informative_analog_digital_time_num_7.png';  // set of images with numbers
            normal_hour_TextCircle_ASCIIARRAY[8] = 'informative_analog_digital_time_num_8.png';  // set of images with numbers
            normal_hour_TextCircle_ASCIIARRAY[9] = 'informative_analog_digital_time_num_9.png';  // set of images with numbers

            //start of ignored block
            for (let i = 0; i < 2; i++) {
              normal_hour_TextCircle[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 466,
                h: 466,
                center_x: 233,
                center_y: 233,
                pos_x: 233 - normal_hour_TextCircle_img_width / 2,
                pos_y: 233 - 238,
                src: 'informative_analog_digital_time_num_0.png',
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
              normal_hour_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
            };
            //end of ignored block

            // normal_minute_text_circle_img = hmUI.createWidget(hmUI.widget.Text_Circle, {
              // circle_center_X: 233,
              // circle_center_Y: 233,
              // font_array: ["informative_analog_digital_time_num_0.png","informative_analog_digital_time_num_1.png","informative_analog_digital_time_num_2.png","informative_analog_digital_time_num_3.png","informative_analog_digital_time_num_4.png","informative_analog_digital_time_num_5.png","informative_analog_digital_time_num_6.png","informative_analog_digital_time_num_7.png","informative_analog_digital_time_num_8.png","informative_analog_digital_time_num_9.png"],
              // radius: 200,
              // angle: 0,
              // char_space_angle: 0,
              // zero: true,
              // reverse_direction: false,
              // unit_in_alignment: true,
              // vertical_alignment: CENTER_V,
              // horizontal_alignment: CENTER_H,
              // type: hmUI.data_type.MINUTE,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_minute_TextCircle_ASCIIARRAY[0] = 'informative_analog_digital_time_num_0.png';  // set of images with numbers
            normal_minute_TextCircle_ASCIIARRAY[1] = 'informative_analog_digital_time_num_1.png';  // set of images with numbers
            normal_minute_TextCircle_ASCIIARRAY[2] = 'informative_analog_digital_time_num_2.png';  // set of images with numbers
            normal_minute_TextCircle_ASCIIARRAY[3] = 'informative_analog_digital_time_num_3.png';  // set of images with numbers
            normal_minute_TextCircle_ASCIIARRAY[4] = 'informative_analog_digital_time_num_4.png';  // set of images with numbers
            normal_minute_TextCircle_ASCIIARRAY[5] = 'informative_analog_digital_time_num_5.png';  // set of images with numbers
            normal_minute_TextCircle_ASCIIARRAY[6] = 'informative_analog_digital_time_num_6.png';  // set of images with numbers
            normal_minute_TextCircle_ASCIIARRAY[7] = 'informative_analog_digital_time_num_7.png';  // set of images with numbers
            normal_minute_TextCircle_ASCIIARRAY[8] = 'informative_analog_digital_time_num_8.png';  // set of images with numbers
            normal_minute_TextCircle_ASCIIARRAY[9] = 'informative_analog_digital_time_num_9.png';  // set of images with numbers

            //start of ignored block
            for (let i = 0; i < 2; i++) {
              normal_minute_TextCircle[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 466,
                h: 466,
                center_x: 233,
                center_y: 233,
                pos_x: 233 - normal_minute_TextCircle_img_width / 2,
                pos_y: 233 - 236,
                src: 'informative_analog_digital_time_num_0.png',
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
              normal_minute_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
            };
            //end of ignored block

            // normal_second_text_circle_img = hmUI.createWidget(hmUI.widget.Text_Circle, {
              // circle_center_X: 233,
              // circle_center_Y: 233,
              // font_array: ["informative_analog_digital_time_num_0.png","informative_analog_digital_time_num_1.png","informative_analog_digital_time_num_2.png","informative_analog_digital_time_num_3.png","informative_analog_digital_time_num_4.png","informative_analog_digital_time_num_5.png","informative_analog_digital_time_num_6.png","informative_analog_digital_time_num_7.png","informative_analog_digital_time_num_8.png","informative_analog_digital_time_num_9.png"],
              // radius: 202,
              // angle: 30,
              // char_space_angle: 0,
              // zero: true,
              // reverse_direction: false,
              // unit_in_alignment: true,
              // vertical_alignment: CENTER_V,
              // horizontal_alignment: CENTER_H,
              // type: hmUI.data_type.SECOND,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_second_TextCircle_ASCIIARRAY[0] = 'informative_analog_digital_time_num_0.png';  // set of images with numbers
            normal_second_TextCircle_ASCIIARRAY[1] = 'informative_analog_digital_time_num_1.png';  // set of images with numbers
            normal_second_TextCircle_ASCIIARRAY[2] = 'informative_analog_digital_time_num_2.png';  // set of images with numbers
            normal_second_TextCircle_ASCIIARRAY[3] = 'informative_analog_digital_time_num_3.png';  // set of images with numbers
            normal_second_TextCircle_ASCIIARRAY[4] = 'informative_analog_digital_time_num_4.png';  // set of images with numbers
            normal_second_TextCircle_ASCIIARRAY[5] = 'informative_analog_digital_time_num_5.png';  // set of images with numbers
            normal_second_TextCircle_ASCIIARRAY[6] = 'informative_analog_digital_time_num_6.png';  // set of images with numbers
            normal_second_TextCircle_ASCIIARRAY[7] = 'informative_analog_digital_time_num_7.png';  // set of images with numbers
            normal_second_TextCircle_ASCIIARRAY[8] = 'informative_analog_digital_time_num_8.png';  // set of images with numbers
            normal_second_TextCircle_ASCIIARRAY[9] = 'informative_analog_digital_time_num_9.png';  // set of images with numbers

            //start of ignored block
            for (let i = 0; i < 2; i++) {
              normal_second_TextCircle[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 466,
                h: 466,
                center_x: 233,
                center_y: 233,
                pos_x: 233 - normal_second_TextCircle_img_width / 2,
                pos_y: 233 - 238,
                src: 'informative_analog_digital_time_num_0.png',
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
              normal_second_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
            };
            //end of ignored block


            console.log('Watch_Face.ScreenAOD');
            idle_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 466,
              h: 466,
              src: 'A100_007.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 140,
              hour_startY: 188,
              hour_array: ["informative_analog_digital_time_num_0.png","informative_analog_digital_time_num_1.png","informative_analog_digital_time_num_2.png","informative_analog_digital_time_num_3.png","informative_analog_digital_time_num_4.png","informative_analog_digital_time_num_5.png","informative_analog_digital_time_num_6.png","informative_analog_digital_time_num_7.png","informative_analog_digital_time_num_8.png","informative_analog_digital_time_num_9.png"],
              hour_zero: 1,
              hour_space: 0,
              hour_angle: 0,
              hour_align: hmUI.align.CENTER_H,

              minute_startX: 246,
              minute_startY: 188,
              minute_array: ["informative_analog_digital_time_num_0.png","informative_analog_digital_time_num_1.png","informative_analog_digital_time_num_2.png","informative_analog_digital_time_num_3.png","informative_analog_digital_time_num_4.png","informative_analog_digital_time_num_5.png","informative_analog_digital_time_num_6.png","informative_analog_digital_time_num_7.png","informative_analog_digital_time_num_8.png","informative_analog_digital_time_num_9.png"],
              minute_zero: 1,
              minute_space: 0,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.CENTER_H,

              show_level: hmUI.show_level.ONLY_AOD,
            });
            console.log('Watch_Face.Shortcuts');

            normal_cal_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 400,
              y: 180,
              w: 50,
              h: 50,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 15,
              y: 245,
              w: 50,
              h: 50,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sunrise_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 300,
              y: 370,
              w: 70,
              h: 50,
              type: hmUI.data_type.SUN_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_moon_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 368,
              y: 108,
              w: 50,
              h: 50,
              type: hmUI.data_type.MOON_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 364,
              y: 270,
              w: 70,
              h: 70,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_alarm_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 155,
              y: 22,
              w: 150,
              h: 50,
              type: hmUI.data_type.ALARM_CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            console.log('Watch_Face.Buttons');
            Button_1 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 15,
              y: 180,
              w: 50,
              h: 50,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'Settings_batteryManagerScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_2 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 115,
              y: 370,
              w: 100,
              h: 60,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'ScheduleCalScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            //start of ignored block
            function text_update() {
              console.log('text_update()');

              console.log('update text circle month_TIME');
              let valueMonth = timeSensor.month;
              let normal_month_circle_string = parseInt(valueMonth).toString();
              normal_month_circle_string = normal_month_circle_string.padStart(2, '0');

              if (screenType != hmSetting.screen_type.AOD) {
                for (var i = 1; i < 2; i++) {  // hide all symbols
                  normal_month_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                let char_Angle = 402;
                if (valueMonth != null && valueMonth != undefined && isFinite(valueMonth) && normal_month_circle_string.length > 0 && normal_month_circle_string.length <= 2) {  // display data if it was possible to get it
                  let normal_month_TextCircle_img_angle = 0;
                  let normal_month_TextCircle_dot_img_angle = 0;
                  normal_month_TextCircle_img_angle = toDegree(Math.atan2(normal_month_TextCircle_img_width/2, 222));
                  // alignment = CENTER_H
                  let normal_month_TextCircle_angleOffset = normal_month_TextCircle_img_angle * (normal_month_circle_string.length - 1);
                  normal_month_TextCircle_angleOffset = -normal_month_TextCircle_angleOffset;
                  char_Angle -= normal_month_TextCircle_angleOffset;
                  // alignment end
                  
                  let firstSymbol = true;
                  let index = 0;
                  for (let char of normal_month_circle_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 2) break;
                    if (charCode >= 0 && charCode < 10) { 
                      if (!firstSymbol) char_Angle -= normal_month_TextCircle_img_angle;
                      firstSymbol = false;
                      normal_month_TextCircle[index].setProperty(hmUI.prop.ANGLE, char_Angle);
                      normal_month_TextCircle[index].setProperty(hmUI.prop.POS_X, 233 - normal_month_TextCircle_img_width / 2);
                      normal_month_TextCircle[index].setProperty(hmUI.prop.SRC, normal_month_TextCircle_ASCIIARRAY[charCode]);
                      normal_month_TextCircle[index].setProperty(hmUI.prop.VISIBLE, true);
                      char_Angle -= normal_month_TextCircle_img_angle;
                      index++;
                    };  // end if digit
                  };  // end char of string
                }  // end isFinite

              };

              console.log('update text circle day_TIME');
              let valueDay = timeSensor.day;
              let normal_day_circle_string = parseInt(valueDay).toString();
              normal_day_circle_string = normal_day_circle_string.padStart(2, '0');

              if (screenType != hmSetting.screen_type.AOD) {
                for (var i = 1; i < 2; i++) {  // hide all symbols
                  normal_day_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                let char_Angle = 382;
                if (valueDay != null && valueDay != undefined && isFinite(valueDay) && normal_day_circle_string.length > 0 && normal_day_circle_string.length <= 2) {  // display data if it was possible to get it
                  let normal_day_TextCircle_img_angle = 0;
                  let normal_day_TextCircle_dot_img_angle = 0;
                  normal_day_TextCircle_img_angle = toDegree(Math.atan2(normal_day_TextCircle_img_width/2, 222));
                  // alignment = CENTER_H
                  let normal_day_TextCircle_angleOffset = normal_day_TextCircle_img_angle * (normal_day_circle_string.length - 1);
                  normal_day_TextCircle_angleOffset = -normal_day_TextCircle_angleOffset;
                  char_Angle -= normal_day_TextCircle_angleOffset;
                  // alignment end
                  
                  let firstSymbol = true;
                  let index = 0;
                  for (let char of normal_day_circle_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 2) break;
                    if (charCode >= 0 && charCode < 10) { 
                      if (!firstSymbol) char_Angle -= normal_day_TextCircle_img_angle;
                      firstSymbol = false;
                      normal_day_TextCircle[index].setProperty(hmUI.prop.ANGLE, char_Angle);
                      normal_day_TextCircle[index].setProperty(hmUI.prop.POS_X, 233 - normal_day_TextCircle_img_width / 2);
                      normal_day_TextCircle[index].setProperty(hmUI.prop.SRC, normal_day_TextCircle_ASCIIARRAY[charCode]);
                      normal_day_TextCircle[index].setProperty(hmUI.prop.VISIBLE, true);
                      char_Angle -= normal_day_TextCircle_img_angle;
                      index++;
                    };  // end if digit
                  };  // end char of string
                }  // end isFinite

              };

              console.log('update text circle hour_TIME');
              let valueHour = timeSensor.format_hour;
              let normal_hour_circle_string = parseInt(valueHour).toString();
              normal_hour_circle_string = normal_hour_circle_string.padStart(2, '0');

              if (screenType != hmSetting.screen_type.AOD) {
                for (var i = 1; i < 2; i++) {  // hide all symbols
                  normal_hour_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                let char_Angle = -32;
                if (valueHour != null && valueHour != undefined && isFinite(valueHour) && normal_hour_circle_string.length > 0 && normal_hour_circle_string.length <= 2) {  // display data if it was possible to get it
                  let normal_hour_TextCircle_img_angle = 0;
                  let normal_hour_TextCircle_dot_img_angle = 0;
                  normal_hour_TextCircle_img_angle = toDegree(Math.atan2(normal_hour_TextCircle_img_width/2, 202));
                  // alignment = CENTER_H
                  let normal_hour_TextCircle_angleOffset = normal_hour_TextCircle_img_angle * (normal_hour_circle_string.length - 1);
                  char_Angle -= normal_hour_TextCircle_angleOffset;
                  // alignment end
                  
                  let firstSymbol = true;
                  let index = 0;
                  for (let char of normal_hour_circle_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 2) break;
                    if (charCode >= 0 && charCode < 10) { 
                      if (!firstSymbol) char_Angle += normal_hour_TextCircle_img_angle;
                      firstSymbol = false;
                      normal_hour_TextCircle[index].setProperty(hmUI.prop.ANGLE, char_Angle);
                      normal_hour_TextCircle[index].setProperty(hmUI.prop.POS_X, 233 - normal_hour_TextCircle_img_width / 2);
                      normal_hour_TextCircle[index].setProperty(hmUI.prop.SRC, normal_hour_TextCircle_ASCIIARRAY[charCode]);
                      normal_hour_TextCircle[index].setProperty(hmUI.prop.VISIBLE, true);
                      char_Angle += normal_hour_TextCircle_img_angle;
                      index++;
                    };  // end if digit
                  };  // end char of string
                }  // end isFinite

              };

              console.log('update text circle minute_TIME');
              let valueMinute = timeSensor.minute;
              let normal_minute_circle_string = parseInt(valueMinute).toString();
              normal_minute_circle_string = normal_minute_circle_string.padStart(2, '0');

              if (screenType != hmSetting.screen_type.AOD) {
                for (var i = 1; i < 2; i++) {  // hide all symbols
                  normal_minute_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                let char_Angle = 0;
                if (valueMinute != null && valueMinute != undefined && isFinite(valueMinute) && normal_minute_circle_string.length > 0 && normal_minute_circle_string.length <= 2) {  // display data if it was possible to get it
                  let normal_minute_TextCircle_img_angle = 0;
                  let normal_minute_TextCircle_dot_img_angle = 0;
                  normal_minute_TextCircle_img_angle = toDegree(Math.atan2(normal_minute_TextCircle_img_width/2, 200));
                  // alignment = CENTER_H
                  let normal_minute_TextCircle_angleOffset = normal_minute_TextCircle_img_angle * (normal_minute_circle_string.length - 1);
                  char_Angle -= normal_minute_TextCircle_angleOffset;
                  // alignment end
                  
                  let firstSymbol = true;
                  let index = 0;
                  for (let char of normal_minute_circle_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 2) break;
                    if (charCode >= 0 && charCode < 10) { 
                      if (!firstSymbol) char_Angle += normal_minute_TextCircle_img_angle;
                      firstSymbol = false;
                      normal_minute_TextCircle[index].setProperty(hmUI.prop.ANGLE, char_Angle);
                      normal_minute_TextCircle[index].setProperty(hmUI.prop.POS_X, 233 - normal_minute_TextCircle_img_width / 2);
                      normal_minute_TextCircle[index].setProperty(hmUI.prop.SRC, normal_minute_TextCircle_ASCIIARRAY[charCode]);
                      normal_minute_TextCircle[index].setProperty(hmUI.prop.VISIBLE, true);
                      char_Angle += normal_minute_TextCircle_img_angle;
                      index++;
                    };  // end if digit
                  };  // end char of string
                }  // end isFinite

              };

              console.log('update text circle second_TIME');
              let valueSecond = timeSensor.second;
              let normal_second_circle_string = parseInt(valueSecond).toString();
              normal_second_circle_string = normal_second_circle_string.padStart(2, '0');

              if (screenType != hmSetting.screen_type.AOD) {
                for (var i = 1; i < 2; i++) {  // hide all symbols
                  normal_second_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                let char_Angle = 30;
                if (valueSecond != null && valueSecond != undefined && isFinite(valueSecond) && normal_second_circle_string.length > 0 && normal_second_circle_string.length <= 2) {  // display data if it was possible to get it
                  let normal_second_TextCircle_img_angle = 0;
                  let normal_second_TextCircle_dot_img_angle = 0;
                  normal_second_TextCircle_img_angle = toDegree(Math.atan2(normal_second_TextCircle_img_width/2, 202));
                  // alignment = CENTER_H
                  let normal_second_TextCircle_angleOffset = normal_second_TextCircle_img_angle * (normal_second_circle_string.length - 1);
                  char_Angle -= normal_second_TextCircle_angleOffset;
                  // alignment end
                  
                  let firstSymbol = true;
                  let index = 0;
                  for (let char of normal_second_circle_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 2) break;
                    if (charCode >= 0 && charCode < 10) { 
                      if (!firstSymbol) char_Angle += normal_second_TextCircle_img_angle;
                      firstSymbol = false;
                      normal_second_TextCircle[index].setProperty(hmUI.prop.ANGLE, char_Angle);
                      normal_second_TextCircle[index].setProperty(hmUI.prop.POS_X, 233 - normal_second_TextCircle_img_width / 2);
                      normal_second_TextCircle[index].setProperty(hmUI.prop.SRC, normal_second_TextCircle_ASCIIARRAY[charCode]);
                      normal_second_TextCircle[index].setProperty(hmUI.prop.VISIBLE, true);
                      char_Angle += normal_second_TextCircle_img_angle;
                      index++;
                    };  // end if digit
                  };  // end char of string
                }  // end isFinite

              };

            };

            //end of ignored block
            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                console.log('resume_call()');
                text_update();
                if (screenType == hmSetting.screen_type.WATCHFACE) {
                  if (!normal_timerTextUpdate) {
                    normal_timerTextUpdate = timer.createTimer(0, 1000, (function (option) {
                      text_update();
                    }));  // end timer 
                  };  // end timer check
                };  // end screenType


              }),
              pause_call: (function () {
                console.log('pause_call()');
                if (normal_timerTextUpdate) {
                  timer.stopTimer(normal_timerTextUpdate);
                  normal_timerTextUpdate = undefined;
                }

              }),
            });

                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}