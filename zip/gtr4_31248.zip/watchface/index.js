/*
** Facemaker bundle tool v0.0.2
* *huamiOS watchface js version v2.0.1
* *Copyright © Huami. All Rights Reserved
*/


try {
	(() => {
		var __$$app$$__ = __$$hmAppManager$$__.currentApp;
		var __$$module$$__ = __$$app$$__.current;

		//drink is a name,can modify
		var h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__), 'drink');

		'use strict';

		//dynamic modify start
		let normal_background_bg_img0 = '';
		let normal_background_bg_img1 = '';
		let normal_background_bg_img2 = '';
		let normal_background_bg_img3 = '';
		let normal_background_bg_img4 = '';
		let normal_digital_clock_img_hour_high6 = '';
		let normal_digital_clock_img_hour_high6_array = ['0005.png','0006.png','0007.png'];
		let normal_digital_clock_img_hour_low7 = '';
		let normal_digital_clock_img_hour_low7_array = ['0008.png','0009.png','0010.png','0011.png','0012.png','0013.png','0014.png','0015.png','0016.png','0017.png'];
		let normal_digital_clock_img_minute_high8 = '';
		let normal_digital_clock_img_minute_high8_array = ['0018.png','0019.png','0020.png','0021.png','0022.png','0023.png'];
		let normal_digital_clock_img_minute_low9 = '';
		let normal_digital_clock_img_minute_low9_array = ['0024.png','0025.png','0026.png','0027.png','0028.png','0029.png','0030.png','0031.png','0032.png','0033.png'];
		let normal_digital_clock_img_second10 = '';
		let normal_date_img_date_week_img12 = '';
		let normal_date_current_date_monthday13 = '';
		let normal_background_bg_img14 = '';
		let normal_date_current_date_month15 = '';
		let normal_date_current_date_year16 = '';
		let normal_battery_current_text_img18 = '';
		let normal_background_bg_img19 = '';
		let normal_alarm_status21 = '';
		let normal_step_current_text_img23 = '';
		let normal_background_bg_img24 = '';
		let normal_distance_current_text_img26 = '';
		let normal_background_bg_img27 = '';
		let normal_weather_image_progress_img_level29 = '';
		let normal_temperature_current_text_img30 = '';
		let normal_background_bg_img31 = '';
		let normal_humidity_current_text_img33 = '';
		let normal_background_bg_img34 = '';
		let normal_background_bg_img35 = '';
		let normal_wind_current_text_img37 = '';
		let normal_background_bg_img38 = '';
		let normal_calories_current_text_img40 = '';
		let normal_background_bg_img41 = '';
		let normal_blood_oxygen_text_img43 = '';
		let normal_background_bg_img44 = '';
		let normal_heart_current_text_img46 = '';
		let normal_background_bg_img47 = '';
		//dynamic modify end

		//not required
		const logger = DeviceRuntimeCore.HmLogger.getLogger("yeguang");

		__$$module$$__.module = DeviceRuntimeCore.WatchFace({
			init_view() {

				let screenType = hmSetting.getScreenType();

				normal_background_bg_img0 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 0,
					y: 0,
					w: 466,
					h: 466,
					src: '0002.png',
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_background_bg_img1 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 212,
					y: 3,
					w: 43,
					h: 45,
					src: '0003.png',
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_background_bg_img2 = hmUI.createWidget(hmUI.widget.IMG, {
					x: -1,
					y: 232,
					w: 126,
					h: 2,
					src: '0004.png',
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_background_bg_img3 = hmUI.createWidget(hmUI.widget.IMG, {
					x: -1,
					y: 123,
					w: 126,
					h: 2,
					src: '0004.png',
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_background_bg_img4 = hmUI.createWidget(hmUI.widget.IMG, {
					x: -1,
					y: 342,
					w: 126,
					h: 2,
					src: '0004.png',
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_digital_clock_img_hour_high6 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 148,
					y: 64,
					w: 148,
					h: 64,
					src: '0007.png',
					show_level: hmUI.show_level.ONLY_NORMAL,
				})

				normal_digital_clock_img_hour_low7 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 239,
					y: 64,
					w: 239,
					h: 64,
					src: '0017.png',
					show_level: hmUI.show_level.ONLY_NORMAL,
				})

				normal_digital_clock_img_minute_high8 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 148,
					y: 256,
					w: 148,
					h: 256,
					src: '0023.png',
					show_level: hmUI.show_level.ONLY_NORMAL,
				})

				normal_digital_clock_img_minute_low9 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 239,
					y: 256,
					w: 239,
					h: 256,
					src: '0033.png',
					show_level: hmUI.show_level.ONLY_NORMAL,
				})

				normal_digital_clock_img_second10 = hmUI.createWidget(hmUI.widget.IMG_TIME, {
					second_startX: 203,
					second_startY: 412,
					second_array: ["0034.png","0035.png","0036.png","0037.png","0038.png","0039.png","0040.png","0041.png","0042.png","0043.png"],
					second_zero: true,
					second_space: -3,
					second_align: hmUI.align.CENTER_H,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_date_img_date_week_img12 = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
					x: 137,
					y: 215,
					week_en: ["0044.png","0045.png","0046.png","0047.png","0048.png","0049.png","0050.png"],
					week_tc: ["0044.png","0045.png","0046.png","0047.png","0048.png","0049.png","0050.png"],
					week_sc: ["0044.png","0045.png","0046.png","0047.png","0048.png","0049.png","0050.png"],
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_date_current_date_monthday13 = hmUI.createWidget(hmUI.widget.IMG_DATE, {
					day_startX: 347,
					day_startY: 183,
					day_sc_array: ["0051.png","0052.png","0053.png","0054.png","0055.png","0056.png","0057.png","0058.png","0059.png","0060.png"],
					day_tc_array: ["0051.png","0052.png","0053.png","0054.png","0055.png","0056.png","0057.png","0058.png","0059.png","0060.png"],
					day_en_array: ["0051.png","0052.png","0053.png","0054.png","0055.png","0056.png","0057.png","0058.png","0059.png","0060.png"],
					day_zero: true,
					day_space: -5,
					day_align: hmUI.align.CENTER_H,
					day_is_character: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_background_bg_img14 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 400,
					y: 185,
					w: 10,
					h: 50,
					src: '0061.png',
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_date_current_date_month15 = hmUI.createWidget(hmUI.widget.IMG_DATE, {
					month_startX: 408,
					month_startY: 183,
					month_sc_array: ["0051.png","0052.png","0053.png","0054.png","0055.png","0056.png","0057.png","0058.png","0059.png","0060.png"],
					month_tc_array: ["0051.png","0052.png","0053.png","0054.png","0055.png","0056.png","0057.png","0058.png","0059.png","0060.png"],
					month_en_array: ["0051.png","0052.png","0053.png","0054.png","0055.png","0056.png","0057.png","0058.png","0059.png","0060.png"],
					month_zero: true,
					month_space: -5,
					month_align: hmUI.align.CENTER_H,
					month_is_character: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_date_current_date_year16 = hmUI.createWidget(hmUI.widget.IMG_DATE, {
					year_startX: 350,
					year_startY: 242,
					year_sc_array: ["0062.png","0063.png","0064.png","0065.png","0066.png","0067.png","0068.png","0069.png","0070.png","0071.png"],
					year_tc_array: ["0062.png","0063.png","0064.png","0065.png","0066.png","0067.png","0068.png","0069.png","0070.png","0071.png"],
					year_en_array: ["0062.png","0063.png","0064.png","0065.png","0066.png","0067.png","0068.png","0069.png","0070.png","0071.png"],
					year_zero: true,
					year_space: -7,
					year_align: hmUI.align.CENTER_H,
					year_is_character: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_battery_current_text_img18 = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
					x: 38,
					y: 348,
					font_array: ["0072.png","0073.png","0074.png","0075.png","0076.png","0077.png","0078.png","0079.png","0080.png","0081.png"],
					padding: false,
					h_space: -8,
					unit_sc: '0082.png',
					unit_tc: '0082.png',
					unit_en: '0082.png',
					align_h: hmUI.align.CENTER_H,
					type: hmUI.data_type.BATTERY,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_background_bg_img19 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 81,
					y: 385,
					w: 24,
					h: 30,
					src: '0083.png',
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_alarm_status21 = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
					x: 212,
					y: 3,
					w: 43,
					h: 45,
					type: hmUI.system_status.CLOCK,
					src: '0084.png',
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_step_current_text_img23 = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
					x: 28,
					y: 188,
					font_array: ["0085.png","0086.png","0087.png","0088.png","0089.png","0090.png","0091.png","0092.png","0093.png","0094.png"],
					padding: false,
					h_space: -2,
					align_h: hmUI.align.CENTER_H,
					type: hmUI.data_type.STEP,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_background_bg_img24 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 0,
					y: 189,
					w: 25,
					h: 32,
					src: '0095.png',
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_distance_current_text_img26 = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
					x: 29,
					y: 245,
					font_array: ["0096.png","0097.png","0098.png","0099.png","0100.png","0101.png","0102.png","0103.png","0104.png","0105.png"],
					padding: false,
					h_space: -2,
					dot_image: '0106.png',
					align_h: hmUI.align.CENTER_H,
					type: hmUI.data_type.DISTANCE,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_background_bg_img27 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 2,
					y: 246,
					w: 20,
					h: 32,
					src: '0107.png',
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_weather_image_progress_img_level29 = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
					x: 335,
					y: 75,
					image_array: ["0108.png","0109.png","0110.png","0111.png","0112.png","0113.png","0114.png","0115.png","0116.png","0117.png","0118.png","0119.png","0120.png","0121.png","0122.png","0123.png","0124.png","0125.png","0126.png","0127.png","0128.png","0129.png","0130.png","0131.png","0132.png","0133.png","0134.png","0135.png","0136.png"],
					image_length: 29,
					type: hmUI.data_type.WEATHER_CURRENT,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_temperature_current_text_img30 = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
					x: 346,
					y: 375,
					font_array: ["0137.png","0138.png","0139.png","0140.png","0141.png","0142.png","0143.png","0144.png","0145.png","0146.png"],
					padding: false,
					h_space: -4,
					unit_sc: ["0148.png"],
					unit_tc: ["0148.png"],
					unit_en: ["0148.png"],
					negative_image: ["0147.png"],
					invalid_image: ["0149.png"],
					align_h: hmUI.align.RIGHT,
					type: hmUI.data_type.WEATHER_CURRENT,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_background_bg_img31 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 341,
					y: 374,
					w: 15,
					h: 30,
					src: '0150.png',
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_humidity_current_text_img33 = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
					x: 363,
					y: 300,
					font_array: ["0151.png","0152.png","0153.png","0154.png","0155.png","0156.png","0157.png","0158.png","0159.png","0160.png"],
					padding: false,
					h_space: -3,
					align_h: hmUI.align.RIGHT,
					type: hmUI.data_type.HUMIDITY,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_background_bg_img34 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 342,
					y: 300,
					w: 22,
					h: 30,
					src: '0161.png',
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_background_bg_img35 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 422,
					y: 306,
					w: 17,
					h: 27,
					src: '0162.png',
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_wind_current_text_img37 = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
					x: 367,
					y: 338,
					font_array: ["0163.png","0164.png","0165.png","0166.png","0167.png","0168.png","0169.png","0170.png","0171.png","0172.png"],
					padding: false,
					h_space: -2,
					align_h: hmUI.align.RIGHT,
					type: hmUI.data_type.WIND,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_background_bg_img38 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 342,
					y: 338,
					w: 25,
					h: 30,
					src: '0173.png',
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_calories_current_text_img40 = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
					x: 56,
					y: 305,
					font_array: ["0174.png","0175.png","0176.png","0177.png","0178.png","0179.png","0180.png","0181.png","0182.png","0183.png"],
					padding: false,
					h_space: -3,
					align_h: hmUI.align.CENTER_H,
					type: hmUI.data_type.CAL,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_background_bg_img41 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 21,
					y: 306,
					w: 25,
					h: 30,
					src: '0184.png',
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_blood_oxygen_text_img43 = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
					x: 55,
					y: 86,
					font_array: ["0185.png","0186.png","0187.png","0188.png","0189.png","0190.png","0191.png","0192.png","0193.png","0194.png"],
					padding: false,
					h_space: -3,
					align_h: hmUI.align.RIGHT,
					type: hmUI.data_type.SPO2,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_background_bg_img44 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 79,
					y: 51,
					w: 28,
					h: 30,
					src: '0195.png',
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_heart_current_text_img46 = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
					x: 64,
					y: 133,
					font_array: ["0196.png","0197.png","0198.png","0199.png","0200.png","0201.png","0202.png","0203.png","0204.png","0205.png"],
					padding: false,
					h_space: -3,
					invalid_image: '0206.png',
					align_h: hmUI.align.CENTER_H,
					type: hmUI.data_type.HEART,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_background_bg_img47 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 18,
					y: 133,
					w: 36,
					h: 30,
					src: '0207.png',
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				const timeSensor = hmSensor.createSensor(hmSensor.id.TIME);
				timeSensor.addEventListener(hmSensor.event.CHANGE, function() {
					updateImageCombos();
				});

				function updateImageCombos() {
					normal_digital_clock_img_hour_high6.setProperty(hmUI.prop.MORE, {
						src: normal_digital_clock_img_hour_high6_array[(timeSensor.hour.toString().length == 2 ? timeSensor.hour.toString().charAt(0) : 0)]
					})
					normal_digital_clock_img_hour_low7.setProperty(hmUI.prop.MORE, {
						src: normal_digital_clock_img_hour_low7_array[(timeSensor.hour.toString().length == 2 ? timeSensor.hour.toString().charAt(1) : timeSensor.hour.toString().charAt(0))]
					})
					normal_digital_clock_img_minute_high8.setProperty(hmUI.prop.MORE, {
						src: normal_digital_clock_img_minute_high8_array[(timeSensor.minute.toString().length == 2 ? timeSensor.minute.toString().charAt(0) : 0)]
					})
					normal_digital_clock_img_minute_low9.setProperty(hmUI.prop.MORE, {
						src: normal_digital_clock_img_minute_low9_array[(timeSensor.minute.toString().length == 2 ? timeSensor.minute.toString().charAt(1) : timeSensor.minute.toString().charAt(0))]
					})
				};

				const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
					resume_call: (function () {
						updateImageCombos();

					}),
					pause_call: (function () {
					}),
				})
			},

		onInit() {
			console.log('index page.js on init invoke')
			this.init_view()
		},
		onReady() {
			console.log('index page.js on ready invoke')
		},
		onShow() {
			console.log('index page.js on show invoke')
		},
		onHide() {
			console.log('index page.js on hide invoke')
		},
		onDestroy() {
			console.log('index page.js on destroy invoke')
		},
	});	})()
} catch (e) {
	console.log(e)
}