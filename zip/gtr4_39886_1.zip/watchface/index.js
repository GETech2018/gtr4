﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        const logger = Logger.getLogger('watchface_SashaCX75');
        //end of ignored block

        //dynamic modify start

// Start						  
	let colornumber_main = 1
        let totalcolors_main = 3
        let namecolor_main = ''

        function color() {
            if(colornumber_main>=totalcolors_main) {
            colornumber_main=1;
                }
            else {
                colornumber_main=colornumber_main+1;
            }

			if ( colornumber_main == 1) { namecolor_main = "1"
			}
			if ( colornumber_main == 2) { namecolor_main = "2"
			}
			if ( colornumber_main == 3) { namecolor_main = "3"
			}

			//hmUI.showToast({text: namecolor_main });
                        normal_analog_clock_pro_hour_pointer_img.setProperty(hmUI.prop.SRC, "t_hor" + parseInt(colornumber_main) + ".png");
			normal_analog_clock_pro_minute_pointer_img.setProperty(hmUI.prop.SRC, "t_min" + parseInt(colornumber_main) + ".png");															        normal_analog_clock_pro_second_pointer_img.setProperty(hmUI.prop.SRC, "t_sec" + parseInt(colornumber_main) + ".png");
		        normal_sun_icon_img.setProperty(hmUI.prop.SRC, "su_" + parseInt(colornumber_main) + ".png");
        }
		
		let elementnumber_1 = 1
        let total_elements = 4

        function hands() {
            if(elementnumber_1==total_elements) {
            elementnumber_1=1;
                UpdateElementOne();
                }
            else {
                elementnumber_1=elementnumber_1+1;
                if(elementnumber_1==2) {
                  UpdateElementTwo();
                }
               if(elementnumber_1==3) {
                  UpdateElementeThree();
                }
	      if(elementnumber_1==4) {
                  UpdateElementeFour();
                }

            }
        }
// End

// Start
let screenType = hmSetting.getScreenType();
        let colornumber = 1
        let totalcolors = 3
		let battstring = 't_bs1.png'
                let backstring = 'bck_1.png'

		function click_COLOR() {
            if(colornumber>=totalcolors) {
            colornumber=1;
                }
            else {
                colornumber=colornumber+1;
            }
			if ( colornumber == 1) { 
				battstring = 't_bs1.png'
				backstring = 'bck_1.png'
				hmUI.showToast({text: 'Yellow'});
			}
			if ( colornumber == 2) {
				battstring = 't_bs2.png'
				backstring = 'bck_2.png'
				hmUI.showToast({text: 'Black'});
			}
			if ( colornumber == 3) {
				battstring = 't_bs3.png'
				backstring = 'bck_3.png'
				hmUI.showToast({text: 'White'});
			}
			if ( colornumber <= 3) { 

	    normal_battery_pointer_progress_img_pointer.setProperty(hmUI.prop.MORE, {
              src: battstring,
              center_x: 233,
              center_y: 138,
              x: 4,
              y: 45,
              start_angle: 228,
              end_angle: 492,
              invalid_visible: false,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

	    normal_step_pointer_progress_img_pointer.setProperty(hmUI.prop.MORE, {
              src: battstring,
              center_x: 233,
              center_y: 328,
              x: 4,
              y: 45,
              start_angle: 228,
              end_angle: 492,
              invalid_visible: false,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_background_bg_img.setProperty(hmUI.prop.MORE, {
              x: 0,
              y: 0,
              w: 466,
              h: 466,
              src: backstring,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
			}
			
			hmFS.SysProSetInt('userScore', colornumber);
//			normal_sun_icon_img.setProperty(hmUI.prop.SRC, "sun" + parseInt(colornumber) + ".png");
//			normal_battery_pointer_progress_img_pointer.setProperty(hmUI.prop.SRC, "batt" + parseInt(colornumber) + ".png");
//			normal_step_pointer_progress_img_pointer.setProperty(hmUI.prop.SRC, "batt" + parseInt(colornumber) + ".png");
//			normal_background_bg_img.setProperty(hmUI.prop.SRC, "back" + parseInt(colornumber) + ".png");
		}
// End

// Start
        let elementdate_1 = 1
        let total_elemente = 3

        function click_dateclock() {
            if(elementdate_1==total_elemente) {
            elementdate_1=1;
                UpdateElementeOne();
                }
            else {
                elementdate_1=elementdate_1+1;
                if(elementdate_1==2) {
                  UpdateElementeTwo();
                }
		if(elementdate_1==3) {
                  UpdateElementeThree();
                }
            }
           // if(elementdate_1==1) hmUI.showToast({text: '1'});
           // if(elementdate_1==2) hmUI.showToast({text: '2'});
	   // if(elementdate_1==3) hmUI.showToast({text: '3'});
        }

        //clock Date
        function UpdateElementeOne(){
		normal_time_hour_min_text_font.setProperty(hmUI.prop.VISIBLE, true);
        	normal_month_name_font.setProperty(hmUI.prop.VISIBLE, true);
		normal_day_text_font.setProperty(hmUI.prop.VISIBLE, true);
		normal_dow_text_font.setProperty(hmUI.prop.VISIBLE, true);
		
		normal_day_text_font_1.setProperty(hmUI.prop.VISIBLE, false);
		normal_dow_text_font_1.setProperty(hmUI.prop.VISIBLE, false);
		solo_time_hour_min_text_font.setProperty(hmUI.prop.VISIBLE, false);

		Button_2.setProperty(hmUI.prop.VISIBLE, true);
		Button_3.setProperty(hmUI.prop.VISIBLE, true);
		Button_7.setProperty(hmUI.prop.VISIBLE, false);
		Button_8.setProperty(hmUI.prop.VISIBLE, false);
        }
        //clock
        function UpdateElementeTwo(){
        	normal_month_name_font.setProperty(hmUI.prop.VISIBLE, false);
		normal_day_text_font.setProperty(hmUI.prop.VISIBLE, false);
		normal_dow_text_font.setProperty(hmUI.prop.VISIBLE, false);
		normal_time_hour_min_text_font.setProperty(hmUI.prop.VISIBLE, false);

		normal_day_text_font_1.setProperty(hmUI.prop.VISIBLE, false);
		normal_dow_text_font_1.setProperty(hmUI.prop.VISIBLE, false);
		solo_time_hour_min_text_font.setProperty(hmUI.prop.VISIBLE, true);

		Button_2.setProperty(hmUI.prop.VISIBLE, false);
		Button_3.setProperty(hmUI.prop.VISIBLE, false);
		Button_7.setProperty(hmUI.prop.VISIBLE, true);
		Button_8.setProperty(hmUI.prop.VISIBLE, false);
        }
	//Date
        function UpdateElementeThree(){
        	normal_month_name_font.setProperty(hmUI.prop.VISIBLE, false);
		normal_day_text_font.setProperty(hmUI.prop.VISIBLE, false);
		normal_dow_text_font.setProperty(hmUI.prop.VISIBLE, false);
		normal_time_hour_min_text_font.setProperty(hmUI.prop.VISIBLE, false);

		normal_day_text_font_1.setProperty(hmUI.prop.VISIBLE, true);
		normal_dow_text_font_1.setProperty(hmUI.prop.VISIBLE, true);
		solo_time_hour_min_text_font.setProperty(hmUI.prop.VISIBLE, false);

		Button_2.setProperty(hmUI.prop.VISIBLE, false);
		Button_3.setProperty(hmUI.prop.VISIBLE, false);
		Button_7.setProperty(hmUI.prop.VISIBLE, false);
		Button_8.setProperty(hmUI.prop.VISIBLE, true);
        }
// end
        let normal_background_bg_img = ''
        let normal_analog_clock_time_pointer_second = ''
        let normal_sun_icon_img = ''
        let normal_sun_low_text_font = ''
        let normal_sun_high_text_font = ''
        let normal_month_name_font = ''
        let normal_Month_Array = ['/01', '/02', '/03', '/04', '/05', '/06', '/07', '/08', '/09', '/10', '/11', '/12', ];
        let normal_day_text_font = ''
	let normal_day_text_font_1 = ''
        let normal_dow_text_font = ''
        let normal_dow_text_font_1 = ''
        let normal_DOW_Array =  ['LUN', 'MAR', 'MER', 'GIO', 'VEN', 'SAB', 'DOM'];
        let normal_time_hour_min_text_font = ''
        let normal_timerTimeUpdate = undefined;
	let solo_time_hour_min_text_font = ''
	let solo_timerTimeUpdate = undefined;
        let normal_step_pointer_progress_img_pointer = ''
        let normal_battery_pointer_progress_img_pointer = ''
        let normal_analog_clock_pro_hour_pointer_img = ''
        let normal_analog_clock_pro_minute_pointer_img = ''
        let normal_analog_clock_pro_second_pointer_img = ''
        let normal_timerUpdateSec = undefined;
        let idle_time_hour_min_text_font = ''
        let idle_timerTimeUpdate = undefined;
        let Button_1 = ''
        let Button_2 = ''
        let Button_3 = ''
        let Button_4 = ''
        let Button_5 = ''
	let Button_6 = ''
	let Button_7 = ''
	let Button_8 = ''
	let Button_9 = ''
        let timeSensor = ''

        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
            console.log('Watch_Face.ScreenNormal');
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 466,
              h: 466,
              src: 'bck_1.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_second = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              second_path: 'radar3.png',
              second_centerX: 138,
              second_centerY: 232,
              second_posX: 57,
              second_posY: 58,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sun_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 125,
              y: 222,
              src: 'su_1.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sun_low_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 64,
              y: 243,
              w: 146,
              h: 29,
              text_size: 24,
              char_space: 0,
              line_space: 0,
              color: 0xFF6A6A6A,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              type: hmUI.data_type.SUN_SET,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sun_high_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 64,
              y: 195,
              w: 146,
              h: 29,
              text_size: 24,
              char_space: 0,
              line_space: 0,
              color: 0xFF6A6A6A,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              type: hmUI.data_type.SUN_RISE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            if (!timeSensor) timeSensor = hmSensor.createSensor(hmSensor.id.TIME);
            timeSensor.addEventListener(timeSensor.event.DAYCHANGE, function() {
              time_update(true);
            });

            normal_month_name_font = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 351,
              y: 229,
              w: 150,
              h: 30,
              text_size: 19,
              char_space: 0,
              line_space: 0,
              color: 0xFF6A6A6A,
              align_h: hmUI.align.LEFT,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              // unit_string: /01, /02, /03, /04, /05, /06, /07, /08, /09, /10, /11, /12,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_day_text_font = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 328,
              y: 229,
              w: 146,
              h: 39,
              text_size: 19,
              char_space: 0,
              line_space: 0,
              color: 0xFF6A6A6A,
              align_h: hmUI.align.LEFT,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              // padding: true,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_day_text_font_1 = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 236,
              y: 213,
              w: 150,
              h: 39,
              text_size: 30,
              char_space: 0,
              line_space: 0,
              color: 0xFF6A6A6A,
              align_h: hmUI.align.RIGHT,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              // padding: true,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
              normal_day_text_font_1.setProperty(hmUI.prop.VISIBLE, false);

            normal_dow_text_font = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 283,
              y: 229,
              w: 146,
              h: 43,
              text_size: 19,
              char_space: 0,
              line_space: 0,
              color: 0xFF6A6A6A,
              align_h: hmUI.align.LEFT,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              // unit_string: LUN,MAR,MER,GIO,VEN,SAB,DOM,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_dow_text_font_1 = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 281,
              y: 211,
              w: 146,
              h: 43,
              text_size: 30,
              char_space: 0,
              line_space: 0,
              color: 0xFF6A6A6A,
              align_h: hmUI.align.LEFT,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              // unit_string: LUN,MAR,MER,GIO,VEN,SAB,DOM,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
              normal_dow_text_font_1.setProperty(hmUI.prop.VISIBLE, false);

            normal_time_hour_min_text_font = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 284,
              y: 207,
              w: 146,
              h: 29,
              text_size: 20,
              char_space: 0,
              line_space: 0,
              color: 0xFF6A6A6A,
              align_h: hmUI.align.LEFT,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              // padding: true,
              // unit_type: 2,
              // unit_end: true,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

	    solo_time_hour_min_text_font = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 259,
              y: 217,
              w: 146,
              h: 29,
              text_size: 40,
              char_space: 0,
              line_space: 0,
              color: 0xFF6A6A6A,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              // padding: true,
              // unit_type: 2,
              // unit_end: true,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
              solo_time_hour_min_text_font.setProperty(hmUI.prop.VISIBLE, false);

            normal_step_pointer_progress_img_pointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
              src: 't_bs1.png',
              center_x: 232,
              center_y: 328,
              x: 4,
              y: 45,
              start_angle: 227,
              end_angle: 490,
              invalid_visible: false,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_pointer_progress_img_pointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
              src: 't_bs1.png',
              center_x: 233,
              center_y: 136,
              x: 4,
              y: 45,
              start_angle: 226,
              end_angle: 493,
              invalid_visible: false,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            const deviceInfo = hmSetting.getDeviceInfo();
            timeSensor.addEventListener(timeSensor.event.MINUTEEND, function() {
              let updateHour = timeSensor.minute == 0;

              time_update(UpdateHour, true);
            });

            // normal_analog_clock_pro_hour_pointer_img = hmUI.createWidget(hmUI.widget.TIME_POINTER_PRO, {
              // src: 't_hor1.png',
              // center_x: 233,
              // center_y: 233,
              // x: 233,
              // y: 233,
              // start_angle: 0,
              // end_angle: 360,
              // type: hmUI.data_type.hour,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_analog_clock_pro_hour_pointer_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: deviceInfo.width,
              h: deviceInfo.height,
              pos_x: 233 - 233,
              pos_y: 233 - 233,
              center_x: 233,
              center_y: 233,
              src: 't_hor1.png',
              angle: 0,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_analog_clock_pro_minute_pointer_img = hmUI.createWidget(hmUI.widget.TIME_POINTER_PRO, {
              // src: 't_min1.png',
              // center_x: 233,
              // center_y: 233,
              // x: 233,
              // y: 233,
              // start_angle: 0,
              // end_angle: 360,
              // type: hmUI.data_type.minute,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_analog_clock_pro_minute_pointer_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: deviceInfo.width,
              h: deviceInfo.height,
              pos_x: 233 - 233,
              pos_y: 233 - 233,
              center_x: 233,
              center_y: 233,
              src: 't_min1.png',
              angle: 0,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_analog_clock_pro_second_pointer_img = hmUI.createWidget(hmUI.widget.TIME_POINTER_PRO, {
              // src: 't_sec1.png',
              // center_x: 233,
              // center_y: 233,
              // x: 233,
              // y: 233,
              // start_angle: 0,
              // end_angle: 360,
              // type: hmUI.data_type.second,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_analog_clock_pro_second_pointer_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: deviceInfo.width,
              h: deviceInfo.height,
              pos_x: 233 - 233,
              pos_y: 233 - 233,
              center_x: 233,
              center_y: 233,
              src: 't_sec1.png',
              angle: 0,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            console.log('Watch_Face.ScreenAOD');
            idle_time_hour_min_text_font = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 283,
              y: 193,
              w: 231,
              h: 72,
              text_size: 50,
              char_space: 0,
              line_space: 0,
              color: 0xFFFFFFFF,
              align_h: hmUI.align.LEFT,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              // padding: true,
              // unit_type: 2,
              // unit_end: true,
              show_level: hmUI.show_level.ONLY_AOD,
            });
            
            // disconnectAlert = hmUI.createWidget(hmUI.widget.DisconnectAlert, {
              // disconneсnt_vibrate_type: 0,
              // disconneсnt_toast_text: Bluetooth Off,
              // conneсnt_vibrate_type: 0,
              // conneсnt_toast_text: Bluetooth On,
            // });

            // vibration when connecting or disconnecting

            function checkConnection() {
              console.log('checkConnection()');
              hmBle.removeListener;
              hmBle.addListener(function (status) {
                if(!status) {
                  hmUI.showToast({text: "Bluetooth Off"});
                  vibro(0);
                }
                if(status) {
                  hmUI.showToast({text: "Bluetooth On"});
                  vibro(0);
                }
              });
            }

            // end vibration when connecting or disconnecting
            // vibrate function

            const vibrate = hmSensor.createSensor(hmSensor.id.VIBRATE);
            let timer_StopVibrate = null;


            function vibro(scene = 25) {
              let stopDelay = 50;
              stopVibro();
              vibrate.stop();
              vibrate.scene = scene;
              if(scene < 23 || scene > 25) stopDelay = 1300;
              vibrate.start();
              if (scene != 1) timer_StopVibrate = timer.createTimer(stopDelay, 3000, stopVibro, {});
            }

            function stopVibro(){
              vibrate.stop();
              if(timer_StopVibrate) timer.stopTimer(timer_StopVibrate);
            }

            // end vibrate function

            console.log('Watch_Face.Buttons');
            Button_1 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 193,
              y: 97,
              w: 78,
              h: 68,
              text: '',
              color: 0xFFFF8C00,
              text_size: 24,
              press_src: 'null.png',
              normal_src: 'null.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'Settings_batteryManagerScreen', native: true });
                vibro(25);
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_2 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 277,
              y: 179,
              w: 113,
              h: 53,
              text: '',
              color: 0xFFFF8C00,
              text_size: 24,
              press_src: 'null.png',
              normal_src: 'null.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'AlarmInfoScreen', native: true });
                vibro(25);
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_3 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 277,
              y: 237,
              w: 113,
              h: 45,
              text: '',
              color: 0xFFFF8C00,
              text_size: 24,
              press_src: 'null.png',
              normal_src: 'null.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'ScheduleCalScreen', native: true });
                vibro(25);
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_4 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 194,
              y: 288,
              w: 79,
              h: 68,
              text: '',
              color: 0xFFFF8C00,
              text_size: 24,
              press_src: 'null.png',
              normal_src: 'null.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'activityAppScreen', native: true });
                vibro(25);
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_5 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 400,
              y: 198,
              w: 64,
              h: 63,
              text: '',
              color: 0xFFFF8C00,
              text_size: 24,
              press_src: 'null.png',
              normal_src: 'null.png',
              click_func: (button_widget) => {    
		click_dateclock();
                vibro(25);
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_6 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 205,
              y: 208,
              w: 59,
              h: 50,
              text: '',
              color: 0xFFFF8C00,
              text_size: 24,
              press_src: 'null.png',
              normal_src: 'null.png',
              click_func: (button_widget) => {
                click_COLOR();
		color();
                vibro(25);
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button
//start
            Button_7 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 276,
              y: 208,
              w: 113,
              h: 53,
              text: '',
              color: 0xFFFF8C00,
              text_size: 24,
              press_src: 'null.png',
              normal_src: 'null.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'AlarmInfoScreen', native: true });
                vibro(25);
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button  
              Button_7.setProperty(hmUI.prop.VISIBLE, false);

            Button_8 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 276,
              y: 208,
              w: 113,
              h: 53,
              text: '',
              color: 0xFFFF8C00,
              text_size: 24,
              press_src: 'null.png',
              normal_src: 'null.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'ScheduleCalScreen', native: true });
                vibro(25);
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button
              Button_8.setProperty(hmUI.prop.VISIBLE, false);

            Button_9 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 95,
              y: 193,
              w: 87,
              h: 80,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'null.png',
              normal_src: 'null.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'TideScreen', native: true });
                vibro(25);
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button
//end
            //start of ignored block
            function time_update(updateHour = false, updateMinute = false) {
              console.log('time_update()');
              let hour = timeSensor.hour;
              let minute = timeSensor.minute;
              let second = timeSensor.second;
              let format_hour = timeSensor.format_hour;

              console.log('month font');
              if (updateHour) {
                let normal_Month_Str = normal_Month_Array[timeSensor.month-1];
                normal_month_name_font.setProperty(hmUI.prop.TEXT, normal_Month_Str );
              };

              console.log('day font');
              if (updateHour) {
                let normal_dayStr = timeSensor.day.toString();
                normal_dayStr = normal_dayStr.padStart(2, '0');
                normal_day_text_font.setProperty(hmUI.prop.TEXT, normal_dayStr );
              };

              console.log('day of week font');
              if (updateHour) {
                let normal_DOW_Str = normal_DOW_Array[timeSensor.week-1];
                normal_dow_text_font.setProperty(hmUI.prop.TEXT, normal_DOW_Str );
              };

              console.log('hour:min font');
              if (updateMinute) {
                let normal_HourMinStr = format_hour.toString();
                normal_HourMinStr = normal_HourMinStr.padStart(2, '0');
                normal_HourMinStr = normal_HourMinStr + ':' + minute.toString().padStart(2, '0')
                if (!timeSensor.is24Hour) {
                  if (hour > 11) normal_HourMinStr = normal_HourMinStr + ' PM';
                  else normal_HourMinStr = normal_HourMinStr + ' AM';
                };
		normal_time_hour_min_text_font.setProperty(hmUI.prop.TEXT, normal_HourMinStr );
              };

              if (updateHour) {
                let normal_hour = hour;
                let normal_fullAngle_hour = 360;
                if (normal_hour > 11) normal_hour -= 12;
                let normal_angle_hour = 0 + normal_fullAngle_hour*normal_hour/12 + (normal_fullAngle_hour/12)*minute/60;
                if (normal_analog_clock_pro_hour_pointer_img) normal_analog_clock_pro_hour_pointer_img.setProperty(hmUI.prop.ANGLE, normal_angle_hour);
              };

              if (updateMinute) {
                let normal_fullAngle_minute = 360;
                let normal_angle_minute = 0 + normal_fullAngle_minute*minute/60;
                if (normal_analog_clock_pro_minute_pointer_img) normal_analog_clock_pro_minute_pointer_img.setProperty(hmUI.prop.ANGLE, normal_angle_minute);
              };

              let normal_fullAngle_second = 360;
              let normal_angle_second = 0 + normal_fullAngle_second*second/60;
              if (normal_analog_clock_pro_second_pointer_img) normal_analog_clock_pro_second_pointer_img.setProperty(hmUI.prop.ANGLE, normal_angle_second);
//
              console.log('day font_1');
              if (updateHour) {
                let normal_dayStr = timeSensor.day.toString();
                normal_dayStr = normal_dayStr.padStart(2, '0');
                normal_day_text_font_1.setProperty(hmUI.prop.TEXT, normal_dayStr );
              };

              console.log('day of week font_1');
              if (updateHour) {
                let normal_DOW_Str = normal_DOW_Array[timeSensor.week-1];
                normal_dow_text_font_1.setProperty(hmUI.prop.TEXT, normal_DOW_Str );
              };
//
              console.log('hour:min font');
              if (updateMinute) {
                let normal_HourMinStr = format_hour.toString();
                normal_HourMinStr = normal_HourMinStr.padStart(2, '0');
                normal_HourMinStr = normal_HourMinStr + ':' + minute.toString().padStart(2, '0')
                if (!timeSensor.is24Hour) {
                  if (hour > 11) normal_HourMinStr = normal_HourMinStr + '';
                  else normal_HourMinStr = normal_HourMinStr + '';
                };
		solo_time_hour_min_text_font.setProperty(hmUI.prop.TEXT, normal_HourMinStr );
              };
//
              console.log('hour:min font');
              if (updateMinute) {
                let idle_HourMinStr = format_hour.toString();
                idle_HourMinStr = idle_HourMinStr.padStart(2, '0');
                idle_HourMinStr = idle_HourMinStr + ':' + minute.toString().padStart(2, '0')
                if (!timeSensor.is24Hour) {
                  if (hour > 11) idle_HourMinStr = idle_HourMinStr + '';
                  else idle_HourMinStr = idle_HourMinStr + '';
                };
                idle_time_hour_min_text_font.setProperty(hmUI.prop.TEXT, idle_HourMinStr );
              };

            };

            //end of ignored block
            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                console.log('resume_call()');
                time_update(true, true);
                if (screenType == hmSetting.screen_type.WATCHFACE) {
                  if (!normal_timerTimeUpdate) {
                    normal_timerTimeUpdate = timer.createTimer(0, 1000, (function (option) {
                      let updateHour = timeSensor.minute == 0;
                      let updateMinute = timeSensor.second < 2;
                      time_update(updateHour, updateMinute);
                    }));  // end timer 
                  };  // end timer check
                };  // end screenType

                if (screenType == hmSetting.screen_type.WATCHFACE) {
                  if (!normal_timerUpdateSec) {
                    let animDelay = timeSensor.utc % 1000;
                    let animRepeat = 1000;
                    normal_timerUpdateSec = timer.createTimer(animDelay, animRepeat, (function (option) {
                      time_update(false, false);
                    }));  // end timer 
                  };  // end timer check
                };  // end screenType

                if (screenType == hmSetting.screen_type.AOD) {
                  if (!idle_timerTimeUpdate) {
                    idle_timerTimeUpdate = timer.createTimer(0, 1000, (function (option) {
                      let updateHour = timeSensor.minute == 0;
                      let updateMinute = timeSensor.second < 2;
                      time_update(updateHour, updateMinute);
                    }));  // end timer 
                  };  // end timer check
                };  // end screenType

                checkConnection();
                stopVibro();

              }),
              pause_call: (function () {
                console.log('pause_call()');
                if (normal_timerTimeUpdate) {
                  timer.stopTimer(normal_timerTimeUpdate);
                  normal_timerTimeUpdate = undefined;
                }
                if (normal_timerUpdateSec) {
                  timer.stopTimer(normal_timerUpdateSec);
                  normal_timerUpdateSec = undefined;
                }
                if (idle_timerTimeUpdate) {
                  timer.stopTimer(idle_timerTimeUpdate);
                  idle_timerTimeUpdate = undefined;
                }
                stopVibro();

              }),
            });

                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}