﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        const logger = Logger.getLogger('watchface_SashaCX75');
        //end of ignored block

        //dynamic modify start

        
        let normal_background_bg_img = ''
		let normal_image_alarm = ''
		let alarm_clock_img = '' 
        let normal_temperature_current_text_img = ''
        let normal_weather_image_progress_img_level = ''
        let normal_date_img_date_week_img = ''
        let normal_date_img_date_day = ''
        let normal_system_disconnect_img = ''
        let normal_battery_icon_img = ''
        let normal_battery_pointer_progress_img_pointer = ''
        let normal_battery_text_text_img = ''
        let normal_battery_image_progress_img_level = ''
        let normal_digital_clock_img_time = ''
        let normal_digital_clock_hour_separator_img = ''
        let normal_digital_clock_minute_separator_img = ''
        let normal_heart_rate_icon_img = ''
        let normal_heart_rate_pointer_progress_img_pointer = ''
        let normal_heart_rate_text_text_img = ''
        let normal_calorie_icon_img = ''
        let normal_calorie_pointer_progress_img_pointer = ''
        let normal_calorie_current_text_img = ''
        let normal_step_icon_img = ''
        let normal_step_pointer_progress_img_pointer = ''
        let normal_step_current_text_img = ''
        let normal_analog_clock_time_pointer_hour = ''
        let normal_analog_clock_time_pointer_minute = ''
        let normal_analog_clock_time_pointer_second = ''
        let idle_background_bg_img = ''
        let idle_date_img_date_week_img = ''
        let idle_date_img_date_day = ''
        let idle_system_disconnect_img = ''
        let idle_battery_icon_img = ''
        let idle_battery_text_text_img = ''
        let idle_battery_image_progress_img_level = ''
        let idle_analog_clock_time_pointer_hour = ''
        let idle_analog_clock_time_pointer_minute = ''
        let idle_analog_clock_time_pointer_second = ''
		
		let btn_zona1 = ''
        let zona1_num = 0
        let zona1_all = 5
		
		function click_zona1() {
		  zona1_num = (zona1_num + 1) % (zona1_all + 1);
          if (zona1_num == 0) {		
		    normal_digital_clock_img_time.setProperty(hmUI.prop.VISIBLE, true);
            normal_digital_clock_hour_separator_img.setProperty(hmUI.prop.VISIBLE, true);
		    normal_digital_clock_minute_separator_img.setProperty(hmUI.prop.VISIBLE, true);
			normal_image_alarm.setProperty(hmUI.prop.VISIBLE, false);
			alarm_clock_img.setProperty(hmUI.prop.VISIBLE, false);
            normal_step_pointer_progress_img_pointer.setProperty(hmUI.prop.VISIBLE, false);
		    normal_step_icon_img.setProperty(hmUI.prop.VISIBLE, false);
            normal_step_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_calorie_pointer_progress_img_pointer.setProperty(hmUI.prop.VISIBLE, false);
			normal_calorie_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_calorie_icon_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_heart_rate_pointer_progress_img_pointer.setProperty(hmUI.prop.VISIBLE, false);
			normal_heart_rate_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_heart_rate_icon_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_battery_pointer_progress_img_pointer.setProperty(hmUI.prop.VISIBLE, false);
			normal_battery_icon_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_battery_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_battery_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, false);
		    hmUI.showToast({
            });
          };
		  
		 if (zona1_num == 1) {
			normal_digital_clock_img_time.setProperty(hmUI.prop.VISIBLE, false);
            normal_digital_clock_hour_separator_img.setProperty(hmUI.prop.VISIBLE, false);
		    normal_digital_clock_minute_separator_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_image_alarm.setProperty(hmUI.prop.VISIBLE, true);
			alarm_clock_img.setProperty(hmUI.prop.VISIBLE, true);
            normal_step_pointer_progress_img_pointer.setProperty(hmUI.prop.VISIBLE, false);
		    normal_step_icon_img.setProperty(hmUI.prop.VISIBLE, false);
            normal_step_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_calorie_pointer_progress_img_pointer.setProperty(hmUI.prop.VISIBLE, false);
			normal_calorie_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_calorie_icon_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_heart_rate_pointer_progress_img_pointer.setProperty(hmUI.prop.VISIBLE, false);
			normal_heart_rate_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_heart_rate_icon_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_battery_pointer_progress_img_pointer.setProperty(hmUI.prop.VISIBLE, false);
			normal_battery_icon_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_battery_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_battery_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, false);
		    hmUI.showToast({
            });
          };
		  
		 if (zona1_num == 2) {
			normal_digital_clock_img_time.setProperty(hmUI.prop.VISIBLE, false);
            normal_digital_clock_hour_separator_img.setProperty(hmUI.prop.VISIBLE, false);
		    normal_digital_clock_minute_separator_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_image_alarm.setProperty(hmUI.prop.VISIBLE, false);
			alarm_clock_img.setProperty(hmUI.prop.VISIBLE, false);
            normal_step_pointer_progress_img_pointer.setProperty(hmUI.prop.VISIBLE, true);
		    normal_step_icon_img.setProperty(hmUI.prop.VISIBLE, true);
            normal_step_current_text_img.setProperty(hmUI.prop.VISIBLE, true);
			normal_calorie_pointer_progress_img_pointer.setProperty(hmUI.prop.VISIBLE, false);
			normal_calorie_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_calorie_icon_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_heart_rate_pointer_progress_img_pointer.setProperty(hmUI.prop.VISIBLE, false);
			normal_heart_rate_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_heart_rate_icon_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_battery_pointer_progress_img_pointer.setProperty(hmUI.prop.VISIBLE, false);
			normal_battery_icon_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_battery_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_battery_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, false);
		    hmUI.showToast({
            });
          };
		  
		  if (zona1_num == 3) {
			normal_digital_clock_img_time.setProperty(hmUI.prop.VISIBLE, false);
            normal_digital_clock_hour_separator_img.setProperty(hmUI.prop.VISIBLE, false);
		    normal_digital_clock_minute_separator_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_image_alarm.setProperty(hmUI.prop.VISIBLE, false);
			alarm_clock_img.setProperty(hmUI.prop.VISIBLE, false);
            normal_step_pointer_progress_img_pointer.setProperty(hmUI.prop.VISIBLE, false);
		    normal_step_icon_img.setProperty(hmUI.prop.VISIBLE, false);
            normal_step_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_calorie_pointer_progress_img_pointer.setProperty(hmUI.prop.VISIBLE, true);
			normal_calorie_current_text_img.setProperty(hmUI.prop.VISIBLE, true);
			normal_calorie_icon_img.setProperty(hmUI.prop.VISIBLE, true);
			normal_heart_rate_pointer_progress_img_pointer.setProperty(hmUI.prop.VISIBLE, false);
			normal_heart_rate_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_heart_rate_icon_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_battery_pointer_progress_img_pointer.setProperty(hmUI.prop.VISIBLE, false);
			normal_battery_icon_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_battery_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_battery_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, false);
		    hmUI.showToast({
            });
          };
		  
		  if (zona1_num == 4) {
			normal_digital_clock_img_time.setProperty(hmUI.prop.VISIBLE, false);
            normal_digital_clock_hour_separator_img.setProperty(hmUI.prop.VISIBLE, false);
		    normal_digital_clock_minute_separator_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_image_alarm.setProperty(hmUI.prop.VISIBLE, false);
			alarm_clock_img.setProperty(hmUI.prop.VISIBLE, false);
            normal_step_pointer_progress_img_pointer.setProperty(hmUI.prop.VISIBLE, false);
		    normal_step_icon_img.setProperty(hmUI.prop.VISIBLE, false);
            normal_step_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_calorie_pointer_progress_img_pointer.setProperty(hmUI.prop.VISIBLE, false);
			normal_calorie_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_calorie_icon_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_heart_rate_pointer_progress_img_pointer.setProperty(hmUI.prop.VISIBLE, true);
			normal_heart_rate_text_text_img.setProperty(hmUI.prop.VISIBLE, true);
			normal_heart_rate_icon_img.setProperty(hmUI.prop.VISIBLE, true);
			normal_battery_pointer_progress_img_pointer.setProperty(hmUI.prop.VISIBLE, false);
			normal_battery_icon_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_battery_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_battery_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, false);
		    hmUI.showToast({
            });
          };
		  
		  if (zona1_num == 5) {
			normal_digital_clock_img_time.setProperty(hmUI.prop.VISIBLE, false);
            normal_digital_clock_hour_separator_img.setProperty(hmUI.prop.VISIBLE, false);
		    normal_digital_clock_minute_separator_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_image_alarm.setProperty(hmUI.prop.VISIBLE, false);
			alarm_clock_img.setProperty(hmUI.prop.VISIBLE, false);
            normal_step_pointer_progress_img_pointer.setProperty(hmUI.prop.VISIBLE, false);
		    normal_step_icon_img.setProperty(hmUI.prop.VISIBLE, false);
            normal_step_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_calorie_pointer_progress_img_pointer.setProperty(hmUI.prop.VISIBLE, false);
			normal_calorie_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_calorie_icon_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_heart_rate_pointer_progress_img_pointer.setProperty(hmUI.prop.VISIBLE, false);
			normal_heart_rate_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_heart_rate_icon_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_battery_pointer_progress_img_pointer.setProperty(hmUI.prop.VISIBLE, true);
			normal_battery_icon_img.setProperty(hmUI.prop.VISIBLE, true);
			normal_battery_text_text_img.setProperty(hmUI.prop.VISIBLE, true);
			normal_battery_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, true);
		    hmUI.showToast({
            });
          };
        }


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 466,
              h: 466,
              src: '127.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
			
			normal_image_alarm = hmUI.createWidget(hmUI.widget.IMG, {
              x: 113,
              y: -1,
              src: '88.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
			
			alarm_clock_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 148,
              y: 80,
              font_array: ["128.png","129.png","130.png","131.png","132.png","133.png","134.png","135.png","136.png","137.png"],
              padding: true,
              h_space: 0,
              dot_image: 'dot.png',
			  invalid_image: 's_minus.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.ALARM_CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 379,
              y: 224,
              font_array: ["66.png","67.png","68.png","69.png","70.png","71.png","72.png","73.png","74.png","75.png"],
              padding: false,
              h_space: 0,
              negative_image: 'minus.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 320,
              y: 211,
              image_array: ["w_0.png","w_1.png","w_2.png","w_3.png","w_4.png","w_5.png","w_6.png","w_7.png","w_8.png","w_9.png","w_10.png","w_11.png","w_12.png","w_13.png","w_14.png","w_15.png","w_16.png","w_17.png","w_18.png","w_19.png","w_20.png","w_21.png","w_22.png","w_23.png","w_24.png","w_25.png","w_26.png","w_27.png","w_28.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 79,
              y: 220,
              week_en: ["day_1.png","day_2.png","day_3.png","day_4.png","day_5.png","day_6.png","day_7.png"],
              week_tc: ["day_1.png","day_2.png","day_3.png","day_4.png","day_5.png","day_6.png","day_7.png"],
              week_sc: ["day_1.png","day_2.png","day_3.png","day_4.png","day_5.png","day_6.png","day_7.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 42,
              day_startY: 221,
              day_sc_array: ["66.png","67.png","68.png","69.png","70.png","71.png","72.png","73.png","74.png","75.png"],
              day_tc_array: ["66.png","67.png","68.png","69.png","70.png","71.png","72.png","73.png","74.png","75.png"],
              day_en_array: ["66.png","67.png","68.png","69.png","70.png","71.png","72.png","73.png","74.png","75.png"],
              day_zero: 1,
              day_space: 0,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 0,
              y: 0,
              src: 'bt.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 113,
              y: -1,
              src: '78.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_pointer_progress_img_pointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
              src: 'point.png',
              center_x: 233,
              center_y: 233,
              x: 12,
              y: 192,
              start_angle: -29,
              end_angle: 29,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 206,
              y: 360,
              font_array: ["66.png","67.png","68.png","69.png","70.png","71.png","72.png","73.png","74.png","75.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 224,
              y: 8,
              image_array: ["6.png","7.png","8.png","9.png","10.png","11.png","12.png","13.png","14.png","15.png","16.png"],
              image_length: 11,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 148,
              hour_startY: 80,
              hour_array: ["128.png","129.png","130.png","131.png","132.png","133.png","134.png","135.png","136.png","137.png"],
              hour_zero: 1,
              hour_space: 0,
              hour_angle: 0,
              hour_align: hmUI.align.LEFT,

              minute_startX: 249,
              minute_startY: 80,
              minute_array: ["128.png","129.png","130.png","131.png","132.png","133.png","134.png","135.png","136.png","137.png"],
              minute_zero: 1,
              minute_space: 0,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_hour_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 228,
              y: 88,
              src: 'dot.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_minute_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 113,
              y: -1,
              src: '92.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 113,
              y: -1,
              src: 'bpm.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_pointer_progress_img_pointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
              src: 'point.png',
              center_x: 233,
              center_y: 233,
              x: 12,
              y: 192,
              start_angle: -29,
              end_angle: 29,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 206,
              y: 360,
              font_array: ["66.png","67.png","68.png","69.png","70.png","71.png","72.png","73.png","74.png","75.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_calorie_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 113,
              y: -1,
              src: 'cal.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_calorie_pointer_progress_img_pointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
              src: 'point.png',
              center_x: 233,
              center_y: 233,
              x: 12,
              y: 192,
              start_angle: -29,
              end_angle: 29,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_calorie_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 199,
              y: 360,
              font_array: ["66.png","67.png","68.png","69.png","70.png","71.png","72.png","73.png","74.png","75.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 113,
              y: -1,
              src: '86.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_pointer_progress_img_pointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
              src: 'point.png',
              center_x: 233,
              center_y: 233,
              x: 12,
              y: 192,
              start_angle: -29,
              end_angle: 29,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 189,
              y: 360,
              font_array: ["66.png","67.png","68.png","69.png","70.png","71.png","72.png","73.png","74.png","75.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_hour = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              hour_path: 'hour.png',
              hour_centerX: 233,
              hour_centerY: 233,
              hour_posX: 28,
              hour_posY: 217,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_minute = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              minute_path: 'minute.png',
              minute_centerX: 233,
              minute_centerY: 233,
              minute_posX: 29,
              minute_posY: 217,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_second = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              second_path: 'second.png',
              second_centerX: 233,
              second_centerY: 233,
              second_posX: 18,
              second_posY: 231,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            idle_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 466,
              h: 466,
              src: '127.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 185,
              y: 110,
              week_en: ["day_1.png","day_2.png","day_3.png","day_4.png","day_5.png","day_6.png","day_7.png"],
              week_tc: ["day_1.png","day_2.png","day_3.png","day_4.png","day_5.png","day_6.png","day_7.png"],
              week_sc: ["day_1.png","day_2.png","day_3.png","day_4.png","day_5.png","day_6.png","day_7.png"],
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 215,
              day_startY: 78,
              day_sc_array: ["66.png","67.png","68.png","69.png","70.png","71.png","72.png","73.png","74.png","75.png"],
              day_tc_array: ["66.png","67.png","68.png","69.png","70.png","71.png","72.png","73.png","74.png","75.png"],
              day_en_array: ["66.png","67.png","68.png","69.png","70.png","71.png","72.png","73.png","74.png","75.png"],
              day_zero: 1,
              day_space: 0,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 0,
              y: 0,
              src: 'bt.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_battery_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 113,
              y: -1,
              src: '78.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 206,
              y: 360,
              font_array: ["66.png","67.png","68.png","69.png","70.png","71.png","72.png","73.png","74.png","75.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_battery_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 224,
              y: 8,
              image_array: ["6.png","7.png","8.png","9.png","10.png","11.png","12.png","13.png","14.png","15.png","16.png"],
              image_length: 11,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_analog_clock_time_pointer_hour = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              hour_path: 'hour.png',
              hour_centerX: 233,
              hour_centerY: 233,
              hour_posX: 28,
              hour_posY: 217,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_analog_clock_time_pointer_minute = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              minute_path: 'minute.png',
              minute_centerX: 233,
              minute_centerY: 233,
              minute_posX: 29,
              minute_posY: 217,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_analog_clock_time_pointer_second = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              second_path: 'second.png',
              second_centerX: 233,
              second_centerY: 233,
              second_posX: 18,
              second_posY: 231,
              show_level: hmUI.show_level.ONLY_AOD,
            });
            
            // disconnectAlert = hmUI.createWidget(hmUI.widget.DisconnectAlert, {
              // disconneсnt_vibrate_type: 9,
              // disconneсnt_toast_text: Connect LOST,
              // conneсnt_vibrate_type: 0,
              // conneсnt_toast_text: Connect FIND,
            // });

            // vibration when connecting or disconnecting

            function checkConnection() {
              hmBle.removeListener;
              hmBle.addListener(function (status) {
                if(!status) {
                  hmUI.showToast({text: "Connect LOST"});
                  vibro(9);
                }
                if(status) {
                  hmUI.showToast({text: "Connect FIND"});
                  vibro(0);
                }
              });
            }

            // end vibration when connecting or disconnecting
            // vibrate function

            const vibrate = hmSensor.createSensor(hmSensor.id.VIBRATE);
            let timer_StopVibrate = null;


            function vibro(scene = 25) {
              let stopDelay = 50;
              stopVibro();
              vibrate.stop();
              vibrate.scene = scene;
              if(scene < 23 || scene > 25) stopDelay = 1300;
              vibrate.start();
              timer_StopVibrate = timer.createTimer(stopDelay, 3000, stopVibro, {});
            }

            function stopVibro(){
              vibrate.stop();
              if(timer_StopVibrate) timer.stopTimer(timer_StopVibrate);
            }

            // end vibrate function

            btn_zona1 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 187, 
              y: 7, 
              text: '',
              w: 100, 
              h: 380,
              normal_src: 'Empty.png',
              press_src: 'Empty.png',
              click_func: () => {
                click_zona1();
                click_Vibrate(); 
              },
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            btn_zona1.setProperty(hmUI.prop.VISIBLE, true);
			normal_image_alarm.setProperty(hmUI.prop.VISIBLE, false);
			alarm_clock_img.setProperty(hmUI.prop.VISIBLE, false);
            normal_step_pointer_progress_img_pointer.setProperty(hmUI.prop.VISIBLE, false);
		    normal_step_icon_img.setProperty(hmUI.prop.VISIBLE, false);
            normal_step_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_calorie_pointer_progress_img_pointer.setProperty(hmUI.prop.VISIBLE, false);
			normal_calorie_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_calorie_icon_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_heart_rate_pointer_progress_img_pointer.setProperty(hmUI.prop.VISIBLE, false);
			normal_heart_rate_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_heart_rate_icon_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_battery_pointer_progress_img_pointer.setProperty(hmUI.prop.VISIBLE, false);
			normal_battery_icon_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_battery_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_battery_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, false);

            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                checkConnection();
                stopVibro();

              }),
              pause_call: (function () {
                stopVibro();

              }),
            });

                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}